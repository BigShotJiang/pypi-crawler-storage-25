# querit-cli

Command-line interface for the [Querit](https://www.querit.ai) Content Retrieval Platform — search the web directly from your terminal or scripts.

## Installation

```bash
pip install querit-cli
```

## Quick Start

```bash
# Authenticate
querit login --api-key YOUR_API_KEY

# Basic search
querit search "climate change"

# Limit result count
querit search "python tutorial" --count 5

# Filter by time range (past 7 days)
querit search "latest AI news" --time-range d7

# Filter by site
querit search "technology" --sites-include bbc.com --sites-exclude reddit.com

# Filter by country and language
querit search "local news" --countries france --countries germany --languages en

# Save results to file
querit search "machine learning" --output results.json

# JSON output (for scripts and agents)
querit search "query" --json

# Interactive REPL mode
querit
```

## Authentication

Set your API key using one of:

```bash
# Save to config file (~/.querit/config.json)
querit login --api-key YOUR_API_KEY

# Or use environment variable
export QUERIT_API_KEY=YOUR_API_KEY
```

Get your API key at [querit.ai](https://www.querit.ai).

## Search Options

| Option | Description |
|---|---|
| `--count N` | Maximum number of results |
| `--sites-include SITE` | Only include results from this site (repeatable) |
| `--sites-exclude SITE` | Exclude results from this site (repeatable) |
| `--time-range RANGE` | Time filter: `d7`, `w2`, `m3`, `y1`, or `2024-01-01to2024-06-30` |
| `--countries CC` | Limit to countries, e.g. `france`, `germany` (repeatable) |
| `--languages LANG` | Limit to languages, e.g. `en`, `zh` (repeatable) |
| `--output FILE` | Save full JSON response to file |
| `--json` | Output as JSON for scripts and agents |

## Links

- [Querit Platform](https://www.querit.ai)
- [API Documentation](https://www.querit.ai/en/docs/reference/post)
- [Python SDK](https://www.querit.ai/en/docs/sdks/python)
