"""Main CLI entry point — wires all commands into the `querit` group."""

from __future__ import annotations

import click

from querit_cli import __version__
from querit_cli.commands.auth import auth_status, login, logout
from querit_cli.commands.search import search


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, default=False, help="Show version and exit.")
@click.option("--status", "show_status", is_flag=True, default=False, help="Show version and auth status.")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output as JSON (for agents and scripts).")
@click.pass_context
def cli(ctx: click.Context, version: bool, show_status: bool, json_output: bool) -> None:
    """Querit CLI — search the web from the command line.

    Authenticate with: querit login --api-key YOUR_KEY
    Or set the QUERIT_API_KEY environment variable.
    """
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output

    if version:
        if json_output:
            import json
            click.echo(json.dumps({"version": __version__}))
        else:
            click.echo(f"querit-cli {__version__}")
        ctx.exit(0)
        return

    if show_status:
        _print_status(json_output)
        ctx.exit(0)
        return

    if ctx.invoked_subcommand is None:
        from querit_cli.repl import run_repl
        run_repl()
        ctx.exit(0)


def _print_status(json_output: bool) -> None:
    """Show version + auth status."""
    import json as _json
    import os

    from querit_cli.config import get_api_key

    key = get_api_key()
    authenticated = key is not None

    if json_output:
        click.echo(_json.dumps({
            "version": __version__,
            "authenticated": authenticated,
        }))
    else:
        from rich.console import Console
        console = Console()
        console.print(f"  [bold #00C2C2]querit[/bold #00C2C2] v{__version__}")
        console.print()
        if authenticated:
            source = "QUERIT_API_KEY env var" if os.environ.get("QUERIT_API_KEY") else "~/.querit/config.json"
            console.print(f"  [#9BC0AE]>[/#9BC0AE] Authenticated via {source}")
        else:
            console.print("  [#FAA2FB]>[/#FAA2FB] Not authenticated")
            console.print("    Run: querit login --api-key YOUR_KEY")


cli.add_command(login)
cli.add_command(logout)
cli.add_command(auth_status)
cli.add_command(search)


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
