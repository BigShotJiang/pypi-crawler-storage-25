"""Formatted output for Querit CLI search results."""

from __future__ import annotations

import json
from typing import Any

import click
from rich.console import Console
from rich.rule import Rule
from rich.text import Text
from rich.theme import Theme

_theme = Theme({
    "markdown.h1": "bold #00C2C2",
    "markdown.h2": "bold #00C2C2",
    "markdown.h3": "bold #00C2C2",
})

console     = Console(theme=_theme)
err_console = Console(stderr=True)


def emit(data: Any, *, json_mode: bool, output_file: str | None = None) -> None:
    """Serialise data as JSON to stdout or a file."""
    text = json.dumps(data, indent=2, ensure_ascii=False)
    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text + "\n")
    else:
        click.echo(text)


def print_search_results(
    response: dict,
    *,
    json_mode: bool,
    output_file: str | None = None,
) -> None:
    """Render Querit search results in human-readable or JSON format."""
    if json_mode:
        emit(response, json_mode=True, output_file=output_file)
        return

    results = response.get("results", {}).get("result", [])
    took    = response.get("took", "")

    if not results:
        console.print()
        console.print("  [dim]No results found.[/dim]")
        console.print()
        return

    console.print()
    for i, r in enumerate(results, 1):
        title    = r.get("title") or r.get("url", "Untitled")
        url      = r.get("url", "")
        snippet  = r.get("snippet", "")
        site     = r.get("site_name", "")
        page_age = r.get("page_age", "")

        # Title
        title_text = Text()
        title_text.append(f"  {i}. ", style="dim")
        title_text.append(title, style="bold #00C2C2")
        console.print(title_text)

        # Meta: site name + age + url
        meta = Text("     ")
        if site:
            meta.append(site, style="#9BC0AE")
        if page_age:
            meta.append(f"  {page_age}", style="dim")
        if url:
            meta.append(f"  {url}", style="dim underline")
        console.print(meta)

        # Snippet
        if snippet:
            short = snippet[:300] + ("…" if len(snippet) > 300 else "")
            console.print(f"     [dim]{short}[/dim]")

        console.print()

    # Footer: result count + server response time
    footer_parts = [f"{len(results)} results"]
    if took:
        footer_parts.append(took)
    console.print(Rule(f"[dim]{' | '.join(footer_parts)}[/dim]", style="dim"))
    console.print()

    if output_file:
        emit(response, json_mode=True, output_file=output_file)
        err_console.print(f"  [dim]Saved to {output_file}[/dim]")
