"""Brand colours, Rich console instances, and the spinner helper."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Generator

from rich.console import Console

# Brand colours
TEAL   = "#00C2C2"
PINK   = "#FAA2FB"
YELLOW = "#FFC769"
BLUE   = "#5B8AF9"
GREEN  = "#9BC0AE"

BRAND   = TEAL
ACCENT  = BLUE
SUCCESS = GREEN
WARN    = YELLOW
ERROR   = PINK

console     = Console()
err_console = Console(stderr=True)

LOGO = """\
[#00C2C2]   ___  _   _  ___  ____  _  _____ [/#00C2C2]
[#5B8AF9]  / _ \\| | | |/ _ \\|  _ \\| ||_   _|[/#5B8AF9]
[#9BC0AE] | | | | | | | | | | |_) | |  | |  [/#9BC0AE]
[#FFC769] | |_| | |_| | |_| |  _ <| |__| |  [/#FFC769]
[#FAA2FB]  \\__\\_\\\\___/ \\___/|_| \\_\\_____|_|  [/#FAA2FB]"""

LOGO_COMPACT = "[#00C2C2 bold]querit[/#00C2C2 bold]"


@contextmanager
def spinner(message: str, *, json_mode: bool = False) -> Generator[None, None, None]:
    """Show a live spinner on stderr; silent in JSON mode."""
    if json_mode:
        yield
        return
    with err_console.status(f"[{TEAL}]{message}[/{TEAL}]", spinner="dots"):
        yield
