"""querit login / logout / auth — credential management."""

from __future__ import annotations

import click


@click.command()
@click.option("--api-key", default=None, help="Your Querit API key.")
def login(api_key: str | None) -> None:
    """Save your Querit API key locally."""
    from rich.console import Console
    from querit_cli.config import save_api_key

    console = Console(stderr=True)
    if not api_key:
        api_key = click.prompt("  Enter your Querit API key", hide_input=True)

    save_api_key(api_key.strip())
    console.print("  [#9BC0AE]>[/#9BC0AE] API key saved.")
    console.print("  [dim]Stored in ~/.querit/config.json[/dim]")


@click.command()
def logout() -> None:
    """Remove your saved Querit API key."""
    from rich.console import Console
    from querit_cli.config import clear_credentials

    console = Console(stderr=True)
    clear_credentials()
    console.print("  [#9BC0AE]>[/#9BC0AE] Credentials cleared.")


@click.command("auth")
def auth_status() -> None:
    """Show current authentication status."""
    import os
    from rich.console import Console
    from querit_cli.config import get_api_key

    console = Console(stderr=True)
    key = get_api_key()

    console.print()
    if key:
        masked = key[:8] + "..." if len(key) > 8 else key
        source = "QUERIT_API_KEY env var" if os.environ.get("QUERIT_API_KEY") else "~/.querit/config.json"
        console.print(f"  [#9BC0AE]>[/#9BC0AE] Authenticated via {source}")
        console.print(f"  [dim]Key: {masked}[/dim]")
    else:
        console.print("  [#FAA2FB]>[/#FAA2FB] Not authenticated")
        console.print("    Run: [#00C2C2]querit login --api-key YOUR_KEY[/#00C2C2]")
    console.print()
