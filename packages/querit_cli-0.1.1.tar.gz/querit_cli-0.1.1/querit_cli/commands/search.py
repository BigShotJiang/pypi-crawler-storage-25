"""querit search — web search via the Querit API."""

from __future__ import annotations

import click

from querit_cli.common import handle_api_error


@click.command()
@click.argument("query", required=False)
@click.option("--count", type=int, default=None,
              help="Maximum number of results to return.")
@click.option("--sites-include", multiple=True, metavar="SITE",
              help="Only include results from this site (repeatable). E.g. --sites-include bbc.com")
@click.option("--sites-exclude", multiple=True, metavar="SITE",
              help="Exclude results from this site (repeatable). E.g. --sites-exclude reddit.com")
@click.option("--time-range", default=None, metavar="RANGE",
              help=(
                  "Time range filter. Examples: "
                  "d7 (past 7 days), w2 (past 2 weeks), m3 (past 3 months), "
                  "y1 (past 1 year), 2024-01-01to2024-06-30 (date range)."
              ))
@click.option("--countries", multiple=True, metavar="CC",
              help="Limit results to these countries (repeatable). E.g. --countries france --countries germany")
@click.option("--languages", multiple=True, metavar="LANG",
              help="Limit results to these languages (repeatable). E.g. --languages en --languages zh")
@click.option("--output", "-o", "output_file", default=None,
              help="Save full JSON response to this file.")
@click.option("--json", "json_flag", is_flag=True, default=False,
              help="Output as JSON (for scripts and agents).")
@click.pass_context
def search(
    ctx: click.Context,
    query: str | None,
    count: int | None,
    sites_include: tuple[str, ...],
    sites_exclude: tuple[str, ...],
    time_range: str | None,
    countries: tuple[str, ...],
    languages: tuple[str, ...],
    output_file: str | None,
    json_flag: bool,
) -> None:
    """Search the web using the Querit API.

    QUERY is your search term.

    Examples:

      querit search "climate change"

      querit search "python tutorial" --count 5

      querit search "news" --time-range d7 --countries US

      querit search "site news" --sites-include bbc.com --sites-include reuters.com
    """
    from querit_cli.config import get_client
    from querit_cli.output import print_search_results
    from querit_cli.theme import spinner

    # Inherit --json from parent context (the global `querit --json` flag)
    json_mode = json_flag or bool(ctx.obj and ctx.obj.get("json_output"))

    if not query:
        raise click.UsageError('QUERY is required. Example: querit search "your query"')

    client = get_client()

    try:
        with spinner("Searching...", json_mode=json_mode):
            response = client.search(
                query,
                count=count,
                sites_include=list(sites_include) or None,
                sites_exclude=list(sites_exclude) or None,
                time_range=time_range,
                countries=list(countries) or None,
                languages=list(languages) or None,
            )
    except Exception as e:
        handle_api_error(e, json_mode)
        return

    print_search_results(response, json_mode=json_mode, output_file=output_file)
