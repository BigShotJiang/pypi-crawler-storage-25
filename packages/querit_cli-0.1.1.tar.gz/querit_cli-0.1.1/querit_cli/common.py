"""Shared utilities: custom exception, error handler."""

from __future__ import annotations

import json

import click

from querit_cli.theme import err_console


class QueritAPIError(Exception):
    """Structured error from the Querit API."""

    def __init__(self, message: str, *, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


def handle_api_error(e: Exception, json_mode: bool) -> None:
    """Print a formatted error message and exit."""
    if json_mode:
        click.echo(json.dumps({"error": str(e)}))
        raise SystemExit(4)
    if isinstance(e, QueritAPIError) and e.status == 429:
        err_console.print(f"  [#FFC769]>[/#FFC769] Rate limit exceeded: {e}")
        err_console.print("  [dim]Check your plan at[/dim] [#00C2C2 link=https://www.querit.ai]querit.ai[/#00C2C2 link=https://www.querit.ai]")
        raise SystemExit(3)
    err_console.print(f"  [#FAA2FB]> Error:[/#FAA2FB] {e}")
    raise SystemExit(4)
