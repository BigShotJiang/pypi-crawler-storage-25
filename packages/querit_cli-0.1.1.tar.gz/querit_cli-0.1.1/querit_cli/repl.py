"""Interactive REPL — gives querit a clean, chat-like shell."""

from __future__ import annotations

import readline  # noqa: F401 — enables arrow-key history in input()
import shlex

import click
from rich.console import Console
from rich.rule import Rule
from rich.text import Text

from querit_cli import __version__
from querit_cli.config import get_api_key
from querit_cli.theme import LOGO

err_console = Console(stderr=True)

_REPL_COMMANDS = {"search", "login", "logout", "auth"}


def _print_banner() -> None:
    """Print the welcome banner inside the REPL."""
    key = get_api_key()

    err_console.print(LOGO)
    err_console.print(f"  [dim]v{__version__}[/dim]")
    err_console.print()

    if key:
        err_console.print("  [#9BC0AE]>[/#9BC0AE] Authenticated")
    else:
        err_console.print("  [#FAA2FB]>[/#FAA2FB] Not authenticated")
        err_console.print("    Type [#00C2C2]login[/#00C2C2] to set your API key.")

    err_console.print()

    tips = Text()
    tips.append("  Tips: ", style="bold")
    tips.append("search ", style="#00C2C2")
    tips.append('"query"', style="dim")
    tips.append("  |  ", style="dim")
    tips.append("search ", style="#00C2C2")
    tips.append('"query" --count 5', style="dim")
    tips.append("  |  ", style="dim")
    tips.append("help", style="#00C2C2")
    tips.append("  |  ", style="dim")
    tips.append("exit", style="#00C2C2")
    err_console.print(tips)
    err_console.print()


def _print_help() -> None:
    """Print REPL help."""
    err_console.print()
    cmds = Text()
    cmds.append("  Commands\n\n", style="bold")
    cmds.append('    search "your query"', style="#00C2C2")
    cmds.append("                     Web search\n")
    cmds.append('    search "query" --count N', style="#00C2C2")
    cmds.append("            Limit result count\n")
    cmds.append('    search "query" --time-range d7', style="#00C2C2")
    cmds.append("      Past 7 days\n")
    cmds.append('    search "query" --sites-include bbc.com', style="#00C2C2")
    cmds.append("  Site filter\n")
    cmds.append('    search "query" --countries US --languages en', style="#00C2C2")
    cmds.append("  Geo/lang filter\n")
    cmds.append("    login", style="#00C2C2")
    cmds.append("                              Authenticate\n")
    cmds.append("    logout", style="#00C2C2")
    cmds.append("                             Clear credentials\n")
    cmds.append("    auth", style="#00C2C2")
    cmds.append("                               Auth status\n")
    cmds.append("    exit / quit / Ctrl+C", style="#00C2C2")
    cmds.append("               Leave\n")
    err_console.print(cmds)


def _prompt() -> str:
    """Print the separator + prompt and read a line of input."""
    err_console.print(Rule(style="dim"))
    try:
        return input("\001\033[38;2;0;194;194m\002\u276f\001\033[0m\002  ")
    except EOFError:
        return "exit"


def run_repl() -> None:
    """Enter the interactive REPL loop."""
    err_console.print()
    _print_banner()

    while True:
        try:
            line = _prompt()
        except KeyboardInterrupt:
            err_console.print()
            err_console.print("  [dim]Farewell, hope to see you again![/dim]")
            err_console.print()
            break

        line = line.strip()
        if not line:
            continue

        if line in ("exit", "quit", "q"):
            err_console.print()
            err_console.print("  [dim]Farewell, hope to see you again![/dim]")
            err_console.print()
            break

        if line in ("help", "?"):
            _print_help()
            continue

        try:
            args = shlex.split(line)
        except ValueError as e:
            err_console.print(f"  [#FAA2FB]Parse error:[/#FAA2FB] {e}")
            continue

        # Allow "querit search ..." as well as plain "search ..."
        if args and args[0] == "querit":
            args = args[1:]

        if not args:
            continue

        from querit_cli.cli import cli
        err_console.print()
        try:
            cli(args, standalone_mode=False)
        except SystemExit:
            pass
        except KeyboardInterrupt:
            err_console.print()
            err_console.print("  [dim]Cancelled.[/dim]")
        except click.exceptions.UsageError as e:
            err_console.print(f"  [#FAA2FB]>[/#FAA2FB] {e.format_message()}")
        except Exception as e:
            err_console.print(f"  [#FAA2FB]> Error:[/#FAA2FB] {e}")

        err_console.print()
