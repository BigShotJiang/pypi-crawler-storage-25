"""Querit CLI — search the web from the command line."""

__version__ = "0.1.0"
