class NoSplitFoundWarning(RuntimeWarning):
    pass