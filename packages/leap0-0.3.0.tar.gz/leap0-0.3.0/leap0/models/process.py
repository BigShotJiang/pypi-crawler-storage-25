from __future__ import annotations

from dataclasses import dataclass
from .._schemas.process import ProcessResultDict

@dataclass(slots=True)
class ProcessResult:
    """Result of a one-shot process execution."""
    exit_code: int
    result: str

    @classmethod
    def from_dict(cls, data: ProcessResultDict) -> ProcessResult:
        """Build an instance from a wire-format dictionary."""
        return cls(exit_code=int(data.get("exit_code", 0)), result=data.get("result", ""))
