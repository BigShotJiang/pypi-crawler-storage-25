"""
Kafka topics registry.

All Kafka topic names should be defined here as StrEnum.
This ensures consistency across producers and consumers in all services,
provides type safety, and enables IDE autocomplete.

Naming convention: <domain>.<event_type>
Examples:
    - notifications.otp
    - orders.created
    - inventory.updated
"""

from enum import StrEnum


class KafkaTopic(StrEnum):
    """Kafka topic names for the microservices ecosystem."""

    # Notifications domain
    NOTIFICATIONS_OTP = "notifications.otp"


__all__ = [
    "KafkaTopic",
]
