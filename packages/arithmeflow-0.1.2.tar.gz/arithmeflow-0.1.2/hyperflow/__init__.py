import numpy as np
from scipy.integrate import solve_ivp

def _flow(z, F, x, y):
    u = x*y - x - y
    L = np.log(x) + np.log(y) - np.log(x + y)
    L_star = L / (1 + L)
    t = z - 1
    remaining = (x*y - F[0]) / (2 - z + 1e-10)
    shape = 1 + 2 * np.sin(np.pi * t)
    dF = remaining * shape * (1 + L_star) / (1 + abs(u)/(x*y))
    return [dF]

def compute(x: float, y: float, z: float) -> float:
    """
    Compute F(x, y, z) — smooth interpolation between addition (z=1)
    and multiplication (z=2).
    
    F(x, y, 1) = x + y
    F(x, y, 2) = x * y
    """
    z = max(1.0, min(2.0, z))
    sol = solve_ivp(_flow, [1, z], [x + y], args=(x, y),
                    dense_output=True, max_step=0.001,
                    rtol=1e-6, atol=1e-8)
    return float(sol.sol([z])[0][0])

def curve(x: float, y: float, steps: int = 50) -> list:
    """
    Return the full interpolation curve as a list of (z, value) pairs.
    """
    z_vals = np.linspace(1, 2, steps)
    return [(round(float(z), 4), compute(x, y, float(z))) for z in z_vals]
