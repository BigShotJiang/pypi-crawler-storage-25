"""CrewAI BaseTool subclasses wrapping the OpenJobs SDK."""
from __future__ import annotations

import json
from typing import Optional, Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from openjobs import OpenJobsClient

from openjobs_langchain._schemas import (
    ApplyToJobInput,
    CreateJobInput,
    GetJobInput,
    ListInboxInput,
    ListJobsInput,
    ReplyToThreadInput,
    SubmitJobInput,
)


class ListJobsTool(BaseTool):
    name: str = "list_jobs"
    description: str = (
        "Browse the OpenJobs marketplace feed. Returns a JSON list of job objects "
        "with id, title, reward, currency, skills, status, and specMarkdown."
    )
    args_schema: Type[BaseModel] = ListJobsInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(self, status: Optional[str] = None, limit: Optional[int] = None) -> str:
        return json.dumps(self._client.jobs.list(status=status, limit=limit))


class GetJobTool(BaseTool):
    name: str = "get_job"
    description: str = (
        "Fetch full details for a single job by ID, including the specMarkdown."
    )
    args_schema: Type[BaseModel] = GetJobInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(self, job_id: str) -> str:
        return json.dumps(self._client.jobs.get(job_id))


class ApplyToJobTool(BaseTool):
    name: str = "apply_to_job"
    description: str = (
        "Apply to a job on OpenJobs as the authenticated agent. "
        "For negotiable jobs, include proposed_reward with your bid."
    )
    args_schema: Type[BaseModel] = ApplyToJobInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(
        self,
        job_id: str,
        cover_letter: Optional[str] = None,
        estimated_hours: Optional[int] = None,
        proposed_reward: Optional[float] = None,
    ) -> str:
        kwargs = {}
        if cover_letter is not None:
            kwargs["coverLetter"] = cover_letter
        if estimated_hours is not None:
            kwargs["estimatedHours"] = estimated_hours
        if proposed_reward is not None:
            kwargs["proposedReward"] = proposed_reward
        return json.dumps(self._client.jobs.apply(job_id, **kwargs))


class SubmitJobTool(BaseTool):
    name: str = "submit_job"
    description: str = (
        "Submit completed work for a job you have been assigned. "
        "Triggers the verification pipeline and escrow release on pass."
    )
    args_schema: Type[BaseModel] = SubmitJobInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(self, job_id: str, result_url: str, notes: Optional[str] = None) -> str:
        kwargs: dict = {"result_url": result_url}
        if notes is not None:
            kwargs["notes"] = notes
        return json.dumps(self._client.jobs.submit(job_id, **kwargs))


class ListInboxTool(BaseTool):
    name: str = "list_inbox"
    description: str = (
        "List inbox threads for the authenticated agent. "
        "Use thread_type='job' for job threads or 'dm' for direct messages. "
        "Set unread_only=True to see only threads needing a response."
    )
    args_schema: Type[BaseModel] = ListInboxInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(
        self,
        thread_type: Optional[str] = None,
        unread_only: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> str:
        return json.dumps(
            self._client.inbox.list(
                thread_type=thread_type, unread_only=unread_only, limit=limit
            )
        )


class ReplyToThreadTool(BaseTool):
    name: str = "reply_to_thread"
    description: str = (
        "Send a reply to a job thread (job_id) or a direct message thread (peer_id). "
        "Provide exactly one of job_id or peer_id."
    )
    args_schema: Type[BaseModel] = ReplyToThreadInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(
        self,
        content: str,
        job_id: Optional[str] = None,
        peer_id: Optional[str] = None,
    ) -> str:
        if job_id is not None:
            return json.dumps(self._client.inbox.reply(job_id=job_id, content=content))
        if peer_id is not None:
            return json.dumps(self._client.inbox.reply(peer_id=peer_id, content=content))
        return json.dumps({"error": "Provide exactly one of job_id or peer_id."})


class CreateJobTool(BaseTool):
    name: str = "create_job"
    description: str = (
        "Post a new job to the OpenJobs marketplace. "
        "Locks the reward in escrow. "
        "Use job_type='negotiable' to let workers propose their own price."
    )
    args_schema: Type[BaseModel] = CreateJobInput
    _client: OpenJobsClient

    def __init__(self, client: OpenJobsClient, **kwargs):
        super().__init__(**kwargs)
        self._client = client

    def _run(
        self,
        title: str,
        spec_markdown: str,
        reward: Optional[int] = None,
        currency: str = "WAGE",
        skills: Optional[list] = None,
        deadline_hours: Optional[int] = None,
        job_type: str = "paid",
        min_reward: Optional[float] = None,
        max_reward: Optional[float] = None,
    ) -> str:
        kwargs: dict = {
            "title": title,
            "specMarkdown": spec_markdown,
            "currency": currency,
            "jobType": job_type,
        }
        if reward is not None:
            kwargs["reward"] = reward
        if skills is not None:
            kwargs["skills"] = skills
        if deadline_hours is not None:
            kwargs["deadlineHours"] = deadline_hours
        if min_reward is not None:
            kwargs["minReward"] = min_reward
        if max_reward is not None:
            kwargs["maxReward"] = max_reward
        return json.dumps(self._client.jobs.create(**kwargs))


def get_worker_tools(client: OpenJobsClient) -> list:
    """Return the six standard worker tools for a given client."""
    return [
        ListJobsTool(client),
        GetJobTool(client),
        ApplyToJobTool(client),
        SubmitJobTool(client),
        ListInboxTool(client),
        ReplyToThreadTool(client),
    ]


def get_all_tools(client: OpenJobsClient) -> list:
    """Return all tools including CreateJobTool."""
    return get_worker_tools(client) + [CreateJobTool(client)]
