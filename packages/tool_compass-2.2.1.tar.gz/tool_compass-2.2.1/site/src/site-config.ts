import type { SiteConfig } from '@mcptoolshop/site-theme';

export const config: SiteConfig = {
  title: 'Tool Compass',
  description: 'Semantic MCP tool discovery gateway — find tools by intent, not memory.',
  logoBadge: 'TC',
  brandName: 'Tool Compass',
  repoUrl: 'https://github.com/mcp-tool-shop-org/tool-compass',
  footerText: 'MIT Licensed — built by <a href="https://github.com/mcp-tool-shop-org" style="color:var(--color-muted);text-decoration:underline">mcp-tool-shop-org</a>',

  hero: {
    badge: 'MCP Gateway — v2.2',
    headline: 'Find tools by',
    headlineAccent: 'intent, not memory.',
    description: 'Semantic search for MCP tools. 95% fewer tokens, ~15ms latency, graceful Ollama-offline fallback, trace IDs you can paste into a bug report.',
    primaryCta: { href: '#quick-start', label: 'Quick Start' },
    secondaryCta: { href: 'handbook/', label: 'Read the Handbook' },
    previews: [
      {
        label: 'Install',
        code: 'ollama pull nomic-embed-text\npip install tool-compass\ntool-compass sync',
      },
      {
        label: 'CLI',
        code: 'tool-compass search "generate an AI image"\ntool-compass describe comfy:comfy_generate\ntool-compass doctor',
      },
      {
        label: 'MCP tool',
        code: 'compass(\n  intent="generate an AI image",\n  top_k=3\n)',
      },
      {
        label: 'Result',
        code: '# comfy:comfy_generate  0.91\n# tokens_saved: 20,500\n# trace_id: 9f3a1c7b',
      },
    ],
  },

  sections: [
    {
      kind: 'features',
      id: 'features',
      title: 'Why Tool Compass',
      subtitle: 'Stop loading all 77 tools into context. Find the right one — and keep finding it when things go sideways.',
      features: [
        {
          title: 'Semantic Discovery',
          desc: 'compass(intent) finds tools by meaning. Describe what you want to do — get the right tool, not a list of all of them.',
        },
        {
          title: '95% Token Savings',
          desc: '38,500 tokens → 2,000 per request. HNSW vector index, nomic-embed-text, ~15ms query latency, ~95% accuracy@3.',
        },
        {
          title: 'Progressive Disclosure',
          desc: 'compass() → describe() → execute(). Load only the schema you need, only when you actually need it.',
        },
        {
          title: 'Graceful degradation',
          desc: 'Ollama down? Compass falls back to keyword search over the same index, marks results degraded, and tells you exactly what to start.',
        },
        {
          title: 'Trace IDs in every response',
          desc: 'Every MCP call gets an 8-char trace_id plumbed into logs, success envelopes, and error envelopes. Paste it into a bug report and grep the logs.',
        },
        {
          title: 'Production observability',
          desc: '/ready does a deep probe (index + Ollama + backends). /metrics emits Prometheus text with embed p95, orphan vectors, per-backend up/down.',
        },
      ],
    },
    {
      kind: 'features',
      id: 'whats-new',
      title: "What's new in v2.2",
      subtitle: 'Stage A bug/security pass (23 HIGH), Stage B/C humanization (15 HIGH), plus 12 shipped features.',
      features: [
        {
          title: 'tool-compass CLI',
          desc: 'New subcommand shell: search, describe, sync, doctor, serve. Default (no args) still starts the MCP server — backward compatible.',
        },
        {
          title: 'Embedding cache',
          desc: 'Persistent SQLite cache keyed by (text, provider, model). Huge speedup on re-sync when most tool descriptions haven\'t changed.',
        },
        {
          title: 'Per-backend concurrency',
          desc: 'New id-keyed stdout reader replaces the blocking read lock. Concurrent calls to the same backend no longer head-of-line-block each other.',
        },
        {
          title: 'Diffing sync',
          desc: 'Upstream tool removed? Sync now diffs the old set against the new and calls remove_tool() for disappearing names. No more index orphans.',
        },
        {
          title: 'Multi-arch Docker',
          desc: 'GHCR image ships linux/amd64 + linux/arm64. Same tag works on x86_64 servers and Apple Silicon / ARM workstations without emulation.',
        },
        {
          title: 'Deprecated-alias handling',
          desc: 'ToolDefinition.deprecated_aliases + get_canonical_name() mean analytics stays consistent across tool renames. UI shows a "deprecated since vX.Y.Z" badge.',
        },
      ],
    },
    {
      kind: 'code-cards',
      id: 'quick-start',
      title: 'Quick Start',
      cards: [
        {
          title: 'Install & Index',
          code: '# Prerequisites: Ollama running locally\nollama pull nomic-embed-text\n\n# Install the CLI + gateway\npip install tool-compass\n\n# Build the search index from your configured backends\ntool-compass sync\n\n# Start the MCP gateway (or `tool-compass serve`)\ntool-compass',
        },
        {
          title: 'One-shot CLI',
          code: '# Search by intent without starting a server\ntool-compass search "generate an AI image" --top 3 --json\n\n# Inspect a tool\'s schema\ntool-compass describe comfy:comfy_generate\n\n# Diagnostics dump — version, config, Ollama reachability\ntool-compass doctor',
        },
        {
          title: 'MCP tool call',
          code: 'compass(\n  intent="I need to generate an AI image from text",\n  top_k=3,\n  min_confidence=0.3\n)\n\n# Returns (excerpt):\n# {\n#   "matches": [{\n#     "tool": "comfy:comfy_generate",\n#     "confidence": 0.912\n#   }],\n#   "tokens_saved": 20500,\n#   "trace_id": "9f3a1c7b"\n# }',
        },
        {
          title: 'Graceful Ollama-down',
          code: '# Ollama stopped mid-session? compass still answers:\ncompass(intent="read a file")\n\n# Returns:\n# {\n#   "matches": [{\n#     "tool": "bridge:read_file",\n#     "degraded": true\n#   }],\n#   "warnings": [\n#     "Semantic search unavailable: Ollama at\n#      http://localhost:11434 is unreachable.\n#      Try: ollama serve"\n#   ]\n# }',
        },
      ],
    },
    {
      kind: 'data-table',
      id: 'tools',
      title: 'Gateway Tools',
      subtitle: 'Nine MCP tools — one semantic entry point for your entire MCP ecosystem.',
      columns: ['Tool', 'Description'],
      rows: [
        ['compass(intent)', 'Semantic search — find the right tool by describing your intent'],
        ['describe(tool)', 'Get full JSON schema for a specific tool before calling it'],
        ['execute(tool, args)', 'Run any indexed tool directly through the gateway'],
        ['compass_categories()', 'List all tool categories and connected MCP servers'],
        ['compass_status()', 'System health — index size, model status, Ollama reachability'],
        ['compass_analytics(timeframe)', 'Usage statistics, accuracy metrics, and performance data'],
        ['compass_chains(action)', 'Discover and manage common multi-tool workflows'],
        ['compass_sync(force)', 'Rebuild the HNSW search index from connected backends'],
        ['compass_audit()', 'Full system diagnostic — index integrity, server health'],
      ],
    },
    {
      kind: 'data-table',
      id: 'operations',
      title: 'HTTP Endpoints',
      subtitle: 'Start the gateway in HTTP mode with `PORT=8000 tool-compass` for operator-grade endpoints.',
      columns: ['Endpoint', 'Purpose'],
      rows: [
        ['/health', 'Liveness probe — always 200 if the process is up.'],
        ['/ready', 'Readiness probe — 200 only when index loaded + Ollama reachable + ≥1 backend connected. 503 otherwise with a JSON breakdown of which check failed. Cached 30s.'],
        ['/metrics', 'Prometheus text format. search_total, ollama_available, backend_up{name}, backend_call_total{name,status}, embed_latency_p95_ms, embed_failures_total, index_age_seconds, orphaned_vectors.'],
        ['MCP JSON-RPC', 'Standard MCP streamable-http transport at the root. HOST env var defaults to 127.0.0.1 — set HOST=0.0.0.0 only behind an auth reverse proxy.'],
      ],
    },
  ],
};
