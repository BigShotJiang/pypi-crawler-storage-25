"""
Tool Compass Gateway - MCP Proxy Server
A semantic routing gateway that aggregates multiple MCP servers.

Architecture (based on 2026 best practices):
- Semantic search via HNSW + nomic-embed-text (MCP-Zero pattern)
- Progressive disclosure: compass() -> describe() -> execute()
- Configurable backend connections (stdio subprocess)
- 98% token reduction vs loading all tool schemas

Usage:
    python gateway.py              # Start gateway server
    python gateway.py --sync       # Sync tools from backends and rebuild index
    python gateway.py --test       # Run test queries
    python gateway.py --config     # Show current configuration

HTTP mode (PORT env var set) exposes three operational endpoints:

    GET /health   — Liveness probe. Always 200 while the process is up.
                    Returns ``{status, server, version}``.
    GET /ready    — Deep readiness probe (GW-FT-003). 200 only when the index
                    is loaded, Ollama is reachable (or the circuit breaker is
                    closed), and at least one configured backend is connected.
                    Otherwise 503 with per-check detail. Result is cached for
                    30s so load-balancer polling cannot DoS Ollama.
    GET /metrics  — Prometheus text format (GW-FT-003). Exposes counters and
                    gauges for search volume, Ollama availability, per-backend
                    health, embedder p95 latency / failures, and index age /
                    orphaned-vector counts. No ``prometheus_client`` dep — the
                    text is emitted manually.
"""

import asyncio
import argparse
import logging
import json
import sqlite3
import time
import uuid
from typing import Optional, List, Dict, Any

from _version import __version__

# MCP imports
try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print("FastMCP not installed. Install with: pip install mcp")
    raise

from indexer import CompassIndex, SearchResult
from tool_manifest import ToolDefinition
from config import load_config, CompassConfig, CONFIG_PATH
# Use simple backend client to avoid anyio conflicts when nested inside another MCP server
from backend_client_simple import SimpleBackendManager as BackendManager
from analytics import CompassAnalytics, get_analytics
from sync_manager import SyncManager, get_sync_manager
from chain_indexer import ChainIndexer, get_chain_indexer

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize MCP server
mcp = FastMCP("tool-compass-gateway")

# ---------------------------------------------------------------------------
# Runtime assumptions (single-process MCP server):
# - The gateway runs as a single process (FastMCP over stdio).
# - Module-level singletons are initialized lazily with asyncio.Lock
#   (double-checked locking) to handle concurrent coroutine access.
# - NOT thread-safe by design — MCP servers are single-threaded async.
# - For the Gradio UI (multi-threaded), see ui.py which uses threading.Lock.
# ---------------------------------------------------------------------------
_compass_index: Optional[CompassIndex] = None
_backend_manager: Optional[BackendManager] = None
_config: Optional[CompassConfig] = None
_analytics: Optional[CompassAnalytics] = None
_sync_manager: Optional[SyncManager] = None
_chain_indexer: Optional[ChainIndexer] = None
_startup_sync_done: bool = False

# GW-B-001 / GW-B-009: runtime health state surfaced via compass_status().
# The gateway degrades gracefully when a dependency is down — compass() falls
# back to lexical search, describe() falls back to the backend path — and
# every response envelope tells the user *why* results look different.
_health_state: Dict[str, Any] = {
    "ollama_available": True,
    "last_ollama_check": 0.0,
    "last_ollama_error": None,
    "index_available": True,
    "last_index_error": None,
}


def _mark_ollama_down(err: BaseException) -> None:
    """Record an Ollama failure so status + hints can surface it."""
    _health_state["ollama_available"] = False
    _health_state["last_ollama_check"] = time.time()
    _health_state["last_ollama_error"] = f"{type(err).__name__}: {err}"


def _mark_ollama_up() -> None:
    _health_state["ollama_available"] = True
    _health_state["last_ollama_check"] = time.time()
    _health_state["last_ollama_error"] = None

# Async locks to prevent race conditions during singleton initialization
_index_lock = asyncio.Lock()
_backend_lock = asyncio.Lock()
_analytics_lock = asyncio.Lock()
_sync_manager_lock = asyncio.Lock()
_chain_indexer_lock = asyncio.Lock()
_startup_sync_lock = asyncio.Lock()


def get_config() -> CompassConfig:
    """Get or load configuration."""
    global _config
    if _config is None:
        _config = load_config()
    return _config


async def get_index() -> CompassIndex:
    """Get or initialize the compass index.

    Uses double-checked locking pattern with asyncio.Lock to prevent
    race conditions when multiple coroutines call this concurrently.

    GW-B-001: If Ollama is unreachable, we still return a usable CompassIndex
    provided a prior ``db/compass.hnsw`` + ``db/tools.db`` exist on disk. The
    index won't be able to service semantic ``search()`` calls, but callers
    (compass(), describe()) can fall back to a lexical LIKE query against
    ``index.db`` and keep serving users instead of raising opaquely.
    """
    global _compass_index

    # Fast path: already initialized
    if _compass_index is not None:
        return _compass_index

    # Slow path: acquire lock and check again
    async with _index_lock:
        # Double-check after acquiring lock (another coroutine may have initialized)
        if _compass_index is not None:
            return _compass_index

        index = CompassIndex()

        # Try to load existing index
        if index.load_index():
            _compass_index = index
            return _compass_index

        logger.warning("No existing index found. Building from manifest...")

        # Check Ollama — building needs embeddings, so this is non-negotiable here.
        try:
            ollama_ok = await index.embedder.health_check()
        except Exception as e:
            _mark_ollama_down(e)
            raise RuntimeError(
                "Ollama not available and no cached index found at "
                f"{index.index_path}. Start Ollama (ollama serve) and run: "
                "ollama pull nomic-embed-text"
            ) from e

        if not ollama_ok:
            _mark_ollama_down(RuntimeError("health_check returned False"))
            raise RuntimeError(
                "Ollama not available and no cached index found at "
                f"{index.index_path}. Start Ollama (ollama serve) and run: "
                "ollama pull nomic-embed-text"
            )

        _mark_ollama_up()

        # Build index from static manifest
        await index.build_index()

        _compass_index = index

    return _compass_index


async def get_backends() -> BackendManager:
    """Get or initialize the backend manager.

    Uses double-checked locking pattern with asyncio.Lock.
    """
    global _backend_manager

    # Fast path
    if _backend_manager is not None:
        return _backend_manager

    # Slow path with lock
    async with _backend_lock:
        if _backend_manager is not None:
            return _backend_manager

        _backend_manager = BackendManager(get_config())

    return _backend_manager


async def get_analytics_instance() -> Optional[CompassAnalytics]:
    """Get or initialize the analytics engine.

    Uses double-checked locking pattern with asyncio.Lock.
    Returns None if analytics is disabled in config.
    """
    global _analytics
    config = get_config()

    if not config.analytics_enabled:
        return None

    # Fast path
    if _analytics is not None:
        return _analytics

    # Slow path with lock
    async with _analytics_lock:
        if _analytics is not None:
            return _analytics

        _analytics = get_analytics()
        await _analytics.load_hot_cache_from_db()

    return _analytics


async def get_sync_manager_instance() -> Optional[SyncManager]:
    """Get or initialize the sync manager.

    Uses double-checked locking pattern with asyncio.Lock.
    Returns None if auto_sync is disabled in config.
    """
    global _sync_manager
    config = get_config()

    if not config.auto_sync:
        return None

    # Fast path
    if _sync_manager is not None:
        return _sync_manager

    # Slow path with lock
    async with _sync_manager_lock:
        if _sync_manager is not None:
            return _sync_manager

        index = await get_index()
        backends = await get_backends()
        _sync_manager = get_sync_manager(config, index, backends)

    return _sync_manager


async def get_chain_indexer_instance() -> Optional[ChainIndexer]:
    """Get or initialize the chain indexer.

    Uses double-checked locking pattern with asyncio.Lock.
    Returns None if chain_indexing is disabled in config.
    """
    global _chain_indexer
    config = get_config()

    if not config.chain_indexing_enabled:
        return None

    # Fast path
    if _chain_indexer is not None:
        return _chain_indexer

    # Slow path with lock
    async with _chain_indexer_lock:
        if _chain_indexer is not None:
            return _chain_indexer

        index = await get_index()
        analytics = await get_analytics_instance()
        chain_indexer = get_chain_indexer(index.embedder, analytics)

        # Load existing chain index or build it
        if not await chain_indexer.load_chain_index():
            # Seed default chains and build index
            await chain_indexer.seed_default_chains()
            await chain_indexer.build_chain_index()

        _chain_indexer = chain_indexer

    return _chain_indexer


async def maybe_startup_sync():
    """Run startup sync if enabled and not yet done.

    Uses double-checked locking pattern with asyncio.Lock to ensure
    sync only runs once even with concurrent requests.
    """
    global _startup_sync_done
    config = get_config()

    if not config.sync_check_on_startup:
        return

    # Fast path: already done
    if _startup_sync_done:
        return

    # Slow path with lock
    async with _startup_sync_lock:
        # Double-check after acquiring lock
        if _startup_sync_done:
            return

        _startup_sync_done = True
        sync_manager = await get_sync_manager_instance()
        if sync_manager:
            try:
                await sync_manager.sync_if_needed()
            except Exception as e:
                logger.warning(f"Startup sync failed: {e}")


# =============================================================================
# GW-B-001: lexical fallback for when semantic search is unavailable.
# Simple LIKE query against the tools table — matches the same metadata fields
# the semantic index covers (name, description, category, server). No FTS5
# setup required.
# =============================================================================


def _lexical_search_fallback(
    index: CompassIndex,
    query: str,
    top_k: int,
    category: Optional[str],
    server: Optional[str],
) -> List[Dict[str, Any]]:
    """Return up to ``top_k`` tool matches via a case-insensitive LIKE scan.

    Each match is already in the response-envelope shape (``tool``,
    ``description``, ``server``, ``category``, ``confidence``, ``degraded``).
    Confidence is a coarse heuristic: 0.6 for name match, 0.4 for description
    match — enough to produce a sensible ordering without pretending it's a
    real similarity score.
    """
    if not index or not getattr(index, "db", None):
        return []

    needle = f"%{query.strip()}%"
    where = [
        "(lower(name) LIKE lower(?) OR lower(description) LIKE lower(?))"
    ]
    params: List[Any] = [needle, needle]
    if category:
        where.append("category = ?")
        params.append(category)
    if server:
        where.append("server = ?")
        params.append(server)

    sql = (
        "SELECT name, description, category, server "
        "FROM tools WHERE " + " AND ".join(where) + " LIMIT ?"
    )
    params.append(max(1, top_k * 3))

    rows = index.db.execute(sql, params).fetchall()
    q_lower = query.strip().lower()

    scored: List[Dict[str, Any]] = []
    for row in rows:
        name_lower = (row["name"] or "").lower()
        desc_lower = (row["description"] or "").lower()
        if q_lower in name_lower:
            confidence = 0.6
        elif q_lower in desc_lower:
            confidence = 0.4
        else:
            # Matched via per-token LIKE but not a direct substring — neutral score
            confidence = 0.3
        scored.append({
            "tool": row["name"],
            "description": row["description"],
            "server": row["server"],
            "category": row["category"],
            "confidence": confidence,
            "degraded": True,
        })

    scored.sort(key=lambda m: m["confidence"], reverse=True)
    return scored[:top_k]


# =============================================================================
# MCP TOOLS - The Gateway Interface
# =============================================================================


@mcp.tool()
async def compass(
    intent: str,
    top_k: int = 5,
    category: Optional[str] = None,
    server: Optional[str] = None,
    min_confidence: float = 0.3,
    include_chains: bool = True,
) -> Dict[str, Any]:
    """
    Find tools by describing what you want to accomplish.

    This is your starting point for tool discovery. Describe your task in natural
    language, and compass will return the most relevant tools using semantic search.
    Also searches for tool chains (workflows) that match your intent.

    WORKFLOW:
    1. compass("your task") -> get tool names, summaries, and matching workflows
    2. describe("tool_name") -> get full schema for chosen tool
    3. execute("tool_name", {...}) -> run the tool

    Args:
        intent: Natural language description of what you want to do.
                Examples: "read a file", "generate an image", "search documents"
        top_k: Maximum number of tools to return (1-10, default 5)
        category: Filter by category (file, git, database, ai, search, analysis, etc.)
        server: Filter by server (bridge, doc, comfy, video, chat)
        min_confidence: Minimum similarity score (0-1, default 0.3)
        include_chains: Also search for matching tool chains/workflows (default True)

    Returns:
        Tool matches with names, descriptions, and confidence scores.
        Also includes matching chains (workflows) if found.
        Use describe() to get full schemas, execute() to run tools.
    """
    start_time = time.time()
    trace_id = uuid.uuid4().hex[:8]
    config = get_config()
    top_k = max(1, min(10, top_k))
    min_confidence = max(0.0, min(1.0, min_confidence))

    warnings: List[str] = []
    degraded = False

    logger.info(
        f"[compass] [{trace_id}] intent={intent!r} top_k={top_k} "
        f"category={category} server={server} min_conf={min_confidence}"
    )

    # Check for sync on first call
    await maybe_startup_sync()

    index = await get_index()

    # Search tools — on embedder/Ollama failure fall back to lexical LIKE
    # over the existing tools table so users keep getting results.
    results: List[SearchResult] = []
    fallback_matches: List[Dict[str, Any]] = []
    try:
        results = await index.search(
            query=intent, top_k=top_k, category_filter=category, server_filter=server
        )
        _mark_ollama_up()
        # Filter by confidence
        results = [r for r in results if r.score >= min_confidence]
    except Exception as e:
        _mark_ollama_down(e)
        degraded = True
        logger.warning(
            f"[compass] [{trace_id}] semantic search failed ({type(e).__name__}: {e}); "
            "falling back to lexical search"
        )
        warnings.append(
            "Semantic search unavailable: Ollama is unreachable at "
            f"{config.ollama_url}. Try: ollama serve. "
            "Showing keyword-based results instead."
        )
        fallback_matches = _lexical_search_fallback(
            index, intent, top_k, category, server
        )

    # Search chains if enabled — chain search also relies on embeddings,
    # so a semantic outage will usually take this path down too. Don't let
    # that kill the whole response.
    chain_matches = []
    if include_chains and config.chain_indexing_enabled and not degraded:
        chain_indexer = await get_chain_indexer_instance()
        if chain_indexer:
            try:
                chain_results = await chain_indexer.search_chains(
                    intent, top_k=3, min_confidence=min_confidence
                )
                for cr in chain_results:
                    chain_matches.append({
                        "name": cr.chain.name,
                        "tools": cr.chain.tools,
                        "description": cr.chain.description,
                        "confidence": float(round(cr.score, 3)),
                        "use_count": cr.chain.use_count,
                    })
            except Exception as e:
                logger.warning(
                    f"[compass] [{trace_id}] chain search failed "
                    f"({type(e).__name__}: {e}); skipping chain matches"
                )
                warnings.append(
                    "Chain search skipped: embedding service unavailable."
                )

    # Build response - progressive disclosure means we only return summaries
    matches: List[Dict[str, Any]] = []
    if fallback_matches:
        # Lexical fallback path — fallback_matches is already shaped correctly.
        matches = fallback_matches
    else:
        for r in results:
            match_data = {
                "tool": r.tool.name,
                "description": r.tool.description,
                "server": r.tool.server,
                "category": r.tool.category,
                "confidence": float(round(r.score, 3)),
            }

            # Only include full schema if progressive disclosure is disabled
            if not config.progressive_disclosure:
                match_data["parameters"] = r.tool.parameters
                match_data["examples"] = r.tool.examples

            matches.append(match_data)

    # Stats
    stats = index.get_stats()
    total_tools = stats.get("total_tools", 0)

    # Calculate latency
    latency_ms = (time.time() - start_time) * 1000

    # Record analytics
    analytics = await get_analytics_instance()
    if analytics:
        await analytics.record_search(intent, results, latency_ms, category, server)

    # Hint for next steps
    if not matches and not chain_matches:
        hint = f"No tools found for '{intent}'. Try broader terms or use compass_categories() to see available categories."
    elif chain_matches and chain_matches[0]["confidence"] > (
        matches[0]["confidence"] if matches else 0
    ):
        # Chain is the best match
        chain_name = chain_matches[0]["name"]
        hint = f"Found workflow '{chain_name}' ({chain_matches[0]['confidence']:.0%}). Tools: {' → '.join(chain_matches[0]['tools'])}"
    elif len(matches) == 1:
        tool_name = matches[0]["tool"]
        if config.progressive_disclosure:
            hint = f"Found: {tool_name}. Use describe('{tool_name}') for full schema, then execute() to run."
        else:
            hint = f"Found: {tool_name}. Use execute('{tool_name}', {{...}}) to run."
    else:
        top_name = matches[0]["tool"]
        if config.progressive_disclosure:
            hint = f"Found {len(matches)} tools. Top: {top_name} ({matches[0]['confidence']:.0%}). Use describe() for schemas."
        else:
            hint = f"Found {len(matches)} tools. Top: {top_name} ({matches[0]['confidence']:.0%}). Use execute() to run."

    response = {
        "trace_id": trace_id,
        "matches": matches,
        "total_indexed": total_tools,
        "tokens_saved": max(0, (total_tools - len(matches)) * 500),
        "hint": hint,
        "workflow": "compass() -> describe() -> execute()"
        if config.progressive_disclosure
        else "compass() -> execute()",
        "degraded": degraded,
    }

    # Include chains if any found
    if chain_matches:
        response["chains"] = chain_matches

    if warnings:
        response["warnings"] = warnings

    return response


@mcp.tool()
async def describe(tool_name: str) -> Dict[str, Any]:
    """
    Get the full schema for a specific tool.

    Use this after compass() to get complete parameter information before calling execute().
    This progressive disclosure pattern saves tokens by only loading schemas when needed.

    Args:
        tool_name: The tool name from compass results (e.g., "bridge:read_file")

    Returns:
        Full tool schema including all parameters, types, and descriptions.
    """
    trace_id = uuid.uuid4().hex[:8]
    logger.info(f"[describe] [{trace_id}] tool_name={tool_name!r}")

    index = await get_index()

    # Try to find in index first (from manifest).
    # GW-B-009: trap sqlite errors so the user sees "index unhealthy" + a
    # fallthrough to the backend lookup path instead of an opaque stack.
    if index.db:
        try:
            cursor = index.db.execute(
                "SELECT name, description, category, server, parameters, examples FROM tools WHERE name = ?",
                (tool_name,),
            )
            row = cursor.fetchone()
        except sqlite3.Error as e:
            logger.error(
                f"[describe] [{trace_id}] index DB error: {type(e).__name__}: {e}"
            )
            _health_state["index_available"] = False
            _health_state["last_index_error"] = f"{type(e).__name__}: {e}"
            row = None
        else:
            _health_state["index_available"] = True

        if row:
            params = json.loads(row["parameters"]) if row["parameters"] else {}
            examples = json.loads(row["examples"]) if row["examples"] else []

            return {
                "trace_id": trace_id,
                "tool": row["name"],
                "description": row["description"],
                "server": row["server"],
                "category": row["category"],
                "parameters": params,
                "examples": examples,
                "hint": f"Use execute('{tool_name}', {{...}}) to run this tool.",
            }

    # Try backends if connected
    manager = await get_backends()
    schema = manager.get_tool_schema(tool_name)
    if schema:
        response: Dict[str, Any] = {
            "trace_id": trace_id,
            **schema,
            "hint": f"Use execute('{tool_name}', {{...}}) to run this tool.",
        }
        if not _health_state.get("index_available", True):
            response["warnings"] = [
                "Index database unhealthy — served schema from backend directly. "
                "Try compass_sync(force=True) to rebuild the index."
            ]
        return response

    response = {
        "trace_id": trace_id,
        "error": f"Tool not found: {tool_name}",
        "hint": "Use compass() to search for available tools.",
    }
    if not _health_state.get("index_available", True):
        response["warnings"] = [
            "Index database unhealthy — lookup may be incomplete. "
            "Try compass_sync(force=True) to rebuild the index."
        ]
    return response


@mcp.tool()
async def execute(
    tool_name: str, arguments: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Execute a tool on its backend server.

    This proxies the call to the appropriate MCP backend server.
    Use compass() to find tools and describe() to get parameter schemas.

    Args:
        tool_name: The tool to execute (e.g., "bridge:read_file" or "comfy:comfy_generate")
        arguments: Tool arguments as a dictionary. Check describe() for required parameters.

    Returns:
        The tool's response or an error message.
    """
    start_time = time.time()
    trace_id = uuid.uuid4().hex[:8]
    logger.info(f"[execute] [{trace_id}] tool_name={tool_name!r}")

    if arguments is None:
        arguments = {}

    manager = await get_backends()
    analytics = await get_analytics_instance()

    # Check hot cache for faster schema lookup (optional optimization)
    if analytics:
        hot_tool = analytics.get_hot_tool(tool_name)
        if hot_tool:
            logger.debug(f"Using hot cache for {tool_name}")

    # Connect to backend if needed
    if ":" in tool_name:
        server_name = tool_name.split(":")[0]
        if not manager.is_backend_connected(server_name):
            logger.info(f"Connecting to backend: {server_name}")
            success = await manager.connect_backend(server_name)
            if not success:
                # Record failed call
                latency_ms = (time.time() - start_time) * 1000
                if analytics:
                    await analytics.record_tool_call(
                        tool_name,
                        success=False,
                        latency_ms=latency_ms,
                        error_message=f"Failed to connect to backend: {server_name}",
                    )
                logger.warning(
                    f"[execute] [{trace_id}] backend connect failed: {server_name}"
                )
                return {
                    "trace_id": trace_id,
                    "success": False,
                    "error": f"Failed to connect to backend: {server_name}",
                    "hint": "Check that the backend server is configured correctly.",
                }

    # Execute
    result = await manager.execute_tool(tool_name, arguments)

    # Record analytics
    latency_ms = (time.time() - start_time) * 1000
    if isinstance(result, dict):
        if "success" in result:
            success = result["success"]
        else:
            # Missing 'success' key: treat as failure to avoid masking backend errors
            logger.warning(
                f"Backend result for {tool_name} lacks 'success' key; defaulting to False"
            )
            success = False
    else:
        success = False
    error_msg = (
        result.get("error") if isinstance(result, dict) and not success else None
    )

    if analytics:
        await analytics.record_tool_call(
            tool_name,
            success=success,
            latency_ms=latency_ms,
            error_message=error_msg,
            arguments=arguments,
        )

    # GW-B-003: stamp trace_id into both success and failure envelopes so the
    # user can paste it into a bug report.
    if isinstance(result, dict):
        result.setdefault("trace_id", trace_id)
        if not success:
            logger.warning(
                f"[execute] [{trace_id}] tool={tool_name!r} failed: {error_msg}"
            )
        else:
            logger.info(
                f"[execute] [{trace_id}] tool={tool_name!r} ok in {latency_ms:.1f}ms"
            )
    return result


@mcp.tool()
async def compass_categories() -> Dict[str, Any]:
    """
    List available tool categories and servers.

    Use this to understand what kinds of tools are available before searching.
    """
    index = await get_index()
    stats = index.get_stats()

    return {
        "categories": stats.get("by_category", {}),
        "servers": stats.get("by_server", {}),
        "total_tools": stats.get("total_tools", 0),
        "hint": "Use compass(intent, category='file') to filter searches.",
    }


@mcp.tool()
async def compass_status() -> Dict[str, Any]:
    """
    Get Tool Compass gateway status and health information.

    Returns index stats, backend connection status, configuration, analytics summary,
    hot cache status, and sync status.
    """
    config = get_config()
    index = await get_index()
    manager = await get_backends()

    index_stats = index.get_stats()
    backend_stats = manager.get_stats()

    trace_id = uuid.uuid4().hex[:8]
    logger.info(f"[compass_status] [{trace_id}]")

    response = {
        "trace_id": trace_id,
        "index": {
            "total_tools": index_stats.get("total_tools", 0),
            "by_category": index_stats.get("by_category", {}),
            "by_server": index_stats.get("by_server", {}),
        },
        "backends": backend_stats,
        "config": {
            "progressive_disclosure": config.progressive_disclosure,
            "auto_sync": config.auto_sync,
            "embedding_model": config.embedding_model,
            "analytics_enabled": config.analytics_enabled,
            "chain_indexing_enabled": config.chain_indexing_enabled,
        },
        # GW-B-001 / GW-B-009: expose degraded-mode flags so users / operators
        # can tell at a glance when compass() is serving lexical fallbacks or
        # when the index DB has gone sour.
        "health": {
            "ollama_available": _health_state["ollama_available"],
            "last_ollama_error": _health_state["last_ollama_error"],
            "index_available": _health_state["index_available"],
            "last_index_error": _health_state["last_index_error"],
            "degraded_mode": (
                not _health_state["ollama_available"]
                or not _health_state["index_available"]
            ),
        },
    }

    # Add analytics info if enabled
    if config.analytics_enabled:
        analytics = await get_analytics_instance()
        if analytics:
            response["hot_cache"] = {
                "size": len(analytics._hot_cache),
                "tools": list(analytics._hot_cache.keys()),
            }

    # Add sync status if enabled
    if config.auto_sync:
        sync_manager = await get_sync_manager_instance()
        if sync_manager:
            response["sync"] = await sync_manager.get_sync_status()

    # Add chain info if enabled
    if config.chain_indexing_enabled:
        chain_indexer = await get_chain_indexer_instance()
        if chain_indexer:
            chains = await chain_indexer.load_chains_from_db()
            response["chains"] = {
                "total": len(chains),
                "cached": len(chain_indexer._chain_cache),
            }

    return response


@mcp.tool()
async def compass_analytics(
    timeframe: str = "24h", include_failures: bool = True
) -> Dict[str, Any]:
    """
    Get detailed usage analytics and tool health metrics.

    Tracks search patterns, tool usage, success/failure rates, and latencies.
    Use this to understand how tools are being used and identify issues.

    Args:
        timeframe: Time window for stats ("1h", "24h", "7d", "30d")
        include_failures: Include details about failed tool calls

    Returns:
        Comprehensive analytics including top tools, failure rates, chains, etc.
    """
    config = get_config()

    if not config.analytics_enabled:
        return {
            "error": "Analytics is disabled",
            "hint": "Enable analytics_enabled in config to track usage",
        }

    analytics = await get_analytics_instance()
    if not analytics:
        return {"error": "Analytics not initialized"}

    summary = await analytics.get_analytics_summary(timeframe)

    if not include_failures:
        summary.pop("failures", None)

    return summary


@mcp.tool()
async def compass_chains(
    action: str = "list",
    chain_name: Optional[str] = None,
    tools: Optional[List[str]] = None,
    description: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List and manage tool chains (workflows).

    Tool chains are sequences of tools that commonly go together.
    They're auto-detected from usage patterns or can be manually defined.

    Args:
        action: "list" to see all chains, "create" to add a new chain, "detect" to find patterns
        chain_name: Name for new chain (required for "create")
        tools: List of tool names for new chain (required for "create")
        description: Description for new chain (optional for "create")

    Returns:
        Chain information based on action
    """
    config = get_config()

    if not config.chain_indexing_enabled:
        return {
            "error": "Chain indexing is disabled",
            "hint": "Enable chain_indexing_enabled in config",
        }

    chain_indexer = await get_chain_indexer_instance()
    if not chain_indexer:
        return {"error": "Chain indexer not initialized"}

    if action == "list":
        chains = await chain_indexer.load_chains_from_db()
        return {
            "chains": [
                {
                    "name": c.name,
                    "tools": c.tools,
                    "description": c.description,
                    "use_count": c.use_count,
                    "is_auto_detected": c.is_auto_detected,
                }
                for c in chains
            ],
            "total": len(chains),
            "cached": len(chain_indexer._chain_cache),
        }

    elif action == "create":
        if not chain_name or not tools:
            return {
                "error": "chain_name and tools are required for create",
                "hint": "compass_chains(action='create', chain_name='my_workflow', tools=['tool1', 'tool2'])",
            }

        chain = await chain_indexer.add_chain(
            name=chain_name,
            tools=tools,
            description=description,
            is_auto_detected=False,
        )

        return {
            "created": {
                "name": chain.name,
                "tools": chain.tools,
                "description": chain.description,
            },
            "hint": f"Chain '{chain_name}' created. It will now appear in compass() search results.",
        }

    elif action == "detect":
        analytics = await get_analytics_instance()
        if analytics:
            detected = await analytics.detect_chains()
            return {
                "detected": detected,
                "count": len(detected),
                "hint": "Detected chains are now indexed and searchable",
            }
        return {"error": "Analytics required for chain detection"}

    else:
        return {
            "error": f"Unknown action: {action}",
            "valid_actions": ["list", "create", "detect"],
        }


@mcp.tool()
async def compass_sync(force: bool = False) -> Dict[str, Any]:
    """
    Check for backend changes and sync the index.

    Normally, sync happens automatically on startup. Use this to manually
    trigger a sync check or force a full rebuild.

    Args:
        force: If True, force a full sync regardless of detected changes

    Returns:
        Sync status for each backend
    """
    config = get_config()

    if not config.auto_sync:
        return {
            "error": "Auto-sync is disabled",
            "hint": "Enable auto_sync in config for automatic synchronization",
        }

    sync_manager = await get_sync_manager_instance()
    if not sync_manager:
        return {"error": "Sync manager not initialized"}

    if force:
        result = await sync_manager.full_sync()
        return {"action": "full_sync", "result": result}
    else:
        results = await sync_manager.sync_if_needed()
        return {
            "action": "sync_if_needed",
            "backends": results,
            "hint": "Use force=True to rebuild the entire index",
        }


@mcp.tool()
async def compass_audit(
    include_tools: bool = False, timeframe: str = "24h"
) -> Dict[str, Any]:
    """
    Comprehensive audit of the Tool Compass system.

    Returns a complete overview including:
    - Index health and tool counts by category/server
    - Backend connection status
    - Hot cache status (top 10 most-used tools)
    - Tool chain definitions
    - Usage analytics summary
    - Configuration status

    Args:
        include_tools: If True, include full list of all indexed tools
        timeframe: Timeframe for analytics ("1h", "24h", "7d", "30d")

    Returns:
        Complete system audit with all subsystems
    """
    config = get_config()
    index = await get_index()
    manager = await get_backends()

    index_stats = index.get_stats()
    backend_stats = manager.get_stats()

    audit = {
        "system": {
            "version": __version__,
            "total_tools": index_stats.get("total_tools", 0),
            "index_path": str(index.index_path),
            "db_path": str(index.db_path),
        },
        "categories": index_stats.get("by_category", {}),
        "servers": index_stats.get("by_server", {}),
        "backends": backend_stats,
        "config": {
            "progressive_disclosure": config.progressive_disclosure,
            "auto_sync": config.auto_sync,
            "analytics_enabled": config.analytics_enabled,
            "chain_indexing_enabled": config.chain_indexing_enabled,
            "hot_cache_size": config.hot_cache_size,
            "embedding_model": config.embedding_model,
        },
    }

    # Hot cache
    analytics = None
    if config.analytics_enabled:
        analytics = await get_analytics_instance()
        if analytics:
            hot_tools = list(analytics._hot_cache.keys())
            audit["hot_cache"] = {
                "size": len(hot_tools),
                "tools": hot_tools,
                "status": "active" if hot_tools else "empty (populates with usage)",
            }

            # Analytics summary
            summary = await analytics.get_analytics_summary(timeframe)
            audit["analytics"] = {
                "timeframe": timeframe,
                "total_searches": summary["searches"]["total"],
                "avg_search_latency_ms": summary["searches"]["avg_latency_ms"],
                "total_tool_calls": summary["tool_calls"]["total"],
                "success_rate": summary["tool_calls"]["success_rate"],
                "top_tools": [
                    t["tool"] for t in summary["tool_calls"]["top_tools"][:5]
                ],
                "top_queries": [
                    q["query"] for q in summary["searches"]["top_queries"][:5]
                ],
            }

    # Chains
    if config.chain_indexing_enabled:
        chain_indexer = await get_chain_indexer_instance()
        if chain_indexer:
            chains = await chain_indexer.load_chains_from_db()
            audit["chains"] = {
                "total": len(chains),
                "cached": len(chain_indexer._chain_cache),
                "workflows": [
                    {
                        "name": c.name,
                        "tools": [t.split(":")[-1] for t in c.tools],
                        "use_count": c.use_count,
                        "auto_detected": c.is_auto_detected,
                    }
                    for c in chains
                ],
            }

    # Sync status
    if config.auto_sync:
        sync_manager = await get_sync_manager_instance()
        if sync_manager:
            sync_status = await sync_manager.get_sync_status()
            audit["sync"] = sync_status

    # Optionally include all tools
    if include_tools:
        if index.db:
            cursor = index.db.execute(
                "SELECT name, description, category, server FROM tools ORDER BY server, category, name"
            )
            audit["tools"] = [
                {
                    "name": row["name"],
                    "description": row["description"][:80] + "..."
                    if len(row["description"]) > 80
                    else row["description"],
                    "category": row["category"],
                    "server": row["server"],
                }
                for row in cursor.fetchall()
            ]
        else:
            audit["tools"] = []
            audit["tools_note"] = "Index database not available; tool list empty."

    # Health check
    issues = []
    if index_stats.get("total_tools", 0) == 0:
        issues.append("No tools indexed - run compass_sync(force=True)")
    if config.analytics_enabled and analytics and not analytics._hot_cache:
        issues.append("Hot cache empty - will populate as tools are used")
    if not config.chain_indexing_enabled:
        issues.append("Chain indexing disabled - enable for workflow detection")

    audit["health"] = {
        "status": "healthy" if not issues else "needs_attention",
        "issues": issues if issues else ["All systems operational"],
    }

    return audit


# =============================================================================
# CLI COMMANDS
# =============================================================================


async def sync_from_backends():
    """Sync tool definitions from live backend servers and rebuild index."""

    print("\n" + "=" * 60)
    print("  TOOL COMPASS - INDEX SYNC")
    print("=" * 60)

    # Step 1: Load config
    print("\n[1/4] Loading configuration...", end=" ", flush=True)
    config = load_config()
    print(f"OK ({len(config.backends)} backends configured)")

    # Step 2: Connect to backends
    print("\n[2/4] Connecting to backends...")
    manager = BackendManager(config)

    results = await manager.connect_all()

    connected = 0
    for name, success in results.items():
        if success:
            print(f"      ✓ {name}")
            connected += 1
        else:
            print(f"      ✗ {name} (FAILED)")

    if connected == 0:
        print("\n❌ No backends connected. Check that servers are running.")
        print("   Hint: Start MCP servers or check compass_config.json")
        return

    # Step 3: Discover tools
    print("\n[3/4] Discovering tools...")
    tools = manager.get_all_tools()
    print(f"      Found {len(tools)} tools from {connected} backend(s)")

    if not tools:
        print("\n❌ No tools discovered. Backends may be misconfigured.")
        await manager.disconnect_all()
        return

    # Convert to ToolDefinition format for indexing
    print("      Converting to index format...", end=" ", flush=True)
    tool_defs = []
    for tool in tools:
        # Parse server and name from qualified name
        if ":" in tool.qualified_name:
            server, name = tool.qualified_name.split(":", 1)
        else:
            server = tool.server
            name = tool.name

        # Extract parameter names from schema
        params = {}
        if tool.input_schema and "properties" in tool.input_schema:
            for param_name, param_info in tool.input_schema["properties"].items():
                param_type = param_info.get("type", "any")
                if isinstance(param_type, list):
                    param_type = "/".join(param_type)
                params[param_name] = param_type

        tool_defs.append(
            ToolDefinition(
                name=tool.qualified_name,
                description=tool.description,
                category=categorize_tool(tool.name, tool.description),
                server=server,
                parameters=params,
                examples=[],
                is_core=False,
            )
        )

    print(f"OK ({len(tool_defs)} definitions)")

    # Step 4: Build index
    print("\n[4/4] Building HNSW search index...")
    index = CompassIndex()

    # Check Ollama first
    print("      Checking Ollama embeddings service...", end=" ", flush=True)
    if not await index.embedder.health_check():
        print("FAILED")
        print("\n❌ Ollama not available. Please start Ollama and pull the embedding model:")
        print("   1. ollama serve")
        print("   2. ollama pull nomic-embed-text")
        await manager.disconnect_all()
        return
    print("OK")

    print("      Generating embeddings and building index...")
    result = await index.build_index(tool_defs)

    # Cleanup
    await index.close()
    await manager.disconnect_all()

    # Summary
    print("\n" + "-" * 60)
    print("  SYNC COMPLETE")
    print("-" * 60)
    print(f"  Tools indexed: {result['tools_indexed']}")
    print(f"  Build time: {result['total_time']:.2f}s")
    print("  Index ready for queries")
    print("-" * 60 + "\n")


def categorize_tool(name: str, description: str) -> str:
    """Infer category from tool name and description."""
    name_lower = name.lower()
    description_lower = (description or "").lower()

    # Category keywords checked against both name and description
    categories = [
        ("file", ["file", "read", "write", "directory", "path"]),
        ("git", ["git", "commit", "branch", "repo"]),
        ("database", ["db_", "sql", "database", "query"]),
        ("search", ["search", "find", "lookup"]),
        ("ai", ["comfy", "image", "generate", "video"]),
        ("analysis", ["scan", "analyze", "health", "report"]),
        ("project", ["project", "session", "content"]),
        ("system", ["status", "health", "service"]),
    ]

    for category, keywords in categories:
        if any(kw in name_lower for kw in keywords):
            return category

    # Fallback: check description when name yields no match
    for category, keywords in categories:
        if any(kw in description_lower for kw in keywords):
            return category

    return "other"


async def run_tests():
    """Run test queries to verify gateway functionality."""
    print("\n" + "=" * 60)
    print("TOOL COMPASS GATEWAY - TEST SUITE")
    print("=" * 60)

    index = await get_index()
    stats = index.get_stats()

    print(f"\nIndex: {stats['total_tools']} tools")
    print(f"Categories: {list(stats['by_category'].keys())}")

    test_cases = [
        ("read a file from disk", "read_file"),
        ("write content to a file", "write_file"),
        ("show git commit history", "git_log"),
        ("generate an AI image from text", "comfy_generate"),
        ("search for documents", "search"),
        ("check database schema", "db_inspect"),
        ("analyze code quality", "scan"),
        ("create a video from prompt", "video_generate"),
        ("list all projects", "list_projects"),
        ("execute SQL query", "db_execute"),
    ]

    print("\n" + "-" * 60)
    print("Semantic Search Tests")
    print("-" * 60)

    passed = 0
    for query, expected in test_cases:
        results = await index.search(query, top_k=3)
        top_match = results[0] if results else None

        if top_match and expected.lower() in top_match.tool.name.lower():
            status = "PASS"
            passed += 1
        else:
            status = "FAIL"

        actual = top_match.tool.name if top_match else "None"
        score = f"{top_match.score:.3f}" if top_match else "N/A"
        print(f"[{status}] '{query}' -> {actual} ({score})")

    print(
        f"\nResults: {passed}/{len(test_cases)} passed ({100 * passed / len(test_cases):.0f}%)"
    )

    # Latency test
    print("\n" + "-" * 60)
    print("Latency Test")
    print("-" * 60)

    import time

    times = []
    for query, _ in test_cases:
        start = time.time()
        await index.search(query, top_k=5)
        times.append(time.time() - start)

    avg_ms = 1000 * sum(times) / len(times)
    print(f"Average search latency: {avg_ms:.1f}ms")

    await index.close()


def show_config():
    """Display current configuration."""
    config = load_config()

    print("\n" + "=" * 60)
    print("TOOL COMPASS GATEWAY - CONFIGURATION")
    print("=" * 60)

    print(f"\nConfig file: {CONFIG_PATH}")
    print(f"Config exists: {CONFIG_PATH.exists()}")

    print("\n--- Settings ---")
    print(f"Progressive disclosure: {config.progressive_disclosure}")
    print(f"Auto sync: {config.auto_sync}")
    print(f"Embedding model: {config.embedding_model}")
    print(f"Ollama URL: {config.ollama_url}")
    print(f"Default top_k: {config.default_top_k}")
    print(f"Min confidence: {config.min_confidence}")

    print("\n--- Backends ---")
    for name, backend in config.backends.items():
        print(f"\n{name}:")
        print(f"  Type: {backend.type}")
        if hasattr(backend, "command"):
            print(f"  Command: {backend.command}")
            print(
                f"  Args: {backend.args[:2]}..."
                if len(backend.args) > 2
                else f"  Args: {backend.args}"
            )


async def async_main(args):
    """Handle async CLI operations."""
    if args.sync:
        await sync_from_backends()
    elif args.test:
        await run_tests()


def _run_http(port: int) -> None:
    """Run the MCP gateway in HTTP mode with /health, /ready, /metrics.

    SECURITY: The gateway proxies arbitrary MCP tool calls to backend servers.
    Binding to a non-loopback interface exposes RCE-class surface. The HOST env
    var defaults to 127.0.0.1 (loopback). Only bind to public interfaces when
    running behind an authenticated reverse proxy (Fly.io edge, etc.).
    """
    import os
    from starlette.routing import Route
    from starlette.responses import JSONResponse, PlainTextResponse

    # GW-FT-003: cache /ready result for 30s so LB polling can't hammer
    # Ollama or the backend pool. Keyed by time only — a single shared slot.
    _ready_cache: Dict[str, Any] = {"at": 0.0, "status_code": 0, "body": None}
    _READY_CACHE_TTL = 30.0

    async def health(_request):
        return JSONResponse({
            "status": "ok",
            "server": "tool-compass-gateway",
            "version": __version__,
        })

    async def ready(_request):
        """Deep readiness probe — 200 iff all dependencies are usable."""
        now = time.time()
        if _ready_cache["body"] is not None and (now - _ready_cache["at"]) < _READY_CACHE_TTL:
            return JSONResponse(_ready_cache["body"], status_code=_ready_cache["status_code"])

        checks: Dict[str, Any] = {}

        # Index check — don't force a load here, just inspect current state.
        index_ok = False
        try:
            idx = _compass_index
            index_ok = idx is not None and getattr(idx, "db", None) is not None
            checks["index"] = {"ok": index_ok}
            if not index_ok:
                checks["index"]["reason"] = "not loaded"
        except Exception as e:  # defensive
            checks["index"] = {"ok": False, "reason": f"{type(e).__name__}: {e}"}

        # Ollama check — honour breaker state too. Breaker "closed" means
        # healthy; "open" means known-down; "half_open" means probing.
        ollama_ok = bool(_health_state.get("ollama_available"))
        breaker_state = None
        try:
            idx = _compass_index
            if idx is not None and getattr(idx, "embedder", None) is not None:
                breaker_state = idx.embedder.circuit_breaker_state
                if breaker_state == "closed":
                    ollama_ok = True
        except Exception:
            pass
        checks["ollama"] = {
            "ok": ollama_ok,
            "breaker": breaker_state,
            "last_error": _health_state.get("last_ollama_error"),
        }

        # Backend check — at least one connected backend (and the manager exists).
        backend_ok = False
        connected_backends: List[str] = []
        configured_backends: List[str] = []
        try:
            mgr = _backend_manager
            if mgr is not None:
                configured_backends = list(mgr.config.backends.keys())
                for name in configured_backends:
                    if mgr.is_backend_connected(name):
                        connected_backends.append(name)
                backend_ok = bool(connected_backends) or not configured_backends
        except Exception as e:
            checks["backends"] = {"ok": False, "reason": f"{type(e).__name__}: {e}"}
        else:
            checks["backends"] = {
                "ok": backend_ok,
                "connected": connected_backends,
                "configured": configured_backends,
            }
            if not backend_ok:
                checks["backends"]["reason"] = (
                    "no backends connected" if configured_backends else "manager not initialized"
                )

        all_ok = index_ok and ollama_ok and backend_ok
        body = {
            "status": "ready" if all_ok else "not_ready",
            "checks": checks,
        }
        status_code = 200 if all_ok else 503
        _ready_cache["at"] = now
        _ready_cache["status_code"] = status_code
        _ready_cache["body"] = body
        return JSONResponse(body, status_code=status_code)

    async def metrics(_request):
        """Prometheus text format — no prometheus_client dep."""

        def _escape_label(v: str) -> str:
            # Prometheus label-value escaping: \, ", newline.
            return v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")

        lines: List[str] = []

        # Search counter from analytics.
        search_total: Optional[int] = None
        try:
            analytics = _analytics
            if analytics is not None:
                summary = await analytics.get_analytics_summary("24h")
                # get_analytics_summary returns a dict; tolerate shape drift.
                if isinstance(summary, dict):
                    stats = summary.get("search_stats") or summary
                    # Try common keys.
                    for k in ("total_searches", "total", "count"):
                        v = stats.get(k) if isinstance(stats, dict) else None
                        if isinstance(v, (int, float)):
                            search_total = int(v)
                            break
        except Exception as e:
            logger.debug(f"metrics: analytics read failed: {e}")

        lines.append("# HELP tool_compass_search_total Total number of compass() searches (24h window).")
        lines.append("# TYPE tool_compass_search_total counter")
        lines.append(f"tool_compass_search_total {search_total if search_total is not None else 0}")

        # Ollama availability gauge — 1 closed, 0 otherwise.
        ollama_val = 1 if _health_state.get("ollama_available") else 0
        try:
            idx = _compass_index
            if idx is not None and getattr(idx, "embedder", None) is not None:
                ollama_val = 1 if idx.embedder.circuit_breaker_state == "closed" else 0
        except Exception:
            pass
        lines.append("# HELP tool_compass_ollama_available 1 if the Ollama circuit breaker is closed, else 0.")
        lines.append("# TYPE tool_compass_ollama_available gauge")
        lines.append(f"tool_compass_ollama_available {ollama_val}")

        # Per-backend gauges + call counters.
        lines.append("# HELP tool_compass_backend_up 1 if the named backend is connected, else 0.")
        lines.append("# TYPE tool_compass_backend_up gauge")
        lines.append("# HELP tool_compass_backend_call_total Backend tool-call counter, labelled by status.")
        lines.append("# TYPE tool_compass_backend_call_total counter")
        try:
            mgr = _backend_manager
            if mgr is not None:
                stats = mgr.get_stats()
                configured = stats.get("configured_backends") or list(mgr.config.backends.keys())
                connected = set(stats.get("connected_backends") or [])
                per_backend = stats.get("stats") or {}
                for name in configured:
                    label = _escape_label(name)
                    up = 1 if name in connected else 0
                    lines.append(f'tool_compass_backend_up{{name="{label}"}} {up}')
                    entry = per_backend.get(name, {}) if isinstance(per_backend, dict) else {}
                    total = int(entry.get("total_calls", 0) or 0)
                    failed = int(entry.get("failed_calls", 0) or 0)
                    success = max(0, total - failed)
                    lines.append(
                        f'tool_compass_backend_call_total{{name="{label}",status="success"}} {success}'
                    )
                    lines.append(
                        f'tool_compass_backend_call_total{{name="{label}",status="error"}} {failed}'
                    )
        except Exception as e:
            logger.debug(f"metrics: backend stats failed: {e}")

        # Embedder p95 + failures.
        embed_p95 = 0.0
        embed_failures = 0
        try:
            idx = _compass_index
            if idx is not None and getattr(idx, "embedder", None) is not None:
                es = idx.embedder.get_stats()
                embed_p95 = float(es.get("p95_latency_ms", 0.0) or 0.0)
                embed_failures = int(es.get("total_failures", 0) or 0)
        except Exception as e:
            logger.debug(f"metrics: embedder stats failed: {e}")

        lines.append("# HELP tool_compass_embed_latency_p95_ms p95 embed latency in ms from the bounded sample window.")
        lines.append("# TYPE tool_compass_embed_latency_p95_ms gauge")
        lines.append(f"tool_compass_embed_latency_p95_ms {embed_p95}")

        lines.append("# HELP tool_compass_embed_failures_total Total embed failures across the process lifetime.")
        lines.append("# TYPE tool_compass_embed_failures_total counter")
        lines.append(f"tool_compass_embed_failures_total {embed_failures}")

        # Index age + orphaned vectors.
        index_age = 0.0
        orphaned = 0
        try:
            idx = _compass_index
            if idx is not None:
                istats = idx.get_stats()
                age = istats.get("index_age_seconds")
                if isinstance(age, (int, float)):
                    index_age = float(age)
                orphaned = int(istats.get("orphaned_vector_count", 0) or 0)
        except Exception as e:
            logger.debug(f"metrics: index stats failed: {e}")

        lines.append("# HELP tool_compass_index_age_seconds Seconds since the index was last built (0 if unknown).")
        lines.append("# TYPE tool_compass_index_age_seconds gauge")
        lines.append(f"tool_compass_index_age_seconds {index_age}")

        lines.append("# HELP tool_compass_orphaned_vectors HNSW entries with no DB mapping.")
        lines.append("# TYPE tool_compass_orphaned_vectors gauge")
        lines.append(f"tool_compass_orphaned_vectors {orphaned}")

        body = "\n".join(lines) + "\n"
        return PlainTextResponse(body, media_type="text/plain; version=0.0.4")

    # Add health / ready / metrics routes to FastMCP's custom routes
    # (included in streamable_http_app).
    mcp._custom_starlette_routes.append(Route("/health", health, methods=["GET"]))
    mcp._custom_starlette_routes.append(Route("/ready", ready, methods=["GET"]))
    mcp._custom_starlette_routes.append(Route("/metrics", metrics, methods=["GET"]))

    # Use FastMCP's built-in HTTP runner (handles lifespan + session manager init)
    from mcp.server.transport_security import TransportSecuritySettings

    host = os.environ.get("HOST", "127.0.0.1")
    if host not in ("127.0.0.1", "localhost", "::1"):
        logger.warning(
            f"HTTP mode binding to non-loopback host {host!r}. "
            "The gateway proxies arbitrary MCP tool calls — ensure an authenticated "
            "reverse proxy is in front. Set HOST=127.0.0.1 for loopback-only."
        )

    mcp.settings.host = host
    mcp.settings.port = port
    # Allow Fly.io and Smithery proxy hosts (0.0.0.0 intentionally omitted — never a valid Host header)
    mcp.settings.transport_security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=[
            "tool-compass-gateway.fly.dev",
            "tool-compass-gateway--mcp-tool-shop.run.tools",
            "localhost",
            "127.0.0.1",
        ],
    )
    mcp.run(transport="streamable-http")


def main():
    parser = argparse.ArgumentParser(
        prog="gateway",
        description="Tool Compass Gateway - Semantic MCP Proxy Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python gateway.py              Start the MCP gateway server (stdio mode)
  python gateway.py --sync       Sync tools from backends and rebuild index
  python gateway.py --test       Run test queries against the index
  python gateway.py --config     Show current configuration

Prerequisites:
  - Ollama must be running: ollama serve
  - Embedding model required: ollama pull nomic-embed-text

Workflow:
  1. First run --sync to build the tool index from backend servers
  2. Then start the gateway for MCP clients to connect
  3. Use compass() -> describe() -> execute() pattern

For more info, see: https://github.com/mcp-tool-shop-org/tool-compass
        """
    )
    parser.add_argument("--sync", action="store_true",
                        help="Sync tools from backend MCP servers and rebuild the HNSW index")
    parser.add_argument("--test", action="store_true",
                        help="Run semantic search tests to verify index quality")
    parser.add_argument("--config", action="store_true",
                        help="Display current configuration including backends and settings")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Enable verbose output with detailed progress")

    args = parser.parse_args()

    # Set verbose logging if requested
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.debug("Verbose mode enabled")

    if args.config:
        show_config()
    elif args.sync or args.test:
        asyncio.run(async_main(args))
    else:
        # NOTE: Never print() to stdout in MCP mode - it corrupts JSON-RPC!
        # Use stderr for diagnostics if needed
        import sys

        print("Starting Tool Compass Gateway v2.0...", file=sys.stderr)
        print(
            "Tools: compass, describe, execute, compass_categories, compass_status",
            file=sys.stderr,
        )
        print(
            "       compass_analytics, compass_chains, compass_sync, compass_audit",
            file=sys.stderr,
        )
        print(
            "Features: auto-sync, hot cache, usage analytics, tool chains",
            file=sys.stderr,
        )
        print("Workflow: compass() -> describe() -> execute()", file=sys.stderr)

        # Select transport: PORT env var → HTTP (Fly.io), else stdio (local)
        import os
        port = os.environ.get("PORT")
        if port:
            host = os.environ.get("HOST", "127.0.0.1")
            print(f"Transport: streamable-http on {host}:{port}", file=sys.stderr)
            _run_http(int(port))
        else:
            print("Transport: stdio", file=sys.stderr)
            mcp.run()


if __name__ == "__main__":
    main()
