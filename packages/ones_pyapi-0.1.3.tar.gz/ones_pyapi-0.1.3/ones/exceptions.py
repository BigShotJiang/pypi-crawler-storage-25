class OnesClientException(Exception):
    pass