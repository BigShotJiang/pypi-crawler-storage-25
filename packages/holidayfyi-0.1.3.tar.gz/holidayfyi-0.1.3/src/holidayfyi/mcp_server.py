"""MCP server for holidayfyi — holiday and calendar tools for AI assistants.

Run: uvx --from "holidayfyi[mcp]" python -m holidayfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("holidayfyi")


@mcp.tool()
def easter_dates(year: int) -> str:
    """Get Western and Orthodox Easter dates for a given year.

    Args:
        year: The year to compute Easter for (e.g. 2026).
    """
    from holidayfyi import easter_orthodox, easter_western

    w = easter_western(year)
    o = easter_orthodox(year)

    return "\n".join([
        f"## Easter Dates — {year}",
        "",
        "| Tradition | Date |",
        "|-----------|------|",
        f"| Western (Gregorian) | {w.isoformat()} |",
        f"| Orthodox (Julian) | {o.isoformat()} |",
    ])


@mcp.tool()
def nth_weekday(year: int, month: int, weekday: int, n: int) -> str:
    """Find the nth occurrence of a weekday in a month.

    Args:
        year: Year (e.g. 2026).
        month: Month number (1-12).
        weekday: Weekday number (0=Monday, 6=Sunday).
        n: Occurrence (1=first, 2=second, etc.).
    """
    from holidayfyi import nth_weekday_of_month

    d = nth_weekday_of_month(year, month, weekday, n)
    weekday_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

    return f"The {n}{'st' if n == 1 else 'nd' if n == 2 else 'rd' if n == 3 else 'th'} {weekday_names[weekday]} of {d.strftime('%B %Y')}: **{d.isoformat()}**"


@mcp.tool()
def days_until_date(month: int, day: int) -> str:
    """Count days until a specific date (next occurrence).

    Args:
        month: Target month (1-12).
        day: Target day (1-31).
    """
    from holidayfyi import days_until, next_occurrence

    target = next_occurrence(month, day)
    remaining = days_until(target)

    return f"Next {target.strftime('%B %d')}: **{target.isoformat()}** ({remaining} days away)"


@mcp.tool()
def upcoming_holidays(country_code: str, count: int = 10) -> str:
    """Get upcoming public holidays for a country (requires python-holidays).

    Args:
        country_code: ISO 3166-1 alpha-2 country code (e.g. "US", "KR", "JP").
        count: Number of upcoming holidays to return. Default 10.
    """
    from holidayfyi import get_upcoming_holidays

    holidays = get_upcoming_holidays(country_code, n=count)
    if not holidays:
        return f"No upcoming holidays found for {country_code} (python-holidays may not be installed)."

    lines = [
        f"## Upcoming Holidays — {country_code}",
        "",
        "| Date | Holiday |",
        "|------|---------|",
    ]
    for h in holidays:
        lines.append(f"| {h['date']} | {h['name']} |")

    return "\n".join(lines)


@mcp.tool()
def search_holidays(query: str) -> str:
    """Search holidayfyi.com for holidays, countries, and guides.

    Args:
        query: Search query string.
    """
    from holidayfyi.api import HolidayFYI

    with HolidayFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
