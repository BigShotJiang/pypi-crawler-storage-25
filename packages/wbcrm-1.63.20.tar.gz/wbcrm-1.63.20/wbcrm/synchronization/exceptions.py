class ProviderCallError(Exception):
    def __init__(self, original_exc):
        self.original_exc = original_exc
        super().__init__(str(original_exc))
