from django.utils.translation import gettext as _
from wbcore.menus import ItemPermission, MenuItem

GROUPS_MENUITEM = MenuItem(
    label=_("Groups"),
    endpoint="wbcrm:group-list",
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbcrm.view_group"]),
    add=MenuItem(
        label=_("Create Groups"),
        endpoint="wbcrm:group-list",
        permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbcrm.add_group"]),
    ),
)
