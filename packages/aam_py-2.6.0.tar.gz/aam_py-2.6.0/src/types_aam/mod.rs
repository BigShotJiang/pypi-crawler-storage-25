//! Type system for AAML value validation.
//!
//! Types are used both directly (via [`AAML::validate_value`]) and indirectly
//! through `@schema` field declarations. The entry point for resolving a type
//! from a string path is [`resolve_builtin`].
//!
//! ## Built-in type paths
//! | Path | Description |
//! |------|-------------|
//! | `i32` / `f64` / `string` / `bool` / `color` | Primitive types |
//! | `math::vector2` … `math::matrix4x4` | N-component float vectors/matrices |
//! | `physics::kilogram` | Non-negative floating-point mass |
//! | `time::datetime` | ISO 8601 date or datetime string |

use crate::error::AamlError;
use crate::pipeline::ExecutionContext;
use crate::types_aam::primitive_type::PrimitiveType;

pub mod list;
mod math;
pub mod physics;
pub mod primitive_type;
mod time;

/// Core trait that every AAML type must implement.
pub trait TypeAAM {
    /// Constructs the type from a name string.
    ///
    /// Used internally by [`resolve_builtin`] to create type instances from
    /// the sub-name after the `::` separator.
    fn from_name(name: &str) -> Result<Self, AamlError>
    where
        Self: Sized;

    /// Returns the primitive type that best represents this type.
    ///
    /// Used as a hint for serialization or schema introspection.
    fn base_type(&self) -> PrimitiveType;

    /// Validates `value` against this type's constraints.
    ///
    /// Returns `Ok(())` if the value is acceptable, or an
    /// [`AamlError`] with a human-readable message otherwise.
    fn validate(&self, value: &str, context: &ExecutionContext) -> Result<(), AamlError>;
}

/// Resolves a type from a module-qualified path or a plain primitive name.
///
/// # Supported paths
/// - `math::<name>` — see [`math::MathTypes`]
/// - `time::<name>` — see [`time::TimeTypes`]
/// - `physics::<name>` — see [`physics::PhysicsTypes`]
/// - `list<T>` — a homogeneous list of elements with type `T`
/// - `<name>` (no `::`) — a [`PrimitiveType`] name
///
/// # Errors
/// [`AamlError::NotFound`] if the path is not recognized.
pub fn resolve_builtin(path: &str) -> Result<Box<dyn TypeAAM>, AamlError> {
    // list<T> — must be checked before splitn to avoid confusion
    if let Some(inner) = list::ListType::parse_inner(path) {
        return Ok(Box::new(list::ListType::new(inner)));
    }

    let parts: Vec<&str> = path.splitn(2, "::").collect();

    match parts.as_slice() {
        ["math", name] => Ok(Box::new(math::MathTypes::from_name(name)?)),
        ["time", name] => Ok(Box::new(time::TimeTypes::from_name(name)?)),
        ["physics", name] => Ok(Box::new(physics::PhysicsTypes::from_name(name)?)),
        [name] => Ok(Box::new(PrimitiveType::from_name(name)?)),
        _ => Err(AamlError::NotFound {
            key: path.to_string(),
            context: "builtin types".to_string(),
            diagnostics: Some(Box::new(crate::error::ErrorDiagnostics::new(
                "Unknown builtin type",
                format!("Type path '{path}' does not match any builtin type"),
                "Valid formats: math::vector3, time::datetime, physics::kilogram, i32, list<i32>, etc.",
            ))),
        }),
    }
}
