"""Tests for the generate_image tool."""

from __future__ import annotations

import os
from unittest.mock import AsyncMock, patch

import pytest

from mcp_content_pipeline.config import Settings
from mcp_content_pipeline.models.schemas import ImageGenerationResult
from mcp_content_pipeline.tools.generate_image import generate_image


@pytest.fixture
def valid_analysis_dict():
    return {
        "title": "Test Video",
        "channel": "Test Channel",
        "url": "https://www.youtube.com/watch?v=abc123",
        "date_analysed": "2026-03-08T12:00:00",
        "key_takeaways": ["Takeaway 1", "Takeaway 2"],
        "tldr": "A short summary.",
        "twitter_hook": "Hook #AI",
        "topics": ["AI"],
    }


class TestGenerateImageTool:
    @pytest.mark.asyncio
    async def test_success(self, valid_analysis_dict):
        settings = Settings(
            anthropic_api_key="test",
            gemini_api_key="test-gemini-key",
        )
        mock_result = ImageGenerationResult(
            image_path="/tmp/test-image.png",
            prompt_used="test prompt",
            analysis_title="Test Video",
        )
        with patch(
            "mcp_content_pipeline.tools.generate_image._generate_image",
            new_callable=AsyncMock,
            return_value=mock_result,
        ) as mock_gen:
            result = await generate_image(analysis_data=valid_analysis_dict, settings=settings)

        assert isinstance(result, ImageGenerationResult)
        assert result.analysis_title == "Test Video"
        # Verify output_dir is passed (defaults to ~/Downloads when image_output_dir is empty)
        call_kwargs = mock_gen.call_args.kwargs
        assert call_kwargs["output_dir"] == os.path.expanduser("~/Downloads")

    @pytest.mark.asyncio
    async def test_custom_output_dir(self, valid_analysis_dict):
        settings = Settings(
            anthropic_api_key="test",
            gemini_api_key="test-gemini-key",
            image_output_dir="/custom/images",
        )
        mock_result = ImageGenerationResult(
            image_path="/custom/images/test-image.png",
            prompt_used="test prompt",
            analysis_title="Test Video",
        )
        with patch(
            "mcp_content_pipeline.tools.generate_image._generate_image",
            new_callable=AsyncMock,
            return_value=mock_result,
        ) as mock_gen:
            result = await generate_image(analysis_data=valid_analysis_dict, settings=settings)

        assert isinstance(result, ImageGenerationResult)
        call_kwargs = mock_gen.call_args.kwargs
        assert call_kwargs["output_dir"] == "/custom/images"

    @pytest.mark.asyncio
    async def test_missing_api_key(self, valid_analysis_dict):
        settings = Settings(
            anthropic_api_key="test",
            gemini_api_key="",
        )
        with pytest.raises(ValueError, match="Gemini API key not configured"):
            await generate_image(analysis_data=valid_analysis_dict, settings=settings)

    @pytest.mark.asyncio
    async def test_invalid_analysis_dict(self):
        settings = Settings(
            anthropic_api_key="test",
            gemini_api_key="test-gemini-key",
        )
        with pytest.raises(Exception):
            await generate_image(analysis_data={"bad": "data"}, settings=settings)
