Aalam Common Web framework
