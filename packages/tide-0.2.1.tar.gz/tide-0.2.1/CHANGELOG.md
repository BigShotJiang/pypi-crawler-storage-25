# Changelog

All notable changes to `tide` are documented in this file. The format
follows [Keep a Changelog](https://keepachangelog.com/); versioning will
follow [Semantic Versioning](https://semver.org/) once `tide` reaches
`1.0`. Until then, `0.x.y` releases may contain breaking changes; the
wire protocol and on-disk store schema are versioned and migrated forward.

## [Unreleased]

## [0.2.1] — 2026-05-12

### Changed
- License: Apache 2.0 (was MIT).
- README: badges, wave emoji in the title, tightened comparison table,
  trimmed redundant sections.

## [0.2.0] — 2026-05-12

First release of `tide` as a local-first SQLite sync engine.

PyPI versions `0.1.x` under this package name belong to a previous,
unrelated project. Pin to `tide==0.1.81` if you depended on the older
library.

### Added
- `Tide` and `Collection` async API for local-first reads, writes,
  deletes, scans, and `watch()` change subscriptions.
- SQLite-backed local store with WAL mode, a durable outbox, and
  persisted Lamport counter / sync cursor / node id.
- HTTP transport over `httpx` with a callable `headers=` hook for
  short-lived auth tokens.
- `sync_once()` for one-shot exchanges; `sync_forever()` async context
  manager for a background sync loop.
- Last-writer-wins conflict resolution ordered by `(lamport, node_id)`.
- Reference Starlette sync server in `tide.server` (`[server]` extra).
- Pluggable `Transport` protocol for in-process tests and alternative
  backends.
- Schema version pin in the local store; refuse to open DBs from newer
  builds.
- Wire protocol reference in [`PROTOCOL.md`](PROTOCOL.md).
