"""Public ``Tide`` and ``Collection`` API."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from collections.abc import AsyncIterator, Mapping
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from .clock import LamportClock
from .errors import NotOpenError
from .events import ChangeEvent
from .store import Store
from .sync import SyncEngine
from .transport import HeadersProvider, HTTPTransport, Transport

logger = logging.getLogger("tide")

_SENTINEL_CLOSE: Any = object()


class Collection:
    """A named bucket of JSON-serializable documents keyed by string id."""

    def __init__(self, tide: Tide, name: str) -> None:
        self._tide = tide
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    async def get(self, id: str) -> dict[str, Any] | None:
        """Return the current local document, or ``None`` if absent or deleted."""
        return await self._tide._store.get(self._name, id)

    async def put(self, id: str, doc: Mapping[str, Any]) -> None:
        """Insert or replace a document. Writes locally and queues for sync."""
        await self._tide._put(self._name, id, dict(doc))

    async def delete(self, id: str) -> None:
        """Tombstone a document. Writes locally and queues for sync."""
        await self._tide._delete(self._name, id)

    async def scan(self) -> list[tuple[str, dict[str, Any]]]:
        """Return all live (non-tombstoned) documents in this collection."""
        return await self._tide._store.scan(self._name)

    def watch(self) -> AsyncIterator[ChangeEvent]:
        """Yield :class:`ChangeEvent` for every local or remote change in this collection.

        The iterator is cancellation-safe: exit the ``async for`` (or break) and
        the subscription is cleaned up automatically.
        """
        return self._tide._watch(self._name)


class Tide:
    """A local-first store that syncs with a server.

    Typical usage::

        async with Tide(db_path="app.db", endpoint="https://example.com/sync") as tide:
            notes = tide.collection("notes")
            await notes.put("n1", {"title": "Hello"})
            async with tide.sync_forever(interval=2.0):
                ...
    """

    def __init__(
        self,
        *,
        db_path: str | Path,
        endpoint: str | None = None,
        node_id: str | None = None,
        headers: Mapping[str, str] | HeadersProvider | None = None,
        transport: Transport | None = None,
    ) -> None:
        if endpoint is None and transport is None:
            # Offline-only mode is fine — useful for tests and local-only apps.
            pass
        elif endpoint is not None and transport is not None:
            raise ValueError("pass either endpoint= or transport=, not both")

        self._store = Store(db_path)
        self._node_id_hint = node_id
        self._endpoint = endpoint
        self._headers = headers
        self._transport_override = transport

        self._clock: LamportClock | None = None
        self._sync: SyncEngine | None = None
        self._transport: Transport | None = None
        self._owns_transport = False
        self._subscribers: dict[str, set[asyncio.Queue[Any]]] = defaultdict(set)
        self._opened = False

    # ---- lifecycle -----------------------------------------------------

    async def open(self) -> Tide:
        if self._opened:
            return self
        await self._store.open()
        node_id = await self._store.ensure_node_id(self._node_id_hint)
        initial_lamport = await self._store.get_initial_lamport()
        self._clock = LamportClock(node_id=node_id, initial=initial_lamport)

        if self._transport_override is not None:
            self._transport = self._transport_override
        elif self._endpoint is not None:
            self._transport = HTTPTransport(self._endpoint, headers=self._headers)
            self._owns_transport = True

        if self._transport is not None:
            self._sync = SyncEngine(
                store=self._store,
                transport=self._transport,
                clock=self._clock,
                emit=self._emit,
            )

        self._opened = True
        return self

    async def close(self) -> None:
        if not self._opened:
            return
        # Close subscribers so any blocked watch() generators wake up and exit.
        for queues in self._subscribers.values():
            for q in queues:
                q.put_nowait(_SENTINEL_CLOSE)
        self._subscribers.clear()
        if self._transport is not None and self._owns_transport:
            await self._transport.aclose()
        await self._store.close()
        self._opened = False

    async def __aenter__(self) -> Tide:
        return await self.open()

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    @property
    def node_id(self) -> str:
        self._ensure_open()
        assert self._clock is not None
        return self._clock.node_id

    # ---- collections ---------------------------------------------------

    def collection(self, name: str) -> Collection:
        if not name or "/" in name:
            raise ValueError("collection name must be non-empty and not contain '/'")
        return Collection(self, name)

    # ---- sync ----------------------------------------------------------

    async def sync_once(self) -> int:
        """Run a single push/pull exchange. Returns the number of remote changes applied."""
        if self._sync is None:
            raise RuntimeError("no transport configured; pass endpoint= or transport= to Tide()")
        return await self._sync.sync_once()

    @asynccontextmanager
    async def sync_forever(
        self, *, interval: float = 5.0, on_error: str = "log"
    ) -> AsyncIterator[None]:
        """Run a background sync loop for the duration of the ``async with`` block."""
        if self._sync is None:
            raise RuntimeError("no transport configured; pass endpoint= or transport= to Tide()")
        async with self._sync.sync_forever(interval=interval, on_error=on_error):
            yield

    # ---- internals -----------------------------------------------------

    def _ensure_open(self) -> None:
        if not self._opened or self._clock is None:
            raise NotOpenError("call await tide.open() before using this method")

    async def _put(self, collection: str, id: str, doc: dict[str, Any]) -> None:
        self._ensure_open()
        assert self._clock is not None
        stamp = self._clock.tick()
        await self._store.put_local(collection, id, doc, stamp)
        await self._emit(
            ChangeEvent(collection=collection, id=id, kind="put", doc=doc, source="local")
        )
        if self._sync is not None:
            self._sync.trigger()

    async def _delete(self, collection: str, id: str) -> None:
        self._ensure_open()
        assert self._clock is not None
        stamp = self._clock.tick()
        await self._store.delete_local(collection, id, stamp)
        await self._emit(
            ChangeEvent(collection=collection, id=id, kind="delete", doc=None, source="local")
        )
        if self._sync is not None:
            self._sync.trigger()

    async def _emit(self, event: ChangeEvent) -> None:
        for q in list(self._subscribers.get(event.collection, ())):
            q.put_nowait(event)

    async def _watch(self, collection: str) -> AsyncIterator[ChangeEvent]:
        self._ensure_open()
        q: asyncio.Queue[Any] = asyncio.Queue()
        self._subscribers[collection].add(q)
        try:
            while True:
                item = await q.get()
                if item is _SENTINEL_CLOSE:
                    return
                yield item
        finally:
            self._subscribers[collection].discard(q)
