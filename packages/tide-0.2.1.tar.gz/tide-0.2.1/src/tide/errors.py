"""Exception hierarchy for tide."""

from __future__ import annotations


class TideError(Exception):
    """Base class for all tide errors."""


class NotOpenError(TideError):
    """Raised when an operation is attempted before ``Tide.open()`` is awaited."""


class TransportError(TideError):
    """Raised when the sync transport fails in a way the engine cannot recover from."""


class ProtocolError(TideError):
    """Raised when the server returns a response that violates the sync protocol."""


class ConflictError(TideError):
    """Reserved for future use; LWW resolves conflicts silently in v0."""
