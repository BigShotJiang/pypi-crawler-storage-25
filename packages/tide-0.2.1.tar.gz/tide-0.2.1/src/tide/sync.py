"""Sync engine: drives push/pull exchanges with the server.

The engine is intentionally dumb: it pulls pending ops out of the store, hands
them to the transport, persists what comes back. All reconciliation logic
lives in :meth:`Store.apply_remote` (LWW based on Lamport stamps).
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress

from .clock import LamportClock
from .errors import TideError
from .events import ChangeEvent
from .protocol import SyncRequest
from .store import Store
from .transport import Transport

logger = logging.getLogger("tide.sync")

EventEmitter = Callable[[ChangeEvent], Awaitable[None]]


class SyncEngine:
    """Drives push/pull cycles against a :class:`Transport`."""

    def __init__(
        self,
        store: Store,
        transport: Transport,
        clock: LamportClock,
        emit: EventEmitter,
        *,
        push_batch: int = 500,
    ) -> None:
        self._store = store
        self._transport = transport
        self._clock = clock
        self._emit = emit
        self._push_batch = push_batch
        self._lock = asyncio.Lock()
        self._trigger = asyncio.Event()

    def trigger(self) -> None:
        """Wake the background sync loop early (called after a local write)."""
        self._trigger.set()

    async def sync_once(self) -> int:
        """Run a single push/pull exchange. Returns the number of remote changes applied."""
        async with self._lock:
            cursor = await self._store.get_cursor()
            pending = await self._store.pending_ops(limit=self._push_batch)
            ops = [op for _, op in pending]
            request = SyncRequest(node_id=self._clock.node_id, cursor=cursor, ops=ops)
            response = await self._transport.exchange(request)

            applied = 0
            for change in response.changes:
                # Keep the local Lamport counter dominating anything we've observed.
                self._clock.observe(change.lamport)
                if change.node_id == self._clock.node_id:
                    # Echo of one of our own ops. We've already applied it locally;
                    # don't re-emit a remote event.
                    continue
                if await self._store.apply_remote(change):
                    applied += 1
                    await self._emit(
                        ChangeEvent(
                            collection=change.collection,
                            id=change.id,
                            kind=change.kind,
                            doc=change.doc,
                            source="remote",
                        )
                    )

            await self._store.set_lamport(self._clock.value)
            await self._store.set_cursor(response.cursor)
            if pending:
                last_seq = pending[-1][0]
                await self._store.clear_outbox_through(last_seq)
            return applied

    @asynccontextmanager
    async def sync_forever(
        self, *, interval: float = 5.0, on_error: str = "log"
    ) -> AsyncIterator[asyncio.Task[None]]:
        """Run a background sync loop for the duration of the ``async with``.

        ``on_error`` is ``"log"`` (default, swallow & continue) or ``"raise"``.
        """
        task = asyncio.create_task(self._run_forever(interval, on_error))
        try:
            yield task
        finally:
            task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await task

    async def _run_forever(self, interval: float, on_error: str) -> None:
        while True:
            try:
                await self.sync_once()
            except asyncio.CancelledError:
                raise
            except TideError as e:
                if on_error == "raise":
                    raise
                logger.warning("tide sync failed: %s", e)
            except Exception:
                if on_error == "raise":
                    raise
                logger.exception("unexpected error in tide sync loop")

            self._trigger.clear()
            with suppress(asyncio.TimeoutError):
                await asyncio.wait_for(self._trigger.wait(), timeout=interval)
