"""Lamport clock used to order writes across nodes for last-writer-wins resolution."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, order=True)
class Stamp:
    """A causal stamp.

    Comparison is ``(lamport, node_id)``: a higher Lamport counter wins; on tie,
    the lexicographically greater node id wins. This gives every (key, write)
    a total order that all nodes agree on, which is what LWW needs.
    """

    lamport: int
    node_id: str


class LamportClock:
    """In-memory Lamport counter.

    The persisted counter lives in the store; this class is the small helper
    that knows how to advance it correctly. Always seed via :meth:`observe`
    before issuing local stamps so the counter dominates anything we've seen.
    """

    __slots__ = ("_counter", "_node_id")

    def __init__(self, node_id: str, initial: int = 0) -> None:
        self._node_id = node_id
        self._counter = initial

    @property
    def node_id(self) -> str:
        return self._node_id

    @property
    def value(self) -> int:
        return self._counter

    def observe(self, remote_lamport: int) -> None:
        """Advance the local counter to dominate a value we just saw."""
        if remote_lamport > self._counter:
            self._counter = remote_lamport

    def tick(self) -> Stamp:
        """Increment and return a fresh stamp for a local write."""
        self._counter += 1
        return Stamp(lamport=self._counter, node_id=self._node_id)
