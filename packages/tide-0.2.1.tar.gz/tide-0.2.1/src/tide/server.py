"""Reference sync server.

A minimal SQLite-backed server that implements the tide wire protocol. It is
production-adjacent — single-process, single-file, no authentication — but it
is enough to power local-first apps in development, demos, and small teams.
For larger deployments, port the same handful of SQL statements to Postgres.

Requires the optional ``starlette`` extra::

    pip install "tide[server]"
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .protocol import Change, SyncRequest, SyncResponse

if TYPE_CHECKING:
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import Response

_SCHEMA = """
CREATE TABLE IF NOT EXISTS tide_state (
    collection TEXT NOT NULL,
    id         TEXT NOT NULL,
    doc        TEXT,
    lamport    INTEGER NOT NULL,
    node_id    TEXT NOT NULL,
    deleted    INTEGER NOT NULL,
    seq        INTEGER NOT NULL,
    PRIMARY KEY (collection, id)
);

CREATE INDEX IF NOT EXISTS tide_state_by_seq ON tide_state (seq);

CREATE TABLE IF NOT EXISTS tide_seq (
    id    INTEGER PRIMARY KEY CHECK(id = 1),
    value INTEGER NOT NULL
);

INSERT OR IGNORE INTO tide_seq(id, value) VALUES (1, 0);
"""


class ServerStore:
    """SQLite-backed canonical state for a sync server."""

    def __init__(self, db_path: str | Path) -> None:
        self._lock = asyncio.Lock()
        self._conn = sqlite3.connect(str(db_path), isolation_level=None, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)

    async def exchange(self, request: SyncRequest) -> SyncResponse:
        async with self._lock:
            return await asyncio.to_thread(self._exchange_sync, request)

    @contextmanager
    def _tx(self):
        self._conn.execute("BEGIN IMMEDIATE")
        try:
            yield self._conn
        except Exception:
            self._conn.execute("ROLLBACK")
            raise
        else:
            self._conn.execute("COMMIT")

    def _next_seq(self, conn: sqlite3.Connection) -> int:
        conn.execute("UPDATE tide_seq SET value = value + 1 WHERE id = 1")
        row = conn.execute("SELECT value FROM tide_seq WHERE id = 1").fetchone()
        return int(row["value"])

    def _exchange_sync(self, request: SyncRequest) -> SyncResponse:
        cursor = int(request.cursor) if request.cursor else 0
        with self._tx() as conn:
            for op in request.ops:
                existing = conn.execute(
                    "SELECT lamport, node_id FROM tide_state WHERE collection = ? AND id = ?",
                    (op.collection, op.id),
                ).fetchone()
                if existing is not None:
                    current = (int(existing["lamport"]), str(existing["node_id"]))
                    incoming = (op.lamport, op.node_id)
                    if incoming <= current:
                        continue
                seq = self._next_seq(conn)
                doc_json = json.dumps(op.doc) if op.doc is not None else None
                deleted = 1 if op.kind == "delete" else 0
                conn.execute(
                    "INSERT INTO tide_state"
                    "(collection, id, doc, lamport, node_id, deleted, seq) "
                    "VALUES(?, ?, ?, ?, ?, ?, ?) "
                    "ON CONFLICT(collection, id) DO UPDATE SET "
                    "  doc = excluded.doc, "
                    "  lamport = excluded.lamport, "
                    "  node_id = excluded.node_id, "
                    "  deleted = excluded.deleted, "
                    "  seq = excluded.seq",
                    (
                        op.collection,
                        op.id,
                        doc_json,
                        op.lamport,
                        op.node_id,
                        deleted,
                        seq,
                    ),
                )

            rows = conn.execute(
                "SELECT collection, id, doc, lamport, node_id, deleted, seq "
                "FROM tide_state WHERE seq > ? ORDER BY seq ASC",
                (cursor,),
            ).fetchall()

            new_cursor = cursor
            changes: list[Change] = []
            for r in rows:
                doc = json.loads(r["doc"]) if r["doc"] is not None else None
                seq = int(r["seq"])
                if seq > new_cursor:
                    new_cursor = seq
                changes.append(
                    Change(
                        collection=r["collection"],
                        id=r["id"],
                        kind="delete" if r["deleted"] else "put",
                        doc=doc,
                        lamport=int(r["lamport"]),
                        node_id=r["node_id"],
                        seq=seq,
                    )
                )
            return SyncResponse(cursor=str(new_cursor), changes=changes)

    def close(self) -> None:
        self._conn.close()


def create_app(db_path: str | Path, *, path: str = "/sync") -> Starlette:
    """Build a Starlette app exposing the sync endpoint at ``path``."""
    try:
        from contextlib import asynccontextmanager

        from starlette.applications import Starlette
        from starlette.responses import JSONResponse
        from starlette.routing import Route
    except ImportError as e:  # pragma: no cover - guarded by extras
        raise ImportError(
            "tide.server requires the 'server' extra: pip install 'tide[server]'"
        ) from e

    store = ServerStore(db_path)

    async def sync_endpoint(request: Request) -> Response:
        try:
            payload: dict[str, Any] = await request.json()
        except ValueError:
            return JSONResponse({"error": "invalid JSON"}, status_code=400)
        try:
            req = SyncRequest.from_json(payload)
        except (KeyError, TypeError, ValueError) as e:
            return JSONResponse({"error": f"bad request: {e}"}, status_code=400)
        resp = await store.exchange(req)
        return JSONResponse(resp.to_json())

    @asynccontextmanager
    async def lifespan(_app: Starlette):
        try:
            yield
        finally:
            store.close()

    return Starlette(
        routes=[Route(path, sync_endpoint, methods=["POST"])],
        lifespan=lifespan,
    )
