"""tide — a local-first sync engine for Python.

See :class:`Tide` for the main entry point.
"""

from __future__ import annotations

from .clock import LamportClock, Stamp
from .core import Collection, Tide
from .errors import (
    ConflictError,
    NotOpenError,
    ProtocolError,
    TideError,
    TransportError,
)
from .events import ChangeEvent
from .protocol import Change, Op, SyncRequest, SyncResponse
from .store import Store
from .sync import SyncEngine
from .transport import HTTPTransport, Transport

__version__ = "0.2.1"

__all__ = [
    "Change",
    "ChangeEvent",
    "Collection",
    "ConflictError",
    "HTTPTransport",
    "LamportClock",
    "NotOpenError",
    "Op",
    "ProtocolError",
    "Stamp",
    "Store",
    "SyncEngine",
    "SyncRequest",
    "SyncResponse",
    "Tide",
    "TideError",
    "Transport",
    "TransportError",
    "__version__",
]
