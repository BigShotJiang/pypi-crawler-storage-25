"""Change events emitted to :meth:`Collection.watch` subscribers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

ChangeSource = Literal["local", "remote"]
ChangeKind = Literal["put", "delete"]


@dataclass(frozen=True)
class ChangeEvent:
    """An event delivered to a collection watcher.

    ``source="local"`` fires from a put/delete call on this client.
    ``source="remote"`` fires from changes the sync engine pulled from the server.
    """

    collection: str
    id: str
    kind: ChangeKind
    doc: dict[str, Any] | None
    source: ChangeSource
