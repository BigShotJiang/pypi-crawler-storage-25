"""Transport layer: how a client talks to a sync server.

The default is :class:`HTTPTransport` (one POST per sync round-trip). The
:class:`Transport` protocol is small on purpose so tests and alternative
backends (in-memory, WebSocket, gRPC) can plug in without touching the engine.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from typing import Protocol

import httpx

from .errors import ProtocolError, TransportError
from .protocol import SyncRequest, SyncResponse

HeadersProvider = Callable[[], Mapping[str, str] | Awaitable[Mapping[str, str]]]


class Transport(Protocol):
    """A transport delivers a :class:`SyncRequest` and returns the server's response."""

    async def exchange(self, request: SyncRequest) -> SyncResponse: ...

    async def aclose(self) -> None: ...


class HTTPTransport:
    """Default transport: a single POST per sync exchange.

    ``headers`` may be a plain mapping or a callable returning a mapping
    (sync or async) so users can inject short-lived auth tokens.
    """

    def __init__(
        self,
        endpoint: str,
        *,
        headers: Mapping[str, str] | HeadersProvider | None = None,
        client: httpx.AsyncClient | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._endpoint = endpoint
        self._headers = headers
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(timeout=timeout)

    async def _resolve_headers(self) -> Mapping[str, str]:
        h = self._headers
        if h is None:
            return {}
        if callable(h):
            result = h()
            if hasattr(result, "__await__"):
                result = await result  # type: ignore[assignment]
            return result  # type: ignore[return-value]
        return h

    async def exchange(self, request: SyncRequest) -> SyncResponse:
        headers = {"content-type": "application/json", **await self._resolve_headers()}
        try:
            resp = await self._client.post(self._endpoint, json=request.to_json(), headers=headers)
        except httpx.HTTPError as e:
            raise TransportError(f"sync request failed: {e}") from e

        if resp.status_code >= 500:
            raise TransportError(f"server error {resp.status_code}: {resp.text[:200]}")
        if resp.status_code >= 400:
            raise ProtocolError(f"server rejected sync ({resp.status_code}): {resp.text[:200]}")

        try:
            payload = resp.json()
        except ValueError as e:
            raise ProtocolError(f"non-JSON response: {e}") from e

        try:
            return SyncResponse.from_json(payload)
        except (KeyError, TypeError, ValueError) as e:
            raise ProtocolError(f"malformed sync response: {e}") from e

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()
