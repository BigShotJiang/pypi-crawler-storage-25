"""SQLite-backed local store: document state, pending outbox, sync metadata.

All blocking SQLite work is wrapped in :func:`asyncio.to_thread` so the public
API is async-first. SQLite is opened in WAL mode for concurrent reads while a
sync push/pull is in flight.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from .clock import Stamp
from .protocol import Change, Op

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS tide_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tide_docs (
    collection TEXT NOT NULL,
    id         TEXT NOT NULL,
    doc        TEXT,
    lamport    INTEGER NOT NULL,
    node_id    TEXT NOT NULL,
    deleted    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (collection, id)
);

CREATE INDEX IF NOT EXISTS tide_docs_by_collection
    ON tide_docs (collection, deleted);

CREATE TABLE IF NOT EXISTS tide_outbox (
    seq        INTEGER PRIMARY KEY AUTOINCREMENT,
    collection TEXT NOT NULL,
    id         TEXT NOT NULL,
    kind       TEXT NOT NULL,
    doc        TEXT,
    lamport    INTEGER NOT NULL,
    node_id    TEXT NOT NULL
);
"""


class Store:
    """Thin async wrapper around a single SQLite connection.

    The instance is not safe to share across event loops, but is fine for the
    common case of one ``Tide`` per process.
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        self._conn: sqlite3.Connection | None = None
        self._write_lock = asyncio.Lock()

    # ---- lifecycle -----------------------------------------------------

    async def open(self) -> None:
        if self._conn is not None:
            return
        self._conn = await asyncio.to_thread(self._open_sync)

    def _open_sync(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self._db_path,
            isolation_level=None,  # autocommit; we manage transactions explicitly
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(_SCHEMA)
        self._check_schema_version(conn)
        return conn

    def _check_schema_version(self, conn: sqlite3.Connection) -> None:
        row = conn.execute("SELECT value FROM tide_meta WHERE key = 'schema_version'").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO tide_meta(key, value) VALUES('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )
            return
        existing = int(row["value"])
        if existing > SCHEMA_VERSION:
            raise RuntimeError(
                f"tide DB at {self._db_path} is schema v{existing}; "
                f"this build supports up to v{SCHEMA_VERSION}. "
                "Upgrade the tide package."
            )

    async def close(self) -> None:
        if self._conn is None:
            return
        conn, self._conn = self._conn, None
        await asyncio.to_thread(conn.close)

    @property
    def _c(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Store is not open")
        return self._conn

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        conn = self._c
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except Exception:
            conn.execute("ROLLBACK")
            raise
        else:
            conn.execute("COMMIT")

    # ---- meta ----------------------------------------------------------

    async def ensure_node_id(self, provided: str | None) -> str:
        return await asyncio.to_thread(self._ensure_node_id_sync, provided)

    def _ensure_node_id_sync(self, provided: str | None) -> str:
        row = self._c.execute("SELECT value FROM tide_meta WHERE key = 'node_id'").fetchone()
        if row is not None:
            return row["value"]
        node_id = provided or uuid.uuid4().hex
        self._c.execute("INSERT INTO tide_meta(key, value) VALUES('node_id', ?)", (node_id,))
        return node_id

    async def get_cursor(self) -> str | None:
        return await asyncio.to_thread(self._get_meta_sync, "cursor")

    async def set_cursor(self, cursor: str) -> None:
        async with self._write_lock:
            await asyncio.to_thread(self._set_meta_sync, "cursor", cursor)

    async def get_initial_lamport(self) -> int:
        """Return a Lamport value that dominates everything already on disk.

        Reads the persisted counter and the max lamport across docs and outbox
        so a crashed-and-restarted node never reuses a stamp.
        """
        return await asyncio.to_thread(self._get_initial_lamport_sync)

    def _get_initial_lamport_sync(self) -> int:
        persisted = self._get_meta_sync("lamport")
        candidates = [int(persisted) if persisted is not None else 0]
        row = self._c.execute("SELECT MAX(lamport) AS m FROM tide_docs").fetchone()
        if row and row["m"] is not None:
            candidates.append(int(row["m"]))
        row = self._c.execute("SELECT MAX(lamport) AS m FROM tide_outbox").fetchone()
        if row and row["m"] is not None:
            candidates.append(int(row["m"]))
        return max(candidates)

    async def set_lamport(self, value: int) -> None:
        async with self._write_lock:
            await asyncio.to_thread(self._set_meta_sync, "lamport", str(value))

    def _get_meta_sync(self, key: str) -> str | None:
        row = self._c.execute("SELECT value FROM tide_meta WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else None

    def _set_meta_sync(self, key: str, value: str) -> None:
        self._c.execute(
            "INSERT INTO tide_meta(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )

    # ---- documents -----------------------------------------------------

    async def get(self, collection: str, id: str) -> dict[str, Any] | None:
        return await asyncio.to_thread(self._get_sync, collection, id)

    def _get_sync(self, collection: str, id: str) -> dict[str, Any] | None:
        row = self._c.execute(
            "SELECT doc, deleted FROM tide_docs WHERE collection = ? AND id = ?",
            (collection, id),
        ).fetchone()
        if row is None or row["deleted"]:
            return None
        return json.loads(row["doc"])

    async def scan(self, collection: str) -> list[tuple[str, dict[str, Any]]]:
        return await asyncio.to_thread(self._scan_sync, collection)

    def _scan_sync(self, collection: str) -> list[tuple[str, dict[str, Any]]]:
        rows = self._c.execute(
            "SELECT id, doc FROM tide_docs WHERE collection = ? AND deleted = 0 ORDER BY id",
            (collection,),
        ).fetchall()
        return [(r["id"], json.loads(r["doc"])) for r in rows]

    # ---- local writes --------------------------------------------------

    async def put_local(self, collection: str, id: str, doc: dict[str, Any], stamp: Stamp) -> None:
        async with self._write_lock:
            await asyncio.to_thread(self._write_local_sync, collection, id, "put", doc, stamp)

    async def delete_local(self, collection: str, id: str, stamp: Stamp) -> None:
        async with self._write_lock:
            await asyncio.to_thread(self._write_local_sync, collection, id, "delete", None, stamp)

    def _write_local_sync(
        self,
        collection: str,
        id: str,
        kind: str,
        doc: dict[str, Any] | None,
        stamp: Stamp,
    ) -> None:
        doc_json = json.dumps(doc) if doc is not None else None
        deleted = 1 if kind == "delete" else 0
        with self._tx() as conn:
            conn.execute(
                "INSERT INTO tide_outbox(collection, id, kind, doc, lamport, node_id) "
                "VALUES(?, ?, ?, ?, ?, ?)",
                (collection, id, kind, doc_json, stamp.lamport, stamp.node_id),
            )
            conn.execute(
                "INSERT INTO tide_docs(collection, id, doc, lamport, node_id, deleted) "
                "VALUES(?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(collection, id) DO UPDATE SET "
                "  doc = excluded.doc, "
                "  lamport = excluded.lamport, "
                "  node_id = excluded.node_id, "
                "  deleted = excluded.deleted",
                (collection, id, doc_json, stamp.lamport, stamp.node_id, deleted),
            )
            self._set_meta_sync("lamport", str(stamp.lamport))

    # ---- remote writes -------------------------------------------------

    async def apply_remote(self, change: Change) -> bool:
        """Apply a remote change. Returns True if it superseded local state."""
        async with self._write_lock:
            return await asyncio.to_thread(self._apply_remote_sync, change)

    def _apply_remote_sync(self, change: Change) -> bool:
        with self._tx() as conn:
            row = conn.execute(
                "SELECT lamport, node_id FROM tide_docs WHERE collection = ? AND id = ?",
                (change.collection, change.id),
            ).fetchone()
            if row is not None:
                current = (int(row["lamport"]), str(row["node_id"]))
                incoming = (change.lamport, change.node_id)
                if incoming <= current:
                    return False
            doc_json = json.dumps(change.doc) if change.doc is not None else None
            deleted = 1 if change.kind == "delete" else 0
            conn.execute(
                "INSERT INTO tide_docs(collection, id, doc, lamport, node_id, deleted) "
                "VALUES(?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(collection, id) DO UPDATE SET "
                "  doc = excluded.doc, "
                "  lamport = excluded.lamport, "
                "  node_id = excluded.node_id, "
                "  deleted = excluded.deleted",
                (
                    change.collection,
                    change.id,
                    doc_json,
                    change.lamport,
                    change.node_id,
                    deleted,
                ),
            )
            return True

    # ---- outbox --------------------------------------------------------

    async def pending_ops(self, limit: int = 500) -> list[tuple[int, Op]]:
        return await asyncio.to_thread(self._pending_ops_sync, limit)

    def _pending_ops_sync(self, limit: int) -> list[tuple[int, Op]]:
        rows = self._c.execute(
            "SELECT seq, collection, id, kind, doc, lamport, node_id "
            "FROM tide_outbox ORDER BY seq ASC LIMIT ?",
            (limit,),
        ).fetchall()
        out: list[tuple[int, Op]] = []
        for r in rows:
            doc = json.loads(r["doc"]) if r["doc"] is not None else None
            out.append(
                (
                    int(r["seq"]),
                    Op(
                        collection=r["collection"],
                        id=r["id"],
                        kind=r["kind"],
                        doc=doc,
                        lamport=int(r["lamport"]),
                        node_id=r["node_id"],
                    ),
                )
            )
        return out

    async def clear_outbox_through(self, seq: int) -> None:
        async with self._write_lock:
            await asyncio.to_thread(self._clear_outbox_through_sync, seq)

    def _clear_outbox_through_sync(self, seq: int) -> None:
        self._c.execute("DELETE FROM tide_outbox WHERE seq <= ?", (seq,))
