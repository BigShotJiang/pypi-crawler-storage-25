"""Wire types for the tide sync protocol.

The wire protocol is intentionally tiny so it is easy to implement servers in
any language. A sync round-trip is one POST::

    POST /sync
    { "node_id": str, "cursor": str | None, "ops": [Op, ...] }

    -> { "cursor": str, "changes": [Change, ...] }

``ops`` are the client's pending writes. ``changes`` are everything the server
has accepted since ``cursor`` (including this client's own writes, echoed back
so multi-device clients can converge through a single path).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

OpKind = Literal["put", "delete"]


@dataclass(frozen=True)
class Op:
    """A pending local write the client wants the server to accept.

    Server-side idempotency is provided by the ``(lamport, node_id)`` pair:
    re-pushing the same op leaves the server in the same state. ``op_id`` is
    an optional diagnostic field surfaced in server logs; it does not affect
    correctness.
    """

    collection: str
    id: str
    kind: OpKind
    doc: dict[str, Any] | None
    lamport: int
    node_id: str
    op_id: str = field(default="")

    def to_json(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "collection": self.collection,
            "id": self.id,
            "kind": self.kind,
            "doc": self.doc,
            "lamport": self.lamport,
            "node_id": self.node_id,
        }
        if self.op_id:
            out["op_id"] = self.op_id
        return out

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> Op:
        return cls(
            collection=data["collection"],
            id=data["id"],
            kind=data["kind"],
            doc=data.get("doc"),
            lamport=int(data["lamport"]),
            node_id=data["node_id"],
            op_id=str(data.get("op_id", "")),
        )


@dataclass(frozen=True)
class Change:
    """A canonical change the server is broadcasting to clients.

    ``seq`` is the server-assigned monotonic sequence number for this change;
    clients persist ``max(seq)`` as their cursor.
    """

    collection: str
    id: str
    kind: OpKind
    doc: dict[str, Any] | None
    lamport: int
    node_id: str
    seq: int

    def to_json(self) -> dict[str, Any]:
        return {
            "collection": self.collection,
            "id": self.id,
            "kind": self.kind,
            "doc": self.doc,
            "lamport": self.lamport,
            "node_id": self.node_id,
            "seq": self.seq,
        }

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> Change:
        return cls(
            collection=data["collection"],
            id=data["id"],
            kind=data["kind"],
            doc=data.get("doc"),
            lamport=int(data["lamport"]),
            node_id=data["node_id"],
            seq=int(data["seq"]),
        )


@dataclass(frozen=True)
class SyncRequest:
    node_id: str
    cursor: str | None
    ops: list[Op]

    def to_json(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "cursor": self.cursor,
            "ops": [op.to_json() for op in self.ops],
        }

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> SyncRequest:
        return cls(
            node_id=data["node_id"],
            cursor=data.get("cursor"),
            ops=[Op.from_json(o) for o in data.get("ops", [])],
        )


@dataclass(frozen=True)
class SyncResponse:
    cursor: str
    changes: list[Change]

    def to_json(self) -> dict[str, Any]:
        return {
            "cursor": self.cursor,
            "changes": [c.to_json() for c in self.changes],
        }

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> SyncResponse:
        return cls(
            cursor=str(data["cursor"]),
            changes=[Change.from_json(c) for c in data.get("changes", [])],
        )
