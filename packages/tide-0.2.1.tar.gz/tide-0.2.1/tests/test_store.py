from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path

import pytest

from tide.clock import Stamp
from tide.protocol import Change
from tide.store import Store


@pytest.fixture
async def store(tmp_path: Path) -> AsyncIterator[Store]:
    s = Store(tmp_path / "tide.db")
    await s.open()
    yield s
    await s.close()


async def test_ensure_node_id_persists(tmp_path: Path) -> None:
    s = Store(tmp_path / "t.db")
    await s.open()
    nid = await s.ensure_node_id("provided")
    assert nid == "provided"
    await s.close()

    s2 = Store(tmp_path / "t.db")
    await s2.open()
    # Even when a different hint is provided, the persisted id wins.
    assert await s2.ensure_node_id("ignored") == "provided"
    await s2.close()


async def test_put_get_delete(store: Store) -> None:
    await store.put_local("notes", "n1", {"title": "Hi"}, Stamp(1, "a"))
    assert await store.get("notes", "n1") == {"title": "Hi"}
    await store.delete_local("notes", "n1", Stamp(2, "a"))
    assert await store.get("notes", "n1") is None


async def test_scan_skips_tombstones(store: Store) -> None:
    await store.put_local("notes", "n1", {"x": 1}, Stamp(1, "a"))
    await store.put_local("notes", "n2", {"x": 2}, Stamp(2, "a"))
    await store.delete_local("notes", "n1", Stamp(3, "a"))
    rows = await store.scan("notes")
    assert rows == [("n2", {"x": 2})]


async def test_outbox_round_trip(store: Store) -> None:
    await store.put_local("notes", "n1", {"x": 1}, Stamp(1, "a"))
    await store.put_local("notes", "n2", {"x": 2}, Stamp(2, "a"))
    pending = await store.pending_ops()
    assert [op.id for _, op in pending] == ["n1", "n2"]

    last_seq = pending[-1][0]
    await store.clear_outbox_through(last_seq)
    assert await store.pending_ops() == []


async def test_apply_remote_lww_wins_on_higher_lamport(store: Store) -> None:
    await store.put_local("notes", "n1", {"v": "local"}, Stamp(3, "a"))
    applied = await store.apply_remote(Change("notes", "n1", "put", {"v": "remote"}, 5, "b", seq=1))
    assert applied is True
    assert await store.get("notes", "n1") == {"v": "remote"}


async def test_apply_remote_lww_loses_on_lower_lamport(store: Store) -> None:
    await store.put_local("notes", "n1", {"v": "local"}, Stamp(10, "a"))
    applied = await store.apply_remote(Change("notes", "n1", "put", {"v": "remote"}, 5, "b", seq=1))
    assert applied is False
    assert await store.get("notes", "n1") == {"v": "local"}


async def test_apply_remote_lww_tiebreaks_on_node_id(store: Store) -> None:
    await store.put_local("notes", "n1", {"v": "a"}, Stamp(5, "a"))
    # Same lamport, higher node id wins.
    assert await store.apply_remote(Change("notes", "n1", "put", {"v": "b"}, 5, "b", seq=1))
    assert await store.get("notes", "n1") == {"v": "b"}
    # Same lamport, lower node id loses.
    assert not await store.apply_remote(Change("notes", "n1", "put", {"v": "a"}, 5, "a", seq=2))


async def test_initial_lamport_dominates_existing_state(tmp_path: Path) -> None:
    s = Store(tmp_path / "t.db")
    await s.open()
    await s.put_local("notes", "n1", {"x": 1}, Stamp(42, "a"))
    await s.close()

    s2 = Store(tmp_path / "t.db")
    await s2.open()
    assert await s2.get_initial_lamport() == 42
    await s2.close()
