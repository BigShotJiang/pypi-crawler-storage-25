from __future__ import annotations

from tide.protocol import Change, Op, SyncRequest, SyncResponse


def test_op_roundtrip() -> None:
    op = Op(
        collection="notes",
        id="n1",
        kind="put",
        doc={"title": "Hi"},
        lamport=5,
        node_id="node-a",
    )
    assert Op.from_json(op.to_json()) == op


def test_change_roundtrip() -> None:
    ch = Change(
        collection="notes",
        id="n1",
        kind="delete",
        doc=None,
        lamport=7,
        node_id="node-a",
        seq=42,
    )
    assert Change.from_json(ch.to_json()) == ch


def test_request_response_roundtrip() -> None:
    req = SyncRequest(
        node_id="node-a",
        cursor=None,
        ops=[Op("c", "i", "put", {"x": 1}, 1, "node-a")],
    )
    assert SyncRequest.from_json(req.to_json()) == req

    resp = SyncResponse(
        cursor="12",
        changes=[Change("c", "i", "put", {"x": 1}, 1, "node-a", 12)],
    )
    assert SyncResponse.from_json(resp.to_json()) == resp
