"""End-to-end sync tests using the reference ServerStore as an in-process transport.

These tests exercise the full client/server round-trip without going over HTTP.
"""

from __future__ import annotations

import asyncio
from collections.abc import Iterator
from contextlib import suppress
from pathlib import Path

import pytest

from tide import Tide
from tide.protocol import SyncRequest, SyncResponse
from tide.server import ServerStore


class InProcessTransport:
    """Transport that calls a :class:`ServerStore` directly, no HTTP."""

    def __init__(self, server: ServerStore) -> None:
        self._server = server

    async def exchange(self, request: SyncRequest) -> SyncResponse:
        return await self._server.exchange(request)

    async def aclose(self) -> None:
        return None


@pytest.fixture
def server(tmp_path: Path) -> Iterator[ServerStore]:
    s = ServerStore(tmp_path / "server.db")
    yield s
    s.close()


async def _client(db: Path, server: ServerStore, node_id: str) -> Tide:
    t = Tide(
        db_path=db,
        transport=InProcessTransport(server),
        node_id=node_id,
    )
    await t.open()
    return t


async def test_local_write_visible_immediately(tmp_path: Path, server: ServerStore):
    t = await _client(tmp_path / "a.db", server, "a")
    try:
        await t.collection("notes").put("n1", {"title": "Hi"})
        assert await t.collection("notes").get("n1") == {"title": "Hi"}
    finally:
        await t.close()


async def test_two_clients_converge(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        await a.collection("notes").put("n1", {"v": "from-a"})
        await a.sync_once()  # push from a, pull echo back
        await b.sync_once()  # b sees a's write
        assert await b.collection("notes").get("n1") == {"v": "from-a"}

        await b.collection("notes").put("n2", {"v": "from-b"})
        await b.sync_once()
        await a.sync_once()
        assert await a.collection("notes").get("n2") == {"v": "from-b"}
    finally:
        await a.close()
        await b.close()


async def test_conflict_resolves_by_lamport(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        # Both write to same id offline. Whoever has the higher Lamport when
        # they reach the server wins for everyone.
        await a.collection("notes").put("k", {"who": "a"})
        await b.collection("notes").put("k", {"who": "b"})
        await b.collection("notes").put("k", {"who": "b2"})  # bumps b's lamport

        await a.sync_once()
        await b.sync_once()
        await a.sync_once()

        # b's later write (higher lamport on the server) wins.
        assert await a.collection("notes").get("k") == {"who": "b2"}
        assert await b.collection("notes").get("k") == {"who": "b2"}
    finally:
        await a.close()
        await b.close()


async def test_delete_propagates(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        await a.collection("notes").put("n1", {"v": 1})
        await a.sync_once()
        await b.sync_once()
        assert await b.collection("notes").get("n1") == {"v": 1}

        await a.collection("notes").delete("n1")
        await a.sync_once()
        await b.sync_once()
        assert await b.collection("notes").get("n1") is None
    finally:
        await a.close()
        await b.close()


async def test_offline_then_sync(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    try:
        # Many offline writes pile up in the outbox.
        for i in range(20):
            await a.collection("notes").put(f"n{i}", {"i": i})
        # One sync flushes them all.
        await a.sync_once()
    finally:
        await a.close()

    # Fresh client picks them up via pull.
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        await b.sync_once()
        rows = await b.collection("notes").scan()
        assert len(rows) == 20
    finally:
        await b.close()


async def test_watch_local_and_remote(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        events_b: list[tuple[str, str]] = []

        async def watcher():
            async for ev in b.collection("notes").watch():
                events_b.append((ev.source, ev.id))
                if len(events_b) >= 2:
                    return

        task = asyncio.create_task(watcher())
        await asyncio.sleep(0)  # let watcher register

        # local write on b
        await b.collection("notes").put("n_local", {"x": 1})

        # remote write from a pulled into b
        await a.collection("notes").put("n_remote", {"x": 2})
        await a.sync_once()
        await b.sync_once()

        await asyncio.wait_for(task, timeout=2.0)

        sources = sorted(events_b)
        assert ("local", "n_local") in sources
        assert ("remote", "n_remote") in sources
    finally:
        await a.close()
        await b.close()


async def test_does_not_double_apply_own_echoes(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    try:
        seen: list[str] = []

        async def watcher():
            async for ev in a.collection("notes").watch():
                seen.append(ev.source)

        task = asyncio.create_task(watcher())
        await asyncio.sleep(0)

        await a.collection("notes").put("n1", {"x": 1})
        await a.sync_once()  # echo of our own op should not produce a remote event
        await asyncio.sleep(0.05)

        task.cancel()
        with suppress(asyncio.CancelledError, Exception):
            await task

        assert seen == ["local"]
    finally:
        await a.close()


async def test_sync_forever_background(tmp_path: Path, server: ServerStore):
    a = await _client(tmp_path / "a.db", server, "a")
    b = await _client(tmp_path / "b.db", server, "b")
    try:
        async with b.sync_forever(interval=0.05):
            await a.collection("notes").put("n1", {"v": "x"})
            await a.sync_once()
            # b's background loop should pick this up quickly.
            for _ in range(50):
                got = await b.collection("notes").get("n1")
                if got is not None:
                    break
                await asyncio.sleep(0.05)
            assert got == {"v": "x"}
    finally:
        await a.close()
        await b.close()
