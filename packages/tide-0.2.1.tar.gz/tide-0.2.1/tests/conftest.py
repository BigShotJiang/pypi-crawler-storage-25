from __future__ import annotations

import logging

# Surface tide warnings in test output to help diagnose flaky tests.
logging.getLogger("tide").setLevel(logging.DEBUG)
