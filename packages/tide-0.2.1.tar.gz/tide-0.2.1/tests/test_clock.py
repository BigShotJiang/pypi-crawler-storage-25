from __future__ import annotations

from tide.clock import LamportClock, Stamp


def test_tick_increments() -> None:
    clock = LamportClock("node-a", initial=4)
    s1 = clock.tick()
    s2 = clock.tick()
    assert s1 == Stamp(5, "node-a")
    assert s2 == Stamp(6, "node-a")
    assert clock.value == 6


def test_observe_jumps_forward() -> None:
    clock = LamportClock("node-a", initial=2)
    clock.observe(10)
    assert clock.value == 10
    assert clock.tick() == Stamp(11, "node-a")


def test_observe_ignores_smaller() -> None:
    clock = LamportClock("node-a", initial=5)
    clock.observe(3)
    assert clock.value == 5


def test_stamp_total_order() -> None:
    a = Stamp(3, "node-a")
    b = Stamp(3, "node-b")
    c = Stamp(4, "node-a")
    assert a < b  # tie-break on node id
    assert b < c  # higher lamport wins
    assert a < c
