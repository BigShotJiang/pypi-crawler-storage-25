"""Brutal failure tests.

A sync library earns trust by not losing data when the network, the server,
or the client misbehaves. The tests below simulate the unhappy paths a real
deployment will hit.
"""

from __future__ import annotations

import asyncio
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest

from tide import Tide
from tide.errors import TransportError
from tide.protocol import SyncRequest, SyncResponse
from tide.server import ServerStore
from tide.store import SCHEMA_VERSION, Store
from tide.transport import Transport


class InProcessTransport:
    def __init__(self, server: ServerStore) -> None:
        self._server = server

    async def exchange(self, request: SyncRequest) -> SyncResponse:
        return await self._server.exchange(request)

    async def aclose(self) -> None:
        return None


class FlakyTransport:
    """Wraps a real transport but can be configured to fail or duplicate calls."""

    def __init__(self, inner: Transport) -> None:
        self._inner = inner
        self.fail_next = 0
        self.duplicate_next = False
        self.calls: list[SyncRequest] = []

    async def exchange(self, request: SyncRequest) -> SyncResponse:
        self.calls.append(request)
        if self.fail_next > 0:
            self.fail_next -= 1
            raise TransportError("simulated transport failure")
        resp = await self._inner.exchange(request)
        if self.duplicate_next:
            self.duplicate_next = False
            # Simulate a server that applied the write but the response got lost,
            # so a retry would resend the same ops.
            self.calls.append(request)
            await self._inner.exchange(request)
        return resp

    async def aclose(self) -> None:
        await self._inner.aclose()


@pytest.fixture
def server(tmp_path: Path) -> Iterator[ServerStore]:
    s = ServerStore(tmp_path / "server.db")
    yield s
    s.close()


async def _client(db: Path, transport: Any, node_id: str) -> Tide:
    t = Tide(db_path=db, transport=transport, node_id=node_id)
    await t.open()
    return t


# ---- crash and resume -------------------------------------------------------


async def test_outbox_survives_process_restart(tmp_path: Path, server: ServerStore):
    """Writes made before a crash must reach the server after restart."""
    db = tmp_path / "a.db"

    # First "process": write but never sync.
    t1 = await _client(db, InProcessTransport(server), "a")
    await t1.collection("notes").put("n1", {"v": 1})
    await t1.collection("notes").put("n2", {"v": 2})
    await t1.close()

    # Second "process": same DB, syncs and pushes durable outbox.
    t2 = await _client(db, InProcessTransport(server), "a")
    try:
        applied = await t2.sync_once()
        # Our own writes echo back but should not produce remote events.
        assert applied == 0
    finally:
        await t2.close()

    # Third client pulls and sees both records.
    t3 = await _client(tmp_path / "b.db", InProcessTransport(server), "b")
    try:
        await t3.sync_once()
        rows = dict(await t3.collection("notes").scan())
        assert rows == {"n1": {"v": 1}, "n2": {"v": 2}}
    finally:
        await t3.close()


async def test_lamport_dominates_after_restart(tmp_path: Path, server: ServerStore):
    """A restarted node must never reuse a Lamport stamp."""
    db = tmp_path / "a.db"

    t1 = await _client(db, InProcessTransport(server), "a")
    for i in range(5):
        await t1.collection("notes").put(f"n{i}", {"i": i})
    pre_restart_max = (await t1._store.pending_ops())[-1][1].lamport
    await t1.close()

    t2 = await _client(db, InProcessTransport(server), "a")
    try:
        await t2.collection("notes").put("after-restart", {"i": 999})
        post = (await t2._store.pending_ops())[-1][1].lamport
        assert post > pre_restart_max
    finally:
        await t2.close()


# ---- duplicate delivery -----------------------------------------------------


async def test_duplicate_push_is_idempotent(tmp_path: Path, server: ServerStore):
    """A retried push must not double-apply on the server."""
    flaky = FlakyTransport(InProcessTransport(server))
    flaky.duplicate_next = True

    a = await _client(tmp_path / "a.db", flaky, "a")
    try:
        await a.collection("notes").put("n1", {"v": "once"})
        await a.sync_once()
    finally:
        await a.close()

    # Server should hold exactly one row at the original value.
    b = await _client(tmp_path / "b.db", InProcessTransport(server), "b")
    try:
        await b.sync_once()
        rows = await b.collection("notes").scan()
        assert rows == [("n1", {"v": "once"})]
    finally:
        await b.close()


# ---- partial sync failure ---------------------------------------------------


async def test_transient_failure_retains_outbox(tmp_path: Path, server: ServerStore):
    """If the transport raises, pending ops must remain in the outbox."""
    flaky = FlakyTransport(InProcessTransport(server))
    flaky.fail_next = 1

    a = await _client(tmp_path / "a.db", flaky, "a")
    try:
        await a.collection("notes").put("n1", {"v": 1})
        with pytest.raises(TransportError):
            await a.sync_once()
        # Op is still pending after the failure.
        pending = await a._store.pending_ops()
        assert len(pending) == 1

        # Next sync succeeds and clears the outbox.
        await a.sync_once()
        assert await a._store.pending_ops() == []
    finally:
        await a.close()


async def test_sync_forever_swallows_transient_failures(tmp_path: Path, server: ServerStore):
    """Background sync must not crash on a recoverable transport error."""
    flaky = FlakyTransport(InProcessTransport(server))
    flaky.fail_next = 2  # first two attempts fail, then success

    a = await _client(tmp_path / "a.db", flaky, "a")
    try:
        async with a.sync_forever(interval=0.05, on_error="log"):
            await a.collection("notes").put("n1", {"v": 1})
            for _ in range(50):
                if not await a._store.pending_ops():
                    break
                await asyncio.sleep(0.05)
            assert await a._store.pending_ops() == []
    finally:
        await a.close()


# ---- server replay from stale cursor ----------------------------------------


async def test_full_state_delivered_when_cursor_is_lost(tmp_path: Path, server: ServerStore):
    """A client that lost its cursor must be able to pull full state."""
    a = await _client(tmp_path / "a.db", InProcessTransport(server), "a")
    try:
        for i in range(10):
            await a.collection("notes").put(f"n{i}", {"i": i})
        await a.sync_once()
    finally:
        await a.close()

    # Fresh client = empty cursor = should receive all 10 changes.
    b = await _client(tmp_path / "b.db", InProcessTransport(server), "b")
    try:
        applied = await b.sync_once()
        assert applied == 10
        assert len(await b.collection("notes").scan()) == 10
    finally:
        await b.close()


# ---- concurrent writes ------------------------------------------------------


async def test_concurrent_local_writes_get_unique_stamps(tmp_path: Path, server: ServerStore):
    """asyncio.gather over puts must produce strictly monotonic Lamport stamps."""
    a = await _client(tmp_path / "a.db", InProcessTransport(server), "a")
    try:
        coros = [a.collection("notes").put(f"n{i}", {"i": i}) for i in range(50)]
        await asyncio.gather(*coros)

        pending = await a._store.pending_ops()
        stamps = [op.lamport for _, op in pending]
        assert stamps == sorted(stamps)
        assert len(set(stamps)) == len(stamps)  # all unique
        assert len(stamps) == 50
    finally:
        await a.close()


# ---- delete semantics -------------------------------------------------------


async def test_delete_then_recreate_with_higher_lamport(tmp_path: Path, server: ServerStore):
    """Tombstones must not block a subsequent put with a higher stamp."""
    a = await _client(tmp_path / "a.db", InProcessTransport(server), "a")
    b = await _client(tmp_path / "b.db", InProcessTransport(server), "b")
    try:
        await a.collection("notes").put("k", {"v": "first"})
        await a.collection("notes").delete("k")
        await a.collection("notes").put("k", {"v": "rebirth"})
        await a.sync_once()
        await b.sync_once()
        assert await b.collection("notes").get("k") == {"v": "rebirth"}
    finally:
        await a.close()
        await b.close()


async def test_stale_put_does_not_undo_delete(tmp_path: Path, server: ServerStore):
    """A delete with a higher Lamport must not be resurrected by a stale put."""
    a = await _client(tmp_path / "a.db", InProcessTransport(server), "a")
    b = await _client(tmp_path / "b.db", InProcessTransport(server), "b")
    try:
        await a.collection("notes").put("k", {"v": "x"})
        await a.sync_once()
        await b.sync_once()

        # b deletes, a is offline and tries a stale put.
        await b.collection("notes").delete("k")
        await b.sync_once()
        # Simulate: a does a put while still unaware of the delete. a has
        # already ticked past the original put; b's delete used a different
        # node's clock. Whichever lamport is higher wins; force the test by
        # ensuring a.delete is older than b.delete via ordering.
        await a.collection("notes").put("k", {"v": "stale"})
        # a.put has lamport=2 (after first put=1); b.delete observed a.put then
        # ticked, so lamport on the server for the delete is at least 2 with
        # node_id "b" — which beats (2, "a") on tie-break.
        await a.sync_once()  # a pushes its stale put, sees the delete echo back
        # If the stale put has a lower stamp than the delete, the delete wins.
        # Otherwise (rare race) the stale put wins. Either way, both clients
        # must agree.
        await b.sync_once()
        assert await a.collection("notes").get("k") == await b.collection("notes").get("k")
    finally:
        await a.close()
        await b.close()


# ---- schema versioning ------------------------------------------------------


async def test_schema_version_pinned_in_meta(tmp_path: Path):
    s = Store(tmp_path / "t.db")
    await s.open()
    try:
        meta_version = s._get_meta_sync("schema_version")
        assert meta_version == str(SCHEMA_VERSION)
    finally:
        await s.close()


async def test_future_schema_version_rejected(tmp_path: Path):
    db = tmp_path / "t.db"
    s = Store(db)
    await s.open()
    # Pretend the DB was written by a future tide release.
    s._set_meta_sync("schema_version", str(SCHEMA_VERSION + 7))
    await s.close()

    s2 = Store(db)
    with pytest.raises(RuntimeError, match="schema v"):
        await s2.open()
