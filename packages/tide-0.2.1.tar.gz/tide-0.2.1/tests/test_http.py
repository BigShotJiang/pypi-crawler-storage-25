"""HTTP integration tests.

The rest of the suite uses an in-process transport; this file exercises the
real :class:`HTTPTransport` against the reference Starlette server over
``httpx.ASGITransport``. This is the path a user actually hits in production.
"""

from __future__ import annotations

from pathlib import Path

import httpx

from tide import Tide
from tide.server import create_app
from tide.transport import HTTPTransport


async def _build_client(db: Path, http: httpx.AsyncClient, node_id: str) -> Tide:
    transport = HTTPTransport("http://server/sync", client=http, headers={"x-test": "1"})
    t = Tide(db_path=db, transport=transport, node_id=node_id)
    await t.open()
    return t


async def test_two_clients_converge_over_http(tmp_path: Path):
    app = create_app(tmp_path / "server.db")
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://server") as http:
        a = await _build_client(tmp_path / "a.db", http, "a")
        b = await _build_client(tmp_path / "b.db", http, "b")
        try:
            await a.collection("todos").put("t1", {"text": "ship tide"})
            await a.sync_once()
            await b.sync_once()
            assert await b.collection("todos").get("t1") == {"text": "ship tide"}

            await b.collection("todos").put("t1", {"text": "ship tide", "done": True})
            await b.sync_once()
            await a.sync_once()
            assert await a.collection("todos").get("t1") == {
                "text": "ship tide",
                "done": True,
            }
        finally:
            await a.close()
            await b.close()


async def test_server_rejects_malformed_request(tmp_path: Path):
    app = create_app(tmp_path / "server.db")
    asgi = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=asgi, base_url="http://server") as http:
        resp = await http.post("/sync", content="not-json")
        assert resp.status_code == 400

        resp = await http.post("/sync", json={"missing": "fields"})
        assert resp.status_code == 400
