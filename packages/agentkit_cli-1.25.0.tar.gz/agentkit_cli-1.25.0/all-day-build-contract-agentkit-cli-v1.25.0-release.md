# All-Day Build Contract: agentkit-cli v1.25.0 release completion

Status: In Progress
Date: 2026-04-21
Owner: OpenClaw release-completion pass
Scope type: Deliverable-gated

## 1. Objective

Take the already-built `agentkit-cli v1.25.0 spec grounding` lane from truthful `RELEASE-READY (LOCAL-ONLY)` to fully shipped truth, or stop with an exact blocker report.

Current verified parent truth:
- Repo: `/Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`
- Branch: `feat/v1.25.0-spec-grounding`
- Current local release-ready head: `853a648` (`docs: close out v1.25.0 spec grounding`)
- Feature commits already landed locally:
  - `ece6aa7` (`test: pin stale spec recommendation regression`)
  - `51fda9a` (`fix: ground spec recommendations in repo truth`)
  - `ecf1f46` (`chore: close out v1.25.0 local release state`)
  - `853a648` (`docs: close out v1.25.0 spec grounding`)
- Current release-ready surfaces already say `v1.25.0` local-only:
  - `BUILD-REPORT.md`
  - `BUILD-REPORT-v1.25.0.md`
  - `FINAL-SUMMARY.md`
  - `CHANGELOG.md`
  - `progress-log.md`
- Current local validation is already strong:
  - focused spec/source-audit slice `24 passed in 4.08s`
  - full suite `5006 passed, 1 warning`
  - `agentkit spec . --json` now returns primary recommendation kind `adjacent-grounding`
  - conflict check clean, hygiene check clean
- `v1.24.0` remains the last shipped line until the four release surfaces below are directly proven for `v1.25.0`

This contract is complete only when all four release surfaces are directly proven and the repo/workspace chronology surfaces reflect one coherent `v1.25.0` shipped story.

## 2. Non-Negotiable Rules

1. No time-based completion claims.
2. No product-scope drift. This is release completion only.
3. Work only in `/Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding` plus the explicitly named workspace memory files needed for chronology sync.
4. Completion is allowed only when every checklist item below is checked.
5. Keep shipped tag truth separate from any later docs-only chronology commit.
6. If blocked after 3 attempts on the same issue, stop and write the exact blocker.
7. No public-post drafting or outward messaging in this pass.
8. Do not trust prior child summaries without direct source-of-truth checks.

## 3. Deliverables

### D1. Re-ground the local release-ready state
- Run release recall before any irreversible step.
- Re-check contradiction scan from the current tree.
- Reconfirm the repo is still truthfully release-ready before any push, tag, or publish action.

### D2. Validation from the release tree
- Re-run the focused source-audit/spec slice from the current tree.
- Re-run the full suite from the current tree.
- Re-run deterministic hygiene and resolve any non-intentional findings.
- Re-prove the user-visible product claim by verifying `agentkit spec . --json` returns `adjacent-grounding` for the flagship repo case.

### D3. Four-surface release completion
- Push the release branch to origin.
- Create or verify annotated tag `v1.25.0` on the tested release commit.
- Push the tag to origin.
- Publish `agentkit-cli==1.25.0` to PyPI from this repo.
- Verify PyPI project page and version JSON both show `1.25.0` live with wheel and sdist.

### D4. Post-release chronology reconciliation
- Reconcile `BUILD-REPORT.md`, `BUILD-REPORT-v1.25.0.md`, `FINAL-SUMMARY.md`, and `progress-log.md` so they distinguish shipped tag truth from any later docs-only chronology head.
- Update `/Users/mordecai/.openclaw/workspace/memory/WORKING.md` so `last_shipped` and active-build state reflect shipped `v1.25.0` truth and the next slot is open.
- Update `/Users/mordecai/.openclaw/workspace/memory/temporal-facts.md` if it is used as a current shipped-truth surface for `agentkit-cli`.

## 4. Test Requirements

- `uv run python -m pytest -q tests/test_source_audit.py tests/test_source_audit_workflow.py tests/test_spec_cmd.py tests/test_spec_workflow.py tests/test_main.py`
- direct command-path proof that `uv run python -m agentkit_cli.main spec . --json` returns primary recommendation kind `adjacent-grounding`
- `uv run python -m pytest -q`
- `bash /Users/mordecai/.openclaw/workspace/scripts/post-agent-hygiene-check.sh /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`
- PyPI project page and version JSON verified after publish

## 5. Reporting

- Append progress to `progress-log.md` after each completed deliverable.
- Before irreversible release steps, run `bash /Users/mordecai/.openclaw/workspace/scripts/pre-action-recall.sh release agentkit-cli /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`.
- Run `bash /Users/mordecai/.openclaw/workspace/scripts/check-status-conflicts.sh /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding` before irreversible steps and again after chronology reconciliation if needed.
- Final summary must say only one of two things: `SHIPPED` with the four surfaces proven, or `BLOCKED` with the exact blocker.

## 6. Stop Conditions

- All deliverables checked and four release surfaces proven -> DONE.
- 3 consecutive failed attempts on the same blocker -> STOP and write blocker report.
- If any irreversible step succeeds while later proof is ambiguous -> STOP, verify source-of-truth surfaces, then reconcile prose before doing anything else.
- If publish is blocked by auth, network, or registry failure that cannot be resolved safely in-pass -> STOP and write the exact blocker.
