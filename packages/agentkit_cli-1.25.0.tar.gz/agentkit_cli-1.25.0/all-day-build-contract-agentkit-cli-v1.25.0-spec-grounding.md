# All-Day Build Contract: agentkit-cli v1.25.0 spec grounding

Status: In Progress
Date: 2026-04-21
Owner: OpenClaw builder pass
Scope type: Deliverable-gated

## 1. Objective

`agentkit spec` should recommend the next honest adjacent build from the repo's current shipped state, not recycle a gap the repo already closed. On the freshly shipped `agentkit-cli` repo, `agentkit source-audit` reports clean readiness, but `agentkit spec` still recommends making the repo self-hosted for the repo-understanding lane, which is stale and already satisfied. This pass fixes that grounding failure so the flagship repo can reliably spec its own next increment.

This contract is complete only when every deliverable and validation gate below is satisfied.

## 2. Non-Negotiable Build Rules

1. No time-based completion claims.
2. Completion is allowed only when all checklist items are checked.
3. Full test suite must pass at the end.
4. New behavior must ship with focused tests and truthful docs/report updates in the same pass.
5. CLI outputs must stay deterministic and schema-backed where specified.
6. Never modify files outside `/Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding` except the explicitly named workspace state files during final chronology sync.
7. Commit after each completed deliverable, not only at the end.
8. If stuck on the same issue for 3 attempts, stop and write a blocker report.
9. Do not refactor unrelated workflow stages just because they are nearby.
10. Read existing spec, source-audit, map, and workflow tests before changing planner logic.

## 3. Feature Deliverables

### D1. Reproduce and pin the stale-recommendation failure

Capture the current failure mode in tests using the flagship repo fixture or a deterministic local fixture that mirrors the shipped state: source-audit clean, self-hosted source already present, recent shipped workflow artifacts available, yet `agentkit spec` still chooses the already-satisfied self-hosting objective.

Required surfaces:
- `tests/test_spec_engine.py`
- `tests/test_spec_workflow.py`
- any fixture data added under `tests/fixtures/`

- [ ] Add a regression test that proves the current stale recommendation is wrong
- [ ] Define the specific evidence the planner should use to suppress already-satisfied objectives
- [ ] Focused tests for D1 pass

### D2. Ground next-build selection in current repo truth

Update the spec planner so it reasons from current shipped/local-ready state, canonical source readiness, and recent workflow artifacts instead of re-proposing a completed prerequisite. The planner should prefer the next unmet adjacent increment, not a generic subsystem-next-step fallback, when the repo already contains enough evidence to do better.

Required surfaces:
- `agentkit_cli/spec.py`
- `agentkit_cli/commands/spec_cmd.py`
- any helper modules touched for planner evidence gathering

- [ ] Ingest current readiness/artifact evidence needed to recognize already-satisfied prerequisites
- [ ] Suppress or down-rank stale objectives that current repo truth already satisfies
- [ ] Produce a more honest primary recommendation for the flagship repo case
- [ ] Focused tests for D2 pass

### D3. Tighten recommendation output and contract seeding

Make the emitted recommendation more useful once grounding improves. The primary recommendation should include why-now reasoning, scope boundaries, and contract-seed material that reflect the actual next increment instead of a generic subsystem placeholder.

Required surfaces:
- `agentkit_cli/spec.py`
- `tests/test_spec_cmd.py`
- `tests/test_spec_workflow.py`

- [ ] Ensure the markdown and JSON output explain the chosen adjacent increment concretely
- [ ] Keep deterministic output shape for existing consumers
- [ ] Add or update regression coverage for the improved explanation fields

### D4. Truthful local closeout

Reconcile local status/report surfaces so the repo clearly records what changed, what the new next-build behavior is, and what validation passed.

Required surfaces:
- `BUILD-REPORT.md`
- `BUILD-REPORT-v1.25.0.md`
- `FINAL-SUMMARY.md`
- `progress-log.md`
- `CHANGELOG.md`
- version surfaces if a local release-ready closeout is reached

- [ ] Update changelog and local report surfaces for `v1.25.0`
- [ ] Write progress updates after each deliverable
- [ ] Leave the repo truthfully `RELEASE-READY (LOCAL-ONLY)` or write an exact blocker report

## 4. Test Requirements

- [ ] Focused spec-planner tests for the stale-recommendation regression
- [ ] Focused command/workflow tests covering user-visible markdown and JSON output
- [ ] Edge cases: already-satisfied prerequisite objectives must not outrank the next unmet adjacent increment
- [ ] `uv run python -m pytest -q`
- [ ] `bash /Users/mordecai/.openclaw/workspace/scripts/post-agent-hygiene-check.sh /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`

## 5. Reports

- Write progress to `progress-log.md` after each deliverable
- Include what was built, what tests pass, what is next, and any blockers
- Before trusting any status narrative, run `bash /Users/mordecai/.openclaw/workspace/scripts/check-status-conflicts.sh /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`
- Before final summary, run `bash /Users/mordecai/.openclaw/workspace/scripts/post-agent-hygiene-check.sh /Users/mordecai/repos/agentkit-cli-v1.25.0-spec-grounding`
- Final summary must say only one of: `RELEASE-READY (LOCAL-ONLY)` or `BLOCKED`

## 6. Stop Conditions

- All deliverables checked and all tests passing -> DONE
- 3 consecutive failed attempts on the same issue -> STOP, write blocker report
- Scope creep discovered beyond next-build grounding -> STOP and report the newly discovered requirement
- Full suite passes but any deliverable remains unchecked -> continue until the deliverable is complete
