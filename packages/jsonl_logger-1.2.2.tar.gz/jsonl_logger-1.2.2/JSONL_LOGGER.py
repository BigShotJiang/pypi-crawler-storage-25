# FILE:    JSONL_LOGGER.py
# PURPOSE: Custom logging system with JSONL file output
# GOAL:    Provide structured logging to JSONL files
# RUNS TO: log_info() / log_warn() / log_error() / log_metric() / send_notification() / send_notification_async()
#
# ┌────────────────────────────────────────────────────────────────────────────────┐
# │ PERFORMANCE TEST RESULTS (10 RUN AVERAGE)                                      │
# ├───────────────────┬──────────┬──────────┬────────────┬─────────────────────────┤
# │ Test              │ Logs     │ Time     │ Throughput │ Status                  │
# ├───────────────────┼──────────┼──────────┼────────────┼─────────────────────────┤
# │ Single-thread     │ 10,000   │ 1.04 sec │ 9,643/sec  │ ✅ PASS                 │
# │ Multi-thread      │ 100,000  │ 16.87 sec│ 5,902/sec  │ ✅ PASS                 │
# └───────────────────┴──────────┴──────────┴────────────┴─────────────────────────┘
# SYSTEM: Ubuntu 24.04.4 LTS | AMD Ryzen 7 5800H (16 cores, 13Gi RAM) | Python 3.12.3
# TESTED: 2026-04-03 12:38 UTC

# ═══════════════════════════════════════════════════════════════════════════════
# QUICK START
# ═══════════════════════════════════════════════════════════════════════════════
#
# Set environment variables in .env:
#   PROJECT_DIRECTORY=/path/to/your/project
#   LOGS_LOCAL_TIMEZONE=Asia/Kolkata
#   LOGGER_FILE_NAME=orders  # Optional: default log file name (default: "LOGS")
#
# Import and use:
#   from JSONL_LOGGER import log_info, log_warn, log_error, log_metric
#
#   log_info("User logged in", user_id=123, email="user@example.com")
#   log_warn("Rate limit approaching", remaining=10, reset_seconds=60)
#   log_error("Payment failed", error_code=500, error="insufficient_funds")
#   log_metric("api_latency_ms", 142.5, unit="ms", endpoint="/checkout", method="POST")
#   send_notification("Application started", source_file="main.py")
#   await send_notification_async("Deployment completed", source_file="deploy.py")
#
# Output: {PROJECT_DIRECTORY}/_LOGS_DIRECTORY/{YYYY_MM_DD}/LOGS/{logfile_name}.jsonl
#
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# KEY FEATURES & DESIGN DECISIONS
# ═══════════════════════════════════════════════════════════════════════════════
#
# 1. Queue-Based Async Logging
#    - Uses stdlib queue.Queue for thread-safe log buffering
#    - Background thread writes to disk; API calls return immediately
#    - WHY: Keeps logging latency off the caller's hot path — disk I/O never
#           blocks the application thread
#
# 2. Retry Helper for I/O Failures
#    - _with_file_retry() wraps file writes with exponential backoff (3 attempts)
#    - Business function _flush_buffer() is clean of retry loop
#    - WHY: Retry logic isolated in helper per RULE retry-mechanics
#
# 3. Per-Module Log Files
#    - Each module gets its own JSONL file keyed by LOGGER_FILE_NAME
#    - WHY: Per-module files enable independent retention, rotation, and grep
#
# 4. JSONL Format
#    - Each log entry is valid JSON on a single line
#    - WHY: JSON supports nested structures; each line independently parseable
#
# 5. Dual-Timestamp
#    - Every log entry includes both UTC and local timestamps
#    - WHY: UTC for machine sorting; local for human readability
#
# 6. Errors-Only and Warnings-Only Dual-Write
#    - log_error() → {module}.jsonl + {module}.errors.jsonl
#    - log_warn()  → {module}.jsonl + {module}.warn.jsonl
#    - WHY: Fast triage without grep — separate files are always current
#
# 7. Opt-In Signal Handlers
#    - LOGGER_REGISTER_SIGNALS=true enables SIGINT/SIGTERM flush
#    - WHY: Default-off avoids silently overriding host app handlers
#
# 8. Caller Detection via inspect
#    - Auto-detects module name and source file from call stack
#    - WHY: Zero-config ergonomics; explicit params bypass inspect overhead
#
# 9. Zero Data Loss Design
#    - Buffer capped at LOGGER_MAX_BUFFER_SIZE; oldest entries dropped on overflow
#    - WHY: Prevents unbounded memory growth on persistent disk failures
#
# 10. Module-Level Notification Log
#     - send_notification() writes to main_logger.jsonl
#     - WHY: Uniform JSONL format — same parser, same tooling, same retention
#
# ═══════════════════════════════════════════════════════════════════════════════
# SECTION MAP:
#   SECTION 1 · CONSTANTS & CONFIG   → LOGGING_CONFIG, module-level state
#   SECTION 2 · CALLER DETECTION     → _get_logfile_name(), _get_actual_source_file()
#   SECTION 3 · TIMESTAMP & DEBUG    → _get_timestamp(), _debug_print(), _warn_non_primitive_fields()
#   SECTION 4 · PATH SETUP           → _get_log_path(), _ensure_directory()
#   SECTION 5 · CUSTOM FORMATTERS    → ColoredFormatter, UniformLevelFormatter
#   SECTION 6 · RETRY HELPER         → _with_file_retry()
#   SECTION 7 · QUEUE & WRITER       → QueueHandler, _writer_worker(), _flush_buffer()
#   SECTION 8 · SHUTDOWN HANDLERS    → _flush_logs(), _chain_signal_handler()
#   SECTION 9 · LOGGER INIT          → _init_logger()
#   SECTION 10 · PUBLIC API          → log_info(), log_warn(), log_error(), log_metric()
#   SECTION 11 · NOTIFICATION API    → send_notification(), send_notification_async()
#   SECTION 12 · PERFORMANCE TEST    → run_performance_test()

# ── IMPORTS ──────────────────────────────────────────────────────────────────
# Three groups: stdlib · third-party · internal

# ── stdlib ───────────────────────────────────────────────────────────────────
import asyncio
import atexit
import inspect
import logging
import os
import queue
import signal
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from unittest.mock import patch

# ── third-party ──────────────────────────────────────────────────────────────
from dotenv import load_dotenv

# WHY: load_dotenv() runs here — after all imports, before constants — so env
#      vars are populated before any os.getenv() call in the constants block
load_dotenv()

# WHY: Shorten level names for compact, uniform JSONL output; "WARN"/"ERRO" are
#      4 chars like "INFO" — makes logs visually aligned and easier to scan
logging.addLevelName(logging.WARNING, "WARN")
logging.addLevelName(logging.ERROR, "ERRO")

# ── CHANGE 1 of 3 — register METR as a custom log level ──────────────────────
METRIC_LEVEL: int = 25
logging.addLevelName(METRIC_LEVEL, "METR")
# WHY: Custom level 25 sits between INFO (20) and WARNING (30) so metric records
#      are distinguishable from audit INFO at the handler level.

# ── TESTS ───────────────────────────────────────────────────────────────────
try:
    import pytest
except ImportError:
    pytest = None

if pytest is not None:

    class TestImportValidation:
        """WHY: _get_log_path() validates PROJECT_DIRECTORY before any log write —
        a missing or invalid path should raise ValueError with actionable message."""

        def test_get_log_path_validates_project_directory(self) -> None:
            import subprocess

            shared_lib_dir = os.path.dirname(os.path.abspath(__file__))
            env = os.environ.copy()
            env.pop("PROJECT_DIRECTORY", None)
            env["PYTHONPATH"] = shared_lib_dir
            # _get_log_path() raises ValueError when PROJECT_DIRECTORY is missing;
            # import itself succeeds because path validation is lazy (on first emit)
            result = subprocess.run(
                ["python3", "-c", "import JSONL_LOGGER as m; m._get_log_path('test')"],
                capture_output=True,
                text=True,
                env=env,
                cwd="/tmp",
            )
            assert result.returncode != 0, (
                f"Expected non-zero returncode, got {result.returncode}"
            )
            assert "PROJECT_DIRECTORY" in result.stderr, (
                f"Expected 'PROJECT_DIRECTORY' in stderr, got: {result.stderr}"
            )
            assert result.returncode != 0, (
                f"Expected non-zero returncode, got {result.returncode}"
            )
            assert "PROJECT_DIRECTORY" in result.stderr, (
                f"Expected 'PROJECT_DIRECTORY' in stderr, got: {result.stderr}"
            )


# ── SECTION 1 · CONSTANTS & CONFIG ───────────────────────────────────────────
# Goal: Define all configuration values and module-level state in one place

LOGGER_FILE_NAME: str = os.getenv("LOGGER_FILE_NAME", "TEST_LOGGER")
# WHY: Sentinel default used when no caller sets LOGGER_FILE_NAME — "TEST_LOGGER"
#      signals test/REPL usage so logs don't silently land in a production module file

DEBUG_PRINT: bool = False
# WHY: Disabled by default to reduce noise; enable during development only

CONSOLE_LOGGING_ENABLED: bool = (
    os.getenv("CONSOLE_LOGGING_ENABLED", "false").lower() == "true"
)
# WHY: Off by default to keep log output clean; enable via env var when debugging

BUFFER_SIZE: int = 1000
# WHY: Larger buffer = fewer open()/write() calls = better throughput under burst load

FLUSH_INTERVAL: float = 0.05
# WHY: 50ms - faster response for flush while keeping syscall overhead low

RETRY_MAX_ATTEMPTS: int = 3
# WHY: Three attempts cover transient disk/NFS blips without delaying the writer loop

RETRY_BACKOFF_BASE: float = 0.1
# WHY: 100ms base → 100ms, 200ms, 400ms; fast enough for transient errors

PROJECT_DIRECTORY: str = os.path.expandvars(os.getenv("PROJECT_DIRECTORY", ""))
# WHY: Required — log root must be explicit; empty string triggers ValueError in
#      _get_log_path() with actionable message rather than silent write to wrong path

_DEFAULT_LOGFILE: str = "LOGS"
# WHY: Default logfile name — can override via LOGGER_FILE_NAME env var or explicit param

LOGS_LOCAL_TIMEZONE: str = os.getenv("LOGS_LOCAL_TIMEZONE", "")
# WHY: Local timezone for logging. Set via LOGS_LOCAL_TIMEZONE env var.

_LOGS_DIRECTORY: str = "_LOGS_DIRECTORY"
# WHY: Hardcoded — this is the one canonical log subdirectory for this project.

LOGGER_REGISTER_SIGNALS: bool = (
    os.getenv("LOGGER_REGISTER_SIGNALS", "false").lower() == "true"
)
# WHY: Opt-in avoids silently overriding host app handlers (FastAPI, Gunicorn, etc.)

LOGGER_DAEMON_THREAD: bool = os.getenv("LOGGER_DAEMON_THREAD", "true").lower() == "true"
# WHY: Daemon=True is the default for fast process exit

LOGGER_MAX_BUFFER_SIZE: int = int(os.getenv("LOGGER_MAX_BUFFER_SIZE", "200000"))
# WHY: Hard cap prevents unbounded memory growth when disk fails persistently

# Logger implementation: stdlib logging (use extra={} for structured fields)
# Logger name: __name__ — from DOMAIN_RULES.md §2 Logging Strategy
logger: logging.Logger | None = None
# WHY: Initialized to None at module level; _init_logger() assigns at import time

_RESERVED_LOG_KEYS: frozenset[str] = frozenset(
    {
        "name",
        "msg",
        "args",
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "taskName",
        "message",
        "asctime",
    }
)
# WHY: Single source of truth for stdlib LogRecord attrs

_PRIMITIVE_TYPES = (str, int, float, bool, type(None))
# WHY: Defines the set of types that serialize cleanly to JSONL

_log_queue: queue.Queue | None = None
_writer_thread: threading.Thread | None = None
_buffers: dict[str, list[str]] = {}
_buffer_lock: threading.Lock = threading.Lock()
_shutdown: bool = False


# ── SECTION 2 · CALLER DETECTION ─────────────────────────────────────────────
# Goal: Resolve the source module name for each log entry


def _get_logfile_name() -> str:
    """[TIER 2] Resolve the logging module name from the call stack.

    WHY: Zero-config ergonomics — callers don't need to pass module_name manually.
    Checks LOGGER_FILE_NAME in caller's globals first (grouping pattern), then
    falls back to the caller's filename without .py extension.
    """
    frame = None
    try:
        frame = inspect.currentframe()
        if frame is None:
            return "unknown_file"

        # WHY: Skip two frames — log_info/warn/error/metric, then this function
        frame = frame.f_back  # → log_info/warn/error/metric
        if frame is None:
            return "unknown_file"
        frame = frame.f_back  # → actual caller
        if frame is None:
            return "unknown_file"

        if "LOGGER_FILE_NAME" in frame.f_globals:
            return frame.f_globals["LOGGER_FILE_NAME"]

        file_path = frame.f_code.co_filename
        if file_path and file_path != __file__:
            return Path(file_path).name.replace(".py", "")

        return "unknown_file"
    except Exception as e:
        # WHY: Exception (not bare except) — frame inspection can fail under
        #      restricted interpreters; returning a sentinel is safer than crashing.
        return "unknown_file"
    finally:
        if frame is not None:
            del frame


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetLogfileName:
        """WHY: Caller detection drives every log entry's module_name field — a wrong
        detection silently misroutes logs to the wrong JSONL file."""

        def test_get_logfile_name(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import types

            # ── LOGGER_FILE_NAME in globals takes priority over filename ──────────
            fake_frame = types.SimpleNamespace(
                f_globals={"LOGGER_FILE_NAME": "MY_APP"},
                f_back=None,
                f_code=types.SimpleNamespace(co_filename="irrelevant.py"),
            )
            with patch("inspect.currentframe") as mock_cf:
                inner = types.SimpleNamespace(
                    f_back=types.SimpleNamespace(f_back=fake_frame)
                )
                mock_cf.return_value = inner
                result = _get_logfile_name()
            assert result == "MY_APP", f"Expected 'MY_APP', got {result!r}"

            # ── no LOGGER_FILE_NAME falls back to caller filename ─────────────────
            result = _get_logfile_name()
            assert result != "unknown_file", (
                "Should detect caller filename, not 'unknown_file'"
            )
            assert len(result) > 0, "Filename must be non-empty"

            # ── exception during frame walk returns "unknown_file" ────────────────
            with patch("inspect.currentframe", side_effect=RuntimeError("no frames")):
                result = _get_logfile_name()
            assert result == "unknown_file", (
                f"Expected 'unknown_file' on exception, got {result!r}"
            )


_SKIP_FRAME_PATHS: tuple[str, ...] = (
    "/asyncio/",
    "asyncio/",
    "asyncio.py",
    "runners.py",
    "base_events.py",
    "events.py",
    "/concurrent/",
    "/threading.py",
    "/site-packages/",
)
_SKIP_FRAME_NAMES: frozenset[str] = frozenset(
    {"runners", "base_events", "events", "asyncio", "threading"}
)


def _get_caller_module() -> str:
    """[TIER 2] Get the Python module name (e.g., 'orders', 'payments') from call stack.

    Uses __name__ from caller's module globals.
    """
    frame = None
    try:
        frame = inspect.currentframe()
        if frame is None:
            return "unknown_module"

        # Skip frames: log_info → this function → actual caller
        for _ in range(2):
            frame = frame.f_back
            if frame is None:
                return "unknown_module"

        module_name = frame.f_globals.get("__name__", "unknown_module")
        return module_name.split(".")[-1]

    except Exception as e:
        # WHY: Exception (not bare except) — frame inspection can fail under
        #      restricted interpreters; returning a sentinel is safer than crashing.
        return "unknown_module"
    finally:
        if frame is not None:
            del frame


def _get_actual_source_file() -> str:
    """[TIER 2] Get the actual Python filename, bypassing LOGGER_FILE_NAME grouping.

    WHY: Skips asyncio/stdlib internal frames so async callers don't produce
    "events" as the detected source.
    """
    frame = None
    try:
        frame = inspect.currentframe()
        if frame is None:
            return "unknown_source"

        while frame is not None:
            co_filename = getattr(getattr(frame, "f_code", None), "co_filename", None)

            if co_filename is None:
                frame = frame.f_back
                continue

            if co_filename == __file__:
                frame = frame.f_back
                continue

            if any(skip in co_filename for skip in _SKIP_FRAME_PATHS):
                frame = frame.f_back
                continue

            filename = Path(co_filename).stem
            if not filename or filename in _SKIP_FRAME_NAMES:
                frame = frame.f_back
                continue

            return filename

        return Path(__file__).stem  # __main__ fallback

    except Exception as e:
        # WHY: Exception (not bare except) — frame inspection can fail under
        #      restricted interpreters; returning a sentinel is safer than crashing.
        return "unknown_source"
    finally:
        if frame is not None:
            del frame


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetActualSourceFile:
        """WHY: source_file must reflect the actual calling Python file, not the
        LOGGER_FILE_NAME group alias — without this, dual-source tracking fails."""

        def test_get_actual_source_file(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import types

            # ── bypasses LOGGER_FILE_NAME and returns actual filename ─────────────
            def _make_frame(co_filename: str, f_back):
                return types.SimpleNamespace(
                    f_code=types.SimpleNamespace(co_filename=co_filename),
                    f_globals={},
                    f_back=f_back,
                )

            fake_caller = _make_frame("actual_module.py", None)
            frame_b = _make_frame(__file__, fake_caller)
            frame_a = _make_frame(__file__, frame_b)

            with patch("inspect.currentframe", return_value=frame_a):
                result = _get_actual_source_file()
            assert result == "actual_module", (
                f"Expected 'actual_module', got {result!r}"
            )

            # ── exception during frame walk returns "unknown_source" ──────────────
            with patch("inspect.currentframe", side_effect=RuntimeError("no frames")):
                result = _get_actual_source_file()
            assert result == "unknown_source", (
                f"Expected 'unknown_source' on exception, got {result!r}"
            )


# ── SECTION 3 · TIMESTAMP & FIELD VALIDATION ─────────────────────────────────
# Goal: Provide timestamp formatting and warn on non-serializable extra fields


def _get_timestamp() -> dict[str, str]:
    """[TIER 3] Return both UTC and local timestamps in ISO-8601 format.

    WHY: ISO-8601 with Z suffix ensures consistent, sortable timestamps.
    Local time with offset helps readability while UTC ensures cross-machine consistency.
    """
    from zoneinfo import ZoneInfo

    utc_time = datetime.now(timezone.utc)
    utc_str = utc_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    try:
        if not LOGS_LOCAL_TIMEZONE:
            raise ValueError(
                "LOGS_LOCAL_TIMEZONE must be set in .env\n"
                "⚠️  Common mistake: LOGS_LOCAL_TIMEZONE =Asia/Kolkata has a space before =\n"
                "   Correct format:  LOGS_LOCAL_TIMEZONE=Asia/Kolkata"
            )
        tz = ZoneInfo(LOGS_LOCAL_TIMEZONE)
        local_time = utc_time.astimezone(tz)
        local_str = local_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[
            :-3
        ] + local_time.strftime("%z")
    except ValueError:
        raise
    except Exception as e:
        # WHY: Exception (not bare except) — timezone lookup can fail for invalid
        #      zone names; falling back to UTC keeps logging functional.
        local_str = utc_str

    return {"utc": utc_str, "local": local_str}


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetTimestamp:
        """WHY: Timestamp format is the contract shared with every log parser and Rust
        sibling — a wrong format silently breaks all downstream tooling."""

        def test_get_timestamp(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import re
            from datetime import timedelta
            import JSONL_LOGGER as mod

            original_tz = mod.LOGS_LOCAL_TIMEZONE
            try:
                mod.LOGS_LOCAL_TIMEZONE = "Asia/Kolkata"

                # ── returns dict with utc and local keys ───────────────────────────────
                result = mod._get_timestamp()
                assert isinstance(result, dict), (
                    f"Expected dict, got {type(result).__name__}"
                )
                assert "utc" in result, "Missing 'utc' key"
                assert "local" in result, "Missing 'local' key"

                # ── UTC ends with Z (UTC marker) ─────────────────────────────────────
                assert result["utc"].endswith("Z"), (
                    f"UTC timestamp must end with 'Z', got {result['utc']!r}"
                )

                # ── UTC matches ISO-8601 with millisecond precision ───────────────────
                pattern = r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$"
                assert re.match(pattern, result["utc"]), (
                    f"Unexpected UTC format: {result['utc']!r}"
                )

                # ── local has offset (e.g., +0530 or -0800) ───────────────────────────
                assert re.match(r".+\d{4}$", result["local"]), (
                    f"Unexpected local format: {result['local']!r}"
                )

                # ── reflects real clock, not a stale cached value ─────────────────────
                before = datetime.now(timezone.utc)
                result2 = mod._get_timestamp()
                after = datetime.now(timezone.utc)
                parsed = datetime.fromisoformat(result2["utc"].replace("Z", "+00:00"))
                assert (before - timedelta(milliseconds=1)) <= parsed <= after, (
                    f"Timestamp {parsed} outside expected range [{before}..{after}]"
                )
            finally:
                mod.LOGS_LOCAL_TIMEZONE = original_tz


def _debug_print(message: str) -> None:
    """[TIER 3] Print internal debug messages to stderr when DEBUG_PRINT is enabled.

    WHY: Tier 3 only — development-time visibility without polluting production logs.
    """
    if DEBUG_PRINT:
        print(f"[DEBUG] {message}", file=sys.stderr)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestDebugPrint:
        """WHY: _debug_print is the only development visibility mechanism — if it leaks
        to production stderr or is silenced when needed, debugging becomes impossible."""

        def test_debug_print(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import io
            import JSONL_LOGGER as mod

            # ── writes to stderr when DEBUG_PRINT=True ────────────────────────────
            original = mod.DEBUG_PRINT
            mod.DEBUG_PRINT = True
            try:
                buf = io.StringIO()
                with patch("sys.stderr", buf):
                    _debug_print("hello debug")
                assert "[DEBUG] hello debug" in buf.getvalue(), (
                    f"Expected debug output, got: {buf.getvalue()!r}"
                )
            finally:
                mod.DEBUG_PRINT = original

            # ── silent when DEBUG_PRINT=False (production default) ───────────────
            mod.DEBUG_PRINT = False
            try:
                buf = io.StringIO()
                with patch("sys.stderr", buf):
                    _debug_print("should not appear")
                assert buf.getvalue() == "", (
                    f"Expected empty output, got: {buf.getvalue()!r}"
                )
            finally:
                mod.DEBUG_PRINT = original


def _warn_non_primitive_fields(extra_fields: dict[str, Any], caller: str) -> None:
    """[TIER 3] Emit a stderr warning for any extra_field value that is not a primitive type.

    WHY: json.dumps(default=str) silently converts datetimes, lists, and custom
    classes to their string repr. This hides bugs and creates unqueryable JSONL fields.
    """
    for k, v in extra_fields.items():
        if not isinstance(v, _PRIMITIVE_TYPES):
            print(
                f"[LOGGER WARN] Field '{k}' in {caller} has type {type(v).__name__!r} "
                f"— will be stringified in JSONL. Consider explicit serialization.",
                file=sys.stderr,
            )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestWarnNonPrimitiveFields:
        """WHY: Silent stringification of complex types produces unqueryable JSONL
        fields — the warning is the only signal callers get."""

        def test_warn_non_primitive_fields(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import io

            # ── list value emits warning with field name and type ─────────────────
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                _warn_non_primitive_fields({"tags": [1, 2, 3]}, "my_module")
            assert "tags" in buf.getvalue(), (
                f"Expected 'tags' in warning, got: {buf.getvalue()!r}"
            )
            assert "list" in buf.getvalue(), (
                f"Expected 'list' in warning, got: {buf.getvalue()!r}"
            )

            # ── dict value emits warning ──────────────────────────────────────────
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                _warn_non_primitive_fields({"meta": {"a": 1}}, "my_module")
            assert "meta" in buf.getvalue(), (
                f"Expected 'meta' in warning, got: {buf.getvalue()!r}"
            )
            assert "dict" in buf.getvalue(), (
                f"Expected 'dict' in warning, got: {buf.getvalue()!r}"
            )

            # ── datetime value emits warning ──────────────────────────────────────
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                _warn_non_primitive_fields({"ts": datetime.now()}, "my_module")
            assert "ts" in buf.getvalue(), (
                f"Expected 'ts' in warning, got: {buf.getvalue()!r}"
            )
            assert "datetime" in buf.getvalue(), (
                f"Expected 'datetime' in warning, got: {buf.getvalue()!r}"
            )

            # ── primitive types (str/int/float/bool/None) emit no warning ─────────
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                _warn_non_primitive_fields(
                    {"s": "ok", "i": 1, "f": 1.5, "b": True, "n": None}, "my_module"
                )
            assert buf.getvalue() == "", (
                f"Expected no warnings for primitives, got: {buf.getvalue()!r}"
            )

            # ── warning includes caller module name for fast triage ───────────────
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                _warn_non_primitive_fields({"x": [1]}, "payments_module")
            assert "payments_module" in buf.getvalue(), (
                f"Expected caller name in warning, got: {buf.getvalue()!r}"
            )


# ── SECTION 4 · PATH SETUP ───────────────────────────────────────────────────
# Goal: Resolve and create the directory path for each module's log file


def _ensure_directory(path: Path, mode: int = 0o755) -> None:
    """[TIER 2] Create directory and all parents if they do not exist.

    WHY: 0o755 gives rwxr-xr-x — owner can write, others can read/execute.
    """
    path.mkdir(parents=True, exist_ok=True, mode=mode)


def _get_log_path(logfile_name: str | None = None, suffix: str = "") -> Path:
    """[TIER 2] Resolve the JSONL file path for a given logfile name and optional suffix.

    WHY: Centralised path logic means all three file types (audit, errors, metrics)
    follow the same directory and naming convention automatically.
    """
    logfile_name = logfile_name or os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    logfile_name = logfile_name.replace(".py", "")

    if not PROJECT_DIRECTORY:
        raise ValueError(
            "PROJECT_DIRECTORY must be set in .env\n"
            "⚠️  Common mistake: PROJECT_DIRECTORY =/path has a space before =\n"
            "   Correct format:  PROJECT_DIRECTORY=/path/to/logs"
        )

    base_dir = Path(PROJECT_DIRECTORY)
    if not base_dir.exists():
        raise ValueError(f"PROJECT_DIRECTORY '{base_dir}' does not exist")
    if not os.access(base_dir, os.W_OK):
        raise ValueError(f"PROJECT_DIRECTORY '{base_dir}' is not writable")

    today = datetime.now(timezone.utc).strftime("%Y_%m_%d")
    log_dir = base_dir / _LOGS_DIRECTORY / today / "LOGS"
    _ensure_directory(log_dir)
    return log_dir / f"{logfile_name}{suffix}.jsonl"


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetLogPath:
        """WHY: Path construction is the spine of the logging system — wrong paths mean
        silent data loss."""

        def test_get_log_path(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import tempfile
            import JSONL_LOGGER as mod
            from datetime import datetime, timezone

            # ── missing PROJECT_DIRECTORY raises ValueError ───────────────────────
            original_pd = mod.PROJECT_DIRECTORY
            mod.PROJECT_DIRECTORY = ""
            try:
                try:
                    _get_log_path("mymodule")
                    assert False, "Expected ValueError for missing PROJECT_DIRECTORY"
                except ValueError as e:
                    assert "PROJECT_DIRECTORY" in str(e), (
                        f"Expected 'PROJECT_DIRECTORY' in error, got: {e!r}"
                    )
            finally:
                mod.PROJECT_DIRECTORY = original_pd

            # ── non-existent PROJECT_DIRECTORY raises ValueError ─────────────────
            with patch("JSONL_LOGGER.PROJECT_DIRECTORY", "/nonexistent/path/abc123"):
                try:
                    _get_log_path("mymodule")
                    assert False, "Expected ValueError for non-existent path"
                except ValueError as e:
                    assert "does not exist" in str(e), (
                        f"Expected 'does not exist' in error, got: {e!r}"
                    )

            # ── _LOGS_DIRECTORY is always _LOGS_DIRECTORY — hardcoded ─────────────
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule")
            assert "_LOGS_DIRECTORY" in str(result), (
                f"Expected '_LOGS_DIRECTORY' in path, got: {result!r}"
            )

            # ── plain suffix="" produces {module}.jsonl ───────────────────────────
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule", suffix="")
            assert result.name == "mymodule.jsonl", (
                f"Expected 'mymodule.jsonl', got {result.name!r}"
            )

            # ── .errors suffix produces {module}.errors.jsonl ────────────────────
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule", suffix=".errors")
            assert result.name == "mymodule.errors.jsonl", (
                f"Expected 'mymodule.errors.jsonl', got {result.name!r}"
            )

            # ── .metrics suffix produces {module}.metrics.jsonl ──────────────────
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule", suffix=".metrics")
            assert result.name == "mymodule.metrics.jsonl", (
                f"Expected 'mymodule.metrics.jsonl', got {result.name!r}"
            )

            # ── dated subdirectory present in path ───────────────────────────────
            today = datetime.now(timezone.utc).strftime("%Y_%m_%d")
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule")
            assert today in str(result), (
                f"Expected date {today} in path, got: {result!r}"
            )

            # ── .py extension stripped from module_name ────────────────────────────
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule.py", suffix="")
            assert result.name == "mymodule.jsonl", (
                f"Expected 'mymodule.jsonl' (stripped .py), got {result.name!r}"
            )

            # ── dated directory is created if not yet present ────────────────────
            with tempfile.TemporaryDirectory() as tmp:
                orig_pd = mod.PROJECT_DIRECTORY
                mod.PROJECT_DIRECTORY = tmp
                try:
                    result = _get_log_path("mymodule")
                    assert result.parent.exists(), (
                        f"Log directory should exist: {result.parent}"
                    )
                finally:
                    mod.PROJECT_DIRECTORY = orig_pd

            # ── LOGS subdirectory present after date in path ──────────────────────
            today = datetime.now(timezone.utc).strftime("%Y_%m_%d")
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    result = _get_log_path("mymodule")
            path_parts = result.parts
            date_idx = path_parts.index(today)
            assert path_parts[date_idx + 1] == "LOGS", (
                f"Expected 'LOGS' after date, got {path_parts[date_idx + 1]!r}"
            )


# ── SECTION 5 · CUSTOM FORMATTERS ────────────────────────────────────────────
# Goal: Format log records for colored console output and JSONL file output
# RULE OVERRIDE: §PYTHON no-oop — logging.Formatter requires class inheritance;
#                there is no functional formatter API in stdlib logging.
# Restore when: stdlib logging adds a hook-based formatter protocol.


class ColoredFormatter(logging.Formatter):
    """Formatter for colored console output with emoji level indicators.

    WHY: Visual differentiation at a glance during development.
    """

    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    RESET = "\033[0m"

    EMOJI_MAP = {
        "INFO": "🟢",
        "WARN": "🟡",
        "ERRO": "🔴",
        "METR": "📊",
        "CRITICAL": "🔴",
    }

    def format(self, record: logging.LogRecord) -> str:
        emoji = self.EMOJI_MAP.get(record.levelname, "")
        color = self.RESET
        if record.levelno >= logging.ERROR:
            color = self.RED
        elif record.levelno == logging.WARNING:
            color = self.YELLOW
        elif record.levelno == logging.INFO:
            color = self.GREEN

        timestamp = _get_timestamp()
        extra = {
            k: v
            for k, v in record.__dict__.items()
            if k not in _RESERVED_LOG_KEYS and not k.startswith("_")
        }
        module_name = extra.get("module_name", Path(record.pathname).name)
        source_file = extra.get("source_file", "unknown")
        return (
            f"{timestamp['utc']} {color}{record.levelname}{self.RESET} "
            f"{emoji} [{module_name}:{source_file}] {record.getMessage()}"
        )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestColoredFormatter:
        """WHY: Console formatting is the developer's primary real-time log view —
        wrong colours or missing emojis make level discrimination impossible."""

        def _make_record(
            self, level: int, message: str, **extra: Any
        ) -> logging.LogRecord:
            record = logging.LogRecord(
                name="test",
                level=level,
                pathname="mymodule.py",
                lineno=1,
                msg=message,
                args=(),
                exc_info=None,
            )
            for k, v in extra.items():
                setattr(record, k, v)
            return record

        def test_colored_formatter_format(self) -> None:
            assert pytest is not None  # Type guard for pyright
            fmt = ColoredFormatter()

            # ── INFO → green ANSI code + green emoji ─────────────────────────────
            result = fmt.format(self._make_record(logging.INFO, "hello"))
            assert "\033[92m" in result, "Expected GREEN ANSI code"
            assert "🟢" in result, "Expected green emoji"

            # ── WARNING → yellow ANSI code + yellow emoji ─────────────────────────
            result = fmt.format(self._make_record(logging.WARNING, "watch out"))
            assert "\033[93m" in result, "Expected YELLOW ANSI code"
            assert "🟡" in result, "Expected yellow emoji"

            # ── ERROR → red ANSI code + red emoji ────────────────────────────────
            result = fmt.format(self._make_record(logging.ERROR, "boom"))
            assert "\033[91m" in result, "Expected RED ANSI code"
            assert "🔴" in result, "Expected red emoji"

            # ── METR → chart emoji ────────────────────────────────────────────────
            metr = self._make_record(METRIC_LEVEL, "api_latency_ms=142ms")
            metr.levelname = "METR"
            assert "📊" in fmt.format(metr), "Expected chart emoji for METR"

            # ── message text survives formatting ──────────────────────────────────
            result = fmt.format(self._make_record(logging.INFO, "user logged in"))
            assert "user logged in" in result, "Message text should survive formatting"

            # ── RESET present to prevent terminal colour bleed ────────────────────
            result = fmt.format(self._make_record(logging.INFO, "hello"))
            assert "\033[0m" in result, "Expected RESET ANSI code"


class UniformLevelFormatter(logging.Formatter):
    """Formatter that serialises each log record as a single-line JSON object.

    WHY: JSONL is independently parseable per line, supports nested types,
    and avoids CSV escaping issues.
    """

    def format(self, record: logging.LogRecord) -> str:
        import json as _json

        timestamp = _get_timestamp()
        extra = {
            k: v
            for k, v in record.__dict__.items()
            if k not in _RESERVED_LOG_KEYS and not k.startswith("_")
        }
        logfile_name = extra.pop(
            "logfile_name", os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
        )
        module_name = extra.pop("module_name", _get_caller_module())
        source_file = extra.pop("source_file", "unknown")
        source = extra.pop("source", None)

        log_entry = {
            "timestamp": timestamp["utc"],
            "timestamp_local": timestamp["local"],
            "level": record.levelname,
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": source_file,
            **({"source": source} if source is not None else {}),
            "message": record.getMessage(),
            **extra,
        }
        return _json.dumps(log_entry, default=str, separators=(",", ":"))
        # WHY: separators=(',', ':') produces compact JSON matching serde_json output


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestUniformLevelFormatter:
        """WHY: JSONL shape is the shared contract between this module, Rust siblings,
        and every downstream log parser."""

        def _make_record(
            self, level: int, message: str, levelname: str | None = None, **extra: Any
        ) -> logging.LogRecord:
            record = logging.LogRecord(
                name="test",
                level=level,
                pathname="mymodule.py",
                lineno=1,
                msg=message,
                args=(),
                exc_info=None,
            )
            if levelname:
                record.levelname = levelname
            for k, v in extra.items():
                setattr(record, k, v)
            return record

        def test_uniform_level_formatter_format(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import json

            fmt = UniformLevelFormatter()

            # ── output is valid JSON ──────────────────────────────────────────────
            record = self._make_record(
                logging.INFO, "hello", module_name="mod", source_file="src"
            )
            parsed = json.loads(fmt.format(record))
            assert isinstance(parsed, dict), (
                f"Expected dict, got {type(parsed).__name__}"
            )

            # ── required top-level keys present ──────────────────────────────────
            for key in (
                "timestamp",
                "timestamp_local",
                "level",
                "logfile_name",
                "module_name",
                "source_file",
                "message",
            ):
                assert key in parsed, f"Missing required key: {key}"

            # ── compact separators (no spaces) ────────────────────────────────────
            result = fmt.format(record)
            assert ", " not in result, "Found ', ' — should use compact ',' separator"
            assert ": " not in result, "Found ': ' — should use compact ':' separator"

            # ── WARNING serialises to renamed levelname "WARN" ────────────────────
            record = self._make_record(
                logging.WARNING, "watch out", module_name="mod", source_file="src"
            )
            parsed = json.loads(fmt.format(record))
            assert parsed["level"] == "WARN", (
                f"Expected 'WARN', got {parsed['level']!r}"
            )

            # ── custom METR level serialises to "METR" ────────────────────────────
            record = self._make_record(
                METRIC_LEVEL,
                "latency=100ms",
                levelname="METR",
                module_name="mod",
                source_file="src",
            )
            assert json.loads(fmt.format(record))["level"] == "METR", (
                "Expected 'METR' level for metric records"
            )

            # ── extra structured fields survive into JSONL ─────────────────────────
            record = self._make_record(
                logging.INFO, "login", module_name="mod", source_file="src", user_id=42
            )
            assert json.loads(fmt.format(record)).get("user_id") == 42, (
                "Expected user_id=42 in JSONL"
            )

            # ── reserved LogRecord internals do not leak into JSONL ───────────────
            record = self._make_record(
                logging.INFO, "hello", module_name="mod", source_file="src"
            )
            parsed = json.loads(fmt.format(record))
            for reserved in ("lineno", "funcName", "thread", "processName", "msecs"):
                assert reserved not in parsed, f"Reserved key leaked: {reserved}"

            # ── source field absent when not set ─────────────────────────────────
            record = self._make_record(
                logging.INFO, "hello", module_name="mod", source_file="src"
            )
            assert "source" not in json.loads(fmt.format(record)), (
                "source field should be absent when not set"
            )

            # ── source field present when set ─────────────────────────────────────
            record = self._make_record(
                logging.INFO,
                "hello",
                module_name="mod",
                source_file="src",
                source="myservice",
            )
            assert json.loads(fmt.format(record)).get("source") == "myservice", (
                "Expected source='myservice'"
            )

            # ── non-serialisable value stringified, not crashed ───────────────────
            record = self._make_record(
                logging.INFO, "hello", module_name="mod", source_file="src"
            )
            record.weird = object()
            result = fmt.format(record)
            parsed = json.loads(result)
            assert "weird" in parsed, (
                "Non-serialisable value should be stringified, not dropped"
            )


# ── SECTION 6 · RETRY HELPER ─────────────────────────────────────────────────
# Goal: Isolate retry mechanics so business functions stay free of retry loops


def _with_file_retry(write_fn: Callable[[], None], log_file: str) -> list[str] | None:
    """[TIER 2] Attempt write_fn() up to RETRY_MAX_ATTEMPTS times with exponential backoff.

    WHY: Retry logic lives here — not in _flush_buffer — per RULE retry-mechanics.
    Business functions must not contain retry loops.
    """
    for attempt in range(RETRY_MAX_ATTEMPTS):
        try:
            write_fn()
            return None  # Success — nothing to re-buffer
        except Exception as e:
            # WHY: Exception (not bare except) — all non-system-exit errors are
            #      treated as transient for file I/O per DOMAIN_RULES retry policy.
            if attempt < RETRY_MAX_ATTEMPTS - 1:
                delay = RETRY_BACKOFF_BASE * (2**attempt)
                _debug_print(
                    f"Retry {attempt + 1}/{RETRY_MAX_ATTEMPTS} for {log_file} "
                    f"after {delay}s: {e}"
                )
                time.sleep(delay)
            else:
                _debug_print(
                    f"Failed to write logs to {log_file} after "
                    f"{RETRY_MAX_ATTEMPTS} attempts: {e}"
                )
    return []  # Signals caller that all attempts failed


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestWithFileRetry:
        """WHY: _with_file_retry is the only disk-failure safety net — a wrong return
        value on exhaustion causes silent log loss."""

        def test_with_file_retry(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── success on first attempt returns None ─────────────────────────────
            calls = []

            def write_fn() -> None:
                calls.append(1)

            result = _with_file_retry(write_fn, "test.jsonl")
            assert result is None, f"Expected None on success, got {result!r}"
            assert len(calls) == 1, f"Expected 1 call, got {len(calls)}"

            # ── success on third attempt (transient failures) returns None ────────
            attempt_count = [0]

            def write_fn_transient() -> None:
                attempt_count[0] += 1
                if attempt_count[0] < 3:
                    raise OSError("disk busy")

            with patch("time.sleep"):
                result = _with_file_retry(write_fn_transient, "test.jsonl")
            assert result is None, (
                f"Expected None after transient recovery, got {result!r}"
            )
            assert attempt_count[0] == 3, f"Expected 3 attempts, got {attempt_count[0]}"

            # ── total exhaustion returns empty list (re-buffer sentinel) ──────────
            with patch("time.sleep"):
                result = _with_file_retry(
                    lambda: (_ for _ in ()).throw(OSError("disk full")), "test.jsonl"
                )
            assert result == [], f"Expected [] on exhaustion, got {result!r}"

            # ── any exception type is retried up to max attempts ──────────────────
            perm_count = [0]

            def write_fn_perm() -> None:
                perm_count[0] += 1
                raise PermissionError("not allowed")

            with patch("time.sleep"):
                _with_file_retry(write_fn_perm, "test.jsonl")
            assert perm_count[0] == RETRY_MAX_ATTEMPTS, (
                f"Expected {RETRY_MAX_ATTEMPTS} attempts, got {perm_count[0]}"
            )

            # ── backoff delays grow exponentially ─────────────────────────────────
            sleep_calls: list[float] = []

            with patch("time.sleep", side_effect=lambda d: sleep_calls.append(d)):
                _with_file_retry(
                    lambda: (_ for _ in ()).throw(OSError("error")), "test.jsonl"
                )
            assert len(sleep_calls) == RETRY_MAX_ATTEMPTS - 1, (
                f"Expected {RETRY_MAX_ATTEMPTS - 1} sleep calls, got {len(sleep_calls)}"
            )
            assert sleep_calls[1] == sleep_calls[0] * 2, (
                f"Expected exponential backoff: {sleep_calls[1]} == {sleep_calls[0]} * 2"
            )


# ── SECTION 7 · QUEUE & WRITER ───────────────────────────────────────────────
# Goal: Buffer log entries and flush them to disk on a background thread
# RULE OVERRIDE: §PYTHON no-oop — QueueHandler inherits from logging.Handler
# which requires class-based inheritance; no functional alternative exists.
# Restore when: stdlib logging adds a hook-based handler protocol.


class QueueHandler(logging.Handler):
    """Handler that enqueues formatted log records for background disk writing.

    WHY: Decouples the caller's thread from disk I/O — emit() returns in microseconds.
    """

    def __init__(self, q: queue.Queue, log_suffix: str = "") -> None:
        super().__init__()
        self.queue = q
        self.log_suffix = log_suffix
        # WHY: log_suffix routes entries to different files sharing one writer thread

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            extra = {
                k: v
                for k, v in record.__dict__.items()
                if k not in _RESERVED_LOG_KEYS and not k.startswith("_")
            }
            logfile_name = extra.get(
                "logfile_name", os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
            )
            log_path = _get_log_path(logfile_name, suffix=self.log_suffix)
            self.queue.put_nowait((str(log_path), msg))
        except queue.Full:
            print("Queue full, dropping log", file=sys.stderr)
        except Exception as e:
            # WHY: Exception (not bare except) — queuing failures should not crash
            #      the logging system; printing to stderr is the last-resort signal.
            print(f"Error queuing log: {e}", file=sys.stderr)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestQueueHandlerEmit:
        """WHY: QueueHandler.emit is the only path from a log call to the writer thread —
        a wrong tuple shape or silent raise causes silent data loss."""

        def test_emit(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import tempfile
            import io

            # ── puts (path, message) tuple onto queue ─────────────────────────────
            q = queue.Queue()
            handler = QueueHandler(q, log_suffix="")
            handler.setFormatter(UniformLevelFormatter())
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="mod.py",
                lineno=1,
                msg="hello",
                args=(),
                exc_info=None,
            )
            record.module_name = "testmod"
            record.source_file = "testmod"
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    handler.emit(record)
            assert not q.empty(), "Queue should not be empty after emit"
            path_str, msg_str = q.get_nowait()
            assert path_str.endswith(".jsonl"), (
                f"Expected .jsonl path, got {path_str!r}"
            )
            assert "hello" in msg_str, f"Expected 'hello' in message, got {msg_str!r}"

            # ── .errors suffix routes to {module}.errors.jsonl ───────────────────
            q = queue.Queue()
            handler = QueueHandler(q, log_suffix=".errors")
            handler.setFormatter(UniformLevelFormatter())
            record = logging.LogRecord(
                name="test",
                level=logging.ERROR,
                pathname="mod.py",
                lineno=1,
                msg="boom",
                args=(),
                exc_info=None,
            )
            record.module_name = "testmod"
            record.source_file = "testmod"
            with tempfile.TemporaryDirectory() as tmp:
                with patch("JSONL_LOGGER.PROJECT_DIRECTORY", tmp):
                    handler.emit(record)
            path_str, _ = q.get_nowait()
            assert ".errors.jsonl" in path_str, (
                f"Expected '.errors.jsonl' in path, got {path_str!r}"
            )

            # ── full queue prints to stderr, does not raise ───────────────────────
            q = queue.Queue(maxsize=1)
            q.put_nowait(("dummy", "dummy"))
            handler = QueueHandler(q, log_suffix="")
            handler.setFormatter(UniformLevelFormatter())
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="mod.py",
                lineno=1,
                msg="overflow",
                args=(),
                exc_info=None,
            )
            record.module_name = "testmod"
            record.source_file = "testmod"
            buf = io.StringIO()
            with patch("sys.stderr", buf):
                with patch(
                    "JSONL_LOGGER._get_log_path", return_value=Path("/tmp/test.jsonl")
                ):
                    handler.emit(record)
            assert "Queue full" in buf.getvalue(), (
                f"Expected 'Queue full' in stderr, got: {buf.getvalue()!r}"
            )


def _writer_worker(q: queue.Queue) -> None:
    """[TIER 2] Background thread: dequeue log entries and flush them to per-module files.

    WHY: Single writer thread per queue eliminates concurrent open() calls.
    """
    global _shutdown, _buffers

    while not _shutdown or not q.empty():
        try:
            log_path_str, msg = q.get(timeout=FLUSH_INTERVAL)

            paths_to_flush = []
            with _buffer_lock:
                if log_path_str not in _buffers:
                    _buffers[log_path_str] = []
                _buffers[log_path_str].append(msg)

                for path, buf in _buffers.items():
                    if len(buf) >= BUFFER_SIZE:
                        paths_to_flush.append(path)

            for path in paths_to_flush:
                _flush_buffer(path)

            q.task_done()

        except queue.Empty:
            with _buffer_lock:
                paths_to_flush = list(_buffers.keys())

            for path in paths_to_flush:
                _flush_buffer(path)
        except Exception as e:
            # WHY: Exception (not bare except) — writer errors should not crash
            #      the thread; debug print surfaces the issue for investigation.
            _debug_print(f"Writer error: {e}")
            try:
                q.task_done()
            except ValueError:
                pass

    # WHY: Final sweep on shutdown — ensures no entries remain after _shutdown=True
    with _buffer_lock:
        paths_to_flush = list(_buffers.keys())

    for path in paths_to_flush:
        _flush_buffer(path)


def _flush_buffer(log_file: str) -> None:
    """[TIER 2] Write buffered log lines for one file to disk via the retry helper.

    NOTE: This function acquires _buffer_lock internally. Do NOT call it while
    already holding the lock.
    """
    global _buffers

    with _buffer_lock:
        if log_file not in _buffers or not _buffers[log_file]:
            return

        to_write = _buffers[log_file][:]
        _buffers[log_file] = []

    def write_fn() -> None:
        with open(log_file, "a") as f:
            for line in to_write:
                f.write(line + "\n")

    failed = _with_file_retry(write_fn, log_file)

    if failed is not None:
        with _buffer_lock:
            combined = to_write + _buffers.get(log_file, [])
            if len(combined) > LOGGER_MAX_BUFFER_SIZE:
                dropped = len(combined) - LOGGER_MAX_BUFFER_SIZE
                combined = combined[-LOGGER_MAX_BUFFER_SIZE:]
                print(
                    f"[LOGGER WARN] Buffer for '{log_file}' exceeded "
                    f"{LOGGER_MAX_BUFFER_SIZE} entries — dropped {dropped} oldest.",
                    file=sys.stderr,
                )
            _buffers[log_file] = combined


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestFlushBuffer:
        """WHY: _flush_buffer is the bridge between in-memory buffers and disk —
        a double-write, silent drop, or missed buffer cap allows data loss or OOM."""

        def test_flush_buffer(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import JSONL_LOGGER as mod
            import io

            # ── no-op on empty buffer — no open() call made ───────────────────────
            original = mod._buffers.copy()
            mod._buffers["fake.jsonl"] = []
            try:
                with patch("builtins.open") as mock_open:
                    _flush_buffer("fake.jsonl")
                    mock_open.assert_not_called()
            finally:
                mod._buffers = original

            # ── buffer cleared after successful write ─────────────────────────────
            original = mod._buffers.copy()
            mod._buffers["fake.jsonl"] = ["line1", "line2"]
            try:
                with patch("builtins.open") as mock_open:
                    mock_open.return_value.__enter__ = lambda self: (
                        mock_open.return_value
                    )
                    mock_open.return_value.__exit__ = lambda self, *args: None
                    with patch("JSONL_LOGGER._with_file_retry", return_value=None):
                        _flush_buffer("fake.jsonl")
                assert mod._buffers.get("fake.jsonl", []) == [], (
                    "Buffer should be empty after successful flush"
                )
            finally:
                mod._buffers = original

            # ── lines re-buffered on retry exhaustion ─────────────────────────────
            original = mod._buffers.copy()
            mod._buffers["fake.jsonl"] = ["line1", "line2"]
            try:
                with patch("JSONL_LOGGER._with_file_retry", return_value=[]):
                    _flush_buffer("fake.jsonl")
                assert len(mod._buffers.get("fake.jsonl", [])) == 2, (
                    "Lines should be re-buffered on retry exhaustion"
                )
            finally:
                mod._buffers = original

            # ── oldest entries dropped when buffer exceeds cap ────────────────────
            original_buffers = mod._buffers.copy()
            original_cap = mod.LOGGER_MAX_BUFFER_SIZE
            mod.LOGGER_MAX_BUFFER_SIZE = 3
            try:
                buf = io.StringIO()
                with patch("sys.stderr", buf):
                    with patch("JSONL_LOGGER._with_file_retry", return_value=[]):
                        mod._buffers["fake.jsonl"] = ["a", "b", "c", "d"]
                        _flush_buffer("fake.jsonl")
                remaining = mod._buffers.get("fake.jsonl", [])
                assert len(remaining) <= mod.LOGGER_MAX_BUFFER_SIZE, (
                    f"Buffer should not exceed cap {mod.LOGGER_MAX_BUFFER_SIZE}, got {len(remaining)}"
                )
            finally:
                mod._buffers = original_buffers
                mod.LOGGER_MAX_BUFFER_SIZE = original_cap

            # ── stderr warning emitted when buffer cap exceeded ───────────────────
            original_buffers = mod._buffers.copy()
            original_cap = mod.LOGGER_MAX_BUFFER_SIZE
            mod.LOGGER_MAX_BUFFER_SIZE = 2
            mod._buffers["fake.jsonl"] = ["a", "b", "c", "d"]
            try:
                buf = io.StringIO()
                with patch("sys.stderr", buf):
                    with patch("JSONL_LOGGER._with_file_retry", return_value=[]):
                        _flush_buffer("fake.jsonl")
                assert (
                    "dropped" in buf.getvalue().lower()
                    or "exceeded" in buf.getvalue().lower()
                ), f"Expected buffer overflow warning, got: {buf.getvalue()!r}"
            finally:
                mod._buffers = original_buffers
                mod.LOGGER_MAX_BUFFER_SIZE = original_cap


# ── SECTION 8 · SHUTDOWN HANDLERS ────────────────────────────────────────────
# Goal: Ensure all pending log entries reach disk before process exit


def _flush_logs() -> None:
    """[TIER 2] Drain the log queue and join the writer thread before process exit.

    WHY: queue.join() blocks until every put() has a matching task_done().
    """
    if _log_queue is None:
        return

    global _shutdown
    _shutdown = True

    if _writer_thread and _writer_thread.is_alive():
        _writer_thread.join(timeout=5)

    try:
        while True:
            try:
                log_path, msg = _log_queue.get_nowait()
                with _buffer_lock:
                    if log_path not in _buffers:
                        _buffers[log_path] = []
                    _buffers[log_path].append(msg)
                _log_queue.task_done()
            except queue.Empty:
                break
    except Exception as e:
        # WHY: Exception (not bare except) — drain failures should not crash
        #      shutdown; best-effort flush is better than nothing.
        _debug_print(f"Error draining queue during shutdown: {e}")

    with _buffer_lock:
        paths = list(_buffers.keys())
    for path in paths:
        _flush_buffer(path)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestFlushLogs:
        """WHY: _flush_logs is the last-mile guarantee that buffered entries reach disk
        before process exit."""

        def test_flush_logs(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import JSONL_LOGGER as mod

            # ── sets _shutdown flag to True ───────────────────────────────────────
            original = mod._shutdown
            try:
                mod._shutdown = False
                with (
                    patch.object(mod._writer_thread, "is_alive", return_value=False),
                ):
                    _flush_logs()
                assert mod._shutdown is True, "_shutdown should be True after flush"
            finally:
                mod._shutdown = original

            # ── drains queue and flushes buffers when thread is alive ───────────────
            original_shutdown = mod._shutdown
            try:
                mod._shutdown = False
                with (
                    patch.object(mod._log_queue, "get_nowait") as mock_get,
                    patch.object(mod._log_queue, "task_done"),
                    patch.object(mod._writer_thread, "is_alive", return_value=True),
                    patch.object(mod._writer_thread, "join"),
                    patch("JSONL_LOGGER._flush_buffer"),
                ):
                    _flush_logs()
                mock_get.assert_called(), ("Queue should be drained during flush")
            finally:
                mod._shutdown = original_shutdown


def _chain_signal_handler(signum: int, frame: Any, previous_handler: Any) -> None:
    """[TIER 2] Flush logs then call the previously registered signal handler.

    WHY: Naive signal override breaks host apps (FastAPI, Gunicorn, Click).
    Chaining preserves the full shutdown chain.
    """
    _flush_logs()
    if callable(previous_handler):
        previous_handler(signum, frame)
    elif previous_handler == signal.default_int_handler:
        raise KeyboardInterrupt
    elif previous_handler not in (signal.SIG_IGN, signal.SIG_DFL):
        signal.signal(signum, previous_handler)
        os.kill(os.getpid(), signum)


# ── SECTION 9 · LOGGER INITIALIZATION ────────────────────────────────────────
# Goal: Construct and configure the logger and its handlers exactly once at import


def _init_logger() -> logging.Logger:
    """[TIER 2] Build the module logger with queue-based handlers for all output files.

    WHY: logger is a module singleton so all callers share the same queue.
    """
    global _log_queue, _writer_thread

    _logger = logging.getLogger(__name__)
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()

    _log_queue = queue.Queue(maxsize=100000)

    _writer_thread = threading.Thread(
        target=_writer_worker,
        args=(_log_queue,),
        daemon=LOGGER_DAEMON_THREAD,
        name="JSONL_LOGGER_writer",
    )
    _writer_thread.start()

    atexit.register(_flush_logs)

    if LOGGER_REGISTER_SIGNALS:
        for sig in (signal.SIGINT, signal.SIGTERM):
            previous = signal.getsignal(sig)
            signal.signal(
                sig,
                lambda signum, frame, prev=previous: _chain_signal_handler(
                    signum, frame, prev
                ),
            )

    if CONSOLE_LOGGING_ENABLED:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(ColoredFormatter())
        _logger.addHandler(console_handler)

    file_handler = QueueHandler(_log_queue, log_suffix="")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(UniformLevelFormatter())
    _logger.addHandler(file_handler)

    errors_handler = QueueHandler(_log_queue, log_suffix=".errors")
    errors_handler.setLevel(logging.ERROR)
    errors_handler.setFormatter(UniformLevelFormatter())
    _logger.addHandler(errors_handler)

    warn_handler = QueueHandler(_log_queue, log_suffix=".warn")
    warn_handler.setLevel(logging.WARNING)
    warn_handler.addFilter(lambda record: record.levelno == logging.WARNING)
    warn_handler.setFormatter(UniformLevelFormatter())
    _logger.addHandler(warn_handler)

    return _logger


# WHY: Initialized automatically at import.
# All callers share the same queue and writer thread.
logger = _init_logger()

_metrics_logger: logging.Logger = logging.getLogger(f"{__name__}.metrics")
_metrics_logger.setLevel(logging.DEBUG)
_metrics_logger.handlers.clear()
_metrics_logger.propagate = False

_metrics_file_handler = QueueHandler(_log_queue, log_suffix=".metrics")  # type: ignore[arg-type]
_metrics_file_handler.setLevel(logging.DEBUG)
_metrics_file_handler.setFormatter(UniformLevelFormatter())
_metrics_logger.addHandler(_metrics_file_handler)

_notifications_logger: logging.Logger = logging.getLogger(f"{__name__}.notifications")
_notifications_logger.setLevel(logging.DEBUG)
_notifications_logger.handlers.clear()
_notifications_logger.propagate = False

_notifications_file_handler = QueueHandler(_log_queue, log_suffix="")  # type: ignore[arg-type]
_notifications_file_handler.setLevel(logging.DEBUG)
_notifications_file_handler.setFormatter(UniformLevelFormatter())
_notifications_logger.addHandler(_notifications_file_handler)


# ── SECTION 10 · PUBLIC API ───────────────────────────────────────────────────
# Goal: Expose four clean logging functions for all application callers


def log_info(
    message: str,
    logfile_name: str | None = None,
    module_name: str | None = None,
    **extra_fields: Any,
) -> None:
    """[TIER 1] Record an informational event in the module's audit log.

    WHY: Primary audit trail for application events — covers the happy path.
    """
    if logfile_name is None:
        logfile_name = os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    if module_name is None:
        module_name = _get_caller_module()
    source_file = _get_actual_source_file()
    _warn_non_primitive_fields(extra_fields, module_name)
    assert logger is not None  # Initialized at import time
    logger.info(
        message,
        extra={
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": source_file,
            **extra_fields,
        },
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestLogInfo:
        """WHY: log_info is the highest-frequency call in the public API — a wrong level,
        dropped message, or missing dual-source entry silently corrupts every audit trail."""

        def test_log_info(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── explicit logfile_name → correct file routing ────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_info("test message", logfile_name="test_file.py")
                mock_handle.assert_called_once()
                record = mock_handle.call_args[0][0]
                assert record.levelno == logging.INFO, (
                    f"Expected INFO level, got {record.levelno}"
                )
                assert record.getMessage() == "test message", (
                    f"Expected 'test message', got {record.getMessage()!r}"
                )

            # ── no logfile_name/module_name → auto-detects non-empty values ─────────
            with patch.object(logger, "handle") as mock_handle:
                log_info("test message")
                record = mock_handle.call_args[0][0]
                assert record.module_name is not None, (
                    "module_name should be auto-detected"
                )
                assert len(record.module_name) > 0, "module_name should be non-empty"

            # ── empty message logs without error ──────────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_info("")
                mock_handle.assert_called_once()
                assert mock_handle.call_args[0][0].getMessage() == "", (
                    "Empty message should log without error"
                )

            # ── special characters and emoji preserved intact ─────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_info('Message with 🐍 emoji and "quotes"')
                msg = mock_handle.call_args[0][0].getMessage()
                assert "🐍" in msg, "Emoji should be preserved"
                assert "quotes" in msg, "Quotes should be preserved"

            # ── 10 000-char message not truncated ─────────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_info("x" * 10000)
                assert len(mock_handle.call_args[0][0].getMessage()) == 10000, (
                    "10k char message should not be truncated"
                )

            # ── dual-source: logfile_name, module_name and source_file all present ───
            with patch.object(logger, "handle") as mock_handle:
                log_info(
                    "test message", logfile_name="LOGS", module_name="grouped_name"
                )
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "logfile_name"), "Missing logfile_name attr"
                assert hasattr(record, "module_name"), "Missing module_name attr"
                assert hasattr(record, "source_file"), "Missing source_file attr"
                assert record.logfile_name == "LOGS", (
                    f"Expected 'LOGS', got {record.logfile_name!r}"
                )
                assert record.module_name == "grouped_name", (
                    f"Expected 'grouped_name', got {record.module_name!r}"
                )
                assert record.source_file is not None, "source_file should not be None"
                assert len(record.source_file) > 0, "source_file should be non-empty"


def log_warn(
    message: str,
    logfile_name: str | None = None,
    module_name: str | None = None,
    **extra_fields: Any,
) -> None:
    """[TIER 1] Record a recoverable anomaly or approaching-limit condition.

    WHY: Warning-level events signal conditions that don't fail the current operation
    but indicate the system is under stress.
    """
    if logfile_name is None:
        logfile_name = os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    if module_name is None:
        module_name = _get_caller_module()
    source_file = _get_actual_source_file()
    _warn_non_primitive_fields(extra_fields, module_name)
    assert logger is not None  # Initialized at import time
    logger.warning(
        message,
        extra={
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": source_file,
            **extra_fields,
        },
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestLogWarn:
        """WHY: log_warn signals approaching-limit conditions — a wrong level or dropped
        message causes silent monitoring gaps."""

        def test_log_warn(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── explicit logfile_name → WARNING level and correct message ───────────
            with patch.object(logger, "handle") as mock_handle:
                log_warn("warning message", logfile_name="test_file.py")
                mock_handle.assert_called_once()
                record = mock_handle.call_args[0][0]
                assert record.levelno == logging.WARNING, (
                    f"Expected WARNING level, got {record.levelno}"
                )
                assert record.getMessage() == "warning message", (
                    f"Expected 'warning message', got {record.getMessage()!r}"
                )

            # ── no logfile_name/module_name → auto-detects non-empty values ─────────
            with patch.object(logger, "handle") as mock_handle:
                log_warn("warning message")
                assert len(mock_handle.call_args[0][0].module_name) > 0, (
                    "module_name should be auto-detected and non-empty"
                )

            # ── empty message logs at WARNING without error ───────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_warn("")
                assert mock_handle.call_args[0][0].levelno == logging.WARNING, (
                    "Empty message should log at WARNING level"
                )

            # ── special characters and emoji preserved ────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_warn("Warning: ⚠️ system overloaded")
                assert "⚠️" in mock_handle.call_args[0][0].getMessage(), (
                    "Emoji should be preserved in warning"
                )

            # ── 10 000-char message not truncated ─────────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_warn("w" * 10000)
                assert len(mock_handle.call_args[0][0].getMessage()) == 10000, (
                    "10k char message should not be truncated"
                )

            # ── dual-source: logfile_name, module_name and source_file all present ───
            with patch.object(logger, "handle") as mock_handle:
                log_warn(
                    "warning message", logfile_name="LOGS", module_name="grouped_name"
                )
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "logfile_name"), "Missing logfile_name attr"
                assert hasattr(record, "module_name"), "Missing module_name attr"
                assert hasattr(record, "source_file"), "Missing source_file attr"
                assert record.logfile_name == "LOGS", (
                    f"Expected 'LOGS', got {record.logfile_name!r}"
                )
                assert record.module_name == "grouped_name", (
                    f"Expected 'grouped_name', got {record.module_name!r}"
                )
                assert record.source_file is not None, "source_file should not be None"
                assert len(record.source_file) > 0, "source_file should be non-empty"


def log_error(
    message: str,
    logfile_name: str | None = None,
    module_name: str | None = None,
    **extra_fields: Any,
) -> None:
    """[TIER 1] Record a failure requiring manual investigation.

    Dual-write: every call appends to BOTH:
      · {module}.jsonl        — full audit log alongside info/warn entries
      · {module}.errors.jsonl — errors only, for fast triage without grep

    WHY: Two files serve two workflows — errors.jsonl for on-call triage,
    main audit file for root-cause investigation.
    """
    if logfile_name is None:
        logfile_name = os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    if module_name is None:
        module_name = _get_caller_module()
    source_file = _get_actual_source_file()
    _warn_non_primitive_fields(extra_fields, module_name)
    assert logger is not None  # Initialized at import time
    logger.error(
        message,
        extra={
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": source_file,
            **extra_fields,
        },
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestLogError:
        """WHY: log_error dual-writes to both audit and errors files — a wrong level,
        missed dual-write, or info/warn leaking into errors.jsonl defeats fast-triage."""

        def test_log_error(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── explicit logfile_name → ERROR level and correct message ─────────────
            with patch.object(logger, "handle") as mock_handle:
                log_error("error message", logfile_name="test_file.py")
                mock_handle.assert_called_once()
                record = mock_handle.call_args[0][0]
                assert record.levelno == logging.ERROR, (
                    f"Expected ERROR level, got {record.levelno}"
                )
                assert record.getMessage() == "error message", (
                    f"Expected 'error message', got {record.getMessage()!r}"
                )

            # ── no logfile_name/module_name → auto-detects non-empty values ─────────
            with patch.object(logger, "handle") as mock_handle:
                log_error("error message")
                assert len(mock_handle.call_args[0][0].module_name) > 0, (
                    "module_name should be auto-detected and non-empty"
                )

            # ── empty message logs at ERROR without crash ─────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_error("")
                assert mock_handle.call_args[0][0].levelno == logging.ERROR, (
                    "Empty message should log at ERROR level"
                )

            # ── special characters and emoji preserved ────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_error("Error: ❌ failed with code 0xFF")
                assert "❌" in mock_handle.call_args[0][0].getMessage(), (
                    "Emoji should be preserved in error"
                )

            # ── 10 000-char message not truncated ─────────────────────────────────
            with patch.object(logger, "handle") as mock_handle:
                log_error("e" * 10000)
                assert len(mock_handle.call_args[0][0].getMessage()) == 10000, (
                    "10k char message should not be truncated"
                )

            # ── dual-write: both main (DEBUG) and errors-only (ERROR) handlers present
            assert logger is not None  # Initialized at import time
            assert len(logger.handlers) >= 2, (
                f"Expected at least 2 handlers, got {len(logger.handlers)}"
            )
            handler_levels = sorted(h.level for h in logger.handlers)
            assert logging.DEBUG in handler_levels, (
                "Missing main handler at DEBUG level"
            )
            assert logging.ERROR in handler_levels, (
                "Missing errors-only handler at ERROR level"
            )

            # ── info/warn do not reach errors-only handler ────────────────────────
            errors_handler = next(
                h for h in logger.handlers if h.level == logging.ERROR
            )
            with patch.object(errors_handler, "emit") as mock_emit:
                log_info("should not reach errors handler")
                log_warn("should not reach errors handler either")
                mock_emit.assert_not_called()

            # ── dual-source: logfile_name, module_name and source_file all present ───
            with patch.object(logger, "handle") as mock_handle:
                log_error(
                    "error message", logfile_name="LOGS", module_name="grouped_name"
                )
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "logfile_name"), "Missing logfile_name attr"
                assert hasattr(record, "module_name"), "Missing module_name attr"
                assert hasattr(record, "source_file"), "Missing source_file attr"
                assert record.logfile_name == "LOGS", (
                    f"Expected 'LOGS', got {record.logfile_name!r}"
                )
                assert record.module_name == "grouped_name", (
                    f"Expected 'grouped_name', got {record.module_name!r}"
                )
                assert record.source_file is not None, "source_file should not be None"
                assert len(record.source_file) > 0, "source_file should be non-empty"


def log_metric(
    metric_name: str,
    value: int | float,
    unit: str = "",
    logfile_name: str | None = None,
    module_name: str | None = None,
    **tags: Any,
) -> None:
    """[TIER 1] Emit a structured numeric metric to a separate .metrics.jsonl file.

    WHY: Metrics and audit logs have different retention and forwarding needs;
    a separate file lets monitoring tools ingest metrics independently.
    """
    if logfile_name is None:
        logfile_name = os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    if module_name is None:
        module_name = _get_caller_module()
    source_file = _get_actual_source_file()
    _warn_non_primitive_fields(tags, module_name)
    message = f"{metric_name}={value}{unit}"
    _metrics_logger.log(
        METRIC_LEVEL,
        message,
        extra={
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": source_file,
            "metric_name": metric_name,
            "value": value,
            "unit": unit,
            **tags,
        },
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestLogMetric:
        """WHY: log_metric emits to a separate .metrics.jsonl file at METR level — if it
        bleeds into audit log or drops structured fields, monitoring tools receive corrupt data."""

        def test_log_metric(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── float value → METR level and correct message ─────────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric(
                    "api_latency_ms", 142.5, unit="ms", module_name="test_module"
                )
                record = mock_handle.call_args[0][0]
                assert record.levelno == METRIC_LEVEL, (
                    f"Expected METRIC_LEVEL ({METRIC_LEVEL}), got {record.levelno}"
                )
                assert record.levelname == "METR", (
                    f"Expected 'METR' levelname, got {record.levelname!r}"
                )
                assert record.getMessage() == "api_latency_ms=142.5ms", (
                    f"Expected 'api_latency_ms=142.5ms', got {record.getMessage()!r}"
                )

            # ── integer value stored as int (no coercion to float) ────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("queue_depth", 83, module_name="test_module")
                assert mock_handle.call_args[0][0].value == 83, (
                    f"Expected int 83, got {mock_handle.call_args[0][0].value!r}"
                )

            # ── tags attached as queryable structured fields ───────────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric(
                    "cache_hits",
                    500,
                    module_name="test_module",
                    region="us-east-1",
                    env="prod",
                )
                record = mock_handle.call_args[0][0]
                assert record.region == "us-east-1", (
                    f"Expected region='us-east-1', got {record.region!r}"
                )
                assert record.env == "prod", f"Expected env='prod', got {record.env!r}"

            # ── no module_name → auto-detects non-empty caller name ─────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("error_rate", 0.02)
                assert len(mock_handle.call_args[0][0].module_name) > 0, (
                    "module_name should be auto-detected and non-empty"
                )

            # ── missing unit defaults to "" not None ──────────────────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("active_sessions", 1200, module_name="test_module")
                assert mock_handle.call_args[0][0].unit == "", (
                    f"Expected empty string for unit, got {mock_handle.call_args[0][0].unit!r}"
                )

            # ── zero value not filtered out ───────────────────────────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("failed_requests", 0, module_name="test_module")
                assert mock_handle.call_args[0][0].value == 0, (
                    "Zero value should not be filtered out"
                )

            # ── negative value accepted ───────────────────────────────────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("delta_users", -42, module_name="test_module")
                assert mock_handle.call_args[0][0].value == -42, (
                    f"Expected -42, got {mock_handle.call_args[0][0].value!r}"
                )

            # ── metric_name stored as structured field, not only in message ────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("db_query_time_ms", 55.3, module_name="test_module")
                assert mock_handle.call_args[0][0].metric_name == "db_query_time_ms", (
                    f"Expected 'db_query_time_ms', got {mock_handle.call_args[0][0].metric_name!r}"
                )

            # ── does not fire audit logger ────────────────────────────────────────
            with (
                patch.object(logger, "handle") as audit_mock,
                patch.object(_metrics_logger, "handle"),
            ):
                log_metric("some_metric", 1.0, module_name="test_module")
                audit_mock.assert_not_called(), ("Metric should not fire audit logger")

            # ── dual-source: module_name and source_file both present ───────────────
            with patch.object(_metrics_logger, "handle") as mock_handle:
                log_metric("test_metric", 42, module_name="grouped_name")
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "module_name"), "Missing module_name attr"
                assert hasattr(record, "source_file"), "Missing source_file attr"
                assert record.module_name == "grouped_name", (
                    f"Expected 'grouped_name', got {record.module_name!r}"
                )
                assert record.source_file is not None, "source_file should not be None"
                assert len(record.source_file) > 0, "source_file should be non-empty"


# ── SECTION 11 · NOTIFICATION API ────────────────────────────────────────────
# Goal: Write structured JSONL notifications to main_logger.jsonl


def send_notification(
    message: str,
    logfile_name: str | None = None,
    module_name: str | None = None,
    source_file: str | None = None,
) -> None:
    """[TIER 1] Synchronously emit a structured notification to main_logger.jsonl.

    WHY: Notifications are cross-module operational signals that belong in one
    shared JSONL file regardless of which module calls them.
    """
    if logfile_name is None:
        logfile_name = os.getenv("LOGGER_FILE_NAME", _DEFAULT_LOGFILE)
    if module_name is None:
        module_name = _get_caller_module()
    resolved_source_file = (
        source_file if source_file is not None else _get_actual_source_file()
    )

    _notifications_logger.info(
        message,
        extra={
            "logfile_name": logfile_name,
            "module_name": module_name,
            "source_file": resolved_source_file,
        },
    )


async def send_notification_async(
    message: str, logfile_name: str | None = None, module_name: str | None = None
) -> None:
    """[TIER 1] Asynchronously emit a structured notification to main_logger.jsonl.

    WHY: Async callers must not block the event loop. run_in_executor() offloads
    the call to a thread pool thread.
    """
    source_file = _get_actual_source_file()
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None, send_notification, message, logfile_name, module_name, source_file
    )


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestSendNotification:
        """WHY: send_notification is the cross-module operational signal path —
        routing to the wrong logger or losing source_file corrupts downstream tools."""

        def test_send_notification(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import asyncio
            import inspect as _inspect

            # ── fires _notifications_logger at INFO level ─────────────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("Deployment complete")
                mock_handle.assert_called_once()
                assert mock_handle.call_args[0][0].levelno == logging.INFO, (
                    f"Expected INFO level, got {mock_handle.call_args[0][0].levelno}"
                )

            # ── message text preserved on record ─────────────────────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("Deployment complete")
                assert (
                    mock_handle.call_args[0][0].getMessage() == "Deployment complete"
                ), "Message text should be preserved"

            # ── logfile_name/module_name present when not provided ─────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("any message")
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "logfile_name"), "Missing logfile_name attr"
                assert hasattr(record, "module_name"), "Missing module_name attr"
                assert record.module_name is not None, "module_name should not be None"
                assert len(record.module_name) > 0, "module_name should be non-empty"

            # ── source_file reflects the actual calling module ────────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("any message")
                record = mock_handle.call_args[0][0]
                assert hasattr(record, "source_file"), "Missing source_file attr"
                assert len(record.source_file) > 0, "source_file should be non-empty"
                assert not hasattr(record, "source"), (
                    "redundant 'source' field must be absent"
                )

            # ── empty message writes without error ────────────────────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("")
                mock_handle.assert_called_once()
                assert mock_handle.call_args[0][0].getMessage() == "", (
                    "Empty message should write without error"
                )

            # ── emoji and unicode preserved intact ───────────────────────────────
            with patch.object(_notifications_logger, "handle") as mock_handle:
                send_notification("🚀 Deploy: región=us-east-1")
                msg = mock_handle.call_args[0][0].getMessage()
                assert "🚀" in msg, "Emoji should be preserved"
                assert "región" in msg, "Unicode should be preserved"

            # ── does not fire audit logger ────────────────────────────────────────
            with (
                patch.object(logger, "handle") as audit_mock,
                patch.object(_notifications_logger, "handle"),
            ):
                send_notification("should not reach audit logger")
                (
                    audit_mock.assert_not_called(),
                    ("Notification should not fire audit logger"),
                )

            # ── async variant delegates to sync variant with captured source_file ──
            calls: list[tuple[str, str | None, str | None]] = []
            with patch(
                "JSONL_LOGGER.send_notification",
                side_effect=lambda m, logfile_name=None, module_name=None, source_file=None: (
                    calls.append((m, logfile_name, module_name))
                ),
            ):
                asyncio.run(send_notification_async("async alert"))
            assert len(calls) == 1, f"Expected 1 call, got {len(calls)}"
            assert calls[0][0] == "async alert", (
                f"Expected 'async alert', got {calls[0][0]!r}"
            )

            # ── async variant is a coroutine and completes without blocking ────────
            assert _inspect.iscoroutinefunction(send_notification_async), (
                "send_notification_async should be a coroutine function"
            )
            with patch("JSONL_LOGGER.send_notification"):
                asyncio.run(send_notification_async("non-blocking check"))


# ── SECTION 12 · PERFORMANCE TEST ─────────────────────────────────────────────
# Goal: Provide live performance benchmarks for all public API operations


def run_performance_test(
    single_thread_count: int = 5000,
    multi_thread_count: int = 10000,
    num_threads: int = 10,
    show_logs: bool = True,
) -> dict:
    """Run live performance benchmarks for JSONL_LOGGER on current hardware."""
    import threading
    import time
    from datetime import datetime
    import JSONL_LOGGER as mod

    original_console = mod.CONSOLE_LOGGING_ENABLED
    dropped_logs = 0

    try:
        if not show_logs:
            mod.CONSOLE_LOGGING_ENABLED = False
            assert logger is not None  # Initialized at import time
            for handler in logger.handlers[:]:
                if isinstance(handler, logging.StreamHandler) and not hasattr(
                    handler, "queue"
                ):
                    logger.removeHandler(handler)

        print("\n" + "=" * 70)
        print("JSONL_LOGGER Live Performance Test")
        print(f"Started: {datetime.now().isoformat()}")
        print("=" * 70)

        results = {}

        if mod._log_queue is None or mod._writer_thread is None:
            print("⚠️ Logger not initialized, re-initializing...")
            mod._init_logger()

        # ── Single-Thread Test ──────────────────────────────────────────────
        print(f"\n📊 Single-Thread Test ({single_thread_count:,} logs):")
        print("-" * 40)

        start = time.time()
        for i in range(single_thread_count):
            try:
                log_info(f"perf_test_single_{i}", test_type="single", index=i)
            except Exception as e:
                dropped_logs += 1
                print(f"⚠️ Log dropped in single-thread test: {e}")

        elapsed = time.time() - start
        _flush_logs()

        throughput = single_thread_count / elapsed
        results["single_thread"] = {
            "logs": single_thread_count,
            "time_seconds": round(elapsed, 2),
            "throughput": round(throughput, 0),
            "target": 10000,
            "dropped_logs": dropped_logs,
        }

        print(f"   Logs: {single_thread_count:,}")
        print(f"   Time: {elapsed:.2f} seconds")
        print(f"   Throughput: {throughput:.0f} logs/sec")
        print(f"   Dropped: {dropped_logs}")
        print("   Target: ≥8,000 logs/sec → ", end="")
        print("✅ PASS" if throughput >= 8000 else "⚠️ Below target")

        # ── Multi-Thread Test ───────────────────────────────────────────────
        total_logs = num_threads * multi_thread_count
        print(
            f"\n📊 Multi-Thread Test ({num_threads} threads × {multi_thread_count:,} logs = {total_logs:,} total):"
        )
        print("-" * 40)

        dropped_logs = 0
        thread_errors = []

        def worker(worker_id: int, count: int) -> None:
            nonlocal dropped_logs
            for i in range(count):
                try:
                    log_info(
                        f"perf_test_multi_{worker_id}_{i}",
                        test_type="multi",
                        worker_id=worker_id,
                        index=i,
                    )
                except Exception as e:
                    dropped_logs += 1
                    if len(thread_errors) < 10:
                        thread_errors.append(f"Thread {worker_id}: {e}")

        threads = []
        start = time.time()
        for i in range(num_threads):
            t = threading.Thread(target=worker, args=(i, multi_thread_count))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        elapsed_multi = time.time() - start
        _flush_logs()
        elapsed_multi = time.time() - start
        throughput_multi = total_logs / elapsed_multi

        results["multi_thread"] = {
            "threads": num_threads,
            "logs_per_thread": multi_thread_count,
            "total_logs": total_logs,
            "time_seconds": round(elapsed_multi, 2),
            "throughput": round(throughput_multi, 0),
            "target": 5000,
            "dropped_logs": dropped_logs,
            "thread_errors": thread_errors[:5],
        }

        print(f"   Total logs: {total_logs:,}")
        print(f"   Time: {elapsed_multi:.2f} seconds")
        print(f"   Throughput: {throughput_multi:.0f} logs/sec")
        print(f"   Dropped: {dropped_logs}")
        if thread_errors:
            print(f"   Thread errors: {len(thread_errors)} occurrences")
        print("   Target: ≥5,000 logs/sec → ", end="")
        print("✅ PASS" if throughput_multi >= 5000 else "⚠️ Below target")

        # ── Queue Health Check ──────────────────────────────────────────────
        if mod._log_queue:
            queue_size = mod._log_queue.qsize()
            max_size = getattr(mod._log_queue, "maxsize", 0)
            if queue_size > 0:
                print(
                    f"\n⚠️ Queue still has {queue_size} pending entries (max: {max_size})"
                )
                _flush_logs()

        # ── Summary ─────────────────────────────────────────────────────────
        print("\n" + "=" * 70)
        print("✅ Performance Test Complete")
        print("=" * 70)

        return results

    except Exception as e:
        print(f"\n❌ Performance test failed: {e}")
        import traceback

        traceback.print_exc()
        return {"error": str(e)}

    finally:
        mod.CONSOLE_LOGGING_ENABLED = original_console
        try:
            _flush_logs()
        except Exception:
            pass  # WHY: best-effort flush on error; should not mask original exception


# ═══════════════════════════════════════════════════════════════════════════════
# TEST COVERAGE MATRIX
# ═══════════════════════════════════════════════════════════════════════════════
#
# Tier 1 = Public API      → must be exhaustive; called by application code
# Tier 2 = Internal Logic  → correctness + resilience; helpers & infrastructure
# Tier 3 = Dev/Debug       → lower priority; dev-time utilities
#
# Legend: ✅ covered  ⚠️ partial  ❌ not covered
#
# ┌─────────────────────────────────────┬──────┬───────────┬────────┬────────────────────────────────────────────────────────────────────────┐
# │ Function / Component                │ Tier │ Test Class│ Tests  │ What is tested                                                         │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ log_info()                          │  1   │TestLogInfo│ 6  ✅  │ level, message, auto-detect, empty, special chars, 10k msg, dual-source│
# │ log_warn()                          │  1   │TestLogWarn│ 6  ✅  │ level, message, auto-detect, empty, special chars, 10k msg, dual-source│
# │ log_error()                         │  1   │TestLogErr │ 8  ✅  │ level, message, auto-detect, empty, special chars, 10k msg,            │
# │                                     │                  │        │ dual-write handlers, info/warn isolation, dual-source                  │
# │ log_metric()                        │  1   │TestLogMet │ 10 ✅  │ METR level, float/int value, tags, auto-detect, unit default,          │
# │                                     │                  │        │ zero value, negative value, metric_name field, audit isolation,        │
# │                                     │                  │        │ dual-source                                                            │
# │ send_notification()                 │  1   │TestSendNot│ 10 ✅  │ INFO level, message, module_name routing, source_file, empty msg,      │
# │                                     │                  │        │ special chars, audit isolation, source field absent                    │
# │ send_notification_async()           │  1   │TestSendNotAsync| 3  ✅ │ delegates to sync, coroutine contract, non-blocking                │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ _get_logfile_name()                 │  2   │TestGetLog │ 3  ✅  │ LOGGER_FILE_NAME priority, filename fallback, exception safety         │
# │ _get_actual_source_file()           │  2   │TestGetAct │ 2  ✅  │ bypasses LOGGER_FILE_NAME, exception safety                            │
# │ _get_log_path()                     │  2   │TestGetLogP│ 9  ✅  │ suffix routing, ValueError on missing dirs, path construction          │
# │ _with_file_retry()                  │  2   │TestWithRet│ 5  ✅  │ success on attempt 1, success on attempt 3, exhaustion sentinel,       │
# │                                     │                  │        │ non-IOError retried, exponential backoff                               │
# │ _flush_buffer()                     │  2   │TestFlushBuf│ 5 ✅  │ re-buffer on retry exhaustion, buffer cap drop, retry logic            │
# │ QueueHandler.emit()                 │  2   │TestQHEmit │ 3  ✅  │ queue.put_nowait called with (path, formatted_msg)                     │
# │ _flush_logs()                       │  2   │TestFlushLog│ 2 ✅  │ mock _writer_thread.join and assert _shutdown=True                     │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ _get_timestamp()                    │  3   │TestGetTime│ 4  ✅  │ ISO-8601 format with Z suffix and ms precision                         │
# │ _debug_print()                      │  3   │TestDbgPrnt│ 2  ✅  │ stderr print guard, DEBUG_PRINT=False in prod                          │
# │ _warn_non_primitive_fields()        │  3   │TestWarnNP │ 5  ✅  │ stderr output for list/dict/datetime values                            │
# │ ColoredFormatter.format()           │  3   │TestColorFM│ 9  ✅  │ emoji present, ANSI codes in output, console formatting                │
# │ UniformLevelFormatter.format()      │  3   │TestUnifFM │ 10 ✅  │ exact JSONL keys, compact separators, JSONL shape                      │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ TOTALS                              │                  │        │                                                                        │
# │   Tier 1 — Public API               │    8 functions   │ 57 ✅  │ All public functions fully covered                                     │
# │   Tier 2 — Internal Logic           │   10 functions   │ 29 ✅  │ 7 helpers unit-tested; 3 covered via integration or import-time verify │
# │   Tier 3 — Dev/Debug                │    5 components  │ 30 ✅  │ All low-risk components now covered                                    │
# └─────────────────────────────────────┴──────┴───────────┴────────┴────────────────────────────────────────────────────────────────────────┘

# ═══════════════════════════════════════════════════════════════════════════════
# USAGE GUIDE
# ═══════════════════════════════════════════════════════════════════════════════
#
# Quick Start:
#   from JSONL_LOGGER import log_info, log_warn, log_error, log_metric
#   from JSONL_LOGGER import send_notification, send_notification_async
#
#   log_info("User logged in", user_id=123)
#   log_warn("Rate limit approaching", remaining=10)
#   log_error("Payment failed", error_code=500)
#   log_metric("api_latency_ms", 142.5, unit="ms", endpoint="/checkout")
#   send_notification("Deployment complete — v2.3.1 live")
#   await send_notification_async("Async worker finished batch")
#
# Environment Variables (.env):
#   PROJECT_DIRECTORY=/path/to/logs              # Required: NO space before =
#   LOGS_LOCAL_TIMEZONE=Asia/Kolkata             # Required: local timezone
#   LOGGER_FILE_NAME=LOGS                        # Optional: log file name (default: LOGS)
#   CONSOLE_LOGGING_ENABLED=false                # Optional: console output (default: false)
#   LOGGER_REGISTER_SIGNALS=false                # Optional: signal handlers (default: false)
#   LOGGER_DAEMON_THREAD=true                    # Optional: daemon thread (default: true)
#   LOGGER_MAX_BUFFER_SIZE=200000                 # Optional: per-file buffer cap (default: 200000)
#
# Output Location:
#   {PROJECT_DIRECTORY}/_LOGS_DIRECTORY/{YYYY_MM_DD}/LOGS/{logfile_name}.jsonl          ← all logs
#   {PROJECT_DIRECTORY}/_LOGS_DIRECTORY/{YYYY_MM_DD}/LOGS/{logfile_name}.errors.jsonl   ← errors only
#   {PROJECT_DIRECTORY}/_LOGS_DIRECTORY/{YYYY_MM_DD}/LOGS/{logfile_name}.metrics.jsonl  ← metrics
#
# ─────────────────────────────────────────────────────────────────────────────
# GROUP MULTIPLE FILES UNDER ONE LOG FILE:
#
#   # trading_symbols.py
#   LOGGER_FILE_NAME = "TRADING"
#   from JSONL_LOGGER import log_info
#   log_info("Order placed", symbol="AAPL")
#
#   # historical_data.py
#   LOGGER_FILE_NAME = "TRADING"
#   from JSONL_LOGGER import log_info
#   log_info("Data fetched", records=1000)
#
#   Both write to: {PROJECT_DIRECTORY}/_LOGS_DIRECTORY/{date}/LOGS/TRADING.jsonl
# ─────────────────────────────────────────────────────────────────────────────
# HIGH-THROUGHPUT CALLERS — bypass inspect overhead (~1-5µs saved per call):
#
#   log_info("msg", logfile_name="MY_LOG", module_name="MY_MODULE")
# ─────────────────────────────────────────────────────────────────────────────
#
# Run Tests:
#   python3 -m pytest JSONL_LOGGER.py -v
#
# Run Performance Test:
#   python3 JSONL_LOGGER.py
#
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import asyncio
    import tempfile

    # Set a default for testing if not already set
    if not os.getenv("PROJECT_DIRECTORY"):
        os.environ["PROJECT_DIRECTORY"] = tempfile.mkdtemp()
        print(f"⚠️  Using temp directory for demo: {os.environ['PROJECT_DIRECTORY']}")
        print("   For production, set PROJECT_DIRECTORY in .env file\n")

    print("=" * 60)
    print("Testing JSONL_LOGGER...")
    print("=" * 60)

    # Regular logs
    print("\n📝 Basic Logging:")
    log_info("Info message")
    log_warn("Warning message")
    log_error("Error message")
    log_info("With extra fields", user_id=123, action="login", response_time_ms=150)

    # Metrics
    print("\n📊 Metric Logging:")
    log_metric("api_latency_ms", 142.5, unit="ms", endpoint="/checkout", method="POST")
    log_metric("queue_depth", 83, service="payment_worker")
    log_metric("cache_hit_rate", 0.94, unit="%", region="us-east-1")

    # Notifications
    print("\n🔔 Notifications:")
    send_notification("Deployment complete — v2.3.1 live")
    asyncio.run(send_notification_async("Async worker finished batch — v2.3.1"))

    # Run full performance test
    print("\n" + "=" * 60)
    print("Running FULL Performance Test Suite")
    print("=" * 60)
    run_performance_test(
        single_thread_count=10000,
        multi_thread_count=10000,
        num_threads=4,
        show_logs=False,
    )

    _flush_logs()

    print("\n" + "=" * 60)
    print(
        f"✅ Done — check {os.environ['PROJECT_DIRECTORY']}/_LOGS_DIRECTORY/ for JSONL files"
    )
    print("=" * 60)
