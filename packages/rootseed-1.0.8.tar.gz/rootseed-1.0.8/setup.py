#!/usr/bin/env python3
# ============================================================================
# Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
# setup.py — Uses system-installed headers and libraries
# Copyright (c) 2026 Fardin Sabid
# ============================================================================

import os
import sys
import platform
import subprocess
from pathlib import Path
from setuptools import setup, find_packages, Extension

VERSION = "1.0.8"

def cuda_available():
    try:
        result = subprocess.run(["nvcc", "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            return True
    except FileNotFoundError:
        pass
    if platform.system() == "Linux" and Path("/usr/local/cuda/bin/nvcc").exists():
        return True
    return False

def get_sources():
    sources = [
        "src/core/dtype.cpp", "src/core/shape.cpp", "src/core/memory.cpp", "src/core/tensor.cpp",
        "src/autograd/tape.cpp", "src/autograd/functions.cpp",
        "src/akd/cache.cpp", "src/akd/dispatcher.cpp", "src/akd/fusion.cpp",
        "src/akd/kernels_cpu.cpp", "src/akd/sparsity.cpp",
        "src/dre/context.cpp", "src/dre/detect.cpp", "src/dre/loader.cpp",
        "src/hal/device.cpp", "src/hal/reference/ref_device.cpp", "src/hal/xnnpack/xnnpack_device.cpp",
        "src/nn/module.cpp", "src/nn/parameter.cpp", "src/nn/linear.cpp", "src/nn/activation.cpp",
        "src/nn/dropout.cpp", "src/nn/conv.cpp", "src/nn/attention.cpp",
        "src/nn/transformer.cpp", "src/nn/norm.cpp",
        "src/nn/moe/router.cpp", "src/nn/moe/dispatch.cpp", "src/nn/moe/expert.cpp",
        "src/nn/moe/combine.cpp", "src/nn/moe/moe_layer.cpp",
        "src/optim/optimizer.cpp", "src/optim/sgd.cpp", "src/optim/adam.cpp",
        "src/optim/adamw.cpp", "src/optim/lion.cpp", "src/optim/scheduler.cpp",
        "src/data/dataset.cpp", "src/data/loader.cpp", "src/data/sampler.cpp", "src/data/transforms.cpp",
        "src/serial/rs_format.cpp", "src/serial/rs_reader.cpp", "src/serial/rs_writer.cpp",
        "src/distributed/process_group.cpp", "src/distributed/collective_ops.cpp",
        "src/distributed/ddp.cpp", "src/distributed/expert_parallel.cpp",
        "src/utils/log.cpp", "src/utils/exception.cpp", "src/utils/profile.cpp",
        "src/ui/ui.cpp",
        "rootseed/_bindings.cpp",
    ]
    if cuda_available():
        sources.extend([
            "src/hal/cuda/cuda_device.cpp", "src/hal/cuda/cuda_allocator.cpp", "src/hal/cuda/nccl_group.cpp",
            "src/hal/rocm/rocm_device.cpp", "src/hal/rocm/rccl_group.cpp",
            "src/hal/vulkan/vulkan_device.cpp", "src/hal/vulkan/vulkan_shaders.cpp",
            "src/hal/tpu/tpu_device.cpp", "src/hal/npu/npu_device.cpp", "src/hal/metal/metal_ane.cpp",
        ])
    return sources

def get_include_dirs():
    import pybind11
    return [
        "src", "src/core", "src/autograd", "src/akd", "src/dre",
        "src/hal", "src/hal/reference", "src/hal/xnnpack",
        "src/hal/cuda", "src/hal/rocm", "src/hal/vulkan", "src/hal/metal", "src/hal/tpu", "src/hal/npu",
        "src/nn", "src/nn/moe", "src/optim", "src/data", "src/serial",
        "src/distributed", "src/utils", "src/ui",
        pybind11.get_include(),
        "/usr/include",
    ]

def get_libraries():
    return ["spdlog", "flatbuffers", "cpuinfo", "fmt"]

setup(
    name="rootseed",
    version=VERSION,
    author="Fardin Sabid",
    author_email="contract.fardinsabid@gmail.com",
    description="A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design",
    license="MIT",
    url="https://github.com/fardinsabid/root-seed",
    packages=find_packages(where=".", include=["rootseed", "rootseed.*"]),
    zip_safe=False,
    python_requires=">=3.8",
    install_requires=["numpy>=1.21.0", "aleam>=1.0.3", "pybind11>=2.10.0"],
    ext_modules=[
        Extension(
            "rootseed._rootseed",
            sources=get_sources(),
            include_dirs=get_include_dirs(),
            libraries=get_libraries(),
            extra_compile_args=["-std=c++20", "-O3", "-fPIC"] + (["-pthread"] if platform.system() == "Linux" else []),
            language="c++",
        )
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research", "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3", "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9", "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11", "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security :: Cryptography",
    ],
)