import os

import typer
from rich import print
from rich.table import Table
from rich.console import Console

from . import __version__
from .config import TmuxrConfigError, find_config, load_config
from .session import SessionManager

app = typer.Typer(invoke_without_command=True)
console = Console()


def version_callback(value: bool):
    if value:
        print(f"tmuxr {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit.",
    ),
):
    """tmuxr — declarative tmux session manager."""
    if ctx.invoked_subcommand is None:
        console.print()
        console.print("[bold cyan]tmuxr[/bold cyan] — Declarative tmux session manager", highlight=False)
        console.print(f"[dim]v{__version__}[/dim]")
        console.print()
        console.print("Define your terminal layout in [bold]tmuxfile.yml[/bold] and let tmuxr handle the rest.")
        console.print("Config lives in your repo — version controlled and team-shareable.")
        console.print()

        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("Command", style="green")
        table.add_column("Description")
        table.add_row("up", "Start all windows defined in config and attach to the session")
        table.add_row("down", "Kill the session and stop all watchers")
        table.add_row("status", "Show running tmuxr-managed sessions")
        console.print(table)

        console.print()
        console.print("[dim]Quick start:[/dim]")
        console.print("  1. Create a [bold]tmuxfile.yml[/bold] in your project root")
        console.print("  2. Run [green]tmuxr up[/green]")
        console.print()
        console.print("[dim]Run[/dim] [green]tmuxr <command> --help[/green] [dim]for more info on a command.[/dim]")


def get_manager(file: str | None) -> SessionManager:
    config_path = find_config(file or "tmuxfile.yml")
    if not config_path:
        print("[red]No tmuxfile.yml found in this directory or parents.[/red]")
        raise typer.Exit(1)
    try:
        config = load_config(config_path)
    except TmuxrConfigError as e:
        print(f"[red]Config error:[/red] {e}")
        raise typer.Exit(1)
    return SessionManager(config, config_path=config_path)


@app.command()
def up(
    file: str = typer.Option(None, "--file", "-f", help="Path to config file."),
    detach: bool = typer.Option(False, "--detach", "-d", help="Start session without attaching."),
):
    """Start all windows defined in config."""
    get_manager(file).up(detach=detach)


@app.command()
def down(file: str = typer.Option(None, "--file", "-f", help="Path to config file.")):
    """Kill the session."""
    get_manager(file).down()


@app.command()
def status():
    """Show running tmuxr-managed sessions."""
    import libtmux

    server = libtmux.Server()
    try:
        sessions = server.sessions
    except Exception:
        print("[dim]No tmux server running.[/dim]")
        return

    table = Table(title="tmuxr sessions")
    table.add_column("Session", style="green")
    table.add_column("Windows", justify="right")
    table.add_column("Config", style="dim")

    found = False
    for s in sessions:
        env = s.show_environment()
        if env.get("TMUXR_MANAGED") != "1":
            continue
        found = True
        raw_path = env.get("TMUXR_CONFIG", "—")
        try:
            display_path = os.path.relpath(raw_path)
        except ValueError:
            display_path = raw_path
        window_count = str(len(s.windows))
        table.add_row(s.name, window_count, display_path)

    if found:
        console.print(table)
    else:
        print("[dim]No tmuxr sessions running.[/dim]")


if __name__ == "__main__":
    app()
