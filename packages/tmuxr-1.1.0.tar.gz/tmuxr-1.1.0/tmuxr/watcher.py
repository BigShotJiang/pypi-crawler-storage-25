import subprocess
import threading

from .utils import is_shell


class WindowWatcher(threading.Thread):
    def __init__(self, session, window_cfg, setup_fn):
        super().__init__(daemon=True)
        self.session = session
        self.window_cfg = window_cfg
        self.setup_fn = setup_fn
        self.poll_interval = 3
        self._stop_event = threading.Event()

    def run(self):
        while not self._stop_event.is_set():
            self._stop_event.wait(self.poll_interval)
            if self._stop_event.is_set():
                break
            if not self._session_alive():
                break
            if not self._process_alive():
                # TODO v1.1: distinguish on-failure (non-zero exit) from always.
                # For v1, both modes restart whenever the process exits.
                print(f"[watcher] '{self.window_cfg.name}' exited. Restarting...")
                self._restart()

    def stop(self):
        self._stop_event.set()

    def _session_alive(self) -> bool:
        try:
            return self.session.windows.get(window_name=self.window_cfg.name, default=None) is not None
        except Exception:
            return False

    def _process_alive(self) -> bool:
        window = self.session.windows.get(window_name=self.window_cfg.name, default=None)
        if not window:
            return False

        pane = window.active_pane
        if pane is None:
            return False

        result = pane.display_message("#{pane_current_command}", get_text=True)
        if not result:
            return False

        current_cmd = result[0] if isinstance(result, list) else str(result)
        return not is_shell(current_cmd)

    def _restart(self):
        window = self.session.windows.get(window_name=self.window_cfg.name, default=None)
        if window:
            pane = window.active_pane
            if pane:
                self.setup_fn(pane, self.window_cfg)


class WindowWaiter(threading.Thread):
    """Polls a shell command until it succeeds, then sets up the window."""

    def __init__(self, session, window_cfg, setup_fn, done_callback):
        super().__init__(daemon=True)
        self.session = session
        self.window_cfg = window_cfg
        self.setup_fn = setup_fn
        self.done_callback = done_callback
        self._stop_event = threading.Event()

    def run(self):
        cfg = self.window_cfg
        elapsed = 0
        success = False

        while not self._stop_event.is_set() and elapsed < cfg.wait_timeout:
            try:
                result = subprocess.run(
                    cfg.wait_for,
                    shell=True,
                    cwd=cfg.dir,
                    capture_output=True,
                    timeout=min(cfg.wait_interval, 10),
                )
                if result.returncode == 0:
                    success = True
                    break
            except subprocess.TimeoutExpired:
                pass
            except Exception:
                pass

            self._stop_event.wait(cfg.wait_interval)
            elapsed += cfg.wait_interval

        if not self._stop_event.is_set():
            self._launch(success)

    def _launch(self, success: bool):
        cfg = self.window_cfg
        window = self.session.windows.get(window_name=cfg.name, default=None)
        if window:
            pane = window.active_pane
            if pane:
                if success:
                    pane.send_keys("echo '[tmuxr] Condition met. Starting...'")
                else:
                    pane.send_keys(
                        f"echo '[tmuxr] Timed out after {cfg.wait_timeout}s. Starting anyway...'"
                    )
                self.setup_fn(pane, cfg)

        self.done_callback(cfg, success)

    def stop(self):
        self._stop_event.set()
