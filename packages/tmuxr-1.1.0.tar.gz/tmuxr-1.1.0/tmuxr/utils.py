import shlex
from pathlib import Path

KNOWN_SHELLS = {"bash", "zsh", "sh", "fish", "dash", "ksh"}


def resolve_path(base_dir: Path, rel_path: str) -> Path:
    """Resolve a path relative to a base directory, returning absolute."""
    return (base_dir / rel_path).resolve()


def source_env_cmd(env_file_path: str | Path) -> str:
    """Return a shell command that sources an env file with proper quoting."""
    return f"set -a && source {shlex.quote(str(env_file_path))} && set +a"


def is_shell(command_name: str) -> bool:
    """Check if a command name is a known shell."""
    return command_name.strip() in KNOWN_SHELLS
