import shlex
import subprocess
import threading
from pathlib import Path

import libtmux

from .config import TmuxrConfig, WindowConfig
from .utils import source_env_cmd
from .watcher import WindowWatcher, WindowWaiter


class SessionManager:
    def __init__(self, config: TmuxrConfig, config_path: Path | None = None):
        self.config = config
        self.config_path = config_path
        self.server = libtmux.Server()
        self._watchers: list[WindowWatcher] = []
        self._waiters: list[WindowWaiter] = []
        self._lock = threading.Lock()

    def _find_session(self):
        return self.server.sessions.get(session_name=self.config.session, default=None)

    def session_exists(self) -> bool:
        return self._find_session() is not None

    def up(self, detach: bool = False):
        if self.session_exists():
            print(f"Session '{self.config.session}' already running. Attaching...")
            if not detach:
                self._attach()
            return

        session = self.server.new_session(session_name=self.config.session)

        # Tag as tmuxr-managed
        session.set_environment("TMUXR_MANAGED", "1")
        if self.config_path:
            session.set_environment("TMUXR_CONFIG", str(self.config_path))

        for i, window_cfg in enumerate(self.config.windows):
            if i == 0:
                window = session.active_window
                window.rename_window(window_cfg.name)
            else:
                window = session.new_window(window_name=window_cfg.name)

            pane = window.active_pane

            if window_cfg.wait_for:
                pane.send_keys(f"echo '[tmuxr] Waiting for: {window_cfg.wait_for} ...'")
                waiter = WindowWaiter(
                    session, window_cfg, self._setup_window, self._on_waiter_done
                )
                waiter.start()
                self._waiters.append(waiter)
            else:
                self._setup_window(pane, window_cfg)

        # Start watchers only for non-waiting windows with restart policy
        for window_cfg in self.config.windows:
            if window_cfg.restart != "never" and window_cfg.wait_for is None:
                watcher = WindowWatcher(session, window_cfg, self._setup_window)
                watcher.start()
                self._watchers.append(watcher)

        if not detach:
            self._attach()

    def _on_waiter_done(self, window_cfg: WindowConfig, success: bool):
        """Called by WindowWaiter when wait_for resolves or times out."""
        if not success:
            print(f"[tmuxr] Window '{window_cfg.name}' timed out waiting. Starting anyway.")
        if window_cfg.restart != "never":
            session = self._find_session()
            if session:
                watcher = WindowWatcher(session, window_cfg, self._setup_window)
                watcher.start()
                with self._lock:
                    self._watchers.append(watcher)

    def down(self):
        # Stop waiters first
        for waiter in self._waiters:
            waiter.stop()
        self._waiters.clear()

        # Stop watchers
        with self._lock:
            for watcher in self._watchers:
                watcher.stop()
            self._watchers.clear()

        # Run per-window down commands before killing session
        for window_cfg in self.config.windows:
            if window_cfg.down_cmd:
                print(f"[tmuxr] Running down_cmd for '{window_cfg.name}'...")
                subprocess.run(window_cfg.down_cmd, shell=True, cwd=window_cfg.dir)

        session = self._find_session()
        if session:
            session.kill()
            print(f"Session '{self.config.session}' stopped.")
        else:
            print("No running session found.")

    def _setup_window(self, pane, cfg: WindowConfig):
        pane.send_keys(f"cd {shlex.quote(cfg.dir)}")

        # Global env_file first, then window-level override
        if self.config.env_file:
            pane.send_keys(source_env_cmd(self.config.env_file))
        if cfg.env_file:
            pane.send_keys(source_env_cmd(cfg.env_file))

        if cfg.pre_cmd:
            pane.send_keys(cfg.pre_cmd)
        pane.send_keys(cfg.cmd)

    def _attach(self):
        subprocess.run(["tmux", "attach", "-t", self.config.session], check=False)
