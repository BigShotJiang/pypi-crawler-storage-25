import os
from pathlib import Path

import pytest

from tmuxr.config import (
    TmuxrConfig,
    TmuxrConfigError,
    WindowConfig,
    find_config,
    load_config,
)


class TestFindConfig:
    def test_find_config_in_current_dir(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("session: test\nwindows: []")
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = find_config()
            assert result == config_file
        finally:
            os.chdir(old_cwd)

    def test_find_config_walks_up(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("session: test\nwindows: []")
        child = tmp_path / "sub" / "deep"
        child.mkdir(parents=True)
        old_cwd = os.getcwd()
        try:
            os.chdir(child)
            result = find_config()
            assert result == config_file
        finally:
            os.chdir(old_cwd)

    def test_find_config_not_found(self, tmp_path):
        child = tmp_path / "empty"
        child.mkdir()
        old_cwd = os.getcwd()
        try:
            os.chdir(child)
            # Walk up won't find it (unless there's one in a real parent — use unique name)
            result = find_config("tmuxfile-nonexistent-test.yml")
            assert result is None
        finally:
            os.chdir(old_cwd)


class TestLoadConfig:
    def test_load_config_valid(self, tmp_config):
        config = load_config(tmp_config)
        assert config.session == "test-app"
        assert len(config.windows) == 2
        assert config.windows[0].name == "backend"
        assert config.windows[0].cmd == "npm run dev"
        assert config.windows[0].restart == "on-failure"
        assert config.windows[1].name == "frontend"
        assert config.windows[1].restart == "never"

    def test_load_config_minimal(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: minimal\n"
            "windows:\n"
            "  - name: shell\n"
            "    cmd: bash\n"
        )
        config = load_config(config_file)
        assert config.session == "minimal"
        assert len(config.windows) == 1
        w = config.windows[0]
        assert w.name == "shell"
        assert w.cmd == "bash"
        assert w.restart == "never"
        assert w.env_file is None
        assert w.pre_cmd is None

    def test_load_config_missing_session(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("windows:\n  - name: x\n    cmd: y\n")
        with pytest.raises(TmuxrConfigError, match="session"):
            load_config(config_file)

    def test_load_config_missing_windows(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("session: test\n")
        with pytest.raises(TmuxrConfigError, match="windows"):
            load_config(config_file)

    def test_load_config_empty_windows(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("session: test\nwindows: []\n")
        with pytest.raises(TmuxrConfigError, match="non-empty"):
            load_config(config_file)

    def test_load_config_bad_restart_value(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
            "    restart: invalid\n"
        )
        with pytest.raises(TmuxrConfigError, match="invalid restart"):
            load_config(config_file)

    def test_load_config_invalid_yaml(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("session: [unbalanced\n")
        with pytest.raises(TmuxrConfigError, match="YAML"):
            load_config(config_file)

    def test_load_config_empty_file(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text("")
        with pytest.raises(TmuxrConfigError, match="mapping"):
            load_config(config_file)

    def test_load_config_resolves_relative_dirs(self, tmp_config):
        config = load_config(tmp_config)
        config_dir = tmp_config.parent
        assert config.windows[0].dir == str((config_dir / "backend").resolve())
        assert config.windows[1].dir == str((config_dir / "frontend").resolve())

    def test_load_config_resolves_env_files(self, tmp_config):
        config = load_config(tmp_config)
        config_dir = tmp_config.parent
        assert config.windows[0].env_file == str((config_dir / "backend" / ".env").resolve())
        assert config.windows[1].env_file is None

    def test_load_config_resolves_global_env_file(self, tmp_path):
        (tmp_path / ".env").write_text("X=1\n")
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "env_file: .env\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
        )
        config = load_config(config_file)
        assert config.env_file == str((tmp_path / ".env").resolve())

    def test_load_config_window_missing_name(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - cmd: echo hi\n"
        )
        with pytest.raises(TmuxrConfigError, match="name"):
            load_config(config_file)

    def test_load_config_window_missing_cmd(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
        )
        with pytest.raises(TmuxrConfigError, match="cmd"):
            load_config(config_file)

    def test_load_config_stores_config_dir(self, tmp_config):
        config = load_config(tmp_config)
        assert config.config_dir == tmp_config.parent.resolve()

    def test_load_config_with_wait_for(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: api\n"
            "    cmd: docker attach api\n"
            "    wait_for: \"docker inspect api\"\n"
            "    wait_timeout: 120\n"
            "    wait_interval: 5\n"
        )
        config = load_config(config_file)
        w = config.windows[0]
        assert w.wait_for == "docker inspect api"
        assert w.wait_timeout == 120
        assert w.wait_interval == 5

    def test_load_config_wait_for_defaults(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: api\n"
            "    cmd: echo hi\n"
            "    wait_for: \"test -f /tmp/ready\"\n"
        )
        config = load_config(config_file)
        w = config.windows[0]
        assert w.wait_for == "test -f /tmp/ready"
        assert w.wait_timeout == 60
        assert w.wait_interval == 2

    def test_load_config_wait_for_empty_string(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
            "    wait_for: \"\"\n"
        )
        with pytest.raises(TmuxrConfigError, match="wait_for"):
            load_config(config_file)

    def test_load_config_wait_timeout_negative(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
            "    wait_for: \"true\"\n"
            "    wait_timeout: -5\n"
        )
        with pytest.raises(TmuxrConfigError, match="wait_timeout"):
            load_config(config_file)

    def test_load_config_with_down_cmd(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: app\n"
            "    cmd: docker compose up -d\n"
            "    down_cmd: docker compose down\n"
        )
        config = load_config(config_file)
        assert config.windows[0].down_cmd == "docker compose down"

    def test_load_config_down_cmd_default_none(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: app\n"
            "    cmd: echo hi\n"
        )
        config = load_config(config_file)
        assert config.windows[0].down_cmd is None

    def test_load_config_down_cmd_empty_string(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
            "    down_cmd: \"\"\n"
        )
        with pytest.raises(TmuxrConfigError, match="down_cmd"):
            load_config(config_file)

    def test_load_config_wait_interval_zero(self, tmp_path):
        config_file = tmp_path / "tmuxfile.yml"
        config_file.write_text(
            "session: test\n"
            "windows:\n"
            "  - name: x\n"
            "    cmd: y\n"
            "    wait_for: \"true\"\n"
            "    wait_interval: 0\n"
        )
        with pytest.raises(TmuxrConfigError, match="wait_interval"):
            load_config(config_file)
