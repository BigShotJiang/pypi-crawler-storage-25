import os
from unittest.mock import patch, MagicMock

import pytest
from typer.testing import CliRunner

from tmuxr.cli import app

runner = CliRunner()


class TestCLI:
    def test_version_flag(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "tmuxr" in result.output

    def test_up_no_config_exits_1(self, tmp_path):
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(app, ["up"])
            assert result.exit_code == 1
            assert "No tmuxfile.yml" in result.output
        finally:
            os.chdir(old_cwd)

    @patch("tmuxr.cli.SessionManager")
    @patch("tmuxr.cli.load_config")
    @patch("tmuxr.cli.find_config")
    def test_up_calls_manager(self, mock_find, mock_load, MockManager):
        mock_find.return_value = "/tmp/tmuxfile.yml"
        mock_config = MagicMock()
        mock_load.return_value = mock_config
        mock_mgr = MockManager.return_value

        result = runner.invoke(app, ["up", "--detach"])
        assert result.exit_code == 0
        mock_mgr.up.assert_called_once_with(detach=True)

    @patch("tmuxr.cli.SessionManager")
    @patch("tmuxr.cli.load_config")
    @patch("tmuxr.cli.find_config")
    def test_down_calls_manager(self, mock_find, mock_load, MockManager):
        mock_find.return_value = "/tmp/tmuxfile.yml"
        mock_config = MagicMock()
        mock_load.return_value = mock_config
        mock_mgr = MockManager.return_value

        result = runner.invoke(app, ["down"])
        assert result.exit_code == 0
        mock_mgr.down.assert_called_once()

    @patch("libtmux.Server")
    def test_status_empty(self, MockServer):
        server = MockServer.return_value
        mock_session = MagicMock()
        mock_session.show_environment.return_value = {}
        server.sessions = [mock_session]

        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "No tmuxr sessions" in result.output
