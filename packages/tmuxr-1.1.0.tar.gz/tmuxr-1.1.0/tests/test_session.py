from pathlib import Path
from unittest.mock import MagicMock, patch, call, ANY
import threading

import pytest

from tmuxr.config import TmuxrConfig, WindowConfig
from tmuxr.session import SessionManager


@pytest.fixture
def sample_config(tmp_path):
    return TmuxrConfig(
        session="test-app",
        windows=[
            WindowConfig(name="backend", cmd="npm run dev", dir=str(tmp_path / "backend"), restart="on-failure"),
            WindowConfig(name="frontend", cmd="npm start", dir=str(tmp_path / "frontend")),
        ],
        config_dir=tmp_path,
    )


@pytest.fixture
def sample_config_with_env(tmp_path):
    return TmuxrConfig(
        session="test-app",
        windows=[
            WindowConfig(
                name="backend",
                cmd="npm run dev",
                dir=str(tmp_path / "backend"),
                env_file=str(tmp_path / "backend" / ".env"),
            ),
        ],
        env_file=str(tmp_path / ".env"),
        config_dir=tmp_path,
    )


class TestSessionManager:
    @patch("tmuxr.session.libtmux.Server")
    def test_up_creates_session(self, MockServer, sample_config, mock_pane):
        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(sample_config, config_path=Path("/tmp/tmuxfile.yml"))
        with patch.object(mgr, "_attach"):
            mgr.up()

        server.new_session.assert_called_once_with(session_name="test-app")
        mock_window.rename_window.assert_called_once_with("backend")
        mock_session.new_window.assert_called_once_with(window_name="frontend")

    @patch("tmuxr.session.libtmux.Server")
    def test_up_existing_session_attaches(self, MockServer, sample_config):
        server = MockServer.return_value
        server.sessions.get.return_value = MagicMock()

        mgr = SessionManager(sample_config)
        with patch.object(mgr, "_attach") as mock_attach:
            mgr.up()

        server.new_session.assert_not_called()
        mock_attach.assert_called_once()

    @patch("tmuxr.session.libtmux.Server")
    def test_down_kills_session(self, MockServer, sample_config):
        server = MockServer.return_value
        mock_session = MagicMock()
        server.sessions.get.return_value = mock_session

        mgr = SessionManager(sample_config)
        mgr.down()

        mock_session.kill.assert_called_once()

    @patch("tmuxr.session.libtmux.Server")
    def test_down_no_session(self, MockServer, sample_config, capsys):
        server = MockServer.return_value
        server.sessions.get.return_value = None

        mgr = SessionManager(sample_config)
        mgr.down()

        output = capsys.readouterr().out
        assert "No running session" in output

    @patch("tmuxr.session.libtmux.Server")
    def test_setup_window_sends_commands_in_order(self, MockServer, sample_config, mock_pane):
        mgr = SessionManager(sample_config)
        cfg = WindowConfig(
            name="test",
            cmd="npm run dev",
            dir="/app/backend",
            pre_cmd="source venv/bin/activate",
        )

        mgr._setup_window(mock_pane, cfg)

        calls = mock_pane.send_keys.call_args_list
        # Order: cd, pre_cmd, cmd
        assert "cd" in calls[0].args[0]
        assert "/app/backend" in calls[0].args[0]
        assert calls[1].args[0] == "source venv/bin/activate"
        assert calls[2].args[0] == "npm run dev"

    @patch("tmuxr.session.libtmux.Server")
    def test_setup_window_global_env_file(self, MockServer, sample_config_with_env, mock_pane):
        mgr = SessionManager(sample_config_with_env)
        cfg = sample_config_with_env.windows[0]

        mgr._setup_window(mock_pane, cfg)

        calls = mock_pane.send_keys.call_args_list
        # Order: cd, global env, window env, cmd
        assert "cd" in calls[0].args[0]
        assert "source" in calls[1].args[0] and ".env" in calls[1].args[0]
        assert "source" in calls[2].args[0] and "backend" in calls[2].args[0]
        assert calls[3].args[0] == "npm run dev"

    @patch("tmuxr.session.libtmux.Server")
    def test_up_starts_watchers_for_restart_windows(self, MockServer, sample_config, mock_pane):
        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(sample_config)
        with patch.object(mgr, "_attach"):
            mgr.up()

        # Only backend has restart=on-failure, frontend has restart=never
        assert len(mgr._watchers) == 1

        # Clean up
        for w in mgr._watchers:
            w.stop()

    @patch("tmuxr.session.libtmux.Server")
    def test_tmuxr_managed_env_set(self, MockServer, sample_config, mock_pane):
        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(sample_config, config_path=Path("/tmp/tmuxfile.yml"))
        with patch.object(mgr, "_attach"):
            mgr.up()

        mock_session.set_environment.assert_any_call("TMUXR_MANAGED", "1")
        mock_session.set_environment.assert_any_call("TMUXR_CONFIG", "/tmp/tmuxfile.yml")

        for w in mgr._watchers:
            w.stop()

    @patch("tmuxr.session.libtmux.Server")
    def test_up_detach_skips_attach(self, MockServer, sample_config, mock_pane):
        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(sample_config)
        with patch.object(mgr, "_attach") as mock_attach:
            mgr.up(detach=True)

        mock_attach.assert_not_called()

        # Clean up watchers
        for w in mgr._watchers:
            w.stop()

    @patch("tmuxr.session.subprocess.run")
    @patch("tmuxr.session.libtmux.Server")
    def test_down_runs_down_cmd_before_kill(self, MockServer, mock_subprocess_run, tmp_path):
        config = TmuxrConfig(
            session="test-app",
            windows=[
                WindowConfig(name="app", cmd="docker compose up -d", dir=str(tmp_path), down_cmd="docker compose down"),
                WindowConfig(name="shell", cmd="bash", dir=str(tmp_path)),
            ],
            config_dir=tmp_path,
        )

        server = MockServer.return_value
        mock_session = MagicMock()
        server.sessions.get.return_value = mock_session

        mgr = SessionManager(config)
        mgr.down()

        # down_cmd should be called for the window that has it
        mock_subprocess_run.assert_called_once_with("docker compose down", shell=True, cwd=str(tmp_path))
        # Session should still be killed after
        mock_session.kill.assert_called_once()

    @patch("tmuxr.session.subprocess.run")
    @patch("tmuxr.session.libtmux.Server")
    def test_down_without_down_cmd_still_works(self, MockServer, mock_subprocess_run, sample_config):
        server = MockServer.return_value
        mock_session = MagicMock()
        server.sessions.get.return_value = mock_session

        mgr = SessionManager(sample_config)
        mgr.down()

        # No down_cmd configured, subprocess.run should not be called
        mock_subprocess_run.assert_not_called()
        mock_session.kill.assert_called_once()

    @patch("tmuxr.session.libtmux.Server")
    def test_up_defers_setup_for_wait_for_windows(self, MockServer, mock_pane):
        config = TmuxrConfig(
            session="test-wait",
            windows=[
                WindowConfig(name="docker", cmd="docker compose up -d"),
                WindowConfig(
                    name="api", cmd="docker attach api",
                    wait_for="docker inspect api", wait_timeout=10, wait_interval=0.1,
                ),
            ],
            config_dir=Path("/tmp"),
        )

        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(config)
        with patch.object(mgr, "_attach"):
            mgr.up()

        # First window (docker) should have _setup_window called directly (cd + cmd)
        # Second window (api) should show waiting message, NOT run _setup_window
        send_calls = mock_pane.send_keys.call_args_list
        # The wait_for window should have an echo with "Waiting for"
        waiting_calls = [c for c in send_calls if "Waiting for" in str(c)]
        assert len(waiting_calls) == 1

        # A waiter should have been started
        assert len(mgr._waiters) == 1

        # Clean up
        for w in mgr._waiters:
            w.stop()
        for w in mgr._watchers:
            w.stop()

    @patch("tmuxr.session.libtmux.Server")
    def test_watchers_not_started_for_waiting_windows(self, MockServer, mock_pane):
        config = TmuxrConfig(
            session="test-wait",
            windows=[
                WindowConfig(name="docker", cmd="docker compose up -d", restart="on-failure"),
                WindowConfig(
                    name="api", cmd="docker attach api", restart="on-failure",
                    wait_for="docker inspect api", wait_timeout=10, wait_interval=0.1,
                ),
            ],
            config_dir=Path("/tmp"),
        )

        server = MockServer.return_value
        server.sessions.get.return_value = None
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.active_window = mock_window
        mock_session.new_window.return_value = mock_window
        server.new_session.return_value = mock_session

        mgr = SessionManager(config)
        with patch.object(mgr, "_attach"):
            mgr.up()

        # Only docker (no wait_for) should have a watcher started immediately
        assert len(mgr._watchers) == 1

        # Clean up
        for w in mgr._waiters:
            w.stop()
        for w in mgr._watchers:
            w.stop()
