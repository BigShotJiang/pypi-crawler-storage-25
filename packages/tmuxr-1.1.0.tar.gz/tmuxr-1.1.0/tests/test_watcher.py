import threading
from unittest.mock import MagicMock, patch

import pytest

from tmuxr.config import WindowConfig
from tmuxr.watcher import WindowWatcher, WindowWaiter


@pytest.fixture
def window_cfg():
    return WindowConfig(name="backend", cmd="npm run dev", restart="on-failure")


@pytest.fixture
def setup_fn():
    return MagicMock()


class TestWindowWatcher:
    def test_watcher_restarts_dead_process(self, window_cfg, setup_fn):
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_pane = MagicMock()
        mock_window.active_pane = mock_pane
        # Return "bash" means process died (fell back to shell)
        mock_pane.display_message.return_value = ["bash"]
        mock_session.windows.get.return_value = mock_window

        watcher = WindowWatcher(mock_session, window_cfg, setup_fn)
        watcher.poll_interval = 0.1

        watcher.start()
        threading.Event().wait(0.3)
        watcher.stop()
        watcher.join(timeout=1)

        setup_fn.assert_called()

    def test_watcher_leaves_running_process(self, window_cfg, setup_fn):
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_pane = MagicMock()
        mock_window.active_pane = mock_pane
        # Return "node" means process is still running
        mock_pane.display_message.return_value = ["node"]
        mock_session.windows.get.return_value = mock_window

        watcher = WindowWatcher(mock_session, window_cfg, setup_fn)
        watcher.poll_interval = 0.1

        watcher.start()
        threading.Event().wait(0.3)
        watcher.stop()
        watcher.join(timeout=1)

        setup_fn.assert_not_called()

    def test_watcher_stops_on_event(self, window_cfg, setup_fn):
        mock_session = MagicMock()
        mock_session.windows.get.return_value = MagicMock()

        watcher = WindowWatcher(mock_session, window_cfg, setup_fn)
        watcher.poll_interval = 10  # long interval

        watcher.start()
        watcher.stop()
        watcher.join(timeout=2)

        assert not watcher.is_alive()

    def test_watcher_handles_missing_window(self, window_cfg, setup_fn):
        mock_session = MagicMock()
        # Window no longer exists
        mock_session.windows.get.return_value = None

        watcher = WindowWatcher(mock_session, window_cfg, setup_fn)
        watcher.poll_interval = 0.1

        watcher.start()
        threading.Event().wait(0.3)
        watcher.stop()
        watcher.join(timeout=1)

        # Should not crash, and should not call setup_fn
        setup_fn.assert_not_called()


class TestWindowWaiter:
    def test_waiter_calls_setup_on_success(self):
        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_pane = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.windows.get.return_value = mock_window

        cfg = WindowConfig(
            name="api", cmd="docker attach api",
            wait_for="true", wait_timeout=10, wait_interval=0.1,
        )
        setup_fn = MagicMock()
        done_cb = MagicMock()

        waiter = WindowWaiter(mock_session, cfg, setup_fn, done_cb)
        waiter.start()
        waiter.join(timeout=3)

        setup_fn.assert_called_once_with(mock_pane, cfg)
        done_cb.assert_called_once_with(cfg, True)

    @patch("tmuxr.watcher.subprocess.run")
    def test_waiter_polls_until_success(self, mock_run):
        # Fail twice, succeed on third
        mock_run.side_effect = [
            MagicMock(returncode=1),
            MagicMock(returncode=1),
            MagicMock(returncode=0),
        ]

        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_pane = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.windows.get.return_value = mock_window

        cfg = WindowConfig(
            name="api", cmd="echo hi",
            wait_for="check_cmd", wait_timeout=10, wait_interval=0.1,
        )
        setup_fn = MagicMock()
        done_cb = MagicMock()

        waiter = WindowWaiter(mock_session, cfg, setup_fn, done_cb)
        waiter.start()
        waiter.join(timeout=5)

        setup_fn.assert_called_once_with(mock_pane, cfg)
        done_cb.assert_called_once_with(cfg, True)
        assert mock_run.call_count == 3

    @patch("tmuxr.watcher.subprocess.run")
    def test_waiter_times_out_and_starts_anyway(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)

        mock_session = MagicMock()
        mock_window = MagicMock()
        mock_pane = MagicMock()
        mock_window.active_pane = mock_pane
        mock_session.windows.get.return_value = mock_window

        cfg = WindowConfig(
            name="api", cmd="echo hi",
            wait_for="false", wait_timeout=1, wait_interval=0.2,
        )
        setup_fn = MagicMock()
        done_cb = MagicMock()

        waiter = WindowWaiter(mock_session, cfg, setup_fn, done_cb)
        waiter.start()
        waiter.join(timeout=5)

        setup_fn.assert_called_once_with(mock_pane, cfg)
        done_cb.assert_called_once_with(cfg, False)

    def test_waiter_stops_on_event(self):
        cfg = WindowConfig(
            name="api", cmd="echo hi",
            wait_for="sleep 100", wait_timeout=60, wait_interval=0.1,
        )
        setup_fn = MagicMock()
        done_cb = MagicMock()

        mock_session = MagicMock()
        waiter = WindowWaiter(mock_session, cfg, setup_fn, done_cb)
        waiter.start()
        waiter.stop()
        waiter.join(timeout=2)

        assert not waiter.is_alive()
        setup_fn.assert_not_called()
        done_cb.assert_not_called()
