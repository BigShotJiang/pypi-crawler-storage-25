"""Private.Me xLink for LangChain - Python Bindings

Identity-based M2M authentication for LangChain agents.
"""

import subprocess
import json
import asyncio
from typing import Dict, Any, Optional
from pathlib import Path

__version__ = "0.1.3"
__all__ = ['connect', 'XLinkConnection']


class XLinkConnection:
    """xLink connection for LangChain agents.

    This class wraps the Node.js @private.me/langchain-xlink package,
    providing a Python interface for identity-based M2M authentication.
    """

    def __init__(self, connection_id: str, node_module_path: str):
        """Initialize xLink connection.

        Args:
            connection_id: Connection identifier
            node_module_path: Path to Node.js module
        """
        self.connection_id = connection_id
        self.node_module_path = node_module_path

    async def send(
        self,
        to: str,
        payload: Dict[str, Any],
        timeout: int = 10000
    ) -> Dict[str, Any]:
        """Send message to agent.

        Args:
            to: Target agent DID
            payload: Message payload
            timeout: Timeout in milliseconds (default: 10000)

        Returns:
            Response from target agent

        Raises:
            RuntimeError: If Node.js backend fails
            TimeoutError: If request times out
        """
        # Construct Node.js command to call the backend
        node_script = f"""
        const {{ connect }} = require('{self.node_module_path}');

        (async () => {{
            try {{
                const conn = await connect('{self.connection_id}');
                if (!conn.ok) {{
                    console.error(JSON.stringify({{ error: conn.error.message }}));
                    process.exit(1);
                }}

                const result = await conn.value.send({{
                    to: '{to}',
                    payload: {json.dumps(payload)}
                }});

                if (!result.ok) {{
                    console.error(JSON.stringify({{ error: result.error.message }}));
                    process.exit(1);
                }}

                console.log(JSON.stringify(result.value));
            }} catch (err) {{
                console.error(JSON.stringify({{ error: err.message }}));
                process.exit(1);
            }}
        }})();
        """

        try:
            result = subprocess.run(
                ['node', '-e', node_script],
                capture_output=True,
                text=True,
                timeout=timeout / 1000
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip()
                try:
                    error_obj = json.loads(error_msg)
                    raise RuntimeError(f"Node.js backend error: {error_obj.get('error', error_msg)}")
                except json.JSONDecodeError:
                    raise RuntimeError(f"Node.js backend error: {error_msg}")

            return json.loads(result.stdout)

        except subprocess.TimeoutExpired:
            raise TimeoutError(f"Request timed out after {timeout}ms")


async def connect(connection_id: str) -> XLinkConnection:
    """Connect to xLink agent.

    Args:
        connection_id: Connection identifier

    Returns:
        XLinkConnection instance

    Raises:
        RuntimeError: If Node.js module not found
    """
    node_module_path = _find_node_module()
    return XLinkConnection(connection_id, node_module_path)


def _find_node_module() -> str:
    """Find @private.me/langchain-xlink Node.js module.

    Returns:
        Absolute path to Node.js module

    Raises:
        RuntimeError: If module not found
    """
    possible_paths = [
        Path('./node_modules/@private.me/langchain-xlink'),
        Path('../node_modules/@private.me/langchain-xlink'),
        Path('../../node_modules/@private.me/langchain-xlink'),
        Path('../../../node_modules/@private.me/langchain-xlink'),
    ]

    for path in possible_paths:
        if path.exists():
            return str(path.resolve())

    raise RuntimeError(
        "Node.js module @private.me/langchain-xlink not found. "
        "Please install it first: npm install @private.me/langchain-xlink"
    )
