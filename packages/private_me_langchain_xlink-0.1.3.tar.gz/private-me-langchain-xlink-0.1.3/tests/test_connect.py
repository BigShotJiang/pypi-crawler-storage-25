"""Test connect function."""

import pytest
from unittest.mock import patch, MagicMock
from private_me.langchain_xlink import connect, XLinkConnection, _find_node_module


@pytest.mark.asyncio
async def test_connect_returns_connection():
    """Test connect returns XLinkConnection."""
    with patch('private_me.langchain_xlink._find_node_module') as mock:
        mock.return_value = '/path/to/module'
        conn = await connect('test-connection')
        assert conn is not None
        assert isinstance(conn, XLinkConnection)
        assert conn.connection_id == 'test-connection'


@pytest.mark.asyncio
async def test_connect_finds_node_module():
    """Test connect locates Node.js module."""
    with patch('private_me.langchain_xlink._find_node_module') as mock:
        mock.return_value = '/path/to/module'
        await connect('test')
        mock.assert_called_once()


def test_connection_stores_id():
    """Test connection stores ID."""
    conn = XLinkConnection('my-id', '/path')
    assert conn.connection_id == 'my-id'


def test_connection_stores_module_path():
    """Test connection stores module path."""
    conn = XLinkConnection('id', '/my/path')
    assert conn.node_module_path == '/my/path'


def test_find_module_raises_when_not_found():
    """Test find module raises error when not found."""
    with patch('pathlib.Path.exists', return_value=False):
        with pytest.raises(RuntimeError, match="Node.js module.*not found"):
            _find_node_module()
