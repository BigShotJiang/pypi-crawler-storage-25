"""Test package imports."""

import pytest


def test_import_package():
    """Test package imports correctly."""
    from private_me import langchain_xlink
    assert langchain_xlink is not None


def test_import_connect():
    """Test connect function imports."""
    from private_me.langchain_xlink import connect
    assert connect is not None


def test_import_connection():
    """Test XLinkConnection class imports."""
    from private_me.langchain_xlink import XLinkConnection
    assert XLinkConnection is not None


def test_version():
    """Test version is set."""
    from private_me import langchain_xlink
    assert hasattr(langchain_xlink, '__version__')
    assert langchain_xlink.__version__ == "0.2.1"
