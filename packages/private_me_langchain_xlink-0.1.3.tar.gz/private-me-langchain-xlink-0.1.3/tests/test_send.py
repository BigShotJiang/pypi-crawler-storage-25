"""Test send method."""

import pytest
import subprocess
from unittest.mock import patch, MagicMock
from private_me.langchain_xlink import XLinkConnection


@pytest.mark.asyncio
async def test_send_calls_node_backend():
    """Test send calls Node.js backend."""
    conn = XLinkConnection('test-conn', '/path/to/module')
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = '{"success": true}'

    with patch('subprocess.run', return_value=mock_result) as mock_run:
        result = await conn.send('agent-123', {'action': 'test'})
        assert result == {"success": True}
        mock_run.assert_called_once()


@pytest.mark.asyncio
async def test_send_handles_timeout():
    """Test send handles timeout."""
    conn = XLinkConnection('test-conn', '/path/to/module')

    with patch('subprocess.run', side_effect=subprocess.TimeoutExpired('node', 10)):
        with pytest.raises(TimeoutError, match="timed out"):
            await conn.send('agent-123', {'action': 'test'})


@pytest.mark.asyncio
async def test_send_handles_error():
    """Test send handles Node.js errors."""
    conn = XLinkConnection('test-conn', '/path/to/module')
    mock_result = MagicMock()
    mock_result.returncode = 1
    mock_result.stderr = '{"error": "Node.js error"}'

    with patch('subprocess.run', return_value=mock_result):
        with pytest.raises(RuntimeError, match="Node.js backend error"):
            await conn.send('agent-123', {'action': 'test'})


@pytest.mark.asyncio
async def test_send_json_parsing():
    """Test send parses JSON response."""
    conn = XLinkConnection('test', '/path')
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = '{"data": [1,2,3]}'

    with patch('subprocess.run', return_value=mock_result):
        result = await conn.send('agent', {})
        assert result == {"data": [1, 2, 3]}


@pytest.mark.asyncio
async def test_send_serializes_payload():
    """Test send serializes complex payloads."""
    conn = XLinkConnection('test', '/path')
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = '{"result": "ok"}'

    with patch('subprocess.run', return_value=mock_result) as mock_run:
        await conn.send('agent', {'nested': {'data': [1, 2, 3]}})
        # Verify subprocess was called
        mock_run.assert_called_once()


@pytest.mark.asyncio
async def test_send_custom_timeout():
    """Test send accepts custom timeout."""
    conn = XLinkConnection('test', '/path')
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = '{}'

    with patch('subprocess.run', return_value=mock_result) as mock_run:
        await conn.send('agent', {}, timeout=5000)
        # Verify timeout was passed correctly (5000ms = 5s)
        call_kwargs = mock_run.call_args[1]
        assert call_kwargs['timeout'] == 5.0
