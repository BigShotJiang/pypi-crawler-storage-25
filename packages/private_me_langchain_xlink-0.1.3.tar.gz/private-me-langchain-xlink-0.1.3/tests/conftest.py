"""Pytest configuration and fixtures."""

import pytest


@pytest.fixture
def mock_node_module_path():
    """Mock Node.js module path."""
    return '/mock/path/to/node_modules/@private.me/langchain-xlink'


@pytest.fixture
def mock_connection_id():
    """Mock connection ID."""
    return 'test-connection-123'
