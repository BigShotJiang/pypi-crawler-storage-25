from setuptools import setup, find_packages

setup(
    name="private-me-langchain-xlink",
    version="0.1.3",
    description="Identity-based M2M authentication for LangChain agents (Python bindings)",
    author="Private.Me",
    author_email="contact@private.me",
    url="https://private.me/docs/langchain",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.9",
    package_data={"private_me": ["py.typed"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
