# Private.Me xLink for LangChain (Python)

**Identity-based M2M authentication for LangChain agents.**

Python bindings for `@private.me/langchain-xlink`. Build LangChain agents that communicate securely using Ed25519 DID identity instead of API keys.

## Installation

### Prerequisites

This package requires both the Node.js module and Python bindings:

```bash
# 1. Install Node.js package
npm install @private.me/langchain-xlink

# 2. Install Python bindings
pip install private-me-langchain-xlink
```

**Requirements:**
- Python 3.9+
- Node.js 18+ (for backend)
- npm (for Node.js package installation)

## Quick Start

```python
from private_me import langchain_xlink

# Connect to xLink agent
connection = await langchain_xlink.connect('my-connection')

# Send message
result = await connection.send(
    to='agent-123',
    payload={'action': 'process', 'data': [1, 2, 3]}
)

print(result)  # Response from agent
```

## API Reference

### `connect(connection_id: str) -> XLinkConnection`

Connect to xLink agent.

**Parameters:**
- `connection_id` (str): Connection identifier

**Returns:**
- `XLinkConnection`: Connection instance

**Raises:**
- `RuntimeError`: If Node.js module not found

**Example:**
```python
conn = await langchain_xlink.connect('research-agent')
```

### `XLinkConnection.send(to: str, payload: Dict[str, Any], timeout: int = 10000) -> Dict[str, Any]`

Send message to agent.

**Parameters:**
- `to` (str): Target agent DID
- `payload` (Dict[str, Any]): Message payload
- `timeout` (int): Timeout in milliseconds (default: 10000)

**Returns:**
- `Dict[str, Any]`: Response from target agent

**Raises:**
- `RuntimeError`: If Node.js backend fails
- `TimeoutError`: If request times out

**Example:**
```python
result = await connection.send(
    to='did:key:z6Mk...',
    payload={'action': 'analyze', 'text': 'Sample document'},
    timeout=5000  # 5 seconds
)
```

## LangChain Integration

### Basic Agent

```python
from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain.tools import Tool
from private_me import langchain_xlink

# Connect to xLink
xlink_conn = await langchain_xlink.connect('research-agent')

# Create tool that uses xLink
def query_secure_database(query: str) -> str:
    result = await xlink_conn.send(
        to='database-agent',
        payload={'query': query}
    )
    return result.get('data', '')

secure_db_tool = Tool(
    name="SecureDatabase",
    func=query_secure_database,
    description="Query secure database using xLink authentication"
)

# Use in LangChain agent
tools = [secure_db_tool]
agent = create_react_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools)
```

### Multi-Agent Collaboration

```python
from private_me import langchain_xlink

# Connect multiple agents
research_agent = await langchain_xlink.connect('research-agent')
analysis_agent = await langchain_xlink.connect('analysis-agent')
summarizer = await langchain_xlink.connect('summarizer-agent')

# Orchestrate workflow
async def research_pipeline(topic: str):
    # Step 1: Research
    research = await research_agent.send(
        to='web-scraper',
        payload={'topic': topic, 'max_results': 10}
    )

    # Step 2: Analyze
    analysis = await analysis_agent.send(
        to='data-analyzer',
        payload={'data': research['results']}
    )

    # Step 3: Summarize
    summary = await summarizer.send(
        to='text-summarizer',
        payload={'text': analysis['insights']}
    )

    return summary['summary']

result = await research_pipeline('AI agent security')
```

## Architecture

This package uses a **wrapper pattern**:

```
Python App → Python Bindings → Node.js Backend → xLink Protocol
```

1. **Python layer**: Provides Pythonic API (`connect()`, `send()`)
2. **Node.js backend**: Handles cryptographic operations (Ed25519, AES-256-GCM)
3. **xLink protocol**: Identity-based M2M authentication

## Troubleshooting

### "Node.js module not found"

**Error:**
```
RuntimeError: Node.js module @private.me/langchain-xlink not found
```

**Solution:**
```bash
# Install Node.js package first
npm install @private.me/langchain-xlink

# Verify installation
ls node_modules/@private.me/langchain-xlink
```

### "Node.js backend error"

**Error:**
```
RuntimeError: Node.js backend error: <message>
```

**Solution:**
- Check Node.js version (requires 18+): `node --version`
- Verify Node.js package installed: `npm list @private.me/langchain-xlink`
- Check connection ID is valid
- Review Node.js error message for details

### Timeout errors

**Error:**
```
TimeoutError: Request timed out after 10000ms
```

**Solution:**
```python
# Increase timeout for long-running operations
result = await connection.send(
    to='agent',
    payload=data,
    timeout=30000  # 30 seconds
)
```

## Development

### Running Tests

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest -v

# Run with coverage
pytest -v --cov=private_me --cov-report=html
```

### Building

```bash
# Build wheel
python setup.py bdist_wheel

# Validate build
bash validate-build.sh
```

## Support

- **Documentation**: https://private.me/docs/langchain
- **White Paper**: https://private.me/docs/langchain.html
- **Email**: contact@private.me
- **GitHub**: https://github.com/xail-io/xail

## License

Proprietary - See LICENSE.md

---

**Questions?** Visit [private.me/docs/langchain](https://private.me/docs/langchain) for complete documentation.
