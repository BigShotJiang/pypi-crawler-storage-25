"""Reliable agent system: UserAgent + AssistantAgent with verification loop.

Architecture (from notebook design):
  UserAgent  — controls the plan, verifies each tool call, triggers compaction
  AssistantAgent — executes todos, calls tools, reports back to UserAgent

Flow per todo:
  1. UserAgent sends todo to AssistantAgent as prompt
  2. AssistantAgent runs (tool calls + text)
  3. UserAgent verifies result: accept or reject with feedback
  4. If rejected, AssistantAgent retries with feedback (max N retries)
  5. Every D=5 todos, UserAgent checks for drift (plan still valid?)
  6. When AssistantAgent context hits 75%, UserAgent triggers compaction
"""
from __future__ import annotations

import logging
import sys
import time
from dataclasses import dataclass, field
from typing import Iterator

from ..agent.agent import Agent
from ..agent.context import Context
from ..agent.events import (
    AgentDone, Event, TextDelta, ToolCallComplete, ToolCallStart, StepComplete,
)
from ..agent.messages import Conversation
from ..agent.provider import OpenAIProvider
from ..agent.tools import default_tools
from ..agent.web_tools import web_tools

log = logging.getLogger("kivi.reliable")

for _n in ("scrapling", "httpx", "httpcore", "openai"):
    logging.getLogger(_n).setLevel(logging.WARNING)


def setup_logging(level: int = logging.INFO) -> None:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S"))
    log.addHandler(h)
    log.setLevel(level)
    log.propagate = False


# ── Souls ─────────────────────────────────────────────────────────────

_ASSISTANT_SOUL = """You are a capable task execution agent. You receive one todo at a time.

Rules:
- Use tools to accomplish the todo completely
- Be thorough — don't leave work half-done
- After finishing, give a brief result summary (1-3 sentences)
- Always keep the overall plan in your context
- If you need to write files, do so in work_dir

Current plan:
{plan}
"""

_USER_SOUL = """You are a strict task verifier. You review work done by an assistant agent.

Given a todo and its result, decide:
- ACCEPT: the todo is fully done (respond exactly: ACCEPT)
- REJECT: the todo needs more work (respond exactly: REJECT\n<reason>)

Be strict. Partial work = REJECT. Correct result = ACCEPT.
"""

_DRIFT_SOUL = """You are a plan auditor. Given the original goal and completed todos, check if the remaining todos are still valid.

Respond with JSON: {"valid": true} or {"valid": false, "updated_todos": ["todo1", "todo2", ...]}
"""


# ── Result types ──────────────────────────────────────────────────────

@dataclass
class TodoResult:
    todo_id: int
    description: str
    result: str
    accepted: bool
    attempts: int


@dataclass
class RunState:
    goal: str
    todos: list[str]
    completed: list[TodoResult] = field(default_factory=list)
    failed: list[TodoResult] = field(default_factory=list)

    @property
    def done_count(self) -> int:
        return len(self.completed)

    @property
    def progress(self) -> str:
        total = len(self.todos) + self.done_count + len(self.failed)
        return f"{self.done_count}/{total}"


# ── AssistantAgent ─────────────────────────────────────────────────────

class AssistantAgent:
    """Executes a single todo using tools. Maintains conversation for context continuity."""

    MAX_TOKENS = 200_000
    COMPACT_AT = 0.75

    def __init__(self, plan: list[str], provider: OpenAIProvider | None = None):
        self._plan = plan
        self._provider = provider or OpenAIProvider()
        soul = _ASSISTANT_SOUL.format(plan="\n".join(f"- {t}" for t in plan))
        self._conv = Conversation(system_prompt=soul)
        self._tools = default_tools() + web_tools()
        self._agent = Agent(provider=self._provider, tools=self._tools, name="assistant")

    def execute(self, todo: str, feedback: str | None = None, work_dir: str = ".") -> str:
        """Run one todo. Returns result text."""
        if feedback:
            prompt = f"Previous attempt was rejected: {feedback}\n\nRetry this todo: {todo}"
        else:
            prompt = f"Execute this todo: {todo}"

        self._conv.add_user(prompt)
        ctx = Context(work_dir=work_dir)
        result_parts: list[str] = []

        for event in self._agent.run(self._conv, ctx=ctx, mode="instruct"):
            if isinstance(event, TextDelta):
                result_parts.append(event.content)
            elif isinstance(event, ToolCallStart):
                log.info("  [assistant] tool: %s", event.tool_name)
            elif isinstance(event, ToolCallComplete):
                short = event.result[:80].replace("\n", " ")
                tag = "✗" if event.is_error else "✓"
                log.info("  %s %-20s  %s", tag, event.tool_name, short)

        result = "".join(result_parts).strip()
        self._maybe_compact()
        return result or "[no output]"

    def _maybe_compact(self) -> None:
        msgs = self._conv.messages
        approx_tokens = sum(len(m.text or "") for m in msgs) // 4
        if approx_tokens > self.MAX_TOKENS * self.COMPACT_AT:
            log.info("  [assistant] compacting context (%d est. tokens)", approx_tokens)
            self._conv = Conversation(system_prompt=self._conv._system_prompt or "")
            log.info("  [assistant] context reset (kept system prompt + plan)")


# ── UserAgent ─────────────────────────────────────────────────────────

class UserAgent:
    """Verifies todo results, controls plan drift, drives the main loop."""

    DRIFT_CHECK_EVERY = 5  # check plan drift every N completed todos
    MAX_RETRIES = 3        # max retries per todo before marking failed

    def __init__(self, goal: str, todos: list[str], provider: OpenAIProvider | None = None):
        self._goal = goal
        self._provider = provider or OpenAIProvider()
        self._verify_agent = Agent(
            provider=self._provider,
            tools=[],  # verifier uses no tools — text only
            name="verifier",
        )

    def verify(self, todo: str, result: str) -> tuple[bool, str]:
        """Returns (accepted, reason). Calls LLM verifier."""
        conv = Conversation(system_prompt=_USER_SOUL)
        conv.add_user(
            f"Todo: {todo}\n\nResult:\n{result}\n\nAccept or reject?"
        )
        resp_parts: list[str] = []
        for event in self._verify_agent.run(conv, mode="instruct", max_steps=2):
            if isinstance(event, TextDelta):
                resp_parts.append(event.content)

        resp = "".join(resp_parts).strip()
        if resp.startswith("ACCEPT"):
            return True, ""
        reason = resp.removeprefix("REJECT").strip()
        return False, reason or "verifier rejected without reason"

    def check_drift(self, remaining_todos: list[str], completed: list[TodoResult]) -> list[str]:
        """Returns possibly-updated remaining todos after drift check."""
        if not completed:
            return remaining_todos
        completed_summary = "\n".join(f"- {r.description}" for r in completed)
        remaining_summary = "\n".join(f"- {t}" for t in remaining_todos)

        conv = Conversation(system_prompt=_DRIFT_SOUL)
        conv.add_user(
            f"Goal: {self._goal}\n\n"
            f"Completed:\n{completed_summary}\n\n"
            f"Remaining:\n{remaining_summary}\n\n"
            f"Are remaining todos still valid? Respond with JSON."
        )
        resp_parts: list[str] = []
        for event in self._verify_agent.run(conv, mode="instruct", max_steps=2):
            if isinstance(event, TextDelta):
                resp_parts.append(event.content)

        import json, re
        resp = "".join(resp_parts).strip()
        try:
            m = re.search(r'\{.*\}', resp, re.DOTALL)
            data = json.loads(m.group()) if m else {}
            if not data.get("valid", True) and "updated_todos" in data:
                updated = [t for t in data["updated_todos"] if isinstance(t, str)]
                if updated:
                    log.info("  [user] drift detected — plan updated (%d todos)", len(updated))
                    return updated
        except Exception:
            pass
        return remaining_todos


# ── Main runner ───────────────────────────────────────────────────────

def run(
    goal: str,
    todos: list[str],
    work_dir: str = ".",
    max_retries: int = 3,
    drift_every: int = 5,
    provider: OpenAIProvider | None = None,
) -> RunState:
    """Run goal with UserAgent verifying each todo from AssistantAgent."""
    from pathlib import Path as _Path
    work_dir = str(_Path(work_dir).resolve())

    prov = provider or OpenAIProvider()
    state = RunState(goal=goal, todos=list(todos))
    remaining = list(todos)
    assistant = AssistantAgent(plan=todos, provider=prov)
    user = UserAgent(goal=goal, todos=todos, provider=prov)

    log.info("━━ Reliable Run ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    log.info("  goal: %s", goal)
    log.info("  todos: %d  work_dir: %s", len(todos), work_dir)
    log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    todo_idx = 0
    done_count = 0

    while remaining:
        # drift check every N completed
        if done_count > 0 and done_count % drift_every == 0:
            log.info("[user] drift check at %d completed...", done_count)
            remaining = user.check_drift(remaining, state.completed)

        todo = remaining[0]
        todo_idx += 1
        log.info("┌─ Todo #%d: %s", todo_idx, todo[:80])

        accepted = False
        feedback: str | None = None
        result = ""

        for attempt in range(1, max_retries + 1):
            log.info("│  attempt %d/%d", attempt, max_retries)
            t0 = time.monotonic()
            result = assistant.execute(todo, feedback=feedback, work_dir=work_dir)
            elapsed = time.monotonic() - t0
            log.info("│  result (%.1fs): %s", elapsed, result[:120].replace("\n", " "))

            log.info("│  verifying...")
            accepted, reason = user.verify(todo, result)

            if accepted:
                log.info("│  ✓ ACCEPTED")
                break
            else:
                log.info("│  ✗ REJECTED: %s", reason[:80])
                feedback = reason

        todo_result = TodoResult(
            todo_id=todo_idx,
            description=todo,
            result=result,
            accepted=accepted,
            attempts=attempt,
        )

        if accepted:
            state.completed.append(todo_result)
            done_count += 1
            log.info("└─ done  progress=%s\n", f"{done_count}/{todo_idx + len(remaining) - 1}")
        else:
            state.failed.append(todo_result)
            log.info("└─ FAILED after %d attempts\n", max_retries)

        remaining.pop(0)

    log.info("━━ Complete ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    log.info("  done=%d  failed=%d", len(state.completed), len(state.failed))
    return state
