from setuptools import setup, find_packages

setup(
    name="litmus-lab",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "bitsandbytes>=0.42.0",
        "transformers>=4.40.0",
        "datasets>=2.19.0",
        "psutil>=5.9.0",
        "accelerate>=0.30.0",
        "torch"
    ],
    entry_points={
        "console_scripts": [
            "litmus-lab=main:app",  
        ],
    },
)