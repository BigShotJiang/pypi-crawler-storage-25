# JAX imports
import jax.numpy as jnp
from jax import vmap

### Aux functions for tests


# Check if two arrays are close with increasing tolerance
def try_all_close(x, y, start_tol=-8, end_tol=-4):
    """Try all close with increasing tolerance"""
    # create list of tols 1e-8, 1e-7, 1e-6, ..., 1e1
    tol_list = jnp.array([10**i for i in range(start_tol, end_tol + 1)])
    for tol in tol_list:
        if jnp.allclose(x, y, atol=tol):
            return True, tol
    return False, tol


# Compare two arrays and print MSE if not close
def compare(x, x_ref, do_det=False, accept_failure=False):
    allclose, tol = try_all_close(x, x_ref)
    if allclose:
        print(f"\tAllclose passed with atol={tol}.")
    else:
        print(f"\tAllclose FAILED with atol={tol}.")

        # if x is 1d, add batch dim
        # TODO: use ensure_array_has_batch_dim instead
        if x.ndim == 1:
            x = x[:, None]
            x_ref = x_ref[:, None]

        # compute MSE of determinants over time
        if do_det:
            x = vmap(jnp.linalg.det)(x)
            x_ref = vmap(jnp.linalg.det)(x_ref)
            mse = (x - x_ref) ** 2
            rel_mse = mse / (x_ref**2)
        else:
            mse = jnp.mean((x - x_ref) ** 2, axis=1)
            rel_mse = mse / jnp.mean(x_ref**2, axis=1)

        print("\tInitial relative MSE: ", rel_mse[0])
        print("\tFinal relative MSE: ", rel_mse[-1])
        print("\tMax relative MSE: ", jnp.max(rel_mse))
        print("\tAverage relative MSE: ", jnp.mean(rel_mse))

        allclose, tol = try_all_close(rel_mse, 0, end_tol=-3)
        if not accept_failure:
            assert allclose, (
                f"Relative MSE allclose FAILED with atol={tol}. UNACCEPTABLE!"
            )
        else:
            print(
                f"Relative MSE allclose FAILED with atol={tol} but accepting this failure."
            )

    pass


# Helper to check for namedtuple
def is_namedtuple(instance):
    """Check if an instance is a namedtuple."""
    return isinstance(instance, tuple) and hasattr(instance, "_fields")


# Compare two arrays with given tolerances
def compare_new(array1, array2, atol=1e-5, rtol=1e-5):
    """Compare two arrays and return a tuple indicating if they are close and the comparison result."""
    are_close = jnp.allclose(array1, array2, atol=atol, rtol=rtol)
    return are_close, "same" if are_close else "different"


def get_array(data):
    """Attempt to extract a JAX array from the input or return it directly if already an array."""
    if isinstance(data, jnp.ndarray):
        return data
    else:
        try:
            return data.params
        except Exception:
            return data


# Recursive function to compare leaves of two nested structures
def compare_leaves(node1, node2, path="", atol=1e-5, rtol=1e-5):
    differences = []
    similarities = []
    unique_to_struct1 = []
    unique_to_struct2 = []

    if is_namedtuple(node1) and is_namedtuple(node2):
        fields1 = set(node1._fields)
        fields2 = set(node2._fields)
        common_fields = fields1.intersection(fields2)

        for field in common_fields:
            new_path = f"{path}.{field}" if path else field
            diff, sim, unique1, unique2 = compare_leaves(
                getattr(node1, field),
                getattr(node2, field),
                new_path,
                atol=atol,
                rtol=rtol,
            )
            differences.extend(diff)
            similarities.extend(sim)
            unique_to_struct1.extend(unique1)
            unique_to_struct2.extend(unique2)

        unique_fields1 = fields1 - fields2
        unique_fields2 = fields2 - fields1
        unique_to_struct1 += [f"{path}.{field}" for field in unique_fields1]
        unique_to_struct2 += [f"{path}.{field}" for field in unique_fields2]

    elif isinstance(node1, dict) and isinstance(node2, dict):
        keys1 = set(node1.keys())
        keys2 = set(node2.keys())
        common_keys = keys1.intersection(keys2)

        for key in common_keys:
            new_path = f"{path}.{key}" if path else key
            diff, sim, unique1, unique2 = compare_leaves(
                node1[key], node2[key], new_path, atol=atol, rtol=rtol
            )
            differences.extend(diff)
            similarities.extend(sim)
            unique_to_struct1.extend(unique1)
            unique_to_struct2.extend(unique2)

        unique_keys1 = keys1 - keys2
        unique_keys2 = keys2 - keys1
        unique_to_struct1 += [f"{path}.{key}" for key in unique_keys1]
        unique_to_struct2 += [f"{path}.{key}" for key in unique_keys2]

    else:
        array1 = get_array(node1)
        array2 = get_array(node2)
        if array1 is not None and array2 is not None:
            are_close, comparison_result = compare_new(
                array1, array2, atol=atol, rtol=rtol
            )
            if are_close:
                similarities.append(path)
            else:
                differences.append(path)
        else:
            if array1 is None and array2 is None:
                # Both are non-array; consider them similar if they are exactly the same
                if node1 == node2:
                    similarities.append(path)
                else:
                    differences.append(path)
            elif array1 is None:
                unique_to_struct2.append(path)
            else:
                unique_to_struct1.append(path)

    return differences, similarities, unique_to_struct1, unique_to_struct2


# Compare two nested structures with given tolerances
def _compare_structs(
    struct1, struct2, accept_failure=False, atol=1e-5, rtol=1e-5, verbose=False
):
    differences, similarities, unique_to_struct1, unique_to_struct2 = compare_leaves(
        struct1, struct2, atol=atol
    )

    if len(unique_to_struct1) > 0 or len(unique_to_struct2) > 0:
        if verbose:
            print("Unique fields in struct1:", unique_to_struct1)
            print("Unique fields in struct2:", unique_to_struct2)

    if len(differences) > 0:
        if verbose:
            print(
                f"Fields that are close within atol={atol} and rtol={rtol}:",
                similarities,
            )
            print(
                f"Fields that are different within tol={atol} and rtol={rtol}:",
                differences,
            )
        return False
    else:
        if verbose:
            print(
                f"Fields that are close within tol={atol} and rtol={rtol}:",
                similarities,
            )
        return True


# Compare two nested structures with increasing tolerances
def compare_structs(
    struct1,
    struct2,
    min_tol=-10,
    max_tol=-4,
    min_tol_rel=-5,
    max_tol_rel=-5,
    accept_failure=False,
):
    for rtol in range(min_tol_rel, max_tol_rel + 1):
        for atol in range(min_tol, max_tol + 1):
            close_enough = _compare_structs(
                struct1, struct2, atol=10**atol, rtol=10**rtol, verbose=False
            )
            if close_enough:
                # run again in verbose mode
                _compare_structs(
                    struct1, struct2, atol=10**atol, rtol=10**rtol, verbose=True
                )
                print(f"Comparison passed with atol=1e-{atol} and reltol=1e-{rtol}.")
                return

    if not close_enough:
        # run again in verbose mode
        _compare_structs(struct1, struct2, atol=10**atol, rtol=10**rtol, verbose=True)
        msg = f"Comparison failed at atol=1e-{max_tol} and rtol=1e-{max_tol_rel}."
        if not accept_failure:
            raise ValueError(msg)
        else:
            print("WARNING:", msg, "Accepting failure.")
