# System imports
import os
from configparser import ConfigParser

# Jax imports
import jax.numpy as jnp
import jax.random as jr

# Typing imports
# Import floating types, to avoid float64' is not defined error
from typing import Tuple, NamedTuple, Union
from jaxtyping import Array

# CD-dynamax imports
from cd_dynamax import (
    ContDiscreteLinearGaussianSSM,
    ContDiscreteNonlinearGaussianSSM,
    ContDiscreteNonlinearSSM,
)
from cd_dynamax.src.continuous_discrete_linear_gaussian_ssm import ParamsCDLGSSM
from cd_dynamax.src.continuous_discrete_nonlinear_gaussian_ssm import ParamsCDNLGSSM
from cd_dynamax.src.continuous_discrete_nonlinear_ssm import ParamsCDNLSSM
from cd_dynamax.dynamax.parameters import ParameterProperties

# Useful utility functions
from .simulation_utils import *  # noqa: F403, F405
from .physics_based_models import *  # noqa: F403, F405
from .data_driven_models import *  # noqa: F403, F405

# Import the models and utils from the continuous-discrete nonlinear SSM codebase, which may be needed for creating the model or filter from config files
from cd_dynamax.src.continuous_discrete_linear_gaussian_ssm.models import *  # noqa: F403
from cd_dynamax.src.continuous_discrete_nonlinear_gaussian_ssm.models import *  # noqa: F403
from cd_dynamax.src.continuous_discrete_nonlinear_ssm.models import *  # noqa: F403
from cd_dynamax.src.continuous_discrete_linear_gaussian_ssm.cdlgssm_utils import *  # noqa: F403
from cd_dynamax.src.continuous_discrete_nonlinear_gaussian_ssm.cdnlgssm_utils import *  # noqa: F403
from cd_dynamax.src.continuous_discrete_nonlinear_ssm.cdnlssm_utils import *  # noqa: F403

from cd_dynamax.dynamax.utils.bijectors import *  # noqa: F403
import diffrax as dfx  # noqa: F401
import optax  # noqa: F401


# Generate time emissions
def generate_t_emissions(
    t0: float,
    t1: float,
    num_samples: int,
    irregular_samples: bool = True,
    key=jr.PRNGKey(0),
) -> Tuple[int, Array]:
    r"""Generate time points for emissions, either uniformly or irregularly sampled.

    Args:
        t0 (float): Start time.
        t1 (float): End time.
        num_samples (int): Number of samples to generate.
        irregular_samples (bool): Whether to generate irregular samples.
        key (jr.PRNGKey): JAX random key.

    Returns:
        Tuple[int, Array]: Number of time steps and the time emissions array.
    """
    if irregular_samples:
        # Generate irregular time points
        u = jr.uniform(key, (num_samples,), minval=0, maxval=1)
        s = jnp.cumsum(u)  # Convert them into sorted cumulative sum
        # Normalize to [t0, t1] interval
        t_emissions = t0 + (s / s[-1]) * (t1 - t0)

        # throw error if duplicate time points
        if jnp.any(jnp.diff(t_emissions) < 1e-12):
            raise ValueError("Generated time points contain duplicates (within 1e-12).")
    else:
        # Generate uniform time points
        t_emissions = jnp.linspace(t0, t1, num_samples)

    # Ensure t_emissions is a column vector
    t_emissions = t_emissions[:, None]

    return len(t_emissions), t_emissions


### Python script utilities
# Build results directory based on config file names
def build_results_dir(
    output_dir, data_config_file, model_config_file, filter_config_file, overrides=None
):
    r"""
        Builds the results directory path based on configuration file names.

        Joins the names of the config files, omitting their directory and extensions.

    Args:
        output_dir (str): Base output directory.
        data_config_file (str): Data configuration file path.
        model_config_file (str): Model configuration file path.
        filter_config_file (str): Filter configuration file path.
        overrides (dict, optional): Dictionary of overrides to apply to the configuration files.

    Returns:
        str: The path to the results directory.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Default subdirectory names
    data_subdir = os.path.basename(data_config_file).split(".")[0]
    model_subdir = os.path.basename(model_config_file).split(".")[0]
    if filter_config_file is not None:
        filter_subdir = os.path.basename(filter_config_file).split(".")[0]
    else:
        filter_subdir = ""
    # Preallocate list for data overrides
    data_override_parts = []
    # Process overrides to create a unique subdirectory if needed
    if overrides is not None and len(overrides) > 0:
        # data_config_file overrides
        for k, v in overrides.items():
            if "data_generation." in k:
                # Remove data_generation. prefix and append the value
                data_override_parts.append(
                    f"{k.replace('data_generation.', 'data')}_{str(v).replace('/', '_')}"
                )

    # Join all parts to form the results directory path
    results_dir = os.path.join(
        output_dir,
        data_subdir
        + ("_" + "_".join(data_override_parts) if data_override_parts else ""),
        model_subdir,
        filter_subdir,
    )
    return results_dir


# Override ConfigParser with a dictionary of overrides
def override_config(cfg: ConfigParser, overrides: dict | None) -> ConfigParser:
    r"""Override configuration options in a ConfigParser object.
    Args:
        cfg (ConfigParser): The original configuration object.
        overrides (dict | None): A dictionary of overrides where keys are in the format 'section.option'.
    Returns:
        ConfigParser: The updated configuration object with overrides applied.
    """

    if overrides is not None and isinstance(overrides, dict):
        for k, v in overrides.items():
            if "." in k:
                sect, opt = k.split(".", 1)
            else:
                raise ValueError(
                    f"Override key {k} must be of the form 'section.option'"
                )
            # Set the option in the configuration
            if sect not in cfg:
                cfg.add_section(sect)
            cfg[sect][opt] = str(v)

    return cfg


# Convert MCMC configuration from config file to dictionary
def mcmc_config_to_dict(mcmc_config):
    r"""
    Convert MCMC configuration from a config file to a dictionary.

    Args:
        mcmc_config (ConfigParser): MCMC configuration section.

    Returns:
        dict: MCMC configuration parameters.
    """

    mcmc_config_dict = {
        "type": mcmc_config.get("type", "nuts"),
        "n_samples": mcmc_config.getint("n_samples", 100),
        "warmup_samples": mcmc_config.getint("warmup_samples", 10),
        "parameters": eval(mcmc_config.get("parameters", "{}")),
    }

    return mcmc_config_dict


# Create a cd-dynamax model from configuration files, which can be CD-LGSSM or CD-NLGSSM
def create_cddynamax_model_from_config(
    config_path: str = "../configs/",
    true_model_config_file: str = None,
    overrides=None,
) -> Tuple[
    Union[
        ContDiscreteLinearGaussianSSM,
        ContDiscreteNonlinearGaussianSSM,
        ContDiscreteNonlinearSSM,
    ],
    Union[ParamsCDLGSSM, ParamsCDNLGSSM, ParamsCDNLSSM],
    ParameterProperties,
]:  # Either CD-LGSSM or CD-NLGSSM or CD-NLSSM
    r"""Create a cd-dynamax model from configuration files
        The model can be either CD-LGSSM or CD-NLGSSM or CD-NLSSM, depending on the class_name specified in the config file.
    Args:
        config_path: Path to the configuration directory.
        true_model_config_file: Path to the model configuration file.
        overrides: Dictionary of overrides to apply to the configuration file.

    Returns:
        Tuple of model (CD-LGSSM or CD-NLGSSM), its parameters, and properties.
    """

    # Full path to the config file
    true_model_config_filepath = os.path.join(config_path, true_model_config_file)

    # Check if the config file exists
    if not os.path.exists(true_model_config_filepath):
        raise FileNotFoundError(
            f"Configuration file '{true_model_config_filepath}' not found."
        )

    # Load the model configuration file
    config = ConfigParser()
    config.read(true_model_config_filepath)

    # The model section contains
    cddynamax_model_class_name = config.get("model", "class_name")
    if cddynamax_model_class_name not in ["CDLGSSM", "CDNLGSSM", "CDNLSSM"]:
        raise ValueError(f"Unknown model class name: {cddynamax_model_class_name}")

    # Apply overrides if provided.
    # For object-valued initial_values.* overrides (e.g. NamedTuples with JAX arrays),
    # avoid routing through ConfigParser stringification, which is not eval-safe.
    direct_initial_value_overrides = {}
    if overrides is not None:
        config_overrides = {}
        for k, v in overrides.items():
            if k.startswith("initial_values.") and not isinstance(v, str):
                _, opt = k.split(".", 1)
                direct_initial_value_overrides[opt] = v
            else:
                config_overrides[k] = v
        config = override_config(cfg=config, overrides=config_overrides)

    # Choose the model class
    if cddynamax_model_class_name == "CDLGSSM":
        # CDLGSSM
        cddynamax_model_class = ContDiscreteLinearGaussianSSM
    elif cddynamax_model_class_name == "CDNLGSSM":
        # CDNLGSSM
        cddynamax_model_class = ContDiscreteNonlinearGaussianSSM
    elif cddynamax_model_class_name == "CDNLSSM":
        # CDNLSSM
        cddynamax_model_class = ContDiscreteNonlinearSSM
    else:
        raise ValueError(f"Unknown model class name: {cddynamax_model_class_name}")
    # Dimensions
    state_dim = config.getint("model", "state_dim")
    emission_dim = config.getint("model", "emission_dim")
    # Create the model
    true_model = cddynamax_model_class(
        state_dim=state_dim,
        emission_dim=emission_dim,
        diffeqsolve_settings=solver_settings_from_config(
            config_path=config_path,
            config_file=config.get("model", "solver_config_file", fallback=None),
            overrides=overrides,
        ),
    )

    # Load the initial values from the configuration file,
    # by iterating over rows in section [initial_values]
    initial_config_values = config["initial_values"]

    # Iterate over the rows in the initial values section (we don't know the order or which parameters are present)
    initial_params = {}
    for key, val in initial_config_values.items():
        initial_params[key] = eval(val)
    # Apply direct object overrides after config parsing/eval.
    # This supports values that cannot round-trip through str(...) + eval(...).
    initial_params.update(direct_initial_value_overrides)

    # Load the prior from the configuration file, if present
    prior_config_file = config.get("prior", "prior_class_file", fallback=None)
    if prior_config_file is not None:
        # Prior name is given as a file path, we need to import it as a module
        # First recover everything after last / and then, remove .py extension
        absolute_prior_path = os.path.abspath(
            os.path.join(config_path, prior_config_file)
        )
        print(f"Attempting to load prior from: {absolute_prior_path}")
        import importlib
        import sys

        prior_module_name = os.path.basename(prior_config_file).rstrip(".py")
        spec = importlib.util.spec_from_file_location(
            prior_module_name, absolute_prior_path
        )

        if spec and spec.loader:
            # Create the module from the spec
            module = importlib.util.module_from_spec(spec)
            sys.modules[prior_module_name] = module
            spec.loader.exec_module(module)
            print(f"Successfully loaded prior from: {absolute_prior_path}")
            # Get the class
            CDNLGSSM_Prior = getattr(module, "CDNLGSSM_Prior")
            # Instantiate the prior class
            prior = CDNLGSSM_Prior()
            print(f"Prior instantiated from class: {prior.__class__.__name__}")
            prior_init_key = jr.PRNGKey(
                config.getint("prior", "prior_init_key", fallback=0)
            )
        else:
            raise ImportError(f"Could not load module from path: {absolute_prior_path}")

    else:
        prior = None
        prior_init_key = jr.PRNGKey(0)

    # Initialize the model with the provided parameters
    true_model_params, true_model_props = eval(
        f"init_{cddynamax_model_class_name.lower()}_params"
    )(
        default_params=eval(
            f"true_model._default_{cddynamax_model_class_name.lower()}_params()"
        ),
        init_params=initial_params,
        init_prior=prior,
        key=prior_init_key,
    )

    return true_model, true_model_params, true_model_props


# Load solver settings from configuration file
def solver_settings_from_config(
    config_path: str = "../configs/",
    config_file: str = None,
    overrides=None,
) -> dict:
    r"""Load solver settings from a configuration file.

    Args:
        config_path: Path to the configuration directory.
        config_file: Path to the configuration file.
        overrides: Dictionary of overrides to apply to the configuration file.

    Returns:
        Dictionary of solver settings.
    """

    # Full path to the config file
    config_filepath = os.path.join(config_path, config_file)

    # Check if the config file exists
    if not os.path.exists(config_filepath):
        raise FileNotFoundError(f"Configuration file '{config_filepath}' not found.")

    # Load the solver configuration file
    solver_config = ConfigParser()
    solver_config.read(config_filepath)

    # Apply overrides if provided
    if overrides is not None:
        solver_config = override_config(cfg=solver_config, overrides=overrides)

    # Import diffrax as dfx (to avoid issues with eval)

    # Extract the solver settings into a dictionary
    diffeqsolve_settings = {}
    diffeqsolve_settings["solver"] = eval(
        solver_config.get("diffeqsolve_settings", "solver", fallback="None")
    )
    diffeqsolve_settings["stepsize_controller"] = eval(
        solver_config.get(
            "diffeqsolve_settings",
            "stepsize_controller",
            fallback="dfx.ConstantStepSize()",
        )
    )
    diffeqsolve_settings["adjoint"] = eval(
        solver_config.get(
            "diffeqsolve_settings",
            "adjoint",
            fallback="dfx.RecursiveCheckpointAdjoint()",
        )
    )
    diffeqsolve_settings["dt0"] = solver_config.getfloat(
        "diffeqsolve_settings", "dt0", fallback=0.01
    )
    diffeqsolve_settings["tol_vbt"] = solver_config.getfloat(
        "diffeqsolve_settings", "tol_vbt", fallback=diffeqsolve_settings["dt0"] / 2.0
    )
    diffeqsolve_settings["max_steps"] = solver_config.getfloat(
        "diffeqsolve_settings", "max_steps", fallback=1e2
    )

    return diffeqsolve_settings


# Create cd-dynamax filter from configuration file
def create_cddynamax_filter_from_config(
    config_path: str = "../configs/",
    filter_config_file: str = None,
    overrides=None,
) -> NamedTuple:
    r"""Create CD-Dynamax filter from configuration file.

    Args:
        config_path: Path to the configuration directory.
        filter_config_file: Path to the filter configuration file.
        overrides: Dictionary of overrides to apply to the configuration file.

    Returns:
        NamedTuple of filter settings.
    """

    # Full path to the config file
    filter_config_filepath = os.path.join(config_path, filter_config_file)
    # Check if the config file exists
    if not os.path.exists(filter_config_filepath):
        raise FileNotFoundError(
            f"Configuration file '{filter_config_filepath}' not found."
        )

    # Load the filter configuration file
    filter_config = ConfigParser()
    filter_config.optionxform = (
        str  # Preserve case sensitivity (needed for "N_particles")
    )
    filter_config.read(filter_config_filepath)

    # Apply overrides if provided
    if overrides is not None:
        filter_config = override_config(cfg=filter_config, overrides=overrides)

    # The filter type is specified as a section within the configuration file
    # The section name is the filter type, e.g. EKF, UKF, EnKF
    section = filter_config.sections()[0] if filter_config.sections() else None

    # Get the section name and check if it is a valid filter type
    if section not in ["KF", "EKF", "UKF", "EnKF", "DPF"]:
        raise ValueError(f"Unknown filter type: {section}")

    # Build the filter class string
    filter_class_str = "{}HyperParams".format(section)

    # Extract basic filter hyperparameters from the section
    hyperparam_dict = dict(filter_config.items(section))
    hyperparam_dict["dt_final"] = float(hyperparam_dict.get("dt_final", 1e-4))
    hyperparam_dict["diffeqsolve_settings"] = solver_settings_from_config(
        config_path=config_path,
        config_file=hyperparam_dict["diffeqsolve_settings_file"],
        overrides=overrides,
    )
    # drop the diffeqsolve_settings_file key
    hyperparam_dict.pop("diffeqsolve_settings_file", None)

    # Process specific hyperparameters based on cd-dynamax filter type
    # Actually, these only apply to nonlinear filters
    if section in ["EKF", "UKF", "EnKF", "DPF"]:
        hyperparam_dict["cov_rescaling"] = float(
            hyperparam_dict.get("cov_rescaling", 1.0)
        )
        if section == "EKF":
            pass
        elif section == "UKF":
            hyperparam_dict["alpha"] = float(
                eval(hyperparam_dict.get("alpha", "jnp.sqrt(3.0)"))
            )
            hyperparam_dict["beta"] = float(eval(hyperparam_dict.get("beta", "2")))
            hyperparam_dict["kappa"] = float(eval(hyperparam_dict.get("kappa", "0")))
        elif section == "EnKF":
            hyperparam_dict["N_particles"] = int(hyperparam_dict.get("N_particles", 30))
            hyperparam_dict["perturb_measurements"] = eval(
                hyperparam_dict.get("perturb_measurements", "True")
            )
        elif section == "DPF":
            hyperparam_dict["N_particles"] = int(hyperparam_dict.get("N_particles", 30))
            hyperparam_dict["proposal_method"] = hyperparam_dict.get(
                "proposal_method",
                "bootstrap",  # Currently, only bootstrap proposals are supported.
            )
            hyperparam_dict["resample_method"] = hyperparam_dict.get(
                "resample_method", "multinomial"
            )
            hyperparam_dict["ess_threshold_ratio"] = float(
                hyperparam_dict.get("ess_threshold_ratio", 0.5)
            )

    # Create the filter hyperparameters NamedTuple
    filter_hyperparams = eval(filter_class_str)(**hyperparam_dict)

    # Also process filter_info section if present
    filter_info = None
    if filter_config.has_section("filter_info"):
        filter_info = {}
        for k, v in filter_config.items("filter_info"):
            filter_info[k] = str(v)

    # return both hyperparams and filter_info
    return filter_hyperparams, filter_info
