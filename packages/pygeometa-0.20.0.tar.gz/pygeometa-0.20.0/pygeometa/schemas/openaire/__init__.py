# =================================================================
#
# Terms and Conditions of Use
#
# Unless otherwise noted, computer program source code of this
# distribution # is covered under Crown Copyright, Government of
# Canada, and is distributed under the MIT License.
#
# The Canada wordmark and related graphics associated with this
# distribution are protected under trademark law and copyright law.
# No permission is granted to use them outside the parameters of
# the Government of Canada's corporate identity program. For
# more information, see
# http://www.tbs-sct.gc.ca/fip-pcim/index-eng.asp
#
# Copyright title to all 3rd party software distributed with this
# software is held by the respective copyright holders as noted in
# those files. Users are asked to read the 3rd Party Licenses
# referenced with those assets.
#
# Copyright (c) 2026 Tom Kralidis
# Copyright (c) 2026 Jiarong Li
# Copyright (c) 2026 Paul van Genuchten
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without
# restriction, including without limitation the rights to use,
# copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following
# conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#
# =================================================================

import json
import logging
import os
import uuid
from typing import Union

from pygeometa.schemas.base import BaseOutputSchema

THISDIR = os.path.dirname(os.path.realpath(__file__))

LOGGER = logging.getLogger(__name__)


class OpenAireOutputSchema(BaseOutputSchema):
    """OpenAire: record schema"""

    def __init__(self):
        """
        Initialize object

        :returns: pygeometa.schemas.base.BaseOutputSchema
        """

        description = 'OpenAire'

        super().__init__('openaire', description, 'json', THISDIR)

    def import_(self, metadata: str) -> dict:
        """
        Import metadata into MCF

        :param metadata: string of metadata content

        :returns: `dict` of MCF content
        """

        # Initialized mcf
        mcf = {
            'mcf': {
                'version': '1.0',
            },
            'metadata': {},
            'identification': {},
            'contact': {}
        }

        md = json.loads(metadata)

        if md is None:
            raise ValueError('No openaire metadata')

        if 'results' in md:
            LOGGER.info('Using first record from results')
            md = next(iter(md.get('results')), None)
            if md is None:
                raise ValueError('No openaire metadata in results')

        metadata_ = md

        # mcf: metadata
        pids_ = metadata_.get('pids', [])
        originIds_ = metadata_.get('originalIds', [])
        id_ = metadata_.get('id')

        children_instances_ = metadata_.get('instances')
        main_id_, altIds_, main_instance_ = process_id_and_instance(
            pids_, originIds_, id_, children_instances_)

        if main_id_:
            mcf['metadata']['identifier'] = main_id_
        else:
            raise ValueError('No identification on record')

        if altIds_:
            mcf['metadata']['additional_identifiers'] = altIds_

        project_ = metadata_.get('projects')
        if project_ is not None and isinstance(project_, list):
            rel_project = []
            for p in project_:
                pids = p.get('pids', [])
                if pids is None or len(pids) == 0:
                    continue
                pid = pids[0]
                pro_dict = {
                    'identifier': pid.get('value'),
                    'scheme': pid.get('scheme'),
                    'type': 'project'
                }
                rel_project.append(pro_dict)
            if len(rel_project) > 0:
                mcf['metadata']['relations'] = rel_project

        if main_instance_:
            instance_type_ = main_instance_.get('type')
            if instance_type_:
                mcf['metadata']['hierarchylevel'] = instance_type_

        date_of_collection = metadata_.get('dateOfCollection')
        if date_of_collection is not None:
            mcf['metadata']['datestamp'] = metadata_.get('dateOfCollection')

        if main_instance_ is not None:
            urls = main_instance_.get('urls')
            if urls:
                mcf['metadata']['dataseturi'] = next(iter(urls), '')

        # mcf: identification
        language_ = metadata_.get('language', {}).get('code')
        if language_ is not None:
            mcf['identification']['language'] = language_

        main_title = metadata_.get('mainTitle')

        if main_title is not None:
            mcf['identification']['title'] = main_title

        description_ = metadata_.get('descriptions')
        if description_ is not None:
            mcf['identification']['abstract'] = next(iter(description_), '')

        version_ = metadata_.get('version')
        if version_ is not None:
            mcf['identification']['edition'] = version_

        right_ = metadata_.get('bestAccessRight', {}).get('label')
        instance_right_ = None
        if main_instance_:
            instance_right_ = main_instance_.get(
                'accessRight', {}).get('label')
        if right_ is not None and right_ != 'unspecified':
            mcf['identification']['rights'] = right_
        elif instance_right_ is not None and instance_right_ != 'unspecified':
            mcf['identification']['rights'] = instance_right_

        if main_instance_ is not None:
            license_ = main_instance_.get('license')
            if license_:
                mcf['identification']['license'] = {
                    'name': license_,
                    'url': ''
                }

        dates_dict = {}
        p_date = metadata_.get('publicationDate')
        e_date = metadata_.get('embargoEndDate')
        if p_date:
            dates_dict['publication'] = p_date
            mcf['identification']['datestamp'] = [p_date]
        if e_date:
            dates_dict['embargoend'] = e_date
        if dates_dict:
            mcf['identification']['dates'] = dates_dict

        subjects_ = metadata_.get('subjects')
        if isinstance(subjects_, dict):
            mcf['identification']['keywords'] = process_keywords([subjects_])
        elif isinstance(subjects_, list):
            mcf['identification']['keywords'] = process_keywords(subjects_)

        # contact
        authors_ = metadata_.get('authors', []) or []
        orgs_ = metadata_.get('organizations', []) or []
        publisher_ = metadata_.get('publisher') or ''
        contribs_ = metadata_.get('contributors', []) or []

        contact_ = process_contact(authors_, orgs_, publisher_, contribs_)
        if contact_:
            mcf['contact'] = contact_

        # distribution
        if isinstance(children_instances_, list) and children_instances_:
            dist_ = process_dist(children_instances_)
            if dist_ is not None:
                mcf['distribution'] = dist_

        return mcf

    def write(self, mcf: dict, stringify: str = True) -> Union[dict, str]:
        """
        Write outputschema to JSON string buffer

        :param mcf: dict of MCF content model
        :param stringify: whether to return a string representation (default)
                          else native (dict, etree)

        :returns: `dict` or `str` of MCF as Schema.org
        """

        # no write implementation for now
        return ''


def process_id_and_instance(
        pids: list, originIds: list,
        id: str, instances: list) -> tuple[str, list, dict]:
    """
    Get the main_id, alternative_ids and main_instance from the input data

    Alternative ids are the unique ids from pids and originIds

    Main id is the first doi from pids, otherwise the first pid,
    otherwise a doi from originId, otherwise an http url from originId,
    otherwise the first originId.

    main_instance is the first instance with the matched id of main_id,
    otherwise the first instance.

    :param pids: main pids
    :param originIds: pids from original
    :param id: id of the record
    :param instances: instances in the record

    :returns: `tuple` of (main_id, alternative_ids, main_instance)
    """

    # altids and main_id
    pids_schemevalue = None
    if pids is not None and len(pids) > 0:
        first_id = pids[0]
        main_id = first_id.get('value') if first_id else None
        if len(pids) > 1:
            for i in pids:
                if i.get('scheme') == "doi":
                    main_id = i.get('value')
                    break
        pids_schemevalue = [
            {
                'identifier': i.get('value'),
                'scheme': i.get('scheme')
            }
            for i in pids
        ]
    elif originIds is not None and len(originIds) > 0:
        main_id = next((item for item in originIds
                        if item.startswith('10.')), None)
        if main_id is None:
            main_id = next((item for item in originIds
                            if item.startswith('http')), None)
        if main_id is None:
            main_id = originIds[0]
    elif id is not None:
        main_id = id
    else:
        LOGGER.error('no valid identifier')
        main_id = None

    origin_and_ids = originIds + [id] if originIds else [id]
    origin_and_ids_uni = list(set(origin_and_ids)) if (
        origin_and_ids is not None) else []

    if pids_schemevalue:
        pids_values = [i.get('identifier') for i in pids_schemevalue]
        for i in origin_and_ids_uni:
            if i not in pids_values and i is not None:
                pids_schemevalue.append({
                    'identifier': i,
                    'scheme': None
                })
    else:
        pids_schemevalue = [
            {
                'identifier': i,
                'scheme': None
            }
            for i in origin_and_ids_uni
        ]

    # instance
    if instances is None or len(instances) == 0:
        return main_id, pids_schemevalue, None

    # get the instance matched with the main id
    main_instance = instances[0]
    for ins in instances:
        pid = ins.get('pid', {})
        if isinstance(pid, list):  # instance has multiple pid
            pid_values = [i.get('value') for i in pid]
            if main_id in pid_values:
                main_instance = ins
                break
        elif isinstance(pid, dict):  # instance has one pid
            if pid.get('value') == main_id:
                main_instance = ins
                break
        else:
            continue

    return main_id, pids_schemevalue, main_instance


def process_keywords(subjects: list) -> dict:
    """
    convert openaire keywords to mcf keywords

    group keywords by scheme

    :param subjects: list

    :returns: `dict` grouped keywords
    """
    unique_scheme = list(set([s.get('subject', {}).get('scheme')
                              for s in subjects]))

    scheme_uuid_dict = {scheme: str(uuid.uuid4()) for scheme in unique_scheme}

    keywords_dict = {
        value: {
            'keywords': [],
            'vocabulary': {
                'name': key
            }
        }
        for key, value in scheme_uuid_dict.items()
    }

    for s in subjects:
        s_value = s.get('subject')
        for k, v in keywords_dict.items():
            if s_value.get('scheme') == v.get('vocabulary', {}).get('name'):
                v['keywords'].append(s_value.get('value'))
                break
    return keywords_dict


def process_contact(author_list: list,
                    organization_list: list,
                    publisher: str,
                    contributor_list: list) -> dict:
    """
    Process authors, organizations, publisher, and contributors into MCF
    contact format

    :param author_list: list of author objects
    :param organization_list: list of organization objects
    :param publisher: publisher string
    :param contributor_list: list of contributor objects

    :returns: dict with UUID keys and contact point values
    """
    contact_dict = {}

    # Process authors
    for author in author_list:
        contact_uuid = str(uuid.uuid4())
        contactpoint_dict = {
            'individualname': None,
            'organization': None,
            'url': None,
            'role': 'author'
        }
        contactpoint_dict['individualname'] = author.get('fullName', '')
        pid = author.get('pid')
        if pid is not None and pid.get('id') is not None:
            pid_scheme = pid.get('id', {}).get('scheme')
            pid_value = pid.get('id', {}).get('value')
            if None not in [pid_scheme, pid_value]:
                contactpoint_dict['url'] = id2url(pid_scheme, pid_value)

        if contactpoint_dict['individualname']:
            contact_dict[contact_uuid] = contactpoint_dict

    # Process organizations
    for org in organization_list:
        contact_uuid = str(uuid.uuid4())
        contactpoint_dict = {
            'individualname': None,
            'organization': None,
            'url': None,
            'role': 'contributor'
        }
        contactpoint_dict['organization'] = org.get('legalName', '')
        pids = org.get('pids', [])
        if pids:
            for p in pids:
                scheme = p.get('scheme', '')
                if scheme and scheme.lower() in [
                        'ror', 'grid', 'wikidata', 'isni']:
                    contactpoint_dict['url'] = id2url(
                        p.get('scheme'), p.get('value'))
                    break

        if contactpoint_dict['organization']:
            contact_dict[contact_uuid] = contactpoint_dict

    # Process publisher
    if publisher:
        contact_uuid = str(uuid.uuid4())
        contactpoint_dict = {
            'individualname': None,
            'organization': publisher,
            'url': None,
            'role': 'publisher'
        }
        contact_dict[contact_uuid] = contactpoint_dict

    # Process contributors
    for contrib in contributor_list:
        contact_uuid = str(uuid.uuid4())
        contactpoint_dict = {
            'individualname': None,
            'organization': None,
            'url': None,
            'role': 'contributor'
        }

        contactpoint_dict['organization'] = str(contrib) if contrib else ''

        if contactpoint_dict['organization']:
            contact_dict[contact_uuid] = contactpoint_dict

    return contact_dict


def id2url(scheme: str, id_: str) -> str:
    """
    Convert orcid, wikidata, ror or grid value to url

    :param scheme: scheme
    :param id: identifier

    :returns: `str` url
    """
    scheme2 = scheme.lower()

    if scheme2 in ['ror', 'grid']:
        return id_
    elif scheme2 == 'orcid':
        return f'https://orcid.org/{id_}'
    elif scheme2 == 'wikidata':
        return f'https://www.wikidata.org/wiki/{id_}'
    elif scheme2 == 'isni':
        return f'https://isni.org/isni/{id_}'

    return None


def process_dist(instances_: list) -> dict | None:
    """
    Extract instances with PDF URLs

    :param instances_: list of instance dictionaries

    :returns: `dict` with UUID keys and instance info, or None if no PDFs found
    """
    result_dict = {}
    seen_urls = set()

    for instance in instances_:
        type_ = instance.get('type')
        urls_ = instance.get('urls')

        # Check if urls_ is a list and not empty
        if not isinstance(urls_, list) or not urls_:
            continue

        # Find first URL ending with .pdf
        pdf_url = None
        for url in urls_:
            if isinstance(url, str) and url.endswith('.pdf'):
                pdf_url = url
                break

        # If we found a PDF URL and haven't seen it before, add to result
        if pdf_url and pdf_url not in seen_urls:
            seen_urls.add(pdf_url)
            instance_uuid = str(uuid.uuid4())
            result_dict[instance_uuid] = {
                'type': type_,
                'url': pdf_url
            }

    # Return None if no results, otherwise return the dict
    return result_dict if result_dict else None
