# upvertex-schema

Namespace reservation for UpVertex Inc. (www.upvertex.com)