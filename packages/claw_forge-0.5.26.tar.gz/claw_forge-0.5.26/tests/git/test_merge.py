"""Tests for claw_forge.git.merge — squash-merge feature branches."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from claw_forge.git.branching import (
    branch_exists,
    create_feature_branch,
    create_worktree,
    current_branch,
)
from claw_forge.git.commits import commit_checkpoint
from claw_forge.git.merge import squash_merge


@pytest.fixture()
def git_repo(tmp_path: Path) -> Path:
    subprocess.run(["git", "init", "-b", "main"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=tmp_path, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=tmp_path, check=True, capture_output=True,
    )
    (tmp_path / "README.md").write_text("# test\n")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=tmp_path, check=True, capture_output=True,
    )
    return tmp_path


class TestSquashMerge:
    def test_squash_merge_creates_single_commit(self, git_repo: Path) -> None:
        create_feature_branch(git_repo, "t1", "auth")
        (git_repo / "auth.py").write_text("login = True\n")
        commit_checkpoint(
            git_repo, message="feat(auth): add login",
            task_id="t1", plugin="coding", phase="milestone", session_id="s1",
        )
        (git_repo / "auth_test.py").write_text("assert True\n")
        commit_checkpoint(
            git_repo, message="test(auth): add test",
            task_id="t1", plugin="testing", phase="milestone", session_id="s1",
        )

        result = squash_merge(git_repo, "feat/auth")
        assert result["merged"] is True
        assert result["commit_hash"]
        assert current_branch(git_repo) in ("main", "master")

    def test_squash_merge_deletes_branch(self, git_repo: Path) -> None:
        create_feature_branch(git_repo, "t2", "payments")
        (git_repo / "pay.py").write_text("pay = True\n")
        commit_checkpoint(
            git_repo, message="feat(pay): add payments",
            task_id="t2", plugin="coding", phase="milestone", session_id="s1",
        )
        squash_merge(git_repo, "feat/payments")
        assert branch_exists(git_repo, "feat/payments") is False

    def test_squash_merge_custom_target(self, git_repo: Path) -> None:
        # Create a develop branch
        subprocess.run(
            ["git", "checkout", "-b", "develop"],
            cwd=git_repo, check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "checkout", "main"],
            cwd=git_repo, check=True, capture_output=True,
        )
        create_feature_branch(git_repo, "t3", "nav")
        (git_repo / "nav.py").write_text("nav = True\n")
        commit_checkpoint(
            git_repo, message="feat(nav): add nav",
            task_id="t3", plugin="coding", phase="milestone", session_id="s1",
        )
        result = squash_merge(git_repo, "feat/nav", target="develop")
        assert result["merged"] is True
        assert current_branch(git_repo) == "develop"

    def test_squash_merge_nonexistent_branch(self, git_repo: Path) -> None:
        result = squash_merge(git_repo, "feat/nonexistent")
        assert result["merged"] is False

    def test_squash_merge_with_semantic_message(self, git_repo: Path) -> None:
        create_feature_branch(git_repo, "t4", "user-auth")
        (git_repo / "auth.py").write_text("login = True\n")
        commit_checkpoint(
            git_repo, message="Implement login endpoint",
            task_id="t4", plugin="coding", phase="coding", session_id="s1",
        )
        (git_repo / "test_auth.py").write_text("assert True\n")
        commit_checkpoint(
            git_repo, message="Add auth integration tests",
            task_id="t4", plugin="testing", phase="testing", session_id="s1",
        )

        result = squash_merge(
            git_repo, "feat/user-auth",
            title="Implement user authentication",
            steps=["Create login endpoint", "Write integration tests"],
            task_id="t4",
            session_id="s1",
        )
        assert result["merged"] is True

        # Verify the commit message on main
        log = subprocess.run(
            ["git", "log", "-1", "--format=%B"],
            cwd=git_repo, capture_output=True, text=True, check=True,
        )
        body = log.stdout
        assert "Implement user authentication" in body
        assert "Completed Steps:" in body
        assert "- [x] Create login endpoint" in body
        assert "- [x] Write integration tests" in body
        assert "Completed Phases:" in body
        assert "- Implement login endpoint" in body
        assert "- Add auth integration tests" in body
        assert "Task-ID: t4" in body
        assert "Session: s1" in body

    def test_squash_merge_without_context_uses_default(
        self, git_repo: Path,
    ) -> None:
        create_feature_branch(git_repo, "t5", "legacy")
        (git_repo / "legacy.py").write_text("old = True\n")
        commit_checkpoint(
            git_repo, message="feat(legacy): add old module",
            task_id="t5", plugin="coding", phase="coding", session_id="s1",
        )
        squash_merge(git_repo, "feat/legacy")

        log = subprocess.run(
            ["git", "log", "-1", "--format=%s"],
            cwd=git_repo, capture_output=True, text=True, check=True,
        )
        assert log.stdout.strip() == "merge: feat/legacy (squash)"

    def test_squash_merge_title_no_phases(self, git_repo: Path) -> None:
        """Merge with title but branch has same commits as main (empty phases)."""
        # Create a branch, add a file, but the branch_commit_subjects will
        # return the commit subject. To get empty phases, we need the branch
        # to exist but with no commits ahead of target. Since squash_merge
        # collects phases before merging, we simulate by providing title + steps
        # but the branch has a single commit. The phases list will be non-empty
        # so let's test the no-steps no-phases path instead.
        create_feature_branch(git_repo, "t-np", "no-phases")
        (git_repo / "np.py").write_text("np = True\n")
        commit_checkpoint(
            git_repo, message="only commit",
            task_id="t-np", plugin="coding", phase="coding", session_id="s1",
        )
        # Merge with title but without steps (steps=None)
        result = squash_merge(
            git_repo, "feat/no-phases",
            title="No steps merge",
            task_id="t-np",
        )
        assert result["merged"] is True

    def test_squash_merge_with_title_no_trailers(self, git_repo: Path) -> None:
        """Merge with title but no task_id/session_id — covers branch miss."""
        create_feature_branch(git_repo, "t8", "no-trailers")
        (git_repo / "nt.py").write_text("nt = True\n")
        commit_checkpoint(
            git_repo, message="add nt",
            task_id="t8", plugin="coding", phase="coding", session_id="s1",
        )
        result = squash_merge(
            git_repo, "feat/no-trailers",
            title="Title only merge",
            # no task_id, no session_id, no steps
        )
        assert result["merged"] is True
        log = subprocess.run(
            ["git", "log", "-1", "--format=%B"],
            cwd=git_repo, capture_output=True, text=True, check=True,
        )
        body = log.stdout
        assert "Title only merge" in body
        assert "Task-ID" not in body
        assert "Session" not in body

    def test_squash_merge_conflict_aborts(self, git_repo: Path) -> None:
        """Conflicting merge triggers abort and error return."""
        create_feature_branch(git_repo, "t9", "conflict")
        (git_repo / "README.md").write_text("# conflict branch\n")
        commit_checkpoint(
            git_repo, message="change readme on branch",
            task_id="t9", plugin="coding", phase="coding", session_id="s1",
        )
        # Go back to main and make a conflicting change
        subprocess.run(
            ["git", "checkout", "main"],
            cwd=git_repo, check=True, capture_output=True,
        )
        (git_repo / "README.md").write_text("# main branch conflict\n")
        subprocess.run(["git", "add", "."], cwd=git_repo, check=True, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "conflict on main"],
            cwd=git_repo, check=True, capture_output=True,
        )
        result = squash_merge(git_repo, "feat/conflict")
        assert result["merged"] is False
        assert "error" in result

    def test_squash_merge_with_worktree_cleanup(self, git_repo: Path) -> None:
        branch, wt_path = create_worktree(git_repo, "t6", "wt-merge")
        (wt_path / "wt_file.py").write_text("wt = True\n")
        commit_checkpoint(
            wt_path, message="add wt file",
            task_id="t6", plugin="coding", phase="coding", session_id="s1",
        )

        result = squash_merge(
            git_repo, branch,
            title="Worktree merge",
            task_id="t6",
            worktree_path=wt_path,
        )
        assert result["merged"] is True
        assert not wt_path.exists()
        assert (git_repo / "wt_file.py").exists()

    def test_squash_merge_failure_preserves_worktree(self, git_repo: Path) -> None:
        _, wt_path = create_worktree(git_repo, "t7", "fail-merge")
        # Don't commit anything — merge of empty branch will fail or produce
        # nothing different from main. Use a nonexistent branch to test the
        # failure path where worktree_path is passed but branch is missing.
        result = squash_merge(
            git_repo, "nonexistent/branch",
            worktree_path=wt_path,
        )
        assert result["merged"] is False
        # Worktree should still exist since merge failed
        assert wt_path.exists()

    def test_squash_merge_recovery_does_not_checkout_worktree_branch(
        self, git_repo: Path,
    ) -> None:
        """Regression: when squash merge falls into the conflict-recovery path,
        it must NOT try to ``git checkout <branch>`` from project_dir — that
        branch is already checked out in the worktree, so the checkout fails
        with ``fatal: '<branch>' is already used by worktree at ...`` (exit
        128).  The recovery must operate inside the worktree where the branch
        is checked out.
        """
        branch, wt_path = create_worktree(git_repo, "t-rec", "rec")
        (wt_path / "README.md").write_text("# from feature branch\n")
        commit_checkpoint(
            wt_path, message="readme change on feature",
            task_id="t-rec", plugin="coding", phase="coding", session_id="s1",
        )

        # Conflicting change on main — forces ``git merge --squash`` to fail
        # which triggers the recovery path.
        (git_repo / "README.md").write_text("# from main\n")
        subprocess.run(
            ["git", "add", "."], cwd=git_repo, check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "readme change on main"],
            cwd=git_repo, check=True, capture_output=True,
        )

        result = squash_merge(git_repo, branch, worktree_path=wt_path)

        # Even if the merge ultimately fails (true content conflict), the error
        # must NOT be the bogus "checkout already-held branch" failure.
        err = result.get("error", "")
        assert "'checkout', 'feat/" not in err, (
            "Recovery path tried to `git checkout` a worktree-held branch "
            f"from project_dir — error: {err!r}"
        )
