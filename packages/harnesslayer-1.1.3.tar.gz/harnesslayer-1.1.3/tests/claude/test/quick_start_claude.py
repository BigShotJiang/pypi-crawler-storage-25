from pathlib import Path
from harnesslayer import Harnesslayer

CURRENT_USER = "stephen@pickaxe.co"

client = Harnesslayer(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a236")

config_folder = str(Path(__file__).resolve().parent / ".claude")

# client.app.delete("app-e89f6cbc-b3e6-4751-8e73-357d3e842c7b")

# app = client.app.retrieve(slug="typedef-claude")

app = client.app.init("typedef-claude", 
    type="claude",
    version_path=config_folder,
)

# app.version.create(version_path=config_folder)

# app.version.sync(strategy="smart")

# app.profile.delete("profile-9e69c14d-6191-4037-83a7-fc8b09c6bb52")

# app.version.clone(transform={
#     "agent.json": {
#         "description": "This is a modification",
#     }
# })

# profile = app.profile.init(
#     identifier=CURRENT_USER,
# )

# profile.state.clone(transform={
#     "agent.json": {
#         "mcp_servers": {
#             "$by": "name",
#             "$patch": {
#                 "pickaxe": {
#                     "url": "https://pickaxeproject--v2-pickaxe-mcp-server.modal.run/mcp/PICKAXE123?sessionId=SESSION123"
#                 }
#             }
#         },
#     }
# })

# channel = app.channel.init("my-api", 
#     type="api",
# )

# stream = channel.run(
#     session_id="my-custom-session-id",
#     user_id=CURRENT_USER, 
#     input="Hello"
# )

# for event in stream:
#     if event.data["type"] == "driftstone.session_end":
#         break

#     print(event)
