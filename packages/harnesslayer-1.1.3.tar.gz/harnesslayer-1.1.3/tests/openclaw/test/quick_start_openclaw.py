from pathlib import Path
from harnesslayer import Harnesslayer

CURRENT_USER = "stephen@pickaxe.co"

client = Harnesslayer(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a236")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-1308c046-a238-450a-a8b6-ec27d7268fd3")

# app = client.app.retrieve(slug="Chat_Z1H90")

app = client.app.init("typedef-claw", 
    type="openclaw",
    version_path=config_folder,
)

# app.profile.delete("profile-9f738c8d-95a4-4762-bede-10216262179f")

# app.version.sync(strategy="theirs")

channel = app.channel.init("my-api", 
    type="api",
)

stream = channel.run(
    session_id="my-custom-session-id",
    user_id=CURRENT_USER, 
    input="Can you remind me every day at 9pm to take my medicine?",
)

for event in stream:
    if event.data["type"] == "driftstone.session_end":
        break

    print(event)
