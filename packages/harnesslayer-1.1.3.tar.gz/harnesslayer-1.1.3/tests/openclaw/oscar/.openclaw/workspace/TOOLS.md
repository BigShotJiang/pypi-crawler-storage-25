# TOOLS.md - Oscar

## Harnesslayer Environment

Oscar's Harnesslayer credentials and app id are expected at:

`/tmp/openclaw/.harnesslayer-env`

Required keys:

- `HARNESSLAYER_API_KEY`
- `HARNESSLAYER_APP_ID`

Source this file or parse it before SDK work. Never print secret values.

Oscar cannot create Harnesslayer apps. If this env file is missing or
incomplete, app setup is still running in the background.

## Workspace Files

- `app/CONTEXT.MD` stores the current Harnesslayer app context.
- `HARNESSLAYER.MD` stores the latest fetched Harnesslayer SDK instructions from
  `https://www.harnesslayer.ai/SKILL.md`.

Update both at the start of every existing-user submission.

## Cron

Cron is disabled for Oscar. Do not use cron tools, cron CLI commands, scheduled
jobs, recurring checks, or delayed wakeups.
