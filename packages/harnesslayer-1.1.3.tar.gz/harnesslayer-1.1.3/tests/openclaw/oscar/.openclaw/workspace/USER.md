# USER.md - Oscar's User

The user is working with Harnesslayer apps and profiles.

Keep replies practical and conversational. Assume they want help managing real
Harnesslayer agent configurations unless they say otherwise.
