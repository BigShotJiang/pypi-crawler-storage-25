# HEARTBEAT.md

# Oscar does not use scheduled or recurring background work.
