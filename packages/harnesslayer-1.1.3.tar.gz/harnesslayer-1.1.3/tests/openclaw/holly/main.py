from pathlib import Path
from harnesslayer import Harnesslayer

CURRENT_USER = "16044401225"

client = Harnesslayer(api_key="dk-c852ee94-7255-42b5-bd7d-17bf5a8958d2") # dk-c852ee94-7255-42b5-bd7d-17bf5a8958d2

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-f7a6b709-2043-47f0-9fc6-39b2e13ec946")

app = client.app.init("holly", 
    type="openclaw",
    version_path=config_folder,
)

# app.profile.delete("profile-5fc98285-6351-4823-86ba-0e3a3db2fee1")

# app.version.create(version_path=config_folder)

# app.version.sync(strategy="incoming")

# app = client.app.retrieve(slug="holly")

# channel = app.channel.init("holly-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "8b93f24cff36b3ba1248402c6a2856bb",
#         "sendBlueSecretKey": "996d24e34c9ed0092c4eeebbbabfe3f9",
#         "fromNumber": "+18324744658",
#     },
# )

# profile = app.profile.init(
#     identifier=CURRENT_USER,
#     auto_update_state=False,
# )
