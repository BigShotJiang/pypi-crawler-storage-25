# 52 Cards — Language Patterns from NLP & Milton Erickson
_Source: Robert Anue © 1992, ISBN 1-55552-046-4_
_Added: 2026-04-27_
_Format: Card deck of Ericksonian indirect language patterns with mechanics + examples_

---

## What This Is

A compact reference deck of Ericksonian/NLP indirect language patterns. Each card = one pattern with:
- The template formula
- How/why it works (the mechanism)
- Example sentences

These are the **building blocks of the Milton Model** in applied, conversational form. Use them as direct script templates.

---

## Delivery Mechanics (applies to all patterns below)

**Embedded commands** are marked by a shift in:
- Voice pitch (lower)
- Volume change
- Head tilt
- Direct eye contact
- Increased touch pressure
- Pointing at the person
- Smiling
- Pausing just before the command
- Touch at the moment of delivery

The shift = **tonal marking**. The words carry the surface meaning; the tone carries the instruction.

---

## The 52 Patterns

---

### 1. You may or may not ___
**Mechanism:** The "or may not" completely disarms resistance. You're not telling them to do anything — you're just noting a possibility. They relax, and the suggestion lands anyway.

*"You may or may not notice the comfortable sensations in your hands."*

---

### 2. I'm wondering if you'll ___ ... or not.
**Mechanism:** Same as above — "or not" ending dodges all resistance. Resistance has nothing to push against.

*"I'm wondering if you'll find this useful... or not."*

---

### 3. People can, you know, ___
**Mechanism:** You're talking about other people in general, not this person. The "you know" clause implies they already knew it — makes it feel like recognition rather than instruction.

*"People can, you know, find ways to make these changes easily and comfortably."*

---

### 4. Maybe you haven't ___ ... yet.
**Mechanism:** The word **yet** is the entire payload. It presupposes the thing *will* happen — it's just a matter of timing. Resistance collapses because you're not claiming it's happening now.

*"Maybe you haven't decided to fully commit to this... yet."*

---

### 5. One might, you know, ___
**Mechanism:** Maximum distance — "one" is even more abstract than "people." Paired with "you know," it feels observational. Near-zero resistance.

*"One might, you know, just relax and let the learning take place on a deep level."*

---

### 6. You might want to ___ ... Now.
**Mechanism:** Soft suggestion ("you might want to") + a pause + **Now** said as a standalone command. Slurred together it adds urgency; paused it becomes a direct command.

*"You might want to let that thought go... now."*

---

### 7. You could ___
**Mechanism:** "Could" = option, not obligation. Acknowledges free will, which paradoxically reduces resistance. The suggestion lands as possibility, not pressure.

*"You could let this process of transformation take place without even knowing how it was happening."*

---

### 8. You might ___
**Mechanism:** Softer than "you could." Suggests without asserting. Often used to introduce a new state or behavior.

*"You might discover that this feels different than you expected."*

---

### 9. A person could, [name], ___
**Mechanism:** Start talking about "a person," then drop the person's name in the middle. Confuses the boundary between abstract and personal — lands as both simultaneously.

*"A person could, Sarah, go into tomorrow with a completely fresh perspective."*

---

### 10. You may ___
**Mechanism:** "May" = permission + possibility. Bypasses "should" (which triggers rebellion) entirely. Gentle and effective.

*"You may find this experience very valuable."*
*"You may get confused about what used to bother you."*

---

### 11. One may, [name], ___
**Mechanism:** "One may" = formal and distanced. Dropping the name mid-sentence snaps it personal at just the right moment. Mild confusion = lowered resistance.

*"One may, Jerry, forgive someone even if you don't think you want to."*

---

### 12. A person may ___, because ___
**Mechanism:** The **because** is the key. It gives a reason — even an illogical one — and attention follows the reason, away from the suggestion. "Because" carries authority.

*"A person may just stop drinking, because you can remember all of your reasons each time you feel an urge."*

---

### 13. Will you ___, or ___, or ___?
**Mechanism:** **Infinite choice** — cover all the options so they're bound to do one. Each option leads where you want. Creates the illusion of freedom while guiding action.

*"Will you start with the easy part, or the interesting part, or just dive straight in?"*

---

### 14. I wouldn't tell you to ___, because ___
**Mechanism:** By saying "I wouldn't tell you to," you ARE telling them — but they can't resist because you've already disclaimed it. The "because" then delivers another suggestion as explanation.

*"I wouldn't tell you to relax right now, because I want you to find that on your own."*

---

### 15. How would it feel if you ___?
**Mechanism:** To answer, they must *imagine* the thing. The imagination *is* the experience at a neurological level. The question creates the very state you're asking about.

*"How would it feel if you had already made this change?"*
*"How would it feel if this was already easy?"*

---

### 16. I could tell you that ___ ... but ___
**Mechanism:** "I could tell you, but I won't" — except you just did. Resistance has nothing to grab onto because you've denied making the claim. The "but" redirects attention away before it registers.

*"I could tell you that this will give you more confidence, but I'd rather let you discover that for yourself."*

---

### 17. Sooner or later ___
**Mechanism:** Pure presupposition — it WILL happen, the only question is timing. The listener can't argue with "sooner or later" without arguing that something will *never* happen, which feels absurd.

*"Sooner or later, you're going to be able to look back on this and laugh."*

---

### 18. Sometime ___
**Mechanism:** Temporal vagueness — "sometime" means no specific commitment, but something will happen. The listener fills in the timing themselves, which makes the suggestion feel self-generated.

*"Sometime, you're going to feel better about this."*
*"Sometime you might find yourself understanding this from a viewpoint where it all makes sense."*

---

### 19. Eventually ___
**Mechanism:** Same as "Sooner or later" — presupposes inevitability without specifying when. Feels philosophical, meets no resistance.

*"Eventually, indirect language patterns will become second nature to you."*

---

### 20. Try to resist ___
**Mechanism:** "Try to" implies you *will* try but *won't succeed*. Tone inflection deepens the implication. The word "resist" paradoxically draws attention toward the thing being resisted.

*"Try to resist the sensation that your hands are becoming so relaxed."*

---

### 21. You might not have noticed ___
**Mechanism:** Directs attention precisely to the thing they "might not have noticed" — which means they now notice it. The negation is transparent at the conscious level but not the unconscious.

*"You might not have noticed how much easier this has become."*

---

### 22. Some people ___
**Mechanism:** The listener immediately wonders "Am I one of those people?" They check internally — and in doing so, they *try on* the suggestion. Give them something worth checking for.

*"Some people discover hidden strengths when they face situations very much like yours."*

---

### 23. Can you really enjoy ___?
**Mechanism:** The question isn't whether they *can* — it's how much they'll *enjoy* it. The only way to answer is to *do* it. Reframes the act as pleasurable before it happens.

*"Can you really enjoy going deeper and deeper into feelings of comfort?"*

---

### 24. You might notice the sensations in ___ while you ___
**Mechanism:** Directing attention to body sensations induces mild trance. The "while you" chains it to another action, making both feel inevitable.

*"You might notice the sensations in your hands while you relax and settle in."*

---

### 25. What happens when you ___?
**Mechanism:** Like #15, answering requires imagining. The imagination is the experience. Also presupposes that *something* happens — the question is just what.

*"What happens when you just decide you aren't going to let this bother you anymore?"*

---

### 26. You don't have to ___
**Mechanism:** **Truism** — true on the surface, contains embedded command beneath. "You don't have to relax" contains "relax." The relief of "don't have to" drops the guard completely.

*"You don't have to understand how this works in order to use it."*

---

### 27. One doesn't have to, [name], ___
**Mechanism:** Formal distancing + personal name = confusion + intimacy at the same moment. Double bind for the critical mind.

*"One doesn't have to, Betty, close your eyes as we begin."*

---

### 28. People don't have to, [name], ___
**Mechanism:** Same as above with "people" instead of "one." The name insertion personalizes it mid-abstraction.

*"People don't have to, Mary, listen carefully to everything I say."*

---

### 29. You may not know if ___
**Mechanism:** **Presupposition** — wondering whether they *know* something presupposes that thing *exists and is true*. The uncertainty is about their knowing, not about the thing itself.

*"You may not know if this is going to feel better than you expected."*

---

### 30. It's easy to ___, is it not?
**Mechanism:** "Is it not?" softens a claim into a question and makes it harder to disagree with (you'd have to say "no, it is not" which sounds confrontational). Calling something "easy" makes them try it to verify.

*"It's easy to just let go of what you don't need, is it not?"*

---

### 31. A person may not know if ___
**Mechanism:** Can shift mid-sentence from "a person" to "you" — the confusion lowers resistance. Same presupposition mechanic as #29.

*"A person may not know if they're already starting to feel more settled."*

---

### 32. You are able to ___
**Mechanism:** **Truism** with embedded command. States an obvious capability, which they affirm internally — then attaches the real suggestion. No resistance because the surface claim is undeniable.

*"You are able to take a breath and notice what's actually important here."*

---

### 33. [Fact], [fact], [fact], and ___
**Mechanism:** **Yes-set** — string undeniable facts together until the listener is in a rhythm of internal agreement, then deliver the suggestion. The habit of "yes" carries forward.

*"You came here today, you've been listening, you're still here, and you can start to feel the shift already."*

---

### 34. A person is able to ___
**Mechanism:** Third-person truism — the listener checks whether they are "a person" who can do this, and by checking, they begin to do it.

*"A person is able to approach this situation with fresh eyes."*

---

### 35. [Name] once told me, "[message]"
**Mechanism:** **Quote pattern** — the message is delivered inside a quote attributed to someone else. You didn't say it; they did. Resistance drops because there's no one to resist.

*"A mentor once told me, 'The fastest way through this is to decide it's already done.'"*

---

### 36. [Name] said, "[message]"
**Mechanism:** Same as above. Especially powerful if the named person is an authority figure the listener respects — or if the quote is attributed to the listener's own stated heroes/role models.

---

### 37. If you ___, then ___
**Mechanism:** **Cause-effect linkage** — the logic doesn't have to be airtight. To *verify* the "then" part is true, they have to *do* the "if" part. The condition is always the behavior you want.

*"If you imagine how this could feel six months from now, then you'll notice something already shifting."*

---

## Pattern Clusters by Function

**Disarming resistance:**
1 (may/may not), 2 (or not), 7 (you could), 14 (I wouldn't tell you), 20 (try to resist), 26 (don't have to)

**Presupposition (assumes truth):**
4 (yet), 17 (sooner or later), 18 (sometime), 19 (eventually), 29 (may not know if), 37 (if/then)

**Directing attention / inducing state:**
21 (might not have noticed), 22 (some people), 24 (sensations while), 25 (what happens when)

**Yes-set / agreement building:**
33 (fact/fact/fact/suggestion), 32 (you are able to), 10 (you may)

**Creating imagination / internal search:**
15 (how would it feel), 23 (can you really enjoy), 25 (what happens when)

**Third-person → personal:**
3 (people can), 9 (a person could, name), 11 (one may, name), 27/28 (don't have to, name)

**Quote / attribution:**
35/36 (name said "___")

**Cause-effect linking:**
12 (person may, because), 37 (if/then)

---

## Application in Practice (NLP Coach Mode)

These are **conversational** patterns — not therapy room scripts. They work in:
- Everyday conversation to shift states and frames
- Suggesting behaviors without triggering defensiveness
- Deepening rapport by speaking to the unconscious alongside the conscious
- Creating anticipation and forward movement in stuck conversations

**Key practice drill:** Take any direct request or command and rewrite it using 3 different patterns from above. Notice how the feeling changes — for you and for the imagined listener.

---

_Last updated: 2026-04-27_
