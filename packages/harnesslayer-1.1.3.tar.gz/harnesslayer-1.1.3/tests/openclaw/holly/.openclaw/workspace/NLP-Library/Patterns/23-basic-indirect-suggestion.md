# 23 — Basic Indirect Suggestion

**Tags:** `indirect suggestion` `Milton Model` `language` `influence`

## Description
Suggest desired outcomes or behaviors indirectly through implication rather than direct command. Bypasses resistance by framing ideas as observations about people in general rather than requests of him specifically.

## Use Cases
- Soft steering in any direction without triggering defensiveness
- Encouraging a behavior change without confrontation
- Planting an idea that he arrives at as if it were his own
- Low-resistance influence in stable or early relationships

## Scripts
1. *"Some people naturally become more generous when they feel respected."*
2. *"I've noticed that men who are consistent with communication tend to get a lot more back."*
3. *"It's funny — the people who make effort early usually get treated really well in return."*

## Practice Ideas
- Rewrite 5 direct requests or asks as implication-based observations
- Practice "third-person framing" — making the suggestion about "people" or "someone I know" rather than him
- Study the Milton Model's use of universal statements ("people," "one," "we") to de-personalize suggestions

## Sources


- NLP Classic — Milton Model (indirect suggestion)
