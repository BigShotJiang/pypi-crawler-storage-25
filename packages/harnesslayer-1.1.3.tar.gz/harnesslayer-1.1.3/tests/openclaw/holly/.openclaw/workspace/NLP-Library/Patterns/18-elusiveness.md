# 18 — Elusiveness

**Tags:** `mystery` `availability` `pull-back` `attraction`

## Description
Be slightly hard to fully capture or pin down — not through games, but through genuine fullness. You're accessible, but not on demand. This creates persistent low-level pursuit.

## Use Cases
- Overpursuit or clingy dynamics where he's tracking your availability too closely
- Preventing the "taken for granted" phase in an established dynamic
- Sustaining long-term attraction by being genuinely unpredictable
- Any moment where your availability has become automatic

## Scripts
1. *"I'm around, but not always available on impulse."*
2. *"I respond when I'm present — I'm not always present."*
3. *"I have a full life. You fit into it, not around it."*

## Practice Ideas
- For one week, shorten over-explaining responses — say less, mean more
- Practice not responding immediately to every message — let natural delays happen
- Identify 3 ways you've been making yourself too predictably available and reduce each by 30%

## Sources

