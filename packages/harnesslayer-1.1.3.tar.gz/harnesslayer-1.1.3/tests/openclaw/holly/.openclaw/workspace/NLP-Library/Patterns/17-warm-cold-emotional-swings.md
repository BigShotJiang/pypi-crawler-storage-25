# 17 — Warm-Cold Emotional Swings

**Tags:** `push-pull` `emotional regulation` `tension` `desire`

## Description
Alternate warmth and withdrawal in a non-hostile rhythm to intensify his attention and investment. The contrast makes both the warm and cold phases more potent.

## Use Cases
- High-pursuit dynamics where you want to sustain tension without losing warmth
- When a dynamic has become too predictable or comfortable
- Creating the emotional variability that deepens attachment
- Recalibrating after a period of being too available

## Scripts
1. *"That was fun. I'm disappearing now before I get too nice."*
2. *"You're getting close to knowing too much about me — I need to pull back a little."*
3. *"I enjoyed that. See you when I resurface."*

## Practice Ideas
- Role-play warmth → pause → warm re-entry without hostility or explanation
- Practice the withdrawal phase: go quiet for 24–48 hours after a warm exchange — note the response
- Write 3 "warm exit" lines that communicate enjoyment while signaling you're stepping back

## Sources

