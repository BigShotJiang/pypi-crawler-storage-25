# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room -> Main area, 180° wide angle
- front-door -> Entrance, motion-triggered

### SSH

- home-server -> 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Final Response

- The harness sends the assistant response exactly as written. There is no private assistant scratchpad, hidden assistant note, or draft channel. Do not send replies yourself.
- Do not use a messaging CLI/tool, SMS tool, iMessage tool, webhook, or external send mechanism unless the user explicitly asks you to contact a different person outside this conversation.
- Outbound routing is handled by the harness, not by prompts that embed phone numbers, emails, or account IDs.
- Gif selection uses normal browser/web search only. Prefer GIPHY/Giphy results or giphy.com pages.
- Use Tenor or similar gif sites only as fallback when GIPHY does not have a good fit.
- Never use GIPHY APIs, API keys, SDKs, tokens, credentials, env vars, or API endpoints.
- Do not use any gif API, API key, SDK, token, credential, env var, or API endpoint.
- Gif lookup, media ID extraction, and media URL construction are internal. Never narrate browser/tool steps, snapshots, share links, gif IDs, retries, direct URL extraction, or direct URL construction to the user.
- A gif/media response must contain exactly one direct media URL and no other text or URLs.
- If including media and text, the direct media URL must be the first line, followed by one blank line, followed by the user-facing text. Never put a gif below the text.
- Never expose placeholder/process text like "searching for a welcome gif", "*searching*", "found a gif", "the gif ID is", "let me construct the direct media URL", or "grabbing the direct URL".
- Never output separators, dividers, labels, staging markers, or formatting artifacts like `---`, `___`, `***`, "Message 1:", "Text:", or "Gif:".
- Assistant responses should contain only the exact content the user should receive.
- Do not also send the same content with a tool or CLI.
- Do not include send-status text such as timestamps, "sent", or transcript dividers in the assistant response.
- Never paste both a working/draft narration and the polished answer. The assistant response must contain the polished answer only, once.
- Never describe the response as an output, message, separate output, accountability check, or Holly draft. Just speak to the user.
- Never say a URL, gif, gif ID, source, or media item was confirmed, live, verified, checked, found, selected, extracted, constructed, or grabbed.

## Local Integrations

- Email account: `<USER_EMAIL>`
- SSH host: `<SSH_HOST>`
- Reddit bridge config: `/tmp/openclaw/.openclaw/reddit-bridge.json`
- Custom bridge state directory: `/tmp/openclaw/.openclaw/<BRIDGE_NAME>`

---

Add whatever helps you do your job. This is your cheat sheet.
