# NLP Essential Techniques — Bandler & Dilts
_Sources: nlpwiki.org, nlpu.com (Robert Dilts), NLP workbook archive, authoritative NLP literature_
_Added: 2026-04-27_
_Note: Scribd doc (346860022) is login-gated. This file synthesizes Bandler/Dilts techniques from open authoritative sources._

---

## The Core Framework

NLP was built by modeling three master therapists:
- **Virginia Satir** — family therapy, communication patterns
- **Fritz Perls** — Gestalt therapy, present-moment awareness
- **Milton Erickson** — hypnotherapy, indirect language

The key insight: excellence has *structure*. Find the structure → teach it to anyone.

---

## PART 1: FOUNDATIONAL MODELS

---

### 1. The Map Is Not the Territory
Core presupposition. Every person operates from their own *model of the world*, not reality itself. The quality of your map determines your options. NLP doesn't ask "is your map true?" — it asks "is it useful?"

---

### 2. Sensory Acuity
The ability to notice fine distinctions in another person's physiology — micro-changes in skin tone, muscle tension, breathing rate, eye movement, voice quality. Calibration is built on this. You can't lead someone you can't read.

---

### 3. Representational Systems (VAK + Ad)
People process and store experience through sensory channels:

| System | Language cues | Internal process |
|--------|--------------|-----------------|
| **Visual (V)** | "I see, looks like, picture this, unclear" | Thinks in images |
| **Auditory (A)** | "I hear you, sounds right, rings a bell, harmony" | Thinks in sounds/words |
| **Kinesthetic (K)** | "I feel, grasp, solid, pressure, gut feeling" | Thinks in feelings |
| **Auditory Digital (Ad)** | "Makes sense, I understand, logical" | Internal self-talk |

**Use:** Match rep system language to build instant rapport. Mismatch = friction.

---

### 4. Submodalities
The *qualities* of internal representations — the fine structure of thought.

**Visual submodalities:** brightness, size, color/B&W, distance, location, focus, moving/still, panoramic/framed, associated/dissociated

**Auditory submodalities:** volume, tempo, pitch, direction, distance, mono/stereo, rhythm, tone

**Kinesthetic submodalities:** pressure, temperature, texture, location in body, movement, weight, intensity

**Key principle:** Change the submodality → change the feeling. A scary memory in big bright color close up = scary. Same memory: small, dim, distant, B&W = manageable.

**Driver submodalities:** The one or two that, when shifted, shift everything else. Find the driver and you have the lever.

---

### 5. States
A state = a total psychophysiological condition: thoughts + feelings + physiology all at once. Every behavior emerges from a state. To change behavior, change state.

**State management:** The ability to enter, exit, and shift states at will. Peak performance requires being able to access resourceful states on demand.

---

### 6. Well-Formed Outcomes (Goals)
NLP has a precise formula for outcomes that actually get achieved:

1. **Stated positively** — "I want X" not "I don't want Y"
2. **Initiated and maintained by self** — within your control
3. **Sensory-specific** — what will you *see, hear, feel* when you have it?
4. **Preserves secondary gain** — the current behavior serves a purpose; the new outcome must preserve that positive intention
5. **Ecological** — good for self AND context AND others
6. **Appropriately sized** — chunk down if overwhelming, chunk up if too small to motivate

---

## PART 2: THE META MODEL (Bandler & Grinder)

Language is a *surface structure* — a compressed version of deep structure thought. Three distortion processes:

### Deletions
**Unspecified noun:** "They upset me" → *Who specifically?*
**Unspecified verb:** "He left me" → *How specifically?*
**Simple deletion:** "I'm uncomfortable" → *About what specifically?*
**Comparative deletion:** "This is better" → *Better than what?*
**Lack of referential index:** "One should be careful" → *Who specifically?*

### Distortions
**Nominalization:** A process frozen into a noun. "Respect," "love," "frustration," "communication" → *How are you [verb-ing]?* ("How are you not respecting yourself?")
**Mind reading:** "I know what you're thinking" → *How do you know?*
**Cause and effect:** "You make me angry" → *How does X cause Y in you?*
**Complex equivalence:** "He's not looking at me = he doesn't care" → *How does not looking = not caring?*
**Presupposition:** Assumed without being stated → *What leads you to believe...?*
**Lost performative:** "It's wrong to lie" → *Who says? By whose standard?*

### Generalizations
**Universal quantifiers:** "Always, never, everyone, nobody" → *Always? Has there ever been a time when...?*
**Modal operators of necessity:** "I must, I should, I have to" → *What would happen if you didn't?*
**Modal operators of possibility:** "I can't, it's impossible" → *What stops you? What would happen if you could?*

---

## PART 3: THE MILTON MODEL (Bandler & Grinder modeling Erickson)

The *inverse* of the Meta Model. Where the Meta Model asks for specificity to recover missing information, the Milton Model uses *deliberate vagueness* so the listener fills in meaning from their own experience. The language of hypnosis, trance, and influence.

### Milton Model Patterns:

**Pacing current experience** — describing what IS happening (undeniably true), building yes-set:
"As you sit there... and breathe... you may notice..."

**Truisms** — obvious statements that bypass resistance:
"People can learn new things." / "Everyone has had the experience of..."

**Embedded commands** — commands hidden in longer sentences (marked by tone shift):
"I wonder if you can *relax now*." / "You don't have to *feel confident* yet."

**Conversational postulate** — question that functions as a command:
"Can you close the door?" (answer is yes/no but action expected)

**Tag questions** — soften, reduce resistance:
"...doesn't it?" / "...can you?" / "...wouldn't you?"

**Double binds** — both options lead where you want:
"You can do this now, or you might find it happens naturally later."

**Cause and effect linkage** — chain behaviors to outcomes:
"As you take a breath, you can begin to feel more comfortable."
"The more you X... the more you Y."

**Nominalization** — creates vague but powerful internal searches:
"Allow a deep *understanding* to begin to form..." (they fill in what understanding means to them)

**Selectional restriction violation** — treating inanimate as animate for effect:
"Your unconscious mind knows..." / "The chair wants you to relax..."

**Presuppositions** — assume what you want to install:
"Before you begin to feel better, notice..." (presupposes they will feel better)
"How quickly will you change?" (presupposes change)

**Yes-set** — three or more undeniably true statements before the suggestion:
"You came here today... you've been listening... you're breathing... and you can begin to relax..."

**Universal quantifiers and vague verbs:** "Everyone... always... completely..." — invites the listener to fill with their own experience

**Utilization** — use whatever is happening (including resistance) to deepen the experience:
"And as you hear that noise outside... you can let it carry you deeper..."

---

## PART 4: PERCEPTUAL POSITIONS (Dilts)

How you experience a situation depends on the position you're in:

**1st Position — Self (I)**
Associated in your own experience. "What do *I* see, hear, feel?"
Access: sensory richness, your own needs, clarity of your own perspective.
Overuse: self-absorption, difficulty understanding others.

**2nd Position — Other (You)**
Stepping into the other person's experience. "If I were them, what would I see, hear, feel?"
Access: empathy, understanding, reducing conflict.
Overuse: losing yourself, pleasing at cost of your own needs.

**3rd Position — Observer / Meta (Witness)**
Detached, neutral, outside the interaction. "What do I notice about the interaction between them?"
Access: objectivity, patterns, systemic view.
Overuse: emotional disconnection, coldness.

**4th Position — System / We (Dilts)**
Associated in the *whole field* — the relationship, the group, the system.
"What's best for the entire system?" The "we" position.
Essential for leadership, wisdom, ecology.

**Practical use:** Stuck in conflict? Visit 2nd position. Overwhelmed? Go to 3rd. Planning strategy? Use 4th.

---

## PART 5: LOGICAL LEVELS (Dilts — Neurological Levels)

A hierarchy of change. Higher levels determine lower ones. Change is easier when you work at the right level.

```
6. SPIRIT / PURPOSE — What am I part of? (beyond self)
5. IDENTITY — Who am I? (I am...)
4. BELIEFS & VALUES — Why? What's important? What's true?
3. CAPABILITIES — How? What can I do?
2. BEHAVIOR — What? What do I do specifically?
1. ENVIRONMENT — Where, when, who? External context
```

**Key insight:** A problem at one level can't be solved at the same level. Behavioral change (level 2) that conflicts with identity (level 5) won't stick. Align the levels and change becomes congruent.

**Use in coaching:** "You keep starting but not finishing" — is that:
- Behavior? (skill issue → level 3)
- Belief? "I don't deserve success" (→ level 4)
- Identity? "I'm not someone who completes things" (→ level 5)
Different level = different intervention.

---

## PART 6: CORE TECHNIQUES

---

### Anchoring (Bandler & Grinder from Pavlov)
A stimulus-response link between a sensory trigger and an emotional state.

**How to anchor:**
1. Access desired state (fully associated — see what you saw, hear what you heard, feel what you felt)
2. At *peak intensity*, apply a unique anchor (knuckle squeeze, touch specific spot, specific sound)
3. Break state. Test anchor. Re-access if needed.
4. Fire anchor when you need the state.

**Stacking anchors:** Multiple positive states on the same anchor = very powerful resource state.

**Collapsing anchors:** Simultaneously fire a negative anchor and a stronger positive anchor. The stronger state dominates and the negative collapses.

**Chaining anchors:** Sequence anchors to move from one state through intermediate states to a target state (useful when the gap is too large to jump directly).

---

### The Swish Pattern (Bandler)
Reprograms an automatic negative trigger into a forward-moving one.

1. Identify the *cue picture* — the image that precedes the unwanted behavior (associated, large, bright, close)
2. Create the *outcome picture* — yourself as you want to be (associated, compelling)
3. Place the outcome picture as a small dark image in the corner of the cue picture
4. **Swish:** Rapidly shrink the cue picture while the outcome picture explodes to fill the screen (with a whoosh sound)
5. Go blank. Repeat 5 times fast.
6. Test: try to get the old cue picture. If Swish worked, outcome picture appears automatically or cue loses its charge.

---

### Reframing
Change the *frame* around an experience — same content, new meaning.

**Context reframe:** Find a context where the behavior is useful.
"I get really angry when I see injustice." → "That intensity would make you a great advocate."

**Content reframe (meaning reframe):** Change what the behavior means.
"She's so stubborn." → "She knows what she believes in." 

**Six-Step Reframe (Bandler & Grinder):**
1. Identify the behavior to change
2. Establish communication with the part responsible
3. Separate the behavior from the positive intention behind it
4. Have the creative part generate 3+ new behaviors that meet the same positive intention
5. Have the responsible part accept the new behaviors
6. Ecology check — any other parts object?

---

### Fast Phobia Cure / Visual-Kinesthetic Dissociation (V-K-D) (Bandler)
Rapid resolution of phobias and trauma. Uses dissociation and submodality changes.

1. Create a *dissociated* view: imagine watching yourself on a movie screen from the back of the cinema (you're in the projection booth)
2. Run the feared memory as a black-and-white movie, watching yourself from projection booth (double dissociation)
3. At the end, freeze the frame. Float into the screen version of yourself.
4. Run the film *backwards*, in color, at high speed, from end to beginning. Do this several times.
5. Test: think about the previously feared situation. Charge should be gone or radically reduced.

**Why it works:** Repeatedly doing V→K (image triggering feeling) in reverse breaks the conditioned link.

---

### Submodality Belief Change
Beliefs have a specific submodality structure. Find it, change the structure, change the belief.

1. Think of something you *don't believe* (a doubt). Notice its submodality qualities (location, size, brightness, framed, etc.)
2. Think of something you *absolutely believe* (an unquestionable fact). Notice its submodalities.
3. Think of the belief you want to change. Notice its submodalities.
4. Gradually shift the belief's submodalities to match the "absolute belief" structure.
5. Step 4 can use the Swish Pattern or manual submodality sliding.

---

### Timeline Work (James & Andreas, Dilts refinement)
People store time spatially — past behind, future ahead, or in a line across. Locating and working with this timeline allows:

- **Change history:** Going back to a past event with adult resources and reimprinting
- **Future pacing:** Stepping into the future to test and install new behavior
- **Clearing limiting decisions:** Finding the root event that created a pattern and updating the learning

---

### Meta Programs (Cameron-Bandler, Dilts)
High-level filters that determine what people notice and how they sort experience. Like the OS that runs below behavior.

Key meta programs:
- **Toward / Away from** — motivated by gain or pain avoidance
- **Internal / External reference** — validates from inside or needs outside confirmation
- **Options / Procedures** — loves possibilities vs. needs established paths
- **Global / Detail** — big picture vs. specific
- **Match / Mismatch** — looks for similarities or differences first
- **Proactive / Reactive** — initiates vs. waits and responds
- **In time / Through time** — lives in the moment vs. observer of time

**Use:** Don't try to motivate an "away from" person with positive outcomes. Show them what they'll lose by *not* acting.

---

### Modeling (The Core Skill)
The foundational NLP competency. How to reverse-engineer excellence.

1. **Unconscious uptake** — spend time with the exemplar, just absorb (no analysis yet)
2. **Elicit the strategy** — what do they do step-by-step? (TOTE: Test-Operate-Test-Exit)
3. **Identify the submodalities** — what do they see, hear, feel at each decision point?
4. **Elicit beliefs and values** — what do they believe about themselves, the task, the world?
5. **Identify meta programs** — how do they sort and filter?
6. **Test** — try it out. Does it produce the same results? Strip what's not necessary.

---

### TOTE Model (Bandler & Grinder from Miller, Galanter & Pribram)
How goals work at a neurological level:

- **Test** — compare current state to desired state
- **Operate** — take action if there's a gap
- **Test again** — has the gap closed?
- **Exit** — stop when match is achieved

Behavior is a feedback loop, not a linear sequence. Understanding this reveals where strategies break down.

---

### The New Behavior Generator
Creating a new skill or behavior from scratch:

1. Imagine watching yourself perform the new behavior perfectly (dissociated)
2. Step into that image (associate)
3. Rehearse with full sensory detail
4. Future pace: "When will you next be in a situation where this is useful?" — fire it in mentally

---

### Pattern Interrupts (Bandler)
Disrupting an unwanted habitual pattern by inserting something unexpected.

- Non-sequitur responses ("What time is it?" / "Carpet.")
- Physical interruption (handshake interrupt)
- Exaggerating the pattern to absurdity
Once the pattern is broken, install a new one immediately.

---

### Rapport Building (Full Stack)
- **Physiology matching** — posture, gestures, breathing rate, facial expression
- **Voice matching** — tempo, volume, tone, rhythm (not pitch mimicry)
- **Crossover mirroring** — match one channel with a different body part
- **Language matching** — predicates, rep system language, specific vocabulary
- **Values matching** — speak to what they care about
- **Pacing and leading** — establish rapport → then lead

---

## PART 7: PRESUPPOSITIONS OF NLP

The operating beliefs that make NLP work:

1. The map is not the territory
2. People respond to their map of reality, not reality itself
3. Mind and body are one system
4. All behavior has a positive intention
5. There is no failure, only feedback
6. The meaning of communication is the response you get
7. You cannot NOT communicate
8. The person with the most flexibility controls the system
9. People have all the resources they need — context activates them
10. Every behavior is appropriate in *some* context
11. Resistance is a comment on the communicator's flexibility
12. Modeling successful performance leads to excellence
13. If one person can do something, it can be modeled and taught

---

## PART 8: ADDITIONAL DILTS PATTERNS

### Sleight of Mouth (Dilts — from Bandler)
14 language patterns for reframing beliefs in real-time conversation. These shift the meaning, context, or frame of a limiting belief.

**The 14 patterns:**
1. **Redefine** — substitute a similar-sounding word with different implications: "I'm too aggressive" → "You mean you're assertive and direct?"
2. **Consequence** — redirect attention to an effect of the belief: "Being aggressive leads to... getting things done fast?"
3. **Intention** — positive purpose behind the belief: "The intention is probably to protect yourself."
4. **Chunk Down** — find a counter-example at the specific level: "Too aggressive *how specifically*? In all situations?"
5. **Chunk Up** — generalize to a higher level: "In the larger context, isn't that called leadership?"
6. **Another Outcome** — switch to a different goal: "The real question isn't whether you're aggressive — it's whether the outcome serves you."
7. **Model of the World** — how does another's worldview view it? "Some of the most admired leaders were described that way."
8. **Reality Strategy** — how do they *know* it's true? What evidence? "How do you know you're 'too' aggressive?"
9. **Counter Example** — find an exception: "Has there been a time when that intensity helped you?"
10. **Metaphor/Analogy** — a story or analogy that challenges the belief.
11. **Apply to Self** — use the belief's own criteria back on itself: "Is calling yourself aggressive being aggressive with yourself?"
12. **Hierarchy of Criteria** — find a higher value that overrides: "Which matters more — how you're perceived, or the results you get for people you care about?"
13. **Change Frame Size** — shift time or scope: "Five years from now, will it matter if people thought you were aggressive?"
14. **Reframe** — same behavior, different meaning/context.

---

### Belief Change Work (Dilts)
Using Logical Levels and submodalities to update limiting beliefs.

Core process:
1. Identify the limiting belief
2. Find its neurological level (behavior? capability? identity?)
3. Identify the positive intention
4. Install a new, more generative belief at the same level
5. Align all levels — environment, behavior, capability, belief, identity

**Museum of Old Beliefs:** Spatial process — walk the old belief to a metaphorical museum. Don't fight it; give it an honored place in history. Step into a new belief space.

---

### New Code NLP (Grinder & DeLozier)
Return to body-centered, state-based NLP. Key addition: state games (juggling, peripheral vision) to access high-performance states without content.

**New Code Change Format:**
1. Identify the context needing change
2. Step into it (briefly, just enough to feel it)
3. Exit and access a high-performance state through a state game
4. At peak state, step back into the original context
5. Let the state update the response automatically

---

### Reimprinting (Dilts)
Working with early formative experiences that created core beliefs.

1. Identify the limiting belief
2. Find the earliest memory associated with it (imprint experience)
3. Identify what resources were missing at that time
4. Bring those resources back to yourself in the memory
5. Extend the resources to the other people in the memory (they were doing the best they could with their model of the world)
6. Re-run the memory with resources present

---

## QUICK REFERENCE: Pattern → Use Case

| Pattern | Use when... |
|---------|-------------|
| Meta Model | Someone is vague, stuck, or limiting themselves with language |
| Milton Model | You want to influence, suggest, or create space for change |
| Anchoring | Installing or accessing resource states on demand |
| Swish | Breaking an automatic negative trigger |
| V-K-D (Phobia Cure) | Trauma, phobia, intense conditioned fear |
| Reframe | Challenging a limiting interpretation |
| Six-Step Reframe | Behavior with strong secondary gain (the "part" doesn't want to give it up) |
| Sleight of Mouth | Real-time belief challenges in conversation |
| Submodality work | Changing emotional intensity of memories/beliefs |
| Logical Levels | Diagnosing where change needs to happen |
| Perceptual Positions | Conflict resolution, empathy, leadership |
| Meta Programs | Influence, motivation, communication style matching |
| Timeline | Clearing past decisions, installing future states |
| Modeling | Learning excellence from an exemplar |

---

_Last updated: 2026-04-27_
