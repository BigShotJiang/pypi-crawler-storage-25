# 04 — Calibration of Intentions

**Tags:** `calibration` `reading people` `rapport`

## Description
Read his feelings, underlying motives, and real intentions before escalating investment or vulnerability. Prevents misreading surface warmth as genuine interest.

## Use Cases
- Ambiguous interest — he's warm but non-committal
- Before agreeing to exclusivity or deepening emotional investment
- Early screening to distinguish genuine interest from convenience
- Any moment where you feel unsure what he actually wants

## Scripts
1. *"You're warm, but slightly guarded — am I reading that right?"*
2. *"I notice you're very easy to be around, but I'm still figuring out what you're actually looking for."*
3. *"Your words say one thing; your actions are telling me something slightly different. Which one is more true?"*

## Practice Ideas
- After each interaction, write down: What did he say? What did he do? Do they match?
- Practice naming the gap — out loud or in writing — before reacting emotionally
- Note emotional vs. logical communication styles across 5 conversations and look for patterns

## Sources

