# 02 — Male Personality Typing

**Tags:** `calibration` `typing` `adaptation`

## Description
Classify men by personality makeup (driver, analyst, connector, expressive, etc.) to adapt your communication style and screening questions accordingly.

## Use Cases
- First-date screening
- Early text exchange where intent is unclear
- Adapting your approach before escalating
- Choosing compatible communication channels (direct vs. indirect)

## Scripts
1. *"You look decisive, but I'm checking whether you're also consistent."*
2. *"I'm noticing you tend to lead with logic — is that how you usually operate?"*
3. *"Most guys I've met fall into one of a few patterns. You seem like the kind who needs proof before he trusts."*

## Practice Ideas
- Build 3 fictional male profiles (e.g. driver, pleaser, avoider) and write one tailored opener for each
- After 3 conversations, note which profile fits and adjust your framing
- Track your accuracy: did your typing predict his behavior?

## Sources

