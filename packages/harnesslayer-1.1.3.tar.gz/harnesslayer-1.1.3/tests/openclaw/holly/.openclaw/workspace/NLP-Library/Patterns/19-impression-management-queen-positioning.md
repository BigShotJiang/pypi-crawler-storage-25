# 19 — Impression Management / Queen Positioning

**Tags:** `frame control` `status` `positioning` `confidence`

## Description
Deliberately control the overall frame of how you are perceived across all channels — verbal, physical, behavioral, and social. You are the author of your image, not a passive subject of his interpretation.

## Use Cases
- Image reset after a low-confidence period
- Entering a new social or dating context with a clean slate
- When you want to be perceived differently than you have been
- Establishing a consistent, high-status presence from the start

## Scripts
1. *"I prefer being around people who naturally rise to the occasion."*
2. *"I don't explain myself much — I'd rather be understood through behavior."*
3. *"The way I show up is pretty consistent. What you see is what you get — and what you get is considered."*

## Practice Ideas
- Audit four domains: wardrobe, posture, pacing (how fast you talk/move), and verbal standards — identify one upgrade per domain
- Practice entering rooms (or Zoom calls) with 3 extra seconds of stillness before speaking
- Write a one-paragraph "Queen positioning" statement describing how you want to come across — then check daily whether your behavior matches it

## Sources


