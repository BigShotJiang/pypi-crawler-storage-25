# 34 — Lightness

**Tags:** `lightness` `tonality` `emotional regulation` `ease`

## Description
Reduce heaviness and create emotional ease and lift — especially when difficult topics or tension are present. Lightness is not avoidance; it's holding a topic without making it a crisis.

## Use Cases
- Tension relief in an escalating conversation
- Delivering hard truths or feedback without crushing the dynamic
- After conflict — re-establishing warmth without pretending nothing happened
- Any moment where you want to stay in connection despite the content

## Scripts
1. *"Let's not make this dramatic; let's make it interesting."*
2. *"This is important — and I'm not going to treat it like it's the end of the world."*
3. *"I can say this and it doesn't have to be heavy. So I'm saying it."*

## Practice Ideas
- Take a hard thing you need to say and rehearse it three times: once serious, once light, once with a small smile — notice the difference
- Practice putting your hand on a topic lightly, rather than gripping it tightly
- Write 5 "lightness pivots" — ways to acknowledge something real without escalating the emotional register

## Sources

