# 33 — Advanced Flirt as Game / Challenge Structure

**Tags:** `flirt` `gamification` `challenge` `attraction`

## Description
Turn flirting into a structured, playful game or challenge with rules, stakes, and scores. Creates high-energy chemistry and keeps both people engaged and competing in a fun frame.

## Use Cases
- High-energy in-person chemistry
- Text exchanges that need more life and engagement
- Dates where you want to create memorable, playful interaction
- Re-igniting attraction in an established dynamic that's become flat

## Scripts
1. *"Rule for tonight: no boring answers."*
2. *"We're playing a game. Every good answer gets a point. I set the rules and I keep score."*
3. *"I'm going to ask you one question and you have 10 seconds. Ready? Go."*

## Practice Ideas
- Build 5 flirt prompts framed as mini-games (e.g., "Most controversial opinion you'd actually defend," "Worst lie you've ever told with a straight face")
- Practice setting up the rules of the game confidently — the frame matters as much as the question
- After a date, note which game-based exchanges created the most energy and what they had in common

## Sources

