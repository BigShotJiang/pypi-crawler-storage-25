# 13 — Mystery / Unread Book

**Tags:** `mystery` `intrigue` `open loops` `attraction`

## Description
Stay legible enough to be trusted but incomplete enough to intrigue. Leave emotional and narrative gaps that pull him toward you rather than giving everything upfront.

## Use Cases
- Sustaining intrigue past the first impression
- When you sense he's losing curiosity or you've over-shared
- Creating a "what is she thinking?" quality that generates pursuit
- Preventing the premature familiarity that kills attraction

## Scripts
1. *"There's a reason I react to that, but that story is better later."*
2. *"I have a theory about that — I'll tell you when I know you better."*
3. *"Most people would have asked by now. I'm waiting to see if you're most people."*

## Practice Ideas
- End 5 conversations on a warm but open loop — something warm enough to invite follow-up, incomplete enough to demand it
- Audit your texting: are you answering every question fully? Practice holding one thing back per conversation
- Write 3 "unread book" lines for common topics (work, past, what you want) that imply depth without revealing it

## Sources


