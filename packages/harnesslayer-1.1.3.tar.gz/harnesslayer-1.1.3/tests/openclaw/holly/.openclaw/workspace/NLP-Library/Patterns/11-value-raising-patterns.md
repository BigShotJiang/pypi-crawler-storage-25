# 11 — Value-Raising Patterns

**Tags:** `value` `self-positioning` `standards` `attraction`

## Description
Increase your perceived value and significance in his eyes through demonstrated standards, calm selectivity, and identity statements — without bragging or performing.

## Use Cases
- When you sense pursuit has stalled or reversed
- Rebalancing a dynamic where you've been over-giving
- Early stages where you're establishing who you are
- Any context where you want to recalibrate his perception of your worth

## Scripts
1. *"I like consistency. It makes people easier to trust."*
2. *"I've stopped making exceptions for people who aren't consistent — it just simplifies things."*
3. *"My time is genuinely limited, so I'm selective about where I put it."*

## Practice Ideas
- Write 5 boundary or standards statements that imply high value without boasting
- Replace self-deprecating or apologetic language with neutral, grounded alternatives for one week
- Audit your recent messages: are you justifying yourself? Reduce justification by 50%

## Sources


