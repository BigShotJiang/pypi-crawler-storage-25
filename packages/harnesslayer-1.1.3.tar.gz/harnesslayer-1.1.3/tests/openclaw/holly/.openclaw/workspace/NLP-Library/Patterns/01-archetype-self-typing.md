# 01 — Archetype Self-Typing

**Tags:** `typing` `self-framing` `archetype` `confidence`

## Description
Identify your own "female archetype" and build consistent behavior around it. Anchors identity before interaction so you lead from wholeness rather than reaction.

## Use Cases
- Before entering a new dating situation or relationship
- When you notice yourself slipping into over-giving or chasing
- As a reset after a breakup or dynamic imbalance
- Present-state positioning and identity calibration

## Scripts
1. *"When I'm at my best, I'm more calm-and-selective than overgiving."*
2. *"My natural state is [archetype trait] — I return to it when I drift."*
3. *"I'm not playing a role; I'm remembering who I actually am."*

## Practice Ideas
- Write your "best-self" archetype in exactly 3 traits (e.g. discerning, warm, unhurried)
- Identify 3 needy habits you currently run — and remove one per week
- Create a one-sentence archetype statement and read it before any date or high-stakes conversation
- Review the statement monthly and adjust as you grow

## Sources

