# NLP Patterns Knowledge Base
_Source: "NLP And The Use Of Language" — from the NLP Work Book collection (Internet Archive)_
_Added: 2026-04-27_

---

## Overview

NLP (Neuro Linguistic Programming) was developed by John Grinder and Richard Bandler in the 1970s. It's a model of how language, thought, and behaviour interconnect — and how changing one changes the others.

Core premise: we process reality through our five senses, create internal representations, and express those through language. Because we compress thought into speech, gaps and distortions appear. NLP gives tools to notice and work with those gaps.

---

## Key Models & Patterns

---

### 1. Representational Systems (VAK)

People process and communicate through preferred sensory channels:

- **Visual** — "I see what you mean", "It looks good to me"
- **Auditory** — "I hear what you're saying", "That rings a bell"
- **Kinesthetic** — "I feel good about this", "I can't grasp it"

**How to use it:** Match someone's representational language to build rapport. "I see what you mean" lands better with a visual person than "I hear you." Notice their vocabulary — it tells you which channel they're in.

---

### 2. Matching, Mirroring, Pacing & Leading

**Matching** — Subtly align voice tone/tempo, body posture, and breathing with the other person. Not mimicry (that reads as mockery) — subtle emulation.

**Mirroring** — Physically mirror posture and movement. Happens naturally in harmony; can be done consciously to build rapport.

**Crossover Mirroring** — Mirror someone's repeated gesture with a *different* repeated movement of your own (e.g. they tap their foot → you rub your jaw). Still creates rapport.

**Pacing** — Acknowledge and respect where someone is emotionally. Don't match their anxiety — pace it (show you understand it). Pacing ≠ agreement; it's acknowledgement.

**Leading** — Once you've established rapport through pacing, gradually shift your own state toward a more positive/resourceful place. If the rapport is real, they follow.

**Use it:** Pace first → build trust → lead the conversation where you want it to go.

---

### 3. Eye-Accessing Cues

Eyes move in predictable directions based on thinking mode (for right-handed people):

- **Up-right** → constructing a visual image (imagining)
- **Up-left** → recalling a visual image (remembering)
- **Level-right** → constructing a sound
- **Level-left** → remembering a sound
- **Down-right** → accessing feelings/emotions
- **Down-left** → internal dialogue (self-talk)

**Use it:** Read how someone is thinking, not just what they say. If someone looks down-right while answering a "factual" question, they may be feeling it, not recalling it.

---

### 4. Calibration

Reading the person in real time — integrating signals from eye movement, breathing rate, skin tone changes, facial muscle tension, and posture.

Calibration tells you:
- When you have rapport
- When you're on track
- When to change approach

It's an observation skill. No hard rules — each person is unique. Practice per individual.

---

### 5. The Meta Model

Created by Grinder & Bandler to close the gap between what's said and what's meant. When we speak, we delete, distort, and generalize our internal experience. The Meta Model is a set of questions that recover the missing information.

#### Meta Model Categories:

**Unspecified Nouns** — "A decision was made" / "They should stop it"
→ Who/what specifically?

**Unspecified Verbs** — "You'll need to preserve the timber" / "He's injured himself"
→ How exactly? In what way?

**Comparisons** — "This is better" / "I'm worse at this"
→ Better/worse than what, specifically?

**Judgements** — "I'm useless with machines" / "Obviously it's the only option"
→ In whose opinion? By whose criteria?

**Nominalizations** — Converting processes into static nouns. "Respect", "intelligence", "aggression", "confidence"
→ These mean wildly different things to different people. Ask: "How is he being aggressive?" "What kind of respect specifically?"

**Modal Operators of Necessity** — "I should", "I must", "I ought to"
→ What would happen if you didn't? What stops you?

**Modal Operators of Possibility** — "I can't", "It's impossible", "I couldn't possibly"
→ What specifically makes it impossible? What would happen if you tried?

**Generalizations** — "They always...", "Nobody ever...", "Everyone knows..."
→ Always? Nobody? Everyone? (Reflect the key word back with a rising tone.)

**Presuppositions** — "Will you type this before you get my sandwiches?" (assumes you'll get the sandwiches)
→ "What makes you think...?" / "What leads you to believe...?"

**Cause and Effect** — "You make me angry when..."
→ They may have triggered a reaction, but you're responsible for how you respond. "How exactly does X cause Y in you?"

**Intuition / Mind-Reading** — "I could tell how he felt" / "She should have known I'd be annoyed"
→ How specifically do you know? What evidence do you have?

---

### 6. The Meta Model — 5 Pointers (Grinder's Refinement)

After initial development, Grinder distilled the Meta Model to five core challenge points:

1. **Nouns** → "What specifically?" (nouns carry wildly different meanings per person)
2. **Verbs** → "How specifically?" (same verb = different actions to different people)
3. **Rules** (should/shouldn't/must/can't) → "What would happen if you did/didn't?"
4. **Generalizations** (always/never/everyone/all) → Reflect the word back: "Always?"
5. **Comparators** (better/cheaper/more effective) → "Better than what, specifically?"

---

### 7. Anchoring

An anchor is a sensory trigger (touch, sound, image) that reliably re-fires a specific emotional state.

**How to create an anchor:**
1. Fully recall or imagine a powerful positive state (confidence, calm, focus)
2. When the feeling is at its peak intensity, apply a physical anchor — e.g. touch forefinger to thumb, press a specific spot on your wrist
3. Hold the touch at peak, then release
4. Test: fire the anchor (touch again) → the state should return

**Key principles:**
- Anchor at peak intensity only
- The more unique the anchor, the cleaner the trigger
- Can be used to replace negative states with positive ones
- Works because mind can't distinguish imagined from real at neurological level

---

## Teaching Application (NLP Coach Mode)

**How to translate these patterns into practice sessions:**

- **Representational Systems** → Scenario: "He says 'I can't picture us working together.' What do you reply to match his channel?"
- **Pacing/Leading** → Scenario: "Your client is visibly defensive. How do you pace before you lead?"
- **Meta Model** → Scenario: "She says 'People always underestimate me.' What's your first question?"
- **Anchoring** → Exercise: Create a confidence anchor. Test it. Then use it in a simulated high-stakes conversation.
- **Eye Cues** → Observation challenge: Watch for eye direction when someone is asked to "remember" vs "imagine."

---

## Starter Teaching Notes

- No source-user progress is preserved in this starter config.
- Begin with the onboarding flow, then Day 1 of `NLP-Library/STUDY_QUEUE.md`.

---

_Last sanitized for starter config._
