# 10 — Anchoring

**Tags:** `anchoring` `NLP-classic` `conditioning` `emotional triggers`

## Description
Tie a positive emotional state to a specific phrase, touch, or gesture by pairing them consistently at peak warmth moments. Over time, the anchor alone retrieves the feeling.

## Use Cases
- Repeated contact — reinforcing a warm emotional association
- Creating a private "our thing" that builds intimacy
- Reactivating positive states after absence or tension
- Classic NLP conditioning for emotional bonding

## Scripts
1. *"Every time we slow down like this, the mood changes."*
2. *"I notice something shifts whenever we get quiet together."*
3. *"That [word/gesture] always brings me back to [positive shared moment]."*

## Practice Ideas
- Choose one phrase or gesture and deploy it only at high-warmth moments (not casually)
- Track how many repetitions it takes before the anchor becomes self-triggering
- Practice anchoring a positive state in yourself first — touch your wrist during a peak moment, repeat for 5 sessions

## Sources


- NLP Classic — Pavlovian Anchoring
