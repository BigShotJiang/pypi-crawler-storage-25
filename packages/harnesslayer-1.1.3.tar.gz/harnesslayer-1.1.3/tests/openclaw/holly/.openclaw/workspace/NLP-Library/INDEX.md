# NLP Pattern Library — Index

This starter config preserves Holly's reusable NLP knowledge while removing source-user progress, channel routes, downloaded source PDFs, and relationship/dating-specific applied files.

## Curriculum

| File | Contents |
|------|----------|
| `NLP-Library/STUDY_QUEUE.md` | 60-day master program for universal NLP communication, influence, perception, and change work |

## Knowledge Base Files

| File | Contents |
|------|----------|
| `memory/nlp-patterns.md` | VAK, matching/mirroring/pacing/leading, eye cues, calibration, Meta Model, anchoring |
| `memory/nlp-bandler-dilts.md` | Submodalities, states, outcomes, Milton Model, perceptual positions, logical levels, Swish, reframing, phobia cure, Sleight of Mouth, meta programs, timeline, modeling, TOTE, presuppositions |
| `memory/nlp-foundations-dilts.md` | NLP premises, change formula, canonical core techniques, generations of NLP, S.C.O.R.E., New Code NLP, Somatic Syntax, Generative NLP, calibrated loops, Change Personal History |
| `memory/nlp-52-cards.md` | 52 Ericksonian language pattern cards, mechanics, templates, examples, tonal marking |
| `memory/nlp-advanced-patterns.md` | Content reframing, parts negotiation, Mind-Lines, time distortion, timeline redecision, New Code NLP, meta-programs, submodality elicitation |
| `memory/nlp-erickson-hypnosis.md` | Ericksonian hypnosis techniques, R-Operator, utilization, session structure, suggestion rules, hypnotic phenomena, therapeutic metaphor |

## Teaching Engine

- Start new users with the onboarding flow in `SOUL.md`.
- Use `STUDY_QUEUE.md` for the daily pattern.
- Teach through simulated reality: create a scenario, wait, refine, repeat.
- Preserve strict message sequencing: gif alone, text alone, one scenario at a time.