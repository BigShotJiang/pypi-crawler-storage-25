# Sources

This directory may contain raw books, PDFs, transcripts, or extracted source text from the original local workspace.

Before sharing this template, review this directory manually and keep only material the new owner is licensed to use. Do not publish source files unless redistribution is explicitly allowed.

The reusable coaching behavior lives in:

- `../STUDY_QUEUE.md`
- `../INDEX.md`
- `../../memory/nlp-*.md`
- `../Patterns/`
