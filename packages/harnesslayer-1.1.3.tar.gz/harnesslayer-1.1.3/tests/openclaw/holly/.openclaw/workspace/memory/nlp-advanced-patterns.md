# Advanced NLP Patterns — Bandler, Dilts, Hall, Grinder
_Sources: Reframing (Bandler/Grinder), Time For A Change (Bandler), Mind-Lines/Sleight of Mouth (Hall/Bodenhamer), NLP Patterns Vol II (Bandler/Grinder/DeLozier), Turtles All the Way Down (Grinder/DeLozier), Timeline Therapy (James/Woodsmall), Frogs Into Princes (Bandler/Grinder), Whispering in the Wind (Grinder/St Clair)_
_Added: 2026-04-27_
_Focus: New patterns NOT already covered in previous knowledge base files_

---

## PART 1 — REFRAMING (Bandler & Grinder)

### The Core Principle
Meaning is not in events — it's in the frame we put around them. The same event can mean entirely different things in different frames. Change the frame → change the meaning → change the response.

**"There will be times when dinner is not served"** — a perfectly true statement that creates unintended panic depending on context. This illustrates: meaning comes entirely from the frame, not the content.

---

### Two Types of Content Reframing

**1. Meaning Reframe (same context, different meaning)**
- Complaint form: "I feel X when Y happens" (complex equivalence)
- Intervention: same behavior, different meaning attached
- Example: Footprints on carpet = "the people I love are near" (not "I'm a bad housekeeper")
- Ask yourself: "What else could this behavior mean?" / "What positive value could this have in a different light?"

**2. Context Reframe (same meaning, different context)**
- Complaint form: "I'm too Z" (comparative with deleted context)
- Intervention: "In what context would this behavior be valuable?"
- Example: "She's too stubborn" → "Imagine how useful that is when a man tries to take advantage of her"
- Ask yourself: "Where/when would this behavior be exactly right?"

**The diagnostic rule:**
- Complex equivalence complaint ("I feel X when Y") → meaning reframe
- Comparative generalization ("I'm too Z") → context reframe

---

### Content Reframing Delivery Principles
- Congruent nonverbal delivery is essential — tone, facial expression, pacing must support the reframe
- Pace the complaint first before delivering the reframe (validate before redirecting)
- Watch for autonomic response: skin flush, muscle relaxation, accessing change = reframe landed
- If accessing sequence changes when you mention the problem again later → the reframe integrated
- Never use a reframe technique on a problem it's not designed for — know your tool

---

### Negotiating Between Parts (Bandler/Grinder)

When the same inverse problem occurs (you can't work because you want to play; you can't play because you feel you should work), you have two parts in conflict — not one "bad" part.

**The negotiation process:**
1. Identify Part X (the one being interrupted) — what is its positive function?
2. Identify Part Y (the one interrupting) — what is ITS positive function?
3. Does Y interrupt X AND does X interrupt Y? If yes → negotiate. If only one way → use six-step reframe on Y instead.
4. Ask Y: "If X didn't interrupt you, would you agree not to interrupt X?"
5. Ask X: "If Y didn't interrupt you, would you agree not to interrupt Y?"
6. Get both parts to agree to a trial period (e.g., 6 weeks). If either becomes dissatisfied, they signal for renegotiation.
7. Ecological check: "Are there any other parts that interrupt these parts, or that utilize these interruptions?"

**Classic use cases:** Insomnia, procrastination, stage fright, impotence, "I want to save money but keep spending," work/play conflict, inability to transition between contexts.

---

### Creating a New Part
Used when the problem isn't a conflicting part or a bad-behaving part — but a **missing** capability entirely. The person has no part that does X.

Steps: define the function needed → find existing parts that could contribute skills → invite the person's unconscious to construct a new integrated part with those resources → future-pace the new part into contexts where it's needed.

---

### Reframing as Sales / Persuasion
Every sales objection is a values statement. The reframe matches the product feature to the client's own stated criteria.

**Formula:**
1. Gather criteria first (what matters to this person?)
2. Listen for objections — each one reveals another criterion
3. Reframe the objection by showing how that same feature satisfies a criterion the person already has
4. Future-pace buyer's remorse before it happens: "Some people will question your choice — here's why you'll feel confident about it"

---

## PART 2 — MIND-LINES / SLEIGHT OF MOUTH (Hall & Bodenhamer)

### The Core Formula
All beliefs have this structure:

```
EB = IS
External Behavior = Internal State (meaning)
```

A belief is a thought you've said "Yes!" to — a frame you've confirmed as real. It commands the nervous system.

To find the formula: listen for **cause-effect** (C-E) words: "because, if, when, so that" and for **complex equivalence** (CEq) words: "is, equals, means, equates to."

**Five eliciting questions:**
- C-E: "How does this create a problem for you?"
- C-E: "What makes it so?"
- CEq: "What does this mean to you?"
- CEq: "What other meanings do you give to this?"
- "How do you know?"

---

### The 7 Directions of Mind-Lines

All reframing moves in one of 7 directions:

1. **Deframe** (down) — pull apart the belief into its component pieces
2. **Content reframe** (horizontal inside) — change EB or IS meaning
3. **Counter reframe** (reflexive) — apply the belief to itself or to counter-examples
4. **Pre-frame** (backward in time) — reframe the prior intention or cause
5. **Post-frame** (forward in time) — redirect to consequences of the belief
6. **Outframe** (up, meta-level) — bring a higher concept to bear on the whole belief
7. **Analogous/story frame** (lateral) — use metaphor, narrative, or analogy

---

### The 20 Mind-Lines (Hall's Expanded Sleight of Mouth)

Applied to any EB=IS belief:

**DEFRAMING (inside the box):**
1. **Chunk Down on EB** — "How specifically do you do/represent that?" (force sensory-specific description, dissolves the abstraction)
2. **Reality Strategy Chunk Down** — "In what sequence do those parts occur? What do you see first, then feel, then say?" (elicit the strategy behind the belief)

**CONTENT REFRAMING:**
3. **Reframe the EB** — "What really IS that behavior? What else qualifies as X?" (same behavior, different label)
4. **Reframe the IS** — "What other state/meaning could we just as well attribute to this EB?" (same behavior, different meaning)

**COUNTER REFRAMING (reflexive):**
5. **Reflexively Apply to Self** — Apply the belief's logic back to the statement itself: "What a [X] statement!" (turns the belief's own logic on itself)
6. **Reflexively Apply to Listener** — "So you're saying that when I [X], you [Y]?" (applies the C-E to the speaker's relationship with you)
7. **Counter-Example** — "Has there ever been a time when that wasn't true? Can you think of one exception?" (find the hole in the universal quantifier)

**PRE-FRAMING (back in time):**
8. **Positive Prior Intention** — "You did/believe that because of [positive purpose behind it]." (honor the protective intent)
9. **Positive Prior Cause** — "You came to believe that to protect yourself from [specific past pain]." (show the cause was understandable)

**POST-FRAMING (forward in time):**
10. **First Outcome** — "If you follow this belief, it leads to..." (reveal the immediate consequence)
11. **Outcome of Outcome** — "And if that happens, then it leads to..." (chain consequences forward)
12. **Eternity Frame** — "Ultimately, this belief leads to... how do you feel about that?" (long-term implication)

**OUTFRAMING (above the box):**
13. **Model of the World** — "Who taught you to think this way? When you see this as just one possible map..." (relativize the belief as a perspective, not reality)
14. **Criteria/Value Frame** — "What's more important to you than this? How does [higher value] affect this?" (override with a higher value)
15. **Allness Frame** — "Always? To everyone? Every single time?" (apply universal quantifier to expose overgeneralization)
16. **Have-To Frame** — "What forces you to think/feel this way? What would happen if you didn't?" (challenge modal operator)
17. **Identity Frame** — "What does this say about you as a person? Do you want to define yourself this way?" (challenge identification)
18. **Other Abstractions** — Bring any other concept to bear: "This is a case of X, isn't it?" (outframe with a different abstraction)
19. **Ecology Frame** — "Does this belief serve you well? Does it enhance your life? Would you recommend it to someone you love?" (systemic utility check)

**ANALOGOUS FRAMING:**
20. **Metaphor/Story Frame** — Tell a story with isomorphic structure to the belief, with a resolution built in. Never explain the point — let them find it.

---

### The Diagnostic Quick Test
To instantly decide WHICH mind-line direction to use:
- If the belief sounds like overgeneralization → Allness Frame (#15) or Counter-Example (#7)
- If it's about identity → Identity Frame (#17) or Reflexive (#5/6)
- If it's self-limiting ("I can't") → Have-To Frame (#16) or Chunk Down (#1/2)
- If it protects from past pain → Positive Prior Intention (#8) or Cause (#9)
- If consequences matter → First Outcome (#10) or Outcome of Outcome (#11)
- When all else fails → Metaphor (#20)

---

## PART 3 — TIME DISTORTION & TIMELINE WORK (Bandler / James)

### Time as a Submodality
Time perception is internally represented spatially — past behind, future ahead (or side to side). The qualities of time (fast vs. slow) have specific submodality signatures.

**How to elicit time submodalities:**
1. Have person recall a "fast time" experience (time flew by)
2. Have person recall a "slow time" experience (time dragged pleasantly)
3. Identify the specific submodality differences — they will differ from standard submodalities (edges of images may move at different rates than centers, etc.)
4. Anchor each state separately

**Applications:**
- Make pleasant experiences feel longer (install slow-time submodalities)
- Make unpleasant tasks pass faster (install fast-time submodalities)
- Practice skills in trance time (hours of subjective practice in minutes of real time)
- Sports: slow the ball, make the target larger (installed as submodality change)

### Contralateral Induction (Bandler)
Moving arms up together, then separating with one pointing/one cupped, then back together, then reversing — creates cerebral hemisphere competition that bypasses conscious resistance and induces altered state rapidly. Based on contralateral vs. isolateral hemispheric control.

### Timeline Redecision
1. Have person locate and visualize their timeline in physical space
2. Float above timeline
3. Float backward past the limiting decision point
4. While above, access and hold a strong resourceful belief/state
5. Drop into the timeline with that resource, then **shoot forward through time** rapidly — days and weeks flashing past, breaking up old generalizations
6. Pop out at present and future
7. Re-place timeline. Test the old decision — it should feel different

**For addiction/stuck patterns:** Have person physically turn and drag the past (which was "behind") into their visual field. See the full history of the pattern. Hear the sound of a door slamming shut. Makes relapse harder by forcing conscious representation of consequences.

### Amplifying Resources into the Future (Bandler's Mega Future Pace)
1. In trance, identify 5 peak resource states
2. Access and fully amplify each one (make bigger, brighter, louder, double, triple)
3. Float above the timeline. Place the 5 resources at intervals into the future (1 week apart, then 4 days, 3, 2, 1, 1 hour apart)
4. When they converge — shoot forward through the timeline into the future
5. Resources integrate and compound as they merge
6. Post-hypnotic suggestion: "Whenever you see a context where you need these resources, they will automatically fire"

---

## PART 4 — HYPERESTHESIA & ALTERED STATES (Bandler)

### Hyperesthesia
Heightened sensory awareness — the opposite of trance numbness. World appears brighter, sounds richer, time slows, detail becomes vivid.

Induced by:
1. Entering deep trance first (to access neurological flexibility)
2. Accessing a memory of heightened natural awareness (a stunning sunset, a moment of peak aliveness)
3. Amplifying that state (double, triple)
4. Installing a post-hypnotic trigger to access it at will
5. Waking the person with the state fully online

**Use in NLP practice:** Enter hyperesthesia before a session — see skin color changes more vividly, hear voice shifts more precisely, notice micro-muscle movements. This IS up-time (100% external sensory attention) at a heightened level.

### Double Induction
Two people simultaneously induce trance using different channels:
- Person 1 (right side, targeting left hemisphere): complex syntax, negations, time words ("before you stop yourself from preventing..."), spoken at double speed
- Person 2 (left side, targeting right hemisphere): childhood phrases, nursery rhyme fragments ("Mary had a little..."), baby tonality, 2-word utterances ("Deeper go. Trance now.")

Result: both hemispheres occupied simultaneously → very rapid, very deep trance. Especially useful for resistant subjects.

---

## PART 5 — NEW CODE NLP (Grinder/DeLozier from Turtles All the Way Down)

### The Core Correction
Classic NLP anchored resources in specific representational channels (visual anchor, kinesthetic anchor). The problem: this ties the resource to content, which is inherently limiting.

New Code principle: **access state without content**. The unconscious selects which resources to apply. The conscious mind only creates the opportunity and then gets out of the way.

### New Code State Games
Physical activities (juggling, peripheral vision walk, alphabet game) that produce a generalized high-performance state — without accessing any specific memory or content. The games occupy conscious attention while the unconscious generates the resource state.

**The New Code Change Format:**
1. Identify problematic context
2. Step briefly into it (feel it)
3. Exit. Access high-performance state via a state game (until the state is strong and generalized)
4. At peak state, step back into the problematic context
5. The unconscious selects appropriate resources and applies them — no direction from the conscious mind
6. The context now "feels different" without knowing why

**Why this matters:** Most NLP techniques require the conscious mind to manage the change. New Code gets the conscious mind out of the loop entirely, which produces more ecological, more generalized, and more lasting change.

### The Five Perceptual Positions (Grinder/DeLozier)
Expanded from the classic 1st/2nd/3rd:

- **1st Position** — Your own eyes, fully associated
- **2nd Position** — The other person's shoes (full somatic entry)
- **3rd Position** — Observer (dissociated from both)
- **4th Position (Dilts)** — The system/field, the "We"
- **5th Position (New Code)** — Complete perceptual openness; no fixed position; "witnessing awareness" that encompasses all positions without fixing in any

New Code training emphasizes 2nd position with full somatic entry — not just imagining what the other person is thinking, but actually feeling their postural and kinesthetic experience in your own body. This produces qualitatively different empathy than cognitive perspective-taking.

---

## PART 6 — META-PROGRAMS (Hall from Cameron-Bandler)

Meta-programs are the filters that determine what we notice, how we sort, and how we respond. They operate below conscious awareness. Unlike strategies, they're not content-specific — they apply across all contexts.

### Primary Meta-Programs (Applied Focus)

**Toward / Away From**
Toward: motivated by possibilities, gains, achievement
Away: motivated by avoiding problems, pain, consequences
*Never try to motivate an Away person with positive vision alone. Show them what they'll lose by NOT acting.*

**Internal / External Reference**
Internal: validates from own judgment — tells you what they think, asks fewer questions, resistant to external feedback
External: needs others' opinions, asks many questions, easily swayed by social proof, may not trust own judgment
*Influencing External: third-party testimonials, expert opinions. Influencing Internal: "You'll know when it's right for you."*

**Options / Procedures**
Options: loves possibilities, hates being locked in, breaks rules, starts many things
Procedures: needs clear steps, follows established paths, finishes what's started, frustrated by ambiguity
*For Options: "Here are several ways you could approach this..." For Procedures: "Here's the exact step-by-step process..."*

**Global / Detail (Chunk Size)**
Global: big picture, overview, patterns, generalizations
Detail: specifics, sequences, precise information
*Mismatch = instant disconnection. Match chunk size before attempting to lead.*

**Match / Mismatch (Sameness / Difference)**
Match: notices similarities, looks for what fits, what's familiar
Mismatch: notices differences, exceptions, what's wrong or unusual
*Mismatch people are natural quality-checkers and skeptics. Use them to test ideas. Don't take their challenge personally.*

**Proactive / Reactive**
Proactive: initiates, just does it, doesn't wait for permission
Reactive: waits, analyzes before acting, responds to others' initiatives
*Language: Proactive = "Do it now." Reactive = "You might want to consider..."*

**In Time / Through Time**
In Time: fully in the present, past is behind/future is ahead (can't easily see the big picture timeline), engaged and spontaneous
Through Time: timeline visible in front of them, can see past and future simultaneously, good at planning, may disconnect from present experience

---

## PART 7 — SUBMODALITIES ADVANCED (Bandler)

### Covert Submodality Elicitation
Before asking directly, watch HOW the person accesses. Observe:
- Which direction they turn their whole body when thinking of the two items
- Breathing changes between accessing
- Facial muscle differences
- Eye focus shifts

This gives you half the submodality information BEFORE you ask a single question. Then when you ask, you can guide them by describing what you've already observed (which sounds like it came from them).

### Emotional Richness via Submodality Engineering
People don't just have one "excitement" or one "confidence." By systematically varying submodalities, you can create dozens of qualitatively distinct versions of any emotion.

**The exercise:** Take a good feeling. Change every submodality systematically — start from the top (change location, then color, then size, then movement, etc.). Some combinations create feelings you've never had before. This is how you can design entirely new emotional states.

### The Belief Submodality Structure (Bandler's Clarification)
A key distinction: changing a thought's submodalities to match your "strong belief" submodalities does NOT automatically create a belief. Beliefs exist at a higher logical level — they require a meta-level "Yes!" (validation) in addition to the representational structure. You can install the structure without installing the confirmation.

**The two-step:** (1) install the submodality structure, THEN (2) access a state of "yes, this is real for me" and anchor it to the new belief structure.

### The Mixed-State Communication (Bandler)
Speaking directly to someone's unconscious while their conscious mind is focused elsewhere. Technique: focus your eyes about 2 inches BEHIND their eyes. Address their unconscious directly: "You, [Name]'s unconscious mind, must be really frustrated with how [Name] treats you..." The person will often show unconscious yes-signals (head nods) while consciously being unaware.

Use to: bypass resistance in highly defended clients, establish unconscious rapport when conscious mind objects, bypass secondary gain.

---

## Quick Pattern Reference

| Pattern | Source | File Reference |
|---------|--------|----------------|
| Content reframing (meaning/context) | Bandler/Grinder Reframing | This file |
| Negotiating between parts | Bandler/Grinder Reframing | This file |
| 20 Mind-Lines / Sleight of Mouth | Hall/Bodenhamer | This file |
| EB=IS belief formula | Hall/Bodenhamer | This file |
| Time distortion submodalities | Bandler Time For A Change | This file |
| Timeline redecision | Bandler/James | This file |
| Amplifying resources into future | Bandler | This file |
| Hyperesthesia induction | Bandler | This file |
| Double induction | Bandler | This file |
| New Code change format | Grinder/DeLozier | This file |
| 5th position (witnessing) | Grinder/DeLozier | This file |
| Full meta-programs (applied) | Hall/Cameron-Bandler | This file |
| Covert submodality elicitation | Bandler | This file |
| Mixed-state communication | Bandler | This file |
| Contralateral induction | Bandler | This file |

---

_Last updated: 2026-04-27_
