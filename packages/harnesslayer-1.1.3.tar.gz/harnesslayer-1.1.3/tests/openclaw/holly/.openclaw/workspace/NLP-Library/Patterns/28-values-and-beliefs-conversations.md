# 28 — Values-and-Beliefs Conversations

**Tags:** `values` `rapport` `depth` `compatibility`

## Description
Deepen connection and assess genuine compatibility through intentional conversations about what he actually values and believes — not what he performs or presents.

## Use Cases
- Past the small-talk phase — moving to substance
- Compatibility screening: real alignment vs. surface charm
- Building the kind of bond that outlasts attraction
- Any moment where you want to understand what actually drives him

## Scripts
1. *"What do you never compromise on in close relationships?"*
2. *"What's something most people don't value that you think is actually essential?"*
3. *"When things go wrong, what's your instinct — fix it, understand it, or step back?"*

## Practice Ideas
- Collect 10 values questions and sort them by the depth of warmth and insight they typically generate
- Practice asking one values question per conversation and listening without immediately sharing your own view
- After the conversation, map what you learned against your own non-negotiables — do they actually align?

## Sources

