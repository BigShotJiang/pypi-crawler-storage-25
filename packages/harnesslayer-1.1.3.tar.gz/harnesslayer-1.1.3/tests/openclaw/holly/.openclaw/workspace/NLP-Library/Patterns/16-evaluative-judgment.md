# 16 — Evaluative Judgment

**Tags:** `qualification` `selectivity` `challenge` `attraction`

## Description
Qualify him rather than only validating him. Signal that your approval is earned, not automatic. Creates genuine challenge and elevates perceived value of your attention.

## Use Cases
- Flirty challenge dynamics where you want to create tension
- When he's becoming complacent or taking your interest for granted
- Screening in early stages — you're deciding, not auditioning
- Rebalancing a dynamic where you've been overly validating

## Scripts
1. *"You're impressive, but I'm still deciding how reliable you are."*
2. *"I like what I've seen so far — but I give that kind of credit slowly."*
3. *"Good answer. That's one for you. I'll need a few more before I'm convinced."*

## Practice Ideas
- Take 5 recent compliments or validations you've given and rewrite them as selective qualifications
- Practice giving genuine appreciation with a built-in condition or question — "That's great… but I'm curious about X"
- Role-play a first date where you actively screen for 3 specific qualities rather than trying to impress

## Sources


