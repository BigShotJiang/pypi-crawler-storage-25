# 20 — Hidden Sexual Signals and Gaze

**Tags:** `nonverbal` `attraction` `sexuality` `presence`

## Description
Use nonverbal attraction cues — eye contact, stillness, pacing, subtle physical presence — to signal desire without explicit pursuit. The body communicates more convincingly than words.

## Use Cases
- In-person chemistry moments where words would over-explain
- Creating sexual tension without saying anything explicit
- Situations where you want to signal interest while maintaining composure
- When verbal flirting has plateaued and you want to deepen the charge

## Scripts
1. *"Say nothing; hold eye contact two seconds longer than usual."* (instruction, not spoken)
2. *"Let the silence sit — don't rescue it."* (internal cue)
3. *"Slow your blinking, relax your jaw, hold the look just past comfortable."* (mirror practice cue)

## Practice Ideas
- Mirror work: practice extended eye contact, a natural pause, and a relaxed half-smile — 5 minutes daily for one week
- In conversations, practice holding eye contact through a full sentence without breaking it at the end
- Notice his micro-reactions when you use stillness instead of words — log what happens

## Sources


