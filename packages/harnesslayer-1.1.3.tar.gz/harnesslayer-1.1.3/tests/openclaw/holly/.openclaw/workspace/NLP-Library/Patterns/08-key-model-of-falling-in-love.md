# 08 — Key Model of Falling in Love

**Tags:** `attraction` `value` `sequencing` `light model`

## Description
The core light-side sequence for naturally raising perceived value and building genuine feelings: value → emotional connection → future contact. Works with, not against, organic attraction.

## Use Cases
- New attraction you want to develop intentionally
- When you want to understand why something worked (or didn't)
- Structuring early interactions to maximize attachment probability
- Foundation pattern — understand this before applying advanced influence

## Scripts
1. *"I'm not trying to impress you; I'm seeing whether we fit."*
2. *"The best connections I've had built slowly — that's what I'm interested in."*
3. *"I think what makes someone unforgettable is how you feel after you leave them."*

## Practice Ideas
- Diagram the sequence for yourself: What communicates your value? → What creates the emotional spark? → What makes him initiate future contact?
- Identify where previous connections broke down in that sequence
- For a current connection, note which stage you're in and what the natural next move is

## Sources


