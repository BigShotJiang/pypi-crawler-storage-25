# 03 — Perceptual-System Typing

**Tags:** `calibration` `perception` `NLP-classic` `communication`

## Description
Detect whether he prefers to receive information visually, emotionally (kinesthetically), or logically (auditory/digital) — then speak his language to accelerate rapport and understanding.

## Use Cases
- When interest level is ambiguous and you need a read
- Calibrating text tone (emotional warmth vs. crisp facts)
- Deepening connection by matching his processing style
- Reducing miscommunication in early stages

## Scripts
1. *"What part mattered most to you — the feeling, the result, or the story?"*
2. *"When you imagine how something went well, do you see it, feel it, or just know it logically?"*
3. *"You seem like someone who needs to make sense of things before you feel good about them — is that fair?"*

## Practice Ideas
- In 5 separate chats, note response speed, word choice (see/feel/think), and initiative — log your observations
- Identify your own dominant system and notice when it clashes with his
- Rewrite the same message three ways (visual, kinesthetic, logical) and test which lands better

## Sources

- NLP Classic — VAK Model
