# 29 — Role Switching

**Tags:** `frame control` `leadership` `polarity` `dynamics`

## Description
Deliberately shift who chases, who leads, who reveals, and who asks — to disrupt predictable dynamics and restore polarity when a connection has stalled.

## Use Cases
- Stalled or predictable dynamic where one person always leads
- Reinvigorating attraction after it's become too comfortable
- Testing his initiative by stepping back from the leading role
- Creating playful tension through unexpected inversions

## Scripts
1. *"Tonight you ask the questions; next time I control the game."*
2. *"I've been leading this whole time — I want to see what you do with the space."*
3. *"I'm stepping back. You decide where this goes."*

## Practice Ideas
- Practice one full conversation with deliberate role inversion — if you usually lead, follow; if you usually share, ask
- Notice which role you default to and practice consciously choosing a different one
- Write two versions of the same interaction: you leading vs. him leading — compare what changes

## Sources

