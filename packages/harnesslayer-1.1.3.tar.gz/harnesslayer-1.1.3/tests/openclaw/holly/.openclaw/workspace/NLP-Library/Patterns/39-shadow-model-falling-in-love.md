# 39 — Shadow Model of Falling in Love

**Tags:** `shadow model` `attachment` `ethics` `advanced`

## Description
Dependency-oriented, manipulation-heavy attachment model. For research and awareness only — not for covert use.

## Use Cases
- Understanding how unhealthy attachment dynamics form
- Recognizing these patterns when they're being used on you
- Academic/analytical study of influence architecture

## Scripts
*(Research only — do not rehearse these covertly)*
1. Study the sequence intellectually: create uncertainty → provide relief → repeat
2. Analyze how intermittent reinforcement builds attachment
3. Recognize: if someone is running this on you, name it

## Practice Ideas
- Analyze the sequence intellectually without rehearsing it deceptively
- Write a "pattern recognition" checklist: signs someone is using shadow attachment on you
- Compare shadow vs light model side by side

## Sources


⚠️ *Ethical warning: covert use risks creating exploitative emotional dependency. Study to recognize, not to deploy.*
