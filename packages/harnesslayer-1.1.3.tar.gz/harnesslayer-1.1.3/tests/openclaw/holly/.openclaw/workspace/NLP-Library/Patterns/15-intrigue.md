# 15 — Intrigue

**Tags:** `intrigue` `mystery` `open loops` `curiosity`

## Description
Create layered curiosity through incomplete but attractive signals. Distinct from mystery (which is about identity) — intrigue is about active curiosity loops that pull him toward you.

## Use Cases
- First 1–3 interactions where you want to stand out
- Generating follow-up questions and messages without asking for them
- Sustaining interest between dates
- Any context where you want him leaning in rather than you chasing

## Scripts
1. *"You'd probably misread me at first."*
2. *"Most people think they have me figured out quickly. They're usually wrong."*
3. *"I have a rule about this that I think you'd find either annoying or fascinating."*

## Practice Ideas
- Practice one-sentence open loops that invite questions rather than supply answers
- Write 5 intrigue hooks — statements that are true, warm, and deliberately incomplete
- For one week: end every text conversation with something that makes him curious to respond

## Sources

