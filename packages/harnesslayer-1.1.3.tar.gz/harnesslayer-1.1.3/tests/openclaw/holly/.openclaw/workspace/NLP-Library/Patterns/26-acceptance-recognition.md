# 26 — Acceptance / Recognition

**Tags:** `recognition` `significance` `rapport` `bonding`

## Description
Give genuine, dignified recognition that acknowledges effort and character rather than just outcomes. People bond most deeply with those who truly see them.

## Use Cases
- Ego-calming in moments of vulnerability or defensiveness
- Deepening emotional bonding in an established connection
- After a difficult conversation — rebuilding warmth through seeing him clearly
- Building loyalty through the experience of being genuinely understood

## Scripts
1. *"I see the effort behind that, not just the result."*
2. *"That wasn't easy to say — I noticed you said it anyway."*
3. *"I don't think most people appreciate how much you actually carry. I do."*

## Practice Ideas
- In 5 conversations this week, practice naming effort, process, or character rather than outcomes
- Write 5 recognition statements for someone you know — make them specific, not generic
- Notice the difference in his response when you recognize the person vs. just the action

## Sources

