# Ericksonian Hypnosis — Techniques & Patterns
_Sources: NLP Patterns of the Hypnotic Techniques of Milton H. Erickson Vol. I & II (Bandler, Grinder, DeLozier); Magic Words in Hypnosis (Nongard); David Gordon - Phoenix; A Teaching Seminar with Milton H. Erickson; Milton Erickson - Time Distortion in Hypnosis; Experiencing Hypnosis (Erickson & Rossi); Script Book Hypnosis; The February Man_
_Added: 2026-04-27_
_Focus: Techniques NOT already in nlp-bandler-dilts.md or nlp-52-cards.md_

---

## Core Erickson Philosophy

- **Utilization:** Whatever the client brings — resistance, behavior, emotion, even hostility — is raw material for trance. Nothing is a problem; everything is usable.
- **Pacing before leading:** Always meet the client exactly where they are before attempting to move them anywhere.
- **Indirect > direct:** The unconscious mind is wiser than the conscious. Bypass the critic with indirection.
- **The unconscious is the ally:** The unconscious already has the resources. The hypnotist's job is to activate them, not install new ones.
- **Mind cannot distinguish imagined from real:** A vividly imagined experience produces the same neurological response as an actual one.

---

## The 4-Tuple Model (Bandler/Grinder/DeLozier)

The primary tool for understanding experience in hypnosis. At any moment, a person's experience consists of:

```
<V, K, At, O>  (Visual, Kinesthetic, Auditory Tonal, Olfactory)
```

Each element can be:
- **e** (externally generated — from the world) or **i** (internally generated — from imagination/memory)
- Located at a **time/space coordinate** (present, past remembered, future imagined)

**Trance = the progressive shift from external to internal experience:**
```
<Ve, Ke, Ae, Oe>  →  <Vi, Ki, Ae, Oe>  →  <Vi, Ki, Ai, Oi>
(waking)              (partial trance)      (deep trance)
```

The last external element remaining is usually `Ae` (the hypnotist's voice) — the only bridge between outer reality and the client's inner world.

**Why this matters:** Match your language to which system the client has online (their R-operator). Speaking in K predicates to a visual person → confusion and resistance.

---

## The R-Operator (Representational System Detection)

People represent experience through a most-valued rep system. Detect it two ways:

**1. Predicate language (unconscious word choice):**
- Visual: see, clear, bright, picture, focus, perspective, look
- Kinesthetic: feel, solid, heavy, grasp, pressure, warm, rough
- Auditory: hear, rings, resonates, sounds, tone, harmony
- Auditory Digital: understand, makes sense, logical, process, know

**2. Eye accessing cues (right-handed):**

| Eye movement | System |
|-------------|--------|
| Up-left | Eidetic (remembered) visual |
| Up-right | Constructed visual |
| Defocused, straight ahead | Visual imagery |
| Level-left | Remembered sound |
| Level-right | Constructed sound |
| Down-left | Auditory digital (internal dialogue) |
| Down-right | Kinesthetic / feelings |

**Also observe:** breathing rate and location (chest = visual; belly = kinesthetic), voice tempo, skin color shifts.

**Application:** Spend the first 5-10 minutes asking questions that presuppose specific rep systems. Watch the accessing cues. Then match all induction language to the client's primary system.

---

## Representational System Overlap (Induction Technique)

Once pacing is established within the client's primary rep system, **overlap** into adjacent systems:

1. Start in primary system (e.g., Visual): "As you see those trees swaying..."
2. Transition to second: "...you can hear the wind moving through the branches..."
3. Then third: "...and feel the cool air on your face..."
4. Then fourth: "...carrying the smell of fresh-cut grass..."

This gracefully leads the client from external to fully internal experience without resistance. The sequence must be verified (watch for unconscious confirming signals — head nods, eye movement, breathing shift) before moving to the next system.

---

## The TOTE Interruption (Pattern Interrupt Induction)

A TOTE (Test-Operate-Test-Exit) is any unconscious behavioral program — a handshake, a greeting, a habitual sequence. These operate below conscious awareness.

**Erickson's handshake interrupt:**
- Extend hand as if to shake → at contact moment, don't complete the shake — instead do something unexpected (adjust clothing, redirect)
- The person is left with an interrupted TOTE, no conscious next step, and zero resources to resist
- In that gap: give the first clear instruction ("Just sit down, close your eyes, take a deep breath")
- The instruction fills the vacuum

**Why it produces deep trance:** The interrupted TOTE leaves the person momentarily without conscious programming. Anything comprehensible offered fills the space with high compliance.

**Note:** Can be done verbally (confusion technique) — a stream of logically connected but ultimately unresolvable sentences that overload conscious processing until the person accepts the first clear suggestion.

---

## The Confusion Technique

A prolonged version of TOTE interruption using language. Erickson would speak in long, meandering, grammatically complex sentences that always seemed to be going somewhere but never quite resolved — until one clear, simple instruction was offered.

**Principle:** Consciousness can hold 7±2 chunks. If you fill those chunks with confusing non-sequiturs, no bandwidth remains for resistance. The first clear signal is grabbed as relief.

**Casual version:** Rapid contradictions, unexpected associations, unfinished sentences — then one sudden clear instruction.

**Formal version (Erickson's):** Long discursive monologue about apparently unrelated topics, slowly steering toward the client's issue, with embedded commands tonal-marked throughout.

---

## Utilization Technique

Erickson's most distinctive principle. **Use the client's presenting behavior — including resistance — as the material for induction.**

**Three types:**
1. **Utilization of cooperation:** Client says "I want to be hypnotized" → pace and lead directly
2. **Utilization of fixed behaviors:** Client is compulsively focused on objects in the room → name each object, gradually slow your own pacing, make them wait for you — their own behavior becomes the induction
3. **Utilization of resistance:** "I can't be hypnotized" → "That's right, and as you keep that thought, you might notice your eyes getting heavier." The resistance is accepted and redirected.

**Key:** Never fight. Absorb and redirect. Every client behavior is data and material.

---

## Trance Induction Components (Session Structure)

### 1. Pre-Talk
- Normalize hypnosis: "It's a natural state you already enter daily"
- Convince via sensory demo: lemon drop exercise (imagine sour taste → saliva forms → "see? your mind affects your body")
- Set expectation for success: "I'm sure you'll do very well" ← this IS a first suggestion
- Resolve misconceptions (not sleep, always in control, always can exit)

### 2. Induction (choose by learning style)
- **Visual:** "Create a mental picture... a clear blue sky..."
- **Auditory:** "Listen to your own thoughts, turning up the volume of stillness..."
- **Kinesthetic:** "Feel the muscles loosen, hands becoming heavier..."
- **Artfully vague (groups):** Use sensory language from all channels, let each person fill their own

### 3. Deepener + Fractionation
**Fractionation:** Take person down → bring slightly up → take deeper than before. The oscillation deepens overall trance.

**Number count with fractionation:**
"10, 9, 8... you're doing so well. 8, 7, 6, 5... doubling the relaxation. 7, 6, 5, 4... all the way down..."
(note: keep going back up before coming down — this IS the fractionation)

**Key phrase: "doubling the sensation of relaxation"** — the concept of doubling is cognitively graspable; "1000 times deeper" isn't.

**Staircase deepener:** "At the top of a majestic staircase. As you step down each stair, you double the sensation of relaxation. Ten... nine..."

### 4. Trance Ratification
Make the client know they're in hypnosis so the critical mind stops questioning:
- **Hypnotic phenomena as proof:** Autogenic warmth/heaviness in hands → ask "Can you feel the warmth or heaviness?" → always yes → "This is hypnosis"
- **Arm catalepsy:** "Your hands are so heavy they cannot lift. The harder you try, the heavier they get" → then immediately deepen
- **Direct suggestion:** "This is what trance feels like. You have created it. You can continue to go deeper."

### 5. Suggestive Therapy (in sequence)
1. **Indirect suggestion** — metaphor, story, parable first (bypasses conscious resistance)
2. **Transitional deepener** — re-ratify trance, deepen
3. **Ego strengthening** — "You're doing perfectly. This is exactly right."
4. **Direct suggestion** — compound (7+ repetitions in varied forms)
5. **Hypnotic phenomena** — age regression/progression, anesthesia, catalepsy (deepens and proves)
6. **Post-hypnotic suggestion**

### 6. Awakening
"As I count from 1 to 5, allow yourself to become more alert, more refreshed... One, becoming aware... Two, stretching... Three, deep breath... Four, eyes opening... Five — totally awake, totally alert, totally refreshed."

### 7. Post-Session
- **Time distortion check** (proof of trance): "How long did that feel?" → almost always shorter than actual time → "That's time distortion — a sign of deep trance"
- Review suggestions with client (compounds them into conscious memory)
- Schedule next session

---

## Rules of Effective Suggestion (Nongard's Applied Erickson)

1. **Positive framing** — never "stop X," always "start Y"
   - Not "quit smoking" → "derive energy from clean oxygen"
   - Not "lose weight" → "eat until your hunger is satisfied, then stop"
   - Not "less pain" → "increasing comfort"

2. **Present tense** — not "you will" but "you are" and "you now"

3. **Compound** — give same suggestion 7+ times in 7+ different ways. First repetition is weak; third is powerful.

4. **Sensory-specific** — engage all modalities. "The sight of... the feel of... the sound of..."

5. **Individualize from client's own words** — clients tell you their magic words. Write down how they describe their goal; use those exact words back.

6. **Dominant emotion** — attach powerful, specific emotion: not "you'll feel good" but "you feel proud, excited, successful"

7. **Single topic per session** — don't try to fix everything at once

8. **Draw on existing strengths** — "You're already loyal to others. You can be equally loyal to yourself."

---

## Post-Hypnotic Suggestions

Suggestions that activate after trance ends, triggered by everyday stimuli:

"Every time you see the color red — a stop sign, a sweater, a phone light — your unconscious is reminded of your ability to feel confident."

"Anytime you hear a phone ring, your subconscious mind recalls this success."

**Principles:**
- Tie to high-frequency neutral stimuli (colors, phone rings, words)
- Phrase in present tense: "this IS a reminder" not "will remind"
- Always include re-hypnosis anchor: "You'll find it even easier to enter this state next time we work together"

---

## Hypnotic Phenomena Toolkit

**Age Regression (Revivification):**
Take client back to a specific memory — not just remembering but re-experiencing. "See yourself at ten years old, before you ever had a cigarette. See yourself going through the years without ever having smoked..."

**Age Progression:**
Move forward into an imagined future where the desired change has already occurred. "See yourself six months from now, having made this change..."

**Arm Catalepsy:**
"As your arm becomes rigid, notice how it becomes impossible to bend — the harder you try, the more rigid it becomes." Used as both phenomena and metaphor for releasing old habits.

**Hypnotic Anesthesia:**
For pain management: never say "pain" — say "increasing comfort" and "your ability to control sensation." Direct attention to comfort, not discomfort.

**Time Distortion:**
Naturally occurs in trance. Used as post-session proof. Can also be induced deliberately for therapeutic work (e.g., making positive experiences feel longer, difficult ones feel shorter).

**Revivification vs. Regression:** Revivification = fully re-experiencing; regression = observing from outside. Both have therapeutic uses.

---

## The Ericksonian Metaphor / Therapeutic Story

Erickson's theory: the unconscious mind hears every story literally and finds its own application. The conscious mind hears the surface story; the unconscious hears the message.

**Structure of an effective therapeutic metaphor:**
1. Isomorphic to the client's problem (similar structure, different content)
2. Protagonist faces an analogous challenge
3. Resolution involves the resource the client needs
4. Told in sensory-specific, present-tense language
5. Left slightly open — don't over-explain the application

**Example structure for a weight loss client:**
"The fruit never has to ask the gardener how much nutrition to use. It listens to Mother Nature. In this same way, you instinctively know when your hunger is satisfied and when to stop."

**Types:**
- Naturalistic (from nature, everyday life)
- Teaching stories (parables with embedded wisdom)
- Client's own stories (their past successes reframed as resources)
- Third-party success stories ("I had a client once who...")

---

## Key Ericksonian Distinctions

**Covert vs. overt pacing:**
- Overt: verbalize what they're experiencing ("as you sit there, you can feel the chair...")
- Covert: match their breathing rhythm, their movement tempo — no words needed

**Up-time strategy:**
Communicating with 100% attention on external sensory experience of the client. All 7±2 conscious chunks dedicated to reading them — no internal dialogue, no planning. The source of Erickson's uncanny responsiveness.

**Complex Equivalence:**
The link between a word and the 4-tuple experience it represents. "Deep trance" means wildly different things to different people. Always establish what the client's specific sensory representation of their desired outcome IS before beginning. (Same principle as Meta Model nominalization work.)

**Minimal model principle (elegance):**
Use the minimum number of distinctions necessary to achieve the outcome. Don't add complexity. The most elegant intervention is the one that works with the fewest steps.

**Transderivational search:**
When given a sufficiently ambiguous statement, the mind automatically searches its entire history of experience for a matching reference structure. Vague language (nominalizations, universal statements) triggers this search — the listener fills the suggestion with their own most relevant experience, making it personal and powerful.

---

## Time Distortion in Hypnosis (Erickson)

Time perception is malleable in trance. Applications:

**Expanding pleasant time:** Suggest that a brief pleasant experience will feel much longer — "in the next few minutes, you can experience what feels like a much longer and restful period of comfort..."

**Compressing unpleasant time:** "This brief discomfort will pass in what seems like a moment..."

**Pseudo-orientation in time (age progression):** Client is oriented to a future time where change has already occurred, then interviewed as if they are that future self. The "future self" describes how they achieved the change — this becomes the treatment plan.

**Time as resource:** Access a time when the desired resource was naturally present. Revivify it, anchor it, bring it to the present.

---

## David Gordon — Therapeutic Patterns (Phoenix)

**Gordon's Erickson model — 4 core therapeutic moves:**

1. **Pace present experience** — undeniably true statements about current state
2. **Access resource state** — locate, in the client's history, a time when they had the needed resource
3. **Future pace** — install the resource into future contexts where it's needed
4. **Utilize naturally occurring phenomena** — use what's present (client's body sensations, behaviors, responses) rather than imposing external structure

**Isomorphic metaphor:** Craft stories structurally identical to the client's problem, with a resolution built in. The unconscious processes the solution even when the conscious mind is following the surface story.

---

## NLP Patterns Vol II — Advanced Concepts

**The Lead System:**
The representational system used to ACCESS or trigger experience (may differ from the most-valued rep system used to PROCESS it). Example: client looks up-left (visual accessing) but expresses the result kinesthetically. The lead system is the key; match your questions/prompts to it.

**Incongruent clients (resistant):**
When verbal and nonverbal communication contradict, the client is incongruent. Techniques:
- **Separate and sort:** Acknowledge both messages explicitly without judgment
- **Meta-comment:** "Part of you seems to want X, while another part seems to want Y. Both make sense."
- **Work with the resistant part first:** Give it respect and voice before attempting to lead

**Calibrated communication loop:**
A rigid, automatic pattern of stimulus-response between hypnotist and client. Useful when established positively (e.g., client automatically deepens when you slow your voice). Dangerous when the loop locks in resistance. Break by: unexpected behavior, silence, change in body position, direct meta-communication.

---

## Quick Reference: Erickson vs. Standard Hypnosis

| Standard | Ericksonian |
|----------|-------------|
| Direct commands | Indirect suggestion |
| Hypnotist controls | Client leads, hypnotist follows |
| Script-based | Utilization of what's present |
| Conscious cooperation needed | Works with or without cooperation |
| Fixed induction | Tailored to individual |
| Resistance = failure | Resistance = resource |
| Surface language | Embedded commands + tonal marking |
| One rep system | Tracks and overlaps all systems |

---

_Last updated: 2026-04-27_
