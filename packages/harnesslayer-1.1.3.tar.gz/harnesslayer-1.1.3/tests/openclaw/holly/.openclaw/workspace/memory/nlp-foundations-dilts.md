# NLP Foundations & Generations — Dilts/NLPU
_Source: NLPU 100 Background of NLP (Dilts, NLP University Press) — official practitioner course booklet_
_Added: 2026-04-27_
_Note: Covers concepts NOT already in nlp-bandler-dilts.md or nlp-patterns.md_

---

## NLP as a Three-Layer System

NLP provides simultaneously:

1. **Epistemology** — a system of knowledge and values (how we know what we know)
2. **Methodology** — processes and procedures for applying that knowledge
3. **Technology** — specific tools and techniques

This matters for coaching: most people encounter NLP only at level 3 (tools). But lasting change needs level 1 (beliefs about what's possible) aligned with levels 2 and 3.

---

## The Two Foundational Premises

Everything in NLP rests on exactly two axioms:

**1. The Map Is Not the Territory**
We can never know reality directly — only our sensory-neurological-linguistic *map* of it. It is not reality that limits or empowers us; it is our map of reality. The goal is not a "correct" map but a *richer* one — one that offers more choices.

**2. Life and Mind Are Systemic Processes**
Human beings, societies, and the universe form an ecology of complex, interdependent systems. Nothing can be completely isolated from the rest of the system. Systems seek self-organizing balance (homeostasis). You cannot change one element without affecting the whole.

Implication: interventions that ignore ecology (the whole system) create problems elsewhere. This is why "ecological check" is built into every major NLP technique.

---

## The Basic Change Formula

```
Present State + Appropriate Resources → Desired State
```

Every NLP technique serves one of three functions:
- **a)** Creating an explicit representation of the *outcome* (desired state)
- **b)** Enriching *sensory experience* (more data, more precision)
- **c)** Adding *flexibility* of internal responses and external behavior

If a technique isn't doing one of these three things, it's not NLP.

---

## The 13 Core NLP Techniques (Bandler & Grinder's Original List)

This is the canonical list from the original practitioner curriculum — the foundation before all the more complex patterns:

1. **Sensory predicate matching** — identify and mirror the most-used VAK language of another person to build rapport and ensure understanding

2. **Pacing via matching/mirroring** — match posture, gesture, facial expression, voice tone and tempo to contribute to rapport

3. **Representational modality translation** — translate experiences across sensory systems to improve communication between people who process differently

4. **Sensory accessing cues** — observe and utilize eye movements and micro-behavioral cues to understand how someone is organizing their experience

5. **Building representational capabilities** — use sensory-specific language and systematic accessing cues to help someone develop new perceptual possibilities

6. **Sensory acuity** — increase precision in perceiving the effects of behavior on others in real time

7. **Sorting incongruent communications** — identify and separate multiple simultaneous (often conflicting) communications to reduce confusion

8. **Anchoring and re-triggering** — establish triggers for positive experiences/resources in one context; re-fire them in other contexts where those resources are needed

9. **Breaking calibrated loops** — interrupt rigid, repetitive stimulus-response patterns between people to introduce new flexibility and choice

10. **Chunking verbal maps** — break down vague/abstract language into specific, behavioral, observable descriptions (Meta Model in applied form)

11. **Framing and reframing** — shift the perceived meaning of a behavior by making its positive intention explicit; separate self from behavior; preserve positive intent while changing the behavioral means

12. **Behavioral flexibility through modeling** — build system flexibility via role-play and behavioral modeling so members can consistently elicit desired responses

13. **Well-formed outcomes** — elicit a high-quality, practical, ecological description of desired states — sensory-specific, positive, self-initiated, ecologically sound

---

## Three Generations of NLP

Understanding which "generation" a technique comes from helps you know *what problem it was designed to solve* and *what its limits are*.

### First Generation NLP (1975–mid 1980s)
- Derived from modeling Satir, Perls, Erickson
- Applied one-on-one, focus entirely on the individual
- Therapist-as-expert model ("NLP done *to* other people")
- Tools: Meta Model, representational systems, accessing cues, anchoring, reframing, Change Personal History, V-K Dissociation, state management
- Focus level: **behavior and capabilities**
- Limitation: can feel manipulative outside therapeutic contexts; doesn't address beliefs/identity/ecology

### Second Generation NLP (mid 1980s–1990s)
- Expanded beyond therapy: negotiation, sales, education, health
- Emphasized relationship between self and others
- New tools: **time lines, submodalities, perceptual positions, meta programs, belief change**
- Focus level: **beliefs, values, higher-level structures**
- Limitation: still primarily individual-focused; limited systemic/ecological scope

### Third Generation NLP (1990s onward — Dilts, Epstein, DeLozier)
- Generative, systemic, focused on identity/vision/mission
- Can be applied to **organizations and cultures**, not just individuals
- Incorporates three "minds": cognitive (brain), somatic (body), field (relational/systemic)
- New frameworks: **S.C.O.R.E. Model, Neurological Levels, Generative NLP, Somatic Syntax**
- Developed via: NLP New Coding (Grinder & DeLozier), Systemic NLP (Dilts & Epstein)
- Focus level: **identity, spirit, whole-system ecology**

---

## S.C.O.R.E. Model (Dilts & Epstein)

A diagnostic and intervention framework. Maps the full structure of a problem situation:

- **S — Symptoms**: the most noticeable, immediate expressions of the present problem state
- **C — Causes**: the underlying elements that produce and maintain the symptoms
- **O — Outcomes**: the specific, desired state or goals to replace the problem state
- **R — Resources**: the elements needed to reach the outcome and address causes
- **E — Effects**: the longer-term results and consequences of achieving the outcome

**How it works:** Symptoms and effects are "surface" (visible). Causes and resources are "deep" (less obvious). Outcomes bridge the two. Effective interventions address causes with resources — not just suppress symptoms.

**Use it:** When someone keeps "fixing" a problem that keeps coming back, they're working at the symptoms level. S.C.O.R.E. forces the diagnosis deeper.

---

## NLP New Coding (Grinder & DeLozier, 1987)

Key departure from classic NLP. Focus shifts from *specific linguistic/behavioral distinctions* to *interactions and relationships between elements in a system*.

Core concepts:
- **States** — the fundamental unit of experience (not behaviors or language)
- **Conscious/unconscious relationship** — change happens when unconscious competence is accessed, not when conscious mind dictates
- **Perceptual positions** — multiple descriptions of the same situation (1st/2nd/3rd/4th)
- **Multiple descriptions** — truth emerges from holding several maps simultaneously, not from finding the "right" one
- **Perceptual filters** — the meta-level patterns that shape what we notice and how we respond

State games (physical activities like juggling, peripheral vision exercises) are used to access high-performance states *without content* — bypassing the cognitive mind's interference.

---

## Somatic Syntax (Dilts & DeLozier)

The body as a cognitive tool, not just a physical container.

Somatic syntax maps how thoughts, emotions, and meanings are expressed and stored in body movement, posture, and gesture — and how moving the body differently can access new cognitive and emotional states.

Key idea: Change the *syntax* (sequence and pattern) of bodily expressions, and you change the meaning and state. This is deeper than "body language" — it's about the body as a *generator* of meaning, not just a reflector of inner state.

---

## Generative NLP (Dilts)

Beyond remedial/therapeutic NLP (fixing problems). Generative NLP is about *creating* — new possibilities, new identities, new futures that didn't exist before.

Distinction:
- **Remedial**: remove obstacles, fix what's broken (first/second gen)
- **Generative**: create what hasn't existed yet; evolve toward vision and mission (third gen)

Requires working at identity and spirit levels — not just behavior/belief.

---

## The "Calibrated Loop" (Classic Code Concept)

A rigid, automatic, unconscious cycle of stimulus-response between two or more people. Each person's behavior automatically triggers the next person's response, which triggers back — with no flexibility or choice in the loop.

Example: Partner A criticizes → Partner B withdraws → Partner A criticizes more → loop continues.

**Breaking it:** Introduce any unexpected element (pattern interrupt), change your own response in the loop, or bring the loop to conscious awareness. Once both parties can *see* the loop, choice returns.

This is why "breaking calibrated loops" (#9 in the core techniques list) is foundational — most stuck relationships are stuck loops.

---

## Change Personal History

A first-generation technique for updating a formative past experience:

1. Identify the current limiting state/response
2. Find the earliest memory associated with that pattern (the "root imprint")
3. Identify what resource was missing in that younger self at the time
4. Build the resource in the present (anchor it)
5. Carry the resource back to the memory — give it to your younger self
6. Re-run the memory with the resource present; notice how the meaning shifts
7. Come forward through time, updating each subsequent related memory with the resource
8. Test: think about the original situation now

Distinction from Reimprinting (which also extends resources to other people in the memory). Change Personal History focuses on resourcing the *self* specifically.

---

## Key Vocabulary Distinctions (often confused)

| Term | Meaning |
|------|---------|
| **Present state** | Where someone is now (problem state, symptom) |
| **Desired state** | Where they want to be (outcome) |
| **Resource state** | A state that provides needed capability |
| **Ecology** | Whether a change works for the *whole* person/system, not just one part |
| **Congruence** | All levels/parts aligned — no internal conflict about the change |
| **Calibration** | Reading another person's state from external cues |
| **Pacing** | Matching current reality to build rapport |
| **Leading** | Shifting direction once rapport is established |
| **Anchor** | A sensory trigger that reliably fires a state |
| **Strategy** | A specific internal sequence of representations that produces an outcome |
| **Well-formed outcome** | A goal that meets all six conditions for achievability |

---

_Last updated: 2026-04-27_
