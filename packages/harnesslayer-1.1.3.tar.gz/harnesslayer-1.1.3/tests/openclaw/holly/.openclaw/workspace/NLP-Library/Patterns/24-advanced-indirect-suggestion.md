# 24 — Advanced Indirect Suggestion

**Tags:** `advanced suggestion` `nested loops` `Milton Model` `future pacing`

## Description
Layer nested implications and future-oriented suggestions to guide someone toward a conclusion or feeling across multiple conversational layers. The most sophisticated form of indirect influence.

## Use Cases
- Serious-relationship escalation — making next steps feel natural and self-motivated
- Shifting a resistant frame over multiple interactions
- Creating the felt sense that a desirable future is already inevitable
- When direct escalation would trigger pushback

## Scripts
1. *"Funny how the right connection makes serious steps feel easy."*
2. *"When two people are actually aligned, the things that seem complicated just… resolve themselves."*
3. *"I think when you find something real, the decision about how to move forward kind of makes itself."*

## Practice Ideas
- Compose 5 "when… then…" suggestion lines (e.g., "When someone feels completely safe, then commitment stops feeling like a risk")
- Practice embedding the suggestion three layers deep: observation → generalization → implication
- Study nested loop structure: open story A → open story B → deliver suggestion → close B → close A

## Sources

- NLP Classic — Milton Model (nested loops, future pacing)
