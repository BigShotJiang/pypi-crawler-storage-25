# 05 — Leading Role

**Tags:** `frame control` `leadership` `standards`

## Description
Hold the directional frame of the interaction instead of chasing, overfunctioning, or reacting. You set the tempo; he decides whether to meet it.

## Use Cases
- Scheduling and logistics where you'd normally over-accommodate
- Re-establishing balance after a period of chasing
- Setting the tone for a new connection from the start
- Anytime you feel the pull to double-text or over-explain

## Scripts
1. *"Thursday works. If not, next week is better."*
2. *"I'll leave that open for you — let me know when you've decided."*
3. *"I'm not in a hurry, but I do need a clear answer before I move things around."*

## Practice Ideas
- Take 5 recent needy or over-accommodating messages and rewrite each as a choice-based message
- Practice stating one preference per day without softening it with apology
- Notice when you're chasing vs. leading — log it for one week without judgment

## Sources

