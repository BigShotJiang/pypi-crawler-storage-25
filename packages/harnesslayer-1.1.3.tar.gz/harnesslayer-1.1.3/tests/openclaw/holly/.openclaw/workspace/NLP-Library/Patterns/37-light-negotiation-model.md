# 37 — Light Negotiation Model (V+V)

**Tags:** `negotiation` `light model` `collaboration` `communication`

## Description
Comfortable, mutual-understanding negotiation style built on shared values. Use in stable, trusting relationships.

## Use Cases
- Stable relationships where both parties are invested
- Reframing a demand into a collaborative ask
- Navigating disagreement without power plays

## Scripts
1. *"What would make this feel good for both of us?"*
2. *"I want us both to walk away from this feeling good. What do you need?"*
3. *"Let's find the version of this that works for both of us."*

## Practice Ideas
- Reframe one current demand into a collaborative ask
- Practice asking "what do you need?" before stating what you need
- Write 3 V+V negotiation openers for common friction points

## Sources
