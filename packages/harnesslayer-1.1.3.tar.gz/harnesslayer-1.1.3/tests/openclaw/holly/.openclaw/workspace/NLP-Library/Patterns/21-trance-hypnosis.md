# 21 — Trance-Hypnosis

**Tags:** `trance` `hypnosis` `Ericksonian` `influence`

## Description
Use rhythm, pacing, sensory imagery, and absorption to gently lower critical resistance and deepen emotional receptivity. Based on Ericksonian hypnosis principles applied conversationally.

## Use Cases
- Emotional deepening — moving a conversation from surface to intimate
- Shifting someone out of analytical mode into felt experience
- Creating moments of shared absorption (the "trance" of deep conversation)
- Softening resistance before a vulnerable or important topic

## Scripts
1. *"Imagine how different this would feel if neither of us were performing."*
2. *"Take a second and really picture what that felt like — not the story of it, the actual feeling."*
3. *"Close your eyes for just a second and notice what your body is doing right now."*

## Practice Ideas
- Read one emotionally resonant story aloud, slowly, with marked pauses and sensory words — notice how the pace affects your own state
- Practice the "pacing and leading" structure: match his current state first, then gradually shift your tone and speed — see if he follows
- Write 3 trance-induction openers using sensory language ("imagine," "picture," "notice," "feel")

## Sources


- Ericksonian Hypnosis — Milton Erickson foundational model
