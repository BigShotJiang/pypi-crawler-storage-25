# 38 — Gift-Creation Scripts

**Tags:** `investment` `scripts` `influence` `language`

## Description
Structured phrasing to evoke generosity and investment without asking directly.

## Use Cases
- Gifts and practical support
- Evoking initiative without demanding it
- Creating investment through implication

## Scripts
1. *"I smiled when I saw it — I realized you'd know exactly which one I'd choose."*
2. *"I never have to explain what I like to people who actually pay attention."*
3. *"Some things just make sense when you know someone well enough."*

## Practice Ideas
- Draft 3 hint lines, 3 soft asks, and 3 direct asks for the same scenario
- Practice implying preference without stating it explicitly
- Identify one situation where a hint would land better than a request

## Sources
