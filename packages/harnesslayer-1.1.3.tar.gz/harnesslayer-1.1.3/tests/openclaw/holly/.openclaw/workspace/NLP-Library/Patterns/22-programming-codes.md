# 22 — Programming / Codes

**Tags:** `programming` `language patterns` `identity` `NLP-advanced`

## Description
Use repeated identity-based phrasing to steer how he sees himself in relation to you — building a self-image that aligns with the behaviors you'd like him to express.

## Use Cases
- Shaping how he thinks of himself as a partner
- Encouraging generosity, initiative, or care through identity framing
- Any moment involving expectations, requests, or desired behavioral change
- Long-term relationship conditioning (use ethically)

## Scripts
1. *"You're the kind of man who likes acting, not delaying."*
2. *"I can tell you're someone who takes care of the people he cares about."*
3. *"That's what I like about you — you don't half-do things."*

## Practice Ideas
- Build 3 identity-based lines targeting different traits: generosity, initiative, attentiveness
- Practice delivering identity lines naturally — not as compliments, but as matter-of-fact observations
- Notice how he responds to having his identity named — does he step into it or resist it?

**Ethical Note:** Programming works by reinforcing self-perception. Use to amplify genuine qualities, not to manufacture behavior that conflicts with his actual values.

## Sources


