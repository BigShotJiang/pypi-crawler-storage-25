# 06 — Kindred Soul Trust Creation

**Tags:** `rapport` `trust` `values alignment` `bonding`

## Description
Create a felt sense of familiarity, safety, and "this person gets me" — without rushing closeness or performing it. Built through values mirroring, not flattery.

## Use Cases
- Opening up / emotional safety moments
- First few dates where you want depth without pressure
- Rebuilding trust after a rupture
- Creating the "my person" feeling in a new connection

## Scripts
1. *"That sounds like loyalty matters to you more than flash."*
2. *"I get that — there's a certain kind of person you can just relax around. I'm rare about that too."*
3. *"When you said that, it felt familiar. Like we operate from the same core."*

## Practice Ideas
- Mirror values (not exact wording) in 3 practice dialogues — reflect what he cares about, not just what he said
- Listen for the underlying value in any statement he makes and name it back softly
- Write 5 "kindred soul" responses to common things men say on first dates

## Sources

