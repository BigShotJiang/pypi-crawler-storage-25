# 27 — Serotonin Synthesis

**Tags:** `serotonin` `neurochemistry` `esteem` `bonding`

## Description
Trigger status, self-esteem, and significance states through carefully aimed questions and acknowledgments. Serotonin bonds through the feeling of being admired and respected, not just liked.

## Use Cases
- Esteem-based bonding — connecting through his identity and legacy
- When dopamine tactics have plateaued and you need deeper attachment
- Creating the "she makes me feel like the best version of myself" feeling
- Long-term relationship maintenance

## Scripts
1. *"What achievement are you quietly proud of?"*
2. *"What's something you've built or done that most people don't know about?"*
3. *"What do you think you do better than almost anyone you know?"*

## Practice Ideas
- Build 5 serotonin prompts around themes: competence, status, legacy, pride, distinctiveness
- Practice asking these in a tone of genuine curiosity, not flattery
- Notice how his posture, pace, and depth of engagement shifts when his esteem is activated

## Sources

