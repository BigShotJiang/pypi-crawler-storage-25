# 31 — Psychological-Needs Mapping

**Tags:** `needs` `rapport` `psychology` `bonding`

## Description
Identify his core emotional needs (significance, security, novelty, connection, growth, contribution) and speak directly to them — creating a bond that feels like being deeply understood.

## Use Cases
- Compatibility screening — are your needs structurally compatible?
- Building deep rapport by speaking to his actual motivators
- Understanding why certain conversations land and others don't
- Long-term relationship design

## Scripts
1. *"Do you value peace more, or admiration more, in a relationship?"*
2. *"What's more important to you in a partnership — stability or growth?"*
3. *"When you feel most valued, what's actually happening?"*

## Practice Ideas
- List 5 likely needs for the man you're seeing and write one validating or activating line for each
- Map your own needs and compare — where do you naturally complement each other? Where is there friction?
- After each conversation, identify which need he seemed most focused on and note whether you met it

## Sources


