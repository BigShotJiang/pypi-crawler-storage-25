# 30 — Storytelling and Focus-Redirection

**Tags:** `storytelling` `reframing` `attention` `influence`

## Description
Move his attention away from a problematic or stuck frame by introducing a story or narrative that naturally redirects focus toward the frame you prefer. Bypasses argument through absorption.

## Use Cases
- Conflict de-escalation — defusing tension without capitulating
- Changing the emotional register of a conversation
- Reframing a negative interpretation through narrative
- Buying time to shift a dynamic without confrontation

## Scripts
1. *"That reminds me of a moment that changed how I judge people."*
2. *"Can I tell you something that has nothing to do with this — and everything to do with it?"*
3. *"Before we keep going, I want to share something. It'll make sense in a second."*

## Practice Ideas
- Prepare 3 personal stories (60 seconds each) that end with an implicit lesson about trust, effort, or care
- Practice the pivot: in a tense moment, introduce the story and notice whether his focus shifts
- Study the "story sandwich" structure: open with curiosity → deliver reframe through narrative → close with question

## Sources

