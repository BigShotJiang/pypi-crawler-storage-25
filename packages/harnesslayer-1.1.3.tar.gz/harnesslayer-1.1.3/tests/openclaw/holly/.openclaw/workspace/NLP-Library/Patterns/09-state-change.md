# 09 — State Change

**Tags:** `emotional influence` `state management` `reframing`

## Description
Shift his emotional state directly rather than debating content or winning arguments. People respond to how they feel, not to logic — change the state, change the outcome.

## Use Cases
- A conversation that's going cold or flat
- Tension or conflict that's becoming circular
- Transitioning from a serious topic to a lighter or warmer one
- Any moment where arguing the facts isn't working

## Scripts
1. *"Let's pause the logic for a second — what actually felt good there?"*
2. *"I don't want to debate this; I want to know how you actually feel about it."*
3. *"Can we just drop the analysis for a minute and check in with what's actually happening between us?"*

## Practice Ideas
- Take one flat or tense topic from this week and practice redirecting it to an emotional register in one sentence
- Write 5 state-change pivots — phrases that acknowledge the current state and gently shift to a warmer one
- Notice in real-time when someone is stuck in their head and practice the pivot without announcing it

## Sources

