# 32 — Flirt

**Tags:** `flirt` `playfulness` `tension` `attraction`

## Description
Use playful emotional stimulation — teasing, light challenge, wit — to create attraction through warmth and tension. Flirting is not niceness; it's charged play.

## Use Cases
- Text exchanges and first dates
- Warming up a conversation that's becoming too transactional
- Establishing a playful baseline that allows for deeper escalation
- Any moment where you want to signal interest without being serious about it

## Scripts
1. *"Careful — I'm starting to think you enjoy this more than you admit."*
2. *"You're getting dangerously close to saying something interesting."*
3. *"I'll give you that one. You've got maybe two more before I stop being impressed."*

## Practice Ideas
- Write 10 flirt lines that tease without insulting — review each for warmth-to-edge ratio
- Practice flirting in low-stakes contexts (coffee shops, casual conversations) to build muscle
- Study the formula: warm observation + light challenge + implied appreciation = good flirt

## Sources

