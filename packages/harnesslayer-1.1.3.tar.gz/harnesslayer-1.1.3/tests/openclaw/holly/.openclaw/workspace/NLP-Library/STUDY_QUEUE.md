# NLP Master Study Program

## Program Rules
- The main program covers universal NLP communication, influence, perception, and change-work skills.
- Daily lessons use this 60-day order.
- Practice is scenario-based. No written reports are required.
- Holly should create situations, wait for the user's answer, then refine the answer.

---

## Pattern Count by Source

| Source | Patterns |
|--------|----------|
| 52 Ericksonian language cards | 37 |
| Meta Model violations | 13 |
| Milton Model patterns | 16 |
| Sleight of Mouth / Mind-Lines | 20 |
| Reframing types | 8 |
| Core techniques | 13 |
| Submodality techniques | 6 |
| Anchoring variations | 4 |
| Perceptual positions | 5 |
| Logical levels | 6 |
| Meta-programs | 7 |
| Erickson trance/hypnosis techniques | 14 |
| Timeline / time distortion | 5 |
| New Code NLP | 4 |
| Modeling & strategy elicitation | 4 |
| Rapport & calibration | 5 |
| **TOTAL** | **~167 distinct patterns** |

---

## 60-Day Master Program
Organized in 5 phases. Each day = one pattern, one drill, one real-world application.

---

### PHASE 1 — FOUNDATIONS (Days 1–12)
*Build the perceptual infrastructure. See the world differently before trying to change it.*

| Day | Pattern | Source | Focus |
|-----|---------|--------|-------|
| 1 | The Map Is Not the Territory | Bandler/Grinder | Your model of reality ≠ reality |
| 2 | Representational Systems (VAK + Ad) | Bandler/Grinder | How people process information |
| 3 | Sensory Acuity — Calibration | Bandler/Grinder | Read before you speak |
| 4 | Eye-Accessing Cues | Bandler/Grinder | Watch how people think |
| 5 | Predicate Language Detection | Bandler/Grinder | Hear the system behind the words |
| 6 | Rapport: Matching & Mirroring | Bandler/Grinder | Get in sync without mimicking |
| 7 | Pacing & Leading | Bandler/Grinder | Meet them first, move them second |
| 8 | Crossover Mirroring | Bandler/Grinder | Rapport without detection |
| 9 | States — What They Are & How They Drive Behavior | Bandler | State = behavior's upstream cause |
| 10 | The TOTE Model | Bandler/Grinder | How goals actually work in the brain |
| 11 | Well-Formed Outcomes | Bandler/Dilts | Goals that your nervous system can achieve |
| 12 | Presuppositions of NLP | Bandler/Grinder | The operating system |

---

### PHASE 2 — PRECISION LANGUAGE: META MODEL (Days 13–22)
*Learn to hear what's missing, distorted, or overgeneralized in how people talk — including yourself.*

| Day | Pattern | Source | Focus |
|-----|---------|--------|-------|
| 13 | Meta Model Overview + Deletions | Bandler/Grinder | Unspecified nouns, verbs, comparisons |
| 14 | Distortions: Nominalization | Bandler/Grinder | Frozen processes masquerading as things |
| 15 | Distortions: Mind Reading & Cause-Effect | Bandler/Grinder | "You make me feel…" |
| 16 | Distortions: Presuppositions & Complex Equivalence | Bandler/Grinder | Assumed truth |
| 17 | Generalizations: Universal Quantifiers | Bandler/Grinder | Always, never, everyone |
| 18 | Generalizations: Modal Operators | Bandler/Grinder | Can't, must, should |
| 19 | Lost Performative & Mind Reading | Bandler/Grinder | "It's wrong to…" |
| 20 | Meta Model in Real Conversation (drill) | Bandler/Grinder | One question, precision only |
| 21 | Meta Model — Grinder's 5 Pointers | Grinder | Distilled to what actually matters |
| 22 | Chunking: Up, Down, Lateral | Bandler/Dilts | Navigate abstraction levels at will |

---

### PHASE 3 — INFLUENCE LANGUAGE: MILTON MODEL + 52 CARDS (Days 23–40)
*The art of speaking directly to the unconscious. Indirection, implication, suggestion.*

| Day | Pattern | Source | Focus |
|-----|---------|--------|-------|
| 23 | Milton Model Overview + Pacing Current Experience | Bandler/Grinder | Undeniably true → suggestion |
| 24 | Embedded Commands + Tonal Marking | Bandler/Grinder | The hidden instruction in plain language |
| 25 | "You may or may not…" / "Or not" endings | 52-card reference | Resistance-proof phrasing |
| 26 | "Yet" / "Sooner or later" / Temporal Presuppositions | 52-card reference | Presuppose inevitability |
| 27 | Truisms + Yes-Set (Fact/Fact/Fact → Suggestion) | 52-card reference/Bandler | Agreement habit before the ask |
| 28 | Double Bind | Bandler/Grinder | Both options lead where you want |
| 29 | Conversational Postulate | Bandler/Grinder | Questions that function as commands |
| 30 | Tag Questions + Soft Negations | 52-card reference | "…is it not?" / "you don't have to" |
| 31 | Cause-Effect Linkage ("If you… then…" / "As you… you…") | 52-card reference/Bandler | Chain behaviors to states |
| 32 | Quote Pattern | 52-card reference | Deliver messages through others' mouths |
| 33 | Utilization — Use What's Present | Erickson | Nothing is resistance; everything is material |
| 34 | Transderivational Search / Nominalization as Invitation | Bandler/Grinder | Vague language triggers personal meaning |
| 35 | "How would it feel if…" / "What happens when…" | 52-card reference | Internal search creates the experience |
| 36 | "Some people…" / Third-Person Insertion | 52-card reference | They check if they're one of those people |
| 37 | Indirect Suggestion — Basic (Milton Model applied) | Bandler/Erickson | Suggest without commanding |
| 38 | Nested Loops + Advanced Indirect Suggestion | Bandler | Layer implications across conversational levels |
| 39 | Future Pacing | Bandler | Install a behavior in a future context |
| 40 | Therapeutic Metaphor / Story Construction | Erickson/Gordon | Change through isomorphic narrative |

---

### PHASE 4 — CHANGE WORK: REFRAMING, BELIEF CHANGE, SUBMODALITIES (Days 41–52)
*The engineering layer. How to actually change a response, a belief, a stuck pattern.*

| Day | Pattern | Source | Focus |
|-----|---------|--------|-------|
| 41 | Content Reframing — Meaning Reframe | Bandler/Grinder | Same behavior, different meaning |
| 42 | Content Reframing — Context Reframe | Bandler/Grinder | Same behavior, different context |
| 43 | Six-Step Reframe | Bandler/Grinder | Work with the part, not against it |
| 44 | Negotiating Between Parts | Bandler/Grinder | Two parts in conflict → truce protocol |
| 45 | Sleight of Mouth — Deframe + Chunk Down | Dilts/Hall | Dissolve the belief's architecture |
| 46 | Sleight of Mouth — Content Reframe (EB / IS) | Dilts/Hall | Shift meaning or context in real-time conversation |
| 47 | Sleight of Mouth — Counter Reframe + Reflexive | Dilts/Hall | Apply the belief to itself |
| 48 | Sleight of Mouth — Pre-Frame + Post-Frame | Dilts/Hall | Before and after the belief |
| 49 | Sleight of Mouth — Outframe (Identity, Ecology, Allness) | Dilts/Hall | Go above the belief |
| 50 | Submodalities — Elicitation | Bandler | Find the structure of the experience |
| 51 | Submodality Belief Change (+ Driver Submodalities) | Bandler | Change the filing system, not the content |
| 52 | Swish Pattern | Bandler | Redirect an automatic negative trigger |

---

### PHASE 5 — ADVANCED & INTEGRATION (Days 53–60)
*The master layer: states, time, modeling, real-world integration.*

| Day | Pattern | Source | Focus |
|-----|---------|--------|-------|
| 53 | Anchoring — Install, Stack, Collapse, Chain | Bandler/Grinder | Trigger states on demand |
| 54 | Fast Phobia Cure / V-K Dissociation | Bandler | Rapid trauma/phobia resolution |
| 55 | Timeline — Elicitation + Redecision | Bandler/James | Locate and update formative decisions |
| 56 | Time Distortion — Submodalities of Fast/Slow Time | Bandler | Reshape subjective time experience |
| 57 | Logical Levels — Diagnosis + Alignment | Dilts | Find the right level for the intervention |
| 58 | Meta-Programs — Detection + Matching | Cameron-Bandler/Hall | Adapt to how someone filters reality |
| 59 | Modeling — The Full Process | Bandler/Grinder | Reverse-engineer excellence |
| 60 | New Code NLP — State Without Content | Grinder/DeLozier | The body leads; conscious mind follows |

---

## Progress Tracker

| Day | Pattern | Status | Notes |
|-----|---------|--------|-------|
| 1 | The Map Is Not the Territory | ⬜ Not started | Starter config |

---

*Last sanitized for starter config.*