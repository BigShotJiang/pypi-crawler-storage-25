# 36 — Shadow Negotiation Model

**Tags:** `negotiation` `shadow model` `tactics` `advanced`

## Description
Multi-step tactical negotiation for difficult or unequal dynamics. Use when direct asks fail or backfire.

## Use Cases
- Hot-cold or resistant dynamic
- When a direct request would create pushback
- Rebalancing a lopsided power frame

## Scripts
1. *"I won't push now; I'll return when the frame is better."*
2. *"I'm not in a hurry. The right moment will make this easier for both of us."*
3. *"Let's set this aside — and revisit it when we're both in a better place."*

## Practice Ideas
- Map a 3-move negotiation sequence instead of one direct ask
- Identify one current situation where patience > pressure
- Write the "when the frame is better" version of a message you've been tempted to send

## Sources

⚠️ *Ethical note: use only with awareness of consent and mutual respect. Not a covert control tool.*
