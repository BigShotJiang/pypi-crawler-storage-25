from pathlib import Path
from harnesslayer import Harnesslayer

client = Harnesslayer(api_key="dk-19bc360c-6f8d-4d62-97ec-a3faec608ec1")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-4954488c-bf3a-4f12-8dc6-33aa0f332db3")
