from __future__ import annotations

import io
import zipfile
from pathlib import Path

from ..exceptions import HarnesslayerError


class DriftstoneZip:
    @staticmethod
    def _resolve_out_path(out_path: str) -> Path:
        if not out_path or not isinstance(out_path, str):
            raise HarnesslayerError("out_path must be a non-empty string")

        path = Path(out_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()
        if root.exists() and not root.is_dir():
            raise HarnesslayerError(f"out_path must be a directory: {root}")

        root.mkdir(parents=True, exist_ok=True)
        return root

    @staticmethod
    def _extract_zip(zip_bytes: bytes, out_dir: Path) -> None:
        with zipfile.ZipFile(io.BytesIO(zip_bytes), mode="r") as archive:
            for zip_info in archive.infolist():
                if not zip_info.filename:
                    continue

                destination = (out_dir / zip_info.filename).resolve()
                if not destination.is_relative_to(out_dir):
                    raise HarnesslayerError(f"Archive contains unsafe path: {zip_info.filename}")

                if zip_info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(zip_info, mode="r") as source, destination.open("wb") as target:
                    target.write(source.read())
