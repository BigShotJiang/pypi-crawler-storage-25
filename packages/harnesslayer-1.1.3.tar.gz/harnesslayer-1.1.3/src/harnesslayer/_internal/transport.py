from __future__ import annotations

from typing import Any, Literal, cast
import httpx

from .utils import logger
from ..exceptions import (
    HarnesslayerAPIError, 
    HarnesslayerHTTPError, 
    HarnesslayerResponseError
)

Method = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]

class Transport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float,
        user_agent: str,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.timeout = timeout
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": user_agent,
        }
        self._owns_http_client = http_client is None
        self._http = http_client or httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers=self._headers,
        )

    @property
    def headers(self) -> dict[str, str]:
        return self._headers.copy()

    def close(self) -> None:
        if self._owns_http_client:
            self._http.close()

    @staticmethod
    def _parse_response(response: httpx.Response) -> dict[str, Any]:
        try:
            decoded = response.json()
        except ValueError as exc:
            raise HarnesslayerResponseError(
                f"Harnesslayer API returned non-JSON response (status={response.status_code})"
            ) from exc

        if not isinstance(decoded, dict):
            raise HarnesslayerResponseError(
                "Harnesslayer API returned an unexpected response payload"
            )

        return cast(dict[str, Any], decoded)

    def request(
        self,
        method: Method,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = payload or {}

        try:
            kwargs: dict[str, Any] = {
                "method": method,
                "url": path.lstrip("/"),
                "headers": self._headers,
            }
            if method == "GET":
                kwargs["params"] = payload
            else:
                kwargs["json"] = payload

            response = self._http.request(**kwargs)
        except httpx.HTTPError as exc:
            raise HarnesslayerHTTPError(f"HTTP request failed: {exc}") from exc

        data = self._parse_response(response)

        logger.debug(
            "Received response from Harnesslayer API (status=%d, data=%s)",
            response.status_code,
            data,
        )

        if response.status_code >= 400:
            raise HarnesslayerAPIError(
                f"Harnesslayer API returned error status {response.status_code}: {data}"
            )

        if data.get("success") is False:
            message = str(data.get("error") or data.get("message") or "Request failed")
            raise HarnesslayerAPIError(f"Harnesslayer API error: {message}")

        return data
