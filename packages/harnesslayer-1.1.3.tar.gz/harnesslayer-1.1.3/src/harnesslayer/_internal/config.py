from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from typing import Any, Optional, TypedDict

from ..exceptions import HarnesslayerError
from ..models.app import ApplicationType
from .utils import safe_parse_json

IGNORED_PARTS = {"__MACOSX"}
CloneTransformValue = dict[str, Any] | str

class ConfigPathData(TypedDict):
    type: ApplicationType
    path: Path

class UploadFilePayload(TypedDict):
    name: str
    hash: str

class HarnesslayerConfig:
    @staticmethod
    def _validate_clone_transform(
        *,
        transform: Optional[dict[str, CloneTransformValue]],
    ) -> dict[str, CloneTransformValue]:
        if transform is None:
            return {}

        if not isinstance(transform, dict):
            raise HarnesslayerError("transform must be a dictionary")

        normalized: dict[str, CloneTransformValue] = {}
        for file_path, patch in transform.items():
            if not isinstance(file_path, str) or not file_path.strip():
                raise HarnesslayerError("transform keys must be non-empty strings")

            normalized_file_path = file_path.strip().replace("\\", "/")
            if normalized_file_path.startswith("/") or ".." in normalized_file_path.split("/"):
                raise HarnesslayerError(f"Invalid transform file path: {file_path}")

            normalized_file_path_lower = normalized_file_path.lower()
            if normalized_file_path_lower.endswith(".json"):
                if not isinstance(patch, dict):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be a JSON object patch"
                    )
            elif normalized_file_path_lower.endswith(".md"):
                if not isinstance(patch, str):
                    raise HarnesslayerError(
                        f"transform['{file_path}'] must be Markdown string content"
                    )
            else:
                raise HarnesslayerError(
                    f"transform target must be a .json or .md file: {file_path}"
                )

            normalized[normalized_file_path] = patch

        return normalized

    @staticmethod
    def _validate_config_path(config_path: str) -> ConfigPathData:
        path = Path(config_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()

        if not root.exists():
            raise HarnesslayerError(f"Config path does not exist: {root}")
        if not root.is_dir():
            raise HarnesslayerError(f"Config path must be a directory: {root}")

        if config_path.endswith(".claude"):
            HarnesslayerConfig._validate_claude_config_path(root)
            app_type: ApplicationType = "claude"
        elif config_path.endswith(".openclaw"):
            HarnesslayerConfig._validate_openclaw_config_path(root)
            app_type = "openclaw"
        else:
            raise HarnesslayerError(f"Config path must end with .claude or .openclaw: {config_path}")

        return {
            "type": app_type,
            "path": root,
        }

    @staticmethod
    def _validate_claude_config_path(root: Path) -> None:
        agent_json_path = root / "agent.json"
        if not agent_json_path.exists() or not agent_json_path.is_file():
            raise HarnesslayerError(f"Invalid Agent config path: missing agent.json in '{root}'")

        environment_json_path = root / "environment.json"
        if not environment_json_path.exists() or not environment_json_path.is_file():
            raise HarnesslayerError(f"Invalid Agent config path: missing environment.json in '{root}'")

        raw_agent_json = agent_json_path.read_text()
        agent_json = safe_parse_json(raw_agent_json)
        if not isinstance(agent_json, dict):
            raise ValueError("agent.json is not a valid JSON object")

        if "skills" in agent_json and isinstance(agent_json["skills"], list):
            for skill in agent_json["skills"]:
                if not isinstance(skill, dict) or "type" not in skill:
                    raise ValueError("Each skill in agent.json must be an object with a 'name' field")

                if skill["type"] != "anthropic":
                    raise ValueError(
                        "Only skills of type 'anthropic' are supported in agent.json, "
                        "if you want custom skills you must add them as a folder under 'skills' directory"
                    )

        for item in root.iterdir():
            if item.name in IGNORED_PARTS:
                continue
            if item.is_dir() and item.name != "skills":
                raise HarnesslayerError(f"Invalid Agent config path: unexpected subdirectory '{item.name}' in '{root}'")
            if item.is_file() and item.name not in {"agent.json", "environment.json"}:
                raise HarnesslayerError(f"Invalid Agent config path: unexpected file '{item.name}' in '{root}'")

        skills_dir = root / "skills"
        if skills_dir.exists() and skills_dir.is_dir():
            for skill_dir in skills_dir.iterdir():
                if skill_dir.name in IGNORED_PARTS:
                    continue
                if not skill_dir.is_dir():
                    raise HarnesslayerError(f"Invalid Agent config path: skill '{skill_dir.name}' is not a directory in '{root}'")
                skill_md_file = skill_dir / "SKILL.md"
                if not skill_md_file.exists() or not skill_md_file.is_file():
                    raise HarnesslayerError(f"Invalid Agent config path: missing SKILL.md in skill '{skill_dir.name}' in '{root}'")

    @staticmethod
    def _validate_openclaw_config_path(root: Path) -> None:
        openclaw_config_file = root / "openclaw.json"
        if not openclaw_config_file.exists() or not openclaw_config_file.is_file():
            raise HarnesslayerError(f"Invalid OpenClaw config path: missing openclaw.json in '{root}'")

    @staticmethod
    def _create_upload_files_payload(root: Path) -> list[UploadFilePayload]:
        upload_files: list[UploadFilePayload] = []

        for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
            relative_path = path.relative_to(root)
            if any(part in IGNORED_PARTS for part in relative_path.parts):
                continue

            if not path.is_file():
                continue

            upload_files.append({
                "name": relative_path.as_posix(),
                "hash": sha256(path.read_bytes()).hexdigest(),
            })

        if not upload_files:
            raise HarnesslayerError(f"Config path contains no files to upload: {root}")

        return upload_files
