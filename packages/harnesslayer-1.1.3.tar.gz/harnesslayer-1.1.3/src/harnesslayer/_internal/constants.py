DEFAULT_API_BASE_URL = "https://api.harnesslayer.ai"

AVAILABLE_APP_TYPES = ("claude", "openclaw")

AVAILABLE_CHANNEL_TYPES = ("api", "imessage")
