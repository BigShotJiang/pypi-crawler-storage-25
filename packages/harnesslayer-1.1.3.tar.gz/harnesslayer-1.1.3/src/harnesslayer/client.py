from __future__ import annotations

from typing import Any, Literal

import httpx
from driftstone import Driftstone

from ._internal.constants import DEFAULT_API_BASE_URL
from ._internal.utils import logger, set_debug
from ._internal.transport import Method, Transport
from .resources.app import HarnesslayerApp
from .resources.organization import HarnesslayerOrganization
from .resources.response import HarnesslayerResponse
from .version import __version__


class Harnesslayer:
    def __init__(
        self,
        api_key: str,
        *,
        version: Literal["v1"] = "v1",
        timeout: float = 600.0,
        debug: bool = False,
        http_client: httpx.Client | None = None,
        driftstone_http_client: httpx.Client | None = None,
    ) -> None:
        self.debug = debug
        set_debug(self.debug)
        
        logger.info("Initializing Harnesslayer client with provided API key")

        trimmed_key = api_key.strip()
        if not trimmed_key:
            raise ValueError("api_key must be provided")
        if not trimmed_key.startswith("dk-"):
            raise ValueError("Invalid Harnesslayer API key")

        self.api_key = trimmed_key
        self.api_version = version
        self.timeout = timeout
        self.base_url = f"{DEFAULT_API_BASE_URL}/{self.api_version}"

        self._transport = Transport(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.timeout,
            user_agent=f"Harnesslayer-python/{__version__}",
            http_client=http_client,
        )
        self._driftstone_client = Driftstone(
            api_key=self.api_key,
            version=version,
            timeout=self.timeout,
            debug=self.debug,
            http_client=driftstone_http_client,
        )

    def close(self) -> None:
        try:
            self._transport.close()
        finally:
            self._driftstone_client.close()

    def __enter__(self) -> "Harnesslayer":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _request(
        self,
        method: Method,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self._transport.request(method, path, payload)

    @property
    def app(self) -> HarnesslayerApp:
        return HarnesslayerApp(self)

    @property
    def organization(self) -> HarnesslayerOrganization:
        return HarnesslayerOrganization(self)

    @property
    def response(self) -> HarnesslayerResponse:
        return HarnesslayerResponse(self)
