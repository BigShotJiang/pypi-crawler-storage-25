from __future__ import annotations

import time
from typing import Any, Optional, Sequence
from uuid import uuid4

import httpx

from .._internal.config import CloneTransformValue, HarnesslayerConfig
from .._internal.zip import DriftstoneZip
from ..models.sync import SyncStrategy
from ..models.version import HarnesslayerVersionCompareModel
from ..exceptions import (
    HarnesslayerError, 
    HarnesslayerResponseError, 
    HarnesslayerAPIError
)
from ._base import AppBase

class HarnesslayerVersion(AppBase):
    def create(
        self, 
        *, 
        version_id: Optional[str] = None, 
        version_path: Optional[str] = None
    ) -> bool:
        if not version_id and not version_path:
            raise HarnesslayerError("Either version_id or version_path must be provided")
        
        if version_id is not None and not version_id.startswith("ver-"):
            raise HarnesslayerError("version_id is invalid")
        
        payload = {
            "appId": self._app_id,
        }

        if version_id:
            payload["versionId"] = version_id
            
        elif version_path:
            version_id = f"ver-{uuid4()}"

            path_data = HarnesslayerConfig._validate_config_path(version_path)

            files = HarnesslayerConfig._create_upload_files_payload(path_data["path"])

            repo = self._driftstone_client.repos.get(self._app_id)

            upload = self._driftstone_client.repos.create_upload(
                repo=repo.id,
                branch="main",
                storage_dir=version_id,
                files=files,
            )

            self._driftstone_client.upload_files(upload, files, path_data["path"])

            self._driftstone_client.repos.complete_upload(repo.id, upload.upload_id)

            payload["versionId"] = version_id

        self._client._request("POST", "/version/create", payload)

        return True

    def download(
        self,
        out_path: str,
        version_id: Optional[str] = None,
    ) -> bool:
        target_version_id = version_id.strip() if isinstance(version_id, str) else version_id

        if not target_version_id:
            app_res = self._client._request("GET", f"/app/{self._app_id}")

            head_version_id = app_res["data"].get("headVersionId")
            if not isinstance(head_version_id, str) or not head_version_id.strip():
                raise HarnesslayerResponseError("Missing headVersionId for app")

            target_version_id = head_version_id

        if not target_version_id:
            raise HarnesslayerError("version_id must be provided or app must have a head version")

        if not target_version_id.startswith("ver-"):
            raise HarnesslayerError("version_id is invalid")

        download_res = self._client._request("GET", f"/version/download/{target_version_id}")

        download_url = download_res["data"].get("url")
        if not isinstance(download_url, str) or not download_url.strip():
            raise HarnesslayerResponseError("Missing download URL for version")

        response = httpx.get(
            download_url,
            timeout=self._client.timeout,
            follow_redirects=True,
        )
        if response.status_code >= 400:
            raise HarnesslayerAPIError("Failed to download version archive")

        out_dir = DriftstoneZip._resolve_out_path(out_path)
        DriftstoneZip._extract_zip(response.content, out_dir)

        return True

    def clone(
        self,
        *,
        version_id: Optional[str] = None,
        transform: Optional[dict[str, CloneTransformValue]] = None,
    ) -> bool:
        try:
            target_version_id = version_id.strip() if isinstance(version_id, str) else version_id

            if not target_version_id:
                app_res = self._client._request("GET", f"/app/{self._app_id}")

                head_version_id = app_res["data"].get("headVersionId")
                if not isinstance(head_version_id, str) or not head_version_id.strip():
                    raise HarnesslayerResponseError("Missing headVersionId for app")

                target_version_id = head_version_id

            if not target_version_id:
                raise HarnesslayerError("version_id must be provided or app must have a head version")

            if not target_version_id.startswith("ver-"):
                raise HarnesslayerError("version_id is invalid")

            new_version_id = f"ver-{uuid4()}"
            transforms = HarnesslayerConfig._validate_clone_transform(transform=transform)

            copy_job = self._driftstone_client.repos.copy_directory(
                self._app_id,
                source_dir=target_version_id,
                dest_dir=new_version_id,
                transforms=transforms,
                archive=True,
            )

            deadline = time.monotonic() + max(float(self._client.timeout), 1.0)
            while True:
                copy_status = self._driftstone_client.repos.get_copy_status(
                    self._app_id,
                    copy_job.run_id,
                )

                if copy_status.status == "completed":
                    if isinstance(copy_status.result, dict) and copy_status.result.get("noChanges") is True:
                        return False
                    break

                if copy_status.status == "failed":
                    error_message = "Version clone failed"
                    if isinstance(copy_status.result, dict):
                        raw_error = copy_status.result.get("error")
                        if isinstance(raw_error, str) and raw_error.strip():
                            error_message = raw_error.strip()
                    raise HarnesslayerAPIError(error_message)

                if copy_status.status != "running":
                    raise HarnesslayerResponseError(
                        f"Unexpected version clone status: {copy_status.status}"
                    )

                if time.monotonic() >= deadline:
                    raise HarnesslayerAPIError(
                        f"Timed out waiting for version clone run {copy_job.run_id}"
                    )

                time.sleep(1.0)

            self._client._request("POST", "/version/create", {
                "appId": self._app_id,
                "versionId": new_version_id,
            })

            return True
        except HarnesslayerError:
            return False
        except Exception as e:
            raise e

    def sync(
        self, 
        strategy: SyncStrategy = "manual",
        *,
        profile_ids: Optional[Sequence[str]] = None,
    ) -> bool:
        if strategy not in {"manual", "current", "incoming", "smart"}:
            raise HarnesslayerError("Invalid sync strategy")

        payload: dict[str, Any] = {
            "appId": self._app_id,
            "strategy": strategy,
        }
        if profile_ids is not None:
            if isinstance(profile_ids, (str, bytes)):
                raise HarnesslayerError("profile_ids must be a sequence of profile ID strings")
            
            normalized_profile_ids = []
            for profile_id in profile_ids:
                if not isinstance(profile_id, str) or not profile_id.strip():
                    raise HarnesslayerError("profile_ids must contain only non-empty strings")
                normalized_profile_ids.append(profile_id.strip())

            if not normalized_profile_ids:
                raise HarnesslayerError("profile_ids must contain at least one profile ID")
            
            payload["profileIds"] = normalized_profile_ids

        sync_res = self._client._request("POST", "/version/sync", payload)

        error = sync_res.get("error")
        if error:
            raise HarnesslayerAPIError(f"Failed to sync version: {error}")

        return True

    def compare(
        self,
        *,
        version_id: str,
        state_id: str,
        context_lines: int = 3,
        max_file_bytes: int = 512 * 1024,
    ) -> HarnesslayerVersionCompareModel:
        if not isinstance(version_id, str) or not version_id.strip():
            raise HarnesslayerError("version_id must be provided")
        
        version_id = version_id.strip()
        if not version_id.startswith("ver-"):
            raise HarnesslayerError("version_id is invalid")

        if not isinstance(state_id, str) or not state_id.strip():
            raise HarnesslayerError("state_id must be provided")
        
        state_id = state_id.strip()
        if not state_id.startswith("state-"):
            raise HarnesslayerError("state_id is invalid")

        if not isinstance(context_lines, int) or context_lines < 0 or context_lines > 20:
            raise HarnesslayerError("context_lines must be an integer between 0 and 20")
        
        if not isinstance(max_file_bytes, int) or max_file_bytes < 0:
            raise HarnesslayerError("max_file_bytes must be a non-negative integer")

        response = self._client._request("POST", "/version/compare", {
            "versionId": version_id,
            "stateId": state_id,
            "contextLines": context_lines,
            "maxFileBytes": max_file_bytes,
        })
        
        data = response.get("data")
        if not isinstance(data, dict):
            raise HarnesslayerResponseError("Missing compare data")

        return HarnesslayerVersionCompareModel._from_api(data)
