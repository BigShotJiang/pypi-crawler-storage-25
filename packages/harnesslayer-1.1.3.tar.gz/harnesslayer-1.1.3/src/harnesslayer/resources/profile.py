from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote
from uuid import uuid4

from .._internal.config import HarnesslayerConfig
from ..exceptions import HarnesslayerError
from ..models.profile import HarnesslayerProfileModel
from ._base import AppBase
from .state import HarnesslayerState

class HarnesslayerProfile(AppBase):
    def _build_profile_model(self, profile_data: dict[str, Any]) -> HarnesslayerProfileModel:
        return HarnesslayerProfileModel._from_api(
            profile_data,
            state=HarnesslayerState(self._client, self._app_id, profile_data["id"]),
        )

    def init(
        self, 
        identifier: str,
        *,
        state_path: Optional[str] = None,
        access_group_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> HarnesslayerProfileModel:
        trimmed_identifier = identifier.strip()
        if not trimmed_identifier:
            raise HarnesslayerError("identifier must be a non-empty string")

        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise HarnesslayerError("name must be a non-empty string")

        if metadata is not None and not isinstance(metadata, dict):
            raise HarnesslayerError("metadata must be a dictionary")
        
        path_data = None
        if state_path is not None and (not isinstance(state_path, str) or not state_path.strip()):
            raise HarnesslayerError("state_path must be a non-empty string")
        
        if state_path is not None:
            path_data = HarnesslayerConfig._validate_config_path(state_path)
            app_res = self._client._request("GET", f"/app/{self._app_id}")
            app_type = app_res["data"].get("type")
            if path_data["type"] != app_type:
                raise HarnesslayerError(
                    f"app type '{app_type}' does not match state_path type '{path_data['type']}'"
                )

        additional_payload = {}
        if access_group_id is not None:
            additional_payload["accessGroupId"] = access_group_id.strip()
        if metadata is not None:
            additional_payload["metadata"] = metadata

        create_res = self._client._request("POST", "/profile/create", payload={
            "appId": self._app_id,
            "identifier": trimmed_identifier,
            **additional_payload,
            "returnIfExist": True,
        })

        state_class = HarnesslayerState(self._client, self._app_id, create_res["data"]["id"])
        profile = HarnesslayerProfileModel._from_api(
            create_res["data"], 
            state=state_class,
        )

        if not create_res.get("exists"):
            state_id = f"state-{uuid4()}"

            if state_path is None:
                branch = self._driftstone_client.repos.create_branch(
                    repo=create_res["data"]["appId"],
                    name=create_res["data"]["id"],
                    storage_dir=state_id,
                    archive=True,
                )
                state_class._wait_for_copy_run(branch.run_id, "profile init")

                state_class.create(state_id=state_id)
            else:
                if path_data is None:
                    raise HarnesslayerError("state_path must be a non-empty string")

                self._driftstone_client.repos.create_branch(
                    repo=create_res["data"]["appId"],
                    name=create_res["data"]["id"],
                    storage_dir=f"state-{uuid4()}",
                )

                files = HarnesslayerConfig._create_upload_files_payload(path_data["path"])
                repo = self._driftstone_client.repos.get(create_res["data"]["appId"])

                upload = self._driftstone_client.repos.create_upload(
                    repo=repo.id,
                    branch=create_res["data"]["id"],
                    storage_dir=state_id,
                    files=files,
                )

                self._driftstone_client.upload_files(upload, files, path_data["path"])
                self._driftstone_client.repos.complete_upload(repo.id, upload.upload_id)

                state_class.create(state_id=state_id)

        return profile

    def retrieve(
        self,
        *,
        profile_id: Optional[str] = None,
        identifier: Optional[str] = None,
    ) -> Optional[HarnesslayerProfileModel]:
        if profile_id is not None and identifier is not None:
            raise HarnesslayerError("Only one of profile_id or identifier may be provided")
        
        if profile_id is None and identifier is None:
            raise HarnesslayerError("Either profile_id or identifier must be provided")
        
        if profile_id is not None and (not isinstance(profile_id, str) or not profile_id.strip()):
            raise HarnesslayerError("profile_id must be a non-empty string")
        
        if identifier is not None and (not isinstance(identifier, str) or not identifier.strip()):
            raise HarnesslayerError("identifier must be a non-empty string")

        try:
            payload: dict[str, Any] = {}
            if identifier is not None:
                profile_ref = identifier.strip()
                payload["appId"] = self._app_id
            else:
                profile_ref = profile_id.strip()

            profile_res = self._client._request("GET", f"/profile/{quote(profile_ref, safe='')}", payload)

            return self._build_profile_model(profile_res["data"])
        except HarnesslayerError:
            return None
        except Exception as e:
            raise e

    def update(
        self,
        profile_id: str,
        *,
        identifier: Optional[str] = None,
        access_group_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> HarnesslayerProfileModel:
        if not isinstance(profile_id, str) or not profile_id.strip():
            raise HarnesslayerError("profile_id must be a non-empty string")
        if identifier is not None and (not isinstance(identifier, str) or not identifier.strip()):
            raise HarnesslayerError("identifier must be a non-empty string")
        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise HarnesslayerError("access_group_id must be a non-empty string")
        if metadata is not None and not isinstance(metadata, dict):
            raise HarnesslayerError("metadata must be a dictionary")

        payload: dict[str, Any] = {}
        if identifier is not None:
            payload["identifier"] = identifier.strip()
        if access_group_id is not None:
            payload["accessGroupId"] = access_group_id.strip()
        if metadata is not None:
            payload["metadata"] = metadata

        if not payload:
            raise HarnesslayerError("At least one field must be provided to update")

        profile_res = self._client._request("PATCH", f"/profile/{profile_id.strip()}", payload)

        state = HarnesslayerState(self._client, self._app_id, profile_res["data"]["id"])

        return HarnesslayerProfileModel._from_api(
            profile_res["data"],
            state=state,
        )

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[HarnesslayerProfileModel]:
        if not isinstance(page, int) or page < 1:
            raise HarnesslayerError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise HarnesslayerError("page_size must be a positive integer")

        profile_list_res = self._client._request(
            "GET",
            "/profile/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = profile_list_res.get("data")
        if not isinstance(data, list):
            raise HarnesslayerError("Expected 'data' to be a list in profile list response")

        return [self._build_profile_model(item) for item in data]
     
    def state(self, profile_id: str) -> HarnesslayerState:
        trimmed_profile_id = profile_id.strip()
        if not profile_id:
            raise HarnesslayerError("profile_id must be a non-empty string")
        return HarnesslayerState(self._client, self._app_id, trimmed_profile_id)

    def delete(self, profile_id: str) -> bool:
        if not isinstance(profile_id, str) or not profile_id.strip():
            raise HarnesslayerError("profile_id must be a non-empty string")

        self._client._request("DELETE", f"/profile/{profile_id.strip()}")

        return True
