from __future__ import annotations

import time
from typing import Optional
from uuid import uuid4

import httpx
from driftstone.exceptions import DriftstoneAPIError

from .._internal.config import CloneTransformValue, HarnesslayerConfig
from .._internal.zip import DriftstoneZip
from ..exceptions import (
    HarnesslayerError, 
    HarnesslayerResponseError, 
    HarnesslayerAPIError
)
from ._base import ProfileBase
class HarnesslayerState(ProfileBase):
    @staticmethod
    def _is_existing_branch_error(error: DriftstoneAPIError) -> bool:
        return "same name already exists" in str(error).lower()

    def _wait_for_copy_run(self, run_id: Optional[str], operation: str):
        if not run_id:
            return None

        deadline = time.monotonic() + max(float(self._client.timeout), 1.0)
        while True:
            copy_status = self._driftstone_client.repos.get_copy_status(
                self._app_id,
                run_id,
            )

            if copy_status.status == "completed":
                return copy_status

            if copy_status.status == "failed":
                error_message = f"{operation} failed"
                if isinstance(copy_status.result, dict):
                    raw_error = copy_status.result.get("error")
                    if isinstance(raw_error, str) and raw_error.strip():
                        error_message = raw_error.strip()
                raise HarnesslayerAPIError(error_message)

            if copy_status.status != "running":
                raise HarnesslayerResponseError(
                    f"Unexpected {operation} status: {copy_status.status}"
                )

            if time.monotonic() >= deadline:
                raise HarnesslayerAPIError(
                    f"Timed out waiting for {operation} run {run_id}"
                )

            time.sleep(1.0)

    def create(
        self,
        state_id: Optional[str] = None,
        state_path: Optional[str] = None,
    ):
        if not state_id and not state_path:
            raise HarnesslayerError("Either state_id or state_path must be provided")
        
        if state_id is not None and not state_id.startswith("state-"):
            raise HarnesslayerError("state_id is invalid")
        
        payload = {
            "profileId": self._profile_id,
        }

        if state_id:
            payload["stateId"] = state_id

        elif state_path:
            state_id = f"state-{uuid4()}"

            path_data = HarnesslayerConfig._validate_config_path(state_path)

            files = HarnesslayerConfig._create_upload_files_payload(path_data["path"])

            repo = self._driftstone_client.repos.get(self._app_id)

            upload = self._driftstone_client.repos.create_upload(
                repo=repo.id,
                branch=self._profile_id,
                storage_dir=state_id,
                files=files,
            )

            self._driftstone_client.upload_files(upload, files, path_data["path"])

            self._driftstone_client.repos.complete_upload(repo.id, upload.upload_id)

            payload["stateId"] = state_id

        self._client._request("POST", "/state/create", payload)

        return True

    def download(
        self,
        out_path: str,
        state_id: Optional[str] = None,
    ) -> bool:
        target_state_id = state_id.strip() if isinstance(state_id, str) else state_id

        if not target_state_id:
            profile_res = self._client._request("GET", f"/profile/{self._profile_id}")

            head_state_id = profile_res["data"].get("headStateId")
            if not isinstance(head_state_id, str) or not head_state_id.strip():
                raise HarnesslayerResponseError("Missing headStateId for profile")

            target_state_id = head_state_id

        if not target_state_id:
            raise HarnesslayerError("state_id must be provided or profile must have a head state")

        if not target_state_id.startswith("state-"):
            raise HarnesslayerError("state_id is invalid")
        
        download_res = self._client._request("POST", f"/state/download/{target_state_id}")

        download_url = download_res["data"].get("url")
        if not isinstance(download_url, str) or not download_url.strip():
            raise HarnesslayerResponseError("Missing download URL for state")

        response = httpx.get(
            download_url,
            timeout=self._client.timeout,
            follow_redirects=True,
        )
        if response.status_code >= 400:
            raise HarnesslayerAPIError("Failed to download state archive")

        out_dir = DriftstoneZip._resolve_out_path(out_path)
        DriftstoneZip._extract_zip(response.content, out_dir)

        return True

    def clone(
        self,
        *,
        state_id: Optional[str] = None,
        transform: Optional[dict[str, CloneTransformValue]] = None,
    ) -> bool:
        try:
            target_state_id = state_id.strip() if isinstance(state_id, str) else state_id

            if not target_state_id:
                profile_res = self._client._request("GET", f"/profile/{self._profile_id}")

                head_state_id = profile_res["data"].get("headStateId")
                if isinstance(head_state_id, str) and head_state_id.strip():
                    target_state_id = head_state_id

            transforms = HarnesslayerConfig._validate_clone_transform(transform=transform)
            new_state_id = f"state-{uuid4()}"

            if target_state_id:
                if not target_state_id.startswith("state-"):
                    raise HarnesslayerError("state_id is invalid")

                copy_job = self._driftstone_client.repos.copy_directory(
                    self._app_id,
                    source_dir=target_state_id,
                    dest_dir=new_state_id,
                    source_branch=self._profile_id,
                    dest_branch=self._profile_id,
                    transforms=transforms,
                    archive=True,
                )

                copy_status = self._wait_for_copy_run(copy_job.run_id, "state clone")
                if isinstance(copy_status.result, dict) and copy_status.result.get("noChanges") is True:
                    return False
            else:
                app_res = self._client._request("GET", f"/app/{self._app_id}")
                head_version_id = app_res["data"].get("headVersionId")
                if not isinstance(head_version_id, str) or not head_version_id.strip():
                    raise HarnesslayerResponseError("Missing headVersionId for app")
                base_version_id = head_version_id.strip()

                try:
                    branch = self._driftstone_client.repos.create_branch(
                        repo=self._app_id,
                        name=self._profile_id,
                        storage_dir=new_state_id,
                        transforms=transforms,
                        archive=True,
                    )
                    self._wait_for_copy_run(branch.run_id, "state clone")
                except DriftstoneAPIError as e:
                    if not self._is_existing_branch_error(e):
                        raise

                    copy_job = self._driftstone_client.repos.copy_directory(
                        self._app_id,
                        source_dir=base_version_id,
                        dest_dir=new_state_id,
                        source_branch="main",
                        dest_branch=self._profile_id,
                        transforms=transforms,
                        archive=True,
                    )

                    copy_status = self._wait_for_copy_run(copy_job.run_id, "state clone")
                    if isinstance(copy_status.result, dict) and copy_status.result.get("noChanges") is True:
                        return False

            self._client._request("POST", "/state/create", {
                "profileId": self._profile_id,
                "stateId": new_state_id,
            })

            return True
        except HarnesslayerError:
            return False
        except Exception as e:
            raise e
