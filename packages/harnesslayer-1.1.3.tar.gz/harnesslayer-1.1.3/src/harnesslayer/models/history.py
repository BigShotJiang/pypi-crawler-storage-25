from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping, Optional


MessageType = Literal["user", "assistant"]


@dataclass(frozen=True, slots=True)
class HarnesslayerMessageModel:
    id: str
    appId: str
    sessionId: str
    historyId: Optional[str]
    type: MessageType
    parts: list[dict[str, Any]]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerMessageModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            sessionId=payload["sessionId"],
            historyId=payload.get("historyId"),
            type=payload["type"],
            parts=payload["parts"],
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerHistoryModel:
    id: str
    appId: str
    sessionId: str
    profileId: str
    identifier: str
    timestamp: int
    messages: list[HarnesslayerMessageModel]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerHistoryModel":
        messages = payload.get("messages", [])
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            sessionId=payload["sessionId"],
            profileId=payload["profileId"],
            identifier=payload["identifier"],
            timestamp=payload["timestamp"],
            messages=[
                HarnesslayerMessageModel._from_api(item)
                for item in messages
                if isinstance(item, Mapping)
            ],
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
