from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping, Optional


SyncStrategy = Literal["manual", "current", "incoming", "smart"]

SyncStatus = Literal["in_progress", "complete", "failed", "conflict"]


@dataclass(frozen=True, slots=True)
class HarnesslayerSmartResolvedHunkModel:
    profileId: str
    stateId: str
    versionId: str
    baseVersionId: str
    path: str
    hunkIndex: int
    startLine: Optional[int]
    current: str
    incoming: str
    currentTruncated: bool
    incomingTruncated: bool
    choice: Literal["current", "incoming"]
    confidence: Optional[float]
    reason: Optional[str]
    resolvedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerSmartResolvedHunkModel":
        return cls(
            profileId=str(payload["profileId"]),
            stateId=str(payload["stateId"]),
            versionId=str(payload["versionId"]),
            baseVersionId=str(payload["baseVersionId"]),
            path=str(payload["path"]),
            hunkIndex=int(payload.get("hunkIndex", 0)),
            startLine=None if payload.get("startLine") is None else int(payload["startLine"]),
            current=str(payload.get("current", "")),
            incoming=str(payload.get("incoming", "")),
            currentTruncated=bool(payload.get("currentTruncated", False)),
            incomingTruncated=bool(payload.get("incomingTruncated", False)),
            choice=payload["choice"],
            confidence=None if payload.get("confidence") is None else float(payload["confidence"]),
            reason=None if payload.get("reason") is None else str(payload["reason"]),
            resolvedAt=datetime.fromisoformat(payload["resolvedAt"]),
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerSyncModel:
    id: str
    appId: str
    versionId: str
    status: SyncStatus
    dispatchingChunks: bool
    totalChunks: int
    pendingChunks: int
    failedChunks: int
    profilesExpected: int
    profilesTotal: int
    profilesMerged: int
    profilesSkipped: int
    profilesConflicted: int
    smartResolvedProfiles: int
    smartResolvedHunksCount: int
    smartResolvedHunks: list[HarnesslayerSmartResolvedHunkModel]
    error: Optional[str]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerSyncModel":
        smart_resolved_hunks = payload.get("smartResolvedHunks", [])
        if not isinstance(smart_resolved_hunks, list):
            smart_resolved_hunks = []

        return cls(
            id=payload["id"],
            appId=payload["appId"],
            versionId=payload["versionId"],
            status=payload["status"],
            dispatchingChunks=payload.get("dispatchingChunks", False),
            totalChunks=payload.get("totalChunks", 0),
            pendingChunks=payload.get("pendingChunks", 0),
            failedChunks=payload.get("failedChunks", 0),
            profilesExpected=payload.get("profilesExpected", 0),
            profilesTotal=payload.get("profilesTotal", 0),
            profilesMerged=payload.get("profilesMerged", 0),
            profilesSkipped=payload.get("profilesSkipped", 0),
            profilesConflicted=payload.get("profilesConflicted", 0),
            smartResolvedProfiles=payload.get("smartResolvedProfiles", 0),
            smartResolvedHunksCount=payload.get("smartResolvedHunksCount", 0),
            smartResolvedHunks=[
                HarnesslayerSmartResolvedHunkModel._from_api(hunk)
                for hunk in smart_resolved_hunks
            ],
            error=payload.get("error"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
