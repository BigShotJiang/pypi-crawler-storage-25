from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Mapping, Optional, TypedDict


class HashMapItem(TypedDict):
    id: str
    hash: str


@dataclass(frozen=True, slots=True)
class HarnesslayerStateModel:
    id: str
    appId: str
    profileId: str
    version: int
    baseVersionId: Optional[str]
    baseStateId: Optional[str]
    storageUrl: str
    downloadUrl: str
    map: Optional[Dict[str, HashMapItem]]
    metadata: Optional[dict[str, Any]]
    status: Optional[str]
    snapshotStorageUrl: Optional[str]
    sandboxId: Optional[str]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerStateModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            profileId=payload["profileId"],
            version=payload["version"],
            baseVersionId=payload.get("baseVersionId"),
            baseStateId=payload.get("baseStateId"),
            storageUrl=payload["storageUrl"],
            downloadUrl=payload["downloadUrl"],
            map=payload.get("map"),
            metadata=payload.get("metadata"),
            status=payload.get("status"),
            snapshotStorageUrl=payload.get("snapshotStorageUrl"),
            sandboxId=payload.get("sandboxId"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
