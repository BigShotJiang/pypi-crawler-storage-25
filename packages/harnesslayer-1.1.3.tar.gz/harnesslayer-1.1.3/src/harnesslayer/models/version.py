from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, TypedDict
from dataclasses import dataclass
from datetime import datetime

class HashMapItem(TypedDict):
    id: str
    hash: str

@dataclass(frozen=True, slots=True)
class HarnesslayerVersionModel:
    id: str
    appId: str
    version: int
    storageUrl: str
    downloadUrl: str
    map: Optional[Dict[str, HashMapItem]]
    metadata: Optional[dict[str, Any]]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerVersionModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            version=payload["version"],
            storageUrl=payload["storageUrl"],
            downloadUrl=payload["downloadUrl"],
            map=payload.get("map"),
            metadata=payload.get("metadata"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerCompareRef:
    type: str
    storageDir: str
    path: str
    branch: Optional[str] = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerCompareRef":
        return cls(
            type=str(payload["type"]),
            storageDir=str(payload["storageDir"]),
            path=str(payload["path"]),
            branch=payload.get("branch"),
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerCompareFile:
    path: str
    status: str
    additions: int
    deletions: int
    changes: int
    binary: bool
    tooLarge: bool
    oldSize: Optional[int]
    newSize: Optional[int]
    patch: Optional[str]

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerCompareFile":
        return cls(
            path=str(payload["path"]),
            status=str(payload["status"]),
            additions=int(payload.get("additions", 0)),
            deletions=int(payload.get("deletions", 0)),
            changes=int(payload.get("changes", 0)),
            binary=bool(payload.get("binary", False)),
            tooLarge=bool(payload.get("tooLarge", False)),
            oldSize=payload.get("oldSize") if isinstance(payload.get("oldSize"), int) else None,
            newSize=payload.get("newSize") if isinstance(payload.get("newSize"), int) else None,
            patch=payload.get("patch") if isinstance(payload.get("patch"), str) else None,
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerCompareStats:
    filesChanged: int
    additions: int
    deletions: int

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerCompareStats":
        return cls(
            filesChanged=int(payload.get("filesChanged", 0)),
            additions=int(payload.get("additions", 0)),
            deletions=int(payload.get("deletions", 0)),
        )


@dataclass(frozen=True, slots=True)
class HarnesslayerVersionCompareModel:
    repoId: str
    versionId: str
    stateId: str
    profileId: str
    base: HarnesslayerCompareRef
    head: HarnesslayerCompareRef
    files: list[HarnesslayerCompareFile]
    stats: HarnesslayerCompareStats

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerVersionCompareModel":
        files = payload.get("files", [])
        return cls(
            repoId=str(payload["repoId"]),
            versionId=str(payload["versionId"]),
            stateId=str(payload["stateId"]),
            profileId=str(payload["profileId"]),
            base=HarnesslayerCompareRef._from_api(payload["base"]),
            head=HarnesslayerCompareRef._from_api(payload["head"]),
            files=[
                HarnesslayerCompareFile._from_api(item)
                for item in files
                if isinstance(item, Mapping)
            ],
            stats=HarnesslayerCompareStats._from_api(payload["stats"]),
        )
