from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping, Optional


WebhookEvent = Literal["profile.created"]
WebhookMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]


@dataclass(frozen=True, slots=True)
class HarnesslayerWebhookModel:
    id: str
    appId: str
    event: WebhookEvent
    method: WebhookMethod
    url: str
    runCount: int
    headers: Optional[dict[str, str]]
    lastTriggeredAt: Optional[datetime]
    createdAt: datetime
    updatedAt: datetime

    @staticmethod
    def _parse_optional_datetime(value: Any) -> Optional[datetime]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            return datetime.fromisoformat(value)
        raise ValueError("Expected datetime, ISO datetime string, or None")

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "HarnesslayerWebhookModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            event=payload["event"],
            method=payload["method"],
            url=payload["url"],
            runCount=payload.get("runCount", 0),
            headers=payload.get("headers"),
            lastTriggeredAt=cls._parse_optional_datetime(payload.get("lastTriggeredAt")),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
