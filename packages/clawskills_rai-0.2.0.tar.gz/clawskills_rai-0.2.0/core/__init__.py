"""ClawSkills — 128K searchable skills from research papers, tech sources & the agent skill ecosystem.

This package implements the ClawSkills pipeline in Python.
"""

from .config import DOMAIN_CONFIG  # re-export for convenience

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.1.0"  # fallback when not installed via setuptools-scm

__all__ = ["DOMAIN_CONFIG", "__version__"]
