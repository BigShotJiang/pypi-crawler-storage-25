# `core/postprocess/`

Postprocessing for run outputs: dedupe clustering and “combo skill” generation.

## What it does

- Clusters similar skills within a run using Jaccard similarity with hash-bucket pre-filtering.
- Optionally generates merged “combo skills” and matrices from near-duplicates.

## Key files

- `run.py`: main postprocess entrypoint used by `clawskills postprocess ...`.
- `dedupe.py`: similarity scoring and clustering logic.

## Tuning (env vars)

- `CLAWSKILLS_DEDUPE_THRESHOLD` (0..1, default 0.25)
- `CLAWSKILLS_MAX_COMBOS` (default 3, max 5)

See `../../README.md` for the end-to-end workflow.
