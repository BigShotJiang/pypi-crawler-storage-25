from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def overlap_ratio_by_fingerprint(fp_a: dict | None, fp_b: dict | None) -> float:
    """Jaccard similarity between two fingerprint hash sets."""
    a = [str(x) for x in (fp_a.get("hashes") if isinstance(fp_a, dict) else []) or []]
    b = [str(x) for x in (fp_b.get("hashes") if isinstance(fp_b, dict) else []) or []]
    if not a or not b:
        return 0.0
    set_a = set(a)
    set_b = set(b)
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    if union <= 0:
        return 0.0
    return float(intersection) / float(union)


@dataclass(frozen=True)
class SkillFp:
    id: str
    title: str
    rel_dir: str
    fingerprint: dict[str, Any]


def build_dedupe_clusters(*, skills: list[SkillFp], threshold: float = 0.25) -> dict[str, Any]:
    arr = list(skills or [])
    n = len(arr)
    parent = list(range(n))

    def find(x: int) -> int:
        p = x
        while parent[p] != p:
            p = parent[p]
        while parent[x] != x:
            nxt = parent[x]
            parent[x] = p
            x = nxt
        return p

    def union(a: int, b: int) -> None:
        ra = find(a)
        rb = find(b)
        if ra != rb:
            parent[rb] = ra

    sims: list[dict[str, Any]] = []
    t = max(0.0, min(1.0, float(threshold or 0.25)))

    # Hash-bucket pre-filter: only compare pairs that share at least one hash.
    # This avoids O(n²) full comparisons for large skill sets.
    hash_to_indices: dict[str, list[int]] = {}
    for i, skill in enumerate(arr):
        hashes = skill.fingerprint.get("hashes") if isinstance(skill.fingerprint, dict) else []
        for h in (hashes or []):
            hash_to_indices.setdefault(str(h), []).append(i)

    candidate_pairs: set[tuple[int, int]] = set()
    for indices in hash_to_indices.values():
        if len(indices) > 1:
            for idx_a in range(len(indices)):
                for idx_b in range(idx_a + 1, len(indices)):
                    i, j = indices[idx_a], indices[idx_b]
                    if i < j:
                        candidate_pairs.add((i, j))
                    else:
                        candidate_pairs.add((j, i))

    for i, j in candidate_pairs:
        r = overlap_ratio_by_fingerprint(arr[i].fingerprint, arr[j].fingerprint)
        if r >= t:
            union(i, j)
            sims.append({"a": arr[i].id, "b": arr[j].id, "ratio": float(f"{r:.4f}")})

    by_root: dict[int, list[SkillFp]] = {}
    for i in range(0, n):
        root = find(i)
        by_root.setdefault(root, []).append(arr[i])

    clusters = [
        sorted(group, key=lambda x: x.id)
        for group in by_root.values()
        if len(group) >= 2
    ]
    clusters.sort(key=lambda g: (-len(g), g[0].id))

    return {
        "threshold": t,
        "clusters": [
            [{"id": s.id, "title": s.title, "rel_dir": s.rel_dir, "fingerprint": s.fingerprint} for s in group] for group in clusters
        ],
        "similar_pairs": sims,
    }

