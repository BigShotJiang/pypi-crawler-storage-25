from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import aiohttp

from .config import CrawlConfig

logger = logging.getLogger("science_crawler")


class DomainRateLimiter:
    def __init__(self, delay: float | None = None):
        self._delay = max(0.0, float(delay or 0.0))
        self._locks: dict[str, asyncio.Lock] = {}
        self._last_request: dict[str, float] = {}

    def _get_domain(self, url: str | None = None) -> str:
        try:
            return urlparse(str(url or "")).netloc.lower()
        except Exception:
            return ""

    async def acquire(self, url: str | None = None) -> None:
        if self._delay <= 0:
            return
        domain = self._get_domain(url)
        if not domain:
            return
        lock = self._locks.setdefault(domain, asyncio.Lock())
        async with lock:
            now = time.monotonic()
            last = self._last_request.get(domain, 0.0)
            wait_s = self._delay - (now - last)
            if wait_s > 0:
                await asyncio.sleep(wait_s)
            self._last_request[domain] = time.monotonic()


class AsyncHTTPClient:
    def __init__(self, config: CrawlConfig):
        self.config = config
        self.rate_limiter = DomainRateLimiter(getattr(config, "per_domain_delay", 0.0))
        self.semaphore = asyncio.Semaphore(max(1, int(getattr(config, "max_concurrent_requests", 20) or 20)))
        self.download_semaphore = asyncio.Semaphore(
            max(1, int(getattr(config, "max_concurrent_downloads", 30) or 30))
        )
        self._session: aiohttp.ClientSession | None = None
        self.stats: dict[str, int] = {"requests": 0, "errors": 0, "retries": 0}

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=60, connect=20, sock_read=60)
            headers = {
                "User-Agent": "ClawSkills-JournalCrawler/1.0 (+https://github.com/LabRAI/ClawSkills)",
                "Accept": "*/*",
            }
            connector = aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver())
            self._session = aiohttp.ClientSession(timeout=timeout, headers=headers, connector=connector)
        return self._session

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()

    async def get_json(self, url: str | None = None) -> dict[str, Any]:
        result = await self._request(url=url, response_type="json")
        return result if isinstance(result, dict) else {}

    async def get_text(self, url: str | None = None) -> str:
        result = await self._request(url=url, response_type="text")
        return str(result or "")

    async def get_xml(self, url: str | None = None) -> str:
        result = await self._request(url=url, response_type="text")
        return str(result or "")

    async def download_file(self, url: str | None = None, dest_path: str | Path | None = None) -> str:
        target = Path(dest_path or "")
        if not str(url or "").strip() or not str(target).strip():
            return ""
        target.parent.mkdir(parents=True, exist_ok=True)
        async with self.download_semaphore:
            blob = await self._request(url=url, response_type="bytes")
        if not isinstance(blob, (bytes, bytearray)) or not blob:
            return ""
        target.write_bytes(bytes(blob))
        return target.as_posix()

    async def _request(self, url: str | None = None, response_type: str | None = None) -> Any:
        target = str(url or "").strip()
        if not target:
            return {} if response_type == "json" else b"" if response_type == "bytes" else ""

        last_err: Exception | None = None
        for attempt in range(3):
            if attempt:
                self.stats["retries"] += 1
                await asyncio.sleep(min(3.0, 0.75 * attempt))
            try:
                await self.rate_limiter.acquire(target)
                async with self.semaphore:
                    session = await self._get_session()
                    async with session.get(target) as resp:
                        self.stats["requests"] += 1
                        if resp.status >= 400:
                            body_preview = (await resp.text())[:400]
                            raise RuntimeError(f"HTTP {resp.status} for {target}: {body_preview}")
                        if response_type == "json":
                            return await resp.json(content_type=None)
                        if response_type == "bytes":
                            return await resp.read()
                        return await resp.text()
            except Exception as exc:
                last_err = exc
                self.stats["errors"] += 1
                logger.debug("HTTP request failed (%s, attempt=%d): %s", target, attempt + 1, exc)
                continue
        raise RuntimeError(f"Failed to fetch {target}") from last_err
