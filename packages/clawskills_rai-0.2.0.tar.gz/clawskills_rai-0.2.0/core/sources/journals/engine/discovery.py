"""Article discovery from publisher/search APIs."""

from __future__ import annotations

import logging
from typing import List

from core.sources.journals.models import PaperRecord
from core.sources.journals.parsers.elife_parser import (
    build_elife_search_url,
    elife_item_to_paper_stub,
    parse_elife_search_response,
)
from core.sources.journals.parsers.nature_parser import (
    build_springer_api_url,
    parse_springer_api_response,
    springer_record_to_paper,
)
from core.sources.journals.parsers.plos_parser import (
    build_plos_search_url,
    parse_plos_search_response,
    plos_doc_to_paper,
)
from core.sources.journals.parsers.pmc_parser import build_esearch_url, parse_esearch_response

from .config import CrawlConfig
from .http_client import AsyncHTTPClient

logger = logging.getLogger("science_crawler")


class ArticleDiscovery:
    """Discover article identifiers/metadata from various APIs."""

    def __init__(self, client: AsyncHTTPClient, config: CrawlConfig):
        self.client = client
        self.config = config

    def _year_from(self) -> int:
        return int(getattr(self.config, "year_from", 2020) or 2020)

    def _year_to(self) -> int:
        return int(getattr(self.config, "year_to", 2026) or 2026)

    def _springer_key(self) -> str:
        return str(
            getattr(self.config, "springer_api_key", "")
            or getattr(self.config, "springer_key", "")
            or ""
        ).strip()

    def _ncbi_key(self) -> str:
        return str(
            getattr(self.config, "ncbi_api_key", "")
            or getattr(self.config, "ncbi_key", "")
            or ""
        ).strip()

    async def discover_pmc_articles(
        self,
        issn: str = "",
        journal_name: str = "",
        max_results: int = 500,
    ) -> List[PaperRecord]:
        """Discover PMC IDs via NCBI E-utilities."""
        want = max(0, int(max_results or 0))
        if want <= 0:
            return []

        out: list[PaperRecord] = []
        seen: set[str] = set()
        retstart = 0
        page_size = min(100, want)
        min_date = f"{self._year_from()}/01/01"
        max_date = f"{self._year_to()}/12/31"
        journal_name_norm = str(journal_name or "").strip()
        if journal_name_norm.lower() in {"pmc open access", "pmc oa"}:
            journal_name_norm = ""

        while len(out) < want:
            url = build_esearch_url(
                issn=str(issn or "").strip(),
                journal_name=journal_name_norm,
                retmax=min(page_size, want - len(out)),
                retstart=retstart,
                min_date=min_date,
                max_date=max_date,
                api_key=self._ncbi_key(),
            )
            payload = await self.client.get_json(url)
            ids, total = parse_esearch_response(payload)
            if not ids:
                break
            for pmc_id in ids:
                pid = str(pmc_id or "").strip()
                if not pid or pid in seen:
                    continue
                seen.add(pid)
                out.append(
                    PaperRecord(
                        title="",
                        journal=str(journal_name or "").strip(),
                        journal_family="PMC",
                        url=f"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC{pid}/",
                        is_open_access=True,
                        pmc_id=pid if pid.upper().startswith("PMC") else f"PMC{pid}",
                    )
                )
                if len(out) >= want:
                    break
            retstart += len(ids)
            if retstart >= int(total or 0) or len(ids) < page_size:
                break

        return out

    async def discover_springer_articles(self, issn: str = "", max_results: int = 100) -> List[PaperRecord]:
        """Discover articles via Springer Nature Open Access API."""
        want = max(0, int(max_results or 0))
        if want <= 0:
            return []
        api_key = self._springer_key()
        if not api_key:
            logger.info("Skipping Springer Nature discovery for ISSN %s because no API key is configured.", issn)
            return []

        out: list[PaperRecord] = []
        seen: set[str] = set()
        start = 1
        page_size = min(100, want)

        while len(out) < want:
            url = build_springer_api_url(
                issn=str(issn or "").strip(),
                start=start,
                page_size=min(page_size, want - len(out)),
                api_key=api_key,
                year_from=self._year_from(),
                year_to=self._year_to(),
            )
            payload = await self.client.get_json(url)
            records, total = parse_springer_api_response(payload)
            if not records:
                break
            for record in records:
                paper = springer_record_to_paper(record)
                if paper is None:
                    continue
                key = str(paper.doi or paper.url or "").strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                out.append(paper)
                if len(out) >= want:
                    break
            start += len(records)
            if start > int(total or 0) or len(records) < page_size:
                break

        return out

    async def discover_plos_articles(self, journal_slug: str = "", max_results: int = 100) -> List[PaperRecord]:
        """Discover articles via PLOS Search API."""
        want = max(0, int(max_results or 0))
        if want <= 0:
            return []

        out: list[PaperRecord] = []
        seen: set[str] = set()
        start = 0
        page_size = min(100, want)

        while len(out) < want:
            url = build_plos_search_url(
                journal_slug=str(journal_slug or "").strip(),
                start=start,
                rows=min(page_size, want - len(out)),
                year_from=self._year_from(),
                year_to=self._year_to(),
            )
            payload = await self.client.get_json(url)
            docs, total = parse_plos_search_response(payload)
            if not docs:
                break
            for doc in docs:
                paper = plos_doc_to_paper(doc)
                if paper is None:
                    continue
                key = str(paper.doi or paper.url or "").strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                out.append(paper)
                if len(out) >= want:
                    break
            start += len(docs)
            if start >= int(total or 0) or len(docs) < page_size:
                break

        return out

    async def discover_elife_articles(self, max_results: int = 100) -> List[PaperRecord]:
        """Discover articles via eLife API."""
        want = max(0, int(max_results or 0))
        if want <= 0:
            return []

        out: list[PaperRecord] = []
        seen: set[str] = set()
        page = 1
        page_size = min(100, want)

        while len(out) < want:
            url = build_elife_search_url(
                page=page,
                per_page=min(page_size, want - len(out)),
                year_from=self._year_from(),
            )
            payload = await self.client.get_json(url)
            items, total = parse_elife_search_response(payload)
            if not items:
                break
            for item in items:
                paper = elife_item_to_paper_stub(item)
                if paper is None:
                    continue
                key = str(paper.doi or paper.url or "").strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                out.append(paper)
                if len(out) >= want:
                    break
            page += 1
            if (page - 1) * page_size >= int(total or 0) or len(items) < page_size:
                break

        return out
