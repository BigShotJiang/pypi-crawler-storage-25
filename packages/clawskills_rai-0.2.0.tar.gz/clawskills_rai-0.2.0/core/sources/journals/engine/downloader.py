"""Figure image downloader."""

from __future__ import annotations

from pathlib import Path

from core.sources.journals.models import PaperRecord
from core.utils.hashing import slugify

from .config import CrawlConfig
from .http_client import AsyncHTTPClient


def _guess_extension(url: str | None = None) -> str:
    raw = str(url or "").strip()
    lower = raw.lower()
    if "journals.plos.org" in lower and "/article/figure/image" in lower:
        return ".tiff" if "size=original" in lower else ".png"
    url_lower = lower.split("?", 1)[0]
    for ext in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".svg", ".gif", ".webp", ".pdf"):
        if url_lower.endswith(ext):
            return ext
    return ".jpg"


class FigureDownloader:
    """Download figure images concurrently."""

    def __init__(self, client: AsyncHTTPClient, config: CrawlConfig):
        self.client = client
        self.config = config

    async def download_paper_figures(self, paper: PaperRecord) -> None:
        figures = list(getattr(paper, "figures", None) or [])
        if not figures:
            return

        paper_slug = slugify(getattr(paper, "doi", "") or getattr(paper, "title", "") or "paper", 80)
        fig_dir = Path(getattr(self.config, "output_dir", "output")) / "figures" / paper_slug
        fig_dir.mkdir(parents=True, exist_ok=True)

        for idx, fig in enumerate(figures, start=1):
            url = str(getattr(fig, "full_size_url", "") or getattr(fig, "thumbnail_url", "") or "").strip()
            if not url:
                continue
            figure_id = slugify(getattr(fig, "figure_id", "") or f"fig{idx}", 60) or f"fig{idx}"
            dest = fig_dir / f"{figure_id}{_guess_extension(url)}"
            saved = await self.client.download_file(url, dest)
            if saved and not getattr(fig, "thumbnail_url", ""):
                fig.thumbnail_url = saved

