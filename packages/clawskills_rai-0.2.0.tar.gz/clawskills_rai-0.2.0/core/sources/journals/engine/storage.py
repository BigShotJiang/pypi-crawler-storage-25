"""Data storage helpers for the legacy journal crawl orchestrator."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, is_dataclass
from datetime import datetime
from hashlib import sha256
from typing import Any

from core.sources.journals.models import PaperRecord

from .config import CrawlConfig


def _paper_key(paper: Any) -> str:
    doi = str(getattr(paper, "doi", "") or "").strip()
    if doi:
        return doi

    url = str(getattr(paper, "url", "") or "").strip()
    if url:
        return url

    pmc_id = str(getattr(paper, "pmc_id", "") or "").strip()
    if pmc_id:
        return f"pmc:{pmc_id}"

    pmid = str(getattr(paper, "pmid", "") or "").strip()
    if pmid:
        return f"pmid:{pmid}"

    title = str(getattr(paper, "title", "") or "").strip()
    if title:
        return f"title:{title}"

    return "paper"


def _safe_slug(raw: str) -> str:
    slug = str(raw or "").strip().replace("/", "_").replace(":", "_")
    slug = "".join(ch if ch.isalnum() or ch in {"_", "-", "."} else "_" for ch in slug)
    slug = slug.strip("._")
    if slug:
        return slug[:160]
    digest = sha256(str(raw or "paper").encode("utf-8")).hexdigest()[:16]
    return f"paper-{digest}"


def _paper_to_dict(paper: PaperRecord) -> dict[str, Any]:
    if is_dataclass(paper):
        payload = asdict(paper)
    else:
        payload = dict(getattr(paper, "__dict__", {}))
    crawled_at = str(getattr(paper, "crawled_at", "") or "").strip()
    if crawled_at:
        payload["crawled_at"] = crawled_at
    return payload


class DataStorage:
    """Save crawled paper metadata for resume support and inspection."""

    def __init__(self, config: CrawlConfig) -> None:
        self.config = config
        self.metadata_dir = os.path.join(config.output_dir, "metadata")
        self.index_path = os.path.join(config.output_dir, "index.jsonl")
        os.makedirs(self.metadata_dir, exist_ok=True)

    def save_paper(self, paper: PaperRecord) -> str:
        """Persist one paper JSON and append a compact entry to index.jsonl."""
        crawled_at = datetime.now().isoformat()
        setattr(paper, "crawled_at", crawled_at)

        paper_dict = _paper_to_dict(paper)
        paper_key = _paper_key(paper)
        safe_name = _safe_slug(paper_key)
        rel_path = f"metadata/{safe_name}.json"
        abs_path = os.path.join(self.config.output_dir, rel_path)

        with open(abs_path, "w", encoding="utf-8") as fh:
            json.dump(paper_dict, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")

        index_row = {
            "doi": str(getattr(paper, "doi", "") or "").strip(),
            "title": str(getattr(paper, "title", "") or "").strip(),
            "journal": str(getattr(paper, "journal", "") or "").strip(),
            "journal_family": str(getattr(paper, "journal_family", "") or "").strip(),
            "url": str(getattr(paper, "url", "") or "").strip(),
            "pmc_id": str(getattr(paper, "pmc_id", "") or "").strip(),
            "pmid": str(getattr(paper, "pmid", "") or "").strip(),
            "pub_date": str(getattr(paper, "pub_date", "") or "").strip(),
            "crawled_at": crawled_at,
            "path": rel_path,
        }
        with open(self.index_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(index_row, ensure_ascii=False))
            fh.write("\n")

        return abs_path

    def get_existing_dois(self) -> set[str]:
        """Load previously crawled DOI keys from index.jsonl or metadata fallback."""
        existing: set[str] = set()

        if os.path.isfile(self.index_path):
            try:
                with open(self.index_path, "r", encoding="utf-8") as fh:
                    for raw_line in fh:
                        line = str(raw_line or "").strip()
                        if not line:
                            continue
                        try:
                            row = json.loads(line)
                        except Exception:
                            continue
                        doi = str((row or {}).get("doi") or "").strip()
                        if doi:
                            existing.add(doi)
            except Exception:
                pass

        if existing:
            return existing

        if not os.path.isdir(self.metadata_dir):
            return existing

        for name in sorted(os.listdir(self.metadata_dir)):
            if not name.endswith(".json"):
                continue
            path = os.path.join(self.metadata_dir, name)
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    row = json.load(fh)
            except Exception:
                continue
            doi = str((row or {}).get("doi") or "").strip()
            if doi:
                existing.add(doi)
        return existing

    def save_summary(self, stats: dict[str, Any]) -> str:
        """Write crawl_summary.json under the configured output directory."""
        path = os.path.join(self.config.output_dir, "crawl_summary.json")
        payload = dict(stats or {})
        payload.setdefault("written_at", datetime.now().isoformat())
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
        return path
