"""Build a cleaned claw bundle from a mined claw bundle."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import re
import sqlite3
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from core.utils.yaml_lite import safe_load_yaml_text

from . import build_claw_bundle
from .converter import ClawSkill

_BAD_TITLES = {
    "", "-", "--", "---", "|", ">", ">-", ".", "..", "...", "skill", "skills",
    "test", "demo", "example", "temp", "tmp", "untitled", "new", "draft",
    "a", "aa", "aaa", "abc", "asdf", "todo", "wip", "placeholder",
}
_NONWORD_RE = re.compile(r"^[\W_]+$", re.UNICODE)
_WHITESPACE_RE = re.compile(r"\s+")
_LOCALE_SEGMENT_RE = re.compile(
    r"(^|/)(i18n/)?(en|es|fr|de|it|ja|ko|pt|pt-br|zh|zh-cn|zh-tw)(/|$)",
    re.IGNORECASE,
)
_VERSION_SUFFIX_RE = re.compile(r"(?<![a-z0-9])(?:v|version)[-_ ]*\d+(?:\.\d+)*$", re.IGNORECASE)
_NONALNUM_RE = re.compile(r"[^a-z0-9]+", re.IGNORECASE)


@dataclass
class _CleanedItem:
    skill: ClawSkill
    dedupe_key: tuple[str, str]
    score: float
    body_len: int
    title_rewritten: bool
    title_norm: str
    title_family: str
    body_norm: str
    repo_full_name: str
    repo_kind: str
    repo_file_path: str


def _find_latest_mined_bundle() -> Path | None:
    roots = [Path.cwd() / "dist", Path.cwd() / "bundles"]
    candidates: list[Path] = []
    for root in roots:
        if not root.is_dir():
            continue
        candidates.extend(root.glob("clawskills-bundle-lite-claw-mined-v*.sqlite"))
    if not candidates:
        return None
    return max(candidates, key=lambda p: (p.stat().st_mtime, p.name))


def _normalize_title(title: str) -> str:
    return _WHITESPACE_RE.sub(" ", str(title or "").strip()).casefold()


def _normalize_body(text: str) -> str:
    return _WHITESPACE_RE.sub(" ", str(text or "").strip()).casefold()


def _title_family(title: str) -> str:
    text = _normalize_title(title)
    text = _VERSION_SUFFIX_RE.sub("", text).strip()
    text = _NONALNUM_RE.sub(" ", text).strip()
    return _WHITESPACE_RE.sub(" ", text)


def _looks_bad_title(title: str, *, repo_full_name: str = "") -> bool:
    text = str(title or "").strip()
    if not text:
        return True
    if _normalize_title(text) in _BAD_TITLES:
        return True
    if _NONWORD_RE.fullmatch(text):
        return True
    if len(text) < 4:
        return True
    # Pure numeric or hex-like strings (e.g., "123", "8k4", "acf")
    if re.fullmatch(r"[a-f0-9]{1,8}", text, re.IGNORECASE):
        return True
    if repo_full_name and _normalize_title(text) == _normalize_title(repo_full_name):
        return True
    return False


def _path_fallback_title(path: str) -> str:
    parts = [part for part in str(path or "").split("/") if part]
    if len(parts) >= 2:
        raw = parts[-2]
    elif parts:
        raw = Path(parts[-1]).stem
    else:
        return ""
    cleaned = raw.replace("-", " ").replace("_", " ").strip()
    if not cleaned:
        return ""
    return cleaned.title()


def _choose_clean_title(meta: dict[str, Any], current_title: str) -> tuple[str, bool]:
    repo_full_name = str(meta.get("repo_full_name") or "")
    claw_name = str(meta.get("claw_name") or "").strip()
    if not _looks_bad_title(claw_name, repo_full_name=repo_full_name):
        return claw_name, _normalize_title(claw_name) != _normalize_title(current_title)

    cur = str(current_title or "").strip()
    if not _looks_bad_title(cur, repo_full_name=repo_full_name):
        return cur, False

    fallback = _path_fallback_title(str(meta.get("repo_file_path") or ""))
    if not _looks_bad_title(fallback, repo_full_name=repo_full_name):
        return fallback, True

    if claw_name:
        return claw_name, True
    return cur or fallback or repo_full_name or "Untitled Skill", True


def _repo_score(meta: dict[str, Any]) -> float:
    for key in ("repo_priority_score", "priority_score", "overall_score"):
        raw = meta.get(key)
        if raw in ("", None):
            continue
        try:
            return float(raw)
        except Exception:
            continue
    return 0.0


def _is_locale_path(path: str) -> bool:
    return bool(_LOCALE_SEGMENT_RE.search(str(path or "").casefold()))


def _path_rank(path: str) -> float:
    norm = str(path or "").strip().casefold()
    score = 0.0
    if not norm:
        return score
    if norm == "skill.md":
        score += 40.0
    if norm.startswith("skills/"):
        score += 24.0
    if any(norm.startswith(p) for p in (".claude/skills/", ".openclaw/skills/", ".agents/", ".cursor/skills/", ".codex/", ".opencode/")):
        score += 16.0
    if norm.startswith("dist/") or "/dist/" in norm:
        score -= 20.0
    if _is_locale_path(norm):
        if "/en/" in norm or norm.startswith("i18n/en/"):
            score += 10.0
        else:
            score -= 6.0
    score -= min(len(norm), 240) / 100.0
    return score


def _item_rank(item: _CleanedItem) -> tuple[float, float, int, str]:
    return (
        float(item.score),
        _path_rank(item.repo_file_path),
        int(item.body_len),
        str(item.skill.source_url),
    )


def _body_similarity(left: str, right: str) -> float:
    a = _normalize_body(left)
    b = _normalize_body(right)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    min_len = min(len(a), len(b))
    max_len = max(len(a), len(b))
    if min_len == 0:
        return 0.0
    if min_len / max_len >= 0.70 and (a in b or b in a):
        return 0.985
    return difflib.SequenceMatcher(None, a[:6000], b[:6000]).ratio()


def _is_near_duplicate(left: _CleanedItem, right: _CleanedItem) -> bool:
    if left.repo_full_name == right.repo_full_name:
        return False
    if not left.title_family or left.title_family != right.title_family:
        return False
    similarity = _body_similarity(left.body_norm, right.body_norm)
    if similarity >= 0.94:
        return True
    if similarity >= 0.90:
        longer = max(left.body_len, right.body_len)
        shorter = min(left.body_len, right.body_len)
        if longer and shorter / longer >= 0.72:
            return True
    return False


def _should_drop(meta: dict[str, Any], *, title: str, body_md: str) -> tuple[bool, str]:
    repo_kind = str(meta.get("repo_kind") or "").strip().lower()
    score = _repo_score(meta)
    body_len = len(str(body_md or "").strip())

    if repo_kind == "mirror":
        return True, "mirror"
    if _looks_bad_title(title, repo_full_name=str(meta.get("repo_full_name") or "")):
        return True, "bad_title"
    if body_len < 40:
        return True, "short_body"
    if repo_kind == "unknown" and score < 20:
        return True, "low_priority_unknown"
    if repo_kind == "example-app" and score < 25:
        return True, "low_priority_example"
    return False, ""


def _row_to_clean_item(row: sqlite3.Row) -> tuple[_CleanedItem | None, str]:
    meta = safe_load_yaml_text(str(row["metadata_yaml"] or ""))
    if not isinstance(meta, dict):
        return None, "invalid_metadata"

    current_title = str(row["title"] or meta.get("title") or "")
    clean_title, rewritten = _choose_clean_title(meta, current_title)
    body_md = str(row["skill_md"] or "")

    drop, reason = _should_drop(meta, title=clean_title, body_md=body_md)
    if drop:
        return None, reason

    title_norm = _normalize_title(clean_title)
    body_norm = _normalize_body(body_md)
    body_hash = hashlib.sha256(body_norm.encode("utf-8")).hexdigest()

    description = str(meta.get("description") or "").strip()
    if not description:
        previous_title = str(current_title or "").strip()
        if previous_title and _normalize_title(previous_title) != title_norm:
            description = previous_title

    skill = ClawSkill(
        name=clean_title,
        description=description,
        version=str(meta.get("claw_version") or "0.0.0"),
        author=str(meta.get("claw_author") or ""),
        tags=[str(tag) for tag in (meta.get("tags") or []) if str(tag).strip()],
        license_spdx=str(meta.get("license_spdx") or ""),
        requires_bins=[str(x) for x in (meta.get("claw_requires_bins") or []) if str(x).strip()],
        body_md=body_md,
        source_url=str(row["source_url"] or meta.get("source_url") or ""),
        source_type=str(row["source_type"] or meta.get("source_type") or ""),
        metadata={**meta, "display_title": clean_title, "cleaned_from_bundle": True},
    )
    return (
        _CleanedItem(
            skill=skill,
            dedupe_key=(title_norm, body_hash),
            score=_repo_score(meta),
            body_len=len(body_md),
            title_rewritten=rewritten,
            title_norm=title_norm,
            title_family=_title_family(clean_title),
            body_norm=body_norm,
            repo_full_name=str(meta.get("repo_full_name") or ""),
            repo_kind=str(meta.get("repo_kind") or ""),
            repo_file_path=str(meta.get("repo_file_path") or ""),
        ),
        "",
    )


def _fold_repo_variants(items: list[_CleanedItem]) -> tuple[list[_CleanedItem], int]:
    groups: dict[tuple[str, str], list[_CleanedItem]] = {}
    for item in items:
        groups.setdefault((item.repo_full_name, item.title_norm), []).append(item)

    kept: list[_CleanedItem] = []
    folded = 0
    for group in groups.values():
        if len(group) == 1:
            kept.extend(group)
            continue
        kept.append(max(group, key=_item_rank))
        folded += len(group) - 1
    return kept, folded


def _fold_near_duplicates(items: list[_CleanedItem]) -> tuple[list[_CleanedItem], int]:
    groups: dict[str, list[_CleanedItem]] = {}
    for item in items:
        groups.setdefault(item.title_family or item.title_norm, []).append(item)

    kept: list[_CleanedItem] = []
    folded = 0
    for group in groups.values():
        if len(group) == 1:
            kept.extend(group)
            continue
        survivors: list[_CleanedItem] = []
        for item in sorted(group, key=_item_rank, reverse=True):
            if any(_is_near_duplicate(item, survivor) for survivor in survivors):
                folded += 1
                continue
            survivors.append(item)
        kept.extend(survivors)
    return kept, folded


def clean_claw_bundle(
    input_bundle: str | Path,
    *,
    out_path: str | Path,
    version: str = "",
) -> tuple[Path, dict[str, int]]:
    src = Path(input_bundle)
    if not src.exists():
        raise FileNotFoundError(src)

    conn = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT i.skill_id, i.source_type, i.source_url, i.title, c.metadata_yaml, c.skill_md
            FROM skills_index AS i
            JOIN skills_content AS c USING(skill_id)
            ORDER BY i.skill_id
            """
        ).fetchall()
    finally:
        conn.close()

    stats = {
        "input_rows": len(rows),
        "kept_rows": 0,
        "dropped_bad_title": 0,
        "dropped_short_body": 0,
        "dropped_low_priority_unknown": 0,
        "dropped_low_priority_example": 0,
        "dropped_mirror": 0,
        "dropped_invalid_metadata": 0,
        "deduped_rows": 0,
        "folded_repo_variants": 0,
        "folded_near_duplicates": 0,
        "rewritten_titles": 0,
    }

    valid_items: list[_CleanedItem] = []
    for row in rows:
        item, reason = _row_to_clean_item(row)
        if item is None:
            key = f"dropped_{reason}" if reason else "dropped_invalid_metadata"
            stats[key] = stats.get(key, 0) + 1
            continue
        valid_items.append(item)

    kept: dict[tuple[str, str], _CleanedItem] = {}
    rewritten_titles = 0
    deduped_rows = 0
    for item in valid_items:
        existing = kept.get(item.dedupe_key)
        if existing is None:
            kept[item.dedupe_key] = item
            rewritten_titles += 1 if item.title_rewritten else 0
            continue

        new_rank = _item_rank(item)
        old_rank = _item_rank(existing)
        if new_rank > old_rank:
            if existing.title_rewritten:
                rewritten_titles -= 1
            kept[item.dedupe_key] = item
            rewritten_titles += 1 if item.title_rewritten else 0
        deduped_rows += 1

    folded_items, repo_folded = _fold_repo_variants(list(kept.values()))
    folded_items, near_folded = _fold_near_duplicates(folded_items)

    stats["deduped_rows"] = deduped_rows
    stats["folded_repo_variants"] = repo_folded
    stats["folded_near_duplicates"] = near_folded
    stats["rewritten_titles"] = rewritten_titles

    cleaned_skills = [item.skill for item in folded_items]
    cleaned_skills.sort(key=lambda skill: (str(skill.name).casefold(), str(skill.source_url)))
    stats["kept_rows"] = len(cleaned_skills)

    version_text = version or date.today().strftime("%Y%m%d")
    out = build_claw_bundle(cleaned_skills, out_path, version=version_text, source="claw-repo-clean")
    return out, stats


def print_clean_stats(stats: dict[str, int]) -> None:
    print(f"\n{'=' * 60}", file=sys.stderr)
    print("Claw Bundle Cleaning Report", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)
    for key in [
        "input_rows",
        "kept_rows",
        "deduped_rows",
        "folded_repo_variants",
        "folded_near_duplicates",
        "rewritten_titles",
        "dropped_bad_title",
        "dropped_short_body",
        "dropped_low_priority_unknown",
        "dropped_low_priority_example",
        "dropped_mirror",
        "dropped_invalid_metadata",
    ]:
        print(f"{key}: {int(stats.get(key, 0) or 0)}", file=sys.stderr)
    print(f"{'=' * 60}\n", file=sys.stderr)


def cli_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="clawskills-claw-clean-bundle",
        description="Clean a mined claw bundle by rewriting titles, dropping low-quality rows, and deduplicating content",
    )
    parser.add_argument("--input", default="", help="Input mined claw bundle (default: latest dist/bundles mined bundle)")
    parser.add_argument(
        "--out",
        default="",
        help="Output SQLite path (default: dist/clawskills-bundle-lite-claw-clean-v{date}.sqlite)",
    )
    parser.add_argument("--version", default="", help="Bundle version string")
    args = parser.parse_args(argv)

    version = args.version or date.today().strftime("%Y%m%d")
    input_bundle = args.input or _find_latest_mined_bundle()
    if not input_bundle:
        print("No mined claw bundle found.", file=sys.stderr)
        return 1
    out_path = args.out or f"dist/clawskills-bundle-lite-claw-clean-v{version}.sqlite"
    out, stats = clean_claw_bundle(input_bundle, out_path=out_path, version=version)
    print_clean_stats(stats)
    print(f"Cleaned bundle written to: {out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(cli_main())
