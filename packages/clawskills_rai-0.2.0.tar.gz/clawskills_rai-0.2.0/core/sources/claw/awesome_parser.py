"""Parse awesome-openclaw-skills and similar curated skill lists.

Fetches the README.md from curated awesome-lists on GitHub, extracts
skill repository links, then fetches SKILL.md from each repo.

Usage:
    from core.sources.claw.awesome_parser import crawl_awesome_lists
    skills = crawl_awesome_lists(max_skills=500)
"""

from __future__ import annotations

import json
import logging
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from typing import Any
from urllib.parse import quote

from .converter import ClawSkill, parse_skill_md
from .http_client import (
    github_headers,
    has_github_token,
    http_get,
    http_get_with_rate_retry,
    is_valid_skill_filename,
    is_valid_soul_filename,
)

# ── Configuration ────────────────────────────────────────────────

_CONTENT_DELAY = 0.5
_AGENT_FETCH_WORKERS = 12

# Known awesome-lists for OpenClaw/Agent skills
_AWESOME_LISTS = [
    {
        "name": "awesome-openclaw-skills",
        "owner": "VoltAgent",
        "repo": "awesome-openclaw-skills",
        "readme_path": "README.md",
        "record_kind": "skill",
    },
    {
        "name": "awesome-openclaw-usecases",
        "owner": "hesamsheikh",
        "repo": "awesome-openclaw-usecases",
        "readme_path": "README.md",
        "record_kind": "usecase",
        "source_type": "claw-awesome-usecase",
    },
    {
        "name": "awesome-openclaw-skills-zh",
        "owner": "clawdbot-ai",
        "repo": "awesome-openclaw-skills-zh",
        "readme_path": "README.md",
        "record_kind": "skill",
    },
    {
        "name": "awesome-openclaw-usecases-zh",
        "owner": "AlexAnys",
        "repo": "awesome-openclaw-usecases-zh",
        "readme_path": "README.md",
        "record_kind": "usecase",
        "source_type": "claw-awesome-usecase",
    },
    {
        "name": "awesome-openclaw-agents",
        "owner": "mergisi",
        "repo": "awesome-openclaw-agents",
        "readme_path": "README.md",
        "record_kind": "agent-template",
        "source_type": "claw-awesome-agent",
    },
    {
        "name": "awesome-openclaw",
        "owner": "SamurAIGPT",
        "repo": "awesome-openclaw",
        "readme_path": "README.md",
        "record_kind": "skill",
    },
    {
        "name": "awesome-openclaw",
        "owner": "mahseema",
        "repo": "awesome-openclaw",
        "readme_path": "README.md",
        "record_kind": "skill",
    },
    {
        "name": "awesome-openclaw-3",
        "owner": "Clawdius",
        "repo": "awesome-openclaw-3",
        "readme_path": "README.md",
        "record_kind": "skill",
    },
]


# ── README parser ────────────────────────────────────────────────

# Patterns to match skill entries in awesome-list READMEs
# Format: - [skill-name](https://clawskills.sh/skills/author-slug) - Description
# or:     - [skill-name](https://clawhub.ai/author/slug) - Description
_CLAWSKILLS_RE = re.compile(
    r"-\s+\[([^\]]+)\]\(https?://(?:clawskills\.sh|clawhub\.ai)/skills?/([a-zA-Z0-9_.-]+(?:/[a-zA-Z0-9_.-]+)?)\)\s*[-–—]\s*(.*)",
    re.IGNORECASE,
)

# GitHub repo links (fallback for lists that link directly to repos)
_GITHUB_LINK_RE = re.compile(
    r"https?://github\.com/([a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+)(?:/|$)",
    re.IGNORECASE,
)

_SKIP_REPOS = {
    "openclaw/openclaw", "openclaw/clawhub",
    "anthropics/claude-code", "anthropics/anthropic-sdk-python",
    "anthropics/anthropic-sdk-typescript",
}


def _extract_skill_entries(readme_text: str) -> list[dict[str, str]]:
    """Extract skill entries from an awesome-list README.

    Supports two formats:
    1. clawskills.sh / clawhub.ai links with descriptions
    2. GitHub repo links (fallback)
    """
    entries: list[dict[str, str]] = []
    seen: set[str] = set()

    # Primary: parse clawskills.sh / clawhub.ai entries
    for match in _CLAWSKILLS_RE.finditer(readme_text):
        name = match.group(1).strip()
        slug = match.group(2).strip().rstrip("/")
        description = match.group(3).strip().rstrip(".")

        key = slug.lower()
        if key in seen:
            continue
        seen.add(key)

        entries.append({
            "name": name,
            "slug": slug,
            "description": description,
            "url": f"https://clawskills.sh/skills/{slug}",
        })

    # Fallback: GitHub repo links (if no clawskills entries found)
    if not entries:
        for match in _GITHUB_LINK_RE.finditer(readme_text):
            full_name = match.group(1).rstrip("/").rstrip(".")
            full_name = re.sub(r"/(tree|blob|issues|pulls|releases|wiki).*$", "", full_name)
            if "/" not in full_name:
                continue
            lower = full_name.lower()
            if lower in seen or lower in _SKIP_REPOS:
                continue
            seen.add(lower)
            entries.append({
                "name": full_name.split("/")[-1],
                "slug": full_name,
                "description": "",
                "url": f"https://github.com/{full_name}",
            })

    return entries


# Also extract category section links for deeper crawling
_CATEGORY_FILE_RE = re.compile(
    r'\[View all \d+ skills in .+? →\]\((categories/[a-z0-9_-]+\.md)\)',
    re.IGNORECASE,
)

_HEADING_RE = re.compile(r"^\s*#\s+(.+?)\s*$", re.MULTILINE)
_LIST_MARKER_RE = re.compile(r"^\s*(?:[-*]|\d+\.)\s+")


def _parse_soul_md(
    text: str,
    *,
    source_url: str,
    source_type: str,
    awesome_list: str,
    repo_full_name: str,
    path: str,
) -> ClawSkill | None:
    """Build a ``ClawSkill`` from a plain ``SOUL.md`` agent template."""
    body_md = text.strip()
    if not body_md:
        return None

    heading_match = _HEADING_RE.search(body_md)
    title = heading_match.group(1).strip() if heading_match else ""

    description = ""
    for raw_line in body_md.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        if _LIST_MARKER_RE.match(line):
            continue
        description = line
        break

    path_parts = [part for part in path.split("/") if part]
    category = path_parts[1].strip() if len(path_parts) >= 4 else ""
    template_slug = path_parts[-2].strip() if len(path_parts) >= 2 else ""

    name = title or template_slug.replace("-", " ").title() or path
    tags = [tag for tag in [category, "agent-template", "openclaw"] if tag]

    return ClawSkill(
        name=name,
        description=description,
        tags=tags,
        source_url=source_url,
        source_type=source_type,
        body_md=body_md + "\n",
        metadata={
            "awesome_list": awesome_list,
            "record_kind": "agent-template",
            "repo_full_name": repo_full_name,
            "soul_path": path,
            "agent_category": category,
            "agent_slug": template_slug,
        },
    )


def _crawl_agent_template_list(
    list_info: dict[str, str],
    max_skills: int,
    seen_slugs: set[str],
    emit: Any = None,
) -> list[ClawSkill]:
    """Expand agent-template lists by enumerating repo ``SOUL.md`` files."""
    owner = list_info["owner"]
    repo = list_info["repo"]
    name = list_info.get("name", f"{owner}/{repo}")
    source_type = str(list_info.get("source_type", "claw-awesome-agent") or "claw-awesome-agent")
    repo_full_name = f"{owner}/{repo}"
    headers = github_headers()

    print(f"[awesome] Fetching {name} tree for SOUL.md files...", file=sys.stderr)
    tree_url = f"https://api.github.com/repos/{repo_full_name}/git/trees/HEAD?recursive=1"
    tree_text = http_get_with_rate_retry(tree_url, headers=headers)
    if not tree_text:
        print(f"  [awesome] Failed to fetch tree for {name}", file=sys.stderr)
        return []

    try:
        tree_data = json.loads(tree_text)
    except (json.JSONDecodeError, ValueError):
        print(f"  [awesome] Invalid tree JSON for {name}", file=sys.stderr)
        return []

    soul_paths = sorted(
        str(item.get("path") or "").strip()
        for item in tree_data.get("tree", [])
        if item.get("type") == "blob"
        and str(item.get("path") or "").startswith("agents/")
        and is_valid_soul_filename(str(item.get("path") or ""))
    )
    if emit:
        emit(f"{name}: found {len(soul_paths)} SOUL.md files")
    print(f"  [awesome] SOUL.md files: {len(soul_paths)}", file=sys.stderr)
    if not soul_paths:
        return []

    seen_lock = Lock()

    def _fetch_one(path: str) -> ClawSkill | None:
        slug_key = f"{repo_full_name}:{path}".lower()
        with seen_lock:
            if slug_key in seen_slugs:
                return None
            seen_slugs.add(slug_key)
        raw_url = f"https://raw.githubusercontent.com/{repo_full_name}/HEAD/{quote(path, safe='/')}"
        blob_url = f"https://github.com/{repo_full_name}/blob/HEAD/{quote(path, safe='/')}"
        content = http_get(raw_url, headers=headers)
        if not content:
            return None
        skill = _parse_soul_md(
            content,
            source_url=blob_url,
            source_type=source_type,
            awesome_list=name,
            repo_full_name=repo_full_name,
            path=path,
        )
        if skill is None or not skill.name:
            return None
        return skill

    skills: list[ClawSkill] = []
    target_paths = soul_paths[:max_skills]
    with ThreadPoolExecutor(max_workers=max(1, _AGENT_FETCH_WORKERS)) as pool:
        futures = {pool.submit(_fetch_one, path): path for path in target_paths}
        for idx, future in enumerate(as_completed(futures), start=1):
            try:
                skill = future.result()
            except Exception as exc:
                logging.getLogger(__name__).warning("SOUL.md fetch failed for %s: %s", futures[future], exc)
                skill = None
            if skill is not None:
                skills.append(skill)
            if idx % 50 == 0:
                print(
                    f"  [awesome] Processed {idx}/{len(target_paths)} SOUL.md files, collected {len(skills)} skills",
                    file=sys.stderr,
                )

    print(f"  [awesome] Expanded {len(skills)} agent templates from {name}", file=sys.stderr)
    return skills


def _fetch_skill_from_clawskills(slug: str) -> str:
    """Fetch SKILL.md content for a skill from clawskills.sh or ClawHub.

    ClawSkills.sh entries link to ClawHub skills. We try to find the
    underlying GitHub repo and fetch SKILL.md from there.
    """
    headers = github_headers()

    # The slug format from clawskills.sh is: "author-skillname"
    # This maps to a GitHub user/repo or a clawhub registry entry.
    # Strategy: search GitHub for a repo matching the skill name.

    # Try common GitHub patterns
    # 1. slug itself might be "owner/repo" or "owner-repo"
    if "/" in slug:
        owner, repo_name = slug.split("/", 1)
    else:
        # Try to split "author-skillname" → search as repo name
        parts = slug.split("-", 1)
        if len(parts) == 2:
            owner, repo_name = parts[0], slug
        else:
            owner, repo_name = "", slug

    # Try fetching from GitHub if we can find the repo
    if owner:
        # Try: github.com/{owner}/{repo_name}/SKILL.md
        for repo_guess in [repo_name, repo_name.split("-", 1)[-1] if "-" in repo_name else ""]:
            if not repo_guess:
                continue
            url = f"https://raw.githubusercontent.com/{owner}/{repo_guess}/HEAD/SKILL.md"
            content = http_get(url, headers=headers)
            if content and content.strip().startswith("---"):
                return content
            time.sleep(_CONTENT_DELAY)

    return ""


def _find_skill_md_in_repo(repo_full_name: str) -> tuple[str, str] | None:
    """Try to find and fetch SKILL.md from a GitHub repo."""
    headers = github_headers()

    url = f"https://raw.githubusercontent.com/{repo_full_name}/HEAD/SKILL.md"
    content = http_get(url, headers=headers)
    if content and content.strip().startswith("---"):
        return content, "SKILL.md"

    # Try listing the repo tree for SKILL.md files
    tree_url = f"https://api.github.com/repos/{repo_full_name}/git/trees/HEAD?recursive=1"
    tree_text = http_get_with_rate_retry(tree_url, headers=headers)
    if not tree_text:
        return None

    try:
        tree_data = json.loads(tree_text)
    except (json.JSONDecodeError, ValueError):
        return None

    skill_paths = [
        item["path"] for item in tree_data.get("tree", [])
        if item.get("type") == "blob" and is_valid_skill_filename(item.get("path", ""))
    ]

    for path in skill_paths[:3]:
        raw_url = f"https://raw.githubusercontent.com/{repo_full_name}/HEAD/{path}"
        content = http_get(raw_url, headers=headers)
        if content and content.strip().startswith("---"):
            return content, path
        time.sleep(_CONTENT_DELAY)

    return None


def _fetch_repo_metadata(repo_full_name: str) -> dict[str, Any]:
    """Fetch repository description/topics for GitHub-linked awesome entries."""
    headers = github_headers()
    text = http_get_with_rate_retry(f"https://api.github.com/repos/{repo_full_name}", headers=headers)
    if not text:
        return {}
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# ── Main crawler ─────────────────────────────────────────────────

def _crawl_single_awesome_list(
    list_info: dict[str, str],
    max_skills: int,
    seen_slugs: set[str],
    emit: Any = None,
) -> list[ClawSkill]:
    """Crawl a single awesome-list for skills."""
    owner = list_info["owner"]
    repo = list_info["repo"]
    readme_path = list_info.get("readme_path", "README.md")
    name = list_info.get("name", f"{owner}/{repo}")
    record_kind = str(list_info.get("record_kind", "skill") or "skill")
    source_type = str(list_info.get("source_type", "claw-awesome") or "claw-awesome")

    if record_kind == "agent-template":
        return _crawl_agent_template_list(list_info, max_skills, seen_slugs, emit=emit)

    print(f"[awesome] Fetching {name} README...", file=sys.stderr)
    headers = github_headers()

    # Fetch main README
    url = f"https://raw.githubusercontent.com/{owner}/{repo}/HEAD/{readme_path}"
    readme = http_get(url, headers=headers)
    if not readme:
        print(f"  [awesome] Failed to fetch README for {name}", file=sys.stderr)
        return []

    # Extract skill entries from main README
    all_entries = _extract_skill_entries(readme)

    # Also fetch category sub-pages for complete listings
    category_files = _CATEGORY_FILE_RE.findall(readme)
    print(f"  [awesome] Main page: {len(all_entries)} entries, {len(category_files)} category pages", file=sys.stderr)

    for cat_path in category_files:
        if len(all_entries) >= max_skills * 2:  # Over-collect, dedup later
            break
        cat_url = f"https://raw.githubusercontent.com/{owner}/{repo}/HEAD/{cat_path}"
        cat_text = http_get(cat_url, headers=headers)
        if cat_text:
            cat_entries = _extract_skill_entries(cat_text)
            existing_slugs = {e["slug"] for e in all_entries}
            for e in cat_entries:
                if e["slug"] not in existing_slugs:
                    all_entries.append(e)
        time.sleep(_CONTENT_DELAY)

    print(f"  [awesome] Total entries after categories: {len(all_entries)}", file=sys.stderr)

    skills: list[ClawSkill] = []

    for i, entry in enumerate(all_entries):
        if len(skills) >= max_skills:
            break

        slug = entry["slug"]
        if slug.lower() in seen_slugs:
            continue
        seen_slugs.add(slug.lower())

        repo_meta: dict[str, Any] = {}
        repo_full_name = ""
        if "/" in slug and entry["url"].startswith("https://github.com/"):
            repo_full_name = slug
            repo_meta = _fetch_repo_metadata(repo_full_name)

        description = entry["description"].strip()
        if not description:
            description = str(repo_meta.get("description") or "").strip()

        tags: list[str] = []
        raw_topics = repo_meta.get("topics", [])
        if isinstance(raw_topics, list):
            tags = [str(t).strip() for t in raw_topics if str(t).strip()]

        body_lines = [f"# {entry['name']}", ""]
        if description:
            body_lines += [description, ""]
        body_lines += [f"Source: {entry['url']}"]
        if record_kind == "skill":
            body_lines.append(f"Install: `clawhub install {entry['name']}`")
        else:
            body_lines.append(f"Record kind: {record_kind}")

        # Create skill directly from the entry metadata
        # (awesome-lists provide name + description, which is enough)
        skill = ClawSkill(
            name=entry["name"],
            description=description,
            tags=tags,
            source_url=entry["url"],
            source_type=source_type,
            body_md="\n".join(body_lines).strip() + "\n",
            metadata={"awesome_list": name, "slug": slug, "record_kind": record_kind, "is_placeholder": True},
        )

        # Try to fetch the actual SKILL.md for richer content
        # Only attempt if we have a GitHub token (otherwise too slow)
        if has_github_token() and i < 200:
            raw_content = _fetch_skill_from_clawskills(slug)
            if raw_content:
                full_skill = parse_skill_md(
                    raw_content,
                    source_url=entry["url"],
                    source_type=source_type,
                )
                if full_skill.body_md.strip():
                    full_skill.metadata["awesome_list"] = name
                    full_skill.metadata["record_kind"] = record_kind
                    if not full_skill.name:
                        full_skill.name = entry["name"]
                    skill = full_skill

        if skill.name and skill.body_md.strip():
            skills.append(skill)

        if (i + 1) % 100 == 0:
            print(f"  [awesome] Processed {i + 1}/{len(all_entries)} entries, collected {len(skills)} skills", file=sys.stderr)

    return skills


def crawl_awesome_lists(
    *,
    max_skills: int = 2000,
    lists: list[dict[str, str]] | None = None,
    emit: Any = None,
) -> list[ClawSkill]:
    """Crawl awesome-lists for Agent Skills / OpenClaw skills.

    Parameters
    ----------
    max_skills : int
        Maximum total skills across all lists.
    lists : list[dict], optional
        Custom list definitions. Each dict needs: owner, repo, readme_path.
        Defaults to known awesome-openclaw-skills lists.
    emit : callable, optional
        Progress callback.

    Returns
    -------
    list[ClawSkill]
        Parsed skills from awesome lists.
    """
    print(f"[awesome] Starting crawl (max_skills={max_skills})...", file=sys.stderr)

    awesome_lists = lists or _AWESOME_LISTS
    all_skills: list[ClawSkill] = []
    seen_slugs: set[str] = set()

    for list_info in awesome_lists:
        if len(all_skills) >= max_skills:
            break

        remaining = max_skills - len(all_skills)
        skills = _crawl_single_awesome_list(
            list_info, remaining, seen_slugs, emit=emit,
        )

        # Deduplicate by skill name
        existing_names = {s.name for s in all_skills}
        for s in skills:
            if s.name not in existing_names:
                all_skills.append(s)
                existing_names.add(s.name)

    print(f"[awesome] Total: {len(all_skills)} skills collected", file=sys.stderr)
    return all_skills[:max_skills]
