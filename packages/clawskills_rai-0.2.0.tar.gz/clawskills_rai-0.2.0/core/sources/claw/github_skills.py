"""Search GitHub for SKILL.md files across public repositories.

Uses the GitHub Code Search API to discover Agent Skills format files,
then fetches and parses their content.

Usage:
    from core.sources.claw.github_skills import crawl_github_skills
    skills = crawl_github_skills(max_skills=500)
"""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any
from urllib.parse import quote

from .converter import ClawSkill, parse_skill_md
from .http_client import (
    github_headers,
    has_github_token,
    http_get_with_rate_retry,
    is_valid_skill_filename,
)

# ── Configuration ────────────────────────────────────────────────

_GITHUB_API = "https://api.github.com"

# GitHub Search API: max 10 requests/min unauthenticated, 30/min with token
_SEARCH_DELAY = 2.5  # seconds between search requests
_CONTENT_DELAY = 0.5  # seconds between content fetches
_MAX_SEARCH_REQUESTS_AUTH = 20
_MAX_SEARCH_REQUESTS_ANON = 6
_LOW_YIELD_THRESHOLD = 25
_MAX_CONSECUTIVE_LOW_YIELD = 3


# ── Search queries ───────────────────────────────────────────────

# Keep defaults intentionally small and high-signal. Broad overlapping shards
# caused heavy code-search quota burn with little marginal recall.
_SEARCH_QUERY_SPECS = [
    # Core OpenClaw / Claude skill paths
    {"query": 'path:.claude/skills filename:SKILL.md', "max_pages": 6},
    {"query": 'path:.openclaw/skills filename:SKILL.md', "max_pages": 4},
    {"query": 'path:skills filename:SKILL.md "---"', "max_pages": 4},
    {"query": 'org:openclaw filename:SKILL.md', "max_pages": 2},
    # Emerging agent skill formats
    {"query": 'path:.agents filename:SKILL.md', "max_pages": 3},
    {"query": 'path:.cursor/skills filename:SKILL.md', "max_pages": 2},
    {"query": 'path:.codex filename:SKILL.md', "max_pages": 2},
    {"query": 'path:.opencode filename:SKILL.md', "max_pages": 2},
    # Quality-filtered broad searches
    {"query": 'filename:SKILL.md "name:" "description:" stars:>10', "max_pages": 3},
    {"query": 'filename:SKILL.md "clawhub install"', "max_pages": 2},
    {"query": 'filename:SKILL.md "user-invocable"', "max_pages": 2},
    {"query": 'filename:SKILL.md "openclaw"', "max_pages": 2},
    {"query": 'filename:SKILL.md NOT "name:" "## When"', "max_pages": 2},
]

_REPO_SEARCH_SPECS = [
    {"query": "topic:openclaw-skill", "max_pages": 2},
    {"query": "topic:claude-skill", "max_pages": 2},
    {"query": "topic:claude-code-skill", "max_pages": 2},
    {"query": "topic:agent-skill", "max_pages": 2},
    {"query": "topic:ai-agent-skills", "max_pages": 2},
]


def _normalize_search_specs(queries: list[str | dict[str, Any]] | None) -> list[dict[str, Any]]:
    if queries is None:
        return [dict(spec) for spec in _SEARCH_QUERY_SPECS]

    normalized: list[dict[str, Any]] = []
    for entry in queries:
        if isinstance(entry, str):
            query = entry.strip()
            max_pages = 3
        else:
            query = str(entry.get("query") or "").strip()
            try:
                max_pages = max(1, int(entry.get("max_pages", 3)))
            except (TypeError, ValueError):
                max_pages = 3
        if query:
            normalized.append({"query": query, "max_pages": max_pages})
    return normalized


def _search_code(query: str, *, max_pages: int = 10) -> tuple[list[dict[str, Any]], int]:
    """Search GitHub Code API for files matching a query."""
    headers = github_headers()
    all_items: list[dict[str, Any]] = []
    pages_used = 0

    for page in range(1, max_pages + 1):
        url = f"{_GITHUB_API}/search/code?q={quote(query)}&per_page=100&page={page}"
        text = http_get_with_rate_retry(url, headers=headers)
        if not text:
            break
        pages_used += 1

        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            break

        items = data.get("items", [])
        if not items:
            break

        all_items.extend(items)

        total_count = data.get("total_count", 0)
        if len(all_items) >= total_count or len(all_items) >= 1000:
            break

        time.sleep(_SEARCH_DELAY)

    return all_items, pages_used


def _search_repos(query: str, *, max_pages: int = 10) -> tuple[list[dict[str, Any]], int]:
    """Search GitHub Repository API for repos likely to contain SKILL.md."""
    headers = github_headers()
    all_items: list[dict[str, Any]] = []
    pages_used = 0

    for page in range(1, max_pages + 1):
        url = f"{_GITHUB_API}/search/repositories?q={quote(query)}&per_page=100&page={page}&sort=updated"
        text = http_get_with_rate_retry(url, headers=headers)
        if not text:
            break
        pages_used += 1

        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            break

        items = data.get("items", [])
        if not items:
            break

        all_items.extend(items)

        total_count = data.get("total_count", 0)
        if len(all_items) >= total_count or len(all_items) >= 1000:
            break

        time.sleep(_SEARCH_DELAY)

    return all_items, pages_used


def _fetch_raw_content(repo_full_name: str, path: str, default_branch: str = "HEAD") -> str | None:
    """Fetch raw file content from GitHub."""
    headers = github_headers()
    # URL-encode the path to handle spaces and special characters
    from urllib.parse import quote as urlquote
    safe_path = urlquote(path, safe="/")
    url = f"https://raw.githubusercontent.com/{repo_full_name}/{default_branch}/{safe_path}"
    return http_get_with_rate_retry(url, headers=headers)


def _find_skill_md_in_repo(repo_full_name: str, *, max_paths: int = 20) -> list[tuple[str, str]]:
    """Locate and fetch SKILL.md files from a repo via the tree API."""
    root_content = _fetch_raw_content(repo_full_name, "SKILL.md")
    if root_content and root_content.strip().startswith("---"):
        return [(root_content, "SKILL.md")]

    headers = github_headers()
    tree_url = f"{_GITHUB_API}/repos/{repo_full_name}/git/trees/HEAD?recursive=1"
    tree_text = http_get_with_rate_retry(tree_url, headers=headers)
    if not tree_text:
        return []

    try:
        tree_data = json.loads(tree_text)
    except (json.JSONDecodeError, ValueError):
        return []

    def _path_rank(path: str) -> tuple[int, int, str]:
        lower = path.lower()
        preferred = 0
        if lower == "skill.md":
            preferred = -3
        elif lower.startswith(".claude/skills/") or lower.startswith(".openclaw/skills/"):
            preferred = -2
        elif "/skills/" in lower:
            preferred = -1
        return (preferred, len(path), lower)

    skill_paths = sorted(
        [
            str(item.get("path") or "")
            for item in tree_data.get("tree", [])
            if item.get("type") == "blob" and is_valid_skill_filename(str(item.get("path") or ""))
        ],
        key=_path_rank,
    )

    results: list[tuple[str, str]] = []
    for path in skill_paths[:max_paths]:
        content = _fetch_raw_content(repo_full_name, path)
        if content and content.strip().startswith("---"):
            results.append((content, path))
        time.sleep(_CONTENT_DELAY)

    return results


def _infer_skill_name(skill: ClawSkill, *, file_path: str, repo_full_name: str) -> None:
    """Infer a skill name from the file path or repo name when frontmatter omits it."""
    if skill.name:
        return
    parts = file_path.replace("\\", "/").split("/")
    for i, p in enumerate(parts):
        if p.lower() in ("skills", ".claude", ".openclaw", ".agents", ".cursor", ".codex", ".opencode", ".gemini") and i + 1 < len(parts):
            skill.name = parts[i + 1]
            break
    if not skill.name:
        skill.name = repo_full_name.split("/")[-1]


# ── Main crawler ─────────────────────────────────────────────────

def _process_one_item(item: dict[str, Any], min_stars: int) -> ClawSkill | None:
    """Fetch and parse a single search result item. Thread-safe."""
    repo = item.get("repository", {})
    repo_full = repo.get("full_name", "")
    file_path = item.get("path", "")
    canonical_url = item.get("_canonical_url", "")

    if not repo_full or not file_path:
        return None

    # Optional star filter
    if min_stars > 0 and repo.get("stargazers_count", 0) < min_stars:
        return None

    # Fetch raw content
    content = _fetch_raw_content(repo_full, file_path)
    if not content or not content.strip().startswith("---"):
        return None

    # Parse
    skill = parse_skill_md(content, source_url=canonical_url, source_type="claw-github")

    # Infer name if missing
    _infer_skill_name(skill, file_path=file_path, repo_full_name=repo_full)

    if not skill.body_md.strip():
        return None

    skill.metadata["github_repo"] = repo_full
    skill.metadata["github_stars"] = repo.get("stargazers_count", 0)
    if not skill.source_url:
        skill.source_url = canonical_url

    return skill


def crawl_github_skills(
    *,
    max_skills: int = 2000,
    queries: list[str | dict[str, Any]] | None = None,
    min_stars: int = 0,
    workers: int = 16,
    emit: Any = None,
) -> list[ClawSkill]:
    """Search GitHub for SKILL.md files and parse them.

    Parameters
    ----------
    max_skills : int
        Maximum number of skills to return.
    queries : list[str], optional
        Custom search queries. Defaults to built-in query set.
    min_stars : int
        Minimum repo stars (0 = no filter).
    workers : int
        Number of parallel content-fetch threads (default: 8).
    emit : callable, optional
        Progress callback.

    Returns
    -------
    list[ClawSkill]
        Parsed skills from GitHub.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    print(f"[github-skills] Starting search (max_skills={max_skills}, workers={workers})...", file=sys.stderr)

    search_specs = _normalize_search_specs(queries)
    seen_urls: set[str] = set()
    skills: list[ClawSkill] = []
    seen_repos: set[str] = set()
    search_request_budget = _MAX_SEARCH_REQUESTS_AUTH if has_github_token() else _MAX_SEARCH_REQUESTS_ANON
    search_requests_used = 0
    consecutive_low_yield = 0
    item_budget = min(max(max_skills * 2, 1000), 10_000)

    # Phase 1: Collect all search results (sequential, rate-limited)
    all_items: list[dict[str, Any]] = []
    for qi, spec in enumerate(search_specs):
        if len(all_items) >= item_budget:
            break
        if search_requests_used >= search_request_budget:
            print("[github-skills] Search budget exhausted before finishing code queries", file=sys.stderr)
            break

        query = str(spec["query"])
        max_pages = min(int(spec.get("max_pages", 3)), max(1, search_request_budget - search_requests_used))
        print(f"[github-skills] Query {qi + 1}/{len(search_specs)}: {query}", file=sys.stderr)
        items, pages_used = _search_code(query, max_pages=max_pages)
        search_requests_used += pages_used

        new_items = 0

        for item in items:
            repo = item.get("repository", {})
            repo_full = repo.get("full_name", "")
            file_path = item.get("path", "")
            if not repo_full or not file_path:
                continue
            if repo.get("fork", False):
                continue

            canonical_url = f"https://github.com/{repo_full}/blob/HEAD/{file_path}"
            if canonical_url in seen_urls:
                continue
            seen_urls.add(canonical_url)
            seen_repos.add(repo_full.lower())
            item["_canonical_url"] = canonical_url
            all_items.append(item)
            new_items += 1

        print(
            f"  Found {len(items)} code results, +{new_items} new unique "
            f"(search requests {search_requests_used}/{search_request_budget})",
            file=sys.stderr,
        )

        if new_items <= _LOW_YIELD_THRESHOLD:
            consecutive_low_yield += 1
        else:
            consecutive_low_yield = 0

        if consecutive_low_yield >= _MAX_CONSECUTIVE_LOW_YIELD and len(all_items) >= 1000:
            print("[github-skills] Saturation detected, stopping code search early", file=sys.stderr)
            break

        if search_requests_used >= search_request_budget:
            print("[github-skills] Search budget exhausted after code query", file=sys.stderr)
            break

        time.sleep(_SEARCH_DELAY)

    print(f"[github-skills] Total unique items to fetch: {len(all_items)}", file=sys.stderr)

    # Phase 2: Parallel content fetch + parse
    fetched = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_process_one_item, item, min_stars): item
            for item in all_items[:max_skills * 2]
        }
        for future in as_completed(futures):
            fetched += 1
            try:
                skill = future.result()
            except Exception as exc:
                logging.getLogger(__name__).warning("_process_one_item worker failed: %s", exc)
                skill = None

            if skill is not None:
                skills.append(skill)

            if len(skills) % 100 == 0 and len(skills) > 0:
                print(f"  [github-skills] Collected {len(skills)} skills ({fetched}/{len(futures)} fetched)", file=sys.stderr)

            if len(skills) >= max_skills:
                # Cancel remaining futures
                for f in futures:
                    f.cancel()
                break

    # Phase 3: Repo-search supplement. This uses fewer broad searches than
    # extra code-search shards and helps recover skills missed by code search.
    if len(skills) < max_skills and search_requests_used < search_request_budget:
        existing_names = {s.name.strip().lower() for s in skills if s.name.strip()}
        repo_low_yield = 0
        for ri, spec in enumerate(_REPO_SEARCH_SPECS):
            if len(skills) >= max_skills:
                break
            if search_requests_used >= search_request_budget:
                break

            query = str(spec["query"])
            max_pages = min(int(spec.get("max_pages", 2)), max(1, search_request_budget - search_requests_used))
            print(f"[github-skills] Repo query {ri + 1}/{len(_REPO_SEARCH_SPECS)}: {query}", file=sys.stderr)
            repos, pages_used = _search_repos(query, max_pages=max_pages)
            search_requests_used += pages_used

            added_skills = 0
            for repo in repos:
                repo_full = str(repo.get("full_name") or "").strip()
                if not repo_full or repo.get("fork", False):
                    continue
                repo_key = repo_full.lower()
                if repo_key in seen_repos:
                    continue
                seen_repos.add(repo_key)

                for content, file_path in _find_skill_md_in_repo(repo_full):
                    canonical_url = f"https://github.com/{repo_full}/blob/HEAD/{file_path}"
                    if canonical_url in seen_urls:
                        continue
                    seen_urls.add(canonical_url)

                    skill = parse_skill_md(content, source_url=canonical_url, source_type="claw-github")
                    _infer_skill_name(skill, file_path=file_path, repo_full_name=repo_full)
                    if not skill.body_md.strip() or not skill.name:
                        continue

                    name_key = skill.name.strip().lower()
                    if name_key in existing_names:
                        continue
                    existing_names.add(name_key)

                    skill.metadata["github_repo"] = repo_full
                    skill.metadata["github_stars"] = repo.get("stargazers_count", 0)
                    skills.append(skill)
                    added_skills += 1

                    if len(skills) >= max_skills:
                        break
                if len(skills) >= max_skills:
                    break

            print(
                f"  Found {len(repos)} repos, +{added_skills} skills "
                f"(search requests {search_requests_used}/{search_request_budget})",
                file=sys.stderr,
            )

            if added_skills <= max(5, _LOW_YIELD_THRESHOLD // 5):
                repo_low_yield += 1
            else:
                repo_low_yield = 0
            if repo_low_yield >= 2 and len(skills) >= 1000:
                print("[github-skills] Repo search saturation detected, stopping early", file=sys.stderr)
                break

            if search_requests_used >= search_request_budget:
                print("[github-skills] Search budget exhausted during repo queries", file=sys.stderr)
                break

            time.sleep(_SEARCH_DELAY)

    print(f"[github-skills] Total: {len(skills)} skills collected", file=sys.stderr)
    return skills[:max_skills]
