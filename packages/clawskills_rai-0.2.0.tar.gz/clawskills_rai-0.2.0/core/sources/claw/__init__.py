"""Claw ecosystem skill aggregator.

Collects skills from ClawHub, the official OpenClaw archive, GitHub
SKILL.md files, and awesome-lists,
converts them to ClawSkills format, and outputs a SQLite bundle.

Usage (CLI):
    python -m core.sources.claw --max-skills 500 --out dist/claw-bundle.sqlite

Usage (Python):
    from core.sources.claw import aggregate_claw_skills, build_claw_bundle
    skills = aggregate_claw_skills(max_skills=500)
    build_claw_bundle(skills, out_path="dist/claw-bundle.sqlite")
"""

from __future__ import annotations

import argparse
import hashlib
import logging
import os
import sqlite3
import sys
import tempfile
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from .converter import ClawSkill, to_bundle_row

# ── SQLite DDL (matches build_bundle.py) ─────────────────────────

_DDL_BUNDLE_META = """
CREATE TABLE IF NOT EXISTS bundle_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
)
"""

_DDL_SKILLS_INDEX = """
CREATE TABLE IF NOT EXISTS skills_index (
    skill_id          TEXT PRIMARY KEY,
    domain            TEXT,
    profile           TEXT,
    source_type       TEXT,
    source_url        TEXT,
    title             TEXT,
    overall_score     REAL,
    skill_kind        TEXT,
    language          TEXT,
    source_id         TEXT,
    primary_source_id TEXT
)
"""

_DDL_SKILLS_CONTENT = """
CREATE TABLE IF NOT EXISTS skills_content (
    skill_id      TEXT PRIMARY KEY,
    metadata_yaml TEXT,
    skill_md      TEXT,
    library_md    TEXT
)
"""

_DDL_FTS = """
CREATE VIRTUAL TABLE IF NOT EXISTS skills_fts
USING fts5(title, domain, skill_id UNINDEXED, content='skills_index', content_rowid='rowid')
"""

_INDEX_COLS = [
    "skill_id", "domain", "profile", "source_type", "source_url",
    "title", "overall_score", "skill_kind", "language",
    "source_id", "primary_source_id",
]

_CONTENT_COLS = ["skill_id", "metadata_yaml", "skill_md", "library_md"]


# ── Aggregation ──────────────────────────────────────────────────

def aggregate_claw_skills(
    *,
    max_skills: int = 5000,
    sources: list[str] | None = None,
    emit: Any = None,
) -> list[ClawSkill]:
    """Collect skills from all Claw ecosystem sources.

    Parameters
    ----------
    max_skills : int
        Maximum total skills to collect.
    sources : list[str], optional
        Which sources to use. Defaults to all:
        ["clawhub", "archive", "github", "awesome"].
    emit : callable, optional
        Progress callback.

    Returns
    -------
    list[ClawSkill]
    """
    from .converter import infer_skill_kind

    active_sources = sources or ["clawhub", "archive", "github", "awesome"]
    all_skills: list[ClawSkill] = []
    # Dedupe by (kind, normalized_name) — keep highest-quality version per key.
    best_by_key: dict[str, tuple[float, int, ClawSkill]] = {}

    def _skill_score(s: ClawSkill) -> float:
        """Heuristic quality score for winner selection."""
        score = 0.0
        # Placeholder entries (awesome-list stubs without real SKILL.md content)
        # are penalized so real parsed skills always win when both exist.
        if s.metadata.get("is_placeholder"):
            score -= 5.0
        if s.body_md and len(s.body_md.strip()) > 100:
            score += 2.0
        if s.description:
            score += 1.0
        if s.tags:
            score += 0.5
        if s.source_url:
            score += 0.5
        # Read quality signal from metadata — check all known score keys.
        for key in ("repo_priority_score", "priority_score", "overall_score"):
            try:
                val = float(s.metadata.get(key) or 0)
                if val > 0:
                    score += val
                    break
            except (ValueError, TypeError):
                continue
        return score

    def _add_deduped(new_skills: list[ClawSkill]) -> int:
        newly_added = 0
        for s in new_skills:
            name_key = str(s.name or "").strip().lower()
            if not name_key:
                continue
            kind = infer_skill_kind(s)
            dedupe_key = f"{kind}:{name_key}"
            score = _skill_score(s)
            existing = best_by_key.get(dedupe_key)
            if existing is None:
                best_by_key[dedupe_key] = (score, len(best_by_key), s)
                newly_added += 1
            elif score > existing[0]:
                # Replace with higher-quality version — not a new unique addition
                best_by_key[dedupe_key] = (score, existing[1], s)
        return newly_added

    def _finalize_skills() -> list[ClawSkill]:
        """Return deduplicated skills sorted by quality score (descending), capped at max_skills."""
        items = sorted(best_by_key.values(), key=lambda t: (-t[0], t[1]))
        return [s for _, _, s in items[:max_skills]]

    # Distribute quota across sources
    per_source = max(100, max_skills // max(len(active_sources), 1))
    _log = logging.getLogger(__name__)

    # Per-source stats: tracks found/added/errors for each source
    source_stats: dict[str, dict[str, int]] = {}

    if "clawhub" in active_sources:
        try:
            from .clawhub import crawl_clawhub
            # ClawHub gets full quota — don't cap at per_source
            skills = crawl_clawhub(max_skills=max_skills, emit=emit)
            added = _add_deduped(skills)
            source_stats["clawhub"] = {"found": len(skills), "added": added, "error": 0}
            _log.info("[aggregate] ClawHub: %d new skills (of %d found)", added, len(skills))
        except Exception as e:
            source_stats["clawhub"] = {"found": 0, "added": 0, "error": 1}
            _log.warning("[aggregate] ClawHub source failed: %s", e)

    if "archive" in active_sources and len(best_by_key) < max_skills:
        try:
            from .openclaw_archive import crawl_openclaw_archive

            remaining = max_skills - len(best_by_key)
            skills = crawl_openclaw_archive(max_skills=min(per_source, remaining), emit=emit)
            added = _add_deduped(skills)
            source_stats["archive"] = {"found": len(skills), "added": added, "error": 0}
            _log.info("[aggregate] OpenClaw archive: %d new skills (of %d found)", added, len(skills))
        except Exception as e:
            source_stats["archive"] = {"found": 0, "added": 0, "error": 1}
            _log.warning("[aggregate] OpenClaw archive source failed: %s", e)

    if "github" in active_sources and len(best_by_key) < max_skills:
        try:
            from .github_skills import crawl_github_skills
            remaining = max_skills - len(best_by_key)
            skills = crawl_github_skills(max_skills=min(per_source, remaining), emit=emit)
            added = _add_deduped(skills)
            source_stats["github"] = {"found": len(skills), "added": added, "error": 0}
            _log.info("[aggregate] GitHub: %d new skills (of %d found)", added, len(skills))
        except Exception as e:
            source_stats["github"] = {"found": 0, "added": 0, "error": 1}
            _log.warning("[aggregate] GitHub source failed: %s", e)

    if "awesome" in active_sources and len(best_by_key) < max_skills:
        try:
            from .awesome_parser import crawl_awesome_lists
            remaining = max_skills - len(best_by_key)
            skills = crawl_awesome_lists(max_skills=min(per_source, remaining), emit=emit)
            added = _add_deduped(skills)
            source_stats["awesome"] = {"found": len(skills), "added": added, "error": 0}
            _log.info("[aggregate] Awesome: %d new skills (of %d found)", added, len(skills))
        except Exception as e:
            source_stats["awesome"] = {"found": 0, "added": 0, "error": 1}
            _log.warning("[aggregate] Awesome source failed: %s", e)

    all_skills = _finalize_skills()
    _log.info("[aggregate] Total unique skills: %d (source_stats=%s)", len(all_skills), source_stats)
    return all_skills


# ── Full pipeline (tier 1-4) ────────────────────────────────────

def aggregate_claw_full(
    *,
    max_skills: int = 5000,
    out_path: str | Path = "",
    version: str = "",
    state_db: str | Path = "",
    max_repos: int = 500,
    changed_only: bool = True,
    emit: Any = None,
) -> Path:
    """Run the full 4-tier Claw pipeline: aggregate → registry → mine → clean → bundle.

    This is the canonical build path that chains all tiers:
    1. Tier 1: ``aggregate_claw_skills()`` — ClawHub / archive / GitHub / awesome
    2. Tier 2: ``aggregate_claw_repos()`` — repo registry discovery
    3. Tier 3: ``mine_repo_state()`` — incremental file-level mining
    4. Tier 4: ``clean_claw_bundle()`` — deduplication and cleaning

    Parameters
    ----------
    max_skills : int
        Target skill count for the final bundle.
    out_path : str | Path
        Output bundle path. Defaults to ``dist/clawskills-bundle-lite-claw-full-v{date}.sqlite``.
    state_db : str | Path
        Repo state database path. Defaults to ``dist/claw-repo-state.sqlite``.
    max_repos : int
        Maximum repos to discover in tier 2.
    changed_only : bool
        Only mine repos whose tree SHA changed since last run.
    """
    _log = logging.getLogger(__name__)
    version = version or date.today().strftime("%Y%m%d")

    # Defaults
    if not out_path:
        out_path = Path("dist") / f"clawskills-bundle-lite-claw-full-v{version}.sqlite"
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if not state_db:
        state_db = Path("dist") / "claw-repo-state.sqlite"

    # ── Tier 1: direct aggregation ──
    _log.info("[full-pipeline] Tier 1: aggregate_claw_skills(max=%d)", max_skills)
    tier1_skills = aggregate_claw_skills(max_skills=max_skills, emit=emit)

    # ── Tier 2: repo registry ──
    tier2_skills: list[ClawSkill] = []
    repos = []
    try:
        from .repo_registry import aggregate_claw_repos, sync_repo_state
        _log.info("[full-pipeline] Tier 2: aggregate_claw_repos(max=%d)", max_repos)
        repos = aggregate_claw_repos(max_repos=max_repos, emit=emit)
        _log.info("[full-pipeline] Tier 2: discovered %d repos", len(repos))
        # Persist repos into state DB so tier 3 can find them.
        if repos:
            sync_repo_state(repos, state_db=str(state_db))
            _log.info("[full-pipeline] Tier 2: synced %d repos to state DB", len(repos))
    except Exception as e:
        _log.warning("[full-pipeline] Tier 2 failed: %s", e)

    # ── Tier 3: incremental mining ──
    if repos:
        try:
            from .repo_miner import mine_repo_state
            _log.info("[full-pipeline] Tier 3: mine_repo_state(changed_only=%s)", changed_only)
            tier3_result, mine_stats = mine_repo_state(
                state_db=str(state_db),
                changed_only=changed_only,
                max_repos=max_repos,
            )
            tier2_skills = tier3_result
            _log.info("[full-pipeline] Tier 3: mined %d skills (stats=%s)", len(tier2_skills), mine_stats)
        except Exception as e:
            _log.warning("[full-pipeline] Tier 3 failed: %s", e)

    # ── Merge tier 1 + tier 3 ──
    all_skills = tier1_skills + tier2_skills
    _log.info("[full-pipeline] Merged: %d skills total (tier1=%d, tier3=%d)", len(all_skills), len(tier1_skills), len(tier2_skills))

    # ── Build intermediate bundle ──
    intermediate = out_path.with_suffix(".raw.sqlite")
    build_claw_bundle(all_skills, out_path=intermediate, version=version, source="claw-full-pipeline")

    # ── Tier 4: clean ──
    try:
        from .clean_bundle import clean_claw_bundle
        _log.info("[full-pipeline] Tier 4: clean_claw_bundle()")
        clean_path, clean_stats = clean_claw_bundle(str(intermediate), out_path=str(out_path), version=version)
        _log.info("[full-pipeline] Tier 4: cleaned bundle → %s (stats=%s)", clean_path, clean_stats)
    except Exception as e:
        _log.warning("[full-pipeline] Tier 4 (clean) failed, using raw bundle: %s", e)
        if intermediate.exists():
            import shutil
            shutil.copy2(intermediate, out_path)
        elif not out_path.exists():
            # No skills at all — write an empty valid bundle
            build_claw_bundle([], out_path=out_path, version=version, source="claw-full-pipeline-empty")

    # Cleanup intermediate
    try:
        intermediate.unlink(missing_ok=True)
    except Exception:
        pass

    _log.info("[full-pipeline] Done: %s", out_path)
    return out_path


# ── Bundle builder ───────────────────────────────────────────────

def build_claw_bundle(
    skills: list[ClawSkill],
    out_path: str | Path,
    version: str = "",
    source: str = "claw-ecosystem",
) -> Path:
    """Build a SQLite bundle from collected Claw skills.

    Output format is identical to ClawSkills' standard bundles.

    Parameters
    ----------
    skills : list[ClawSkill]
        Skills to include.
    out_path : str | Path
        Output .sqlite file path.
    version : str
        Version string. Defaults to today's date.

    Returns
    -------
    Path
        The output file path.
    """
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    version = version or date.today().strftime("%Y%m%d")

    # Convert skills to bundle rows
    rows: list[dict[str, Any]] = []
    for skill in skills:
        row = to_bundle_row(skill)
        if row:
            rows.append(row)

    print(f"[bundle] Building SQLite bundle: {len(rows)} valid skills", file=sys.stderr)

    if not rows:
        print("[bundle] No valid skills to write — creating empty bundle.", file=sys.stderr)
        # Still create a valid empty SQLite so downstream consumers have a valid file.

    # Build in temp file, then atomic rename
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".sqlite", dir=out.parent)
    os.close(tmp_fd)

    try:
        conn = sqlite3.connect(tmp_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute(_DDL_BUNDLE_META)
        conn.execute(_DDL_SKILLS_INDEX)
        conn.execute(_DDL_SKILLS_CONTENT)
        conn.commit()

        # Batch insert
        batch_size = 500
        inserted = 0
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]

            idx_ph = ",".join("?" for _ in _INDEX_COLS)
            conn.executemany(
                f"INSERT OR REPLACE INTO skills_index ({','.join(_INDEX_COLS)}) VALUES ({idx_ph})",
                [[row.get(c, "") for c in _INDEX_COLS] for row in batch],
            )

            cnt_ph = ",".join("?" for _ in _CONTENT_COLS)
            conn.executemany(
                f"INSERT OR REPLACE INTO skills_content ({','.join(_CONTENT_COLS)}) VALUES ({cnt_ph})",
                [[row.get(c, "") for c in _CONTENT_COLS] for row in batch],
            )

            conn.commit()
            inserted += len(batch)

        # Build FTS5 index
        try:
            conn.execute(_DDL_FTS)
            conn.execute("INSERT INTO skills_fts(skills_fts) VALUES('rebuild')")
            conn.commit()
            print("[bundle] FTS5 index built.", file=sys.stderr)
        except Exception as e:
            print(f"[bundle] FTS5 warning: {e}", file=sys.stderr)

        # Write metadata
        meta = {
            "version": f"v{version}",
            "created_at": datetime.now(tz=timezone.utc).isoformat(),
            "total_skills": str(inserted),
            "bundle_type": "lite",
            "source": source,
        }
        for k, v in meta.items():
            conn.execute(
                "INSERT OR REPLACE INTO bundle_meta (key, value) VALUES (?, ?)",
                (k, v),
            )
        conn.commit()
        conn.close()

        # Atomic rename
        os.replace(tmp_path, out)

        # Write SHA256 checksum
        h = hashlib.sha256()
        with open(out, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        checksum_path = out.with_suffix(out.suffix + ".sha256")
        checksum_path.write_text(f"{h.hexdigest()}  {out.name}\n", encoding="utf-8")

        print(f"[bundle] Written: {out} ({inserted} skills)", file=sys.stderr)
        print(f"[bundle] Checksum: {checksum_path}", file=sys.stderr)
        return out

    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# ── Statistics ───────────────────────────────────────────────────

def print_stats(skills: list[ClawSkill]) -> None:
    """Print a summary of collected skills."""
    from collections import Counter
    from .converter import infer_domain

    source_counts = Counter(s.source_type for s in skills)
    domain_counts = Counter(infer_domain(s) for s in skills)
    license_counts = Counter(s.license_spdx or "unknown" for s in skills)
    has_body = sum(1 for s in skills if s.body_md.strip())

    print(f"\n{'='*60}", file=sys.stderr)
    print("Claw Ecosystem Aggregation Report", file=sys.stderr)
    print(f"{'='*60}", file=sys.stderr)
    print(f"Total skills: {len(skills)}", file=sys.stderr)
    print(f"With content: {has_body}", file=sys.stderr)
    print("\nBy source:", file=sys.stderr)
    for src, cnt in source_counts.most_common():
        print(f"  {src}: {cnt}", file=sys.stderr)
    print("\nBy domain:", file=sys.stderr)
    for dom, cnt in domain_counts.most_common(15):
        print(f"  {dom}: {cnt}", file=sys.stderr)
    print("\nBy license (top 10):", file=sys.stderr)
    for lic, cnt in license_counts.most_common(10):
        print(f"  {lic}: {cnt}", file=sys.stderr)
    print(f"{'='*60}\n", file=sys.stderr)


# ── CLI entry point ──────────────────────────────────────────────

def cli_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="clawskills-claw-aggregate",
        description="Aggregate skills from the Claw ecosystem (ClawHub, official archive, GitHub, awesome-lists)",
    )
    parser.add_argument(
        "--max-skills", type=int, default=5000,
        help="Maximum total skills to collect (default: 5000)",
    )
    parser.add_argument(
        "--sources", default="clawhub,archive,github,awesome",
        help="Comma-separated source list (default: clawhub,archive,github,awesome)",
    )
    parser.add_argument(
        "--out", default="",
        help="Output SQLite path (default: dist/clawskills-bundle-lite-claw-v{date}.sqlite)",
    )
    parser.add_argument(
        "--version", default="",
        help="Bundle version string (default: today's date)",
    )
    parser.add_argument(
        "--stats-only", action="store_true",
        help="Only print stats, don't build bundle",
    )

    args = parser.parse_args(argv)
    source_list = [s.strip() for s in args.sources.split(",") if s.strip()]
    version = args.version or date.today().strftime("%Y%m%d")

    # Aggregate
    skills = aggregate_claw_skills(
        max_skills=args.max_skills,
        sources=source_list,
    )

    if not skills:
        print("No skills collected. Check network and API tokens.", file=sys.stderr)
        return 1

    # Stats
    print_stats(skills)

    if args.stats_only:
        return 0

    # Build bundle
    out_path = args.out or f"dist/clawskills-bundle-lite-claw-v{version}.sqlite"
    build_claw_bundle(skills, out_path, version=version)

    return 0


if __name__ == "__main__":
    raise SystemExit(cli_main())
