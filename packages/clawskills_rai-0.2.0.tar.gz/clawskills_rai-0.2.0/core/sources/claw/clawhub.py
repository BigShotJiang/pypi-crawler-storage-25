"""Crawl skills from ClawHub (clawhub.ai).

ClawHub is the official OpenClaw skill registry (~4K+ community skills).
This module discovers skills via the search API, fetches metadata via the
skill detail API, and extracts SKILL.md content from registry pages.

Discovered API surface (as of 2026-04):
- GET /api/v1/search?q={keyword}&limit=200  → vector search, returns slugs
- GET /api/v1/skills/{slug}                 → metadata + stats
- GET /api/v1/skills/{slug}/versions/{ver}  → file list with SHA256
- GET /registry/{slug}/{ver}/SKILL.md       → HTML with embedded SKILL.md

Usage:
    from core.sources.claw.clawhub import crawl_clawhub
    skills = crawl_clawhub(max_skills=5000)
"""

from __future__ import annotations

import json
import logging
import re
import string
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .converter import ClawSkill, parse_skill_md
from .http_client import http_get

_log = logging.getLogger(__name__)

# ── Configuration ────────────────────────────────────────────────

_CLAWHUB_BASE = "https://clawhub.ai"
_SEARCH_LIMIT = 200  # max results per search call
_FETCH_WORKERS = 12
_RATE_DELAY = 0.25  # seconds between API calls

# Search queries to cover the full registry.
# The search API is vector-based and doesn't support wildcards,
# so we fan out across letters, digits, and common keywords.
_SEARCH_QUERIES = (
    list(string.ascii_lowercase)
    + list(string.digits)
    + [
        "ai", "agent", "code", "dev", "api", "web", "data", "ml",
        "docker", "git", "react", "python", "node", "test", "deploy",
        "aws", "sql", "linux", "security", "prompt", "llm", "cli",
        "mcp", "tool", "search", "file", "database", "cloud", "debug",
    ]
)


# ── Phase 1: Discover all slugs via search API ──────────────────

def _discover_slugs(max_skills: int, emit: Any = None) -> list[dict[str, Any]]:
    """Fan-out search queries to discover all skill slugs on ClawHub."""
    all_slugs: dict[str, dict[str, Any]] = {}

    for i, query in enumerate(_SEARCH_QUERIES):
        if len(all_slugs) >= max_skills:
            break
        url = f"{_CLAWHUB_BASE}/api/v1/search?q={query}&limit={_SEARCH_LIMIT}"
        text = http_get(url)
        if not text:
            continue
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            continue

        results = data.get("results", [])
        for r in results:
            slug = str(r.get("slug") or "").strip()
            if slug and slug not in all_slugs:
                all_slugs[slug] = {
                    "slug": slug,
                    "displayName": str(r.get("displayName") or slug),
                    "summary": str(r.get("summary") or ""),
                }

        if (i + 1) % 10 == 0:
            _log.info("[clawhub] Discovery: %d queries done, %d unique slugs", i + 1, len(all_slugs))
        time.sleep(_RATE_DELAY)

    slugs = list(all_slugs.values())[:max_skills]
    _log.info("[clawhub] Discovered %d unique skill slugs", len(slugs))
    return slugs


# ── Phase 2: Fetch skill detail + resolve version ───────────────

def _fetch_skill_version(slug: str) -> str:
    """Get the latest version string for a skill."""
    url = f"{_CLAWHUB_BASE}/api/v1/skills/{slug}"
    text = http_get(url)
    if not text:
        return ""
    try:
        data = json.loads(text)
        skill = data.get("skill", {})
        tags = skill.get("tags", {})
        return str(tags.get("latest") or data.get("latestVersion", {}).get("version") or "")
    except (json.JSONDecodeError, ValueError, AttributeError):
        return ""


# ── Phase 3: Fetch SKILL.md content from registry page ──────────

def _extract_skillmd_from_registry_html(html: str) -> str:
    """Extract embedded SKILL.md content from a ClawHub registry page.

    The registry page is a React SPA that embeds the full SKILL.md as a
    JSON-encoded string in its JavaScript bundle.
    """
    # Search for long JSON strings that start with YAML frontmatter.
    all_json_strings = re.findall(r'"((?:[^"\\]|\\.){50,})"', html)
    for s in all_json_strings:
        try:
            decoded = json.loads(f'"{s}"')
            if decoded.strip().startswith("---") and "name:" in decoded[:300]:
                return decoded
        except (json.JSONDecodeError, ValueError):
            continue
    return ""


def _fetch_one_skill(info: dict[str, Any]) -> ClawSkill | None:
    """Fetch a single skill's SKILL.md content. Thread-safe."""
    slug = info["slug"]
    display_name = info.get("displayName", slug)
    summary = info.get("summary", "")

    # Step 1: Get latest version
    version = _fetch_skill_version(slug)
    if not version:
        # No version info — create a metadata-only entry
        return ClawSkill(
            name=display_name,
            description=summary,
            source_url=f"{_CLAWHUB_BASE}/skills/{slug}",
            source_type="claw-clawhub",
            body_md=f"# {display_name}\n\n{summary}\n",
            metadata={"clawhub_slug": slug, "is_placeholder": True},
        )

    time.sleep(_RATE_DELAY)

    # Step 2: Fetch registry page and extract SKILL.md
    registry_url = f"{_CLAWHUB_BASE}/registry/{slug}/{version}/SKILL.md"
    html = http_get(registry_url)
    if not html:
        return ClawSkill(
            name=display_name,
            description=summary,
            source_url=f"{_CLAWHUB_BASE}/skills/{slug}",
            source_type="claw-clawhub",
            body_md=f"# {display_name}\n\n{summary}\n",
            metadata={"clawhub_slug": slug, "clawhub_version": version, "is_placeholder": True},
        )

    skill_md = _extract_skillmd_from_registry_html(html)
    if not skill_md:
        return ClawSkill(
            name=display_name,
            description=summary,
            source_url=f"{_CLAWHUB_BASE}/skills/{slug}",
            source_type="claw-clawhub",
            body_md=f"# {display_name}\n\n{summary}\n",
            metadata={"clawhub_slug": slug, "clawhub_version": version, "is_placeholder": True},
        )

    skill = parse_skill_md(
        skill_md,
        source_url=f"{_CLAWHUB_BASE}/registry/{slug}/{version}/SKILL.md",
        source_type="claw-clawhub",
    )
    if not skill.name:
        skill.name = display_name
    skill.metadata["clawhub_slug"] = slug
    skill.metadata["clawhub_version"] = version
    return skill


# ── Public API ───────────────────────────────────────────────────

def crawl_clawhub(
    *,
    max_skills: int = 5000,
    emit: Any = None,
) -> list[ClawSkill]:
    """Crawl ClawHub for skills via search API + registry pages.

    Phase 1: Discover slugs by fanning out search queries across letters/keywords.
    Phase 2: Fetch SKILL.md content from registry pages in parallel.

    Parameters
    ----------
    max_skills : int
        Maximum number of skills to fetch.
    emit : callable, optional
        Progress callback.

    Returns
    -------
    list[ClawSkill]
        Parsed skills from ClawHub.
    """
    print(f"[clawhub] Starting crawl (max_skills={max_skills})...", file=sys.stderr)

    # Phase 1: Discover
    slugs = _discover_slugs(max_skills, emit=emit)
    if not slugs:
        print("[clawhub] No skills discovered from search API", file=sys.stderr)
        return []

    # Phase 2: Fetch content in parallel
    skills: list[ClawSkill] = []
    fetched = 0
    with ThreadPoolExecutor(max_workers=_FETCH_WORKERS) as pool:
        futures = {pool.submit(_fetch_one_skill, info): info for info in slugs}
        for future in as_completed(futures):
            fetched += 1
            try:
                skill = future.result()
            except Exception as exc:
                _log.warning("[clawhub] Fetch failed for %s: %s", futures[future].get("slug"), exc)
                skill = None

            if skill is not None:
                skills.append(skill)

            if fetched % 100 == 0:
                real_count = sum(1 for s in skills if not s.metadata.get("is_placeholder"))
                print(
                    f"  [clawhub] Progress: {fetched}/{len(slugs)} fetched, "
                    f"{len(skills)} collected ({real_count} with SKILL.md content)",
                    file=sys.stderr,
                )

    real_count = sum(1 for s in skills if not s.metadata.get("is_placeholder"))
    print(f"[clawhub] Done: {len(skills)} skills ({real_count} with full SKILL.md, "
          f"{len(skills) - real_count} metadata-only)", file=sys.stderr)
    return skills[:max_skills]
