"""Incrementally mine SKILL.md and SOUL.md content from the claw repo registry."""

from __future__ import annotations

import argparse
import base64
import json
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from . import build_claw_bundle
from .awesome_parser import _parse_soul_md
from .converter import ClawSkill, parse_skill_md
from .http_client import github_headers, http_get_with_rate_retry
from .repo_state import ClawRepoStateStore


@dataclass
class _FileMineResult:
    repo_full_name: str
    path: str
    file_kind: str
    status: str
    skill: ClawSkill | None = None
    error: str = ""


def _decode_github_api_content(payload_text: str) -> str | None:
    try:
        payload = json.loads(payload_text)
    except (json.JSONDecodeError, ValueError, TypeError):
        return None
    if not isinstance(payload, dict):
        return None
    encoding = str(payload.get("encoding") or "").strip().lower()
    content = payload.get("content")
    if encoding == "base64" and isinstance(content, str):
        try:
            return base64.b64decode(content.encode("utf-8"), validate=False).decode("utf-8", errors="replace")
        except Exception:
            return None
    if isinstance(content, str):
        return content
    return None


def _fetch_repo_file(repo_full_name: str, path: str, *, blob_sha: str = "") -> str | None:
    headers = github_headers()
    raw_url = f"https://raw.githubusercontent.com/{repo_full_name}/HEAD/{quote(path, safe='/')}"
    text = http_get_with_rate_retry(raw_url, headers=headers)
    if text is not None:
        return text

    contents_url = f"https://api.github.com/repos/{repo_full_name}/contents/{quote(path, safe='/')}"
    raw_text = http_get_with_rate_retry(
        contents_url,
        headers={**headers, "Accept": "application/vnd.github.raw+json"},
    )
    if raw_text is not None:
        return raw_text

    contents_json = http_get_with_rate_retry(contents_url, headers=headers)
    if contents_json is not None:
        decoded = _decode_github_api_content(contents_json)
        if decoded is not None:
            return decoded

    sha = str(blob_sha or "").strip()
    if sha:
        blob_json = http_get_with_rate_retry(
            f"https://api.github.com/repos/{repo_full_name}/git/blobs/{sha}",
            headers=headers,
        )
        if blob_json is not None:
            decoded = _decode_github_api_content(blob_json)
            if decoded is not None:
                return decoded
    return None


def _default_skill_name(repo_full_name: str, path: str) -> str:
    parts = [part for part in path.split("/") if part]
    if len(parts) >= 2:
        return parts[-2].replace("-", " ").replace("_", " ").title()
    return repo_full_name.split("/")[-1].replace("-", " ").replace("_", " ").title()


def _enrich_skill(
    skill: ClawSkill,
    *,
    repo_state: dict[str, Any],
    path: str,
    file_kind: str,
) -> ClawSkill:
    repo_full_name = str(repo_state.get("repo_full_name") or "")
    repo_url = str(repo_state.get("repo_url") or f"https://github.com/{repo_full_name}")
    repo_kind = str(repo_state.get("repo_kind") or "unknown")
    if not skill.name:
        skill.name = _default_skill_name(repo_full_name, path)
    if not skill.description:
        skill.description = str(repo_state.get("repo_description") or repo_full_name or skill.name)
    meta = dict(skill.metadata or {})
    if not meta.get("record_kind"):
        meta["record_kind"] = "agent-template" if file_kind == "soul_md" else "skill"
    meta["repo_full_name"] = repo_full_name
    meta["repo_url"] = repo_url
    meta["repo_kind"] = repo_kind
    meta["repo_file_path"] = path
    meta["repo_tree_sha"] = str(repo_state.get("tree_sha") or "")
    meta["repo_priority_score"] = float(repo_state.get("priority_score") or 0.0)
    meta["mined_from_repo_registry"] = True
    skill.metadata = meta
    return skill


def _mine_one_file(repo_state: dict[str, Any], file_row: dict[str, Any]) -> _FileMineResult:
    repo_full_name = str(repo_state.get("repo_full_name") or "")
    path = str(file_row.get("path") or "")
    file_kind = str(file_row.get("file_kind") or "")
    blob_url = str(file_row.get("source_url") or f"https://github.com/{repo_full_name}/blob/HEAD/{quote(path, safe='/')}")
    text = _fetch_repo_file(repo_full_name, path, blob_sha=str(file_row.get("blob_sha") or ""))
    if text is None:
        return _FileMineResult(
            repo_full_name=repo_full_name,
            path=path,
            file_kind=file_kind,
            status="fetch_error",
            error="failed to fetch raw file content",
        )
    if not text.strip():
        return _FileMineResult(
            repo_full_name=repo_full_name,
            path=path,
            file_kind=file_kind,
            status="parse_error",
            error="file is empty",
        )

    try:
        if file_kind == "soul_md":
            skill = _parse_soul_md(
                text,
                source_url=blob_url,
                source_type="claw-repo-agent",
                awesome_list="repo-registry",
                repo_full_name=repo_full_name,
                path=path,
            )
        else:
            skill = parse_skill_md(
                text,
                source_url=blob_url,
                source_type="claw-repo-skill",
            )
    except Exception as exc:
        return _FileMineResult(
            repo_full_name=repo_full_name,
            path=path,
            file_kind=file_kind,
            status="parse_error",
            error=str(exc),
        )

    if skill is None:
        return _FileMineResult(
            repo_full_name=repo_full_name,
            path=path,
            file_kind=file_kind,
            status="parse_error",
            error="parser returned no skill",
        )

    skill = _enrich_skill(skill, repo_state=repo_state, path=path, file_kind=file_kind)
    if not skill.name or not skill.body_md.strip():
        return _FileMineResult(
            repo_full_name=repo_full_name,
            path=path,
            file_kind=file_kind,
            status="parse_error",
            error="parsed skill is missing name or body",
        )

    return _FileMineResult(
        repo_full_name=repo_full_name,
        path=path,
        file_kind=file_kind,
        status="emitted",
        skill=skill,
    )


def mine_repo_state(
    *,
    state_db: str | Path,
    repo_full_name: str = "",
    changed_only: bool = True,
    max_repos: int = 500,
    workers: int = 16,
) -> tuple[list[ClawSkill], dict[str, Any]]:
    """Mine claw skills incrementally from the repo registry state DB."""
    store = ClawRepoStateStore(state_db)
    repo_rows = store.list_repos_for_mining(
        changed_only=changed_only,
        max_repos=max_repos,
        repo_full_name=repo_full_name,
    )
    if not repo_rows:
        return [], {
            "selected_repos": 0,
            "selected_files": 0,
            "emitted_skills": 0,
            "emitted_agents": 0,
            "file_errors": 0,
        }

    repo_map = {str(row["repo_full_name"]): row for row in repo_rows}
    repo_files: dict[str, list[dict[str, Any]]] = {}
    tasks: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for row in repo_rows:
        repo_name = str(row["repo_full_name"])
        files = [
            file_row
            for file_row in store.list_repo_files(repo_name)
            if str(file_row.get("file_kind") or "") in {"skill_md", "soul_md"}
        ]
        repo_files[repo_name] = files
        for file_row in files:
            tasks.append((row, file_row))

    fetched_at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    emitted: list[ClawSkill] = []
    repo_skill_counts: dict[str, int] = defaultdict(int)
    repo_agent_counts: dict[str, int] = defaultdict(int)
    repo_errors: dict[str, list[str]] = defaultdict(list)

    max_workers = max(1, int(workers or 1))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_mine_one_file, repo_row, file_row): (repo_row, file_row)
            for repo_row, file_row in tasks
        }
        for future in as_completed(futures):
            repo_row, file_row = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = _FileMineResult(
                    repo_full_name=str(repo_row.get("repo_full_name") or ""),
                    path=str(file_row.get("path") or ""),
                    file_kind=str(file_row.get("file_kind") or ""),
                    status="parse_error",
                    error=str(exc),
                )
            emitted_skill_id = ""
            if result.skill is not None:
                emitted.append(result.skill)
                emitted_skill_id = result.skill.skill_id
                if result.file_kind == "soul_md":
                    repo_agent_counts[result.repo_full_name] += 1
                else:
                    repo_skill_counts[result.repo_full_name] += 1
            else:
                error = result.error or result.status
                repo_errors[result.repo_full_name].append(f"{result.path}: {error}")
            store.mark_file_result(
                result.repo_full_name,
                result.path,
                fetched_at=fetched_at,
                parse_status=result.status,
                emitted_skill_id=emitted_skill_id,
            )

    for repo_name, repo_row in repo_map.items():
        errors = repo_errors.get(repo_name, [])
        status = "ok"
        if errors and (repo_skill_counts.get(repo_name, 0) or repo_agent_counts.get(repo_name, 0)):
            status = "partial"
        elif errors:
            status = "error"
        elif not repo_files.get(repo_name):
            status = "skipped"
        store.mark_mined(
            repo_name,
            mined_at=fetched_at,
            tree_sha=str(repo_row.get("tree_sha") or ""),
            status=status,
            skill_count=repo_skill_counts.get(repo_name, 0),
            agent_count=repo_agent_counts.get(repo_name, 0),
            error=" | ".join(errors)[:2000],
        )

    stats = {
        "selected_repos": len(repo_rows),
        "selected_files": len(tasks),
        "emitted_skills": sum(repo_skill_counts.values()),
        "emitted_agents": sum(repo_agent_counts.values()),
        "file_errors": sum(len(items) for items in repo_errors.values()),
    }
    return emitted, stats


def print_mining_stats(stats: dict[str, Any]) -> None:
    print(f"\n{'=' * 60}", file=sys.stderr)
    print("Claw Repo Mining Report", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)
    print(f"Selected repos: {int(stats.get('selected_repos', 0) or 0)}", file=sys.stderr)
    print(f"Selected files: {int(stats.get('selected_files', 0) or 0)}", file=sys.stderr)
    print(f"Emitted skills: {int(stats.get('emitted_skills', 0) or 0)}", file=sys.stderr)
    print(f"Emitted agents: {int(stats.get('emitted_agents', 0) or 0)}", file=sys.stderr)
    print(f"File errors: {int(stats.get('file_errors', 0) or 0)}", file=sys.stderr)
    print(f"{'=' * 60}\n", file=sys.stderr)


def cli_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="clawskills-claw-mine-skills",
        description="Incrementally mine SKILL.md and SOUL.md content from the claw repo registry state DB",
    )
    parser.add_argument(
        "--state-db",
        default=str(Path.home() / ".clawskills" / "claw-repo-state.sqlite"),
        help="SQLite state DB produced by claw-repo-aggregate",
    )
    parser.add_argument("--repo", default="", help="Mine a single repo_full_name only")
    parser.add_argument("--changed-only", action="store_true", help="Only mine repos whose tree SHA changed since last mine")
    parser.add_argument("--all", action="store_true", help="Mine all tracked repos regardless of tree SHA")
    parser.add_argument("--max-repos", type=int, default=500, help="Maximum repos to mine")
    parser.add_argument("--workers", type=int, default=16, help="Concurrent file fetch workers")
    parser.add_argument(
        "--out",
        default="",
        help="Output SQLite path (default: dist/clawskills-bundle-lite-claw-mined-v{date}.sqlite)",
    )
    parser.add_argument("--version", default="", help="Bundle version string")

    args = parser.parse_args(argv)
    version = args.version or date.today().strftime("%Y%m%d")
    changed_only = not bool(args.all)
    if args.changed_only:
        changed_only = True

    skills, stats = mine_repo_state(
        state_db=args.state_db,
        repo_full_name=args.repo,
        changed_only=changed_only,
        max_repos=args.max_repos,
        workers=args.workers,
    )
    print_mining_stats(stats)

    if not skills:
        print("No mined skills emitted.", file=sys.stderr)
        return 0

    out_path = args.out or f"dist/clawskills-bundle-lite-claw-mined-v{version}.sqlite"
    build_claw_bundle(skills, out_path, version=version, source="claw-repo-miner")
    return 0


if __name__ == "__main__":
    raise SystemExit(cli_main())
