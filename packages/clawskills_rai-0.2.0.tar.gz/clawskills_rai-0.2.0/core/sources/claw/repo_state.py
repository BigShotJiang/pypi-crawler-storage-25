"""Persistent SQLite state for claw repo scanning and future incremental mining."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


def _json_dumps(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, sort_keys=True)
    except Exception:
        return "[]"


def _json_loads(raw: str) -> Any:
    text = str(raw or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


class ClawRepoStateStore:
    """Read/write access to the claw repo state database."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path).expanduser()

    def _connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path.as_posix(), timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.OperationalError:
            conn.execute("PRAGMA journal_mode=DELETE")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS repo_state (
                    repo_full_name TEXT PRIMARY KEY,
                    repo_id TEXT NOT NULL DEFAULT '',
                    repo_url TEXT NOT NULL DEFAULT '',
                    default_branch TEXT NOT NULL DEFAULT 'HEAD',
                    repo_kind TEXT NOT NULL DEFAULT 'unknown',
                    crawl_sources_json TEXT NOT NULL DEFAULT '[]',
                    tree_sha TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL DEFAULT '',
                    pushed_at TEXT NOT NULL DEFAULT '',
                    last_seen_at TEXT NOT NULL DEFAULT '',
                    last_mined_at TEXT NOT NULL DEFAULT '',
                    last_mined_tree_sha TEXT NOT NULL DEFAULT '',
                    last_mined_status TEXT NOT NULL DEFAULT '',
                    last_skill_count INTEGER NOT NULL DEFAULT 0,
                    last_agent_count INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT NOT NULL DEFAULT '',
                    priority_score REAL NOT NULL DEFAULT 0.0,
                    has_skill_md INTEGER NOT NULL DEFAULT 0,
                    skill_file_count INTEGER NOT NULL DEFAULT 0,
                    has_soul_md INTEGER NOT NULL DEFAULT 0,
                    soul_file_count INTEGER NOT NULL DEFAULT 0,
                    has_claude_skills_dir INTEGER NOT NULL DEFAULT 0,
                    has_openclaw_skills_dir INTEGER NOT NULL DEFAULT 0,
                    has_agent_skills_dir INTEGER NOT NULL DEFAULT 0
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS repo_file_state (
                    repo_full_name TEXT NOT NULL,
                    path TEXT NOT NULL,
                    blob_sha TEXT NOT NULL DEFAULT '',
                    file_kind TEXT NOT NULL,
                    source_url TEXT NOT NULL DEFAULT '',
                    last_seen_at TEXT NOT NULL,
                    last_fetched_at TEXT NOT NULL DEFAULT '',
                    parse_status TEXT NOT NULL DEFAULT '',
                    emitted_skill_id TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (repo_full_name, path),
                    FOREIGN KEY (repo_full_name) REFERENCES repo_state(repo_full_name) ON DELETE CASCADE
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS state_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "INSERT INTO state_meta(key, value) VALUES('schema_version', '2') "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value"
            )
            repo_columns = {
                str(row["name"])
                for row in conn.execute("PRAGMA table_info(repo_state)").fetchall()
            }
            if "last_mined_tree_sha" not in repo_columns:
                conn.execute(
                    "ALTER TABLE repo_state ADD COLUMN last_mined_tree_sha TEXT NOT NULL DEFAULT ''"
                )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_repo_state_priority ON repo_state(priority_score DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_repo_state_tree_sha ON repo_state(tree_sha)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_repo_file_state_kind ON repo_file_state(file_kind)")
            conn.commit()
        finally:
            conn.close()

    def sync_scan(self, repos: list[Any]) -> None:
        """Upsert scan results while preserving mining status fields."""
        self.init_db()
        conn = self._connect()
        try:
            for repo in repos:
                conn.execute(
                    """
                    INSERT INTO repo_state (
                        repo_full_name, repo_id, repo_url, default_branch, repo_kind,
                        crawl_sources_json, tree_sha, updated_at, pushed_at, last_seen_at,
                        priority_score, has_skill_md, skill_file_count, has_soul_md,
                        soul_file_count, has_claude_skills_dir, has_openclaw_skills_dir, has_agent_skills_dir
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(repo_full_name) DO UPDATE SET
                        repo_id=excluded.repo_id,
                        repo_url=excluded.repo_url,
                        default_branch=excluded.default_branch,
                        repo_kind=excluded.repo_kind,
                        crawl_sources_json=excluded.crawl_sources_json,
                        tree_sha=excluded.tree_sha,
                        updated_at=excluded.updated_at,
                        pushed_at=excluded.pushed_at,
                        last_seen_at=excluded.last_seen_at,
                        priority_score=excluded.priority_score,
                        has_skill_md=excluded.has_skill_md,
                        skill_file_count=excluded.skill_file_count,
                        has_soul_md=excluded.has_soul_md,
                        soul_file_count=excluded.soul_file_count,
                        has_claude_skills_dir=excluded.has_claude_skills_dir,
                        has_openclaw_skills_dir=excluded.has_openclaw_skills_dir,
                        has_agent_skills_dir=excluded.has_agent_skills_dir
                    """,
                    (
                        str(repo.repo_full_name),
                        str(getattr(repo, "repo_id", "") or ""),
                        str(getattr(repo, "repo_url", "") or ""),
                        str(getattr(repo, "default_branch", "HEAD") or "HEAD"),
                        str(getattr(repo, "repo_kind", "unknown") or "unknown"),
                        _json_dumps(getattr(repo, "crawl_sources", []) or []),
                        str(getattr(repo, "tree_sha", "") or ""),
                        str(getattr(repo, "updated_at", "") or ""),
                        str(getattr(repo, "pushed_at", "") or ""),
                        str(getattr(repo, "last_seen_at", "") or ""),
                        float(getattr(repo, "priority_score", 0.0) or 0.0),
                        1 if bool(getattr(repo, "has_skill_md", False)) else 0,
                        int(getattr(repo, "skill_file_count", 0) or 0),
                        1 if bool(getattr(repo, "has_soul_md", False)) else 0,
                        int(getattr(repo, "soul_file_count", 0) or 0),
                        1 if bool(getattr(repo, "has_claude_skills_dir", False)) else 0,
                        1 if bool(getattr(repo, "has_openclaw_skills_dir", False)) else 0,
                        1 if bool(getattr(repo, "has_agent_skills_dir", False)) else 0,
                    ),
                )

                tracked_files = list(getattr(repo, "tracked_files", []) or [])
                tracked_paths = [str(file.path) for file in tracked_files if str(file.path).strip()]
                if tracked_paths:
                    placeholders = ",".join("?" for _ in tracked_paths)
                    conn.execute(
                        f"DELETE FROM repo_file_state WHERE repo_full_name = ? AND path NOT IN ({placeholders})",
                        [str(repo.repo_full_name), *tracked_paths],
                    )
                else:
                    conn.execute(
                        "DELETE FROM repo_file_state WHERE repo_full_name = ?",
                        (str(repo.repo_full_name),),
                    )

                for file in tracked_files:
                    conn.execute(
                        """
                        INSERT INTO repo_file_state (
                            repo_full_name, path, blob_sha, file_kind, source_url, last_seen_at
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        ON CONFLICT(repo_full_name, path) DO UPDATE SET
                            blob_sha=excluded.blob_sha,
                            file_kind=excluded.file_kind,
                            source_url=excluded.source_url,
                            last_seen_at=excluded.last_seen_at
                        """,
                        (
                            str(repo.repo_full_name),
                            str(file.path),
                            str(getattr(file, "blob_sha", "") or ""),
                            str(getattr(file, "file_kind", "") or ""),
                            str(getattr(file, "source_url", "") or ""),
                            str(getattr(repo, "last_seen_at", "") or ""),
                        ),
                    )

            conn.commit()
        finally:
            conn.close()

    def get_repo_state(self, repo_full_name: str) -> dict[str, Any] | None:
        self.init_db()
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM repo_state WHERE repo_full_name = ?",
                (str(repo_full_name),),
            ).fetchone()
            if row is None:
                return None
            out = dict(row)
            out["crawl_sources"] = _json_loads(out.pop("crawl_sources_json", "[]")) or []
            return out
        finally:
            conn.close()

    def list_repo_files(self, repo_full_name: str) -> list[dict[str, Any]]:
        self.init_db()
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM repo_file_state WHERE repo_full_name = ? ORDER BY path",
                (str(repo_full_name),),
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def list_repos_for_mining(
        self,
        *,
        changed_only: bool = True,
        max_repos: int = 500,
        repo_full_name: str = "",
    ) -> list[dict[str, Any]]:
        """Return repo_state rows eligible for incremental mining."""
        self.init_db()
        clauses = [
            "(skill_file_count > 0 OR soul_file_count > 0)",
        ]
        params: list[Any] = []
        if repo_full_name:
            clauses.append("repo_full_name = ?")
            params.append(str(repo_full_name))
        if changed_only:
            clauses.append("(last_mined_tree_sha = '' OR tree_sha != last_mined_tree_sha)")
        where_sql = " AND ".join(clauses) if clauses else "1=1"
        limit = max(1, int(max_repos or 1))

        conn = self._connect()
        try:
            rows = conn.execute(
                f"""
                SELECT *
                FROM repo_state
                WHERE {where_sql}
                ORDER BY priority_score DESC, pushed_at DESC, repo_full_name ASC
                LIMIT ?
                """,
                [*params, limit],
            ).fetchall()
            out: list[dict[str, Any]] = []
            for row in rows:
                item = dict(row)
                item["crawl_sources"] = _json_loads(item.pop("crawl_sources_json", "[]")) or []
                out.append(item)
            return out
        finally:
            conn.close()

    def mark_file_result(
        self,
        repo_full_name: str,
        path: str,
        *,
        fetched_at: str,
        parse_status: str,
        emitted_skill_id: str = "",
    ) -> None:
        self.init_db()
        conn = self._connect()
        try:
            conn.execute(
                """
                UPDATE repo_file_state
                SET last_fetched_at = ?,
                    parse_status = ?,
                    emitted_skill_id = ?
                WHERE repo_full_name = ? AND path = ?
                """,
                (
                    str(fetched_at or ""),
                    str(parse_status or ""),
                    str(emitted_skill_id or ""),
                    str(repo_full_name),
                    str(path),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def mark_mined(
        self,
        repo_full_name: str,
        *,
        mined_at: str,
        tree_sha: str = "",
        status: str,
        skill_count: int = 0,
        agent_count: int = 0,
        error: str = "",
    ) -> None:
        self.init_db()
        conn = self._connect()
        try:
            conn.execute(
                """
                UPDATE repo_state
                SET last_mined_at = ?,
                    last_mined_tree_sha = ?,
                    last_mined_status = ?,
                    last_skill_count = ?,
                    last_agent_count = ?,
                    last_error = ?
                WHERE repo_full_name = ?
                """,
                (
                    str(mined_at or ""),
                    str(tree_sha or ""),
                    str(status or ""),
                    int(skill_count or 0),
                    int(agent_count or 0),
                    str(error or ""),
                    str(repo_full_name),
                ),
            )
            conn.commit()
        finally:
            conn.close()
