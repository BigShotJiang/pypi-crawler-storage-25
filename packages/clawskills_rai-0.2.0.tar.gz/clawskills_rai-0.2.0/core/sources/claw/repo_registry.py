"""Aggregate GitHub repositories related to the Claw / OpenClaw ecosystem."""

from __future__ import annotations

import argparse
import json
import logging
import math
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from .awesome_parser import _AWESOME_LISTS
from .converter import ClawSkill
from .http_client import (
    github_headers,
    http_get,
    http_get_with_rate_retry,
    is_valid_skill_filename,
    is_valid_soul_filename,
)
from .repo_state import ClawRepoStateStore

_GITHUB_API = "https://api.github.com"
_SEARCH_DELAY = 2.5
_README_DELAY = 0.2
_TOPIC_SPECS = [
    {"query": "topic:openclaw-skill", "max_pages": 2},
    {"query": "topic:claude-skill", "max_pages": 2},
    {"query": "topic:claude-code-skill", "max_pages": 2},
    {"query": "topic:agent-skill", "max_pages": 2},
]
_ORG_SPECS = [
    {"org": "openclaw", "max_pages": 3},
]
_CLAWHUB_SEED_REPOS = [
    "openclaw/clawhub",
]
_DEFAULT_SOURCES = ["org", "topic", "awesome", "clawhub", "seed"]
_HYDRATE_WORKERS = 12
_GITHUB_REPO_RE = re.compile(
    r"https?://github\.com/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)(?:[/?#)\]\s]|$)",
    re.IGNORECASE,
)


@dataclass
class ClawRepoFile:
    """Tracked candidate file inside a claw-related repository."""

    path: str
    blob_sha: str
    file_kind: str
    source_url: str


@dataclass
class ClawRepo:
    """Normalized repository record for the claw repo registry."""

    repo_full_name: str
    repo_url: str
    repo_owner: str
    repo_name: str
    repo_id: str = ""
    description: str = ""
    homepage: str = ""
    topics: list[str] = field(default_factory=list)
    primary_language: str = ""
    stars: int = 0
    forks: int = 0
    open_issues: int = 0
    license_spdx: str = ""
    archived: bool = False
    fork: bool = False
    default_branch: str = "HEAD"
    updated_at: str = ""
    pushed_at: str = ""
    readme_excerpt: str = ""
    crawl_sources: list[str] = field(default_factory=list)
    repo_kind: str = "unknown"
    has_skill_md: bool = False
    skill_file_count: int = 0
    has_soul_md: bool = False
    soul_file_count: int = 0
    has_claude_skills_dir: bool = False
    has_openclaw_skills_dir: bool = False
    has_agent_skills_dir: bool = False
    priority_score: float = 0.0
    last_seen_at: str = ""
    tree_sha: str = ""
    tracked_files: list[ClawRepoFile] = field(default_factory=list)


def _json_get(url: str, *, headers: dict[str, str] | None = None) -> Any:
    text = http_get_with_rate_retry(url, headers=headers or github_headers())
    if not text:
        return None
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return None


def _search_repositories(query: str, *, max_pages: int = 2) -> list[dict[str, Any]]:
    headers = github_headers()
    items: list[dict[str, Any]] = []
    for page in range(1, max_pages + 1):
        url = (
            f"{_GITHUB_API}/search/repositories?q={quote(query)}"
            f"&per_page=100&page={page}&sort=updated"
        )
        data = _json_get(url, headers=headers)
        if not isinstance(data, dict):
            break
        page_items = data.get("items", [])
        if not isinstance(page_items, list) or not page_items:
            break
        items.extend(page_items)
        total_count = int(data.get("total_count", 0) or 0)
        if len(items) >= total_count or len(items) >= 1000:
            break
        time.sleep(_SEARCH_DELAY)
    return items


def _list_org_repositories(org: str, *, max_pages: int = 2) -> list[dict[str, Any]]:
    headers = github_headers()
    items: list[dict[str, Any]] = []
    for page in range(1, max_pages + 1):
        url = f"{_GITHUB_API}/orgs/{org}/repos?per_page=100&page={page}&sort=updated"
        data = _json_get(url, headers=headers)
        if not isinstance(data, list) or not data:
            break
        items.extend(data)
        if len(data) < 100:
            break
        time.sleep(_SEARCH_DELAY)
    return items


def _fetch_repo_metadata(full_name: str) -> dict[str, Any]:
    data = _json_get(f"{_GITHUB_API}/repos/{full_name}", headers=github_headers())
    return data if isinstance(data, dict) else {}


def _fetch_repo_tree_data(full_name: str, default_branch: str) -> dict[str, Any]:
    ref = quote(default_branch or "HEAD", safe="")
    data = _json_get(
        f"{_GITHUB_API}/repos/{full_name}/git/trees/{ref}?recursive=1",
        headers=github_headers(),
    )
    if not isinstance(data, dict):
        return {"tree_sha": "", "paths": [], "tracked_files": []}

    paths: list[str] = []
    tracked_files: list[ClawRepoFile] = []
    for item in data.get("tree", []):
        if item.get("type") != "blob":
            continue
        path = str(item.get("path") or "").strip()
        if not path:
            continue
        paths.append(path)
        file_kind = ""
        if is_valid_skill_filename(path):
            file_kind = "skill_md"
        elif is_valid_soul_filename(path):
            file_kind = "soul_md"
        if not file_kind:
            continue
        tracked_files.append(
            ClawRepoFile(
                path=path,
                blob_sha=str(item.get("sha") or ""),
                file_kind=file_kind,
                source_url=f"https://github.com/{full_name}/blob/HEAD/{quote(path, safe='/')}",
            )
        )
    return {
        "tree_sha": str(data.get("sha") or ""),
        "paths": paths,
        "tracked_files": tracked_files,
    }


def _fetch_readme_excerpt(full_name: str) -> str:
    headers = github_headers()
    headers["Accept"] = "application/vnd.github.raw+json"
    text = http_get_with_rate_retry(f"{_GITHUB_API}/repos/{full_name}/readme", headers=headers)
    if not text:
        return ""
    cleaned = re.sub(r"!\[[^\]]*\]\([^)]+\)", " ", text)
    cleaned = re.sub(r"\[[^\]]+\]\([^)]+\)", " ", cleaned)
    cleaned = re.sub(r"`{1,3}.*?`{1,3}", " ", cleaned, flags=re.DOTALL)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned[:500]


def _extract_github_repo_links(text: str) -> list[str]:
    repos: list[str] = []
    seen: set[str] = set()
    for match in _GITHUB_REPO_RE.finditer(text):
        full_name = match.group(1).rstrip("/").rstrip(".")
        full_name = re.sub(r"/(tree|blob|issues|pull|pulls|releases|wiki).*$", "", full_name)
        lower = full_name.lower()
        if "/" not in full_name or lower in seen:
            continue
        seen.add(lower)
        repos.append(full_name)
    return repos


def _load_seed_repos(seed_file: str) -> list[str]:
    if not seed_file:
        return []
    path = Path(seed_file)
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return []
        if isinstance(data, list):
            return [str(item).strip() for item in data if str(item).strip()]
        if isinstance(data, dict):
            repos = data.get("repos", [])
            if isinstance(repos, list):
                return [str(item).strip() for item in repos if str(item).strip()]
        return []
    repos: list[str] = []
    for line in text.splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#"):
            continue
        repos.append(raw)
    return repos


def _artifact_summary(paths: list[str]) -> dict[str, Any]:
    skill_paths = [path for path in paths if is_valid_skill_filename(path)]
    soul_paths = [path for path in paths if is_valid_soul_filename(path)]
    # Detect all known agent-skill directory layouts
    _SKILL_DIR_PREFIXES = (".claude/skills/", ".openclaw/skills/", ".agents/", ".cursor/skills/", ".codex/", ".opencode/")
    return {
        "has_skill_md": bool(skill_paths),
        "skill_file_count": len(skill_paths),
        "has_soul_md": bool(soul_paths),
        "soul_file_count": len(soul_paths),
        "has_claude_skills_dir": any(path.startswith(".claude/skills/") for path in paths),
        "has_openclaw_skills_dir": any(path.startswith(".openclaw/skills/") for path in paths),
        "has_agent_skills_dir": any(any(path.startswith(p) for p in _SKILL_DIR_PREFIXES) for path in paths),
    }


def _classify_repo(
    *,
    repo_full_name: str,
    repo_name: str,
    description: str,
    topics: list[str],
    readme_excerpt: str,
    archived: bool,
    fork: bool,
    skill_file_count: int,
    soul_file_count: int,
) -> str:
    lower_full_name = repo_full_name.lower()
    lower_name = repo_name.lower()
    text = " ".join([repo_full_name, description, readme_excerpt, " ".join(topics)]).lower()

    if lower_full_name == "openclaw/skills":
        return "archive"
    if soul_file_count > 0:
        return "agent-templates"
    if skill_file_count >= 5:
        return "skill-collection"
    if skill_file_count > 0:
        return "skill-repo"
    if "awesome" in lower_name or "awesome" in text:
        return "awesome-list"
    if fork:
        return "mirror"
    if any(token in text for token in ("slack", "discord", "telegram", "notion", "mcp", "integration")):
        return "integration"
    if any(token in text for token in ("sdk", "client library", "bindings", "api wrapper")):
        return "sdk"
    if any(token in text for token in ("gateway", "runner", "deploy", "cli", "tooling")):
        return "tooling"
    if any(token in text for token in ("example", "starter", "demo", "template")):
        return "example-app"
    if archived:
        return "archive"
    return "unknown"


def _priority_score(
    *,
    stars: int,
    archived: bool,
    fork: bool,
    skill_file_count: int,
    soul_file_count: int,
    repo_kind: str,
    crawl_sources: list[str],
) -> float:
    score = math.log10(max(stars, 0) + 1.0) * 20.0
    score += min(skill_file_count, 25) * 3.0
    score += min(soul_file_count, 25) * 3.0
    if repo_kind == "agent-templates":
        score += 12.0
    elif repo_kind == "skill-collection":
        score += 10.0
    elif repo_kind == "skill-repo":
        score += 8.0
    elif repo_kind == "awesome-list":
        score += 6.0
    if any(src.startswith("org:openclaw") for src in crawl_sources):
        score += 8.0
    if any(src.startswith("topic:") for src in crawl_sources):
        score += 2.0
    if archived:
        score -= 5.0
    if fork:
        score -= 6.0
    return round(score, 2)


def _repo_to_skill(repo: ClawRepo) -> ClawSkill:
    display_title = repo.repo_full_name
    if repo.description:
        display_title = f"{repo.repo_full_name} — {repo.description}"
    count_bits: list[str] = []
    if int(repo.skill_file_count or 0) > 0:
        count_bits.append(f"skills:{int(repo.skill_file_count)}")
    if int(repo.soul_file_count or 0) > 0:
        count_bits.append(f"agents:{int(repo.soul_file_count)}")
    if count_bits:
        display_title = f"{display_title} [{' '.join(count_bits)}]"

    lines = [
        f"# {repo.repo_full_name}",
        "",
    ]
    if repo.description:
        lines += [repo.description, ""]
    lines += [
        f"Repo kind: {repo.repo_kind}",
        f"Stars: {repo.stars}",
        f"Primary language: {repo.primary_language or 'unknown'}",
        f"Topics: {', '.join(repo.topics) if repo.topics else 'none'}",
        (
            "Artifacts: "
            f"SKILL.md={repo.skill_file_count}, "
            f"SOUL.md={repo.soul_file_count}, "
            f".claude/skills={'yes' if repo.has_claude_skills_dir else 'no'}, "
            f".openclaw/skills={'yes' if repo.has_openclaw_skills_dir else 'no'}"
        ),
        f"Sources: {', '.join(repo.crawl_sources) if repo.crawl_sources else 'unknown'}",
        f"Source: {repo.repo_url}",
    ]
    if repo.homepage:
        lines.append(f"Homepage: {repo.homepage}")
    if repo.readme_excerpt:
        lines += ["", "README excerpt:", repo.readme_excerpt]

    tags: list[str] = []
    for tag in [*repo.topics, repo.repo_kind, "openclaw", "repo"]:
        normalized = str(tag).strip()
        if normalized and normalized not in tags:
            tags.append(normalized)

    return ClawSkill(
        name=repo.repo_full_name,
        description=repo.description or repo.repo_full_name,
        tags=tags,
        license_spdx=repo.license_spdx,
        source_url=repo.repo_url,
        source_type="claw-repo",
        body_md="\n".join(lines).strip() + "\n",
        metadata={
            "record_kind": "repo",
            "display_title": display_title,
            "repo_full_name": repo.repo_full_name,
            "repo_owner": repo.repo_owner,
            "repo_name": repo.repo_name,
            "repo_id": repo.repo_id,
            "repo_description": repo.description,
            "homepage": repo.homepage,
            "topics": repo.topics,
            "primary_language": repo.primary_language,
            "stars": repo.stars,
            "forks": repo.forks,
            "open_issues": repo.open_issues,
            "archived": repo.archived,
            "fork": repo.fork,
            "default_branch": repo.default_branch,
            "updated_at": repo.updated_at,
            "pushed_at": repo.pushed_at,
            "crawl_sources": repo.crawl_sources,
            "repo_kind": repo.repo_kind,
            "has_skill_md": repo.has_skill_md,
            "skill_file_count": repo.skill_file_count,
            "has_soul_md": repo.has_soul_md,
            "soul_file_count": repo.soul_file_count,
            "has_claude_skills_dir": repo.has_claude_skills_dir,
            "has_openclaw_skills_dir": repo.has_openclaw_skills_dir,
            "priority_score": repo.priority_score,
            "last_seen_at": repo.last_seen_at,
            "tree_sha": repo.tree_sha,
            "readme_excerpt": repo.readme_excerpt,
        },
    )


def _add_candidate(candidates: dict[str, dict[str, Any]], full_name: str, source: str) -> None:
    normalized = str(full_name).strip().strip("/")
    if normalized.count("/") != 1:
        return
    key = normalized.lower()
    entry = candidates.setdefault(key, {"full_name": normalized, "sources": []})
    sources = entry["sources"]
    if source not in sources:
        sources.append(source)


def _discover_candidates(
    *,
    max_candidates: int,
    sources: list[str],
    seed_file: str = "",
    emit: Any = None,
) -> dict[str, dict[str, Any]]:
    candidates: dict[str, dict[str, Any]] = {}

    if "seed" in sources:
        for full_name in _load_seed_repos(seed_file):
            _add_candidate(candidates, full_name, "seed")

    if "clawhub" in sources:
        for full_name in _CLAWHUB_SEED_REPOS:
            _add_candidate(candidates, full_name, "clawhub")

    if "org" in sources:
        for spec in _ORG_SPECS:
            items = _list_org_repositories(spec["org"], max_pages=int(spec.get("max_pages", 2)))
            for item in items:
                _add_candidate(candidates, str(item.get("full_name") or ""), f"org:{spec['org']}")
                if len(candidates) >= max_candidates:
                    break
            if len(candidates) >= max_candidates:
                break

    if "topic" in sources and len(candidates) < max_candidates:
        for spec in _TOPIC_SPECS:
            items = _search_repositories(spec["query"], max_pages=int(spec.get("max_pages", 2)))
            for item in items:
                _add_candidate(candidates, str(item.get("full_name") or ""), f"topic:{spec['query']}")
                if len(candidates) >= max_candidates:
                    break
            if len(candidates) >= max_candidates:
                break

    if "awesome" in sources and len(candidates) < max_candidates:
        headers = github_headers()
        for list_info in _AWESOME_LISTS:
            full_name = f"{list_info['owner']}/{list_info['repo']}"
            awesome_source = f"awesome:{list_info['name']}"
            _add_candidate(candidates, full_name, awesome_source)

            readme_path = str(list_info.get("readme_path", "README.md"))
            readme_url = f"https://raw.githubusercontent.com/{full_name}/HEAD/{readme_path}"
            readme = http_get(readme_url, headers=headers)
            if readme:
                for linked_full_name in _extract_github_repo_links(readme):
                    _add_candidate(candidates, linked_full_name, awesome_source)
                    if len(candidates) >= max_candidates:
                        break
            time.sleep(_README_DELAY)
            if len(candidates) >= max_candidates:
                break

    if emit:
        emit(f"Discovered {len(candidates)} claw-related repo candidates")
    return candidates


def _hydrate_candidate(entry: dict[str, Any], now_iso: str) -> ClawRepo | None:
    full_name = str(entry["full_name"])
    repo_data = _fetch_repo_metadata(full_name)
    if not repo_data:
        return None

    default_branch = str(repo_data.get("default_branch") or "HEAD")
    tree_data = _fetch_repo_tree_data(full_name, default_branch)
    tree_paths = list(tree_data.get("paths", []) or [])
    artifact = _artifact_summary(tree_paths)
    readme_excerpt = _fetch_readme_excerpt(full_name)
    repo_kind = _classify_repo(
        repo_full_name=full_name,
        repo_name=str(repo_data.get("name") or full_name.split("/")[-1]),
        description=str(repo_data.get("description") or ""),
        topics=[str(t).strip() for t in repo_data.get("topics", []) if str(t).strip()],
        readme_excerpt=readme_excerpt,
        archived=bool(repo_data.get("archived", False)),
        fork=bool(repo_data.get("fork", False)),
        skill_file_count=int(artifact["skill_file_count"]),
        soul_file_count=int(artifact["soul_file_count"]),
    )
    crawl_sources = [str(src) for src in entry.get("sources", []) if str(src).strip()]
    priority = _priority_score(
        stars=int(repo_data.get("stargazers_count", 0) or 0),
        archived=bool(repo_data.get("archived", False)),
        fork=bool(repo_data.get("fork", False)),
        skill_file_count=int(artifact["skill_file_count"]),
        soul_file_count=int(artifact["soul_file_count"]),
        repo_kind=repo_kind,
        crawl_sources=crawl_sources,
    )
    # Bonus for repos using any recognized agent skill directory layout
    if artifact.get("has_agent_skills_dir"):
        priority += 4.0
    license_info = repo_data.get("license") or {}
    return ClawRepo(
        repo_full_name=full_name,
        repo_url=str(repo_data.get("html_url") or f"https://github.com/{full_name}"),
        repo_owner=str(repo_data.get("owner", {}).get("login") or full_name.split("/")[0]),
        repo_name=str(repo_data.get("name") or full_name.split("/")[-1]),
        repo_id=str(repo_data.get("id") or ""),
        description=str(repo_data.get("description") or ""),
        homepage=str(repo_data.get("homepage") or ""),
        topics=[str(t).strip() for t in repo_data.get("topics", []) if str(t).strip()],
        primary_language=str(repo_data.get("language") or ""),
        stars=int(repo_data.get("stargazers_count", 0) or 0),
        forks=int(repo_data.get("forks_count", 0) or 0),
        open_issues=int(repo_data.get("open_issues_count", 0) or 0),
        license_spdx=str(license_info.get("spdx_id") or ""),
        archived=bool(repo_data.get("archived", False)),
        fork=bool(repo_data.get("fork", False)),
        default_branch=default_branch,
        updated_at=str(repo_data.get("updated_at") or ""),
        pushed_at=str(repo_data.get("pushed_at") or ""),
        readme_excerpt=readme_excerpt,
        crawl_sources=crawl_sources,
        repo_kind=repo_kind,
        has_skill_md=bool(artifact["has_skill_md"]),
        skill_file_count=int(artifact["skill_file_count"]),
        has_soul_md=bool(artifact["has_soul_md"]),
        soul_file_count=int(artifact["soul_file_count"]),
        has_claude_skills_dir=bool(artifact["has_claude_skills_dir"]),
        has_openclaw_skills_dir=bool(artifact["has_openclaw_skills_dir"]),
        has_agent_skills_dir=bool(artifact.get("has_agent_skills_dir", False)),
        priority_score=priority,
        last_seen_at=now_iso,
        tree_sha=str(tree_data.get("tree_sha", "") or ""),
        tracked_files=list(tree_data.get("tracked_files", []) or []),
    )


def aggregate_claw_repos(
    *,
    max_repos: int = 2000,
    sources: list[str] | None = None,
    seed_file: str = "",
    emit: Any = None,
) -> list[ClawRepo]:
    """Discover and hydrate claw-related repositories."""
    active_sources = sources or list(_DEFAULT_SOURCES)
    max_candidates = max(max_repos * 3, 200)
    candidates = _discover_candidates(
        max_candidates=max_candidates,
        sources=active_sources,
        seed_file=seed_file,
        emit=emit,
    )

    repos: list[ClawRepo] = []
    now_iso = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    candidate_entries = list(candidates.values())
    max_workers = max(1, int(_HYDRATE_WORKERS))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_hydrate_candidate, entry, now_iso) for entry in candidate_entries]
        for idx, future in enumerate(as_completed(futures), start=1):
            try:
                repo = future.result()
            except Exception as exc:
                logging.getLogger(__name__).warning("repo hydration failed for candidate %d: %s", idx, exc)
                repo = None
            if repo is not None:
                repos.append(repo)
            if idx % 25 == 0:
                print(f"[claw-repo] Hydrated {idx}/{len(candidate_entries)} candidates", file=sys.stderr)

    repos.sort(key=lambda repo: (repo.priority_score, repo.stars, repo.repo_full_name.lower()), reverse=True)
    print(f"[claw-repo] Total hydrated repos: {len(repos)}", file=sys.stderr)
    return repos[:max_repos]


def build_claw_repo_bundle(
    repos: list[ClawRepo],
    out_path: str | Path,
    version: str = "",
) -> Path:
    """Build a SQLite repo bundle using the claw bundle format."""
    from . import build_claw_bundle

    skills = [_repo_to_skill(repo) for repo in repos]
    return build_claw_bundle(skills, out_path, version=version, source="claw-repo-registry")


def sync_repo_state(
    repos: list[ClawRepo],
    *,
    state_db: str | Path,
) -> None:
    """Persist repo scan state for future incremental mining."""
    store = ClawRepoStateStore(state_db)
    store.sync_scan(repos)


def print_repo_stats(repos: list[ClawRepo]) -> None:
    from collections import Counter

    kinds = Counter(repo.repo_kind for repo in repos)
    sources = Counter(src for repo in repos for src in repo.crawl_sources)
    with_skill = sum(1 for repo in repos if repo.has_skill_md)
    with_soul = sum(1 for repo in repos if repo.has_soul_md)

    print(f"\n{'=' * 60}", file=sys.stderr)
    print("Claw Repo Registry Report", file=sys.stderr)
    print(f"{'=' * 60}", file=sys.stderr)
    print(f"Total repos: {len(repos)}", file=sys.stderr)
    print(f"With SKILL.md: {with_skill}", file=sys.stderr)
    print(f"With SOUL.md: {with_soul}", file=sys.stderr)
    print("\nBy repo kind:", file=sys.stderr)
    for kind, count in kinds.most_common():
        print(f"  {kind}: {count}", file=sys.stderr)
    print("\nBy discovery source:", file=sys.stderr)
    for source, count in sources.most_common():
        print(f"  {source}: {count}", file=sys.stderr)
    print(f"{'=' * 60}\n", file=sys.stderr)


def cli_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="clawskills-claw-repo-aggregate",
        description="Aggregate claw-related repositories into a local repo bundle",
    )
    parser.add_argument("--max-repos", type=int, default=2000, help="Maximum total repos to collect")
    parser.add_argument(
        "--sources",
        default="org,topic,awesome,clawhub,seed",
        help="Comma-separated source list (default: org,topic,awesome,clawhub,seed)",
    )
    parser.add_argument("--seed-file", default="", help="Optional plain-text or JSON seed repo file")
    parser.add_argument(
        "--out",
        default="",
        help="Output SQLite path (default: dist/clawskills-bundle-lite-claw-repos-v{date}.sqlite)",
    )
    parser.add_argument("--version", default="", help="Bundle version string")
    parser.add_argument("--stats-only", action="store_true", help="Only print stats, do not build the bundle")
    parser.add_argument(
        "--state-db",
        default=str(Path.home() / ".clawskills" / "claw-repo-state.sqlite"),
        help="SQLite state DB for incremental repo mining metadata",
    )
    parser.add_argument("--no-state", action="store_true", help="Do not persist repo scan state")

    args = parser.parse_args(argv)
    version = args.version or date.today().strftime("%Y%m%d")
    source_list = [part.strip() for part in args.sources.split(",") if part.strip()]

    repos = aggregate_claw_repos(
        max_repos=args.max_repos,
        sources=source_list,
        seed_file=args.seed_file,
    )
    if not repos:
        print("No claw repos collected. Check network and GitHub token.", file=sys.stderr)
        return 1

    if not args.no_state:
        sync_repo_state(repos, state_db=args.state_db)

    print_repo_stats(repos)
    if args.stats_only:
        return 0

    out_path = args.out or f"dist/clawskills-bundle-lite-claw-repos-v{version}.sqlite"
    build_claw_repo_bundle(repos, out_path, version=version)
    return 0


if __name__ == "__main__":
    raise SystemExit(cli_main())
