"""Centralized HTTP client for all Claw ecosystem fetches.

Routes ALL requests through the hardened ``core.utils.http.fetch_with_retries``
so that scheme allowlisting, SSRF blocking, byte caps, and retry logic are
inherited automatically.
"""

from __future__ import annotations

import os
import time


_USER_AGENT = "clawskills-claw-crawler/0.1 (+https://github.com/LabRAI/ClawSkills)"
_DEFAULT_TIMEOUT_MS = 20_000
_MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB per fetch (raw content / tree JSON)


def github_headers() -> dict[str, str]:
    """Build GitHub API headers with optional auth token."""
    headers: dict[str, str] = {
        "User-Agent": _USER_AGENT,
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    token = (os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN") or "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def has_github_token() -> bool:
    return bool((os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN") or "").strip())


def http_get(url: str, *, headers: dict[str, str] | None = None, timeout_ms: int = 0) -> str | None:
    """Fetch a URL using the hardened central HTTP client.

    Returns the response text, or ``None`` on 404 / permanent failure.
    Raises on scheme/SSRF violations (propagated from ``fetch_with_retries``).
    """
    from ...utils.http import fetch_with_retries, HttpError

    hdrs = {"User-Agent": _USER_AGENT}
    if headers:
        hdrs.update(headers)

    effective_timeout = timeout_ms if timeout_ms > 0 else _DEFAULT_TIMEOUT_MS

    try:
        resp = fetch_with_retries(
            url,
            headers=hdrs,
            timeout_ms=effective_timeout,
            retries=2,
            max_bytes=_MAX_RESPONSE_BYTES,
        )
        return resp.text
    except HttpError as e:
        if e.status == 404:
            return None
        if e.status == 422:
            # GitHub validation failed (e.g., query too complex)
            return None
        if e.status in {403, 429}:
            # Rate limited — caller should handle retry/backoff
            raise
        return None
    except ValueError:
        # Scheme/SSRF violation — propagate
        raise
    except Exception:
        return None


def http_get_with_rate_retry(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout_ms: int = 0,
    max_retries: int = 3,
) -> str | None:
    """Like ``http_get`` but with built-in rate-limit retry (for GitHub 403/429)."""
    from ...utils.http import HttpError

    for attempt in range(max_retries):
        try:
            return http_get(url, headers=headers, timeout_ms=timeout_ms)
        except HttpError as e:
            if e.status in {403, 429} and attempt < max_retries - 1:
                retry_after = e.headers.get("Retry-After", "")
                wait = int(retry_after) if retry_after.isdigit() else min(60, 2 ** attempt * 10)
                time.sleep(wait)
                continue
            return None
    return None


def is_valid_skill_filename(path: str) -> bool:
    """Check if a path ends with exactly ``SKILL.md`` (not NOSKILL.md, .tmpl, etc.)."""
    from pathlib import PurePosixPath
    name = PurePosixPath(path).name
    return name == "SKILL.md"


def is_valid_soul_filename(path: str) -> bool:
    """Check if a path ends with exactly ``SOUL.md``."""
    from pathlib import PurePosixPath
    name = PurePosixPath(path).name
    return name == "SOUL.md"
