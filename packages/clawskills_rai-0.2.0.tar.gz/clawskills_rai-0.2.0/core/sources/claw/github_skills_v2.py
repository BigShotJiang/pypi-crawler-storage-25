"""Extended GitHub SKILL.md crawler with ultra-fine size sharding + topic-based repo search.

Supplements github_skills.py by using:
1. Fine-grained file size shards (every 200-500 bytes) to bypass 1000-result limit
2. GitHub Repository Search API (different rate limits) to find repos by topic
"""

from __future__ import annotations

import json
import logging
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any
from urllib.parse import quote

from .converter import ClawSkill, parse_skill_md
from .github_skills import _fetch_raw_content, _process_one_item
from .http_client import github_headers, http_get_with_rate_retry, is_valid_skill_filename

_GITHUB_API = "https://api.github.com"
_SEARCH_DELAY = 3.0
_CONTENT_DELAY = 0.3


# ── Strategy 1: Ultra-fine size shards ───────────────────────────

def _generate_size_shards() -> list[str]:
    """Generate fine-grained size-based queries to maximize coverage."""
    shards = []
    # 0-1000: single shard (small files)
    shards.append('filename:SKILL.md "name:" size:<500')
    shards.append('filename:SKILL.md "name:" size:500..1000')
    # 1000-5000: every 200 bytes
    for lo in range(1000, 5000, 200):
        shards.append(f'filename:SKILL.md "name:" size:{lo}..{lo+200}')
    # 5000-15000: every 500 bytes
    for lo in range(5000, 15000, 500):
        shards.append(f'filename:SKILL.md "name:" size:{lo}..{lo+500}')
    # 15000-50000: every 1000 bytes
    for lo in range(15000, 50000, 1000):
        shards.append(f'filename:SKILL.md "name:" size:{lo}..{lo+1000}')
    # 50000+: every 5000 bytes up to 100K, then open-ended
    for lo in range(50000, 100000, 5000):
        shards.append(f'filename:SKILL.md "name:" size:{lo}..{lo+5000}')
    shards.append('filename:SKILL.md "name:" size:>100000')
    return shards


# ── Strategy 2: Topic-based repo search ──────────────────────────

_REPO_QUERIES = [
    'topic:openclaw-skill',
    'topic:claude-skill',
    'topic:claude-code-skill',
    'topic:agent-skill',
    'SKILL.md in:readme "clawhub install"',
]


def _search_repos(query: str, max_pages: int = 10) -> list[dict[str, Any]]:
    """Search GitHub Repository API."""
    headers = github_headers()
    all_items: list[dict[str, Any]] = []

    for page in range(1, max_pages + 1):
        url = f"{_GITHUB_API}/search/repositories?q={quote(query)}&per_page=100&page={page}&sort=updated"
        text = http_get_with_rate_retry(url, headers=headers)
        if not text:
            break
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            break
        items = data.get("items", [])
        if not items:
            break
        all_items.extend(items)
        if len(all_items) >= data.get("total_count", 0) or len(all_items) >= 1000:
            break
        time.sleep(_SEARCH_DELAY)

    return all_items


def _find_skill_md_in_repo(repo_full_name: str) -> list[tuple[str, str]]:
    """Find all SKILL.md files in a repo via tree API. Returns [(content, path), ...]."""
    headers = github_headers()
    results = []

    # Try root SKILL.md first (fast path)
    content = _fetch_raw_content(repo_full_name, "SKILL.md")
    if content and content.strip().startswith("---"):
        results.append((content, "SKILL.md"))
        return results  # Most repos have just one

    # Use tree API for repos with multiple skills
    tree_url = f"{_GITHUB_API}/repos/{repo_full_name}/git/trees/HEAD?recursive=1"
    text = http_get_with_rate_retry(tree_url, headers=headers)
    if not text:
        return results
    try:
        tree = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return results

    skill_paths = [
        item["path"] for item in tree.get("tree", [])
        if item.get("type") == "blob" and is_valid_skill_filename(item["path"])
    ]

    for path in skill_paths[:20]:  # Max 20 per repo
        content = _fetch_raw_content(repo_full_name, path)
        if content and content.strip().startswith("---"):
            results.append((content, path))
        time.sleep(_CONTENT_DELAY)

    return results


def _crawl_topic_repos(existing_urls: set[str], max_skills: int = 5000) -> list[ClawSkill]:
    """Search repos by topic, then find SKILL.md in each."""
    skills: list[ClawSkill] = []
    seen_repos: set[str] = set()

    for query in _REPO_QUERIES:
        if len(skills) >= max_skills:
            break
        print(f"[topic-repos] Searching: {query}", file=sys.stderr)
        repos = _search_repos(query, max_pages=10)
        print(f"  Found {len(repos)} repos", file=sys.stderr)

        for repo in repos:
            if len(skills) >= max_skills:
                break
            full_name = repo.get("full_name", "")
            if not full_name or full_name.lower() in seen_repos:
                continue
            if repo.get("fork", False):
                continue
            seen_repos.add(full_name.lower())

            found = _find_skill_md_in_repo(full_name)
            for content, path in found:
                canonical = f"https://github.com/{full_name}/blob/HEAD/{path}"
                if canonical in existing_urls:
                    continue
                existing_urls.add(canonical)

                skill = parse_skill_md(content, source_url=canonical, source_type="claw-github")
                if not skill.name:
                    parts = path.split("/")
                    for i, p in enumerate(parts):
                        if p.lower() in ("skills", ".claude", ".openclaw") and i + 1 < len(parts):
                            skill.name = parts[i + 1]
                            break
                    if not skill.name:
                        skill.name = full_name.split("/")[-1]
                if skill.body_md.strip():
                    skill.metadata["github_repo"] = full_name
                    skill.metadata["github_stars"] = repo.get("stargazers_count", 0)
                    skills.append(skill)

            time.sleep(_CONTENT_DELAY)

        time.sleep(_SEARCH_DELAY)

    print(f"[topic-repos] Total: {len(skills)} skills", file=sys.stderr)
    return skills


# ── Strategy 1 runner: fine size shards ──────────────────────────

def _search_code_single(query: str) -> list[dict[str, Any]]:
    """Search GitHub Code API, return items."""
    headers = github_headers()
    all_items = []
    for page in range(1, 11):
        url = f"{_GITHUB_API}/search/code?q={quote(query)}&per_page=100&page={page}"
        text = http_get_with_rate_retry(url, headers=headers)
        if not text:
            break
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            break
        items = data.get("items", [])
        if not items:
            break
        all_items.extend(items)
        if len(all_items) >= data.get("total_count", 0) or len(all_items) >= 1000:
            break
        time.sleep(_SEARCH_DELAY)
    return all_items


def crawl_fine_shards(
    *,
    existing_urls: set[str] | None = None,
    max_skills: int = 30000,
    workers: int = 12,
) -> list[ClawSkill]:
    """Crawl GitHub SKILL.md with ultra-fine size sharding."""
    shards = _generate_size_shards()
    print(f"[fine-shards] {len(shards)} size shard queries, workers={workers}", file=sys.stderr)

    seen_urls = set(existing_urls or set())
    all_items: list[dict[str, Any]] = []

    # Phase 1: Sequential search (rate-limited)
    for i, query in enumerate(shards):
        if len(all_items) >= max_skills * 2:
            print(f"[fine-shards] Reached item cap at query {i+1}/{len(shards)}", file=sys.stderr)
            break

        items = _search_code_single(query)
        new = 0
        for item in items:
            repo = item.get("repository", {})
            repo_full = repo.get("full_name", "")
            file_path = item.get("path", "")
            if not repo_full or not file_path:
                continue
            if repo.get("fork", False):
                continue
            canonical = f"https://github.com/{repo_full}/blob/HEAD/{file_path}"
            if canonical in seen_urls:
                continue
            seen_urls.add(canonical)
            item["_canonical_url"] = canonical
            all_items.append(item)
            new += 1

        if (i + 1) % 10 == 0 or new > 0:
            print(f"[fine-shards] Query {i+1}/{len(shards)}: +{new} new (total unique: {len(all_items)})", file=sys.stderr)

        time.sleep(_SEARCH_DELAY)

    print(f"[fine-shards] Total unique items: {len(all_items)}", file=sys.stderr)

    # Phase 2: Parallel fetch
    skills: list[ClawSkill] = []
    fetched = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_process_one_item, item, 0): item
            for item in all_items[:max_skills * 2]
        }
        for future in as_completed(futures):
            fetched += 1
            try:
                skill = future.result()
            except Exception as exc:
                logging.getLogger(__name__).warning("fine-shard fetch failed: %s", exc)
                skill = None
            if skill is not None:
                skills.append(skill)
            if len(skills) % 500 == 0 and len(skills) > 0:
                print(f"  [fine-shards] {len(skills)} skills ({fetched}/{len(futures)} fetched)", file=sys.stderr)
            if len(skills) >= max_skills:
                for f in futures:
                    f.cancel()
                break

    print(f"[fine-shards] Final: {len(skills)} skills", file=sys.stderr)
    return skills


# ── Combined entry point ─────────────────────────────────────────

def crawl_extended(
    *,
    existing_urls: set[str] | None = None,
    max_skills: int = 30000,
    workers: int = 12,
) -> list[ClawSkill]:
    """Run both fine-shard and topic-repo crawls in sequence."""
    seen = set(existing_urls or set())
    all_skills: list[ClawSkill] = []

    # Strategy 1: Fine size shards
    shard_skills = crawl_fine_shards(existing_urls=seen, max_skills=max_skills, workers=workers)
    for s in shard_skills:
        all_skills.append(s)
        if s.source_url:
            seen.add(s.source_url)
    print(f"[extended] After fine-shards: {len(all_skills)} skills", file=sys.stderr)

    # Strategy 2: Topic repos
    if len(all_skills) < max_skills:
        topic_skills = _crawl_topic_repos(seen, max_skills=max_skills - len(all_skills))
        existing_names = {s.name for s in all_skills}
        for s in topic_skills:
            if s.name not in existing_names:
                all_skills.append(s)
                existing_names.add(s.name)
        print(f"[extended] After topic-repos: {len(all_skills)} skills", file=sys.stderr)

    return all_skills
