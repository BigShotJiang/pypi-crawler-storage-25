"""Convert SKILL.md (Agent Skills standard) ↔ ClawSkills internal format.

The Agent Skills standard uses a single SKILL.md file with YAML frontmatter.
ClawSkills internally uses metadata.yaml + skill.md (no frontmatter).

This module bridges the two.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


# ── Data model ───────────────────────────────────────────────────

@dataclass
class ClawSkill:
    """A skill parsed from the Agent Skills / OpenClaw ecosystem."""

    # Identity
    name: str = ""
    description: str = ""
    version: str = "0.0.0"
    author: str = ""

    # Classification
    tags: list[str] = field(default_factory=list)
    license_spdx: str = ""

    # Requirements
    requires_bins: list[str] = field(default_factory=list)
    requires_python: str = ""

    # Content
    body_md: str = ""  # Markdown body (without frontmatter)

    # Provenance
    source_url: str = ""  # Where this skill was fetched from
    source_type: str = ""  # claw-clawhub | claw-github | claw-awesome
    raw_frontmatter: dict[str, Any] = field(default_factory=dict)

    # Metadata (pass-through from frontmatter)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def skill_id(self) -> str:
        """Generate a stable skill_id from name + source."""
        slug = re.sub(r"[^a-z0-9]+", "-", self.name.lower()).strip("-") or "unknown"
        h = hashlib.sha256(self.source_url.encode()).hexdigest()[:10]
        return f"claw/{slug}/{slug}-{h}"

    @property
    def source_id(self) -> str:
        """SHA256 of the source URL."""
        return hashlib.sha256(self.source_url.encode()).hexdigest()


# ── SKILL.md parser ──────────────────────────────────────────────

_FRONTMATTER_RE = re.compile(
    r"\A\s*---[ \t]*\n(.*?\n)---[ \t]*\n",
    re.DOTALL,
)


def _parse_yaml_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from SKILL.md text using PyYAML.

    Returns (frontmatter_dict, body_markdown).
    """
    import yaml  # PyYAML is already a project dependency

    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text

    yaml_block = m.group(1)
    body = text[m.end():]

    try:
        result = yaml.safe_load(yaml_block)
    except yaml.YAMLError:
        return {}, text

    if not isinstance(result, dict):
        return {}, text

    return result, body


def parse_skill_md(text: str, *, source_url: str = "", source_type: str = "") -> ClawSkill:
    """Parse a SKILL.md file into a ClawSkill object."""
    fm, body = _parse_yaml_frontmatter(text)

    # Extract metadata sub-dict
    metadata = fm.get("metadata", {})
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except (json.JSONDecodeError, ValueError):
            metadata = {}

    # Extract requires
    requires = fm.get("requires", {})
    if isinstance(requires, dict):
        bins = requires.get("bins", [])
        python_ver = str(requires.get("python", ""))
    else:
        bins = []
        python_ver = ""

    if isinstance(bins, str):
        bins = [bins]

    # Tags
    tags = fm.get("tags", [])
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",") if t.strip()]

    return ClawSkill(
        name=str(fm.get("name", "")),
        description=str(fm.get("description", "")),
        version=str(fm.get("version", "0.0.0")),
        author=str(fm.get("author", "")),
        tags=tags,
        license_spdx=str(fm.get("license", metadata.get("license", ""))),
        requires_bins=bins,
        requires_python=python_ver,
        body_md=body.strip(),
        source_url=source_url or str(metadata.get("source", "")),
        source_type=source_type,
        raw_frontmatter=fm,
        metadata=metadata if isinstance(metadata, dict) else {},
    )


# ── Domain inference ─────────────────────────────────────────────

_TAG_DOMAIN_MAP: dict[str, str] = {
    # Web / Frontend
    "react": "web", "vue": "web", "angular": "web", "svelte": "web",
    "nextjs": "web", "next.js": "web", "nuxt": "web", "remix": "web",
    "css": "web", "html": "web", "javascript": "web", "typescript": "web",
    "frontend": "web", "web": "web", "tailwind": "web", "sass": "web",
    "dom": "web", "browser": "web", "webpack": "web", "vite": "web",
    "ui": "web", "ux": "web", "responsive": "web", "spa": "web",
    # Linux / System
    "linux": "linux", "bash": "linux", "shell": "linux", "cli": "linux",
    "systemd": "linux", "unix": "linux", "terminal": "linux", "zsh": "linux",
    "apt": "linux", "brew": "linux", "cron": "linux", "ssh": "linux",
    "nginx": "linux", "apache": "linux", "sysadmin": "linux",
    # DevTools
    "git": "devtools", "ci": "devtools", "cd": "devtools", "ci/cd": "devtools",
    "github-actions": "devtools", "docker": "devtools", "devtools": "devtools",
    "testing": "devtools", "debugging": "devtools", "linting": "devtools",
    "devops": "devtools", "deployment": "devtools", "build": "devtools",
    "npm": "devtools", "yarn": "devtools", "pnpm": "devtools", "pip": "devtools",
    "eslint": "devtools", "prettier": "devtools", "formatter": "devtools",
    "jest": "devtools", "pytest": "devtools", "playwright": "devtools",
    "cicd": "devtools", "pipeline": "devtools", "makefile": "devtools",
    "vscode": "devtools", "cursor": "devtools", "ide": "devtools",
    # Cloud
    "aws": "cloud", "gcp": "cloud", "azure": "cloud", "cloud": "cloud",
    "kubernetes": "cloud", "k8s": "cloud", "terraform": "cloud",
    "serverless": "cloud", "lambda": "cloud", "cloudformation": "cloud",
    "s3": "cloud", "ec2": "cloud", "vercel": "cloud", "netlify": "cloud",
    "heroku": "cloud", "digitalocean": "cloud", "helm": "cloud",
    # ML
    "machine-learning": "ml", "ml": "ml", "pytorch": "ml", "tensorflow": "ml",
    "deep-learning": "ml", "neural-network": "ml", "training": "ml",
    "model": "ml", "huggingface": "ml", "scikit": "ml", "sklearn": "ml",
    "computer-vision": "ml", "nlp": "ml", "fine-tune": "ml",
    # LLM / AI
    "llm": "llm", "gpt": "llm", "claude": "llm", "openai": "llm",
    "langchain": "llm", "rag": "llm", "prompt": "llm", "ai": "llm",
    "agent": "llm", "chatbot": "llm", "embedding": "llm", "vector": "llm",
    "mcp": "llm", "anthropic": "llm", "gemini": "llm", "copilot": "llm",
    "automation": "llm", "workflow": "llm", "n8n": "llm",
    "chat": "llm", "assistant": "llm", "bot": "llm",
    # Data
    "sql": "data", "database": "data", "postgres": "data", "mysql": "data",
    "data": "data", "pandas": "data", "etl": "data", "dbt": "data",
    "mongodb": "data", "redis": "data", "elasticsearch": "data",
    "sqlite": "data", "graphql": "data", "api": "data",
    "scraping": "data", "crawling": "data", "csv": "data", "json": "data",
    # Security
    "security": "security", "auth": "security", "oauth": "security",
    "encryption": "security", "vulnerability": "security", "pentest": "security",
    "firewall": "security", "tls": "security", "ssl": "security",
    "jwt": "security", "rbac": "security", "audit": "security",
    # Observability
    "monitoring": "observability", "logging": "observability",
    "prometheus": "observability", "grafana": "observability",
    "observability": "observability", "alerting": "observability",
    "metrics": "observability", "tracing": "observability", "datadog": "observability",
    # Programming
    "python": "programming", "rust": "programming", "go": "programming",
    "java": "programming", "c++": "programming", "algorithm": "programming",
    "design-pattern": "programming", "refactoring": "programming",
    "kotlin": "programming", "swift": "programming", "ruby": "programming",
    "php": "programming", "scala": "programming", "elixir": "programming",
    "code-review": "programming", "architecture": "programming",
    # Research
    "research": "research", "paper": "research", "arxiv": "research",
    "academic": "research", "experiment": "research", "journal": "research",
}

# Regex patterns for body-content-based classification (checked when tags/name fail)
_BODY_DOMAIN_PATTERNS: list[tuple[str, str]] = [
    # LLM / AI — most agent skills mention these
    (r"(?:prompt|LLM|GPT|Claude|OpenAI|AI agent|chatbot|embedding|RAG|MCP|langchain)", "llm"),
    (r"(?:automat|workflow|n8n|zapier|assistant|bot\b)", "llm"),
    # Web
    (r"(?:React|Vue|Angular|Next\.js|CSS|HTML|frontend|browser|DOM|Tailwind|component)", "web"),
    (r"(?:HTTP|REST\s*API|endpoint|fetch|axios|GraphQL|webhook)", "web"),
    # DevTools
    (r"(?:Docker|CI/CD|GitHub Actions|Jenkins|deploy|pipeline|build|test|lint|debug)", "devtools"),
    (r"(?:git\b|npm|yarn|pip install|makefile|Dockerfile)", "devtools"),
    # Cloud
    (r"(?:AWS|GCP|Azure|Kubernetes|Terraform|S3|EC2|Lambda|Serverless|CloudFormation)", "cloud"),
    # Data
    (r"(?:SQL|database|PostgreSQL|MySQL|MongoDB|Redis|ETL|DataFrame|pandas|query)", "data"),
    (r"(?:scraping|crawl|API\s+call|JSON|CSV|data\s+pipeline)", "data"),
    # Security
    (r"(?:security|auth|OAuth|JWT|encrypt|vulnerability|firewall|SSL|TLS|RBAC)", "security"),
    # Linux
    (r"(?:bash|shell|terminal|systemd|cron|SSH|nginx|Apache|sysadmin|chmod|sudo)", "linux"),
    # Programming
    (r"(?:Python|Rust|Go\b|Java\b|C\+\+|algorithm|refactor|design pattern|code review)", "programming"),
    # ML
    (r"(?:PyTorch|TensorFlow|model\s+train|neural|deep learning|fine-?tune|scikit|HuggingFace)", "ml"),
]

_BODY_DOMAIN_COMPILED = [(re.compile(pattern, re.IGNORECASE), domain) for pattern, domain in _BODY_DOMAIN_PATTERNS]


def infer_domain(skill: ClawSkill) -> str:
    """Infer the ClawSkills domain from tags, name, description, and body content."""
    # 1. Check tags first (highest signal)
    for tag in skill.tags:
        tag_lower = tag.lower().strip()
        if tag_lower in _TAG_DOMAIN_MAP:
            return _TAG_DOMAIN_MAP[tag_lower]

    # 2. Check name and description with word-boundary matching
    text = f" {skill.name} {skill.description} ".lower()
    # Replace common separators with spaces for better word matching
    text = re.sub(r"[-_./]", " ", text)
    for keyword, domain in _TAG_DOMAIN_MAP.items():
        # Short keywords (≤3 chars) need word boundaries to avoid false positives
        if len(keyword) <= 3:
            if re.search(rf"\b{re.escape(keyword)}\b", text):
                return domain
        else:
            if keyword in text:
                return domain

    # 3. Check body content with regex patterns (first 2000 chars for speed)
    body_sample = (skill.body_md or "")[:2000]
    if body_sample:
        for pattern, domain in _BODY_DOMAIN_COMPILED:
            if pattern.search(body_sample):
                return domain

    return "other"


def infer_skill_kind(skill: ClawSkill) -> str:
    """Map claw ecosystem records to a stable skill kind."""
    record_kind = str(skill.metadata.get("record_kind") or "").strip().lower()
    if record_kind == "usecase":
        return "claw-usecase"
    if record_kind == "agent-template":
        return "claw-agent-template"
    if record_kind == "repo":
        return "claw-repo"
    return "claw-skill"


# ── Convert to ClawSkills format ─────────────────────────────────

def to_clawskills_metadata(skill: ClawSkill) -> dict[str, Any]:
    """Convert a ClawSkill to a ClawSkills metadata dict.

    This produces the same field set as ClawSkills' metadata.yaml.
    """
    domain = infer_domain(skill)
    now_iso = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Compute a content-based quality score instead of just repo priority.
    overall_score = 0.0
    # Inherit repo priority if available
    for score_key in ("priority_score", "repo_priority_score"):
        try:
            raw_score = skill.metadata.get(score_key)
        except Exception:
            raw_score = None
        if raw_score is None or raw_score == "":
            continue
        try:
            overall_score = float(raw_score)
            break
        except Exception:
            continue
    # Add content-based quality signals
    body = skill.body_md or ""
    body_len = len(body.strip())
    if body_len > 2000:
        overall_score += 3.0
    elif body_len > 500:
        overall_score += 2.0
    elif body_len > 100:
        overall_score += 1.0
    if skill.description and len(skill.description) > 20:
        overall_score += 1.0
    if skill.tags and len(skill.tags) >= 2:
        overall_score += 0.5
    # Code blocks indicate actionable content
    if "```" in body:
        overall_score += 1.5
    # Sections indicate structured content
    if body.count("\n## ") >= 2:
        overall_score += 1.0

    display_title = str(skill.metadata.get("display_title") or "").strip()
    title = display_title or str(skill.name or "").strip() or str(skill.description or "").strip()

    meta: dict[str, Any] = {
        "id": skill.skill_id,
        "skill_id": skill.skill_id,
        "title": title,
        "domain": domain,
        "profile": domain,
        "topic": skill.tags[0] if skill.tags else domain,
        "slug": re.sub(r"[^a-z0-9]+", "-", skill.name.lower()).strip("-"),
        "source_type": skill.source_type,
        "source_url": skill.source_url,
        "source_id": skill.source_id,
        "primary_source_id": skill.source_id,
        "overall_score": overall_score,
        "skill_kind": infer_skill_kind(skill),
        "language": "en",
        "license_spdx": skill.license_spdx or "NOASSERTION",
        "license_risk": "allow" if skill.license_spdx in (
            "MIT", "Apache-2.0", "BSD-3-Clause", "BSD-2-Clause",
            "ISC", "Unlicense", "CC0-1.0", "CC-BY-4.0",
        ) else "needs_review",
        "tags": skill.tags,
        "has_evidence": False,
        "verification_runnable": False,
        "generated_at": now_iso,
        "source_fetched_at": now_iso,
        "package_schema_version": 2,
        "claw_name": skill.name,
        "claw_version": skill.version,
        "claw_author": skill.author,
        "claw_requires_bins": skill.requires_bins,
    }

    for key, value in skill.metadata.items():
        if not key or key in meta or value is None:
            continue
        if isinstance(value, (str, int, float, bool)):
            meta[key] = value
            continue
        if isinstance(value, (list, tuple)):
            simple_items: list[Any] = []
            ok = True
            for item in value:
                if isinstance(item, (str, int, float, bool)) or item is None:
                    simple_items.append(item)
                else:
                    ok = False
                    break
            if ok:
                meta[key] = simple_items

    return meta


def to_metadata_yaml_text(meta: dict[str, Any]) -> str:
    """Serialize a metadata dict to ClawSkills metadata.yaml text."""
    lines: list[str] = []
    for k, v in meta.items():
        if v is None:
            continue
        if isinstance(v, bool):
            lines.append(f"{k}: {'true' if v else 'false'}")
        elif isinstance(v, (int, float)):
            lines.append(f"{k}: {v}")
        elif isinstance(v, (list, tuple)):
            encoded = ", ".join(json.dumps(str(x)) for x in v)
            lines.append(f"{k}: [{encoded}]")
        else:
            lines.append(f"{k}: {json.dumps(str(v))}")
    return "\n".join(lines) + "\n"


def to_bundle_row(skill: ClawSkill) -> dict[str, Any] | None:
    """Convert a ClawSkill to a dict ready for SQLite bundle insertion.

    Returns None if the skill is invalid (no name or body).
    """
    if not skill.name or not skill.body_md.strip():
        return None

    meta = to_clawskills_metadata(skill)
    meta_yaml_text = to_metadata_yaml_text(meta)

    return {
        # skills_index columns
        "skill_id": meta["skill_id"],
        "domain": meta["domain"],
        "profile": meta["profile"],
        "source_type": meta["source_type"],
        "source_url": meta["source_url"],
        "title": meta["title"],
        "overall_score": meta["overall_score"],
        "skill_kind": meta["skill_kind"],
        "language": meta["language"],
        "source_id": meta["source_id"],
        "primary_source_id": meta["primary_source_id"],
        # skills_content columns
        "metadata_yaml": meta_yaml_text,
        "skill_md": skill.body_md,
        "library_md": "",
    }
