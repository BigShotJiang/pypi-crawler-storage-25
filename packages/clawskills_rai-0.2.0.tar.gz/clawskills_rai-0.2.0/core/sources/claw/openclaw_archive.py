"""Fetch archived skills from the official ``openclaw/skills`` repository."""

from __future__ import annotations

import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any
from urllib.parse import quote

from .converter import ClawSkill, parse_skill_md
from .http_client import github_headers, http_get_with_rate_retry, is_valid_skill_filename

_TREE_URL = "https://api.github.com/repos/openclaw/skills/git/trees/HEAD?recursive=1"
_RAW_BASE = "https://raw.githubusercontent.com/openclaw/skills/HEAD"
_BLOB_BASE = "https://github.com/openclaw/skills/blob/HEAD"
_DEFAULT_WORKERS = 16  # bounded to avoid hammering raw.githubusercontent.com


def _list_skill_paths() -> list[str]:
    """Return archived ``SKILL.md`` paths from the official repo tree."""
    text = http_get_with_rate_retry(_TREE_URL, headers=github_headers())
    if not text:
        return []
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return []

    paths = [
        str(item.get("path") or "").strip()
        for item in data.get("tree", [])
        if item.get("type") == "blob" and is_valid_skill_filename(str(item.get("path") or ""))
    ]
    return [p for p in paths if p]


def crawl_openclaw_archive(
    *,
    max_skills: int = 2000,
    workers: int = _DEFAULT_WORKERS,
    emit: Any = None,
) -> list[ClawSkill]:
    """Fetch skills from ``openclaw/skills``.

    This is the official archived skill repository behind the OpenClaw ecosystem.
    """
    print(f"[openclaw-archive] Starting crawl (max_skills={max_skills})...", file=sys.stderr)
    paths = _list_skill_paths()
    if emit:
        emit(f"Found {len(paths)} archived SKILL.md files in openclaw/skills")
    if not paths:
        return []

    def _fetch_one(path: str) -> tuple[str, ClawSkill | None]:
        encoded_path = quote(path, safe="/")
        raw_url = f"{_RAW_BASE}/{encoded_path}"
        blob_url = f"{_BLOB_BASE}/{encoded_path}"
        content = http_get_with_rate_retry(raw_url, headers=github_headers())
        if not content or not content.strip().startswith("---"):
            return path, None

        skill = parse_skill_md(
            content,
            source_url=blob_url,
            source_type="claw-archive",
        )
        if not skill.name or not skill.body_md.strip():
            return path, None
        skill.metadata["archive_path"] = path
        return path, skill

    skills: list[ClawSkill] = []
    seen_names: set[str] = set()
    fetched = 0
    target_paths = paths[:max_skills]

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = {pool.submit(_fetch_one, path): path for path in target_paths}
        for future in as_completed(futures):
            fetched += 1
            try:
                _, skill = future.result()
            except Exception as exc:
                logging.getLogger(__name__).warning("_fetch_one worker failed: %s", exc)
                skill = None

            if skill is not None:
                key = skill.name.strip().lower()
                if key and key not in seen_names:
                    seen_names.add(key)
                    skills.append(skill)

            if fetched % 20 == 0:
                print(
                    f"  [openclaw-archive] Fetched {fetched}/{len(target_paths)} files, kept {len(skills)} skills",
                    file=sys.stderr,
                )
            if len(skills) >= max_skills:
                for pending in futures:
                    pending.cancel()
                break

    print(f"[openclaw-archive] Total: {len(skills)} skills collected", file=sys.stderr)
    return skills
