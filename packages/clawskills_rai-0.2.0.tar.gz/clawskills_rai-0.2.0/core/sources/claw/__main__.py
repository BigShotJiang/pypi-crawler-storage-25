"""Allow ``python -m core.sources.claw`` invocation."""
from . import cli_main

raise SystemExit(cli_main())
