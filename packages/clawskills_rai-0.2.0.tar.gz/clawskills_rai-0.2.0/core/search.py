"""Skill search module — query the ClawSkills SQLite index locally.

Supports two modes:

1. **Single-file bundle** (preferred): A self-contained ``.sqlite`` bundle
   built by ``build_bundle.py`` that includes both ``skills_index`` and
   ``skills_content`` tables plus an FTS5 virtual table.

2. **Legacy two-file mode**: Separate ``index.sqlite`` (metadata) +
   ``skills_bundle.sqlite`` (content).

Bundle resolution order (first existing path wins):

1. ``CLAWSKILLS_BUNDLE_PATH`` environment variable
2. ``skills/skills_bundle.sqlite`` in the repo  (if it contains ``skills_index``)
3. ``~/.clawskills/search_config.json`` → ``bundle_path``
4. ``~/.clawskills/clawskills-bundle-lite-*.sqlite`` (glob, newest)
5. Fallback: legacy ``skills/index.sqlite`` + ``skills/skills_bundle.sqlite``

Zero new dependencies — uses only stdlib ``sqlite3``.
"""

from __future__ import annotations

import glob as _glob
import json
import os
import re
import sqlite3
import sys
from pathlib import Path
from typing import Any

# ── path resolution ──────────────────────────────────────────────

_REPO_ROOT = Path(__file__).resolve().parents[1]
_SEARCH_BODY_EXCERPT_CHARS = 2000
_TOKEN_RE = re.compile(r"[0-9A-Za-z_./:+#-]+", re.UNICODE)
_TITLE_WORD_RE = re.compile(r"[0-9A-Za-z]+", re.UNICODE)


def _skills_dir() -> Path:
    """Return the directory containing the SQLite databases."""
    override = os.environ.get("CLAWSKILLS_SKILLS_DIR", "").strip()
    if override:
        return Path(override)
    return _REPO_ROOT / "skills"


def _dist_dir() -> Path:
    """Return the dist/ directory containing built bundles."""
    override = os.environ.get("CLAWSKILLS_DIST_DIR", "").strip()
    if override:
        return Path(override)
    return _REPO_ROOT / "dist"


def _index_db() -> Path:
    return _skills_dir() / "index.sqlite"


def _bundle_db() -> Path:
    return _skills_dir() / "skills_bundle.sqlite"


def _bundle_has_index(conn: sqlite3.Connection) -> bool:
    """Check whether a bundle DB contains the ``skills_index`` table.

    If True, the bundle is self-contained (single-file mode).
    """
    try:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='skills_index'"
        ).fetchone()
        return row is not None
    except Exception:
        return False


def _resolve_bundle() -> Path | None:
    """Walk the fallback chain and return the first usable bundle path.

    Returns None if no bundle is found (caller should fall back to legacy).
    """
    # 1. Explicit env override
    env_path = os.environ.get("CLAWSKILLS_BUNDLE_PATH", "").strip()
    if env_path:
        p = Path(env_path)
        if p.exists():
            return p

    # 2. Repo-local skills_bundle.sqlite (only if it has skills_index)
    repo_bundle = _bundle_db()
    if repo_bundle.exists():
        try:
            c = sqlite3.connect(f"file:{repo_bundle}?mode=ro", uri=True)
            has = _bundle_has_index(c)
            c.close()
            if has:
                return repo_bundle
        except Exception:
            pass

    # 3. ~/.clawskills/search_config.json → bundle_path
    config_path = Path.home() / ".clawskills" / "search_config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            bp = cfg.get("bundle_path", "")
            if bp and Path(bp).exists():
                return Path(bp)
        except Exception:
            pass

    # 4. Glob ~/.clawskills/clawskills-bundle-lite-*.sqlite (newest)
    home_dir = Path.home() / ".clawskills"
    if home_dir.is_dir():
        candidates = sorted(
            _glob.glob(str(home_dir / "clawskills-bundle-lite-*.sqlite")),
            reverse=True,
        )
        if candidates:
            return Path(candidates[0])

    return None


def _resolve_all_bundles(domain: str = "", bundle_name: str = "") -> list[Path]:
    """Return all installed bundle paths for multi-bundle search.

    Resolution order:
    1. ``search_config.json`` → ``bundles`` dict (domain-keyed)
    2. Glob ``~/.clawskills/clawskills-bundle-*.sqlite``
    3. Single-bundle fallback via ``_resolve_bundle()``

    If *bundle_name* is given, only return the bundle registered under that
    config key or matching that bundle name in dist/home globs.
    If *domain* is given, only return the bundle for that domain.
    """
    found: list[Path] = []
    seen: set[str] = set()

    # 0. Explicit env override
    env_path = os.environ.get("CLAWSKILLS_BUNDLE_PATH", "").strip()
    if env_path:
        p = Path(env_path)
        if p.exists():
            if bundle_name and f"-{bundle_name}-" not in p.name:
                return []
            found.append(p)
            seen.add(str(p))
            return found

    # 1. search_config.json → bundles dict
    config_path = Path.home() / ".clawskills" / "search_config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            bundles_dict = cfg.get("bundles", {})
            if isinstance(bundles_dict, dict):
                for d, bp in bundles_dict.items():
                    if bundle_name and d != bundle_name:
                        continue
                    if domain and not bundle_name and d != domain:
                        continue
                    p = Path(bp)
                    if p.exists() and str(p) not in seen:
                        found.append(p)
                        seen.add(str(p))
        except Exception:
            pass

    if (bundle_name or domain) and found:
        return found

    # 2. Glob dist/ directory for split bundles
    dist = _dist_dir()
    if dist.is_dir():
        for candidate in sorted(
            _glob.glob(str(dist / "clawskills-bundle-*.sqlite")),
            reverse=True,
        ):
            p = Path(candidate)
            name = p.name
            if str(p) not in seen:
                if domain:
                    if bundle_name:
                        if f"-{bundle_name}-" not in name:
                            continue
                    else:
                        if f"-{domain}-" not in name:
                            continue
                elif bundle_name:
                    name = p.name
                    if f"-{bundle_name}-" not in name:
                        continue
                found.append(p)
                seen.add(str(p))

    if found:
        return found

    # 3. Glob ~/.clawskills/clawskills-bundle-*-*.sqlite (domain bundles)
    home_dir = Path.home() / ".clawskills"
    if home_dir.is_dir():
        for candidate in sorted(
            _glob.glob(str(home_dir / "clawskills-bundle-*-*.sqlite")),
            reverse=True,
        ):
            p = Path(candidate)
            name = p.name
            if str(p) not in seen:
                if domain:
                    if bundle_name:
                        if f"-{bundle_name}-" not in name:
                            continue
                    else:
                        if f"-{domain}-" not in name:
                            continue
                elif bundle_name:
                    name = p.name
                    if f"-{bundle_name}-" not in name:
                        continue
                found.append(p)
                seen.add(str(p))

    if found:
        return found

    # 3. Fallback to single bundle
    single = _resolve_bundle()
    if single is not None:
        if bundle_name:
            if f"-{bundle_name}-" in single.name:
                return [single]
            return []
        return [single]

    return []


def list_bundle_names() -> list[str]:
    """Return installed bundle keys discovered from config and filenames."""
    names: set[str] = set()
    config_path = Path.home() / ".clawskills" / "search_config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            bundles_dict = cfg.get("bundles", {})
            if isinstance(bundles_dict, dict):
                names.update(str(k).strip() for k in bundles_dict if str(k).strip())
        except Exception:
            pass

    for root in (_dist_dir(), Path.home() / ".clawskills"):
        if not root.is_dir():
            continue
        for p in root.glob("clawskills-bundle-*.sqlite"):
            name = p.name
            marker = "clawskills-bundle-"
            if not name.startswith(marker) or "-v" not in name:
                continue
            stem = name[: -len(".sqlite")]
            payload = stem[len(marker):]
            if payload.startswith("lite-"):
                payload = payload[len("lite-"):]
            elif payload.startswith("full-"):
                payload = payload[len("full-"):]
            bundle_key = payload.rsplit("-v", 1)[0]
            if bundle_key:
                names.add(bundle_key.strip())

    return sorted(n for n in names if n)


# ── FTS helpers ──────────────────────────────────────────────────

def _ensure_fts(conn: sqlite3.Connection) -> bool:
    """Try to create an FTS5 virtual table over ``skills_index.title``.

    Returns True if FTS5 is available, False otherwise (falls back to LIKE).
    """
    try:
        # Check if FTS table already exists (e.g. built into the bundle).
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='skills_fts'"
        ).fetchone()
        if row is not None:
            return True
        conn.execute(
            "CREATE VIRTUAL TABLE IF NOT EXISTS skills_fts "
            "USING fts5(title, skill_id UNINDEXED, content='skills_index', content_rowid='rowid')"
        )
        # Populate if empty.
        count = conn.execute("SELECT COUNT(*) FROM skills_fts").fetchone()[0]
        if count == 0:
            conn.execute(
                "INSERT INTO skills_fts(skills_fts) VALUES('rebuild')"
            )
        return True
    except Exception:
        return False


def _fts_query(conn: sqlite3.Connection, query: str, limit: int) -> list[str]:
    """Return matching skill_ids via FTS5 ranked search."""
    # Escape double-quotes in query for FTS5 syntax.
    safe_q = query.replace('"', '""')
    rows = conn.execute(
        'SELECT skill_id FROM skills_fts WHERE skills_fts MATCH ? ORDER BY rank LIMIT ?',
        (f'"{safe_q}"', limit),
    ).fetchall()
    return [r[0] for r in rows]


def _like_query(conn: sqlite3.Connection, query: str, limit: int) -> list[str]:
    """Fallback: return matching skill_ids via LIKE %query%."""
    rows = conn.execute(
        "SELECT skill_id FROM skills_index WHERE title LIKE ? ORDER BY overall_score DESC LIMIT ?",
        (f"%{query}%", limit),
    ).fetchall()
    return [r[0] for r in rows]


def _normalize_query_text(text: str) -> str:
    return " ".join(str(text or "").strip().casefold().split())


def _query_terms(query: str) -> tuple[str, list[str]]:
    phrase = _normalize_query_text(query)
    tokens: list[str] = []
    seen: set[str] = set()
    for token in _TOKEN_RE.findall(phrase):
        norm = _normalize_query_text(token)
        if not norm or norm in seen:
            continue
        seen.add(norm)
        tokens.append(norm)
    return phrase, tokens


def _title_text_query(conn: sqlite3.Connection, query: str, limit: int) -> list[str]:
    """Search title text for phrase/tokens without requiring an exact phrase hit."""
    phrase, tokens = _query_terms(query)
    if not phrase:
        return []

    terms = [phrase, *tokens]
    ids: list[str] = []
    seen: set[str] = set()
    per_term_limit = max(limit, 25)
    for term in terms:
        rows = conn.execute(
            """
            SELECT skill_id
            FROM skills_index
            WHERE instr(lower(COALESCE(title, '')), ?) > 0
            ORDER BY overall_score DESC
            LIMIT ?
            """,
            (term, per_term_limit),
        ).fetchall()
        for row in rows:
            skill_id = str(row[0] or "")
            if not skill_id or skill_id in seen:
                continue
            seen.add(skill_id)
            ids.append(skill_id)
            if len(ids) >= limit:
                return ids
    return ids


def _content_query(conn: sqlite3.Connection, query: str, limit: int) -> list[str]:
    """Search metadata + body excerpt for a query phrase and tokens."""
    phrase, tokens = _query_terms(query)
    if not phrase:
        return []

    terms = [phrase, *tokens]
    ids: list[str] = []
    seen: set[str] = set()
    per_term_limit = max(limit, 25)
    for term in terms:
        rows = conn.execute(
            f"""
            SELECT skill_id
            FROM skills_content
            WHERE instr(lower(COALESCE(metadata_yaml, '')), ?) > 0
               OR instr(lower(substr(COALESCE(skill_md, ''), 1, {_SEARCH_BODY_EXCERPT_CHARS})), ?) > 0
            LIMIT ?
            """,
            (term, term, per_term_limit),
        ).fetchall()
        for row in rows:
            skill_id = str(row[0] or "")
            if not skill_id or skill_id in seen:
                continue
            seen.add(skill_id)
            ids.append(skill_id)
            if len(ids) >= limit:
                return ids
    return ids


def _merge_candidate_ids(*id_lists: list[str], limit: int) -> list[str]:
    merged: list[str] = []
    seen: set[str] = set()
    for items in id_lists:
        for skill_id in items:
            sid = str(skill_id or "")
            if not sid or sid in seen:
                continue
            seen.add(sid)
            merged.append(sid)
            if len(merged) >= limit:
                return merged
    return merged


def _text_signal(text: str, phrase: str, tokens: list[str], *, exact_weight: float, token_weight: float) -> float:
    hay = _normalize_query_text(text)
    if not hay:
        return 0.0
    score = 0.0
    if phrase and phrase in hay:
        score += exact_weight
    for token in tokens:
        if token and token in hay:
            score += token_weight
    return score


def _search_rank(row: dict[str, Any], query: str) -> float:
    phrase, tokens = _query_terms(query)
    title = str(row.get("title") or "")
    metadata_yaml = str(row.get("metadata_yaml") or "")
    body_excerpt = str(row.get("skill_md_excerpt") or "")
    score = 0.0
    score += _text_signal(title, phrase, tokens, exact_weight=120.0, token_weight=24.0)
    score += _text_signal(metadata_yaml, phrase, tokens, exact_weight=45.0, token_weight=9.0)
    score += _text_signal(body_excerpt, phrase, tokens, exact_weight=30.0, token_weight=6.0)
    try:
        overall = float(row.get("overall_score") or 0.0)
    except Exception:
        overall = 0.0
    score += min(overall, 250.0) * 0.1
    return score


def _title_family(title: str) -> str:
    words = [w for w in _TITLE_WORD_RE.findall(_normalize_query_text(title)) if w]
    return " ".join(words)


def _title_token_list(title: str) -> list[str]:
    return [w for w in _TITLE_WORD_RE.findall(_normalize_query_text(title)) if w]


def _cluster_key(row: dict[str, Any], query: str) -> str:
    phrase, tokens = _query_terms(query)
    title = str(row.get("title") or "")
    family = _title_family(title)
    if not family:
        return ""
    title_tokens = _title_token_list(title)
    if len(tokens) >= 2 and all(token in title_tokens for token in tokens):
        extras = [tok for tok in title_tokens if tok not in tokens]
        if len(extras) <= 3:
            return f"query:{' '.join(tokens)}"
    return f"title:{family}"


def _cluster_primary_rank(row: dict[str, Any], query: str) -> tuple[float, float, float, float, float]:
    phrase, tokens = _query_terms(query)
    family = _title_family(str(row.get("title") or ""))
    title_tokens = _title_token_list(str(row.get("title") or ""))
    extras = [tok for tok in title_tokens if tok not in tokens]
    exact = 1.0 if phrase and family == phrase else 0.0
    prefix = 1.0 if phrase and family.startswith(f"{phrase} ") else 0.0
    contains = 1.0 if phrase and phrase in family else 0.0
    try:
        search_score = float(row.get("_search_score") or 0.0)
    except Exception:
        search_score = 0.0
    return (
        exact,
        prefix,
        contains,
        -float(len(extras)),
        search_score,
    )


def _variant_payload(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "skill_id": row.get("skill_id") or "",
        "title": row.get("title") or "",
        "source_url": row.get("source_url") or "",
        "overall_score": row.get("overall_score") or 0,
    }


def _collapse_variant_results(
    results: list[dict[str, Any]],
    query: str,
    *,
    top_k: int,
    enabled: bool,
) -> list[dict[str, Any]]:
    if not enabled or not results:
        return results[:top_k]

    collapsed: list[dict[str, Any]] = []
    groups: dict[str, dict[str, Any]] = {}
    group_positions: dict[str, int] = {}

    for row in results:
        key = _cluster_key(row, query)
        if not key:
            row.pop("variant_count", None)
            row.pop("variant_examples", None)
            collapsed.append(row)
            continue

        current = groups.get(key)
        if current is None:
            row["variant_count"] = 0
            row["variant_examples"] = []
            groups[key] = row
            group_positions[key] = len(collapsed)
            collapsed.append(row)
            continue

        if _cluster_primary_rank(row, query) > _cluster_primary_rank(current, query):
            variant_examples = list(current.get("variant_examples") or [])
            variant_examples.append(_variant_payload(current))
            row["variant_examples"] = variant_examples
            row["variant_count"] = len(variant_examples)
            groups[key] = row
            collapsed[group_positions[key]] = row
            continue

        variant_examples = list(current.get("variant_examples") or [])
        variant_examples.append(_variant_payload(row))
        current["variant_examples"] = variant_examples
        current["variant_count"] = len(variant_examples)

    return collapsed[:top_k]


# ── core search ──────────────────────────────────────────────────

def _search_single_bundle(
    bundle_path: Path,
    query: str,
    top_k: int,
    domain: str,
    kind: str,
    source_type: str,
    min_score: float,
    content: bool,
    max_chars: int,
) -> list[dict[str, Any]]:
    """Search a self-contained bundle (has both skills_index and skills_content)."""
    conn = sqlite3.connect(f"file:{bundle_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        has_fts = _ensure_fts(conn)
        if has_fts:
            fts_ids = _fts_query(conn, query, top_k * 8)
        else:
            fts_ids = _like_query(conn, query, top_k * 8)
        title_ids = _title_text_query(conn, query, top_k * 12)
        content_ids = _content_query(conn, query, top_k * 12)
        candidate_ids = _merge_candidate_ids(fts_ids, title_ids, content_ids, limit=top_k * 24)

        if not candidate_ids:
            return []

        placeholders = ",".join("?" for _ in candidate_ids)
        rows = conn.execute(
            f"""
            SELECT i.*, c.metadata_yaml, substr(COALESCE(c.skill_md, ''), 1, {_SEARCH_BODY_EXCERPT_CHARS}) AS skill_md_excerpt
            FROM skills_index AS i
            LEFT JOIN skills_content AS c USING(skill_id)
            WHERE i.skill_id IN ({placeholders})
            """,
            candidate_ids,
        ).fetchall()

        results: list[dict[str, Any]] = []
        for row in rows:
            r = dict(row)
            if domain and (r.get("domain") or "").lower() != domain.lower():
                continue
            if kind and (r.get("skill_kind") or "").lower() != kind.lower():
                continue
            if source_type and (r.get("source_type") or "").lower() != source_type.lower():
                continue
            if min_score and (r.get("overall_score") or 0) < min_score:
                continue
            r["_search_score"] = _search_rank(r, query)
            results.append(r)

        id_order = {sid: i for i, sid in enumerate(candidate_ids)}
        results.sort(
            key=lambda r: (
                -(float(r.get("_search_score") or 0.0)),
                -(float(r.get("overall_score") or 0.0)),
                id_order.get(r["skill_id"], 9999),
            )
        )
        results = results[:top_k]

        # Content fetch from the same DB
        if content and results:
            ids = [r["skill_id"] for r in results]
            ph = ",".join("?" for _ in ids)
            content_rows = conn.execute(
                f"SELECT skill_id, skill_md FROM skills_content WHERE skill_id IN ({ph})",
                ids,
            ).fetchall()
            content_map = {cr["skill_id"]: cr["skill_md"] for cr in content_rows}
            for r in results:
                md = content_map.get(r["skill_id"], "")
                if max_chars and len(md) > max_chars:
                    md = md[:max_chars] + "\n\n... [truncated]"
                r["skill_md"] = md

        for r in results:
            r.pop("metadata_yaml", None)
            r.pop("skill_md_excerpt", None)

        return results
    finally:
        conn.close()


def search_skills(
    query: str,
    *,
    top_k: int = 10,
    domain: str = "",
    bundle_name: str = "",
    kind: str = "",
    source_type: str = "",
    min_score: float = 0.0,
    content: bool = False,
    max_chars: int = 0,
) -> list[dict[str, Any]]:
    """Search the skill index and optionally fetch full content.

    Parameters
    ----------
    query : str
        Free-text search string.
    top_k : int
        Maximum results to return.
    domain : str
        Filter by domain (e.g. ``linux``, ``ml``, ``web``).
    kind : str
        Filter by skill_kind (e.g. ``github``, ``arxiv``, ``webpage``).
    source_type : str
        Filter by source_type (e.g. ``github``, ``journal``).
    min_score : float
        Minimum ``overall_score`` threshold.
    content : bool
        If True, join the bundle DB to include ``skill_md`` content.
    max_chars : int
        Truncate ``skill_md`` to this many characters (0 = no limit).

    Returns
    -------
    list[dict]
        Each dict has index metadata fields and optionally ``skill_md``.
    """
    fetch_k = max(top_k * 4, top_k)
    collapse_variants = bundle_name == "claw" and not kind and not source_type

    # Try multi-bundle search first (covers domain bundles + single bundle)
    bundles = _resolve_all_bundles(domain=domain, bundle_name=bundle_name)
    if bundles:
        all_results: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for bp in bundles:
            try:
                partial = _search_single_bundle(
                    bp, query, fetch_k, domain, kind, source_type,
                    min_score, content, max_chars,
                )
            except Exception:
                continue
            for r in partial:
                sid = r.get("skill_id", "")
                if sid not in seen_ids:
                    seen_ids.add(sid)
                    all_results.append(r)
        # Sort by search score first, then overall_score across bundles.
        all_results.sort(
            key=lambda r: (
                float(r.get("_search_score") or 0.0),
                float(r.get("overall_score") or 0.0),
            ),
            reverse=True,
        )
        trimmed = _collapse_variant_results(
            all_results,
            query,
            top_k=top_k,
            enabled=collapse_variants,
        )
        for row in trimmed:
            row.pop("_search_score", None)
        return trimmed

    # Legacy two-file mode
    idx_path = _index_db()
    if not idx_path.exists():
        raise FileNotFoundError(
            f"No bundle found and index database missing: {idx_path}\n"
            "Install bundles with: clawskills bundle-install --auto"
        )

    conn = sqlite3.connect(f"file:{idx_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        # Phase 1: get candidate skill_ids.
        has_fts = _ensure_fts(conn)

        if has_fts:
            fts_ids = _fts_query(conn, query, fetch_k * 8)
        else:
            fts_ids = _like_query(conn, query, fetch_k * 8)
        title_ids = _title_text_query(conn, query, fetch_k * 12)

        content_ids: list[str] = []
        bun_path = _bundle_db()
        if bun_path.exists():
            bconn = sqlite3.connect(f"file:{bun_path}?mode=ro", uri=True)
            try:
                content_ids = _content_query(bconn, query, fetch_k * 12)
            finally:
                bconn.close()

        candidate_ids = _merge_candidate_ids(fts_ids, title_ids, content_ids, limit=fetch_k * 24)

        if not candidate_ids:
            return []

        # Fetch full index rows for candidates.
        placeholders = ",".join("?" for _ in candidate_ids)
        rows = conn.execute(
            f"SELECT * FROM skills_index WHERE skill_id IN ({placeholders})",
            candidate_ids,
        ).fetchall()

        # Apply filters.
        results: list[dict[str, Any]] = []
        for row in rows:
            r = dict(row)
            if domain and (r.get("domain") or "").lower() != domain.lower():
                continue
            if kind and (r.get("skill_kind") or "").lower() != kind.lower():
                continue
            if source_type and (r.get("source_type") or "").lower() != source_type.lower():
                continue
            if min_score and (r.get("overall_score") or 0) < min_score:
                continue
            results.append(r)

        id_order = {sid: i for i, sid in enumerate(candidate_ids)}

    finally:
        conn.close()

    # Phase 2: optionally fetch content.
    bun_path = _bundle_db()
    if results and bun_path.exists():
        bconn = sqlite3.connect(f"file:{bun_path}?mode=ro", uri=True)
        bconn.row_factory = sqlite3.Row
        try:
            ids = [r["skill_id"] for r in results]
            ph = ",".join("?" for _ in ids)
            content_rows = bconn.execute(
                f"""
                SELECT skill_id, metadata_yaml, substr(COALESCE(skill_md, ''), 1, {_SEARCH_BODY_EXCERPT_CHARS}) AS skill_md_excerpt
                FROM skills_content WHERE skill_id IN ({ph})
                """,
                ids,
            ).fetchall()
            content_map = {cr["skill_id"]: dict(cr) for cr in content_rows}
            for r in results:
                payload = content_map.get(r["skill_id"], {})
                r["metadata_yaml"] = payload.get("metadata_yaml", "")
                r["skill_md_excerpt"] = payload.get("skill_md_excerpt", "")
                r["_search_score"] = _search_rank(r, query)
        finally:
            bconn.close()
    else:
        for r in results:
            r["_search_score"] = _search_rank(r, query)

    results.sort(
        key=lambda r: (
            -(float(r.get("_search_score") or 0.0)),
            -(float(r.get("overall_score") or 0.0)),
            id_order.get(r["skill_id"], 9999),
        )
    )
    results = _collapse_variant_results(
        results,
        query,
        top_k=top_k,
        enabled=collapse_variants,
    )

    if content and results:
        if not bun_path.exists():
            raise FileNotFoundError(f"Bundle database not found: {bun_path}")

        bconn = sqlite3.connect(f"file:{bun_path}?mode=ro", uri=True)
        bconn.row_factory = sqlite3.Row
        try:
            ids = [r["skill_id"] for r in results]
            ph = ",".join("?" for _ in ids)
            content_rows = bconn.execute(
                f"SELECT skill_id, skill_md FROM skills_content WHERE skill_id IN ({ph})",
                ids,
            ).fetchall()
            content_map = {cr["skill_id"]: cr["skill_md"] for cr in content_rows}
            for r in results:
                md = content_map.get(r["skill_id"], "")
                if max_chars and len(md) > max_chars:
                    md = md[:max_chars] + "\n\n... [truncated]"
                r["skill_md"] = md
        finally:
            bconn.close()

    for r in results:
        r.pop("metadata_yaml", None)
        r.pop("skill_md_excerpt", None)
        r.pop("_search_score", None)

    return results


# ── listing helpers ──────────────────────────────────────────────

def _list_distinct_values(column: str) -> list[str]:
    """Return sorted unique values from ``skills_index.<column>``.

    *column* must be one of the hard-coded column names passed by the
    public wrappers (``list_domains`` / ``list_kinds``).
    """
    _ALLOWED_COLUMNS = {"domain", "skill_kind"}
    if column not in _ALLOWED_COLUMNS:
        raise ValueError(f"column must be one of {_ALLOWED_COLUMNS}")

    values: set[str] = set()
    bundles = _resolve_all_bundles()
    if bundles:
        for bp in bundles:
            try:
                conn = sqlite3.connect(f"file:{bp}?mode=ro", uri=True)
                rows = conn.execute(
                    f"SELECT DISTINCT {column} FROM skills_index "
                    f"WHERE COALESCE({column}, '') != ''"
                ).fetchall()
                for row in rows:
                    val = str(row[0] or "").strip()
                    if val:
                        values.add(val)
            except Exception:
                continue
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        return sorted(values)

    idx_path = _index_db()
    if not idx_path.exists():
        raise FileNotFoundError(
            f"No bundle found and index database missing: {idx_path}\n"
            "Install bundles with: clawskills bundle-install --auto"
        )

    conn = sqlite3.connect(f"file:{idx_path}?mode=ro", uri=True)
    try:
        rows = conn.execute(
            f"SELECT DISTINCT {column} FROM skills_index "
            f"WHERE COALESCE({column}, '') != ''"
        ).fetchall()
        for row in rows:
            val = str(row[0] or "").strip()
            if val:
                values.add(val)
    finally:
        conn.close()
    return sorted(values)


def list_domains() -> list[str]:
    """Return sorted unique domain values from installed bundles/index."""
    return _list_distinct_values("domain")


def list_kinds() -> list[str]:
    """Return sorted unique skill_kind values from installed bundles/index."""
    return _list_distinct_values("skill_kind")


# ── formatters ───────────────────────────────────────────────────

def _local_skill_md_path(item: dict[str, Any]) -> str:
    """Best-effort local skill.md path from index metadata."""
    raw_dir = str(item.get("dir") or "").strip()
    if raw_dir:
        base = raw_dir.replace("\\", "/").rstrip("/")
    else:
        skill_id = str(item.get("skill_id") or "").strip()
        base = f"skills/by-skill/{skill_id}" if skill_id else ""
    if not base:
        return ""
    return f"{base}/skill.md"


def _shorten_url(url: str) -> str:
    """Shorten a GitHub/ClawHub URL for display."""
    if "github.com" in url:
        parts = url.split("/blob/")
        if len(parts) == 2:
            return parts[0].split("github.com/")[-1]
    if "clawhub.ai" in url and "/registry/" in url:
        return "clawhub:" + url.split("/registry/")[-1].split("/")[0]
    return url[:50]


def format_brief(
    results: list[dict[str, Any]],
    *,
    show_path: bool = False,
    show_variants: bool = False,
) -> str:
    """Rich table output for skill search results."""
    if not results:
        return "No results found."

    from rich.console import Console
    from rich.table import Table

    console = Console(file=__import__("io").StringIO())

    table = Table(
        title="🦞 Search Results",
        show_lines=False,
        padding=(0, 1),
        title_style="bold",
        expand=False,
    )
    table.add_column("#", style="dim", width=3, justify="right")
    table.add_column("Skill", style="bold cyan", no_wrap=True)
    table.add_column("Domain", style="magenta")
    table.add_column("Score", justify="right", style="green")
    table.add_column("Source", style="dim", no_wrap=True, overflow="ellipsis")

    for i, r in enumerate(results, 1):
        score = r.get("overall_score") or 0
        domain = r.get("domain") or "-"
        title = r.get("title") or "(untitled)"
        source_url = str(r.get("source_url") or "").strip()
        variant_count = int(r.get("variant_count") or 0)
        if variant_count:
            title = f"{title} (+{variant_count})"

        table.add_row(
            str(i),
            title,
            domain,
            f"{score:.1f}",
            _shorten_url(source_url) if source_url else "",
        )

        if show_path:
            path = _local_skill_md_path(r)
            if path:
                table.add_row("", "", "", "", f"path: {path}", "")

        if show_variants:
            for variant in r.get("variant_examples") or []:
                v_title = str(variant.get("title") or "").strip()
                v_url = str(variant.get("source_url") or "").strip()
                table.add_row("", f"  ↳ {v_title}", "", "", "", _shorten_url(v_url) if v_url else "")

    console.print(table)
    return console.file.getvalue()


def format_markdown(
    results: list[dict[str, Any]],
    *,
    show_path: bool = False,
    show_variants: bool = False,
) -> str:
    """Full Markdown output suitable for agent consumption."""
    if not results:
        return "No results found."
    parts = []
    for i, r in enumerate(results, 1):
        score = r.get("overall_score") or 0
        title = r.get("title") or "(untitled)"
        domain = r.get("domain") or "-"
        kind = r.get("skill_kind") or "-"
        source_type = r.get("source_type") or "-"
        skill_id = r.get("skill_id") or ""

        hdr = f"## {i}. {title}\n"
        meta = (
            f"- **Score:** {score:.1f}\n"
            f"- **Domain:** {domain}\n"
            f"- **Kind:** {kind}\n"
            f"- **Source type:** {source_type}\n"
            f"- **Skill ID:** `{skill_id[:12]}...`\n"
        )
        variant_count = int(r.get("variant_count") or 0)
        if variant_count:
            meta += f"- **Collapsed variants:** {variant_count}\n"
            variant_titles = [str(v.get("title") or "").strip() for v in (r.get("variant_examples") or [])]
            variant_titles = [v for v in variant_titles if v]
            if variant_titles:
                meta += f"- **Variant titles:** {', '.join(variant_titles[:5])}\n"
        if show_path:
            path = _local_skill_md_path(r)
            if path:
                meta += f"- **Path:** `{path}`\n"
        if show_variants:
            variant_lines = []
            for variant in r.get("variant_examples") or []:
                variant_title = str(variant.get("title") or "").strip() or "(untitled)"
                variant_url = str(variant.get("source_url") or "").strip()
                if variant_url:
                    variant_lines.append(f"- {variant_title} — {variant_url}")
                else:
                    variant_lines.append(f"- {variant_title}")
            if variant_lines:
                meta += "\n### Variants\n\n" + "\n".join(variant_lines) + "\n"
        body = ""
        if "skill_md" in r and r["skill_md"]:
            body = f"\n### Content\n\n{r['skill_md']}\n"

        parts.append(hdr + meta + body)
    return "\n---\n\n".join(parts)


def format_json(results: list[dict[str, Any]]) -> str:
    """JSON output."""
    # Drop heavy item_json field for cleaner output.
    cleaned = []
    for r in results:
        out = {k: v for k, v in r.items() if k != "item_json"}
        cleaned.append(out)
    return json.dumps(cleaned, indent=2, ensure_ascii=False)


# ── CLI ──────────────────────────────────────────────────────────

def cli_skill_search(argv: list[str] | None = None) -> int:
    """CLI entry point for ``clawskills skill-search``."""
    import argparse

    p = argparse.ArgumentParser(
        prog="clawskills skill-search",
        description="Search the ClawSkills skill library",
    )
    p.add_argument("query", nargs="?", default="", help="Free-text search query")
    p.add_argument("--top", type=int, default=10, help="Max results (default: 10)")
    p.add_argument("--domains", action="store_true", help="List available domains and exit")
    p.add_argument("--bundles", action="store_true", help="List installed bundle names and exit")
    p.add_argument("--kinds", action="store_true", help="List available skill kinds and exit")
    p.add_argument("--show-path", action="store_true", help="Show local skill.md paths in results")
    p.add_argument("--show-variants", action="store_true", help="Expand collapsed claw variant matches in text output")
    p.add_argument("--bundle-name", default="", help="Restrict search to a named installed bundle (e.g. claw)")
    p.add_argument("--domain", default="", help="Filter by domain (linux, ml, web, ...)")
    p.add_argument("--kind", default="", help="Filter by skill_kind (github, arxiv, ...)")
    p.add_argument("--source-type", default="", help="Filter by source_type (github, journal, ...)")
    p.add_argument("--min-score", type=float, default=0.0, help="Minimum overall_score")
    p.add_argument("--content", action="store_true", help="Include full skill.md content (joins bundle DB)")
    p.add_argument("--max-chars", type=int, default=4000, help="Truncate skill content (0=unlimited, default: 4000)")
    p.add_argument(
        "--format",
        choices=["brief", "markdown", "json"],
        default="brief",
        help="Output format (default: brief)",
    )
    p.add_argument("--brief", action="store_true", help="Shorthand for --format brief")

    args = p.parse_args(argv)

    fmt = "brief" if args.brief else args.format

    if args.domains:
        try:
            domains = list_domains()
        except FileNotFoundError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        print("\n".join(domains) if domains else "No domains found.")
        return 0

    if args.bundles:
        bundles = list_bundle_names()
        print("\n".join(bundles) if bundles else "No bundles found.")
        return 0

    if args.kinds:
        try:
            kinds = list_kinds()
        except FileNotFoundError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        print("\n".join(kinds) if kinds else "No kinds found.")
        return 0

    if not str(args.query or "").strip():
        p.error("query is required unless --domains, --bundles or --kinds is set")

    # Brief format always fetches content for description excerpts
    fetch_content = args.content or fmt == "brief"
    try:
        results = search_skills(
            args.query,
            top_k=args.top,
            domain=args.domain,
            bundle_name=args.bundle_name,
            kind=args.kind,
            source_type=args.source_type,
            min_score=args.min_score,
            content=fetch_content,
            max_chars=args.max_chars if args.content else 300,
        )
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    if fmt == "brief":
        print(format_brief(results, show_path=bool(args.show_path), show_variants=bool(args.show_variants)))
    elif fmt == "markdown":
        print(format_markdown(results, show_path=bool(args.show_path), show_variants=bool(args.show_variants)))
    else:
        print(format_json(results))

    return 0


if __name__ == "__main__":
    raise SystemExit(cli_skill_search())
