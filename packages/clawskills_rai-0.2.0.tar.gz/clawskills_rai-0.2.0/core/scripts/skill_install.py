"""Install a skill from the ClawSkills bundle directly into your agent's skill directory.

One command: search → pick best → write SKILL.md → ready to use.

Usage:
    clawskills install docker-essentials
    clawskills install "react hooks" --target .cursor/skills
    clawskills install coding-agent --list  # preview without installing
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any


def _detect_skill_dir() -> Path:
    """Auto-detect the best skill directory for the current environment."""
    cwd = Path.cwd()

    # Check for known agent directories in order of preference
    candidates = [
        cwd / ".claude" / "skills",
        cwd / ".cursor" / "skills",
        cwd / ".openclaw" / "skills",
        cwd / ".agents",
        cwd / ".codex",
    ]

    for d in candidates:
        if d.exists():
            return d

    # Default: .claude/skills (most common)
    return cwd / ".claude" / "skills"


def _slugify(text: str) -> str:
    """Convert a skill title to a filesystem-safe directory name."""
    s = text.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:60] or "skill"


def _rebuild_skill_md(title: str, body_md: str, meta: dict[str, Any]) -> str:
    """Reconstruct a complete SKILL.md with YAML frontmatter."""
    lines = ["---"]
    lines.append(f"name: {title}")

    description = str(meta.get("description") or "").strip()
    if description:
        lines.append(f"description: {description}")

    tags = meta.get("tags")
    if isinstance(tags, list) and tags:
        tag_str = ", ".join(str(t) for t in tags[:10])
        lines.append(f"tags: [{tag_str}]")

    claw_version = str(meta.get("claw_version") or meta.get("version") or "").strip()
    if claw_version and claw_version != "0.0.0":
        lines.append(f"version: {claw_version}")

    claw_author = str(meta.get("claw_author") or meta.get("author") or "").strip()
    if claw_author:
        lines.append(f"author: {claw_author}")

    source_url = str(meta.get("source_url") or "").strip()
    if source_url:
        lines.append(f'metadata: {{"source": "{source_url}"}}')

    lines.append("---")
    lines.append("")

    # If body already starts with frontmatter, strip it
    body = body_md.strip()
    if body.startswith("---"):
        # Find end of frontmatter
        end = body.find("---", 3)
        if end > 0:
            body = body[end + 3:].strip()

    lines.append(body)
    return "\n".join(lines) + "\n"


def cli_skill_install(argv: list[str] | None = None) -> int:
    """CLI entry point for ``clawskills install``."""
    p = argparse.ArgumentParser(
        prog="clawskills install",
        description="Install a skill from the ClawSkills bundle into your agent's skill directory",
    )
    p.add_argument("query", help="Skill name or search query")
    p.add_argument(
        "--target", default="",
        help="Target skill directory (default: auto-detect .claude/skills, .cursor/skills, etc.)",
    )
    p.add_argument(
        "--bundle-name", default="claw",
        help="Bundle to search (default: claw)",
    )
    p.add_argument(
        "--list", action="store_true", dest="list_only",
        help="List matching skills without installing",
    )
    p.add_argument(
        "--top", type=int, default=5,
        help="Number of candidates to show (default: 5)",
    )
    p.add_argument(
        "--pick", type=int, default=1,
        help="Install the Nth result (default: 1 = best match)",
    )
    p.add_argument(
        "--force", action="store_true",
        help="Overwrite if skill directory already exists",
    )

    args = p.parse_args(argv)

    from ..search import search_skills

    # Search
    try:
        results = search_skills(
            args.query,
            top_k=args.top,
            bundle_name=args.bundle_name,
            content=True,
            max_chars=0,
        )
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        print("Run 'clawskills bundle-install --domain claw' first.", file=sys.stderr)
        return 1

    if not results:
        print(f"No skills found for '{args.query}'.", file=sys.stderr)
        return 1

    # List mode
    if args.list_only:
        from rich.console import Console
        from rich.table import Table
        from rich.text import Text

        console = Console()
        table = Table(
            title=f"🦞 Skills matching \"{args.query}\"",
            show_lines=False,
            padding=(0, 1),
            title_style="bold",
        )
        table.add_column("#", style="dim", width=3, justify="right")
        table.add_column("Skill", style="bold cyan", no_wrap=True)
        table.add_column("Domain", style="magenta")
        table.add_column("Score", justify="right", style="green")
        table.add_column("Size", justify="right", style="dim")
        table.add_column("Source", style="dim", max_width=50, overflow="ellipsis")

        for i, r in enumerate(results, 1):
            title = r.get("title") or "(untitled)"
            domain = r.get("domain") or "-"
            score = r.get("overall_score") or 0
            body_len = len(r.get("skill_md") or "")
            source_url = str(r.get("source_url") or "")
            # Shorten URL
            short_url = source_url
            if "github.com" in short_url:
                parts = short_url.split("/blob/")
                if len(parts) == 2:
                    short_url = parts[0].split("github.com/")[-1]
            elif "clawhub.ai" in short_url:
                short_url = "clawhub:" + short_url.split("/registry/")[-1].split("/")[0] if "/registry/" in short_url else short_url

            size_str = f"{body_len // 1024}K" if body_len >= 1024 else f"{body_len}B"
            table.add_row(str(i), title, domain, f"{score:.1f}", size_str, short_url)

        console.print(table)
        console.print()
        console.print(f"  Install: [bold]clawskills install \"{args.query}\" --pick N[/bold]")
        return 0

    # Pick result
    pick_idx = max(1, min(len(results), args.pick)) - 1
    skill = results[pick_idx]
    title = str(skill.get("title") or "skill").strip()
    body_md = str(skill.get("skill_md") or "").strip()
    source_url = str(skill.get("source_url") or "").strip()

    if not body_md:
        print(f"Error: skill '{title}' has no content.", file=sys.stderr)
        return 1

    # Determine target directory
    if args.target:
        skill_dir = Path(args.target) / _slugify(title)
    else:
        base = _detect_skill_dir()
        skill_dir = base / _slugify(title)

    # Check existing
    skill_file = skill_dir / "SKILL.md"
    if skill_file.exists() and not args.force:
        print(f"Already exists: {skill_file}", file=sys.stderr)
        print("Use --force to overwrite.", file=sys.stderr)
        return 1

    # Build SKILL.md with frontmatter
    # Parse metadata from metadata_yaml if available
    meta: dict[str, Any] = {}
    meta_yaml = str(skill.get("metadata_yaml") or "").strip()
    if meta_yaml:
        try:
            import yaml
            meta = yaml.safe_load(meta_yaml) or {}
        except Exception:
            pass
    meta["source_url"] = source_url
    meta["description"] = str(skill.get("description") or meta.get("description") or "").strip()

    skill_md_content = _rebuild_skill_md(title, body_md, meta)

    # Write
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file.write_text(skill_md_content, encoding="utf-8")

    # Print result
    rel_path = skill_file
    try:
        rel_path = skill_file.relative_to(Path.cwd())
    except ValueError:
        pass

    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text

    console = Console()
    body_k = len(body_md) // 1024

    lines = Text()
    lines.append("→ ", style="dim")
    lines.append(str(rel_path), style="bold")
    lines.append(f"\n  {body_k}K chars", style="dim")
    lines.append(f" · {skill.get('domain', '-')}", style="magenta")
    if source_url:
        lines.append(f"\n  {source_url}", style="dim")
    lines.append("\n\n  Your agent will pick it up automatically.", style="green")

    console.print(Panel(
        lines,
        title=f"[bold green]✓ Installed: {title}[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))
    return 0
