from __future__ import annotations

import asyncio
import concurrent.futures as concurrent
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any

from core.env import load_dotenv
from core.env import load_master_config
from core.llm.factory import create_llm_from_env

try:
    from core.scripts.validate_skills.core import validate_skills
except ImportError:  # pragma: no cover
    validate_skills = None

from core.skills.generate import generate_one_skill
from core.skills.publish import publish_run_to_skills_library
from core.sources.artifacts import write_source_artifact
from core.sources.journals.engine import CrawlConfig, CrawlStats, crawl_journals
from core.sources.journals.normalize import paper_primary_url, paper_to_extracted_text, paper_to_raw_json
from core.sources.types import SourceInput
from core.utils.fs import ensure_dir, make_run_dir, write_json_atomic
from core.utils.paths import repo_root as _repo_root
from core.utils.time import utc_now_iso_z

from .cli_args import parse_journal_pipeline_args
from .skill_template import JournalSkillOutput, write_journal_skill


_PAPER_SKILL_KINDS = [
    "paper.idea_intro",
    "paper.experiment",
    "paper.picture",
    "paper.method",
]


def _truncate(text: str, max_len: int) -> str:
    value = str(text or "")
    if max_len <= 0 or len(value) <= max_len:
        return value
    return value[: max(0, max_len - 1)] + "..."


def _infer_journal_license(*, paper: Any) -> tuple[str, str]:
    family = str(getattr(paper, "journal_family", "") or "").strip().lower()
    is_oa = bool(getattr(paper, "is_open_access", True))
    if family == "plos" and is_oa:
        return ("CC-BY-4.0", "low")
    return ("", "unknown")


def _paper_extra(paper: Any) -> dict[str, Any]:
    raw = paper_to_raw_json(paper)
    sections_in = raw.get("fulltext_sections") if isinstance(raw.get("fulltext_sections"), dict) else {}
    sections_out = {
        key: _truncate(str(sections_in.get(key) or "").strip(), 1800)
        for key in ("introduction", "methods", "results", "discussion")
        if str(sections_in.get(key) or "").strip()
    }
    return {
        **raw,
        "figures": list(raw.get("figures") or [])[:50],
        "data_sources": list(raw.get("data_sources") or [])[:50],
        "fulltext_sections": sections_out,
    }


def _selected_families(ns: Any) -> list[str]:
    families = list(getattr(ns, "families", None) or [])
    return families or ["Nature", "Science", "Cell", "PLOS", "eLife", "PMC", "Other"]


def _run_topic(ns: Any) -> str:
    families = _selected_families(ns)
    label = "-".join(str(name).lower() for name in families[:3]) or "journals"
    if len(families) > 3:
        label += "-more"
    return f"journals-{label}"


def _write_manifest(
    *,
    run_dir: Path,
    ns: Any,
    stats: CrawlStats,
    total_sources: int,
    artifacts_written: int,
    skills_written: int,
    published: dict[str, int] | None,
    warnings: list[str],
    sources: list[dict[str, Any]],
) -> dict[str, Any]:
    payload = {
        "schema_version": 1,
        "pipeline": "journal",
        "run_id": run_dir.name,
        "created_at": utc_now_iso_z(),
        "profile": str(getattr(ns, "profile", "") or ""),
        "skill_kind": str(getattr(ns, "skill_kind", "") or "journal_figure_data_mining"),
        "families": _selected_families(ns),
        "config": {
            "max_papers": int(getattr(ns, "max_papers", 0) or 0),
            "concurrency": int(getattr(ns, "concurrency", 0) or 0),
            "download_concurrency": int(getattr(ns, "download_concurrency", 0) or 0),
            "delay": float(getattr(ns, "delay", 0.0) or 0.0),
            "no_download": bool(getattr(ns, "no_download", False)),
            "year_from": int(getattr(ns, "year_from", 0) or 0),
            "year_to": int(getattr(ns, "year_to", 0) or 0),
            "llm_skills": bool(getattr(ns, "llm_skills", False)),
            "llm_only": bool(getattr(ns, "llm_only", False)),
            "llm_skill_kinds": _llm_skill_kinds(ns) if bool(getattr(ns, "llm_skills", False)) else [],
            "publish": bool(getattr(ns, "publish", False) or getattr(ns, "publish_overwrite", False)),
            "dry_run": bool(getattr(ns, "dry_run", False)),
        },
        "stats": asdict(stats),
        "total_sources": int(total_sources),
        "artifacts_written": int(artifacts_written),
        "skills_written": int(skills_written),
        "published": dict(published or {}),
        "warnings": list(warnings),
        "sources": list(sources),
    }
    write_json_atomic(run_dir / "manifest.json", payload)
    return payload


def _build_config(ns: Any, run_dir: Path) -> CrawlConfig:
    repo_cfg = load_master_config(Path(_repo_root()).resolve()) or {}
    journal_api_cfg = repo_cfg.get("journal_api") if isinstance(repo_cfg.get("journal_api"), dict) else {}
    springer_from_cfg = str(journal_api_cfg.get("springer_api_key") or journal_api_cfg.get("springer_key") or "").strip()
    ncbi_from_cfg = str(journal_api_cfg.get("ncbi_api_key") or journal_api_cfg.get("ncbi_key") or "").strip()
    springer_key = str(getattr(ns, "springer_key", "") or "").strip() or springer_from_cfg or str(os.environ.get("SPRINGER_API_KEY") or "").strip()
    ncbi_key = str(getattr(ns, "ncbi_key", "") or "").strip() or ncbi_from_cfg or str(os.environ.get("NCBI_API_KEY") or "").strip()

    config = CrawlConfig(
        output_dir=run_dir.as_posix(),
        max_papers=int(getattr(ns, "max_papers", 10000) or 10000),
        families=list(getattr(ns, "families", None) or []) or None,
        max_concurrent_requests=int(getattr(ns, "concurrency", 20) or 20),
        max_concurrent_downloads=int(getattr(ns, "download_concurrency", 30) or 30),
        per_domain_delay=float(getattr(ns, "delay", 0.5) or 0.5),
    )
    # The crawler reads these as ad-hoc config attributes.
    config.download_figures = not bool(getattr(ns, "no_download", False))  # type: ignore[attr-defined]
    config.year_from = int(getattr(ns, "year_from", 2020) or 2020)  # type: ignore[attr-defined]
    config.year_to = int(getattr(ns, "year_to", 2026) or 2026)  # type: ignore[attr-defined]
    config.springer_key = springer_key  # type: ignore[attr-defined]
    config.springer_api_key = config.springer_key  # type: ignore[attr-defined]
    config.ncbi_key = ncbi_key  # type: ignore[attr-defined]
    config.ncbi_api_key = config.ncbi_key  # type: ignore[attr-defined]
    return config


def _llm_skill_kinds(ns: Any) -> list[str]:
    limit = max(1, min(int(getattr(ns, "max_skills_per_paper", 3) or 3), len(_PAPER_SKILL_KINDS)))
    return list(_PAPER_SKILL_KINDS[:limit])


def cli_journal_pipeline(argv: list[str] | None = None) -> int:
    ns = parse_journal_pipeline_args(argv)
    if bool(ns.llm_only) and not bool(ns.llm_skills):
        print("ERROR: --llm-only requires --llm-skills.")
        return 2

    repo_root = Path(_repo_root()).resolve()
    load_dotenv(repo_root)

    run_dir = make_run_dir(repo_root, _run_topic(ns))
    ensure_dir(run_dir)
    ensure_dir(run_dir / "sources")

    warnings: list[str] = []
    if bool(ns.llm_skills):
        warnings.append(
            "LLM journal skill generation is enabled; paper.* skills will be emitted in addition to the deterministic baseline."
        )

    empty_stats = CrawlStats(start_time=utc_now_iso_z(), end_time=utc_now_iso_z())
    if bool(ns.dry_run):
        _write_manifest(
            run_dir=run_dir,
            ns=ns,
            stats=empty_stats,
            total_sources=0,
            artifacts_written=0,
            skills_written=0,
            published=None,
            warnings=warnings,
            sources=[],
        )
        print(f"Dry-run only. Manifest written to {run_dir}/manifest.json sources=0")
        return 0

    config = _build_config(ns, run_dir)
    outputs: list[JournalSkillOutput] = []
    llm_outputs: list[dict[str, Any]] = []
    source_rows: list[dict[str, Any]] = []
    artifacts_written = 0
    llm_jobs: list[dict[str, Any]] = []

    async def _on_paper(paper: Any) -> None:
        nonlocal artifacts_written

        primary_url = str(paper_primary_url(paper) or "").strip()
        title = str(getattr(paper, "title", "") or "").strip()
        raw_obj = paper_to_raw_json(paper)
        extracted_text = paper_to_extracted_text(paper)
        license_spdx, license_risk = _infer_journal_license(paper=paper)

        artifact = write_source_artifact(
            run_dir=run_dir,
            source_type="journal",
            url=primary_url,
            title=title,
            raw_text=json.dumps(raw_obj, ensure_ascii=False, indent=2),
            extracted_text=extracted_text,
            license_spdx=license_spdx,
            license_risk=license_risk,
            extra=_paper_extra(paper),
        )
        artifacts_written += 1

        row = {
            "source_id": artifact.source_id,
            "source_type": "journal",
            "url": primary_url,
            "title": title,
            "journal_family": str(getattr(paper, "journal_family", "") or "").strip(),
            "doi": str(getattr(paper, "doi", "") or "").strip(),
            "skill_rel_dir": "",
            "skill_id": "",
            "skill_ids": [],
            "skill_rel_dirs": [],
        }

        if not bool(ns.llm_only):
            out = write_journal_skill(
                run_dir=run_dir,
                domain=str(ns.profile or "research"),
                seq=len(outputs) + 1,
                base_slug=title or str(getattr(paper, "doi", "") or ""),
                paper_title=title,
                source_url=primary_url,
                source_fetched_at=artifact.fetched_at,
                source_artifact_id=artifact.source_id,
                doi=str(getattr(paper, "doi", "") or "").strip(),
                journal=str(getattr(paper, "journal", "") or "").strip(),
                journal_family=str(getattr(paper, "journal_family", "") or "").strip(),
                pub_date=str(getattr(paper, "pub_date", "") or "").strip(),
                skill_kind=str(ns.skill_kind or "journal_figure_data_mining"),
                license_spdx=license_spdx,
                license_risk=license_risk,
                language="en",
            )
            outputs.append(out)
            row["skill_rel_dir"] = out.rel_dir
            row["skill_id"] = out.skill_id
            row["skill_ids"] = [out.skill_id]
            row["skill_rel_dirs"] = [out.rel_dir]

        source_rows.append(row)
        llm_jobs.append(
            {
                "row": row,
                "source": SourceInput(
                    source_type="journal",
                    url=artifact.url,
                    title=artifact.title,
                    text=extracted_text,
                    fetched_at=artifact.fetched_at,
                    extra={
                        "source_artifact_id": artifact.source_id,
                        "source_refs": [
                            {
                                "source_id": artifact.source_id,
                                "source_type": "journal",
                                "source_url": artifact.url,
                            }
                        ],
                        "license_spdx": artifact.license_spdx,
                        "license_risk": artifact.license_risk,
                        "tags": [
                            str(getattr(paper, "journal_family", "") or "").strip().lower(),
                            "journal",
                        ],
                    },
                ),
                "base_slug": title or str(getattr(paper, "doi", "") or ""),
            }
        )

    stats = asyncio.run(crawl_journals(config=config, on_paper=_on_paper))

    if bool(ns.llm_skills) and llm_jobs:
        llm = create_llm_from_env(provider_override=getattr(ns, "provider", None))
        kinds = _llm_skill_kinds(ns)
        tasks: list[tuple[dict[str, Any], str, int]] = []
        seq = len(outputs) + 1
        for job in llm_jobs:
            for kind in kinds:
                tasks.append((job, kind, seq))
                seq += 1

        def _run_one(job: dict[str, Any], kind: str, seq_no: int) -> dict[str, Any]:
            source = job["source"]
            source_extra = dict(source.extra or {})
            source_extra["skill_kind"] = kind
            result = generate_one_skill(
                run_dir=run_dir,
                domain=str(ns.profile or "research"),
                method="journal",
                seq=seq_no,
                base_slug=job["base_slug"],
                source=SourceInput(
                    source_type=source.source_type,
                    url=source.url,
                    title=source.title,
                    text=source.text,
                    fetched_at=source.fetched_at,
                    extra=source_extra,
                ),
                llm=llm,
            )
            return {"row": job["row"], "kind": kind, "result": result}

        max_workers = max(1, min(int(getattr(ns, "llm_concurrency", 4) or 4), len(tasks)))
        with concurrent.ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(_run_one, job, kind, seq_no) for job, kind, seq_no in tasks]
            for future in concurrent.as_completed(futures):
                try:
                    payload = future.result()
                except Exception as exc:
                    warnings.append(f"journal llm skill generation failed: {exc}")
                    continue
                row = payload["row"]
                result = payload["result"]
                llm_outputs.append(result)
                skill_id = str(result.get("id") or "").strip()
                rel_dir = str(result.get("rel_dir") or "").strip()
                if skill_id:
                    row["skill_ids"] = list(row.get("skill_ids") or []) + [skill_id]
                if rel_dir:
                    row["skill_rel_dirs"] = list(row.get("skill_rel_dirs") or []) + [rel_dir]

    total_skills_written = len(outputs) + len(llm_outputs)

    write_json_atomic(
        run_dir / "journal_results.json",
        {
            "created_at": utc_now_iso_z(),
            "stats": asdict(stats),
            "sources": source_rows,
            "skills": [
                {
                    "skill_id": out.skill_id,
                    "title": out.title,
                    "rel_dir": out.rel_dir,
                    "source_url": out.source_url,
                    "doi": out.doi,
                }
                for out in outputs
            ]
            + [
                {
                    "skill_id": str(out.get("id") or ""),
                    "title": str(out.get("title") or ""),
                    "rel_dir": str(out.get("rel_dir") or ""),
                    "source_url": str(out.get("source_url") or ""),
                    "doi": "",
                }
                for out in llm_outputs
            ],
        },
    )

    errors: list[str] = []
    validation_warnings: list[str] = []
    if total_skills_written and validate_skills is not None:
        errors, validation_warnings = validate_skills(
            repo_root=repo_root,
            root=run_dir / "skills",
            strict=True,
            check_package=False,
        )
        for warning in validation_warnings:
            print(f"WARN: {warning}")
        for error in errors:
            print(f"FAIL: {error}")

    publish_summary: dict[str, int] | None = None
    if total_skills_written and bool(ns.publish or ns.publish_overwrite):
        old_allow = os.environ.get("CLAWSKILLS_PUBLISH_ALLOW_NEEDS_REVIEW")
        try:
            if bool(ns.publish_allow_needs_review):
                os.environ["CLAWSKILLS_PUBLISH_ALLOW_NEEDS_REVIEW"] = "1"
            publish_summary = publish_run_to_skills_library(
                repo_root=repo_root,
                run_dir=run_dir,
                overwrite=bool(ns.publish_overwrite),
            )
        finally:
            if old_allow is None:
                os.environ.pop("CLAWSKILLS_PUBLISH_ALLOW_NEEDS_REVIEW", None)
            else:
                os.environ["CLAWSKILLS_PUBLISH_ALLOW_NEEDS_REVIEW"] = old_allow

    all_warnings = warnings + validation_warnings
    _write_manifest(
        run_dir=run_dir,
        ns=ns,
        stats=stats,
        total_sources=len(source_rows),
        artifacts_written=artifacts_written,
        skills_written=total_skills_written,
        published=publish_summary,
        warnings=all_warnings,
        sources=source_rows,
    )

    print(
        f"Run dir: {run_dir.as_posix()} "
        f"papers={stats.total_papers} artifacts={artifacts_written} skills={total_skills_written} errors={len(errors)}"
    )
    return 1 if errors else 0


__all__ = ["cli_journal_pipeline"]
