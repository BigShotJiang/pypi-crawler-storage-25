"""Journal pipeline entrypoints."""

from __future__ import annotations


def cli_journal_pipeline(*args, **kwargs):
    """Lazy import to avoid requiring aiohttp at CLI startup."""
    from .cli import cli_journal_pipeline as _impl
    return _impl(*args, **kwargs)


__all__ = ["cli_journal_pipeline"]
