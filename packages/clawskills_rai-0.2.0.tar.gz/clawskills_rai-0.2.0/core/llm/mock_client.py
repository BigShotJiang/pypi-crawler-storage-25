"""Deterministic local mock LLM for offline tests and smoke runs."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from .base import BaseJsonClient, RequestSpec


def _load_json_block(raw: str) -> dict[str, Any]:
    try:
        obj = json.loads(str(raw or ""))
    except Exception:
        return {}
    return obj if isinstance(obj, dict) else {}


def _markdown_title(source_title: str, skill_id: str) -> str:
    base = str(source_title or "").strip() or str(skill_id or "").strip() or "Mock Skill"
    return re.sub(r"\s+", " ", base).strip()


def _skill_markdown(*, title: str, source_url: str, skill_kind: str) -> str:
    if skill_kind == "paper_writing":
        return "\n".join(
            [
                f"# {title}",
                "",
                "## Audience",
                "- Researchers preparing a concise paper summary.",
                "",
                "## Key Contributions",
                "- Extract the main contribution from the source text.",
                "- Preserve claims that can be traced back to the provided excerpt.",
                "",
                "## Method Overview",
                "- Summarize the method at a high level before writing.",
                "",
                "## Experiments",
                "- List datasets, metrics, and baselines mentioned in the excerpt.",
                "",
                "## Limitations",
                "- Mark missing details as not provided.",
                "",
                "## Writing Outline",
                "```bash",
                "cat <<'EOF' > article_outline.md",
                "# Draft Outline",
                "- Introduction",
                "- Method",
                "- Experiments",
                "- Limitations",
                "EOF",
                "```",
                "",
                "## Steps",
                "1. Read the extracted text and list the paper's main claims.",
                "2. Map each claim to the paper section where it appears.",
                "3. Draft the article outline with contribution and limitation bullets.",
                "4. Review the outline for unsupported statements.",
                "",
                "## Verification",
                "```bash",
                "test -f article_outline.md && echo \"outline ready\"",
                "```",
                "",
                "## Safety",
                "- Do not invent experimental details that are not in the source.",
                "",
                "## Evidence",
                "- mock-provider: true",
                "",
                "## Sources",
                f"- {source_url or 'https://example.invalid/mock'}",
                "",
            ]
        )
    if skill_kind == "experiment_design":
        return "\n".join(
            [
                f"# {title}",
                "",
                "## Audience",
                "- Engineers or researchers reproducing the paper.",
                "",
                "## Claims and Metrics",
                "| Claim | Metric | Dataset | Baseline |",
                "| --- | --- | --- | --- |",
                "| Main claim | not provided | not provided | not provided |",
                "",
                "## Datasets and Baselines",
                "- Record datasets and baselines from the source excerpt.",
                "",
                "## Experiment Plan",
                "- Start with a small reproduction before full runs.",
                "",
                "## Risks and Observability",
                "- Capture run metadata and evaluation logs.",
                "",
                "## Steps",
                "1. Extract explicit metrics and baselines from the source.",
                "2. Write a minimal reproduction plan.",
                "3. Add full-run and ablation checkpoints.",
                "",
                "## Verification",
                "```bash",
                "cat <<'EOF' > experiment_plan.md",
                "# Experiment Plan",
                "- metric: not provided",
                "EOF",
                "echo \"experiment plan ready\"",
                "```",
                "",
                "## Safety",
                "- Validate compute cost before launching large experiments.",
                "",
                "## Evidence",
                "- mock-provider: true",
                "",
                "## Sources",
                f"- {source_url or 'https://example.invalid/mock'}",
                "",
            ]
        )
    if skill_kind == "paper_writeup":
        return "\n".join(
            [
                f"# {title}",
                "",
                "## Audience",
                "- Readers who need a short technical write-up.",
                "",
                "## Topic",
                "- Summarize the paper topic in one line.",
                "",
                "## Introduction",
                "- Turn the motivation into a short intro paragraph.",
                "",
                "## Method Innovation Summary",
                "- Highlight what is new compared with prior work.",
                "",
                "## Experiment Design and Analysis",
                "- Note datasets, metrics, and the evaluation plan.",
                "",
                "## Method Paragraph",
                "- Draft a method paragraph based on the source excerpt.",
                "",
                "## Figure Caption",
                "- Option 1: concise caption.",
                "",
                "## Steps",
                "1. Extract the core problem statement.",
                "2. Rewrite the method and experiments in plain language.",
                "3. Draft one figure caption and one method paragraph.",
                "",
                "## Verification",
                "```bash",
                "cat <<'EOF' > paper_writeup.md",
                "# Paper Write-up",
                "- draft ready",
                "EOF",
                "echo \"paper writeup ready\"",
                "```",
                "",
                "## Safety",
                "- Preserve attribution to the original paper.",
                "",
                "## Evidence",
                "- mock-provider: true",
                "",
                "## Sources",
                f"- {source_url or 'https://example.invalid/mock'}",
                "",
            ]
        )
    return "\n".join(
        [
            f"# {title}",
            "",
            "## Background",
            "- Mock provider generated this skill without network access.",
            "",
            "## Use Cases",
            "- Offline smoke test for skill generation.",
            "",
            "## Inputs",
            "- Extracted text from the selected source artifact.",
            "",
            "## Outputs",
            "- A deterministic markdown skill and package files.",
            "",
            "## Steps",
            "1. Read the extracted text and list the key facts.",
            "2. Turn those facts into a concise skill outline.",
            "3. Run the verification block to confirm the file shape.",
            "",
            "## Verification",
            "```bash",
            "echo \"mock skill verified\"",
            "```",
            "",
            "## Safety",
            "- Treat this output as a deterministic test fixture, not expert advice.",
            "",
            "## Evidence",
            "- mock-provider: true",
            "",
            "## Sources",
            f"- {source_url or 'https://example.invalid/mock'}",
            "",
        ]
    )


def _normalize_skill_kind(raw: str) -> str:
    value = str(raw or "").strip().lower()
    return {
        "paper.idea_intro": "paper_writing",
        "paper.experiment": "experiment_design",
        "paper.picture": "paper_writeup",
        "paper.method": "paper_writeup",
    }.get(value, value)


def _package_response(meta: dict[str, Any]) -> dict[str, Any]:
    source_url = str(meta.get("source_url") or "").strip() or "https://example.invalid/mock"
    generated_at = str(meta.get("package_generated_at") or "").strip()
    date_part = generated_at[:10] if re.match(r"^\d{4}-\d{2}-\d{2}", generated_at) else "YYYY-MM-DD"
    accessed_at = str(meta.get("source_fetched_at") or generated_at or "").strip()
    return {
        "library_md": "# Library\n\n```bash\necho \"mock package\"\n```\n",
        "reference": {
            "sources_md": f"# Sources\n\n- {source_url}\n\nAccessed at: {accessed_at}\n",
            "troubleshooting_md": "# Troubleshooting\n\n- If validation fails, inspect the generated markdown sections.\n",
            "edge_cases_md": "# Edge Cases\n\n- Replace placeholder text before publication.\n",
            "examples_md": "# Examples\n\n```bash\necho \"example\"\n```\n",
            "changelog_md": f"# Changelog\n\n- **{date_part}**: initial package generation.\n",
        },
    }


@dataclass(frozen=True)
class MockLlmClient(BaseJsonClient):
    model: str = "mock-json"
    default_timeout_ms: int = 1_000

    @property
    def provider(self) -> str:
        return "mock"

    def _local_response(
        self,
        *,
        messages: list[Any],
        temperature: float,
        timeout_ms: int,
    ) -> dict[str, Any] | None:
        msg_dicts = self._normalize_messages(messages)
        system = str(msg_dicts[0].get("content") or "") if msg_dicts else ""
        user = str(msg_dicts[-1].get("content") or "") if msg_dicts else ""
        payload = _load_json_block(user)

        allowed_domains = payload.get("allowed_domains") if isinstance(payload.get("allowed_domains"), list) else None
        if allowed_domains:
            allowed = [str(x or "").strip() for x in allowed_domains if str(x or "").strip()]
            return {"domain": allowed[0] if allowed else "linux"}

        meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
        extra = payload.get("extra_context") if isinstance(payload.get("extra_context"), dict) else {}
        if str(meta.get("task") or "").strip() == "package_v2":
            return _package_response(meta)

        if meta or "Output ONLY a JSON object with keys: title, skill_md, review." in system:
            source_title = _markdown_title(str(meta.get("source_title") or ""), str(meta.get("skill_id") or ""))
            source_url = str(meta.get("source_url") or "").strip()
            skill_kind = _normalize_skill_kind(str(extra.get("skill_kind") or "").strip())
            return {
                "title": source_title,
                "skill_md": _skill_markdown(title=source_title, source_url=source_url, skill_kind=skill_kind),
                "review": {
                    "overall_score": 4,
                    "issues": [],
                    "suggestions": [
                        "Replace placeholder bullets with source-specific details before publication.",
                        "Re-run with a real provider for production-quality prose.",
                    ],
                },
            }

        return {"ok": True}

    def _request_candidates(self, *, messages: list[dict[str, str]], temperature: float) -> list[RequestSpec]:
        return []

    def _extract_content(self, response_obj: dict[str, Any]) -> str:
        return json.dumps(response_obj, ensure_ascii=False)


MockLLM = MockLlmClient


def create_mock_llm(**kwargs: Any) -> MockLlmClient:
    return MockLlmClient(**kwargs)
