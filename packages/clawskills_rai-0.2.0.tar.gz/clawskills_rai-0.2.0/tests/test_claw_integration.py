from __future__ import annotations

import hashlib
import json
from pathlib import Path

from core.cli import main
from core.detect_project import detect_domains
from core.scripts import bundle_install
from core.sources.claw import aggregate_claw_skills
from core.sources.claw.awesome_parser import _AWESOME_LISTS, _crawl_single_awesome_list


def test_detect_domains_includes_claw(tmp_path: Path):
    (tmp_path / ".openclaw" / "skills" / "demo").mkdir(parents=True)
    assert "claw" in detect_domains(tmp_path)


def test_bundle_install_claw_uses_local_bundle(monkeypatch, tmp_path: Path):
    src = tmp_path / "clawskills-bundle-lite-claw-v20260402.sqlite"
    src.write_bytes(b"demo claw bundle")
    digest = hashlib.sha256(src.read_bytes()).hexdigest()
    src.with_suffix(src.suffix + ".sha256").write_text(
        f"{digest}  {src.name}\n",
        encoding="utf-8",
    )

    install_dir = tmp_path / ".clawskills"
    config_path = install_dir / "search_config.json"
    monkeypatch.setattr(bundle_install, "_INSTALL_DIR", install_dir)
    monkeypatch.setattr(bundle_install, "_CONFIG_PATH", config_path)
    monkeypatch.setattr(bundle_install, "_find_local_claw_bundle", lambda bundle_type="lite": src)

    assert bundle_install.install_bundle(domain="claw") == 0

    dest = install_dir / src.name
    assert dest.exists()
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    assert cfg["bundles"]["claw"] == str(dest)


def test_main_dispatches_claw_aggregate(monkeypatch):
    from core.sources import claw as claw_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_main(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(claw_mod, "cli_main", fake_cli_main)

    assert main(["claw-aggregate", "--max-skills", "42", "--sources", "clawhub,archive", "--stats-only"]) == 0
    assert calls["argv"] == ["--max-skills", "42", "--sources", "clawhub,archive", "--stats-only"]


def test_main_skill_search_forwards_bundle_name(monkeypatch):
    from core import search as search_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_skill_search(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(search_mod, "cli_skill_search", fake_cli_skill_search)

    assert main(["skill-search", "calendar", "--bundle-name", "claw", "--format", "json"]) == 0
    assert calls["argv"] == ["calendar", "--top", "10", "--bundle-name", "claw", "--max-chars", "4000", "--format", "json"]


def test_main_skill_search_forwards_show_variants(monkeypatch):
    from core import search as search_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_skill_search(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(search_mod, "cli_skill_search", fake_cli_skill_search)

    assert main(["skill-search", "skill creator", "--bundle-name", "claw", "--show-variants"]) == 0
    assert calls["argv"] == [
        "skill creator",
        "--top",
        "10",
        "--show-variants",
        "--bundle-name",
        "claw",
        "--max-chars",
        "4000",
        "--format",
        "brief",
    ]


def test_aggregate_defaults_include_archive(monkeypatch):
    calls: list[str] = []

    monkeypatch.setattr("core.sources.claw.clawhub.crawl_clawhub", lambda max_skills, emit=None: [])
    monkeypatch.setattr("core.sources.claw.openclaw_archive.crawl_openclaw_archive", lambda max_skills, emit=None: calls.append("archive") or [])
    monkeypatch.setattr("core.sources.claw.github_skills.crawl_github_skills", lambda max_skills, emit=None: [])
    monkeypatch.setattr("core.sources.claw.awesome_parser.crawl_awesome_lists", lambda max_skills, emit=None: [])

    aggregate_claw_skills(max_skills=10)
    assert calls == ["archive"]


def test_awesome_registry_includes_usecases_and_zh():
    names = {item["name"] for item in _AWESOME_LISTS}
    assert "awesome-openclaw-usecases" in names
    assert "awesome-openclaw-skills-zh" in names
    assert "awesome-openclaw-usecases-zh" in names


def test_agent_template_list_expands_soul_files(monkeypatch):
    tree_payload = {
        "tree": [
            {"type": "blob", "path": "agents/productivity/orion/SOUL.md"},
            {"type": "blob", "path": "agents/development/code-reviewer/SOUL.md"},
            {"type": "blob", "path": "README.md"},
        ],
    }
    soul_docs = {
        "https://raw.githubusercontent.com/mergisi/awesome-openclaw-agents/HEAD/agents/productivity/orion/SOUL.md": (
            "# Orion - The Coordinator\n\n"
            "You are Orion, an AI coordinator and project manager powered by OpenClaw.\n"
        ),
        "https://raw.githubusercontent.com/mergisi/awesome-openclaw-agents/HEAD/agents/development/code-reviewer/SOUL.md": (
            "# Lens - The Code Reviewer\n\n"
            "You are Lens, an AI code reviewer powered by OpenClaw.\n"
        ),
    }

    def fake_http_get(url: str, *, headers=None):
        if url.endswith("/git/trees/HEAD?recursive=1"):
            return json.dumps(tree_payload)
        return soul_docs.get(url)

    monkeypatch.setattr("core.sources.claw.awesome_parser.http_get", fake_http_get)
    monkeypatch.setattr("core.sources.claw.awesome_parser.http_get_with_rate_retry", fake_http_get)

    skills = _crawl_single_awesome_list(
        {
            "name": "awesome-openclaw-agents",
            "owner": "mergisi",
            "repo": "awesome-openclaw-agents",
            "record_kind": "agent-template",
            "source_type": "claw-awesome-agent",
        },
        max_skills=10,
        seen_slugs=set(),
    )

    assert sorted(skill.name for skill in skills) == [
        "Lens - The Code Reviewer",
        "Orion - The Coordinator",
    ]
    assert {skill.source_type for skill in skills} == {"claw-awesome-agent"}
    assert {skill.metadata["record_kind"] for skill in skills} == {"agent-template"}
    assert {skill.metadata["agent_category"] for skill in skills} == {"development", "productivity"}
