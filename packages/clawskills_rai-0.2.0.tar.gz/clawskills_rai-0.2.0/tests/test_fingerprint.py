"""Tests for fingerprint immutability and dedupe."""
from __future__ import annotations

from core.utils.fingerprint import build_fingerprint
from core.postprocess.dedupe import overlap_ratio_by_fingerprint


class TestFingerprint:
    def test_returns_tuple_hashes(self):
        fp = build_fingerprint("hello world this is a test of the fingerprint system with enough text")
        assert isinstance(fp.hashes, tuple)

    def test_frozen_immutable(self):
        fp = build_fingerprint("some long text for fingerprinting purposes that should generate hashes")
        import pytest
        with pytest.raises(AttributeError):
            fp.hashes = ("new",)  # type: ignore

    def test_to_dict_returns_list(self):
        fp = build_fingerprint("enough text here to generate at least one shingle for fingerprint building")
        d = fp.to_dict()
        assert isinstance(d["hashes"], list)

    def test_deterministic(self):
        text = "deterministic fingerprint test with sufficient length for shingle generation"
        assert build_fingerprint(text).hashes == build_fingerprint(text).hashes


class TestJaccardSimilarity:
    def test_identical_sets(self):
        fp = {"hashes": ["a", "b", "c"]}
        assert overlap_ratio_by_fingerprint(fp, fp) == 1.0

    def test_disjoint_sets(self):
        a = {"hashes": ["a", "b"]}
        b = {"hashes": ["c", "d"]}
        assert overlap_ratio_by_fingerprint(a, b) == 0.0

    def test_partial_overlap(self):
        a = {"hashes": ["a", "b", "c"]}
        b = {"hashes": ["b", "c", "d"]}
        # intersection=2, union=4 => 0.5
        assert abs(overlap_ratio_by_fingerprint(a, b) - 0.5) < 0.01

    def test_subset_not_1_0(self):
        """Jaccard of a subset should NOT be 1.0 (unlike the old min-based metric)."""
        small = {"hashes": ["a", "b"]}
        big = {"hashes": ["a", "b", "c", "d", "e"]}
        ratio = overlap_ratio_by_fingerprint(small, big)
        # intersection=2, union=5 => 0.4
        assert ratio < 1.0
        assert abs(ratio - 0.4) < 0.01

    def test_empty_hashes(self):
        assert overlap_ratio_by_fingerprint({"hashes": []}, {"hashes": ["a"]}) == 0.0
        assert overlap_ratio_by_fingerprint(None, {"hashes": ["a"]}) == 0.0
