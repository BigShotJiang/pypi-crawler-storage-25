from __future__ import annotations

import asyncio

from core.sources.journals.engine.config import CrawlConfig
from core.sources.journals.engine.discovery import ArticleDiscovery
class _FakeClient:
    def __init__(self, payloads: list[dict]):
        self.payloads = list(payloads)
        self.urls: list[str] = []

    async def get_json(self, url: str):
        self.urls.append(url)
        if not self.payloads:
            return {}
        return self.payloads.pop(0)
def test_article_discovery_plos_returns_papers():
    client = _FakeClient(
        [
            {
                "response": {
                    "numFound": 1,
                    "docs": [
                        {
                            "id": "10.1371/journal.pone.0000001",
                            "title_display": "Example PLOS Paper",
                            "abstract": ["Example abstract"],
                            "author_display": ["Alice", "Bob"],
                            "journal": "PLOS One",
                            "publication_date": "2026-04-02T00:00:00Z",
                            "figure_table_caption": ["Caption one"],
                        }
                    ],
                }
            }
        ]
    )
    discovery = ArticleDiscovery(client, CrawlConfig())
    papers = asyncio.run(discovery.discover_plos_articles("plosone", 1))
    assert len(papers) == 1
    assert papers[0].doi == "10.1371/journal.pone.0000001"
    assert papers[0].journal_family == "PLOS"
def test_article_discovery_elife_returns_papers():
    client = _FakeClient(
        [
            {
                "total": 1,
                "items": [
                    {
                        "id": "109465",
                        "doi": "10.7554/eLife.109465",
                        "title": "eLife Example",
                        "published": "2026-04-02T00:00:00Z",
                        "authors": [{"name": {"preferred": "A. Author"}}],
                    }
                ],
            }
        ]
    )
    discovery = ArticleDiscovery(client, CrawlConfig())
    papers = asyncio.run(discovery.discover_elife_articles(1))
    assert len(papers) == 1
    assert papers[0].doi == "10.7554/eLife.109465"
    assert papers[0].journal_family == "eLife"
def test_article_discovery_pmc_returns_stub_records():
    client = _FakeClient(
        [
            {
                "esearchresult": {
                    "count": "2",
                    "idlist": ["13042999", "13043000"],
                }
            }
        ]
    )
    discovery = ArticleDiscovery(client, CrawlConfig())
    papers = asyncio.run(discovery.discover_pmc_articles(journal_name="Science", max_results=2))
    assert len(papers) == 2
    assert papers[0].pmc_id == "PMC13042999"
    assert papers[0].journal == "Science"
    assert papers[0].journal_family == "PMC"
