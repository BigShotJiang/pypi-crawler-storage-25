from __future__ import annotations

import json
from pathlib import Path

from core.scripts import repo_export


def _make_fake_repo(tmp_path: Path, monkeypatch) -> Path:
    repo_root = tmp_path / "repo"
    (repo_root / "core" / "scripts").mkdir(parents=True)
    (repo_root / "captures" / "run1").mkdir(parents=True)
    (repo_root / "docs").mkdir(parents=True)
    (repo_root / "captures" / "run1" / "note.md").write_text("capture text", encoding="utf-8")
    (repo_root / "docs" / "plan.md").write_text("docs text", encoding="utf-8")
    monkeypatch.setattr(repo_export, "__file__", str(repo_root / "core" / "scripts" / "repo_export.py"))
    return repo_root


def test_cli_repo_export_writes_bundle(tmp_path: Path, monkeypatch):
    repo_root = _make_fake_repo(tmp_path, monkeypatch)
    out_root = repo_root / "exports"

    rc = repo_export.cli_repo_export(["--out", str(out_root)])

    assert rc == 0
    bundles = sorted(out_root.glob("repo_export_*"))
    assert len(bundles) == 1
    manifest = bundles[0] / "export_manifest.json"
    assert manifest.exists()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert data["summary"]["files_copied"] >= 2
    assert (bundles[0] / "captures" / "run1" / "note.md").exists()
    assert (bundles[0] / "docs" / "plan.md").exists()


def test_cli_repo_export_rejects_output_inside_captures(tmp_path: Path, monkeypatch, capsys):
    repo_root = _make_fake_repo(tmp_path, monkeypatch)
    out_root = repo_root / "captures" / "nested-export"

    rc = repo_export.cli_repo_export(["--out", str(out_root)])

    captured = capsys.readouterr()
    assert rc == 2
    assert "--out must not be inside source tree" in captured.err
    assert not list(out_root.glob("repo_export_*"))
