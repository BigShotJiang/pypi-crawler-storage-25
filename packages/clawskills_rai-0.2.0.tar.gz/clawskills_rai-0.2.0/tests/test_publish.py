"""Tests for skill publishing."""
from __future__ import annotations

import json
from pathlib import Path

from core.skills.publish import publish_run_to_skills_library


def _write_license_policy(root: Path) -> None:
    config_dir = root / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    policy = {
        "env": {},
        "license_policy": {
            "defaults": {"unknown": "needs_review"},
            "by_source_type": {
                "webpage": {
                    "allow_spdx": ["MIT", "Apache-2.0"],
                    "deny_spdx": ["GPL-3.0"],
                    "unknown": "allow",
                }
            },
        },
    }
    (config_dir / "clawskills.json").write_text(json.dumps(policy), encoding="utf-8")


def test_publish_returns_error_when_no_license_policy(tmp_path):
    """publish should return error key when no license policy is configured."""
    run_dir = tmp_path / "captures" / "run-test"
    skills_dir = run_dir / "skills" / "test" / "topic" / "slug"
    skills_dir.mkdir(parents=True)
    (skills_dir / "skill.md").write_text("# Test Skill\n\nContent here.", encoding="utf-8")
    (skills_dir / "metadata.yaml").write_text("title: Test\noverall_score: 5\n", encoding="utf-8")

    result = publish_run_to_skills_library(repo_root=tmp_path, run_dir=run_dir)
    assert result.get("error") == "missing_license_policy"
    assert result["published"] == 0


def test_publish_succeeds_with_valid_policy(tmp_path, monkeypatch):
    """publish should succeed when license policy, metadata, and source artifact are all present."""
    monkeypatch.setenv("CLAWSKILLS_CONFIG", str(tmp_path / "config" / "clawskills.json"))
    _write_license_policy(tmp_path)

    run_dir = tmp_path / "captures" / "run-test"
    source_url = "https://example.com/article"

    # Create source artifact
    from core.utils.hashing import sha256_hex
    source_id = sha256_hex(source_url)
    sources_dir = run_dir / "sources"
    sources_dir.mkdir(parents=True)
    source_artifact = {
        "source_id": source_id,
        "source_type": "webpage",
        "source_url": source_url,
        "url": source_url,
        "title": "Test Article",
        "fetched_at": "2026-04-03T00:00:00Z",
        "license_spdx": "MIT",
        "extracted_text": "Some text content.",
    }
    (sources_dir / f"{source_id}.json").write_text(json.dumps(source_artifact), encoding="utf-8")

    # Create skill
    skills_dir = run_dir / "skills" / "linux" / "web" / "g-0001-test"
    skills_dir.mkdir(parents=True)
    (skills_dir / "skill.md").write_text("# Test Skill\n\n## Background\nContent\n\n## Steps\n1. Do thing\n\n## Verification\n```bash\necho ok\n```\n", encoding="utf-8")
    meta_yaml = f"title: Test Skill\noverall_score: 5.0\nsource_type: webpage\nsource_url: {source_url}\nsource_artifact_id: {source_id}\nlicense_spdx: MIT\n"
    (skills_dir / "metadata.yaml").write_text(meta_yaml, encoding="utf-8")

    result = publish_run_to_skills_library(repo_root=tmp_path, run_dir=run_dir)
    assert result.get("error") is None
    assert result["published"] >= 1
