from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from core.skills.generate import generate_one_skill
from core.sources.types import SourceInput


class _DummyLlm:
    provider = "openai"
    model = "dummy-model"

    def chat_json(self, *, messages, temperature=0.2, timeout_ms=None, max_tokens=None, **extra):
        return {
            "title": "Minimal Paper Skill",
            "skill_md": (
                "# Minimal Paper Skill\n\n"
                "This is a compact paper summary that is intentionally missing the validation sections "
                "so post-processing has to add them.\n"
            ),
            "review": {"overall_score": 4, "issues": [], "suggestions": []},
        }


def test_generate_one_skill_backfills_validation_sections(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(
        "core.skills.generate.build_skill_package_v2_with_llm",
        lambda **kwargs: SimpleNamespace(
            library_md="# Library\n",
            reference={
                "sources_md": "Source: https://doi.org/10.1000/demo\n",
                "troubleshooting_md": "# Troubleshooting\n",
                "edge_cases_md": "# Edge Cases\n",
                "examples_md": "# Examples\n",
                "changelog_md": "# Changelog\n",
            },
        ),
    )
    monkeypatch.setenv("CLAWSKILLS_SAVE_LLM_ARTIFACTS", "0")

    out = generate_one_skill(
        run_dir=tmp_path,
        domain="research",
        method="journal",
        seq=1,
        base_slug="minimal-paper",
        source=SourceInput(
            source_type="journal",
            url="https://doi.org/10.1000/demo",
            title="Minimal Paper",
            text="Introduction. Methods. Results. Discussion.",
            fetched_at="2026-04-03T00:00:00Z",
            extra={
                "skill_kind": "paper.idea_intro",
                "source_artifact_id": "artifact-1",
                "source_refs": [
                    {
                        "source_id": "artifact-1",
                        "source_type": "journal",
                        "source_url": "https://doi.org/10.1000/demo",
                    }
                ],
                "license_spdx": "",
                "license_risk": "unknown",
                "tags": ["journal", "nature"],
            },
        ),
        llm=_DummyLlm(),
    )

    skill_path = tmp_path / out["rel_dir"] / "skill.md"
    skill_md = skill_path.read_text(encoding="utf-8")
    assert "## Steps" in skill_md
    assert "1. Review the paper title, abstract, and extracted sections referenced in Evidence." in skill_md
    assert "## Safety" in skill_md
    assert "## Verification" in skill_md
    assert "test -n \"$PWD\"" in skill_md
    assert "printf \"verification: ok\\n\"" in skill_md
    assert "Missing '## Steps' section" not in out["lint_issues"]
    assert "Missing '## Safety' section" not in out["lint_issues"]
