"""Tests for claw SKILL.md converter/parser."""
from __future__ import annotations

from core.sources.claw.converter import parse_skill_md, infer_domain, ClawSkill


class TestParseSkillMd:
    def test_basic_frontmatter(self):
        text = """---
name: my-skill
description: A test skill
version: 1.0.0
tags: [python, testing]
---

# My Skill

Some content here.
"""
        skill = parse_skill_md(text, source_url="https://example.com/SKILL.md")
        assert skill.name == "my-skill"
        assert skill.description == "A test skill"
        assert skill.version == "1.0.0"
        assert "python" in skill.tags
        assert "testing" in skill.tags
        assert "Some content here." in skill.body_md

    def test_block_list_tags(self):
        text = """---
name: block-tags
tags:
  - react
  - typescript
  - web
---

Body text.
"""
        skill = parse_skill_md(text)
        assert skill.tags == ["react", "typescript", "web"]

    def test_nested_requires(self):
        text = """---
name: nested-req
requires:
  bins: [python3, node]
  python: ">=3.10"
---

Body.
"""
        skill = parse_skill_md(text)
        assert "python3" in skill.requires_bins
        assert "node" in skill.requires_bins
        assert skill.requires_python == ">=3.10"

    def test_metadata_dict(self):
        text = """---
name: with-meta
metadata:
  source: https://github.com/example/repo
  license: MIT
---

Content.
"""
        skill = parse_skill_md(text)
        assert skill.metadata.get("source") == "https://github.com/example/repo"
        assert skill.license_spdx == "MIT"

    def test_no_frontmatter(self):
        text = "# Just a regular markdown file\n\nNo frontmatter here."
        skill = parse_skill_md(text)
        assert skill.name == ""
        assert skill.body_md == text.strip()

    def test_empty_input(self):
        skill = parse_skill_md("")
        assert skill.name == ""
        assert skill.body_md == ""

    def test_missing_name(self):
        text = """---
description: No name field
---

Body.
"""
        skill = parse_skill_md(text)
        assert skill.name == ""
        assert skill.description == "No name field"

    def test_source_url_from_arg(self):
        text = """---
name: test
---
Body.
"""
        skill = parse_skill_md(text, source_url="https://github.com/foo/bar")
        assert skill.source_url == "https://github.com/foo/bar"

    def test_source_url_from_metadata(self):
        text = """---
name: test
metadata:
  source: https://github.com/from-meta
---
Body.
"""
        skill = parse_skill_md(text)
        assert skill.source_url == "https://github.com/from-meta"


class TestInferDomain:
    def test_web_tags(self):
        skill = ClawSkill(name="react-helper", tags=["react", "frontend"])
        assert infer_domain(skill) == "web"

    def test_linux_tags(self):
        skill = ClawSkill(name="bash-utils", tags=["bash", "linux"])
        assert infer_domain(skill) == "linux"

    def test_llm_tags(self):
        skill = ClawSkill(name="prompt-eng", tags=["llm", "prompt"])
        assert infer_domain(skill) == "llm"

    def test_fallback_from_name(self):
        skill = ClawSkill(name="kubernetes-deploy", tags=[])
        assert infer_domain(skill) == "cloud"

    def test_unknown_domain(self):
        skill = ClawSkill(name="some-random-tool", tags=["misc"])
        assert infer_domain(skill) == "other"


class TestSkillId:
    def test_deterministic(self):
        s1 = ClawSkill(name="test", source_url="https://example.com")
        s2 = ClawSkill(name="test", source_url="https://example.com")
        assert s1.skill_id == s2.skill_id

    def test_different_urls(self):
        s1 = ClawSkill(name="test", source_url="https://a.com")
        s2 = ClawSkill(name="test", source_url="https://b.com")
        assert s1.skill_id != s2.skill_id

    def test_format(self):
        s = ClawSkill(name="My Skill", source_url="https://example.com")
        assert s.skill_id.startswith("claw/my-skill/")
