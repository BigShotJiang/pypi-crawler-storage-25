from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.cli import main
from core.llm.factory import create_llm_from_env
from core.scripts.journal_pipeline import cli as journal_cli
from core.scripts.journal_pipeline.cli_args import parse_journal_pipeline_args
from core.sources.journals.engine import CrawlStats
from core.sources.journals.models import DataSource, FigureInfo, PaperRecord
def test_journal_pipeline_dry_run_writes_manifest(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir(parents=True)

    async def fail_crawl(*, config, on_paper):
        raise AssertionError("dry-run should not call crawl_journals")

    monkeypatch.setattr(journal_cli, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(journal_cli, "load_dotenv", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(journal_cli, "crawl_journals", fail_crawl)

    rc = journal_cli.cli_journal_pipeline(["--dry-run"])

    assert rc == 0
    manifests = sorted((repo_root / "captures").glob("run-*/manifest.json"))
    assert len(manifests) == 1
    manifest = json.loads(manifests[0].read_text(encoding="utf-8"))
    assert manifest["pipeline"] == "journal"
    assert manifest["total_sources"] == 0
    assert manifest["artifacts_written"] == 0
    assert manifest["skills_written"] == 0
def test_journal_pipeline_writes_artifacts_and_skills(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir(parents=True)

    paper = PaperRecord(
        doi="10.1000/demo",
        title="Open Data Figure Mining",
        journal="PLOS ONE",
        journal_family="PLOS",
        abstract="A paper about figures and datasets.",
        pub_date="2026-04-01",
        url="https://example.com/paper",
        is_open_access=True,
        figures=[
            FigureInfo(
                figure_id="fig1",
                caption="Example figure caption.",
                full_size_url="https://example.com/fig1.png",
                thumbnail_url="https://example.com/thumb1.png",
            )
        ],
        data_sources=[DataSource(repository="Zenodo", accession="zenodo.1234", url="https://zenodo.org/record/1234")],
        fulltext_sections={"methods": "Method details."},
    )

    async def fake_crawl(*, config, on_paper):
        await on_paper(paper)
        return CrawlStats(
            total_papers=1,
            total_figures=1,
            total_data_sources=1,
            by_family={"PLOS": 1},
            errors=0,
            skipped=0,
            start_time="2026-04-03T00:00:00Z",
            end_time="2026-04-03T00:00:01Z",
        )

    monkeypatch.setattr(journal_cli, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(journal_cli, "load_dotenv", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(journal_cli, "crawl_journals", fake_crawl)

    rc = journal_cli.cli_journal_pipeline(["--families", "PLOS", "--max-papers", "1", "--no-download"])

    assert rc == 0
    run_dirs = sorted((repo_root / "captures").glob("run-*"))
    assert len(run_dirs) == 1
    run_dir = run_dirs[0]

    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["total_sources"] == 1
    assert manifest["artifacts_written"] == 1
    assert manifest["skills_written"] == 1
    assert manifest["stats"]["total_papers"] == 1
    assert manifest["sources"][0]["doi"] == "10.1000/demo"

    result = json.loads((run_dir / "journal_results.json").read_text(encoding="utf-8"))
    assert result["stats"]["total_papers"] == 1
    assert len(result["skills"]) == 1

    source_files = sorted((run_dir / "sources").glob("*.json"))
    assert source_files

    skill_md_files = sorted((run_dir / "skills").glob("**/skill.md"))
    assert len(skill_md_files) == 1
    skill_md = skill_md_files[0].read_text(encoding="utf-8")
    assert "## Verification" in skill_md
    assert "## Evidence" in skill_md
def test_journal_pipeline_llm_skills_only_generates_paper_variants(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir(parents=True)

    paper = PaperRecord(
        doi="10.1000/demo-llm",
        title="LLM Figure Mining",
        journal="Nature",
        journal_family="Nature",
        abstract="A paper for LLM skill generation.",
        pub_date="2026-04-01",
        url="https://example.com/llm-paper",
        is_open_access=True,
    )

    async def fake_crawl(*, config, on_paper):
        await on_paper(paper)
        return CrawlStats(total_papers=1, by_family={"Nature": 1})

    class DummyLlm:
        provider = "openai"
        model = "dummy-model"

    generated_kinds: list[str] = []

    def fake_generate_one_skill(*, run_dir, domain, method, seq, base_slug, source, llm):
        generated_kinds.append(str(source.extra.get("skill_kind") or ""))
        skill_dir = Path(run_dir) / "skills" / domain / method / f"llm-{seq}"
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "metadata.yaml").write_text(
            "skill_id: demo\n"
            f"title: {source.extra.get('skill_kind')}\n"
            f"source_url: {source.url}\n",
            encoding="utf-8",
        )
        (skill_dir / "skill.md").write_text("# Demo\n\n## Verification\n\n```bash\necho ok\n```\n", encoding="utf-8")
        return {
            "id": f"{method}-{seq}",
            "title": f"LLM {source.extra.get('skill_kind')}",
            "rel_dir": skill_dir.relative_to(Path(run_dir)).as_posix(),
            "source_url": source.url,
        }

    monkeypatch.setattr(journal_cli, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(journal_cli, "load_dotenv", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(journal_cli, "crawl_journals", fake_crawl)
    monkeypatch.setattr(journal_cli, "create_llm_from_env", lambda provider_override=None: DummyLlm())
    monkeypatch.setattr(journal_cli, "generate_one_skill", fake_generate_one_skill)
    monkeypatch.setattr(journal_cli, "validate_skills", lambda **kwargs: ([], []))

    rc = journal_cli.cli_journal_pipeline(
        ["--families", "Nature", "--max-papers", "1", "--no-download", "--llm-skills", "--llm-only", "--max-skills-per-paper", "2"]
    )

    assert rc == 0
    assert generated_kinds == ["paper.idea_intro", "paper.experiment"]
    run_dir = sorted((repo_root / "captures").glob("run-*"))[0]
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["skills_written"] == 2
    assert manifest["artifacts_written"] == 1
    result = json.loads((run_dir / "journal_results.json").read_text(encoding="utf-8"))
    assert len(result["skills"]) == 2
def test_journal_pipeline_build_config_reads_journal_api_from_master_config(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    (repo_root / "config").mkdir(parents=True)
    (repo_root / "config" / "clawskills.json").write_text(
        json.dumps(
            {
                "journal_api": {
                    "springer_api_key": "springer-from-config",
                    "ncbi_api_key": "ncbi-from-config",
                }
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(journal_cli, "_repo_root", lambda: repo_root)
    ns = parse_journal_pipeline_args(["--families", "PLOS", "--max-papers", "1"])
    cfg = journal_cli._build_config(ns, repo_root / "captures" / "run-test")
    assert getattr(cfg, "springer_key", "") == "springer-from-config"
    assert getattr(cfg, "springer_api_key", "") == "springer-from-config"
    assert getattr(cfg, "ncbi_key", "") == "ncbi-from-config"
    assert getattr(cfg, "ncbi_api_key", "") == "ncbi-from-config"
def test_main_journal_pipeline_help_shows_real_options(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["journal-pipeline", "--help"])

    assert exc.value.code == 0
    out = capsys.readouterr().out
    assert "--max-papers" in out
    assert "--llm-skills" in out
    assert "--provider" in out
def test_create_llm_from_env_supports_mock_without_openai_env(monkeypatch):
    monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    llm = create_llm_from_env(provider_override="mock")
    out = llm.chat_json(
        messages=[
            {"role": "system", "content": "You are a router that classifies a user topic into a single domain. Output ONLY a JSON object with key 'domain'."},
            {"role": "user", "content": json.dumps({"topic": "linux shell", "allowed_domains": ["linux", "web"]})},
        ]
    )
    assert llm.provider == "mock"
    assert out["domain"] == "linux"
def test_journal_pipeline_mock_provider_runs_without_openai_env(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir(parents=True)

    paper = PaperRecord(
        doi="10.1000/mock-provider",
        title="Mock Provider Paper",
        journal="PLOS ONE",
        journal_family="PLOS",
        abstract="A paper for offline mock provider validation.",
        pub_date="2026-04-03",
        url="https://example.com/mock-provider",
        is_open_access=True,
    )

    async def fake_crawl(*, config, on_paper):
        await on_paper(paper)
        return CrawlStats(total_papers=1, by_family={"PLOS": 1})

    monkeypatch.setattr(journal_cli, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(journal_cli, "load_dotenv", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(journal_cli, "crawl_journals", fake_crawl)
    monkeypatch.setattr(journal_cli, "validate_skills", lambda **kwargs: ([], []))
    monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
    monkeypatch.delenv("OPENAI_API_BASE", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    rc = journal_cli.cli_journal_pipeline(
        [
            "--families",
            "PLOS",
            "--max-papers",
            "1",
            "--no-download",
            "--llm-skills",
            "--llm-only",
            "--provider",
            "mock",
            "--max-skills-per-paper",
            "2",
        ]
    )

    assert rc == 0
    run_dir = sorted((repo_root / "captures").glob("run-*"))[0]
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["skills_written"] == 2
    assert manifest["artifacts_written"] == 1
    result = json.loads((run_dir / "journal_results.json").read_text(encoding="utf-8"))
    assert len(result["skills"]) == 2
