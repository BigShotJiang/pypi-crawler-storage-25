from __future__ import annotations

import sqlite3
from pathlib import Path

from core.cli import main
from core.search import search_skills
from core.sources.claw.repo_registry import ClawRepo, ClawRepoFile, aggregate_claw_repos, build_claw_repo_bundle, sync_repo_state
from core.sources.claw.repo_state import ClawRepoStateStore


def test_aggregate_claw_repos_hydrates_and_classifies(monkeypatch):
    monkeypatch.setattr(
        "core.sources.claw.repo_registry._discover_candidates",
        lambda **kwargs: {
            "openclaw/skills": {
                "full_name": "openclaw/skills",
                "sources": ["org:openclaw", "topic:openclaw-skill"],
            },
            "mergisi/awesome-openclaw-agents": {
                "full_name": "mergisi/awesome-openclaw-agents",
                "sources": ["awesome:awesome-openclaw-agents"],
            },
        },
    )

    def fake_repo_metadata(full_name: str):
        if full_name == "openclaw/skills":
            return {
                "id": 1,
                "html_url": "https://github.com/openclaw/skills",
                "name": "skills",
                "owner": {"login": "openclaw"},
                "description": "Official archived skills",
                "homepage": "",
                "topics": ["openclaw", "skills"],
                "language": "Markdown",
                "stargazers_count": 100,
                "forks_count": 5,
                "open_issues_count": 1,
                "license": {"spdx_id": "MIT"},
                "archived": False,
                "fork": False,
                "default_branch": "main",
                "updated_at": "2026-04-02T00:00:00Z",
                "pushed_at": "2026-04-02T00:00:00Z",
            }
        return {
            "id": 2,
            "html_url": "https://github.com/mergisi/awesome-openclaw-agents",
            "name": "awesome-openclaw-agents",
            "owner": {"login": "mergisi"},
            "description": "AI agent templates",
            "homepage": "",
            "topics": ["openclaw", "agents"],
            "language": "Markdown",
            "stargazers_count": 50,
            "forks_count": 2,
            "open_issues_count": 0,
            "license": {"spdx_id": "MIT"},
            "archived": False,
            "fork": False,
            "default_branch": "main",
            "updated_at": "2026-04-02T00:00:00Z",
            "pushed_at": "2026-04-02T00:00:00Z",
        }

    monkeypatch.setattr("core.sources.claw.repo_registry._fetch_repo_metadata", fake_repo_metadata)
    monkeypatch.setattr(
        "core.sources.claw.repo_registry._fetch_repo_tree_data",
        lambda full_name, default_branch: (
            {
                "tree_sha": "tree-soul",
                "paths": ["agents/productivity/orion/SOUL.md"],
                "tracked_files": [
                    ClawRepoFile(
                        path="agents/productivity/orion/SOUL.md",
                        blob_sha="blob-soul",
                        file_kind="soul_md",
                        source_url="https://github.com/mergisi/awesome-openclaw-agents/blob/HEAD/agents/productivity/orion/SOUL.md",
                    )
                ],
            }
            if full_name == "mergisi/awesome-openclaw-agents"
            else {
                "tree_sha": "tree-skill",
                "paths": ["skills/demo/SKILL.md"],
                "tracked_files": [
                    ClawRepoFile(
                        path="skills/demo/SKILL.md",
                        blob_sha="blob-skill",
                        file_kind="skill_md",
                        source_url="https://github.com/openclaw/skills/blob/HEAD/skills/demo/SKILL.md",
                    )
                ],
            }
        ),
    )
    monkeypatch.setattr(
        "core.sources.claw.repo_registry._fetch_readme_excerpt",
        lambda full_name: f"README for {full_name}",
    )

    repos = aggregate_claw_repos(max_repos=10)

    assert [repo.repo_full_name for repo in repos] == [
        "openclaw/skills",
        "mergisi/awesome-openclaw-agents",
    ]
    assert repos[0].repo_kind == "archive"
    assert repos[0].has_skill_md is True
    assert repos[0].tree_sha == "tree-skill"
    assert repos[1].repo_kind == "agent-templates"
    assert repos[1].has_soul_md is True
    assert repos[1].tracked_files[0].file_kind == "soul_md"
    assert repos[1].priority_score > 0


def test_build_claw_repo_bundle_writes_repo_metadata(tmp_path: Path):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-repos-v20260402.sqlite"
    build_claw_repo_bundle(
        [
            ClawRepo(
                repo_full_name="openclaw/openclaw",
                repo_url="https://github.com/openclaw/openclaw",
                repo_owner="openclaw",
                repo_name="openclaw",
                description="Personal AI assistant",
                topics=["openclaw", "assistant"],
                stars=123,
                repo_kind="tooling",
                crawl_sources=["org:openclaw"],
                skill_file_count=12,
                soul_file_count=3,
                has_openclaw_skills_dir=True,
                priority_score=42.5,
                last_seen_at="2026-04-02T00:00:00Z",
            ),
        ],
        bundle_path,
        version="20260402",
    )

    conn = sqlite3.connect(bundle_path)
    try:
        row = conn.execute(
            "SELECT skill_kind, source_type, title, overall_score FROM skills_index"
        ).fetchone()
        assert row[0] == "claw-repo"
        assert row[1] == "claw-repo"
        assert row[2] == "openclaw/openclaw — Personal AI assistant [skills:12 agents:3]"
        assert row[3] > 40.0  # score includes content-based bonuses
        meta = conn.execute("SELECT metadata_yaml FROM skills_content").fetchone()[0]
        assert 'repo_kind: "tooling"' in meta
        assert 'crawl_sources: ["org:openclaw"]' in meta
        assert "priority_score: 42.5" in meta
    finally:
        conn.close()


def test_search_claw_repo_prefers_priority_score(tmp_path: Path, monkeypatch):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-repos-v20260403.sqlite"
    build_claw_repo_bundle(
        [
            ClawRepo(
                repo_full_name="openclaw/low-priority",
                repo_url="https://github.com/openclaw/low-priority",
                repo_owner="openclaw",
                repo_name="low-priority",
                description="Lower priority repo",
                skill_file_count=2,
                priority_score=10.0,
                last_seen_at="2026-04-03T00:00:00Z",
            ),
            ClawRepo(
                repo_full_name="openclaw/high-priority",
                repo_url="https://github.com/openclaw/high-priority",
                repo_owner="openclaw",
                repo_name="high-priority",
                description="Higher priority repo",
                skill_file_count=8,
                soul_file_count=1,
                priority_score=55.0,
                last_seen_at="2026-04-03T00:00:00Z",
            ),
        ],
        bundle_path,
        version="20260403",
    )

    monkeypatch.setenv("CLAWSKILLS_BUNDLE_PATH", str(bundle_path))
    results = search_skills("openclaw", top_k=5, kind="claw-repo")

    assert [row["title"] for row in results[:2]] == [
        "openclaw/high-priority — Higher priority repo [skills:8 agents:1]",
        "openclaw/low-priority — Lower priority repo [skills:2]",
    ]
    # Scores include content-based bonuses (body length, code blocks, sections)
    assert results[0]["overall_score"] > results[1]["overall_score"]


def test_main_dispatches_claw_repo_aggregate(monkeypatch):
    from core.sources.claw import repo_registry as repo_registry_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_main(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(repo_registry_mod, "cli_main", fake_cli_main)

    assert main(
        [
            "claw-repo-aggregate",
            "--max-repos",
            "42",
            "--sources",
            "org,topic",
            "--seed-file",
            "seeds.txt",
            "--state-db",
            "state.sqlite",
            "--no-state",
            "--stats-only",
        ]
    ) == 0
    assert calls["argv"] == [
        "--max-repos",
        "42",
        "--sources",
        "org,topic",
        "--seed-file",
        "seeds.txt",
        "--state-db",
        "state.sqlite",
        "--no-state",
        "--stats-only",
    ]


def test_main_dispatches_claw_repo_search(monkeypatch):
    from core import search as search_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_skill_search(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(search_mod, "cli_skill_search", fake_cli_skill_search)

    assert main(
        [
            "claw-repo-search",
            "openclaw",
            "--top",
            "5",
            "--content",
            "--format",
            "json",
        ]
    ) == 0
    assert calls["argv"] == [
        "openclaw",
        "--top",
        "5",
        "--bundle-name",
        "claw-repos",
        "--kind",
        "claw-repo",
        "--content",
        "--max-chars",
        "4000",
        "--format",
        "json",
    ]


def test_main_dispatches_claw_mine_skills(monkeypatch):
    from core.sources.claw import repo_miner as repo_miner_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_main(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(repo_miner_mod, "cli_main", fake_cli_main)

    assert main(
        [
            "claw-mine-skills",
            "--state-db",
            "state.sqlite",
            "--repo",
            "openclaw/example",
            "--all",
            "--max-repos",
            "12",
            "--workers",
            "3",
            "--out",
            "dist/mined.sqlite",
            "--version",
            "20260403",
        ]
    ) == 0
    assert calls["argv"] == [
        "--max-repos",
        "12",
        "--workers",
        "3",
        "--state-db",
        "state.sqlite",
        "--repo",
        "openclaw/example",
        "--all",
        "--out",
        "dist/mined.sqlite",
        "--version",
        "20260403",
    ]


def test_main_dispatches_claw_clean_bundle(monkeypatch):
    from core.sources.claw import clean_bundle as clean_bundle_mod

    calls: dict[str, list[str] | None] = {}

    def fake_cli_main(argv: list[str] | None = None) -> int:
        calls["argv"] = argv
        return 0

    monkeypatch.setattr(clean_bundle_mod, "cli_main", fake_cli_main)

    assert main(
        [
            "claw-clean-bundle",
            "--input",
            "dist/in.sqlite",
            "--out",
            "dist/out.sqlite",
            "--version",
            "20260403",
        ]
    ) == 0
    assert calls["argv"] == [
        "--input",
        "dist/in.sqlite",
        "--out",
        "dist/out.sqlite",
        "--version",
        "20260403",
    ]


def test_sync_repo_state_persists_and_prunes_files(tmp_path: Path):
    state_db = tmp_path / "claw-repo-state.sqlite"
    repo = ClawRepo(
        repo_full_name="openclaw/example",
        repo_url="https://github.com/openclaw/example",
        repo_owner="openclaw",
        repo_name="example",
        repo_id="101",
        repo_kind="skill-repo",
        crawl_sources=["org:openclaw"],
        has_skill_md=True,
        skill_file_count=1,
        has_soul_md=True,
        soul_file_count=1,
        tree_sha="tree-1",
        last_seen_at="2026-04-02T00:00:00Z",
        tracked_files=[
            ClawRepoFile(
                path="SKILL.md",
                blob_sha="blob-a",
                file_kind="skill_md",
                source_url="https://github.com/openclaw/example/blob/HEAD/SKILL.md",
            ),
            ClawRepoFile(
                path="agents/demo/SOUL.md",
                blob_sha="blob-b",
                file_kind="soul_md",
                source_url="https://github.com/openclaw/example/blob/HEAD/agents/demo/SOUL.md",
            ),
        ],
    )

    sync_repo_state([repo], state_db=state_db)
    store = ClawRepoStateStore(state_db)
    state = store.get_repo_state("openclaw/example")
    files = store.list_repo_files("openclaw/example")

    assert state is not None
    assert state["tree_sha"] == "tree-1"
    assert state["crawl_sources"] == ["org:openclaw"]
    assert len(files) == 2

    store.mark_mined(
        "openclaw/example",
        mined_at="2026-04-02T01:00:00Z",
        status="ok",
        skill_count=1,
        agent_count=1,
    )

    repo.tree_sha = "tree-2"
    repo.last_seen_at = "2026-04-02T02:00:00Z"
    repo.tracked_files = [
        ClawRepoFile(
            path="agents/demo/SOUL.md",
            blob_sha="blob-c",
            file_kind="soul_md",
            source_url="https://github.com/openclaw/example/blob/HEAD/agents/demo/SOUL.md",
        )
    ]
    repo.has_skill_md = False
    repo.skill_file_count = 0
    repo.soul_file_count = 1
    sync_repo_state([repo], state_db=state_db)

    state = store.get_repo_state("openclaw/example")
    files = store.list_repo_files("openclaw/example")
    assert state is not None
    assert state["tree_sha"] == "tree-2"
    assert state["last_mined_status"] == "ok"
    assert state["last_skill_count"] == 1
    assert len(files) == 1
    assert files[0]["path"] == "agents/demo/SOUL.md"
    assert files[0]["blob_sha"] == "blob-c"
