"""Tests for skill gate and prompt hashing."""
from __future__ import annotations

from core.skills.gate import _prompt_sha
from core.llm.types import ChatMessage


class TestPromptSha:
    def test_hash_with_chat_messages(self):
        msgs = [ChatMessage(role="system", content="hello"), ChatMessage(role="user", content="test")]
        h = _prompt_sha(msgs)
        assert isinstance(h, str) and len(h) == 64

    def test_hash_with_dicts(self):
        msgs = [{"role": "system", "content": "hello"}, {"role": "user", "content": "test"}]
        h = _prompt_sha(msgs)
        assert isinstance(h, str) and len(h) == 64

    def test_hash_with_plain_strings(self):
        msgs = ["hello", "world"]
        h = _prompt_sha(msgs)
        assert isinstance(h, str) and len(h) == 64

    def test_hash_with_mixed_types(self):
        msgs = [ChatMessage(role="system", content="sys"), {"role": "user", "content": "dict"}, "plain"]
        h = _prompt_sha(msgs)
        assert isinstance(h, str) and len(h) == 64

    def test_deterministic(self):
        msgs = [ChatMessage(role="user", content="test")]
        assert _prompt_sha(msgs) == _prompt_sha(msgs)

    def test_different_content_different_hash(self):
        a = _prompt_sha([ChatMessage(role="user", content="a")])
        b = _prompt_sha([ChatMessage(role="user", content="b")])
        assert a != b
