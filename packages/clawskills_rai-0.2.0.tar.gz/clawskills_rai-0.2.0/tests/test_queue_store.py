"""Tests for QueueStore core operations."""
from __future__ import annotations

import pytest

from core.queue.store import QueueStore


@pytest.fixture
def store(tmp_path):
    db_path = tmp_path / "queue.db"
    s = QueueStore(db_path)
    s.init_db()
    return s


class TestQueueEnqueue:
    def test_enqueue_new_item(self, store):
        result = store.enqueue(
            source_id="abc123def456",
            source_type="webpage",
            source_url="https://example.com/page",
            source_title="Test Page",
        )
        assert result["enqueued"] is True
        assert "id" in result

    def test_enqueue_duplicate_source_id(self, store):
        store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com/1")
        result = store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com/1")
        assert result["enqueued"] is False
        assert result["reason"] == "source_exists"

    def test_enqueue_respects_drain(self, store):
        store.set_meta("drain", "1")
        result = store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com")
        assert result["enqueued"] is False
        assert result["reason"] == "drain_enabled"


class TestQueueLeaseNext:
    def test_lease_returns_items(self, store):
        store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com/1", stage="ingest")
        leased = store.lease_next(worker_id="test", limit=1, stages=["ingest"], lease_seconds=300)
        assert len(leased) == 1
        assert leased[0]["source_id"] == "abc123def456"

    def test_lease_empty_stage(self, store):
        leased = store.lease_next(worker_id="test", limit=1, stages=["ingest"], lease_seconds=300)
        assert leased == []


class TestQueueAckNack:
    def test_ack_completes_item(self, store):
        store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com", stage="ingest")
        leased = store.lease_next(worker_id="test", limit=1, stages=["ingest"], lease_seconds=300)
        item_id = int(leased[0]["id"])
        store.ack(item_id)
        stats = store.stats()
        assert stats["total"] >= 1

    def test_nack_records_error(self, store):
        store.enqueue(source_id="abc123def456", source_type="webpage", source_url="https://example.com", stage="ingest")
        leased = store.lease_next(worker_id="test", limit=1, stages=["ingest"], lease_seconds=300)
        item_id = int(leased[0]["id"])
        result = store.nack(item_id, reason="test error", backoff_seconds=1)
        assert result["status"] in {"queued", "dead"}


class TestQueueMeta:
    def test_set_and_get_meta(self, store):
        store.set_meta("test_key", "test_value")
        assert store.get_meta("test_key") == "test_value"

    def test_get_missing_key(self, store):
        assert store.get_meta("nonexistent") == ""

    def test_is_draining(self, store):
        assert store.is_draining() is False
        store.set_meta("drain", "1")
        assert store.is_draining() is True
