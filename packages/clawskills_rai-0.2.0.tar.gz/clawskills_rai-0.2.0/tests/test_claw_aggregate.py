"""Tests for claw aggregate deduplication, scoring, and placeholder handling."""
from __future__ import annotations

from core.sources.claw.converter import ClawSkill


class TestAggregateDedupeLogic:
    """Test the dedupe and winner-selection logic extracted from aggregate_claw_skills."""

    def _make_skill(self, name="test", body="x" * 200, description="desc", tags=None, source_url="https://example.com", metadata=None):
        return ClawSkill(
            name=name,
            description=description,
            tags=tags or ["python"],
            body_md=body,
            source_url=source_url,
            source_type="claw-github",
            metadata=metadata or {},
        )

    def test_placeholder_penalized(self):
        """Placeholder skills should have a much lower score than real skills."""
        # We can't easily call aggregate directly without network, so test the scoring logic
        real = self._make_skill(metadata={})
        placeholder = self._make_skill(metadata={"is_placeholder": True})

        # Simulate the scoring function
        def _skill_score(s):
            score = 0.0
            if s.metadata.get("is_placeholder"):
                score -= 5.0
            if s.body_md and len(s.body_md.strip()) > 100:
                score += 2.0
            if s.description:
                score += 1.0
            if s.tags:
                score += 0.5
            if s.source_url:
                score += 0.5
            for key in ("repo_priority_score", "priority_score", "overall_score"):
                try:
                    val = float(s.metadata.get(key) or 0)
                    if val > 0:
                        score += val
                        break
                except (ValueError, TypeError):
                    continue
            return score

        real_score = _skill_score(real)
        placeholder_score = _skill_score(placeholder)
        assert real_score > placeholder_score
        assert placeholder_score < 0  # placeholder should be negative

    def test_higher_score_wins_dedupe(self):
        """When two skills share the same name+kind, the higher-scored one should win."""
        low = self._make_skill(body="short", description="")
        high = self._make_skill(body="x" * 200, description="detailed desc", metadata={"priority_score": 5.0})

        def _skill_score(s):
            score = 0.0
            if s.metadata.get("is_placeholder"):
                score -= 5.0
            if s.body_md and len(s.body_md.strip()) > 100:
                score += 2.0
            if s.description:
                score += 1.0
            if s.tags:
                score += 0.5
            if s.source_url:
                score += 0.5
            for key in ("repo_priority_score", "priority_score", "overall_score"):
                try:
                    val = float(s.metadata.get(key) or 0)
                    if val > 0:
                        score += val
                        break
                except (ValueError, TypeError):
                    continue
            return score

        assert _skill_score(high) > _skill_score(low)

    def test_repo_priority_score_used(self):
        """repo_priority_score should be picked up by the scorer."""
        skill = self._make_skill(metadata={"repo_priority_score": 10.0})

        def _skill_score(s):
            score = 0.0
            if s.body_md and len(s.body_md.strip()) > 100:
                score += 2.0
            if s.description:
                score += 1.0
            if s.tags:
                score += 0.5
            if s.source_url:
                score += 0.5
            for key in ("repo_priority_score", "priority_score", "overall_score"):
                try:
                    val = float(s.metadata.get(key) or 0)
                    if val > 0:
                        score += val
                        break
                except (ValueError, TypeError):
                    continue
            return score

        assert _skill_score(skill) >= 14.0  # 2 + 1 + 0.5 + 0.5 + 10


class TestEmergingPathInference:
    """Test that emerging directory layouts are recognized."""

    def test_agents_path_infer_name(self):
        from core.sources.claw.github_skills import _infer_skill_name
        skill = ClawSkill(name="", source_url="https://example.com")
        _infer_skill_name(skill, file_path=".agents/my-agent/SKILL.md", repo_full_name="owner/repo")
        assert skill.name == "my-agent"

    def test_cursor_path_infer_name(self):
        from core.sources.claw.github_skills import _infer_skill_name
        skill = ClawSkill(name="", source_url="https://example.com")
        # .cursor is a recognized root; the next part after it is the skill name
        _infer_skill_name(skill, file_path=".cursor/helper/SKILL.md", repo_full_name="owner/repo")
        assert skill.name == "helper"

    def test_codex_path_infer_name(self):
        from core.sources.claw.github_skills import _infer_skill_name
        skill = ClawSkill(name="", source_url="https://example.com")
        _infer_skill_name(skill, file_path=".codex/my-tool/SKILL.md", repo_full_name="owner/repo")
        assert skill.name == "my-tool"

    def test_existing_name_not_overwritten(self):
        from core.sources.claw.github_skills import _infer_skill_name
        skill = ClawSkill(name="existing-name", source_url="https://example.com")
        _infer_skill_name(skill, file_path=".agents/other/SKILL.md", repo_full_name="owner/repo")
        assert skill.name == "existing-name"

    def test_fallback_to_repo_name(self):
        from core.sources.claw.github_skills import _infer_skill_name
        skill = ClawSkill(name="", source_url="https://example.com")
        _infer_skill_name(skill, file_path="SKILL.md", repo_full_name="owner/my-tool")
        assert skill.name == "my-tool"
