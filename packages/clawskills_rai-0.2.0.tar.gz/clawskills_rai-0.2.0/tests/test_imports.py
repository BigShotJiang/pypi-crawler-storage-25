"""Smoke tests: verify all core modules can be imported without errors."""


def test_import_core():
    import core
    assert hasattr(core, "__version__")
    assert hasattr(core, "DOMAIN_CONFIG")


def test_import_config():
    from core.config import extract_url_hostname, canonicalize_source_url
    assert callable(extract_url_hostname)
    assert callable(canonicalize_source_url)


def test_import_env():
    from core.env import env_int, env_bool, resolve_llm_provider_name
    assert callable(env_int)
    assert callable(env_bool)
    assert callable(resolve_llm_provider_name)


def test_import_cli():
    from core.cli import main
    assert callable(main)


def test_import_search():
    from core.search import search_skills, format_brief, format_json
    assert callable(search_skills)
    assert callable(format_brief)
    assert callable(format_json)


def test_import_queue():
    from core.queue import QueueSettings, QueueStore
    assert QueueSettings is not None
    assert QueueStore is not None


def test_import_utils():
    from core.utils.hashing import sha256_hex, slugify
    from core.utils.paths import repo_root
    assert callable(sha256_hex)
    assert callable(slugify)
    assert callable(repo_root)


def test_import_claw():
    from core.sources.claw import aggregate_claw_skills, build_claw_bundle
    from core.sources.claw.clean_bundle import clean_claw_bundle
    from core.sources.claw.openclaw_archive import crawl_openclaw_archive
    from core.sources.claw.repo_miner import mine_repo_state
    from core.sources.claw.repo_registry import aggregate_claw_repos, build_claw_repo_bundle
    from core.sources.claw.repo_state import ClawRepoStateStore
    assert callable(aggregate_claw_skills)
    assert callable(build_claw_bundle)
    assert callable(clean_claw_bundle)
    assert callable(crawl_openclaw_archive)
    assert callable(mine_repo_state)
    assert callable(aggregate_claw_repos)
    assert callable(build_claw_repo_bundle)
    assert ClawRepoStateStore is not None
