from __future__ import annotations

from pathlib import Path

from core.sources.claw.repo_miner import mine_repo_state
from core.sources.claw.repo_registry import ClawRepo, ClawRepoFile, sync_repo_state
from core.sources.claw.repo_state import ClawRepoStateStore


def test_list_repos_for_mining_respects_changed_only(tmp_path: Path):
    state_db = tmp_path / "claw-repo-state.sqlite"
    repo = ClawRepo(
        repo_full_name="openclaw/example",
        repo_url="https://github.com/openclaw/example",
        repo_owner="openclaw",
        repo_name="example",
        repo_id="101",
        repo_kind="skill-repo",
        crawl_sources=["org:openclaw"],
        has_skill_md=True,
        skill_file_count=1,
        tree_sha="tree-1",
        last_seen_at="2026-04-03T00:00:00Z",
        tracked_files=[
            ClawRepoFile(
                path="SKILL.md",
                blob_sha="blob-a",
                file_kind="skill_md",
                source_url="https://github.com/openclaw/example/blob/HEAD/SKILL.md",
            )
        ],
    )
    sync_repo_state([repo], state_db=state_db)

    store = ClawRepoStateStore(state_db)
    pending = store.list_repos_for_mining(changed_only=True, max_repos=10)
    assert [row["repo_full_name"] for row in pending] == ["openclaw/example"]

    store.mark_mined(
        "openclaw/example",
        mined_at="2026-04-03T01:00:00Z",
        tree_sha="tree-1",
        status="ok",
        skill_count=1,
        agent_count=0,
    )
    assert store.list_repos_for_mining(changed_only=True, max_repos=10) == []

    repo.tree_sha = "tree-2"
    repo.last_seen_at = "2026-04-03T02:00:00Z"
    sync_repo_state([repo], state_db=state_db)
    pending = store.list_repos_for_mining(changed_only=True, max_repos=10)
    assert [row["repo_full_name"] for row in pending] == ["openclaw/example"]


def test_mine_repo_state_emits_skills_and_updates_state(monkeypatch, tmp_path: Path):
    state_db = tmp_path / "claw-repo-state.sqlite"
    repo = ClawRepo(
        repo_full_name="openclaw/example",
        repo_url="https://github.com/openclaw/example",
        repo_owner="openclaw",
        repo_name="example",
        repo_id="101",
        description="Example claw repo",
        repo_kind="agent-templates",
        crawl_sources=["org:openclaw"],
        has_skill_md=True,
        skill_file_count=1,
        has_soul_md=True,
        soul_file_count=1,
        tree_sha="tree-1",
        last_seen_at="2026-04-03T00:00:00Z",
        tracked_files=[
            ClawRepoFile(
                path="skills/demo/SKILL.md",
                blob_sha="blob-skill",
                file_kind="skill_md",
                source_url="https://github.com/openclaw/example/blob/HEAD/skills/demo/SKILL.md",
            ),
            ClawRepoFile(
                path="agents/productivity/orion/SOUL.md",
                blob_sha="blob-soul",
                file_kind="soul_md",
                source_url="https://github.com/openclaw/example/blob/HEAD/agents/productivity/orion/SOUL.md",
            ),
        ],
    )
    sync_repo_state([repo], state_db=state_db)

    docs = {
        "https://raw.githubusercontent.com/openclaw/example/HEAD/skills/demo/SKILL.md": (
            "---\n"
            "name: Demo Skill\n"
            "description: Demo repo skill\n"
            "tags: [openclaw, cli]\n"
            "---\n"
            "# Demo Skill\n\n"
            "Use the demo skill.\n"
        ),
        "https://raw.githubusercontent.com/openclaw/example/HEAD/agents/productivity/orion/SOUL.md": (
            "# Orion - The Coordinator\n\n"
            "You are Orion, an AI coordinator and project manager powered by OpenClaw.\n"
        ),
    }

    monkeypatch.setattr(
        "core.sources.claw.repo_miner.http_get_with_rate_retry",
        lambda url, *, headers=None: docs.get(url),
    )

    skills, stats = mine_repo_state(
        state_db=state_db,
        changed_only=True,
        max_repos=10,
        workers=2,
    )

    assert stats == {
        "selected_repos": 1,
        "selected_files": 2,
        "emitted_skills": 1,
        "emitted_agents": 1,
        "file_errors": 0,
    }
    assert sorted(skill.name for skill in skills) == ["Demo Skill", "Orion - The Coordinator"]
    assert {skill.source_type for skill in skills} == {"claw-repo-agent", "claw-repo-skill"}
    assert {skill.metadata["repo_full_name"] for skill in skills} == {"openclaw/example"}
    assert {skill.metadata["repo_file_path"] for skill in skills} == {
        "skills/demo/SKILL.md",
        "agents/productivity/orion/SOUL.md",
    }

    store = ClawRepoStateStore(state_db)
    state = store.get_repo_state("openclaw/example")
    files = store.list_repo_files("openclaw/example")

    assert state is not None
    assert state["last_mined_status"] == "ok"
    assert state["last_mined_tree_sha"] == "tree-1"
    assert state["last_skill_count"] == 1
    assert state["last_agent_count"] == 1
    assert {file_row["parse_status"] for file_row in files} == {"emitted"}
    assert all(file_row["emitted_skill_id"] for file_row in files)


def test_mine_repo_state_marks_empty_skill_file_as_parse_error(monkeypatch, tmp_path: Path):
    state_db = tmp_path / "claw-repo-state.sqlite"
    repo = ClawRepo(
        repo_full_name="openclaw/empty-skill",
        repo_url="https://github.com/openclaw/empty-skill",
        repo_owner="openclaw",
        repo_name="empty-skill",
        repo_id="102",
        description="Empty skill repo",
        repo_kind="skill-repo",
        crawl_sources=["org:openclaw"],
        has_skill_md=True,
        skill_file_count=1,
        tree_sha="tree-empty",
        last_seen_at="2026-04-03T00:00:00Z",
        tracked_files=[
            ClawRepoFile(
                path="SKILL.md",
                blob_sha="e69de29bb2d1d6434b8b29ae775ad8c2e48c5391",
                file_kind="skill_md",
                source_url="https://github.com/openclaw/empty-skill/blob/HEAD/SKILL.md",
            )
        ],
    )
    sync_repo_state([repo], state_db=state_db)

    def fake_http_get(url: str, *, headers=None):
        if url == "https://raw.githubusercontent.com/openclaw/empty-skill/HEAD/SKILL.md":
            return ""
        if url == "https://api.github.com/repos/openclaw/empty-skill/contents/SKILL.md":
            return (
                '{"name":"SKILL.md","path":"SKILL.md","sha":"e69de29bb2d1d6434b8b29ae775ad8c2e48c5391",'
                '"size":0,"content":"","encoding":"base64"}'
            )
        return None

    monkeypatch.setattr("core.sources.claw.repo_miner.http_get_with_rate_retry", fake_http_get)

    skills, stats = mine_repo_state(
        state_db=state_db,
        changed_only=True,
        max_repos=10,
        workers=1,
    )

    assert skills == []
    assert stats["file_errors"] == 1

    store = ClawRepoStateStore(state_db)
    state = store.get_repo_state("openclaw/empty-skill")
    files = store.list_repo_files("openclaw/empty-skill")
    assert state is not None
    assert state["last_mined_status"] == "error"
    assert "file is empty" in state["last_error"]
    assert files[0]["parse_status"] == "parse_error"
