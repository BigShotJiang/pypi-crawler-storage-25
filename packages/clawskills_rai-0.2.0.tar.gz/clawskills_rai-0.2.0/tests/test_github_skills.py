from __future__ import annotations

from core.sources.claw import github_skills as gh


def test_crawl_github_skills_respects_search_budget(monkeypatch):
    calls: list[tuple[str, int]] = []

    def fake_search_code(query: str, *, max_pages: int = 10):
        calls.append((query, max_pages))
        return [], 1

    monkeypatch.setattr(gh, "has_github_token", lambda: True)
    monkeypatch.setattr(gh, "_MAX_SEARCH_REQUESTS_AUTH", 2)
    monkeypatch.setattr(gh, "_search_code", fake_search_code)
    monkeypatch.setattr(gh, "_search_repos", lambda query, max_pages=10: ([], 0))

    skills = gh.crawl_github_skills(
        max_skills=10,
        queries=[
            {"query": "q1", "max_pages": 3},
            {"query": "q2", "max_pages": 3},
            {"query": "q3", "max_pages": 3},
        ],
        workers=1,
    )

    assert skills == []
    assert calls == [("q1", 2), ("q2", 1)]


def test_crawl_github_skills_uses_repo_search_supplement(monkeypatch):
    def fake_search_code(query: str, *, max_pages: int = 10):
        return [], 0

    def fake_search_repos(query: str, *, max_pages: int = 10):
        return [
            {
                "full_name": "demo/repo",
                "fork": False,
                "stargazers_count": 7,
            },
        ], 1

    monkeypatch.setattr(gh, "has_github_token", lambda: True)
    monkeypatch.setattr(gh, "_MAX_SEARCH_REQUESTS_AUTH", 4)
    monkeypatch.setattr(gh, "_search_code", fake_search_code)
    monkeypatch.setattr(gh, "_search_repos", fake_search_repos)
    monkeypatch.setattr(gh, "_REPO_SEARCH_SPECS", [{"query": "topic:agent-skill", "max_pages": 1}])
    monkeypatch.setattr(
        gh,
        "_find_skill_md_in_repo",
        lambda repo_full: [("---\nname: Demo Repo Skill\ndescription: Demo\n---\nBody\n", "SKILL.md")],
    )

    skills = gh.crawl_github_skills(
        max_skills=10,
        queries=[{"query": "q1", "max_pages": 1}],
        workers=1,
    )

    assert len(skills) == 1
    assert skills[0].name == "Demo Repo Skill"
    assert skills[0].metadata["github_repo"] == "demo/repo"
    assert skills[0].metadata["github_stars"] == 7
