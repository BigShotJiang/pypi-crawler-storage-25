from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from core.search import format_brief, format_markdown, list_bundle_names, search_skills


def _write_bundle(path: Path, rows: list[dict[str, object]]) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.execute(
            """
            CREATE TABLE skills_index (
                skill_id TEXT PRIMARY KEY,
                title TEXT,
                domain TEXT,
                skill_kind TEXT,
                source_type TEXT,
                source_url TEXT,
                overall_score REAL,
                dir TEXT,
                item_json TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE skills_content (
                skill_id TEXT PRIMARY KEY,
                metadata_yaml TEXT,
                skill_md TEXT
            )
            """
        )
        for row in rows:
            conn.execute(
                """
                INSERT INTO skills_index
                (skill_id, title, domain, skill_kind, source_type, source_url, overall_score, dir, item_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    row["skill_id"],
                    row["title"],
                    row.get("domain", "llm"),
                    row.get("skill_kind", "claw-repo-skill"),
                    row.get("source_type", "claw-repo-skill"),
                    row.get("source_url", ""),
                    row.get("overall_score", 0.0),
                    row.get("dir", ""),
                    row.get("item_json", "{}"),
                ),
            )
            conn.execute(
                """
                INSERT INTO skills_content (skill_id, metadata_yaml, skill_md)
                VALUES (?, ?, ?)
                """,
                (
                    row["skill_id"],
                    row.get("metadata_yaml", ""),
                    row.get("skill_md", ""),
                ),
            )
        conn.commit()
    finally:
        conn.close()


def test_search_skills_matches_non_contiguous_title_tokens(monkeypatch, tmp_path: Path):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"
    _write_bundle(
        bundle_path,
        [
            {
                "skill_id": "skill-title",
                "title": "Calendar Sync Automation Toolkit",
                "overall_score": 4.0,
                "metadata_yaml": "",
                "skill_md": "",
            },
            {
                "skill_id": "skill-other",
                "title": "General Workflow Helper",
                "overall_score": 90.0,
                "metadata_yaml": "",
                "skill_md": "",
            },
        ],
    )

    monkeypatch.setenv("CLAWSKILLS_BUNDLE_PATH", str(bundle_path))
    results = search_skills("calendar automation", top_k=5)

    assert [row["skill_id"] for row in results] == ["skill-title"]


def test_search_skills_matches_metadata_and_body_excerpt(monkeypatch, tmp_path: Path):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"
    _write_bundle(
        bundle_path,
        [
            {
                "skill_id": "skill-meta",
                "title": "OpenClaw Productivity Pack",
                "overall_score": 12.0,
                "metadata_yaml": 'tags: ["calendar", "automation"]\nrepo_kind: "tooling"\n',
                "skill_md": "Coordinates inbox workflows.",
            },
            {
                "skill_id": "skill-body",
                "title": "Outlook Workflow Assistant",
                "overall_score": 8.0,
                "metadata_yaml": 'tags: ["email"]\nrepo_kind: "tooling"\n',
                "skill_md": "This skill helps teams run calendar automation across Outlook and Gmail.",
            },
        ],
    )

    monkeypatch.setenv("CLAWSKILLS_BUNDLE_PATH", str(bundle_path))
    results = search_skills("calendar automation", top_k=5)

    ids = [row["skill_id"] for row in results]
    assert "skill-meta" in ids
    assert "skill-body" in ids


def test_search_skills_bundle_name_filters_configured_bundle(monkeypatch, tmp_path: Path):
    home_dir = tmp_path / "home"
    clawskills_dir = home_dir / ".clawskills"
    clawskills_dir.mkdir(parents=True)

    claw_bundle = clawskills_dir / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"
    other_bundle = clawskills_dir / "clawskills-bundle-lite-linux-v20260403.sqlite"
    _write_bundle(
        claw_bundle,
        [
            {
                "skill_id": "claw-skill",
                "title": "Claw Calendar Helper",
                "overall_score": 10.0,
            },
        ],
    )
    _write_bundle(
        other_bundle,
        [
            {
                "skill_id": "linux-skill",
                "title": "Linux Calendar Helper",
                "overall_score": 99.0,
            },
        ],
    )

    (clawskills_dir / "search_config.json").write_text(
        json.dumps(
            {
                "bundles": {
                    "claw": str(claw_bundle),
                    "linux": str(other_bundle),
                }
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.delenv("CLAWSKILLS_BUNDLE_PATH", raising=False)
    monkeypatch.setenv("HOME", str(home_dir))
    results = search_skills("calendar", top_k=5, bundle_name="claw")

    assert [row["skill_id"] for row in results] == ["claw-skill"]
    assert "claw" in list_bundle_names()
    assert "linux" in list_bundle_names()


def test_search_skills_soft_collapses_claw_variants(monkeypatch, tmp_path: Path):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"
    _write_bundle(
        bundle_path,
        [
            {
                "skill_id": "skill-acrid",
                "title": "Acrid Skill Creator",
                "overall_score": 55.0,
                "source_url": "https://example.com/acrid",
                "metadata_yaml": 'repo_full_name: "example/acrid"\n',
                "skill_md": "Guide for building skills.",
            },
            {
                "skill_id": "skill-canonical",
                "title": "skill-creator",
                "overall_score": 40.0,
                "source_url": "https://example.com/canonical",
                "metadata_yaml": 'repo_full_name: "example/canonical"\n',
                "skill_md": "Canonical guide for creating skills.",
            },
            {
                "skill_id": "skill-build",
                "title": "skill-creator-build",
                "overall_score": 38.0,
                "source_url": "https://example.com/build",
                "metadata_yaml": 'repo_full_name: "example/build"\n',
                "skill_md": "Build-focused skill creator notes.",
            },
            {
                "skill_id": "calendar",
                "title": "Calendar Helper",
                "overall_score": 12.0,
                "source_url": "https://example.com/calendar",
                "metadata_yaml": 'repo_full_name: "example/calendar"\n',
                "skill_md": "Calendar helper.",
            },
        ],
    )

    monkeypatch.setenv("CLAWSKILLS_BUNDLE_PATH", str(bundle_path))
    results = search_skills("skill creator", top_k=5, bundle_name="claw")

    assert [row["skill_id"] for row in results] == ["skill-canonical"]
    assert results[0]["variant_count"] == 2
    assert [row["title"] for row in results[0]["variant_examples"]] == [
        "Acrid Skill Creator",
        "skill-creator-build",
    ]
    brief = format_brief(results)
    assert "(+2)" in brief  # variant count shown in skill title
    expanded = format_brief(results, show_variants=True)
    assert "Acrid Skill Creator" in expanded
    assert "skill-creator-build" in expanded


def test_search_skills_does_not_overcollapse_body_only_matches(monkeypatch, tmp_path: Path):
    bundle_path = tmp_path / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"
    _write_bundle(
        bundle_path,
        [
            {
                "skill_id": "calendar-a",
                "title": "Google Workspace Automation",
                "overall_score": 30.0,
                "source_url": "https://example.com/google",
                "metadata_yaml": 'repo_full_name: "example/google"\n',
                "skill_md": "Handles calendar automation flows.",
            },
            {
                "skill_id": "calendar-b",
                "title": "Email To Calendar",
                "overall_score": 28.0,
                "source_url": "https://example.com/email",
                "metadata_yaml": 'repo_full_name: "example/email"\n',
                "skill_md": "Moves emails into calendar automation pipelines.",
            },
        ],
    )

    monkeypatch.setenv("CLAWSKILLS_BUNDLE_PATH", str(bundle_path))
    results = search_skills("calendar automation", top_k=5, bundle_name="claw")

    assert [row["skill_id"] for row in results] == ["calendar-a", "calendar-b"]
    assert all(int(row.get("variant_count") or 0) == 0 for row in results)


def test_format_markdown_show_variants_renders_variant_list() -> None:
    rendered = format_markdown(
        [
            {
                "title": "skill-creator",
                "overall_score": 10.0,
                "domain": "devtools",
                "skill_kind": "claw-skill",
                "variant_count": 1,
                "variant_examples": [
                    {
                        "title": "Acrid Skill Creator",
                        "source_url": "https://example.com/acrid",
                    }
                ],
            }
        ],
        show_variants=True,
    )
    assert "### Variants" in rendered
    assert "- Acrid Skill Creator — https://example.com/acrid" in rendered
