from __future__ import annotations

import asyncio
import json
from pathlib import Path

from core.sources.journals.engine.config import CrawlConfig
from core.sources.journals.engine.orchestrator import CrawlOrchestrator
from core.sources.journals.engine.storage import DataStorage
from core.sources.journals.models import DataSource, FigureInfo, PaperRecord
def test_data_storage_persists_paper_index_and_summary(tmp_path: Path):
    cfg = CrawlConfig(output_dir=tmp_path.as_posix())
    store = DataStorage(cfg)
    paper = PaperRecord(
        doi="10.1000/storage-demo",
        title="Storage Demo",
        journal="Demo Journal",
        journal_family="PMC",
        url="https://example.com/storage-demo",
        figures=[FigureInfo(figure_id="fig1", caption="caption")],
        data_sources=[DataSource(repository="Zenodo", accession="123", url="https://zenodo.org/record/123")],
    )

    saved_path = Path(store.save_paper(paper))
    store.save_summary({"total_papers": 1})

    assert saved_path.is_file()
    paper_json = json.loads(saved_path.read_text(encoding="utf-8"))
    assert paper_json["doi"] == "10.1000/storage-demo"
    assert "crawled_at" in paper_json

    index_rows = [json.loads(line) for line in (tmp_path / "index.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    assert index_rows[0]["doi"] == "10.1000/storage-demo"
    assert store.get_existing_dois() == {"10.1000/storage-demo"}

    summary = json.loads((tmp_path / "crawl_summary.json").read_text(encoding="utf-8"))
    assert summary["total_papers"] == 1
    assert "written_at" in summary
def test_crawl_orchestrator_run_uses_storage_and_respects_enabled_families(monkeypatch, tmp_path: Path):
    cfg = CrawlConfig(output_dir=tmp_path.as_posix(), max_papers=1, families=["PMC"])
    cfg.download_figures = False  # type: ignore[attr-defined]

    paper = PaperRecord(
        doi="10.1000/orchestrator-demo",
        title="Orchestrator Demo",
        journal="PMC Journal",
        journal_family="PMC",
        url="https://example.com/orchestrator-demo",
        pmc_id="PMC123456",
    )

    seen_families: list[str] = []

    class FakeClient:
        def __init__(self, config):
            self.config = config

        async def close(self):
            return None

    class FakeDiscovery:
        def __init__(self, client, config):
            self.client = client
            self.config = config

        async def discover_springer_articles(self, issn, max_results):
            seen_families.append("Nature")
            return []

        async def discover_plos_articles(self, journal_slug, max_results):
            seen_families.append("PLOS")
            return []

        async def discover_elife_articles(self, max_results):
            seen_families.append("eLife")
            return []

        async def discover_pmc_articles(self, issn, journal_name, max_results):
            seen_families.append("PMC")
            return [paper]

    class FakeExtractor:
        def __init__(self, client, config):
            self.client = client
            self.config = config

        async def enrich_nature_paper(self, paper):
            return paper

        async def enrich_plos_paper(self, paper):
            return paper

        async def enrich_elife_paper(self, paper):
            return paper

        async def enrich_paper_via_pmc(self, pmc_ids, family_name):
            paper.figures = [FigureInfo(figure_id="fig1", caption="demo")]
            paper.data_sources = [DataSource(repository="Zenodo", accession="123", url="https://zenodo.org/record/123")]
            return [paper]

        async def enrich_generic_paper(self, paper):
            return paper

    class FakeDownloader:
        def __init__(self, client, config):
            self.client = client
            self.config = config

        async def download_paper_figures(self, paper):
            return None

    import core.sources.journals.engine.orchestrator as orch_mod

    monkeypatch.setattr(orch_mod, "AsyncHTTPClient", FakeClient)
    monkeypatch.setattr(orch_mod, "ArticleDiscovery", FakeDiscovery)
    monkeypatch.setattr(orch_mod, "ContentExtractor", FakeExtractor)
    monkeypatch.setattr(orch_mod, "FigureDownloader", FakeDownloader)

    orch = CrawlOrchestrator(cfg)
    asyncio.run(orch.run())

    assert seen_families == ["PMC"]
    summary = json.loads((tmp_path / "crawl_summary.json").read_text(encoding="utf-8"))
    assert summary["total_papers"] == 1
    assert orch.storage.get_existing_dois() == {"10.1000/orchestrator-demo"}
