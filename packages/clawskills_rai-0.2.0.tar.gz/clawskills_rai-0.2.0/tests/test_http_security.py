"""Tests for HTTP fetch security hardening."""
from __future__ import annotations

import pytest

from core.utils.http import fetch_with_retries, _is_private_host


class TestSchemeAllowlist:
    def test_rejects_file_scheme(self):
        with pytest.raises(ValueError, match="not allowed"):
            fetch_with_retries("file:///etc/passwd")

    def test_rejects_ftp_scheme(self):
        with pytest.raises(ValueError, match="not allowed"):
            fetch_with_retries("ftp://example.com/file.txt")

    def test_rejects_empty_scheme(self):
        with pytest.raises(ValueError, match="not allowed"):
            fetch_with_retries("no-scheme-url")

    def test_rejects_javascript_scheme(self):
        with pytest.raises(ValueError, match="not allowed"):
            fetch_with_retries("javascript:alert(1)")


class TestPrivateHostBlocking:
    """Tests that _is_private_host correctly identifies private/loopback IPs."""

    def test_blocks_localhost(self):
        assert _is_private_host("localhost") is True

    def test_blocks_127_0_0_1(self):
        assert _is_private_host("127.0.0.1") is True

    def test_blocks_10_x(self):
        assert _is_private_host("10.0.0.1") is True

    def test_blocks_172_16_x(self):
        assert _is_private_host("172.16.0.1") is True

    def test_blocks_192_168_x(self):
        assert _is_private_host("192.168.1.1") is True

    def test_blocks_ipv6_loopback(self):
        assert _is_private_host("::1") is True

    def test_allows_public_ip(self):
        assert _is_private_host("8.8.8.8") is False

    def test_allows_public_hostname(self):
        assert _is_private_host("example.com") is False

    def test_blocks_zero_ip(self):
        assert _is_private_host("0.0.0.0") is True

    def test_does_not_block_hostname_starting_with_10(self):
        """'10.example.com' is a valid public hostname, not a private IP."""
        assert _is_private_host("10.example.com") is False

    def test_blocks_link_local(self):
        assert _is_private_host("169.254.1.1") is True

    def test_fetch_blocks_private_host(self):
        with pytest.raises(ValueError, match="private/loopback"):
            fetch_with_retries("http://127.0.0.1/secret")

    def test_fetch_blocks_localhost(self):
        with pytest.raises(ValueError, match="private/loopback"):
            fetch_with_retries("https://localhost/admin")

    def test_fetch_blocks_10_x(self):
        with pytest.raises(ValueError, match="private/loopback"):
            fetch_with_retries("http://10.0.0.1/internal")
