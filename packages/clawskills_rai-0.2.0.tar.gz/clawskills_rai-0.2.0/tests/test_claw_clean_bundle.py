from __future__ import annotations

import sqlite3
from pathlib import Path

from core.sources.claw import build_claw_bundle
from core.sources.claw.clean_bundle import clean_claw_bundle
from core.sources.claw.converter import ClawSkill


def test_clean_claw_bundle_rewrites_titles_and_dedupes(tmp_path: Path):
    input_bundle = tmp_path / "clawskills-bundle-lite-claw-mined-v20260403.sqlite"
    output_bundle = tmp_path / "clawskills-bundle-lite-claw-clean-v20260403.sqlite"

    build_claw_bundle(
        [
            ClawSkill(
                name="Wechat Layout Publish",
                description="Publish markdown to WeChat with layout presets.",
                source_url="https://github.com/clawdbot/skills/blob/HEAD/skills/08820048/wechat-layout-publish/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Wechat Layout Publish\n\nPublish markdown to WeChat with layout presets.\n",
                metadata={
                    "display_title": "clawdbot/skills",
                    "claw_name": "Wechat Layout Publish",
                    "record_kind": "skill",
                    "repo_full_name": "clawdbot/skills",
                    "repo_kind": "skill-collection",
                    "repo_priority_score": 35,
                    "repo_file_path": "skills/08820048/wechat-layout-publish/SKILL.md",
                },
            ),
            ClawSkill(
                name="Product Playbook",
                description="English product operating system.",
                source_url="https://github.com/example/product-playbook/blob/HEAD/i18n/en/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Product Playbook\n\nShip faster with a tight product operating cadence.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "example/product-playbook",
                    "repo_kind": "skill-collection",
                    "repo_priority_score": 60,
                    "repo_file_path": "i18n/en/SKILL.md",
                },
            ),
            ClawSkill(
                name="Product Playbook",
                description="Spanish product operating system.",
                source_url="https://github.com/example/product-playbook/blob/HEAD/i18n/es/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Product Playbook\n\nEntrega mas rapido con una cadencia operativa de producto.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "example/product-playbook",
                    "repo_kind": "skill-collection",
                    "repo_priority_score": 60,
                    "repo_file_path": "i18n/es/SKILL.md",
                },
            ),
            ClawSkill(
                name="Skill Creator",
                description="Canonical guide.",
                source_url="https://github.com/openclaw/openclaw/blob/HEAD/skills/skill-creator/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Skill Creator\n\nWrite a skill with frontmatter, examples, validation, and packaging guidance.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "openclaw/openclaw",
                    "repo_kind": "tooling",
                    "repo_priority_score": 80,
                    "repo_file_path": "skills/skill-creator/SKILL.md",
                },
            ),
            ClawSkill(
                name="Skill Creator",
                description="Copied guide.",
                source_url="https://github.com/mirror/openclaw-copy/blob/HEAD/skills/skill-creator/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Skill Creator\n\nWrite a skill with frontmatter, examples, validation, and packaging guidance.\n\nUse the same sections and prompts.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "mirror/openclaw-copy",
                    "repo_kind": "skill-repo",
                    "repo_priority_score": 15,
                    "repo_file_path": "skills/skill-creator/SKILL.md",
                },
            ),
            ClawSkill(
                name="Outlook Calendar Automation",
                description="Automate Outlook calendar tasks.",
                source_url="https://github.com/example/a/blob/HEAD/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Outlook Calendar Automation\n\nAutomate Outlook calendar tasks with COM.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "example/a",
                    "repo_kind": "skill-repo",
                    "repo_priority_score": 40,
                    "repo_file_path": "SKILL.md",
                },
            ),
            ClawSkill(
                name="Outlook Calendar Automation",
                description="Automate Outlook calendar tasks.",
                source_url="https://github.com/example/b/blob/HEAD/SKILL.md",
                source_type="claw-repo-skill",
                body_md="# Outlook Calendar Automation\n\nAutomate Outlook calendar tasks with COM.\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "example/b",
                    "repo_kind": "skill-repo",
                    "repo_priority_score": 10,
                    "repo_file_path": "SKILL.md",
                },
            ),
            ClawSkill(
                name=">",
                description="bad",
                source_url="https://github.com/example/c/blob/HEAD/SKILL.md",
                source_type="claw-repo-skill",
                body_md="short\n",
                metadata={
                    "record_kind": "skill",
                    "repo_full_name": "example/c",
                    "repo_kind": "unknown",
                    "repo_priority_score": 5,
                    "repo_file_path": "SKILL.md",
                },
            ),
        ],
        input_bundle,
        version="20260403",
        source="claw-repo-miner",
    )

    out, stats = clean_claw_bundle(input_bundle, out_path=output_bundle, version="20260403")

    assert out == output_bundle
    assert stats["input_rows"] == 8
    assert stats["kept_rows"] == 4
    assert stats["deduped_rows"] == 1
    assert stats["folded_repo_variants"] == 1
    assert stats["folded_near_duplicates"] == 1
    assert stats["rewritten_titles"] >= 1

    conn = sqlite3.connect(output_bundle)
    try:
        rows = conn.execute(
            "select title, overall_score, source_url from skills_index order by title, source_url"
        ).fetchall()
        assert rows == [
            ("Outlook Calendar Automation", 40.0, "https://github.com/example/a/blob/HEAD/SKILL.md"),
            ("Product Playbook", 60.0, "https://github.com/example/product-playbook/blob/HEAD/i18n/en/SKILL.md"),
            ("Skill Creator", 80.0, "https://github.com/openclaw/openclaw/blob/HEAD/skills/skill-creator/SKILL.md"),
            ("Wechat Layout Publish", 35.0, "https://github.com/clawdbot/skills/blob/HEAD/skills/08820048/wechat-layout-publish/SKILL.md"),
        ]
        source = conn.execute("select value from bundle_meta where key='source'").fetchone()[0]
        assert source == "claw-repo-clean"
    finally:
        conn.close()
