"""Tests for aggregate_claw_full() — the canonical 4-tier pipeline."""
from __future__ import annotations

import sqlite3
from pathlib import Path


from core.sources.claw.converter import ClawSkill


def _fake_skill(name: str = "demo-skill", body: str = "# Demo\n\nContent " * 20) -> ClawSkill:
    return ClawSkill(
        name=name,
        description="A demo skill",
        tags=["python"],
        body_md=body,
        source_url=f"https://github.com/test/{name}",
        source_type="claw-github",
    )


class TestAggregateClawFull:
    """Smoke tests for the full 4-tier pipeline with all tiers mocked."""

    def test_happy_path_produces_bundle(self, monkeypatch, tmp_path):
        """When all tiers succeed, a cleaned bundle should be produced."""
        out_path = tmp_path / "claw-full.sqlite"
        state_db = tmp_path / "state.sqlite"

        # Mock tier 1
        monkeypatch.setattr(
            "core.sources.claw.aggregate_claw_skills",
            lambda **kw: [_fake_skill("tier1-skill")],
        )
        # Mock tier 2 — repo discovery + sync
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.aggregate_claw_repos",
            lambda **kw: [],  # no repos → tier 3 skipped
        )
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.sync_repo_state",
            lambda repos, *, state_db: None,
        )

        from core.sources.claw import aggregate_claw_full

        result = aggregate_claw_full(
            max_skills=10,
            out_path=str(out_path),
            state_db=str(state_db),
            version="test",
        )
        result_path = Path(result)
        assert result_path.exists()
        # Verify it's a valid SQLite with skills
        conn = sqlite3.connect(str(result_path))
        try:
            count = conn.execute("SELECT count(*) FROM skills_index").fetchone()[0]
            assert count >= 1
        finally:
            conn.close()

    def test_tier2_failure_degrades_gracefully(self, monkeypatch, tmp_path):
        """When tier 2 fails, pipeline should still produce a bundle from tier 1."""
        out_path = tmp_path / "claw-degraded.sqlite"
        state_db = tmp_path / "state.sqlite"

        monkeypatch.setattr(
            "core.sources.claw.aggregate_claw_skills",
            lambda **kw: [_fake_skill("tier1-only")],
        )
        # Tier 2 raises
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.aggregate_claw_repos",
            lambda **kw: (_ for _ in ()).throw(RuntimeError("tier2 network error")),
        )

        from core.sources.claw import aggregate_claw_full

        result = aggregate_claw_full(
            max_skills=10,
            out_path=str(out_path),
            state_db=str(state_db),
            version="test",
        )
        assert Path(result).exists()
        conn = sqlite3.connect(str(result))
        try:
            count = conn.execute("SELECT count(*) FROM skills_index").fetchone()[0]
            assert count >= 1  # tier 1 skill should still be there
        finally:
            conn.close()

    def test_all_tiers_fail_still_produces_empty_bundle(self, monkeypatch, tmp_path):
        """Even if all collection tiers fail, we should still get a valid (empty) bundle."""
        out_path = tmp_path / "claw-empty.sqlite"
        state_db = tmp_path / "state.sqlite"

        monkeypatch.setattr(
            "core.sources.claw.aggregate_claw_skills",
            lambda **kw: [],  # empty
        )
        # Tier 2 also returns nothing
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.aggregate_claw_repos",
            lambda **kw: [],
        )

        from core.sources.claw import aggregate_claw_full

        result = aggregate_claw_full(
            max_skills=10,
            out_path=str(out_path),
            state_db=str(state_db),
            version="test",
        )
        assert Path(result).exists()
        conn = sqlite3.connect(str(result))
        try:
            tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            assert "skills_index" in tables
        finally:
            conn.close()

    def test_tier3_tuple_unpacked_correctly(self, monkeypatch, tmp_path):
        """Tier 3 returns (skills, stats) tuple — verify it's unpacked correctly."""
        out_path = tmp_path / "claw-tier3.sqlite"
        state_db = tmp_path / "state.sqlite"

        monkeypatch.setattr(
            "core.sources.claw.aggregate_claw_skills",
            lambda **kw: [_fake_skill("from-tier1")],
        )
        # Tier 2 returns repos
        fake_repo = type("FakeRepo", (), {"repo_full_name": "test/repo"})()
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.aggregate_claw_repos",
            lambda **kw: [fake_repo],
        )
        monkeypatch.setattr(
            "core.sources.claw.repo_registry.sync_repo_state",
            lambda repos, *, state_db: None,
        )
        # Tier 3 returns (skills, stats) tuple
        monkeypatch.setattr(
            "core.sources.claw.repo_miner.mine_repo_state",
            lambda **kw: ([_fake_skill("from-tier3")], {"emitted_skills": 1}),
        )

        from core.sources.claw import aggregate_claw_full

        result = aggregate_claw_full(
            max_skills=10,
            out_path=str(out_path),
            state_db=str(state_db),
            version="test",
        )
        assert Path(result).exists()
        conn = sqlite3.connect(str(result))
        try:
            count = conn.execute("SELECT count(*) FROM skills_index").fetchone()[0]
            assert count >= 2  # tier1 + tier3
        finally:
            conn.close()
