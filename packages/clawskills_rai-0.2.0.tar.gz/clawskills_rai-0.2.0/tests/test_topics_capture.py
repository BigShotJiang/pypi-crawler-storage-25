from __future__ import annotations

import json
from pathlib import Path

from core.scripts import topics_capture


def test_topics_capture_profile_skips_llm(monkeypatch, tmp_path: Path):
    repo_root = tmp_path / "repo"
    (repo_root / "core" / "scripts").mkdir(parents=True)
    topics_path = repo_root / "topics.yaml"
    topics_path.write_text("- topic: linux permissions\n  profile: linux\n  tags: [linux]\n", encoding="utf-8")

    monkeypatch.setattr(topics_capture, "__file__", str(repo_root / "core" / "scripts" / "topics_capture.py"))

    seen: dict[str, object] = {}

    def fake_discover_tasks(**kwargs):
        seen["domains"] = list(kwargs.get("domains") or [])
        seen["topic"] = kwargs.get("topic_override")
        seen["tags"] = list(kwargs.get("topic_tags") or [])
        return []

    def fail_create_llm(*args, **kwargs):
        raise AssertionError("LLM should not be created when topic profile is explicit")

    monkeypatch.setattr("core.scripts.runner._discover_tasks", fake_discover_tasks)
    monkeypatch.setattr("core.llm.factory.create_llm_from_env", fail_create_llm)

    queue_path = repo_root / "queue.db"
    rc = topics_capture.cli_topics_capture(["--topics-file", str(topics_path), "--queue", str(queue_path)])

    assert rc == 0
    assert seen == {
        "domains": ["linux"],
        "topic": "linux permissions",
        "tags": ["linux"],
    }
    runs_json = json.loads((repo_root / "runs" / "topics_runs.json").read_text(encoding="utf-8"))
    assert runs_json["queue"] == str(queue_path)
