"""Tests for claw HTTP client and filename validation."""
from __future__ import annotations

from core.sources.claw.http_client import is_valid_skill_filename, is_valid_soul_filename


class TestSkillFilenameValidation:
    def test_exact_skill_md(self):
        assert is_valid_skill_filename("SKILL.md") is True

    def test_path_ending_skill_md(self):
        assert is_valid_skill_filename(".claude/skills/my-skill/SKILL.md") is True

    def test_rejects_noskill(self):
        assert is_valid_skill_filename("skills/weird/NOSKILL.md") is False

    def test_rejects_template(self):
        assert is_valid_skill_filename("templates/SKILL.md.tera") is False

    def test_rejects_backup(self):
        assert is_valid_skill_filename("SKILL.md.backup") is False

    def test_rejects_bak(self):
        assert is_valid_skill_filename("SKILL.md.bak") is False

    def test_rejects_tmpl(self):
        assert is_valid_skill_filename("SKILL.md.tmpl") is False

    def test_rejects_lowercase(self):
        """skill.md (lowercase) is not the standard format."""
        assert is_valid_skill_filename("vue/skill.md") is False

    def test_rejects_tskill(self):
        assert is_valid_skill_filename(".tldr/cache/pages/windows/tskill.md") is False

    def test_agents_path(self):
        assert is_valid_skill_filename(".agents/my-agent/SKILL.md") is True

    def test_cursor_path(self):
        assert is_valid_skill_filename(".cursor/skills/helper/SKILL.md") is True


class TestSoulFilenameValidation:
    def test_exact_soul_md(self):
        assert is_valid_soul_filename("SOUL.md") is True

    def test_path_ending_soul_md(self):
        assert is_valid_soul_filename("agents/my-agent/SOUL.md") is True

    def test_rejects_non_soul(self):
        assert is_valid_soul_filename("NOSOUL.md") is False

    def test_rejects_template(self):
        assert is_valid_soul_filename("SOUL.md.template") is False
