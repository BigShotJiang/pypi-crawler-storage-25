# Sources Audit Report

- run_id: `20260403_025234`
- query: `python`
- generated_at: `2026-04-02T18:53:08.896Z`
- out_dir: `/Users/shatianming/Downloads/clss/ClawSkills/captures/source_audit/20260403_025234`

## Summary

- PASS `playwright` (ok, 4322ms)
- PASS `tavily_search(api)` (skipped, 0ms)
- PASS `arxiv_search` (ok, 1739ms)
- PASS `github_search+readme` (ok, 2859ms)
- PASS `stackoverflow_search+fetch` (ok, 2912ms)
- PASS `webpage_fetch_bulk(http)` (ok, 1850ms)
- PASS `baidu_search(playwright)` (ok, 9668ms)
- PASS `baidu_url_fetch(sample)` (ok, 8819ms)
- FAIL `zhihu_search(playwright)` (needs_auth, 1602ms)
- FAIL `xhs_search(playwright)` (needs_auth, 473ms)
- PASS `zhihu_fetch(sample)` (skipped, 0ms)
- PASS `xhs_fetch(sample)` (skipped, 0ms)

## Details

### playwright

- ok: `True`
- status: `ok`
- duration_ms: `4322`
- details:
  - `playwright_available`: `True`

### tavily_search(api)

- ok: `True`
- status: `skipped`
- duration_ms: `0`
- suggestion: `Set `TAVILY_API_KEY` (or `TAVILY_TOKEN`) to enable Tavily search`

### arxiv_search

- ok: `True`
- status: `ok`
- duration_ms: `1739`
- details:
  - `count`: `5`
  - `duration_ms_inner`: `1739`

### github_search+readme

- ok: `True`
- status: `ok`
- duration_ms: `2859`
- details:
  - `duration_ms_inner`: `2858`
  - `count`: `5`
  - `top_repo`: `{"full_name": "donnemartin/system-design-primer", "url": "https://github.com/donnemartin/system-design-primer", "stars": 341077, "language": "Python"}`
  - `readme_chars`: `6013`

### stackoverflow_search+fetch

- ok: `True`
- status: `ok`
- duration_ms: `2912`
- details:
  - `duration_ms_inner`: `2912`
  - `count`: `5`
  - `fetched_questions`: `5`
  - `fetched_answers`: `50`
  - `answer_picks_ok`: `3`
  - `sample_title`: `What does the &quot;yield&quot; keyword do in Python?`
  - `sample_has_body`: `True`

### webpage_fetch_bulk(http)

- ok: `True`
- status: `ok`
- duration_ms: `1850`
- details:
  - `urls`: `["https://example.com", "https://httpbin.org/html", "https://www.python.org/", "https://www.rfc-editor.org/rfc/rfc2616", "https://docs.python.org/3/"]`
  - `ok_count`: `5`
  - `failures`: `[]`
  - `samples`: `[{"url": "https://example.com", "raw_html_chars": 528, "extracted_text_chars": 149}, {"url": "https://www.python.org/", "raw_html_chars": 11098, "extracted_text_chars": 5527}, {"url": "https://docs.python.org/3/", "raw_html_chars": 17797, "extracted_text_chars": 3764}, {"url": "https://httpbin.org/html", "raw_html_chars": 3739, "extracted_text_chars": 3602}, {"url": "https://www.rfc-editor.org/rfc/rfc2616", "raw_html_chars": 521792, "extracted_text_chars": 386177}]`
  - `duration_ms_inner`: `1850`

### baidu_search(playwright)

- ok: `True`
- status: `ok`
- duration_ms: `9668`
- details:
  - `duration_ms_inner`: `9668`
  - `count`: `5`
  - `sample`: `["http://www.baidu.com/link?url=yI5EHJGtmyeC0jWwzXq-lz0lSncrjCuaCzU2sRcm3vzgd42YEHkilwOdtbXZN3u2", "https://www.baidu.com/baidu.php?url=060000KKXYb9K48fSLl8Ha_JEhzGMHrFzRZi_K6F24KwwIEytV71uAxbK4vKlGoXKtOHaC0ISUk5LdLaaiIWDWMtRQoIgJogdCoAAdGSiSMyd_qTtqGONAVFw1zObnJ_ZnQNITEwrf5VLlq6dLsFaAU80H2IqS4WtGEvoeIwgPJCipUVbM13sXdeqeNfNQtZYmM7nVNGmSnXygKVrE4jnVPm_nNe.7D_NR2Ar5Od663rj6tCphguglyXd5FKenamljLwTVxH1RojPakktX1IER0.U1Yk0ZDqTZ-YpAq80ZKGm1Ys0ZK1pyI85iY0IjdsXgwCUvej4_oRdJo2VogW0A-V5HDYPWD0u1dEugK1nfKdpHdBmy-bIfKspyfqn1T0mv-b5H00UgfqrH0dn7t1nWc3g1DsnHIxnW0dnNtknjD4g1nvnjD0pvbqn0KzIjYVnfKBpHYkPH9xnW0Y0AdW5HbsPHKxn1czr7tknjDLg1csPH7xnH0krNts0Z7spyfqn0Kkmv-b5H00ThIYmyTqn0K8my-b5H00Uh7YTjYs0APdujYYnWbdn1R4PHf0mycqn7ts0ANzu1Ys0ZKs5H00UMus5H08nj0snj0snj00Ugws5H00uAwETjYs0ZFJ5H00uANv5gKW0AuY5H00TA6qn0KET1Ys0AFL5HDs0A4Y5H00TLCq0A71gv-bm1dsTzdMXh410A-bm1dcHbc0TA9YXHY0IA7zuvNY5Hnkg1nkP7tknHD0IZN15HDvnH63Pjm4PjT3nWRdPHnzP1mv0ZF-TgfqnHTLPHDdPHbLnj6dn0KGm1Ys0ZPGujY3mWIWPWIhrj0sPj04nWIh0AP1UHY4PHRdwbRkwRn3nWm3wHNa0AkBT1Ys0A7W5HD0TA3qn0KkUgfqn0KkUgnqn0KlIjYs0AFvujYs0AdWgvuzUvYqn7tsg1Kxn7tsg100uA78IyF-gLK_my4GuZnqnWTsnjDsP1fvg1cLnj0knjTYP-tsg1Kxn7ts0ZK9I7qhUA7M5H00uAPGujYs0ANYpyfqQHD0mgPsmvnqn0KdTA-8mvnqn0KkUymqn0KhmLNY5H00pgPWUjYs0A7buhk9u1Yk0Akhm1Ys0AwWmvfq0Zwzmyw-5H00mhwGujY0UvnqnfKBIjYk0Aq9IZTqn0KEIjYs0AqzTZfqnanscznsc10WnansQW0snj0snanscYwANansczYWna3snj0snj0Wni3snj0snj0Wnansc108nj0snj0sc10Wnansc10Wnansc100mh78pv7Wm1Ysc10Wnans0Z91IZRqPjcdPHRYnj00TNqv5H08nWwxna3sn7tsQW0sg1Dsna3sn7tknj08njKxn7tsQW0zg100mMPxTZFEuA-b5H00ThqGuhk9u1Ys0Ad-IjYs0APv5fKGTdqWTADqn0KWTjYs0AN1IjYs0Z7MIvfqn0KETjDqn0KsTjfqn6KWThnqnHn4P1m&us=newvui&xst=T1Yknj0dnH0znWT3n1c1P163PWR4nNtkPjmkg10KI1dsXgwCUvej4_oRdJo2VogW0gDqTZ-YpAq80gRqPjcdPHRYnj0KIjYkP1TdnHRdrHTk0ydk5H0an0cV0yPC5yuWgLKW0ykd5H0Kmv3qmh7GuZRKTMfqn0DYnWfkPjnsPj6d&word=&ck=0.0.0.0.0.0.0.0&shh=www.baidu.com", "http://www.baidu.com/link?url=I42UvBjNnjETohEGPga_CfqdpTxmihUDClQgbcLRCRDIko-w1FI99xjMiMWldBku1IRB2FvveByrF2nUYMIvmK"]`

### baidu_url_fetch(sample)

- ok: `True`
- status: `ok`
- duration_ms: `8819`
- details:
  - `url`: `http://www.baidu.com/link?url=sz6HDivC8TXXvtOBAqOdULRxe-diPyFInJ5X5q0k-GVPiyH0yfofMBJOZC1EbOow`
  - `final_url`: `http://www.baidu.com/link?url=sz6HDivC8TXXvtOBAqOdULRxe-diPyFInJ5X5q0k-GVPiyH0yfofMBJOZC1EbOow`
  - `used_playwright`: `False`
  - `extracted_text_chars`: `5527`
  - `duration_ms_inner`: `1463`

### zhihu_search(playwright)

- ok: `False`
- status: `needs_auth`
- duration_ms: `1602`
- suggestion: `Run `./.venv/bin/python clawskills_cli.py auth zhihu` once (headed) to persist login`
- details:
  - `duration_ms_inner`: `1602`
  - `count`: `0`
  - `auth`: `{"login_type": "qrcode", "login_ok": false, "requires_headful": true}`
  - `sample`: `[]`
  - `playwright_user_data_dir`: `/Users/shatianming/Downloads/clss/ClawSkills/runs/browser_data/zhihu_user_data_dir`

### xhs_search(playwright)

- ok: `False`
- status: `needs_auth`
- duration_ms: `473`
- suggestion: `Run `./.venv/bin/python clawskills_cli.py auth xhs` once (headed) to persist login`
- details:
  - `duration_ms_inner`: `473`
  - `count`: `0`
  - `auth`: `{"login_type": "qrcode", "login_ok": false, "requires_headful": true}`
  - `sample`: `[]`
  - `playwright_user_data_dir`: `/Users/shatianming/Downloads/clss/ClawSkills/runs/browser_data/xhs_user_data_dir`

### zhihu_fetch(sample)

- ok: `True`
- status: `skipped`
- duration_ms: `0`
- suggestion: `Create `runs/playwright_auth/zhihu_sample_url.txt` to enable fetch sampling.`

### xhs_fetch(sample)

- ok: `True`
- status: `skipped`
- duration_ms: `0`
- suggestion: `Create `runs/playwright_auth/xhs_sample_url.txt` to enable fetch sampling.`
