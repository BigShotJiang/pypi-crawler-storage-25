# Claw Ecosystem Coverage

Updated: 2026-04-03

This note compares the current external OpenClaw / ClawHub ecosystem against
ClawSkills' current in-repo `core/sources/claw` implementation.

## Verdict

ClawSkills now has a **first-class in-repo Claw integration path**.

It now covers:

- official `clawhub.ai` skill directory
- official archived skills repo (`openclaw/skills`) as a dedicated source
- generic GitHub `SKILL.md` discovery across OpenClaw / agent-skill repos
- community awesome skill lists
- community usecase lists
- Chinese community mirrors / curated lists
- a first-class claw repo registry bundle
- incremental repo -> skill / agent mining via tracked `SKILL.md` / `SOUL.md` files
- the ClawSkills main product flow (`clawskills`, `bundle-install`, auto-detect, tests, docs`)

The main remaining gap is external product distribution:

- direct `clawhub install clawskills-search` registry publishing is still documented as upcoming

## Coverage Matrix

| Ecosystem item | External role | Current ClawSkills status | Evidence | Judgment |
| --- | --- | --- | --- | --- |
| `openclaw/openclaw` | Official core product repo | Not a direct ingestion target | Still not ingested directly; ecosystem is captured via directory/archive/lists | Not a source by design |
| `openclaw/clawhub` / `clawhub.ai` | Official skill directory | Dedicated parser exists | `core/sources/claw/clawhub.py` | Covered |
| `openclaw/skills` | Official archived skill versions | Dedicated source adapter exists | `core/sources/claw/openclaw_archive.py` | Covered |
| `VoltAgent/awesome-openclaw-skills` | Major community skill index | Explicit awesome-list source | `_AWESOME_LISTS` in `awesome_parser.py` | Covered |
| `hesamsheikh/awesome-openclaw-usecases` | Major community usecase index | Explicit awesome-list source | `_AWESOME_LISTS` in `awesome_parser.py` | Covered |
| `clawdbot-ai/awesome-openclaw-skills-zh` | Chinese skill mirror/index | Explicit awesome-list source | `_AWESOME_LISTS` in `awesome_parser.py` | Covered |
| `openclaw/*` repos as a searchable ecosystem layer | Core repo discovery surface | Dedicated repo registry aggregator + bundle | `core/sources/claw/repo_registry.py` | Covered |
| Repo-level incremental mining | Controlled freshness / lower search quota usage | State DB + `changed-only` miner | `core/sources/claw/repo_state.py` + `repo_miner.py` | Covered |
| Other current awesome repos found via GitHub search | Community discovery layer | Additional curated lists added plus generic GitHub fallback | `_AWESOME_LISTS` + `github_skills.py` | Mostly covered |

## Current In-Repo Implementation

### Aggregator

The claw aggregator currently enables four source families:

- `clawhub`
- `archive`
- `github`
- `awesome`

See `core/sources/claw/__init__.py`.

### Repo registry layer

ClawSkills now also has a repo-first claw ingestion path:

- `clawskills claw-repo-aggregate`
- `clawskills claw-repo-search`
- `clawskills claw-mine-skills`

This path builds a dedicated claw repo registry bundle, persists repo/file state
in SQLite, and incrementally mines only changed `SKILL.md` / `SOUL.md` files.
It reduces reliance on global GitHub code search and treats repo discovery as a
first-class product surface.

### Official directory coverage

`core/sources/claw/clawhub.py` directly targets:

- `https://clawhub.ai`
- `https://clawhub.ai/api`

It also has a GitHub fallback for ClawHub-related `SKILL.md` repos.

### Official archive coverage

`core/sources/claw/openclaw_archive.py` walks the official
`openclaw/skills` repo tree and fetches archived `SKILL.md` files directly.

### GitHub coverage

The active aggregator path uses `github_skills.py`, which searches for:

- `path:.openclaw/skills filename:SKILL.md`
- `org:openclaw filename:SKILL.md`
- generic `filename:SKILL.md` shards
- OpenClaw / ClawHub keywords

This gives broad discovery on top of the dedicated official archive source.

### Awesome-list coverage

`core/sources/claw/awesome_parser.py` now includes:

- `VoltAgent/awesome-openclaw-skills`
- `hesamsheikh/awesome-openclaw-usecases`
- `clawdbot-ai/awesome-openclaw-skills-zh`
- `AlexAnys/awesome-openclaw-usecases-zh`
- `mergisi/awesome-openclaw-agents`
- `SamurAIGPT/awesome-openclaw`
- `mahseema/awesome-openclaw`
- `Clawdius/awesome-openclaw-3`

## Product Integration Gaps

The remaining product gap is external publication and registry distribution:

- README still says `clawhub install clawskills-search` publish is "coming soon"
- local bundle install is now available via `clawskills bundle-install --domain claw`
- local aggregation is now available via `clawskills claw-aggregate`
- local repo registry + incremental mining are now available via
  `clawskills claw-repo-aggregate`, `claw-repo-search`, and
  `claw-mine-skills`

## Recommended Next Steps

1. Publish the ClawSkills OpenClaw skill to the external ClawHub registry.
2. Decide whether additional awesome repos should be treated as canonical defaults.
3. Decide whether mined claw bundles should be published on a schedule or kept as local artifacts.
