## Current State

- A dedicated claw ecosystem aggregator exists under `core/sources/claw/`.
- It now collects from `clawhub`, the official `openclaw/skills` archive, GitHub `SKILL.md` repos, and curated awesome-lists.
- It converts those sources into the same SQLite bundle shape used by ClawSkills bundles.
- The search layer can search multiple installed bundles, and claw bundles can now be targeted explicitly with `--bundle-name claw`.
- A repo-first claw ingestion path now exists: repo registry bundle, persistent repo/file state, and incremental `changed-only` mining.

## What Is Already Done

- Source collectors:
  - `core/sources/claw/clawhub.py`
  - `core/sources/claw/openclaw_archive.py`
  - `core/sources/claw/github_skills.py`
  - `core/sources/claw/awesome_parser.py`
- Aggregation + bundle build:
  - `core/sources/claw/__init__.py`
- Output format alignment:
  - `core/sources/claw/converter.py`
- First-class product entry points:
  - `clawskills claw-aggregate`
  - `clawskills claw-repo-aggregate`
  - `clawskills claw-repo-search`
  - `clawskills claw-mine-skills`
  - `clawskills bundle-install --domain claw`
  - `clawskills skill-search --bundle-name claw ...`
- Auto-detect + tests:
  - `core/detect_project.py` recognizes claw/openclaw repos
  - claw-focused tests now exist under `tests/`
- Incremental mining state:
  - `core/sources/claw/repo_state.py`
  - `core/sources/claw/repo_miner.py`

## Remaining Gaps

- Direct external Claw Hub registry publication is still not finished.
- README still says the registry publish path is "coming soon".
- If the goal is fully automated upstream freshness, claw bundle refresh is still a local aggregation/build workflow rather than a published remote channel.
- Repo-first mining is now incremental locally, but not yet scheduled/published remotely.

## Minimum Steps To Reach “Externally Complete”

1. Decide the external product boundary.
   - Option A: OpenClaw-only.
   - Option B: broader agent-skill ecosystem including `.claude`, `.agents`, `.openclaw`.
   - Reflect that choice in README, naming, and bundle metadata.

2. Publish the ClawSkills skill and/or bundle to the external Claw Hub registry.
   - Keep `clawskills bundle-install --domain claw` as the local path.
   - Add the hosted registry/distribution path as the public path.

3. Tighten external docs and examples.
   - Replace “coming soon” once the registry publish path is live.
   - Keep one end-to-end example: repo-aggregate -> mine -> install/register -> search.

4. Optional but likely useful: continuous ingestion.
   - If the goal is an always-fresh claw bundle, integrate this source family into the regular refresh/publish workflow instead of leaving it as a one-off script.

## Practical Judgment

- If the question is “does it do more than ClawHub?”: yes.
- If the question is “is claw a first-class, in-repo product feature inside ClawSkills?”: now yes.
- If the question is “is the external Claw Hub registry publication complete?”: not yet.
