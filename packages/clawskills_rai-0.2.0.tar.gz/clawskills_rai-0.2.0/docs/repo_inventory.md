## Tree

- `README.md`: project overview, install, CLI usage, pipeline docs.
- `pyproject.toml`: package metadata and `clawskills` console entrypoint.
- `clawskills_cli.py`: repo-local wrapper; prefers `.venv` Python and dispatches into `core.cli`.
- `core/`: main package.
- `config/`: runtime config and example schedules.
- `bundles/`: local SQLite bundle artifacts used for offline search / distribution.
- `captures/`: auditable runtime output for capture runs.
- `tests/`: pytest smoke and unit tests.
- `.github/workflows/test.yml`: CI matrix for pytest.
- `.github/workflows/publish.yml`: PyPI publish workflow on tags.

## Entry Points

- `clawskills_cli.py`: source checkout entrypoint; re-execs into repo `.venv` when present.
- `core/cli.py`: main argparse surface for `clawskills`.
- `core/scripts/runner.py`: resumable background worker for staged pipeline execution.
- `core/scripts/bundle_install.py`: downloads per-domain SQLite bundles from Hugging Face.
- `core/scripts/build_bundle.py`: builds distributable SQLite bundles from local skills.
- `core/scripts/reindex_skills.py`: rebuilds the searchable library index.
- `core/scripts/topics_capture.py`: batch-enqueues topic lists.
- `core/scripts/arxiv_pipeline.py`: paper-oriented capture pipeline.
- `core/scripts/repo_index.py`, `repo_query.py`, `repo_runbook.py`, `skill_from_repo.py`: repo-understanding and repo-to-skill tooling.

## Core Modules

- `core/sources/`: search/fetch/extract from web, GitHub, arXiv, forums, Zhihu, XHS, etc.
- `core/skills/`: generate, gate, package, publish, and index skill artifacts.
- `core/postprocess/`: dedupe and post-generation cleanup.
- `core/llm/`: provider abstraction for OpenAI-compatible and Ollama backends.
- `core/queue/`: persistent queue settings and storage for background processing.
- `core/repo_understanding/`: static repo indexing, graph building, runbook generation, and LLM-assisted repo synthesis.
- `core/utils/`: shared helpers for hashing, files, markdown, URLs, text, and time.
- `core/config.py`, `core/domain_config.py`, `core/env.py`: runtime config and environment handling.

## Config & Data

- Main config: `config/clawskills.json`.
- Minimal env bootstrap: `.env.example`.
- Required for LLM-backed generation: `OPENAI_API_KEY`, `OPENAI_BASE_URL`.
- Optional integrations: `LLM_PROVIDER`, `OLLAMA_*`, `GITHUB_TOKEN`, `TAVILY_API_KEY`, `HF_ENDPOINT`.
- Bundle install target: `~/.clawskills/` with `search_config.json`.
- Runtime outputs: `captures/<run-id>/...`.
- Search/distribution artifacts: SQLite files under `bundles/` and user-installed bundles under `~/.clawskills/`.
- This repo does not expect a training dataset; it works on fetched evidence sources plus generated skill packages.

## How To Run

```bash
cd ClawSkills
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

```bash
clawskills self-check --skip-remote
clawskills bundle-install --auto
clawskills skill-search "machine learning" --top 3
```

```bash
cp .env.example .env
# fill OPENAI_API_KEY and OPENAI_BASE_URL first
clawskills capture "Docker networking@15"
```

```bash
pytest tests/ -v
```

## Risks / Unknowns

- `config/README.md` still refers to `skill_config.json`, but the repo currently ships `config/clawskills.json`; this looks like stale docs.
- Some README commands describe outputs such as `skills/` and `dist/`, but those directories are not populated in the current checkout.
- Source coverage for Zhihu/XHS depends on Playwright auth state and platform restrictions, so those paths are environment-sensitive.
- No dedicated `docs/` folder existed before this inventory; repo documentation is centered in `README.md` and module READMEs.
