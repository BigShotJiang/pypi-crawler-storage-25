# Contracts

- Generated at: 2026-04-03T04:15:57Z
- Repo root: `/Users/shatianming/Downloads/clss/ClawSkills`

## Environment
- `CLAWSKILLS_NO_VENV_REEXEC`

## Network Touchpoints
- `tests.test_env`
- `tests.test_env.TestNormalizeOpenaiBaseUrl`
- `tests.test_env.TestNormalizeOpenaiBaseUrl.test_appends_v1`
- `tests.test_env.TestNormalizeOpenaiBaseUrl.test_empty`
- `tests.test_env.TestNormalizeOpenaiBaseUrl.test_keeps_existing_v1`
- `tests.test_env.TestNormalizeOpenaiBaseUrl.test_strips_trailing_slash`
- `tests.test_github_skills`
- `tests.test_github_skills.test_crawl_github_skills_respects_search_budget`
- `tests.test_github_skills.test_crawl_github_skills_uses_repo_search_supplement`

## Stable Outputs
- (none detected)

## Entrypoints
- (none detected)
