<div align="center">

# 🦞 ClawSkills

Every agent skill on GitHub — in one install.

**Comprehensive** · **Offline** · **One-command** · **Cross-platform**

<p>
  <a href="https://pypi.org/project/clawskills-rai/"><img alt="PyPI" src="https://img.shields.io/pypi/v/clawskills-rai?style=flat-square&logo=pypi&logoColor=white" /></a>
  <a href="https://www.python.org/downloads/"><img alt="Python 3.10+" src="https://img.shields.io/badge/python-3.10+-3776AB?style=flat-square&logo=python&logoColor=white" /></a>
  <a href="LICENSE"><img alt="MIT License" src="https://img.shields.io/badge/license-MIT-green?style=flat-square" /></a>
  <a href="https://github.com/LabRAI/ClawSkills/stargazers"><img alt="Stars" src="https://img.shields.io/github/stars/LabRAI/ClawSkills?style=flat-square&logo=github" /></a>
</p>

</div>

<p align="center">
  <img src="demo.gif" alt="clawskills install docker-essentials" width="860" />
</p>

We crawled **842 GitHub repos**, [ClawHub](https://clawhub.ai), [OpenClaw](https://github.com/openclaw/openclaw), and 10 awesome lists — extracted every `SKILL.md` and `SOUL.md` — and packaged them into one searchable index. Install once, access all of them.

**125K skills total:**
- **11,389 agent skills** — from 842 repos across `.claude/`, `.cursor/`, `.agents/`, `.openclaw/`, `.codex/`
- **90K research skills** — from arXiv, PMC, PLOS, Nature, eLife
- **24K tech skills** — from GitHub, StackOverflow, web sources

## Quick Start

```bash
pip install clawskills-rai
clawskills bundle-install --domain claw     # one-time: download skill index
clawskills install docker-essentials        # search + install → .claude/skills/
```

Works with **Claude Code**, **Cursor**, **OpenClaw**, **Codex**, and any `--target` path.

## Search Skills

Find skills across the full 125K index:

<p align="center">
  <img src="demo_search.gif" alt="clawskills skill-search kubernetes" width="860" />
</p>

```bash
clawskills skill-search "kubernetes" --top 5
clawskills skill-search "CRISPR" --domain research --top 3
```

## Browse & Install

Preview matches before installing:

<p align="center">
  <img src="demo_browse.gif" alt="clawskills install react --list" width="860" />
</p>

```bash
clawskills install "react" --list          # browse matches
clawskills install "react" --pick 2        # install 2nd result
clawskills install coding-agent            # install best match directly
```

## Real-World Example

Here's what a real installed skill looks like — `docker-essentials` from [Pr-E/openclaw-master-skills](https://github.com/Pr-E/openclaw-master-skills):

```markdown
# Docker Essentials

Essential Docker commands for container and image management.

## Container Lifecycle
docker run -d --name web -p 8080:80 nginx     # run in background
docker exec -it web bash                       # attach to running container
docker stop web && docker rm web               # stop and remove

## Images
docker build -t myapp:latest .                 # build from Dockerfile
docker images --filter dangling=true           # list unused images
docker system prune -af                        # clean up everything
```

This file was installed to `.claude/skills/docker-essentials/SKILL.md` — Claude Code picks it up automatically.

## Full Workflow: Setting Up a New Project

Browse, pick, and install multiple skills in under a minute:

<p align="center">
  <img src="demo_agent.gif" alt="Full workflow: browse → install docker → install react" width="860" />
</p>

1. **Browse** — `clawskills install "docker" --list` to see what's available
2. **Install** — `clawskills install docker-essentials` writes to `.claude/skills/`
3. **Add more** — `clawskills install react-expert` for React patterns
4. **Done** — your agent picks up the new skills on next run

## What's Inside

11,389 agent skills from 842 repos, 93% domain-classified. Updated 2026-04-04.

| Domain | Skills | Examples |
|:--|--:|:--|
| AI & Agents | 4,265 | coding agents, prompt engineering, RAG, MCP servers |
| Web & Apps | 3,877 | React, Vue, REST APIs, Notion, Discord |
| DevTools | 731 | Docker, CI/CD, GitHub Actions, testing |
| Data | 548 | SQL, scraping, API integrations |
| Security | 300 | auth, auditing, triage |
| Linux | 261 | CLI tools, cron, SSH |
| Cloud | 166 | AWS, Azure, Vercel, Terraform |
| Programming | 164 | Python, Go, architecture patterns |

<details>
<summary>Also available: 90K research + 24K tech skills</summary>

```bash
clawskills bundle-install --auto          # auto-detect project type
clawskills skill-search "CRISPR gene editing" --domain research --top 5
```

Research: arXiv (3.5K), PLOS journals (62K across 7 sub-journals), eLife (941), other academic (24K).
Tech: Linux (7.5K), web (6K), programming (4K), devtools (2.2K), security (1.2K), and more.

</details>

<details>
<summary>Where do the skills come from?</summary>

**Agent skills (11,389 after dedup)**

| Source | Skills | How |
|:--|--:|:--|
| [ClawHub](https://clawhub.ai) | 4,293 | Search API + registry page extraction |
| Awesome lists | 5,028 | 10 curated community lists |
| GitHub code search | 1,135 | 19 queries across 6 agent platforms |
| Repo mining (842 repos) | 933 | `SKILL.md` / `SOUL.md` from tracked repos |

**Research skills (90,084)** — PLOS, arXiv, eLife, PMC, Springer, CrossRef

**Tech skills (24,515)** — GitHub repos, StackOverflow, Tavily/Baidu/Zhihu/XHS

</details>

<details>
<summary>Top contributing repos</summary>

| Repo | Files | Type |
|:--|--:|:--|
| `clawdbot/skills` | 7,546 | agent-templates |
| `openclaw/skills` | 7,546 | archive |
| `TravisLeeeeee/awesome-openclaw-personas` | 404 | agent-templates |
| `Pr-E/openclaw-master-skills` | 363 | agent-templates |
| `secondsky/claude-skills` | 208 | skill-collection |

</details>

<details>
<summary>Build the index yourself</summary>

```bash
export GITHUB_TOKEN=<YOUR_GITHUB_TOKEN>
clawskills claw-full-build --max-skills 50000 --max-repos 1000
```

4-tier pipeline (~40 min): ClawHub API → repo discovery → mine files → deduplicate.

</details>

<details>
<summary>Generate new skills with LLM</summary>

```bash
cp .env.example .env  # set OPENAI_API_KEY + OPENAI_BASE_URL
clawskills capture "React Server Components@20"
```

</details>

## Installation

```bash
pip install clawskills-rai
```

No API key needed for searching and installing.

<details>
<summary>From source / environment variables</summary>

```bash
git clone https://github.com/LabRAI/ClawSkills.git && cd ClawSkills
pip install -e ".[dev]"
```

| Variable | Needed for |
|:---|:---|
| `GITHUB_TOKEN` | `claw-full-build` (higher API rate limits) |
| `OPENAI_API_KEY` | `capture` (LLM skill generation) |
| `HF_ENDPOINT` | `bundle-install` in China (`https://hf-mirror.com`) |

</details>

<details>
<summary>FAQ</summary>

**Do I need API keys?** — No. Install and search work fully offline.

**Does it work offline?** — Yes. Everything is local SQLite after `bundle-install`.

**`install` vs `skill-search`?** — `install` writes SKILL.md into your agent directory. `skill-search` just searches.

</details>

<details>
<summary>CLI reference</summary>

| Command | What It Does |
|:---|:---|
| `install "<query>"` | Search + install a skill |
| `install "<query>" --list` | Browse matches |
| `skill-search "<query>"` | Search the full index |
| `claw-full-build` | Build index from scratch |
| `bundle-install --domain claw` | Download pre-built index |
| `capture "<topic>@N"` | Generate skills with LLM |

</details>

## Contributing

[Open an issue](https://github.com/LabRAI/ClawSkills/issues) first for larger changes.

## License

[MIT](LICENSE) — [Responsible AI Lab](https://github.com/LabRAI) @ Florida State University

**Authors:** [Tianming Sha](https://shatianming5.github.io/) · [Yue Zhao](https://viterbi-web.usc.edu/~yzhao010/) · [Lichao Sun](https://lichao-sun.github.io/) · [Yushun Dong](https://yushundong.github.io/)

