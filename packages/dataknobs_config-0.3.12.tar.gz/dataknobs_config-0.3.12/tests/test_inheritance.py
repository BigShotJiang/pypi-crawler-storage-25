"""Tests for configuration inheritance utilities."""

import json
import os
from pathlib import Path

import pytest
import yaml

from dataknobs_config import (
    InheritableConfigLoader,
    InheritanceError,
    RequiredEnvVarError,
    deep_merge,
    load_config_with_inheritance,
    substitute_env_vars,
)


class TestDeepMerge:
    """Test deep_merge utility function."""

    def test_simple_merge(self):
        """Test merging simple dictionaries."""
        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}
        result = deep_merge(base, override)

        assert result == {"a": 1, "b": 3, "c": 4}
        # Original dicts should be unchanged
        assert base == {"a": 1, "b": 2}
        assert override == {"b": 3, "c": 4}

    def test_nested_merge(self):
        """Test merging nested dictionaries."""
        base = {
            "a": 1,
            "nested": {"x": 10, "y": 20},
        }
        override = {
            "nested": {"y": 25, "z": 30},
        }
        result = deep_merge(base, override)

        assert result == {
            "a": 1,
            "nested": {"x": 10, "y": 25, "z": 30},
        }

    def test_deeply_nested_merge(self):
        """Test deeply nested merge."""
        base = {
            "level1": {
                "level2": {
                    "level3": {"a": 1, "b": 2},
                },
            },
        }
        override = {
            "level1": {
                "level2": {
                    "level3": {"b": 3, "c": 4},
                },
            },
        }
        result = deep_merge(base, override)

        assert result["level1"]["level2"]["level3"] == {"a": 1, "b": 3, "c": 4}

    def test_list_replacement(self):
        """Test that lists are replaced, not merged."""
        base = {"items": [1, 2, 3]}
        override = {"items": [4, 5]}
        result = deep_merge(base, override)

        assert result["items"] == [4, 5]

    def test_type_override(self):
        """Test that different types override completely."""
        base = {"value": {"nested": True}}
        override = {"value": "string now"}
        result = deep_merge(base, override)

        assert result["value"] == "string now"

    def test_empty_dicts(self):
        """Test merging with empty dicts."""
        assert deep_merge({}, {"a": 1}) == {"a": 1}
        assert deep_merge({"a": 1}, {}) == {"a": 1}
        assert deep_merge({}, {}) == {}


class TestSubstituteEnvVars:
    """Test environment variable substitution."""

    def test_simple_substitution(self, monkeypatch):
        """Test simple env var substitution."""
        monkeypatch.setenv("TEST_VAR", "hello")

        result = substitute_env_vars({"key": "${TEST_VAR}"})
        assert result["key"] == "hello"

    def test_default_value(self, monkeypatch):
        """Test default value when env var not set."""
        monkeypatch.delenv("MISSING_VAR", raising=False)

        result = substitute_env_vars({"key": "${MISSING_VAR:default}"})
        assert result["key"] == "default"

    def test_required_var_missing(self, monkeypatch):
        """Test error when required var is missing."""
        monkeypatch.delenv("REQUIRED_VAR", raising=False)

        with pytest.raises(ValueError, match="Required environment variable not set"):
            substitute_env_vars({"key": "${REQUIRED_VAR}"})

    def test_nested_substitution(self, monkeypatch):
        """Test substitution in nested structure."""
        monkeypatch.setenv("NESTED_VAR", "nested_value")

        data = {
            "level1": {
                "level2": "${NESTED_VAR}",
            },
        }
        result = substitute_env_vars(data)
        assert result["level1"]["level2"] == "nested_value"

    def test_list_substitution(self, monkeypatch):
        """Test substitution in lists."""
        monkeypatch.setenv("LIST_VAR", "list_value")

        data = {"items": ["${LIST_VAR}", "static"]}
        result = substitute_env_vars(data)
        assert result["items"] == ["list_value", "static"]

    def test_multiple_vars_in_string(self, monkeypatch):
        """Test multiple vars in same string."""
        monkeypatch.setenv("VAR1", "hello")
        monkeypatch.setenv("VAR2", "world")

        result = substitute_env_vars({"key": "${VAR1} ${VAR2}"})
        assert result["key"] == "hello world"

    def test_tilde_expansion(self, monkeypatch):
        """Test home directory tilde expansion."""
        monkeypatch.setenv("PATH_VAR", "~/test")

        result = substitute_env_vars({"path": "${PATH_VAR}"})
        assert "~" not in result["path"]
        assert result["path"].endswith("/test")

    def test_url_with_double_slash_preserved(self, monkeypatch):
        """Bug B4: URLs with :// must not have double-slash collapsed.

        Path(result).expanduser() normalizes path separators, turning
        postgresql://host:5432/db into postgresql:/host:5432/db.
        os.path.expanduser() only expands ~ and leaves URLs intact.
        """
        monkeypatch.setenv("DB_URL", "postgresql://host:5432/db")

        result = substitute_env_vars({"dsn": "${DB_URL}"})
        assert result["dsn"] == "postgresql://host:5432/db"

    def test_url_env_var_substitution_preserves_scheme(self, monkeypatch):
        """Bug B4: Various URL schemes must survive env var substitution."""
        monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")
        monkeypatch.setenv("HTTP_URL", "https://api.example.com/v1")

        result = substitute_env_vars({
            "redis": "${REDIS_URL}",
            "api": "${HTTP_URL}",
        })
        assert result["redis"] == "redis://localhost:6379/0"
        assert result["api"] == "https://api.example.com/v1"

    def test_empty_default(self, monkeypatch):
        """Test empty string as default value."""
        monkeypatch.delenv("EMPTY_DEFAULT", raising=False)

        result = substitute_env_vars({"key": "${EMPTY_DEFAULT:}"})
        assert result["key"] == ""

    def test_non_string_values_unchanged(self):
        """Test that non-string values are unchanged."""
        data = {
            "number": 42,
            "boolean": True,
            "null": None,
            "float": 3.14,
        }
        result = substitute_env_vars(data)
        assert result == data

    def test_dict_key_substitution(self, monkeypatch):
        """Bug B5: Dict keys containing ${VAR} must be substituted."""
        monkeypatch.setenv("TOKEN", "secret-abc-123")

        result = substitute_env_vars({"${TOKEN}": {"role": "admin"}})
        assert "secret-abc-123" in result
        assert "${TOKEN}" not in result
        assert result["secret-abc-123"]["role"] == "admin"

    def test_dict_key_substitution_with_default(self, monkeypatch):
        """Dict keys with default syntax ${VAR:default} must be substituted."""
        monkeypatch.delenv("MISSING_KEY_VAR", raising=False)

        result = substitute_env_vars({"${MISSING_KEY_VAR:fallback}": "value"})
        assert "fallback" in result
        assert result["fallback"] == "value"

    def test_dict_key_non_string_unchanged(self):
        """Non-string dict keys (ints, etc.) pass through unchanged."""
        data = {42: "int-key", True: "bool-key"}
        result = substitute_env_vars(data)
        assert result[42] == "int-key"
        assert result[True] == "bool-key"

    def test_dict_key_substitution_nested(self, monkeypatch):
        """Dict keys at multiple nesting levels must be substituted."""
        monkeypatch.setenv("OUTER_KEY", "outer")
        monkeypatch.setenv("INNER_KEY", "inner")

        data = {"${OUTER_KEY}": {"${INNER_KEY}": "deep_value"}}
        result = substitute_env_vars(data)
        assert result["outer"]["inner"] == "deep_value"

    def test_dict_key_tilde_expansion(self):
        """Tilde expansion via os.path.expanduser applies to dict keys."""
        result = substitute_env_vars({"~/configs": "value"})
        key = next(iter(result))
        assert "~" not in key
        assert key.endswith("/configs")

    # --- Item 109 — bash-superset syntax + new option flags ---

    def test_dash_default_syntax(self, monkeypatch):
        """Bash-style ${VAR:-default} works as alias for ${VAR:default}."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        result = substitute_env_vars({"k": "${MISSING_VAR:-fallback}"})
        assert result == {"k": "fallback"}

    def test_question_mark_error_syntax(self, monkeypatch):
        """Bash-style ${VAR:?msg} raises with the custom message when unset."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        with pytest.raises(
            ValueError, match="Required environment variable not set: DB password is required"
        ):
            substitute_env_vars({"k": "${MISSING_VAR:?DB password is required}"})

    def test_question_mark_uses_var_name_when_msg_empty(self, monkeypatch):
        """${VAR:?} (empty message) raises using the variable name."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        with pytest.raises(
            ValueError, match="Required environment variable not set: MISSING_VAR"
        ):
            substitute_env_vars({"k": "${MISSING_VAR:?}"})

    def test_question_mark_returns_value_when_set(self, monkeypatch):
        """${VAR:?msg} returns the env value when the variable is set."""
        monkeypatch.setenv("PRESENT_VAR", "hello")
        result = substitute_env_vars({"k": "${PRESENT_VAR:?must be set}"})
        assert result == {"k": "hello"}

    def test_type_coerce_int(self, monkeypatch):
        """type_coerce=True returns int when the entire string is a numeric ${VAR}."""
        monkeypatch.setenv("PORT", "5432")
        result = substitute_env_vars({"port": "${PORT}"}, type_coerce=True)
        assert result == {"port": 5432}

    def test_type_coerce_bool(self, monkeypatch):
        """type_coerce=True returns bool for the unambiguous bool words.

        Only ``true``/``false``/``yes``/``no`` (case-insensitive) coerce
        to bool. ``"0"`` / ``"1"`` are tested separately as int to lock
        in that they are NOT treated as booleans (see
        ``test_type_coerce_zero_one_are_int``).
        """
        monkeypatch.setenv("ENABLED", "true")
        monkeypatch.setenv("DISABLED", "false")
        monkeypatch.setenv("YES_VAR", "Yes")
        monkeypatch.setenv("NO_VAR", "NO")
        result = substitute_env_vars(
            {
                "on": "${ENABLED}",
                "off": "${DISABLED}",
                "yes_v": "${YES_VAR}",
                "no_v": "${NO_VAR}",
            },
            type_coerce=True,
        )
        assert result == {"on": True, "off": False, "yes_v": True, "no_v": False}

    def test_type_coerce_zero_one_are_int(self, monkeypatch):
        """${VAR}=='0' and '1' coerce to int, not bool.

        Bash conflates ``"0"`` / ``"1"`` with falsey/truthy, but for
        config values like port / count / size, callers expect an
        integer. ``isinstance(result, bool)`` is False here even though
        ``bool`` is a subclass of ``int`` — the actual type must be
        ``int``.
        """
        monkeypatch.setenv("ZERO", "0")
        monkeypatch.setenv("ONE", "1")
        result = substitute_env_vars(
            {"z": "${ZERO}", "o": "${ONE}"}, type_coerce=True
        )
        assert result == {"z": 0, "o": 1}
        assert type(result["z"]) is int
        assert type(result["o"]) is int

    def test_type_coerce_float(self, monkeypatch):
        """type_coerce=True returns float for numeric strings with a decimal."""
        monkeypatch.setenv("THRESHOLD", "0.95")
        result = substitute_env_vars({"t": "${THRESHOLD}"}, type_coerce=True)
        assert result == {"t": 0.95}

    def test_type_coerce_only_whole_value(self, monkeypatch):
        """type_coerce=True does NOT coerce mixed-content strings."""
        monkeypatch.setenv("PORT", "5432")
        result = substitute_env_vars({"k": "port=${PORT}"}, type_coerce=True)
        assert result == {"k": "port=5432"}  # string, not int

    def test_type_coerce_default_value(self, monkeypatch):
        """type_coerce=True coerces values from defaults too."""
        monkeypatch.delenv("PORT", raising=False)
        result = substitute_env_vars({"port": "${PORT:5432}"}, type_coerce=True)
        assert result == {"port": 5432}

    def test_type_coerce_preserves_string_for_non_numeric(self, monkeypatch):
        """type_coerce=True returns the original string when no coercion applies."""
        monkeypatch.setenv("NAME", "hello")
        result = substitute_env_vars({"name": "${NAME}"}, type_coerce=True)
        assert result == {"name": "hello"}

    def test_expand_user_paths_off(self, monkeypatch):
        """expand_user_paths=False leaves ~ literals intact."""
        monkeypatch.setenv("P", "~/data")
        result = substitute_env_vars(
            {"path": "${P}"}, expand_user_paths=False
        )
        assert result == {"path": "~/data"}

    def test_expand_user_paths_fast_path_tilde(self, monkeypatch, tmp_path):
        """type_coerce=True + expand_user_paths=True (default) expand ~ on the fast path.

        ``_substitute_string`` has two branches: a fast path for whole-value
        ``${VAR}`` placeholders that goes straight from ``_resolve_match``
        through ``os.path.expanduser`` to ``_convert_type``, and a slow
        path that uses ``re.sub`` for mixed-content strings. This test
        exercises the fast path with a tilde-valued env var to confirm
        ``os.path.expanduser`` is applied before type coercion (rather
        than skipped when ``type_coerce`` is on).
        """
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.setenv("P", "~/data")
        result = substitute_env_vars({"path": "${P}"}, type_coerce=True)
        assert result == {"path": str(tmp_path / "data")}

    def test_substitute_keys_off(self, monkeypatch):
        """substitute_keys=False leaves ${VAR}-shaped keys as literals."""
        monkeypatch.setenv("K", "resolved")
        result = substitute_env_vars({"${K}": "v"}, substitute_keys=False)
        assert result == {"${K}": "v"}

    def test_keys_never_type_coerced(self, monkeypatch):
        """Even with type_coerce=True, dict keys remain strings (no int keys)."""
        monkeypatch.setenv("PORT", "5432")
        result = substitute_env_vars({"${PORT}": "v"}, type_coerce=True)
        assert "5432" in result  # string key
        assert 5432 not in result  # never int key

    def test_dash_default_set_value_parity(self, monkeypatch):
        """${VAR:default} and ${VAR:-default} return the env value identically when set."""
        monkeypatch.setenv("VAR", "real")
        legacy = substitute_env_vars({"k": "${VAR:fallback}"})
        bash = substitute_env_vars({"k": "${VAR:-fallback}"})
        assert legacy == bash == {"k": "real"}

    def test_dash_default_literal_dash(self, monkeypatch):
        """${VAR:--} resolves to a literal '-' default when VAR is unset."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        result = substitute_env_vars({"k": "${MISSING_VAR:--}"})
        assert result == {"k": "-"}

    def test_dash_default_with_dash_prefix(self, monkeypatch):
        """${VAR:--default} resolves to literal '-default' when VAR is unset."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        result = substitute_env_vars({"k": "${MISSING_VAR:--flag}"})
        assert result == {"k": "-flag"}

    def test_question_mark_msg_starting_with_colon(self, monkeypatch):
        """${VAR:?:foo} uses ':foo' as the error message when VAR is unset."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        with pytest.raises(
            ValueError, match=r"Required environment variable not set: :foo"
        ):
            substitute_env_vars({"k": "${MISSING_VAR:?:foo}"})

    def test_required_env_var_error_is_public_and_introspectable(self, monkeypatch):
        """RequiredEnvVarError is exposed publicly with usable attributes.

        Callers should be able to ``except RequiredEnvVarError`` directly
        (rather than catching ``ValueError`` and inspecting message text)
        and read ``var_name`` / ``bash_form`` / ``explicit_message`` to
        decide how to handle the failure.
        """
        monkeypatch.delenv("MISSING_VAR", raising=False)

        # Bare ${VAR} — bash_form=False, no explicit message.
        with pytest.raises(RequiredEnvVarError) as bare:
            substitute_env_vars({"k": "${MISSING_VAR}"})
        assert bare.value.var_name == "MISSING_VAR"
        assert bare.value.bash_form is False
        assert bare.value.explicit_message is None

        # ${VAR:?msg} — bash_form=True, message preserved.
        with pytest.raises(RequiredEnvVarError) as bash:
            substitute_env_vars({"k": "${MISSING_VAR:?must be set}"})
        assert bash.value.var_name == "MISSING_VAR"
        assert bash.value.bash_form is True
        assert bash.value.explicit_message == "must be set"

        # ${VAR:?} — bash_form=True, empty message normalized to None.
        with pytest.raises(RequiredEnvVarError) as empty:
            substitute_env_vars({"k": "${MISSING_VAR:?}"})
        assert empty.value.bash_form is True
        assert empty.value.explicit_message is None

        # Subclass relationship: existing ``except ValueError`` keeps working.
        assert issubclass(RequiredEnvVarError, ValueError)


class TestInheritableConfigLoader:
    """Test InheritableConfigLoader class."""

    @pytest.fixture
    def config_dir(self, tmp_path):
        """Create temporary config directory."""
        return tmp_path / "configs"

    @pytest.fixture
    def loader(self, config_dir):
        """Create loader with temp config directory."""
        config_dir.mkdir()
        return InheritableConfigLoader(config_dir)

    def test_load_simple_yaml(self, loader, config_dir):
        """Test loading simple YAML config."""
        config_file = config_dir / "simple.yaml"
        config_file.write_text("""
llm:
  provider: openai
  model: gpt-4
""")

        result = loader.load("simple")
        assert result["llm"]["provider"] == "openai"
        assert result["llm"]["model"] == "gpt-4"

    def test_load_json_config(self, loader, config_dir):
        """Test loading JSON config."""
        config_file = config_dir / "config.json"
        config_file.write_text('{"key": "value", "number": 42}')

        result = loader.load("config")
        assert result["key"] == "value"
        assert result["number"] == 42

    def test_load_yml_extension(self, loader, config_dir):
        """Test loading .yml extension."""
        config_file = config_dir / "config.yml"
        config_file.write_text("key: value")

        result = loader.load("config")
        assert result["key"] == "value"

    def test_config_not_found(self, loader):
        """Test error when config not found."""
        with pytest.raises(InheritanceError, match="not found"):
            loader.load("nonexistent")

    def test_simple_inheritance(self, loader, config_dir):
        """Test simple single-level inheritance."""
        # Create base config
        base_file = config_dir / "base.yaml"
        base_file.write_text("""
llm:
  provider: openai
  model: gpt-4
  temperature: 0.7
""")

        # Create child config
        child_file = config_dir / "child.yaml"
        child_file.write_text("""
extends: base

llm:
  model: gpt-4-turbo
""")

        result = loader.load("child")

        # Should have base values
        assert result["llm"]["provider"] == "openai"
        assert result["llm"]["temperature"] == 0.7
        # Should have overridden value
        assert result["llm"]["model"] == "gpt-4-turbo"
        # extends field should be removed
        assert "extends" not in result

    def test_multi_level_inheritance(self, loader, config_dir):
        """Test multi-level inheritance chain."""
        # Create base
        (config_dir / "base.yaml").write_text("a: 1\nb: 2\nc: 3")

        # Create middle
        (config_dir / "middle.yaml").write_text("extends: base\nb: 20")

        # Create child
        (config_dir / "child.yaml").write_text("extends: middle\nc: 30")

        result = loader.load("child")
        assert result == {"a": 1, "b": 20, "c": 30}

    def test_circular_inheritance_detection(self, loader, config_dir):
        """Test circular inheritance is detected."""
        # Create circular reference
        (config_dir / "a.yaml").write_text("extends: b\nvalue: a")
        (config_dir / "b.yaml").write_text("extends: a\nvalue: b")

        with pytest.raises(InheritanceError, match="Circular inheritance"):
            loader.load("a")

    def test_caching(self, loader, config_dir):
        """Test configuration caching."""
        config_file = config_dir / "cached.yaml"
        config_file.write_text("key: original")

        # First load
        result1 = loader.load("cached")
        assert result1["key"] == "original"

        # Modify file
        config_file.write_text("key: modified")

        # Second load should return cached value
        result2 = loader.load("cached", use_cache=True)
        assert result2["key"] == "original"

        # Load without cache should get new value
        result3 = loader.load("cached", use_cache=False)
        assert result3["key"] == "modified"

    def test_clear_cache(self, loader, config_dir):
        """Test cache clearing."""
        (config_dir / "test.yaml").write_text("key: value")

        loader.load("test")
        assert "test" in loader._cache

        loader.clear_cache("test")
        assert "test" not in loader._cache

    def test_clear_all_cache(self, loader, config_dir):
        """Test clearing all cache."""
        (config_dir / "a.yaml").write_text("key: a")
        (config_dir / "b.yaml").write_text("key: b")

        loader.load("a")
        loader.load("b")
        assert len(loader._cache) == 2

        loader.clear_cache()
        assert len(loader._cache) == 0

    def test_env_var_substitution(self, loader, config_dir, monkeypatch):
        """Test environment variable substitution."""
        monkeypatch.setenv("TEST_VALUE", "from_env")

        config_file = config_dir / "env.yaml"
        config_file.write_text("key: ${TEST_VALUE}")

        result = loader.load("env")
        assert result["key"] == "from_env"

    def test_disable_env_substitution(self, loader, config_dir, monkeypatch):
        """Test disabling env var substitution."""
        monkeypatch.setenv("TEST_VALUE", "from_env")

        config_file = config_dir / "noenv.yaml"
        config_file.write_text("key: ${TEST_VALUE}")

        result = loader.load("noenv", substitute_vars=False)
        assert result["key"] == "${TEST_VALUE}"

    def test_list_available(self, loader, config_dir):
        """Test listing available configurations."""
        (config_dir / "a.yaml").write_text("key: a")
        (config_dir / "b.json").write_text('{"key": "b"}')
        (config_dir / "c.yml").write_text("key: c")

        available = loader.list_available()
        assert "a" in available
        assert "b" in available
        assert "c" in available

    def test_list_available_empty_dir(self, tmp_path):
        """Test listing with empty or missing directory."""
        loader = InheritableConfigLoader(tmp_path / "nonexistent")
        assert loader.list_available() == []

    def test_validate_valid_config(self, loader, config_dir):
        """Test validating a valid config."""
        (config_dir / "valid.yaml").write_text("key: value")

        is_valid, error = loader.validate("valid")
        assert is_valid is True
        assert error is None

    def test_validate_invalid_config(self, loader, config_dir):
        """Test validating an invalid config."""
        (config_dir / "invalid.yaml").write_text("- not a dict")

        is_valid, error = loader.validate("invalid")
        assert is_valid is False
        assert error is not None

    def test_validate_missing_config(self, loader):
        """Test validating a missing config."""
        is_valid, error = loader.validate("missing")
        assert is_valid is False
        assert "not found" in error

    def test_load_from_file(self, loader, tmp_path):
        """Test loading from absolute file path."""
        # Create config outside config_dir
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        config_file = other_dir / "external.yaml"
        config_file.write_text("key: external")

        result = loader.load_from_file(config_file)
        assert result["key"] == "external"

    def test_load_from_file_with_inheritance(self, loader, tmp_path):
        """Test load_from_file resolves inheritance relative to file."""
        other_dir = tmp_path / "other"
        other_dir.mkdir()

        # Create base in other_dir
        (other_dir / "base.yaml").write_text("base_key: base_value")

        # Create child in other_dir
        child_file = other_dir / "child.yaml"
        child_file.write_text("extends: base\nchild_key: child_value")

        result = loader.load_from_file(child_file)
        assert result["base_key"] == "base_value"
        assert result["child_key"] == "child_value"

    def test_load_from_file_not_found(self, loader, tmp_path):
        """Test load_from_file with missing file."""
        with pytest.raises(InheritanceError, match="not found"):
            loader.load_from_file(tmp_path / "missing.yaml")

    def test_invalid_yaml(self, loader, config_dir):
        """Test error on invalid YAML."""
        (config_dir / "invalid.yaml").write_text("key: [unclosed")

        with pytest.raises(InheritanceError, match="Failed to parse"):
            loader.load("invalid")

    def test_invalid_json(self, loader, config_dir):
        """Test error on invalid JSON."""
        (config_dir / "invalid.json").write_text('{"key": invalid}')

        with pytest.raises(InheritanceError, match="Failed to parse"):
            loader.load("invalid")

    def test_non_dict_config(self, loader, config_dir):
        """Test error when config is not a dict."""
        (config_dir / "list.yaml").write_text("- item1\n- item2")

        with pytest.raises(InheritanceError, match="Expected a dict at the root"):
            loader.load("list")

    def test_default_config_dir(self):
        """Test default config directory."""
        loader = InheritableConfigLoader()
        assert loader.config_dir == Path("./configs")

    def test_inheritance_adds_new_fields(self, loader, config_dir):
        """Test that inheritance adds new fields from child."""
        (config_dir / "base.yaml").write_text("existing: value")
        (config_dir / "child.yaml").write_text("extends: base\nnew_field: new_value")

        result = loader.load("child")
        assert result["existing"] == "value"
        assert result["new_field"] == "new_value"


class TestLoadConfigWithInheritance:
    """Test the convenience function."""

    def test_load_config_with_inheritance(self, tmp_path):
        """Test the convenience function."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("key: value")

        result = load_config_with_inheritance(config_file)
        assert result["key"] == "value"

    def test_load_with_inheritance_chain(self, tmp_path):
        """Test convenience function with inheritance."""
        (tmp_path / "base.yaml").write_text("a: 1")
        child_file = tmp_path / "child.yaml"
        child_file.write_text("extends: base\nb: 2")

        result = load_config_with_inheritance(child_file)
        assert result["a"] == 1
        assert result["b"] == 2

    def test_load_without_substitution(self, tmp_path, monkeypatch):
        """Test convenience function without env substitution."""
        monkeypatch.setenv("VAR", "value")

        config_file = tmp_path / "config.yaml"
        config_file.write_text("key: ${VAR}")

        result = load_config_with_inheritance(config_file, substitute_vars=False)
        assert result["key"] == "${VAR}"
