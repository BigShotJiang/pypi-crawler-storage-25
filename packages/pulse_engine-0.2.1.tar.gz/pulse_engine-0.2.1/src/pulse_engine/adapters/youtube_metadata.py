"""YouTube Data API v3 channel metadata adapter."""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any

import httpx
import structlog

from .models import VideoMetadata

logger = structlog.get_logger(__name__)

_YOUTUBE_API_BASE = "https://www.googleapis.com/youtube/v3"
_MAX_PAGE_SIZE = 50

_ISO8601_DURATION_RE = re.compile(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?")


def _parse_duration(duration: str) -> int:
    """Parse an ISO 8601 duration string (e.g. ``PT15M33S``) to seconds."""
    m = _ISO8601_DURATION_RE.search(duration)
    if not m:
        return 0
    hours = int(m.group(1) or 0)
    minutes = int(m.group(2) or 0)
    seconds = int(m.group(3) or 0)
    return hours * 3600 + minutes * 60 + seconds


def _is_live_or_upcoming(video: dict[str, Any]) -> bool:
    lbc = (video.get("snippet") or {}).get("liveBroadcastContent") or "none"
    return lbc in ("live", "upcoming")


class YouTubeMetadataAdapter:
    """Discovers video metadata from a YouTube channel via the Data API v3.

    Mirrors the ``DigitalNewsMetadataAdapter`` interface: construct with
    connection config, call ``fetch()`` to get a list of ``VideoMetadata``.

    Usage::

        adapter = YouTubeMetadataAdapter(
            channel_name="@mkbhd",
            api_key="YOUR_YT_API_KEY",
        )
        videos = await adapter.fetch(since=timedelta(days=7), max_videos=50)
    """

    def __init__(self, channel_name: str, api_key: str) -> None:
        self._channel_name = channel_name
        self._api_key = api_key

    async def fetch(
        self,
        since: timedelta | None = None,
        max_videos: int = 50,
        min_duration_seconds: int = 0,
        skip_live_streams: bool = True,
    ) -> list[VideoMetadata]:
        """Fetch video metadata from the channel.

        Args:
            since: Only return videos published within this window.
            max_videos: Upper bound on videos returned.
            min_duration_seconds: Skip videos shorter than this threshold.
            skip_live_streams: Drop live and scheduled broadcasts.

        Returns:
            List of ``VideoMetadata`` ordered newest-first from the API.
        """
        published_after: str | None = None
        if since is not None:
            cutoff = datetime.now(UTC) - since
            published_after = cutoff.isoformat()

        logger.info(
            "youtube_metadata_fetch_started",
            channel=self._channel_name,
            since=str(since),
            max_videos=max_videos,
        )

        async with httpx.AsyncClient(timeout=30.0) as client:
            channel_id = await self._resolve_channel_id(client)
            playlist_id, channel_info = await self._get_channel_info(client, channel_id)
            video_ids = await self._list_playlist_video_ids(
                client,
                playlist_id,
                max_videos=max_videos,
                published_after=published_after,
            )
            raw_videos = await self._get_video_details(client, video_ids)

        videos = self._apply_filters(
            raw_videos,
            min_duration_seconds=min_duration_seconds,
            skip_live_streams=skip_live_streams,
        )

        result = [self._to_model(v, channel_info) for v in videos]
        logger.info(
            "youtube_metadata_fetch_completed",
            channel=self._channel_name,
            returned=len(result),
        )
        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _resolve_channel_id(self, client: httpx.AsyncClient) -> str:
        """Resolve a channel handle or display name to a channel ID."""
        handle = self._channel_name.lstrip("@")
        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/channels",
            params={"part": "id", "forHandle": handle, "key": self._api_key},
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if items:
            return str(items[0]["id"])

        # Fall back to search by display name.
        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/search",
            params={
                "part": "snippet",
                "type": "channel",
                "q": self._channel_name,
                "maxResults": 1,
                "key": self._api_key,
            },
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if not items:
            raise ValueError(f"YouTube channel not found: '{self._channel_name}'")
        return str(items[0]["snippet"]["channelId"])

    async def _get_channel_info(
        self, client: httpx.AsyncClient, channel_id: str
    ) -> tuple[str, dict[str, Any]]:
        """Fetch uploads playlist ID and channel metadata in one API call."""
        resp = await client.get(
            f"{_YOUTUBE_API_BASE}/channels",
            params={
                "part": "contentDetails,snippet,statistics",
                "id": channel_id,
                "key": self._api_key,
            },
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if not items:
            raise ValueError(f"Channel not found: {channel_id}")
        item = items[0]
        playlist_id = str(item["contentDetails"]["relatedPlaylists"]["uploads"])
        return playlist_id, item

    async def _list_playlist_video_ids(
        self,
        client: httpx.AsyncClient,
        playlist_id: str,
        max_videos: int,
        published_after: str | None,
    ) -> list[str]:
        video_ids: list[str] = []
        page_token: str | None = None

        while len(video_ids) < max_videos:
            page_size = min(_MAX_PAGE_SIZE, max_videos - len(video_ids))
            params: dict[str, Any] = {
                "part": "contentDetails,snippet",
                "playlistId": playlist_id,
                "maxResults": page_size,
                "key": self._api_key,
            }
            if page_token:
                params["pageToken"] = page_token

            resp = await client.get(f"{_YOUTUBE_API_BASE}/playlistItems", params=params)
            resp.raise_for_status()
            data = resp.json()

            for item in data.get("items", []):
                vid_id = item["contentDetails"]["videoId"]
                if published_after:
                    published = item["snippet"].get("publishedAt", "")
                    if published < published_after:
                        # Playlist is newest-first; older video means we're done.
                        return video_ids
                video_ids.append(vid_id)

            page_token = data.get("nextPageToken")
            if not page_token:
                break

        return video_ids

    async def _get_video_details(
        self, client: httpx.AsyncClient, video_ids: list[str]
    ) -> list[dict[str, Any]]:
        if not video_ids:
            return []
        details: list[dict[str, Any]] = []
        for i in range(0, len(video_ids), _MAX_PAGE_SIZE):
            batch = video_ids[i : i + _MAX_PAGE_SIZE]
            resp = await client.get(
                f"{_YOUTUBE_API_BASE}/videos",
                params={
                    "part": "snippet,contentDetails,statistics",
                    "id": ",".join(batch),
                    "key": self._api_key,
                },
            )
            resp.raise_for_status()
            details.extend(resp.json().get("items", []))
        return details

    def _apply_filters(
        self,
        videos: list[dict[str, Any]],
        min_duration_seconds: int,
        skip_live_streams: bool,
    ) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for v in videos:
            if skip_live_streams and _is_live_or_upcoming(v):
                continue
            if min_duration_seconds > 0:
                details = v.get("contentDetails", {})
                dur = _parse_duration(details.get("duration", "PT0S"))
                if dur < min_duration_seconds:
                    continue
            result.append(v)
        return result

    @staticmethod
    def _to_model(v: dict[str, Any], channel_info: dict[str, Any]) -> VideoMetadata:
        snippet = v["snippet"]
        pub_at = datetime.fromisoformat(snippet["publishedAt"].replace("Z", "+00:00"))
        thumbnails = snippet.get("thumbnails", {})
        thumbnail_url = (
            (thumbnails.get("maxres") or thumbnails.get("high") or thumbnails.get("medium") or {})
            .get("url")
        )
        ch_snippet = channel_info.get("snippet", {})
        ch_stats = channel_info.get("statistics", {})
        ch_created_raw = ch_snippet.get("publishedAt")
        ch_created_at = (
            datetime.fromisoformat(ch_created_raw.replace("Z", "+00:00"))
            if ch_created_raw
            else None
        )
        return VideoMetadata(
            video_id=v["id"],
            url=f"https://www.youtube.com/watch?v={v['id']}",
            title=snippet["title"],
            channel_id=snippet["channelId"],
            channel_name=snippet["channelTitle"],
            published_at=pub_at,
            description=snippet.get("description", ""),
            tags=snippet.get("tags", []),
            duration_seconds=_parse_duration(
                v.get("contentDetails", {}).get("duration", "PT0S")
            ),
            view_count=v.get("statistics", {}).get("viewCount"),
            like_count=v.get("statistics", {}).get("likeCount"),
            comment_count=v.get("statistics", {}).get("commentCount"),
            thumbnail_url=thumbnail_url,
            channel_subscriber_count=ch_stats.get("subscriberCount"),
            channel_video_count=ch_stats.get("videoCount"),
            channel_description=ch_snippet.get("description"),
            channel_custom_url=ch_snippet.get("customUrl"),
            channel_country=ch_snippet.get("country"),
            channel_created_at=ch_created_at,
        )
