"""OpenSearchStorageAdapter — upsert documents into an OpenSearch index.

Schema (index name, field mappings, id field) is defined at call time so
products can configure it entirely from pipeline.yaml args.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Maps pipeline.yaml type names → OpenSearch mapping types
_TYPE_MAP: dict[str, dict[str, Any]] = {
    "text": {"type": "text"},
    "keyword": {"type": "keyword"},
    "date": {"type": "date"},
    "integer": {"type": "integer"},
    "long": {"type": "long"},
    "float": {"type": "float"},
    "boolean": {"type": "boolean"},
    "object": {"type": "object", "enabled": False},  # stored but not indexed
}


class OpenSearchStorageAdapter:
    """Upsert documents into an OpenSearch index.

    Args:
        url: OpenSearch endpoint URL.
        username: HTTP basic auth username (optional).
        password: HTTP basic auth password (optional).
        use_ssl: Whether to use SSL. Default True.
        verify_certs: Whether to verify SSL certificates. Default True.
        index_prefix: Prefix prepended to index name. Default "".

    Usage::

        adapter = OpenSearchStorageAdapter(url="https://...")
        await adapter.ensure_index(
            index="pulse_videos",
            id_field="video_id",
            mappings={"video_id": "keyword", "title": "text", ...},
        )
        result = await adapter.upsert_batch(
            index="pulse_videos",
            id_field="video_id",
            documents=[{"video_id": "abc", "title": "...", ...}],
        )
    """

    def __init__(
        self,
        url: str,
        username: str = "",
        password: str = "",
        use_ssl: bool = True,
        verify_certs: bool = True,
        index_prefix: str = "",
    ) -> None:
        self._url = url.rstrip("/")
        self._username = username
        self._password = password
        self._use_ssl = use_ssl
        self._verify_certs = verify_certs
        self._index_prefix = index_prefix

    def _client(self) -> Any:
        from opensearchpy import AsyncOpenSearch

        kwargs: dict[str, Any] = {
            "hosts": [self._url],
            "use_ssl": self._use_ssl,
            "verify_certs": self._verify_certs,
        }
        if self._username and self._password:
            kwargs["http_auth"] = (self._username, self._password)
        return AsyncOpenSearch(**kwargs)

    def _index_name(self, index: str) -> str:
        return f"{self._index_prefix}{index}" if self._index_prefix else index

    @staticmethod
    def _build_properties(mappings: dict[str, str]) -> dict[str, Any]:
        properties: dict[str, Any] = {}
        for field, type_name in mappings.items():
            properties[field] = _TYPE_MAP.get(type_name, {"type": "keyword"})
        return properties

    async def ensure_index(
        self,
        index: str,
        id_field: str,
        mappings: dict[str, str],
    ) -> None:
        """Create index with mappings if it doesn't exist."""
        name = self._index_name(index)
        body = {
            "settings": {"number_of_shards": 1, "number_of_replicas": 1},
            "mappings": {"properties": self._build_properties(mappings)},
        }
        async with self._client() as client:
            exists = await client.indices.exists(index=name)
            if not exists:
                await client.indices.create(index=name, body=body)
                logger.info("Created OpenSearch index '%s'", name)
            else:
                logger.debug("OpenSearch index '%s' already exists", name)

    async def upsert_batch(
        self,
        index: str,
        id_field: str,
        documents: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Bulk upsert documents. Uses id_field value as document _id.

        Returns:
            {"indexed": N, "errors": [...]}
        """
        from opensearchpy.helpers import async_bulk

        name = self._index_name(index)
        actions = [
            {
                "_op_type": "index",
                "_index": name,
                "_id": str(doc[id_field]),
                "_source": doc,
            }
            for doc in documents
            if doc.get(id_field)
        ]

        skipped = len(documents) - len(actions)
        if skipped:
            logger.warning(
                "Skipped %d documents missing id_field '%s'", skipped, id_field
            )

        errors: list[Any] = []
        async with self._client() as client:
            success, failed = await async_bulk(
                client, actions, raise_on_error=False, stats_only=False
            )
            failed_list: list[Any] = failed if isinstance(failed, list) else []
            if failed_list:
                errors = failed_list
                logger.warning("OpenSearch bulk errors: %d failed", len(failed_list))

        logger.info("Upserted %d documents to index '%s'", success, name)
        return {"indexed": success, "errors": errors}

    async def store(
        self,
        index: str,
        id_field: str,
        mappings: dict[str, str],
        documents: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Ensure index exists then upsert all documents."""
        await self.ensure_index(index=index, id_field=id_field, mappings=mappings)
        return await self.upsert_batch(
            index=index, id_field=id_field, documents=documents
        )
