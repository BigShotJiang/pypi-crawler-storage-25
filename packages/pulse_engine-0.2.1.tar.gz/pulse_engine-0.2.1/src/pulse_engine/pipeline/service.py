from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pulse_engine.pipeline.models import PipelineRunModel
from pulse_engine.pipeline.repositories import (
    ModuleRegistryRepository,
    PipelineRunRepository,
    PipelineStepRunRepository,
)
from pulse_engine.pipeline.schemas import PipelineConfig, StepStatus
from pulse_engine.pipeline.translators.base import (
    BaseStatusProvider,
    BaseTranslator,
    PipelineStatus,
)


class PipelineServiceError(Exception):
    pass


class PipelineSubmissionError(PipelineServiceError):
    pass


class PipelineService:
    def __init__(
        self,
        module_repo: ModuleRegistryRepository,
        run_repo: PipelineRunRepository,
        translators: dict[str, BaseTranslator],
        status_providers: dict[str, BaseStatusProvider],
        settings: Any,
        token_issuer: Any,
        step_repo: PipelineStepRunRepository | None = None,
    ) -> None:
        self._module_repo = module_repo
        self._run_repo = run_repo
        self._translators = translators
        self._status_providers = status_providers
        self._settings = settings
        self._token_issuer = token_issuer
        self._step_repo = step_repo

    async def trigger(
        self,
        tenant_id: str,
        product: str,
        orchestrator: str,
        config: PipelineConfig,
        global_config: dict[str, Any],
    ) -> str:
        """Trigger a pipeline. Returns the pipeline run ID."""
        # Validate orchestrator
        if orchestrator not in self._translators:
            raise PipelineServiceError(f"Unsupported orchestrator: '{orchestrator}'")

        # Resolve module images
        images = await self._module_repo.get_images_map(tenant_id, product)
        missing = [m.name for m in config.modules if m.module not in images]
        if missing:
            raise PipelineServiceError(
                f"Modules not registered for product '{product}': {missing}"
            )

        # Create pipeline run record
        run = await self._run_repo.create(
            tenant_id=tenant_id,
            product=product,
            orchestrator=orchestrator,
            config_snapshot=config.model_dump(mode="json", by_alias=True),
            global_config=global_config,
        )

        # Issue run-scoped token
        token = self._token_issuer.issue_token(
            pipeline_run_id=run.id,
            tenant_id=tenant_id,
        )

        # Submit to orchestrator
        translator = self._translators[orchestrator]
        try:
            orchestrator_run_id = await translator.submit(
                pipeline_run_id=run.id,
                parsed_config=config,
                module_images=images,
                global_config=global_config,
                tenant_id=tenant_id,
                pulse_engine_url=self._settings.pulse_engine_url,
                pulse_api_token=token,
            )
        except Exception as e:
            await self._run_repo.update_status(run.id, "submission_failed")
            raise PipelineSubmissionError(
                f"Failed to submit pipeline to {orchestrator}: {e}"
            ) from e

        await self._run_repo.set_orchestrator_run_id(run.id, orchestrator_run_id)
        await self._run_repo.update_status(run.id, "running")
        return run.id

    async def get_run(self, tenant_id: str, run_id: str) -> PipelineRunModel | None:
        """Get a pipeline run record."""
        return await self._run_repo.get(run_id, tenant_id)

    async def get_status(self, tenant_id: str, run_id: str) -> PipelineStatus | None:
        """Get normalized pipeline status, merging DB step records as fallback."""
        run = await self._run_repo.get(run_id, tenant_id)
        if run is None:
            return None

        # Load DB-persisted step records for merge / fallback
        db_steps: list[StepStatus] = []
        if self._step_repo is not None:
            rows = await self._step_repo.list_by_run(run_id, tenant_id)
            db_steps = [
                StepStatus(
                    step=r.step_name,
                    module=r.module_type,
                    status=r.status,
                    started_at=r.started_at,
                    completed_at=r.completed_at,
                    error_message=r.error_message,
                    output_ref=r.output_ref,
                )
                for r in rows
            ]

        if run.orchestrator_run_id is None:
            return PipelineStatus(status=run.status, steps=db_steps)

        provider = self._status_providers.get(run.orchestrator)
        if provider is None:
            return PipelineStatus(status=run.status, steps=db_steps)

        try:
            status = await provider.get_status(run.orchestrator_run_id)
        except Exception:
            # Orchestrator unreachable — serve from DB
            return PipelineStatus(status=run.status, steps=db_steps)

        # Merge: enrich orchestrator steps with DB fields (error_message, output_ref)
        db_map = {s.step: s for s in db_steps}
        merged: list[StepStatus] = []
        for s in status.steps:
            db = db_map.get(s.step)
            if db is not None:
                merged.append(
                    StepStatus(
                        step=s.step,
                        module=s.module,
                        status=s.status,
                        fan_out_count=s.fan_out_count,
                        completed_count=s.completed_count,
                        failed_count=s.failed_count,
                        started_at=s.started_at or db.started_at,
                        completed_at=db.completed_at,
                        error_message=db.error_message,
                        output_ref=db.output_ref,
                    )
                )
            else:
                merged.append(s)

        # Add DB-only steps not returned by orchestrator (e.g. after purge)
        orchestrator_step_names = {s.step for s in status.steps}
        for s in db_steps:
            if s.step not in orchestrator_step_names:
                merged.append(s)

        status.steps = merged

        # Cache top-level status
        if status.status != run.status:
            await self._run_repo.update_status(run_id, status.status)

        return status

    async def record_step_status(
        self,
        tenant_id: str,
        run_id: str,
        step_name: str,
        status: str,
        output_ref: dict[str, Any] | list[Any] | None = None,
        error_message: str | None = None,
    ) -> None:
        """Persist a step status callback from the orchestrator runner."""
        run = await self._run_repo.get(run_id, tenant_id)
        if run is None or self._step_repo is None:
            return

        now = datetime.now(tz=UTC)
        started_at = now if status == "running" else None
        completed_at = now if status in {"completed", "failed"} else None

        # Derive module_type from config snapshot if possible
        module_type = ""
        dag = run.config_snapshot.get("dag", [])
        for step in dag:
            base_name = step_name.split("[")[0]
            if step.get("step") == base_name:
                module_type = step.get("module_type") or step.get("module", "")
                break

        await self._step_repo.upsert(
            pipeline_run_id=run_id,
            tenant_id=tenant_id,
            step_name=step_name,
            module_type=module_type,
            status=status,
            started_at=started_at,
            completed_at=completed_at,
            error_message=error_message,
            output_ref=output_ref,
        )

    async def cancel(self, tenant_id: str, run_id: str) -> bool:
        """Cancel a running pipeline."""
        run = await self._run_repo.get(run_id, tenant_id)
        if run is None:
            return False

        if run.orchestrator_run_id is None:
            await self._run_repo.update_status(run_id, "cancelled")
            return True

        provider = self._status_providers.get(run.orchestrator)
        if provider is None:
            return False

        result = await provider.cancel(run.orchestrator_run_id)
        if result:
            await self._run_repo.update_status(run_id, "cancelled")
        return result

    async def list_runs(
        self,
        tenant_id: str,
        product: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[PipelineRunModel], int]:
        return await self._run_repo.list_runs(
            tenant_id, product=product, status=status, limit=limit, offset=offset
        )
