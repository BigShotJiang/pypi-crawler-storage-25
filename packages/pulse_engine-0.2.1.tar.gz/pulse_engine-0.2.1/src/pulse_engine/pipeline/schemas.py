from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class SecretRef(BaseModel):
    from_secret: str  # AWS Secrets Manager ARN or name


class ResultsBackendConfig(BaseModel):
    type: Literal["s3"] = "s3"
    bucket: str | None = None  # overrides PULSE_S3_BUCKET engine setting
    prefix: str = "pipeline-runs/"


_VCPU_TO_ECS_UNITS: dict[float, int] = {
    0.25: 256,
    0.5: 512,
    1.0: 1024,
    2.0: 2048,
    4.0: 4096,
}


class ResourceConfig(BaseModel):
    compute: Literal["ecs", "lambda"] | None = Field(
        default=None,
        description="Compute backend. None = inherit infra.default_compute.",
    )
    vCPU: float = Field(
        default=0.25,
        description="vCPU units. Allowed: 0.25, 0.5, 1, 2, 4.",
    )
    memory: int = Field(default=512, gt=0, description="MB")
    storage: int | None = Field(
        default=None, gt=0, description="GB ephemeral storage (ECS only)"
    )

    @field_validator("vCPU")
    @classmethod
    def validate_vcpu(cls, v: float) -> float:
        if v not in _VCPU_TO_ECS_UNITS:
            allowed = ", ".join(str(k) for k in _VCPU_TO_ECS_UNITS)
            raise ValueError(f"vCPU must be one of {allowed}, got {v}")
        return v

    @property
    def ecs_cpu_units(self) -> int:
        return _VCPU_TO_ECS_UNITS[self.vCPU]


class ModuleConfig(BaseModel):
    name: str
    module: str  # module type → MODULE_NAME env var in container
    retries: int = Field(default=0, ge=0)
    retry_delay: int = Field(default=0, ge=0, description="Seconds between retries")
    timeout: int = Field(
        default=3600, gt=0, description="Seconds before container killed"
    )
    max_concurrency: int | None = Field(
        default=None, gt=0, description="Max parallel fan-out tasks (None = unlimited)"
    )
    resources: ResourceConfig = Field(default_factory=ResourceConfig)
    args: dict[str, Any] = Field(default_factory=dict)
    env: dict[str, str | SecretRef] = Field(default_factory=dict)


class DependsOnRef(BaseModel):
    step: str


class StepConfig(BaseModel):
    step: str
    module: str  # references ModuleConfig.name
    for_each: str | None = None  # expression: $args.X, $steps.S.output[.F], $collect.F
    collect_from: str | list[str] | None = None  # step name(s) to collect from
    when: str | None = None  # boolean expression; item-level if $item.* present
    trigger_rule: (
        Literal[
            "all_success",
            "all_done",
            "all_skipped",
            "one_succeeded",
            "one_failed",
            "none_failed",
            "none_skipped",
        ]
        | None
    ) = None  # default: all_success
    depends_on: list[DependsOnRef] | None = None  # explicit side-effect deps


class InfraConfig(BaseModel):
    orchestrator: Literal["prefect"] = "prefect"
    default_compute: Literal["ecs", "lambda"] = "ecs"
    schedule: str | None = None  # cron string — passed to Prefect deployment schedules
    results_backend: ResultsBackendConfig = Field(default_factory=ResultsBackendConfig)


class PipelineConfig(BaseModel):
    name: str
    pipeline: str | None = None  # pipeline identifier; defaults to name if omitted
    version: str = "2.0"
    infra: InfraConfig = Field(default_factory=InfraConfig)
    modules: list[ModuleConfig]
    dag: list[StepConfig]
    config: dict[str, Any] = Field(default_factory=dict)

    @property
    def deployment_name(self) -> str:
        """Unique Prefect deployment name: product[-pipeline]."""
        suffix = self.pipeline or self.name
        if suffix == self.name:
            return self.name
        return f"{self.name}-{suffix}"

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        if v != "2.0":
            raise ValueError(
                f"Unsupported pipeline version {v!r}. Only '2.0' supported."
            )
        return v


# ---------------------------------------------------------------------------
# API Request / Response Schemas  (unchanged from v1)
# ---------------------------------------------------------------------------


class ModuleImageDef(BaseModel):
    image: str


class TriggerPayload(BaseModel):
    product: str | None = None
    orchestrator: Literal["prefect"] | None = None


class PipelineRunStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"
    submission_failed = "submission_failed"


class StepStatus(BaseModel):
    step: str
    module: str
    status: str
    fan_out_count: int | None = None
    completed_count: int | None = None
    failed_count: int | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error_message: str | None = None
    output_ref: dict[str, Any] | list[Any] | None = None


class StepStatusUpdate(BaseModel):
    status: str
    output_ref: dict[str, Any] | list[Any] | None = None
    error_message: str | None = None


class PipelineStatusResponse(BaseModel):
    run_id: str
    product: str
    orchestrator: str
    status: PipelineRunStatus
    started_at: datetime | None = None
    steps: list[StepStatus] = Field(default_factory=list)


class TriggerResponse(BaseModel):
    run_id: str


class RegisterModulesRequest(BaseModel):
    product: str
    modules: dict[str, ModuleImageDef]


class RegisterModulesResponse(BaseModel):
    product: str
    modules: dict[str, dict[str, str]]


class PipelineRunListResponse(BaseModel):
    items: list[PipelineStatusResponse]
    total: int
    limit: int
    offset: int
