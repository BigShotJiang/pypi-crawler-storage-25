"""STEM BIO-AI local audit CLI."""

__version__ = "1.6.2"
