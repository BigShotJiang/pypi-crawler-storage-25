from typing import TYPE_CHECKING

from django.db import models
from django.utils import timezone

from whitebox.utils import get_plugin_logger
from utils.models import TimestampedModel
from .manager import device_manager
from .consts import device_type_2_icon_url_map


if TYPE_CHECKING:
    from .base import Device


logger = get_plugin_logger(__name__)


class ConnectionStatus(models.TextChoices):
    CONNECTING = "connecting", "Connecting"
    CONNECTED = "connected", "Connected"
    DISCONNECTING = "disconnecting", "Disconnecting"
    DISCONNECTED = "disconnected", "Disconnected"
    FAILED = "failed", "Failed"


class DeviceReachability(models.TextChoices):
    UNKNOWN = "unknown", "Unknown"
    HEALTHY = "healthy", "Healthy"
    UNAVAILABLE = "unavailable", "Unavailable"


class DeviceConnection(TimestampedModel):
    # Allow easier external access
    ConnectionStatus = ConnectionStatus
    DeviceReachability = DeviceReachability

    name = models.CharField(max_length=128, unique=True)
    codename = models.CharField(max_length=128)

    connection_type = models.CharField(max_length=128)
    connection_settings = models.JSONField()

    connection_status = models.CharField(
        max_length=20,
        choices=ConnectionStatus.choices,
        default=ConnectionStatus.DISCONNECTED,
    )
    last_connection_attempt = models.DateTimeField(null=True, blank=True)
    last_successful_connection = models.DateTimeField(null=True, blank=True)
    connection_error_message = models.TextField(blank=True, default="")
    device_reachability = models.CharField(
        max_length=20,
        choices=DeviceReachability.choices,
        default=DeviceReachability.UNKNOWN,
    )

    def __str__(self):
        return "{} ({})".format(self.name, self.codename)

    def get_device_class(self) -> type["Device"]:
        try:
            return device_manager.get_device_class(self.codename)
        except ValueError:
            return None

    def get_device_type_icon_url(self):
        device_class = self.get_device_class()
        if not device_class:
            return None

        return device_type_2_icon_url_map.get(device_class.device_type)

    def update_connection_status(
        self,
        status: ConnectionStatus,
        error_message: str = "",
    ):
        """
        Update the connection status and related timestamps.
        """
        old_status = self.connection_status
        self.connection_status = status
        self.last_connection_attempt = timezone.now()

        if status == ConnectionStatus.CONNECTED:
            self.last_successful_connection = timezone.now()
            self.connection_error_message = ""
        elif status == ConnectionStatus.FAILED:
            self.connection_error_message = error_message

        self.save(
            update_fields=[
                "connection_status",
                "last_connection_attempt",
                "last_successful_connection",
                "connection_error_message",
            ]
        )

        if status == ConnectionStatus.FAILED and error_message:
            logger.info(
                "Device connection status transition id=%s name=%s codename=%s old_status=%s new_status=%s failure_reason=%s",
                self.pk,
                self.name,
                self.codename,
                old_status,
                status,
                error_message,
            )
            return

        logger.info(
            "Device connection status transition id=%s name=%s codename=%s old_status=%s new_status=%s",
            self.pk,
            self.name,
            self.codename,
            old_status,
            status,
        )

    def update_device_reachability(self, reachability: DeviceReachability):
        old_reachability = self.device_reachability
        self.device_reachability = reachability
        self.save(update_fields=["device_reachability"])

        logger.info(
            "Device reachability transition id=%s name=%s codename=%s old_reachability=%s new_reachability=%s",
            self.pk,
            self.name,
            self.codename,
            old_reachability,
            reachability,
        )

    @property
    def is_wifi_connection(self) -> bool:
        """
        Check if this is a Wi-Fi-based connection.
        """
        return self.connection_type == "wifi"

    @property
    def wifi_ssid(self) -> str:
        """
        Get the Wi-Fi SSID from connection settings.
        """
        if self.is_wifi_connection:
            return self.connection_settings.get("ssid", "")
        return ""

    @property
    def wifi_password(self) -> str:
        """
        Get the Wi-Fi password from connection settings.
        """
        if self.is_wifi_connection:
            return self.connection_settings.get("password", "")
        return ""

    def delete(self, *args, **kwargs):
        """
        Override delete to clean up Wi-Fi interface assignments.
        """
        if self.is_wifi_connection:
            from .networking.wireless_interface_manager import (
                wireless_interface_manager,
            )

            wireless_interface_manager.release_interface_from_device(self.id)
        super().delete(*args, **kwargs)
