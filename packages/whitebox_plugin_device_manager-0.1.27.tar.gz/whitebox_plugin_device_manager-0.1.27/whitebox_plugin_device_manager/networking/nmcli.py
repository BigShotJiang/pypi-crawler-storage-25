import logging
import re
import collections

from types import SimpleNamespace

from whitebox.api import API


logger = logging.getLogger(__name__)


_NAMEDTUPLE_CACHE = {}
_RE_SPLIT_UNESCAPED_COLON = re.compile(r"(?<!\\):")


def _redact_command(command: list[str]) -> list[str]:
    sensitive_tokens = {"password", "passphrase", "secret", "token"}
    redacted = []
    redact_next = False

    for part in command:
        if redact_next:
            redacted.append("<redacted>")
            redact_next = False
            continue

        token, separator, _ = part.partition("=")
        if token in sensitive_tokens:
            if separator:
                redacted.append(f"{token}=<redacted>")
            else:
                redacted.append(part)
                redact_next = True
            continue

        redacted.append(part)

    return redacted


def _format_command(command: list[str]) -> str:
    return " ".join(_redact_command(command))


def _get_namedtuple(field_names: list[str]):
    typename = "NmcliResult"
    field_names = [
        name.lower().replace(" ", "_").replace("-", "_") for name in field_names
    ]

    lookup_key = (typename, tuple(field_names))

    if lookup_key not in _NAMEDTUPLE_CACHE:
        _NAMEDTUPLE_CACHE[lookup_key] = collections.namedtuple(
            typename,
            field_names,
        )

    return _NAMEDTUPLE_CACHE[lookup_key]


class NmcliError(Exception):
    """Exception raised for errors in nmcli operations."""

    pass


class NmcliTimeout(NmcliError):
    """Exception raised when nmcli command times out."""

    pass


class NmcliNonZeroExit(NmcliError):
    """Exception raised when nmcli returns a non-zero exit code."""

    def __init__(self, result):
        self.result = result
        self.returncode = result.returncode

        super().__init__(
            f"nmcli exited with code {self.returncode}\n"
            f"stderr: {result.stderr.strip()}",
        )

    @classmethod
    def check(cls, result):
        if result.returncode != 0:
            raise cls(result)


def _make_result(command: list[str], execute_result: dict):
    if not isinstance(execute_result, dict):
        raise NmcliError(f"nmcli command failed: {_format_command(command)}")

    status = execute_result.get("status")
    if status not in {"success", "error", "timeout"}:
        raise NmcliError(f"nmcli command failed: {_format_command(command)}")

    returncode = execute_result.get("return_code")
    if not isinstance(returncode, int):
        raise NmcliError(f"nmcli command failed: {_format_command(command)}")

    stdout = execute_result.get("stdout", "")
    stderr = execute_result.get("stderr", "")
    if not isinstance(stdout, str):
        stdout = "" if stdout is None else str(stdout)
    if not isinstance(stderr, str):
        stderr = "" if stderr is None else str(stderr)

    return status, SimpleNamespace(
        args=command,
        returncode=returncode,
        stdout=stdout,
        stderr=stderr,
    )


def run_command(
    nmcli_input: list[str],
    *,
    parse_fields: list[str] = None,
    capture_output=True,
    text=True,
    timeout=10,
):
    command = ["nmcli"]

    # nmcli requires fields to be specified at the beginning of the command
    if parse_fields:
        parse_fields = [f.upper() for f in parse_fields]

        command += [
            "-g",
            ",".join(parse_fields),
        ]

    # Append the rest of the command
    command += nmcli_input

    try:
        execute_result = API.host_manager.execute(
            command,
            timeout=timeout,
        )
    except Exception as e:
        raise NmcliError(
            f"nmcli command failed: {_format_command(command)}",
        ) from e

    status, result = _make_result(command, execute_result)

    if status == "timeout":
        raise NmcliTimeout(
            f"nmcli command timed out: {_format_command(command)}",
        )

    if result.returncode == -1:
        raise NmcliError(
            f"nmcli command failed: {_format_command(command)}",
        )

    NmcliNonZeroExit.check(result)

    if parse_fields:
        # Parse output into namedtuples
        lines = result.stdout.strip().splitlines()
        NtClass = _get_namedtuple(parse_fields)

        parsed_output = []
        for line in lines:
            # nmcli sometimes outputs empty lines as separators
            if not line.strip():
                continue

            # Some fields may contain colons (SSIDs, MAC addresses). When they
            # have it, nmcli escapes them with a backslash. We need to split only
            # on unescaped colons.
            parts = _RE_SPLIT_UNESCAPED_COLON.split(line)
            values = [part.replace(r"\:", ":") for part in parts]
            parsed_output.append(NtClass(*values))

        return parsed_output

    return result


def get_nmcli_version_string() -> str:
    # This function HAS TO return a string. No exceptions must be raised!
    try:
        result = run_command(["--version"])
        return result.stdout.strip()
    except Exception as e:
        logger.exception(f"Failed to get nmcli version: {e}")
        return "<unknown>"


# region nmcli helpers


def device_status():
    """
    Get device status using nmcli.

    Returns:
        List of namedtuples with fields:
            DEVICE, TYPE, STATE, CON_UUID, CONNECTION
    """
    return run_command(
        ["device", "status"],
        parse_fields=[
            "DEVICE",
            "TYPE",
            "STATE",
            "CON-UUID",
            "CONNECTION",
        ],
    )


def connection_show():
    """
    Get all network connections using nmcli.

    Returns:
        List of namedtuples with fields:
            UUID, TYPE, DEVICE, AUTOCONNECT, NAME
    """
    return run_command(
        ["connection", "show"],
        parse_fields=[
            "UUID",
            "TYPE",
            "DEVICE",
            "AUTOCONNECT",
            "NAME",
        ],
    )


def connection_modify(connection: str, settings: dict):
    """
    Modify a network connection using nmcli.

    Args:
        connection: Name/UUID of the connection to modify.
        settings: Dictionary of settings to modify.
    """
    args = []
    for key, value in settings.items():
        args.append(key)
        args.append(value)

    return run_command(
        [
            "connection",
            "modify",
            connection,
        ]
        + args,
    )


def device_wifi_list(ifname: str = None):
    """
    List available Wi-Fi networks using nmcli.

    Args:
        ifname: (optional) Interface name to return networks for.

    Returns:
        List of namedtuples with fields:
            DEVICE, SIGNAL, SECURITY, ACTIVE, BSSID, SSID
    """
    command = [
        "device",
        "wifi",
        "list",
    ]

    if ifname:
        command += [
            "ifname",
            ifname,
        ]

    return run_command(
        command,
        parse_fields=[
            "DEVICE",
            "SIGNAL",
            "SECURITY",
            "ACTIVE",
            "BSSID",
            "SSID",
        ],
    )


def device_wifi_connect(ssid: str, password: str, ifname: str):
    """
    Connect to a Wi-Fi network using nmcli.

    Args:
        ssid: SSID of the Wi-Fi network.
        password: Password of the Wi-Fi network.
        ifname: Interface name to use for the connection.
    """
    return run_command(
        [
            "device",
            "wifi",
            "connect",
            ssid,
            "password",
            password,
            "ifname",
            ifname,
        ],
        # Connecting may take some time
        timeout=30,
    )


def device_disconnect(ifname: str):
    """
    Disconnect from a Wi-Fi network using nmcli.

    Args:
        ifname: Interface name to disconnect.
    """
    return run_command(
        [
            "device",
            "disconnect",
            ifname,
        ],
    )


# endregion nmcli helpers
