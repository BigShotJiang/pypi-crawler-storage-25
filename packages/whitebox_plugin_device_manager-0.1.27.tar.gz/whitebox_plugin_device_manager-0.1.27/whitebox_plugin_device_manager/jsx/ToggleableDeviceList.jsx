import DeviceConnection from "./common/DeviceConnection";
import useDevicesStore from "./stores/devices";
import { joinPendingTransferWarningState } from "./ToggleableDeviceList.utils";

const { importWhiteboxStateStore, utils, withStateStore } = Whitebox;

const ToggleButton = ({ isToggled, onClick, isDisabled = false }) => {
  return (
    <>
      <label
        className={`flex cursor-pointer select-none items-center ${
          isDisabled ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <div className="relative">
          <input
            type="checkbox"
            checked={isToggled}
            onChange={onClick}
            className="sr-only"
            disabled={isDisabled}
          />
          <div
            className={`block h-8 w-14 rounded-full transition-colors ${
              isToggled ? "bg-full-emphasis" : "bg-gray-5"
            }`}
          ></div>
          <div
            className={`dot absolute left-1 top-1 h-6 w-6 rounded-full transition-all ${
              isToggled ? "bg-white translate-x-6" : "bg-gray-3"
            }`}
          ></div>
        </div>
      </label>
    </>
  );
};

const ToggleableDeviceListToWrap = () => {
  const devices = useDevicesStore((state) => state.devices);
  const useTransferStore = importWhiteboxStateStore("transfer");
  const pendingTransferDeviceIds = useTransferStore(
    (state) => state.pendingDeviceDependentTransferDeviceIds
  ) || [];

  const toggleDeviceConnection = useDevicesStore(
    (state) => state.toggleDeviceConnection
  );

  // Show message when no devices are available
  if (!devices || devices.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center self-stretch gap-2">
        <p className="text-gray-4 text-lg">No devices installed</p>
      </div>
    );
  }

  // Render list of devices with toggle buttons
  const devicesWithWarningState = joinPendingTransferWarningState(
    devices,
    pendingTransferDeviceIds
  );

  const deviceComponents = devicesWithWarningState.map((device, index) => {
    const isToggled = (
        device.connection_status === "connecting"
        || device.connection_status === "connected"
    )
    const isDisabled = (
        device.connection_status === "connecting"
        || device.connection_status === "disconnecting"
    );

    const handleToggle = () => {
      toggleDeviceConnection(device.id, isToggled);
    };

    const action = (
      <ToggleButton isToggled={isToggled}
                    onClick={handleToggle}
                    isDisabled={isDisabled} />
    );

    const iconUrl = utils.buildStaticUrl(device.device_type_icon_url);
    const icon = <img src={iconUrl} alt={device.name} />;

    return (
      <DeviceConnection
        key={index}
        deviceName={device.name}
        connectionStatus={device.connection_status}
        deviceReachability={device.device_reachability}
        hasPendingTransferWarning={device.hasPendingTransferWarning}
        icon={icon}
        action={action}
      />
    );
  });

  return (
    <div className="flex flex-1 flex-col items-center self-stretch gap-2">
      {deviceComponents}
    </div>
  );
};

const ToggleableDeviceList = withStateStore(ToggleableDeviceListToWrap, [
  "transfer",
]);

export { ToggleableDeviceList, ToggleableDeviceListToWrap, joinPendingTransferWarningState };
export default ToggleableDeviceList;
