import {
  isInsta360Codename,
  joinPendingTransferWarningState,
} from "./ToggleableDeviceList.utils";

describe("joinPendingTransferWarningState", () => {
  it("detects Insta360 codenames using existing codename pattern", () => {
    expect(isInsta360Codename("insta360_x4")).toBe(true);
    expect(isInsta360Codename("INSTA360_X3")).toBe(true);
    expect(isInsta360Codename("sony_a7")).toBe(false);
  });

  it("flags non-connected Insta360 rows with matching pending transfer ids", () => {
    const joinedDevices = joinPendingTransferWarningState(
      [
        {
          id: 1,
          codename: "insta360_x4",
          connection_status: "disconnected",
          name: "Cam A",
        },
        {
          id: 2,
          codename: "insta360_x4",
          connection_status: "failed",
          name: "Cam B",
        },
        {
          id: 3,
          codename: "insta360_x4",
          connection_status: "connecting",
          name: "Cam C",
        },
        {
          id: 4,
          codename: "insta360_x4",
          connection_status: "connected",
          device_reachability: "unavailable",
          name: "Cam D",
        },
        {
          id: 5,
          codename: "sony_a7",
          connection_status: "failed",
          name: "Cam E",
        },
      ],
      ["1", "2", "3", "4", "5"]
    );

    expect(joinedDevices[0].hasPendingTransferWarning).toBe(true);
    expect(joinedDevices[1].hasPendingTransferWarning).toBe(true);
    expect(joinedDevices[2].hasPendingTransferWarning).toBe(true);
    expect(joinedDevices[3].hasPendingTransferWarning).toBe(true);
    expect(joinedDevices[4].hasPendingTransferWarning).toBe(false);
  });

  it("supports numeric pending-transfer ids from store state", () => {
    const joinedDevices = joinPendingTransferWarningState(
      [{ id: 12, codename: "insta360_x3", connection_status: "failed" }],
      [12]
    );

    expect(joinedDevices[0].hasPendingTransferWarning).toBe(true);
  });

  it("keeps warning off for connected reachable Insta360 devices", () => {
    const joinedDevices = joinPendingTransferWarningState(
      [
        {
          id: 7,
          codename: "insta360_x4",
          connection_status: "connected",
          device_reachability: "healthy",
        },
      ],
      [7]
    );

    expect(joinedDevices[0].hasPendingTransferWarning).toBe(false);
  });
});
