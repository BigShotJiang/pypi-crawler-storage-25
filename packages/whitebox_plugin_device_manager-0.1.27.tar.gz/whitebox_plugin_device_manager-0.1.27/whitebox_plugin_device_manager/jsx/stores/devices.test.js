import useDevicesStore from "./devices";

describe("DevicesStore", () => {
  afterEach(() => {
    useDevicesStore.setState({ devices: null, fetchState: "initial" });
  });

  it("updates device reachability from connection status events", () => {
    useDevicesStore.setState({
      devices: [
        {
          id: 4,
          codename: "insta360_x4",
          connection_status: "connected",
          device_reachability: "healthy",
        },
      ],
      fetchState: "loaded",
    });

    useDevicesStore
      .getState()
      .updateDeviceConnectionStatus(4, "connected", "unavailable");

    expect(useDevicesStore.getState().devices[0]).toMatchObject({
      connection_status: "connected",
      device_reachability: "unavailable",
    });
  });
});
