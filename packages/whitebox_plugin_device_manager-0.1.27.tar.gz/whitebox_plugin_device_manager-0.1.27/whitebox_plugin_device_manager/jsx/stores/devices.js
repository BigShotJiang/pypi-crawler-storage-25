import { create } from "zustand";

const { api } = Whitebox;



const devicesStore = (set) => ({
  fetchState: "initial",
  devices: null,

  fetchDevices: async () => {
    let data;

    const url = api.getPluginProvidedPath(
      "device.device-connection-management"
    );

    try {
      const response = await api.client.get(url);
      data = await response.data;
    } catch {
      set({ fetchState: "error" });
      return false;
    }

    set({
      devices: data,
      fetchState: "loaded",
    });
    return true;
  },

  toggleDeviceConnection: async (deviceId, isConnected) => {
    const subcommand = isConnected ? "disconnect" : "connect";
    const command = `command.device.device_connection.${subcommand}`;

    Whitebox.sockets.send("management", {
      type: command,
      device_connection_id: deviceId,
    });

    // Reflect the change in local state for immediate UI feedback
    set((state) => {
      const updatedDevices = state.devices.map((device) => {
        if (device.id === deviceId) {
          return {
            ...device,
            connection_status: isConnected ? "disconnecting" : "connecting",
          };
        }
        return device;
      });
      return { devices: updatedDevices };
    });
  },

  updateDeviceConnectionStatus: (
    deviceStatusPayloadOrId,
    newStatus,
    deviceReachability
  ) => {
    const deviceStatusPayload =
      typeof deviceStatusPayloadOrId === "object"
        ? deviceStatusPayloadOrId
        : {
            id: deviceStatusPayloadOrId,
            connection_status: newStatus,
            ...(deviceReachability === undefined
              ? {}
              : { device_reachability: deviceReachability }),
          };

    set((state) => {
      if (!state.devices) {
        return state;
      }

      const updatedDevices = state.devices.map((device) => {
        if (device.id === deviceStatusPayload.id) {
          return {
            ...device,
            ...deviceStatusPayload,
          };
        }
        return device;
      });

      return { devices: updatedDevices };
    });
  },
});

const useDevicesStore = create(devicesStore);

export default useDevicesStore;
