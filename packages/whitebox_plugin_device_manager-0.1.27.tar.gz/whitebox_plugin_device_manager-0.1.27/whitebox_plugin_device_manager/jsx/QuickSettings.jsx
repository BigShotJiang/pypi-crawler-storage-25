import { useState } from "react";
import ToggleableDeviceList from "./ToggleableDeviceList";
import { joinPendingTransferWarningState } from "./ToggleableDeviceList.utils";
import useDevicesStore from "./stores/devices";

const { importWhiteboxStateStore, withStateStore } = Whitebox;

const QuickSettingsButton = ({
  isPanelOpen,
  setIsPanelOpen,
  hasPendingTransferWarning,
}) => {
  const TertiaryButton = Whitebox.importWhiteboxComponent("ui.button-tertiary");
  const TuneIcon = Whitebox.importWhiteboxComponent("icons.tune");
  const ExpandLessIcon = Whitebox.importWhiteboxComponent("icons.expand-less");

  const tuneIconClassName = hasPendingTransferWarning
    ? "c_quick_settings_warning_icon [&_path]:fill-error"
    : null;

  const buttonClassName = hasPendingTransferWarning
    ? "c_quick_settings_warning_button text-error"
    : null;

  const ExpandLessRotated = () => {
    return (
      <ExpandLessIcon
        className={`transition-transform duration-200 ${
          isPanelOpen ? "rotate-180" : ""
        }`}
      />
    );
  };

  return (
    <div onClick={() => setIsPanelOpen(!isPanelOpen)}>
      <TertiaryButton
        className={buttonClassName}
        leftIcon={<TuneIcon className={tuneIconClassName} />}
        rightIcon={<ExpandLessRotated />}
      />
    </div>
  );
};

const QuickSettingsPanel = ({ isPanelOpen, setIsPanelOpen }) => {
  if (!isPanelOpen) {
    return null;
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={() => setIsPanelOpen(false)}
      />
      {/* Panel */}
      <div className="absolute right-0 top-full mt-2 z-50 w-[400px] bg-white rounded-3xl shadow-lg p-6">
        <ToggleableDeviceList />
      </div>
    </>
  );
};

const QuickSettingsToWrap = () => {
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const devices = useDevicesStore((state) => state.devices) || [];
  const useTransferStore = importWhiteboxStateStore("transfer");
  const pendingTransferDeviceIds = useTransferStore(
    (state) => state.pendingDeviceDependentTransferDeviceIds
  ) || [];

  const hasPendingTransferWarning = joinPendingTransferWarningState(
    devices,
    pendingTransferDeviceIds
  ).some((device) => device.hasPendingTransferWarning);

  return (
    <div className="relative">
      <QuickSettingsButton
        isPanelOpen={isPanelOpen}
        setIsPanelOpen={setIsPanelOpen}
        hasPendingTransferWarning={hasPendingTransferWarning}
      />
      <QuickSettingsPanel
        isPanelOpen={isPanelOpen}
        setIsPanelOpen={setIsPanelOpen}
      />
    </div>
  );
};

const QuickSettings = withStateStore(QuickSettingsToWrap, ["transfer"]);

export { QuickSettings, QuickSettingsToWrap };
export default QuickSettings;
