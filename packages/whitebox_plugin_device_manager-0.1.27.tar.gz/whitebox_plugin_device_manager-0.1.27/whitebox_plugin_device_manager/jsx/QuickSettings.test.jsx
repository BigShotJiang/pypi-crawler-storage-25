import { cleanup, render, screen } from "@testing-library/react";
import QuickSettings from "./QuickSettings";
import useDevicesStore from "./stores/devices";

const { mockWhiteboxStateStore, resetWhiteboxStateStoreMocks } = WhiteboxTest;
const originalImportWhiteboxComponent = Whitebox.importWhiteboxComponent;

const mockQuickSettingsComponents = () => {
  Whitebox.importWhiteboxComponent = vi.fn((name) => {
    if (name === "ui.button-tertiary") {
      return ({ className, leftIcon, rightIcon }) => (
        <button data-testid="quick-settings-button" className={className || ""}>
          {leftIcon}
          {rightIcon}
        </button>
      );
    }

    if (name === "icons.tune") {
      return ({ className }) => (
        <svg data-testid="tune-icon" className={className || ""} />
      );
    }

    if (name === "icons.expand-less") {
      return ({ className }) => (
        <svg data-testid="expand-less-icon" className={className || ""} />
      );
    }

    return () => null;
  });
};

const setDevices = (devices) => {
  useDevicesStore.setState({ devices, fetchState: "loaded" });
};

describe("QuickSettings", () => {
  beforeEach(() => {
    mockQuickSettingsComponents();
    useDevicesStore.setState({ devices: null, fetchState: "initial" });
  });

  afterEach(() => {
    cleanup();
    resetWhiteboxStateStoreMocks();
    useDevicesStore.setState({ devices: null, fetchState: "initial" });
    Whitebox.importWhiteboxComponent = originalImportWhiteboxComponent;
  });

  it("adds warning classes when an unavailable device has pending transfers", () => {
    mockWhiteboxStateStore("transfer", {
      pendingDeviceDependentTransferDeviceIds: ["4"],
    });
    setDevices([
      {
        id: 4,
        codename: "insta360_x4",
        connection_status: "connected",
        device_reachability: "unavailable",
      },
    ]);

    render(<QuickSettings />);

    expect(screen.getByTestId("quick-settings-button")).toHaveClass(
      "c_quick_settings_warning_button",
      "text-error"
    );
    expect(screen.getByTestId("tune-icon")).toHaveClass(
      "c_quick_settings_warning_icon"
    );
    expect(screen.getByTestId("tune-icon")).toHaveAttribute(
      "class",
      expect.stringContaining("[&_path]:fill-error")
    );
  });

  it("keeps default classes when pending transfers do not require warning", () => {
    mockWhiteboxStateStore("transfer", {
      pendingDeviceDependentTransferDeviceIds: ["4"],
    });
    setDevices([
      {
        id: 4,
        codename: "insta360_x4",
        connection_status: "connected",
        device_reachability: "healthy",
      },
    ]);

    render(<QuickSettings />);

    expect(screen.getByTestId("quick-settings-button")).not.toHaveClass(
      "c_quick_settings_warning_button",
      "text-error"
    );
    expect(screen.getByTestId("tune-icon")).not.toHaveClass(
      "c_quick_settings_warning_icon"
    );
    expect(screen.getByTestId("tune-icon")).not.toHaveAttribute(
      "class",
      expect.stringContaining("[&_path]:fill-error")
    );
  });
});
