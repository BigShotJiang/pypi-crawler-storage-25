import {
  getDeviceConnectionClasses,
  getDeviceStatusDisplay,
} from "./DeviceConnection.utils";

describe("DeviceConnection warning helpers", () => {
  it("returns reconnect warning text for disconnected pending transfers", () => {
    const status = getDeviceStatusDisplay({
      connectionStatus: "disconnected",
      hasPendingTransferWarning: true,
    });

    expect(status.connectionText).toBe("Pending transfers, please connect");
    expect(status.badgeColor).toBe("fill-error");
    expect(status.statusTextColorClass).toBe("text-error");
  });

  it("returns reconnect warning text for failed pending transfers", () => {
    const status = getDeviceStatusDisplay({
      connectionStatus: "failed",
      hasPendingTransferWarning: true,
    });

    expect(status.connectionText).toBe("Pending transfers, please connect");
    expect(status.badgeColor).toBe("fill-error");
    expect(status.statusTextColorClass).toBe("text-error");
  });

  it("keeps connecting copy when warning remains active", () => {
    const status = getDeviceStatusDisplay({
      connectionStatus: "connecting",
      hasPendingTransferWarning: true,
    });

    expect(status.connectionText).toBe("Connecting...");
    expect(status.badgeColor).toBe("fill-warning");
    expect(status.statusTextColorClass).toBe("text-full-emphasis");
  });

  it("shows reconnect warning when wifi is connected but device is unavailable", () => {
    const status = getDeviceStatusDisplay({
      connectionStatus: "connected",
      deviceReachability: "unavailable",
      hasPendingTransferWarning: true,
    });

    expect(status.connectionText).toBe("Pending transfers, please connect");
    expect(status.badgeColor).toBe("fill-error");
    expect(status.statusTextColorClass).toBe("text-error");
  });

  it("keeps default disconnected text when warning flag is off", () => {
    const status = getDeviceStatusDisplay({
      connectionStatus: "disconnected",
      connectionInfo: "Cable unplugged",
      hasPendingTransferWarning: false,
    });

    expect(status.connectionText).toBe("Disconnected - Cable unplugged");
    expect(status.badgeColor).toBe("fill-error");
    expect(status.statusTextColorClass).toBe("text-full-emphasis");
  });

  it("returns red row classes when warning is active", () => {
    const classes = getDeviceConnectionClasses(true);

    expect(classes.borderClass).toBe("border-error");
    expect(classes.deviceNameClass).toBe("text-error");
  });

  it("keeps default row classes when warning is inactive", () => {
    const classes = getDeviceConnectionClasses(false);

    expect(classes.borderClass).toBe("border-borders-default");
    expect(classes.deviceNameClass).toBe("text-full-emphasis");
  });
});
