const getDeviceStatusDisplay = ({
  connectionStatus = null,
  deviceReachability = null,
  connectionInfo = null,
  hasPendingTransferWarning = false,
}) => {
  let connectionText;
  let badgeColor;
  let statusTextColorClass = "text-full-emphasis";
  const isUnavailableDevice = deviceReachability === "unavailable";

  switch (connectionStatus) {
    case "connecting":
      connectionText = "Connecting...";
      badgeColor = "fill-warning";
      break;
    case "disconnecting":
      connectionText = "Disconnecting...";
      badgeColor = "fill-warning";
      break;
    case "connected":
      connectionText = (
        hasPendingTransferWarning && isUnavailableDevice
      )
        ? "Pending transfers, please connect"
        : "Connected";
      badgeColor = (
        hasPendingTransferWarning && isUnavailableDevice
      )
        ? "fill-error"
        : "fill-success";
      statusTextColorClass = (
        hasPendingTransferWarning && isUnavailableDevice
      )
        ? "text-error"
        : "text-full-emphasis";
      break;
    case "disconnected":
      connectionText = hasPendingTransferWarning
        ? "Pending transfers, please connect"
        : "Disconnected";
      badgeColor = "fill-error";
      statusTextColorClass = hasPendingTransferWarning
        ? "text-error"
        : "text-full-emphasis";
      break;
    case "failed":
      connectionText = hasPendingTransferWarning
        ? "Pending transfers, please connect"
        : "Failed to connect";
      badgeColor = "fill-error";
      statusTextColorClass = hasPendingTransferWarning
        ? "text-error"
        : "text-full-emphasis";
      break;
    default:
      connectionText = "Unknown";
      badgeColor = "fill-secondary";
      break;
  }

  if (connectionInfo && !hasPendingTransferWarning) {
    connectionText += ` - ${connectionInfo}`;
  }

  return {
    connectionText,
    badgeColor,
    statusTextColorClass,
  };
};

const getDeviceConnectionClasses = (hasPendingTransferWarning = false) => {
  return {
    borderClass: hasPendingTransferWarning
      ? "border-error"
      : "border-borders-default",
    deviceNameClass: hasPendingTransferWarning
      ? "text-error"
      : "text-full-emphasis",
  };
};

export { getDeviceStatusDisplay, getDeviceConnectionClasses };
