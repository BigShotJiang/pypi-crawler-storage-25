const isInsta360Codename = (codename = "") =>
  String(codename).toLowerCase().includes("insta360");

const hasUnavailableDeviceReachability = (device = {}) =>
  device.device_reachability === "unavailable";

const joinPendingTransferWarningState = (
  devices = [],
  pendingTransferDeviceIds = []
) => {
  const pendingTransferDeviceIdSet = new Set(
    pendingTransferDeviceIds.map((deviceId) => String(deviceId))
  );

  return devices.map((device) => ({
    ...device,
    hasPendingTransferWarning: (
      (
        device.connection_status !== "connected"
        || hasUnavailableDeviceReachability(device)
      )
      && isInsta360Codename(device.codename)
      && pendingTransferDeviceIdSet.has(String(device.id))
    ),
  }));
};

export {
  hasUnavailableDeviceReachability,
  isInsta360Codename,
  joinPendingTransferWarningState,
};
