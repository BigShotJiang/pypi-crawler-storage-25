"""CodeTrust HTTP API — FastAPI wrapper around the core trust scoring engine.

Endpoints:
    POST /v1/scan/file     — Score a single file (upload)
    POST /v1/scan/snippet  — Score a code snippet
    POST /v1/scan/diff     — Score a git diff
    GET  /v1/reports/{id}  — Get a stored report by ID
    GET  /v1/benchmark     — Compare AI tools
    POST /v1/keys/generate — Generate an API key (requires master key)
    GET  /v1/keys/usage    — Check usage for an API key
    GET  /health           — Health check
"""

from __future__ import annotations

import hashlib
import os
import secrets
import sqlite3
import tempfile
import time
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Header, UploadFile, File, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .analyzers import ALL_ANALYZERS
from .analyzers.hallucination import HallucinationAnalyzer
from .store import TrustStore
from .types import TrustIssue, TrustResult, IssueCategory, Severity

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

RATE_LIMITS = {
    "free": 100,        # 100 scans/day
    "pro": 10_000,      # 10K scans/day
    "team": 50_000,     # 50K scans/day
    "enterprise": -1,   # unlimited
}

_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}

# In-memory rate limit counters (reset daily)
_usage: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
_usage_date: str = ""


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CodeTrust API",
    description="AI code security & quality scanner — catches vulnerabilities, hallucinated dependencies, and compliance issues in AI-generated code. By AutoAI Labs.",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Singleton store (created on first request)
_store: TrustStore | None = None
_key_db: sqlite3.Connection | None = None


def _get_store() -> TrustStore:
    global _store
    if _store is None:
        db_path = os.environ.get("CODETRUST_DB_PATH", "data/codetrust.db")
        _store = TrustStore(db_path)
    return _store


def _get_key_db() -> sqlite3.Connection:
    """Get or create the API key database."""
    global _key_db
    if _key_db is None:
        db_path = os.environ.get("CODETRUST_DB_PATH", "data/codetrust.db")
        _key_db = sqlite3.connect(db_path, check_same_thread=False)
        _key_db.row_factory = sqlite3.Row
        _key_db.executescript("""
            CREATE TABLE IF NOT EXISTS api_keys (
                key_hash TEXT PRIMARY KEY,
                key_prefix TEXT NOT NULL,
                tier TEXT NOT NULL DEFAULT 'free',
                owner_email TEXT,
                stripe_customer_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                revoked_at TIMESTAMP,
                last_used_at TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS usage_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_hash TEXT NOT NULL,
                endpoint TEXT NOT NULL,
                scan_date TEXT NOT NULL,
                count INTEGER DEFAULT 1,
                UNIQUE(key_hash, endpoint, scan_date)
            );
        """)
    return _key_db


# ---------------------------------------------------------------------------
# Auth + Rate Limiting
# ---------------------------------------------------------------------------

def _hash_key(api_key: str) -> str:
    """Hash API key for storage (never store raw keys)."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def _validate_api_key(x_api_key: str = Header(default="")) -> str:
    """Validate API key and return tier. Enforces rate limits."""
    if not x_api_key:
        return "free"

    # Check master key (for admin operations)
    master = os.environ.get("CODETRUST_MASTER_KEY", "")
    if master and x_api_key == master:
        return "enterprise"

    # Look up in database
    db = _get_key_db()
    key_hash = _hash_key(x_api_key)
    row = db.execute(
        "SELECT tier, revoked_at FROM api_keys WHERE key_hash = ?",
        (key_hash,),
    ).fetchone()

    if not row:
        return "free"  # Unknown key = free tier
    if row["revoked_at"]:
        raise HTTPException(403, "API key has been revoked")

    tier = row["tier"]

    # Update last_used_at
    db.execute(
        "UPDATE api_keys SET last_used_at = CURRENT_TIMESTAMP WHERE key_hash = ?",
        (key_hash,),
    )
    db.commit()

    return tier


def _check_rate_limit(tier: str, key_identifier: str = "anonymous") -> None:
    """Enforce daily rate limits per tier."""
    global _usage, _usage_date

    today = date.today().isoformat()
    if _usage_date != today:
        _usage.clear()
        _usage_date = today

    limit = RATE_LIMITS.get(tier, 100)
    if limit == -1:
        return  # unlimited

    current = _usage[key_identifier][today]
    if current >= limit:
        raise HTTPException(
            429,
            detail=f"Rate limit exceeded: {current}/{limit} scans today. "
            f"Upgrade to Pro for 10K scans/day: https://buy.stripe.com/8x200j18igdefhEartbfO0k",
        )
    _usage[key_identifier][today] += 1


def _rate_limited_key(x_api_key: str = Header(default="")) -> str:
    """Validate key AND enforce rate limits."""
    tier = _validate_api_key(x_api_key)
    key_id = _hash_key(x_api_key)[:16] if x_api_key else "anonymous"
    _check_rate_limit(tier, key_id)
    return tier


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------

class SnippetRequest(BaseModel):
    """Request to scan a code snippet."""
    code: str = Field(..., description="Source code to scan", max_length=500_000)
    language: str = Field(
        "python",
        description="Language: python, typescript, javascript, go",
    )
    ai_tool: str = Field("", description="AI tool that generated this code")
    filename: str = Field("snippet", description="Optional filename for context")
    format: str = Field("json", description="Output format: json or sarif")


class DiffRequest(BaseModel):
    """Request to scan a git diff."""
    diff: str = Field(..., description="Git diff output", max_length=1_000_000)
    ai_tool: str = Field("", description="AI tool that generated the changes")


class ScanResult(BaseModel):
    """Scan result returned by the API."""
    id: str
    target: str
    score: int
    trust_category: str
    trust_label: str
    total_issues: int
    critical_issues: int
    high_issues: int
    breakdown: dict[str, int]
    issues: list[dict[str, Any]]
    ai_tool: str
    scan_time_ms: int


# ---------------------------------------------------------------------------
# Core scanning logic (reuses server.py functions)
# ---------------------------------------------------------------------------

def _detect_ai_tool(content: str) -> str:
    content_lower = content.lower()
    for marker, tool in [
        ("copilot", "copilot"), ("github copilot", "copilot"),
        ("cursor", "cursor"), ("claude", "claude"), ("anthropic", "claude"),
        ("chatgpt", "chatgpt"), ("openai", "chatgpt"),
        ("gemini", "gemini"), ("codewhisperer", "codewhisperer"),
    ]:
        if marker in content_lower:
            return tool
    return "unknown"


def _scan_content(
    content: str,
    file_path: Path,
    ai_tool: str,
    store: TrustStore,
    output_format: str = "json",
) -> dict[str, Any]:
    """Run all analyzers on content and return structured result."""
    from .sarif import result_to_sarif

    start = time.monotonic()

    all_issues: list[TrustIssue] = []
    for analyzer_cls in ALL_ANALYZERS:
        all_issues.extend(analyzer_cls.analyze_file(file_path, content))

    detected_tool = ai_tool or _detect_ai_tool(content)

    result = TrustResult(
        target=str(file_path),
        issues=all_issues,
        ai_tool=detected_tool,
    )
    result.compute_score()
    score_id = store.save_result(result)

    if output_format == "sarif":
        sarif = result_to_sarif(result)
        sarif["runs"][0]["properties"] = {"scanTimeMs": int((time.monotonic() - start) * 1000)}
        return sarif

    elapsed_ms = int((time.monotonic() - start) * 1000)

    output = result.to_dict()
    output["id"] = score_id
    output["scan_time_ms"] = elapsed_ms
    output["critical_issues"] = sum(
        1 for i in all_issues if i.severity.value == "critical"
    )
    output["high_issues"] = sum(
        1 for i in all_issues if i.severity.value == "high"
    )

    return output


def _scan_diff(
    diff_text: str,
    ai_tool: str,
    store: TrustStore,
) -> dict[str, Any]:
    """Scan a git diff — only analyses added lines."""
    start = time.monotonic()

    all_issues: list[TrustIssue] = []
    current_file: str | None = None
    added_lines: list[str] = []

    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            if current_file and added_lines:
                fp = Path(current_file)
                if fp.suffix in _CODE_EXTENSIONS:
                    added_content = "\n".join(added_lines)
                    for analyzer_cls in ALL_ANALYZERS:
                        issues = analyzer_cls.analyze_file(fp, added_content)
                        for issue in issues:
                            issue.description = f"[IN DIFF] {issue.description}"
                        all_issues.extend(issues)
            current_file = line[6:]
            added_lines = []
        elif line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])

    # Process last file
    if current_file and added_lines:
        fp = Path(current_file)
        if fp.suffix in _CODE_EXTENSIONS:
            added_content = "\n".join(added_lines)
            for analyzer_cls in ALL_ANALYZERS:
                issues = analyzer_cls.analyze_file(fp, added_content)
                for issue in issues:
                    issue.description = f"[IN DIFF] {issue.description}"
                all_issues.extend(issues)

    result = TrustResult(
        target="git diff",
        issues=all_issues,
        ai_tool=ai_tool or "unknown",
    )
    result.compute_score()
    score_id = store.save_result(result)

    elapsed_ms = int((time.monotonic() - start) * 1000)

    output = result.to_dict()
    output["id"] = score_id
    output["scan_time_ms"] = elapsed_ms
    output["critical_issues"] = sum(
        1 for i in all_issues if i.severity.value == "critical"
    )
    output["high_issues"] = sum(
        1 for i in all_issues if i.severity.value == "high"
    )

    return output


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "codetrust", "version": "0.1.0"}


@app.post("/v1/scan/snippet", response_model=None)
async def scan_snippet(
    req: SnippetRequest,
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Scan a code snippet for security, quality, and hallucination issues."""
    ext_map = {
        "python": ".py", "typescript": ".ts", "javascript": ".js",
        "go": ".go", "tsx": ".tsx", "jsx": ".jsx",
    }
    ext = ext_map.get(req.language.lower(), ".py")
    fake_path = Path(f"{req.filename}{ext}")

    store = _get_store()
    return _scan_content(req.code, fake_path, req.ai_tool, store, output_format=req.format)


@app.post("/v1/scan/file", response_model=None)
async def scan_file(
    file: UploadFile = File(...),
    ai_tool: str = "",
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Upload and scan a single source file."""
    if not file.filename:
        raise HTTPException(400, "Filename required")

    ext = Path(file.filename).suffix
    if ext not in _CODE_EXTENSIONS:
        raise HTTPException(
            400,
            f"Unsupported file type: {ext}. Supported: {', '.join(sorted(_CODE_EXTENSIONS))}",
        )

    content = (await file.read()).decode("utf-8", errors="replace")
    if len(content) > 500_000:
        raise HTTPException(413, "File too large (max 500KB)")

    store = _get_store()
    return _scan_content(content, Path(file.filename), ai_tool, store)


@app.post("/v1/scan/diff", response_model=None)
async def scan_diff(
    req: DiffRequest,
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Scan a git diff — only analyses added/changed lines."""
    if not req.diff.strip():
        raise HTTPException(400, "Empty diff")

    store = _get_store()
    return _scan_diff(req.diff, req.ai_tool, store)


@app.get("/v1/reports/{report_id}", response_model=None)
async def get_report(
    report_id: str,
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Retrieve a stored scan report by ID."""
    store = _get_store()
    result = store.get_score(report_id)
    if not result:
        raise HTTPException(404, f"Report not found: {report_id}")
    return result


@app.get("/v1/benchmark", response_model=None)
async def benchmark(
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Compare trust scores across AI tools (Cursor, Copilot, Claude, etc.)."""
    store = _get_store()
    return store.get_benchmark_by_tool()


class SCARequest(BaseModel):
    """Request to scan dependencies for CVEs."""
    manifest: str = Field(..., description="Content of requirements.txt, package.json, pyproject.toml, or go.mod")
    manifest_type: str = Field(..., description="File name: requirements.txt, package.json, pyproject.toml, go.mod")


@app.post("/v1/scan/dependencies", response_model=None)
async def scan_dependencies(
    req: SCARequest,
    tier: str = Depends(_rate_limited_key),
) -> dict[str, Any]:
    """Scan dependencies for known CVEs using OSV.dev database.

    Upload your requirements.txt, package.json, pyproject.toml, or go.mod
    and get a list of known vulnerabilities affecting your dependencies.
    """
    from .analyzers.sca import SCAAnalyzer

    fake_path = Path(req.manifest_type)
    issues = SCAAnalyzer.analyze_file(fake_path, req.manifest)

    return {
        "manifest_type": req.manifest_type,
        "total_vulnerabilities": len(issues),
        "critical": sum(1 for i in issues if i.severity == Severity.CRITICAL),
        "high": sum(1 for i in issues if i.severity == Severity.HIGH),
        "medium": sum(1 for i in issues if i.severity == Severity.MEDIUM),
        "low": sum(1 for i in issues if i.severity == Severity.LOW),
        "vulnerabilities": [i.to_dict() for i in issues],
    }


# ---------------------------------------------------------------------------
# API Key Management
# ---------------------------------------------------------------------------


class KeyGenerateRequest(BaseModel):
    """Request to generate an API key."""
    email: str = Field(..., description="Owner email address")
    tier: str = Field("pro", description="Tier: free, pro, team, enterprise")
    stripe_customer_id: str = Field("", description="Stripe customer ID")


@app.post("/v1/keys/generate", response_model=None)
async def generate_api_key(
    req: KeyGenerateRequest,
    x_api_key: str = Header(default=""),
) -> dict[str, Any]:
    """Generate a new API key. Requires master key."""
    master = os.environ.get("CODETRUST_MASTER_KEY", "")
    if not master or x_api_key != master:
        raise HTTPException(403, "Master key required to generate API keys")

    # Generate a secure API key
    raw_key = f"ct_{req.tier}_{secrets.token_urlsafe(32)}"
    key_hash = _hash_key(raw_key)
    key_prefix = raw_key[:12]

    db = _get_key_db()
    db.execute(
        "INSERT INTO api_keys (key_hash, key_prefix, tier, owner_email, stripe_customer_id) "
        "VALUES (?, ?, ?, ?, ?)",
        (key_hash, key_prefix, req.tier, req.email, req.stripe_customer_id),
    )
    db.commit()

    return {
        "api_key": raw_key,  # Only shown once!
        "prefix": key_prefix,
        "tier": req.tier,
        "rate_limit": RATE_LIMITS.get(req.tier, 100),
        "message": "Store this key securely — it cannot be retrieved again.",
    }


@app.get("/v1/keys/usage", response_model=None)
async def get_usage(
    x_api_key: str = Header(default=""),
) -> dict[str, Any]:
    """Check usage and rate limit status for an API key."""
    tier = _validate_api_key(x_api_key)
    key_id = _hash_key(x_api_key)[:16] if x_api_key else "anonymous"
    today = date.today().isoformat()
    limit = RATE_LIMITS.get(tier, 100)

    current = _usage.get(key_id, {}).get(today, 0)

    return {
        "tier": tier,
        "scans_today": current,
        "daily_limit": limit if limit > 0 else "unlimited",
        "remaining": (limit - current) if limit > 0 else "unlimited",
        "upgrade_url": "https://buy.stripe.com/8x200j18igdefhEartbfO0k" if tier == "free" else None,
    }


@app.post("/v1/keys/revoke", response_model=None)
async def revoke_key(
    key_to_revoke: str = "",
    x_api_key: str = Header(default=""),
) -> dict[str, str]:
    """Revoke an API key. Requires master key."""
    master = os.environ.get("CODETRUST_MASTER_KEY", "")
    if not master or x_api_key != master:
        raise HTTPException(403, "Master key required")

    db = _get_key_db()
    key_hash = _hash_key(key_to_revoke)
    db.execute(
        "UPDATE api_keys SET revoked_at = CURRENT_TIMESTAMP WHERE key_hash = ?",
        (key_hash,),
    )
    db.commit()
    return {"status": "revoked"}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the API server."""
    import uvicorn

    host = os.environ.get("CODETRUST_HOST", "0.0.0.0")
    port = int(os.environ.get("CODETRUST_PORT", "8080"))
    uvicorn.run(
        "aicodetrustcore.api:app",
        host=host,
        port=port,
        reload=False,
    )
