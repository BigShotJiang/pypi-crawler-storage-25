# HmLogger

Ein leichtgewichtiges Logging-Modul fuer Python mit:

- farbiger Konsolen-Ausgabe
- optionalem Rotating-File-Logging
- optionalem asynchronen Logging ueber QueueHandler und QueueListener

## Voraussetzungen

- Python 3.11 oder neuer

Hinweis: Das Projekt verwendet typing.Self und Union-Typen mit |.

## Installation (lokal)

Direkt aus dem Repository:

```bash
pip install -e .
```

Bis zur PyPI-Veroeffentlichung kann das Modul lokal so verwendet werden:

```python
import HmLogger
```

## Schnellstart

```python
import logging
from HmLogger import setup_logging, get_logger

setup_logging(
    level=logging.DEBUG,
    use_colors=True,
    file_logging=True,
    async_logging=True,
)

log = get_logger("App")
log.debug("Debug-Nachricht")
log.info("Info-Nachricht")
log.warning("Warnung")
log.error("Fehler")
log.critical("Kritischer Fehler")
```

## API

### setup_logging(...)

```python
setup_logging(
    level=logging.INFO,
    use_colors=True,
    file_logging=True,
    async_logging=True,
    log_folder="./logs",
    log_file="app.log",
    mb=5,
    backup_count=5,
)
```

Parameter:

- level: Log-Level (z. B. logging.DEBUG)
- use_colors: ANSI-Farben fuer Konsole aktivieren
- file_logging: Log-Ausgabe in Datei aktivieren
- async_logging: Queue-basiertes, nicht blockierendes Logging
- log_folder: Zielordner fuer Log-Dateien
- log_file: Dateiname der Haupt-Logdatei
- mb: maximale Dateigroesse in MB vor Rotation
- backup_count: Anzahl aufbewahrter Rotationsdateien

### get_logger(name)

```python
from HmLogger import get_logger

log = get_logger("MyService")
log.info("Service gestartet")
```

## Farben und Styles

```python
from HmLogger import Color, Text

print(Color("green")("Erfolg"))
print(Color("red").bold()("Fehler"))
print(Color("yellow").underline()("Achtung"))
print(Text("Custom Text", Color("magenta").italic()))
```

Verfuegbare Farben:

- default
- grey
- red
- green
- yellow
- blue
- magenta
- cyan
- white

Verfuegbare Styles:

- bold()
- dim()
- italic()
- underline()
- blink()
- reversed()
- strikethrough()
- intense()

## PyPI-Veroeffentlichung (Schritt fuer Schritt)

1. Paket-Metadaten anlegen

   - Datei pyproject.toml erstellen
   - mind. name, version, description, readme, requires-python, authors setzen
   - Build-Backend definieren (z. B. hatchling oder setuptools)

2. Lizenzdatei hinzufuegen

   - Datei LICENSE erstellen (z. B. MIT)
   - Lizenz in pyproject.toml referenzieren

3. Paketstruktur pruefen

   - sicherstellen, dass das importierbare Paket korrekt gefunden wird
   - Paketname auf PyPI: hmlogger
   - Import-Name im Code: HmLogger

4. Build-Werkzeuge installieren

```bash
python -m pip install --upgrade build twine
```

5. Paket bauen

```bash
python -m build
```

Ergebnis liegt in dist/ (sdist und wheel).

6. Artefakte pruefen

```bash
python -m twine check dist/*
```

7. Test-Upload zu TestPyPI

```bash
python -m twine upload --repository testpypi dist/*
```

8. Installation von TestPyPI pruefen

```bash
pip install --index-url https://test.pypi.org/simple/ hmlogger
```

9. Upload zu PyPI

```bash
python -m twine upload dist/*
```

10. Release taggen

   - Version in pyproject.toml erhoehen
   - Git-Tag setzen und veroeffentlichen

## Hinweise

- Bei aktivem async_logging wird ein QueueListener verwendet und per atexit sauber beendet.
- Bei file_logging=True werden Dateien rotiert, sobald die konfigurierte Groesse erreicht ist.

## Lizenz

Dieses Projekt steht unter der MIT License.
