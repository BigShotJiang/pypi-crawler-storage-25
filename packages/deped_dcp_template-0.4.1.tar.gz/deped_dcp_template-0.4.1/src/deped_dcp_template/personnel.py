"""Shared personnel-loader helper functions."""

from __future__ import annotations

from .normalization import clean_review_text


def flush_batch(
    conn, table: str, columns: list[str], rows: list[tuple[object, ...]]
) -> None:
    """Insert a batch of rows into a table."""
    if not rows:
        return
    placeholders = ", ".join("?" for _ in columns)
    sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
    conn.executemany(sql, rows)


def maybe_log_date_error(
    errors: list[tuple[object, ...]],
    source_table: str,
    source_file: str,
    source_row_num: int,
    source_record_id: int | None,
    column_name: str,
    raw_value: str | None,
    parsed_value: str | None,
) -> bool:
    """Log invalid date input and return whether it was invalid."""
    if clean_review_text(raw_value) is None or parsed_value is not None:
        return False
    errors.append(
        (
            source_table,
            source_file,
            source_row_num,
            source_record_id,
            column_name,
            clean_review_text(raw_value),
        )
    )
    return True


def duplicate_scope_key(
    entity_type: str,
    employee_id: str | None,
    region: str | None,
    division: str | None,
) -> tuple[str, str, str] | None:
    """Return the duplicate-check scope for a personnel row."""
    if employee_id is None:
        return None
    if entity_type == "REGIONAL_OFFICE":
        return entity_type, employee_id, region or ""
    return entity_type, employee_id, division or ""
