from __future__ import annotations

import json
import sqlite3
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import load_workbook

from .normalization import clean_review_text as clean_text

TEMPLATE_FILES = (
    "ict-equipment-inventory-school-template_v1.16.xlsx",
    "ict-equipment-inventory-division-template_v1.16.xlsx",
    "ict-equipment-inventory-region-template_v1.16.xlsx",
)

POSITION_CATEGORY_OVERRIDES = (
    ("Master Teacher", "TEACHING_RELATED"),
    ("Head Teacher", "TEACHING_RELATED"),
    ("Principal", "TEACHING_RELATED"),
    ("School Principal", "TEACHING_RELATED"),
    ("Assistant School Principal", "TEACHING_RELATED"),
    ("Secondary School Principal", "TEACHING_RELATED"),
    ("Assistant Secondary School Principal", "TEACHING_RELATED"),
    ("School Head", "TEACHING_RELATED"),
    ("District Supervisor", "TEACHING_RELATED"),
    ("Education Program Supervisor", "TEACHING_RELATED"),
    ("Education Program Specialist", "TEACHING_RELATED"),
    ("Supervisor", "TEACHING_RELATED"),
    ("Superintendent", "TEACHING_RELATED"),
    ("Director", "TEACHING_RELATED"),
    ("Chief Education Supervisor", "TEACHING_RELATED"),
    ("Guidance Counselor", "TEACHING_RELATED"),
    ("Guidance Coordinator", "TEACHING_RELATED"),
    ("Counselor", "TEACHING_RELATED"),
    ("Teacher", "TEACHING"),
    ("Administrative Officer", "NON_TEACHING"),
    ("Administrative Assistant", "NON_TEACHING"),
    ("Administrative Support", "NON_TEACHING"),
    ("Administrative Aide", "NON_TEACHING"),
    ("Officer", "NON_TEACHING"),
    ("Assistant", "NON_TEACHING"),
    ("Aide", "NON_TEACHING"),
    ("Attorney", "NON_TEACHING"),
    ("Accountant", "NON_TEACHING"),
    ("Bookkeeper", "NON_TEACHING"),
    ("Cashier", "NON_TEACHING"),
    ("Librarian", "NON_TEACHING"),
    ("Nurse", "NON_TEACHING"),
    ("Dentist", "NON_TEACHING"),
    ("Driver", "NON_TEACHING"),
    ("Guard", "NON_TEACHING"),
    ("Clerk", "NON_TEACHING"),
    ("Registrar", "NON_TEACHING"),
    ("Technologist", "NON_TEACHING"),
    ("Programmer", "NON_TEACHING"),
    ("Engineer", "NON_TEACHING"),
)

NON_TEACHING_POSITION_EXCEPTIONS = {
    "ASSISTANT TEACHERS CAMP SUPERINTENDENT",
    "ASSISTANT TEACHER'S CAMP SUPERINTENDENT",
    "TEACHERS CAMP SUPERINTENDENT",
    "DIRECTOR III",
    "DIRECTOR IV",
    "DIRECTORY III",
    "DIRECTORY IV",
    "PUBLIC SCHOOLS DISTRICT SUPERVISOR",
    "VOCATIONAL SCHOOL SUPERINTENDENT I",
    "SCHOOLS DIVISION SUPERINTENDENT",
    "PUBLICATION PRODUCTION SUPERVISOR",
}

POSITION_TITLE_NORMALIZATIONS = {
    "ASSISTANT TEACHER'S CAMP SUPERINTENDENT": "Assistant Teachers Camp Superintendent",
    "DIRECTORY III": "Director III",
    "DIRECTORY IV": "Director IV",
}


def normalize_key(value: str | None) -> str | None:
    if value is None:
        return None
    return "".join(ch for ch in value.upper() if ch.isalnum())


def infer_position_category(name: str) -> str:
    upper = name.upper()
    if upper in NON_TEACHING_POSITION_EXCEPTIONS:
        return "NON_TEACHING"
    if "TEACHER" in upper:
        if (
            "MASTER TEACHER" in upper
            or "HEAD TEACHER" in upper
            or "TEACHER CREDENTIALS" in upper
        ):
            return "TEACHING_RELATED"
        return "TEACHING"
    if "CAMP SUPERINTENDENT" in upper:
        return "NON_TEACHING"
    for token, category in POSITION_CATEGORY_OVERRIDES:
        if token.upper() in upper:
            return category
    return "NON_TEACHING"


def normalize_position_title(name: str) -> str:
    normalized = POSITION_TITLE_NORMALIZATIONS.get(name.upper())
    if normalized is not None:
        return normalized
    return name


def template_version_from_name(path: Path) -> str:
    stem = path.stem
    if "_v" in stem:
        return stem.rsplit("_v", 1)[1]
    return "unknown"


@dataclass(slots=True)
class ExtractedTemplate:
    source_file: str
    positions: list[tuple[str, str]]
    equipment_items: list[tuple[str, str | None]]
    equipment_brands: list[str]
    equipment_units: list[str]
    acquisition_modes: list[str]
    acquisition_sources: list[str]
    dcp_packages: list[tuple[str, str | None, str | None]]
    funds_sources: list[str]
    equipment_conditions: list[str]
    disposition_statuses: list[str]
    suffixes: list[str]
    regions: list[str]
    divisions: list[tuple[str, str]]


def _sheet_rows(path: Path, sheet_name: str):
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        for row in worksheet.iter_rows(values_only=True):
            yield row
    finally:
        workbook.close()


def extract_positions(path: Path) -> list[tuple[str, str]]:
    positions: list[tuple[str, str]] = []
    for index, row in enumerate(_sheet_rows(path, "List of Positions")):
        value = clean_text(row[0] if row else None)
        if index == 0 or value is None:
            continue
        value = normalize_position_title(value)
        positions.append((value, infer_position_category(value)))
    return positions


def extract_referential_data(path: Path) -> dict[str, list]:
    rows = list(_sheet_rows(path, "Referential Data"))
    headers = [clean_text(value) or "" for value in rows[0]]
    header_index = {header: idx for idx, header in enumerate(headers) if header}

    def idx(header_name: str) -> int:
        if header_name in header_index:
            return header_index[header_name]
        for candidate, index in header_index.items():
            if normalize_key(candidate) == normalize_key(header_name):
                return index
        raise KeyError(header_name)

    extracted: dict[str, list] = {
        "equipment_items": [],
        "equipment_brands": [],
        "equipment_units": [],
        "acquisition_modes": [],
        "acquisition_sources": [],
        "dcp_packages": [],
        "funds_sources": [],
        "equipment_conditions": [],
        "disposition_statuses": [],
        "suffixes": [],
    }
    single_value_fields = (
        ("Common ICT Equipment Brands", "equipment_brands"),
        ("Unit", "equipment_units"),
        ("Mode of Acquisition", "acquisition_modes"),
        ("Source of Acquisition", "acquisition_sources"),
        ("Source of Funds", "funds_sources"),
        ("Condition (COA classification)", "equipment_conditions"),
        ("Accountability / Disposition Status", "disposition_statuses"),
        ("Name Suffix", "suffixes"),
    )
    for row in rows[1:]:
        item = clean_text(
            row[idx("Item (Device Type, ICT Hardware, Software and peripherals)")]
        )
        item_description = clean_text(row[idx("Item Description")])
        if item:
            extracted["equipment_items"].append((item, item_description))
        for header_name, output_name in single_value_fields:
            value = clean_text(row[idx(header_name)])
            if value:
                extracted[output_name].append(value)
        package_code = clean_text(row[idx("DCP Package")])
        package_name = clean_text(row[idx("Package Name")])
        package_description = clean_text(row[idx("Package Description (Key Contents)")])
        if package_code:
            extracted["dcp_packages"].append(
                (package_code, package_name, package_description)
            )
    return extracted


def extract_regions(path: Path) -> list[str]:
    regions: list[str] = []
    for index, row in enumerate(_sheet_rows(path, "Regions")):
        if index == 0:
            continue
        formal = clean_text(row[1] if len(row) > 1 else None)
        if formal:
            regions.append(formal)
    return regions


def extract_divisions(path: Path) -> list[tuple[str, str]]:
    rows = list(_sheet_rows(path, "SDOs"))
    header = [clean_text(value) for value in rows[0]]
    region_map = {
        "I": "Region I",
        "II": "Region II",
        "III": "Region III",
        "IVA": "Region IV-A",
        "MIMAROPA": "Region IV-B",
        "V": "Region V",
        "VI": "Region VI",
        "VII": "Region VII",
        "VIII": "Region VIII",
        "IX": "Region IX",
        "X": "Region X",
        "XI": "Region XI",
        "XII": "Region XII",
        "CARAGA": "Region XIII",
        "BARMM": "BARMM",
        "CAR": "CAR",
        "NCR": "NCR",
        "NIR": "NIR",
    }
    divisions: list[tuple[str, str]] = []
    for row in rows[1:]:
        for idx, value in enumerate(row):
            division = clean_text(value)
            region = region_map.get(header[idx] or "")
            if division and region:
                divisions.append((region, division))
    return divisions


def extract_template(path: Path) -> ExtractedTemplate:
    referential = extract_referential_data(path)
    return ExtractedTemplate(
        source_file=path.name,
        positions=extract_positions(path),
        equipment_items=referential["equipment_items"],
        equipment_brands=referential["equipment_brands"],
        equipment_units=referential["equipment_units"],
        acquisition_modes=referential["acquisition_modes"],
        acquisition_sources=referential["acquisition_sources"],
        dcp_packages=referential["dcp_packages"],
        funds_sources=referential["funds_sources"],
        equipment_conditions=referential["equipment_conditions"],
        disposition_statuses=referential["disposition_statuses"],
        suffixes=referential["suffixes"],
        regions=extract_regions(path),
        divisions=extract_divisions(path),
    )


def resolve_templates_dir(templates_dir: str | Path) -> Path:
    directory = Path(templates_dir)
    if directory.exists():
        return directory

    if directory == Path("templates"):
        package_templates = Path(__file__).resolve().parent / "templates"
        if package_templates.exists():
            return package_templates

        repo_templates = Path(__file__).resolve().parents[2] / "templates"
        if repo_templates.exists():
            return repo_templates

    raise FileNotFoundError(f"Template directory does not exist: {directory}")


def find_templates(templates_dir: str | Path) -> list[Path]:
    directory = resolve_templates_dir(templates_dir)
    paths = [directory / name for name in TEMPLATE_FILES]
    missing = [path.name for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing template files: {', '.join(missing)}")
    return paths


def dedupe_rows(values: list[tuple]) -> list[tuple]:
    seen = set()
    deduped: list[tuple] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def compare_sets(name: str, payloads: list[tuple[str, set]]) -> dict[str, object]:
    baseline_name, baseline_values = payloads[0]
    mismatches = []
    for source_name, values in payloads[1:]:
        if values != baseline_values:
            mismatches.append(
                {
                    "source_file": source_name,
                    "missing_from_source": sorted(baseline_values - values)[:25],
                    "extra_in_source": sorted(values - baseline_values)[:25],
                }
            )
    return {
        "dataset": name,
        "baseline_source": baseline_name,
        "baseline_count": len(baseline_values),
        "consistent": not mismatches,
        "mismatches": mismatches,
    }


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE positions(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL
        );
        CREATE TABLE equipment_items(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE,
            description TEXT
        );
        CREATE TABLE equipment_brands(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE equipment_units(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE acquisition_modes(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE acquisition_sources(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE dcp_packages(
            id INTEGER PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            name TEXT,
            description TEXT
        );
        CREATE TABLE funds_sources(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE equipment_conditions(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE disposition_statuses(
            id INTEGER PRIMARY KEY,
            canonical_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE suffixes(
            id INTEGER PRIMARY KEY,
            value TEXT NOT NULL UNIQUE
        );
        CREATE TABLE regions(
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE divisions(
            id INTEGER PRIMARY KEY,
            region_id INTEGER NOT NULL REFERENCES regions(id),
            name TEXT NOT NULL,
            UNIQUE(region_id, name)
        );
        CREATE TABLE _meta(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """
    )


def insert_canonical_table(
    conn: sqlite3.Connection, table_name: str, column_name: str, values: list[str]
) -> None:
    rows = [(value,) for value in sorted(set(values))]
    conn.executemany(
        f"INSERT INTO {table_name}({column_name}) VALUES (?)",
        rows,
    )


def build_lookup_db(templates_dir: str | Path, output_path: str | Path) -> None:
    template_paths = find_templates(templates_dir)
    extracted = [extract_template(path) for path in template_paths]
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    conn = sqlite3.connect(output)
    try:
        create_schema(conn)
        positions = dedupe_rows(
            sorted(
                {
                    (name, category)
                    for template in extracted
                    for name, category in template.positions
                }
            )
        )
        conn.executemany(
            "INSERT INTO positions(canonical_name, category) VALUES (?, ?)", positions
        )
        item_rows = dedupe_rows(
            sorted(
                {
                    (name, description)
                    for template in extracted
                    for name, description in template.equipment_items
                }
            )
        )
        conn.executemany(
            "INSERT INTO equipment_items(canonical_name, description) VALUES (?, ?)",
            item_rows,
        )
        insert_canonical_table(
            conn,
            "equipment_brands",
            "canonical_name",
            [value for template in extracted for value in template.equipment_brands],
        )
        insert_canonical_table(
            conn,
            "equipment_units",
            "canonical_name",
            [value for template in extracted for value in template.equipment_units],
        )
        insert_canonical_table(
            conn,
            "acquisition_modes",
            "canonical_name",
            [value for template in extracted for value in template.acquisition_modes],
        )
        insert_canonical_table(
            conn,
            "acquisition_sources",
            "canonical_name",
            [value for template in extracted for value in template.acquisition_sources],
        )
        conn.executemany(
            "INSERT INTO dcp_packages(code, name, description) VALUES (?, ?, ?)",
            dedupe_rows(
                sorted(
                    {value for template in extracted for value in template.dcp_packages}
                )
            ),
        )
        insert_canonical_table(
            conn,
            "funds_sources",
            "canonical_name",
            [value for template in extracted for value in template.funds_sources],
        )
        insert_canonical_table(
            conn,
            "equipment_conditions",
            "canonical_name",
            [
                value
                for template in extracted
                for value in template.equipment_conditions
            ],
        )
        insert_canonical_table(
            conn,
            "disposition_statuses",
            "canonical_name",
            [
                value
                for template in extracted
                for value in template.disposition_statuses
            ],
        )
        insert_canonical_table(
            conn,
            "suffixes",
            "value",
            [value for template in extracted for value in template.suffixes],
        )
        insert_canonical_table(
            conn,
            "regions",
            "name",
            [value for template in extracted for value in template.regions],
        )
        region_lookup = {
            name: region_id
            for region_id, name in conn.execute("SELECT id, name FROM regions")
        }
        conn.executemany(
            "INSERT INTO divisions(region_id, name) VALUES (?, ?)",
            dedupe_rows(
                sorted(
                    (
                        region_lookup[region_name],
                        division_name,
                    )
                    for template in extracted
                    for region_name, division_name in template.divisions
                    if region_name in region_lookup
                )
            ),
        )

        consistency_checks = [
            compare_sets(
                "positions",
                [(t.source_file, {name for name, _ in t.positions}) for t in extracted],
            ),
            compare_sets(
                "equipment_brands",
                [(t.source_file, set(t.equipment_brands)) for t in extracted],
            ),
            compare_sets(
                "regions",
                [(t.source_file, set(t.regions)) for t in extracted],
            ),
            compare_sets(
                "divisions",
                [(t.source_file, set(t.divisions)) for t in extracted],
            ),
        ]
        template_version = template_version_from_name(template_paths[0])
        meta = {
            "template_version": template_version,
            "source_files": json.dumps([path.name for path in template_paths]),
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "consistency_checks": json.dumps(consistency_checks),
        }
        for key, value in meta.items():
            conn.execute("INSERT INTO _meta(key, value) VALUES (?, ?)", (key, value))
        conn.commit()
    finally:
        conn.close()


def describe_lookup_db(db_path: str | Path) -> dict[str, object]:
    conn = sqlite3.connect(db_path)
    try:
        counts = {
            table: conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in (
                "positions",
                "equipment_items",
                "equipment_brands",
                "equipment_units",
                "acquisition_modes",
                "acquisition_sources",
                "dcp_packages",
                "funds_sources",
                "equipment_conditions",
                "disposition_statuses",
                "suffixes",
                "regions",
                "divisions",
            )
        }
        meta = dict(conn.execute("SELECT key, value FROM _meta"))
        consistency = json.loads(meta.get("consistency_checks", "[]"))
        summary = Counter(check["consistent"] for check in consistency)
        return {"counts": counts, "meta": meta, "consistency_summary": dict(summary)}
    finally:
        conn.close()
