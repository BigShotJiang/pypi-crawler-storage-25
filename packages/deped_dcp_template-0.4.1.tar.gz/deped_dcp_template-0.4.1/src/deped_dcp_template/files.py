"""Shared CSV and Excel row helpers."""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path
from typing import Iterable, Iterator

from openpyxl import load_workbook
from rich.progress import Progress, TaskID

from .normalization import normalize_label as normalize_header


class ProgressReader:
    """Proxy a text file and advance a Rich task by bytes read."""

    def __init__(self, handle, progress: Progress, task_id: TaskID):
        self.handle = handle
        self.progress = progress
        self.task_id = task_id

    def __iter__(self):
        return self

    def __next__(self):
        line = next(self.handle)
        self.progress.update(self.task_id, advance=len(line.encode("utf-8")))
        return line

    def __getattr__(self, name: str):
        return getattr(self.handle, name)


def deduplicate_headers(headers: Iterable[object | None]) -> list[str]:
    """Normalize headers and suffix duplicate names with a 1-based occurrence."""
    seen_headers: Counter[str] = Counter()
    normalized_headers: list[str] = []
    for header in headers:
        normalized_header = normalize_header(header)
        seen_headers[normalized_header] += 1
        if seen_headers[normalized_header] > 1:
            normalized_header = f"{normalized_header} {seen_headers[normalized_header]}"
        normalized_headers.append(normalized_header)
    return normalized_headers


def iter_csv_rows(
    path: str | Path,
    progress: Progress | None = None,
    task_id: TaskID | None = None,
) -> Iterable[tuple[int, dict[str, str]]]:
    """Yield normalized CSV rows along with their source row numbers."""
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        stream = (
            ProgressReader(handle, progress, task_id)
            if progress is not None and task_id is not None
            else handle
        )
        reader = csv.reader(stream)
        try:
            headers = deduplicate_headers(next(reader))
        except StopIteration:
            return
        last_row_num = 1
        for row_num, values in enumerate(reader, start=2):
            last_row_num = row_num
            normalized_row = {
                header: values[index] if index < len(values) else ""
                for index, header in enumerate(headers)
            }
            if progress is not None and task_id is not None and row_num % 1000 == 0:
                base_description = progress.tasks[task_id].description.split(" (", 1)[0]
                progress.update(
                    task_id, description=f"{base_description} ({row_num - 1:,} rows)"
                )
            yield row_num, normalized_row
        if progress is not None and task_id is not None:
            base_description = progress.tasks[task_id].description.split(" (", 1)[0]
            progress.update(
                task_id,
                description=f"{base_description} ({max(last_row_num - 1, 0):,} rows)",
            )


def iter_sheet_rows(
    workbook_path: str | Path,
    sheet_name: str,
    *,
    header_row: int = 1,
) -> Iterator[tuple[int, dict[str, object]]]:
    """Yield normalized rows from a workbook sheet."""
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        rows = worksheet.iter_rows(values_only=True)
        for _ in range(header_row - 1):
            next(rows, None)
        headers = deduplicate_headers(next(rows, ()))
        for row_num, values in enumerate(rows, start=header_row + 1):
            yield (
                row_num,
                {
                    header: values[index] if index < len(values) else None
                    for index, header in enumerate(headers)
                },
            )
    finally:
        workbook.close()


def workbook_sheet_names(workbook_path: str | Path) -> list[str]:
    """Return workbook sheet names without loading cell data."""
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        return list(workbook.sheetnames)
    finally:
        workbook.close()
