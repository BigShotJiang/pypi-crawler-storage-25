"""Shared text normalization helpers."""

from __future__ import annotations

import re

from .constants import NULL_LIKE_COMPACT_VALUES, NULL_LIKE_VALUES


def normalize_label(value: object | None) -> str:
    """Return a whitespace-normalized label suitable for headers and keys."""
    if value is None:
        return ""
    text = str(value).replace("\ufeff", "").replace("\xa0", " ").strip()
    return re.sub(r"\s+", " ", text)


def normalize_null_key(value: object | None) -> str:
    """Return a compact uppercase key for null-placeholder comparisons."""
    return re.sub(r"[^A-Za-z0-9]+", "", normalize_label(value).upper())


def is_null_like(
    value: object | None,
    *,
    extra_values: set[str] | frozenset[str] | None = None,
    numeric_placeholder: bool = False,
    na_numeric_placeholder: bool = False,
) -> bool:
    """Return whether a value is blank or an explicit null-like placeholder."""
    text = normalize_label(value)
    if not text:
        return True
    if re.fullmatch(r"[-_/\\.\s]+", text):
        return True
    upper = text.upper()
    if upper in NULL_LIKE_VALUES:
        return True
    compact = normalize_null_key(text)
    compact_values = set(NULL_LIKE_COMPACT_VALUES)
    if extra_values:
        compact_values.update(normalize_null_key(value) for value in extra_values)
    if compact in compact_values:
        return True
    if na_numeric_placeholder and re.fullmatch(r"(?:NA)+9{3,}", compact):
        return True
    if numeric_placeholder and re.fullmatch(r"9{3,}", compact):
        return True
    return False


def clean_null_like(
    value: object | None,
    *,
    extra_values: set[str] | frozenset[str] | None = None,
    numeric_placeholder: bool = False,
    na_numeric_placeholder: bool = False,
) -> str | None:
    """Normalize text and collapse configured null-like placeholders."""
    text = normalize_label(value)
    if is_null_like(
        text,
        extra_values=extra_values,
        numeric_placeholder=numeric_placeholder,
        na_numeric_placeholder=na_numeric_placeholder,
    ):
        return None
    return text


def clean_review_text(value: object | None) -> str | None:
    """Normalize freeform review/audit text while preserving human casing."""
    return clean_null_like(value)


def normalize_review_key(value: object | None) -> str:
    """Return a stable uppercase key for matching review/audit labels."""
    text = clean_review_text(value)
    if text is None:
        return ""
    key = re.sub(r"[^A-Za-z0-9]+", "_", text.upper()).strip("_")
    return re.sub(r"_+", "_", key)
