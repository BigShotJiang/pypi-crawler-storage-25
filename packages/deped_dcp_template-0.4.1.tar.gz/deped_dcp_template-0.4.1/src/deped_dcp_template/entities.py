"""Shared governance entity helpers."""

from __future__ import annotations

from collections import Counter

from .constants import ENTITY_TYPES
from .normalization import clean_review_text


def determine_entity_type(governance_level: str | None) -> str:
    """Map a governance level string to an entity type."""
    level = (clean_review_text(governance_level) or "").upper()
    if level not in ENTITY_TYPES:
        raise ValueError(f"Unsupported governance level: {governance_level!r}")
    return level


def build_natural_key(
    entity_type: str,
    school_id: int | None,
    region: str | None,
    division: str | None,
) -> str:
    """Construct the entity natural key."""
    if entity_type == "SCHOOL":
        if school_id is None:
            raise ValueError("SCHOOL entity requires school_id")
        return f"SCHOOL:{school_id}"
    if entity_type == "DIVISION_OFFICE":
        if not region or not division:
            raise ValueError("DIVISION_OFFICE requires region and division")
        return f"DIVISION_OFFICE:{region}:{division}"
    if not region:
        raise ValueError("REGIONAL_OFFICE requires region")
    return f"REGIONAL_OFFICE:{region}"


def choose_preferred_text(counter: Counter[str]) -> str | None:
    """Choose the most representative non-empty value from observed variants."""
    if not counter:
        return None
    return sorted(counter.items(), key=lambda item: (-item[1], -len(item[0]), item[0]))[
        0
    ][0]


def derive_entity_name(
    entity_type: str,
    school_name: str | None,
    region: str | None,
    division: str | None,
) -> str:
    """Build the display name for an entity."""
    if entity_type == "SCHOOL":
        if school_name:
            return school_name
        if division:
            return f"School {division}"
        raise ValueError("SCHOOL entity requires school_name")
    if entity_type == "DIVISION_OFFICE":
        return f"{division} Division Office"
    return f"{region} Regional Office"
