from __future__ import annotations

import json

import click

from .console import command_step, get_console
from .extractor import build_lookup_db, describe_lookup_db
from .r2 import (
    download_files,
    list_objects,
    load_settings_for_cli,
    normalize_r2_prefix,
    print_summary,
    upload_files,
)

CONSOLE = get_console()


@click.group()
def main() -> None:
    """Template lookup database utilities."""


@main.command("extract")
@click.option("--templates-dir", required=True, type=click.Path(file_okay=False))
@click.option("--output", required=True, type=click.Path(dir_okay=False))
def extract_command(templates_dir: str, output: str) -> None:
    try:
        with CONSOLE.status("Extracting template lookup database...", spinner="dots"):
            build_lookup_db(templates_dir, output)
    except FileNotFoundError as exc:
        raise click.BadParameter(str(exc), param_hint="--templates-dir") from exc
    click.echo(output)


@main.command("show")
@click.option(
    "--db", "db_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
def show_command(db_path: str) -> None:
    with command_step("Loading template lookup summary..."):
        summary = describe_lookup_db(db_path)
    click.echo(json.dumps(summary, indent=2, sort_keys=True))


@main.group("r2")
def r2_group() -> None:
    """Cloudflare R2 transfer utilities."""


def _load_r2_settings():
    try:
        return load_settings_for_cli()
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc


@r2_group.command("upload")
@click.option("--source", required=True, type=click.Path(exists=True))
@click.option(
    "--prefix", default=None, help="Remote key prefix. Defaults to R2_PREFIX."
)
@click.option(
    "--include",
    "includes",
    multiple=True,
    help="Glob pattern relative to --source. Repeatable.",
)
@click.option("--overwrite", is_flag=True, help="Replace existing remote objects.")
@click.option("--dry-run", is_flag=True, help="Plan transfer without uploading.")
def r2_upload_command(
    source: str,
    prefix: str | None,
    includes: tuple[str, ...],
    overwrite: bool,
    dry_run: bool,
) -> None:
    """Upload files to Cloudflare R2."""
    settings = _load_r2_settings()
    try:
        summary = upload_files(
            source,
            prefix=prefix,
            settings=settings,
            include=includes or None,
            overwrite=overwrite,
            dry_run=dry_run,
        )
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc
    print_summary(summary)


@r2_group.command("download")
@click.option("--target", required=True, type=click.Path(file_okay=False))
@click.option(
    "--prefix", default=None, help="Remote key prefix. Defaults to R2_PREFIX."
)
@click.option("--overwrite", is_flag=True, help="Replace existing local files.")
@click.option("--dry-run", is_flag=True, help="Plan transfer without downloading.")
def r2_download_command(
    target: str,
    prefix: str | None,
    overwrite: bool,
    dry_run: bool,
) -> None:
    """Download files from Cloudflare R2."""
    settings = _load_r2_settings()
    try:
        summary = download_files(
            target,
            prefix=prefix,
            settings=settings,
            overwrite=overwrite,
            dry_run=dry_run,
        )
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc
    print_summary(summary)


@r2_group.command("ls")
@click.option(
    "--prefix", default=None, help="Remote key prefix. Defaults to R2_PREFIX."
)
def r2_ls_command(prefix: str | None) -> None:
    """List Cloudflare R2 objects."""
    settings = _load_r2_settings()
    resolved_prefix = normalize_r2_prefix(
        prefix if prefix is not None else settings.prefix
    )
    try:
        objects = list_objects(prefix=resolved_prefix, settings=settings)
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(json.dumps(objects, indent=2, default=str))


if __name__ == "__main__":
    main()
