"""Analytics tool handlers for the Distillery MCP server.

Implements the following tools:
  - distillery_metrics: Aggregate usage and quality metrics from the DuckDB store.
  - distillery_stale: Entries not accessed within a staleness window.
  - distillery_tag_tree: Nested tag hierarchy from active entries.
  - distillery_interests: Interest profile mined from stored entries (optionally
    includes feed source suggestions when suggest_sources=True).
  - distillery_type_schemas: Full metadata schema registry for all entry types.
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mcp import types

from distillery.config import DistilleryConfig
from distillery.mcp.tools._common import (
    error_response,
    success_response,
    validate_type,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Storage path helpers (duplicated here to avoid circular imports with server)
# ---------------------------------------------------------------------------


def _is_remote_db_path(path: str) -> bool:
    """Return True for S3 or MotherDuck URIs that should not be treated as local paths."""
    return path.startswith("s3://") or path.startswith("md:")


def _normalize_db_path(raw: str) -> str:
    """Expand ``~`` for local paths; leave cloud URIs (S3/MotherDuck) untouched."""
    if _is_remote_db_path(raw):
        return raw
    return os.path.expanduser(raw)


# ---------------------------------------------------------------------------
# _handle_tag_tree
# ---------------------------------------------------------------------------


async def _handle_tag_tree(
    store: Any,
    arguments: dict[str, Any],
) -> list[types.TextContent]:
    """Implement the ``distillery_tag_tree`` tool.

    Fetches all tags from active entries and builds a nested dict tree.
    Each node has a ``count`` (entries whose tags fall under that subtree)
    and a ``children`` dict.

    Args:
        store: Initialised ``DuckDBStore``.
        arguments: Dict with optional key ``prefix`` (str | None).

    Returns:
        MCP content list with a JSON payload containing ``tree`` and ``prefix``.
    """
    prefix: str | None = arguments.get("prefix")

    def _build_tree_from_vocab(vocab: dict[str, int], prefix_arg: str | None) -> dict[str, Any]:
        """Build the nested hierarchy from a tag vocabulary dict.

        Args:
            vocab: Tag -> count mapping from get_tag_vocabulary().
            prefix_arg: The original prefix argument (used to strip tags).

        Returns:
            Nested tree dict with count and children at each node.
        """
        # Strip the prefix from the tags so the tree is rooted at the prefix.
        processed_tags: dict[str, int] = {}
        if prefix_arg is not None:
            prefix_slash = prefix_arg + "/"
            for tag, count in vocab.items():
                if tag == prefix_arg:
                    # Tag exactly matches the prefix
                    processed_tags[""] = count
                elif tag.startswith(prefix_slash):
                    # Strip the prefix and its trailing slash
                    stripped = tag[len(prefix_slash) :]
                    processed_tags[stripped] = count
        else:
            processed_tags = vocab

        # Build the tree from path segments.
        # Each node: {"count": int, "children": {segment: node}, "_counts": dict}
        # _counts maps each leaf tag to its entry count for aggregation upward.
        root: dict[str, Any] = {"count": 0, "children": {}, "_counts": {}}

        for tag, count in processed_tags.items():
            if not tag:
                # This is the root (prefix exactly matched)
                root["_counts"]["<root>"] = count
                continue
            segments = tag.split("/")
            node = root
            for i, seg in enumerate(segments):
                if seg not in node["children"]:
                    node["children"][seg] = {"count": 0, "children": {}, "_counts": {}}
                node = node["children"][seg]
                # At the leaf, record the full tag and its count
                if i == len(segments) - 1:
                    node["_counts"][tag] = count

        # Convert _counts to actual counts and aggregate up the tree.
        # The count at a node represents how many distinct entries have any tag
        # under that node. Since the vocabulary only tracks one count per tag,
        # we need to accumulate counts from all leaf tags under each node.
        def _finalize(n: dict[str, Any]) -> None:
            # At leaf nodes, _counts has tag -> entry_count mappings.
            # For intermediate nodes, accumulate from children.
            if n["_counts"]:
                # This is a leaf node or partially populated node
                # Sum the counts from all registered tags here
                n["count"] = sum(n["_counts"].values())
            else:
                n["count"] = 0

            for child in n["children"].values():
                _finalize(child)
                # Accumulate child counts (they already include their descendants)
                # But we need to be careful: if an entry has multiple tags under
                # this subtree, we don't want to double-count it. However, since
                # we're only summing leaf tags (entries only have specific tags),
                # this is correct.
                n["count"] += child["count"]
            n.pop("_counts", None)

        _finalize(root)

        return root

    try:
        # Fetch tag vocabulary using the store's method
        vocab = await store.get_tag_vocabulary(prefix=prefix)
        tree = _build_tree_from_vocab(vocab, prefix)
    except Exception:  # noqa: BLE001
        logger.exception("Error in distillery_tag_tree")
        return error_response("INTERNAL", "Failed to build tag tree")

    return success_response({"tree": tree, "prefix": prefix})


# ---------------------------------------------------------------------------
# _handle_type_schemas
# ---------------------------------------------------------------------------


async def _handle_type_schemas() -> list[types.TextContent]:
    """Implement the ``distillery_type_schemas`` tool.

    Returns the full metadata schema registry for all known entry types.
    Types with structured schemas (``person``, ``project``, ``digest``,
    ``github``) include their required/optional/constraints definitions.
    Legacy types are reported with empty required/optional dicts.

    Returns:
        MCP content list with a JSON payload containing a ``schemas`` dict.
    """
    from distillery.models import TYPE_METADATA_SCHEMAS, EntryType

    all_schemas: dict[str, Any] = {}

    # For each known entry type, include its schema (or empty dicts for legacy).
    for et in EntryType:
        schema = TYPE_METADATA_SCHEMAS.get(et.value, {})
        all_schemas[et.value] = {
            "required": schema.get("required", {}),
            "optional": schema.get("optional", {}),
        }
        if "constraints" in schema:
            all_schemas[et.value]["constraints"] = schema["constraints"]

    return success_response({"schemas": all_schemas})


# ---------------------------------------------------------------------------
# _handle_metrics
# ---------------------------------------------------------------------------


_VALID_METRICS_SCOPES = frozenset({"summary", "full", "search_quality", "audit"})


async def _handle_metrics(
    store: Any,
    config: DistilleryConfig,
    embedding_provider: Any,
    arguments: dict[str, Any],
) -> list[types.TextContent]:
    """
    Aggregate usage and quality metrics from the DuckDB store for the Distillery instance.

    Parameters:
        store: Initialised store with a live ``connection``.
        config: Loaded :class:`~distillery.config.DistilleryConfig`.
        embedding_provider: Active embedding provider (used to report model metadata).
        arguments: Tool arguments; supports optional ``period_days`` (int) specifying
            the lookback window in days (must be >= 1), and optional ``scope``
            (``"summary"`` | ``"full"`` | ``"search_quality"`` | ``"audit"``,
            default ``"full"``):

            - ``"summary"``: entry counts by type/status, database size, embedding model info
              (equivalent to the former ``distillery_status`` output).
            - ``"full"``: complete metrics payload — entries, activity, search, quality,
              staleness, and storage sections (default behaviour).
            - ``"search_quality"``: search totals, feedback rates, and quality breakdown
              (equivalent to the former ``distillery_quality`` output).
            - ``"audit"``: login and operation audit data — recent_logins, login_summary,
              active_users, and recent_operations sections.  Accepts optional ``date_from``
              (ISO 8601 str) and ``user`` (str) filters.  Incompatible with ``entry_type``.

    Returns:
        MCP content list with aggregated metrics shaped by the requested scope.
    """
    # --- validate scope -----------------------------------------------------
    scope_raw = arguments.get("scope", "full")
    if not isinstance(scope_raw, str):
        return error_response("INVALID_PARAMS", "Field 'scope' must be a string")
    scope = scope_raw
    if scope not in _VALID_METRICS_SCOPES:
        return error_response(
            "INVALID_PARAMS",
            f"Field 'scope' must be one of: {', '.join(sorted(_VALID_METRICS_SCOPES))}",
        )

    # --- scope=search_quality delegates to _handle_quality ------------------
    if scope == "search_quality":
        entry_type_filter: str | None = arguments.get("entry_type")
        try:
            result = await asyncio.to_thread(_sync_gather_quality, store, entry_type_filter)
            return success_response(result)
        except Exception:  # noqa: BLE001
            logger.exception("Error gathering quality metrics")
            return error_response("INTERNAL", "Failed to gather quality metrics")

    # --- scope=audit -----------------------------------------------------------
    if scope == "audit":
        # entry_type is incompatible with audit scope
        if "entry_type" in arguments:
            return error_response(
                "INVALID_PARAMS",
                "Field 'entry_type' is not compatible with scope='audit'",
            )
        # validate date_from
        date_from: str | None = arguments.get("date_from")
        if date_from is not None and not isinstance(date_from, str):
            return error_response("INVALID_PARAMS", "Field 'date_from' must be a string")
        if date_from is not None:
            try:
                datetime.fromisoformat(date_from)
            except (ValueError, TypeError):
                return error_response(
                    "INVALID_PARAMS", "Field 'date_from' must be a valid ISO 8601 string"
                )
        # validate user
        audit_user: str | None = arguments.get("user")
        if audit_user is not None and not isinstance(audit_user, str):
            return error_response("INVALID_PARAMS", "Field 'user' must be a string")
        try:
            result_audit = await _gather_audit(store, date_from=date_from, user=audit_user)
            return success_response(result_audit)
        except Exception:  # noqa: BLE001
            logger.exception("Error gathering audit metrics")
            return error_response("INTERNAL", "Failed to gather audit metrics")

    # --- scope=summary delegates to _sync_gather_summary --------------------
    if scope == "summary":
        try:
            result_summary = await asyncio.to_thread(
                _sync_gather_summary, store, config, embedding_provider
            )
            return success_response(result_summary)
        except Exception:  # noqa: BLE001
            logger.exception("Error gathering summary metrics")
            return error_response("INTERNAL", "Failed to gather summary")

    # --- scope=full (default) -----------------------------------------------
    # --- validate period_days -----------------------------------------------
    period_days_raw = arguments.get("period_days", 30)
    err_period = validate_type(arguments, "period_days", int, "integer")
    if err_period:
        return error_response("INVALID_PARAMS", err_period)
    period_days = int(period_days_raw) if period_days_raw is not None else 30
    if period_days < 1:
        return error_response("INVALID_PARAMS", "Field 'period_days' must be >= 1")

    try:
        metrics = await asyncio.to_thread(
            _sync_gather_metrics, store, config, embedding_provider, period_days
        )
        return success_response(metrics)
    except Exception:  # noqa: BLE001
        logger.exception("Error gathering metrics")
        return error_response("INTERNAL", "Failed to gather metrics")


def _sync_gather_summary(
    store: Any,
    config: DistilleryConfig,
    embedding_provider: Any,
) -> dict[str, Any]:
    """
    Gather summary statistics from DuckDB — equivalent to the former ``distillery_status`` output.

    Returns entry counts by type and status, database size, and embedding model info.
    Used when ``scope="summary"`` is passed to ``_handle_metrics``.

    Parameters:
        store: Initialized DuckDBStore exposing a live ``connection``.
        config: Loaded DistilleryConfig (used for storage path resolution and rate limits).
        embedding_provider: Active embedding provider (used to report model metadata).

    Returns:
        A JSON-serializable dict with keys matching the former ``distillery_status`` response:
        ``status``, ``total_entries``, ``entries_by_type``, ``entries_by_status``,
        ``database_size_bytes``, ``embedding_model``, ``embedding_dimensions``,
        ``database_path``, ``embedding_usage_today``, ``embedding_budget_daily``,
        ``version``, and optionally ``warnings``.
    """
    import contextlib

    conn = store.connection

    # Total entry count (all statuses).
    total_row = conn.execute("SELECT COUNT(*) FROM entries").fetchone()
    total_entries: int = total_row[0] if total_row else 0

    # Counts grouped by entry_type.
    type_rows = conn.execute(
        "SELECT entry_type, COUNT(*) AS cnt FROM entries GROUP BY entry_type ORDER BY cnt DESC"
    ).fetchall()
    entries_by_type = {row[0]: row[1] for row in type_rows}

    # Counts grouped by status.
    status_rows = conn.execute(
        "SELECT status, COUNT(*) AS cnt FROM entries GROUP BY status ORDER BY cnt DESC"
    ).fetchall()
    entries_by_status = {row[0]: row[1] for row in status_rows}

    # Database file size.
    db_path = _normalize_db_path(config.storage.database_path)
    database_size_bytes: int | None = None
    if db_path != ":memory:" and not _is_remote_db_path(db_path):
        try:
            database_size_bytes = Path(db_path).stat().st_size
        except OSError:
            database_size_bytes = None

    # Embedding model info.
    model_name = getattr(embedding_provider, "model_name", "unknown")
    embedding_dimensions = getattr(embedding_provider, "dimensions", None)

    # Embedding budget usage.
    from distillery.mcp.budget import get_daily_usage

    embedding_usage_today = 0
    embedding_budget_daily = config.rate_limit.embedding_budget_daily
    with contextlib.suppress(Exception):
        embedding_usage_today = get_daily_usage(conn)

    # Storage warnings.
    warnings: list[str] = []
    rl = config.rate_limit
    if database_size_bytes is not None and rl.max_db_size_mb > 0:
        size_mb = database_size_bytes / (1024 * 1024)
        warn_threshold_mb = rl.max_db_size_mb * rl.warn_db_size_pct / 100
        if size_mb >= rl.max_db_size_mb:
            warnings.append(
                f"Database size ({size_mb:.1f} MB) has reached the limit "
                f"({rl.max_db_size_mb} MB). New writes will be rejected."
            )
        elif size_mb >= warn_threshold_mb:
            warnings.append(
                f"Database size ({size_mb:.1f} MB) is at "
                f"{size_mb / rl.max_db_size_mb * 100:.0f}% of the "
                f"{rl.max_db_size_mb} MB limit."
            )

    if embedding_budget_daily > 0 and embedding_usage_today >= embedding_budget_daily:
        warnings.append(
            f"Daily embedding budget exhausted: {embedding_usage_today}/{embedding_budget_daily} "
            "calls used."
        )

    from distillery import __version__

    result: dict[str, Any] = {
        "status": "ok",
        "version": __version__,
        "total_entries": total_entries,
        "entries_by_type": entries_by_type,
        "entries_by_status": entries_by_status,
        "database_size_bytes": database_size_bytes,
        "embedding_model": model_name,
        "embedding_dimensions": embedding_dimensions,
        "database_path": db_path,
        "embedding_usage_today": embedding_usage_today,
        "embedding_budget_daily": embedding_budget_daily,
    }
    if warnings:
        result["warnings"] = warnings
    return result


def _sync_gather_metrics(
    store: Any,
    config: DistilleryConfig,
    embedding_provider: Any,
    period_days: int,
) -> dict[str, Any]:
    """
    Gather comprehensive DuckDB-backed metrics for Distillery.

    Collects entry counts, activity windows, search statistics (if available),
    feedback quality (if available), staleness estimates, and storage/embedding
    metadata; missing auxiliary tables yield zeroed metrics.

    Parameters:
        store: Initialized DuckDBStore exposing a live ``connection``.
        config: Loaded DistilleryConfig (used for storage path resolution).
        embedding_provider: Active embedding provider (used to report model metadata).
        period_days: Number of days for the "recent" activity/search window.

    Returns:
        A JSON-serializable dict with keys: ``entries``, ``activity``, ``search``,
        ``quality``, ``staleness``, and ``storage``, each containing aggregated metrics.
    """
    conn = store.connection

    # ------------------------------------------------------------------ #
    # entries section                                                      #
    # ------------------------------------------------------------------ #
    total_row = conn.execute("SELECT COUNT(*) FROM entries WHERE status != 'archived'").fetchone()
    total_entries: int = total_row[0] if total_row else 0

    type_rows = conn.execute(
        "SELECT entry_type, COUNT(*) AS cnt FROM entries "
        "WHERE status != 'archived' GROUP BY entry_type ORDER BY cnt DESC"
    ).fetchall()
    by_type = {row[0]: row[1] for row in type_rows}

    status_rows = conn.execute(
        "SELECT status, COUNT(*) AS cnt FROM entries GROUP BY status ORDER BY cnt DESC"
    ).fetchall()
    by_status = {row[0]: row[1] for row in status_rows}

    source_rows = conn.execute(
        "SELECT source, COUNT(*) AS cnt FROM entries "
        "WHERE status != 'archived' GROUP BY source ORDER BY cnt DESC"
    ).fetchall()
    by_source = {row[0]: row[1] for row in source_rows}

    entries_section: dict[str, Any] = {
        "total": total_entries,
        "by_type": by_type,
        "by_status": by_status,
        "by_source": by_source,
    }

    # ------------------------------------------------------------------ #
    # activity section                                                     #
    # ------------------------------------------------------------------ #
    def _count_where(column: str, days: int) -> int:
        """
        Count entries in the ``entries`` table whose timestamp in the given column
        is within the past ``days``.

        Parameters:
            column: Name of a datetime column in the ``entries`` table.
            days: Number of days for the lookback window.

        Returns:
            int: The number of rows matching the condition.
        """
        row = conn.execute(
            f"SELECT COUNT(*) FROM entries "
            f"WHERE {column} > CURRENT_TIMESTAMP - (? * INTERVAL '1 day')",
            [days],
        ).fetchone()
        return row[0] if row else 0

    activity_section: dict[str, Any] = {
        "created_7d": _count_where("created_at", 7),
        "created_30d": _count_where("created_at", 30),
        "created_90d": _count_where("created_at", 90),
        "updated_7d": _count_where("updated_at", 7),
        "updated_30d": _count_where("updated_at", 30),
        "updated_90d": _count_where("updated_at", 90),
        f"created_{period_days}d": _count_where("created_at", period_days),
        f"updated_{period_days}d": _count_where("updated_at", period_days),
    }

    # ------------------------------------------------------------------ #
    # search section (search_log table may not exist yet)                 #
    # ------------------------------------------------------------------ #
    search_section: dict[str, Any] = {
        "total_searches": 0,
        "searches_7d": 0,
        "searches_30d": 0,
        f"searches_{period_days}d": 0,
        "avg_results_per_search": 0.0,
    }
    try:
        _table_exists = conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'search_log'"
        ).fetchone()
        if _table_exists and _table_exists[0] > 0:
            total_searches_row = conn.execute("SELECT COUNT(*) FROM search_log").fetchone()
            total_searches: int = total_searches_row[0] if total_searches_row else 0

            def _count_searches(days: int) -> int:
                """
                Count search log entries with timestamps within the last ``days`` days.

                Parameters:
                    days: Number of days to look back from the current time.

                Returns:
                    int: Number of search_log rows with timestamp > now - ``days`` days.
                """
                r = conn.execute(
                    f"SELECT COUNT(*) FROM search_log "
                    f"WHERE timestamp > CURRENT_TIMESTAMP - INTERVAL '{days} days'"
                ).fetchone()
                return r[0] if r else 0

            avg_row = conn.execute(
                "SELECT AVG(array_length(result_entry_ids)) FROM search_log"
            ).fetchone()
            avg_results = float(avg_row[0]) if avg_row and avg_row[0] is not None else 0.0

            search_section = {
                "total_searches": total_searches,
                "searches_7d": _count_searches(7),
                "searches_30d": _count_searches(30),
                f"searches_{period_days}d": _count_searches(period_days),
                "avg_results_per_search": round(avg_results, 4),
            }
    except Exception:  # noqa: BLE001
        # Table doesn't exist or is not accessible; return zeros.
        pass

    # ------------------------------------------------------------------ #
    # quality section (feedback_log table may not exist yet)              #
    # ------------------------------------------------------------------ #
    quality_section: dict[str, Any] = {
        "total_feedback": 0,
        "feedback_30d": 0,
        "positive_rate": 0.0,
    }
    try:
        _fb_exists = conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'feedback_log'"
        ).fetchone()
        if _fb_exists and _fb_exists[0] > 0:
            total_fb_row = conn.execute("SELECT COUNT(*) FROM feedback_log").fetchone()
            total_fb: int = total_fb_row[0] if total_fb_row else 0

            positive_row = conn.execute(
                "SELECT COUNT(*) FROM feedback_log WHERE signal = 'positive'"
            ).fetchone()
            positive_count: int = positive_row[0] if positive_row else 0

            fb_30d_row = conn.execute(
                "SELECT COUNT(*) FROM feedback_log "
                "WHERE timestamp > CURRENT_TIMESTAMP - INTERVAL '30 days'"
            ).fetchone()
            fb_30d: int = fb_30d_row[0] if fb_30d_row else 0

            positive_rate = (positive_count / total_fb) if total_fb > 0 else 0.0

            quality_section = {
                "total_feedback": total_fb,
                "feedback_30d": fb_30d,
                "positive_rate": round(positive_rate, 4),
            }
    except Exception:  # noqa: BLE001
        # Table doesn't exist or is not accessible; return zeros.
        pass

    # ------------------------------------------------------------------ #
    # staleness section                                                    #
    # ------------------------------------------------------------------ #
    stale_days = config.defaults.stale_days

    # accessed_at column may not exist yet (added by T02.1).
    # Fall back to updated_at if the column is absent.
    stale_count = 0
    stale_by_type: dict[str, int] = {}
    try:
        stale_row = conn.execute(
            f"SELECT COUNT(*) FROM entries "
            f"WHERE status != 'archived' "
            f"AND COALESCE(accessed_at, updated_at) < "
            f"CURRENT_TIMESTAMP - INTERVAL '{stale_days} days'"
        ).fetchone()
        stale_count = stale_row[0] if stale_row else 0

        stale_type_rows = conn.execute(
            f"SELECT entry_type, COUNT(*) AS cnt FROM entries "
            f"WHERE status != 'archived' "
            f"AND COALESCE(accessed_at, updated_at) < "
            f"CURRENT_TIMESTAMP - INTERVAL '{stale_days} days' "
            f"GROUP BY entry_type ORDER BY cnt DESC"
        ).fetchall()
        stale_by_type = {row[0]: row[1] for row in stale_type_rows}
    except Exception:  # noqa: BLE001
        # If accessed_at column doesn't exist, try without it.
        try:
            stale_row = conn.execute(
                f"SELECT COUNT(*) FROM entries "
                f"WHERE status != 'archived' "
                f"AND updated_at < CURRENT_TIMESTAMP - INTERVAL '{stale_days} days'"
            ).fetchone()
            stale_count = stale_row[0] if stale_row else 0

            stale_type_rows = conn.execute(
                f"SELECT entry_type, COUNT(*) AS cnt FROM entries "
                f"WHERE status != 'archived' "
                f"AND updated_at < CURRENT_TIMESTAMP - INTERVAL '{stale_days} days' "
                f"GROUP BY entry_type ORDER BY cnt DESC"
            ).fetchall()
            stale_by_type = {row[0]: row[1] for row in stale_type_rows}
        except Exception:  # noqa: BLE001
            pass

    staleness_section: dict[str, Any] = {
        "stale_count": stale_count,
        "stale_days": stale_days,
        "by_type": stale_by_type,
    }

    # ------------------------------------------------------------------ #
    # storage section                                                      #
    # ------------------------------------------------------------------ #
    db_path = _normalize_db_path(config.storage.database_path)
    db_file_size: int | None = None
    if db_path != ":memory:" and not _is_remote_db_path(db_path):
        try:
            db_file_size = Path(db_path).stat().st_size
        except OSError:
            db_file_size = None

    model_name = getattr(embedding_provider, "model_name", "unknown")
    embedding_dimensions = getattr(embedding_provider, "dimensions", None)

    storage_section: dict[str, Any] = {
        "db_file_size": db_file_size,
        "embedding_model": model_name,
        "embedding_dimensions": embedding_dimensions,
    }

    return {
        "entries": entries_section,
        "activity": activity_section,
        "search": search_section,
        "quality": quality_section,
        "staleness": staleness_section,
        "storage": storage_section,
    }


def _sync_gather_quality(
    store: Any,
    entry_type_filter: str | None,
) -> dict[str, Any]:
    """
    Compute aggregated quality metrics from the DuckDB-backed store.

    Handles missing ``search_log`` or ``feedback_log`` tables by returning zeroed
    metrics for the missing data.

    Parameters:
        store: Initialized DuckDBStore exposing a live ``connection`` to execute queries.
        entry_type_filter: Optional entry-type to include a per-type feedback breakdown.

    Returns:
        A dictionary containing:
            - total_searches (int): Total number of search events (0 if unavailable).
            - total_feedback (int): Total number of feedback records (0 if unavailable).
            - positive_rate (float): Fraction of feedback that is positive, rounded to 4 decimals.
            - avg_result_count (float): Average number of results per search, rounded to 4 decimals.
            - per_type_breakdown (dict): Mapping of the ``entry_type_filter`` to a dict with
              ``total_feedback``, ``positive_count``, and ``positive_rate``. Empty if no filter
              provided or data unavailable.
    """
    conn = store.connection

    total_searches = 0
    total_feedback = 0
    positive_count = 0
    avg_result_count = 0.0

    try:
        sl_exists = conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'search_log'"
        ).fetchone()
        if sl_exists and sl_exists[0] > 0:
            row = conn.execute("SELECT COUNT(*) FROM search_log").fetchone()
            total_searches = row[0] if row else 0

            avg_row = conn.execute(
                "SELECT AVG(array_length(result_entry_ids)) FROM search_log"
            ).fetchone()
            avg_result_count = float(avg_row[0]) if avg_row and avg_row[0] is not None else 0.0
    except Exception:  # noqa: BLE001
        pass

    try:
        fl_exists = conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'feedback_log'"
        ).fetchone()
        if fl_exists and fl_exists[0] > 0:
            row = conn.execute("SELECT COUNT(*) FROM feedback_log").fetchone()
            total_feedback = row[0] if row else 0

            pos_row = conn.execute(
                "SELECT COUNT(*) FROM feedback_log WHERE signal = 'positive'"
            ).fetchone()
            positive_count = pos_row[0] if pos_row else 0
    except Exception:  # noqa: BLE001
        pass

    positive_rate = (positive_count / total_feedback) if total_feedback > 0 else 0.0

    # Per-type breakdown: join feedback_log -> search_log -> entries
    per_type_breakdown: dict[str, Any] = {}
    if entry_type_filter is not None:
        try:
            sl_exists2 = conn.execute(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'search_log'"
            ).fetchone()
            fl_exists2 = conn.execute(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'feedback_log'"
            ).fetchone()
            if (sl_exists2 and sl_exists2[0] > 0) and (fl_exists2 and fl_exists2[0] > 0):
                type_fb_row = conn.execute(
                    "SELECT COUNT(*) FROM feedback_log fl "
                    "JOIN entries e ON fl.entry_id = e.id "
                    "WHERE e.entry_type = ?",
                    [entry_type_filter],
                ).fetchone()
                type_fb = type_fb_row[0] if type_fb_row else 0

                type_pos_row = conn.execute(
                    "SELECT COUNT(*) FROM feedback_log fl "
                    "JOIN entries e ON fl.entry_id = e.id "
                    "WHERE e.entry_type = ? AND fl.signal = 'positive'",
                    [entry_type_filter],
                ).fetchone()
                type_pos = type_pos_row[0] if type_pos_row else 0

                type_rate = (type_pos / type_fb) if type_fb > 0 else 0.0
                per_type_breakdown[entry_type_filter] = {
                    "total_feedback": type_fb,
                    "positive_count": type_pos,
                    "positive_rate": round(type_rate, 4),
                }
        except Exception:  # noqa: BLE001
            pass

    return {
        "total_searches": total_searches,
        "total_feedback": total_feedback,
        "positive_rate": round(positive_rate, 4),
        "avg_result_count": round(avg_result_count, 4),
        "per_type_breakdown": per_type_breakdown,
    }


# ---------------------------------------------------------------------------
# _gather_audit  (scope="audit" for _handle_metrics)
# ---------------------------------------------------------------------------

#: Tool names that represent authentication events.
_AUTH_TOOLS = frozenset({"auth_login", "auth_login_failed", "auth_org_denied"})


async def _gather_audit(
    store: Any,
    *,
    date_from: str | None,
    user: str | None,
) -> dict[str, Any]:
    """Gather audit metrics from the store's ``audit_log`` table.

    Queries the audit log four times to build the response sections:

    - **recent_logins**: up to 50 auth events (``auth_login``,
      ``auth_login_failed``, ``auth_org_denied``), optionally filtered by
      ``date_from``.
    - **login_summary**: totals derived from all auth events (not truncated) —
      ``total_logins``, ``unique_users``, ``failed_attempts``,
      ``org_denials``.
    - **active_users**: unique users seen in *all* operations, with
      ``last_seen`` and ``operation_count``, ordered by ``last_seen`` DESC.
      Filtered by ``date_from`` and/or ``user`` when provided.
    - **recent_operations**: up to 50 non-auth tool operations.
      Filtered by ``date_from`` and/or ``user`` when provided.

    Args:
        store: Initialised store implementing ``query_audit_log``.
        date_from: Optional ISO 8601 lower-bound timestamp applied to all
            sections that support a ``date_from`` filter.
        user: Optional user ID.  Applied to ``recent_operations`` and
            ``active_users`` only.

    Returns:
        Dict with keys ``recent_logins``, ``login_summary``,
        ``active_users``, and ``recent_operations``.
    """
    # Build the base filters shared by all auth-related queries.
    base_filters: dict[str, Any] = {}
    if date_from is not None:
        base_filters["date_from"] = date_from

    # --- recent_logins --------------------------------------------------
    # We fetch a large batch and filter in Python because query_audit_log
    # does not support an "operation IN (...)" clause.
    all_rows: list[dict[str, Any]] = await store.query_audit_log(
        filters=base_filters if base_filters else None,
        limit=500,
    )
    auth_events = [r for r in all_rows if r["tool"] in _AUTH_TOOLS]
    recent_logins = auth_events[:50]

    # --- login_summary --------------------------------------------------
    # Compute from full auth_events (not truncated recent_logins) for accurate totals.
    total_logins = sum(1 for r in auth_events if r["tool"] == "auth_login")
    failed_attempts = sum(1 for r in auth_events if r["tool"] == "auth_login_failed")
    org_denials = sum(1 for r in auth_events if r["tool"] == "auth_org_denied")
    unique_users_set = {r["user_id"] for r in auth_events if r["user_id"]}
    login_summary: dict[str, Any] = {
        "total_logins": total_logins,
        "unique_users": len(unique_users_set),
        "failed_attempts": failed_attempts,
        "org_denials": org_denials,
    }

    # --- recent_operations (non-auth, filtered by user + date_from) ------
    ops_filters: dict[str, Any] = dict(base_filters)
    if user is not None:
        ops_filters["user"] = user
    ops_rows: list[dict[str, Any]] = await store.query_audit_log(
        filters=ops_filters if ops_filters else None,
        limit=500,
    )
    recent_operations = [r for r in ops_rows if r["tool"] not in _AUTH_TOOLS][:50]

    # --- active_users (filtered by date_from + user) ---------------------
    # Derive from ops_rows (which already respects date_from + user).
    # Note: operation_count includes all operations (auth + non-auth) to
    # represent total user activity.  Rows are ordered DESC so the first
    # occurrence of each user is their most recent timestamp.
    user_stats: dict[str, dict[str, Any]] = {}
    for row in ops_rows:
        uid = row["user_id"] or ""
        if not uid:
            continue
        if uid not in user_stats:
            user_stats[uid] = {"last_seen": row["timestamp"], "operation_count": 0}
        user_stats[uid]["operation_count"] += 1
    active_users = sorted(
        [{"user_id": uid, **stats} for uid, stats in user_stats.items()],
        key=lambda x: x["last_seen"],
        reverse=True,
    )

    return {
        "recent_logins": recent_logins,
        "login_summary": login_summary,
        "active_users": active_users,
        "recent_operations": recent_operations,
    }


# ---------------------------------------------------------------------------
# _handle_stale
# ---------------------------------------------------------------------------


async def _handle_stale(
    store: Any,
    config: DistilleryConfig,
    arguments: dict[str, Any],
) -> list[types.TextContent]:
    """Implement the ``distillery_stale`` tool.

    Returns entries that have not been accessed within the configured
    staleness window.  An entry's last access time is determined by
    ``COALESCE(accessed_at, updated_at)`` so that entries without an
    explicit access timestamp fall back to their last modification time.

    Args:
        store: Initialised :class:`~distillery.store.duckdb.DuckDBStore`.
        config: The loaded Distillery configuration.
        arguments: Tool argument dict.  Accepts optional ``days`` (int),
            ``limit`` (int), and ``entry_type`` (str).

    Returns:
        MCP content list with a single JSON ``TextContent`` block.
    """
    # --- validate days -------------------------------------------------------
    err_days = validate_type(arguments, "days", int, "integer")
    if err_days:
        return error_response("INVALID_PARAMS", err_days)
    days_raw = arguments.get("days")
    days: int = int(days_raw) if days_raw is not None else config.defaults.stale_days
    if days < 1:
        return error_response("INVALID_PARAMS", "Field 'days' must be >= 1")

    # --- validate limit -------------------------------------------------------
    err_limit = validate_type(arguments, "limit", int, "integer")
    if err_limit:
        return error_response("INVALID_PARAMS", err_limit)
    limit_raw = arguments.get("limit")
    limit: int = int(limit_raw) if limit_raw is not None else 20
    if limit < 1:
        return error_response("INVALID_PARAMS", "Field 'limit' must be >= 1")

    # --- validate entry_type -------------------------------------------------
    entry_type_filter: str | None = arguments.get("entry_type")
    if entry_type_filter is not None and not isinstance(entry_type_filter, str):
        return error_response("INVALID_PARAMS", "Field 'entry_type' must be a string")

    try:
        stale_entries = await asyncio.to_thread(
            _sync_gather_stale, store, days, limit, entry_type_filter
        )
        expired_entries = await asyncio.to_thread(
            _sync_gather_expired, store, limit, entry_type_filter
        )
        # Deduplicate: expired entries take priority over stale entries.
        # An entry that is both stale and expired should only appear once
        # with reason="expired".
        expired_ids = {e["id"] for e in expired_entries}
        deduped_stale = [e for e in stale_entries if e["id"] not in expired_ids]
        # Merge expired first (higher priority), then stale, apply single limit.
        merged = expired_entries + deduped_stale
        merged = merged[:limit]
        stale_in_result = [e for e in merged if e.get("reason") == "stale"]
        expired_in_result = [e for e in merged if e.get("reason") == "expired"]
        return success_response(
            {
                "days_threshold": days,
                "entry_type_filter": entry_type_filter,
                "stale_count": len(stale_in_result),
                "expired_count": len(expired_in_result),
                "entries": merged,
            }
        )
    except Exception:  # noqa: BLE001
        logger.exception("Error gathering stale entries")
        return error_response("INTERNAL", "Failed to gather stale entries")


def _sync_gather_stale(
    store: Any,
    days: int,
    limit: int,
    entry_type_filter: str | None,
) -> list[dict[str, Any]]:
    """
    Return entries whose last access (accessed_at or updated_at) is older than the given days.

    Parameters:
        store: Initialized DuckDBStore used to query entries.
        days: Staleness threshold in days; entries last accessed strictly earlier than
            now - days are returned.
        limit: Maximum number of entries to return.
        entry_type_filter: Optional entry_type value to restrict results to a single type.

    Returns:
        List of stale entry summaries ordered stalest-first. Each dict contains:
            - id: entry identifier
            - content_preview: first 200 characters of the content (empty string if None)
            - entry_type: entry type string
            - author: author string
            - project: project string or None
            - last_accessed: ISO 8601 timestamp string of the last access or None
            - days_since_access: integer days since last access or None
    """
    conn = store.connection

    params: list[Any] = [days]
    type_clause = ""
    if entry_type_filter is not None:
        type_clause = " AND entry_type = ?"
        params.append(entry_type_filter)
    params.append(limit)

    sql = f"""
        SELECT
            id,
            content,
            entry_type,
            author,
            project,
            COALESCE(accessed_at, updated_at) AS last_accessed
        FROM entries
        WHERE status != 'archived'
          AND COALESCE(accessed_at, updated_at) < NOW() - INTERVAL (CAST(? AS INT)) DAYS
          {type_clause}
        ORDER BY last_accessed ASC
        LIMIT ?
    """

    rows = conn.execute(sql, params).fetchall()

    result: list[dict[str, Any]] = []
    for row in rows:
        entry_id, content, entry_type, author, project, last_accessed = row
        content_preview = (content or "")[:200]
        # Calculate days since access
        if last_accessed is not None:
            if hasattr(last_accessed, "tzinfo") and last_accessed.tzinfo is None:
                last_accessed_aware = last_accessed.replace(tzinfo=UTC)
            else:
                last_accessed_aware = last_accessed
            now = datetime.now(UTC)
            days_since = (now - last_accessed_aware).days
            last_accessed_iso = last_accessed_aware.isoformat()
        else:
            days_since = None
            last_accessed_iso = None

        result.append(
            {
                "id": entry_id,
                "content_preview": content_preview,
                "entry_type": entry_type,
                "author": author,
                "project": project,
                "last_accessed": last_accessed_iso,
                "days_since_access": days_since,
                "reason": "stale",
            }
        )

    return result


def _sync_gather_expired(
    store: Any,
    limit: int,
    entry_type_filter: str | None,
) -> list[dict[str, Any]]:
    """Return active entries whose ``expires_at`` is in the past.

    Parameters:
        store: Initialized DuckDBStore used to query entries.
        limit: Maximum number of entries to return.
        entry_type_filter: Optional entry_type value to restrict results.

    Returns:
        List of expired entry summaries. Each dict mirrors the stale format
        but includes ``"reason": "expired"`` and an ``expires_at`` field.
    """
    conn = store.connection

    params: list[Any] = []
    type_clause = ""
    if entry_type_filter is not None:
        type_clause = " AND entry_type = ?"
        params.append(entry_type_filter)
    params.append(limit)

    sql = f"""
        SELECT
            id,
            content,
            entry_type,
            author,
            project,
            expires_at,
            COALESCE(accessed_at, updated_at) AS last_accessed
        FROM entries
        WHERE status != 'archived'
          AND expires_at IS NOT NULL
          AND expires_at < NOW()
          {type_clause}
        ORDER BY expires_at ASC
        LIMIT ?
    """

    rows = conn.execute(sql, params).fetchall()

    result: list[dict[str, Any]] = []
    for row in rows:
        entry_id, content, entry_type, author, project, expires_at, last_accessed = row
        content_preview = (content or "")[:200]

        expires_at_iso: str | None = None
        if expires_at is not None:
            if hasattr(expires_at, "tzinfo") and expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=UTC)
            expires_at_iso = expires_at.isoformat()

        # Compute last_accessed / days_since_access to match stale entry shape.
        if last_accessed is not None:
            if hasattr(last_accessed, "tzinfo") and last_accessed.tzinfo is None:
                last_accessed = last_accessed.replace(tzinfo=UTC)
            days_since: int | None = (datetime.now(UTC) - last_accessed).days
            last_accessed_iso: str | None = last_accessed.isoformat()
        else:
            days_since = None
            last_accessed_iso = None

        result.append(
            {
                "id": entry_id,
                "content_preview": content_preview,
                "entry_type": entry_type,
                "author": author,
                "project": project,
                "last_accessed": last_accessed_iso,
                "days_since_access": days_since,
                "expires_at": expires_at_iso,
                "reason": "expired",
            }
        )

    return result


# ---------------------------------------------------------------------------
# _handle_interests
# ---------------------------------------------------------------------------


async def _handle_interests(
    store: Any,
    config: DistilleryConfig,
    arguments: dict[str, Any],
) -> list[types.TextContent]:
    """Handle the ``distillery_interests`` tool.

    Builds an :class:`~distillery.feeds.interests.InterestProfile` by mining
    the active entries in *store* and returns it as a JSON payload.

    When ``suggest_sources=True`` is passed, the response also includes
    heuristic feed source suggestions derived from the interest profile
    (absorbing the former ``distillery_suggest_sources`` tool behaviour).

    Args:
        store: An initialised storage backend.
        config: The current :class:`~distillery.config.DistilleryConfig`.
        arguments: Parsed tool arguments dict (``recency_days``, ``top_n``,
            ``suggest_sources``, ``max_suggestions``).

    Returns:
        A structured MCP success or error response.
    """
    from distillery.feeds.interests import InterestExtractor

    recency_days_raw = arguments.get("recency_days", 90)
    try:
        recency_days = int(recency_days_raw)
    except (TypeError, ValueError):
        return error_response(
            "INVALID_PARAMS",
            f"recency_days must be an integer, got: {recency_days_raw!r}",
        )
    if recency_days <= 0:
        return error_response(
            "INVALID_PARAMS",
            f"recency_days must be a positive integer, got: {recency_days}",
        )

    top_n_raw = arguments.get("top_n", 20)
    try:
        top_n = int(top_n_raw)
    except (TypeError, ValueError):
        return error_response(
            "INVALID_PARAMS",
            f"top_n must be an integer, got: {top_n_raw!r}",
        )
    if top_n <= 0:
        return error_response(
            "INVALID_PARAMS",
            f"top_n must be a positive integer, got: {top_n}",
        )

    suggest_sources_raw = arguments.get("suggest_sources", False)
    if not isinstance(suggest_sources_raw, bool):
        return error_response(
            "INVALID_PARAMS",
            f"suggest_sources must be a boolean, got: {suggest_sources_raw!r}",
        )
    suggest_sources: bool = suggest_sources_raw

    max_suggestions_raw = arguments.get("max_suggestions", 5)
    try:
        max_suggestions = int(max_suggestions_raw)
    except (TypeError, ValueError):
        return error_response(
            "INVALID_PARAMS",
            f"max_suggestions must be an integer, got: {max_suggestions_raw!r}",
        )
    if max_suggestions <= 0:
        return error_response(
            "INVALID_PARAMS",
            f"max_suggestions must be a positive integer, got: {max_suggestions}",
        )

    extractor = InterestExtractor(
        store=store,
        recency_days=recency_days,
        top_n=top_n,
    )
    try:
        profile = await extractor.extract()
    except Exception:  # noqa: BLE001
        logger.exception("distillery_interests: extraction failed")
        return error_response("INTERNAL", "Interest extraction failed")

    payload: dict[str, Any] = {
        "top_tags": [[tag, weight] for tag, weight in profile.top_tags],
        "bookmark_domains": profile.bookmark_domains,
        "tracked_repos": profile.tracked_repos,
        "expertise_areas": profile.expertise_areas,
        "watched_sources": profile.watched_sources,
        "suggestion_context": profile.suggestion_context,
        "entry_count": profile.entry_count,
        "generated_at": profile.generated_at.isoformat(),
    }

    if suggest_sources:
        from distillery.mcp.tools.feeds import _derive_suggestions, _normalise_watched_set

        watched_set = _normalise_watched_set(profile.watched_sources)
        suggestions = _derive_suggestions(
            profile=profile,
            watched_set=watched_set,
            source_type_filter=None,
            max_suggestions=max_suggestions,
        )
        payload["suggestions"] = suggestions

    return success_response(payload)


__all__ = [
    "_VALID_METRICS_SCOPES",
    "_handle_interests",
    "_handle_metrics",
    "_handle_stale",
    "_handle_tag_tree",
    "_handle_type_schemas",
    "_sync_gather_summary",
    "_sync_gather_quality",
]
