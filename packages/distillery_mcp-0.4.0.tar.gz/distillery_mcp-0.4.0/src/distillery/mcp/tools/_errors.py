"""Standardized error codes and helpers for MCP tool handlers.

This module defines a canonical set of error codes used across all 22 MCP
tool handlers, eliminating inconsistencies like ``INVALID_INPUT`` vs
``VALIDATION_ERROR`` that made client-side error handling complex.

Error codes are used with the ``error_response()`` helper from ``_common.py``
to produce structured JSON error responses.
"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mcp import types

    from distillery.embedding.errors import EmbeddingProviderError


class ToolErrorCode(StrEnum):
    """Standard error codes for all MCP tool handlers.

    Attributes:
        INVALID_PARAMS: Request parameters fail validation (e.g., missing
            required fields, wrong types, values out of range). This replaces
            ``INVALID_INPUT``, ``VALIDATION_ERROR``, ``MISSING_FIELD``,
            ``INVALID_FIELD``, ``INVALID_ACTION``, ``INVALID_SOURCE_TYPE``,
            ``INVALID_STATE``, and ``RESERVED_PREFIX`` to provide consistency
            across all handlers.
        NOT_FOUND: The requested resource does not exist (e.g., entry ID not
            found, user not found).
        CONFLICT: The operation conflicts with existing state (e.g.,
            deduplication detected, duplicate feed source).
        INTERNAL: An unexpected server-side error occurred (e.g., database
            connection failure, embedding service timeout). This replaces
            ``STORE_ERROR``, ``SEARCH_ERROR``, ``FIND_SIMILAR_ERROR``,
            ``WATCH_ERROR``, ``RELATIONS_ERROR``, ``LIST_ERROR``,
            ``AGGREGATE_ERROR``, ``METRICS_ERROR``, ``TAG_TREE_ERROR``,
            ``STALE_ERROR``, ``POLL_ERROR``, ``RESCORE_ERROR``,
            ``DEDUP_ERROR``, ``CONFLICT_ERROR``, and ``EXTRACTION_ERROR``.
        FORBIDDEN: The authenticated user is not allowed to perform the
            operation (e.g., ownership violation).
        BUDGET_EXCEEDED: A rate-limit or budget has been exhausted (e.g.,
            daily embedding budget, database size limit).
        RATE_LIMITED: The request was rejected due to rate limiting.
        UPSTREAM_RATE_LIMITED: An upstream dependency (e.g. embedding
            provider) rate-limited the request after internal retries were
            exhausted.  Response ``details`` includes ``provider``,
            ``status_code``, and ``retry_after`` (seconds) when available
            so clients can back off appropriately.
        UPSTREAM_ERROR: An upstream dependency returned an error (5xx,
            transport failure) after internal retries were exhausted.
            Response ``details`` mirrors ``UPSTREAM_RATE_LIMITED``.
    """

    INVALID_PARAMS = "INVALID_PARAMS"
    NOT_FOUND = "NOT_FOUND"
    CONFLICT = "CONFLICT"
    INTERNAL = "INTERNAL"
    FORBIDDEN = "FORBIDDEN"
    BUDGET_EXCEEDED = "BUDGET_EXCEEDED"
    RATE_LIMITED = "RATE_LIMITED"
    UPSTREAM_RATE_LIMITED = "UPSTREAM_RATE_LIMITED"
    UPSTREAM_ERROR = "UPSTREAM_ERROR"


def tool_error(code: ToolErrorCode | str, message: str) -> tuple[ToolErrorCode | str, str]:
    """Format a tool error as a (code, message) tuple for use with error_response().

    This helper ensures consistent error response formatting. It returns a tuple
    that can be passed to ``error_response(code, message)`` from ``_common.py``.

    Args:
        code: A ``ToolErrorCode`` enum value or string.
        message: Human-readable error description.

    Returns:
        A (code, message) tuple ready for passing to error_response().

    Example:
        >>> from distillery.mcp.tools._common import error_response
        >>> from distillery.mcp.tools._errors import tool_error, ToolErrorCode
        >>> code, msg = tool_error(ToolErrorCode.NOT_FOUND, "User not found")
        >>> error = error_response(code, msg)
    """
    return (code, message)


def validate_limit(
    value: Any,
    min_val: int = 1,
    max_val: int = 1000,
    default: int = 50,
) -> int | tuple[ToolErrorCode | str, str]:
    """Validate and coerce a limit parameter to an integer in [min_val, max_val].

    Used by handlers to validate ``limit`` parameters consistently. If validation
    fails, returns a (code, message) tuple suitable for ``error_response()``.

    Args:
        value: The value to validate (typically from tool arguments).
        min_val: Minimum allowed value (inclusive). Default: ``1``.
        max_val: Maximum allowed value (inclusive). Default: ``1000``.
        default: Default value if ``value`` is ``None``. Default: ``50``.

    Returns:
        On success: An integer in [min_val, max_val].
        On failure: A (code, message) tuple ready for ``error_response()``.

    Example:
        >>> from distillery.mcp.tools._errors import validate_limit
        >>> result = validate_limit(None, min_val=1, max_val=100, default=50)
        >>> assert result == 50
        >>> result = validate_limit(150, min_val=1, max_val=100)
        >>> assert isinstance(result, tuple)  # error case
    """
    if value is None:
        return default

    try:
        limit = int(value)
    except (TypeError, ValueError):
        return tool_error(
            ToolErrorCode.INVALID_PARAMS,
            f"Field 'limit' must be an integer, got: {type(value).__name__}",
        )

    if limit < min_val:
        return tool_error(
            ToolErrorCode.INVALID_PARAMS,
            f"Field 'limit' must be >= {min_val}",
        )

    if limit > max_val:
        return tool_error(
            ToolErrorCode.INVALID_PARAMS,
            f"Field 'limit' must be <= {max_val}",
        )

    return limit


def upstream_error_response(exc: EmbeddingProviderError) -> list[types.TextContent]:
    """Build a structured MCP error response from an :class:`EmbeddingProviderError`.

    Chooses between :class:`ToolErrorCode.UPSTREAM_RATE_LIMITED` (HTTP
    429) and :class:`ToolErrorCode.UPSTREAM_ERROR` (everything else) and
    populates ``details`` with ``provider``, ``status_code``, and
    ``retry_after`` so clients can react appropriately.

    Args:
        exc: The :class:`EmbeddingProviderError` raised by the provider
            after retries were exhausted.

    Returns:
        A single-element list of :class:`~mcp.types.TextContent` suitable
        for returning from an MCP tool handler.
    """
    from distillery.mcp.tools._common import error_response

    code = (
        ToolErrorCode.UPSTREAM_RATE_LIMITED
        if exc.is_rate_limited
        else ToolErrorCode.UPSTREAM_ERROR
    )
    details: dict[str, Any] = {"provider": exc.provider}
    if exc.status_code is not None:
        details["status_code"] = exc.status_code
    if exc.retry_after is not None:
        details["retry_after"] = exc.retry_after
    if exc.endpoint is not None:
        details["endpoint"] = exc.endpoint

    message = (
        f"Embedding provider {exc.provider!r} rate limit reached after retries."
        if exc.is_rate_limited
        else f"Embedding provider {exc.provider!r} failed after retries."
    )
    if exc.retry_after is not None:
        message = f"{message} Retry after {exc.retry_after:g} seconds."

    return error_response(code, message, details=details)
