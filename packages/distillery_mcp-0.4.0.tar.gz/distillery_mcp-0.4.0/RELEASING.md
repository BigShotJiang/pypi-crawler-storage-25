# Releasing Distillery

This document describes the release process for the Distillery MCP server and plugin.

## Release Chain

Creating a GitHub release triggers three automated workflows:

```text
GitHub Release (tag: vX.Y.Z)
  ├─ pypi-publish.yml
  │   ├─ Build sdist + wheel
  │   ├─ Publish to PyPI (distillery-mcp)
  │   ├─ Stamp version in server.json, plugin.json, marketplace.json
  │   ├─ Publish to MCP Registry
  │   └─ Publish to Smithery
  └─ changelog.yml
      ├─ Generate CHANGELOG.md via git-cliff
      └─ Open PR to main (branch protection prevents direct push)
```

Users install the server via `pip install distillery-mcp` or `uvx distillery-mcp`, both pulling from PyPI.

## Pre-Release Checklist

1. **Version bump** — Update all version references. Every file listed below must be updated manually before tagging:

   | File | Field(s) | Notes |
   |------|----------|-------|
   | `pyproject.toml` | `version` | Source of truth |
   | `src/distillery/__init__.py` | `__version__` | Reported by `distillery_metrics` |
   | `.claude-plugin/plugin.json` | `version`, SessionStart echo string | Plugin manifest |
   | `.claude-plugin/marketplace.json` | `plugins[0].version` | Marketplace listing |
   | `server.json` | `version`, `packages[*].version` | MCP Registry listing |
   | `uv.lock` | auto-updated | Run `uv lock` after editing `pyproject.toml` |
   | `CHANGELOG.md` | `[Unreleased]` comparison link | Update base tag in footer links |

   ```bash
   # 1. Edit pyproject.toml and src/distillery/__init__.py
   # 2. Edit .claude-plugin/plugin.json and marketplace.json
   # 3. Edit server.json (version + packages[*].version)
   # 4. Regenerate lockfile
   uv lock
   # 5. Update CHANGELOG.md comparison links (done automatically on release by changelog.yml)
   ```

2. **Merge all PRs** — Ensure all feature branches for this release are merged to `main`.

3. **Tests pass** — Verify CI is green on `main`:

   ```bash
   pytest --cov=src/distillery --cov-fail-under=80
   mypy --strict src/distillery/
   ruff check src/ tests/
   ```

4. **Skill compatibility** — If new MCP tools were added, ensure skills that use them have `min_server_version` in their frontmatter.

## Plugin Manifest Policy

Files in `.claude-plugin/` are read by the marketplace from `main`. To avoid advertising unreleased tools or skills:

- **Feature PRs must not bump versions in `.claude-plugin/`**. New skills and tools can land on `main`, but the plugin manifest should not reference them until a release branch is cut.
- **Version bumps to plugin.json and marketplace.json happen only on `release/X.Y.Z` branches**, alongside the `pyproject.toml` bump.
- The SessionStart echo in `plugin.json` should only list skills available in the last published PyPI version.

## Cutting the Release

### Step 1: Create a release branch

Cut a release branch from `main` for version validation before tagging. This
branch is where you bump versions, run the full test suite, and deploy to the
hosted server for smoke-testing — without committing to a public tag.

```bash
git checkout main
git pull origin main
git checkout -b release/X.Y.Z
```

### Step 2: Bump versions and test

Follow the version bump checklist in step 1 of the pre-release checklist above,
then push and open a PR against `main`:

```bash
git push -u origin release/X.Y.Z
gh pr create --title "release: vX.Y.Z" --body "Version bump and release validation"
```

Validate on the release branch:

- CI passes (tests, mypy, ruff, coverage)
- `promptfoo eval` passes against the MCP server
- Deploy to the hosted server (`fly deploy` from distill_ops) and smoke-test
- Verify `distillery_metrics` reports the correct version

Once validated, merge the PR to `main`.

### Step 3: Tag and release

```bash
# IMPORTANT: Tag format is vX.Y.Z (no extra dots, no prefix other than 'v')
# The release workflow extracts the version with: ${GITHUB_REF#refs/tags/v}
# Wrong: v.0.2.1 → extracts ".0.2.1"
# Right: v0.2.1  → extracts "0.2.1"

git checkout main
git pull origin main
git tag vX.Y.Z
git push origin vX.Y.Z
```

### Step 4: Create the GitHub release

```bash
gh release create vX.Y.Z \
  --title "vX.Y.Z — Short Description" \
  --generate-notes
```

Or create via the GitHub UI at `https://github.com/norrietaylor/distillery/releases/new`.

This triggers pypi-publish.yml and changelog.yml automatically.

### Step 5: Verify

1. **PyPI**: Check https://pypi.org/project/distillery-mcp/ for the new version
2. **Install**: `pip install distillery-mcp==X.Y.Z` or `uvx distillery-mcp --version`
3. **MCP Registry**: Verify the server listing is updated
4. **Changelog**: Merge the auto-generated changelog PR (created by changelog.yml)

## Deploying the Hosted Server

The hosted MCP server at `distillery-mcp.fly.dev` is deployed separately via the [distill_ops](https://github.com/norrietaylor/distill_ops) repo. After a PyPI release:

```bash
# In the distill_ops repo
fly deploy --app distillery-mcp
```

## Versioning

Follow [Semantic Versioning](https://semver.org/):

- **Patch** (0.2.1 → 0.2.2): Bug fixes, doc updates, no new MCP tools or skills
- **Minor** (0.2.x → 0.3.0): New MCP tools, new skills, new store methods, migration additions
- **Major** (0.x → 1.0): Breaking protocol changes, migration format changes, removed tools

## Tag Format

**The tag MUST be `vX.Y.Z`** — exactly `v` followed by semver digits.

The release workflow extracts the version number using `${GITHUB_REF#refs/tags/v}`, which strips the leading `v`. Any deviation (e.g., `v.0.2.1`, `ver0.2.1`) produces a malformed version string that breaks PyPI metadata, MCP Registry publishing, and plugin manifest stamping.

## Fixing a Bad Tag

If a tag was created with the wrong format:

```bash
# Delete the bad tag locally and remotely
git tag -d v.0.2.1
git push origin :refs/tags/v.0.2.1

# Delete the GitHub release (if created)
gh release delete v.0.2.1 --yes

# Create the correct tag
git tag v0.2.1 <commit-sha>
git push origin v0.2.1

# Re-create the release
gh release create v0.2.1 --title "v0.2.1 — Description" --generate-notes
```
