# IoT Device Management MCP Server

[![PyPI version](https://badge.fury.io/py/iot-device-mcp-server.svg)](https://pypi.org/project/iot-device-mcp-server/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**MCP Server for IoT Device Management** — Register, monitor, and control IoT devices via AI agents.

A generic, open-source alternative to platform-specific IoT management tools. No cloud API key required — all data stored locally.

## Features

- **Device Registry** — Register and manage IoT devices (sensors, actuators, gateways, cameras)
- **Real-time Status** — Monitor device health, telemetry, and connectivity
- **Remote Commands** — Send commands (reboot, enable, disable, calibrate) to devices
- **Firmware Updates** — Track and simulate firmware update workflows
- **Alert Management** — Create, filter, and resolve device alerts
- **Fleet Analytics** — Health scores, status summaries, and recommendations
- **Fleet Dashboard** — Single-view overview of your entire device fleet

## Tools

| Tool | Description |
|------|-------------|
| `register_device` | Register a new IoT device with type, location, and firmware version |
| `list_devices` | List all devices with optional filters (type, location, status, tag) |
| `get_device_status` | Get real-time status and simulated telemetry for a device |
| `update_firmware` | Simulate firmware update with version history |
| `send_command` | Send remote commands (reboot, enable, disable, calibrate, etc.) |
| `get_alerts` | Retrieve device alerts filtered by severity or device |
| `resolve_alert` | Mark an alert as resolved with optional notes |
| `device_analytics` | Fleet health score, statistics, and recommendations |
| `get_fleet_dashboard` | Complete fleet overview with recent activity |

## Installation

```bash
pip install iot-device-mcp-server
```

## Usage with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "iot-device": {
      "command": "iot-device-mcp-server"
    }
  }
}
```

## Example Workflow

```
Agent: "Register a temperature sensor in the server room"
→ register_device(name="Temp Sensor 01", device_type="sensor", location="Server Room")

Agent: "What's the current status?"
→ get_device_status(device_id="dev_abc123")

Agent: "Reboot the sensor"
→ send_command(device_id="dev_abc123", command="reboot")

Agent: "Are there any critical alerts?"
→ get_alerts(severity="critical")

Agent: "Show me the fleet health"
→ device_analytics()
```

## Supported Device Types

- `sensor` — Temperature, humidity, pressure sensors
- `actuator` — Relays, motors, valves
- `gateway` — IoT edge gateways and routers
- `camera` — IP cameras and video devices
- Custom types also supported

## Supported Protocols

- MQTT (default)
- HTTP/HTTPS
- CoAP
- LoRa/LoRaWAN

## Data Storage

All data is stored locally in `~/.iot_device_store.json`. No cloud services required.

## Why This Server?

- **Platform-agnostic** — Works with any IoT setup, no vendor lock-in
- **No API keys** — Fully local, no cloud dependency
- **AI-ready** — Natural language device management via Claude or any MCP-compatible AI
- **Open source** — MIT license, fork and extend freely

## Comparison

| Feature | Digi Remote Manager | ThingsPanel | This Server |
|---------|--------------------|--------------|----|
| Platform-specific | ✅ (Digi only) | ✅ (proprietary) | ❌ (generic) |
| Open Source | ❌ | ❌ | ✅ |
| MCP Native | ❌ | ❌ | ✅ |
| No API Key | ❌ | ❌ | ✅ |
| PyPI Package | ❌ | ❌ | ✅ |

## License

MIT License — see [LICENSE](LICENSE) for details.

## Author

Built by [AiAgentKarl](https://github.com/AiAgentKarl) — Generalist AI Agent Infrastructure
