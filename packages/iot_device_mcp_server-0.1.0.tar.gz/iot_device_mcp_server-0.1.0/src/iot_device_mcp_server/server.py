"""IoT Device Management MCP Server — Hauptmodul."""

import json
import random
import string
from datetime import datetime, timedelta
from typing import Any

from mcp.server.fastmcp import FastMCP
from .store import get_store, save_store, now_iso

# FastMCP-Server initialisieren
mcp = FastMCP(
    "iot-device-mcp-server",
    instructions=(
        "MCP Server fuer IoT Device Management. "
        "Ermoeglicht AI-Agents das Registrieren, Ueberwachen und Steuern von IoT-Geraeten. "
        "Unterstuetzt Device-Registrierung, Status-Monitoring, Firmware-Updates, "
        "Remote-Commands, Alert-Management und Device-Analytics. "
        "Daten werden lokal in ~/.iot_device_store.json gespeichert. "
        "Ideal fuer DevOps, IoT-Teams und Edge-Computing-Workflows."
    ),
)

# --- Hilfsfunktionen ---

def _generate_id(prefix: str = "dev") -> str:
    """Generiert eine eindeutige Geraete-ID."""
    suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"{prefix}_{suffix}"


def _device_uptime(registered_at: str) -> str:
    """Berechnet Uptime aus Registrierungsdatum."""
    try:
        reg = datetime.strptime(registered_at, "%Y-%m-%dT%H:%M:%SZ")
        delta = datetime.utcnow() - reg
        days = delta.days
        hours = delta.seconds // 3600
        return f"{days}d {hours}h"
    except Exception:
        return "unknown"


# --- Tools ---

@mcp.tool()
def register_device(
    name: str,
    device_type: str,
    location: str,
    firmware_version: str = "1.0.0",
    tags: str = "",
    ip_address: str = "",
    protocol: str = "mqtt",
) -> dict:
    """
    Registriert ein neues IoT-Geraet im System.

    Args:
        name: Anzeigename des Geraets (z.B. 'Temperatur-Sensor Halle A')
        device_type: Geraete-Typ (z.B. 'sensor', 'actuator', 'gateway', 'camera')
        location: Standort des Geraets (z.B. 'Halle A / Regal 3')
        firmware_version: Aktuelle Firmware-Version (Standard: 1.0.0)
        tags: Komma-getrennte Tags (z.B. 'temperature,humidity')
        ip_address: IP-Adresse des Geraets (optional)
        protocol: Kommunikationsprotokoll (mqtt, http, coap, lora)
    """
    store = get_store()
    device_id = _generate_id("dev")

    device = {
        "id": device_id,
        "name": name,
        "type": device_type,
        "location": location,
        "firmware_version": firmware_version,
        "tags": [t.strip() for t in tags.split(",") if t.strip()],
        "ip_address": ip_address,
        "protocol": protocol,
        "status": "online",
        "registered_at": now_iso(),
        "last_seen": now_iso(),
        "telemetry": {},
        "metadata": {}
    }

    store["devices"][device_id] = device
    save_store(store)

    return {
        "success": True,
        "device_id": device_id,
        "message": f"Geraet '{name}' erfolgreich registriert",
        "device": device
    }


@mcp.tool()
def list_devices(
    device_type: str = "",
    location: str = "",
    status: str = "",
    tag: str = "",
) -> dict:
    """
    Listet alle registrierten IoT-Geraete auf, optional gefiltert.

    Args:
        device_type: Filtert nach Geraete-Typ (sensor, actuator, gateway, etc.)
        location: Filtert nach Standort (Teilstring-Suche)
        status: Filtert nach Status (online, offline, warning, error)
        tag: Filtert nach Tag
    """
    store = get_store()
    devices = list(store["devices"].values())

    # Filterung
    if device_type:
        devices = [d for d in devices if d.get("type") == device_type]
    if location:
        devices = [d for d in devices if location.lower() in d.get("location", "").lower()]
    if status:
        devices = [d for d in devices if d.get("status") == status]
    if tag:
        devices = [d for d in devices if tag in d.get("tags", [])]

    # Zusammenfassung
    status_counts = {}
    for d in store["devices"].values():
        s = d.get("status", "unknown")
        status_counts[s] = status_counts.get(s, 0) + 1

    return {
        "total_registered": len(store["devices"]),
        "filtered_count": len(devices),
        "status_summary": status_counts,
        "devices": devices
    }


@mcp.tool()
def get_device_status(device_id: str) -> dict:
    """
    Gibt den aktuellen Status und Telemetrie-Daten eines Geraets zurueck.

    Args:
        device_id: ID des Geraets (aus register_device oder list_devices)
    """
    store = get_store()

    if device_id not in store["devices"]:
        return {"error": f"Geraet '{device_id}' nicht gefunden"}

    device = store["devices"][device_id]

    # Simulierte Telemetrie-Werte je nach Typ
    device_type = device.get("type", "sensor")
    simulated_telemetry = {}

    if device_type == "sensor":
        simulated_telemetry = {
            "temperature": round(random.uniform(18.0, 35.0), 1),
            "humidity": round(random.uniform(30.0, 80.0), 1),
            "battery_level": random.randint(20, 100),
            "signal_strength": random.randint(-80, -40),
        }
    elif device_type == "actuator":
        simulated_telemetry = {
            "state": random.choice(["on", "off"]),
            "power_consumption_w": round(random.uniform(0, 500), 1),
            "cycles_today": random.randint(0, 50),
        }
    elif device_type == "gateway":
        simulated_telemetry = {
            "connected_devices": random.randint(1, 50),
            "messages_forwarded": random.randint(100, 10000),
            "cpu_usage_pct": random.randint(5, 80),
            "memory_usage_pct": random.randint(10, 90),
        }
    elif device_type == "camera":
        simulated_telemetry = {
            "fps": random.choice([15, 24, 30]),
            "resolution": "1920x1080",
            "storage_free_gb": round(random.uniform(0, 100), 1),
            "motion_detected": random.choice([True, False]),
        }

    # Letztes Telemetrie-Update speichern
    device["telemetry"] = simulated_telemetry
    device["last_seen"] = now_iso()
    store["devices"][device_id] = device
    save_store(store)

    return {
        "device_id": device_id,
        "name": device["name"],
        "status": device["status"],
        "type": device["type"],
        "location": device["location"],
        "firmware_version": device["firmware_version"],
        "ip_address": device.get("ip_address", ""),
        "protocol": device.get("protocol", "mqtt"),
        "uptime": _device_uptime(device["registered_at"]),
        "last_seen": device["last_seen"],
        "telemetry": simulated_telemetry,
        "tags": device.get("tags", []),
    }


@mcp.tool()
def update_firmware(
    device_id: str,
    new_version: str,
    notes: str = "",
) -> dict:
    """
    Simuliert ein Firmware-Update fuer ein IoT-Geraet.

    Args:
        device_id: ID des Geraets
        new_version: Neue Firmware-Version (z.B. '2.1.0')
        notes: Notizen zum Update (z.B. 'Sicherheitspatch fuer CVE-2025-1234')
    """
    store = get_store()

    if device_id not in store["devices"]:
        return {"error": f"Geraet '{device_id}' nicht gefunden"}

    device = store["devices"][device_id]
    old_version = device["firmware_version"]

    # Update ausfuehren
    device["firmware_version"] = new_version
    device["last_seen"] = now_iso()
    store["devices"][device_id] = device

    # History eintragen
    history_entry = {
        "device_id": device_id,
        "device_name": device["name"],
        "from_version": old_version,
        "to_version": new_version,
        "notes": notes,
        "timestamp": now_iso(),
        "status": "success",
    }
    store["firmware_history"].append(history_entry)

    # Alert hinzufuegen
    store["alerts"].append({
        "id": _generate_id("alert"),
        "device_id": device_id,
        "type": "firmware_update",
        "severity": "info",
        "message": f"Firmware von {old_version} auf {new_version} aktualisiert",
        "timestamp": now_iso(),
        "resolved": True,
    })

    save_store(store)

    return {
        "success": True,
        "device_id": device_id,
        "device_name": device["name"],
        "old_version": old_version,
        "new_version": new_version,
        "message": f"Firmware erfolgreich aktualisiert: {old_version} → {new_version}",
        "notes": notes,
    }


@mcp.tool()
def send_command(
    device_id: str,
    command: str,
    parameters: str = "",
) -> dict:
    """
    Sendet einen Remote-Befehl an ein IoT-Geraet.

    Args:
        device_id: ID des Geraets
        command: Befehl (z.B. 'reboot', 'set_interval', 'enable', 'disable', 'calibrate', 'reset')
        parameters: Optionale JSON-Parameter als String (z.B. '{"interval_seconds": 60}')
    """
    store = get_store()

    if device_id not in store["devices"]:
        return {"error": f"Geraet '{device_id}' nicht gefunden"}

    device = store["devices"][device_id]

    # Parameter parsen
    params = {}
    if parameters:
        try:
            params = json.loads(parameters)
        except Exception:
            params = {"raw": parameters}

    # Befehlsausfuehrung simulieren
    valid_commands = ["reboot", "set_interval", "enable", "disable", "calibrate", "reset", "blink", "ping", "get_config", "set_config"]
    command_lower = command.lower()

    if command_lower not in valid_commands:
        return {
            "success": False,
            "error": f"Unbekannter Befehl '{command}'",
            "valid_commands": valid_commands
        }

    # Status aendern bei bestimmten Befehlen
    if command_lower == "reboot":
        device["status"] = "online"
        device["last_seen"] = now_iso()
    elif command_lower == "disable":
        device["status"] = "offline"
    elif command_lower == "enable":
        device["status"] = "online"

    store["devices"][device_id] = device

    # Command-Log eintragen
    log_entry = {
        "id": _generate_id("cmd"),
        "device_id": device_id,
        "device_name": device["name"],
        "command": command,
        "parameters": params,
        "timestamp": now_iso(),
        "status": "executed",
        "response_time_ms": random.randint(10, 500),
    }
    store["command_log"].append(log_entry)

    save_store(store)

    return {
        "success": True,
        "device_id": device_id,
        "device_name": device["name"],
        "command": command,
        "parameters": params,
        "response": f"Befehl '{command}' erfolgreich ausgefuehrt",
        "response_time_ms": log_entry["response_time_ms"],
        "timestamp": log_entry["timestamp"],
    }


@mcp.tool()
def get_alerts(
    device_id: str = "",
    severity: str = "",
    resolved: bool = False,
    limit: int = 20,
) -> dict:
    """
    Ruft Alerts und Warnungen fuer IoT-Geraete ab.

    Args:
        device_id: Filtert Alerts fuer ein bestimmtes Geraet (optional)
        severity: Filtert nach Schwere (info, warning, error, critical)
        resolved: Wenn True, zeigt auch geloeste Alerts (Standard: False = nur offene)
        limit: Maximale Anzahl zurueckgegebener Alerts (Standard: 20)
    """
    store = get_store()
    alerts = store.get("alerts", [])

    # Demo-Alerts hinzufuegen wenn leer
    if not alerts:
        alerts = _generate_demo_alerts(store)
        store["alerts"] = alerts
        save_store(store)

    # Filterung
    filtered = alerts.copy()
    if device_id:
        filtered = [a for a in filtered if a.get("device_id") == device_id]
    if severity:
        filtered = [a for a in filtered if a.get("severity") == severity]
    if not resolved:
        filtered = [a for a in filtered if not a.get("resolved", False)]

    # Neueste zuerst
    filtered = list(reversed(filtered))[:limit]

    severity_counts = {}
    for a in alerts:
        s = a.get("severity", "unknown")
        severity_counts[s] = severity_counts.get(s, 0) + 1

    return {
        "total_alerts": len(alerts),
        "open_alerts": len([a for a in alerts if not a.get("resolved", False)]),
        "severity_summary": severity_counts,
        "filtered_count": len(filtered),
        "alerts": filtered
    }


@mcp.tool()
def resolve_alert(alert_id: str, resolution_note: str = "") -> dict:
    """
    Markiert einen Alert als geloest.

    Args:
        alert_id: ID des Alerts (aus get_alerts)
        resolution_note: Optionale Notiz zur Loesung
    """
    store = get_store()
    alerts = store.get("alerts", [])

    for alert in alerts:
        if alert.get("id") == alert_id:
            alert["resolved"] = True
            alert["resolved_at"] = now_iso()
            alert["resolution_note"] = resolution_note
            store["alerts"] = alerts
            save_store(store)
            return {
                "success": True,
                "alert_id": alert_id,
                "message": "Alert als geloest markiert",
                "resolution_note": resolution_note
            }

    return {"error": f"Alert '{alert_id}' nicht gefunden"}


@mcp.tool()
def device_analytics(
    period_days: int = 7,
    device_id: str = "",
) -> dict:
    """
    Gibt Analyse und Statistiken ueber den Device-Fleet zurueck.

    Args:
        period_days: Analysezeitraum in Tagen (Standard: 7)
        device_id: Optional: Analyse fuer ein spezifisches Geraet
    """
    store = get_store()
    devices = list(store["devices"].values())
    alerts = store.get("alerts", [])
    firmware_history = store.get("firmware_history", [])
    command_log = store.get("command_log", [])

    if device_id:
        if device_id not in store["devices"]:
            return {"error": f"Geraet '{device_id}' nicht gefunden"}
        devices = [store["devices"][device_id]]

    # Fleet-Statistiken
    total = len(devices)
    by_status = {}
    by_type = {}
    by_location = {}

    for d in devices:
        s = d.get("status", "unknown")
        t = d.get("type", "unknown")
        loc = d.get("location", "unknown")

        by_status[s] = by_status.get(s, 0) + 1
        by_type[t] = by_type.get(t, 0) + 1
        by_location[loc] = by_location.get(loc, 0) + 1

    # Alert-Statistiken
    critical_alerts = len([a for a in alerts if a.get("severity") == "critical" and not a.get("resolved")])
    warning_alerts = len([a for a in alerts if a.get("severity") == "warning" and not a.get("resolved")])

    # Firmware-Statistiken
    unique_versions = set(d.get("firmware_version", "unknown") for d in devices)

    # Fleet-Gesundheitsscore (0-100)
    online_pct = (by_status.get("online", 0) / total * 100) if total > 0 else 0
    alert_penalty = min(50, critical_alerts * 10 + warning_alerts * 3)
    health_score = max(0, round(online_pct - alert_penalty))

    # Empfehlungen
    recommendations = []
    if by_status.get("offline", 0) > 0:
        recommendations.append(f"{by_status['offline']} Geraete offline — Verbindung pruefen")
    if critical_alerts > 0:
        recommendations.append(f"{critical_alerts} kritische Alerts erfordern sofortige Aufmerksamkeit")
    if len(unique_versions) > 3:
        recommendations.append(f"{len(unique_versions)} verschiedene Firmware-Versionen — Update-Strategie empfohlen")
    if total == 0:
        recommendations.append("Noch keine Geraete registriert — starte mit register_device")

    return {
        "analysis_period_days": period_days,
        "fleet_overview": {
            "total_devices": total,
            "by_status": by_status,
            "by_type": by_type,
            "top_locations": dict(list(sorted(by_location.items(), key=lambda x: x[1], reverse=True))[:5]),
        },
        "health_score": health_score,
        "health_rating": "Excellent" if health_score >= 90 else "Good" if health_score >= 70 else "Fair" if health_score >= 50 else "Poor",
        "alerts": {
            "total": len(alerts),
            "open_critical": critical_alerts,
            "open_warnings": warning_alerts,
        },
        "firmware": {
            "unique_versions": list(unique_versions),
            "update_history_total": len(firmware_history),
        },
        "commands_executed": len(command_log),
        "recommendations": recommendations,
    }


@mcp.tool()
def get_fleet_dashboard() -> dict:
    """
    Gibt ein vollstaendiges Fleet-Dashboard mit Gesamtueberblick zurueck.
    Kein Parameter noetig — gibt eine strukturierte Uebersicht aller Geraete,
    Alerts und Aktivitaeten zurueck.
    """
    store = get_store()
    devices = store.get("devices", {})
    alerts = store.get("alerts", [])
    firmware_history = store.get("firmware_history", [])
    command_log = store.get("command_log", [])

    # Online/Offline
    online = [d for d in devices.values() if d.get("status") == "online"]
    offline = [d for d in devices.values() if d.get("status") == "offline"]
    warning_devices = [d for d in devices.values() if d.get("status") == "warning"]

    # Offene kritische Alerts
    open_critical = [a for a in alerts if a.get("severity") == "critical" and not a.get("resolved")]

    # Letzte 5 Aktivitaeten
    recent_commands = list(reversed(command_log))[:5]
    recent_firmware = list(reversed(firmware_history))[:5]

    return {
        "dashboard": {
            "fleet_size": len(devices),
            "online": len(online),
            "offline": len(offline),
            "warnings": len(warning_devices),
            "open_critical_alerts": len(open_critical),
        },
        "top_devices": [
            {"id": d["id"], "name": d["name"], "status": d["status"], "type": d["type"], "location": d["location"]}
            for d in list(devices.values())[:10]
        ],
        "recent_commands": recent_commands,
        "recent_firmware_updates": recent_firmware,
        "critical_alerts": open_critical[:5],
        "quick_actions": [
            "register_device — Neues Geraet registrieren",
            "list_devices — Alle Geraete anzeigen",
            "get_device_status <id> — Geraete-Status abrufen",
            "send_command <id> reboot — Geraet neu starten",
            "get_alerts — Alle offenen Alerts anzeigen",
            "device_analytics — Fleet-Analyse starten",
        ],
    }


def _generate_demo_alerts(store: dict) -> list:
    """Generiert Demo-Alerts wenn keine Geraete vorhanden."""
    devices = list(store.get("devices", {}).values())
    if not devices:
        return []

    alerts = []
    severities = ["info", "warning", "error", "critical"]

    for i, device in enumerate(devices[:3]):
        severity = severities[i % len(severities)]
        messages = {
            "info": f"Geraet '{device['name']}' meldet sich regelmaessig",
            "warning": f"Battery low auf '{device['name']}' (< 20%)",
            "error": f"Verbindungsabbruch bei '{device['name']}' — 3 Wiederversuche",
            "critical": f"Kein Heartbeat von '{device['name']}' seit > 1 Stunde",
        }
        alerts.append({
            "id": _generate_id("alert"),
            "device_id": device["id"],
            "type": "health_check",
            "severity": severity,
            "message": messages[severity],
            "timestamp": now_iso(),
            "resolved": severity == "info",
        })

    return alerts


def main():
    """Einstiegspunkt fuer den MCP-Server."""
    mcp.run()


if __name__ == "__main__":
    main()
