"""Persistenter lokaler Device-Store (JSON-Datei)."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

# Pfad zur persistenten Datei
STORE_PATH = Path.home() / ".iot_device_store.json"


def _load() -> dict:
    """Laedt den Store aus der Datei."""
    if not STORE_PATH.exists():
        return {
            "devices": {},
            "alerts": [],
            "firmware_history": [],
            "command_log": [],
        }
    with open(STORE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: dict) -> None:
    """Speichert den Store in die Datei."""
    with open(STORE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_store() -> dict:
    """Gibt den aktuellen Store zurueck."""
    return _load()


def save_store(data: dict) -> None:
    """Speichert den Store."""
    _save(data)


def now_iso() -> str:
    """Gibt aktuelle Zeit als ISO-String zurueck."""
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
