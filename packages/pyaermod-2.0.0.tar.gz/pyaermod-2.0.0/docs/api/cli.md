# cli

::: pyaermod.cli
