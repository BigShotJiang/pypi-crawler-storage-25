"""Test suite for pyisolate."""
