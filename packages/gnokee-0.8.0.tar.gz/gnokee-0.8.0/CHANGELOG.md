# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.8.0] — 2026-05-16

The "verifiable forgetting" ramp. gnokee finally ships Mode 2 of the
three forgetting modes enumerated in `docs/architecture.md §Forgetting`:
hard-delete with a verifiable audit trail. ADR-0026.

**Two MCP tools land.** `gnokee_forget_episode(tenant_id, episode_uuid,
*, cascade=False, reason, actor=None)` hard-deletes one episode and all
derived data from both Postgres and Neo4j; on a chain node it refuses
with `cannot_forget_chain_node` (ADR-0022 refusal posture) unless
`cascade=True` is set, in which case descendants are also deleted —
ancestors are never cascaded, their `superseded_by` pointer is cleared
via explicit UPDATE. `gnokee_forget_tenant(tenant_id, *, dry_run=True,
reason, actor=None)` defaults to a planning call that returns counts
without writing; the caller MUST issue a second call with
`dry_run=False` to execute — the two-call ceremony is the guard for an
irreversible op (no `confirm_tenant_id` parameter).

**Audit-row-as-journal.** A new schema-isolated table
`gnokee_maintenance.forget_audit` records a `begin → commit` pair per
forget call inside the SERIALIZABLE Postgres transaction that covers
the sweep DELETEs. The schema isolation is load-bearing: the
`gnokee_maintenance` schema survives a `gnokee_forget_tenant` sweep,
which is its purpose — proof the deletion happened. The `commit` row's
`receipt` JSONB carries the frozen `cascade_uuids[]` list and a
per-uuid `bitemporal_snap` (`{asserted_at, valid_at, valid_until}`)
captured pre-DELETE for compliance completeness. A `state='fail'` row
is appended when the post-commit Neo4j sweep raises;
`gnokee.resume_forget(tenant_id, *, pipeline)` retries Neo4j-only
failures using the frozen cascade UUIDs from the committed audit row
(mirror of `gnokee.resume_ingest` from ADR-0024).

**`ingest_journal` cascade gap closed (issue #130).** `ingest_journal`
has no FK to `episode_metadata` (designed append-only per ADR-0024), so
the v0.7 `gnokee_forget_tenant` plan would have left orphaned journal
rows after tenant deletion. The v0.8 sweep DELETEs `ingest_journal`
explicitly inside the same SERIALIZABLE tx as the
`episode_metadata` + FK-cascade chain.

**Consumer-side KMS handoff.** `ForgetReceipt.affected_key_ids[]`
surfaces the DEK identifiers attached to deleted encrypted episodes;
the consumer is responsible for KMS destruction. gnokee never holds
DEKs, so Mode 3 (cryptographic erasure) remains a documentation note —
this field is the handoff point for any consumer who wants to
approximate Mode 3 after a Mode 2 call.

### Added

- **`gnokee_forget_episode` + `gnokee_forget_tenant` MCP tools and
  `gnokee.forget.forget_episode` / `gnokee.forget.forget_tenant`
  Python APIs (#133, ADR-0026).** Both return a compact
  `ForgetReceipt` on the MCP surface (summary string + key fields)
  and a richer `ForgetReceiptDetail` on the Python surface (full
  storage metrics + frozen cascade UUIDs). DAG behaviour matrix:
  `cascade=False` refuses chain nodes (`cannot_forget_chain_node`,
  no descendant UUIDs inlined); `cascade=True` hard-deletes target +
  all descendants transitively; ancestors are never touched but
  their `superseded_by` pointer is cleared via explicit UPDATE
  (no FK exists). Tenant tool defaults `dry_run=True` — first call is
  always a planning call. `affected_key_ids[]` on the receipt
  surfaces consumer-KMS handoff (gnokee never holds DEKs). See
  `docs/api/python.md` § `gnokee.forget`.

- **`gnokee_maintenance.forget_audit` table + migration
  `0017_forget_audit.sql` (#133).** Schema-isolated audit table that
  survives `gnokee_forget_tenant` — proof of deletion lives outside
  the public schema the sweep clears. Records a `begin → commit`
  pair per forget call inside the SERIALIZABLE Postgres tx covering
  the sweep DELETEs; `state='fail'` rows are appended on post-commit
  Neo4j sweep errors. `receipt` JSONB carries frozen
  `cascade_uuids[]` + per-uuid `bitemporal_snap`
  (`{asserted_at, valid_at, valid_until}`) captured pre-DELETE.

- **`gnokee.resume_forget(tenant_id, *, pipeline)` Python API (#133,
  ADR-0026).** Retries Neo4j-only sweep failures using the frozen
  cascade UUIDs from the committed audit row. Mirrors
  `gnokee.resume_ingest` (ADR-0024) for operator-driven recovery
  after partial Neo4j outage. Python-API only in v0.8; CLI
  (`scan-forgets` / `resume-forget`) deferred — matches
  `resume_ingest` precedent.

### Fixed

- **Clinical-topic routing in `gnokee_query` (#134, fixed in #135).**
  v0.7.0 shipped the typed-store back-ends for labs (ADR-0009,
  v0.2) and meds (ADR-0010, v0.2) but `gnokee_query` ask-parsing
  never wired `topic="clinical.lab"` / `topic="clinical.med"` to
  `gnokee_lab_query` / `gnokee_med_query`. Bug surfaced when MCP
  callers received the graph-only path on clinical asks instead of
  the typed-store path that already existed. ADR-0013 §sequencing:
  v0.6 row shipped end-to-end; v0.6.1 row (ask-parsing) closed
  here.

- **Encrypted-body plaintext window dropped before persistence
  (#132, fixed in #136).** On the encrypted-branch + opt-in
  `EncryptedBody.content_for_embedding=PLAINTEXT`, the v0.6.0–v0.7.0
  ingest path leaked plaintext into `Episodic.content` +
  `Episodic.name` on Neo4j and into `lab_record.*` /
  `med_record.*` typed-store columns. The pre-fix surface
  contradicted the privacy posture promised by `EncryptedBody` —
  this was a privacy-contract violation, not just doc rot. v0.8.0
  drops `content_for_embedding` from local scope after Stage 3
  (embed) returns; Stage 4 (`graph.write_lite_episode`) branches on
  `is_encrypted` directly and always lands `content=""`,
  `name="[encrypted episode]"`,
  `source_description="gnokee.ingest.encrypted"`. Stage 6
  (`parse_labs` / `parse_meds`) is force-disabled on the encrypted
  branch. The opt-in plaintext window now leaves the gnokee process
  only over the TEI socket and is dropped before any persistence
  step touches it. See `docs/privacy-posture.md` § "What
  encrypted-body delivers" / § "What gnokee stores in plaintext".

## [0.7.0] — 2026-05-16

The "durability + lineage" ramp. Two things ship together:

1. **Durability.** Ingest now writes an append-only `ingest_journal` row
   before Stage 4 (lite-Episodic Neo4j MERGE) and after Stage 5 (PG txn).
   On container kill / OOM between Stage 4 and Stage 5 the orphan
   `begin` row is surfaced (never auto-replayed); operators call
   `gnokee.resume_ingest()` to finish the half-written episode using
   the journaled `stage_4_time` so the resumed `Episodic.created_at`
   matches the original ingest-time clock. ADR-0024.

2. **Lineage.** `gnokee_history_of` returns the full supersession DAG
   (Cytoscape-flat envelope: `nodes` + `edges` + `head` + `root`) for
   any episode in a tenant; `mode=compact` keeps it LLM-cheap,
   `mode=verbatim` attaches body text on the newest `top_k_bodies`
   nodes. Encrypted episodes never leak plaintext. `as_of` gives
   bi-temporal time-travel; `cycle_detected=true` reports DAG defects
   without raising.

Companion: hard-removal of the v0.6-deprecated `GNOKEE_INGEST_STRICT`
env var. v0.6 already neutralized it (no-op-with-warning) once
ADR-0023 made lite-fallback the contract — v0.7 finishes the cleanup.

### Added

- **Ingest crash-recovery journal + `gnokee.resume_ingest` Python API (#122, ADR-0024).**
  Append-only `ingest_journal` Postgres table records one `begin` row
  before Stage 4 (lite-Episodic Neo4j MERGE) and one `commit` row after
  Stage 5 (PG txn) on every `ingest_episode` call; `fail` rows are
  appended on unhandled exceptions (compensation runs first). On
  container kill / OOM between Stage 4 and Stage 5, the `begin`
  without matching `commit` is surfaced by `IngestPipeline` on the
  first ingest per tenant per process as a `ResumableIngest` log
  warning — gnokee NEVER auto-replays. Operators call
  `gnokee.resume_ingest(tenant_id, episode_uuid, episode, *, pipeline)`
  to re-execute Stage 4 (Neo4j MERGE preserves the journaled
  `stage_4_time` → `Episodic.created_at`) + Stage 5 (idempotent
  inserts) + write the `commit` row. The consumer re-supplies the
  original `EpisodeIn`; gnokee refuses with `IngestJournalError` on
  payload-hash drift (`SHA256(tenant_id ‖ our_id ‖ valid_at)`). Stage
  6 (Graphiti enhancement) stays the domain of
  `run_deferred_extraction` and is force-disabled on resume. Q19
  spike: 2.17% median latency regression (101.93 ms on / 99.76 ms off
  on `extract=False` ingests), well under ADR-0024's 10% threshold.
  See `docs/architecture.md` § Durability and
  `docs/api/python.md` § `gnokee.resume_ingest`.

- **`gnokee_history_of` MCP tool + `gnokee.history_of` Python API (#123).**
  Returns the supersession DAG for an episode in flat Cytoscape-style
  envelope (`nodes`, `edges`, `head`, `root`, `truncated`,
  `cycle_detected`). `mode=compact` (default) ships LLM-facing nodes
  with no body; `mode=verbatim` attaches body text to the newest
  `top_k_bodies` nodes capped at `per_body_char_cap` chars. Encrypted
  episodes return `body_encrypted=true` + ciphertext envelope —
  plaintext NEVER leaves gnokee for those. `as_of` filters every node
  by `asserted_at <= as_of`; nodes whose `superseded_by` points outside
  the visible set are reported as `active` for that time-travel slice.
  Storage walk uses a Postgres recursive CTE bounded by `max_nodes` (32);
  on cycle/depth-exceeded the response carries `cycle_detected=true`
  instead of raising. See `docs/api/python.md` § `gnokee.history_of`.

- **`EpisodeIn.corrects_reason: str | None` field (#123).** Optional
  consumer-supplied rationale (≤500 chars) for the supersession declared
  via `corrects:`. Persisted on `episode_metadata.corrects_reason` via
  migration `0014_episode_corrects_reason.sql` and surfaced verbatim on
  `HistoryNode.rationale` in DAG responses. Only honored when `corrects:`
  is also set; ignored otherwise. Python-API only in v0.7; MCP exposure
  on `gnokee_ingest_episode` deferred to a follow-up.

### Removed

- **BREAKING: `GNOKEE_INGEST_STRICT` env var removed (#124).** Deprecated in
  v0.6 (PR #111, H3) after ADR-0023 made gnokee own Episodic storage and
  failure semantics uniform (lite-fallback + `extraction_deferred` flag).
  Setting `GNOKEE_INGEST_STRICT=1` is now a no-op — the env var is no longer
  read. No behavior change for production callers: the v0.6 deprecation
  path already neutralized the loud-failure mode. Replacement signals on
  `IngestReceipt.ingest_telemetry`: `lite_fallback_engaged`,
  `enhancement_retries`, `orphan_edge_warnings`.

## [0.6.0] — 2026-05-16

The "ingest hardening" ramp. gnokee never loses an episode regardless of
Graphiti state. Closes the Q18 silent-drop bug class (`INGEST_GAP_NOT_RETRIEVAL_GAP`
verdict, 2026-05-12) on the LongMemEval-S corpus. Architectural shift per
[ADR-0023](docs/adr/0023-gnokee-owns-episode-storage.md): gnokee owns the
Episodic write surface, Graphiti is best-effort enhancement.

**Q18 release-cut gate (2026-05-16, stageC_30q20s @ conc=4):**
- silent-drops: 0 (v0.5 baseline: 14/17)
- recall@5 measurable: 100% (v0.5: 17.6%) — 5.7× improvement
- recall@1: 88.2% / recall@3: 94.1%
- 600 episodes ingested @ tier-1 200K TPM with 4-way concurrency; Z1 + Z4
  preserved all of them; 15 (2.5%) hit Z1 lite-fallback on genuine rate-limits.

### Added

- **v0.6 Z1 ingest hardening (#111):** storage-first ingest pipeline —
  gnokee writes Episodic + episode_metadata + content_embedding FIRST
  using a gnokee-generated `episode_uuid`; Graphiti's `add_episode`
  runs after as best-effort enhancement. On graphiti failure (RateLimitError
  exhaustion or non-retryable raise), episode stays retrievable;
  `IngestReceipt.extraction_deferred=True` flags rehydration via
  `maintenance.run_deferred_extraction`. Closes the Q18 silent-drop bug
  class. See [ADR-0023](docs/adr/0023-gnokee-owns-episode-storage.md).

- **v0.6 Z4 adaptive ingest retry (#111):** `IngestPipeline` gains
  `extraction_concurrency: int = 2` kwarg; `asyncio.Semaphore` bounds
  parallel graphiti enhancement calls. Per-call adaptive backoff via
  `_retry_enhancement` (max 3 retries, ±20% jitter, honours
  `RateLimitError.retry_after`). Receipt surfaces
  `IngestTelemetry.enhancement_retries` + `lite_fallback_engaged`.

- **`GraphitiStore.remove_lite_episode`** — direct Cypher `MATCH ... DETACH DELETE`
  that reaches lite-written Episodic nodes for compensate-on-failure.
  `GraphitiStore.add_episode` gains `uuid: UUID | None = None` kwarg.

- **`MetadataStore.set_extraction_deferred`** — flips the column
  post-Stage-6 when lite-fallback engages.

- **Q18 spike `--gate` mode** — `python evals/spike_q18_recall_at_k_diagnostic/run.py --gate`
  asserts the v0.6 release-cut thresholds (≥14/17 measurable in storage,
  ≥80% recall@5 on measurable).

- **MCP `gnokee_recall` exposes `top_k_bodies` + `per_body_char_cap`**
  (issue #84). The two body-coverage knobs shipped in v0.4.0 (#52)
  were Python-API only; MCP consumers (noggin, Claude / Cursor,
  third-party MCP clients) were pinned to `DEFAULT_TOP_K_BODIES = 3`
  and `DEFAULT_PER_BODY_CHAR_CAP = 600`. Both parameters now appear
  on the MCP tool surface with the same defaults, forwarded into the
  Python `recall()` call. No behavioural change at defaults.

### Fixed

- **`maintenance.run_deferred_extraction` invalid SQL** (#111 M4 side-fix):
  parametrized `SET app.current_tenant = $1` does not work in Postgres
  (SET rejects positional params). Replaced with
  `SELECT set_config('app.current_tenant', $1, false)`. Pre-existing
  latent bug surfaced by the Z1.7 rehydration test.

- **`maintenance.run_deferred_extraction` missing uuid plumbing** (#111 M4):
  `graphiti.add_episode` was called without `uuid=episode_uuid` during
  rehydration, creating new graphiti-owned Episodic nodes instead of
  attaching entities to the existing lite Episodic. Now passes the
  gnokee-owned uuid + pre-overwrites the lite Episodic content to
  `augment_for_extraction(...)` so graphiti's load-by-uuid extraction
  sees the augmented form.

- `docs/api/python.md` `per_body_char_cap` example default corrected
  from `800` → `600` to match `src/gnokee/retrieval.py`
  `DEFAULT_PER_BODY_CHAR_CAP`.

### Deprecated

- **`GNOKEE_INGEST_STRICT` env var:** emits `DeprecationWarning` on
  `IngestPipeline.__init__` when set. Hard-removal in v0.7. Z1 closes
  the silent-drop class by architecture (ADR-0023); the env-flag-based
  "fail loud on orphan-edge warnings" surface is no longer load-bearing.
  Replacement: `IngestTelemetry.lite_fallback_engaged` +
  `enhancement_retries` + `orphan_edge_warnings`.

### Notes

- ADR-0012 (cross-tool eval verdict) amended with § v0.6 ingest hardening.
- ADR-0019 (confidence model) amended with § LongMemEval-S publish
  stance refresh — once the Q18 re-spike passes, the publish stance
  lifts from `DECLINE_TO_PUBLISH` to `PUBLISH_POST_Z1`.

## [0.5.0] — 2026-05-12

The "read-side hardening" ramp. v0.5 keeps the v0.1 core surface
unchanged and lands six adopt-decisions that sharpen the MCP read
contract: declarative `gnokee_query` envelope (ADR-0013), per-claim
bi-temporal citation envelope (ADR-0016), `confidence` recency-proxy
field (ADR-0019, `SHIP_RECENCY_AS_PROXY` confirmed at N=31 in stage-2
spike), Obsidian vault adapter (ADR-0020 `SHIP_ADAPTER`),
three-tier consumer-surface strategy (ADR-0021), and explicit refusal
posture (`refused: bool` + `cosine_floor` knob; ADR-0022 Option A on
top of Option D). Adds per-fact `cosine_top1` telemetry on
`gnokee_recall` (#89, opt-in flag, default off). v0.5 narrative on
LongMemEval-S: `DECLINE_TO_PUBLISH` (ADR-0019 amendment) — Q18
verdict isolated the gap to `add_episode` ingest, not retrieval; the
re-publish gates on v0.6 Z-series ingest hardening (#111).

> **Backfilled 2026-05-16.** Tag `v0.5.0` (commit `ed8cec7`) shipped
> on 2026-05-12 without promoting `[Unreleased]` → `[0.5.0]` in this
> file. Section reconstructed from the GitHub release notes + commit
> log `git log v0.4.0..v0.5.0`.

### Added

- **ADR-0013 — `gnokee_query` declarative envelope MCP tool** (issue
  #72, PR #100). Pinecone KnowQL + GCP Memory Bank `lookup_context`
  shape on top of the v0.1 `gnokee_recall` primitive. `confidence_floor`
  parameter applies on top of the recency-proxy `confidence` value per
  ADR-0019.
- **ADR-0015 — `gnokee_wiki_export` + `llms.txt` manifest** (issue
  #74, PR #99). Karpathy LLM-wiki + `llms.txt` convention; one-shot
  fetch of all per-tenant facts in LLM-readable form.
- **ADR-0016 — per-claim bi-temporal citation envelope on MCP read
  responses** (issue #76, PR #92). NotebookLM / GraphRAG / KnowQL
  field-level provenance baseline. Each fact statement carries
  `Citation(fact_uuid, valid_at, asserted_at, confidence)`.
- **ADR-0019 — `confidence` field on read-tool responses** (issue
  #80, PR #87). Function B (recency-only Ebbinghaus, `SHIP_RECENCY_AS_PROXY`)
  ships as the v0.5 `confidence`. Documented as a recency proxy, not a
  calibrated model. Stage-2 spike (#88, PR #118) reconfirmed at N=31
  with 48 composite variants — 0/48 cleared both Spearman + calibration
  gates → ADR-0019 § Follow-up closed; recency proxy is durable.
- **ADR-0020 — Obsidian vault adapter** (issues #96/#97, PR #101).
  Q14 spike verdict `SHIP_ADAPTER`. Drops markdown vaults into gnokee
  via the consumer-side adapter pattern (ADR-0021 tier).
- **ADR-0021 — Consumer surface strategy** (issue #106, PR #113).
  Three-tier policy + source-to-shape routing; closes the recurring
  "which consumer next" question; gates `gnokee-consumer-template`
  sibling repo.
- **ADR-0022 — Refusal posture** (issue #109, PRs #115/#116/#119).
  Q17 spike (`evals/spike_q17_refusal_posture/`) verdict
  `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL` — Option D
  (current "zero refusal envelope" posture, consumer LLM renders the
  refusal) accepted as v0.5 posture. Option A landed same day:
  `refused: bool = False` on `RecallResponse`, set `True` when
  `len(facts) == 0 AND len(episode_fallback) == 0`. Companion knob
  `cosine_floor: float | None = None` on `recall()` /
  `gnokee_recall` MCP tool: when set (0.0-1.0), episodes whose
  cosine similarity falls below the floor are pruned at stage 3.6,
  making `refused=true` observable in default mode.
- **Per-fact `cosine_top1` telemetry on `gnokee_recall`** (issue
  #89, PR #117). Each `facts[]` entry gains
  `cosine_top1: float | None` when `include_cosine_top1=true`.
  Pgvector cosine similarity in `[0, 1]` of the source episode vs
  query; `null` for Path-A fallback facts. Telemetry only — does
  NOT reorder or threshold-prune. Closes the "recency-proxy as
  cosine proxy" caveat in ADR-0019. Default off — wire shape stable
  for non-opt-in consumers.
- **Q14.1 — threshold-semantics sweep across past spike harnesses**
  (issue #107, PR #114). ADR-0020 follow-up; confirmed no past spike
  verdict silently misfired due to threshold-direction bugs.
- **Z3 — graphiti orphan-edge warnings on `IngestReceipt`** (issue
  #111 partial, PR #112). Loud telemetry surface for the
  `add_episode` silent-drop class. Z1 + Z2 remain for v0.6.
- **ADR-0005 amended** — AGE v1.7.0 maturity correction + concrete
  7–8wk cost (#91, commit `fda572c`); 90-day watch issue filed.
- **Mean-centered cosine etalon separation probe** (#103, PR #105) —
  calibration tooling for embedding diagnostics.
- **Q41 source-grounded refusal spike** verdict ADOPT (#77, PR #93,
  ADR-0008 extension).

### Changed

- **README status banner refreshed** to v0.5; lists v0.5 ADRs +
  `cosine_top1` telemetry.
- **Documentation overhaul** — contributor / user / integrator /
  operator surfaces split (commit `32f0342`).
- **CI deps:** `actions/download-artifact` 4 → 8 (#82),
  `actions/upload-artifact` 4 → 7 (#83).

### Resolved (no-code amendments)

- **#81 — LongMemEval-S v0.5 target** — `DECLINE_TO_PUBLISH` (ADR-0019
  amendment 2026-05-12). Q18 verdict (`evals/spike_q18_recall_at_k_diagnostic/`)
  isolated the gap to graphiti `add_episode` silent-drop ingest, not
  retrieval — 14/17 measurable LongMemEval-S rows had gold sessions
  silently dropped. Re-publish gates on v0.6 #111 Z1 + Z2 landing.
- **#90 — Graphiti literal-numeric extraction gap** — Accept (option
  1 of 4); triple-coverage via `lab_record` / `med_record` /
  `excerpts[]` + `episode_fallback[]` suffices for the v0.5 read
  contract.

### Carryover

- **v0.5.x:** [#95](https://github.com/gnokeelabs/gnokee/issues/95)
  Graphiti fact-ranking allergy-vs-medication edge case (Q41 p_x1_03).
  Low priority single eval miss.
- **v0.6 lead:** [#111](https://github.com/gnokeelabs/gnokee/issues/111)
  graphiti `add_episode` silent-drop ingest hardening (Z1 + Z2);
  Z3 already landed. Highest-leverage retrieval-quality fix.
  Unblocks LongMemEval-S re-publish. **Landed v0.6.0.**

## [0.4.0] — 2026-05-10

The "encrypted_body + body knobs" ramp. Closes the v0.1-deferred
`encrypted_body` `NotImplementedYet` boundary (issue #22): Stage 1
ingest now accepts `content xor encrypted_body`, lands ciphertext
unmodified in a sibling Postgres table, and surfaces it on recall
without ever decrypting. Adds Python-API-only knobs for tighter
body-emission control on `recall()` (#52). Consolidates the duplicate
`episode_metadata.content` + `content_text` plaintext columns into a
single canonical column (#51). Extends the cross-tool eval harness for
LongMemEval-S scale (#62, #63, #64). MCP `gnokee_recall` parameter
surface stays byte-identical to v0.3 — `top_k_bodies` /
`per_body_char_cap` exposure on MCP is deferred to a v0.4.x
maintenance bump.

### Added

- **`encrypted_body` DEK pathway — Stage 1 boundary accepts
  `content xor encrypted_body`** (issue #22).
  `EpisodeIn._content_xor_encrypted_body` Pydantic `model_validator`
  rejects both/neither. Encrypted episodes land
  `(ciphertext, nonce, key_id)` in the new sibling table
  `episode_body_encrypted` via raw-SQL migration
  `0012_episode_body_encrypted.sql` — PK on
  `(tenant_id, episode_uuid)`, FK to `episode_metadata` with
  `ON DELETE CASCADE`. gnokee NEVER holds key material and NEVER
  decrypts: `EncryptedBody.content_for_embedding` plaintext is
  local-scope only, passed to `embeddings.embed_one()` and dropped at
  end of `ingest()`. Recall surfaces
  `RecallResponse.encrypted_bodies[]` carrying
  `EncryptedEpisodeBody(episode_uuid, ciphertext, nonce, key_id)`
  verbatim; excerpt and body lanes filter encrypted episodes out
  before fetching plaintext from Graphiti, and
  `FactProvenance.episode_content` is forced to `""` with the
  ciphertext envelope riding on `FactProvenance.encrypted_body` for
  encrypted rows. New
  `EncryptedBodyStore.{write, get, fetch_many}` all require
  `tenant_id` in the `WHERE` clause. Postgres RLS reuses the existing
  `app.current_tenant` GUC pattern at deployment time. Unblocks
  clinical-Omur phase-1 ingest.
- **`top_k_bodies` + `per_body_char_cap` knobs on `recall()`** (issue
  #52). `_build_episode_body_rows` now truncates each body to
  `per_body_char_cap` chars (default 600 ≈ 150 approx-tokens) before
  token accounting + emission, and stops after `top_k_bodies` rows
  (default 3). Surfaced by Q10 Stage A re-run after #41 hybrid body
  emission landed: every fired body call hit
  `body_first_row_oversize=True` because a single conversation-turn
  body is ~3700 approx-tokens against the 66-token `body_budget` at
  `max_tokens=200` (telemetry from #54). Cap-and-count lets multiple
  ranked episodes share the lane on larger budgets while preserving
  the always-emit-first guard semantics on tight ones. Knob is
  Python-API-only for v0.4; MCP `gnokee_recall` keeps the v0.3
  parameter surface unchanged. **MCP exposure deferred to v0.4.x.**

### Changed

- **Consolidated `episode_metadata.content` + `content_text`** (issue
  #51). After PRs #48 (BM25/RRF) and #49 (deferred extraction) both
  landed in v0.3, `episode_metadata` carried two TEXT columns storing
  identical plaintext for lite-mode episodes. Migration
  `0011_drop_content_column` backfills `content_text` from `content`
  (defence-in-depth) then drops `content`.
  `maintenance.run_deferred_extraction()` now reads `content_text`
  instead. `PgVectorStore.write_content_text` remains the canonical
  write path. `IngestPipeline` Stage 6 metadata write no longer
  carries the dropped column.

### Documentation

- **ADR-0004 amended** for the `encrypted_body` boundary rules: gnokee
  never holds key material; ciphertext + nonce + key_id are the only
  shapes that touch storage; `content_for_embedding` is a local-scope
  embedding window dropped after `embed()` returns (issue #37, PR
  #69).
- **ADR-0012 amendment** bundled: Q10 Stage C-pilot magnitude
  confirmation + `run.py` recovery primitives narrative captured in a
  single doc-only PR (issue #37, PR #69).

### Evals

- **Q12 abstain split + synth-v2 falsifies #62** (issue #62, PR #65).
  Adds the abstain-rate split to LongMemEval-S analysis and lands a
  synth-v2 prompt that pins synthesizer abstention as the dominant
  failure mode at 20-session scale; closes the original Q12 question
  about whether retrieval or synthesis was the bottleneck.
- **`evals/q10/run.py` parallelize per-question + Mem0 adapter
  robustness** (issue #63, PR #66). Per-question execution now runs
  in parallel across the SUT × question matrix; the Mem0 adapter
  recovers from per-call transient errors instead of failing the
  whole grid.
- **Q10 / Zep CE compose env keys + smoke** (issue #64, PR #67).
  Fixes the `store.type must be set` server-exit by aligning the
  docker-compose env keys to what Zep CE actually reads, plus a smoke
  step so future env-key drift fails fast.

## [0.3.0] — 2026-05-09

The "telemetry + integration patterns" ramp. Promotes the recall surface
from "fires and emits a result" to "fires, emits, and reports its own
budget vs emitted accounting." Documents the lite-ingest + deferred-
extraction integration patterns introduced in v0.2.x. Lands the
lite-mode-recall fix that makes `extract=False` actually queryable via
the main retrieval surface.

### Added

- **`RecallResponse.recall_telemetry: RecallTelemetry`** (issue #54).
  Stage 6 per-lane budget vs emitted-token accounting:
  `budget_max_tokens`, `fact_budget`/`excerpt_budget`/`body_budget`,
  `fact_tokens_emitted`/`excerpt_tokens_emitted`/`body_tokens_emitted`,
  `fact_count`/`excerpt_count`/`body_count`, `body_first_row_oversize`.
  Lets eval harnesses + observability record actual budget usage per
  call instead of inferring it from row counts.
- **`gnokee_recall` MCP response carries `recall_telemetry{}`** (issue
  #54). Surfaced to MCP consumers so model-side observability can graph
  body-coverage distributions per session.
- **`_compute_budget_split(...) -> BudgetSplit`** pure helper in
  `retrieval.py`. Replaces the inline four-branch budget split (Path A
  / `wants_excerpt` / hybrid / no-signal) with a unit-tested function;
  same shape powers Stage 6 emission and `RecallTelemetry` reporting.
- **`docs/integration_patterns.md`** (issue #16). Authoritative
  integrator-facing doc on lite-ingest + deferred extraction patterns:
  when to use, when not, backfill scheduling, typed-reads interaction,
  two-customer byte-identical invariant, AGENTS.md compliance matrix.
- **`docs/eval_delta_gate.md`** (issue #16). Documents the v0.3 manual
  eval-delta gate: 5 pp pass-rate floor + per-question PASS→FAIL
  guard; baseline JSONs under `evals/baselines/<spike>.json`. Manual
  gate this ramp; CI in v0.4.
- **`make eval-delta`** Makefile target (issue #16). Stub invoking
  spike runners with `--check-baseline` (flag wired in v0.3 follow-up).
- **Lite-mode recall path: minimal `Episodic` node written to Neo4j on
  `extract=False` ingest** (issue #56). `uuid` (gnokee-owned),
  `group_id`, `valid_at`, `name`, `content`, `created_at`,
  `source_description = "gnokee.ingest.lite"`. No entity nodes, no
  `MENTIONS` / `RELATES_TO` edges. Recall Stage 2a now surfaces
  lite-mode episodes via the BM25 / cosine path; Stage 4 fact-fetch
  returns 0 → Path A body emission fires correctly.

### Changed

- **`_build_episode_body_rows` now returns `BodyRowsResult`** (rows,
  truncated, tokens_emitted, first_row_oversize) instead of a 2-tuple.
  Stage 6 mirrors `tokens_emitted` and `first_row_oversize` into
  `recall_telemetry`. Existing callers updated.
- **ADR-0012 status: Draft → Accepted-with-caveat.** Stage C
  confirmation deferred post-v0.3 tag. See § "v0.3 status decision
  (2026-05-09)" in the ADR for the cost / signal-saturation reasoning.

### Fixed

- **Lite-mode ingest no longer breaks recall** (issue #56). Previously,
  `extract=False` wrote no `Episodic` node to Neo4j, causing Stage 2a
  (`list_candidate_episodes`) to return 0 candidates → empty
  `RecallResponse`. The recall surface now sees lite-mode episodes
  natively.

## [0.2.3] — 2026-05-09

First PyPI publish (closes #20). Restructures install UX so naked
`pip install gnokee` works and the wheel ships without duplicate
migration files. No retrieval / ingest behaviour changes; no new
migrations.

### Added

- **`.github/workflows/pypi-publish.yml`** — Trusted Publishing
  (OIDC) workflow that builds sdist + wheel on `v*` tag pushes,
  guards against duplicate-entry regressions in the wheel, and
  uploads to PyPI (or TestPyPI via `workflow_dispatch`) without a
  stored API token.

### Changed

- **`[core]` extras → mandatory `dependencies`.** `gnokee/__init__.py`
  eagerly imports `ingest` + `retrieval`, both of which need
  `asyncpg` / `graphiti-core` / `neo4j` / `pgvector` / `httpx` /
  `openai` / `structlog` / `langdetect`. Naked `pip install gnokee`
  used to `ImportError` on first import; it now works. The `[core]`
  extra is retained as a no-op alias so existing `pip install
  gnokee[core]` invocations keep working without surprise.
- **`gnokee.__version__` now reads from `importlib.metadata`** so it
  stays in sync with `pyproject.toml` automatically. Was hardcoded
  to `"0.1.0"` since v0.1, drifting silently across every release.
- **README install line** drops the `[core]` extra (now redundant);
  recommended dev install becomes `pip install -e ".[mcp,dev]"`.

### Fixed

- **Wheel no longer ships duplicate migration SQL files.** The
  `tool.hatch.build.targets.wheel.force-include` directive was
  redundant with `packages = ["src/gnokee"]` and caused each
  `0001…0008_*.sql` to appear twice in the wheel zip (eight
  `UserWarning: Duplicate name` warnings on every build, ~12 KB
  unnecessary payload). The new pypi-publish workflow has a
  regression guard step that fails CI on any future duplicate.

## [0.2.2] — 2026-05-09

Maintenance bundle closing the three named v0.2.1 footguns plus a CI
hardening pass. Q7 lifts to **11/15 (73.3 %)** via a new typed
`op=abnormal`. Recall now surfaces a `supersession_hints[]` discovery
field instead of either hiding superseded episodes silently or
surfacing their stale narratives unsafely. Storage gains partial
indexes on the open subset of `lab_record` / `med_record` so
supersede UPDATEs scale with the open-subset cardinality, not the
full PK. Net: backwards-compatible — no v0.2.1 contract changes; one
new migration (`0008_supersession_partial_indexes.sql`).

### Added

- **`gnokee_lab_query` `op=abnormal`** (issue #18). Returns visible
  `lab_record` rows whose `abnormal_flag` is set within an optional
  `(since, until]` window. `analyte` is optional for this op so
  callers can ask "which electrolytes were abnormal?" without naming
  every analyte upfront; when supplied, it acts as a narrowing
  filter. Both bi-temporal half-pairs apply identically to the other
  read paths so retroactive corrections honour `as_of` / `valid_at`.
- **`gnokee_recall.supersession_hints[]`** (issue #19, ADR-0009 status
  note). When cosine ranks a superseded episode in the top-K, recall
  now emits a `SupersessionHint(superseded_uuid, current_head_uuid,
  superseded_at)` instead of surfacing the stale narrative. Closes
  the v0.2.1 footgun where row-level data on unrelated analytes
  remained open while episode-level supersession hid the original
  panel from default recall. Decision: Option A+ (clinical-safe —
  stale narrative never surfaces; agent follows up via
  `gnokee_lab_query` / `gnokee_med_query` typed reads, or pins
  `as_of` pre-correction). Hint cap = 5 per recall;
  `RecallResponse.supersession_hints` defaults to empty list
  (backwards compatible).
- **`MetadataStore.chain_head_at(tenant, start_uuid, as_of)`** —
  read-only chain-walk used by retrieval to resolve hints to their
  current head. Bounded depth = 32 (matches `supersede`).

### Changed

- **`gnokee_lab_query.analyte` is now optional** at the typed-pipeline
  surface (`str | None`). It remains required for every op except
  `abnormal`. The validator raises `ValidationError("analyte is
  required")` for any other op when missing.

### Performance

- **Partial indexes on the open subset of `lab_record` / `med_record`**
  (issue #17, migration `0008_supersession_partial_indexes.sql`). New
  `lab_record_open_idx` and `med_record_open_idx` cover only rows
  where `asserted_until IS NULL` so `LabStore.supersede_matching` /
  `MedStore.supersede_matching` walk an index whose size is bounded by
  the open-subset cardinality instead of the full PK. Read paths
  (`latest`, `history`, `aggregate`, `abnormal`) are unaffected by
  design — they need closed-but-tx-time-valid rows for pre-correction
  `as_of` pins. Pure perf win; non-load-bearing for v0.2.1
  correctness (the PK still satisfies the UPDATE if the planner
  prefers it for any reason). Apply with `make migrate`.

### Evals

- Q7 re-spike on the v0.2.2 stack (`spike-q7` tenant,
  `--skip-ingest`) lifts headline pass = **11/15 (73.3 %)** (was
  10/15 / 66.7 % at v0.2.1 ship). `q_electrolyte_abnormal_q2` flips
  PARTIAL → **PASS** via the new typed `abnormal` op. Verdict stays
  ADOPT_WITH_GAPS.
- Q8 re-spike unchanged (16/16 — already at ADOPT ceiling at v0.2.1).

### CI / tooling

- **Dependabot** (PR #26) — weekly Monday updates for `pip` (root
  pyproject), `github-actions`, and `docker` (compose image tags).
  Eval-spike `requirements.txt` files deliberately excluded (frozen-
  in-time records per AGENTS.md spike workflow).
- **`pip-audit` CI job** (PR #26) — scans `pyproject.toml`-declared
  deps against the PyPI advisory DB on every push and PR. Currently
  green ("No known vulnerabilities found").
- **`gitleaks` CI job** (PR #26) — server-side secret-scan backup
  for the local pre-commit hook. Pinned to v8.21.2 to match
  `.pre-commit-config.yaml`.

### Migration

```sh
make migrate   # applies 0008_supersession_partial_indexes.sql
```

No application-code changes required for upgraders.

## [0.2.1] — 2026-05-09

Supersession-aware ingest. The named v0.2.0 follow-up gap closes:
correction episodes now propagate `asserted_until` to prior
`lab_record` + `med_record` rows and to `episode_metadata`. Q7's
`q_k_lowest_2024` flips from FAIL to PASS (typed `min` aggregation
now skips superseded values).

### Added

- **`EpisodeIn.corrects: UUID | None`** boundary signal. When set,
  declares this episode supersedes a prior one. Same-tenant only;
  corrected episode must exist; new `asserted_at` must be greater
  than the corrected episode's. Chain-walk follows `superseded_by`
  to the current head when the caller named a stale target.
- **3 new storage primitives.** `MetadataStore.supersede`
  (validates + walks the chain via `SELECT … FOR UPDATE` per hop;
  depth bound 32 raises `CorrectsChainError`),
  `LabStore.supersede_matching` (per-row `(analyte, valid_at)`
  UPDATE), `MedStore.supersede_matching` (per-row
  `(drug_name, event_kind, valid_at)` UPDATE). All parameterised on
  `tenant_id` + the chain-walk-resolved head's `episode_uuid`.
- **4 new typed errors:** `CorrectsError` (base) +
  `EpisodeNotFoundError`, `CorrectsCrossTenantError`,
  `CorrectsAxisInversionError`, `CorrectsChainError`. All subclass
  `VectorStoreError`, so the existing Stage 6 compensate path rolls
  back the Graphiti episode.
- **Module-level `ingest_episode(...)` helper** gains
  `corrects: UUID | None = None`. Backwards-compatible.
- **Stage 6 wiring.** Supersession runs inside the existing
  single-txn block, between the `metadata.write` insert (which
  guards `_OurIdRaceLost`) and the `vector.write_embedding` insert.
  On row-level partial-key UPDATE (count < `len(keys)`), Stage 6
  logs a `WARNING` — surfaces parser drift on `valid_at` rounding
  rather than a silent zero-match.
- **11-case integration suite** at
  `tests/integration/test_supersession_e2e.py`: lab + med happy
  paths, episode-metadata supersession, aggregation respects
  supersession (Q7's named bug), cross-tenant rejection, episode
  not found, axis inversion, chained correction, empty new rows
  with corrects, idempotent replay, chain-walk from stale target.

### Fixed

- **Q7 `q_k_lowest_2024`** — typed `MIN(value_numeric)` over
  Potassium 2024 now returns 3.2 mmol/L (March, open) instead of
  2.8 mmol/L (April, superseded). Q7 verdict stays ADOPT_WITH_GAPS
  (10/15) — the fix is offset by a designed-correct regression on
  `q_electrolyte_abnormal_q2`: episode-metadata supersession hides
  the original April panel from default `gnokee_recall`, breaking
  a query that expected both the original (Mg LOW) and the
  correction. The agent should query `gnokee_lab_query` typed
  surface for abnormal-flag filtering, or pin `as_of` pre-correction.

### Spike harness

- Q7 + Q8 `ingest_corpus` helpers gain `corrects:` plumbing — read
  an optional `corrects: <our_id>` from corpus entries and resolve
  to the runtime `episode_uuid` via the harness's growing
  `our_id → episode_uuid` map. Corpus entries referencing
  `corrects:` MUST appear after their target in file order.
- Fresh re-spike tenants `spike-q7-v0_2_1` and `spike-q8-v0_2_1c`
  — re-running against the v0.2.0 tenants would short-circuit on
  `our_id` idempotency and skip Stage 6 entirely.
- Q8 extends to 16 queries: new `q_metoprolol_dose_corrected`
  exercises the corrects: signal on med-side via a synthetic
  Metoprolol start (25 mg) + correction (50 mg). Picked an
  orthogonal drug to avoid clashing with existing Lisinopril
  dose-pinned queries. Q8 re-spike: **16/16 (100 %)**, verdict
  stays ADOPT.

### Known limitations

- **Graphiti edge supersession is NOT auto-run.** Narrative
  corrections continue to flow through ADR-0008 contradiction
  surfacing. ADR-0009 boundary holds: graphiti owns prose, gnokee
  owns the typed half. Correcting an episode does not retract its
  edges from the graph.
- **Episode-metadata supersession hides original episodes from
  `gnokee_recall`** even when their unrelated rows (e.g. Mg LOW
  on a panel where only K was corrected) remain row-level open.
  Designed-correct per the bi-temporal model, but biases recall
  away from row-level data on superseded episodes. Workaround: use
  `gnokee_lab_query` / `gnokee_med_query` for typed reads, or pin
  `as_of` pre-correction for narrative recall.
- **Encrypted-body branch is unaffected** — `corrects` is
  metadata, orthogonal to the body shape. Encrypted-body remains
  `NotImplementedYet` per v0.1 guard.

## [0.2.0] — 2026-05-09

Typed clinical-data reads land — first net-new MCP surface since v0.1.
Closes the v0.1.x carry-over from ADR-0009 (Q7 labs OFF-RAMP at 13.3 %)
and ADR-0010 (Q8 meds ADOPT_WITH_GAPS at 53.3 %): structured Postgres
siblings to graphiti's narrative half preserve the numerics the
edge-fact LLM was stripping. Q7 lifts to 66.7 % (ADOPT_WITH_GAPS); Q8
lifts to **100 %** (ADOPT) once `event_kind` is rendered in human
form. Purely additive — no v0.1 contract changes.

### Added

- **`gnokee_lab_query` MCP tool** (ADR-0009) — typed reads against the
  new `lab_record` table. Ops: `latest | history | min | max | avg |
  count` over `(tenant, analyte, date_range)`. Returns parsed
  `value_numeric` / `unit` / `ref_range_*` / `abnormal_flag` plus the
  `episode_uuid` provenance handle. Both bi-temporal half-pairs
  mandatory.
- **`gnokee_med_query` MCP tool** (ADR-0010) — sibling typed reads
  over `med_record`. Ops: `active | history | allergies | switches`.
  `active` returns one row per drug whose latest visible event isn't
  `stop` / `allergy`; pin `valid_at` for historical "active on …".
- **`gnokee.extract.clinical.{lab_parser,med_parser}`** — pure-Python
  deterministic parsers. Lab: bullet-line panel shape (`- Analyte:
  value unit (ref: low-high)`). Med: sentence-boundary med-event
  shapes (`Started X N mg`, `Increased X from N to M mg`,
  `Discontinued X`, `Allergy documented: X`). Never raise; empty
  parse → no rows.
- **Stage 6 ingest writes lab + med rows** — `IngestPipeline.ingest()`
  Stage 6 now writes `lab_record` + `med_record` rows inside the same
  Postgres txn as `episode_metadata` + `content_embedding`, so
  retroactive corrections stay atomic with the narrative episode.
- **`gnokee.{lab_query,med_query}` orchestrators** — sit between the
  MCP layer and the storage adapters; clean tach boundary (mcp does
  not reach into `gnokee.storage.*` directly).
- **Integration tests** — `tests/integration/test_clinical_lab_e2e.py`
  + `tests/integration/test_clinical_med_e2e.py`. 11 tests covering
  ingest writes, all typed-read ops, valid_at-pinned active, tenant
  isolation, against real Postgres + Neo4j + TEI.
- **Re-spike harnesses** — Q7 + Q8 `queries.yaml` gained per-query
  `typed: {tool, op, args}` blocks; spike `run.py` merges typed
  responses into `value_substring` grading. Recall path stays as
  v0.1.1 baseline reference, typed calls are additive.
- **Docs** — new `docs/specs/v0.2.md` captures the additive surface;
  ADR-0009 / ADR-0010 status notes amended with v0.2 headline +
  remaining-gap inventory; README tools-surfaced list expanded.
- **noggin sister repo** — bumped 0.0.1 → 0.0.2 with prompt guidance
  teaching the agent when to reach for the typed clinical tools.

### Known limitations

- **Supersession-aware ingest is incomplete.** A correction episode
  writes a new `lab_record` row but does not set `asserted_until` on
  the prior row — visible `MIN(value_numeric)` therefore still
  includes superseded values. Tracked as v0.2.1 candidate; needs an
  explicit `corrects: episode_uuid` signal from the caller per
  ADR-0009.
- **Q7 5/15 still partial** (cross-domain narrative, count→episode
  backfill, multi-analyte abnormal filter, narrative-only correction
  audit). Documented in ADR-0009 status notes.

## [0.1.2] — 2026-05-09

Cheap-path recall improvements and v0.2 schema groundwork. Q8 (med
supersession) lifts from 53.3 % → 73.3 % (ADOPT_WITH_GAPS) on the same
graph just from recall-side changes. v0.2 implementation follows under
ADR-0009 + ADR-0010.

### Added

- **`med_event` preprocessor rule** (`src/gnokee/extract/rules/med_event.py`)
  — fifth deterministic rule lifting `Started X N mg` / `Increased X
  from N to M mg` / `Discontinued X` / `Allergy documented: X` shapes
  into short SVO derived sentences so graphiti's edge-fact extractor
  preserves the drug-name + dose tuple. ADR-0010 cheap-path piece.
- **Med-aware excerpt path** (`src/gnokee/excerpts.py`) —
  `query_wants_excerpt` now fires on med tokens (`medication / dose /
  allergic / mg / mcg / mEq / drug-class names`); new `find_med_excerpt`
  surfaces verbatim Episodic.content med-event lines as a sibling to
  `find_currency_excerpt`. Body-side finders are English-aware for
  v0.1.x; non-EN bodies fall back to facts and v0.2 typed reads.
- **Date prefix on excerpts** — every `Excerpt.text` is prepended with
  `[YYYY-MM-DD]` from the episode `valid_at`, so date-asking variants
  ("when was the renovation invoice?") can quote the date even when
  the body says "today". Inner `max_chars` adjusts so total stays ≤
  `DEFAULT_EXCERPT_CHARS`.
- **Recency rerank** (stage 3c) — when the query carries a temporal-
  current marker (`currently / now / today / latest / current / active /
  am i on / am i taking`), the cosine top-K is sorted by `valid_at` desc
  before fact fetch, so "what am I currently on?" picks the most recent
  semantically-near episode instead of the highest cosine match.
  English markers only; non-EN time-pin reads land in v0.2 typed
  `med_record` / `lab_record`. Unit-tested via `_query_wants_recency` +
  `_sort_by_recency`.
- **`lab_record` schema** (`migrations/0006_lab_record.sql`) — Postgres
  table per ADR-0009. Stores parsed analyte / value_numeric / unit /
  ref_range / abnormal_flag with bi-temporal half-pairs matching
  `episode_metadata`. ON DELETE CASCADE so tenant forgetting is clean.
  Indexes for time-pin / range / supersession reads.
- **`med_record` schema** (`migrations/0007_med_record.sql`) — sibling
  Postgres table per ADR-0010 with drug_name / drug_class / dose /
  event_kind. Partial indexes for drug-class history (NOT NULL) and
  allergy lookups (`event_kind = 'allergy'`).

### Fixed

- **`bootstrap.py` silent-leak footgun** —
  `build_app(settings)` now refuses to boot when `openai_base_url`
  targets `api.openai.com/v1` AND `openai_api_key` is empty. Previously
  fell back to `api_key="unused"` and 401'd mid-ingest on every
  graphiti extraction call. Self-hosted endpoints (litellm / ollama /
  vllm OpenAI-compat) keep working with no key.
- **Q7 / Q8 spike harness `--skip-ingest`** — both referenced a
  nonexistent `app.metadata._pool`; corrected to `app.pool` so
  re-grading against an existing tenant works without re-ingest cost.

### Validation

- 117 / 117 unit tests green (10 new for retrieval helpers, 11 new for
  med excerpts, 11 new for `med_event`, 5 new for bootstrap pre-flight).
- 22 integration tests against the live compose stack (smoke updated
  for migrations 0006 + 0007).
- Q8 spike re-grade against `spike-q8` tenant: **53.3 % → 73.3 %**
  (`ADOPT_WITH_GAPS`). Q7 spike unchanged at 13.3 % `OFF-RAMP` (typed
  `lab_record` table is the right v0.2 fix, not the cheap path).
- Downstream noggin real-corpus suite: 6 / 7 (one likely-flaky LLM-
  variance test on a query with no recall-path-affecting keywords).

## [0.1.1] — 2026-05-08

Patch release focused on extraction quality on real-corpus shapes that
the v0.1 surface left under-served. Spec gates from v0.1 stay green;
no public-API breakage.

### Added

- **Pre-extraction preprocessor** (`src/gnokee/extract/`) — a deterministic
  pass that augments the body sent to graphiti's edge-fact extractor with
  derived sentences for shapes the LLM tends to drop. Three rules ship:
  `identifier` (numbered references such as ADR-025, Q1, P1.3), `ranked_list`
  (top-of-stack / P-prefix / ordered-list priority), and `table_amount`
  (pipe-table currency rows). Closes #2 / #3 / #4.
- **`currency_anchor` rule** — fourth preprocessor rule covering the two
  non-pipe-table shapes the original `table_amount` rule cannot reach:
  bold list-item totals (`- **Total spent: 14,225.45**`) and bold
  declarative currency lines (`**€14,225 spent through 20.04.2026.**`).
  Pairs the amount with the document's first H1 so derived sentences
  read like `Sofia Apartment: €14,225 spent through 20.04.2026
  (Renovation — actuals).`. Closes #6 (layer 2 piece).
- **`gnokee_recall` body excerpts** — `RecallResponse.excerpts[]` now
  surfaces verbatim `Episodic.content` lines containing currency or
  amount-keyword digits when the query is amount-bearing. Recall reserves
  ~⅓ of `max_tokens` for the excerpt slice so the LLM-summarised fact
  list cannot crowd out the verbatim numerics. Tool description nudges
  the agent to quote excerpts when answering numeric questions.
  Closes #7. New leaf module `gnokee.excerpts` (pure helpers).
- **`Excerpt` model** on the public surface
  (`src/gnokee/models.py`) and serialised by the `gnokee_recall` MCP tool.
- **`GraphitiStore.fetch_episode_contents`** — batch episode-body fetch
  in one Cypher round-trip, used by the recall excerpt stage.
- **`our_id` idempotency** on `EpisodeIn` — re-ingest with the same
  `(tenant_id, our_id)` returns the existing receipt and skips graphiti
  extraction, vector write, and contradiction detection.

### Changed

- **Currency pattern** in both ingest- and recall-side scanners now
  matches the EU-suffix shape (`1,000 €`) in addition to the prefix
  form (`€1,000`).
- **TEI embeddings** — client-side batch chunking + `truncate=true`
  makes the embedder resilient to long inputs without surfacing
  413/max-token errors at ingest time.

### Validation

- 79/79 unit tests green (12 new for excerpts, 13 new for
  `currency_anchor`).
- 21/21 integration tests against the live compose stack.
- Downstream noggin real-corpus suite goes from 4/4 → 7/7 passing
  (the three previously known recall gaps from #2 / #3 / #4 are now
  promoted to tests and pass).

## [0.1.0] — 2026-05-08

Initial release. Spec frozen, gates green.

### Added

- Ingest pipeline (`src/gnokee/ingest.py`): tenant-validated ingress,
  `valid_at` / `asserted_at` half-pair invariants, content-embedding
  via TEI, graphiti `add_episode` extraction, contradiction detection.
- Recall pipeline (`src/gnokee/retrieval.py`): six-stage recall with
  bi-temporal filtering, pgvector rerank, Cypher fact fetch, Q3
  response shaping (~125 median tokens, 67 % win vs graphiti raw).
- Q4 contradiction surface — `unrelated | refinement | update |
  contradiction` 4-label classifier; persisted as symmetric edges in
  Postgres `fact_contradiction`; surfaced on recall, never auto-resolved.
- MCP server (`src/gnokee/mcp.py`): `gnokee_ingest_episode`,
  `gnokee_recall`, `gnokee_fact_provenance`. stdio transport.
- Postgres schema (Alembic migrations): `episode_metadata`,
  `content_embedding` (1024-dim bge-m3, HNSW), `fact_contradiction`,
  RLS gated on `app.current_tenant` GUC.
- Neo4j 5 Community via graphiti-core 0.29; gnokee-managed HNSW
  indexes on `name_embedding` + `fact_embedding`.
- Docker compose for the v0.1 stack (`gnokee-postgres`, `gnokee-neo4j`,
  `gnokee-tei`); arm64 platform pin for TEI on Apple Silicon (Rosetta).
- Eval spikes Q1–Q5 under `evals/` validating the v0.1 architecture.

[0.1.2]: https://github.com/gnokeelabs/gnokee/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/gnokeelabs/gnokee/compare/v0.1...v0.1.1
[0.1.0]: https://github.com/gnokeelabs/gnokee/releases/tag/v0.1
