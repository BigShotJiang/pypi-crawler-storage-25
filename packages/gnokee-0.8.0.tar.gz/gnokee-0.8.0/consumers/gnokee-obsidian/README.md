# gnokee-obsidian

Obsidian vault adapter for [gnokee](https://github.com/gnokeelabs/gnokee).
Walks an Obsidian markdown vault and ingests each `.md` note as one
bi-temporal Episode. The vault remains the user's source of truth; gnokee
never writes back.

Decision record: [ADR-0020](../../docs/adr/0020-obsidian-vault-adapter.md).
Eval verdict: `SHIP_ADAPTER` from
[`evals/spike_q14_obsidian/`](../../evals/spike_q14_obsidian/) — 10/10 pass
both arms, 0 divergences, 0 axis-confusion against direct
`ingest_episode()` calls with identical content + timestamps.

## Install

```bash
pip install -e consumers/gnokee-obsidian
```

You need a gnokee stack running and `GNOKEE_*` environment variables set —
see the top-level [README](../../README.md) and
[`docker-compose.yml`](../../docker-compose.yml).

## Use

```bash
gnokee-obsidian sync /path/to/vault --tenant alice:personal
```

Each `.md` note becomes one Episode. Frontmatter drives the bi-temporal
axes:

```markdown
---
id: 2024-01-15-cardio-followup        # stable our_id (REQUIRED — see § our_id below)
valid_at: 2024-01-15T09:00:00Z        # world-time the note describes
asserted_at: 2024-01-16T10:30:00Z     # optional; defaults to ingest-time
corrects: 7f2b...                     # optional UUID of episode this supersedes
sensitive: clinical                   # public | private | clinical
language: en                          # optional ISO 639-1
tags: [labs, ldl]                     # optional → entity_type_hints
---
Body of the note as plain markdown.
```

## Rules

- **`our_id` is required.** Frontmatter `id:` is preferred; the path-hash
  fallback (`vault-path:<sha256[:16]>`) only fires when `id:` is missing,
  and is unstable across moves/renames. Provide an `id:` for any note you
  care about.
- **`valid_at` is required.** UTC, tz-aware. Falls back to file mtime when
  the frontmatter field is missing.
- **`corrects:` is caller-asserted only** (matches v0.2.1 supersession
  contract). The UUID must reference an already-ingested episode in the
  same tenant. No heuristic detection.
- **Re-walks are mtime-gated** via `.gnokee_sync.json` at the vault root.
  Unchanged mtime → skip. gnokee's own `(tenant_id, our_id)` replay path
  catches duplicates regardless, but the sidecar saves a roundtrip.
- **Dotdirs (`.obsidian`, `.trash`, ...) are skipped.**
- **Tags → `entity_type_hints` is a bias hint, not authoritative.** Q14
  showed the bias neither helps nor hurts rankings.

## Heading-split mode — many Episodes per note

For daily notes / journals / logs that capture multiple events per file,
set `split: heading` in the note frontmatter. Each `## section` becomes
one Episode. Section overrides go in an inline HTML comment directly
under the heading; override pairs are **`;`-separated** (commas inside
fields like `tags` stay intact):

```markdown
---
id: daily-2024-01-15
valid_at: 2024-01-15T00:00:00Z
split: heading
---

## Morning run
<!-- gnokee: valid_at=2024-01-15T07:00:00Z; tags=fitness,run -->
5k easy along the river.

## Cardio follow-up
<!-- gnokee: valid_at=2024-01-15T14:30:00Z; sensitive=clinical -->
Dr Chen flagged LDL drift.

## Bug shipped
Fixed the supersession race in #38.
```

Result: three Episodes with `our_id`s `daily-2024-01-15#morning-run`,
`daily-2024-01-15#cardio-follow-up`, `daily-2024-01-15#bug-shipped`.
Sections without an inline override inherit the note's frontmatter
(`valid_at`, `sensitive`, `tags`, ...). The mtime sidecar gates the
whole note; gnokee's `(tenant_id, our_id)` replay key keeps unchanged
sections idempotent.

Supported override keys: `valid_at`, `asserted_at`, `corrects`,
`sensitive`, `language`, `tags`. A note with `split: heading` but no
`## ` headings silently falls back to single-Episode mode.

## Library API

```python
import asyncio
from pathlib import Path

from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee_obsidian import build_episode_from_note, ingest_vault


async def main() -> None:
    settings = Settings()
    app = await build_app(settings)
    try:
        report = await ingest_vault(
            vault=Path("./my-vault"),
            tenant="alice:personal",
            ingest=app.ingest,
        )
        print(report)  # SyncReport(seen=42, ingested=12, skipped_unchanged=30, errors=0)
    finally:
        await shutdown_app(app)


asyncio.run(main())
```

`build_episode_from_note(path, vault_root, tenant)` returns a Pydantic
`EpisodeIn` (or `None` if the body is empty) — handy for piping into a
custom ingest loop.

## Not in scope (deferred)

- Markdown → plaintext conversion. Bodies go in as-is.
- Wikilink (`[[note]]`) graph resolution. Graphiti owns entity extraction
  from prose; vault structure does not become graph structure.
- Heading-split mode (one Episode per `## section`).
- Encrypted-vault path. Add an `encrypted_body` branch when consumers
  need it; pattern in `examples/04_encrypted_body.py`.
- `--watch` / live-sync mode via fsnotify. v1 ships one-shot `sync`.

## License

Apache-2.0. Same as the parent project.
