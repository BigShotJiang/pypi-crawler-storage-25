"""src/gnokee/retrieval.py — Recall pipeline (spec §5 stages 1–6).

Stages:
  1 embed query                — TEI 1024-dim
  2a Cypher narrow (Neo4j)     — ep.valid_at <= valid_at; ORDER BY ep.uuid; LIMIT pool
  2b pg join                   — episode_metadata bi-temporal half-pairs (asserted + valid_until)
  3a pgvector cosine           — cosine over content_embedding within candidates
  3a BM25                      — tsvector FTS over episode_metadata.content_text (parallel)
  3b RRF fuse                  — Reciprocal Rank Fusion (k=60) over cosine + BM25 ranked lists
  3.5 partition                — visible (→ facts) + closed (→ supersession hints)
  3.6 cosine_floor prune       — drop episodes whose cosine score < cosine_floor (optional)
  4 fact fetch (Cypher batch)  — MENTIONS → RELATES_TO undirected; r.invalid_at half-pair
                                  empty result → ADR-0012 Path A episode-cosine fallback
  5 contradictions             — symmetric UNION over fact_contradiction; valid_at backfill
  6 shape response             — Q3-validated FactStatement list; max_tokens budget
  6d refused signal            — ADR-0022 Option A: set refused=True when facts==[] and
                                  episode_fallback==[]

`gnokee_fact_provenance` lives here too — full episode body fetch.

Episode-body emission (#41 + ADR-0012 Path A) — `_build_episode_body_rows`
surfaces the top-K ranked `Episodic.content` bodies as `EpisodeFact`
rows and flips `RecallResponse.body_used = True`. Two triggers, same
helper: hybrid emission when the fact pipeline succeeds but the query
carries no excerpt signal (LongMemEval-shape conversation literals),
and full-budget fallback when stage 4 returns zero facts. Mutually
exclusive with `excerpts[]` — the currency / med-signal snippet path
already covers Q8 numeric-quote queries with its own 1/3 budget.

#50 — `retrieved_episode_external_ids` exposes the BM25/cosine fused
ranking as `our_id` strings (in `ranked` order, visible episodes only),
giving eval harnesses a ranking-quality signal independent of fact
provenance.

ADR-0012 Q11 fix (issue #46) — BM25 sibling lane added at stage 3a.
RRF constant k=60 matches graphiti's COMBINED_HYBRID_SEARCH_RRF recipe.

#89 (ADR-0019 follow-up) — ``include_cosine_top1`` opt-in flag. When
True, stage 3a also calls ``search_embeddings_with_scores`` to capture
the raw cosine distance per episode; stage 6 converts it to similarity
(``1 - distance``) and populates ``FactStatement.cosine_top1``. Default
False — keeps wire shape stable for non-opt-in consumers. Telemetry only:
no reordering, no threshold enforcement.

ADR-0022 Option A (issue #94) — `cosine_floor: float | None = None` added
to recall(). When set, episodes whose cosine similarity score falls below
the floor are dropped before stage 4. This makes `refused=True` observable
in single-tenant default mode for out-of-domain queries. Default None
preserves current behaviour for callers not opting in. When either
``include_cosine_top1`` or ``cosine_floor`` is set, the scored variant runs
ONCE and the scores feed both paths.

exports: recall | fact_provenance | RecallPipeline
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   tenant_id on every read; both bi-temporal half-pairs mandatory; lazy provenance
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-opus-4-7 | 2026-05-09 | issue #52 top_k_bodies + per_body_char_cap (body-coverage tuning)
         claude-sonnet-4-6 | 2026-05-12 | issue #89 include_cosine_top1 opt-in telemetry
         claude-sonnet-4-6 | 2026-05-12 | issue #94 / ADR-0022 Option A cosine_floor + refused signal
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID

from gnokee.citations import build_recall_citations
from gnokee.config import utc_now
from gnokee.embeddings import TEIClient
from gnokee.errors import GnokeeError, ValidationError
from gnokee.excerpts import find_currency_excerpt, find_med_excerpt, query_wants_excerpt
from gnokee.models import (
    ContradictionRef,
    EncryptedEpisodeBody,
    EpisodeFact,
    Excerpt,
    FactProvenance,
    FactStatement,
    RecallResponse,
    RecallTelemetry,
    SupersessionHint,
)
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.encrypted_body import EncryptedBodyStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.vector import PgVectorStore

log = logging.getLogger(__name__)

DEFAULT_CANDIDATE_POOL = 500
_RRF_K = 60  # matches graphiti COMBINED_HYBRID_SEARCH_RRF constant
DEFAULT_TOP_K = 10
DEFAULT_MAX_TOKENS = 200
DEFAULT_EXCERPT_CHARS = 200
DEFAULT_EXCERPT_MAX_COUNT = 3
DEFAULT_SUPERSESSION_HINT_CAP = 5
# Issue #52 body-coverage tuning. #54 telemetry showed every fired body
# call hit `body_first_row_oversize=True` because a single conversation-
# turn body is ~3700 approx-tokens (~14k chars) against a 66-token
# `body_budget` at the default `max_tokens=200`. Capping each body at
# 600 chars (~150 approx-tokens) lets ~3 bodies fit under a Path A
# 200-token allocation — the always-emit-first guard still fires when
# even one capped body exceeds the budget, so single-body coverage is
# unchanged when char cap binds tightly.
DEFAULT_TOP_K_BODIES = 3
DEFAULT_PER_BODY_CHAR_CAP = 600
_DATE_PREFIX_LEN = len("[YYYY-MM-DD] ")

# Temporal-current intent markers — when present, reorder the cosine
# top-K by ``valid_at`` desc so "what am I currently on" picks the most
# recent semantically-near episode rather than the highest cosine match.
# English-only for now; non-EN handled by v0.2 typed reads (ADR-0010).
_RECENCY_QUERY_PATTERN = re.compile(
    r"\b(currently|now|today|recently|latest|current|active|"
    r"these days|right now|at the moment|am i on|am i taking)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class BudgetSplit:
    """Stage 6 token-budget allocation across the three emission lanes.

    Issue #54 — promoted from inline branches into a pure helper so the
    same shape powers Stage 6 emission and ``RecallTelemetry`` reporting,
    and so the four cases (Path A / wants_excerpt / hybrid / no-signal)
    are unit-testable without standing up the full pipeline.
    """

    fact: int
    excerpt: int
    body: int


def _compute_budget_split(
    max_tokens: int,
    *,
    wants_excerpt: bool,
    wants_body: bool,
    has_facts: bool,
) -> BudgetSplit:
    """Map (max_tokens, signal flags, has_facts) → per-lane budgets.

    Cases (mutex on excerpt vs body, per ADR-0012 §41):

    * ADR-0012 Path A — ``wants_body and not has_facts``: body lane takes
      the full budget. Giving it 1/3 would needlessly truncate when there
      is nothing else to emit.
    * ``wants_excerpt``: excerpt = ``max_tokens // 3``, facts get the
      rest, body OFF. Q8 numeric quoting is already covered by the
      surgical excerpt extractor.
    * Hybrid (``wants_body and has_facts``): body = ``max_tokens // 3``,
      facts get the rest. Body row carries verbatim literals the
      LLM-summarised fact may have stripped.
    * No signal: facts take the full budget. Universal top-1 body emission
      was tried and regressed real-corpus tests by crowding the fact list.
    """
    if wants_body and not has_facts:
        return BudgetSplit(fact=0, excerpt=0, body=max_tokens)
    if wants_excerpt:
        excerpt = max_tokens // 3
        return BudgetSplit(fact=max_tokens - excerpt, excerpt=excerpt, body=0)
    if wants_body:
        body = max_tokens // 3
        return BudgetSplit(fact=max_tokens - body, excerpt=0, body=body)
    return BudgetSplit(fact=max_tokens, excerpt=0, body=0)


@dataclass
class BodyRowsResult:
    """Return type of ``RecallPipeline._build_episode_body_rows``.

    ``tokens_emitted`` and ``first_row_oversize`` exist for issue #54
    telemetry — Stage 6 mirrors them into ``RecallResponse.recall_telemetry``
    so eval harnesses can record actual budget usage instead of inferring
    it from row counts alone.
    """

    rows: list[EpisodeFact]
    truncated: bool
    tokens_emitted: int
    first_row_oversize: bool


@dataclass
class RecallPipeline:
    graph: GraphitiStore
    vector: PgVectorStore
    metadata: MetadataStore
    contradictions: ContradictionStore
    encrypted_body: EncryptedBodyStore
    embeddings: TEIClient

    async def recall(
        self,
        *,
        tenant_id: str,
        text: str,
        as_of: datetime | None = None,
        valid_at: datetime | None = None,
        surface_contradictions: bool = True,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        top_k: int = DEFAULT_TOP_K,
        top_k_bodies: int = DEFAULT_TOP_K_BODIES,
        per_body_char_cap: int = DEFAULT_PER_BODY_CHAR_CAP,
        include_cosine_top1: bool = False,
        cosine_floor: float | None = None,
    ) -> RecallResponse:
        if not tenant_id:
            raise ValidationError("tenant_id required")
        as_of_eff = _ensure_utc(as_of) or utc_now()
        valid_eff = _ensure_utc(valid_at) or utc_now()

        # Stage 1: embed
        q_vec = await self.embeddings.embed_one(text)

        # Stage 2a: Neo4j candidate narrow
        candidates = await self.graph.list_candidate_episodes(
            tenant_id=tenant_id,
            valid_at=valid_eff,
            candidate_pool=DEFAULT_CANDIDATE_POOL,
        )
        candidate_count = len(candidates)
        if not candidates:
            # Stage 6d: no candidates → facts==[] and episode_fallback==[] → refused=True.
            # ADR-0022 Option A: the rule is structural (len checks), not semantic.
            return RecallResponse(
                facts=[],
                truncated=False,
                candidate_count=0,
                recall_telemetry=RecallTelemetry(budget_max_tokens=max_tokens),
                refused=True,
            )

        # Stage 2b: pg bi-temporal join
        candidate_uuids = [c.episode_uuid for c in candidates]
        survivors = await self.metadata.filter_visible(
            tenant_id=tenant_id,
            candidate_uuids=candidate_uuids,
            as_of=as_of_eff,
            valid_at=valid_eff,
        )

        # Stage 3a: pgvector cosine + BM25 — run in parallel over the FULL
        # candidate set (visible + closed) so stage 3.5 can detect
        # closed-but-relevant episodes for supersession-hint surfacing.
        # BM25 uses episode_metadata.content_text (migration 0009); if no
        # rows have content_text set, search_bm25 returns [] and RRF
        # degrades to cosine-only (correct — no crash).
        #
        # Unified scored-variant path. When EITHER include_cosine_top1 (#89
        # telemetry) OR cosine_floor (#94 ADR-0022 Option A prune) is set, run
        # search_embeddings_with_scores once and feed both downstream paths.
        # When neither is set, use the cheaper search_embeddings hot path.
        use_scored = include_cosine_top1 or (cosine_floor is not None)
        bm25_task = self.vector.search_bm25(
            tenant_id=tenant_id,
            episode_uuids=candidate_uuids,
            query_text=text,
            top_k=top_k,
        )
        cosine_score_map: dict[UUID, float] = {}
        if use_scored:
            cosine_scored_task = self.vector.search_embeddings_with_scores(
                tenant_id=tenant_id,
                episode_uuids=candidate_uuids,
                query_vector=q_vec,
                top_k=top_k,
            )
            cosine_scored, bm25_ranked = await asyncio.gather(cosine_scored_task, bm25_task)
            # Convert distance → similarity (1 - distance for cosine_ops).
            # Clamp to [0, 1] to guard against floating-point edge-cases where
            # distance marginally exceeds 1.0 (identical vectors should be
            # distance=0; orthogonal ≈1; opposite ≈2).
            cosine_score_map = {ep_uuid: max(0.0, min(1.0, 1.0 - dist)) for ep_uuid, dist in cosine_scored}
            if cosine_floor is not None:
                # Stage 3.6 — cosine_floor prune: drop episodes below the floor.
                # BM25 ranking is NOT filtered — the floor is cosine-only to
                # avoid suppressing episodes that BM25 found relevant but
                # cosine missed.
                cosine_ranked = [u for u, dist in cosine_scored if cosine_score_map[u] >= cosine_floor]
            else:
                cosine_ranked = [u for u, _dist in cosine_scored]
        else:
            cosine_task = self.vector.search_embeddings(
                tenant_id=tenant_id,
                episode_uuids=candidate_uuids,
                query_vector=q_vec,
                top_k=top_k,
            )
            cosine_ranked, bm25_ranked = await asyncio.gather(cosine_task, bm25_task)

        # Stage 3b: RRF fuse — Reciprocal Rank Fusion (k=60, matches graphiti).
        # RRF score(uuid) = sum over ranked lists of 1 / (k + rank_in_list).
        # Produces top_k uuids by fused score.
        ranked_all = _rrf_fuse(cosine_ranked, bm25_ranked, top_k=top_k)
        if not ranked_all:
            # Stage 6d: RRF produced no results (e.g. cosine_floor pruned all) →
            # facts==[] and episode_fallback==[] → refused=True.
            return RecallResponse(
                facts=[],
                truncated=False,
                candidate_count=candidate_count,
                recall_telemetry=RecallTelemetry(budget_max_tokens=max_tokens),
                refused=True,
            )

        # Stage 3.5: partition into visible (→ facts) + closed (→ hints).
        # Visible-only set is what the rest of the pipeline sees.
        visible_set = set(survivors)
        ranked = [u for u in ranked_all if u in visible_set]
        hidden_top_k = [u for u in ranked_all if u not in visible_set]

        supersession_hints: list[SupersessionHint] = []
        for hidden_uuid in hidden_top_k[:DEFAULT_SUPERSESSION_HINT_CAP]:
            head = await self.metadata.chain_head_at(
                tenant_id=tenant_id,
                start_uuid=hidden_uuid,
                as_of=as_of_eff,
            )
            superseded_meta = await self.metadata.get(
                tenant_id=tenant_id,
                episode_uuid=hidden_uuid,
            )
            if superseded_meta is None or superseded_meta.asserted_until is None:
                # Episode disappeared mid-recall (rare) or never had a
                # supersession close — skip rather than emit a malformed hint.
                continue
            head_uuid = head.episode_uuid if head is not None else hidden_uuid
            supersession_hints.append(
                SupersessionHint(
                    superseded_uuid=hidden_uuid,
                    current_head_uuid=head_uuid,
                    superseded_at=superseded_meta.asserted_until,
                )
            )

        if not ranked:
            # Stage 6d: all ranked episodes were closed/superseded → refused=True.
            return RecallResponse(
                facts=[],
                truncated=False,
                candidate_count=candidate_count,
                supersession_hints=supersession_hints,
                recall_telemetry=RecallTelemetry(budget_max_tokens=max_tokens),
                refused=True,
            )

        # Stage 3b — fetch metadata per ranked episode. Done before stage 4
        # so the optional recency re-sort below has valid_at on hand;
        # FactStatement.asserted_at and the excerpt date-prefix both also
        # read from this map.
        metadata_lookup: dict[UUID, EpisodeMetadataRow] = {}
        for ep_uuid in ranked:
            row = await self.metadata.get(tenant_id=tenant_id, episode_uuid=ep_uuid)
            if row is not None:
                metadata_lookup[ep_uuid] = row

        # Stage 3d — encrypted-body lookup (issue #22). Batch-fetch the
        # ciphertext envelope for any ranked episode that was ingested
        # via the encrypted_body branch. Used downstream to (a) skip
        # plaintext-only lanes (excerpts, episode_fallback) for those
        # episodes and (b) populate ``RecallResponse.encrypted_bodies``
        # so the consumer can decrypt via their KMS using ``key_id``.
        # gnokee NEVER decrypts.
        encrypted_lookup = await self.encrypted_body.fetch_many(
            tenant_id=tenant_id,
            episode_uuids=ranked,
        )

        # Stage 3c — optional recency rerank for "currently / now / what am
        # I on" queries. Sort the cosine top-K by ``valid_at`` desc so the
        # most recent semantically-near episode wins. Cosine has already
        # narrowed the candidate set; recency picks among the survivors.
        if _query_wants_recency(text):
            ranked = _sort_by_recency(ranked, metadata_lookup)

        # Stage 4: fact fetch (single Cypher)
        fact_rows = await self.graph.fetch_facts_for_episodes(
            tenant_id=tenant_id,
            episode_uuids=ranked,
            valid_at=valid_eff,
        )

        # Reorder by ranked-episode order (cosine, or recency-reranked).
        rank_index = {u: i for i, u in enumerate(ranked)}
        fact_rows.sort(key=lambda r: rank_index.get(r.episode_uuid, 1_000_000))

        # Stage 5: contradictions (optional)
        contradiction_map: dict[UUID, list[ContradictionRef]] = {}
        if surface_contradictions:
            counterparts = await self.contradictions.lookup_counterparts(
                tenant_id=tenant_id,
                fact_uuids=[r.fact_uuid for r in fact_rows],
            )
            counterpart_uuids = {c.fact_uuid for cs in counterparts.values() for c in cs}
            valid_at_lookup = await self.graph.fact_valid_at_lookup(
                tenant_id=tenant_id,
                fact_uuids=list(counterpart_uuids),
            )
            for src, cs in counterparts.items():
                refs: list[ContradictionRef] = []
                for c in cs:
                    refs.append(
                        ContradictionRef(
                            fact_uuid=c.fact_uuid,
                            verdict=c.verdict,
                            summary=c.summary,
                            valid_at=valid_at_lookup.get(c.fact_uuid, valid_eff),
                        )
                    )
                contradiction_map[src] = refs

        # Stage 6: shape response under max_tokens budget.
        #
        # Three lanes share ``max_tokens`` — facts, excerpts, body — with
        # body and excerpts mutually exclusive (#41 hybrid emission).
        # Sizing branches on what the query asked for and what stage 4
        # returned:
        #
        # * ``wants_excerpt`` (currency / amount / med-keyword / dose-unit
        #   signal in the query): excerpt lane gets ``max_tokens // 3``,
        #   facts get the rest. Body lane is OFF — Q8 numeric quoting is
        #   already covered by the surgical excerpt extractor.
        # * No excerpt signal, fact_rows non-empty (LongMemEval-shape):
        #   body lane gets ``max_tokens // 3``, facts get the rest. The
        #   body row carries verbatim literals the LLM-summarised fact
        #   may have stripped ("25 postcards", "2 doctor's appointments").
        # * No excerpt signal, fact_rows empty (ADR-0012 Path A):
        #   body lane takes the full ``max_tokens`` — there is nothing
        #   else to emit, so giving it 1/3 would needlessly truncate.
        # * No signal at all, fact_rows non-empty: facts take the full
        #   budget. Universal top-1 body emission was tried and regressed
        #   real-corpus noggin tests (license / name-history) by crowding
        #   the fact list.
        #
        # Q8 drug-name-only date queries still lose the date prefix from
        # the fact-summary path; v0.2 typed ``med_record`` (ADR-0010)
        # handles those via a typed read instead.
        wants_excerpt = query_wants_excerpt(text)
        wants_body = (not wants_excerpt) and bool(ranked)
        budget = _compute_budget_split(
            max_tokens,
            wants_excerpt=wants_excerpt,
            wants_body=wants_body,
            has_facts=bool(fact_rows),
        )
        fact_budget = budget.fact
        excerpt_budget = budget.excerpt
        body_budget = budget.body

        facts: list[FactStatement] = []
        truncated = False
        fact_tokens_emitted = 0
        for r in fact_rows:
            meta = metadata_lookup.get(r.episode_uuid)
            asserted = meta.asserted_at if meta is not None else None
            if asserted is None:
                # An episode that survived stage 2b must have a metadata row.
                # Skip rather than silently substitute as_of_eff (would conflate
                # query tx-time with the source's asserted_at).
                log.warning(
                    "fact %s skipped: episode %s passed filter_visible but no metadata row",
                    r.fact_uuid,
                    r.episode_uuid,
                )
                continue
            stmt = FactStatement(
                text=r.text,
                fact_uuid=r.fact_uuid,
                episode_uuid=r.episode_uuid,
                valid_at=r.valid_at,
                asserted_at=asserted,
                contradicts=contradiction_map.get(r.fact_uuid, []),
                cosine_top1=cosine_score_map.get(r.episode_uuid) if include_cosine_top1 else None,
            )
            estimated = _approx_tokens(stmt.text)
            if fact_tokens_emitted + estimated > fact_budget and facts:
                truncated = True
                break
            fact_tokens_emitted += estimated
            facts.append(stmt)

        # Stage 6b: verbatim body excerpts (gnokee #7 + ADR-0010 cheap path).
        # When the query mentions an amount or a med-history token,
        # ``FactStatement.text`` (LLM-summarised) often drops the digits
        # / drug names / dates. Pull verbatim lines from the surviving
        # episodes' ``Episodic.content`` so the agent can quote them.
        # Excerpts get their own slice of ``max_tokens`` so the fact list
        # cannot crowd them out. Currency hit wins over med-event hit on
        # the same line; either-or per episode. Each excerpt is prefixed
        # with ``[YYYY-MM-DD]`` from the episode ``valid_at`` so date-
        # asking variants ("when was the renovation invoice?") can quote
        # the date the body says "today" about.
        excerpts: list[Excerpt] = []
        excerpt_tokens_emitted = 0
        if wants_excerpt and ranked:
            # Issue #22 — skip encrypted episodes from the excerpt lane;
            # gnokee has no plaintext to extract a currency / med snippet
            # from. They surface via ``encrypted_bodies`` instead.
            excerpt_candidates = [u for u in ranked[:DEFAULT_EXCERPT_MAX_COUNT] if u not in encrypted_lookup]
            episode_contents = await self.graph.fetch_episode_contents(
                tenant_id=tenant_id,
                episode_uuids=excerpt_candidates,
            )
            for ep_uuid in excerpt_candidates:
                content_body = episode_contents.get(ep_uuid)
                if not content_body:
                    continue
                meta = metadata_lookup.get(ep_uuid)
                valid_at_for_ep = meta.valid_at if meta is not None else None
                inner_max = (
                    max(0, DEFAULT_EXCERPT_CHARS - _DATE_PREFIX_LEN) if valid_at_for_ep else DEFAULT_EXCERPT_CHARS
                )
                excerpt_text = find_currency_excerpt(content_body, max_chars=inner_max)
                if not excerpt_text:
                    excerpt_text = find_med_excerpt(content_body, max_chars=inner_max)
                if not excerpt_text:
                    continue
                excerpt_text = _format_excerpt_with_date(excerpt_text, valid_at_for_ep)
                cost = _approx_tokens(excerpt_text)
                # Always emit at least one excerpt when found; cap subsequent
                # ones at the reserved excerpt budget.
                if excerpts and excerpt_tokens_emitted + cost > excerpt_budget:
                    truncated = True
                    break
                excerpt_tokens_emitted += cost
                excerpts.append(Excerpt(episode_uuid=ep_uuid, text=excerpt_text))

        # Stage 6c: episode-body rows (#41 hybrid emission + ADR-0012 Path A).
        # Mutually exclusive with excerpts; budget is sized in Stage 6's
        # ``wants_body`` branch. When ``fact_rows`` was empty, body takes
        # the full budget (Path A). The helper preserves the cosine /
        # recency rank order of ``ranked`` and never produces a zero-row
        # body lane (first row always emits even if alone it exceeds the
        # budget — the consumer's synthesiser would otherwise have nothing).
        episode_fallback: list[EpisodeFact] = []
        body_truncated = False
        body_tokens_emitted = 0
        body_first_row_oversize = False
        if wants_body and body_budget > 0:
            # Issue #22 — body lane never carries plaintext for encrypted
            # episodes (gnokee has no DEK). Drop them before the lane
            # builder runs; consumer reads them from ``encrypted_bodies``
            # and decrypts via their KMS.
            body_ranked = [u for u in ranked if u not in encrypted_lookup]
            body_result = await self._build_episode_body_rows(
                tenant_id=tenant_id,
                ranked=body_ranked,
                metadata_lookup=metadata_lookup,
                max_tokens=body_budget,
                top_k_bodies=top_k_bodies,
                per_body_char_cap=per_body_char_cap,
            )
            episode_fallback = body_result.rows
            body_truncated = body_result.truncated
            body_tokens_emitted = body_result.tokens_emitted
            body_first_row_oversize = body_result.first_row_oversize
        body_used = bool(episode_fallback)
        truncated = truncated or body_truncated

        retrieved_episode_external_ids = _ranked_external_ids(ranked, metadata_lookup)

        recall_telemetry = RecallTelemetry(
            budget_max_tokens=max_tokens,
            fact_budget=fact_budget,
            excerpt_budget=excerpt_budget,
            body_budget=body_budget,
            fact_tokens_emitted=fact_tokens_emitted,
            excerpt_tokens_emitted=excerpt_tokens_emitted,
            body_tokens_emitted=body_tokens_emitted,
            fact_count=len(facts),
            excerpt_count=len(excerpts),
            body_count=len(episode_fallback),
            body_first_row_oversize=body_first_row_oversize,
        )

        # Issue #22 — surface ciphertext for any ranked encrypted episode
        # in fused-rank order so the consumer's session-side code can
        # decrypt them via their KMS using ``key_id``. gnokee NEVER
        # decrypts; this list never carries plaintext.
        encrypted_bodies = [
            EncryptedEpisodeBody(
                episode_uuid=enc_row.episode_uuid,
                ciphertext=enc_row.ciphertext,
                nonce=enc_row.nonce,
                key_id=enc_row.key_id,
            )
            for ep_uuid in ranked
            if (enc_row := encrypted_lookup.get(ep_uuid)) is not None
        ]

        # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
        # Built from the in-flight metadata_lookup so the host LLM has a
        # `[cN]` back-reference for every claim it might emit. `valid_at`
        # / `asserted_at` carry the two bi-temporal axes; `extracted_quote`
        # is `None` everywhere in v0.5 (extraction stage does not yet
        # record per-fact body spans — backfill in a follow-up issue).
        extracted_quotes: dict[UUID, str | None] = {
            ep_uuid: row.extracted_quote for ep_uuid, row in metadata_lookup.items()
        }
        excerpt_metadata: dict[UUID, tuple[datetime, datetime]] = {
            ep_uuid: (row.valid_at, row.asserted_at) for ep_uuid, row in metadata_lookup.items()
        }
        citations = build_recall_citations(
            facts=facts,
            excerpts=excerpts,
            episode_fallback=episode_fallback,
            extracted_quotes=extracted_quotes,
            excerpt_metadata=excerpt_metadata,
        )

        # Stage 6d: ADR-0022 Option A — refused signal.
        # True when the retrieval pipeline produced zero facts AND zero
        # episode_fallback rows. Never auto-resolves; never suppresses
        # contradiction facts. The flag is most meaningful when cosine_floor
        # is set — without a floor gnokee almost always returns something.
        refused = len(facts) == 0 and len(episode_fallback) == 0

        return RecallResponse(
            facts=facts,
            truncated=truncated,
            candidate_count=candidate_count,
            excerpts=excerpts,
            supersession_hints=supersession_hints,
            episode_fallback=episode_fallback,
            body_used=body_used,
            retrieved_episode_external_ids=retrieved_episode_external_ids,
            recall_telemetry=recall_telemetry,
            encrypted_bodies=encrypted_bodies,
            citations=citations,
            refused=refused,
        )

    async def _build_episode_body_rows(
        self,
        *,
        tenant_id: str,
        ranked: list[UUID],
        metadata_lookup: dict[UUID, EpisodeMetadataRow],
        max_tokens: int,
        top_k_bodies: int = DEFAULT_TOP_K_BODIES,
        per_body_char_cap: int = DEFAULT_PER_BODY_CHAR_CAP,
    ) -> BodyRowsResult:
        """Build ``EpisodeFact`` rows for the top-K ranked episodes.

        Used by both #41 hybrid emission and the ADR-0012 Path A empty-fact
        fallback — caller decides which branch is active and sets the
        budget accordingly. Fetches each ranked episode's
        ``Episodic.content`` in a single batch and emits it verbatim,
        capped by ``max_tokens`` (same approx-token budget the fact loop
        uses). The first row is always emitted even if it exceeds the
        budget so a long episode does not produce a zero-row body lane.
        Cosine / recency-rerank order is preserved.

        Issue #52 body-coverage tuning. Each body is truncated to
        ``per_body_char_cap`` characters before token accounting + emission
        so a single ~14k-char conversation turn no longer monopolises the
        lane. Loop stops after emitting ``top_k_bodies`` rows so the lane
        spreads cosine-relevance across multiple ranked episodes.
        ``first_row_oversize`` still trips when even the (capped) first
        body exceeds ``max_tokens`` — the always-emit-first guard semantics
        are preserved.

        Returns a ``BodyRowsResult`` with ``rows``, ``truncated``,
        ``tokens_emitted`` (sum of ``_approx_tokens`` over emitted rows,
        for telemetry / issue #54), and ``first_row_oversize`` (True iff
        the always-emit-first guard fired). Caller assembles
        ``RecallResponse`` and decides what ``body_used`` means in context.
        """
        contents = await self.graph.fetch_episode_contents(
            tenant_id=tenant_id,
            episode_uuids=ranked,
        )
        rows: list[EpisodeFact] = []
        truncated = False
        running_tokens = 0
        first_row_oversize = False
        for ep_uuid in ranked:
            if len(rows) >= top_k_bodies:
                # Loop bound: ranked is top_k from earlier RRF; body lane
                # caps at top_k_bodies independently so the lane never
                # crowds out coverage of ranks beyond the first body.
                truncated = True
                break
            body = contents.get(ep_uuid)
            if not body:
                continue
            meta = metadata_lookup.get(ep_uuid)
            if meta is None:
                # Episode passed filter_visible but its metadata row
                # vanished mid-recall — skip rather than substitute
                # query tx-time for asserted_at (would conflate axes).
                log.warning(
                    "body row skipped episode %s: no metadata row after filter_visible",
                    ep_uuid,
                )
                continue
            text = body if len(body) <= per_body_char_cap else body[:per_body_char_cap]
            cost = _approx_tokens(text)
            if running_tokens + cost > max_tokens and rows:
                truncated = True
                break
            if not rows and cost > max_tokens:
                first_row_oversize = True
            running_tokens += cost
            rows.append(
                EpisodeFact(
                    episode_uuid=ep_uuid,
                    text=text,
                    valid_at=meta.valid_at,
                    asserted_at=meta.asserted_at,
                )
            )
        return BodyRowsResult(
            rows=rows,
            truncated=truncated,
            tokens_emitted=running_tokens,
            first_row_oversize=first_row_oversize,
        )

    async def fact_provenance(
        self,
        *,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> FactProvenance | None:
        prov = await self.graph.fetch_provenance(tenant_id=tenant_id, fact_uuid=fact_uuid)
        if prov is None:
            return None
        meta = await self.metadata.get(tenant_id=tenant_id, episode_uuid=prov.episode_uuid)
        if meta is None:
            return None
        # Issue #22 — when the episode was ingested via the encrypted_body
        # branch, surface the ciphertext envelope and force the plaintext
        # ``episode_content`` to "" so the consumer never sees garbled or
        # placeholder text. They decrypt via their KMS using ``key_id``.
        encrypted_row = await self.encrypted_body.get(
            tenant_id=tenant_id,
            episode_uuid=prov.episode_uuid,
        )
        encrypted_body: EncryptedEpisodeBody | None = None
        episode_content_visible = prov.episode_content
        if encrypted_row is not None:
            encrypted_body = EncryptedEpisodeBody(
                episode_uuid=encrypted_row.episode_uuid,
                ciphertext=encrypted_row.ciphertext,
                nonce=encrypted_row.nonce,
                key_id=encrypted_row.key_id,
            )
            episode_content_visible = ""
        return FactProvenance(
            fact_uuid=prov.fact_uuid,
            fact_text=prov.fact_text,
            episode_uuid=prov.episode_uuid,
            episode_content=episode_content_visible,
            valid_at=meta.valid_at,
            valid_until=meta.valid_until,
            asserted_at=meta.asserted_at,
            asserted_until=meta.asserted_until,
            language=meta.language,
            sensitive=meta.sensitive,
            encrypted_body=encrypted_body,
        )


def _approx_tokens(text: str) -> int:
    """Rough token estimate. ~4 chars/token English; conservative."""
    return max(1, len(text) // 4)


def _ranked_external_ids(
    ranked: list[UUID],
    metadata_lookup: dict[UUID, EpisodeMetadataRow],
) -> list[str]:
    """Map ``ranked`` UUIDs → consumer ``our_id`` strings (issue #50).

    Preserves rank order. Skips episodes whose metadata row is missing
    (rare; only when an episode passed filter_visible but the row
    vanished mid-recall) and episodes ingested without an ``our_id``
    (consumer didn't supply a stable external key).
    """
    ids: list[str] = []
    for ep_uuid in ranked:
        meta = metadata_lookup.get(ep_uuid)
        if meta is None or meta.our_id is None:
            continue
        ids.append(meta.our_id)
    return ids


def _query_wants_recency(query: str) -> bool:
    """True when the query asks about the current / latest state.

    Triggers a stage-3c recency rerank so the cosine top-K is sorted by
    ``valid_at`` desc, pushing the most recent semantically-near episode
    to the front. English markers only for now — non-EN time-pin
    reads land in v0.2 typed `med_record` (ADR-0010) and `lab_record`
    (ADR-0009).
    """
    if not query:
        return False
    return bool(_RECENCY_QUERY_PATTERN.search(query))


def _sort_by_recency(
    ranked: list[UUID],
    metadata_lookup: dict[UUID, EpisodeMetadataRow],
) -> list[UUID]:
    """Sort ``ranked`` by episode ``valid_at`` desc; episodes without
    metadata go last (preserved relative cosine order at the tail).
    """
    sentinel_min = datetime.min.replace(tzinfo=timezone.utc)

    def key(u: UUID) -> datetime:
        meta = metadata_lookup.get(u)
        return meta.valid_at if meta is not None else sentinel_min

    return sorted(ranked, key=key, reverse=True)


def _format_excerpt_with_date(text: str, valid_at: datetime | None) -> str:
    """Prepend ``[YYYY-MM-DD]`` from episode ``valid_at`` to an excerpt.

    Date queries ("when did I start X?") fail when the body says "today"
    — the date lives only in the bi-temporal ``valid_at`` column. The
    prefix surfaces it on the verbatim recall response so an agent can
    quote "[2024-02-01]" alongside "Started Lisinopril 10 mg ...".

    No-op when ``valid_at`` is ``None`` (e.g. pre-migration episode).
    """
    if valid_at is None:
        return text
    return f"[{valid_at.date().isoformat()}] {text}"


def _rrf_fuse(
    cosine_ranked: list[UUID],
    bm25_ranked: list[UUID],
    *,
    top_k: int,
    k: int = _RRF_K,
) -> list[UUID]:
    """Reciprocal Rank Fusion over two ranked uuid lists.

    score(uuid) = sum over each ranked list of  1 / (k + rank_1based)
    where rank is 1-based position in the list (rank 1 = best).

    A uuid present in only one list receives a score from that list only;
    the missing-list contribution is 0.  This means:
    - BM25-only hit: gets 1/(k+rank) from BM25, no cosine term.
    - Cosine-only hit: gets 1/(k+rank) from cosine, no BM25 term.
    - Both lists: full sum, double contribution.

    Returns the top_k uuids ordered by fused score descending.
    """
    scores: dict[UUID, float] = {}
    for rank, uuid in enumerate(cosine_ranked, 1):
        scores[uuid] = scores.get(uuid, 0.0) + 1.0 / (k + rank)
    for rank, uuid in enumerate(bm25_ranked, 1):
        scores[uuid] = scores.get(uuid, 0.0) + 1.0 / (k + rank)
    # Sort descending by fused score; stable tie-break preserves cosine order
    # (cosine was populated first, so equal-score ties favour cosine rank).
    ordered = sorted(scores.keys(), key=lambda u: scores[u], reverse=True)
    return ordered[:top_k]


def _ensure_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        raise ValidationError("recall datetimes must be tz-aware UTC")
    return value


# Public coroutine wrappers — `pipeline` is the construction site.
async def recall(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    text: str,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    surface_contradictions: bool = True,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    top_k: int = DEFAULT_TOP_K,
    top_k_bodies: int = DEFAULT_TOP_K_BODIES,
    per_body_char_cap: int = DEFAULT_PER_BODY_CHAR_CAP,
    include_cosine_top1: bool = False,
    cosine_floor: float | None = None,
) -> RecallResponse:
    try:
        return await pipeline.recall(
            tenant_id=tenant_id,
            text=text,
            as_of=as_of,
            valid_at=valid_at,
            surface_contradictions=surface_contradictions,
            max_tokens=max_tokens,
            top_k=top_k,
            top_k_bodies=top_k_bodies,
            per_body_char_cap=per_body_char_cap,
            include_cosine_top1=include_cosine_top1,
            cosine_floor=cosine_floor,
        )
    except GnokeeError:
        raise


async def fact_provenance(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    fact_uuid: UUID,
) -> FactProvenance | None:
    return await pipeline.fact_provenance(tenant_id=tenant_id, fact_uuid=fact_uuid)


fact_provenance.__module__ = __name__
recall.__module__ = __name__


__all__ = ["RecallPipeline", "_rrf_fuse", "fact_provenance", "recall"]
