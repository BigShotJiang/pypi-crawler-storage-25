"""src/gnokee/ingest.py — Episode ingest pipeline (spec §4 stages 1–8).

Stages:
  1 validate    — Pydantic on EpisodeIn; content xor encrypted_body; reject naive datetimes
  2 lang detect — langdetect when None
  3 embed       — TEI 1024-dim (skipped when encrypted_body without content_for_embedding)
  4 graphiti    — add_episode, group_id=tenant_id, reference_time=valid_at
                  [SKIPPED when extract=False OR encrypted_body branch]
  5 resolve     — asserted_at default = now(UTC) at API boundary
  6 pg writes   — episode_metadata + content_embedding (when embedded) + clinical rows
                  + episode_body_encrypted (when encrypted_body branch) in one txn
  7 contradict  — Q4 pipeline writes fact_contradiction; degraded-tolerant
                  [SKIPPED when extract=False — lite mode]
  8 receipt     — IngestReceipt(episode_uuid, asserted_at, created_fact_uuids, contradicts)
                  [extraction_deferred=True when extract=False]

Encrypted-body branch (issue #22, hardened in #132):
  When EpisodeIn.encrypted_body is set (and content is None per Stage 1
  xor), gnokee NEVER holds key material and NEVER decrypts. Stage 4
  (Graphiti add_episode) is skipped — the LLM extractor needs plaintext
  the consumer didn't share. Stage 3 (embed) runs ONLY if the consumer
  supplied EncryptedBody.content_for_embedding (an opt-in plaintext
  window for the cosine lane). The plaintext bytes leave the process
  only over the TEI socket; **once embed() returns, the plaintext is
  dropped from local scope before any persistence step touches it.**
  Specifically: Stage 4 (lite Episodic) writes content="" and
  name="[encrypted episode]" — NOT a substring of the embed window; the
  source_description column reads "gnokee.ingest.encrypted" so audits
  can identify the branch. Stage 6 clinical parsers (parse_labs /
  parse_meds) are skipped — no lab_record / med_record derivatives land
  on the encrypted branch (#132 closed the leak where they did in
  v0.6.0). Stage 6 writes the ciphertext to episode_body_encrypted
  (sibling table, FK to episode_metadata). content_text stays NULL so
  BM25 degrades to cosine-only RRF (or to graph + lab/med structured
  stores when no embedding window was given).
  Receipt carries created_fact_uuids=[] and extraction_deferred=False
  (extraction is not "deferred" — it is permanently off-limits without
  the DEK; consumers can re-ingest plaintext later if they decide to
  share it).

Lite mode (extract=False):
  Skips Graphiti's LLM extractor (no entities, no MENTIONS, no RELATES_TO,
  no contradiction stage). A MINIMAL Episodic node IS still written to
  Neo4j (issue #56) so recall Stage 2a can locate the episode — without
  it every recall short-circuited to an empty RecallResponse.
  All Postgres writes (episode_metadata, content_embedding, lab_record,
  med_record) still run. episode_uuid is gnokee-generated (uuid4) instead of
  coming from Graphiti. Use for high-cadence telemetry where LLM-extraction
  latency is unacceptable. Receipt carries extraction_deferred=True.
  Deferred extraction can be run later via gnokee.maintenance
  (see issue #16 item 1).

Stage 6 also runs the deterministic clinical parsers (ADR-0009 lab_record,
ADR-0010 med_record) inside the same transaction so retroactive corrections
land atomically with the narrative episode. Parsers are pure / never raise;
empty parse = empty rows = no insert.

Cross-store atomicity (full mode):
  step 4 first, step 6 second; on step 6 failure → Graphiti.remove_episode

Cross-store atomicity (lite mode, issue #56):
  Lite mode writes a MINIMAL Episodic node (no entities / edges) to
  Neo4j BEFORE Stage 6, so recall Stage 2a (`list_candidate_episodes`)
  can find the episode. On Stage 6 Postgres failure we compensate by
  removing the Episodic node — same shape as full mode.

exports: ingest_episode | IngestPipeline
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   tenant_id mandatory; UTC-aware datetimes; idempotency on (tenant_id, episode_uuid)
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009/0010
         claude-sonnet-4-6 | 2026-05-09 | issue #16 item 1 lite mode
         claude-sonnet-4-6 | 2026-05-09 | issue #46 wire write_content_text into Stage 6
         claude-opus-4-7 | 2026-05-09 | issue #56 lite-mode minimal Episodic write
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol
from uuid import UUID, uuid4

import asyncpg
import langdetect
from pydantic import ValidationError as PydanticValidationError

from gnokee.config import utc_now
from gnokee.contradiction import detect_for_facts
from gnokee.embeddings import TEIClient
from gnokee.errors import (
    EmbeddingsUnavailable,
    GnokeeError,
    GraphStoreError,
    ValidationError,
    VectorStoreError,
)
from gnokee.extract import augment_for_extraction
from gnokee.extract.clinical import LabRow, MedRow, parse_labs, parse_meds
from gnokee.ingest_retry import _retry_enhancement
from gnokee.llm import OpenAIClient
from gnokee.models import ContradictionRef, EncryptedBody, EpisodeIn, IngestReceipt, IngestTelemetry, Sensitivity
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.encrypted_body import EncryptedBodyRow, EncryptedBodyStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.journal import IngestJournal, IngestJournalError, ResumableEntry, payload_hash
from gnokee.storage.lab import LabRecordRow, LabStore
from gnokee.storage.med import MedRecordRow, MedStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.vector import PgVectorStore

log = logging.getLogger(__name__)


class _OrphanEdgeWarningCounter(logging.Handler):
    """Counts WARNING records emitted by graphiti's edge-extraction logger
    during a single ``add_episode`` call.

    Z3 (#111) — surfaces the per-call orphan-edge warning count on the
    ``IngestReceipt.ingest_telemetry.orphan_edge_warnings`` field so
    callers (spike harnesses, observability layers) can detect the Q18
    silent-drop class without scraping logs. Attached for the lifetime
    of the Stage 4 call only; never installed on the root logger.
    """

    def __init__(self) -> None:
        super().__init__(level=logging.WARNING)
        self.count = 0

    def emit(self, record: logging.LogRecord) -> None:
        # Match the warning shape graphiti_core emits:
        #   "Target entity not found in nodes for edge relation: X"
        #   "Source entity not found in nodes for edge relation: Y"
        #   "Error parsing valid_at date, skipping"
        # All are WARNING level on the edge-extraction logger; level
        # already filters at construction so any record reaching us
        # counts.
        self.count += 1


class _ContradictionStageProto(Protocol):
    async def run(
        self,
        *,
        tenant_id: str,
        new_facts: list[tuple[UUID, str, datetime, list[float]]],
        detected_at: datetime,
    ) -> list[ContradictionRef]: ...


@dataclass
class IngestPipeline:
    """Bundles real-store dependencies. One instance per process."""

    pool: asyncpg.Pool
    graph: GraphitiStore
    vector: PgVectorStore
    metadata: MetadataStore
    contradictions: ContradictionStore
    lab: LabStore
    med: MedStore
    encrypted_body: EncryptedBodyStore
    embeddings: TEIClient
    journal: IngestJournal
    llm: OpenAIClient | None = None
    contradiction_enabled: bool = True
    # v0.6 Z4 (#111) — bounds parallel graphiti.add_episode calls within this
    # process to avoid TPM cascades at higher OpenAI tiers. Default 2 mirrors
    # the Q18 spike configuration that exposed the silent-drop class.
    extraction_concurrency: int = 2
    _enhancement_semaphore: asyncio.Semaphore = field(init=False, repr=False)
    # ADR-0024 / #122 — tenants whose resumable scan has already fired this
    # process. Scan runs once per tenant per pipeline lifetime; result is
    # logged as ResumableIngest warnings, never auto-replayed.
    _warned_tenants: set[str] = field(init=False, default_factory=set, repr=False)

    def __post_init__(self) -> None:
        # Z4 (#111) — bounds parallel graphiti.add_episode calls within this
        # process to avoid TPM cascades at higher OpenAI tiers.
        self._enhancement_semaphore = asyncio.Semaphore(self.extraction_concurrency)

    async def _warn_resumable_once(self, tenant_id: str) -> None:
        """Emit ResumableIngest warnings for ``tenant_id`` on first ingest.

        ADR-0024: gnokee never auto-replays. Operators / consumers
        decide whether to call ``maintenance.resume_ingest`` for each
        surfaced episode.
        """
        if tenant_id in self._warned_tenants:
            return
        self._warned_tenants.add(tenant_id)
        for entry in await self.journal.scan_resumable(tenant_id):
            log.warning(
                "ResumableIngest: tenant=%s episode_uuid=%s our_id=%s "
                "stage_4_time=%s begin_at=%s — call maintenance.resume_ingest()",
                entry.tenant_id,
                entry.episode_uuid,
                entry.our_id,
                entry.stage_4_time,
                entry.created_at,
            )

    async def ingest(
        self,
        episode: EpisodeIn,
        *,
        extract: bool = True,
        _resume: ResumableEntry | None = None,
    ) -> IngestReceipt:
        """Run the ingest pipeline for one episode (v0.6 Z1-B storage-first).

        Stage order (ADR-0023):
          1   validate (xor enforced by ``EpisodeIn.model_validator``)
          1b  idempotency SELECT on (tenant_id, our_id)
          2   language detect (``langdetect``)
          3   embed (TEI 1024-dim)
          3.5 gnokee generates ``episode_uuid = uuid4()``
          4   ``GraphitiStore.write_lite_episode`` → Episodic node.
              Full-mode writes ``content = augment_for_extraction(content)``
              (so the Stage 6 graphiti extraction reads the augmented body
              from the loaded node — see ADR-0023 / Z1.6 spike); lite mode
              writes raw content; encrypted writes empty string.
          5   Postgres txn: episode_metadata + content_embedding +
              content_text + encrypted_body + lab/med supersession.
          6   ``graphiti.add_episode(uuid=X)`` — best-effort enhancement;
              wrapped in Z4 semaphore + ``_retry_enhancement``.
              On retry-exhaustion OR non-retryable raise: lite-fallback
              engages, ``extraction_deferred`` flips True, pipeline does
              NOT raise.
          6b  ``overwrite_episode_content(content=original)`` — restores
              ``Episodic.content`` to non-augmented form, only when
              extract succeeded AND augmented != original.
          7   contradiction detection (only when Stage 6 produced edges).
          8   receipt.

        Atomicity:
          Stage 4 lite Episodic + Stage 5 pg row land BEFORE Stage 6's
          best-effort LLM call. Stage 5 failure compensates by removing
          the lite Episodic (via ``remove_lite_episode`` — raw Cypher to
          avoid graphiti's load-by-uuid lookup that may miss MERGE-only
          writes). Stage 6 failure does NOT compensate: episode survives
          in lite shape with ``extraction_deferred=True`` so
          ``maintenance.run_deferred_extraction`` rehydrates it later.

        Args:
            episode: Validated EpisodeIn. Either ``content`` or
                ``encrypted_body`` set (xor). When ``encrypted_body`` is
                set, gnokee NEVER decrypts; Stage 6 is force-disabled.
            extract: When True (default), runs Stage 6 graphiti
                enhancement + Stage 7 contradiction. When False (lite
                mode), Stage 6/7 skipped; receipt carries
                ``extraction_deferred=True``. Ignored on the
                encrypted_body branch (always forced False).
            _resume: ADR-0024 / #122 internal kwarg used by
                :func:`gnokee.maintenance.resume_ingest`. When set,
                pins ``episode_uuid`` + ``stage_4_time`` to the
                journaled ``begin`` row, skips the resumable scan
                warning, skips ``write_begin`` (one exists), validates
                the consumer-supplied EpisodeIn's payload hash against
                the journal, and force-disables Stage 6 (resume only
                covers Stage 4 + Stage 5; Stage 6 stays the domain of
                ``run_deferred_extraction``).

        Raises:
            ValidationError: ``EpisodeIn`` boundary validation
                (mandatory ``tenant_id``, ``content`` xor
                ``encrypted_body``, tz-aware datetimes) is enforced
                upstream by Pydantic; bad shapes surface as
                ``ValidationError`` when consumers go through
                ``ingest_episode``.
            VectorStoreError: Stage 5 Postgres txn failure (idempotency
                race vanished, asyncpg error, etc.). Existing
                compensation removes the Stage 4 lite-Episodic and the
                journal records a ``fail`` row before re-raise.
            GraphStoreError: Stage 4 lite-Episodic write failed.
            IngestJournalError: On the resume path only — payload-hash
                drift between the consumer-supplied ``EpisodeIn`` and
                the journaled ``begin`` row.
            EmbeddingsUnavailable: TEI client could not produce a
                vector for plaintext content.
        """
        # ── Stage 1: validate (xor enforced by EpisodeIn.model_validator).
        encrypted_body: EncryptedBody | None = episode.encrypted_body
        is_encrypted = encrypted_body is not None
        if is_encrypted:
            assert encrypted_body is not None
            content = encrypted_body.content_for_embedding
            extract = False  # Stage 6 perma-off on the encrypted branch
        else:
            assert episode.content is not None  # xor invariant
            content = episode.content

        # ── Stage 1b: idempotency short-circuit.
        # ADR-0024 / #122 — skip when resuming. A resume may target an
        # episode whose Stage 5 metadata row already landed (crash was
        # between Stage 5 commit and journal write_commit); Stage 1b
        # would return replayed=True here without closing the journal
        # 'begin' row, leaving scan_resumable surfacing it forever. The
        # resume's own write_commit (downstream of Stage 5 idempotent
        # inserts) closes the journal correctly.
        if episode.our_id is not None and _resume is None:
            existing = await self.metadata.get_by_our_id(
                tenant_id=episode.tenant_id,
                our_id=episode.our_id,
            )
            if existing is not None:
                return IngestReceipt(
                    episode_uuid=existing.episode_uuid,
                    asserted_at=existing.asserted_at,
                    created_fact_uuids=[],
                    contradicts=[],
                    replayed=True,
                )

        # ── Stage 2: classify language.
        language = episode.language
        if language is None and content is not None:
            try:
                language = langdetect.detect(content)
            except langdetect.LangDetectException:
                language = "en"
        if language is not None and len(language) > 2:
            language = language[:2]

        # ── Stage 3: embed.
        vector: list[float] | None = None
        if content is not None:
            try:
                vector = await self.embeddings.embed_one(content)
            except EmbeddingsUnavailable:
                raise

        # Issue #132 — defense-in-depth: drop the encrypted-body embed
        # window from local scope as soon as Stage 3 returns. Downstream
        # code (Stage 4 Episodic.content, Stage 6 parse_labs / parse_meds,
        # journal write_commit body-snapshot) MUST NOT see plaintext from
        # the opt-in embed window. `vector` carries the only allowed
        # at-rest derivative.
        if is_encrypted:
            content = None

        # ── Stage 3.5: gnokee owns episode_uuid (Z1-B uniform contract).
        if _resume is not None:
            # ADR-0024 resume path — pin journaled identifiers, refuse
            # if the consumer-supplied EpisodeIn drifted from the
            # journaled 'begin' row.
            expected_hash = payload_hash(episode.tenant_id, episode.our_id, episode.valid_at)
            if expected_hash != _resume.payload_hash:
                raise IngestJournalError(
                    f"resume_ingest: payload_hash mismatch "
                    f"tenant={episode.tenant_id} episode_uuid={_resume.episode_uuid}: "
                    f"consumer-supplied EpisodeIn does not match the journaled 'begin' row"
                )
            episode_uuid = _resume.episode_uuid
            stage_4_time = _resume.stage_4_time
            journal_begin = _resume
            extract = False  # resume only covers Stage 4 + Stage 5
        else:
            episode_uuid = uuid4()
            stage_4_time = utc_now()
            # ADR-0024 / #122 — surface resumable journal rows for this tenant
            # (first ingest per tenant per process), then write 'begin'.
            await self._warn_resumable_once(episode.tenant_id)
            journal_begin = await self.journal.write_begin(
                tenant_id=episode.tenant_id,
                our_id=episode.our_id,
                episode_uuid=episode_uuid,
                payload_hash=payload_hash(episode.tenant_id, episode.our_id, episode.valid_at),
                stage_4_time=stage_4_time,
            )

        # ── Stage 4: write lite Episodic FIRST.
        # Full mode writes augmented content so Stage 6 extraction sees
        # it; Stage 6b restores the original. Lite mode writes raw
        # content. Encrypted writes empty string (gnokee has no plaintext
        # at-rest claim — issue #132). The `content` local stays live up
        # to Stage 3 so the opt-in embed window still feeds the cosine
        # lane; only Stage 4 (Neo4j) and Stage 6 clinical parsers see
        # the placeholder.
        if is_encrypted:
            episode_name = "[encrypted episode]"
            augmented = ""
            stage_4_content = ""
            lite_source = "gnokee.ingest.encrypted"
        else:
            assert content is not None  # xor + non-encrypted branch
            episode_name = _episode_name_from_content(content)
            augmented = augment_for_extraction(content) if extract else content
            stage_4_content = augmented
            lite_source = "gnokee.ingest"

        try:
            await self.graph.write_lite_episode(
                tenant_id=episode.tenant_id,
                episode_uuid=episode_uuid,
                valid_at=episode.valid_at,
                name=episode_name,
                content=stage_4_content,
                created_at=stage_4_time,
                source_description=lite_source,
            )
        except Exception as exc:
            # ADR-0024: Stage 4 failure — no compensation needed (nothing
            # landed), journal a 'fail' row and re-raise.
            await _journal_fail_swallow(self.journal, journal_begin, exc)
            raise

        # ── Stage 5: pg writes (one txn).
        asserted_at = episode.asserted_at or utc_now()

        # extraction_deferred starts FALSE on the row. Stage 6 flips it
        # True via ``set_extraction_deferred`` on retry-exhaustion or
        # when lite mode / encrypted branch keeps Stage 6 off.
        # Issue #123 — `corrects_reason` is only meaningful when a
        # supersession is asserted. Silently drop the rationale when
        # `corrects` is unset so the column reflects "rationale for the
        # supersession this row declared" honestly.
        corrects_reason = episode.corrects_reason if episode.corrects is not None else None
        row = EpisodeMetadataRow(
            tenant_id=episode.tenant_id,
            episode_uuid=episode_uuid,
            valid_at=episode.valid_at,
            valid_until=episode.valid_until,
            asserted_at=asserted_at,
            asserted_until=None,
            superseded_by=None,
            sensitive=episode.sensitive,
            language=language,
            our_id=episode.our_id,
            extraction_deferred=False,
            extraction_completed_at=None,
            corrects_reason=corrects_reason,
        )

        race_winner_uuid: UUID | None = None
        race_winner_asserted_at: datetime | None = None
        head: EpisodeMetadataRow | None = None
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    inserted = await self.metadata.write(conn=conn, row=row)
                    if not inserted:
                        raise _OurIdRaceLost()

                    if episode.corrects is not None:
                        head = await self.metadata.supersede(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            corrected_episode_uuid=episode.corrects,
                            new_episode_uuid=episode_uuid,
                            asserted_until=asserted_at,
                        )

                    if vector is not None:
                        await self.vector.write_embedding(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=episode_uuid,
                            embedding=vector,
                        )
                    if episode.content is not None:
                        await self.vector.write_content_text(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=episode_uuid,
                            content_text=episode.content,
                        )
                    if encrypted_body is not None:
                        await self.encrypted_body.write(
                            conn=conn,
                            row=EncryptedBodyRow(
                                tenant_id=episode.tenant_id,
                                episode_uuid=episode_uuid,
                                ciphertext=encrypted_body.ciphertext,
                                nonce=encrypted_body.nonce,
                                key_id=encrypted_body.key_id,
                            ),
                        )
                    lab_rows = _build_lab_rows(
                        parse_labs(content) if content is not None else [],
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and lab_rows:
                        updated = await self.lab.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[(r.analyte, r.valid_at) for r in lab_rows],
                            asserted_until=asserted_at,
                        )
                        if updated < len(lab_rows):
                            log.warning(
                                "lab.supersede_matching: matched %d of %d keys tenant=%s head=%s new=%s",
                                updated,
                                len(lab_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if lab_rows:
                        await self.lab.write_rows(conn=conn, rows=lab_rows)
                    med_rows = _build_med_rows(
                        parse_meds(content) if content is not None else [],
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and med_rows:
                        updated = await self.med.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[(r.drug_name, r.event_kind, r.valid_at) for r in med_rows],
                            asserted_until=asserted_at,
                        )
                        if updated < len(med_rows):
                            log.warning(
                                "med.supersede_matching: matched %d of %d keys tenant=%s head=%s new=%s",
                                updated,
                                len(med_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if med_rows:
                        await self.med.write_rows(conn=conn, rows=med_rows)
        except _OurIdRaceLost:
            assert episode.our_id is not None
            winner = await self.metadata.get_by_our_id(
                tenant_id=episode.tenant_id,
                our_id=episode.our_id,
            )
            if winner is None:
                await _compensate(self.graph, episode.tenant_id, episode_uuid, _OurIdRaceLost())
                vanished_exc = VectorStoreError(
                    "race lost on (tenant_id, our_id) but winner row vanished",
                )
                await _journal_fail_swallow(self.journal, journal_begin, vanished_exc)
                raise vanished_exc from None
            race_winner_uuid = winner.episode_uuid
            race_winner_asserted_at = winner.asserted_at
            await _compensate(self.graph, episode.tenant_id, episode_uuid, _OurIdRaceLost())
            # ADR-0024 / #122 — the race-loser's episode_uuid was
            # compensated away; this is NOT a Stage 5 commit. Write a
            # 'fail' row referencing the winner so the audit trail is
            # honest. (The race-winner return below skips
            # `journal.write_commit` for this episode_uuid.)
            await _journal_fail_swallow(
                self.journal,
                journal_begin,
                f"race_lost: superseded by winner_uuid={winner.episode_uuid}",
            )
        except VectorStoreError as exc:
            await _compensate(self.graph, episode.tenant_id, episode_uuid, exc)
            await _journal_fail_swallow(self.journal, journal_begin, exc)
            raise
        except Exception as exc:  # pragma: no cover
            await _compensate(self.graph, episode.tenant_id, episode_uuid, exc)
            wrapped = VectorStoreError(f"pg writes failed: {exc}")
            await _journal_fail_swallow(self.journal, journal_begin, wrapped)
            raise wrapped from exc

        if race_winner_uuid is not None and race_winner_asserted_at is not None:
            # Race-loser path: journal 'fail' already written above with
            # the winner uuid; do NOT write 'commit' for this attempt.
            # Caller still sees a replayed=True receipt pointing at the
            # winner's episode_uuid.
            return IngestReceipt(
                episode_uuid=race_winner_uuid,
                asserted_at=race_winner_asserted_at,
                created_fact_uuids=[],
                contradicts=[],
                replayed=True,
            )

        # ADR-0024 / #122 — Stage 5 returned success; close the journal
        # entry. The commit row lives outside the Stage 5 txn — it
        # trails the work it journals — and goes BEFORE Stage 6's
        # best-effort enhancement runs.
        await self.journal.write_commit(journal_begin)

        # ── Stage 6: graphiti enhancement (best-effort, Z4 wrapped).
        orphan_edge_warnings = 0
        extraction_succeeded = False
        enhancement_retries = 0
        lite_fallback_engaged = False
        enhancement_result = None
        created_fact_uuids: list[UUID] = []

        if extract:
            assert content is not None  # extract path requires plaintext
            warning_counter = _OrphanEdgeWarningCounter()
            graphiti_edge_logger = logging.getLogger(
                "graphiti_core.utils.maintenance.edge_operations",
            )
            graphiti_edge_logger.addHandler(warning_counter)

            async def _do_enhance() -> object:
                # NOTE: per Z1.6 spike, graphiti's add_episode short-circuits
                # to load-by-uuid when ``uuid`` is set and uses the loaded
                # Episodic.content for extraction. The ``content`` kwarg
                # here is documentation-only on this path.
                return await self.graph.add_episode(
                    tenant_id=episode.tenant_id,
                    name=episode_name,
                    content=augmented,
                    reference_time=episode.valid_at,
                    uuid=episode_uuid,
                    source_description="gnokee.ingest",
                )

            try:
                async with self._enhancement_semaphore:
                    enhancement_result, enhancement_retries = await _retry_enhancement(
                        _do_enhance,
                        max_retries=3,
                        base_delay=1.0,
                        jitter_pct=0.2,
                    )
            finally:
                graphiti_edge_logger.removeHandler(warning_counter)
                orphan_edge_warnings = warning_counter.count

            if enhancement_result is None:
                # Retry-exhausted OR non-retryable — lite-fallback engaged.
                lite_fallback_engaged = True
                log.warning(
                    "gnokee.ingest: extraction deferred after %d retries; episode_uuid=%s tenant=%s",
                    enhancement_retries,
                    episode_uuid,
                    episode.tenant_id,
                )
            else:
                extraction_succeeded = True
                created_fact_uuids = [
                    UUID(e.uuid)
                    for e in enhancement_result.edges  # type: ignore[attr-defined]
                    if e.uuid is not None
                ]
                # Stage 6b: restore original content if augmented.
                if augmented != content:
                    try:
                        await self.graph.overwrite_episode_content(
                            tenant_id=episode.tenant_id,
                            episode_uuid=episode_uuid,
                            content=content,
                        )
                    except GraphStoreError as exc:
                        # Z1-B intentional behaviour change: provenance
                        # restore failure is logged-loud-but-non-fatal.
                        # Augmented body in fact_provenance is preferable
                        # to silently dropping the whole episode.
                        log.warning(
                            "gnokee.ingest: overwrite_episode_content failed tenant=%s episode_uuid=%s: %s",
                            episode.tenant_id,
                            episode_uuid,
                            exc,
                        )

                # Z3 (#111) — orphan-edge counts surface via
                # IngestTelemetry.orphan_edge_warnings (env-var control removed v0.7).
                if orphan_edge_warnings > 0:
                    log.warning(
                        "gnokee.ingest: episode our_id=%s tenant=%s extraction "
                        "emitted %d orphan-edge warnings; gnokee episode_uuid=%s",
                        episode.our_id,
                        episode.tenant_id,
                        orphan_edge_warnings,
                        episode_uuid,
                    )

        # Flip extraction_deferred on episode_metadata when lite mode,
        # encrypted (extract=False but is_encrypted), or lite-fallback.
        # Encrypted branch stays False (no DEK = never rehydratable).
        extraction_deferred_flag = (not extract and not is_encrypted) or lite_fallback_engaged
        if extraction_deferred_flag:
            async with self.pool.acquire() as conn:
                await self.metadata.set_extraction_deferred(
                    conn=conn,
                    tenant_id=episode.tenant_id,
                    episode_uuid=episode_uuid,
                    extraction_deferred=True,
                )

        # ── Stage 7: contradiction detection (degraded-tolerant).
        contradicts: list[ContradictionRef] = []
        if (
            enhancement_result is not None
            and self.contradiction_enabled
            and self.llm is not None
            and enhancement_result.edges  # type: ignore[attr-defined]
        ):
            new_facts: list[tuple[UUID, str, datetime, list[float]]] = []
            for edge in enhancement_result.edges:  # type: ignore[attr-defined]
                if edge.fact_embedding is None:
                    continue
                edge_valid = edge.valid_at or episode.valid_at
                new_facts.append(
                    (
                        UUID(edge.uuid),
                        edge.fact,
                        edge_valid,
                        list(edge.fact_embedding),
                    )
                )
            if new_facts:
                detection = await detect_for_facts(
                    tenant_id=episode.tenant_id,
                    new_facts=new_facts,
                    store=self.graph,
                    contradictions=self.contradictions,
                    llm=self.llm,
                    detected_at=utc_now(),
                )
                contradicts = detection.contradicts

        # ── Stage 8: return receipt.
        return IngestReceipt(
            episode_uuid=episode_uuid,
            asserted_at=asserted_at,
            created_fact_uuids=created_fact_uuids,
            contradicts=contradicts,
            extraction_deferred=extraction_deferred_flag,
            ingest_telemetry=IngestTelemetry(
                orphan_edge_warnings=orphan_edge_warnings,
                extraction_succeeded=extraction_succeeded,
                enhancement_retries=enhancement_retries,
                lite_fallback_engaged=lite_fallback_engaged,
            ),
        )


class _OurIdRaceLost(Exception):
    """Internal sentinel: lost the race on the partial unique (tenant_id, our_id) index."""


async def _journal_fail_swallow(
    journal: IngestJournal,
    begin: ResumableEntry,
    original: Exception | str,
) -> None:
    """Write a journal 'fail' row, swallowing any journal-write error.

    ADR-0024: the journal-write itself is best-effort during exception
    handling. If it fails (e.g. Postgres down), the original ingest
    error must still propagate — the audit-row miss is acceptable, the
    masked failure is not.

    ``original`` may be an ``Exception`` (typical Stage 4 / Stage 5
    raise) or a ``str`` (race-loser semantic on _OurIdRaceLost, where
    there is no exception to report). ``Exception`` values are
    ``repr``-formatted; strings pass through.
    """
    error_msg = original if isinstance(original, str) else repr(original)
    try:
        await journal.write_fail(begin, error_msg)
    except Exception:  # pragma: no cover — journal write failed mid-exception
        log.exception(
            "gnokee.ingest: journal.write_fail failed tenant=%s episode_uuid=%s",
            begin.tenant_id,
            begin.episode_uuid,
        )


async def _compensate(
    graph: GraphitiStore,
    tenant_id: str,
    episode_uuid: UUID,
    original: Exception,
) -> None:
    """Best-effort lite-Episodic removal on partial-failure (#111 Z1-B B2).

    Uses ``remove_lite_episode`` (raw Cypher) rather than graphiti's
    ``remove_episode`` because the latter may rely on graphiti-internal
    indexing that doesn't see MERGE-only-written nodes — Z1-B writes via
    raw Cypher so compensation must take the same path.
    """
    try:
        await graph.remove_lite_episode(tenant_id=tenant_id, episode_uuid=episode_uuid)
        log.warning(
            "compensated by removing episode %s (tenant=%s) after failure: %s",
            episode_uuid,
            tenant_id,
            original,
        )
    except GraphStoreError as comp_exc:
        log.error(
            "compensation FAILED for %s (tenant=%s); orphan episode in Neo4j. original=%s comp=%s",
            episode_uuid,
            tenant_id,
            original,
            comp_exc,
        )


def _build_lab_rows(
    parsed: list[LabRow],
    *,
    tenant_id: str,
    episode_uuid: UUID,
    valid_at: datetime,
    asserted_at: datetime,
) -> list[LabRecordRow]:
    return [
        LabRecordRow(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            analyte=p.analyte,
            value_numeric=p.value_numeric,
            value_text=p.value_text,
            unit=p.unit,
            ref_range_low=p.ref_range_low,
            ref_range_high=p.ref_range_high,
            abnormal_flag=p.abnormal_flag,
            valid_at=valid_at,
            asserted_at=asserted_at,
        )
        for p in parsed
    ]


def _build_med_rows(
    parsed: list[MedRow],
    *,
    tenant_id: str,
    episode_uuid: UUID,
    valid_at: datetime,
    asserted_at: datetime,
) -> list[MedRecordRow]:
    return [
        MedRecordRow(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            drug_name=p.drug_name,
            event_kind=p.event_kind,
            valid_at=valid_at,
            asserted_at=asserted_at,
            dose_value=p.dose_value,
            dose_unit=p.dose_unit,
            frequency=p.frequency,
            route=p.route,
            reason=p.reason,
        )
        for p in parsed
    ]


def _episode_name_from_content(content: str, *, limit: int = 80) -> str:
    """Stable name for Graphiti's `name` field (NOT used for retrieval — episode_uuid is)."""
    head = content.strip().splitlines()[0] if content.strip() else "episode"
    if len(head) <= limit:
        return head
    return head[: limit - 1].rstrip() + "…"


# Public API alias kept module-level so external `gnokee.ingest_episode(...)` works.
async def ingest_episode(
    *,
    pipeline: IngestPipeline,
    tenant_id: str,
    content: str | None = None,
    encrypted_body: EncryptedBody | None = None,
    valid_at: datetime,
    valid_until: datetime | None = None,
    asserted_at: datetime | None = None,
    our_id: str | None = None,
    corrects: UUID | None = None,
    corrects_reason: str | None = None,
    entity_type_hints: list[str] | None = None,
    sensitive: Sensitivity = "private",
    language: str | None = None,
    extract: bool = True,
) -> IngestReceipt:
    """Public coroutine. Constructs `EpisodeIn` and dispatches to the pipeline.

    Args:
        content: Plaintext episode body. Mutually exclusive with
            ``encrypted_body`` (xor — Stage 1 boundary, issue #22).
        encrypted_body: Pre-encrypted episode body (issue #22).
            Mutually exclusive with ``content``. gnokee NEVER decrypts;
            see ``EncryptedBody`` docstring for the embed-only plaintext
            window option.
        extract: When True (default), runs full pipeline including Graphiti
            add_episode and contradiction detection. When False, skips those
            stages for low-latency lite ingest (receipt.extraction_deferred=True).
            Backwards-compatible: existing callers that omit `extract` get
            extract=True (full mode) behaviour unchanged. Force-disabled on
            the encrypted_body branch.

    Raises:
        ValidationError: Pydantic ``EpisodeIn`` validation failed
            (empty ``tenant_id``, ``content`` xor ``encrypted_body``
            violated, naive ``valid_at``, etc.).
        VectorStoreError: Stage 5 Postgres failure; existing
            compensation removed any partial Stage 4 lite-Episodic.
        GraphStoreError: Stage 4 lite-Episodic write failed.
        EmbeddingsUnavailable: TEI client could not produce a vector
            for plaintext content.
    """
    try:
        episode = EpisodeIn(
            tenant_id=tenant_id,
            content=content,
            encrypted_body=encrypted_body,
            valid_at=valid_at,
            valid_until=valid_until,
            asserted_at=asserted_at,
            our_id=our_id,
            corrects=corrects,
            corrects_reason=corrects_reason,
            entity_type_hints=entity_type_hints,
            sensitive=sensitive,
            language=language,
        )
    except PydanticValidationError as exc:
        raise ValidationError(str(exc)) from exc
    try:
        return await pipeline.ingest(episode, extract=extract)
    except GnokeeError:
        raise


__all__ = ["IngestPipeline", "ingest_episode"]
