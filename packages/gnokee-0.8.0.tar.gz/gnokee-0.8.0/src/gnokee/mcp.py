"""src/gnokee/mcp.py — FastMCP server. Tools:

  - gnokee_ingest_episode
  - gnokee_recall
  - gnokee_fact_provenance
  - gnokee_lab_query       (v0.2 / ADR-0009 — typed clinical-lab reads)
  - gnokee_med_query       (v0.2 / ADR-0010 — typed medication-history reads)
  - gnokee_query           (v0.5 / ADR-0013 — declarative envelope)
  - gnokee_wiki_export     (v0.5 / ADR-0015 — markdown wiki view per tenant)
  - gnokee_history_of      (v0.7 / issue #123 — supersession DAG)
  - gnokee_forget_episode  (v0.8 / ADR-0026 — hard-delete episode + descendants)
  - gnokee_forget_tenant   (v0.8 / ADR-0026 — hard-delete entire tenant)

Tool descriptions per spec §6 (token-budgeted, fit MCP listing). All
datetime parameters accept ISO-8601 strings (Z or +HH:MM); MCP layer
resolves null → datetime.now(UTC) BEFORE calling the Python API.

exports: build_server | _cli_main
used_by: external MCP clients
rules:   never let `None` flow into storage; tenant_id mandatory; v0.1 unauthenticated
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
         claude-opus-4-7 | 2026-05-11 | issue #84 expose top_k_bodies + per_body_char_cap on gnokee_recall
         claude-opus-4-7 | 2026-05-11 | issue #76 / ADR-0016 per-claim citation envelope
         claude-opus-4-7 | 2026-05-11 | issue #72 / ADR-0013 gnokee_query declarative envelope
         claude-opus-4-7 | 2026-05-11 | issue #74 / ADR-0015 gnokee_wiki_export + llms.txt manifest
         claude-sonnet-4-6 | 2026-05-12 | issue #89 include_cosine_top1 opt-in telemetry on gnokee_recall
         claude-sonnet-4-6 | 2026-05-12 | issue #94 / ADR-0022 Option A cosine_floor + refused signal
         claude-sonnet-4-6 | 2026-05-16 | issue #130 / ADR-0026 gnokee_forget_episode + gnokee_forget_tenant
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from gnokee.bootstrap import App, build_app, shutdown_app
from gnokee.config import Settings, utc_now
from gnokee.errors import CannotForgetChainNode, ForgetNeo4jPartial, GnokeeError, ValidationError
from gnokee.forget import forget_episode, forget_tenant
from gnokee.history import (
    DEFAULT_MAX_NODES as HISTORY_DEFAULT_MAX_NODES,
)
from gnokee.history import (
    DEFAULT_MAX_TOKENS as HISTORY_DEFAULT_MAX_TOKENS,
)
from gnokee.history import (
    DEFAULT_PER_BODY_CHAR_CAP as HISTORY_DEFAULT_PER_BODY_CHAR_CAP,
)
from gnokee.history import (
    DEFAULT_TOP_K_BODIES as HISTORY_DEFAULT_TOP_K_BODIES,
)
from gnokee.ingest import ingest_episode
from gnokee.lab_query import DEFAULT_HISTORY_LIMIT, lab_query
from gnokee.med_query import DEFAULT_HISTORY_LIMIT as MED_HISTORY_LIMIT
from gnokee.med_query import med_query
from gnokee.models import Citation, ForgetEpisodeIn, ForgetReceipt, ForgetTenantIn
from gnokee.query import (
    DEFAULT_MAX_EPISODES,
    DEFAULT_MAX_TOKENS,
    DateRange,
    QueryEnvelope,
    QueryEnvelopeBudget,
    QueryEnvelopeFilter,
    QueryResponse,
)
from gnokee.query import (
    gnokee_query as run_gnokee_query,
)
from gnokee.retrieval import (
    DEFAULT_PER_BODY_CHAR_CAP,
    DEFAULT_TOP_K_BODIES,
    fact_provenance,
    recall,
)
from gnokee.wiki_export import wiki_export

log = logging.getLogger(__name__)


def _parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _require_datetime(value: str | None) -> datetime:
    parsed = _parse_datetime(value)
    return parsed if parsed is not None else utc_now()


def _serialize_citations(citations: dict[str, Citation]) -> dict[str, dict[str, Any]]:
    """Serialise the per-claim bi-temporal citation envelope (ADR-0016).

    Map keys (``c1``, ``c2``, …) are preserved verbatim so the host LLM
    can back-reference entries via inline `[cN]` markers. UUIDs serialise
    to strings; datetimes serialise to ISO-8601; `extracted_quote` and
    `source_uri` stay nullable in the wire envelope (v0.5 emits them as
    `None` everywhere — see ADR-0016 § "Migration strategy").
    """
    return {
        key: {
            "episode_uuid": str(cite.episode_uuid),
            "fact_uuid": str(cite.fact_uuid) if cite.fact_uuid is not None else None,
            "valid_at": cite.valid_at.isoformat(),
            "asserted_at": cite.asserted_at.isoformat(),
            "extracted_quote": cite.extracted_quote,
            "source_uri": cite.source_uri,
        }
        for key, cite in citations.items()
    }


def build_server(app: App) -> FastMCP:
    server = FastMCP(name="gnokee", instructions="bi-temporal memory infrastructure for personal AI")

    @server.tool(
        name="gnokee_ingest_episode",
        description=(
            "Store a new fact, event, or observation in bi-temporal memory. Call this whenever "
            "the user states something worth remembering, or when an external source delivers a "
            "new fact-bearing payload. `valid_at` = when the fact was true in the world (not the "
            "ingestion time); `asserted_at` = when you learned of it (defaults to now). Pass "
            "`our_id` (a stable consumer-supplied key, e.g. `email:msg-id`) to make ingest "
            "idempotent — re-ingest with the same key returns the existing episode with "
            "`replayed=true` instead of creating a duplicate. Returns the episode UUID, the UUIDs "
            "of any facts created, and any contradictions detected against existing facts; "
            "gnokee never auto-resolves — surface contradictions to the user."
        ),
    )
    async def gnokee_ingest_episode(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        content: Annotated[str, Field(description="Episode body (cleartext).")],
        valid_at: Annotated[
            str,
            Field(description="ISO-8601 UTC. When the fact was true in the world (NOT ingestion time)."),
        ],
        valid_until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Optional world-time upper bound."),
        ] = None,
        asserted_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. When the consumer learned of it. Defaults to now."),
        ] = None,
        our_id: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "Stable consumer-supplied id (e.g. `email:<message-id>`). Same key + tenant = "
                    "idempotent replay; response sets `replayed=true`."
                ),
            ),
        ] = None,
        sensitive: Annotated[
            Literal["public", "private", "clinical"],
            Field(default="private", description="Sensitivity tag. Drives retrieval gating."),
        ] = "private",
        language: Annotated[
            str | None,
            Field(default=None, description="ISO 639-1; auto-detect when null."),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        receipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant_id,
            content=content,
            valid_at=_require_datetime(valid_at),
            valid_until=_parse_datetime(valid_until),
            asserted_at=_require_datetime(asserted_at),
            our_id=our_id,
            sensitive=sensitive,
            language=language,
        )
        return {
            "episode_uuid": str(receipt.episode_uuid),
            "asserted_at": receipt.asserted_at.isoformat(),
            "created_fact_uuids": [str(u) for u in receipt.created_fact_uuids],
            "contradicts": [
                {
                    "fact_uuid": str(c.fact_uuid),
                    "verdict": c.verdict,
                    "summary": c.summary,
                    "valid_at": c.valid_at.isoformat(),
                }
                for c in receipt.contradicts
            ],
            "replayed": receipt.replayed,
        }

    @server.tool(
        name="gnokee_recall",
        description=(
            "Retrieve facts from bi-temporal memory. Call this before answering questions about "
            "past user state, prior decisions, or stored knowledge. `valid_at` pins world-time "
            "(default: now); `as_of` pins source-time (default: now). For most queries leave both "
            "unset. Returns natural-language fact statements with provenance handles (UUIDs); fetch "
            "full episode bodies via `gnokee_fact_provenance(fact_uuid)` when a fact is contested or "
            "carries an `update` verdict and you need the original source text. If "
            "`surface_contradictions`, conflicting facts are returned alongside primaries with a "
            "`verdict` (`refinement`/`update`/`contradiction`) and the conflicting fact's "
            "`valid_at` — do not auto-pick a winner. When the query references currency or amount "
            "keywords (`spent`, `cost`, `budget`, `€`, `$`, …), the response also includes an "
            "`excerpts[]` list with verbatim ``Episodic.content`` lines that carry the digits the "
            "fact-extraction step may have summarised away — quote those when answering numeric questions. "
            "When a cosine-relevant episode has been superseded (closed via `corrects:`) at the "
            "caller's `as_of`, it is hidden from `facts[]` and `excerpts[]` and instead surfaced "
            "in `supersession_hints[]` with the chain head — call `gnokee_lab_query` / "
            "`gnokee_med_query` for typed reads against still-open row-level data, or pin `as_of` "
            "pre-correction to recall the original narrative. "
            "`episode_fallback[]` carries the verbatim ``Episodic.content`` of the top-K ranked "
            "episodes — populated alongside `facts[]` whenever the query carries no excerpt signal "
            "(conversation literals like counts, dates, names that the fact-extraction step may "
            "have summarised away), and as the sole answer surface when Graphiti synthesised no "
            "edges for the ranked candidates (ADR-0012 Path A). `body_used` is `true` whenever "
            "`episode_fallback[]` is non-empty — quote those bodies when answering, especially for "
            "literal-asking variants. Mutually exclusive with `excerpts[]` (currency / med-keyword "
            "snippets cover the same need with a tighter budget). "
            "`refused: bool` — true when corpus returned zero facts and zero episode fallback for "
            "this query. Consumer LLMs should render an explicit 'I cannot answer from these "
            "sources' message in this case. Most useful when `cosine_floor` is set — without a "
            "floor gnokee almost always returns something grounded. "
            "`cosine_floor` (0.0-1.0, default null) — when set, episodes whose cosine similarity "
            "falls below this value are pruned before fact fetch, enabling `refused=true` on "
            "out-of-domain queries. Start around 0.3-0.4 for narrow corpora. Null = no floor "
            "(current behaviour preserved). "
            "`retrieved_episode_external_ids[]` carries the consumer-supplied `our_id` of the "
            "BM25/cosine top-K ranked visible episodes in fused-rank order (eval-only signal — "
            "do NOT user-quote). "
            "`recall_telemetry{}` carries the Stage 6 per-lane budget vs emitted-token accounting "
            "(`budget_max_tokens`, `fact_budget`/`excerpt_budget`/`body_budget`, "
            "`fact_tokens_emitted`/`excerpt_tokens_emitted`/`body_tokens_emitted`, per-lane row "
            "counts, `body_first_row_oversize`) — eval / observability signal, do NOT user-quote. "
            "`top_k_bodies` + `per_body_char_cap` tune the body lane: raise `top_k_bodies` when "
            "conversation-shape corpora need multiple turns quoted side-by-side; lower "
            "`per_body_char_cap` to stop a single oversized body from starving the always-emit "
            "guard. Defaults match the Python API. "
            "`citations{}` (ADR-0016 / issue #76) is a MAP keyed `c1`, `c2`, … in deterministic "
            "emission order (facts first, then excerpts, then episode_fallback). Each entry "
            "carries `episode_uuid`, `fact_uuid` (nullable — set for FactStatement-backed "
            "citations, null for body-surface ones), `valid_at`, `asserted_at`, `extracted_quote` "
            "(nullable — verbatim body span when the extraction stage recorded one, else null; "
            "v0.5 emits null everywhere pending follow-up), and `source_uri` (nullable). Emit "
            "inline `[c1]`, `[c2]`, … markers in your answer text wherever you state a fact, so "
            "the user can back-reference the source episode. `[cN]` is unambiguous; `[N]` is "
            "ALSO accepted by downstream graders. Additive to `facts[].fact_uuid` / "
            "`facts[].episode_uuid` provenance handles — those keep working unchanged. "
            "`include_cosine_top1` (issue #89 / ADR-0019 follow-up) — when `true`, each entry "
            "in `facts[]` gains a `cosine_top1` field: the pgvector cosine similarity (in [0, 1]; "
            "`1 - distance`) of the fact's source episode vs the query embedding. `null` when the "
            "episode had no ANN hit (e.g. Path-A episode-fallback facts). Default `false` — "
            "telemetry signal only, do NOT use to reorder or suppress facts."
        ),
    )
    async def gnokee_recall(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        text: Annotated[str, Field(description="Natural-language query.")],
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        surface_contradictions: Annotated[
            bool,
            Field(default=True, description="If true, attach contradicts[] to each FactStatement."),
        ] = True,
        max_tokens: Annotated[
            int,
            Field(default=200, description="Response token budget. Truncates fact list when reached."),
        ] = 200,
        top_k: Annotated[
            int,
            Field(default=10, description="Cosine top-K candidates to consider."),
        ] = 10,
        top_k_bodies: Annotated[
            int,
            Field(
                default=DEFAULT_TOP_K_BODIES,
                description=(
                    "Max episode_fallback body rows the body lane is allowed to emit when it "
                    "fires. Stacks against body_budget; the always-emit-first guard still applies."
                ),
            ),
        ] = DEFAULT_TOP_K_BODIES,
        per_body_char_cap: Annotated[
            int,
            Field(
                default=DEFAULT_PER_BODY_CHAR_CAP,
                description=(
                    "Per-body character cap before token accounting + emission. Bounds the "
                    "body lane's token cost so the first-row guard does not consume the budget."
                ),
            ),
        ] = DEFAULT_PER_BODY_CHAR_CAP,
        include_cosine_top1: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "When true, each facts[] entry gains cosine_top1: pgvector cosine similarity "
                    "in [0,1] of the source episode vs the query. Null for Path-A fallback facts. "
                    "Telemetry only — do NOT use to reorder or suppress. Default false."
                ),
            ),
        ] = False,
        cosine_floor: Annotated[
            float | None,
            Field(
                default=None,
                ge=0.0,
                le=1.0,
                description=(
                    "ADR-0022 Option A (issue #94). When set (0.0-1.0), episodes whose cosine "
                    "similarity falls below this floor are pruned before fact fetch. Makes "
                    "refused=true observable on out-of-domain queries. Default null = no floor "
                    "(preserves current behaviour). Start around 0.3-0.4 for narrow corpora."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        response = await recall(
            pipeline=app.recall,
            tenant_id=tenant_id,
            text=text,
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            surface_contradictions=surface_contradictions,
            max_tokens=max_tokens,
            top_k=top_k,
            top_k_bodies=top_k_bodies,
            per_body_char_cap=per_body_char_cap,
            include_cosine_top1=include_cosine_top1,
            cosine_floor=cosine_floor,
        )
        return {
            "facts": [
                {
                    "text": f.text,
                    "fact_uuid": str(f.fact_uuid),
                    "episode_uuid": str(f.episode_uuid),
                    "valid_at": f.valid_at.isoformat(),
                    "asserted_at": f.asserted_at.isoformat(),
                    "confidence": f.confidence,
                    "cosine_top1": f.cosine_top1,
                    "contradicts": [
                        {
                            "fact_uuid": str(c.fact_uuid),
                            "verdict": c.verdict,
                            "summary": c.summary,
                            "valid_at": c.valid_at.isoformat(),
                        }
                        for c in f.contradicts
                    ],
                }
                for f in response.facts
            ],
            "truncated": response.truncated,
            "candidate_count": response.candidate_count,
            "excerpts": [
                {
                    "episode_uuid": str(e.episode_uuid),
                    "text": e.text,
                }
                for e in response.excerpts
            ],
            "supersession_hints": [
                {
                    "superseded_uuid": str(h.superseded_uuid),
                    "current_head_uuid": str(h.current_head_uuid),
                    "superseded_at": h.superseded_at.isoformat(),
                }
                for h in response.supersession_hints
            ],
            "episode_fallback": [
                {
                    "episode_uuid": str(r.episode_uuid),
                    "text": r.text,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
                for r in response.episode_fallback
            ],
            "body_used": response.body_used,
            "retrieved_episode_external_ids": list(response.retrieved_episode_external_ids),
            "recall_telemetry": response.recall_telemetry.model_dump(),
            # Issue #22 — encrypted-body episodes ride here. ciphertext +
            # nonce are bytes; emit hex strings so the JSON-RPC envelope
            # stays UTF-8 clean. Consumer decrypts via their KMS using
            # `key_id`. gnokee NEVER carries plaintext for these.
            "encrypted_bodies": [
                {
                    "episode_uuid": str(eb.episode_uuid),
                    "ciphertext_hex": eb.ciphertext.hex(),
                    "nonce_hex": eb.nonce.hex(),
                    "key_id": eb.key_id,
                }
                for eb in response.encrypted_bodies
            ],
            # ADR-0022 Option A (issue #94) — structural refusal signal.
            # True when the corpus returned zero facts and zero episode_fallback.
            # Consumer LLMs should render "I cannot answer from these sources"
            # when refused=True rather than synthesising an off-topic answer.
            "refused": response.refused,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Additive to the existing `facts[].fact_uuid` / `episode_uuid`
            # provenance handles; both ship in v0.5. Host LLM emits inline
            # `[cN]` markers to back-reference entries.
            "citations": _serialize_citations(response.citations),
        }

    @server.tool(
        name="gnokee_fact_provenance",
        description=(
            "Fetch the full episode body and metadata behind a `fact_uuid` returned by "
            "`gnokee_recall` or `gnokee_ingest_episode`. Call when a fact is contested, carries an "
            "`update`/`contradiction` verdict, or its source text is needed for the user-facing answer."
        ),
    )
    async def gnokee_fact_provenance(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        fact_uuid: Annotated[str, Field(description="UUID returned in a FactStatement or IngestReceipt.")],
    ) -> dict[str, Any] | None:
        try:
            parsed_uuid = UUID(fact_uuid)
        except ValueError as exc:
            raise ValidationError(f"fact_uuid is not a valid UUID: {fact_uuid!r}") from exc
        prov = await fact_provenance(
            pipeline=app.recall,
            tenant_id=tenant_id,
            fact_uuid=parsed_uuid,
        )
        if prov is None:
            return None
        return {
            "fact_uuid": str(prov.fact_uuid),
            "fact_text": prov.fact_text,
            "episode_uuid": str(prov.episode_uuid),
            "episode_content": prov.episode_content,
            "valid_at": prov.valid_at.isoformat(),
            "valid_until": prov.valid_until.isoformat() if prov.valid_until else None,
            "asserted_at": prov.asserted_at.isoformat(),
            "asserted_until": prov.asserted_until.isoformat() if prov.asserted_until else None,
            "language": prov.language,
            "sensitive": prov.sensitive,
            # Issue #22 — populated when the episode was ingested via
            # the encrypted_body branch. ``episode_content`` is "" then;
            # consumer decrypts via their KMS using ``key_id``.
            "encrypted_body": (
                {
                    "episode_uuid": str(prov.encrypted_body.episode_uuid),
                    "ciphertext_hex": prov.encrypted_body.ciphertext.hex(),
                    "nonce_hex": prov.encrypted_body.nonce.hex(),
                    "key_id": prov.encrypted_body.key_id,
                }
                if prov.encrypted_body is not None
                else None
            ),
        }

    @server.tool(
        name="gnokee_history_of",
        description=(
            "Return the supersession DAG for a single episode — chain of "
            "corrections from oldest predecessor to current active head, in "
            "bi-temporal order. Use when auditing how a fact changed over "
            "time, NOT to answer a current-state question (use "
            "`gnokee_recall` or `gnokee_fact_provenance` for that). "
            "`mode=compact` (default) returns one line per node with no "
            "body; `mode=verbatim` attaches body text to the newest "
            "`top_k_bodies` nodes and respects `per_body_char_cap`. "
            "`as_of` pins transaction time (chain as believed at T); "
            "`valid_at` pins world time. Encrypted episodes return "
            "`body_encrypted=true` + ciphertext envelope — gnokee NEVER "
            "returns plaintext for those. Contradictions surface inline; "
            "gnokee never auto-resolves."
        ),
    )
    async def gnokee_history_of(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        episode_id: Annotated[
            str,
            Field(
                description=(
                    "Anchor episode UUID — returned by `gnokee_recall.facts[].episode_uuid`, "
                    "`gnokee_ingest_episode`, or `gnokee_fact_provenance`. Walks the supersession "
                    "DAG in both directions from this node."
                )
            ),
        ],
        mode: Annotated[
            Literal["compact", "verbatim"],
            Field(
                description=(
                    "`compact` (default) — DAG nodes carry id + bi-temporal axes + status + "
                    "rationale only; no episode body. `verbatim` — additionally attaches body "
                    "text to the newest `top_k_bodies` nodes, capped at `per_body_char_cap` "
                    "chars each."
                )
            ),
        ] = "compact",
        as_of: Annotated[
            str | None,
            Field(
                description=(
                    "Transaction-time pin (ISO-8601). 'Show the DAG as believed at T' — filters "
                    "nodes by `asserted_at <= as_of AND (asserted_until IS NULL OR asserted_until "
                    "> as_of)`. Defaults to now(UTC)."
                )
            ),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(
                description=(
                    "World-time pin (ISO-8601). Filters nodes by `valid_until IS NULL OR "
                    "valid_until > valid_at`. Rarely narrows the DAG — most useful when "
                    "episodes carry long validity ranges. Defaults to now(UTC)."
                )
            ),
        ] = None,
        max_nodes: Annotated[
            int,
            Field(
                description=(
                    "Bound on DAG node count. Matches the storage chain-depth limit. "
                    "Truncated DAGs surface `truncated=true` with `truncation_note`."
                )
            ),
        ] = HISTORY_DEFAULT_MAX_NODES,
        max_tokens: Annotated[
            int,
            Field(
                description=(
                    "Token budget for the assembled response. Oldest nodes dropped first "
                    "when over budget; head + recent predecessors preserved."
                )
            ),
        ] = HISTORY_DEFAULT_MAX_TOKENS,
        top_k_bodies: Annotated[
            int,
            Field(
                description=(
                    "Verbatim-only — number of newest nodes to attach body text to. "
                    "Older nodes stay compact. Ignored in `compact` mode."
                )
            ),
        ] = HISTORY_DEFAULT_TOP_K_BODIES,
        per_body_char_cap: Annotated[
            int,
            Field(
                description=(
                    "Verbatim-only — max characters of `content_text` per attached body. "
                    "Mirrors `gnokee_recall.per_body_char_cap`. Ignored in `compact` mode."
                )
            ),
        ] = HISTORY_DEFAULT_PER_BODY_CHAR_CAP,
    ) -> dict[str, Any]:
        try:
            parsed_uuid = UUID(episode_id)
        except ValueError as exc:
            raise ValidationError(f"episode_id is not a valid UUID: {episode_id!r}") from exc
        result = await app.history.history_of(
            tenant_id=tenant_id,
            episode_id=parsed_uuid,
            mode=mode,
            as_of=_parse_datetime(as_of),
            valid_at=_parse_datetime(valid_at),
            max_nodes=max_nodes,
            max_tokens=max_tokens,
            top_k_bodies=top_k_bodies,
            per_body_char_cap=per_body_char_cap,
        )
        return {
            "nodes": [
                {
                    "episode_id": str(node.episode_id),
                    "valid_at": node.valid_at.isoformat(),
                    "asserted_at": node.asserted_at.isoformat(),
                    "superseded_by": (str(node.superseded_by) if node.superseded_by is not None else None),
                    "status": node.status,
                    "rationale": node.rationale,
                    "episode_body": node.episode_body,
                    "body_encrypted": node.body_encrypted,
                    "encrypted_body": (
                        {
                            "episode_uuid": str(node.encrypted_body.episode_uuid),
                            "ciphertext_hex": node.encrypted_body.ciphertext.hex(),
                            "nonce_hex": node.encrypted_body.nonce.hex(),
                            "key_id": node.encrypted_body.key_id,
                        }
                        if node.encrypted_body is not None
                        else None
                    ),
                }
                for node in result.nodes
            ],
            "edges": [{"from_id": str(edge.from_id), "to_id": str(edge.to_id)} for edge in result.edges],
            "root": str(result.root),
            "head": str(result.head),
            "truncated": result.truncated,
            "truncation_note": result.truncation_note,
            "cycle_detected": result.cycle_detected,
        }

    @server.tool(
        name="gnokee_lab_query",
        description=(
            "Typed clinical-lab read against `lab_record` (ADR-0009). Use when the "
            "user asks for a numeric analyte value, trend, or aggregate that "
            "`gnokee_recall`'s narrative facts strip away (potassium on a date, "
            "min K+ in 2024, history of hemoglobin). `op=latest` returns the most "
            "recent visible row; `op=history` returns rows ascending by `valid_at`; "
            "`op=min`/`max`/`avg`/`count` return a numeric scalar over rows whose "
            "`value_numeric` is non-null; `op=abnormal` returns rows whose "
            "`abnormal_flag` is set (high/low/critical) within the date range — "
            "use this when the question is 'which analytes were abnormal?' rather "
            "than naming an analyte upfront. Both bi-temporal half-pairs apply: "
            "`as_of` pins source-tx-time (default: now — post-correction view); "
            "`valid_at` pins world-time (default: now). `since`/`until` are world-"
            "time bounds on the analyte sample (`valid_at`). `analyte` is required "
            "for every op except `abnormal`, where it is optional and acts as a "
            "narrowing filter when supplied. Returns rows with "
            "value/unit/ref-range/abnormal-flag and the `episode_uuid` provenance "
            "handle — fetch the original panel body via `gnokee_fact_provenance`. "
            "`citations{}` (ADR-0016 / issue #76) is a MAP keyed `c1`, `c2`, … in "
            "`rows` order — one entry per emitted row, each carrying `episode_uuid`, "
            "`fact_uuid` (null for typed-store rows), `valid_at`, `asserted_at`, "
            "`extracted_quote` (nullable; v0.5 emits null pending follow-up), and "
            "`source_uri` (nullable). Scalar ops (min/max/avg/count) emit zero rows "
            "and an empty `citations` map — quote `scalar` directly without a `[cN]` "
            "marker. For row-bearing ops, emit inline `[c1]`, `[c2]`, … markers in "
            "your answer wherever you state a value, date, or trend so the user can "
            "back-reference the source panel."
        ),
    )
    async def gnokee_lab_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["latest", "history", "min", "max", "avg", "count", "abnormal"],
            Field(description="latest|history|min|max|avg|count|abnormal."),
        ],
        analyte: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    'Analyte name, e.g. "Potassium", "Hemoglobin". Required for '
                    "every op except `abnormal` (where it acts as an optional "
                    "narrowing filter)."
                ),
            ),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on sample valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on sample valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=DEFAULT_HISTORY_LIMIT, description="Row cap for op=history. Ignored for scalar ops."),
        ] = DEFAULT_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await lab_query(
            pipeline=app.lab_query,
            tenant_id=tenant_id,
            analyte=analyte,
            op=op,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        return {
            "op": response.op,
            "rows": [
                {
                    "episode_uuid": str(r.episode_uuid),
                    "analyte": r.analyte,
                    "value_numeric": str(r.value_numeric) if r.value_numeric is not None else None,
                    "value_text": r.value_text,
                    "unit": r.unit,
                    "ref_range_low": str(r.ref_range_low) if r.ref_range_low is not None else None,
                    "ref_range_high": str(r.ref_range_high) if r.ref_range_high is not None else None,
                    "abnormal_flag": r.abnormal_flag,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
                for r in response.rows
            ],
            "scalar": str(response.scalar) if response.scalar is not None else None,
            "count": response.count,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Map keyed `c1`, `c2`, … in `rows` order. Empty for scalar ops.
            "citations": _serialize_citations(response.citations),
        }

    @server.tool(
        name="gnokee_med_query",
        description=(
            "Typed medication-history read against `med_record` (ADR-0010). Use "
            "when the user asks for current meds, dose history, allergy list, or "
            "ACE→ARB-style switches that `gnokee_recall`'s narrative facts may "
            "preserve drug names for but strip dates and dose numerals from. "
            "`op=active` returns one row per drug whose latest visible event is "
            "not a stop/allergy (defaults to current state — pass `valid_at` to "
            "pin a different world-time, e.g. 'meds active on 2024-07-01'); "
            "`op=history` returns all events for `drug_name` ascending by "
            "`valid_at`, optionally bounded by `since`/`until`; `op=allergies` "
            "returns all allergy rows for the tenant; `op=switches` returns "
            "drug-switch events. Both bi-temporal half-pairs apply: `as_of` pins "
            "source-tx-time (default: now); `valid_at` pins world-time (default: "
            "now). Each row carries the `episode_uuid` provenance handle — fetch "
            "the original prose via `gnokee_fact_provenance`. "
            "`citations{}` (ADR-0016 / issue #76) is a MAP keyed `c1`, `c2`, … in "
            "`rows` order — one entry per emitted row, each carrying `episode_uuid`, "
            "`fact_uuid` (null for typed-store rows), `valid_at`, `asserted_at`, "
            "`extracted_quote` (nullable; v0.5 emits null pending follow-up), and "
            "`source_uri` (nullable). Emit inline `[c1]`, `[c2]`, … markers in "
            "your answer wherever you state a drug name, dose, start date, or "
            "switch event so the user can back-reference the source episode."
        ),
    )
    async def gnokee_med_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["active", "history", "allergies", "switches"],
            Field(description="active|history|allergies|switches."),
        ],
        drug_name: Annotated[
            str | None,
            Field(default=None, description="Drug name. Required for op=history; optional filter for op=active."),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on event valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on event valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=MED_HISTORY_LIMIT, description="Row cap. Ignored for op=active (one per drug)."),
        ] = MED_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await med_query(
            pipeline=app.med_query,
            tenant_id=tenant_id,
            op=op,
            drug_name=drug_name,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        return {
            "op": response.op,
            "rows": [
                {
                    "episode_uuid": str(r.episode_uuid),
                    "drug_name": r.drug_name,
                    "drug_class": r.drug_class,
                    "dose_value": str(r.dose_value) if r.dose_value is not None else None,
                    "dose_unit": r.dose_unit,
                    "frequency": r.frequency,
                    "route": r.route,
                    "event_kind": r.event_kind,
                    "reason": r.reason,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
                for r in response.rows
            ],
            "count": response.count,
            # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope.
            # Map keyed `c1`, `c2`, … in `rows` order.
            "citations": _serialize_citations(response.citations),
        }

    # ── ADR-0013 / issue #72 — gnokee_query declarative envelope ────────────
    # Isolated registration block. See `src/gnokee/query.py` for the
    # orchestrator; this block only carries the FastMCP tool wrapper +
    # envelope -> dict serialiser.

    @server.tool(
        name="gnokee_query",
        description=(
            "Declarative envelope read (ADR-0013). Single MCP call with "
            "`ask` + bi-temporal range filter + topics + budget + "
            "`confidence_floor`. Returns provenance, the ADR-0016 citation "
            "envelope keyed `c1`, `c2`, …, an ADR-0019 recency-proxy "
            "`confidence` aggregate (NOT a calibrated probability — see "
            "tool-description caveat), and a flat `contradictions[]` list "
            "from ADR-0008. gnokee NEVER auto-resolves contradictions — "
            "both sides are surfaced; the consumer's LLM decides. "
            "`filter.tenant_id` is REQUIRED (federation is a hard non-goal). "
            "`filter.valid_at_range` filters world-time; "
            "`filter.asserted_at_range` filters source-tx-time — gnokee "
            "NEVER exposes `created_at` (ingest-system time) as a filter "
            "axis. Range filtering is implemented as a v0.5 post-recall "
            "filter (push-down into Cypher deferred to v0.5.x). `topics` "
            "(open list — vocabulary: `general`, `clinical.lab`, "
            "`clinical.med`) routes between the underlying pipelines: "
            "`clinical.lab` adds an abnormal-labs lane from `lab_record` "
            "(provenance `source_uri='lab_record'`), `clinical.med` adds "
            "an active-meds lane from `med_record` (`source_uri="
            "'med_record'`) — both compose alongside the recall lane in "
            "the same envelope, with row counts in "
            "`query_telemetry.clinical_lab_rows` / `clinical_med_rows`. "
            "Unknown entries fall through to `general` and surface in "
            "`query_telemetry.unknown_topics[]`. `output_shape: fact | "
            "episode | mixed` reshapes the lanes (`fact` drops body+excerpt "
            "rows; `episode` drops facts). `budget.max_episodes` caps the "
            "provenance list AFTER filters; `budget.max_tokens` maps to "
            "recall's Stage 6 per-lane budget. The `value` field is "
            "RESERVED-but-`null` in v0.5 — gnokee does not host an LLM, "
            "the consumer's LLM synthesises the answer prose from "
            "`provenance` + `citations`. Emit inline `[c1]`, `[c2]`, … "
            "markers in your answer text wherever you state a claim so "
            "the user can back-reference the source episode."
        ),
    )
    async def gnokee_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        ask: Annotated[str, Field(description="Natural-language question.")],
        valid_at_gte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower bound on fact `valid_at`."),
        ] = None,
        valid_at_lte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper bound on fact `valid_at`."),
        ] = None,
        asserted_at_gte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower bound on fact `asserted_at`."),
        ] = None,
        asserted_at_lte: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper bound on fact `asserted_at`."),
        ] = None,
        topics: Annotated[
            list[str] | None,
            Field(
                default=None,
                description=(
                    "Routing hint. v0.5 vocabulary: general, clinical.lab, "
                    "clinical.med. Unknown entries surface in telemetry."
                ),
            ),
        ] = None,
        tenant_scope: Annotated[
            Literal["self"],
            Field(
                default="self",
                description=("Reserved for future federation. v0.5 accepts `self` only — `cross` is a hard non-goal."),
            ),
        ] = "self",
        output_shape: Annotated[
            Literal["fact", "episode", "mixed"],
            Field(default="mixed", description="fact | episode | mixed."),
        ] = "mixed",
        max_episodes: Annotated[
            int,
            Field(
                default=DEFAULT_MAX_EPISODES,
                description="Provenance list cap. Applied after all filters.",
            ),
        ] = DEFAULT_MAX_EPISODES,
        max_tokens: Annotated[
            int,
            Field(
                default=DEFAULT_MAX_TOKENS,
                description="Response token budget. Maps to recall(max_tokens).",
            ),
        ] = DEFAULT_MAX_TOKENS,
        confidence_floor: Annotated[
            float,
            Field(
                default=0.0,
                ge=0.0,
                le=1.0,
                description=(
                    "Minimum age-credibility cutoff. ADR-0019 recency proxy "
                    "(NOT a calibrated probability). Default 0.0."
                ),
            ),
        ] = 0.0,
    ) -> dict[str, Any]:
        # Build the Pydantic envelope from the flat-keyword MCP shape so
        # the JSON-Schema validation runs at the boundary. Bad envelopes
        # raise ValidationError → MCP layer surfaces a structured error.
        valid_range = (
            DateRange(gte=_parse_datetime(valid_at_gte), lte=_parse_datetime(valid_at_lte))
            if (valid_at_gte is not None or valid_at_lte is not None)
            else None
        )
        asserted_range = (
            DateRange(
                gte=_parse_datetime(asserted_at_gte),
                lte=_parse_datetime(asserted_at_lte),
            )
            if (asserted_at_gte is not None or asserted_at_lte is not None)
            else None
        )
        envelope = QueryEnvelope(
            ask=ask,
            filter=QueryEnvelopeFilter(
                tenant_id=tenant_id,
                valid_at_range=valid_range,
                asserted_at_range=asserted_range,
                topics=topics or [],
                tenant_scope=tenant_scope,
            ),
            output_shape=output_shape,
            budget=QueryEnvelopeBudget(max_episodes=max_episodes, max_tokens=max_tokens),
            confidence_floor=confidence_floor,
        )
        response: QueryResponse = await run_gnokee_query(
            recall_pipeline=app.recall,
            lab_pipeline=app.lab_query,
            med_pipeline=app.med_query,
            envelope=envelope,
        )
        return _serialize_query_response(response)

    # ──────────────────────────────────────────────────────────────────────
    # gnokee_wiki_export — ADR-0015 / issue #74. Isolated registration
    # block; no shared mutable state with the tools above. The only
    # construction-site coupling is `app.wiki_export` from bootstrap.py.
    # ──────────────────────────────────────────────────────────────────────

    @server.tool(
        name="gnokee_wiki_export",
        description=(
            "Export a tenant's memory as a markdown wiki (ADR-0015 / issue #74). "
            "Returns synthetic files (`index.md`, `log.md`, `entities/<slug>.md`) "
            "templated from the bi-temporal store — no LLM synthesis, no new "
            "storage. `scope='self'` returns active facts only; `scope='full'` "
            "includes a 'History' section per entity for superseded facts. "
            "`as_of` pins source-tx-time (default: now). When `as_of` precedes "
            "the latest write, v0.5 falls back to the latest snapshot and emits "
            "a header note in `index.md` (issue #73 / ADR-0014 `fact_revision` "
            "table is deferred — true `as_of` history rendering follows). "
            "Output is markdown bytes in the MCP response — gnokee NEVER writes "
            "to a consumer git repo or filesystem on its own. Slug strategy: "
            "human-readable + UUID-derived disambiguation suffix on collision "
            "(stable across calls). Cache invalidation is per-tenant write-clock; "
            "repeated calls with no intervening writes return the cached payload. "
            "Pagination is out of scope for v0.5; very large tenants get the "
            "first 200 episodes in `log.md`."
        ),
    )
    async def gnokee_wiki_export(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        scope: Annotated[
            Literal["self", "full"],
            Field(
                default="self",
                description=(
                    "`self` = active facts only (Current section per entity). "
                    "`full` = include superseded facts (History section per entity)."
                ),
            ),
        ] = "self",
        as_of: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "ISO-8601 UTC source-tx-time pin. Defaults to now. When "
                    "older than the latest write, v0.5 falls back to the "
                    "latest snapshot + emits a header note in `index.md`."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        response = await wiki_export(
            pipeline=app.wiki_export,
            tenant_id=tenant_id,
            scope=scope,
            as_of=_parse_datetime(as_of),
        )
        return {
            "files": [{"path": f.path, "content": f.content} for f in response.files],
            "generated_at": response.generated_at.isoformat(),
            "tenant_id": response.tenant_id,
        }

    # ── ADR-0026 / issue #130 — forget pipeline (destructive; registered last) ──

    @server.tool(
        name="gnokee_forget_episode",
        description=(
            "Hard-delete a single episode (and optionally its supersession descendants) from gnokee "
            "storage. Verifiable: a forget_audit row is persisted in the gnokee_maintenance schema "
            "and survives tenant deletion. If the episode is part of a supersession chain, this tool "
            "REFUSES with 'cannot_forget_chain_node' unless cascade=True is set — DO NOT auto-retry "
            "with cascade=True without explicit operator approval. When the receipt's affected_key_ids "
            "is non-empty, the consumer MUST destroy those DEKs in their KMS to complete cryptographic "
            "erasure (gnokee never holds keys)."
        ),
    )
    async def gnokee_forget_episode(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        episode_uuid: Annotated[str, Field(description="UUID of the episode to hard-delete.")],
        reason: Annotated[
            str,
            Field(
                description=(
                    "Required. Category label only — DO NOT include personal data "
                    "(names, identifiers, diagnoses). Persisted in forget_audit which survives "
                    "tenant deletion."
                ),
            ),
        ],
        cascade: Annotated[
            bool,
            Field(
                default=False,
                description=(
                    "If True, recursively deletes this episode AND all supersession descendants. "
                    "Default False. DO NOT set True without explicit operator approval — permanent "
                    "and irreversible."
                ),
            ),
        ] = False,
        actor: Annotated[
            str | None,
            Field(default=None, description="Optional actor identifier for the audit trail."),
        ] = None,
    ) -> dict[str, Any]:
        try:
            parsed_uuid = UUID(episode_uuid)
        except ValueError as exc:
            raise ValidationError(f"episode_uuid is not a valid UUID: {episode_uuid!r}") from exc
        spec = ForgetEpisodeIn(
            tenant_id=tenant_id,
            episode_uuid=parsed_uuid,
            cascade=cascade,
            reason=reason,
            actor=actor,
        )
        try:
            detail = await forget_episode(
                app,
                tenant_id=spec.tenant_id,
                episode_uuid=spec.episode_uuid,
                cascade=spec.cascade,
                reason=spec.reason,
                actor=spec.actor,
            )
        except CannotForgetChainNode as exc:
            return {
                "error": "cannot_forget_chain_node",
                "descendant_count": exc.descendant_count,
                "deepest_descendant_uuid": exc.deepest_descendant_uuid,
                "hint": (
                    "Use gnokee_history_of(uuid=<target>) to inspect the chain. "
                    "Resubmit with cascade=True only after explicit operator approval — "
                    "this is permanent."
                ),
            }
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                "hint": "Invoke gnokee.maintenance.resume_forget(tenant_id, audit_id) to retry the Neo4j sweep.",
            }
        return ForgetReceipt.model_validate(detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(
            mode="json"
        )

    @server.tool(
        name="gnokee_forget_tenant",
        description=(
            "Hard-delete an entire tenant. Two-call ceremony: dry_run defaults to True and returns "
            "a planned receipt with no writes. Caller MUST issue a SECOND call with dry_run=False to "
            "actually destroy. Affected key_ids surface on the receipt — the consumer destroys those "
            "DEKs in their KMS."
        ),
    )
    async def gnokee_forget_tenant(
        tenant_id: Annotated[str, Field(description="Memory partition to hard-delete. Mandatory.")],
        reason: Annotated[
            str,
            Field(
                description=(
                    "Required. Category label only — DO NOT include personal data. "
                    "Persisted in forget_audit which survives tenant deletion."
                ),
            ),
        ],
        dry_run: Annotated[
            bool,
            Field(
                default=True,
                description=(
                    "DEFAULT TRUE. dry_run=True returns a planned receipt with no writes. "
                    "Issue a SECOND call with dry_run=False to actually destroy the tenant."
                ),
            ),
        ] = True,
        actor: Annotated[
            str | None,
            Field(default=None, description="Optional actor identifier for the audit trail."),
        ] = None,
    ) -> dict[str, Any]:
        spec = ForgetTenantIn(
            tenant_id=tenant_id,
            dry_run=dry_run,
            reason=reason,
            actor=actor,
        )
        try:
            detail = await forget_tenant(
                app,
                tenant_id=spec.tenant_id,
                dry_run=spec.dry_run,
                reason=spec.reason,
                actor=spec.actor,
            )
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                "hint": "Invoke gnokee.maintenance.resume_forget(tenant_id, audit_id) to retry the Neo4j sweep.",
            }
        return ForgetReceipt.model_validate(detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(
            mode="json"
        )

    return server


def _serialize_query_response(response: QueryResponse) -> dict[str, Any]:
    """Serialise `QueryResponse` to the MCP wire envelope.

    Kept as a free helper so the wire shape is co-located with the
    citation serialiser. UUIDs → strings; datetimes → ISO-8601; the
    citation map is delegated to `_serialize_citations` to keep the
    `[cN]` ordering invariant in a single place.
    """
    telemetry = response.query_telemetry
    return {
        # ADR-0013 § value field — `null` in v0.5 (no LLM hosting). Kept
        # on the wire so future hosts can populate it without a schema bump.
        "value": response.value,
        "provenance": [
            {
                "episode_uuid": str(p.episode_uuid),
                "fact_uuid": str(p.fact_uuid) if p.fact_uuid is not None else None,
                "valid_at": p.valid_at.isoformat(),
                "asserted_at": p.asserted_at.isoformat(),
                "source_uri": p.source_uri,
                "score": p.score,
            }
            for p in response.provenance
        ],
        "confidence": response.confidence,
        "contradictions": [
            {
                "episode_a": str(c.episode_a),
                "episode_b": str(c.episode_b),
                "fact_a": str(c.fact_a),
                "fact_b": str(c.fact_b),
                "verdict": c.verdict,
                "axis": c.axis,
                "summary": c.summary,
            }
            for c in response.contradictions
        ],
        "citations": _serialize_citations(response.citations),
        "query_telemetry": {
            "topic": telemetry.topic,
            "max_episodes": telemetry.max_episodes,
            "max_tokens": telemetry.max_tokens,
            "facts_considered": telemetry.facts_considered,
            "facts_after_floor": telemetry.facts_after_floor,
            "facts_after_range": telemetry.facts_after_range,
            "confidence_floor": telemetry.confidence_floor,
            "recall_telemetry": telemetry.recall_telemetry.model_dump(),
            "post_recall_filter": telemetry.post_recall_filter,
            "unknown_topics": list(telemetry.unknown_topics),
            "clinical_lab_rows": telemetry.clinical_lab_rows,
            "clinical_med_rows": telemetry.clinical_med_rows,
        },
    }


async def _async_main() -> None:
    settings = Settings()
    app = await build_app(settings)
    server = build_server(app)
    transport: Literal["stdio", "streamable-http"] = "streamable-http" if settings.mcp_http else "stdio"
    try:
        if transport == "streamable-http":
            await server.run_streamable_http_async()
        else:
            await server.run_stdio_async()
    finally:
        await shutdown_app(app)


def _cli_main() -> None:
    from gnokee.logging import configure as configure_logging

    configure_logging(os.environ.get("GNOKEE_LOG_LEVEL", "info"))
    try:
        asyncio.run(_async_main())
    except (GnokeeError, KeyboardInterrupt) as exc:
        log.error("gnokee mcp exit: %s", exc)


__all__ = ["_cli_main", "build_server"]


if __name__ == "__main__":
    _cli_main()
