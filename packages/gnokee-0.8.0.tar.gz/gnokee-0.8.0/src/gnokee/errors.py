"""src/gnokee/errors.py — Typed exception hierarchy.

exports: class GnokeeError | class ValidationError | class EmbeddingsUnavailable | class GraphStoreError | class VectorStoreError | class LLMUnavailable | class NotImplementedYet | class CorrectsError | class EpisodeNotFoundError | class CorrectsCrossTenantError | class CorrectsAxisInversionError | class CorrectsChainError | class CannotForgetChainNode | class ForgetContention | class ForgetNeo4jPartial
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/storage/* | src/gnokee/embeddings.py | src/gnokee/llm.py | src/gnokee/contradiction.py | src/gnokee/mcp.py | src/gnokee/forget.py
rules:   raise typed; never bare Exception in src/gnokee
agent:   claude-opus-4-7 | 2026-05-09 | v0.2.1 ADR-0009/0010 corrects: signal
         claude-haiku-4-5 | 2026-05-16 | issue #130 ADR-0026 forget exceptions
"""

from __future__ import annotations

from uuid import UUID


class GnokeeError(Exception):
    """Base class for all gnokee-raised exceptions."""


class ValidationError(GnokeeError):
    """Bad input (e.g. naive datetime, missing tenant_id)."""


class EmbeddingsUnavailable(GnokeeError):
    """TEI / embedding endpoint is unreachable or returning errors."""


class GraphStoreError(GnokeeError):
    """Graphiti / Neo4j fault during read or write."""


class VectorStoreError(GnokeeError):
    """Postgres / pgvector fault during read or write."""


class LLMUnavailable(GnokeeError):
    """OpenAI-compatible LLM endpoint is unreachable; ingest may degrade."""


class NotImplementedYet(GnokeeError):
    """Feature is on the v0.2+ roadmap; not yet wired in v0.1."""


class CorrectsError(VectorStoreError):
    """Base for ``EpisodeIn.corrects:`` validation failures (Stage 6 txn-scope).

    Subclasses derive from ``VectorStoreError`` so the existing
    ``IngestPipeline.ingest`` compensate path catches them and rolls
    back the Graphiti episode created at Stage 4.
    """


class EpisodeNotFoundError(CorrectsError):
    """Raised when ``corrects`` targets an episode_uuid not in episode_metadata."""

    def __init__(self, episode_uuid: UUID) -> None:
        super().__init__(f"corrects: episode {episode_uuid} not found")
        self.episode_uuid = episode_uuid


class CorrectsCrossTenantError(CorrectsError):
    """Raised when ``corrects`` targets a different tenant_id."""


class CorrectsAxisInversionError(CorrectsError):
    """Raised when new asserted_at <= corrected.asserted_at.

    Bi-temporal axis integrity: a correction is always learned-later
    in tx-time than the row it corrects.
    """


class CorrectsChainError(CorrectsError):
    """Raised when ``superseded_by`` walk exceeds bounded depth.

    Distinct from ``CorrectsAxisInversionError`` — cycle / runaway
    chain is a structural invariant, not a tx-time inversion. Callers
    and log parsers must be able to tell them apart.
    """


class CannotForgetChainNode(GnokeeError):
    """Refusal raised when a target episode has supersession descendants
    and the caller did not pass `cascade=True`. Surfaces a bounded payload
    (count + tail UUID) — never inlines the full descendant list."""

    def __init__(self, *, descendant_count: int, deepest_descendant_uuid: str) -> None:
        self.descendant_count = descendant_count
        self.deepest_descendant_uuid = deepest_descendant_uuid
        super().__init__(
            f"Episode is corrected by {descendant_count} descendant(s); "
            f"deepest tail = {deepest_descendant_uuid}. "
            "Resubmit with cascade=True only after explicit operator approval — "
            "this is permanent and irreversible."
        )


class ForgetContention(GnokeeError):
    """Postgres serializable retry budget exhausted under concurrent ingest."""


class ForgetNeo4jPartial(GnokeeError):
    """Postgres sweep committed; Neo4j sweep failed. Carries the audit_id
    so the caller can invoke `gnokee.maintenance.resume_forget` for retry."""

    def __init__(self, *, audit_id: str, cause: BaseException) -> None:
        self.audit_id = audit_id
        super().__init__(
            f"Postgres sweep committed (audit_id={audit_id}); Neo4j sweep failed. "
            f"Invoke gnokee.maintenance.resume_forget(audit_id=...) to retry."
        )
        self.__cause__ = cause
