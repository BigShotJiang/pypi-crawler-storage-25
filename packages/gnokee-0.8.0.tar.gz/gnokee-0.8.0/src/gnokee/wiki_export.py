"""src/gnokee/wiki_export.py — Markdown wiki export (ADR-0015, issue #74).

Templated markdown view of a tenant's memory. Pure derivation layer over
`MetadataStore` + `GraphitiStore` reads — no new storage, no LLM calls,
no auto-resolve. Karpathy LLM Wiki pattern (2026-04-04 gist) adapted to
gnokee's multi-tenant, bi-temporal model.

Synthetic files emitted:

* ``index.md`` — entity list, one link per top-level entity.
* ``log.md`` — episode summaries newest-first.
* ``entities/<slug>.md`` — one page per entity with Current + History
  sections and source-episode citation handles (reuse ADR-0016 shape).

Cache invalidation: per-tenant write-clock. The pipeline memoises
rendered payloads keyed on ``(tenant_id, scope, as_of_iso)``; on the next
call we read ``MetadataStore.latest_write_clock(tenant_id)`` and skip
re-render iff the cached ``generated_at`` >= the clock. Cache lives in
the pipeline instance (per-process) — promotion to a persistent cache is
a follow-up.

Slug strategy: human-readable + UUID disambiguation suffix on collision.
``Metoprolol Succinate ER`` → ``metoprolol-succinate-er``; on collision
within a single export, an 8-char hex suffix derived from the entity
UUID is appended so the slug stays stable across calls.

``as_of`` past timestamp: v0.5 falls back to the latest snapshot when
``fact_revision`` is unavailable (ADR-0014 / issue #73 deferred) AND the
cache write-clock indicates newer writes exist. The fallback emits a
header note in ``index.md`` so the caller sees the degradation.

exports: WikiExportPipeline | WikiExportResponse | WikiFile | wiki_export
used_by: src/gnokee/mcp.py
rules:   tenant_id mandatory on every read; group_id partitions Graphiti;
         markdown bytes are output — gnokee NEVER writes to consumer disk;
         no LLM synthesis — text comes from FactRow.text + entity names;
         no "knowledge engine" branding in copy
agent:   claude-opus-4-7 | 2026-05-11 | issue #74 / ADR-0015 wiki export
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.storage.graph import EntityFactRow, EntitySummary, GraphitiStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

# Cap on episodes surfaced in `log.md` so the response stays inside the
# MCP envelope. Per-tenant write rate beyond this threshold means the
# wiki view degrades to the most recent N episodes — pagination lands
# in v0.6+ (see ADR-0015 § Open questions deferred).
_LOG_EPISODE_CAP = 200
# Cap on log-line content snippet so a single multi-kilobyte episode body
# does not crowd the rest of the log.
_LOG_SNIPPET_CHARS = 200

# Slug regex — lowercase ASCII, collapse non-alphanumerics to single
# hyphen, strip leading / trailing hyphens.
_SLUG_NORMALISE = re.compile(r"[^a-z0-9]+")


class WikiFile(BaseModel):
    """One markdown file in the wiki export response.

    `path` is the in-archive path the consumer would write to (e.g.
    `index.md`, `log.md`, `entities/metoprolol.md`). `content` is the
    rendered markdown bytes. gnokee NEVER writes to consumer disk —
    persisting the file is the consumer's choice.
    """

    model_config = ConfigDict(frozen=True)

    path: str = Field(min_length=1)
    content: str


class WikiExportResponse(BaseModel):
    """Output of `gnokee.wiki_export.wiki_export(...)`.

    `files` is the list of synthetic markdown files. `generated_at`
    carries the source-tx-time the export rendered at (used both for the
    response timestamp and for the per-tenant cache write-clock).
    `tenant_id` echoes the caller's input so a host that batches
    multiple tenants can route the response.
    """

    model_config = ConfigDict(frozen=True)

    files: list[WikiFile] = Field(default_factory=list)
    generated_at: datetime
    tenant_id: str


@dataclass
class _CacheEntry:
    """In-process per-tenant cache entry. Keyed on (scope, as_of_iso)."""

    generated_at: datetime
    response: WikiExportResponse


@dataclass
class WikiExportPipeline:
    """Wiki export pipeline. One per process — caches per tenant.

    Construction site: `gnokee.bootstrap`. Reads only — never writes to
    the graph or the metadata store. Cache is per-process and in-memory;
    a future follow-up can promote it to Postgres if multi-process
    deployment warrants.
    """

    graph: GraphitiStore
    metadata: MetadataStore
    # Per-tenant cache: (scope, as_of_iso) → entry. Cleared whenever
    # `MetadataStore.latest_write_clock(tenant_id)` exceeds the cached
    # `generated_at`. v0.5 in-process; not concurrent-safe across
    # processes (acceptable for v0.5; see ADR-0015).
    _cache: dict[str, dict[tuple[str, str], _CacheEntry]] = field(default_factory=dict)

    async def export(
        self,
        *,
        tenant_id: str,
        scope: str = "self",
        as_of: datetime | None = None,
    ) -> WikiExportResponse:
        if not tenant_id:
            raise ValidationError("tenant_id required")
        if scope not in ("self", "full"):
            raise ValidationError(f"scope must be 'self' or 'full', got {scope!r}")

        as_of_eff = _ensure_utc(as_of) or utc_now()
        valid_eff = as_of_eff  # wiki view is anchored on as_of for both axes
        cache_key = (scope, as_of_eff.isoformat())

        # Per-tenant write-clock cache check.
        write_clock = await self.metadata.latest_write_clock(tenant_id=tenant_id)
        tenant_cache = self._cache.get(tenant_id)
        if tenant_cache is not None:
            cached = tenant_cache.get(cache_key)
            if cached is not None and write_clock is not None and cached.generated_at >= write_clock:
                return cached.response

        # `as_of` history fallback note — emitted when the caller asks
        # for a past `as_of` newer than the most recent write would
        # have rendered. v0.5 lacks `fact_revision` (issue #73 deferred),
        # so we fall back to the current snapshot. The note lives in
        # `index.md`'s header so the consumer sees the degradation.
        as_of_history_unavailable = write_clock is not None and as_of_eff < write_clock and as_of is not None

        include_superseded = scope == "full"
        episodes = await self.metadata.list_episodes_for_tenant(
            tenant_id=tenant_id,
            as_of=as_of_eff,
            valid_at=valid_eff,
            include_superseded=include_superseded,
            limit=_LOG_EPISODE_CAP,
        )
        entities = await self.graph.list_entities_for_tenant(
            tenant_id=tenant_id,
            valid_at=valid_eff,
        )

        # Resolve slugs up front so cross-file links stay consistent.
        slug_map = _build_slug_map(entities)

        # Per-entity facts — batched but sequential to keep the Cypher
        # plan simple. Tenant cap on entities means N is bounded.
        entity_facts: dict[UUID, list[EntityFactRow]] = {}
        for entity in entities:
            rows = await self.graph.fetch_facts_for_entity(
                tenant_id=tenant_id,
                entity_uuid=entity.entity_uuid,
                valid_at=valid_eff,
            )
            entity_facts[entity.entity_uuid] = rows

        files: list[WikiFile] = []
        files.append(
            WikiFile(
                path="index.md",
                content=_render_index(
                    tenant_id=tenant_id,
                    entities=entities,
                    slug_map=slug_map,
                    generated_at=as_of_eff,
                    scope=scope,
                    as_of_history_unavailable=as_of_history_unavailable,
                ),
            )
        )
        files.append(
            WikiFile(
                path="log.md",
                content=_render_log(
                    tenant_id=tenant_id,
                    episodes=episodes,
                    generated_at=as_of_eff,
                    scope=scope,
                ),
            )
        )
        for entity in entities:
            files.append(
                WikiFile(
                    path=f"entities/{slug_map[entity.entity_uuid]}.md",
                    content=_render_entity(
                        entity=entity,
                        facts=entity_facts.get(entity.entity_uuid, []),
                        slug_map=slug_map,
                        as_of=as_of_eff,
                        scope=scope,
                    ),
                )
            )

        response = WikiExportResponse(
            files=files,
            generated_at=as_of_eff,
            tenant_id=tenant_id,
        )
        # Cache the rendered payload.
        if tenant_cache is None:
            tenant_cache = {}
            self._cache[tenant_id] = tenant_cache
        tenant_cache[cache_key] = _CacheEntry(generated_at=as_of_eff, response=response)
        return response


def _ensure_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        raise ValidationError("wiki_export datetimes must be tz-aware UTC")
    return value


def _slugify(name: str) -> str:
    """Human-readable slug. ADR-0015 § slug strategy.

    Lowercase the display name, collapse runs of non-alphanumeric chars
    into a single hyphen, strip leading / trailing hyphens. Returns
    ``"unnamed"`` for an empty result so the slug stays addressable.
    """
    base = _SLUG_NORMALISE.sub("-", name.lower()).strip("-")
    return base or "unnamed"


def _disambiguate(base_slug: str, entity_uuid: UUID) -> str:
    """Collision suffix — first 8 hex chars of the entity UUID.

    Stable across calls because the suffix derives from the entity UUID,
    not a positional counter. Two entities with the same display name in
    the same tenant get distinct slugs without renaming either.
    """
    return f"{base_slug}-{entity_uuid.hex[:8]}"


def _build_slug_map(entities: list[EntitySummary]) -> dict[UUID, str]:
    """Map entity UUIDs → unique slugs.

    First pass renders the human-readable base slug; collisions inside
    the same tenant get a UUID-derived suffix.
    """
    base_assignments: dict[UUID, str] = {entity.entity_uuid: _slugify(entity.name) for entity in entities}
    # Count base slugs to detect collisions.
    counts: dict[str, int] = {}
    for slug in base_assignments.values():
        counts[slug] = counts.get(slug, 0) + 1
    final: dict[UUID, str] = {}
    for entity_uuid, base_slug in base_assignments.items():
        if counts.get(base_slug, 0) > 1:
            final[entity_uuid] = _disambiguate(base_slug, entity_uuid)
        else:
            final[entity_uuid] = base_slug
    return final


def _md_escape(text: str) -> str:
    """Escape characters that confuse markdown renderers in headings / links.

    Conservative: backslash-escape `[`, `]`, `(`, `)`. Full markdown
    escaping is unnecessary because we control the surrounding template
    structure and only render user-supplied text inside paragraph bodies
    and link labels.
    """
    return text.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")


def _render_index(
    *,
    tenant_id: str,
    entities: list[EntitySummary],
    slug_map: dict[UUID, str],
    generated_at: datetime,
    scope: str,
    as_of_history_unavailable: bool,
) -> str:
    """Render `index.md` — entity list + header metadata."""
    lines: list[str] = [
        "# gnokee memory",
        "",
        f"- tenant_id: `{tenant_id}`",
        f"- generated_at: `{generated_at.isoformat()}`",
        f"- scope: `{scope}`",
        "",
    ]
    if as_of_history_unavailable:
        # ADR-0015 § `as_of` past timestamp fallback note.
        lines.extend(
            [
                "> Note: `as_of` history reads are not yet available in this "
                "version (issue #73 / ADR-0014 deferred). The wiki view "
                "below reflects the latest snapshot at render time.",
                "",
            ]
        )
    lines.extend(
        [
            "## Entities",
            "",
        ]
    )
    if not entities:
        lines.append("_No entities yet._")
    else:
        for entity in entities:
            slug = slug_map[entity.entity_uuid]
            label = _md_escape(entity.name or "(unnamed)")
            lines.append(f"- [{label}](entities/{slug}.md)")
    lines.extend(["", "## Log", "", "- [Episode log](log.md)", ""])
    return "\n".join(lines)


def _render_log(
    *,
    tenant_id: str,
    episodes: list[EpisodeMetadataRow],
    generated_at: datetime,
    scope: str,
) -> str:
    """Render `log.md` — episode summaries newest-first.

    One row per episode: bi-temporal axes + a short snippet from
    `content_text` (when present) so the consumer's LLM has a quick
    preview without round-tripping to `gnokee_fact_provenance`.
    """
    lines: list[str] = [
        "# Episode log",
        "",
        f"- tenant_id: `{tenant_id}`",
        f"- generated_at: `{generated_at.isoformat()}`",
        f"- scope: `{scope}`",
        "",
    ]
    if not episodes:
        lines.append("_No episodes yet._")
        return "\n".join(lines) + "\n"
    for episode in episodes:
        snippet = (episode.content_text or "").strip()
        if len(snippet) > _LOG_SNIPPET_CHARS:
            snippet = snippet[:_LOG_SNIPPET_CHARS].rstrip() + "…"
        snippet_md = _md_escape(snippet) if snippet else "_(empty body)_"
        superseded_marker = " *(superseded)*" if episode.asserted_until is not None else ""
        lines.extend(
            [
                f"## `{episode.episode_uuid}`{superseded_marker}",
                "",
                f"- valid_at: `{episode.valid_at.isoformat()}`",
                f"- asserted_at: `{episode.asserted_at.isoformat()}`",
            ]
        )
        if episode.asserted_until is not None:
            lines.append(f"- asserted_until: `{episode.asserted_until.isoformat()}`")
        if episode.our_id is not None:
            lines.append(f"- our_id: `{episode.our_id}`")
        lines.extend(
            [
                "",
                snippet_md,
                "",
            ]
        )
    return "\n".join(lines)


def _render_entity(
    *,
    entity: EntitySummary,
    facts: list[EntityFactRow],
    slug_map: dict[UUID, str],
    as_of: datetime,
    scope: str,
) -> str:
    """Render `entities/<slug>.md` — Current + History sections.

    Current = open edges (`invalid_at` is None) at `as_of`.
    History = closed edges (`invalid_at <= as_of`) — only emitted when
    `scope=full`.

    Each fact line carries the source episode handle so the consumer's
    LLM can back-reference it via the ADR-0016 citation envelope
    delivered by other tools (`gnokee_recall`, `gnokee_fact_provenance`).
    """
    name = entity.name or "(unnamed)"
    lines: list[str] = [
        f"# {_md_escape(name)}",
        "",
        f"- entity_uuid: `{entity.entity_uuid}`",
        f"- as_of: `{as_of.isoformat()}`",
        f"- scope: `{scope}`",
        "",
        "## Current",
        "",
    ]
    current = [f for f in facts if f.invalid_at is None or f.invalid_at > as_of]
    history = [f for f in facts if f.invalid_at is not None and f.invalid_at <= as_of]
    if not current:
        lines.append("_No active facts._")
        lines.append("")
    else:
        for fact in current:
            lines.append(_render_fact_line(fact, slug_map))
        lines.append("")
    if scope == "full":
        lines.append("## History")
        lines.append("")
        if not history:
            lines.append("_No superseded facts._")
            lines.append("")
        else:
            for fact in history:
                lines.append(_render_fact_line(fact, slug_map, superseded=True))
            lines.append("")
    return "\n".join(lines)


def _render_fact_line(
    fact: EntityFactRow,
    slug_map: dict[UUID, str],
    *,
    superseded: bool = False,
) -> str:
    """One bullet-list line per fact, with a source-episode handle.

    The handle reuses the ADR-0016 citation shape concept: bi-temporal
    axes (`valid_at`, plus `invalid_at` when closed) and the episode
    UUID. We render the OTHER endpoint as a slug-link when we have one
    so the wiki cross-links between entity pages.
    """
    other_slug = slug_map.get(fact.other_entity_uuid)
    if other_slug is None:
        other_label = _md_escape(fact.other_entity_name or "(unknown)")
        other_md = f"**{other_label}**"
    else:
        other_label = _md_escape(fact.other_entity_name or "(unnamed)")
        other_md = f"[{other_label}]({other_slug}.md)"
    suffix = " *(superseded)*" if superseded else ""
    invalid_part = ""
    if fact.invalid_at is not None:
        invalid_part = f", invalid_at=`{fact.invalid_at.isoformat()}`"
    return (
        f"- {_md_escape(fact.fact_text)} (→ {other_md}) "
        f"[episode=`{fact.episode_uuid}`, "
        f"valid_at=`{fact.valid_at.isoformat()}`"
        f"{invalid_part}]{suffix}"
    )


async def wiki_export(
    *,
    pipeline: WikiExportPipeline,
    tenant_id: str,
    scope: str = "self",
    as_of: datetime | None = None,
) -> WikiExportResponse:
    """Public coroutine wrapper around the pipeline."""
    return await pipeline.export(tenant_id=tenant_id, scope=scope, as_of=as_of)


wiki_export.__module__ = __name__


__all__ = [
    "WikiExportPipeline",
    "WikiExportResponse",
    "WikiFile",
    "wiki_export",
]
