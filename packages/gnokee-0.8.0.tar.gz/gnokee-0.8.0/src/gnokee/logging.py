"""src/gnokee/logging.py — structured-logging configuration.

JSON output. Always include: tenant_id, episode_uuid (when applicable),
latency_ms, stage. Never include: content, embedding vectors, LLM prompts.

exports: configure | get_logger
used_by: src/gnokee/mcp.py | src/gnokee/demo.py
rules:   v0.1 = stdlib + structlog; metrics + OTel are v0.2
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
from typing import Any

import structlog


def configure(level: str = "info") -> None:
    """Configure structlog → stdlib bridge with JSON output."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(message)s",
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO),
        ),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str | None = None) -> Any:
    return structlog.get_logger(name)


__all__ = ["configure", "get_logger"]
