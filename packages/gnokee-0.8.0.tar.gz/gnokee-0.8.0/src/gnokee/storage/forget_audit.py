"""src/gnokee/storage/forget_audit.py — gnokee_maintenance.forget_audit CRUD.

Pure async helpers over the audit table introduced by migration 0017.
The pipeline (src/gnokee/forget.py) is the only caller for INSERT /
UPDATE; maintenance.resume_forget reads via find_resumable.

exports: ForgetAuditRow | insert_begin | mark_commit | mark_fail | find_resumable | find_failed_neo4j_rows | find_prior_commit
used_by: src/gnokee/forget.py | src/gnokee/maintenance.py
rules:   tenant_id on every read/write; no RLS (schema-isolated); tz-aware UTC
agent:   claude-sonnet-4-6 | 2026-05-16 | issue #130 ADR-0026 impl
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg

Scope = Literal["episode", "tenant"]


@dataclass(frozen=True, slots=True)
class ForgetAuditRow:
    audit_id: UUID
    tenant_id: str
    scope: Scope
    episode_uuid: UUID | None
    cascade: bool
    dry_run: bool
    state: Literal["begin", "commit", "fail"]
    reason: str
    actor: str | None
    receipt: dict[str, Any] | None
    error: dict[str, Any] | None
    cascade_uuids: list[str] | None
    bitemporal_snap: list[dict[str, Any]] | None
    started_at: datetime
    finished_at: datetime | None


async def insert_begin(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
    cascade: bool,
    dry_run: bool,
    reason: str,
    actor: str | None,
    cascade_uuids: list[str] | None,
    bitemporal_snap: list[dict[str, Any]] | None,
) -> UUID:
    """INSERT a state='begin' row. Returns the generated `audit_id`.

    Caller MUST run this inside an open transaction it controls (so the
    audit-begin row commits atomically with the Postgres sweep). The
    pool acquire here is for code-locality only; the caller wires the
    connection via `pool.acquire()` itself in the forget pipeline.
    """
    sql = """
        INSERT INTO gnokee_maintenance.forget_audit
            (tenant_id, scope, episode_uuid, cascade, dry_run, state,
             reason, actor, cascade_uuids, bitemporal_snap)
        VALUES
            ($1, $2, $3, $4, $5, 'begin', $6, $7, $8, $9)
        RETURNING audit_id;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            sql,
            tenant_id,
            scope,
            episode_uuid,
            cascade,
            dry_run,
            reason,
            actor,
            json.dumps(cascade_uuids) if cascade_uuids is not None else None,
            json.dumps(bitemporal_snap) if bitemporal_snap is not None else None,
        )
    assert row is not None
    return cast(UUID, row["audit_id"])


async def mark_commit(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    receipt: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'commit',
               receipt = $2,
               finished_at = now()
         WHERE audit_id = $1 AND state IN ('begin', 'fail');
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(receipt))


async def mark_fail(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    error: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'fail',
               error = $2,
               finished_at = now()
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(error))


async def find_resumable(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    """Return state='begin' rows for tenant, oldest-first.

    'fail' rows are surfaced separately via find_failed_neo4j_rows;
    resume_forget consumes both lists.
    """
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'begin'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_failed_neo4j_rows(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'fail'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_prior_commit(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
) -> ForgetAuditRow | None:
    """Idempotency helper. Returns the most-recent 'commit' row that
    matches the (tenant, scope, episode_uuid) lookup, or None."""
    if scope == "episode":
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'episode' AND episode_uuid = $2
               AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params: tuple[Any, ...] = (tenant_id, episode_uuid)
    else:
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'tenant' AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params = (tenant_id,)
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, *params)
    return _row(row) if row else None


def _row(r: asyncpg.Record) -> ForgetAuditRow:
    return ForgetAuditRow(
        audit_id=r["audit_id"],
        tenant_id=r["tenant_id"],
        scope=r["scope"],
        episode_uuid=r["episode_uuid"],
        cascade=r["cascade"],
        dry_run=r["dry_run"],
        state=r["state"],
        reason=r["reason"],
        actor=r["actor"],
        receipt=json.loads(r["receipt"]) if r["receipt"] else None,
        error=json.loads(r["error"]) if r["error"] else None,
        cascade_uuids=json.loads(r["cascade_uuids"]) if r["cascade_uuids"] else None,
        bitemporal_snap=json.loads(r["bitemporal_snap"]) if r["bitemporal_snap"] else None,
        started_at=r["started_at"],
        finished_at=r["finished_at"],
    )
