"""src/gnokee/storage/migrate.py — Raw-SQL migration runner.

One-shot runner. Applies every NNNN_*.sql file in order, idempotently.
Tracks applied migrations in `gnokee_schema_migrations`.

exports: discover_migrations | apply | _applied_migrations | _cli_main
used_by: tests/integration | gnokee.demo
rules:   per ADR-0006 raw SQL only; no alembic
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

import asyncpg

from gnokee.config import Settings
from gnokee.errors import VectorStoreError

log = logging.getLogger(__name__)

MIGRATIONS_DIR = Path(__file__).parent / "migrations"

CREATE_MIGRATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS gnokee_schema_migrations (
    name        TEXT PRIMARY KEY,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""


def discover_migrations(directory: Path) -> list[Path]:
    """Return *.sql files in `directory` sorted by name (lexicographic)."""
    if not directory.is_dir():
        raise VectorStoreError(f"migrations directory not found: {directory}")
    return sorted(p for p in directory.iterdir() if p.is_file() and p.suffix == ".sql")


async def _applied_migrations(conn: asyncpg.Connection) -> set[str]:
    rows = await conn.fetch("SELECT name FROM gnokee_schema_migrations")
    return {r["name"] for r in rows}


async def apply(dsn: str, directory: Path = MIGRATIONS_DIR) -> list[str]:
    """Apply every pending migration. Returns names applied this call."""
    migrations = discover_migrations(directory)
    applied: list[str] = []
    conn = await asyncpg.connect(dsn)
    try:
        await conn.execute(CREATE_MIGRATIONS_TABLE)
        already = await _applied_migrations(conn)
        for path in migrations:
            if path.name in already:
                continue
            sql = path.read_text(encoding="utf-8")
            async with conn.transaction():
                await conn.execute(sql)
                await conn.execute(
                    "INSERT INTO gnokee_schema_migrations (name) VALUES ($1)",
                    path.name,
                )
            log.info("applied migration: %s", path.name)
            applied.append(path.name)
    finally:
        await conn.close()
    return applied


def _cli_main() -> None:
    settings = Settings()
    assert settings.pg_dsn is not None  # resolved by model_validator
    applied = asyncio.run(apply(settings.pg_dsn))
    if not applied:
        print("no pending migrations", file=sys.stderr)
        return
    for name in applied:
        print(f"applied: {name}")


if __name__ == "__main__":
    _cli_main()
