"""src/gnokee/storage/contradictions.py — fact_contradiction adapter (per ADR-0008).

Stored in pg because Neo4j cannot connect a relationship to another
relationship. Keys on (tenant_id, fact_uuid_a, fact_uuid_b). Symmetric
pair lookup via UNION ALL.

exports: class ContradictionStore | ContradictionRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/contradiction.py
rules:   tenant_id on every read+write; verdict in {refinement,update,contradiction}
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError
from gnokee.models import Verdict


@dataclass(frozen=True)
class ContradictionRow:
    tenant_id: str
    fact_uuid_a: UUID
    fact_uuid_b: UUID
    verdict: Verdict
    detected_at: datetime
    summary_a: str
    summary_b: str


@dataclass(frozen=True)
class CounterpartFact:
    """Result row from `lookup_counterparts`. The OTHER side of a contradiction."""

    fact_uuid: UUID
    verdict: Verdict
    summary: str


class ContradictionStore:
    """Async wrapper around `fact_contradiction`."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write(self, row: ContradictionRow) -> None:
        try:
            async with self._pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO fact_contradiction (
                        tenant_id, fact_uuid_a, fact_uuid_b,
                        verdict, detected_at, summary_a, summary_b
                    ) VALUES ($1,$2,$3,$4,$5,$6,$7)
                    ON CONFLICT (tenant_id, fact_uuid_a, fact_uuid_b) DO NOTHING
                    """,
                    row.tenant_id,
                    row.fact_uuid_a,
                    row.fact_uuid_b,
                    row.verdict,
                    row.detected_at,
                    row.summary_a,
                    row.summary_b,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"contradiction.write failed: {exc}") from exc

    async def lookup_counterparts(
        self,
        *,
        tenant_id: str,
        fact_uuids: list[UUID],
    ) -> dict[UUID, list[CounterpartFact]]:
        """For each input fact_uuid, find counterpart facts via symmetric UNION."""
        if not fact_uuids:
            return {}
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT fact_uuid_a AS source, fact_uuid_b AS counterpart, verdict, summary_b AS summary
                      FROM fact_contradiction
                     WHERE tenant_id = $1 AND fact_uuid_a = ANY($2::uuid[])
                    UNION ALL
                    SELECT fact_uuid_b AS source, fact_uuid_a AS counterpart, verdict, summary_a AS summary
                      FROM fact_contradiction
                     WHERE tenant_id = $1 AND fact_uuid_b = ANY($2::uuid[])
                    """,
                    tenant_id,
                    fact_uuids,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"contradiction.lookup failed: {exc}") from exc

        out: dict[UUID, list[CounterpartFact]] = {}
        for r in rows:
            out.setdefault(r["source"], []).append(
                CounterpartFact(
                    fact_uuid=r["counterpart"],
                    verdict=r["verdict"],
                    summary=r["summary"],
                )
            )
        return out
