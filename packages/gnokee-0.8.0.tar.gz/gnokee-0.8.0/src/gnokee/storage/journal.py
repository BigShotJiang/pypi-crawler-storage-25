"""src/gnokee/storage/journal.py — ingest crash-recovery journal (ADR-0024 / issue #122).

Append-only Postgres replay log for the Stage 4 -> Stage 5 boundary of
``IngestPipeline.ingest()``. One ``begin`` row is written after Stage 3.5
(``episode_uuid`` known) and before Stage 4 (lite-Episodic Neo4j MERGE);
one ``commit`` row is written after the Stage 5 Postgres txn returns.
``fail`` rows are written on unhandled exceptions, after Stage 4
compensation. Resume is opt-in via
:func:`gnokee.maintenance.resume_ingest`; gnokee never auto-replays.

exports: IngestJournal | ResumableEntry | payload_hash | IngestJournalError | get_resumable | episode_state
used_by: src/gnokee/ingest.py | src/gnokee/maintenance.py
rules:   tenant_id on every write; RLS via app.current_tenant GUC;
         append-only — no UPDATE/DELETE; tz-aware UTC timestamps
agent:   claude-opus-4-7 | 2026-05-16 | issue #122 ADR-0024 impl
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.errors import GnokeeError


class IngestJournalError(GnokeeError):
    """Raised when a journal precondition is violated.

    Examples: ``write_commit`` called without a matching ``begin`` row,
    or ``resume_ingest`` invoked with a payload whose hash does not match
    the journaled ``begin``.
    """


@dataclass(frozen=True, slots=True)
class ResumableEntry:
    """One 'begin' row that has not yet been matched by a 'commit' row.

    Doubles as the handle returned by :meth:`IngestJournal.write_begin`
    and consumed by :meth:`IngestJournal.write_commit` /
    :meth:`IngestJournal.write_fail` — keeps caller-side state explicit
    and avoids an extra ``SELECT`` per commit.
    """

    tenant_id: str
    our_id: str | None
    episode_uuid: UUID
    payload_hash: str
    stage_4_time: datetime
    created_at: datetime


def payload_hash(tenant_id: str, our_id: str | None, valid_at: datetime) -> str:
    """SHA-256 over ``(tenant_id || our_id || valid_at)`` per ADR-0024.

    Used to detect consumer payload drift on resume — if the consumer
    re-supplies an ``EpisodeIn`` whose hash differs from the journaled
    ``begin`` row, :func:`gnokee.maintenance.resume_ingest` refuses to
    proceed.

    ``our_id`` may be NULL (mirrors ``episode_metadata``). NULL is
    encoded with a leading ``N`` tag byte, present values with a
    leading ``V`` tag, so ``None``, ``""``, and ``"\\x00"`` all hash to
    distinct digests.

    ``valid_at`` MUST be timezone-aware. A naive datetime would produce
    a different ISO string than the consumer's re-supplied UTC-aware
    datetime on resume, surfacing as a misleading "payload drift"
    error. Assert at the boundary instead.
    """
    if valid_at.tzinfo is None:
        raise IngestJournalError(
            "payload_hash: valid_at must be timezone-aware (UTC); "
            "naive datetimes are rejected at the EpisodeIn boundary."
        )
    sep = b"\x1f"  # ASCII unit separator — not legal in tenant/our_id
    parts: list[bytes] = [tenant_id.encode("utf-8"), sep]
    if our_id is None:
        parts.append(b"N")
    else:
        parts.append(b"V")
        parts.append(our_id.encode("utf-8"))
    parts.append(sep)
    parts.append(valid_at.isoformat().encode("utf-8"))
    return hashlib.sha256(b"".join(parts)).hexdigest()


class IngestJournal:
    """Append-only journal of ingest lifecycle transitions.

    Each method acquires its own pool connection and sets the
    ``app.current_tenant`` RLS GUC before writing — journal writes live
    outside the Stage 5 transaction (per ADR-0024 §Granularity), so
    they cannot share that conn anyway.

    Callers must not ``UPDATE`` or ``DELETE`` journal rows after insert
    — append-only is a hard invariant. TTL pruning is a future
    maintenance job, not a write-path concern.
    """

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def _acquire(self, tenant_id: str, conn: asyncpg.Connection) -> None:
        # ``is_local=false`` = connection-scope GUC. Journal methods write
        # outside an explicit transaction, so ``is_local=true`` would
        # scope the GUC to the implicit single-statement txn for the SET
        # itself and expire before the subsequent INSERT — RLS bypassed.
        # Matches the pattern in ``maintenance.py:run_deferred_extraction``.
        # GUC persists on the borrowed conn until the next acquirer sets
        # its own tenant (every gnokee Postgres caller does so before
        # any read/write).
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, false)",
            tenant_id,
        )

    async def write_begin(
        self,
        *,
        tenant_id: str,
        our_id: str | None,
        episode_uuid: UUID,
        payload_hash: str,
        stage_4_time: datetime,
    ) -> ResumableEntry:
        """Journal entry: Stage 3.5 complete, about to run Stage 4 + Stage 5.

        Returns a :class:`ResumableEntry` handle for the caller to pass
        to :meth:`write_commit` / :meth:`write_fail`. The returned
        ``created_at`` is the value Postgres assigned to the ``begin``
        row, not ``stage_4_time``.
        """
        async with self._pool.acquire() as conn:
            await self._acquire(tenant_id, conn)
            row = await conn.fetchrow(
                """
                INSERT INTO ingest_journal
                    (tenant_id, our_id, episode_uuid, payload_hash, state, stage_4_time)
                VALUES ($1, $2, $3, $4, 'begin', $5)
                RETURNING created_at
                """,
                tenant_id,
                our_id,
                episode_uuid,
                payload_hash,
                stage_4_time,
            )
        if row is None:
            # ``INSERT … RETURNING`` returns a row when the INSERT lands;
            # a PK collision would surface as ``UniqueViolationError``.
            # ``None`` here means a future asyncpg behaviour change —
            # surface it as a typed error rather than ``AssertionError``.
            raise IngestJournalError(
                f"write_begin: INSERT ... RETURNING produced no row (tenant={tenant_id}, episode_uuid={episode_uuid})"
            )
        return ResumableEntry(
            tenant_id=tenant_id,
            our_id=our_id,
            episode_uuid=episode_uuid,
            payload_hash=payload_hash,
            stage_4_time=stage_4_time,
            created_at=row["created_at"],
        )

    async def write_commit(self, begin: ResumableEntry) -> None:
        """Journal entry: Stage 5 Postgres txn returned. Ingest succeeded.

        Caller is responsible for invoking this *outside* the Stage 5
        transaction — the journal trails the work it journals (per
        ADR-0024 §Granularity).
        """
        async with self._pool.acquire() as conn:
            await self._acquire(begin.tenant_id, conn)
            await conn.execute(
                """
                INSERT INTO ingest_journal
                    (tenant_id, our_id, episode_uuid, payload_hash, state, stage_4_time)
                VALUES ($1, $2, $3, $4, 'commit', $5)
                """,
                begin.tenant_id,
                begin.our_id,
                begin.episode_uuid,
                begin.payload_hash,
                begin.stage_4_time,
            )

    async def write_fail(self, begin: ResumableEntry, error: str) -> None:
        """Journal entry: unhandled exception escaped Stage 4 or Stage 5.

        Called *after* compensation (``remove_lite_episode``) on Stage 5
        failure. The ``begin`` row stays in place — append-only — so
        operators can audit the trail of every attempt.
        """
        async with self._pool.acquire() as conn:
            await self._acquire(begin.tenant_id, conn)
            await conn.execute(
                """
                INSERT INTO ingest_journal
                    (tenant_id, our_id, episode_uuid, payload_hash, state, stage_4_time, error)
                VALUES ($1, $2, $3, $4, 'fail', $5, $6)
                """,
                begin.tenant_id,
                begin.our_id,
                begin.episode_uuid,
                begin.payload_hash,
                begin.stage_4_time,
                error,
            )

    async def get_resumable(
        self,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> ResumableEntry | None:
        """Point-lookup variant of :meth:`scan_resumable` for a single episode.

        Used by :func:`gnokee.maintenance.resume_ingest` to find the
        target 'begin' row without surfacing every open begin for the
        tenant. Returns ``None`` when no resumable begin exists — the
        caller distinguishes that from "begin existed but was already
        committed" via a separate ``has_any`` probe if needed.
        """
        async with self._pool.acquire() as conn:
            await self._acquire(tenant_id, conn)
            row = await conn.fetchrow(
                """
                SELECT b.our_id, b.payload_hash, b.stage_4_time, b.created_at
                  FROM ingest_journal b
                 WHERE b.tenant_id = $1
                   AND b.episode_uuid = $2
                   AND b.state = 'begin'
                   AND NOT EXISTS (
                       SELECT 1 FROM ingest_journal c
                        WHERE c.tenant_id = b.tenant_id
                          AND c.episode_uuid = b.episode_uuid
                          AND c.state = 'commit'
                          AND c.seq > b.seq
                   )
                 ORDER BY b.seq DESC
                 LIMIT 1
                """,
                tenant_id,
                episode_uuid,
            )
        if row is None:
            return None
        return ResumableEntry(
            tenant_id=tenant_id,
            our_id=row["our_id"],
            episode_uuid=episode_uuid,
            payload_hash=row["payload_hash"],
            stage_4_time=row["stage_4_time"],
            created_at=row["created_at"],
        )

    async def episode_state(
        self,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> str | None:
        """Latest journal state for ``(tenant_id, episode_uuid)`` or ``None``.

        Used by :func:`gnokee.maintenance.resume_ingest` to disambiguate
        "no begin ever existed" from "begin existed but was already
        committed" when :meth:`get_resumable` returns ``None``.
        """
        async with self._pool.acquire() as conn:
            await self._acquire(tenant_id, conn)
            row = await conn.fetchrow(
                """
                SELECT state FROM ingest_journal
                 WHERE tenant_id = $1 AND episode_uuid = $2
                 ORDER BY seq DESC
                 LIMIT 1
                """,
                tenant_id,
                episode_uuid,
            )
        if row is None:
            return None
        return str(row["state"])

    async def scan_resumable(self, tenant_id: str) -> list[ResumableEntry]:
        """All 'begin' rows for ``tenant_id`` with no matching 'commit' row.

        Includes rows that subsequently had a 'fail' written — operator
        can decide whether to retry or accept the orphan reaping.
        """
        async with self._pool.acquire() as conn:
            await self._acquire(tenant_id, conn)
            rows = await conn.fetch(
                """
                SELECT b.our_id, b.episode_uuid, b.payload_hash,
                       b.stage_4_time, b.created_at
                  FROM ingest_journal b
                 WHERE b.tenant_id = $1
                   AND b.state = 'begin'
                   AND NOT EXISTS (
                       SELECT 1 FROM ingest_journal c
                        WHERE c.tenant_id = b.tenant_id
                          AND c.episode_uuid = b.episode_uuid
                          AND c.state = 'commit'
                          AND c.seq > b.seq
                   )
                 ORDER BY b.created_at ASC, b.seq ASC
                """,
                tenant_id,
            )
        return [
            ResumableEntry(
                tenant_id=tenant_id,
                our_id=r["our_id"],
                episode_uuid=r["episode_uuid"],
                payload_hash=r["payload_hash"],
                stage_4_time=r["stage_4_time"],
                created_at=r["created_at"],
            )
            for r in rows
        ]


__all__ = [
    "IngestJournal",
    "IngestJournalError",
    "ResumableEntry",
    "payload_hash",
]
