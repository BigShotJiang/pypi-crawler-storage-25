"""src/gnokee/storage/metadata.py — episode_metadata adapter (gnokee tx-time axis).

Owns `asserted_at` ≠ Graphiti's `created_at` semantically (per ADR-0004 +
bi-temporal-auditor). Python layer resolves `asserted_at` defaults; this
module never calls `now()` itself.

exports: class MetadataStore | EpisodeMetadataRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/maintenance.py
rules:   tenant_id on every read+write; tz-aware UTC; never SQL DEFAULT now() on asserted_at
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-sonnet-4-6 | 2026-05-09 | issue #47 deferred extraction columns
         claude-opus-4-7 | 2026-05-09 | issue #51 drop content column (consolidate to content_text)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError
from gnokee.models import Sensitivity


@dataclass(frozen=True)
class EpisodeMetadataRow:
    tenant_id: str
    episode_uuid: UUID
    valid_at: datetime
    valid_until: datetime | None
    asserted_at: datetime
    asserted_until: datetime | None
    superseded_by: UUID | None
    sensitive: Sensitivity
    language: str | None
    our_id: str | None = None
    extraction_deferred: bool = field(default=False)
    extraction_completed_at: datetime | None = field(default=None)
    content_text: str | None = field(default=None)
    # Issue #76 / ADR-0016 — verbatim body-span quote surfaced on the
    # per-claim citation envelope. NULL on every row in v0.5 (the extraction
    # stage does not yet emit per-fact body spans); backfill arrives in a
    # follow-up issue. NEVER populated from an LLM paraphrase.
    extracted_quote: str | None = field(default=None)
    # Issue #123 — consumer-supplied rationale for the supersession this
    # episode declared via `EpisodeIn.corrects_reason`. Surfaced verbatim
    # on `HistoryNode.rationale` in `gnokee_history_of` DAGs. NULL on
    # rows where no supersession was asserted (or no rationale was given).
    corrects_reason: str | None = field(default=None)


class MetadataStore:
    """Async wrapper around `episode_metadata`."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write(
        self,
        *,
        conn: asyncpg.Connection,
        row: EpisodeMetadataRow,
    ) -> bool:
        """Insert metadata row. Returns True iff a new row landed.

        ``ON CONFLICT DO NOTHING`` (bare target) absorbs both the
        ``(tenant_id, episode_uuid)`` PK collision (self-idempotency on
        replayed pipeline runs) and the partial unique index on
        ``(tenant_id, our_id)`` (idempotency on consumer-supplied keys).
        Returning ``False`` signals the caller that the row was already
        present and that downstream side-effects (vector write, Graphiti
        episode) need compensation.
        """
        try:
            result = await conn.fetchrow(
                """
                INSERT INTO episode_metadata (
                    tenant_id, episode_uuid, valid_at, valid_until,
                    asserted_at, asserted_until, superseded_by,
                    sensitive, language, our_id,
                    extraction_deferred, extraction_completed_at,
                    corrects_reason
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                ON CONFLICT DO NOTHING
                RETURNING episode_uuid
                """,
                row.tenant_id,
                row.episode_uuid,
                row.valid_at,
                row.valid_until,
                row.asserted_at,
                row.asserted_until,
                row.superseded_by,
                row.sensitive,
                row.language,
                row.our_id,
                row.extraction_deferred,
                row.extraction_completed_at,
                row.corrects_reason,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.write failed: {exc}") from exc
        return result is not None

    async def filter_visible(
        self,
        *,
        tenant_id: str,
        candidate_uuids: list[UUID],
        as_of: datetime,
        valid_at: datetime,
    ) -> list[UUID]:
        """Apply gnokee bi-temporal predicates on the episode side.

        - source-tx-time half-pair: `asserted_at <= as_of AND (asserted_until IS NULL OR asserted_until > as_of)`
        - episode-level world-time upper bound: `valid_until IS NULL OR valid_until > valid_at`
        Both required; bi-temporal-auditor surfaces partial halves.
        """
        if not candidate_uuids:
            return []
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                    """,
                    tenant_id,
                    candidate_uuids,
                    as_of,
                    valid_at,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.filter_visible failed: {exc}") from exc
        return [r["episode_uuid"] for r in rows]

    async def get(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> EpisodeMetadataRow | None:
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id,
                           extraction_deferred, extraction_completed_at, content_text,
                           extracted_quote, corrects_reason
                      FROM episode_metadata
                     WHERE tenant_id = $1 AND episode_uuid = $2
                    """,
                    tenant_id,
                    episode_uuid,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.get failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    async def get_by_our_id(
        self,
        *,
        tenant_id: str,
        our_id: str,
    ) -> EpisodeMetadataRow | None:
        """Lookup an episode by consumer-supplied (tenant_id, our_id) key.

        Used by the ingest pipeline to short-circuit on idempotent re-ingest.
        Returns ``None`` when no episode has been recorded against the key yet.
        """
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id,
                           extraction_deferred, extraction_completed_at, content_text,
                           extracted_quote, corrects_reason
                      FROM episode_metadata
                     WHERE tenant_id = $1 AND our_id = $2
                    """,
                    tenant_id,
                    our_id,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.get_by_our_id failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    async def fetch_deferred(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        since: datetime | None,
        limit: int,
    ) -> list[EpisodeMetadataRow]:
        """Fetch up to `limit` episodes with extraction_deferred=TRUE.

        Ordered by valid_at ASC so older episodes are processed first.
        When `since` is set, restricts to rows with valid_at >= since.
        Uses the partial index idx_episode_metadata_deferred for efficiency.

        Called inside an already-acquired connection so the RLS GUC set by
        the maintenance helper applies to this query.
        """
        try:
            if since is None:
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id,
                           extraction_deferred, extraction_completed_at, content_text,
                           extracted_quote, corrects_reason
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND extraction_deferred = TRUE
                     ORDER BY valid_at ASC
                     LIMIT $2
                    """,
                    tenant_id,
                    limit,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id,
                           extraction_deferred, extraction_completed_at, content_text,
                           extracted_quote, corrects_reason
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND extraction_deferred = TRUE
                       AND valid_at >= $2
                     ORDER BY valid_at ASC
                     LIMIT $3
                    """,
                    tenant_id,
                    since,
                    limit,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.fetch_deferred failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def mark_extraction_complete(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        completed_at: datetime,
    ) -> None:
        """Clear extraction_deferred and stamp extraction_completed_at.

        Idempotent: if the row was already cleared (second run), UPDATE
        matches 0 rows — no error, no audit side-effect. The WHERE clause
        requires both tenant_id (RLS defence-in-depth) and
        extraction_deferred=TRUE so concurrent runs don't double-stamp.
        """
        try:
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET extraction_deferred     = FALSE,
                       extraction_completed_at = $3
                 WHERE tenant_id    = $1
                   AND episode_uuid = $2
                   AND extraction_deferred = TRUE
                """,
                tenant_id,
                episode_uuid,
                completed_at,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.mark_extraction_complete failed: {exc}") from exc

    async def set_extraction_deferred(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        extraction_deferred: bool,
    ) -> None:
        """v0.6 Z1 (#111). Flip ``extraction_deferred`` post-Stage-6.

        Called by the v0.6 storage-first ingest pipeline when graphiti
        enhancement either succeeds (set False — happy path, no-op since
        the column was inserted False at Stage 5) or exhausts retry / raises
        non-retryable (set True — lite-fallback engaged, so
        ``maintenance.run_deferred_extraction`` picks it up later).
        """
        try:
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET extraction_deferred = $3
                 WHERE tenant_id = $1
                   AND episode_uuid = $2
                """,
                tenant_id,
                episode_uuid,
                extraction_deferred,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(
                f"metadata.set_extraction_deferred failed: {exc}",
            ) from exc

    async def list_episodes_for_tenant(
        self,
        *,
        tenant_id: str,
        as_of: datetime,
        valid_at: datetime,
        include_superseded: bool = False,
        limit: int = 500,
    ) -> list[EpisodeMetadataRow]:
        """List episodes for the requesting tenant (ADR-0015 wiki export).

        Used by the wiki export builder to render `log.md` and to walk
        the episode→entity edges that drive `entities/<slug>.md`.

        Bi-temporal predicates:

        - World-time lower bound `valid_at <= $valid_at` filters episodes
          that haven't happened yet out of the view.
        - Source-tx-time half-pair `asserted_at <= $as_of` honours the
          caller's `as_of` pin.
        - When `include_superseded` is False (`scope=self`), also apply
          `asserted_until > $as_of OR asserted_until IS NULL` so closed
          episodes drop out. When True (`scope=full`), keep them so the
          wiki page can render a History section.

        Ordered by `valid_at` desc so `log.md` reads newest-first; tenant
        predicate gates every row.
        """
        if include_superseded:
            sql = """
            SELECT tenant_id, episode_uuid, valid_at, valid_until,
                   asserted_at, asserted_until, superseded_by,
                   sensitive, language, our_id,
                   extraction_deferred, extraction_completed_at, content_text,
                   extracted_quote
              FROM episode_metadata
             WHERE tenant_id = $1
               AND valid_at <= $2
               AND asserted_at <= $3
             ORDER BY valid_at DESC, episode_uuid
             LIMIT $4
            """
            args = (tenant_id, valid_at, as_of, limit)
        else:
            sql = """
            SELECT tenant_id, episode_uuid, valid_at, valid_until,
                   asserted_at, asserted_until, superseded_by,
                   sensitive, language, our_id,
                   extraction_deferred, extraction_completed_at, content_text,
                   extracted_quote
              FROM episode_metadata
             WHERE tenant_id = $1
               AND valid_at <= $2
               AND asserted_at <= $3
               AND (asserted_until IS NULL OR asserted_until > $3)
             ORDER BY valid_at DESC, episode_uuid
             LIMIT $4
            """
            args = (tenant_id, valid_at, as_of, limit)
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(sql, *args)
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.list_episodes_for_tenant failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def latest_write_clock(
        self,
        *,
        tenant_id: str,
    ) -> datetime | None:
        """Most-recent `asserted_at` for the tenant — wiki-cache write-clock.

        ADR-0015 per-tenant cache invalidation. The wiki export memoises
        the rendered files keyed on `(tenant_id, scope, as_of)` and uses
        this value to decide whether to regenerate: if the cached
        `generated_at >= latest_write_clock`, return the cached payload.

        Returns `None` when the tenant has no episodes yet — caller treats
        that as "nothing to cache" and renders an empty wiki.
        """
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT MAX(asserted_at) AS clock
                      FROM episode_metadata
                     WHERE tenant_id = $1
                    """,
                    tenant_id,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.latest_write_clock failed: {exc}") from exc
        if row is None:
            return None
        clock = row["clock"]
        if clock is None:
            return None
        # asyncpg returns a tz-aware datetime when the column is
        # `TIMESTAMPTZ`; cast explicitly to satisfy mypy strict.
        assert isinstance(clock, datetime)
        return clock

    _CHAIN_DEPTH_LIMIT = 32

    async def chain_head_at(
        self,
        *,
        tenant_id: str,
        start_uuid: UUID,
        as_of: datetime,
    ) -> EpisodeMetadataRow | None:
        """Walk `superseded_by` from `start_uuid` to the chain's head as
        of `as_of`. Read-only, no FOR UPDATE — used by retrieval to
        resolve supersession hints (issue #19) where contention with the
        write path is undesirable.

        Returns the row that is open at `as_of` (asserted_at <= as_of
        AND (asserted_until IS NULL OR asserted_until > as_of)), or the
        last row in the chain when every episode in the chain is closed
        at `as_of` (rare; e.g. a redaction chain). Returns ``None`` when
        the starting episode does not exist or belongs to a different
        tenant.

        Bounded depth: chains > 32 hops raise ``CorrectsChainError``
        (defensive; matches the write-side bound on
        :py:meth:`supersede`).
        """
        from gnokee.errors import CorrectsChainError

        current_uuid = start_uuid
        last_row: asyncpg.Record | None = None
        try:
            async with self._pool.acquire() as conn:
                for _ in range(self._CHAIN_DEPTH_LIMIT):
                    row = await conn.fetchrow(
                        """
                        SELECT tenant_id, episode_uuid, valid_at, valid_until,
                               asserted_at, asserted_until, superseded_by,
                               sensitive, language, our_id,
                               extraction_deferred, extraction_completed_at, content_text,
                               extracted_quote, corrects_reason
                          FROM episode_metadata
                         WHERE tenant_id = $1 AND episode_uuid = $2
                        """,
                        tenant_id,
                        current_uuid,
                    )
                    if row is None:
                        return None if last_row is None else _row_to_dc(last_row)
                    last_row = row
                    open_at_as_of = row["asserted_at"] <= as_of and (
                        row["asserted_until"] is None or row["asserted_until"] > as_of
                    )
                    if open_at_as_of:
                        return _row_to_dc(row)
                    next_uuid = row["superseded_by"]
                    if next_uuid is None:
                        return _row_to_dc(row)
                    current_uuid = next_uuid
                else:
                    raise CorrectsChainError(
                        f"chain_head_at: superseded_by chain exceeded "
                        f"{self._CHAIN_DEPTH_LIMIT} hops starting at "
                        f"{start_uuid}"
                    )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.chain_head_at failed: {exc}") from exc

    async def history_of(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
        as_of: datetime,
        valid_at: datetime,
        max_nodes: int = 32,
    ) -> list[EpisodeMetadataRow]:
        """Walk the full bi-temporal supersession DAG anchored at
        ``episode_uuid`` (issue #123 / #122 lineage trail).

        Recursive CTE in both directions:

        * Forward (successors): chain via ``superseded_by`` pointer.
        * Backward (predecessors): rows whose ``superseded_by`` matches
          a member of the visible set.

        Every node filtered bi-temporally (``filter_visible`` predicate
        pair on ``asserted_at`` + ``valid_until``). Each direction
        bounded by ``max_nodes``; outer ``LIMIT`` keeps the total at
        ``max_nodes`` after dedup, ordered by ``asserted_at DESC`` so
        newest nodes survive truncation (oldest ancestors dropped — the
        documented behaviour on overflow).

        Callers must treat returned-row count == ``max_nodes`` as a
        truncation signal; on a strict-cycle assertion (which the
        schema's ``supersede()`` write-path forbids) the bound still
        terminates the recursion, so this method never loops forever.
        """
        if max_nodes < 1:
            raise ValueError("history_of: max_nodes must be >= 1")
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    WITH RECURSIVE
                    successors AS (
                        SELECT em.tenant_id, em.episode_uuid, em.valid_at,
                               em.valid_until, em.asserted_at,
                               em.asserted_until, em.superseded_by,
                               em.sensitive, em.language, em.our_id,
                               em.extraction_deferred,
                               em.extraction_completed_at, em.content_text,
                               em.extracted_quote, em.corrects_reason,
                               0 AS lvl
                          FROM episode_metadata em
                         WHERE em.tenant_id    = $1
                           AND em.episode_uuid = $2
                           AND em.asserted_at  <= $3
                           AND (em.valid_until IS NULL OR em.valid_until > $4)
                        UNION ALL
                        SELECT em.tenant_id, em.episode_uuid, em.valid_at,
                               em.valid_until, em.asserted_at,
                               em.asserted_until, em.superseded_by,
                               em.sensitive, em.language, em.our_id,
                               em.extraction_deferred,
                               em.extraction_completed_at, em.content_text,
                               em.extracted_quote, em.corrects_reason,
                               s.lvl + 1
                          FROM episode_metadata em
                          JOIN successors s
                            ON em.episode_uuid = s.superseded_by
                         WHERE em.tenant_id   = $1
                           AND em.asserted_at <= $3
                           AND (em.valid_until IS NULL OR em.valid_until > $4)
                           AND s.lvl < $5
                    ),
                    predecessors AS (
                        SELECT em.tenant_id, em.episode_uuid, em.valid_at,
                               em.valid_until, em.asserted_at,
                               em.asserted_until, em.superseded_by,
                               em.sensitive, em.language, em.our_id,
                               em.extraction_deferred,
                               em.extraction_completed_at, em.content_text,
                               em.extracted_quote, em.corrects_reason,
                               0 AS lvl
                          FROM episode_metadata em
                         WHERE em.tenant_id    = $1
                           AND em.episode_uuid = $2
                           AND em.asserted_at  <= $3
                           AND (em.valid_until IS NULL OR em.valid_until > $4)
                        UNION ALL
                        SELECT em.tenant_id, em.episode_uuid, em.valid_at,
                               em.valid_until, em.asserted_at,
                               em.asserted_until, em.superseded_by,
                               em.sensitive, em.language, em.our_id,
                               em.extraction_deferred,
                               em.extraction_completed_at, em.content_text,
                               em.extracted_quote, em.corrects_reason,
                               p.lvl + 1
                          FROM episode_metadata em
                          JOIN predecessors p
                            ON em.superseded_by = p.episode_uuid
                         WHERE em.tenant_id   = $1
                           AND em.asserted_at <= $3
                           AND (em.asserted_until IS NULL OR em.asserted_until > $3)
                           AND (em.valid_until    IS NULL OR em.valid_until    > $4)
                           AND p.lvl < $5
                    ),
                    combined AS (
                        SELECT * FROM successors
                        UNION
                        SELECT * FROM predecessors
                    ),
                    dedup AS (
                        SELECT DISTINCT ON (episode_uuid)
                               tenant_id, episode_uuid, valid_at, valid_until,
                               asserted_at, asserted_until, superseded_by,
                               sensitive, language, our_id,
                               extraction_deferred, extraction_completed_at,
                               content_text, extracted_quote, corrects_reason
                          FROM combined
                         ORDER BY episode_uuid, lvl ASC
                    )
                    SELECT * FROM dedup
                     ORDER BY asserted_at DESC
                     LIMIT $5
                    """,
                    tenant_id,
                    episode_uuid,
                    as_of,
                    valid_at,
                    max_nodes,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.history_of failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def supersede(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        corrected_episode_uuid: UUID,
        new_episode_uuid: UUID,
        asserted_until: datetime,
    ) -> EpisodeMetadataRow:
        """Close ``episode_metadata`` for the corrected episode (v0.2.1).

        Validates: same tenant, episode exists, asserted_at axis (new
        > corrected). If the named episode is already superseded, walks
        ``superseded_by`` chain to current head and supersedes the head
        instead. Each hop SELECT uses ``FOR UPDATE`` so concurrent
        ``corrects:`` requests against the same chain serialize
        correctly under READ COMMITTED.

        Bounded depth: chains > 32 hops raise ``CorrectsChainError``
        (defensive against cycles).

        Returns the head ``EpisodeMetadataRow`` (the row that was
        UPDATEd). Caller passes ``head.episode_uuid`` to
        :py:meth:`gnokee.storage.lab.LabStore.supersede_matching` /
        :py:meth:`gnokee.storage.med.MedStore.supersede_matching` so
        row-level supersession lands on the same row that has open
        visible state.
        """
        # Local import: gnokee.errors imports models for Sensitivity
        # (transitively) — keep top-level imports minimal.
        from gnokee.errors import (
            CorrectsAxisInversionError,
            CorrectsChainError,
            CorrectsCrossTenantError,
            EpisodeNotFoundError,
        )

        current_uuid = corrected_episode_uuid
        head_row: asyncpg.Record | None = None
        try:
            for _ in range(self._CHAIN_DEPTH_LIMIT):
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id,
                           extraction_deferred, extraction_completed_at, content_text,
                           extracted_quote, corrects_reason
                      FROM episode_metadata
                     WHERE episode_uuid = $1
                       FOR UPDATE
                    """,
                    current_uuid,
                )
                if row is None:
                    raise EpisodeNotFoundError(current_uuid)
                if row["tenant_id"] != tenant_id:
                    raise CorrectsCrossTenantError(
                        f"corrects: episode {current_uuid} belongs to tenant {row['tenant_id']!r}, not {tenant_id!r}"
                    )
                if row["asserted_until"] is None:
                    head_row = row
                    break
                next_uuid = row["superseded_by"]
                if next_uuid is None:
                    # Closed but not pointing forward — historical
                    # data quirk. Treat as the chain head.
                    head_row = row
                    break
                current_uuid = next_uuid
            else:
                raise CorrectsChainError(
                    f"corrects: superseded_by chain exceeded "
                    f"{self._CHAIN_DEPTH_LIMIT} hops starting at "
                    f"{corrected_episode_uuid}"
                )

            assert head_row is not None  # narrowed by loop above
            if asserted_until <= head_row["asserted_at"]:
                raise CorrectsAxisInversionError(
                    f"corrects: new asserted_at={asserted_until.isoformat()} "
                    f"<= corrected.asserted_at="
                    f"{head_row['asserted_at'].isoformat()} "
                    f"(head episode={head_row['episode_uuid']})"
                )
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET asserted_until = $3,
                       superseded_by  = $4
                 WHERE tenant_id    = $1
                   AND episode_uuid = $2
                   AND asserted_until IS NULL
                """,
                tenant_id,
                head_row["episode_uuid"],
                asserted_until,
                new_episode_uuid,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.supersede failed: {exc}") from exc
        return _row_to_dc(head_row)


def _row_to_dc(row: asyncpg.Record) -> EpisodeMetadataRow:
    return EpisodeMetadataRow(
        tenant_id=row["tenant_id"],
        episode_uuid=row["episode_uuid"],
        valid_at=row["valid_at"],
        valid_until=row["valid_until"],
        asserted_at=row["asserted_at"],
        asserted_until=row["asserted_until"],
        superseded_by=row["superseded_by"],
        sensitive=row["sensitive"],
        language=row["language"],
        our_id=row["our_id"],
        extraction_deferred=row["extraction_deferred"] if "extraction_deferred" in row.keys() else False,
        extraction_completed_at=row["extraction_completed_at"] if "extraction_completed_at" in row.keys() else None,
        content_text=row["content_text"] if "content_text" in row.keys() else None,
        extracted_quote=row["extracted_quote"] if "extracted_quote" in row.keys() else None,
        corrects_reason=row["corrects_reason"] if "corrects_reason" in row.keys() else None,
    )
