"""src/gnokee/config.py — Environment-driven settings for gnokee.

Reads `GNOKEE_*` env vars per spec § Settings. Settings is frozen and
read once at startup; all downstream modules accept it as a parameter.

exports: class Settings | utc_now
used_by: src/gnokee/storage/migrate.py | src/gnokee/storage/* | src/gnokee/embeddings.py | src/gnokee/llm.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   GNOKEE_* env vars only; no hard-coded defaults for connection strings
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from datetime import datetime, timezone

from pydantic import AliasChoices, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All gnokee-side env config. Frozen; read once at startup.

    `openai_base_url` / `openai_api_key` accept the spec-canonical
    `GNOKEE_OPENAI_*` and the spike-era `GNOKEE_LLM_*` env names.

    `pg_dsn` may be assembled from `GNOKEE_PG_USER` / `_PASSWORD` / `_DB`
    / `_PORT` (compose-stack convention) when not given directly.
    Same for `tei_url` from `GNOKEE_TEI_PORT` (defaults to 8080).
    """

    model_config = SettingsConfigDict(
        env_prefix="GNOKEE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        frozen=True,
        populate_by_name=True,
    )

    pg_dsn: str | None = Field(default=None, description="Postgres DSN, e.g. postgresql://u:p@h:5432/d")
    pg_user: str = Field(default="gnokee")
    pg_password: str = Field(default="gnokee")
    pg_db: str = Field(default="gnokee")
    pg_port: int = Field(default=5432)
    pg_host: str = Field(default="localhost")
    neo4j_uri: str = Field(default="bolt://localhost:7687", description="Bolt URI")
    neo4j_user: str = Field(default="neo4j")
    neo4j_password: str = Field(default="gnokee-dev-password", description="Neo4j auth password")
    tei_url: str | None = Field(default=None, description="TEI base URL (legacy)")
    tei_port: int = Field(default=8080)
    embed_base_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GNOKEE_EMBED_BASE_URL"),
        description=(
            "Embedder endpoint. URLs ending in `/v1` use the OpenAI-compatible "
            "shape (Ollama, OpenAI cloud); otherwise the native HuggingFace TEI "
            "`/embed` shape. Falls back to `tei_url` when unset."
        ),
    )
    embed_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_EMBED_API_KEY"),
        description="Bearer for OpenAI-compatible embedders. Empty for TEI native.",
    )
    embed_model: str = Field(default="bge-m3")
    openai_base_url: str = Field(
        default="https://api.openai.com/v1",
        validation_alias=AliasChoices("GNOKEE_OPENAI_BASE_URL", "GNOKEE_LLM_BASE_URL"),
    )
    openai_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("GNOKEE_OPENAI_API_KEY", "GNOKEE_LLM_API_KEY"),
    )
    llm_model: str = Field(default="gpt-4o-mini")
    tenant_default: str = Field(default="default")
    mcp_http: bool = Field(default=False)
    log_level: str = Field(default="info")

    @model_validator(mode="after")
    def _resolve_optional(self) -> Settings:
        if self.pg_dsn is None:
            object.__setattr__(
                self,
                "pg_dsn",
                f"postgresql://{self.pg_user}:{self.pg_password}@{self.pg_host}:{self.pg_port}/{self.pg_db}",
            )
        if self.tei_url is None:
            object.__setattr__(self, "tei_url", f"http://localhost:{self.tei_port}")
        if self.embed_base_url is None:
            # Fall back to the legacy TEI URL so existing configs keep working.
            object.__setattr__(self, "embed_base_url", self.tei_url)
        return self


def utc_now() -> datetime:
    """Tz-aware UTC datetime. Single source for `now()` across the codebase."""
    return datetime.now(timezone.utc)
