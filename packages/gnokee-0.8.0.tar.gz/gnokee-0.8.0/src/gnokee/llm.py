"""src/gnokee/llm.py — OpenAI-compatible LLM client wrapper.

gnokee never vendors an LLM. The consumer supplies `GNOKEE_OPENAI_BASE_URL`
+ `GNOKEE_OPENAI_API_KEY`. v0.1 uses gpt-4o-mini per Q4 spike.

exports: class OpenAIClient | classify_contradiction
used_by: src/gnokee/contradiction.py | src/gnokee/storage/graph.py (Graphiti LLM driver)
rules:   never hold keys; raise LLMUnavailable on transport faults; deterministic temperature=0
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from openai import AsyncOpenAI, OpenAIError

from gnokee.errors import LLMUnavailable
from gnokee.models import Verdict

Q4_SYSTEM_PROMPT = """You are a fact-relationship classifier for a memory system.

Classify the relationship between two facts (A and B) as exactly ONE word from this set:

  unrelated     - different topics; no semantic overlap
  refinement    - same fact, B adds detail or precision
  update        - world-state changed: A was true, then B replaced it
  contradiction - A and B make incompatible claims about the same point in time

Respond with ONLY the single classification word, lowercase, no punctuation,
no explanation.
"""

Q4_USER_TEMPLATE = "Fact A: {a_text}\n\nFact B: {b_text}"


class OpenAIClient:
    """Async OpenAI-compatible chat client."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        temperature: float = 0.0,
    ) -> None:
        if not api_key:
            raise LLMUnavailable("OPENAI_API_KEY is empty")
        self._client = AsyncOpenAI(base_url=base_url, api_key=api_key)
        self._model = model
        self._temperature = temperature

    @property
    def model(self) -> str:
        return self._model

    async def complete(
        self,
        *,
        system: str,
        user: str,
        max_tokens: int = 32,
    ) -> str:
        try:
            resp = await self._client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                temperature=self._temperature,
                max_tokens=max_tokens,
            )
        except (OpenAIError, httpx.HTTPError) as exc:
            raise LLMUnavailable(f"chat.completions failed: {exc}") from exc
        if not resp.choices:
            raise LLMUnavailable("chat.completions returned no choices")
        content = resp.choices[0].message.content
        return (content or "").strip()


VALID_VERDICTS: tuple[str, ...] = ("unrelated", "refinement", "update", "contradiction")


async def classify_contradiction(
    *,
    client: OpenAIClient,
    a_text: str,
    b_text: str,
) -> str:
    """Return one of `VALID_VERDICTS`. Falls back to `unrelated` on parse failure.

    v0.1 prompt is time-agnostic per Q4 spike — passing `valid_at` strings
    confused the classifier. The `update` vs `contradiction` distinction is
    inferred from semantic content alone; bi-temporal context is applied at
    retrieval-time, not classification-time.
    """
    user = Q4_USER_TEMPLATE.format(a_text=a_text, b_text=b_text)
    raw = await client.complete(system=Q4_SYSTEM_PROMPT, user=user, max_tokens=8)
    if not raw:
        return "unrelated"
    label = raw.split()[0].lower().rstrip(".,;:!?")
    if label not in VALID_VERDICTS:
        return "unrelated"
    return label


def _coerce_verdict(label: str) -> Verdict | None:
    """Map a Q4 label to a persistable verdict (drops `unrelated`)."""
    if label in ("refinement", "update", "contradiction"):
        return label  # type: ignore[return-value]
    return None


def _safe_json_loads(s: str) -> dict[str, Any]:
    try:
        result = json.loads(s)
    except json.JSONDecodeError:
        return {}
    if isinstance(result, dict):
        return dict(result)
    return {}


__all__ = [
    "Q4_SYSTEM_PROMPT",
    "Q4_USER_TEMPLATE",
    "VALID_VERDICTS",
    "OpenAIClient",
    "_coerce_verdict",
    "_safe_json_loads",
    "classify_contradiction",
]
