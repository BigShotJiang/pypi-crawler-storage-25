"""src/gnokee/maintenance.py — Periodic maintenance helpers for gnokee operators.

Provides `run_deferred_extraction` — a backfill helper that lifts narrative
facts for episodes ingested with `extract=False` (lite mode, issue #16 item 1).

Design: single-threaded batched loop. Concurrency is out of scope for v0.3
(see issue #47). The operator drives scheduling via cron / pg_cron / any
external task runner; gnokee does NOT host a scheduler.

Two-store coordination: Graphiti write first (Stage 4), then Postgres update
(mark_extraction_complete). If the Postgres update fails after a successful
Graphiti write the episode will be re-processed on the next run — idempotency
comes from Graphiti's dedup (same `name` + `group_id`) and from the WHERE
clause in `mark_extraction_complete` (extraction_deferred=TRUE guard).

RLS: the helper sets `app.current_tenant` GUC on every acquired connection
before any SELECT or UPDATE so Postgres row-level security policies (when
enabled) enforce tenant isolation. The GUC is set inside the connection
scope and does not persist beyond the connection's lifetime.

exports: run_deferred_extraction | resume_ingest | DeferredExtractionReport | ExtractionFailure
used_by: operator scripts / cron / noggin maintenance task
rules:   tenant_id mandatory; reference_time = valid_at (NOT now()); never
         re-run Stages 1-3 (embed, lang detect, clinical parsers already done);
         leave extraction_deferred=TRUE on failure (next run retries)
agent:   claude-sonnet-4-6 | 2026-05-09 | issue #47 v0.3
         claude-opus-4-7 | 2026-05-09 | issue #51 read content_text (content column dropped)
         claude-opus-4-7 | 2026-05-16 | issue #122 ADR-0024 resume_ingest
         claude-sonnet-4-6 | 2026-05-16 | ADR-0026 §7 resume_forget
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

import asyncpg

if TYPE_CHECKING:
    from gnokee.bootstrap import App
    from gnokee.ingest import IngestPipeline
    from gnokee.models import ForgetReceiptDetail

from gnokee.config import utc_now
from gnokee.contradiction import detect_for_facts
from gnokee.errors import GraphStoreError, ValidationError, VectorStoreError
from gnokee.extract import augment_for_extraction
from gnokee.llm import OpenAIClient
from gnokee.models import EpisodeIn, IngestReceipt
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.journal import IngestJournalError
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

log = logging.getLogger(__name__)

_MAX_NAME_LEN = 80


def _episode_name(content: str) -> str:
    head = content.strip().splitlines()[0] if content.strip() else "episode"
    if len(head) <= _MAX_NAME_LEN:
        return head
    return head[: _MAX_NAME_LEN - 1].rstrip() + "…"


@dataclass(frozen=True)
class ExtractionFailure:
    """Record of one failed episode in a deferred-extraction run."""

    episode_uuid: UUID
    tenant_id: str
    error: str


@dataclass
class DeferredExtractionReport:
    """Summary returned by `run_deferred_extraction`."""

    processed: int = 0
    succeeded: int = 0
    failed: list[ExtractionFailure] = field(default_factory=list)
    elapsed_ms: int = 0


async def run_deferred_extraction(
    tenant_id: str,
    *,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None = None,
    contradiction_enabled: bool = True,
    since: datetime | None = None,
    batch_size: int = 50,
    max_episodes: int | None = None,
) -> DeferredExtractionReport:
    """Back-fill Graphiti narrative extraction for lite-ingest episodes.

    Args:
        tenant_id: Mandatory. Raises ValidationError when empty/missing.
        pool: asyncpg connection pool.
        graph: GraphitiStore wrapping the Graphiti client.
        metadata: MetadataStore for episode_metadata reads + updates.
        contradictions: ContradictionStore for writing contradiction rows.
        llm: OpenAIClient for contradiction detection. When None or
            contradiction_enabled=False, Stage 5 contradiction detection
            is skipped (consistent with full-mode ingest with llm=None).
        contradiction_enabled: Toggle contradiction detection independently
            of llm presence. Mirrors IngestPipeline.contradiction_enabled.
        since: When set, restricts to episodes with valid_at >= since.
            Useful for operators running a targeted backfill over a
            specific time window (e.g. "last 7 days of Pulse telemetry").
        batch_size: Episodes per batch. Default 50.
        max_episodes: Hard cap on total episodes processed this run.
            None = no cap (process all deferred). Useful for rate-limited
            operators who want to spread cost over multiple scheduler ticks.

    Returns:
        DeferredExtractionReport with counts and per-failure records.

    Raises:
        ValidationError: tenant_id is empty.

    RLS note: `app.current_tenant` GUC is SET on every acquired connection
    before any query. This is defence-in-depth for Postgres RLS policies.
    The WHERE clause always includes `tenant_id = $1` as primary isolation.
    """
    if not tenant_id or not tenant_id.strip():
        raise ValidationError("run_deferred_extraction: tenant_id is required and must be non-empty")

    report = DeferredExtractionReport()
    t0 = time.monotonic()

    remaining = max_episodes  # None = unlimited

    while True:
        fetch_limit = batch_size
        if remaining is not None:
            fetch_limit = min(batch_size, remaining)

        async with pool.acquire() as conn:
            # RLS GUC: defence-in-depth tenant isolation.
            # SET LOCAL scopes to the current transaction; SET (no LOCAL)
            # scopes to the connection. We use the connection scope here
            # because fetch_deferred and mark_extraction_complete both run
            # on this connection without a surrounding transaction.
            # ``SET`` does NOT accept positional parameters in PostgreSQL,
            # so we use ``set_config(name, value, is_local)`` which does.
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, false)",
                tenant_id,
            )

            batch = await metadata.fetch_deferred(
                conn=conn,
                tenant_id=tenant_id,
                since=since,
                limit=fetch_limit,
            )

        if not batch:
            break

        report.processed += len(batch)

        for row in batch:
            success = await _extract_one(
                row=row,
                graph=graph,
                pool=pool,
                metadata=metadata,
                contradictions=contradictions,
                llm=llm,
                contradiction_enabled=contradiction_enabled,
                report=report,
            )
            if success:
                report.succeeded += 1

        if remaining is not None:
            remaining -= len(batch)
            if remaining <= 0:
                break

        # If the batch was smaller than requested, we've exhausted the
        # deferred set (or the since-filter drained it). Stop.
        if len(batch) < fetch_limit:
            break

    report.elapsed_ms = int((time.monotonic() - t0) * 1000)
    return report


async def _extract_one(
    *,
    row: EpisodeMetadataRow,
    graph: GraphitiStore,
    pool: asyncpg.Pool,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None,
    contradiction_enabled: bool,
    report: DeferredExtractionReport,
) -> bool:
    """Run Stage 4 + Stage 5 for a single deferred episode.

    Returns True on full success (Graphiti write + Postgres stamp both OK).
    Returns False and appends to report.failed on any error.
    Never raises — failure isolation is the contract.
    """
    tenant_id = row.tenant_id
    episode_uuid = row.episode_uuid

    if row.content_text is None:
        # Should not happen (lite ingest writes content_text via
        # PgVectorStore.write_content_text in Stage 6); guard anyway.
        failure_msg = (
            f"episode {episode_uuid} has extraction_deferred=True but content_text is NULL; "
            "cannot rehydrate for Graphiti extraction"
        )
        log.error("deferred_extraction: %s", failure_msg)
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=failure_msg,
            )
        )
        return False

    content = row.content_text

    # Stage 4: Graphiti add_episode.
    # reference_time MUST be valid_at — NOT utc_now(). This is the
    # load-bearing invariant: deferred extraction must assign the same
    # world-time as the original lite ingest would have. Using now() here
    # would corrupt the valid-time axis for every backfilled episode.
    augmented = augment_for_extraction(content)
    try:
        # v0.6 Z1 / #111 M4 — pass ``uuid=episode_uuid`` so graphiti attaches
        # entities + edges to the EXISTING lite Episodic (gnokee-owned uuid)
        # instead of creating a fresh node. Per Z1.6 spike, graphiti's
        # add_episode(uuid=X) loads-by-uuid and uses the LOADED Episodic's
        # content for extraction (kwarg silently dropped). The lite write
        # already lands the raw content (no augmentation in lite mode), so
        # we overwrite it to the augmented form just before this call so
        # the extractor sees augmented body, then restore at Stage 4b.
        await graph.overwrite_episode_content(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            content=augmented,
        )
        result = await graph.add_episode(
            tenant_id=tenant_id,
            name=_episode_name(content),
            content=augmented,
            reference_time=row.valid_at,  # NOT utc_now()
            uuid=episode_uuid,
            source_description="gnokee.maintenance.deferred_extraction",
        )
    except GraphStoreError as exc:
        log.warning(
            "deferred_extraction: graphiti.add_episode failed tenant=%s uuid=%s: %s",
            tenant_id,
            episode_uuid,
            exc,
        )
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=str(exc),
            )
        )
        return False

    # Stage 4b: restore original content on the Episodic node if the
    # preprocessor augmented the body (consistent with v0.6 Z1-B ingest).
    # Z1-B intentional behaviour: provenance-restore failure is logged
    # loud but non-fatal — the Episodic + facts already exist; rolling
    # back here would delete real entity work.
    if augmented != content:
        try:
            await graph.overwrite_episode_content(
                tenant_id=tenant_id,
                episode_uuid=episode_uuid,
                content=content,
            )
        except GraphStoreError as exc:
            log.warning(
                "deferred_extraction: overwrite_episode_content failed (non-fatal in v0.6 Z1-B); tenant=%s uuid=%s: %s",
                tenant_id,
                episode_uuid,
                exc,
            )

    # Stage 5: contradiction detection (degraded-tolerant; mirrors ingest.py).
    if contradiction_enabled and llm is not None and result.edges:
        new_facts: list[tuple[UUID, str, datetime, list[float]]] = []
        for edge in result.edges:
            if edge.fact_embedding is None:
                continue
            edge_valid = edge.valid_at or row.valid_at
            new_facts.append(
                (
                    UUID(edge.uuid),
                    edge.fact,
                    edge_valid,
                    list(edge.fact_embedding),
                )
            )
        if new_facts:
            try:
                await detect_for_facts(
                    tenant_id=tenant_id,
                    new_facts=new_facts,
                    store=graph,
                    contradictions=contradictions,
                    llm=llm,
                    detected_at=utc_now(),
                )
            except Exception as exc:
                # Contradiction detection is degraded-tolerant: log + continue.
                # The Graphiti episode is already written; don't roll back for
                # contradiction detection failures.
                log.warning(
                    "deferred_extraction: contradiction detection failed (degraded); tenant=%s uuid=%s: %s",
                    tenant_id,
                    episode_uuid,
                    exc,
                )

    # Stamp extraction_completed_at + clear extraction_deferred flag.
    completed_at = utc_now()
    try:
        async with pool.acquire() as conn:
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, false)",
                tenant_id,
            )
            await metadata.mark_extraction_complete(
                conn=conn,
                tenant_id=tenant_id,
                episode_uuid=episode_uuid,
                completed_at=completed_at,
            )
    except VectorStoreError as exc:
        log.error(
            "deferred_extraction: mark_extraction_complete failed; "
            "Graphiti write succeeded but Postgres stamp failed — "
            "episode will be re-processed on next run. "
            "tenant=%s uuid=%s: %s",
            tenant_id,
            episode_uuid,
            exc,
        )
        report.failed.append(
            ExtractionFailure(
                episode_uuid=episode_uuid,
                tenant_id=tenant_id,
                error=f"mark_extraction_complete: {exc}",
            )
        )
        return False

    log.info(
        "deferred_extraction: completed tenant=%s uuid=%s",
        tenant_id,
        episode_uuid,
    )
    return True


async def resume_ingest(
    tenant_id: str,
    episode_uuid: UUID,
    episode: EpisodeIn,
    *,
    pipeline: IngestPipeline,
) -> IngestReceipt:
    """Opt-in resume for a journaled ``begin`` row with no matching ``commit``.

    ADR-0024 / issue #122. gnokee NEVER auto-replays: the consumer
    must explicitly call this entry with the original ``EpisodeIn``
    payload (option (b) — consumer-resupply, locked on #122). The
    journaled ``payload_hash`` is checked against the supplied
    payload; mismatch raises :class:`IngestJournalError` without
    touching either store.

    The resume re-executes Stage 4 (Neo4j ``MERGE`` is idempotent on
    ``uuid``) and Stage 5 (all inserts use ``ON CONFLICT DO NOTHING``
    or ``DO UPDATE``). Stage 6 (Graphiti enhancement) is force-
    disabled — call :func:`run_deferred_extraction` separately if
    narrative extraction is wanted on the resumed episode.

    Args:
        tenant_id: Tenant scope. Must match ``episode.tenant_id``.
        episode_uuid: The journaled ``episode_uuid`` from the
            ``begin`` row to resume.
        episode: Consumer-resupplied ``EpisodeIn``. Must produce the
            same ``payload_hash`` as the journaled ``begin`` row
            (i.e. same ``tenant_id``, ``our_id``, ``valid_at``).
        pipeline: The :class:`IngestPipeline` whose pool + journal
            are addressed.

    Raises:
        ValidationError: empty ``tenant_id`` (input validation; the
            journal is not consulted in this case).
        IngestJournalError: ``tenant_id``/``episode.tenant_id``
            mismatch; no resumable ``begin`` row for the given
            ``(tenant_id, episode_uuid)``; the episode is already
            committed (no resume needed); or payload-hash drift.

    Returns:
        :class:`IngestReceipt` describing the resumed episode.

    Note on ``asserted_at`` semantics: if the consumer's re-supplied
    ``EpisodeIn.asserted_at`` is ``None``, Stage 5 will write a fresh
    ``asserted_at = utc_now()`` — the source-tx time of the resume,
    NOT the original ingest wall-clock time (axis-2 ADR-0004). Pass
    the original ``asserted_at`` explicitly if reproducibility matters.

    Note on content drift: ``payload_hash`` covers ``(tenant_id,
    our_id, valid_at)`` only — content bytes are NOT hashed. If the
    consumer re-supplies a different ``content`` on resume, Stage 5's
    ``content_embedding`` and ``content_text`` writes use
    ``ON CONFLICT ... DO UPDATE`` and will overwrite any previously
    landed embedding/text with the resume's value. Resume MUST supply
    the original ``EpisodeIn`` content for axis-2 consistency.
    """
    if not tenant_id:
        raise ValidationError("resume_ingest: tenant_id required")
    if episode.tenant_id != tenant_id:
        raise IngestJournalError(
            f"resume_ingest: tenant_id mismatch — argument={tenant_id!r} vs episode.tenant_id={episode.tenant_id!r}"
        )

    # Point-lookup avoids the race window where another caller commits
    # this episode between scan_resumable and the predicate match.
    target = await pipeline.journal.get_resumable(tenant_id, episode_uuid)
    if target is None:
        state = await pipeline.journal.episode_state(tenant_id, episode_uuid)
        if state == "commit":
            raise IngestJournalError(
                f"resume_ingest: episode {episode_uuid} already committed for tenant={tenant_id}; no resume needed"
            )
        raise IngestJournalError(
            f"resume_ingest: no resumable 'begin' row for tenant={tenant_id} episode_uuid={episode_uuid}"
        )

    log.info(
        "resume_ingest: tenant=%s episode_uuid=%s replaying Stage 4 + Stage 5",
        tenant_id,
        episode_uuid,
    )
    return await pipeline.ingest(episode, _resume=target)


async def resume_forget(
    app: App,
    *,
    tenant_id: str,
    audit_id: UUID | None = None,
) -> list[ForgetReceiptDetail]:
    """Replay 'fail' rows (Neo4j retry); skip orphaned 'begin' rows.

    Opt-in mirror of resume_ingest. gnokee never auto-replays.

    ADR-0026 §7. Finds all ``state='fail'`` rows for ``tenant_id`` (or a
    single row when ``audit_id`` is supplied), re-drives the Neo4j sweep,
    then flips the audit row to ``state='commit'``.

    ``state='begin'`` rows (process kill before Postgres commit) are
    surfaced as a WARNING and skipped — the caller must re-issue the
    original forget call (data is intact; Postgres was never swept).

    Args:
        app: Bootstrapped :class:`gnokee.bootstrap.App`.
        tenant_id: Tenant scope.
        audit_id: Optional narrow filter — retry only this audit row.

    Returns:
        List of :class:`~gnokee.models.ForgetReceiptDetail` for each
        row that was successfully retried and committed.
    """
    from gnokee.models import ForgetReceiptDetail
    from gnokee.storage import forget_audit

    failed = await forget_audit.find_failed_neo4j_rows(app.pool, tenant_id=tenant_id)
    pending = await forget_audit.find_resumable(app.pool, tenant_id=tenant_id)

    if pending:
        log.warning(
            "resume_forget: %d 'begin' rows for tenant=%s skipped — these indicate "
            "a process kill before Postgres commit; data is intact, caller must "
            "re-issue the forget call",
            len(pending),
            tenant_id,
        )

    if audit_id is not None:
        failed = [r for r in failed if r.audit_id == audit_id]

    receipts: list[ForgetReceiptDetail] = []
    for row in failed:
        if row.scope == "tenant":
            counts = await app.graph_store.remove_tenant_group(tenant_id=tenant_id)
        else:
            uuids = [UUID(s) for s in (row.cascade_uuids or [])]
            counts = await app.graph_store.remove_episodes_by_uuid(
                tenant_id=tenant_id,
                episode_uuids=uuids,
            )
        # receipt may be None if the fail happened before the commit phase
        # stored a receipt — reconstruct from the audit row columns.
        existing: dict[str, Any]
        if row.receipt:
            existing = dict(row.receipt)
        else:
            now_iso = utc_now().isoformat()
            existing = {
                "audit_id": str(row.audit_id),
                "tenant_id": row.tenant_id,
                "scope": row.scope,
                "episode_uuid": str(row.episode_uuid) if row.episode_uuid else None,
                "cascade": row.cascade,
                "dry_run": row.dry_run,
                "summary": "",
                "affected_episode_count": 0,
                "deepest_episode_uuid": None,
                "affected_key_ids": [],
                "replayed": False,
                "started_at": row.started_at.isoformat() if row.started_at else now_iso,
                "finished_at": row.finished_at.isoformat() if row.finished_at else now_iso,
                "actor": row.actor,
                "reason": row.reason,
                "postgres_rows_deleted": {},
                "neo4j_nodes_deleted": {},
                "neo4j_edges_deleted": {},
                "cascaded_episode_uuids": row.cascade_uuids or [],
                "partial": True,
                "bitemporal_snap": row.bitemporal_snap or [],
            }
        merged = {
            **existing,
            "neo4j_nodes_deleted": {k: v for k, v in counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": counts.get("edges_total", 0)},
            "partial": False,
            "replayed": False,
        }
        await forget_audit.mark_commit(app.pool, audit_id=row.audit_id, receipt=merged)
        receipts.append(ForgetReceiptDetail.model_validate(merged))
        log.info(
            "resume_forget: tenant=%s audit_id=%s committed",
            tenant_id,
            row.audit_id,
        )

    return receipts


__all__ = [
    "DeferredExtractionReport",
    "ExtractionFailure",
    "resume_forget",
    "resume_ingest",
    "run_deferred_extraction",
]
