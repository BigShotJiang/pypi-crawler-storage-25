"""src/gnokee/query.py — Declarative envelope orchestrator (ADR-0013, issue #72).

Single-call read surface that composes the existing recall / lab_query /
med_query pipelines under a declarative envelope:

  - `ask`                — natural-language question
  - `filter.tenant_id`   — REQUIRED (federation is a hard non-goal)
  - `filter.valid_at_range`     — bi-temporal world-time range
  - `filter.asserted_at_range`  — bi-temporal source-tx-time range
  - `filter.topics`      — routing hint (clinical.lab / clinical.med / general)
  - `output_shape`       — fact | episode | mixed
  - `budget.max_episodes` / `max_tokens`
  - `confidence_floor`   — ADR-0019 recency-proxy cutoff

Returns a `QueryResponse` carrying:

  - `value`           — RESERVED; null in v0.5 (AGENTS.md no LLM hosting).
  - `provenance[]`    — flat per-claim provenance handles.
  - `confidence`      — top-level recency-proxy aggregate (ADR-0019).
  - `contradictions[]` — flat list, NEVER auto-resolved (ADR-0008).
  - `citations`       — ADR-0016 per-claim bi-temporal citation envelope.
  - `query_telemetry` — extends #54 telemetry shape with per-envelope-axis
                        counters.

Bi-temporal range filtering is implemented as a **post-recall filter** in
v0.5 — the caller's `lte` bound becomes the recall pipeline's point pin,
then the surviving facts are filtered against the full range. Pushing the
range bounds down into Cypher is a v0.5.x follow-up (ADR-0013 § sequencing).

`confidence` is the ADR-0019 recency proxy: `exp(-Δt_days / 365)` where
`Δt = as_of - fact.valid_at`. NOT a calibrated probability — the tool
description documents the caveat.

exports: QueryEnvelope | QueryResponse | gnokee_query | QueryEnvelopeFilter
        | QueryEnvelopeBudget | DateRange | ProvenanceEntry | ContradictionEntry
        | QueryTelemetry
used_by: src/gnokee/mcp.py | src/gnokee/__init__.py
rules:   tenant_id mandatory; tenant_scope cross rejected; UTC-only datetimes;
         value field is null in v0.5; bi-temporal axes never confused with
         created_at (ADR-0001)
agent:   claude-opus-4-7 | 2026-05-11 | issue #72 / ADR-0013 declarative envelope
"""

from __future__ import annotations

import logging
import math
from datetime import datetime, timedelta
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from gnokee.citations import build_recall_citations, citation_key
from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.lab_query import LabQueryPipeline, LabQueryResponse, LabRowOut
from gnokee.med_query import MedQueryPipeline, MedQueryResponse, MedRowOut
from gnokee.models import (
    Citation,
    EpisodeFact,
    Excerpt,
    FactStatement,
    RecallResponse,
    RecallTelemetry,
)
from gnokee.retrieval import RecallPipeline

log = logging.getLogger(__name__)

# ADR-0019 recency-proxy half-life. Function B from the Q13 spike. Anchored
# at one year so a fact one half-life old reads as confidence ≈ 0.37 and a
# brand-new fact reads as confidence = 1.0. Documented as a *proxy*, NOT a
# calibrated probability — cal_max = 0.41 on N=13.
RECENCY_HALF_LIFE_DAYS = 365.0

# v0.5 topic vocabulary. `general` routes to recall; `clinical.lab` /
# `clinical.med` route to the typed clinical pipelines. Unknown topics fall
# through to `general` and surface in `query_telemetry.unknown_topics[]`.
Topic = Literal["general", "clinical.lab", "clinical.med"]

# `output_shape` selects which provenance lanes are emitted.
OutputShape = Literal["fact", "episode", "mixed"]

# `tenant_scope` is reserved for future federation — v0.5 accepts only
# `self`. Any other value (including `cross`) raises ValidationError at
# the model boundary.
TenantScope = Literal["self"]

# Default budget knob values. `max_tokens=200` mirrors recall's default;
# `max_episodes=20` caps the provenance list so an unbounded
# `top_k`-scaled response cannot blow the LLM's context.
DEFAULT_MAX_EPISODES = 20
DEFAULT_MAX_TOKENS = 200


def _require_utc(value: datetime) -> datetime:
    """Reject naive AND non-UTC datetimes at the envelope boundary.

    Mirrors `gnokee.models._require_utc` so the envelope refuses to mix
    axes silently. Bi-temporal axis hygiene is a load-bearing invariant.
    """
    if value.tzinfo is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    if value.utcoffset() != timedelta(0):
        raise ValueError(f"datetime must be UTC; got utcoffset={value.utcoffset()}")
    return value


class DateRange(BaseModel):
    """Bi-temporal range bound. `gte` is inclusive lower; `lte` is inclusive
    upper. Both bounds are optional — omitting one bounds the range on the
    other side only.

    The bounds are interpreted against ONE bi-temporal axis. `DateRange`
    instances live on `QueryEnvelopeFilter.valid_at_range` (world-time
    axis, ADR-0001) and `QueryEnvelopeFilter.asserted_at_range`
    (source-tx-time axis, ADR-0001). **Never** against `created_at` —
    ingest-system time is not a knowledge axis (ADR-0013 § Anti-patterns).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    gte: datetime | None = Field(
        default=None,
        description="Inclusive lower bound. ISO-8601 UTC. Omit for no lower bound.",
    )
    lte: datetime | None = Field(
        default=None,
        description="Inclusive upper bound. ISO-8601 UTC. Omit for no upper bound.",
    )

    @field_validator("gte", "lte")
    @classmethod
    def _utc_only(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        return _require_utc(value)

    @model_validator(mode="after")
    def _range_is_ordered(self) -> DateRange:
        if self.gte is not None and self.lte is not None and self.gte > self.lte:
            raise ValueError(f"DateRange: gte {self.gte} > lte {self.lte}")
        return self


class QueryEnvelopeFilter(BaseModel):
    """Filter clause of the declarative envelope.

    `tenant_id` is REQUIRED — empty string and `None` both raise. Memory
    partitioning is a load-bearing invariant; no cross-tenant federation
    (AGENTS.md "do not" list).

    `valid_at_range` / `asserted_at_range` are the two ADR-0001 axes.
    `topics` is a routing hint — unknown entries fall through to
    `general` and surface in telemetry.

    `tenant_scope` is reserved for future federation; v0.5 accepts only
    `self`. Any other value (including the issue body's `cross` /
    `shared` examples) raises `ValidationError`.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: str = Field(min_length=1, description="Memory partition. REQUIRED.")
    valid_at_range: DateRange | None = Field(
        default=None,
        description="ADR-0001 world-time axis range filter. Optional.",
    )
    asserted_at_range: DateRange | None = Field(
        default=None,
        description="ADR-0001 source-tx-time axis range filter. Optional.",
    )
    topics: list[str] = Field(
        default_factory=list,
        description=(
            "Routing hint. v0.5 vocabulary: clinical.lab, clinical.med, "
            "general. Unknown entries fall through to general and surface "
            "in query_telemetry.unknown_topics."
        ),
    )
    tenant_scope: TenantScope = Field(
        default="self",
        description=(
            "Reserved for future federation. v0.5 accepts `self` only — cross-tenant federation is a hard non-goal."
        ),
    )

    @field_validator("tenant_id")
    @classmethod
    def _tenant_id_non_blank(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("tenant_id must be a non-empty string")
        return value


class QueryEnvelopeBudget(BaseModel):
    """Budget knob for the declarative envelope.

    `max_tokens` maps to `recall(max_tokens=...)` directly — the same
    per-lane Stage 6 budget split applies (fact / excerpt / body lanes,
    issue #54).

    `max_episodes` caps the provenance list length AFTER all filters
    (range, confidence_floor, topic routing). Defaults to 20 to keep
    the wire envelope bounded.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    max_episodes: int = Field(
        default=DEFAULT_MAX_EPISODES,
        ge=1,
        le=500,
        description="Provenance list cap. Applied after all filters.",
    )
    max_tokens: int = Field(
        default=DEFAULT_MAX_TOKENS,
        ge=1,
        le=10_000,
        description="Response token budget. Maps directly to recall(max_tokens).",
    )


class QueryEnvelope(BaseModel):
    """Declarative envelope — single MCP tool input shape (ADR-0013).

    Validated at the MCP boundary via Pydantic v2 (`extra="forbid"`).
    Malformed envelopes raise `ValidationError` which the MCP layer
    converts to a structured JSON-RPC error.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    ask: str = Field(min_length=1, description="Natural-language question.")
    filter: QueryEnvelopeFilter = Field(description="Filter clause. Mandatory.")
    output_shape: OutputShape = Field(
        default="mixed",
        description="fact | episode | mixed. Default: mixed.",
    )
    budget: QueryEnvelopeBudget = Field(
        default_factory=QueryEnvelopeBudget,
        description="Budget knobs. Defaults: max_episodes=20, max_tokens=200.",
    )
    confidence_floor: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description=(
            "Minimum age-credibility cutoff. ADR-0019 recency proxy "
            "(NOT a calibrated probability). Default: 0.0 (no filter)."
        ),
    )


class ProvenanceEntry(BaseModel):
    """One row in `QueryResponse.provenance`.

    Flat per-claim handle: `episode_uuid` is always present, `fact_uuid`
    is populated for FactStatement-backed rows (recall's `facts[]`),
    `null` for episode-body rows (recall's `episode_fallback[]`) or
    typed-store rows (lab/med). Bi-temporal axes are mandatory.

    `score` is `None` in v0.5 — we do not surface the cosine / RRF
    score per row today. v0.5.x may wire it through once
    `RecallPipeline` exposes per-fact scores.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID
    fact_uuid: UUID | None = None
    valid_at: datetime
    asserted_at: datetime
    source_uri: str | None = None
    score: float | None = None

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class ContradictionEntry(BaseModel):
    """One row in `QueryResponse.contradictions`.

    Flat surfacing of an ADR-0008 contradiction pair. `axis` is fixed to
    `"asserted_at"` in v0.5 — the `fact_contradiction` table records
    `detected_at` (source-tx-time), not which axis the contradiction
    fires on. A v0.6 amendment may split contradictions by axis.

    `fact_a` is the primary fact (the one returned in `provenance`);
    `fact_b` is the counterpart. `episode_a` / `episode_b` carry the
    episode handles. NEVER auto-resolved — the consumer's LLM decides.
    """

    model_config = ConfigDict(frozen=True)

    episode_a: UUID
    episode_b: UUID
    fact_a: UUID
    fact_b: UUID
    verdict: Literal["refinement", "update", "contradiction"]
    axis: Literal["valid_at", "asserted_at", "both"] = "asserted_at"
    summary: str = ""


class QueryTelemetry(BaseModel):
    """Per-envelope-axis telemetry (extends #54 telemetry shape).

    Surfaces how the envelope's filter primitives shaped the response so
    eval harnesses and observability can attribute drops to a specific
    axis (range vs floor vs budget).

    `recall_telemetry` carries the existing `RecallTelemetry` shape
    inline so a single envelope dump reproduces what the underlying
    pipeline emitted; no separate round-trip needed.
    """

    model_config = ConfigDict(frozen=True)

    topic: str = Field(default="general", description="Pipeline that served the request.")
    max_episodes: int = DEFAULT_MAX_EPISODES
    max_tokens: int = DEFAULT_MAX_TOKENS
    facts_considered: int = 0
    facts_after_floor: int = 0
    facts_after_range: int = 0
    confidence_floor: float = 0.0
    recall_telemetry: RecallTelemetry = Field(default_factory=RecallTelemetry)
    post_recall_filter: bool = True
    unknown_topics: list[str] = Field(default_factory=list)
    # Typed-store lane row counts (#134 / ADR-0013 v0.6 row). Pre-cap
    # rows returned by `lab_pipeline.query` / `med_pipeline.query`;
    # `max_episodes` still caps the survivors that reach `provenance`.
    clinical_lab_rows: int = 0
    clinical_med_rows: int = 0


class QueryResponse(BaseModel):
    """Declarative envelope output (ADR-0013).

    `value` is `None` in v0.5 — gnokee does not host an LLM (AGENTS.md
    "do not" list). The consumer's LLM synthesises the answer prose
    from `provenance` + `citations`. The field is reserved so a future
    host-side adapter can populate it without a breaking schema change.

    `provenance` is a flat list of per-claim handles in deterministic
    emission order (facts → excerpts → episode_fallback). `citations`
    is the same data shaped as the ADR-0016 `{c1, c2, …}` map for
    inline `[cN]` back-reference by the host LLM.
    """

    model_config = ConfigDict(frozen=True)

    value: str | None = None
    provenance: list[ProvenanceEntry] = Field(default_factory=list)
    confidence: float = 0.0
    contradictions: list[ContradictionEntry] = Field(default_factory=list)
    citations: dict[str, Citation] = Field(default_factory=dict)
    query_telemetry: QueryTelemetry = Field(default_factory=QueryTelemetry)


def _recency_proxy(
    *,
    as_of: datetime,
    valid_at: datetime,
    half_life_days: float = RECENCY_HALF_LIFE_DAYS,
) -> float:
    """ADR-0019 function B — recency-only Ebbinghaus.

    `confidence = exp(-Δt_days / half_life_days)` where
    `Δt = as_of - valid_at`. Δt is clamped to ≥ 0 so a fact whose
    `valid_at` is in the future (i.e. caller asked about a future
    event) reads as `confidence = 1.0` rather than overflowing.

    NOT a calibrated probability — cal_max = 0.41 on the Q13 spike.
    Documented as a proxy in the tool description.
    """
    delta = (as_of - valid_at).total_seconds() / 86400.0
    if delta < 0:
        delta = 0.0
    return math.exp(-delta / half_life_days)


def _aggregate_confidence(values: list[float]) -> float:
    """Arithmetic mean across the post-floor / post-range survivors.

    Returns 0.0 when the list is empty so the top-level `confidence`
    is well-defined for empty result envelopes.
    """
    if not values:
        return 0.0
    return sum(values) / len(values)


def _normalise_topics(topics: list[str]) -> tuple[list[Topic], list[str]]:
    """Split caller-supplied topics into (known, unknown) lists.

    Unknown topics fall through to `general` routing — recorded in
    `query_telemetry.unknown_topics` so a consumer that mistyped a
    topic sees the warning instead of getting silent fallthrough.
    """
    known_set: set[str] = {"general", "clinical.lab", "clinical.med"}
    known: list[Topic] = []
    unknown: list[str] = []
    for raw in topics:
        if raw in known_set:
            # Literal narrows on membership check.
            known.append(raw)  # type: ignore[arg-type]
        else:
            unknown.append(raw)
    if not known and not unknown:
        known = ["general"]
    elif not known:
        # Caller passed only unknown topics → fall through to general.
        known = ["general"]
    return known, unknown


def _filter_facts_by_range(
    facts: list[FactStatement],
    *,
    valid_at_range: DateRange | None,
    asserted_at_range: DateRange | None,
) -> list[FactStatement]:
    """Post-recall filter on the full bi-temporal range bounds.

    The recall pipeline filters edges on `r.valid_at <= $valid_at` +
    `r.invalid_at > $valid_at` (single point pin). The envelope adds
    `gte` bounds on top: a fact whose `valid_at < valid_at_range.gte`
    or whose `asserted_at < asserted_at_range.gte` is dropped. The
    `lte` bounds are already enforced by the recall pin (we set it to
    `lte` before calling).

    Axis-safe: `valid_at_range` filters `fact.valid_at` only;
    `asserted_at_range` filters `fact.asserted_at` only. NEVER touches
    `created_at` (ingest-system time, NOT a knowledge axis).
    """
    out: list[FactStatement] = []
    for fact in facts:
        if valid_at_range is not None:
            if valid_at_range.gte is not None and fact.valid_at < valid_at_range.gte:
                continue
            if valid_at_range.lte is not None and fact.valid_at > valid_at_range.lte:
                continue
        if asserted_at_range is not None:
            if asserted_at_range.gte is not None and fact.asserted_at < asserted_at_range.gte:
                continue
            if asserted_at_range.lte is not None and fact.asserted_at > asserted_at_range.lte:
                continue
        out.append(fact)
    return out


def _filter_episode_facts_by_range(
    rows: list[EpisodeFact],
    *,
    valid_at_range: DateRange | None,
    asserted_at_range: DateRange | None,
) -> list[EpisodeFact]:
    """Same bi-temporal range filter, applied to ``EpisodeFact`` body rows.

    Episode-body rows carry their own `valid_at` + `asserted_at` (from
    the episode metadata) so the envelope's bi-temporal range filter
    applies to them identically — a body row outside the range drops
    just like a fact would. Axis-safe: `valid_at_range` filters
    `row.valid_at`; `asserted_at_range` filters `row.asserted_at`.
    """
    out: list[EpisodeFact] = []
    for row in rows:
        if valid_at_range is not None:
            if valid_at_range.gte is not None and row.valid_at < valid_at_range.gte:
                continue
            if valid_at_range.lte is not None and row.valid_at > valid_at_range.lte:
                continue
        if asserted_at_range is not None:
            if asserted_at_range.gte is not None and row.asserted_at < asserted_at_range.gte:
                continue
            if asserted_at_range.lte is not None and row.asserted_at > asserted_at_range.lte:
                continue
        out.append(row)
    return out


def _facts_to_provenance(facts: list[FactStatement]) -> list[ProvenanceEntry]:
    return [
        ProvenanceEntry(
            episode_uuid=f.episode_uuid,
            fact_uuid=f.fact_uuid,
            valid_at=f.valid_at,
            asserted_at=f.asserted_at,
        )
        for f in facts
    ]


def _episode_facts_to_provenance(
    rows: list[EpisodeFact],
) -> list[ProvenanceEntry]:
    return [
        ProvenanceEntry(
            episode_uuid=r.episode_uuid,
            fact_uuid=None,
            valid_at=r.valid_at,
            asserted_at=r.asserted_at,
        )
        for r in rows
    ]


def _excerpts_to_provenance(
    excerpts: list[Excerpt],
    *,
    metadata: dict[UUID, tuple[datetime, datetime]],
) -> list[ProvenanceEntry]:
    """Map `Excerpt` rows to provenance entries via the metadata lookup.

    Excerpts don't carry bi-temporal axes themselves (the lane is body-
    surface, not edge-fact); the metadata lookup is the source of truth.
    Defensive: skip excerpts whose episode lacks a metadata entry
    (rare; would mean the episode passed filter_visible but its row
    vanished mid-recall).
    """
    out: list[ProvenanceEntry] = []
    for excerpt in excerpts:
        meta = metadata.get(excerpt.episode_uuid)
        if meta is None:
            continue
        valid_at, asserted_at = meta
        out.append(
            ProvenanceEntry(
                episode_uuid=excerpt.episode_uuid,
                fact_uuid=None,
                valid_at=valid_at,
                asserted_at=asserted_at,
            )
        )
    return out


def _lab_rows_to_provenance(rows: list[LabRowOut]) -> list[ProvenanceEntry]:
    return [
        ProvenanceEntry(
            episode_uuid=row.episode_uuid,
            fact_uuid=None,
            valid_at=row.valid_at,
            asserted_at=row.asserted_at,
            source_uri="lab_record",
        )
        for row in rows
    ]


def _med_rows_to_provenance(rows: list[MedRowOut]) -> list[ProvenanceEntry]:
    return [
        ProvenanceEntry(
            episode_uuid=row.episode_uuid,
            fact_uuid=None,
            valid_at=row.valid_at,
            asserted_at=row.asserted_at,
            source_uri="med_record",
        )
        for row in rows
    ]


def _extend_citations_with_clinical_rows(
    citations: dict[str, Citation],
    *,
    lab_rows: list[LabRowOut],
    med_rows: list[MedRowOut],
) -> None:
    """Extend the c-namespace contiguously with typed-store rows.

    Recall lanes (facts → excerpts → episode_fallback) have already
    populated `c1..cN`. Lab rows continue at `c{N+1}`, then med rows. No
    `c1` collision because `build_row_citations` (per-pipeline standalone
    usage) re-keys for ``gnokee_lab_query`` / ``gnokee_med_query`` only —
    when the envelope merges all lanes (``gnokee_query``), keys flow.
    """
    offset = len(citations)
    for index, lab in enumerate(lab_rows):
        citations[citation_key(offset + index)] = Citation(
            episode_uuid=lab.episode_uuid,
            fact_uuid=None,
            valid_at=lab.valid_at,
            asserted_at=lab.asserted_at,
            extracted_quote=None,
            source_uri=None,
        )
    offset = len(citations)
    for index, med in enumerate(med_rows):
        citations[citation_key(offset + index)] = Citation(
            episode_uuid=med.episode_uuid,
            fact_uuid=None,
            valid_at=med.valid_at,
            asserted_at=med.asserted_at,
            extracted_quote=None,
            source_uri=None,
        )


def _contradictions_from_facts(
    facts: list[FactStatement],
) -> list[ContradictionEntry]:
    """Unwrap each `FactStatement.contradicts[]` into the flat envelope list.

    `axis` is fixed to `"asserted_at"` in v0.5 — see ADR-0013 §
    Contradictions for why. The flat shape carries `fact_a` (primary)
    and `fact_b` (counterpart) plus both episode handles so the consumer
    can fetch either side via `gnokee_fact_provenance`.

    The counterpart's `episode_uuid` is NOT known to the recall
    pipeline today (`ContradictionRef` carries `fact_uuid` + `verdict`
    + `summary` + `valid_at`, not the episode handle). v0.5 reuses
    the primary fact's `episode_uuid` for `episode_b` as a defensive
    placeholder; v0.5.x can join through `fact_contradiction` →
    `RELATES_TO.episode_uuid` if a consumer needs both episode
    handles distinctly.
    """
    out: list[ContradictionEntry] = []
    for fact in facts:
        for counterpart in fact.contradicts:
            out.append(
                ContradictionEntry(
                    episode_a=fact.episode_uuid,
                    episode_b=fact.episode_uuid,  # v0.5 placeholder; see docstring.
                    fact_a=fact.fact_uuid,
                    fact_b=counterpart.fact_uuid,
                    verdict=counterpart.verdict,
                    axis="asserted_at",
                    summary=counterpart.summary,
                )
            )
    return out


def _build_excerpt_metadata(
    facts: list[FactStatement],
    excerpts: list[Excerpt],
    episode_fallback: list[EpisodeFact],
) -> dict[UUID, tuple[datetime, datetime]]:
    """Derive an (episode_uuid → (valid_at, asserted_at)) lookup from the
    in-flight response rows.

    Facts carry both axes directly; episode-body rows do too. Excerpts
    inherit from whichever fact / body row shares their episode handle.
    This keeps the envelope orchestrator decoupled from `MetadataStore`
    — no extra storage read.
    """
    meta: dict[UUID, tuple[datetime, datetime]] = {}
    for fact in facts:
        meta.setdefault(fact.episode_uuid, (fact.valid_at, fact.asserted_at))
    for row in episode_fallback:
        meta.setdefault(row.episode_uuid, (row.valid_at, row.asserted_at))
    # Excerpts whose episode appears in neither facts nor fallback rows
    # have no metadata source on the response — they will be dropped by
    # `_excerpts_to_provenance` rather than fabricating axes.
    _ = excerpts
    return meta


def _apply_output_shape(
    *,
    output_shape: OutputShape,
    facts: list[FactStatement],
    excerpts: list[Excerpt],
    episode_fallback: list[EpisodeFact],
) -> tuple[list[FactStatement], list[Excerpt], list[EpisodeFact]]:
    """Reshape recall lanes per `output_shape`.

    - `fact` — drop excerpts + episode_fallback; keep facts only.
    - `episode` — drop facts; keep episode_fallback only. Excerpts
      drop too (they live in the fact-signal lane, not the body lane).
    - `mixed` — keep everything (default).
    """
    if output_shape == "fact":
        return facts, [], []
    if output_shape == "episode":
        return [], [], episode_fallback
    return facts, excerpts, episode_fallback


def _recall_pin_for(
    range_filter: DateRange | None,
    fallback: datetime,
) -> datetime:
    """Return the point pin to pass to the underlying recall pipeline.

    Use `lte` when supplied (so the recall pipeline filters edges
    `r.valid_at <= lte`), else the caller-supplied fallback (defaults
    to `utc_now()`). The `gte` bound is enforced post-recall.
    """
    if range_filter is not None and range_filter.lte is not None:
        return range_filter.lte
    return fallback


async def gnokee_query(
    *,
    recall_pipeline: RecallPipeline,
    lab_pipeline: LabQueryPipeline | None,
    med_pipeline: MedQueryPipeline | None,
    envelope: QueryEnvelope,
    as_of: datetime | None = None,
) -> QueryResponse:
    """Run the declarative envelope against the pipeline trio.

    Orchestrator only — no I/O of its own. Composes
    `RecallPipeline.recall(...)` for the recall lanes and, when the
    envelope names a `clinical.*` topic, the matching typed-store
    pipeline (`LabQueryPipeline` / `MedQueryPipeline`).

    The orchestrator does the following in order:

    1. Resolve `as_of` (caller pin or `utc_now()`).
    2. Pick recall pins from the `lte` bound of each range filter
       (defaults: `as_of` for asserted, `as_of` for valid).
    3. Call `recall_pipeline.recall(...)` with the envelope's
       `max_tokens` and `surface_contradictions=True`.
    4. Apply `output_shape` to the recall response.
    5. Post-filter facts on `valid_at_range.gte` + `asserted_at_range`.
    6. Compute the recency-proxy `confidence` per fact and filter on
       `confidence_floor`.
    7. Cap survivors at `budget.max_episodes`.
    8. When `clinical.lab` ∈ topics + `lab_pipeline` is supplied: call
       `lab_pipeline.query(op="abnormal", analyte=None, ...)`. When
       `clinical.med` ∈ topics + `med_pipeline` is supplied: call
       `med_pipeline.query(op="active", drug_name=None, ...)`. Both
       pass the envelope's `valid_at_range.gte/lte` as `since/until`
       and the recall pins as `as_of`/`valid_at`. Post-filter on
       `asserted_at_range.gte` (the typed-store API only accepts the
       `as_of` point pin natively), cap per-lane at `max_episodes`.
    9. Assemble `provenance`, `citations`, `contradictions`, and
       `query_telemetry`. Typed-store rows extend the c-namespace
       contiguously (`c{N+1}`, …) and surface as `ProvenanceEntry`
       rows with `source_uri="lab_record"` / `"med_record"`.

    Safe-defaults posture for clinical routing (#134 / ADR-0013 v0.6
    row): the envelope today carries no analyte / drug_name slot, so
    the orchestrator picks the most-common typed-store surface per
    topic (abnormal labs / active meds). Ask-parsing for analyte +
    drug-name extraction is a v0.6.1 follow-up.
    """
    if not envelope.filter.tenant_id:
        raise ValidationError("tenant_id is required")

    as_of_eff = _require_utc(as_of) if as_of is not None else utc_now()
    valid_pin = _recall_pin_for(envelope.filter.valid_at_range, fallback=as_of_eff)
    asserted_pin = _recall_pin_for(envelope.filter.asserted_at_range, fallback=as_of_eff)

    known_topics, unknown_topics = _normalise_topics(envelope.filter.topics)
    topic_label = ",".join(known_topics)

    response: RecallResponse = await recall_pipeline.recall(
        tenant_id=envelope.filter.tenant_id,
        text=envelope.ask,
        as_of=asserted_pin,
        valid_at=valid_pin,
        surface_contradictions=True,
        max_tokens=envelope.budget.max_tokens,
    )

    facts, excerpts, episode_fallback = _apply_output_shape(
        output_shape=envelope.output_shape,
        facts=list(response.facts),
        excerpts=list(response.excerpts),
        episode_fallback=list(response.episode_fallback),
    )

    facts_considered = len(facts)

    # Range filter — strict gte/lte against both bi-temporal axes.
    facts = _filter_facts_by_range(
        facts,
        valid_at_range=envelope.filter.valid_at_range,
        asserted_at_range=envelope.filter.asserted_at_range,
    )
    facts_after_range = len(facts)

    # ADR-0019 recency-proxy `confidence` per fact. Compute first so we
    # can filter on the floor and surface the aggregate.
    proxy_lookup: dict[UUID, float] = {
        fact.fact_uuid: _recency_proxy(as_of=asserted_pin, valid_at=fact.valid_at) for fact in facts
    }
    facts = [fact for fact in facts if proxy_lookup[fact.fact_uuid] >= envelope.confidence_floor]
    facts_after_floor = len(facts)

    # Apply the same bi-temporal range filter to episode-body rows so
    # the body lane respects the envelope's filter (they carry their
    # own `valid_at` + `asserted_at`). Excerpts have no per-row axes —
    # they inherit from the parent fact / episode, so they survive iff
    # their episode appears among the surviving facts OR body rows.
    episode_fallback = _filter_episode_facts_by_range(
        episode_fallback,
        valid_at_range=envelope.filter.valid_at_range,
        asserted_at_range=envelope.filter.asserted_at_range,
    )
    surviving_episodes = {fact.episode_uuid for fact in facts} | {row.episode_uuid for row in episode_fallback}
    excerpts = [e for e in excerpts if e.episode_uuid in surviving_episodes]

    # max_episodes cap — applied last so it does not silently drop facts
    # that survived the more meaningful semantic filters.
    if len(facts) > envelope.budget.max_episodes:
        facts = facts[: envelope.budget.max_episodes]
    if len(episode_fallback) > envelope.budget.max_episodes:
        episode_fallback = episode_fallback[: envelope.budget.max_episodes]

    # Stamp the recency-proxy confidence onto the surviving facts so the
    # citation envelope sees a populated value (Citation today does not
    # carry `confidence`; FactStatement does).
    facts = [fact.model_copy(update={"confidence": proxy_lookup[fact.fact_uuid]}) for fact in facts]

    # Citations — reuse the ADR-0016 builder. Extracted-quote lookup is
    # `None` everywhere in v0.5 (extraction stage does not record body
    # spans; ADR-0016 § Migration strategy).
    excerpt_metadata = _build_excerpt_metadata(facts, excerpts, episode_fallback)
    extracted_quotes: dict[UUID, str | None] = {
        ep_uuid: None for ep_uuid in (excerpt_metadata.keys() | {e.episode_uuid for e in excerpts})
    }
    citations: dict[str, Citation] = build_recall_citations(
        facts=facts,
        excerpts=excerpts,
        episode_fallback=episode_fallback,
        extracted_quotes=extracted_quotes,
        excerpt_metadata=excerpt_metadata,
    )

    # Clinical typed-store routing — #134 / ADR-0013 v0.6 row. Fires
    # AFTER recall so the c-namespace extends contiguously and
    # provenance keeps deterministic order (recall lanes → lab → med).
    # The typed-store API filters world-time via `since`/`until` and
    # pins source-tx-time via `as_of`; the `asserted_at_range.gte`
    # post-filter compensates for the missing native gte clause.
    valid_range = envelope.filter.valid_at_range
    asserted_range = envelope.filter.asserted_at_range
    since = valid_range.gte if valid_range is not None else None
    until = valid_range.lte if valid_range is not None else None
    asserted_gte = asserted_range.gte if asserted_range is not None else None

    lab_response: LabQueryResponse | None = None
    lab_rows: list[LabRowOut] = []
    if "clinical.lab" in known_topics and lab_pipeline is not None:
        lab_response = await lab_pipeline.query(
            tenant_id=envelope.filter.tenant_id,
            analyte=None,
            op="abnormal",
            since=since,
            until=until,
            as_of=asserted_pin,
            valid_at=valid_pin,
            limit=envelope.budget.max_episodes,
        )
        lab_rows = list(lab_response.rows)
        if asserted_gte is not None:
            lab_rows = [r for r in lab_rows if r.asserted_at >= asserted_gte]
        if len(lab_rows) > envelope.budget.max_episodes:
            lab_rows = lab_rows[: envelope.budget.max_episodes]

    med_response: MedQueryResponse | None = None
    med_rows: list[MedRowOut] = []
    if "clinical.med" in known_topics and med_pipeline is not None:
        med_response = await med_pipeline.query(
            tenant_id=envelope.filter.tenant_id,
            op="active",
            drug_name=None,
            since=since,
            until=until,
            as_of=asserted_pin,
            valid_at=valid_pin,
            limit=envelope.budget.max_episodes,
        )
        med_rows = list(med_response.rows)
        if asserted_gte is not None:
            med_rows = [r for r in med_rows if r.asserted_at >= asserted_gte]
        if len(med_rows) > envelope.budget.max_episodes:
            med_rows = med_rows[: envelope.budget.max_episodes]

    _extend_citations_with_clinical_rows(
        citations,
        lab_rows=lab_rows,
        med_rows=med_rows,
    )

    # Provenance — flat, deterministic emission order matching citations.
    provenance: list[ProvenanceEntry] = []
    provenance.extend(_facts_to_provenance(facts))
    provenance.extend(_excerpts_to_provenance(excerpts, metadata=excerpt_metadata))
    provenance.extend(_episode_facts_to_provenance(episode_fallback))
    provenance.extend(_lab_rows_to_provenance(lab_rows))
    provenance.extend(_med_rows_to_provenance(med_rows))

    # Contradictions — flat list from the surviving facts. Per ADR-0008,
    # NEVER auto-resolved; the consumer's LLM presents both sides.
    contradictions = _contradictions_from_facts(facts)

    confidence_aggregate = _aggregate_confidence([proxy_lookup[fact.fact_uuid] for fact in facts])

    telemetry = QueryTelemetry(
        topic=topic_label or "general",
        max_episodes=envelope.budget.max_episodes,
        max_tokens=envelope.budget.max_tokens,
        facts_considered=facts_considered,
        facts_after_floor=facts_after_floor,
        facts_after_range=facts_after_range,
        confidence_floor=envelope.confidence_floor,
        recall_telemetry=response.recall_telemetry,
        post_recall_filter=True,
        unknown_topics=unknown_topics,
        clinical_lab_rows=lab_response.count if lab_response is not None else 0,
        clinical_med_rows=med_response.count if med_response is not None else 0,
    )

    return QueryResponse(
        value=None,  # ADR-0013 § value field — null in v0.5 (no LLM hosting).
        provenance=provenance,
        confidence=confidence_aggregate,
        contradictions=contradictions,
        citations=citations,
        query_telemetry=telemetry,
    )


__all__ = [
    "DEFAULT_MAX_EPISODES",
    "DEFAULT_MAX_TOKENS",
    "RECENCY_HALF_LIFE_DAYS",
    "ContradictionEntry",
    "DateRange",
    "ProvenanceEntry",
    "QueryEnvelope",
    "QueryEnvelopeBudget",
    "QueryEnvelopeFilter",
    "QueryResponse",
    "QueryTelemetry",
    "_recency_proxy",
    "gnokee_query",
]
