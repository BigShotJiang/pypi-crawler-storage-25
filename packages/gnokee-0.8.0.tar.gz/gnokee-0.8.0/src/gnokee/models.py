"""src/gnokee/models.py — Pydantic v2 contracts for the gnokee v0.1 surface.

These shapes are the public contract for ingest, recall, and provenance.
External consumers (Omur, personal stacks) develop against them; breaking
a model = breaking the API.

All datetime fields require tz-aware UTC. Naive datetimes are rejected at
the Pydantic boundary as a defence-in-depth check.

exports: class EpisodeIn | class IngestReceipt | class IngestTelemetry | class FactStatement | class ContradictionRef | class Excerpt | class EpisodeFact | class SupersessionHint | class RecallTelemetry | class RecallResponse | class FactProvenance | class EncryptedBody | class EncryptedEpisodeBody | class Citation | class HistoryNode | class HistoryEdge | class HistoryResponse | Sensitivity | HistoryStatus | ForgetEpisodeIn | ForgetTenantIn | ForgetReceipt | ForgetReceiptDetail
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/mcp.py | src/gnokee/history.py
rules:   pure data + validators only; no I/O; UTC-only datetimes
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-opus-4-7 | 2026-05-10 | issue #22 encrypted_body wire-up
         claude-opus-4-7 | 2026-05-11 | issue #76 / ADR-0016 per-claim citation envelope
         claude-sonnet-4-6 | 2026-05-12 | issue #89 cosine_top1 telemetry field on FactStatement
         claude-sonnet-4-6 | 2026-05-12 | issue #94 / ADR-0022 Option A refused signal
         claude-opus-4-7 | 2026-05-16 | issue #123 gnokee_history_of DAG models
         claude-haiku-4-5 | 2026-05-16 | issue #130 ADR-0026 forget models
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Sensitivity = Literal["public", "private", "clinical"]
"""Per-fact sensitivity tag. Drives retrieval gating; see ``docs/architecture.md``."""

Verdict = Literal["refinement", "update", "contradiction"]
"""Q4 contradiction verdicts that get persisted (`unrelated` is dropped)."""


def _require_utc(value: datetime) -> datetime:
    """Reject naive AND non-UTC tz-aware datetimes at the model boundary.

    Spec §3 invariant: "All gnokee `datetime` values are tz-aware UTC."
    Silent coercion would mask axis-assignment bugs; reject hard.
    """
    if value.tzinfo is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    if value.utcoffset() != timedelta(0):
        raise ValueError(f"datetime must be UTC; got utcoffset={value.utcoffset()}")
    return value


class EncryptedBody(BaseModel):
    """Pre-encrypted episode body (issue #22 / v0.3+).

    Consumer encrypts the episode body in-process with a DEK they own,
    then hands gnokee the resulting (ciphertext, nonce, key_id) triple.
    gnokee NEVER holds the DEK and NEVER decrypts. The ``key_id``
    references the DEK in the consumer's KMS (OpenBao for Omur,
    libsodium-via-pynacl in tests). On recall the same triple is
    surfaced verbatim so the consumer's session-side code can unwrap.

    ``content_for_embedding`` is the embed-only plaintext window. When
    set, gnokee runs it through the embedder and stores ONLY the
    1024-dim ``content_embedding`` row. The plaintext leaves the
    gnokee process only over the TEI socket; once ``embed()`` returns,
    the plaintext is dropped from local scope before any other stage
    touches it (Stage 4 lite Episodic writes ``content=""``, Stage 6
    clinical parsers are skipped — see ``ingest.py`` § Encrypted-body
    branch). Issue #132 hardened the contract after v0.6.0 was caught
    persisting the window to Neo4j ``Episodic.content`` + deriving
    ``lab_record`` / ``med_record`` rows from it. When ``None`` the
    semantic-recall lane has no embedding for this episode and
    BM25/cosine RRF degrades to graph + lab/med structured stores
    (correct — there is no plaintext to index). The consumer is the
    sole owner of this trade-off.
    """

    model_config = ConfigDict(frozen=True)

    ciphertext: bytes
    nonce: bytes
    key_id: str = Field(
        description="References a DEK in the consumer's KMS (e.g. OpenBao for Omur).",
    )
    content_for_embedding: str | None = Field(
        default=None,
        description=(
            "Optional embed-only plaintext window. When set, gnokee embeds "
            "it for the cosine lane and DROPS the plaintext after the "
            "embedder returns — never persisted. When None, the episode is "
            "absent from the semantic recall lane (graph + structured stores "
            "still fire)."
        ),
    )


class EncryptedEpisodeBody(BaseModel):
    """Recall-side surface for a ciphertext episode body (issue #22).

    Returned by ``RecallResponse.encrypted_bodies`` and
    ``FactProvenance.encrypted_body`` when the episode was ingested via
    the ``encrypted_body`` branch. gnokee returns the ciphertext +
    envelope verbatim — the consumer decrypts using their KMS via
    ``key_id``. NEVER carries plaintext.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID
    ciphertext: bytes
    nonce: bytes
    key_id: str = Field(
        description="References the DEK in the consumer's KMS that decrypts this body.",
    )


class EpisodeIn(BaseModel):
    """Input shape for `gnokee.ingest_episode(...)` and `gnokee_ingest_episode` MCP tool."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    content: str | None = Field(default=None)
    encrypted_body: EncryptedBody | None = Field(default=None)
    valid_at: datetime
    valid_until: datetime | None = None
    asserted_at: datetime | None = Field(
        default=None,
        description="When the consumer learned of this fact. Defaults to now(UTC) at the API boundary.",
    )
    our_id: str | None = Field(
        default=None,
        description=(
            "Consumer-supplied stable id, unique per (tenant_id, our_id). When set, re-ingest "
            "with the same key returns the existing episode (replayed=True) and skips Graphiti "
            "extraction, vector write, and contradiction detection."
        ),
    )
    entity_type_hints: list[str] | None = Field(default=None)
    sensitive: Sensitivity = "private"
    language: str | None = Field(
        default=None,
        description="ISO 639-1; auto-detect when null.",
    )
    corrects: UUID | None = Field(
        default=None,
        description=(
            "When set, declares this episode supersedes a prior one. "
            "Same-tenant only; corrected episode must exist in "
            "episode_metadata; new asserted_at must be > "
            "corrected.asserted_at. Closes matching lab_record + "
            "med_record rows from the corrected episode and sets "
            "episode_metadata.asserted_until + superseded_by. "
            "Caller-asserted only — no heuristic detection. Graphiti "
            "edges are NOT auto-superseded; narrative corrections flow "
            "through ADR-0008 contradiction surfacing."
        ),
    )
    corrects_reason: str | None = Field(
        default=None,
        max_length=500,
        description=(
            "Short human-readable rationale for the supersession (#123). "
            "Surfaced verbatim on `HistoryNode.rationale` for the "
            "successor in `gnokee_history_of` DAGs. Capped at 500 chars; "
            "longer rationales should ship as ordinary episode content. "
            "Only honored when `corrects` is also set."
        ),
    )

    @field_validator("valid_at", "valid_until", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        return _require_utc(value)

    @field_validator("our_id")
    @classmethod
    def _our_id_non_empty(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.strip():
            raise ValueError("our_id must be a non-empty string when set")
        return value

    @model_validator(mode="after")
    def _content_xor_encrypted_body(self) -> EpisodeIn:
        """Stage 1 boundary: ``content`` xor ``encrypted_body`` (issue #22).

        Both set → ambiguous source of truth, reject. Neither set →
        nothing to ingest, reject. Exactly one accepted. ValidationError
        is raised by the public ``ingest_episode`` wrapper; callers see
        ``gnokee.errors.ValidationError`` on the boundary.
        """
        has_content = self.content is not None
        has_encrypted = self.encrypted_body is not None
        if has_content and has_encrypted:
            raise ValueError(
                "EpisodeIn: content and encrypted_body are mutually exclusive "
                "(content xor encrypted_body) — pass exactly one"
            )
        if not has_content and not has_encrypted:
            raise ValueError("EpisodeIn: one of content or encrypted_body is required")
        return self


class ContradictionRef(BaseModel):
    """Pointer to the OTHER side of a contradiction surfaced at ingest or recall."""

    model_config = ConfigDict(frozen=True)

    fact_uuid: UUID
    verdict: Verdict
    summary: str
    valid_at: datetime

    @field_validator("valid_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class FactStatement(BaseModel):
    """A single fact as returned from `gnokee.recall(...)`.

    `text` is a compact natural-language fact statement (Q3-validated shape).
    `fact_uuid` is the lazy provenance handle — call `gnokee_fact_provenance`
    to fetch the full episode body and metadata.

    `cosine_top1` (issue #89 / ADR-0019 follow-up) — per-fact cosine
    similarity of the source episode's content_embedding vs the query
    embedding, in [0, 1] (``1 - pgvector_cosine_distance``). Populated
    only when ``recall()`` is called with ``include_cosine_top1=True``
    AND the fact's episode appeared in the pgvector ANN result. ``None``
    when the flag is off (default — keeps the wire shape stable for
    non-opt-in consumers) OR when the fact arrived via the episode-cosine
    fallback Path A and the episode had no vector counterpart in the ANN
    result. Telemetry only — do NOT use to reorder facts or suppress them.
    """

    text: str
    fact_uuid: UUID
    episode_uuid: UUID
    valid_at: datetime
    asserted_at: datetime
    confidence: float | None = None
    cosine_top1: float | None = Field(
        default=None,
        description=(
            "Issue #89 — per-fact pgvector cosine similarity (1 - distance) of the "
            "source episode vs the query. Populated only when recall() is called with "
            "include_cosine_top1=True. None when flag is off or the episode had no "
            "ANN hit (e.g. Path-A episode-fallback). Telemetry signal only."
        ),
    )
    contradicts: list[ContradictionRef] = Field(default_factory=list)

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class Excerpt(BaseModel):
    """Verbatim ``Episodic.content`` excerpt around a currency / amount line.

    Surfaced on recall when the query references currency or amount-keyword
    tokens and graphiti's edge-fact LLM has summarised the digits away
    from ``FactStatement.text``. Carries the raw line so the agent can
    quote it back to the user. See ``gnokee.excerpts`` for the extractor.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID
    text: str = Field(min_length=1)


class EpisodeFact(BaseModel):
    """Episode body row surfaced alongside (or in place of) edge facts.

    Carries the verbatim ``Episodic.content`` body of a top-K ranked
    episode so the consumer's synthesiser has the literal answer text
    even when Graphiti's edge-fact LLM summarised the digits / drug
    names / dates away. Two trigger conditions, signalled by
    ``RecallResponse.body_used = True``:

    * **Hybrid emission (#41).** Edge facts present, query carries
      no excerpt signal — body rows fire with a third of ``max_tokens``
      so conversation-shape literals (counts, dates, values) survive
      the fact-only summarisation.
    * **Empty-fact fallback (ADR-0012 Path A).** Cosine ranks
      candidates but Graphiti synthesised zero edges — body rows take
      the full budget instead.

    Distinct from :class:`Excerpt`: that one is a signal-gated
    currency / med-keyword snippet around a single line; this one is
    the full body of a top-K ranked episode.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID
    text: str = Field(min_length=1)
    valid_at: datetime
    asserted_at: datetime

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class SupersessionHint(BaseModel):
    """Issue #19 hint surfacing.

    Emitted by `gnokee.recall(...)` when an episode is cosine-relevant
    AND has been superseded at the caller's `as_of` (so it is correctly
    hidden from the narrative facts/excerpts), but its row-level
    `lab_record` / `med_record` data may still be open. Lets the agent
    discover the gap without surfacing a stale narrative on the hot
    path. Resolution: call `gnokee_lab_query` / `gnokee_med_query` for
    the typed reads, or pin `as_of` pre-correction to read the original
    panel narrative.
    """

    model_config = ConfigDict(frozen=True)

    superseded_uuid: UUID = Field(
        description="Episode that ranked top-K on cosine but was hidden by supersession.",
    )
    current_head_uuid: UUID = Field(
        description=(
            "Chain head of the supersession chain at the caller's `as_of`. "
            "Equal to `superseded_uuid` when the episode was closed without a "
            "named replacement (rare; e.g. a redaction)."
        ),
    )
    superseded_at: datetime = Field(
        description="`asserted_until` of the hidden episode (when the correction landed).",
    )

    @field_validator("superseded_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class Citation(BaseModel):
    """Per-claim bi-temporal citation envelope entry (ADR-0016, issue #76).

    One entry per inline `[cN]` marker the host LLM emits in its answer. The
    host LLM produces the marker text; gnokee guarantees every citation
    carries both bi-temporal axes (`valid_at` = world-time, `asserted_at` =
    source-tx-time), the episode handle, and (when the extraction stage
    recorded one) a verbatim `extracted_quote` body span.

    Strictly stronger than NotebookLM's `[1] = source_3.pdf` shape:

    * **bi-temporal**: callers see both `valid_at` and `asserted_at`, never
      a single opaque timestamp.
    * **episode + fact**: `episode_uuid` is always present; `fact_uuid` is
      populated when the citation backs a Graphiti edge fact (most facts
      from `gnokee_recall.facts`) and `None` when it backs a row-level
      typed-store entry (`lab_record`, `med_record`) or an episode-body
      surface (excerpt, episode_fallback).
    * **never hallucinated**: `extracted_quote` is filled ONLY when the
      extraction stage recorded a verbatim span from the episode body.
      `None` otherwise — gnokee REFUSES to synthesise a quote from a
      summarised fact statement (ADR-0016 § Anti-patterns to avoid).

    `source_uri` carries an optional external pointer (e.g. the consumer's
    original document URI) when the ingest path supplied one. v0.5 ships
    this as `None` everywhere; a follow-up issue wires it through the
    ingest surface once the consumer-supplied envelope lands.

    Pairs with the existing `provenance` axis on `RecallResponse` (the
    `facts[].fact_uuid` / `facts[].episode_uuid` handles) — the citation
    envelope is **additive**, both surfaces ship in the same minor version,
    and existing callers that walk `facts[]` keep working unchanged.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID = Field(
        description="The episode that backs this citation. Always present.",
    )
    fact_uuid: UUID | None = Field(
        default=None,
        description=(
            "Populated when the citation backs a Graphiti edge fact (a "
            "`FactStatement` row). `None` when it backs a typed clinical "
            "row (`lab_record` / `med_record`) or an episode-body surface "
            "(excerpt / episode_fallback) — those carry no per-fact UUID."
        ),
    )
    valid_at: datetime = Field(
        description="World-time the cited claim is true for (ADR-0001 axis).",
    )
    asserted_at: datetime = Field(
        description="Source-tx-time the consumer learned of it (ADR-0001 axis).",
    )
    extracted_quote: str | None = Field(
        default=None,
        description=(
            "Verbatim body span from `episode_metadata.extracted_quote`. "
            "`None` when the extraction stage did not record one (v0.5 "
            "default state — backfill in a follow-up issue). NEVER "
            "synthesised from an LLM paraphrase."
        ),
    )
    source_uri: str | None = Field(
        default=None,
        description=(
            "Optional consumer-supplied source URI (e.g. the original "
            "document URL). `None` until the ingest surface carries it."
        ),
    )

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class RecallTelemetry(BaseModel):
    """Per-lane budget vs emitted accounting for a single ``recall()`` call.

    Issue #54 — surfaces the Stage 6 budget split and actual emitted-token
    sums so eval harnesses can record how far real usage falls from the
    ``max_tokens`` cap, instead of inferring it from row counts. Counts
    duplicate ``len(facts | excerpts | episode_fallback)`` so harness JSON
    dumps stay self-describing without re-walking the response body.

    ``body_first_row_oversize`` surfaces the always-emit-first guard in
    ``RecallPipeline._build_episode_body_rows`` — when True, ``body_count``
    is 1 and ``body_tokens_emitted`` exceeds ``body_budget``. Lets the
    harness distinguish "budget too tight, raise it" from "single row
    barely fit, split is healthy".

    All counters default to zero so early-return paths in ``recall()`` can
    construct a default-shaped response without per-branch boilerplate.
    """

    budget_max_tokens: int = 0
    fact_budget: int = 0
    excerpt_budget: int = 0
    body_budget: int = 0
    fact_tokens_emitted: int = 0
    excerpt_tokens_emitted: int = 0
    body_tokens_emitted: int = 0
    fact_count: int = 0
    excerpt_count: int = 0
    body_count: int = 0
    body_first_row_oversize: bool = False


class IngestTelemetry(BaseModel):
    """Per-call diagnostic surface for ``IngestPipeline.ingest()``.

    Issue #111 (Q18 follow-up, 2026-05-12). The Q18 spike showed gnokee's
    ingest path silently loses episodes when graphiti's extraction stage
    strains (TPM-bound; orphan-edge warnings on multi-KB conversational
    haystacks). Today's ``IngestReceipt`` reports
    ``extraction_deferred`` but says nothing about *partial* extraction
    quality. ``IngestTelemetry`` carries the two counts a spike harness
    or observability layer needs to detect the silent-drop class:

    - ``orphan_edge_warnings`` — count of WARNING records emitted by
      ``graphiti_core.utils.maintenance.edge_operations`` during the
      Stage 4 ``add_episode`` call. Non-zero is not by itself a failure
      (graphiti drops the orphan edge and keeps the episode), but it
      correlates strongly with the Q18 silent-drop pattern. Use as an
      early-warning signal.
    - ``extraction_succeeded`` — True iff Stage 4 returned an episode
      with a non-null UUID. False on the encrypted / lite-mode branches
      (where Stage 4 is skipped) AND on any future failure mode where
      graphiti returns without a UUID. Distinguishes "extraction
      deliberately off" (lite / encrypted) from "extraction tried and
      didn't produce" using the receipt's
      ``extraction_deferred`` field — extraction_deferred=True ⇒
      extraction_succeeded=False is *expected*; extraction_deferred=False
      ⇒ extraction_succeeded=False is *unexpected* and warrants a
      loud-failure log.

    All counters default to zero so the encrypted / lite-mode paths
    (where Stage 4 is skipped) emit a clean ``IngestTelemetry()``
    without per-branch boilerplate.
    """

    orphan_edge_warnings: int = 0
    extraction_succeeded: bool = False
    enhancement_retries: int = Field(
        default=0,
        description=(
            "v0.6 Z4 (#111). Number of times the Z4 retry helper re-attempted "
            "graphiti.add_episode during this ingest call. 0 = first try succeeded "
            "or extraction was skipped (lite / encrypted). >0 = TPM / transient "
            "error caused retry; max value is the configured retry cap (default 3)."
        ),
    )
    lite_fallback_engaged: bool = Field(
        default=False,
        description=(
            "v0.6 Z1 (#111). True iff graphiti enhancement (Stage 6) failed after "
            "Z4 retry exhaustion or raised a non-retryable error, AND gnokee "
            "fell through to the lite-mode result (Episodic + episode_metadata + "
            "content_embedding written; entities + edges not). receipt."
            "extraction_deferred is also True in this case so "
            "maintenance.run_deferred_extraction can pick it up. False on the "
            "happy path and on deliberately-lite ingests (extract=False)."
        ),
    )


class RecallResponse(BaseModel):
    """Output of `gnokee.recall(...)`. Q3-validated shape.

    ``facts`` carries Graphiti edge-fact statements (the primary answer
    surface). ``episode_fallback`` carries verbatim ``Episodic.content``
    bodies of top-K ranked episodes — populated under hybrid emission
    (#41) when the query carries no excerpt signal, AND under the
    empty-fact fallback (ADR-0012 Path A). ``body_used`` signals either
    branch is active. ``excerpts`` and ``supersession_hints`` are
    independent of the body emission path.

    ``retrieved_episode_external_ids`` (#50) carries the consumer-supplied
    ``our_id`` of the BM25/cosine top-K ranked **visible** episodes, in
    fused-rank order. Lets eval harnesses score the BM25/cosine ranking
    surface directly instead of inferring it from the fact-derived
    MENTIONS-edge backwalk (which the BM25 lane couldn't influence).
    Empty when the corresponding ``our_id`` was not supplied at ingest
    time, or when no visible episode survived stage 3.5.

    ``recall_telemetry`` (#54) carries Stage 6 per-lane budget vs emitted
    counters so eval harnesses can record actual budget usage per call.

    ``refused`` (ADR-0022 Option A, issue #94) is ``True`` when the
    retrieval pipeline returned zero facts AND zero episode_fallback rows.
    Computed post-retrieval; never auto-resolves contradictions or
    suppresses any fact. Consumer LLMs should render an explicit "I cannot
    answer from these sources" message when ``refused=True``. The flag is
    most meaningful when combined with a ``cosine_floor`` knob that can
    actually produce zero-fact responses on out-of-domain queries — without
    a floor the pipeline almost always returns something grounded.
    Default ``False`` for backwards compatibility.
    """

    facts: list[FactStatement] = Field(default_factory=list)
    truncated: bool = False
    candidate_count: int = 0
    excerpts: list[Excerpt] = Field(default_factory=list)
    supersession_hints: list[SupersessionHint] = Field(default_factory=list)
    episode_fallback: list[EpisodeFact] = Field(default_factory=list)
    body_used: bool = False
    retrieved_episode_external_ids: list[str] = Field(default_factory=list)
    recall_telemetry: RecallTelemetry = Field(default_factory=RecallTelemetry)
    refused: bool = Field(
        default=False,
        description=(
            "ADR-0022 Option A (issue #94). True when the corpus returned zero "
            "facts AND zero episode_fallback rows for this query. Consumer LLMs "
            "should render an explicit 'I cannot answer from these sources' message "
            "in this case. Combine with cosine_floor on recall() to make the flag "
            "non-trivial on unanswerable queries — without a floor gnokee almost "
            "always returns something grounded. Never suppresses contradiction facts; "
            "no auto-resolve. Default False (backwards-compatible)."
        ),
    )
    encrypted_bodies: list[EncryptedEpisodeBody] = Field(
        default_factory=list,
        description=(
            "Issue #22 — ciphertext + envelope for any ranked episode whose "
            "body was ingested via the encrypted_body branch. Plaintext-only "
            "lanes (excerpts, episode_fallback) skip these episodes. The "
            "consumer decrypts using their KMS via key_id; gnokee NEVER "
            "carries plaintext for them."
        ),
    )
    citations: dict[str, Citation] = Field(
        default_factory=dict,
        description=(
            "ADR-0016 (issue #76) — per-claim bi-temporal citation envelope. "
            "Map keyed by `c1`, `c2`, … in deterministic emission order: one "
            "entry per FactStatement, then one per Excerpt, then one per "
            "episode_fallback body row, then one per lab/med row when the "
            "tool is `gnokee_lab_query` / `gnokee_med_query`. The host LLM "
            "back-references entries via inline `[cN]` markers in its answer. "
            "Additive to the existing `facts[]` provenance handles — both "
            "surfaces ship in the same minor version (v0.5)."
        ),
    )


class IngestReceipt(BaseModel):
    """Receipt returned from `gnokee.ingest_episode(...)`."""

    episode_uuid: UUID
    asserted_at: datetime
    created_fact_uuids: list[UUID] = Field(default_factory=list)
    contradicts: list[ContradictionRef] = Field(default_factory=list)
    replayed: bool = Field(
        default=False,
        description=(
            "True iff this call was an idempotent re-ingest matched on (tenant_id, our_id). "
            "When True, no new Graphiti episode was created; created_fact_uuids and contradicts "
            "are empty even if the original ingest produced facts."
        ),
    )
    extraction_deferred: bool = Field(
        default=False,
        description=(
            "True iff the episode was ingested in lite mode (extract=False). "
            "Graphiti add_episode and contradiction detection were skipped. "
            "Narrative fact extraction can be triggered later via "
            "gnokee.maintenance.run_deferred_extraction(). "
            "created_fact_uuids is always [] when extraction_deferred is True."
        ),
    )
    ingest_telemetry: IngestTelemetry = Field(
        default_factory=IngestTelemetry,
        description=(
            "Per-call diagnostic surface (Q18 / #111 Z3, 2026-05-12). Carries "
            "orphan_edge_warnings (count of graphiti edge-extraction WARNING "
            "records during Stage 4) + extraction_succeeded (True iff Stage 4 "
            "returned a UUID; always False on lite / encrypted branches). "
            "Use to detect the Q18 silent-drop class -- non-zero "
            "orphan_edge_warnings is a leading indicator of partial-extraction "
            "failure under concurrency x TPM pressure."
        ),
    )

    @field_validator("asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class FactProvenance(BaseModel):
    """Output of `gnokee.fact_provenance(...)` — full episode body, lazy fetch.

    Issue #22 — ``episode_content`` is ``""`` and ``encrypted_body`` is
    populated when the episode was ingested via the ``encrypted_body``
    branch. The consumer decrypts using their KMS via
    ``encrypted_body.key_id``; gnokee NEVER returns plaintext for
    encrypted episodes.
    """

    fact_uuid: UUID
    fact_text: str
    episode_uuid: UUID
    episode_content: str
    valid_at: datetime
    valid_until: datetime | None = None
    asserted_at: datetime
    asserted_until: datetime | None = None
    language: str | None = None
    sensitive: Sensitivity
    encrypted_body: EncryptedEpisodeBody | None = Field(
        default=None,
        description=(
            "Issue #22 — populated when the episode was ingested via the "
            "encrypted_body branch. ``episode_content`` is empty in that "
            "case; the consumer decrypts via their KMS using key_id."
        ),
    )

    @field_validator("valid_at", "valid_until", "asserted_at", "asserted_until")
    @classmethod
    def _utc_only(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        return _require_utc(value)


HistoryStatus = Literal["active", "superseded"]
"""Per-node lifecycle tag on a `gnokee_history_of` DAG (issue #123)."""


class HistoryNode(BaseModel):
    """One node in a supersession DAG returned by `gnokee.history_of(...)`.

    Compact mode: `episode_body` is None, `body_encrypted` is False,
    `encrypted_body` is None. Verbatim mode: `episode_body` carries up to
    `per_body_char_cap` characters of the original `content` for the newest
    `top_k_bodies` nodes; older nodes stay compact. When the node's source
    episode was ingested via the `encrypted_body` branch, `body_encrypted`
    is True, `episode_body` is None, and `encrypted_body` carries the
    ciphertext envelope — gnokee NEVER returns plaintext for those.

    `rationale` is the rationale string the successor declared via
    `EpisodeIn.corrects_reason` when its supersession was asserted. Null
    when the supersession was declared without a reason OR when this node
    is the chain's head (no successor exists to carry a rationale).

    `status` is `active` for the chain head (no `superseded_by`) and
    `superseded` for every other node. `as_of` filtering (transaction-time
    snapshot) is applied at the storage layer — the returned DAG already
    reflects the requested as_of slice.
    """

    model_config = ConfigDict(frozen=True)

    episode_id: UUID
    valid_at: datetime
    asserted_at: datetime
    superseded_by: UUID | None
    status: HistoryStatus
    rationale: str | None = None
    episode_body: str | None = None
    body_encrypted: bool = False
    encrypted_body: EncryptedEpisodeBody | None = None

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class HistoryEdge(BaseModel):
    """Directed supersession edge: `from_id` was superseded by `to_id`.

    Flat Cytoscape-style envelope (issue #123). Edges are emitted in
    chronological order (oldest-first); each edge corresponds to one
    `superseded_by` pointer surviving the as_of / valid_at filter at
    storage time.
    """

    model_config = ConfigDict(frozen=True)

    from_id: UUID
    to_id: UUID


class HistoryResponse(BaseModel):
    """Envelope for `gnokee.history_of(...)` — supersession DAG (issue #123).

    Flat Cytoscape-style: `nodes` is the list of `HistoryNode` entries
    surviving the as_of / valid_at filter; `edges` carries directed
    `from_id -> to_id` supersession pointers between them. `root` is the
    oldest ancestor in the returned subgraph (no incoming edge);
    `head` is the chain terminus (no outgoing edge / `superseded_by` is
    None). For a single-node DAG (no supersession asserted yet) `root ==
    head` and `edges` is empty.

    Bounded by `max_nodes` (default 32 — matches the storage chain-depth
    limit). When the traversal would exceed the bound, the response is
    `truncated=True` with `truncation_note` carrying a human-readable
    explanation; oldest nodes are dropped first. `cycle_detected=True`
    is set when the storage layer raises a `CorrectsChainError` —
    callers see a structured envelope instead of a raw exception.
    """

    model_config = ConfigDict(frozen=True)

    nodes: list[HistoryNode]
    edges: list[HistoryEdge]
    root: UUID
    head: UUID
    truncated: bool = False
    truncation_note: str | None = None
    cycle_detected: bool = False


class ForgetEpisodeIn(BaseModel):
    """Input for `gnokee_forget_episode` MCP tool / `gnokee.forget.forget_episode` API.

    `cascade` MUST NOT be set True without explicit operator approval; the
    refusal `cannot_forget_chain_node` is the gate — see ADR-0026 / ADR-0022.
    """

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    episode_uuid: UUID
    cascade: bool = Field(
        default=False,
        description=(
            "If True, recursively hard-deletes this episode AND all "
            "supersession descendants (episodes that corrected this one, "
            "transitively). Ancestors are NEVER cascaded. Default False. "
            "DO NOT set True without explicit operator instruction — this is "
            "permanent and irreversible. If this tool refuses with "
            "'cannot_forget_chain_node', surface the refusal to the operator "
            "and obtain explicit consent before retrying with cascade=True."
        ),
    )
    reason: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description=(
            "Required. Category label only — DO NOT include personal data "
            "(names, identifiers, diagnoses). This field is persisted in the "
            "forget_audit table which survives tenant deletion."
        ),
    )
    actor: str | None = None


class ForgetTenantIn(BaseModel):
    """Input for `gnokee_forget_tenant` MCP tool / `gnokee.forget.forget_tenant` API."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    dry_run: bool = Field(
        default=True,
        description=(
            "DEFAULT TRUE. dry_run=True returns a planned ForgetReceipt "
            "with no writes — counts of rows that would be deleted, key_ids "
            "that would be surfaced. To actually destroy the tenant, the "
            "caller MUST issue a SECOND call with dry_run=False. This is a "
            "deliberate two-call ceremony for an irreversible operation."
        ),
    )
    reason: str = Field(..., min_length=1, max_length=500)
    actor: str | None = None


class ForgetReceipt(BaseModel):
    """Compact MCP-facing return. See `ForgetReceiptDetail` for the
    Python-API operator shape that carries internal storage metrics."""

    model_config = ConfigDict(extra="forbid")

    audit_id: UUID
    tenant_id: str
    scope: Literal["episode", "tenant"]
    episode_uuid: UUID | None = None
    cascade: bool = False
    dry_run: bool = False

    summary: str = Field(
        description=(
            "Human-readable summary. Examples: 'Deleted 1 episode: "
            "4 Postgres rows, 1 Neo4j node, 2 Neo4j edges.' or 'PLANNED "
            "(dry_run): tenant X — N episodes.'"
        ),
    )
    affected_episode_count: int = Field(
        ge=0,
        description=(
            "Episode tool: 1 (no cascade) or 1+descendants (cascade). "
            "Tenant tool: full count of distinct episodes affected."
        ),
    )
    deepest_episode_uuid: UUID | None = Field(
        default=None,
        description="Episode-cascade only: chain-tail UUID. Tenant tool returns None.",
    )

    affected_key_ids: list[str] = Field(
        default_factory=list,
        description=(
            "DEK identifiers (key_id) of any encrypted episode bodies "
            "destroyed by this operation. When non-empty, the consumer "
            "MUST destroy these DEKs in their KMS to complete the "
            "cryptographic-erasure mode of the forgetting contract. "
            "gnokee never touches keys."
        ),
    )

    replayed: bool = Field(
        default=False,
        description=(
            "True when this receipt is returned from a prior successful "
            "commit found in forget_audit — i.e. the operation was "
            "already performed in a previous call. No new writes occurred."
        ),
    )

    started_at: datetime
    finished_at: datetime
    actor: str | None = None
    reason: str

    @field_validator("started_at", "finished_at")
    @classmethod
    def _ensure_utc(cls, value: datetime) -> datetime:
        return _require_utc(value)


class ForgetReceiptDetail(ForgetReceipt):
    """Operator / Python-API shape. Extends `ForgetReceipt` with
    full storage-metric dicts + the frozen cascade UUID list. Never
    serialized through MCP — kept inside the Python API and the
    `forget_audit.receipt` JSONB."""

    model_config = ConfigDict(extra="forbid")

    postgres_rows_deleted: dict[str, int] = Field(default_factory=dict)
    neo4j_nodes_deleted: dict[str, int] = Field(default_factory=dict)
    neo4j_edges_deleted: dict[str, int] = Field(default_factory=dict)
    cascaded_episode_uuids: list[UUID] = Field(default_factory=list)
    partial: bool = Field(
        default=False,
        description="True when Postgres committed but Neo4j sweep failed.",
    )
    bitemporal_snap: list[dict[str, object]] = Field(
        default_factory=list,
        description=(
            "Pre-DELETE snapshot of (episode_uuid, asserted_at, valid_at, "
            "valid_until) for every episode in the cascade scope. Time-axis-"
            "complete compliance artifact per ADR-0026 §6.4."
        ),
    )
