# gnokee backlog

Living index of post-v0.2.x work. Each item links to its tracking GitHub issue. Items get promoted from this doc to a release scope (v0.3, v0.4, etc.) as they pick up momentum.

Source of truth is the GitHub issue. This doc is the table of contents.

## v0.4.x — release scope

| # | Title | Driver |
|---|---|---|
| _(empty — #84 landed in v0.4.0 follow-up, see Closed in the v0.4.x series below)_ | | |

## v0.5.x — release scope (post-v0.5 follow-ups)

| # | Title | Driver |
|---|---|---|
| [#95](https://github.com/gnokeelabs/gnokee/issues/95) | Graphiti fact-ranking: allergy episode outranked by medication episode (Q41 p_x1_03) | Q41 follow-up; single eval miss, rank-order tune. Low priority. |

## v0.5 — release scope (LANDED 2026-05-12)

Source: [#71](https://github.com/gnokeelabs/gnokee/issues/71) competitive-landscape 2026-Q2 review.
Scope landed 2026-05-12 (commits b990f3f / e7e81b3 / d8fe1d5 / a013a49).
See "Closed in the v0.5 series" below for the rotation.

### Next-quarter candidates (post-v0.5)

| # | Title | Driver |
|---|---|---|
| [#73](https://github.com/gnokeelabs/gnokee/issues/73) | ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. |
| [#79](https://github.com/gnokeelabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/gnokeelabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/gnokeelabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution; cron infra (`scheduled_tasks.lock`) already present. |
| [#102](https://github.com/gnokeelabs/gnokee/issues/102) | Spike Q15: semantic bridges across `group_id` partitions (cross-source-type fact discovery) | NOUZ-MCP "semantic bridge" idea on `EntityEdge.fact_embedding`; lab↔med↔wearable see-also signal. |
| [#103](https://github.com/gnokeelabs/gnokee/issues/103) | Vault-adapter onboarding: mean-centered cosine separation health check on source-type prompts | NOUZ-MCP calibration ergonomic; one-shot probe, no infra, catches weak source-type prompts before retrieval. |
| [#104](https://github.com/gnokeelabs/gnokee/issues/104) | Obsidian vault adapter: opportunistic NOUZ frontmatter interop (read sign/level/parents/tags if present) | Co-marketing + zero-risk interop with NOUZ-managed vaults; follow-up to ADR-0020. |
| [#108](https://github.com/gnokeelabs/gnokee/issues/108) | Q16 — Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; measures markdown→plaintext recall on heavy-formatted (Notion-noise) source. |

Items can move to `wontfix` after ADR debate per #71 § "What this issue is for".

## v0.6 — release scope (LANDED 2026-05-16)

Source: [#111](https://github.com/gnokeelabs/gnokee/issues/111) (Q18 silent-drop verdict).
Scope landed 2026-05-16 via PR #121 (squash commit 9b4cd54). Q18 release-cut gate PASS: recall@5 measurable = 100% (vs v0.5 baseline 17.6%); 0 silent-drops. See "Closed in the v0.6 series" below for the rotation.

## v0.7 — release scope (LANDED 2026-05-16)

"Durability + lineage" ramp. Scope locked 2026-05-15; full batch landed 2026-05-16 (#124 STRICT removal → #122 journal + ADR-0024 → #123 history_of DAG). See "Closed in the v0.7 series" below for the rotation.

## v0.7.x — release scope (post-v0.7 follow-ups)

| # | Title | Driver |
|---|---|---|
| [#130](https://github.com/gnokeelabs/gnokee/issues/130) | Forget-cascade: include `ingest_journal` in tenant-deletion sweep | ADR-0024 follow-up; tenant-forget must wipe journal rows. |
| [#102](https://github.com/gnokeelabs/gnokee/issues/102) | Q15 cross-`group_id` semantic bridges spike | Adjacent retrieval primitive; carried over from v0.6.x. |

### Next-quarter candidates (post-v0.7)

| # | Title | Driver |
|---|---|---|
| [#73](https://github.com/gnokeelabs/gnokee/issues/73) | ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. Natural successor to `gnokee_history_of` (episode-level → fact-level lineage). |
| [#79](https://github.com/gnokeelabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/gnokeelabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/gnokeelabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution. |
| [#108](https://github.com/gnokeelabs/gnokee/issues/108) | Q16 Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; markdown→plaintext recall on Notion-noise source. |
| Z2 (untracked) | `EpisodeIn.source_type` field + lite-mode default for prose | Deferred from v0.6 per ADR-0023 § Out-of-scope. Public API contract — own ADR. |
| LongMemEval-S publish | ADR-0019 stance `PUBLISH_POST_Z1`; publish recall@5 / recall@10 numbers | Q18 gate pass unlocks this. Separate PR. |

## How to add an item

1. Open a GitHub issue with a 1-line title and a short body covering: problem / decision / acceptance.
2. Label with the target release (`v0.3`, `v0.4`, etc.) and a category (`enhancement`, `documentation`, etc.).
3. Add a row to the appropriate table above. Keep the description column to one driver-sentence — the issue carries the detail.

## Closed in the v0.7 series

v0.7.0 (2026-05-16):
- Issue #122 — Ingest crash-recovery journal + `gnokee.resume_ingest` Python API — landed (PR #129, squash aa559da). Append-only `ingest_journal` Postgres table; `begin`/`commit`/`fail` rows; `IngestPipeline` surfaces orphans on first ingest per tenant per process. Operator-driven resume only — gnokee NEVER auto-replays. ADR-0024 Accepted. Q19 spike: 2.17% median latency regression (under ADR-0024 10% threshold).
- Issue #123 — `gnokee_history_of` supersession-DAG MCP tool + `gnokee.history_of` Python API — landed (#128). Cytoscape-flat envelope; `mode=compact` / `mode=verbatim`; `as_of` time-travel; `cycle_detected` instead of raising; encrypted episodes keep ciphertext. `EpisodeIn.corrects_reason` field added (Python API only; MCP exposure deferred).
- Issue #124 — Hard-removal of `GNOKEE_INGEST_STRICT` env var — landed (#126). v0.6 deprecation cycle closed; env var now a no-op. Replacement signals on `IngestReceipt.ingest_telemetry`.
- ADR-0024 — Ingest crash-recovery journal — Status `Accepted` (#127).

## Closed in the v0.6 series

v0.6.0 (2026-05-16):
- Issue #111 — Graphiti `add_episode` silent-drop ingest hardening — landed (#121). Z1 storage-first stage reorder + Z4 adaptive retry + concurrency cap. Q18 release-cut gate PASS: recall@5 measurable 17.6% → 100%; zero silent-drops. ADR-0023 Accepted. ADR-0012 + ADR-0019 amended.
- ADR-0023 — gnokee owns episode storage; Graphiti is enhancement-only — Status `Accepted`.
- `GNOKEE_INGEST_STRICT` env var — deprecated (DeprecationWarning); hard-removal v0.7.

## Closed in the v0.5 series

v0.5.0 (2026-05-12):
- Issue #72 — ADR-0013 `gnokee_query` declarative envelope MCP tool — landed (#100).
- Issue #74 — ADR-0015 `gnokee_wiki_export` + `llms.txt` manifest — landed (#99).
- Issue #76 — ADR-0016 per-claim bi-temporal citation envelope — landed (#92).
- Issue #77 — Source-grounded refusal Q-suite — consolidated into #109 / ADR-0022.
- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (`SHIP_RECENCY_AS_PROXY`, PR #87).
- Issue #81 — LongMemEval-S v0.5 publish target — resolved as `DECLINE_TO_PUBLISH` (ADR-0019 amendment 2026-05-12); defer to v0.6 after #111.
- Issue #88 — Q13.1 confidence-model stage-2 spike at N≥30 — landed (#118). Verdict `KEEP_RECENCY_PROXY`: 0/48 composite variants cleared both Spearman + calibration gates at N=31. ADR-0019 § Follow-up closed.
- Issue #89 — per-fact `cosine_top1` telemetry on `gnokee_recall` — landed (#117); ADR-0019 § Follow-up amended (recency-proxy proxy reading retired).
- Issue #90 — Graphiti literal-numeric extraction gap — accepted (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices.
- Issue #94 — Refusal posture UX gap — ADR-0022 Option A landed (#119): `refused: bool` + `cosine_floor` knob on `RecallResponse` / `gnokee_recall`. Pulled forward from v0.5.x.
- Issue #97 / #96 — Obsidian vault adapter — landed (#101); ADR-0020 Q14 spike verdict `SHIP_ADAPTER`.
- Issue #103 — Vault-adapter mean-centered cosine separation probe — landed (#105).
- Issue #106 — ADR-0021 consumer surface strategy — accepted (#113).
- Issue #107 — Q14.1 sweep of past spike harnesses for threshold-semantics bug class — landed (#114).
- Issue #109 — Q17 refusal-posture spike + ADR-0022 draft — landed (#115); verdict `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL`.
- Issue #110 — v0.5 LongMemEval narrative note — landed (8743c25).
- Issue #111 (Z3 partial) — graphiti orphan-edge warnings on `IngestReceipt` — landed (#112). Z1/Z2 remain for v0.6.
- ADR-0022 — refusal posture — Status `Accepted` (verdict `ADOPT_OPTION_D`, Q17 spike; amended same-day for Option A landing) — landed (#116, #119).

## Closed in the v0.2.x maintenance series

v0.2.2 (2026-05-09):
- Issue #17 — partial open-subset indexes on `lab_record` / `med_record` for supersession perf — landed.
- Issue #18 — `gnokee_lab_query op=abnormal`; Q7 `q_electrolyte_abnormal_q2` PARTIAL → PASS — landed.
- Issue #19 — `gnokee_recall.supersession_hints[]` (Option A+, clinical-safe) — landed.

v0.2.3 (2026-05-09):
- Issue #20 — first PyPI publish; `pip install gnokee==0.2.3` works — landed.
- Issue #21 — `GNOKEE_SPIKE_SKIP_INGEST=1` env-var alignment for Q7 + Q8 harnesses — landed.

## Closed in the v0.3.x release scope

v0.3.0 (2026-05-09):
- Issue #16 — Lite ingest mode + integration patterns doc + eval-delta gate — landed.
- Issue #38 — `gnokee.recall` episode-cosine fallback when `fact_count == 0` (Path A) — landed.
- Issue #39 — Q10.1 Zep-OSS + basic-memory adapters + Stage C confirmation — landed; ADR-0012 Accepted-with-caveat.
- Issue #54 — per-lane budget + emitted telemetry on `RecallResponse` — landed.
- Issue #56 — lite-mode ingest writes minimal `Episodic` node so recall sees it — landed.

v0.4.0 (2026-05-10):
- Issue #22 — `encrypted_body` branch wires DEK pathway end-to-end (Stage 1 boundary, migration `0012_episode_body_encrypted`, recall surfacing) — landed.
- Issue #37 — ADR-0004 + ADR-0012 amendments for encrypted_body boundary + Q10 Stage C-pilot magnitude — landed.
- Issue #51 — consolidate `episode_metadata.content` + `content_text` (migration `0011_drop_content_column`) — landed.
- Issue #52 — `top_k_bodies` + `per_body_char_cap` knobs on `recall()` (Python API; MCP deferred) — landed.
- Issue #62 — Q12 abstain split + synth-v2 falsifies "retrieval is the bottleneck" hypothesis — landed.
- Issue #63 — `evals/q10/run.py` parallelize per-question + Mem0 adapter robustness — landed.
- Issue #64 — Q10 / Zep CE compose env keys + smoke step — landed.

## Closed in the v0.4.x series

(no v0.4.x point release cut yet; closures listed against the next tag)

- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (Accepted-with-caveat, SHIP_RECENCY_AS_PROXY); merged in #87.
- Issue #84 — MCP `top_k_bodies` + `per_body_char_cap` exposure on `gnokee_recall` — merged in #85.
- Issue #90 — Graphiti literal-numeric extraction gap — **Accept** (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices; ADR-0019 § Follow-up amended + spike-author guidance added to `docs/evals/methodology.md`.

## Closed before v0.2.x

- Issue #15 — `chore(release): v0.2.0 typed clinical reads` — landed.
- Issues #2 / #3 / #4 / #5 / #6 / #7 / #8 — v0.1.1 extraction-quality work, all closed before v0.2.0.

ADRs that surface implicit backlog items but are not yet tracked as issues:
- ADR-0011 (wearables off-ramp) — depends on consumer TimescaleDB integration; not gnokee work.
- ADR-0008 (contradiction storage) — Q4 closed; orthogonal to supersession.
