# Upstream contribution — Graphiti `small_model` fallback

> Repository: https://github.com/getzep/graphiti
> Affected versions: at least `graphiti-core 0.29.0` (HEAD as of 2026-05-07)
> Filed by: gnokeelabs (Vadim Yuzi)

This document is the source of truth for an upstream issue + PR pair that
the gnokee project plans to file against Graphiti. Keep it in sync with
the actual issue/PR once submitted (link them in the *Status* section).

---

## Status

- [ ] Issue filed at https://github.com/getzep/graphiti/issues/new
- [ ] PR opened
- [ ] PR merged

---

## Issue text (paste into "New issue")

### Title

> [BUG] `LLMConfig.small_model=None` falls through to hardcoded `gpt-4.1-nano`, breaking every non-OpenAI provider

### Body

**Affected:** `graphiti-core 0.29.0` (latest at time of report).

**Summary:** When `LLMConfig.small_model` is left at its documented
default of `None`, `BaseOpenAIClient._get_model_for_size(...)` falls back
to a hardcoded `'gpt-4.1-nano'`. This hardcoded model is sent to whatever
endpoint the user configured — which on every non-OpenAI provider results
in a **404 model_not_found** error during ingestion.

**Source pointers:**

- `graphiti_core/llm_client/openai_base_client.py:35`
  ```python
  DEFAULT_SMALL_MODEL = 'gpt-4.1-nano'
  ```
- `graphiti_core/llm_client/openai_base_client.py:112`
  ```python
  return self.small_model or DEFAULT_SMALL_MODEL
  ```
- `graphiti_core/llm_client/config.py:60-61` documents
  *"Defaults to 'gpt-4.1-nano'"* — but does not warn that this means
  every non-OpenAI provider must override `small_model` explicitly.

**There is already an established pattern in the codebase that does the
right thing**, in `graphiti_core/llm_client/gliner2_client.py:92`:

```python
model_id = config.model or DEFAULT_MODEL
small_model_id = config.small_model or model_id   # falls back to main, not to a fixed string
```

The `BaseOpenAIClient` should follow the same pattern.

**Repro (Ollama, but reproduces on any non-OpenAI base_url):**

```python
import asyncio
from graphiti_core import Graphiti
from graphiti_core.llm_client import LLMConfig
from graphiti_core.llm_client.openai_generic_client import OpenAIGenericClient

async def main():
    cfg = LLMConfig(
        api_key="ollama",
        model="llama3.1:8b",
        base_url="http://localhost:11434/v1",
        # small_model intentionally left as None (per docstring this should be valid)
    )
    g = Graphiti(
        uri="bolt://localhost:7687", user="neo4j", password="neo4j",
        llm_client=OpenAIGenericClient(config=cfg),
    )
    await g.build_indices_and_constraints()
    from datetime import datetime, timezone
    from graphiti_core.nodes import EpisodeType
    await g.add_episode(
        name="test",
        episode_body="The user prefers Postgres.",
        source_description="repro",
        reference_time=datetime.now(timezone.utc),
        source=EpisodeType.text,
        group_id="repro",
    )

asyncio.run(main())
```

**Expected:** ingest succeeds (the small_model path uses `cfg.model`).
**Actual:**

```
openai.NotFoundError: 404 - {'error': {'message': "model 'gpt-4.1-nano' not found", ...}}
```

**Why this matters / blast radius:** affects 100% of users routing
Graphiti at any OpenAI-compatible endpoint that isn't OpenAI itself —
Ollama, Groq, NVIDIA NIM, Anthropic-via-LiteLLM, OpenRouter, Cerebras,
Together, Fireworks, DeepInfra, Hyperbolic, Cloudflare Workers AI, etc.

**Proposed fix:** see PR (linked in *Status* once filed). Two-line
change in `openai_base_client.py:112` plus a docstring update in
`config.py:61`.

**Workaround until merged:** explicitly set `small_model=` to the same
model as `model=` in your `LLMConfig`.

---

## Proposed fix (paste / `git apply` to a Graphiti checkout)

```diff
diff --git a/graphiti_core/llm_client/openai_base_client.py b/graphiti_core/llm_client/openai_base_client.py
--- a/graphiti_core/llm_client/openai_base_client.py
+++ b/graphiti_core/llm_client/openai_base_client.py
@@ -32,7 +32,6 @@ from .errors import RateLimitError, RefusalError
 logger = logging.getLogger(__name__)

 DEFAULT_MODEL = 'gpt-4.1-mini'
-DEFAULT_SMALL_MODEL = 'gpt-4.1-nano'
 DEFAULT_REASONING = 'minimal'
 DEFAULT_VERBOSITY = 'low'

@@ -107,9 +106,12 @@ class BaseOpenAIClient(LLMClient):
         return openai_messages

     def _get_model_for_size(self, model_size: ModelSize) -> str:
+        # When small_model is unset, fall back to the main model rather
+        # than a hardcoded OpenAI string. This mirrors the established
+        # pattern in gliner2_client.py and keeps non-OpenAI providers
+        # working out of the box.
         if model_size == ModelSize.small:
-            return self.small_model or DEFAULT_SMALL_MODEL
+            return self.small_model or self.model or DEFAULT_MODEL
         else:
             return self.model or DEFAULT_MODEL
```

```diff
diff --git a/graphiti_core/llm_client/config.py b/graphiti_core/llm_client/config.py
--- a/graphiti_core/llm_client/config.py
+++ b/graphiti_core/llm_client/config.py
@@ -57,9 +57,10 @@ class LLMConfig:
                                                                 Defaults to 16384.
                 small_model (str, optional): The specific LLM model to use for generating responses of simpler prompts.
-                                                                Defaults to "gpt-4.1-nano".
+                                                                When unset, falls back to ``model`` (the main model). Set
+                                                                explicitly when you want to use a smaller / cheaper model
+                                                                than the main one for entity-dedup-style calls.
         """
         self.api_key = api_key
```

### Test that should be added (suggestion for the PR)

```python
def test_small_model_fallback_uses_main_model_not_hardcoded():
    from graphiti_core.llm_client import LLMConfig
    from graphiti_core.llm_client.openai_generic_client import OpenAIGenericClient
    from graphiti_core.llm_client.client import ModelSize

    cfg = LLMConfig(
        api_key="x",
        model="my-custom-model",
        base_url="http://example.invalid",
        # small_model intentionally None
    )
    client = OpenAIGenericClient(config=cfg)
    assert client._get_model_for_size(ModelSize.small) == "my-custom-model"
    assert client._get_model_for_size(ModelSize.medium) == "my-custom-model"
```

---

## Why this fix is safe (review notes for maintainers)

1. **Behaviour change for OpenAI users:** none in practice. Anyone
   running against `api.openai.com` with `model='gpt-4.1-mini'` (the
   existing default) and `small_model=None` will now have their small
   calls also routed to `gpt-4.1-mini` instead of `gpt-4.1-nano`. Slight
   cost increase, identical correctness. Users wanting cost optimisation
   set `small_model='gpt-4.1-nano'` explicitly — which the updated
   docstring makes clear is the right call.

2. **Behaviour change for non-OpenAI users:** ingestion that previously
   crashed with 404 now succeeds.

3. **Established precedent:** `gliner2_client.py:92` already uses this
   exact pattern. The fix brings `BaseOpenAIClient` into line.

4. **No new dependencies, no new public API surface, no migration
   required.**

---

## After this lands

Followups gnokee may also send upstream:

- Issue #1393 (`OpenAIRerankerClient` hardcoded with no config) — same
  shape of bug; comment with our reproduction.
- Docs: provider compatibility matrix (`OpenAIClient` uses `/v1/responses`,
  works only on OpenAI proper; `OpenAIGenericClient` uses
  `/v1/chat/completions`, works everywhere). Currently undocumented and
  cost us several debugging cycles.
