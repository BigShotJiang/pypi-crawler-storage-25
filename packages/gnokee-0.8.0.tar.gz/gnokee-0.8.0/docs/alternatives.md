# Alternatives

> Honest comparison of gnokee against the closest open-source memory
> systems. Numbers cited inline are from public benchmarks or
> gnokee's own [eval methodology](evals/methodology.md). The Q10
> cross-tool spike — gnokee vs Mem0 vs Graphiti-alone vs Zep-OSS vs
> basic-memory — produced the verdict in
> [ADR-0012](adr/0012-cross-tool-eval-verdict.md), which we
> reproduce honestly below.

## TL;DR

| Tool | Pick when |
|---|---|
| **gnokee** | Bi-temporal queries matter; contradictions must surface honestly; verifiable forgetting required (GDPR / clinical); multi-tenant from day one; multilingual corpus; "no key" privacy contract. |
| **Mem0** | Conversation-shaped memory is the dominant use case (LongMemEval-S benchmark fits well). Hosted offering acceptable. |
| **Graphiti-alone** | Want a bi-temporal knowledge graph primitive without gnokee's opinions about retrieval shape, contradiction non-resolution, multi-tenancy, or MCP-native interface. |
| **Zep-OSS** | Conversation memory with a focus on session-level summarisation. Prefer their hybrid retrieval default. |
| **basic-memory** | Personal-use, single-binary, markdown-vault-shaped corpus. No multi-tenancy, no clinical structure, no contradictions. Lowest ops floor. |

## Comparison matrix

| Axis | gnokee 0.4 | Mem0 | Graphiti-alone | Zep-OSS | basic-memory |
|---|---|---|---|---|---|
| Bi-temporal (valid + transaction time) | ✓ first-class | partial (timestamps, no time-travel queries) | ✓ underlies gnokee | partial | ✗ |
| Time-travel `as_of` queries | ✓ | ✗ | ✓ via raw API | partial | ✗ |
| Contradiction surfacing | ✓ surface, never auto-resolve | auto-resolves silently | ✗ | partial | ✗ |
| Verifiable forgetting | ✓ 3 modes (soft / hard / crypto-erase) | soft only | partial | partial | partial |
| Multi-tenant by API contract | ✓ `tenant_id` on every call | partial | ✓ `group_id` | partial | ✗ |
| Postgres RLS (defence-in-depth) | ✓ documented pattern | ✗ | ✗ | ✗ | ✗ |
| Multilingual retrieval | ✓ bge-m3, validated cross-lingual (Q2) | depends on embedder | depends on embedder | depends on embedder | depends on embedder |
| Encrypted-body branch (consumer-KMS DEK) | ✓ v0.4 | ✗ | ✗ | ✗ | ✗ |
| MCP-native server | ✓ five tools | ✗ (SDK only) | ✗ | ✗ | ✓ |
| BYO LLM (OpenAI-compatible endpoint) | ✓ | ✓ | ✓ | ✓ | ✓ |
| BYO embedder | ✓ TEI / Ollama / OpenAI-compatible | ✓ | ✓ | ✓ | partial |
| Storage backend | Postgres + pgvector + Neo4j Community | Postgres or DuckDB or others | Neo4j / FalkorDB / Kùzu / Neptune | Postgres | SQLite + markdown |
| License (project) | Apache-2.0 | Apache-2.0 | Apache-2.0 | Apache-2.0 | MIT |
| Backend license footprint | Neo4j is GPLv3; pgvector is permissive | mostly permissive | Neo4j default GPLv3 | permissive | permissive |
| Single-binary deploy | ✗ (compose stack) | ✓ | ✓ | partial | ✓ |
| Production consumers driving the project | Omur (clinical), noggin (personal) | broad | broad | broad | personal |
| Project age / maturity | pre-1.0 (2026) | mature, hosted SaaS available | mature | mature | mature |

✓ = present and tested; partial = present but with caveats; ✗ = not present.

## Eval honesty

gnokee's [Q10 cross-tool spike](adr/0012-cross-tool-eval-verdict.md)
ran gnokee, Mem0, Graphiti-alone, Zep-OSS, and basic-memory against
[LongMemEval-S](https://github.com/xiaowu0162/LongMemEval) at
30-question + 100-question scale.

**Stage A (10 Q × 10 sessions, 3 SUTs, double-run judge agreed,
2026-05-09):** all three SUTs scored 0/10 strict.

**Stage C-pilot (30 Q × 20 sessions, 3 SUTs, double-run judge
agreed, 2026-05-10):** all three SUTs scored 0/30 strict.

**Verdict:** REJECT for v0.2.x retrieval surface on LongMemEval-S
strict scoring. ADR-0012 Accepted-with-caveat.

**Bottleneck (per [#62](https://github.com/gnokeelabs/gnokee/issues/62)):**
synth-prompt abstention bias — the SUTs had retrievable evidence
but the synth prompt biased the LLM to abstain. This means the
*retrieval* surface is not the limiting factor on this benchmark.
Q10.1 (#39) wired Zep-OSS + basic-memory adapters to extend the
panel; full-pilot (100 Q, Track 1 + Track 2) tracked under
[#63](https://github.com/gnokeelabs/gnokee/issues/63).

**What gnokee's own benchmarks say:**

- Q1 Graphiti spike — ADOPT as storage primitive.
- Q2 cross-lingual — 100% top-1 over en/ru/bg/he via direct cosine.
- Q3 token-efficiency — gnokee response shape: 91.7% top-3 recall
  at 125 median tokens vs Graphiti-raw 50% at 367 tokens.
- Q4 contradiction-classifier — 80% accuracy on labelled pairs
  with gpt-4o-mini.
- Q5 forgetting — 2/2 hard-delete propagation probes.
- Q7 clinical labs — v0.1.1 13.3% → v0.2 66.7% (ADOPT_WITH_GAPS).
- Q8 medication history — v0.1.1 53.3% → v0.2 100% (ADOPT).

These are the use cases gnokee was built for. LongMemEval-S is a
conversation-memory benchmark — different shape. Pick the tool
that fits your workload.

## When to pick each

### gnokee

- You need bi-temporal queries (`as_of`, `valid_at`).
- Contradictions must surface to the user / LLM, not be silently
  resolved.
- Forgetting must be verifiable across vector / graph / derived
  stores.
- Multi-tenant isolation is a contract requirement, not a feature
  you'll bolt on later.
- You speak more than one language and can't drop the rest.
- You handle clinical / sensitive data and need an encrypted-body
  pathway with a real "no key" invariant on the memory layer.
- You want an MCP server out of the box that LLM clients can
  introspect and call.

### Mem0

- Conversation-shaped memory is the primary workload.
- LongMemEval-S benchmark performance is your purchase criterion.
- A hosted offering is acceptable (and you can pay for it).
- Single-binary install matters more than bi-temporal correctness.

### Graphiti-alone

- You want a bi-temporal knowledge graph primitive.
- You're building your own retrieval layer and have your own
  opinions about response shape and ranking.
- You don't need contradiction surfacing as a first-class API
  (you'd build it yourself).
- You don't need multi-tenancy beyond Graphiti's `group_id`.
- You don't need MCP-native packaging.
- gnokee is in fact built on top of Graphiti — pick this if
  gnokee's opinions don't match yours.

### Zep-OSS

- Conversation memory with summarised sessions.
- You prefer a hybrid retrieval default (BM25 + vector + RRF).
- Your privacy posture is comfortable with their default
  configuration.

### basic-memory

- Personal, single-user knowledge corpus.
- Markdown vault is your existing source of truth.
- You want the lowest possible ops floor.
- No multi-tenancy, no clinical structure, no contradictions are
  acceptable trade-offs.

## How this comparison was built

- Public READMEs of Mem0, Graphiti, Zep-OSS, basic-memory at the
  versions current as of 2026-05-10.
- gnokee's own ADRs and spike methodology
  ([`evals/methodology.md`](evals/methodology.md)).
- [ADR-0012](adr/0012-cross-tool-eval-verdict.md) — cross-tool eval
  verdict.
- Issue [#62](https://github.com/gnokeelabs/gnokee/issues/62) —
  abstention bottleneck analysis.
- Issue [#63](https://github.com/gnokeelabs/gnokee/issues/63) —
  full-pilot Stage C plan.

If a row is wrong or out of date, file a doc PR. We update this
page when an upstream tool changes its position on an axis we
compare on.
