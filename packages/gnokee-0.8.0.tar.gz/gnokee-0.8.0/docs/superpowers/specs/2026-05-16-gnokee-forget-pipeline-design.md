# Spec — gnokee forget pipeline (v0.8.0)

**Date:** 2026-05-16
**Status:** Draft (specialist-reviewed: postgres-pgvector-specialist, bi-temporal-auditor, mcp-tool-designer)
**Closes:** [#130 Forget-cascade: include ingest_journal in tenant-deletion sweep](https://github.com/gnokeelabs/gnokee/issues/130)
**ADR:** ADR-0026 (Forget pipeline) — to be filed alongside implementation

---

## 1. Goal

Ship a production `gnokee.forget` surface that implements the **hard-delete + tombstone-propagation** mode from `docs/architecture.md §Forgetting`, with verifiable audit, opt-in crash recovery, and bi-temporally honest interaction with the supersession DAG.

The pipeline replaces the Q5 spike (in-memory map + Cypher) and closes the long-standing `ingest_journal` cascade gap surfaced by `postgres-pgvector-specialist` during ADR-0024 review (#130).

## 2. Non-goals

- **Soft supersession.** Already shipped in v0.2.1 via `EpisodeIn.corrects:`. Not in scope.
- **Cryptographic erasure as a distinct mode.** `gnokee` never holds DEKs. v1 ships hard-delete only; the receipt surfaces `affected_key_ids[]` so the consumer destroys DEKs in their own KMS. The "Mode 3" semantics from architecture.md (consumer destroys key, ciphertext stays on backup) becomes a documentation note, not a code path.
- **Chunked Neo4j DETACH for >1M-node tenants.** Single statement for v1. Telemetry-gated follow-up if real OOMs surface.
- **Tenant-grade reaper / GC for `forget_audit`.** Retention policy is operator-driven via a separate CLI.
- **Time-travel preservation post-forget.** Hard-delete is explicitly incompatible with `valid_at` time-travel through pre-forget windows. See §10.

## 3. Surface — two MCP tools

```
gnokee_forget_episode(tenant_id, episode_uuid, *, cascade=False, reason, actor=None)
gnokee_forget_tenant(tenant_id, *, dry_run=True, reason, actor=None)
```

Both return `ForgetReceipt`. Python API mirrors at `gnokee.forget.forget_episode(...)` and `gnokee.forget.forget_tenant(...)`.

**Tool-name pattern note:** `AGENTS.md` lists `gnokee_forget` as an example; this spec ships two more-specific tools and adds a doc-update to `AGENTS.md` as part of the merge.

### 3.1 `gnokee_forget_episode`

```python
class ForgetEpisodeIn(BaseModel):
    tenant_id: str
    episode_uuid: UUID
    cascade: bool = Field(
        False,
        description=(
            "If True, recursively hard-deletes this episode AND all "
            "supersession descendants (episodes that corrected this one, "
            "transitively). Ancestors are NEVER cascaded. Default False. "
            "DO NOT set True without explicit operator instruction — this is "
            "permanent and irreversible. If this tool refuses with "
            "'cannot_forget_chain_node', surface the refusal to the operator "
            "and obtain explicit consent before retrying with cascade=True."
        ),
    )
    reason: str = Field(..., max_length=500, description=(
        "Required. Category label only — DO NOT include personal data "
        "(names, identifiers, diagnoses). This field is persisted in the "
        "forget_audit table which survives tenant deletion."
    ))
    actor: str | None = None
```

#### 3.1.1 Refusal: `cannot_forget_chain_node`

Triggered when the target episode has at least one supersession descendant (an episode whose `corrects_episode_uuid → target.uuid`, transitively) AND `cascade=False`.

Returns (compact, bounded payload):

```json
{
  "error": "cannot_forget_chain_node",
  "descendant_count": 7,
  "deepest_descendant_uuid": "<uuid>",
  "hint": "Use gnokee_history_of(uuid=<target>) to inspect the chain. Resubmit with cascade=True only after explicit operator approval — this is permanent."
}
```

The full descendant UUID list is **never** inlined in the refusal (architecture contract: compact responses). Callers walk the DAG via `gnokee_history_of` if they need details.

#### 3.1.2 DAG behaviour matrix

| Has ancestors? | Has descendants? | `cascade=False` | `cascade=True` |
|---|---|---|---|
| No | No | hard-delete this | same |
| Yes | No | hard-delete this; explicit UPDATE clears ancestors' `superseded_by` pointer (see §6.2) | same |
| No | Yes | **REFUSE** `cannot_forget_chain_node` | hard-delete this + all descendants transitively |
| Yes | Yes | **REFUSE** | hard-delete this + all descendants |

Ancestors are never touched. Ancestor's `asserted_until` and `valid_until` are **not reopened** by forget(B) — A's prior assertion that B corrected it remains historically true; what we erase is B itself and its descendant lineage.

### 3.2 `gnokee_forget_tenant`

```python
class ForgetTenantIn(BaseModel):
    tenant_id: str
    dry_run: bool = Field(
        True,
        description=(
            "DEFAULT TRUE. dry_run=True returns a planned ForgetReceipt with "
            "no writes — counts of rows that would be deleted, key_ids that "
            "would be surfaced, etc. To actually destroy the tenant, the "
            "caller MUST issue a SECOND call with dry_run=False. This is a "
            "deliberate two-call ceremony for an irreversible operation."
        ),
    )
    reason: str = Field(..., max_length=500, description=(
        "Required. Category label only — see gnokee_forget_episode.reason."
    ))
    actor: str | None = None
```

No `confirm_tenant_id` — the `dry_run=True` default forces a meaningful second call rather than a copy-paste guard.

### 3.3 `ForgetReceipt` (MCP-facing return)

```python
class ForgetReceipt(BaseModel):
    audit_id: UUID
    tenant_id: str
    scope: Literal["episode", "tenant"]
    episode_uuid: UUID | None = None
    cascade: bool = False
    dry_run: bool = False           # True on tenant tool's planning call

    summary: str                    # human-readable, e.g.:
                                    #   "Deleted 1 episode: 4 Postgres rows, 1 Neo4j node, 2 Neo4j edges."
                                    #   "PLANNED (dry_run): tenant 'omur' — 1,247 episodes, 8,921 Postgres rows, 1 Neo4j subgraph."

    affected_episode_count: int     # episode tool: 1 (no cascade) or 1+descendants (cascade); tenant tool: full count
    deepest_episode_uuid: UUID | None = None  # episode tool with cascade=True: chain tail; tenant tool: None

    affected_key_ids: list[str] = Field(
        default_factory=list,
        description=(
            "DEK identifiers (key_id) of any encrypted episode bodies "
            "destroyed by this operation. When non-empty, the consumer "
            "MUST destroy these DEKs in their KMS to complete the "
            "cryptographic-erasure mode of the forgetting contract. "
            "gnokee never touches keys."
        ),
    )

    replayed: bool = False          # True when this receipt is a cached prior commit

    started_at: datetime
    finished_at: datetime
    actor: str | None = None
    reason: str
```

**Stripped from the MCP shape (Python API only):**
- `postgres_rows_deleted: dict[str, int]`
- `neo4j_nodes_deleted: dict[str, int]`
- `neo4j_edges_deleted: dict[str, int]`
- `partial: bool` — see §7.4
- `cascaded_episode_uuids: list[UUID]` — operator audit only

The Python API `gnokee.forget.forget_episode/forget_tenant` returns a richer `ForgetReceiptDetail` that includes all of these fields for operator tooling and tests. The MCP envelope returns the compact `ForgetReceipt`.

## 4. Audit storage — `gnokee_maintenance.forget_audit`

### 4.1 Schema isolation rationale

`forget_audit` survives `gnokee_forget_tenant(t)` — that is its purpose (proof the deletion happened). Three placement options were considered:

- **Public schema, no RLS:** rejected by postgres-pgvector-specialist B3 — cross-tenant readable via the app role.
- **Public schema, RLS with operator bypass:** workable but couples table lifecycle to per-tenant RLS GUC discipline.
- **Separate `gnokee_maintenance` schema:** **adopted.** Schema-level isolation; the app role retains full CRUD because the pipeline itself writes here, but no SQL-pass-through surface in gnokee today reaches this schema. Future MCP audit-read tools can layer RLS at that point.

### 4.2 Migration 0017

```sql
-- 0017_forget_audit.sql
-- ADR-0026 — system-scoped audit + journal for gnokee.forget.
-- Schema-isolated so the table survives tenant deletion (which is the point).

CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.forget_audit (
    audit_id          UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id         TEXT        NOT NULL,
    scope             TEXT        NOT NULL CHECK (scope IN ('episode','tenant')),
    episode_uuid      UUID,
    cascade           BOOLEAN     NOT NULL DEFAULT FALSE,
    dry_run           BOOLEAN     NOT NULL DEFAULT FALSE,
    state             TEXT        NOT NULL CHECK (state IN ('begin','commit','fail')),
    actor             TEXT,
    reason            TEXT        NOT NULL,
    receipt           JSONB,        -- populated at 'commit'; carries the frozen cascade UUID list + per-uuid bi-temporal snapshot
    error             TEXT,         -- populated at 'fail'
    cascade_uuids     JSONB,        -- frozen at begin time when cascade=True; resume_forget reads this exact set
    bitemporal_snap   JSONB,        -- per-deleted-uuid {asserted_at, valid_at, valid_until} captured pre-DELETE
    started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at       TIMESTAMPTZ,
    PRIMARY KEY (audit_id),
    CHECK (
        (scope = 'episode' AND episode_uuid IS NOT NULL)
        OR
        (scope = 'tenant'  AND episode_uuid IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS forget_audit_resumable_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'begin';

-- No additional descending index — drop unless a query pattern justifies it post-ship.
-- No RLS — schema-level isolation is the access model.
```

### 4.3 RLS / role posture

Operators query directly:

```sql
SET search_path TO gnokee_maintenance;
SELECT audit_id, tenant_id, scope, state, reason, started_at, finished_at
  FROM forget_audit
 WHERE tenant_id = 'omur'
 ORDER BY started_at DESC;
```

The application connection uses `gnokee_maintenance.forget_audit` explicitly when reading/writing. No future MCP tool exposes audit reads without an explicit ADR + RLS pass.

## 5. ForgetPipeline — stages and transaction shape

### 5.1 Module layout

```
src/gnokee/forget/__init__.py         # public API: forget_episode, forget_tenant
src/gnokee/forget/models.py           # ForgetEpisodeIn, ForgetTenantIn, ForgetReceipt, ForgetReceiptDetail
src/gnokee/forget/pipeline.py         # ForgetPipeline class — stages 1–6
src/gnokee/forget/dag.py              # recursive CTE descendant walk
src/gnokee/forget/audit.py            # gnokee_maintenance.forget_audit CRUD
src/gnokee/maintenance/resume_forget.py
src/gnokee/storage/graphiti_store.py  # add: remove_episode_by_uuid, remove_tenant_group
```

### 5.2 Stages

| Stage | Action | Tx |
|---|---|---|
| 1 | Validate args; load existing `commit`-state audit row (idempotency check) | none |
| 2 | DAG walk (episode tool): refuse on chain-node if `cascade=False`; freeze descendant set | none |
| 3 | OPEN serializable Postgres tx; `SET LOCAL app.current_tenant = $1`; capture pre-DELETE `bitemporal_snap`; capture `affected_key_ids` from `episode_body_encrypted` | begin tx |
| 4 | INSERT `forget_audit` row `state='begin'` + `cascade_uuids` + `bitemporal_snap` | same tx |
| 5 | Postgres sweep — `DELETE FROM episode_metadata`, `DELETE FROM fact_contradiction`, `DELETE FROM ingest_journal` (per scope) | same tx |
| 6 | UPDATE `forget_audit` SET `state='commit'`, `receipt`, `finished_at`; COMMIT tx | same tx |
| 7 | Neo4j sweep — `DETACH DELETE` per `group_id` (tenant) or by uuid set (episode/cascade) | separate Neo4j tx (driver session) |
| 8 | If Neo4j sweep fails — open a NEW Postgres tx; INSERT a `state='fail'` audit row whose `error` JSONB carries the original `audit_id` linking back to the committed `state='commit'` row from stage 6; raise. (resume_forget retries Neo4j only.) | new Postgres tx |
| 9 | Return `ForgetReceipt` | n/a |

**Critical correction from earlier draft (postgres-pgvector-specialist B2):**
Stages 4–6 are inside one Postgres transaction. If the Postgres sweep fails, the audit-begin row rolls back **with** it — `state='begin'` rows therefore do NOT mean "Postgres committed, Neo4j pending." A `state='begin'` row that survives a crash means the tx was killed mid-flight and Postgres rolled back the whole thing. **`resume_forget` must retry BOTH stores starting from stage 3.**

`state='commit'` rows in `forget_audit` are the only proof Postgres has been swept. The Neo4j sweep happens in a separate phase AFTER Postgres commits. If the Neo4j sweep fails post-Postgres-commit, gnokee writes a separate `state='fail'` audit row (different `audit_id`) referencing the original via `error` payload — resume_forget then retries Neo4j only for that.

### 5.3 Per-tenant Postgres sweep order

Inside the single tx (after `SET LOCAL app.current_tenant`):

```sql
DELETE FROM fact_contradiction WHERE tenant_id = $1;
DELETE FROM ingest_journal     WHERE tenant_id = $1;
DELETE FROM episode_metadata   WHERE tenant_id = $1;
-- FK CASCADE from episode_metadata flows to:
--   content_embedding, content_text, episode_body_encrypted,
--   episode_extracted_quote, lab_record, med_record
```

Order rationale: tables without FK cascade go FIRST (`fact_contradiction`, `ingest_journal`) so they hold no row-locks when `episode_metadata`'s cascade fires. Concurrent ingest race window is documented in §8.

### 5.4 Per-episode Postgres sweep

```sql
SELECT key_id FROM episode_body_encrypted WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]) FOR SHARE;
-- (capture key_ids into bitemporal_snap)
SELECT episode_uuid, asserted_at, valid_at, valid_until
  FROM episode_metadata
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])
 FOR UPDATE;
-- (snapshot bi-temporal axes)
UPDATE episode_metadata SET superseded_by = NULL
 WHERE tenant_id=$1 AND superseded_by = ANY($2::uuid[]);
DELETE FROM fact_contradiction
 WHERE tenant_id=$1 AND (fact_uuid_a = ANY($2::uuid[]) OR fact_uuid_b = ANY($2::uuid[]));
DELETE FROM ingest_journal
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]);
DELETE FROM episode_metadata
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]);
```

`$2` is the cascade-frozen UUID set from §5.2 stage 2 (single uuid if cascade=False or no descendants).

The `UPDATE ... SET superseded_by = NULL` is critical: `episode_metadata.superseded_by` has **no FK** (per migration 0001 line 28-30 — confirmed by bi-temporal-auditor Q1). Without this UPDATE, ancestors retain a dangling pointer to a deleted UUID, and `gnokee_history_of` walks into a void. Ancestors of the deleted set are identified by their `superseded_by ∈ $2::uuid[]`.

### 5.5 Neo4j sweep

**Tenant scope:**
```cypher
MATCH (n {group_id: $tenant_id})
DETACH DELETE n
RETURN count(n) AS deleted_nodes;
```

**Episode scope (with cascade):**
```cypher
UNWIND $uuids AS uuid
MATCH (ep:Episodic {uuid: uuid, group_id: $tenant_id})
DETACH DELETE ep
RETURN count(ep) AS deleted_nodes;
```

Plus orphan-entity cleanup:
```cypher
MATCH (e:Entity {group_id: $tenant_id})
WHERE NOT EXISTS { MATCH (e)<-[:MENTIONS]-(:Episodic) }
DETACH DELETE e;
```

## 6. Bi-temporal honesty + DAG semantics

### 6.1 The supersession-DAG-walk frozen scope (bi-temporal-auditor Q7, Q8)

The DAG walk uses **no temporal predicate** — pure reachability over the `superseded_by` pointer graph (descendants = rows whose `superseded_by = target.uuid`, transitively).

Implementation: recursive CTE inside the Postgres serializable transaction (stage 3) so the descendant set is determined under the same snapshot as the DELETE. The frozen UUID set is written to `forget_audit.cascade_uuids` JSONB before any DELETE fires. `resume_forget` reads this exact set; it does NOT re-walk the DAG.

If a concurrent ingest tries to add a new descendant D between the DAG-walk and the DELETE: the serializable tx detects the conflict; one of the two txs aborts with `serialization_failure`. The forget pipeline retries the walk on its own snapshot (bounded retries). This is the standard Postgres serializable-isolation discipline.

### 6.2 Ancestor cleanup (bi-temporal-auditor Q1)

When forget(B) commits, all rows where `superseded_by = B.uuid` (the ancestors of B) get `SET superseded_by = NULL`. We do **not** reopen `asserted_until` or `valid_until` on those rows. Rationale:

- A's prior assertion (closed-at-`B.asserted_at`) was historically true. The act of correction happened. We are erasing the corrector, not retroactively unmaking the correction.
- Reopening `asserted_until = NULL` would be revisionist: it would assert that A is once again the active head, which is a new fact we have no source for.
- Bi-temporally, this leaves A in state "transaction-time bounded, world-time bounded, no successor pointer" — readable via time-travel queries with `as_of <= A.asserted_until`, not surfaced as live.

This is the bi-temporal-honest choice and is called out as an explicit ADR-0026 consequence.

### 6.3 `valid_at` time-travel post-forget (bi-temporal-auditor Q3)

**Hard-delete erases the row.** `gnokee_query(..., valid_at=<T before forget>)` will NOT surface forgotten episodes even if T predates the forget operation. This is by design — Mode 2 (hard delete) explicitly trades time-travel for hard erasure. Callers who need time-travel through history must use Mode 1 (soft supersession via `EpisodeIn.corrects:`).

ADR-0026 will surface this incompatibility prominently in its Consequences section so the trade-off is documented up-front.

### 6.4 Receipt completeness — `bitemporal_snap` (bi-temporal-auditor Q6)

Before any DELETE fires, the pipeline SELECTs `(episode_uuid, asserted_at, valid_at, valid_until)` for the entire cascade set and writes that to `forget_audit.bitemporal_snap`. This makes the audit row time-axis-complete: a compliance auditor can answer "which world-time + transaction-time window did this forget cover?" without reconstructing the deleted data.

## 7. Crash recovery — `resume_forget`

### 7.1 Module

`src/gnokee/maintenance/resume_forget.py` — mirror of `maintenance.resume_ingest` from #122.

```python
async def scan_resumable_forgets(tenant_id: str) -> list[ResumableForget]:
    """SELECT audit_id, scope, episode_uuid, cascade, started_at, error
         FROM gnokee_maintenance.forget_audit
        WHERE tenant_id = $1 AND state IN ('begin', 'fail')
        ORDER BY started_at;"""

async def resume_forget(tenant_id: str, *, audit_id: UUID | None = None) -> list[ForgetReceiptDetail]:
    """Replay specific or all resumable rows for tenant.
       Each row: re-issue stages 3-9 from §5.2. Reads the frozen cascade_uuids
       and bitemporal_snap from the original audit row — does NOT re-walk
       the DAG."""
```

### 7.2 Resumability matrix (corrected)

| Original outcome | `forget_audit` state | What resume does |
|---|---|---|
| Crash before stage 4 begin INSERT | no row | nothing — call must be re-issued by caller |
| Postgres tx rolled back (crash mid stages 4–6) | row was never committed; no `state='begin'` row exists | same — caller re-issues |
| Postgres tx committed (stage 6), Neo4j sweep failed (stage 7+) | TWO audit rows: original `state='commit'` + new `state='fail'` row linking back to original `audit_id` in its `error` JSONB | retry Neo4j sweep using `cascade_uuids` from the linked `state='commit'` row; on success, UPDATE the fail row to `state='commit'` (resolving its `finished_at`) |
| All stages succeeded | single `state='commit'` row | resume is a no-op (skipped) |

**The earlier draft's claim that `state='begin'` rows survive a crash was wrong.** The corrected design has no `state='begin'` survival mode — those only ever exist inside a still-open transaction. The journal-state genuinely tracking the failure surface is `state='fail'` (Neo4j only).

### 7.3 Idempotency on replay

All DELETEs are idempotent (empty result = no error). The frozen `cascade_uuids` ensures the replay scope is identical to the original. Receipt's `postgres_rows_deleted` will be 0 on replay if the original Postgres tx already succeeded — `resume_forget` interprets this as the expected idempotent outcome, not a failure.

### 7.4 `partial` field — internal only

The MCP-facing `ForgetReceipt` does **NOT** include a `partial` field (mcp-tool-designer F7). The Python API `ForgetReceiptDetail` includes `partial: bool` so operators and resume tooling can branch on it.

LLMs that get `ForgetReceipt` and want to know "did the full operation succeed end-to-end?" check that the receipt was returned at all — gnokee raises on Neo4j failure rather than returning a partial receipt with `partial=True`.

### 7.5 CLI surface

```
gnokee maintenance scan-forgets --tenant <t>
gnokee maintenance resume-forget --tenant <t> [--audit-id <uuid>]
```

Not exposed via MCP (matches `resume_ingest` precedent).

## 8. Concurrency, locking, isolation

- **Serializable isolation** on the forget Postgres tx (`BEGIN ISOLATION LEVEL SERIALIZABLE`). Postgres surfaces concurrent-write conflicts as `serialization_failure`; the pipeline retries the tx up to 3 times with jittered backoff (mirrors ADR-0023's `_retry_enhancement` shape).
- **`SET LOCAL app.current_tenant = $1`** inside the tx so all RLS-gated DELETEs operate on the right tenant scope (postgres-pgvector-specialist B1). Without this, `ingest_journal`'s RLS policy returns zero rows and the cascade is silently broken.
- **Tenant quiescence not required** but **strongly recommended.** Concurrent ingest on the same tenant may cause `serialization_failure` retries on the forget side and `serialization_failure` (or wait) on the ingest side. The pipeline documents this in its docstring and the architecture doc. (No advisory-lock primitive in v1 — bumped to a follow-up if telemetry shows real contention.)
- **`SELECT … FOR UPDATE`** on the cascade descendant closure + `episode_body_encrypted` pre-fetch ensures the bi-temporal snapshot and key_id capture are consistent with the eventual DELETE.

## 9. Failure modes inventory

| Failure | Where detected | What gnokee does | Caller sees |
|---|---|---|---|
| `episode_not_found` | stage 1 | Check for prior `commit` audit row; if found return `replayed=True` receipt; else raise | `episode_not_found` (real miss) or success receipt with `replayed=True` |
| `tenant_not_found` | stage 1 | Same idempotency check at tenant grain | Same |
| `cannot_forget_chain_node` | stage 2 | Refuse, no audit row | `cannot_forget_chain_node` envelope per §3.1.1 |
| `confirm_*` mismatch | n/a — no `confirm_tenant_id` parameter; `dry_run=True` is the guard | n/a | n/a |
| `missing_audit_fields` | stage 1 | `reason` is required at the Pydantic boundary; raises before any tx | `missing_audit_fields` validation error |
| `serialization_failure` | stage 4-6 | Retry tx up to 3× with jittered backoff; on exhaustion raise | `forget_contention` error pointing to retry |
| Postgres tx fail (any other) | stage 4-6 | Tx rolls back; no audit row persists; raise | underlying error |
| Neo4j sweep fail (stage 7) | stage 7 | Write `state='fail'` audit row; raise; resume_forget handles retry | `forget_neo4j_partial` error with `audit_id`; operator runs `resume_forget` |
| Caller passes `reason` with apparent PII (heuristic) | not validated by gnokee | Caller's problem; field length-cap is gnokee's only guardrail | n/a |

## 10. Accepted consequences (for ADR-0026)

- **Time-travel through pre-forget windows is broken by Mode 2** — explicit, not a regression. Mode 1 (soft supersession) is the time-travel-preserving path.
- **`gnokee_history_of(A)` after `forget(B, cascade=True)` shows a truncated lineage** — the system cannot distinguish "A was never corrected" from "A was corrected by B which was later forgotten." Compliance trade-off accepted.
- **`forget_audit` grows unbounded** without operator pruning. Default retention = forever. Operator CLI for pruning is a follow-up issue.
- **Single-statement Neo4j DETACH on huge tenants** may OOM. Chunked path is a telemetry-gated follow-up.
- **Tenant quiescence during forget is not enforced** — concurrent ingest may surface as `serialization_failure` retries on both sides. Documented, not yet mitigated by advisory lock.
- **No cryptographic-erasure mode as a distinct code path in v1** — hard-delete surfaces affected `key_id`s on the receipt; the consumer-side KMS destruction is out-of-band.
- **`reason` is required free-text capped at 500 chars** — gnokee does not PII-scan it; field description warns the caller.

## 11. Testing

### 11.1 Unit (`tests/unit/forget/`)

- `test_forget_models.py` — Pydantic boundaries: missing `reason`, oversized `reason`, `dry_run` default, invalid `scope`+`episode_uuid` combinations.
- `test_dag_walker.py` — recursive CTE: no-chain, linear, branched, deeply nested. Frozen-scope correctness.
- `test_receipt_shape.py` — `ForgetReceipt` (MCP) vs `ForgetReceiptDetail` (Python) round-trip; ensure storage-metric dicts NEVER appear on MCP shape.
- `test_audit_constraints.py` — `gnokee_maintenance.forget_audit` CHECK constraints: scope/episode_uuid exclusivity; state transitions.

### 11.2 Integration (`tests/integration/test_forget_pipeline.py`)

Real Postgres + Neo4j (session-scoped fixtures per the `pytest_asyncio_session_loop` memory entry):

1. `test_forget_episode_no_chain` — single fact, both stores clean, receipt counts.
2. `test_forget_episode_refuses_chain_node` — A→B→C, forget(B, cascade=False) raises with bounded payload.
3. `test_forget_episode_cascade_descendants` — forget(B, cascade=True): B + C gone, A live, `A.superseded_by = NULL`.
4. `test_forget_episode_idempotent_replay` — second call returns prior receipt with `replayed=True`; no second audit row.
5. `test_forget_episode_encrypted_body` — receipt's `affected_key_ids[]` populated with all DEK ids of cascaded episodes.
6. `test_forget_episode_bitemporal_snap` — audit row's `bitemporal_snap` JSONB captures the deleted episode's `{asserted_at, valid_at, valid_until}`.
7. `test_forget_tenant_dry_run` — dry_run=True returns a populated receipt; nothing deleted; no audit row.
8. `test_forget_tenant_full_sweep` — 5-episode tenant; all per-tenant tables empty after; `ingest_journal` empty (closes #130 explicitly); Neo4j group_id wiped.
9. `test_forget_tenant_audit_survives` — `gnokee_maintenance.forget_audit` row readable AFTER the tenant is wiped.
10. `test_resume_forget_after_neo4j_crash` — inject Neo4j fault between stage 6 commit and stage 7; verify `state='fail'` row + retry-via-`resume_forget` cleans up.
11. `test_serialization_retry` — concurrent ingest + forget on same tenant; both eventually succeed via retry.
12. `test_fact_contradiction_swept` — tenant with contradictions; tenant-forget DELETEs `fact_contradiction` explicitly.
13. `test_ingest_journal_swept_per_tenant` — `ingest_journal` for the tenant is empty after `forget_tenant`. Direct verification of #130's fix.
14. `test_ingest_journal_swept_per_episode` — episode-grain forget also removes the corresponding `ingest_journal` rows.

### 11.3 Q5 spike extension

Update `evals/spike_q5_forgetting/`:
- Probe 3: forget mid-chain node without cascade → expect refusal.
- Probe 4: forget tenant → assert `ingest_journal`, `fact_contradiction`, all FK-CASCADE descendants, Neo4j group_id all empty.
- README: remove "Tenant-scoped forget isolation" from "What this spike does NOT cover."

## 12. File inventory

```
docs/adr/0026-forget-pipeline.md                            [new]
docs/architecture.md                                         [edit: pin Mode-2 + add §10 trade-off note]
docs/superpowers/specs/2026-05-16-gnokee-forget-pipeline-design.md   [this doc]
docs/superpowers/plans/2026-05-16-gnokee-forget-pipeline.md  [from writing-plans]
src/gnokee/storage/migrations/0017_forget_audit.sql         [new]
src/gnokee/forget/__init__.py                                [new]
src/gnokee/forget/models.py                                  [new]
src/gnokee/forget/pipeline.py                                [new]
src/gnokee/forget/dag.py                                     [new]
src/gnokee/forget/audit.py                                   [new]
src/gnokee/maintenance/resume_forget.py                      [new]
src/gnokee/mcp.py                                            [edit: register gnokee_forget_episode + gnokee_forget_tenant after gnokee_history_of]
src/gnokee/storage/graphiti_store.py                         [edit: add remove_episode_by_uuid, remove_tenant_group]
src/gnokee/cli/maintenance.py                                [edit: scan-forgets, resume-forget commands]
tests/unit/forget/test_forget_models.py                      [new]
tests/unit/forget/test_dag_walker.py                         [new]
tests/unit/forget/test_receipt_shape.py                      [new]
tests/unit/forget/test_audit_constraints.py                  [new]
tests/integration/test_forget_pipeline.py                    [new]
evals/spike_q5_forgetting/run.py                             [edit]
evals/spike_q5_forgetting/README.md                          [edit]
AGENTS.md                                                    [edit: update example tool name list to mention both gnokee_forget_episode + gnokee_forget_tenant]
```

## 13. ADR-0026 outline

- **Status:** Proposed → Accepted at merge.
- **Context:** architecture.md §Forgetting names 3 modes; Mode 1 shipped v0.2.1; Mode 2 (this) addresses #130 cascade gap and the long-running un-shipped hard-delete path; Mode 3 deferred (consumer KMS dependency).
- **Decision:** §3–§9 of this spec verbatim.
- **Consequences:** §10 of this spec.
- **Cross-refs:** ADR-0004 §Forgetting, ADR-0022 (refusal posture), ADR-0023 (gnokee owns episode write), ADR-0024 (ingest journal — twin precedent), AGENTS.md "verifiable forgetting," `docs/architecture.md` §Forgetting.

## 14. Closes / follow-ups

- **Closes:** [#130](https://github.com/gnokeelabs/gnokee/issues/130).
- **Filed during this spec:** none (deferring chunked-Neo4j-DETACH + audit-pruner + advisory-lock until telemetry justifies).

## 15. Specialist review summary

This spec incorporates findings from three specialist sub-agent reviews (2026-05-16):

- **postgres-pgvector-specialist** — 3 BLOCKERS resolved: tenant-GUC inside tx, inverted crash-recovery semantics (corrected throughout), schema-isolated `forget_audit` instead of public-no-RLS. 5 WARNs incorporated (fact_contradiction explicit DELETE, deadlock note, CHECK tightening, IF NOT EXISTS on indexes, replay row-count=0 documented).
- **bi-temporal-auditor** — 4 BLOCKERS resolved: explicit `superseded_by = NULL` UPDATE (no FK exists), `valid_at` time-travel incompatibility documented as accepted, serializable + FOR UPDATE for ingest race, frozen cascade-UUID JSONB (not re-walked). 4 WARNs incorporated (no temporal filter on DAG walk, history-truncation called out, receipt `bitemporal_snap`, axis labels).
- **mcp-tool-designer** — 5 BLOCKERS resolved: `cascade=True` description forbids LLM auto-cascade, refusal payload bounded to count + tail UUID, `affected_key_ids` description carries action instruction, `partial` removed from MCP shape, storage-metric dicts collapsed to `summary` string for MCP. 4 WARNs incorporated (required `reason` with PII warning, `replayed: bool`, tool-list ordering, `dry_run` replaces `confirm_tenant_id`).
