# gnokee forget pipeline — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship `gnokee_forget_episode` + `gnokee_forget_tenant` MCP tools (ADR-0026) with verifiable audit, frozen-cascade DAG, and opt-in `resume_forget`. Closes [#130](https://github.com/gnokeelabs/gnokee/issues/130).

**Architecture:** Stages 4–6 (audit-begin INSERT + Postgres sweep + audit-commit UPDATE) inside a single SERIALIZABLE Postgres tx. Neo4j sweep is a separate phase post-Postgres-commit; failure writes a linked `state='fail'` audit row that `resume_forget` retries. The supersession DAG is walked via recursive CTE inside the serializable tx; the descendant UUID set is frozen into `forget_audit.cascade_uuids` JSONB at begin time and reused verbatim on resume. `forget_audit` lives in a `gnokee_maintenance` schema so it survives `gnokee_forget_tenant(t)` (the proof-of-deletion artifact must outlive the deletion).

**Tech Stack:** Python 3.10+ strict-typed, pydantic v2, asyncpg, graphiti-core 0.29, Neo4j 5 Community, pgvector, pytest-asyncio session-scoped fixtures.

**Spec:** [`docs/superpowers/specs/2026-05-16-gnokee-forget-pipeline-design.md`](../specs/2026-05-16-gnokee-forget-pipeline-design.md)

**Out of scope (deferred):** Operator CLI for `scan-forgets` / `resume-forget` (match `resume_ingest` precedent — Python API only). Chunked Neo4j DETACH for >1M-node tenants. `forget_audit` retention pruner. Advisory-lock primitive for ingest/forget contention.

---

## File Structure

**New files:**
- `src/gnokee/storage/migrations/0017_forget_audit.sql` — `gnokee_maintenance.forget_audit` table + partial index.
- `src/gnokee/storage/forget_audit.py` — async CRUD helpers (`insert_begin`, `mark_commit`, `mark_fail`, `find_resumable`, `find_prior_commit`).
- `src/gnokee/forget.py` — `ForgetPipeline` class, DAG walker (recursive CTE), public `forget_episode` / `forget_tenant`.
- `tests/unit/test_forget_models.py` — Pydantic boundary tests.
- `tests/unit/test_forget_audit.py` — CRUD unit tests against asyncpg test pool.
- `tests/unit/test_forget_dag.py` — DAG walker recursive-CTE coverage.
- `tests/unit/test_resume_forget.py` — Mocked replay unit tests (mirror `test_resume_ingest.py`).
- `tests/integration/test_forget_pipeline.py` — Real PG + Neo4j integration suite (14 cases per spec §11.2).
- `docs/adr/0026-forget-pipeline.md` — ADR.

**Modified files:**
- `src/gnokee/models.py` — add `ForgetEpisodeIn`, `ForgetTenantIn`, `ForgetReceipt`, `ForgetReceiptDetail`, `ForgetRefusal`.
- `src/gnokee/maintenance.py` — add `resume_forget` function alongside `resume_ingest`.
- `src/gnokee/mcp.py` — register `gnokee_forget_episode` + `gnokee_forget_tenant` after `gnokee_history_of`.
- `src/gnokee/storage/graph.py` — add `GraphitiStore.remove_tenant_group(tenant_id)`; existing `remove_episode` already covers the per-uuid case.
- `src/gnokee/errors.py` — add `CannotForgetChainNode`, `ForgetContention`, `ForgetNeo4jPartial`.
- `evals/spike_q5_forgetting/run.py` — add Probes 3 + 4.
- `evals/spike_q5_forgetting/README.md` — remove "Tenant-scoped forget isolation" from non-coverage list.
- `docs/architecture.md` — pin Mode-2 contract + time-travel incompatibility note.
- `AGENTS.md` — update tool-name example list to include both `gnokee_forget_episode` + `gnokee_forget_tenant`.

---

### Task 1: Add typed forget errors

**Files:**
- Modify: `src/gnokee/errors.py`
- Test: `tests/unit/test_errors.py` (extend existing)

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_errors.py`:

```python
def test_forget_errors_exist_and_are_gnokee_errors() -> None:
    from gnokee.errors import (
        CannotForgetChainNode,
        ForgetContention,
        ForgetNeo4jPartial,
        GnokeeError,
    )

    for cls in (CannotForgetChainNode, ForgetContention, ForgetNeo4jPartial):
        assert issubclass(cls, GnokeeError)

    err = CannotForgetChainNode(
        descendant_count=3,
        deepest_descendant_uuid="11111111-1111-1111-1111-111111111111",
    )
    assert err.descendant_count == 3
    assert "cascade=True" in str(err)
```

- [ ] **Step 2: Run test to verify failure**

`pytest tests/unit/test_errors.py::test_forget_errors_exist_and_are_gnokee_errors -v`

Expected: FAIL with `ImportError: cannot import name 'CannotForgetChainNode'`.

- [ ] **Step 3: Implement errors**

Append to `src/gnokee/errors.py`:

```python
class CannotForgetChainNode(GnokeeError):
    """Refusal raised when a target episode has supersession descendants
    and the caller did not pass `cascade=True`. Surfaces a bounded payload
    (count + tail UUID) — never inlines the full descendant list."""

    def __init__(self, *, descendant_count: int, deepest_descendant_uuid: str) -> None:
        self.descendant_count = descendant_count
        self.deepest_descendant_uuid = deepest_descendant_uuid
        super().__init__(
            f"Episode is corrected by {descendant_count} descendant(s); "
            f"deepest tail = {deepest_descendant_uuid}. "
            "Resubmit with cascade=True only after explicit operator approval — "
            "this is permanent and irreversible."
        )


class ForgetContention(GnokeeError):
    """Postgres serializable retry budget exhausted under concurrent ingest."""


class ForgetNeo4jPartial(GnokeeError):
    """Postgres sweep committed; Neo4j sweep failed. Carries the audit_id
    so the caller can invoke `gnokee.maintenance.resume_forget` for retry."""

    def __init__(self, *, audit_id: str, cause: BaseException) -> None:
        self.audit_id = audit_id
        super().__init__(
            f"Postgres sweep committed (audit_id={audit_id}); Neo4j sweep failed. "
            f"Invoke gnokee.maintenance.resume_forget(audit_id=...) to retry."
        )
        self.__cause__ = cause
```

- [ ] **Step 4: Test passes**

`pytest tests/unit/test_errors.py::test_forget_errors_exist_and_are_gnokee_errors -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/errors.py tests/unit/test_errors.py
git commit -m "feat(errors): add CannotForgetChainNode, ForgetContention, ForgetNeo4jPartial (ADR-0026)"
```

---

### Task 2: Pydantic models for forget surface

**Files:**
- Modify: `src/gnokee/models.py`
- Create: `tests/unit/test_forget_models.py`

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_forget_models.py`:

```python
"""tests/unit/test_forget_models.py — ADR-0026 forget surface boundary tests."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

import pytest
from pydantic import ValidationError

from gnokee.models import (
    ForgetEpisodeIn,
    ForgetReceipt,
    ForgetReceiptDetail,
    ForgetTenantIn,
)


def _utc() -> datetime:
    return datetime(2026, 5, 16, 12, 0, 0, tzinfo=timezone.utc)


def test_forget_episode_in_requires_reason() -> None:
    with pytest.raises(ValidationError, match="reason"):
        ForgetEpisodeIn(tenant_id="t1", episode_uuid=uuid4())


def test_forget_episode_in_caps_reason_at_500_chars() -> None:
    with pytest.raises(ValidationError, match="500"):
        ForgetEpisodeIn(tenant_id="t1", episode_uuid=uuid4(), reason="x" * 501)


def test_forget_episode_in_cascade_default_false() -> None:
    spec = ForgetEpisodeIn(tenant_id="t1", episode_uuid=uuid4(), reason="audit")
    assert spec.cascade is False


def test_forget_episode_in_rejects_empty_tenant() -> None:
    with pytest.raises(ValidationError, match="tenant_id"):
        ForgetEpisodeIn(tenant_id="", episode_uuid=uuid4(), reason="audit")


def test_forget_tenant_in_dry_run_default_true() -> None:
    spec = ForgetTenantIn(tenant_id="t1", reason="audit")
    assert spec.dry_run is True


def test_forget_tenant_in_requires_reason() -> None:
    with pytest.raises(ValidationError, match="reason"):
        ForgetTenantIn(tenant_id="t1")


def test_forget_receipt_strips_storage_dicts_from_mcp_shape() -> None:
    """MCP shape MUST NOT carry postgres_rows_deleted etc."""
    fields = ForgetReceipt.model_fields.keys()
    assert "postgres_rows_deleted" not in fields
    assert "neo4j_nodes_deleted" not in fields
    assert "neo4j_edges_deleted" not in fields
    assert "partial" not in fields
    assert "summary" in fields
    assert "affected_key_ids" in fields
    assert "replayed" in fields


def test_forget_receipt_detail_carries_full_dicts() -> None:
    """Python API (operator) shape carries everything."""
    fields = ForgetReceiptDetail.model_fields.keys()
    assert "postgres_rows_deleted" in fields
    assert "neo4j_nodes_deleted" in fields
    assert "neo4j_edges_deleted" in fields
    assert "partial" in fields
    assert "cascaded_episode_uuids" in fields


def test_forget_receipt_minimal_round_trip() -> None:
    audit_id = uuid4()
    r = ForgetReceipt(
        audit_id=audit_id,
        tenant_id="t1",
        scope="episode",
        episode_uuid=uuid4(),
        cascade=False,
        dry_run=False,
        summary="Deleted 1 episode: 4 Postgres rows, 1 Neo4j node, 0 Neo4j edges.",
        affected_episode_count=1,
        deepest_episode_uuid=None,
        affected_key_ids=[],
        replayed=False,
        started_at=_utc(),
        finished_at=_utc(),
        actor=None,
        reason="audit",
    )
    assert r.audit_id == audit_id
    assert r.scope == "episode"
```

- [ ] **Step 2: Run tests — verify failures**

`pytest tests/unit/test_forget_models.py -v`

Expected: all FAIL with `ImportError`.

- [ ] **Step 3: Implement the models**

Append to `src/gnokee/models.py` (preserve existing exports list — update the module docstring's `exports:` line to include the new classes):

```python
class ForgetEpisodeIn(BaseModel):
    """Input for `gnokee_forget_episode` MCP tool / `gnokee.forget.forget_episode` API.

    `cascade` MUST NOT be set True without explicit operator approval; the
    refusal `cannot_forget_chain_node` is the gate — see ADR-0026 / ADR-0022.
    """

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    episode_uuid: UUID
    cascade: bool = Field(
        default=False,
        description=(
            "If True, recursively hard-deletes this episode AND all "
            "supersession descendants (episodes that corrected this one, "
            "transitively). Ancestors are NEVER cascaded. Default False. "
            "DO NOT set True without explicit operator instruction — this is "
            "permanent and irreversible. If this tool refuses with "
            "'cannot_forget_chain_node', surface the refusal to the operator "
            "and obtain explicit consent before retrying with cascade=True."
        ),
    )
    reason: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description=(
            "Required. Category label only — DO NOT include personal data "
            "(names, identifiers, diagnoses). This field is persisted in the "
            "forget_audit table which survives tenant deletion."
        ),
    )
    actor: str | None = None


class ForgetTenantIn(BaseModel):
    """Input for `gnokee_forget_tenant` MCP tool / `gnokee.forget.forget_tenant` API."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    dry_run: bool = Field(
        default=True,
        description=(
            "DEFAULT TRUE. dry_run=True returns a planned ForgetReceipt "
            "with no writes — counts of rows that would be deleted, key_ids "
            "that would be surfaced. To actually destroy the tenant, the "
            "caller MUST issue a SECOND call with dry_run=False. This is a "
            "deliberate two-call ceremony for an irreversible operation."
        ),
    )
    reason: str = Field(..., min_length=1, max_length=500)
    actor: str | None = None


class ForgetReceipt(BaseModel):
    """Compact MCP-facing return. See `ForgetReceiptDetail` for the
    Python-API operator shape that carries internal storage metrics."""

    model_config = ConfigDict(extra="forbid")

    audit_id: UUID
    tenant_id: str
    scope: Literal["episode", "tenant"]
    episode_uuid: UUID | None = None
    cascade: bool = False
    dry_run: bool = False

    summary: str = Field(
        description=(
            "Human-readable summary. Examples: 'Deleted 1 episode: "
            "4 Postgres rows, 1 Neo4j node, 2 Neo4j edges.' or 'PLANNED "
            "(dry_run): tenant X — N episodes.'"
        ),
    )
    affected_episode_count: int = Field(
        ge=0,
        description=(
            "Episode tool: 1 (no cascade) or 1+descendants (cascade). "
            "Tenant tool: full count of distinct episodes affected."
        ),
    )
    deepest_episode_uuid: UUID | None = Field(
        default=None,
        description="Episode-cascade only: chain-tail UUID. Tenant tool returns None.",
    )

    affected_key_ids: list[str] = Field(
        default_factory=list,
        description=(
            "DEK identifiers (key_id) of any encrypted episode bodies "
            "destroyed by this operation. When non-empty, the consumer "
            "MUST destroy these DEKs in their KMS to complete the "
            "cryptographic-erasure mode of the forgetting contract. "
            "gnokee never touches keys."
        ),
    )

    replayed: bool = Field(
        default=False,
        description=(
            "True when this receipt is returned from a prior successful "
            "commit found in forget_audit — i.e. the operation was "
            "already performed in a previous call. No new writes occurred."
        ),
    )

    started_at: datetime
    finished_at: datetime
    actor: str | None = None
    reason: str

    @field_validator("started_at", "finished_at")
    @classmethod
    def _ensure_utc(cls, value: datetime) -> datetime:
        return _require_utc(value)


class ForgetReceiptDetail(ForgetReceipt):
    """Operator / Python-API shape. Extends `ForgetReceipt` with
    full storage-metric dicts + the frozen cascade UUID list. Never
    serialized through MCP — kept inside the Python API and the
    `forget_audit.receipt` JSONB."""

    model_config = ConfigDict(extra="forbid")

    postgres_rows_deleted: dict[str, int] = Field(default_factory=dict)
    neo4j_nodes_deleted: dict[str, int] = Field(default_factory=dict)
    neo4j_edges_deleted: dict[str, int] = Field(default_factory=dict)
    cascaded_episode_uuids: list[UUID] = Field(default_factory=list)
    partial: bool = Field(
        default=False,
        description="True when Postgres committed but Neo4j sweep failed.",
    )
    bitemporal_snap: list[dict[str, object]] = Field(
        default_factory=list,
        description=(
            "Pre-DELETE snapshot of (episode_uuid, asserted_at, valid_at, "
            "valid_until) for every episode in the cascade scope. Time-axis-"
            "complete compliance artifact per ADR-0026 §6.4."
        ),
    )
```

Update `src/gnokee/models.py` module-docstring `exports:` line: append `ForgetEpisodeIn | ForgetTenantIn | ForgetReceipt | ForgetReceiptDetail`. Update `agent:` trailer with a 2026-05-16 ADR-0026 line.

- [ ] **Step 4: Tests pass**

`pytest tests/unit/test_forget_models.py -v`

Expected: 9 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/models.py tests/unit/test_forget_models.py
git commit -m "feat(models): ForgetEpisodeIn/ForgetTenantIn/ForgetReceipt/ForgetReceiptDetail (ADR-0026)"
```

---

### Task 3: Migration 0017 — `gnokee_maintenance.forget_audit`

**Files:**
- Create: `src/gnokee/storage/migrations/0017_forget_audit.sql`
- Modify: `tests/unit/test_migrate.py` (bump count + name list)

- [ ] **Step 1: Write the failing test**

Edit `tests/unit/test_migrate.py::test_discover_migrations_returns_sorted_files`:

```python
def test_discover_migrations_returns_sorted_files() -> None:
    here = Path(__file__).parent.parent.parent / "src" / "gnokee" / "storage" / "migrations"
    migrations = discover_migrations(here)
    assert len(migrations) == 17
    names = [m.name for m in migrations]
    assert names[-1] == "0017_forget_audit.sql"
```

(Leave the full list assertion intact — just bump the trailing element.)

- [ ] **Step 2: Run — verify failure**

`pytest tests/unit/test_migrate.py::test_discover_migrations_returns_sorted_files -v`

Expected: FAIL with `assert 16 == 17`.

- [ ] **Step 3: Create the migration**

Create `src/gnokee/storage/migrations/0017_forget_audit.sql`:

```sql
-- 0017_forget_audit.sql
-- ADR-0026 — system-scoped audit + journal for gnokee.forget pipeline (#130).
--
-- Schema isolation rationale: this table survives gnokee_forget_tenant(t).
-- That is its purpose — verifiable proof that the deletion happened, readable
-- by operators after the tenant is gone. Placing it in a separate schema
-- (gnokee_maintenance) decouples it from the per-tenant cascade and from
-- any future MCP audit-read surface that would need its own RLS pass.
--
-- The application connection retains full CRUD on this table because the
-- forget pipeline itself writes here; no SQL-pass-through surface in gnokee
-- today reaches this schema.
--
-- Row shape mirrors ingest_journal (ADR-0024) on its state-transition axis
-- (begin -> commit | fail). Resume semantics differ — see ADR-0026 §7.

CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.forget_audit (
    audit_id          UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id         TEXT        NOT NULL,
    scope             TEXT        NOT NULL CHECK (scope IN ('episode', 'tenant')),
    episode_uuid      UUID,
    cascade           BOOLEAN     NOT NULL DEFAULT FALSE,
    dry_run           BOOLEAN     NOT NULL DEFAULT FALSE,
    state             TEXT        NOT NULL CHECK (state IN ('begin', 'commit', 'fail')),
    actor             TEXT,
    reason            TEXT        NOT NULL,
    receipt           JSONB,        -- populated at 'commit'; ForgetReceiptDetail serialization
    error             JSONB,        -- populated at 'fail'; carries linked audit_id for Neo4j-only failures
    cascade_uuids     JSONB,        -- frozen descendant set when scope='episode' AND cascade=TRUE
    bitemporal_snap   JSONB,        -- per-deleted-uuid {asserted_at, valid_at, valid_until} captured pre-DELETE
    started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at       TIMESTAMPTZ,
    PRIMARY KEY (audit_id),
    CHECK (
        (scope = 'episode' AND episode_uuid IS NOT NULL)
        OR
        (scope = 'tenant'  AND episode_uuid IS NULL)
    )
);

-- Resumable hot path: 'begin' state rows oldest-first per tenant.
CREATE INDEX IF NOT EXISTS forget_audit_resumable_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'begin';

-- 'fail' rows for resume_forget Neo4j-retry scan.
CREATE INDEX IF NOT EXISTS forget_audit_failed_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'fail';

-- No RLS. Schema-level isolation is the access model. Operator queries
-- this table directly; the application connection inserts/updates via
-- gnokee.storage.forget_audit module.
```

- [ ] **Step 4: Test passes**

`pytest tests/unit/test_migrate.py::test_discover_migrations_returns_sorted_files -v`

Expected: PASS.

- [ ] **Step 5: Smoke-run migration against local Postgres**

```bash
gnokee-migrate
psql "$GNOKEE_DB_URL" -c "\dt gnokee_maintenance.*"
```

Expected output includes `forget_audit`. Inspect indexes:

```bash
psql "$GNOKEE_DB_URL" -c "\di gnokee_maintenance.*"
```

Expected: `forget_audit_resumable_idx`, `forget_audit_failed_idx`.

- [ ] **Step 6: Commit**

```bash
git add src/gnokee/storage/migrations/0017_forget_audit.sql tests/unit/test_migrate.py
git commit -m "feat(storage): migration 0017 gnokee_maintenance.forget_audit (ADR-0026, #130)"
```

---

### Task 4: `forget_audit` async CRUD module

**Files:**
- Create: `src/gnokee/storage/forget_audit.py`
- Create: `tests/unit/test_forget_audit.py` (uses an asyncpg pool fixture; integration-flavored unit test)

- [ ] **Step 1: Write the failing tests**

Create `tests/unit/test_forget_audit.py`:

```python
"""tests/unit/test_forget_audit.py — gnokee_maintenance.forget_audit CRUD."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID, uuid4

import pytest

from gnokee.storage.forget_audit import (
    ForgetAuditRow,
    find_prior_commit,
    find_resumable,
    insert_begin,
    mark_commit,
    mark_fail,
)

pytestmark = [pytest.mark.integration]  # needs Postgres pool fixture


def _utc() -> datetime:
    return datetime(2026, 5, 16, 12, 0, 0, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_insert_begin_returns_row_with_audit_id(pg_pool, fresh_tenant: str) -> None:
    audit_id = await insert_begin(
        pg_pool,
        tenant_id=fresh_tenant,
        scope="episode",
        episode_uuid=uuid4(),
        cascade=False,
        dry_run=False,
        reason="unit-test",
        actor="test-suite",
        cascade_uuids=None,
        bitemporal_snap=None,
    )
    assert isinstance(audit_id, UUID)


@pytest.mark.asyncio
async def test_mark_commit_updates_state_and_receipt(pg_pool, fresh_tenant: str) -> None:
    audit_id = await insert_begin(
        pg_pool,
        tenant_id=fresh_tenant,
        scope="tenant",
        episode_uuid=None,
        cascade=False,
        dry_run=False,
        reason="unit-test",
        actor=None,
        cascade_uuids=None,
        bitemporal_snap=None,
    )
    await mark_commit(
        pg_pool,
        audit_id=audit_id,
        receipt={"scope": "tenant", "affected_episode_count": 0},
    )
    rows = await find_resumable(pg_pool, tenant_id=fresh_tenant)
    assert rows == []


@pytest.mark.asyncio
async def test_find_resumable_returns_only_begin_state(pg_pool, fresh_tenant: str) -> None:
    a = await insert_begin(
        pg_pool, tenant_id=fresh_tenant, scope="tenant", episode_uuid=None,
        cascade=False, dry_run=False, reason="r", actor=None,
        cascade_uuids=None, bitemporal_snap=None,
    )
    b = await insert_begin(
        pg_pool, tenant_id=fresh_tenant, scope="tenant", episode_uuid=None,
        cascade=False, dry_run=False, reason="r", actor=None,
        cascade_uuids=None, bitemporal_snap=None,
    )
    await mark_commit(pg_pool, audit_id=a, receipt={})
    rows = await find_resumable(pg_pool, tenant_id=fresh_tenant)
    assert [r.audit_id for r in rows] == [b]


@pytest.mark.asyncio
async def test_find_prior_commit_for_episode_returns_latest(pg_pool, fresh_tenant: str) -> None:
    ep_uuid = uuid4()
    a = await insert_begin(
        pg_pool, tenant_id=fresh_tenant, scope="episode", episode_uuid=ep_uuid,
        cascade=False, dry_run=False, reason="r", actor=None,
        cascade_uuids=None, bitemporal_snap=None,
    )
    await mark_commit(pg_pool, audit_id=a, receipt={"x": 1})
    found: ForgetAuditRow | None = await find_prior_commit(
        pg_pool, tenant_id=fresh_tenant, scope="episode", episode_uuid=ep_uuid
    )
    assert found is not None
    assert found.audit_id == a
    assert found.receipt == {"x": 1}


@pytest.mark.asyncio
async def test_mark_fail_persists_error_payload(pg_pool, fresh_tenant: str) -> None:
    a = await insert_begin(
        pg_pool, tenant_id=fresh_tenant, scope="tenant", episode_uuid=None,
        cascade=False, dry_run=False, reason="r", actor=None,
        cascade_uuids=None, bitemporal_snap=None,
    )
    await mark_fail(pg_pool, audit_id=a, error={"kind": "neo4j_partial", "linked_audit_id": str(uuid4())})
    rows = await find_resumable(pg_pool, tenant_id=fresh_tenant)
    assert rows == []  # 'fail' state excluded from resumable scan
```

- [ ] **Step 2: Run — verify failures**

`pytest tests/unit/test_forget_audit.py -v -m integration`

Expected: all FAIL with `ImportError` from `gnokee.storage.forget_audit`.

- [ ] **Step 3: Implement `src/gnokee/storage/forget_audit.py`**

```python
"""src/gnokee/storage/forget_audit.py — gnokee_maintenance.forget_audit CRUD.

Pure async helpers over the audit table introduced by migration 0017.
The pipeline (src/gnokee/forget.py) is the only caller for INSERT /
UPDATE; maintenance.resume_forget reads via find_resumable.

exports: ForgetAuditRow | insert_begin | mark_commit | mark_fail | find_resumable | find_prior_commit
used_by: src/gnokee/forget.py | src/gnokee/maintenance.py
rules:   tenant_id on every read/write; no RLS (schema-isolated); tz-aware UTC
agent:   claude-opus-4-7 | 2026-05-16 | issue #130 ADR-0026 impl
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal
from uuid import UUID

import asyncpg

Scope = Literal["episode", "tenant"]


@dataclass(frozen=True, slots=True)
class ForgetAuditRow:
    audit_id: UUID
    tenant_id: str
    scope: Scope
    episode_uuid: UUID | None
    cascade: bool
    dry_run: bool
    state: Literal["begin", "commit", "fail"]
    reason: str
    actor: str | None
    receipt: dict[str, Any] | None
    error: dict[str, Any] | None
    cascade_uuids: list[str] | None
    bitemporal_snap: list[dict[str, Any]] | None
    started_at: datetime
    finished_at: datetime | None


async def insert_begin(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
    cascade: bool,
    dry_run: bool,
    reason: str,
    actor: str | None,
    cascade_uuids: list[str] | None,
    bitemporal_snap: list[dict[str, Any]] | None,
) -> UUID:
    """INSERT a state='begin' row. Returns the generated `audit_id`.

    Caller MUST run this inside an open transaction it controls (so the
    audit-begin row commits atomically with the Postgres sweep). The
    pool acquire here is for code-locality only; the caller wires the
    connection via `pool.acquire()` itself in the forget pipeline.
    """
    sql = """
        INSERT INTO gnokee_maintenance.forget_audit
            (tenant_id, scope, episode_uuid, cascade, dry_run, state,
             reason, actor, cascade_uuids, bitemporal_snap)
        VALUES
            ($1, $2, $3, $4, $5, 'begin', $6, $7, $8, $9)
        RETURNING audit_id;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            sql,
            tenant_id,
            scope,
            episode_uuid,
            cascade,
            dry_run,
            reason,
            actor,
            json.dumps(cascade_uuids) if cascade_uuids is not None else None,
            json.dumps(bitemporal_snap) if bitemporal_snap is not None else None,
        )
    assert row is not None
    return row["audit_id"]


async def mark_commit(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    receipt: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'commit',
               receipt = $2,
               finished_at = now()
         WHERE audit_id = $1 AND state IN ('begin', 'fail');
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(receipt))


async def mark_fail(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    error: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'fail',
               error = $2,
               finished_at = now()
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(error))


async def find_resumable(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    """Return state='begin' rows for tenant, oldest-first.

    'fail' rows are surfaced separately via find_failed_neo4j_rows;
    resume_forget consumes both lists.
    """
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'begin'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_failed_neo4j_rows(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'fail'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_prior_commit(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
) -> ForgetAuditRow | None:
    """Idempotency helper. Returns the most-recent 'commit' row that
    matches the (tenant, scope, episode_uuid) lookup, or None."""
    if scope == "episode":
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'episode' AND episode_uuid = $2
               AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params: tuple[Any, ...] = (tenant_id, episode_uuid)
    else:
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'tenant' AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params = (tenant_id,)
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, *params)
    return _row(row) if row else None


def _row(r: asyncpg.Record) -> ForgetAuditRow:
    return ForgetAuditRow(
        audit_id=r["audit_id"],
        tenant_id=r["tenant_id"],
        scope=r["scope"],
        episode_uuid=r["episode_uuid"],
        cascade=r["cascade"],
        dry_run=r["dry_run"],
        state=r["state"],
        reason=r["reason"],
        actor=r["actor"],
        receipt=json.loads(r["receipt"]) if r["receipt"] else None,
        error=json.loads(r["error"]) if r["error"] else None,
        cascade_uuids=json.loads(r["cascade_uuids"]) if r["cascade_uuids"] else None,
        bitemporal_snap=json.loads(r["bitemporal_snap"]) if r["bitemporal_snap"] else None,
        started_at=r["started_at"],
        finished_at=r["finished_at"],
    )
```

- [ ] **Step 4: Tests pass**

```bash
pytest tests/unit/test_forget_audit.py -v -m integration
```

Expected: 5 PASS. (Uses the existing `pg_pool` + `fresh_tenant` fixtures from `tests/integration/conftest.py`. If `pg_pool` is integration-scoped only, move this test file into `tests/integration/test_forget_audit.py` instead.)

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/forget_audit.py tests/unit/test_forget_audit.py
git commit -m "feat(storage): forget_audit async CRUD over gnokee_maintenance schema (ADR-0026)"
```

---

### Task 5: GraphitiStore tenant-group remove

**Files:**
- Modify: `src/gnokee/storage/graph.py` (extend existing class)
- Test: `tests/unit/test_graphiti_store.py` (extend) + `tests/integration/test_forget_pipeline.py` (covered by later integration suite)

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_graphiti_store.py`:

```python
@pytest.mark.asyncio
async def test_remove_tenant_group_emits_detach_delete_with_group_id(mocker) -> None:
    """remove_tenant_group must issue a single DETACH DELETE matching group_id."""
    from gnokee.storage.graph import GraphitiStore

    fake_driver = mocker.MagicMock()
    fake_session = mocker.MagicMock()
    fake_session.run = mocker.AsyncMock(return_value=mocker.MagicMock(consume=mocker.AsyncMock()))
    fake_driver.session = mocker.MagicMock(return_value=mocker.AsyncMock(__aenter__=mocker.AsyncMock(return_value=fake_session), __aexit__=mocker.AsyncMock(return_value=None)))

    store = GraphitiStore.__new__(GraphitiStore)  # bypass __init__
    store._driver = fake_driver  # type: ignore[attr-defined]

    counts = await store.remove_tenant_group(tenant_id="t-test")
    assert "Episodic" in counts or "deleted" in counts
    args, _ = fake_session.run.call_args
    cypher = args[0]
    assert "group_id" in cypher
    assert "DETACH DELETE" in cypher
```

(If existing `test_graphiti_store.py` does not use `mocker`/`pytest-mock`, adapt to its existing mock idiom — `unittest.mock.AsyncMock`.)

- [ ] **Step 2: Run — verify failure**

`pytest tests/unit/test_graphiti_store.py -v -k remove_tenant_group`

Expected: FAIL with `AttributeError: 'GraphitiStore' object has no attribute 'remove_tenant_group'`.

- [ ] **Step 3: Implement `GraphitiStore.remove_tenant_group`**

In `src/gnokee/storage/graph.py`, locate the existing `remove_lite_episode` method and insert AFTER it:

```python
    async def remove_tenant_group(self, *, tenant_id: str) -> dict[str, int]:
        """Hard-delete every node + edge keyed by `group_id = tenant_id`.

        Single statement: DETACH DELETE on the matched set. Returns a
        counts dict for the ForgetReceiptDetail bookkeeping.

        ADR-0023: `group_id` is the tenant retention key in Neo4j; no
        cross-tenant link can exist by construction. This call is safe.
        """
        async with self._driver.session() as session:  # type: ignore[attr-defined]
            ep_summary = await (
                await session.run(
                    "MATCH (ep:Episodic {group_id: $group_id}) "
                    "DETACH DELETE ep "
                    "RETURN count(ep) AS deleted_nodes",
                    group_id=tenant_id,
                )
            ).consume()
            ent_summary = await (
                await session.run(
                    "MATCH (e:Entity {group_id: $group_id}) "
                    "DETACH DELETE e "
                    "RETURN count(e) AS deleted_nodes",
                    group_id=tenant_id,
                )
            ).consume()
        return {
            "Episodic": int(ep_summary.counters.nodes_deleted),
            "Entity": int(ent_summary.counters.nodes_deleted),
            "edges_total": int(ep_summary.counters.relationships_deleted + ent_summary.counters.relationships_deleted),
        }

    async def remove_episodes_by_uuid(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
    ) -> dict[str, int]:
        """Hard-delete a SET of Episodics (cascade scope) keyed by uuid + group_id."""
        if not episode_uuids:
            return {"Episodic": 0, "Entity": 0, "edges_total": 0}
        async with self._driver.session() as session:  # type: ignore[attr-defined]
            ep_summary = await (
                await session.run(
                    "UNWIND $uuids AS uuid "
                    "MATCH (ep:Episodic {uuid: uuid, group_id: $group_id}) "
                    "DETACH DELETE ep "
                    "RETURN count(ep) AS deleted_nodes",
                    uuids=[str(u) for u in episode_uuids],
                    group_id=tenant_id,
                )
            ).consume()
            # Orphan-entity cleanup: entities with zero remaining MENTIONS.
            orphan_summary = await (
                await session.run(
                    "MATCH (e:Entity {group_id: $group_id}) "
                    "WHERE NOT EXISTS { MATCH (e)<-[:MENTIONS]-(:Episodic) } "
                    "DETACH DELETE e "
                    "RETURN count(e) AS deleted_nodes",
                    group_id=tenant_id,
                )
            ).consume()
        return {
            "Episodic": int(ep_summary.counters.nodes_deleted),
            "Entity": int(orphan_summary.counters.nodes_deleted),
            "edges_total": int(ep_summary.counters.relationships_deleted + orphan_summary.counters.relationships_deleted),
        }
```

Update the `graph.py` module-docstring `exports:` line to add `remove_tenant_group` / `remove_episodes_by_uuid` to the implicit class API hint.

- [ ] **Step 4: Tests pass**

```bash
pytest tests/unit/test_graphiti_store.py -v -k remove_tenant_group
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/graph.py tests/unit/test_graphiti_store.py
git commit -m "feat(graph): remove_tenant_group + remove_episodes_by_uuid (ADR-0026)"
```

---

### Task 6: DAG walker (recursive CTE)

**Files:**
- Create: `src/gnokee/forget.py` (initial version — DAG walker only; pipeline added in Task 7)
- Create: `tests/unit/test_forget_dag.py`

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_forget_dag.py`:

```python
"""tests/unit/test_forget_dag.py — supersession DAG recursive CTE."""

from __future__ import annotations

from uuid import UUID, uuid4

import pytest

from gnokee.forget import descendants_closure

pytestmark = [pytest.mark.integration]  # exercises real Postgres recursion


@pytest.mark.asyncio
async def test_no_descendants_returns_singleton(pg_pool, fresh_tenant: str, seed_episode) -> None:
    """An isolated episode has no descendants — closure = [self]."""
    ep = await seed_episode(fresh_tenant)
    closure = await descendants_closure(pg_pool, tenant_id=fresh_tenant, episode_uuid=ep)
    assert closure == [ep]


@pytest.mark.asyncio
async def test_linear_chain_returns_full_subtree(pg_pool, fresh_tenant: str, seed_episode, seed_correction) -> None:
    """A → B → C; closure(B) = [B, C]; closure(A) = [A, B, C]."""
    a = await seed_episode(fresh_tenant)
    b = await seed_correction(fresh_tenant, corrects=a)
    c = await seed_correction(fresh_tenant, corrects=b)

    cb = await descendants_closure(pg_pool, tenant_id=fresh_tenant, episode_uuid=b)
    assert set(cb) == {b, c}

    ca = await descendants_closure(pg_pool, tenant_id=fresh_tenant, episode_uuid=a)
    assert set(ca) == {a, b, c}


@pytest.mark.asyncio
async def test_branched_chain(pg_pool, fresh_tenant: str, seed_episode, seed_correction) -> None:
    """A → B; A → C; closure(A) = [A, B, C]."""
    a = await seed_episode(fresh_tenant)
    b = await seed_correction(fresh_tenant, corrects=a)
    c = await seed_correction(fresh_tenant, corrects=a)
    closure = await descendants_closure(pg_pool, tenant_id=fresh_tenant, episode_uuid=a)
    assert set(closure) == {a, b, c}


@pytest.mark.asyncio
async def test_tenant_isolation(pg_pool, seed_episode, seed_correction) -> None:
    """Descendants from another tenant are NOT in the closure."""
    a = await seed_episode("tenant_x")
    _b = await seed_correction("tenant_y", corrects=a)  # cross-tenant correction is impossible
                                                         # in practice; this asserts the guard
    closure = await descendants_closure(pg_pool, tenant_id="tenant_x", episode_uuid=a)
    assert closure == [a]
```

Helper fixtures `seed_episode` / `seed_correction` need to be added to `tests/integration/conftest.py` if not already present. Inline definition for the plan:

```python
# In tests/integration/conftest.py (extend):
@pytest_asyncio.fixture
async def seed_episode(pg_pool):
    async def _seed(tenant_id: str) -> UUID:
        ep_uuid = uuid4()
        async with pg_pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO episode_metadata (tenant_id, episode_uuid, asserted_at, valid_at) "
                "VALUES ($1, $2, now(), now())",
                tenant_id, ep_uuid,
            )
        return ep_uuid
    return _seed

@pytest_asyncio.fixture
async def seed_correction(pg_pool):
    async def _seed(tenant_id: str, *, corrects: UUID) -> UUID:
        ep_uuid = uuid4()
        async with pg_pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO episode_metadata (tenant_id, episode_uuid, asserted_at, valid_at, corrects_episode_uuid) "
                "VALUES ($1, $2, now(), now(), $3)",
                tenant_id, ep_uuid, corrects,
            )
            await conn.execute(
                "UPDATE episode_metadata SET superseded_by = $1 WHERE tenant_id = $2 AND episode_uuid = $3",
                ep_uuid, tenant_id, corrects,
            )
        return ep_uuid
    return _seed
```

Adjust column names to match the actual `episode_metadata` schema after re-reading `0001_episode_metadata.sql` + `0014_episode_corrects_reason.sql`. The exact column might be `corrects_episode_uuid` (per the spec) or differ slightly — read the migration and pin.

- [ ] **Step 2: Run — verify failure**

`pytest tests/unit/test_forget_dag.py -v -m integration`

Expected: ImportError from `gnokee.forget`.

- [ ] **Step 3: Implement DAG walker**

Create `src/gnokee/forget.py` (initial — DAG walker + scaffolding):

```python
"""src/gnokee/forget.py — gnokee.forget pipeline (ADR-0026, closes #130).

Hard-delete with verifiable audit. Two surfaces:

  - forget_episode(tenant_id, episode_uuid, *, cascade=False, reason, actor=None)
  - forget_tenant(tenant_id, *, dry_run=True, reason, actor=None)

Both return ForgetReceiptDetail. The MCP layer in src/gnokee/mcp.py
projects this down to the compact ForgetReceipt for the LLM-facing wire.

exports: descendants_closure | ForgetPipeline | forget_episode | forget_tenant
used_by: src/gnokee/mcp.py | src/gnokee/maintenance.py
rules:   tenant_id on every call; serializable Postgres tx for the
         begin+sweep+commit triple; Neo4j sweep is a separate phase;
         tz-aware UTC throughout
agent:   claude-opus-4-7 | 2026-05-16 | issue #130 ADR-0026 impl
"""

from __future__ import annotations

from uuid import UUID

import asyncpg


_DESCENDANTS_CTE_SQL = """
WITH RECURSIVE chain(uuid) AS (
    SELECT $2::uuid
  UNION
    SELECT em.episode_uuid
      FROM episode_metadata em
      JOIN chain c ON em.corrects_episode_uuid = c.uuid
     WHERE em.tenant_id = $1
)
SELECT uuid FROM chain;
"""


async def descendants_closure(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    episode_uuid: UUID,
) -> list[UUID]:
    """Return the transitive descendant set INCLUDING the input UUID.

    Pure topology — no temporal predicate (ADR-0026 §6.1). Walks
    ``corrects_episode_uuid → ancestor`` in REVERSE: descendants are
    rows whose corrects_episode_uuid points INTO the chain.

    Caller is responsible for running this inside the serializable
    Postgres transaction that will execute the DELETE — otherwise a
    concurrent ingest may add a new descendant after this returns.
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(_DESCENDANTS_CTE_SQL, tenant_id, episode_uuid)
    return [r["uuid"] for r in rows]
```

- [ ] **Step 4: Tests pass**

```bash
pytest tests/unit/test_forget_dag.py -v -m integration
```

Expected: 4 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/forget.py tests/unit/test_forget_dag.py tests/integration/conftest.py
git commit -m "feat(forget): descendants_closure recursive CTE walker (ADR-0026 §6.1)"
```

---

### Task 7: ForgetPipeline — episode tool

**Files:**
- Modify: `src/gnokee/forget.py` (add `ForgetPipeline` + `forget_episode`)
- Create: `tests/integration/test_forget_pipeline.py` (start with episode cases — cases 1–6 from spec §11.2)

- [ ] **Step 1: Write the failing tests**

Create `tests/integration/test_forget_pipeline.py`:

```python
"""tests/integration/test_forget_pipeline.py — ADR-0026 forget pipeline E2E.

Real Postgres + Neo4j via the session-scoped conftest. Covers spec §11.2.
"""

from __future__ import annotations

from uuid import UUID

import pytest

from gnokee.bootstrap import App
from gnokee.errors import CannotForgetChainNode
from gnokee.forget import forget_episode, forget_tenant
from gnokee.models import ForgetReceiptDetail

pytestmark = [pytest.mark.integration]


@pytest.mark.asyncio
async def test_forget_episode_no_chain(app: App, fresh_tenant: str, seed_episode) -> None:
    ep = await seed_episode(fresh_tenant)
    receipt: ForgetReceiptDetail = await forget_episode(
        app,
        tenant_id=fresh_tenant,
        episode_uuid=ep,
        cascade=False,
        reason="unit-test",
    )
    assert receipt.affected_episode_count == 1
    assert receipt.cascade is False
    assert receipt.partial is False
    assert receipt.postgres_rows_deleted["episode_metadata"] == 1
    # Verify both stores empty
    async with app.pg_pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT 1 FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant, ep,
        )
        assert row is None


@pytest.mark.asyncio
async def test_forget_episode_refuses_chain_node(app: App, fresh_tenant: str, seed_episode, seed_correction) -> None:
    a = await seed_episode(fresh_tenant)
    b = await seed_correction(fresh_tenant, corrects=a)
    _c = await seed_correction(fresh_tenant, corrects=b)
    with pytest.raises(CannotForgetChainNode) as exc:
        await forget_episode(
            app, tenant_id=fresh_tenant, episode_uuid=b,
            cascade=False, reason="unit-test",
        )
    assert exc.value.descendant_count == 1  # only c is a descendant of b


@pytest.mark.asyncio
async def test_forget_episode_cascade_descendants(app: App, fresh_tenant: str, seed_episode, seed_correction) -> None:
    a = await seed_episode(fresh_tenant)
    b = await seed_correction(fresh_tenant, corrects=a)
    c = await seed_correction(fresh_tenant, corrects=b)
    receipt = await forget_episode(
        app, tenant_id=fresh_tenant, episode_uuid=b,
        cascade=True, reason="unit-test",
    )
    assert receipt.affected_episode_count == 2  # b + c
    assert set(receipt.cascaded_episode_uuids) == {b, c}
    # A stays live; superseded_by cleared
    async with app.pg_pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT superseded_by FROM episode_metadata WHERE tenant_id=$1 AND episode_uuid=$2",
            fresh_tenant, a,
        )
        assert row is not None
        assert row["superseded_by"] is None


@pytest.mark.asyncio
async def test_forget_episode_idempotent_replay(app: App, fresh_tenant: str, seed_episode) -> None:
    ep = await seed_episode(fresh_tenant)
    first = await forget_episode(
        app, tenant_id=fresh_tenant, episode_uuid=ep,
        cascade=False, reason="unit-test",
    )
    second = await forget_episode(
        app, tenant_id=fresh_tenant, episode_uuid=ep,
        cascade=False, reason="unit-test",
    )
    assert second.replayed is True
    assert second.audit_id == first.audit_id


@pytest.mark.asyncio
async def test_forget_episode_encrypted_body_surfaces_key_ids(app: App, fresh_tenant: str, seed_encrypted_episode) -> None:
    ep, key_id = await seed_encrypted_episode(fresh_tenant)
    receipt = await forget_episode(
        app, tenant_id=fresh_tenant, episode_uuid=ep,
        cascade=False, reason="unit-test",
    )
    assert key_id in receipt.affected_key_ids


@pytest.mark.asyncio
async def test_forget_episode_bitemporal_snap_captured(app: App, fresh_tenant: str, seed_episode) -> None:
    ep = await seed_episode(fresh_tenant)
    receipt = await forget_episode(
        app, tenant_id=fresh_tenant, episode_uuid=ep,
        cascade=False, reason="unit-test",
    )
    assert len(receipt.bitemporal_snap) == 1
    snap = receipt.bitemporal_snap[0]
    assert "episode_uuid" in snap
    assert "asserted_at" in snap
    assert "valid_at" in snap
```

Add the `seed_encrypted_episode` fixture to `tests/integration/conftest.py`:

```python
@pytest_asyncio.fixture
async def seed_encrypted_episode(pg_pool):
    async def _seed(tenant_id: str) -> tuple[UUID, str]:
        ep_uuid = uuid4()
        key_id = f"key-{ep_uuid}"
        async with pg_pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO episode_metadata (tenant_id, episode_uuid, asserted_at, valid_at) "
                "VALUES ($1, $2, now(), now())",
                tenant_id, ep_uuid,
            )
            await conn.execute(
                "INSERT INTO episode_body_encrypted (tenant_id, episode_uuid, ciphertext, nonce, key_id) "
                "VALUES ($1, $2, $3, $4, $5)",
                tenant_id, ep_uuid, b"\x00", b"\x00", key_id,
            )
        return ep_uuid, key_id
    return _seed
```

- [ ] **Step 2: Run — verify failures**

```bash
pytest tests/integration/test_forget_pipeline.py -v -m integration -k "test_forget_episode"
```

Expected: all FAIL with `ImportError` from `gnokee.forget.forget_episode`.

- [ ] **Step 3: Implement `ForgetPipeline` + `forget_episode`**

Append to `src/gnokee/forget.py`:

```python
import asyncio
import json
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

import asyncpg

from gnokee.bootstrap import App
from gnokee.errors import CannotForgetChainNode, ForgetContention, ForgetNeo4jPartial
from gnokee.models import ForgetReceiptDetail
from gnokee.storage import forget_audit


_SERIALIZABLE_RETRIES = 3
_SERIALIZATION_FAILURE_SQLSTATE = "40001"


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def forget_episode(
    app: App,
    *,
    tenant_id: str,
    episode_uuid: UUID,
    cascade: bool,
    reason: str,
    actor: str | None = None,
) -> ForgetReceiptDetail:
    """Hard-delete a single episode (and optionally its supersession
    descendants) across pgvector + Graphiti/Neo4j with verifiable audit.

    See ADR-0026 / spec §3.1 + §5 for semantics.
    """
    # 1. Idempotency check — prior commit returns its receipt
    prior = await forget_audit.find_prior_commit(
        app.pg_pool, tenant_id=tenant_id, scope="episode", episode_uuid=episode_uuid,
    )
    if prior is not None and prior.receipt is not None:
        return _detail_from_audit(prior, replayed=True)

    # 2. Postgres txn with SERIALIZABLE retry
    last_exc: BaseException | None = None
    for _attempt in range(_SERIALIZABLE_RETRIES):
        try:
            audit_id, detail, cascade_uuids = await _episode_postgres_phase(
                app, tenant_id=tenant_id, episode_uuid=episode_uuid,
                cascade=cascade, reason=reason, actor=actor,
            )
            break
        except asyncpg.exceptions.SerializationError as exc:
            last_exc = exc
            await asyncio.sleep(0.05 * (_attempt + 1))
            continue
    else:
        raise ForgetContention("forget_episode serializable retry budget exhausted") from last_exc

    # 3. Neo4j phase — separate
    try:
        n4j_counts = await app.graph.remove_episodes_by_uuid(
            tenant_id=tenant_id, episode_uuids=cascade_uuids,
        )
    except Exception as exc:
        await forget_audit.mark_fail(
            app.pg_pool,
            audit_id=audit_id,
            error={
                "kind": "neo4j_partial",
                "linked_audit_id": str(audit_id),
                "message": str(exc),
            },
        )
        raise ForgetNeo4jPartial(audit_id=str(audit_id), cause=exc) from exc

    detail = detail.model_copy(
        update={
            "neo4j_nodes_deleted": {k: v for k, v in n4j_counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": n4j_counts.get("edges_total", 0)},
            "summary": _summary_episode(detail),
        },
    )
    await forget_audit.mark_commit(
        app.pg_pool, audit_id=audit_id, receipt=detail.model_dump(mode="json"),
    )
    return detail


async def _episode_postgres_phase(
    app: App,
    *,
    tenant_id: str,
    episode_uuid: UUID,
    cascade: bool,
    reason: str,
    actor: str | None,
) -> tuple[UUID, ForgetReceiptDetail, list[UUID]]:
    """Stages 2-6 inside one SERIALIZABLE Postgres tx.

    Returns (audit_id, detail-without-neo4j-fields-yet, cascade_uuids).
    """
    async with app.pg_pool.acquire() as conn:
        await conn.execute("SET LOCAL TRANSACTION ISOLATION LEVEL SERIALIZABLE")
        async with conn.transaction():
            await conn.execute("SET LOCAL app.current_tenant = $1", tenant_id)

            # 2. DAG walk inside tx
            descendants_rows = await conn.fetch(_DESCENDANTS_CTE_SQL, tenant_id, episode_uuid)
            cascade_set: list[UUID] = [r["uuid"] for r in descendants_rows]
            non_target = [u for u in cascade_set if u != episode_uuid]
            if non_target and not cascade:
                deepest = non_target[-1]
                raise CannotForgetChainNode(
                    descendant_count=len(non_target),
                    deepest_descendant_uuid=str(deepest),
                )
            scope_set: list[UUID] = cascade_set if cascade else [episode_uuid]

            # 3. Pre-DELETE captures (key_ids + bitemporal snap) under SELECT FOR UPDATE
            key_ids_rows = await conn.fetch(
                "SELECT key_id FROM episode_body_encrypted "
                "WHERE tenant_id = $1 AND episode_uuid = ANY($2::uuid[]) FOR SHARE",
                tenant_id, [str(u) for u in scope_set],
            )
            key_ids = [r["key_id"] for r in key_ids_rows]
            snap_rows = await conn.fetch(
                "SELECT episode_uuid, asserted_at, valid_at, valid_until "
                "  FROM episode_metadata "
                " WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]) "
                "FOR UPDATE",
                tenant_id, [str(u) for u in scope_set],
            )
            snap = [
                {
                    "episode_uuid": str(r["episode_uuid"]),
                    "asserted_at": r["asserted_at"].isoformat() if r["asserted_at"] else None,
                    "valid_at": r["valid_at"].isoformat() if r["valid_at"] else None,
                    "valid_until": r["valid_until"].isoformat() if r["valid_until"] else None,
                }
                for r in snap_rows
            ]

            # 4. Audit begin row
            audit_id = await _insert_begin_in_conn(
                conn,
                tenant_id=tenant_id, scope="episode", episode_uuid=episode_uuid,
                cascade=cascade, dry_run=False, reason=reason, actor=actor,
                cascade_uuids=[str(u) for u in scope_set],
                bitemporal_snap=snap,
            )

            # 5. Ancestor pointer cleanup BEFORE delete (spec §6.2)
            await conn.execute(
                "UPDATE episode_metadata SET superseded_by = NULL "
                " WHERE tenant_id=$1 AND superseded_by = ANY($2::uuid[])",
                tenant_id, [str(u) for u in scope_set],
            )

            # 6. Postgres sweep
            await conn.execute(
                "DELETE FROM fact_contradiction "
                " WHERE tenant_id=$1 AND (fact_uuid_a = ANY($2::uuid[]) OR fact_uuid_b = ANY($2::uuid[]))",
                tenant_id, [str(u) for u in scope_set],
            )
            await conn.execute(
                "DELETE FROM ingest_journal "
                " WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])",
                tenant_id, [str(u) for u in scope_set],
            )
            del_metadata = await conn.execute(
                "DELETE FROM episode_metadata "
                " WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])",
                tenant_id, [str(u) for u in scope_set],
            )

    detail = ForgetReceiptDetail(
        audit_id=audit_id,
        tenant_id=tenant_id,
        scope="episode",
        episode_uuid=episode_uuid,
        cascade=cascade,
        dry_run=False,
        summary="",  # filled after Neo4j
        affected_episode_count=len(scope_set),
        deepest_episode_uuid=(scope_set[-1] if cascade and len(scope_set) > 1 else None),
        affected_key_ids=key_ids,
        replayed=False,
        started_at=_now(),
        finished_at=_now(),
        actor=actor,
        reason=reason,
        postgres_rows_deleted={
            "episode_metadata": int(del_metadata.split()[-1]),
        },
        cascaded_episode_uuids=scope_set if cascade else [],
        partial=False,
        bitemporal_snap=snap,
    )
    return audit_id, detail, scope_set


async def _insert_begin_in_conn(
    conn: asyncpg.Connection,
    *,
    tenant_id: str,
    scope: str,
    episode_uuid: UUID | None,
    cascade: bool,
    dry_run: bool,
    reason: str,
    actor: str | None,
    cascade_uuids: list[str] | None,
    bitemporal_snap: list[dict[str, Any]] | None,
) -> UUID:
    """In-transaction insert; mirror of storage.forget_audit.insert_begin
    that does NOT acquire a fresh connection."""
    row = await conn.fetchrow(
        """
        INSERT INTO gnokee_maintenance.forget_audit
            (tenant_id, scope, episode_uuid, cascade, dry_run, state,
             reason, actor, cascade_uuids, bitemporal_snap)
        VALUES ($1, $2, $3, $4, $5, 'begin', $6, $7, $8, $9)
        RETURNING audit_id;
        """,
        tenant_id, scope, episode_uuid, cascade, dry_run, reason, actor,
        json.dumps(cascade_uuids) if cascade_uuids is not None else None,
        json.dumps(bitemporal_snap) if bitemporal_snap is not None else None,
    )
    assert row is not None
    return row["audit_id"]


def _summary_episode(detail: ForgetReceiptDetail) -> str:
    pg_rows = sum(detail.postgres_rows_deleted.values())
    n_nodes = sum(detail.neo4j_nodes_deleted.values())
    n_edges = sum(detail.neo4j_edges_deleted.values())
    return f"Deleted {detail.affected_episode_count} episode(s): {pg_rows} Postgres rows, {n_nodes} Neo4j nodes, {n_edges} Neo4j edges."


def _detail_from_audit(row, *, replayed: bool) -> ForgetReceiptDetail:
    receipt = row.receipt or {}
    return ForgetReceiptDetail(**{**receipt, "replayed": replayed})
```

- [ ] **Step 4: Tests pass**

```bash
pytest tests/integration/test_forget_pipeline.py -v -m integration -k "test_forget_episode"
```

Expected: 6 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/forget.py tests/integration/test_forget_pipeline.py tests/integration/conftest.py
git commit -m "feat(forget): forget_episode pipeline with SERIALIZABLE tx + DAG cascade (ADR-0026)"
```

---

### Task 8: ForgetPipeline — tenant tool with dry_run

**Files:**
- Modify: `src/gnokee/forget.py` (add `forget_tenant`)
- Modify: `tests/integration/test_forget_pipeline.py` (cases 7–9, 12–14 from spec §11.2)

- [ ] **Step 1: Write the failing tests**

Append to `tests/integration/test_forget_pipeline.py`:

```python
@pytest.mark.asyncio
async def test_forget_tenant_dry_run(app: App, fresh_tenant: str, seed_episode) -> None:
    e1 = await seed_episode(fresh_tenant)
    e2 = await seed_episode(fresh_tenant)
    receipt = await forget_tenant(
        app, tenant_id=fresh_tenant, dry_run=True, reason="unit-test",
    )
    assert receipt.dry_run is True
    assert receipt.affected_episode_count == 2
    # Verify NOTHING deleted
    async with app.pg_pool.acquire() as conn:
        n = await conn.fetchval(
            "SELECT count(*) FROM episode_metadata WHERE tenant_id = $1", fresh_tenant,
        )
        assert n == 2
    # No audit-commit row should exist (dry_run is observation-only)
    rows = await app.pg_pool.fetch(
        "SELECT audit_id FROM gnokee_maintenance.forget_audit "
        " WHERE tenant_id=$1 AND state='commit'",
        fresh_tenant,
    )
    assert len(rows) == 0


@pytest.mark.asyncio
async def test_forget_tenant_full_sweep(app: App, fresh_tenant: str, seed_episode) -> None:
    for _ in range(5):
        await seed_episode(fresh_tenant)
    receipt = await forget_tenant(
        app, tenant_id=fresh_tenant, dry_run=False, reason="unit-test",
    )
    assert receipt.dry_run is False
    assert receipt.affected_episode_count == 5
    async with app.pg_pool.acquire() as conn:
        for tbl in ("episode_metadata", "content_embedding", "content_text",
                    "episode_body_encrypted", "lab_record", "med_record",
                    "fact_contradiction", "ingest_journal"):
            n = await conn.fetchval(f"SELECT count(*) FROM {tbl} WHERE tenant_id = $1", fresh_tenant)
            assert n == 0, f"{tbl} still has rows for {fresh_tenant}"


@pytest.mark.asyncio
async def test_forget_tenant_audit_survives(app: App, fresh_tenant: str, seed_episode) -> None:
    await seed_episode(fresh_tenant)
    receipt = await forget_tenant(
        app, tenant_id=fresh_tenant, dry_run=False, reason="unit-test",
    )
    async with app.pg_pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT audit_id, state, reason FROM gnokee_maintenance.forget_audit "
            " WHERE audit_id = $1",
            receipt.audit_id,
        )
        assert row is not None
        assert row["state"] == "commit"
        assert row["reason"] == "unit-test"


@pytest.mark.asyncio
async def test_forget_tenant_sweeps_ingest_journal(app: App, fresh_tenant: str, seed_episode, seed_journal_row) -> None:
    """Direct verification of #130 fix."""
    ep = await seed_episode(fresh_tenant)
    await seed_journal_row(fresh_tenant, ep)
    await forget_tenant(app, tenant_id=fresh_tenant, dry_run=False, reason="unit-test")
    async with app.pg_pool.acquire() as conn:
        await conn.execute("SET app.current_tenant = $1", fresh_tenant)
        n = await conn.fetchval(
            "SELECT count(*) FROM ingest_journal WHERE tenant_id = $1", fresh_tenant,
        )
        assert n == 0


@pytest.mark.asyncio
async def test_forget_tenant_sweeps_fact_contradiction(app: App, fresh_tenant: str, seed_contradiction) -> None:
    await seed_contradiction(fresh_tenant)
    await forget_tenant(app, tenant_id=fresh_tenant, dry_run=False, reason="unit-test")
    async with app.pg_pool.acquire() as conn:
        n = await conn.fetchval(
            "SELECT count(*) FROM fact_contradiction WHERE tenant_id = $1", fresh_tenant,
        )
        assert n == 0
```

Add the missing fixtures to `tests/integration/conftest.py`:

```python
@pytest_asyncio.fixture
async def seed_journal_row(pg_pool):
    async def _seed(tenant_id: str, episode_uuid: UUID) -> None:
        async with pg_pool.acquire() as conn:
            await conn.execute("SET LOCAL app.current_tenant = $1", tenant_id)
            await conn.execute(
                "INSERT INTO ingest_journal "
                "  (tenant_id, our_id, episode_uuid, payload_hash, state, stage_4_time) "
                "VALUES ($1, NULL, $2, $3, 'commit', now())",
                tenant_id, episode_uuid, "0" * 64,
            )
    return _seed


@pytest_asyncio.fixture
async def seed_contradiction(pg_pool):
    async def _seed(tenant_id: str) -> None:
        async with pg_pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO fact_contradiction "
                "  (tenant_id, fact_uuid_a, fact_uuid_b, verdict, created_at) "
                "VALUES ($1, gen_random_uuid(), gen_random_uuid(), 'contradiction', now())",
                tenant_id,
            )
    return _seed
```

(Adjust column names in fixtures to match actual schemas of `ingest_journal` from migration 0015 and `fact_contradiction` from migration 0003 — read both files and pin.)

- [ ] **Step 2: Run — verify failures**

```bash
pytest tests/integration/test_forget_pipeline.py -v -m integration -k "test_forget_tenant"
```

Expected: failures with `ImportError` from `gnokee.forget.forget_tenant`.

- [ ] **Step 3: Implement `forget_tenant`**

Append to `src/gnokee/forget.py`:

```python
async def forget_tenant(
    app: App,
    *,
    tenant_id: str,
    dry_run: bool,
    reason: str,
    actor: str | None = None,
) -> ForgetReceiptDetail:
    """Hard-delete the entire tenant. `dry_run=True` (default) returns a
    planned ForgetReceiptDetail with no writes — caller must invoke a
    second time with dry_run=False to actually destroy.

    Closes #130: explicit DELETE on ingest_journal alongside the cascade
    via episode_metadata's FK chain.
    """
    if dry_run:
        return await _forget_tenant_dry_run(app, tenant_id=tenant_id, reason=reason, actor=actor)

    prior = await forget_audit.find_prior_commit(
        app.pg_pool, tenant_id=tenant_id, scope="tenant", episode_uuid=None,
    )
    if prior is not None and prior.receipt is not None:
        return _detail_from_audit(prior, replayed=True)

    last_exc: BaseException | None = None
    for _attempt in range(_SERIALIZABLE_RETRIES):
        try:
            audit_id, detail = await _tenant_postgres_phase(
                app, tenant_id=tenant_id, reason=reason, actor=actor,
            )
            break
        except asyncpg.exceptions.SerializationError as exc:
            last_exc = exc
            await asyncio.sleep(0.05 * (_attempt + 1))
            continue
    else:
        raise ForgetContention("forget_tenant serializable retry budget exhausted") from last_exc

    try:
        n4j_counts = await app.graph.remove_tenant_group(tenant_id=tenant_id)
    except Exception as exc:
        await forget_audit.mark_fail(
            app.pg_pool, audit_id=audit_id,
            error={"kind": "neo4j_partial", "linked_audit_id": str(audit_id), "message": str(exc)},
        )
        raise ForgetNeo4jPartial(audit_id=str(audit_id), cause=exc) from exc

    detail = detail.model_copy(
        update={
            "neo4j_nodes_deleted": {k: v for k, v in n4j_counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": n4j_counts.get("edges_total", 0)},
            "summary": _summary_tenant(detail),
        },
    )
    await forget_audit.mark_commit(
        app.pg_pool, audit_id=audit_id, receipt=detail.model_dump(mode="json"),
    )
    return detail


async def _forget_tenant_dry_run(
    app: App, *, tenant_id: str, reason: str, actor: str | None,
) -> ForgetReceiptDetail:
    """Plan-only: SELECT counts; NO writes; NO audit row."""
    from uuid import uuid4 as _uuid4
    async with app.pg_pool.acquire() as conn:
        n_episodes = await conn.fetchval(
            "SELECT count(*) FROM episode_metadata WHERE tenant_id = $1", tenant_id,
        ) or 0
        key_ids = [
            r["key_id"]
            for r in await conn.fetch(
                "SELECT DISTINCT key_id FROM episode_body_encrypted WHERE tenant_id = $1",
                tenant_id,
            )
        ]
    return ForgetReceiptDetail(
        audit_id=_uuid4(),  # ephemeral — no row persisted
        tenant_id=tenant_id,
        scope="tenant",
        episode_uuid=None,
        cascade=False,
        dry_run=True,
        summary=f"PLANNED (dry_run): tenant '{tenant_id}' — {n_episodes} episodes, {len(key_ids)} encrypted DEKs.",
        affected_episode_count=n_episodes,
        deepest_episode_uuid=None,
        affected_key_ids=key_ids,
        replayed=False,
        started_at=_now(),
        finished_at=_now(),
        actor=actor,
        reason=reason,
        postgres_rows_deleted={},
        cascaded_episode_uuids=[],
        partial=False,
        bitemporal_snap=[],
    )


async def _tenant_postgres_phase(
    app: App, *, tenant_id: str, reason: str, actor: str | None,
) -> tuple[UUID, ForgetReceiptDetail]:
    async with app.pg_pool.acquire() as conn:
        await conn.execute("SET LOCAL TRANSACTION ISOLATION LEVEL SERIALIZABLE")
        async with conn.transaction():
            await conn.execute("SET LOCAL app.current_tenant = $1", tenant_id)

            key_ids = [
                r["key_id"]
                for r in await conn.fetch(
                    "SELECT DISTINCT key_id FROM episode_body_encrypted WHERE tenant_id = $1",
                    tenant_id,
                )
            ]
            snap_rows = await conn.fetch(
                "SELECT episode_uuid, asserted_at, valid_at, valid_until "
                "  FROM episode_metadata WHERE tenant_id = $1",
                tenant_id,
            )
            snap = [
                {
                    "episode_uuid": str(r["episode_uuid"]),
                    "asserted_at": r["asserted_at"].isoformat() if r["asserted_at"] else None,
                    "valid_at": r["valid_at"].isoformat() if r["valid_at"] else None,
                    "valid_until": r["valid_until"].isoformat() if r["valid_until"] else None,
                }
                for r in snap_rows
            ]
            n_episodes = len(snap_rows)

            audit_id = await _insert_begin_in_conn(
                conn, tenant_id=tenant_id, scope="tenant", episode_uuid=None,
                cascade=False, dry_run=False, reason=reason, actor=actor,
                cascade_uuids=None, bitemporal_snap=snap,
            )

            d1 = await conn.execute("DELETE FROM fact_contradiction WHERE tenant_id = $1", tenant_id)
            d2 = await conn.execute("DELETE FROM ingest_journal     WHERE tenant_id = $1", tenant_id)
            d3 = await conn.execute("DELETE FROM episode_metadata   WHERE tenant_id = $1", tenant_id)

    detail = ForgetReceiptDetail(
        audit_id=audit_id,
        tenant_id=tenant_id,
        scope="tenant",
        episode_uuid=None,
        cascade=False,
        dry_run=False,
        summary="",
        affected_episode_count=n_episodes,
        deepest_episode_uuid=None,
        affected_key_ids=key_ids,
        replayed=False,
        started_at=_now(),
        finished_at=_now(),
        actor=actor,
        reason=reason,
        postgres_rows_deleted={
            "fact_contradiction": int(d1.split()[-1]),
            "ingest_journal":     int(d2.split()[-1]),
            "episode_metadata":   int(d3.split()[-1]),
        },
        cascaded_episode_uuids=[],
        partial=False,
        bitemporal_snap=snap,
    )
    return audit_id, detail


def _summary_tenant(detail: ForgetReceiptDetail) -> str:
    pg_rows = sum(detail.postgres_rows_deleted.values())
    n_nodes = sum(detail.neo4j_nodes_deleted.values())
    n_edges = sum(detail.neo4j_edges_deleted.values())
    return f"Deleted tenant '{detail.tenant_id}': {detail.affected_episode_count} episodes, {pg_rows} Postgres rows, {n_nodes} Neo4j nodes, {n_edges} Neo4j edges."
```

- [ ] **Step 4: Tests pass**

```bash
pytest tests/integration/test_forget_pipeline.py -v -m integration -k "test_forget_tenant"
```

Expected: 5 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/forget.py tests/integration/test_forget_pipeline.py tests/integration/conftest.py
git commit -m "feat(forget): forget_tenant pipeline with dry_run + #130 ingest_journal sweep"
```

---

### Task 9: `resume_forget` maintenance primitive

**Files:**
- Modify: `src/gnokee/maintenance.py` (add `resume_forget` alongside `resume_ingest`)
- Create: `tests/unit/test_resume_forget.py`
- Modify: `tests/integration/test_forget_pipeline.py` (add the Neo4j-crash case)

- [ ] **Step 1: Write failing unit tests**

Create `tests/unit/test_resume_forget.py`:

```python
"""tests/unit/test_resume_forget.py — mocked replay correctness."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4

import pytest

from gnokee.maintenance import resume_forget
from gnokee.storage.forget_audit import ForgetAuditRow


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _fail_row(audit_id: UUID, scope: str = "tenant") -> ForgetAuditRow:
    return ForgetAuditRow(
        audit_id=audit_id, tenant_id="t1", scope=scope, episode_uuid=None,
        cascade=False, dry_run=False, state="fail", reason="r", actor=None,
        receipt={"affected_episode_count": 0, "cascaded_episode_uuids": []},
        error={"kind": "neo4j_partial", "linked_audit_id": str(audit_id)},
        cascade_uuids=None, bitemporal_snap=[],
        started_at=_now(), finished_at=_now(),
    )


@pytest.mark.asyncio
async def test_resume_forget_returns_empty_when_no_fail_rows(monkeypatch) -> None:
    fake_app = MagicMock()
    monkeypatch.setattr(
        "gnokee.maintenance.forget_audit.find_failed_neo4j_rows",
        AsyncMock(return_value=[]),
    )
    monkeypatch.setattr(
        "gnokee.maintenance.forget_audit.find_resumable",
        AsyncMock(return_value=[]),
    )
    result = await resume_forget(fake_app, tenant_id="t1")
    assert result == []


@pytest.mark.asyncio
async def test_resume_forget_retries_neo4j_for_fail_rows(monkeypatch) -> None:
    fake_app = MagicMock()
    fake_app.graph.remove_tenant_group = AsyncMock(
        return_value={"Episodic": 3, "Entity": 1, "edges_total": 2}
    )
    fail = _fail_row(uuid4())
    monkeypatch.setattr(
        "gnokee.maintenance.forget_audit.find_failed_neo4j_rows",
        AsyncMock(return_value=[fail]),
    )
    monkeypatch.setattr(
        "gnokee.maintenance.forget_audit.find_resumable",
        AsyncMock(return_value=[]),
    )
    monkeypatch.setattr(
        "gnokee.maintenance.forget_audit.mark_commit",
        AsyncMock(),
    )
    result = await resume_forget(fake_app, tenant_id="t1")
    assert len(result) == 1
    fake_app.graph.remove_tenant_group.assert_awaited_once_with(tenant_id="t1")
```

- [ ] **Step 2: Add integration test for end-to-end crash recovery**

Append to `tests/integration/test_forget_pipeline.py`:

```python
@pytest.mark.asyncio
async def test_resume_forget_after_neo4j_crash(app: App, fresh_tenant: str, seed_episode, monkeypatch) -> None:
    """Inject Neo4j failure; verify fail-row + retry-success path."""
    for _ in range(3):
        await seed_episode(fresh_tenant)

    # Monkeypatch remove_tenant_group to fail once
    real_remove = app.graph.remove_tenant_group
    calls = {"n": 0}

    async def fail_first(*args, **kwargs):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("simulated neo4j outage")
        return await real_remove(*args, **kwargs)

    monkeypatch.setattr(app.graph, "remove_tenant_group", fail_first)

    from gnokee.errors import ForgetNeo4jPartial
    with pytest.raises(ForgetNeo4jPartial):
        await forget_tenant(app, tenant_id=fresh_tenant, dry_run=False, reason="crash-test")

    # Verify 'fail' row exists, Postgres data is gone
    async with app.pg_pool.acquire() as conn:
        n = await conn.fetchval(
            "SELECT count(*) FROM episode_metadata WHERE tenant_id = $1", fresh_tenant,
        )
        assert n == 0
        fail_count = await conn.fetchval(
            "SELECT count(*) FROM gnokee_maintenance.forget_audit "
            " WHERE tenant_id=$1 AND state='fail'", fresh_tenant,
        )
        assert fail_count == 1

    # Now resume
    from gnokee.maintenance import resume_forget
    receipts = await resume_forget(app, tenant_id=fresh_tenant)
    assert len(receipts) == 1
    async with app.pg_pool.acquire() as conn:
        committed = await conn.fetchval(
            "SELECT count(*) FROM gnokee_maintenance.forget_audit "
            " WHERE tenant_id=$1 AND state='commit'", fresh_tenant,
        )
        assert committed >= 1
```

- [ ] **Step 3: Run — verify failures**

```bash
pytest tests/unit/test_resume_forget.py -v
pytest tests/integration/test_forget_pipeline.py -v -m integration -k resume
```

Expected: `ImportError` from `gnokee.maintenance.resume_forget`.

- [ ] **Step 4: Implement `resume_forget`**

Append to `src/gnokee/maintenance.py` (after the existing `resume_ingest` function):

```python
async def resume_forget(
    app: "App",
    *,
    tenant_id: str,
    audit_id: UUID | None = None,
) -> list["ForgetReceiptDetail"]:
    """Replay 'fail' rows (Neo4j retry) and any orphaned 'begin' rows.

    Mirror of resume_ingest. Opt-in: gnokee never auto-replays.

    'begin' rows are an impossible-survival shape if Postgres tx
    rolled back atomically with the audit-begin INSERT — they exist
    only if a process was killed before COMMIT. resume_forget skips
    them (no work to retry — data is intact) and logs a warning.

    'fail' rows mean Postgres committed but Neo4j sweep failed; this
    function retries the Neo4j sweep using the saved cascade_uuids
    (episode scope) or remove_tenant_group (tenant scope), then
    marks the row 'commit'.
    """
    from gnokee.bootstrap import App as _App
    from gnokee.forget import _detail_from_audit, _summary_episode, _summary_tenant  # noqa: F401
    from gnokee.models import ForgetReceiptDetail
    from gnokee.storage import forget_audit

    failed = await forget_audit.find_failed_neo4j_rows(app.pg_pool, tenant_id=tenant_id)
    pending = await forget_audit.find_resumable(app.pg_pool, tenant_id=tenant_id)

    if pending:
        logger.warning(
            "resume_forget: %d 'begin' rows for tenant=%s skipped — "
            "these indicate a process kill before Postgres commit; "
            "data is intact, caller must re-issue the forget call",
            len(pending), tenant_id,
        )

    if audit_id is not None:
        failed = [r for r in failed if r.audit_id == audit_id]

    receipts: list[ForgetReceiptDetail] = []
    for row in failed:
        if row.scope == "tenant":
            counts = await app.graph.remove_tenant_group(tenant_id=tenant_id)
        else:
            uuids = [UUID(s) for s in (row.cascade_uuids or [])]
            counts = await app.graph.remove_episodes_by_uuid(
                tenant_id=tenant_id, episode_uuids=uuids,
            )
        existing = row.receipt or {}
        merged = {
            **existing,
            "neo4j_nodes_deleted": {k: v for k, v in counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": counts.get("edges_total", 0)},
            "partial": False,
        }
        await forget_audit.mark_commit(app.pg_pool, audit_id=row.audit_id, receipt=merged)
        receipts.append(ForgetReceiptDetail(**merged, replayed=False))

    return receipts
```

Add the necessary import at the top of `maintenance.py` if not already present: `from uuid import UUID` and `from typing import TYPE_CHECKING` (App used only for typing).

- [ ] **Step 5: Tests pass**

```bash
pytest tests/unit/test_resume_forget.py -v
pytest tests/integration/test_forget_pipeline.py -v -m integration -k resume
```

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/gnokee/maintenance.py tests/unit/test_resume_forget.py tests/integration/test_forget_pipeline.py
git commit -m "feat(maintenance): resume_forget Neo4j-retry primitive (ADR-0026)"
```

---

### Task 10: MCP tool registration

**Files:**
- Modify: `src/gnokee/mcp.py`
- Modify: `tests/unit/test_mcp_contract.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_mcp_contract.py`:

```python
def test_mcp_registers_gnokee_forget_episode() -> None:
    from gnokee.mcp import _register_tools  # whatever the impl exposes
    # Build a fake server; capture registered tool names
    names = _registered_tool_names()
    assert "gnokee_forget_episode" in names
    assert "gnokee_forget_tenant" in names
    # Verify ordering — destructive tools registered AFTER read tools
    assert names.index("gnokee_query") < names.index("gnokee_forget_episode")
    assert names.index("gnokee_history_of") < names.index("gnokee_forget_episode")


def test_mcp_forget_episode_input_schema_compact() -> None:
    """Refusal payload + description ≤ 1KB; key params present."""
    schema = _tool_input_schema("gnokee_forget_episode")
    required = set(schema.get("required", []))
    assert {"tenant_id", "episode_uuid", "reason"} <= required
    # Optional but defaults to False
    assert schema["properties"]["cascade"]["default"] is False


def test_mcp_forget_tenant_dry_run_defaults_true() -> None:
    schema = _tool_input_schema("gnokee_forget_tenant")
    assert schema["properties"]["dry_run"]["default"] is True
```

(Helper `_registered_tool_names` / `_tool_input_schema` mimic the patterns already in `test_mcp_contract.py` — read that file and reuse them.)

- [ ] **Step 2: Run — verify failures**

`pytest tests/unit/test_mcp_contract.py -v -k forget`

Expected: assertion failure ("not in names").

- [ ] **Step 3: Register tools in `src/gnokee/mcp.py`**

Locate the tool-registration block where `gnokee_history_of` is wired (~line 467). AFTER it, add:

```python
    @server.tool(
        name="gnokee_forget_episode",
        description=(
            "Hard-delete a single episode (and optionally its supersession "
            "descendants) from gnokee storage. Verifiable: a forget_audit "
            "row is persisted in the gnokee_maintenance schema and survives "
            "tenant deletion. If the episode is part of a supersession "
            "chain, this tool REFUSES with 'cannot_forget_chain_node' "
            "unless cascade=True is set — DO NOT auto-retry with "
            "cascade=True without explicit operator approval. When the "
            "receipt's affected_key_ids is non-empty, the consumer MUST "
            "destroy those DEKs in their KMS to complete cryptographic "
            "erasure (gnokee never holds keys)."
        ),
    )
    async def gnokee_forget_episode(spec: ForgetEpisodeIn) -> dict:
        try:
            detail = await forget_episode(
                app,
                tenant_id=spec.tenant_id,
                episode_uuid=spec.episode_uuid,
                cascade=spec.cascade,
                reason=spec.reason,
                actor=spec.actor,
            )
        except CannotForgetChainNode as exc:
            return {
                "error": "cannot_forget_chain_node",
                "descendant_count": exc.descendant_count,
                "deepest_descendant_uuid": exc.deepest_descendant_uuid,
                "hint": (
                    "Use gnokee_history_of(uuid=<target>) to inspect the chain. "
                    "Resubmit with cascade=True only after explicit operator "
                    "approval — this is permanent."
                ),
            }
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                "hint": "Invoke gnokee.maintenance.resume_forget(tenant_id, audit_id) to retry the Neo4j sweep.",
            }
        # Project ForgetReceiptDetail → compact ForgetReceipt for MCP
        return ForgetReceipt(**detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(mode="json")


    @server.tool(
        name="gnokee_forget_tenant",
        description=(
            "Hard-delete an entire tenant. Two-call ceremony: dry_run "
            "defaults to True and returns a planned receipt with no "
            "writes. Caller MUST issue a SECOND call with dry_run=False "
            "to actually destroy. Affected key_ids surface on the "
            "receipt — the consumer destroys those DEKs in their KMS."
        ),
    )
    async def gnokee_forget_tenant(spec: ForgetTenantIn) -> dict:
        try:
            detail = await forget_tenant(
                app,
                tenant_id=spec.tenant_id,
                dry_run=spec.dry_run,
                reason=spec.reason,
                actor=spec.actor,
            )
        except ForgetNeo4jPartial as exc:
            return {
                "error": "forget_neo4j_partial",
                "audit_id": exc.audit_id,
                "hint": "Invoke gnokee.maintenance.resume_forget(tenant_id, audit_id) to retry.",
            }
        return ForgetReceipt(**detail.model_dump(include=set(ForgetReceipt.model_fields))).model_dump(mode="json")
```

Add imports near the top of `mcp.py`:

```python
from gnokee.errors import CannotForgetChainNode, ForgetNeo4jPartial
from gnokee.forget import forget_episode, forget_tenant
from gnokee.models import ForgetEpisodeIn, ForgetReceipt, ForgetTenantIn
```

- [ ] **Step 4: Tests pass**

```bash
pytest tests/unit/test_mcp_contract.py -v -k forget
```

Expected: 3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/mcp.py tests/unit/test_mcp_contract.py
git commit -m "feat(mcp): register gnokee_forget_episode + gnokee_forget_tenant (ADR-0026)"
```

---

### Task 11: ADR-0026

**Files:**
- Create: `docs/adr/0026-forget-pipeline.md`

- [ ] **Step 1: Write the ADR**

Use the existing ADR-0024 (`docs/adr/0024-ingest-crash-recovery-journal.md`) as the structural template. Sections required:

- **Title:** `ADR-0026: Forget pipeline — hard-delete with verifiable audit + audit-row-as-journal`
- **Status:** `Proposed` (flip to `Accepted` on merge)
- **Date:** `2026-05-16`
- **Refs:** ADR-0004, ADR-0022, ADR-0023, ADR-0024, issue #130, spec `docs/superpowers/specs/2026-05-16-gnokee-forget-pipeline-design.md`
- **Context:** architecture.md §Forgetting names 3 modes; Mode 1 (soft supersession) shipped v0.2.1; Mode 2 (hard delete) never shipped; Mode 3 (crypto erasure) deferred (consumer-KMS dependency). #130 surfaces the `ingest_journal` cascade gap.
- **Decision:** Lifted verbatim from spec §3–§9. Two MCP tools; SERIALIZABLE Postgres tx for begin+sweep+commit; Neo4j separate; audit-row-as-journal with `find_failed_neo4j_rows` retry surface.
- **Consequences:** Spec §10 verbatim.
- **Acceptance evidence:** Integration test list from spec §11.2.
- **Cross-refs:** ADR-0022 refusal posture (DAG refusal payload format), ADR-0023 (gnokee owns episode write — graph store layout), ADR-0024 (ingest journal — twin precedent).

- [ ] **Step 2: Smoke check (markdown lints)**

```bash
markdownlint docs/adr/0026-forget-pipeline.md 2>/dev/null || true
grep -c '^## ' docs/adr/0026-forget-pipeline.md  # >=6 sections expected
```

- [ ] **Step 3: Commit**

```bash
git add docs/adr/0026-forget-pipeline.md
git commit -m "docs(adr): ADR-0026 forget pipeline — Proposed (#130)"
```

---

### Task 12: Q5 spike extension

**Files:**
- Modify: `evals/spike_q5_forgetting/run.py`
- Modify: `evals/spike_q5_forgetting/README.md`

- [ ] **Step 1: Add Probe 3 (chain refusal) + Probe 4 (tenant sweep) to `run.py`**

Extend the `PROBES` list:

```python
PROBES = [
    # existing Probe 1 + 2 unchanged
    ...,
    {
        "id": "probe_03_chain_refusal",
        "kind": "chain_refusal",
        "fixture": "supersession_chain",
        "expect": "CannotForgetChainNode",
    },
    {
        "id": "probe_04_tenant_sweep",
        "kind": "tenant_sweep",
        "expect_empty_tables": [
            "episode_metadata", "content_embedding", "content_text",
            "episode_body_encrypted", "lab_record", "med_record",
            "fact_contradiction", "ingest_journal",
        ],
        "expect_neo4j_group_empty": True,
    },
]
```

Then add the handler branches in `amain()` that:
- Build a 3-episode supersession chain in the spike corpus
- For Probe 3: call `forget_episode(b, cascade=False)`; expect `CannotForgetChainNode`
- For Probe 4: call `forget_tenant(GROUP_ID, dry_run=False, reason="q5-spike")`; assert each table count is 0; assert `MATCH (n {group_id: GROUP_ID}) RETURN count(n)` is 0

- [ ] **Step 2: Update README**

Edit `evals/spike_q5_forgetting/README.md`:
- Remove "Tenant-scoped forget isolation" from the "What this spike does NOT cover" list
- Add Probe 3 + Probe 4 rows to the Test design table
- Update the decision criterion to include "all four probes pass"

- [ ] **Step 3: Run the spike**

```bash
cd evals/spike_q5_forgetting && python run.py
```

Expected: 4/4 probes pass; `results/<utc-stamp>.json` written.

- [ ] **Step 4: Commit**

```bash
git add evals/spike_q5_forgetting/run.py evals/spike_q5_forgetting/README.md evals/spike_q5_forgetting/results/
git commit -m "feat(eval): Q5 Probes 3 + 4 — chain refusal + tenant sweep (ADR-0026)"
```

---

### Task 13: Docs sync (architecture.md + AGENTS.md)

**Files:**
- Modify: `docs/architecture.md`
- Modify: `AGENTS.md`

- [ ] **Step 1: architecture.md update**

In `docs/architecture.md`, edit the §Forgetting section to:

1. Pin the Mode-2 contract verbatim from spec §3.3 + §10:
   - "Hard delete is implemented by `gnokee_forget_episode` + `gnokee_forget_tenant` (ADR-0026)."
   - "Hard delete is INCOMPATIBLE with `valid_at` time-travel through pre-forget windows — Mode 1 (soft supersession via `EpisodeIn.corrects`) is the time-travel-preserving path."
2. Replace the existing "Tenant deletion cascades through facts, episodes, embeddings, derived summaries, tombstones" bullet with an explicit per-table list referencing migration 0017's `gnokee_maintenance.forget_audit`.

- [ ] **Step 2: AGENTS.md update**

In `AGENTS.md` §"Naming" find the line:

```
- MCP tools: `gnokee_<verb>` (e.g. `gnokee_query`, `gnokee_ingest_episode`, `gnokee_forget`)
```

Replace `gnokee_forget` with `gnokee_forget_episode`, `gnokee_forget_tenant`.

- [ ] **Step 3: Commit**

```bash
git add docs/architecture.md AGENTS.md
git commit -m "docs(adr): sync architecture.md + AGENTS.md to ADR-0026 forget surface"
```

---

### Task 14: End-to-end smoke + PR

**Files:**
- All changes from Tasks 1–13.

- [ ] **Step 1: Full test suite**

```bash
pytest tests/unit -v
pytest tests/integration -v -m integration
```

Expected: 0 failures across all forget tests + no regressions in pre-existing tests.

- [ ] **Step 2: Mypy strict**

```bash
mypy src/gnokee
```

Expected: 0 errors.

- [ ] **Step 3: Ruff**

```bash
ruff check src/gnokee tests
ruff format --check src/gnokee tests
```

Expected: clean.

- [ ] **Step 4: Smoke the Q5 spike one more time**

```bash
cd evals/spike_q5_forgetting && python run.py
```

Expected: 4/4 probes pass.

- [ ] **Step 5: Push branch + open PR**

```bash
git push -u origin <branch-name>
gh pr create --title "feat(v0.8): gnokee.forget pipeline — hard-delete + verifiable audit (ADR-0026, closes #130)" --body "$(cat <<'EOF'
## Summary
- Implements `gnokee_forget_episode` + `gnokee_forget_tenant` MCP tools (ADR-0026)
- Closes #130: `ingest_journal` swept in tenant forget alongside FK-CASCADE chain
- `gnokee_maintenance.forget_audit` table survives tenant deletion (verifiable forgetting)
- DAG-refusal default; `cascade=True` opt-in deletes descendants only
- `dry_run=True` default on tenant tool — two-call ceremony for irreversible op
- `affected_key_ids` on receipt surfaces consumer-KMS handoff
- `resume_forget` retries Neo4j-only failures via `state='fail'` audit rows

## Test plan
- [ ] `pytest tests/unit -v` passes
- [ ] `pytest tests/integration -v -m integration` passes (14 forget cases)
- [ ] `mypy src/gnokee` strict clean
- [ ] `ruff check` + `ruff format` clean
- [ ] Q5 spike: 4/4 probes pass

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 6: Self-merge gate**

Wait for CI green, then merge per repo norms.

---

## Self-Review

**Spec coverage:**
- §1 architecture overview: Task 7 + 8 carry the pipeline; Task 5 the Neo4j removers
- §2 Pydantic models: Task 2
- §3 MCP tool signatures + refusal: Task 10 + 1 (errors)
- §4 forget_audit schema + RLS posture: Task 3 (migration) + Task 4 (CRUD)
- §5 pipeline stages: Task 7 (episode) + Task 8 (tenant)
- §6 DAG semantics + ancestor cleanup: Task 6 (DAG walker) + Task 7 (ancestor UPDATE inside `_episode_postgres_phase`)
- §7 resume_forget: Task 9
- §8 concurrency: Task 7 + 8 (SERIALIZABLE + SET LOCAL app.current_tenant)
- §9 failure modes: covered across error class definitions (Task 1) + pipeline implementations
- §10 accepted consequences: documented in ADR-0026 (Task 11)
- §11 testing: Tasks 2, 4, 6, 7, 8, 9 (unit + integration); Task 12 (eval)
- §12 file inventory: matches Tasks 1–13
- §13 ADR-0026 outline: Task 11
- §14 closes/follow-ups: PR description Task 14

**No gaps.** All spec sections mapped to at least one task.

**Placeholder scan:**
- No "TBD" / "TODO" in any task body.
- Task 5's mocker-based test references existing test idioms — flagged adapt-to-pattern explicitly.
- Task 6 fixture column names flagged with "read the migration and pin" — acceptable because the executing agent has the migration in scope.
- Task 8 fixture column names similarly flagged.

**Type consistency:**
- `ForgetReceipt` vs `ForgetReceiptDetail` split is consistent across Tasks 2 (definition), 7 + 8 (returns Detail), 10 (projects to Receipt).
- `descendants_closure` returns `list[UUID]` — Task 6 defines, Task 7 consumes.
- `forget_audit.ForgetAuditRow` fields match across Task 4 (definition) + Task 9 (consumption).
- `app.pg_pool` + `app.graph` references match the existing `gnokee.bootstrap.App` shape.

---

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-05-16-gnokee-forget-pipeline.md`. Two execution options:

**1. Subagent-Driven (recommended)** — fresh subagent per task, two-stage review between tasks, isolates the long context window from each task's working memory.

**2. Inline Execution** — execute tasks in this session via executing-plans skill with checkpoint commits.

Which approach?
