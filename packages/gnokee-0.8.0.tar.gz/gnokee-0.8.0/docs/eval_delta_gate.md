# Eval-delta gate (v0.3)

> Lightweight regression gate for PRs that touch gnokee's retrieval or
> ingest hot paths. Pins last-known-good per-spike pass rates and fails
> a PR when a retrieval / ingest change silently regresses any of them.
>
> v0.3 ramp is **manual** — humans run `make eval-delta` locally before
> merging hot-path PRs. v0.4 promotes it to GitHub Actions once the
> base-image story stabilises.

## 1. Purpose

gnokee has eight deterministic spike harnesses under
[`evals/spike_q*/`](../evals). Three of them (Q1 graphiti, Q3 token
efficiency, Q4 contradiction) jointly cover the v0.1 surface; two more
(Q7 lab results, Q8 med supersession) cover the v0.2 typed clinical
reads. Every one of these is at risk of silent regression when a PR
touches:

- [`src/gnokee/retrieval.py`](../src/gnokee/retrieval.py) — recall
  candidate-narrowing + cosine + BM25 ranking.
- [`src/gnokee/ingest.py`](../src/gnokee/ingest.py) — Stage 1–8
  pipeline, lite-mode branch, supersession.
- Prompt files (extraction / contradiction / synthesis templates) under
  `src/gnokee/extract/` and `src/gnokee/contradiction/`.
- The deterministic clinical parsers under
  `src/gnokee/extract/clinical/`.

The eval-delta gate's job is to detect **measurable** regressions on
these spikes before merge, without burning the LLM-judge budget that
the heavy spikes (Q10 cross-tool) require.

## 2. What "delta" means

A delta is computed against a pinned **baseline** — the last-known-good
per-spike pass rates committed under
[`evals/baselines/<spike>.json`](../evals/baselines).

A PR fails the gate when **any** of the following holds:

1. **Spike-level pass rate drops by more than 5 percentage points.**
   Example: Q7 baseline `pass_rate = 0.733` (11 / 15). A PR that lands
   `pass_rate = 0.667` (10 / 15) is a 6.6 pp drop and fails the gate.
2. **A previously-PASS row turns FAIL.** Per-question regressions are
   binary: a row that was PASS in the baseline must remain PASS in the
   PR run, even if the spike-level pass rate is unchanged or improved.
   This catches "improved overall, regressed on a specific shape" PRs
   that the percentage gate would otherwise mask.

A PR passes when:

- Every spike's pass rate is within 5 pp of baseline OR strictly better.
- No previously-PASS row regressed to FAIL.
- New PASS rows (rows that did not exist in baseline, or that were FAIL
  in baseline and are now PASS) are surfaced as informational deltas
  but do not block.

## 3. Baseline shape

One JSON file per spike, committed under `evals/baselines/`. Shape:

```json
{
  "spike": "spike_q7_lab_results",
  "tag": "v0.2.3",
  "commit": "12dc539abc...",
  "harness_hash": "sha256:fc8e...",
  "captured_at": "2026-05-09T12:00:00Z",
  "pass_rate": 0.733,
  "rows": [
    {"qid": "q_k_lowest_2024",            "verdict": "PASS"},
    {"qid": "q_k_highest_2024",           "verdict": "PASS"},
    {"qid": "q_panel_count_2024",         "verdict": "PASS"},
    {"qid": "q_post_correction_value",    "verdict": "PASS"},
    {"qid": "q_pre_correction_value",     "verdict": "PASS"},
    {"qid": "q_units_recall_basic",       "verdict": "PASS"},
    {"qid": "q_abnormal_in_window",       "verdict": "PASS"},
    {"qid": "q_supersession_trail",       "verdict": "PASS"},
    {"qid": "q_trend_across_episodes",    "verdict": "PASS"},
    {"qid": "q_min_in_window",            "verdict": "PASS"},
    {"qid": "q_max_in_window",            "verdict": "PASS"},
    {"qid": "q_med_explains_lab",         "verdict": "FAIL"},
    {"qid": "q_anomaly_filter_compound",  "verdict": "FAIL"},
    {"qid": "q_reference_range_compare",  "verdict": "FAIL"},
    {"qid": "q_units_recall_compound",    "verdict": "FAIL"}
  ]
}
```

Fields:

| Field           | Purpose                                                                                          |
|-----------------|--------------------------------------------------------------------------------------------------|
| `spike`         | Directory name under `evals/`. Matches the harness invocation.                                  |
| `tag`           | gnokee tag the baseline was captured at (e.g. `v0.2.3`).                                         |
| `commit`        | Full SHA. Lets the reviewer reproduce the baseline exactly.                                      |
| `harness_hash`  | SHA-256 of the spike's `run.py` at the time the baseline was captured. If the harness changes, the baseline must be re-pinned in the same PR. |
| `captured_at`   | ISO-8601 UTC. For audit only.                                                                    |
| `pass_rate`     | Float in [0, 1]. Percentage gate compares against this.                                          |
| `rows`          | Per-question verdict list. Per-question gate compares against this. `qid` matches `queries.yaml`. |

Baselines are **committed**, not generated at CI time. The repo holds
the contract; the harness produces a comparable artifact at PR time.

## 4. Make target

The Make target is `eval-delta`. It runs the cheap deterministic
harnesses sequentially and prints the pass / fail verdict for each.
Today the runners do not yet accept a `--check-baseline` flag — wiring
that flag into each spike runner is part of #16 follow-up scope. The
target is committed as a stub that documents the contract; flip the
commented invocations on once the runners support `--check-baseline`.

```Makefile
.PHONY: eval-delta
eval-delta:
        # See docs/eval_delta_gate.md for the contract.
        # Each spike's run.py will gain --check-baseline in a follow-up
        # PR. For now this target wires the invocation skeleton; the
        # runners themselves emit pass/fail and exit non-zero on
        # regression once #16 follow-up lands.
        .venv/bin/python evals/spike_q1_graphiti/run.py        # --check-baseline
        .venv/bin/python evals/spike_q3_token_efficiency/run.py # --check-baseline
        .venv/bin/python evals/spike_q4_contradiction/run.py    # --check-baseline
        .venv/bin/python evals/spike_q7_lab_results/run.py      # --check-baseline
        .venv/bin/python evals/spike_q8_med_supersession/run.py # --check-baseline
```

The five spikes wired into the target are exactly the ones the v0.3
gate covers — see §6 below for what is in scope and §7 for what is
out.

## 5. CI invocation

For the v0.3 ramp, **the gate is manual**. The expectation is:

- A reviewer or PR author runs `make eval-delta` locally before merging
  any PR that touches `src/gnokee/retrieval.py`,
  `src/gnokee/ingest.py`, prompt files, or clinical parsers.
- The reviewer pastes the spike-level pass rates into the PR body
  under an `### Eval delta` section. AGENTS.md already requires "every
  PR includes test changes (or explicit `no-test-needed:` rationale)";
  for retrieval / ingest PRs, the eval-delta block is the proof.
- A regression (per §2) blocks the merge until the author either fixes
  the regression or re-pins the baseline with a written justification
  (e.g. "Q3 pass rate dropped 6 pp because Q3 surface intentionally
  changed in this PR; re-pin baseline to new known-good").

v0.4 promotes this to GitHub Actions. The blocker for automating it
today is the base-image / TEI-up dependency: the spike harnesses
require Postgres, Neo4j and TEI to be running, and the v0.3 CI image
does not yet ship with a stable cached layer for those services. Once
the base image stabilises, the gate moves from "manual checklist" to
"required status check on `pull_request` events touching the
hot-path glob".

## 6. In scope (v0.3 gate)

The five spikes the gate covers:

| Spike                          | What it gates                                      | Why deterministic                                                  |
|--------------------------------|----------------------------------------------------|---------------------------------------------------------------------|
| `spike_q1_graphiti`            | Graphiti-side recall on engineering / personal corpus | Recall@K + ranked-position checks; no LLM judge.                    |
| `spike_q3_token_efficiency`    | gnokee compact-fact-statement surface vs Graphiti raw | Token counts + top-K recall checks; deterministic comparison.       |
| `spike_q4_contradiction`       | Contradiction detection precision/recall on labelled pairs | Pairs are pre-labelled `unrelated/refinement/update/contradiction`. |
| `spike_q7_lab_results`         | `gnokee_lab_query` typed-read coverage             | Per-question ground truth in `queries.yaml`; deterministic.         |
| `spike_q8_med_supersession`    | `gnokee_med_query` typed-read coverage             | Per-question ground truth in `queries.yaml`; deterministic.         |

Each of these has either:

- a `queries.yaml` / `pairs.yaml` of expected answers, or
- a deterministic recall@K / contains-text check inside `run.py`.

There is no LLM-as-judge step in any of the five — that is the price
of admission to the gate.

## 7. Out of scope (v0.3 gate)

- **Q2 multilingual** (`spike_q2_multilingual`) — this is a 1024-dim
  cosine bench, not a semantic gate. The cross-lingual property is
  hardware-stable; there is no per-PR signal to extract.
- **Q5 forgetting** (`spike_q5_forgetting`) — separate retention spike;
  exercises tombstone propagation, not retrieval / ingest hot paths.
- **Q6 TEI / Ollama parity** (`spike_q6_tei_ollama_parity`) — embedder
  parity bench; runs only when the embedder version pins change.
- **Q10 cross-tool** (`spike_q10_cross_tool`) — LLM-judge,
  expensive, runs only on tag cuts. Tracked under
  [ADR-0012](adr/0012-cross-tool-eval-verdict.md). The tag-cut
  harness is invoked separately, not via `make eval-delta`.
- **Q11 recall diagnostic** (`spike_q11_recall_diagnostic`) — a
  diagnostic, not a regression gate; emits telemetry that operators
  consult during a debugging session, not pass / fail.

If a PR touches one of these out-of-scope spikes (e.g. a Q10 surface
change), the PR description must include the spike's verdict block as
documented in the spike's `README.md`. The eval-delta gate does not
cover them.

## 8. Re-pinning the baseline

A baseline is re-pinned when:

- An intentional change shifts the spike — e.g. ADR-0009 changing the
  Q7 corpus shape, or ADR-0012 changing the Q10 surface (out of scope
  for this gate, but the principle is the same).
- A bug fix lifts the pass rate enough that the new known-good
  exceeds the previous baseline (re-pin upward).
- A harness change recomputes the verdict deterministically — e.g.
  parser idempotency fix that reclassifies a previously-PASS row as
  FAIL or vice versa.

Re-pinning rules:

1. Update the baseline JSON under `evals/baselines/<spike>.json` in
   the **same PR** that lands the change.
2. Update the `tag` and `commit` fields to the new known-good.
3. Update `harness_hash` if `run.py` changed.
4. Mention the re-pin explicitly in the PR description under the
   `### Eval delta` block. Reviewers should not be surprised by a
   silent baseline shift.

## 9. Cross-references

- [ADR-0012](adr/0012-cross-tool-eval-verdict.md) — Q10 cross-tool
  status; tag-cut gate, not the per-PR gate documented here.
- [`integration_patterns.md`](integration_patterns.md) — lite-mode
  ingest mode contract; PRs touching the lite-mode branch must run
  `make eval-delta` because the branch shares Stage 1–3, 5, 6 with the
  full-mode hot path.
- [`AGENTS.md`](../AGENTS.md) §"Workflow" — "Eval-suite changes
  require a results delta posted in PR description".
- Spike runners — `evals/spike_q1_graphiti/run.py`,
  `evals/spike_q3_token_efficiency/run.py`,
  `evals/spike_q4_contradiction/run.py`,
  `evals/spike_q7_lab_results/run.py`,
  `evals/spike_q8_med_supersession/run.py`.
