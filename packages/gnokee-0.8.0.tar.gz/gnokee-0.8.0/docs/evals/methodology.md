# Eval methodology

> How gnokee evaluates itself. Pairs with
> [`../eval_delta_gate.md`](../eval_delta_gate.md) (the PR-merge
> contract) and the per-spike `README.md` files under
> [`../../evals/spike_*/`](../../evals/).

## Why gnokee evaluates

Per [Q9 / `AGENTS.md`](../../AGENTS.md): gnokee's credibility is
**published eval numbers**, not feature lists. Every load-bearing
design decision (Q1 Graphiti, Q2 bge-m3 cross-lingual, Q3 MCP
response shape, Q4 contradiction classifier, Q5 forgetting, Q7
clinical labs, Q8 medication history, Q9 wearables off-ramp, Q10
cross-tool, Q12 abstention) ran as a Q-numbered spike before the
ADR locked the decision.

This page is the methodology overview; the canonical contract is
[`../eval_delta_gate.md`](../eval_delta_gate.md).

## Spike harness pattern

Every spike under `evals/spike_q*/` follows the same shape:

```text
evals/spike_qN_<name>/
  README.md          — goal, decision criterion, what this does NOT cover, cost & time
  corpus.jsonl       — input episodes / sessions / canonical events
  queries.yaml       — labelled queries with grading criteria
                        (value_substring / contains_any / abstains / …)
  run.py             — harness entry: ingest → query → grade → dump JSON
                        accepts --skip-ingest (re-run grading without re-ingest)
                        respects GROUP_ID + threshold constants
  results/
    <utc-timestamp>.json   — one JSON dump per run, includes per-query notes
```

The harness writes a JSON result file per run; the ADR cites the
file path + verdict. Re-running the harness produces a new JSON
file alongside the old ones — history is append-only.

## Decision verdicts

Each spike resolves to one of four verdicts in its ADR amendment:

| Verdict | Meaning | Action |
|---|---|---|
| **ADOPT** | Spike target met. Accept design. | Lock in spec or ADR. |
| **ADOPT_WITH_GAPS** | Most queries pass; documented gaps. | Accept with the gap list as deferred follow-ups. |
| **OFF-RAMP** | Spike target not met by the current architecture. | Architectural change required (e.g. Q7 → typed `lab_record` table). |
| **REJECT** | Approach does not work. | Discard. |

Examples:

- Q1 Graphiti — **ADOPT** as storage primitive
  ([ADR-0001](../adr/0001-build-on-graphiti.md)).
- Q2 cross-lingual bge-m3 — **ADOPT** at 100% top-1 via direct
  cosine ([ADR-0004](../adr/0004-gnokee-owns-retrieval.md)).
- Q3 MCP response shape — **ADOPT** at 91.7% top-3 recall, 60%
  token reduction.
- Q5 forgetting — **ADOPT** at 2/2 propagation probes.
- Q7 clinical labs v0.1.1 — **OFF-RAMP** at 13.3% → v0.2 typed
  `lab_record` re-spike — **ADOPT_WITH_GAPS** at 66.7%
  ([ADR-0009](../adr/0009-clinical-labs-need-structured-store.md)).
- Q8 medication history v0.1.1 — **ADOPT_WITH_GAPS** at 53.3% →
  v0.2 — **ADOPT** at 100%
  ([ADR-0010](../adr/0010-meds-share-lab-record-shape.md)).
- Q9 wearables — **OFF-RAMP**; consumer TimescaleDB owns raw
  streams ([ADR-0011](../adr/0011-wearables-batch-or-off-ramp.md)).
- Q10 cross-tool — **REJECT** for v0.2.x retrieval surface on
  LongMemEval-S strict; Accepted-with-caveat
  ([ADR-0012](../adr/0012-cross-tool-eval-verdict.md)).

## Target dimensions

The dimensions gnokee evaluates on:

- **Bi-temporal correctness** — `as_of` / `valid_at` queries
  return the right facts under time-travel.
- **Contradiction surfacing** — % of conflicts surfaced honestly
  vs silently picked. Q4 minicorpus is the baseline.
- **Multilingual retrieval** — cross-language F1 on en / ru / bg /
  he at minimum (Q2 corpus). bge-m3 nominally covers 100+
  languages.
- **Token efficiency** — mean tokens per query vs answer quality.
  Q3 baseline is gnokee's MCP response shape vs Graphiti-raw.
- **Forgetting completeness** — `forget(X)` removes X from every
  retrievable surface. Q5 probes pgvector + Neo4j +
  contradiction-store + derived summaries.
- **Clinical workload accuracy** — Q7 labs + Q8 medication-history
  spikes against synthetic but realistic corpora.
- **Cross-tool head-to-head** — Q10 vs Mem0 / Graphiti / Zep /
  basic-memory on LongMemEval-S.
- **Abstention behaviour** — Q12: when SUTs have evidence but
  abstain. Synth-prompt bias diagnostic.

## Datasets

| Dataset | Shape | Used by |
|---|---|---|
| Synthetic personal corpus | en/ru/bg/he episodes about devops / journal / finance / preferences | Q1, Q2, Q3 |
| Q4 minicorpus | hand-labelled fact-pair contradictions | Q4 |
| Q7 / Q8 clinical corpus | rendered lab + medication episodes per ADR-0009 / ADR-0010 body shapes | Q7, Q8 |
| LongMemEval-S | upstream conversation-memory benchmark | Q10 |
| LongMemEval-S subsets | 10-, 30-, 100-question scale | Q10 Stage A / C-pilot / full-pilot |

We don't optimise for LongMemEval-S — it's conversation-shaped,
which is not gnokee's primary target. We run it for cross-tool
honesty (per ADR-0012).

## Cross-tool methodology (Q10)

Per [ADR-0012](../adr/0012-cross-tool-eval-verdict.md):

- Five SUTs ("systems under test"): gnokee, Mem0, Graphiti-alone,
  Zep-OSS, basic-memory.
- Each SUT wired through an adapter under `evals/q10/adapters/`
  with the same ingest + query interface.
- Double-run judge: two independent LLM judges grade each (query,
  response) pair; we accept only when they agree. Disagreements are
  surfaced as part of the result JSON.
- Same corpus, same queries, same grading rubric across SUTs.
- Track 1 = strict scoring (exact value match). Track 2 = looser
  (semantic match) — added in Q10.1.

This is what produced the "all three SUTs 0/30 strict" verdict at
Stage C-pilot. The bottleneck (synth-prompt abstention bias) was
diagnosed in #62 and falsifies the "retrieval is the bottleneck"
hypothesis — meaningful for which fix to invest in next.

## Eval-delta gate

The PR-merge contract: PRs that touch ingest, retrieval, or the
contradiction pipeline must not regress published eval baselines.

The full contract — which spikes gate which paths, the
`--check-baseline` flag semantics, the delta-posting format —
lives in [`../eval_delta_gate.md`](../eval_delta_gate.md). The
`Makefile` `eval-delta` target wires the runners; today it's a
stub until each spike's `run.py` accepts `--check-baseline`.

## Reproducibility

Each release tag should be reproducible against:

- The eval harness in `evals/spike_qN_*/run.py` at the tagged
  commit.
- The corpus and queries committed alongside the harness (no
  network-fetched corpora that drift).
- A documented hardware profile (CPU vs GPU TEI, available LLM
  endpoint).
- Pinned dependency versions in `pyproject.toml` at the tagged
  commit.

Result deltas, not absolute numbers, are the thing we cite when
comparing across SUTs that ship different feature sets.

## Authoring a new spike

When a Q-numbered question lands:

1. Create `evals/spike_qN_<short-name>/`.
2. Draft `README.md` covering: goal, decision criterion, methodology,
   what this does NOT cover, cost + time estimate.
3. Build `corpus.jsonl` and `queries.yaml`. Keep both small enough
   that the harness is reproducible on a developer laptop in
   minutes, not hours.
   - **Target extracted facts, not raw literals.** Graphiti
     paraphrases narrative during entity-edge extraction and silently
     drops literal numeric phrases (`"58 bpm"`, `"5.1 mmol"`, `"25 mg"`)
     and state-of-being adverbs (`"fully remote"`, `"car-free"`). See
     [ADR-0019 § Follow-up — Graphiti fragment-matching](../adr/0019-confidence-model.md#follow-up-post-v05)
     and [#90](https://github.com/gnokeelabs/gnokee/issues/90) for the
     resolution. Probes should target what graphiti **did** extract
     (`gnokee_recall.fact_count > 0` in a pre-flight pass); literal
     numeric retrieval goes through `gnokee_lab_query` (ADR-0009),
     `gnokee_med_query` (ADR-0010), or the `excerpts[]` /
     `episode_fallback[]` lanes — not through fact-graph probes.
4. Implement `run.py` to ingest → query → grade → dump JSON to
   `results/<utc-timestamp>.json`. Include per-query notes for
   non-trivial graders.

   **Ingest-completeness pre-flight (Q18 lesson, 2026-05-12).** Every
   spike that ingests narrative content MUST assert ingest completeness
   before scoring retrieval:

   ```python
   expected = sum(len(question.haystack) for question in questions)
   rows = await pg.fetchval(
       "SELECT count(*) FROM episode_metadata "
       "WHERE tenant_id = ANY($1::text[])",
       [q.tenant_id for q in questions],
   )
   if rows < expected:
       raise SystemExit(
           f"ingest dropped {expected - rows} of {expected} episodes "
           f"({(expected - rows) / expected:.1%}); rerun at --per-sut-concurrency 1 "
           "or wait for TPM headroom. See spike_q18_recall_at_k_diagnostic/ "
           "+ issue #111."
       )
   ```

   Q18 showed gnokee's recall@5 on 2026-05-10 stageC_30q20s was a
   100% ingest-gap (14 / 17 measurable rows had zero gold episodes in
   `episode_metadata`), not a retrieval-gap. Until [#111
   Z3](https://github.com/gnokeelabs/gnokee/issues/111) (loud-failure
   telemetry) ships, every spike MUST pre-flight ingest completeness
   itself or risk publishing measurement artifacts.

5. Run, collect results, write the per-query notes inline.
6. Open the ADR (or amend an existing one) with verdict + key
   findings. Link the result JSON.
7. PR for review by `eval-spike-author` (sole reviewer per
   [`AGENTS.md`](../../AGENTS.md) routing — methodology PRs don't
   need cross-stack review).

## Pointers

- [`../eval_delta_gate.md`](../eval_delta_gate.md) — PR-merge contract.
- [`../adr/0012-cross-tool-eval-verdict.md`](../adr/0012-cross-tool-eval-verdict.md) — Q10 verdict.
- [`../alternatives.md`](../alternatives.md) — public-facing summary of
  cross-tool comparison.
- [`../../evals/`](../../evals/) — all spike harnesses live here.
