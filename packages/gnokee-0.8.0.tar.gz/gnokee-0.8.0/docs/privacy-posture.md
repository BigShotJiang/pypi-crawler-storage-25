# Privacy posture

> Status: pre-1.0. The architectural invariants below are stable
> and will not change pre-1.0 (or post-1.0). The deployment
> mitigations are operator-tunable. Pair with
> [`architecture.md`](architecture.md) §"Privacy" and ADRs.

## TL;DR

- gnokee **never holds encryption keys** and **never decrypts**.
  This is the architectural invariant the project name encodes
  (*gno-kee* = "no key").
- gnokee **never auto-resolves contradictions** — surfaces both
  sides with a `verdict`, never picks a winner.
- gnokee **never deletes superseded facts silently** — three
  forgetting modes, all explicit, all returning `ForgetReceipt`.
- gnokee partitions by `tenant_id` on every API call, every
  Postgres row, every Neo4j node + edge. Postgres RLS is
  defence-in-depth.
- gnokee is a library + MCP server, not a hosting service. **It
  is not a HIPAA BAA, not a SOC2 attestation, not a sub-processor
  agreement**. Deployment compliance is the consumer's call.

## Threat model

Threats gnokee defends against (in scope):

- **Cross-tenant data leakage.** Tenant A queries somehow seeing
  Tenant B's facts. `tenant_id` predicate on every read + Postgres
  RLS + Neo4j `group_id` discipline.
- **Accidental key exposure.** gnokee storing a DEK, decrypting
  user data outside the documented embed-only window, or logging
  plaintext from an `encrypted_body` payload. Architectural
  invariant; load-bearing.
- **Contradiction laundering.** gnokee silently picking a "winner"
  and hiding the conflict from the consuming LLM / user. Hard
  refusal — surface, never resolve.
- **Forgetting non-propagation.** `gnokee_forget(X)` leaving X
  visible somewhere. Q5 spike validated propagation across
  pgvector + Neo4j + contradiction-store + derived summaries.
- **Bi-temporal-axis confusion.** Axis A (`asserted_at`) treated as
  axis B (`created_at`) and vice versa. `bi-temporal-auditor`
  reviewer agent + reviewer routing per [`AGENTS.md`](../AGENTS.md).

Threats **out of scope** (consumer's responsibility):

- Network-level intercepts. Use TLS to Postgres / Neo4j / TEI /
  the LLM endpoint. gnokee uses whatever the underlying client
  library does (asyncpg, neo4j-driver, httpx).
- Compromised LLM endpoint. The endpoint sees episode `content`
  during Graphiti narrative extraction (Stage 4) and the Q4
  contradiction prompt (Stage 7). If your LLM provider is the
  threat, encrypted-body branch (Stage 4 force-skipped) and
  consumer-self-hosted LLM (Ollama / vLLM) are the mitigations.
- Compromised storage backend. Postgres / Neo4j / TEI run in
  consumer infrastructure; gnokee assumes them honest.
- DoS via unbounded cost — see [`deploy.md`](deploy.md) §"Cost
  control".
- Side-channel attacks (timing, embedding-based deanonymisation,
  membership inference). Mature problems; gnokee does not provide
  guarantees here.

## "No key" invariant

gnokee accepts two episode-body shapes via the `EpisodeIn`
boundary validator:

- `content: str` — plaintext. gnokee stores it in
  `episode_metadata.content`, embeds it for the cosine recall
  lane, sends it to the LLM for entity extraction (Stage 4) and
  contradiction detection (Stage 7).
- `encrypted_body: EncryptedBody` — pre-encrypted. gnokee stores
  the `(ciphertext, nonce, key_id)` triple verbatim in
  `episode_body_encrypted`. **gnokee never decrypts.**

The `content` xor `encrypted_body` rule is enforced as a Pydantic
`model_validator` — both = ambiguous, neither = nothing to ingest,
exactly one = accepted.

### Encrypted-body lifecycle

```text
Consumer KMS              Consumer process            gnokee process
     │                          │                           │
     │  encrypt(plaintext)      │                           │
     │ ───────────────────────►│                           │
     │  (ciphertext, nonce,     │                           │
     │   key_id)                │                           │
     │                          │  EpisodeIn(               │
     │                          │     encrypted_body=...,  │
     │                          │     valid_at=...)        │
     │                          │ ─────────────────────────►│
     │                          │                           │ Stage 1: validate
     │                          │                           │ Stage 3: embed (if
     │                          │                           │   content_for_embedding
     │                          │                           │   set; plaintext dropped
     │                          │                           │   after embed())
     │                          │                           │ Stage 4: SKIPPED
     │                          │                           │ Stage 6: store ciphertext
     │                          │                           │ Stage 7: SKIPPED
     │                          │                           │
     │                          │                           │ ... later, on recall ...
     │                          │  RecallResponse(          │
     │                          │     encrypted_bodies=[...]│
     │                          │  ) ◄──────────────────────│
     │                          │                           │
     │ ◄────────────────────────│                           │
     │  decrypt(ciphertext,     │                           │
     │   nonce, key_id)         │                           │
     │  → plaintext             │                           │
```

Key facts about the lifecycle:

- **gnokee never sees the DEK.** Only the consumer-managed
  `key_id` reference travels with the ciphertext.
- **Stage 4 (Graphiti narrative extraction) is force-skipped** for
  encrypted episodes — there's no plaintext narrative for the LLM
  to extract.
- **Stage 7 (contradiction detection) is force-skipped** — no
  edge facts to compare against.
- **Stage 3 (embedding) runs only if** the consumer set
  `EncryptedBody.content_for_embedding`. The plaintext is passed
  to the embedder (over the TEI socket — see § "What encrypted-
  body does NOT defend against" for the TEI access-log caveat)
  and dropped from gnokee's local scope immediately after
  `embed()` returns. Never persisted on disk by gnokee.
  Specifically (hardened in #132 after v0.6.0 was caught leaking):
  Stage 4 lite Episodic writes `n.content = ""` +
  `n.name = "[encrypted episode]"` + `n.source_description =
  "gnokee.ingest.encrypted"` regardless of whether the embed
  window was supplied; Stage 6 clinical parsers (`parse_labs` /
  `parse_meds`) are skipped on the encrypted branch, so no
  `lab_record` / `med_record` rows are derived from the plaintext
  window.
- **Recall surfaces ciphertext verbatim** via
  `RecallResponse.encrypted_bodies[]`. The consumer decrypts
  using their KMS via `key_id`.
- **`FactProvenance.episode_content` is `""`** for encrypted
  episodes; the ciphertext envelope rides on
  `FactProvenance.encrypted_body`.

### Cryptographic erasure (forgetting mode 3)

The consumer destroys the DEK in their KMS. Ciphertext gnokee
holds becomes unreadable. No gnokee-side action required —
ciphertext-at-rest is rendered useless without the key.

This is the standard pattern for clinical / regulatory contexts
where backups can't be selectively rewritten. gnokee's role is to
**not be a key holder** so the consumer's KMS-side delete is
sufficient.

### What encrypted-body does NOT defend against

- **Pattern leakage from embeddings.** When
  `content_for_embedding` is set, the 1024-dim embedding stays in
  pgvector. Embedding inversion attacks are an active research
  area; gnokee makes no claim that the embedding is information-
  theoretically zero-knowledge. If your threat model rules out
  embeddings entirely, set `content_for_embedding=None` and accept
  the recall trade-off (no semantic lane for that episode).
- **Metadata leakage.** `valid_at`, `asserted_at`, `tenant_id`,
  `language`, `sensitive` are stored in plaintext in
  `episode_metadata`. If the existence of an episode is itself
  sensitive, encrypted-body is not enough — you need a different
  storage layer.

## Multi-tenancy

`tenant_id` is mandatory on every gnokee API call. It maps to:

- **`tenant_id` column** on every Postgres table, primary-key
  prefix in most cases.
- **`group_id` property** on every Graphiti node and edge in
  Neo4j. Every gnokee Cypher query includes
  `WHERE n.group_id = $tenant` on every node and edge predicate.
- **`tenant_id` argument** on every MCP tool call.

### Postgres RLS (defence-in-depth)

gnokee stores `tenant_id` as a normal indexed column and relies on
the application layer (gnokee's own SQL + the consumer middleware)
to apply the predicate. As an additional layer:

- The consumer middleware sets a session GUC:
  `set_config('app.current_tenant', $tenant, true)` per request
  (third arg `true` = transaction-local).
- Postgres RLS policies use this GUC to enforce that even a
  hand-crafted `SELECT * FROM episode_metadata` returns only the
  current tenant's rows.

`run_deferred_extraction` already does this internally. Consumer
code paths that talk to gnokee's Postgres tables directly should
do the same.

The RLS policies are not shipped in gnokee's migrations — they're
operator-owned, since they need to match the consumer's auth
middleware. See [`deploy.md`](deploy.md) §"RLS GUC pattern" for the
canonical shape.

### Neo4j Community has no RLS

Neo4j Community does not support row-level security. gnokee's
isolation is `group_id` discipline — every Cypher query gnokee
emits includes the tenant predicate on every node and edge.

If you don't trust application-layer discipline (e.g. running
gnokee behind an untrusted application layer), put each tenant
in its own Neo4j database. Multi-database is a Neo4j Enterprise
feature and moves you off the gnokee-tested deployment shape; see
[ADR-0005](adr/0005-graph-backend-tradeoff.md) for the trade-off.

### Tenant deletion

GDPR right-to-erasure mode: hard-delete a tenant's data across
all stores.

- **Postgres**: ON DELETE CASCADE FK chain handles the dependent
  tables. Single delete on `episode_metadata` cascades to
  `content_embedding`, `lab_record`, `med_record`,
  `episode_body_encrypted`. `fact_contradiction` rows are deleted
  by the matching `tenant_id` predicate.
- **Neo4j**: hard-delete every node + edge with
  `group_id = $tenant`. `gnokee_forget` does this on a per-fact
  basis; per-tenant deletion is a `MATCH (n) WHERE n.group_id =
  $tenant DETACH DELETE n` Cypher.
- **pgvector**: rows in `content_embedding` with the matching
  `tenant_id` are dropped via the FK cascade above.

The `gnokee_forget` MCP tool ships in v0.2+ for per-fact deletes.
Per-tenant deletion is operator-driven SQL + Cypher today;
plumbing to expose it as an MCP tool is post-v0.x scope.

## What gnokee logs

Per [`observability.md`](observability.md):

- Mandatory: `tenant_id`, `episode_uuid`, `latency_ms`, `stage`,
  event names, error classes.
- Forbidden: episode `content`, embedding vectors, LLM prompts,
  LLM responses, DEK material, `key_id` material, ciphertext
  bodies, secrets / passwords / API keys.

If you find a log line carrying any forbidden field, file a
security report per [`../SECURITY.md`](../SECURITY.md).

## What gnokee stores in plaintext

Even with the encrypted-body branch, gnokee stores in plaintext:

| Field | Why |
|---|---|
| `episode_metadata.tenant_id` | Tenant key — has to be filterable. |
| `episode_metadata.episode_uuid` | Identity. |
| `episode_metadata.valid_at` / `valid_until` | Bi-temporal world-time axis. |
| `episode_metadata.asserted_at` / `asserted_until` | Bi-temporal source-tx-time axis. |
| `episode_metadata.language` | ISO 639-1 tag. |
| `episode_metadata.sensitive` | `"public" \| "private" \| "clinical"` — drives downstream gating. |
| `episode_metadata.content` | **Only when content branch is used.** NULL on encrypted-body branch. |
| `content_embedding.embedding` | 1024-dim float vector. Retains semantic content of the input. |
| `lab_record` / `med_record` rows | **Only when the deterministic parsers extracted them from a `content` body.** Encrypted-body episodes do NOT populate these — Stage 6 parsers are skipped on the encrypted branch (`parse_labs` / `parse_meds` never see the embed-window plaintext, hardened in #132). |
| Graphiti `EpisodicNode.content`, `EntityNode.name`, `EntityEdge.fact` | **Only on `content` branch.** Encrypted-body episodes write a lite `EpisodicNode` (Stage 4) so recall Stage 2a can locate the episode, but `content=""`, `name="[encrypted episode]"`, `source_description="gnokee.ingest.encrypted"` regardless of whether `content_for_embedding` was supplied (hardened in #132). The LLM-driven `EntityNode` / `EntityEdge` lanes never fire on the encrypted branch. |

If the existence or metadata of an episode is itself sensitive,
encrypted-body is not enough — you need a different storage
layer or row-level encryption applied to `episode_metadata` too.

## LLM endpoint exposure

The consumer-supplied LLM endpoint sees:

- **Stage 4 (Graphiti narrative extraction):** the full episode
  `content`. Skipped on encrypted-body branch.
- **Stage 7 (Q4 contradiction classification):** pairs of
  `EntityEdge.fact` strings (LLM-summarised facts, not raw
  bodies). Skipped on encrypted-body branch.
- **Future maintenance synthesis:** episode bodies (consumer's
  call to enable).

If your LLM provider is part of your threat model:

- Run the LLM yourself (Ollama / vLLM / on-prem) and point
  `GNOKEE_OPENAI_BASE_URL` at it.
- For per-episode "this body must never reach the LLM" rules, use
  the encrypted-body branch — Stage 4 is force-skipped and
  Stage 7 has no edge facts to evaluate.
- Use the `sensitive` flag (`"clinical"`) to tag episodes for your
  own downstream gating; gnokee does not currently route based on
  it but the field is durably stored.

## What gnokee is NOT

- **Not a HIPAA BAA.** gnokee is library code. Compliance with
  HIPAA's BAA contract requires a hosted offering and a signed
  agreement with the consumer's covered entity — neither of which
  gnokee provides. gnokee can be deployed *into* a HIPAA-compliant
  environment by a consumer who runs their own infrastructure.
- **Not a SOC2 attestation.** Same shape — SOC2 attests to a
  service organisation; gnokee is not a service. Your deployment
  may be SOC2-attestable; the gnokee project is not.
- **Not a GDPR sub-processor.** gnokee processes data in the
  consumer's deployment; the consumer is the data controller and
  the data processor. gnokee is a library the consumer uses.
- **Not a confidential-computing solution.** gnokee makes no
  claims about TEE / SGX / SEV memory protection. Stage 3 plaintext
  windows live in process memory; if your threat model includes
  process-memory attacks, encrypted-body branch + a confidential-
  computing TEE around the gnokee process is the path — and
  validating that combination is the operator's responsibility.

## What gnokee IS

- A library and an MCP server, deployable into any environment
  the consumer manages.
- An architectural commitment to specific invariants:
  bi-temporal honesty, contradiction surfacing, verifiable
  forgetting, multi-tenant isolation, no key holding, no LLM
  vendoring, no auto-resolution, no supersession-by-deletion.
- A toolset for building memory infrastructure that doesn't
  silently corrupt user data or quietly leak it across tenants.

## Reporting a privacy bug

If you find:

- gnokee storing or transmitting a DEK,
- gnokee decrypting an `encrypted_body`,
- gnokee logging plaintext / embeddings / LLM prompts / `key_id`
  outside the documented lifecycle,
- gnokee returning rows from another tenant,
- `gnokee_forget` leaving residue in any retrievable surface,
- bi-temporal filters returning superseded facts under the
  default `as_of`,

… treat as a critical privacy bug and report per
[`../SECURITY.md`](../SECURITY.md). The "no key" invariant and
tenant isolation are load-bearing for the project's promise.

## See also

- [`architecture.md`](architecture.md) §"Privacy" + §"Multi-tenancy" + §"Encrypted-body lifecycle".
- [`adr/0004-gnokee-owns-retrieval.md`](adr/0004-gnokee-owns-retrieval.md) — retrieval design.
- [`adr/0005-graph-backend-tradeoff.md`](adr/0005-graph-backend-tradeoff.md) — Neo4j Community + group_id discipline.
- [`adr/0008-contradiction-storage-pg-table.md`](adr/0008-contradiction-storage-pg-table.md) — contradiction model.
- [`deploy.md`](deploy.md) — RLS GUC pattern, secrets management.
- [`observability.md`](observability.md) — what gnokee logs vs never logs.
- [`../SECURITY.md`](../SECURITY.md) — vulnerability disclosure.
- [`../examples/04_encrypted_body.py`](../examples/04_encrypted_body.py) — runnable encrypted-body lifecycle.
