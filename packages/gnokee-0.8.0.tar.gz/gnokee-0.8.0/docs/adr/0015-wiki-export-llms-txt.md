# ADR-0015: `gnokee_wiki_export` MCP tool + `llms.txt` manifest

- **Status:** Accepted — `gnokee_wiki_export` MCP tool + static
  `static/.well-known/llms.txt` (and pointer `gnokee.txt`) ship in
  v0.5. Markdown templating layer only — zero new storage, zero LLM
  hosting. Issue [#74](https://github.com/gnokeelabs/gnokee/issues/74).
- **Date:** 2026-05-11
- **Decider:** Vadim Yuzi
- **Context:** Adoption candidate #3 from competitive landscape 2026-Q2
  (synthesis Section 5, row 3). Tracks umbrella issue. Direct lineage
  from Karpathy's Software 3.0 YC keynote 2025-06-17 ("markdown is
  crazy for LLMs.") and the 2026-04-04 LLM Wiki gist (~16M tweet
  views). `llms.txt` convention adopted by Mintlify, Cloudflare,
  Anthropic.

## Context

gnokee already owns the source-of-truth surface: a bi-temporal knowledge
graph in Neo4j (via Graphiti) plus episodes in Postgres. Consumers reach
that data via four MCP read tools today (`gnokee_recall`,
`gnokee_fact_provenance`, `gnokee_lab_query`, `gnokee_med_query`).

What's missing is a **derived markdown view** of the same data:

- Karpathy's LLM Wiki pattern (single-user, filesystem-rooted) treats
  markdown as the canonical LLM-friendly format. A `wiki/` directory of
  `entities/<slug>.md` files is what an LLM agent reads to bootstrap
  context — not a SQL row or a Cypher edge.
- The `llms.txt` convention (analogous to `robots.txt` / `humans.txt`)
  publishes a manifest of an org's MCP tools, identity model, and red
  lines so an agent can probe and discover the surface without reading
  a full README.

gnokee differs from the LLM Wiki pattern in three ways:

- **Multi-tenant.** The pattern assumes single-user filesystem; gnokee's
  wiki is per-tenant and `tenant_id` is mandatory.
- **Output, not source-of-truth.** The KG + episode store remain
  canonical; wiki export is a derived view rebuilt on demand.
- **No "lint" pass.** Karpathy's pattern has a `wiki/` LLM lint step;
  that's adoption candidate #4 (dreaming pass), out of scope here.

## Decision

Ship two pieces in v0.5:

### A. `gnokee_wiki_export` MCP tool

```jsonc
gnokee_wiki_export({
  "tenant_id": "uuid",                  // MANDATORY
  "scope":     "self" | "full",         // self = active facts only;
                                        // full = include superseded
  "as_of":     "ISO-8601 | null"        // bi-temporal source-time pin
}) -> {
  "files": [
    { "path": "index.md",             "content": "..." },
    { "path": "log.md",               "content": "..." },
    { "path": "entities/<slug>.md",   "content": "..." }
  ],
  "generated_at": "ISO-8601",
  "tenant_id":    "uuid"
}
```

Synthetic shape:

- `index.md` — entity list, one link per entity.
- `log.md` — episode summaries newest-first.
- `entities/<slug>.md` — one page per top-level entity, current facts
  under a "Current" section, superseded facts under a "History" section
  (only when `scope=full`), plus source-episode handles (`episode_uuid`,
  `valid_at`, `asserted_at`) reusing the ADR-0016 citation shape concept.

Slug strategy: **human-readable + UUID disambiguation suffix on collision**.
The slug is a lowercased, hyphenated rendering of the entity's display
name (`Metoprolol Succinate ER` → `metoprolol-succinate-er`); on
collision within the tenant, an 8-char hex suffix is appended
(`metoprolol-7a2f08c1`). Stable across calls for the same entity
because the suffix derives from the entity UUID rather than a counter.

Cache invalidation: **per-tenant write-clock**. The tool maintains an
in-process per-tenant cache of the last `generated_at`; on the next call
the cache is invalidated when the tenant's latest `asserted_at` exceeds
the cached value. v0.5 implementation is in-process; a future
follow-up can promote it to Postgres if multi-process deployment
warrants. Per-entity invalidation was considered and rejected — the
extra bookkeeping cost outweighs the regeneration cost of a tenant
typically holding tens-to-hundreds of entities, not millions.

`as_of` past timestamp: returns the wiki as it was at that bi-temporal
point. v0.5 falls back to the latest snapshot when an `as_of` precedes
the most recent write (the `fact_revision` table from ADR-0014 deferred
issue #73 is the long-term path); when fallback fires, a header note is
emitted in `index.md` so the consumer knows `as_of` history was
unavailable. The fallback degrades gracefully — `as_of` newer than the
latest write returns the current snapshot without a header note.

Pagination: **out of scope for v0.5**. One MCP call returns all files.
A tenant with ten thousand entities would blow the MCP envelope; we
defer pagination + `max_pages` knob to v0.6+ once a real consumer hits
the limit.

### B. Static `llms.txt` manifest

Drop two static files at `static/.well-known/`:

- `llms.txt` — full manifest (gnokee version, ADR index, MCP tool list
  with one-line descriptions, identity model, red lines).
- `gnokee.txt` — pointer file (`manifest: ./llms.txt`) so agents that
  probe a `<project>.txt` path also discover the canonical manifest.

Both ship in the PyPI sdist + wheel via the hatch build config (the
`force-include` map under `[tool.hatch.build.targets.{sdist,wheel}]`).
Docker users find them in the in-repo `static/.well-known/` path of
the gnokee install; gnokee itself does NOT publish a webserver, so
self-hosters wire their own static-file route if they want to serve
the manifest at a real URL.

The `llms.txt` lists ONLY tools that ship on main. `gnokee_query`
(declarative envelope, ADR-0013 / issue #72) is filed as a follow-up
and is intentionally absent — we add it when its PR lands.

## Why it fits gnokee's red lines

- **Pure templating layer over existing reads.** No new Postgres
  tables, no new Cypher predicates, no LLM calls. The export builder
  composes `MetadataStore` + `GraphitiStore` reads against the same
  tenant predicates everything else uses.
- **No LLM hosting.** Markdown is fact-templated, never generated.
  Strings come from `FactStatement.text` + entity names + episode
  bodies. gnokee never paraphrases.
- **No auto-pushing to a consumer git repo.** Output is markdown
  bytes in the MCP response — the consumer decides what to do with
  them.
- **No UI.** The export is bytes, not a rendered page; rendering is
  the host's problem.
- **No "knowledge engine" branding.** The manifest copy is
  deliberately neutral.

## Anti-patterns to avoid

- Writing markdown to disk by default — output stays as MCP response
  bytes; let the consumer persist.
- Auto-pushing markdown to a git repo — consumer's choice, not
  gnokee's.
- Calling the manifest "knowledge engine manifest" — Pinecone
  trademark feel.
- Mixing the manifest with marketing copy — it's a structured
  discovery surface; keep the format greppable.
- Synthesising entity summaries from an LLM — the wiki is a view
  over stored facts, not a generated artifact.

## Open questions deferred to follow-ups

- `fact_revision` integration for true `as_of` history (#73, ADR-0014).
- Pagination + `max_pages` knob (v0.6+ once a real consumer hits the
  current envelope limit).
- Static-file webserver hosting (out of scope — self-hosters wire
  their own route).

## Sequencing

Lands in v0.5 alongside ADR-0016 (citation envelope) and the v0.5
backlog (#74, #75, #76, #77). Best-ROI adoption-candidate of the eight
identified in 2026-Q2 synthesis — zero new storage, ship in days.
