# ADR-0016: per-claim bi-temporal citation envelope on MCP read responses

- **Status:** Proposed — schema + wire envelope ship in v0.5. `extracted_quote`
  populated by the extraction stage is deferred to a follow-up issue; v0.5
  ships every quote as `null`. Status moves to Accepted once the
  extraction-stage backfill lands and at least one host (Omur / noggin)
  has emitted `[cN]` markers against a real corpus.
- **Date:** 2026-05-11
- **Decider:** Vadim Yuzi
- **Context:** Adoption candidate #5 from competitive-landscape 2026-Q2
  ([umbrella #71](https://github.com/gnokeelabs/gnokee/issues/71)),
  tracking [#76](https://github.com/gnokeelabs/gnokee/issues/76).
  Spike Q42 (`evals/spike_q42_cites_mismatch/`) is the new eval class
  ADR-0016 unlocks. Gated by ADR-0019 confidence-decay verdict
  (`SHIP_RECENCY_AS_PROXY` — citations may carry a recency-proxy
  `confidence` field in a follow-up amendment, not in v0.5).

## Context

gnokee's MCP read tools today return free-form recall responses with
provenance handles attached per fact (`facts[].fact_uuid`,
`facts[].episode_uuid`), plus row-level `episode_uuid` on
`gnokee_lab_query` / `gnokee_med_query`. The host LLM that consumes
these tools has no standard way to back-reference a single claim in
its answer to a specific episode — it gets a flat list and a wall of
prose.

Three peer systems publish a structured per-claim citation envelope:

| System | Surface | Bi-temporal? | Quote? |
|---|---|---|---|
| NotebookLM | `[1] = source_N.pdf` + highlighted span | No | Yes (span) |
| Microsoft GraphRAG | per-claim provenance with extracted quote | No | Yes |
| Pinecone KnowQL | field-level citations with `confidence` + `source_uri` | No | No |

Source: synthesis at `research/competitive_landscape_2026-05-10.md`,
dossiers `research/_dossier_notebooklm.md`,
`research/_dossier_umbrella_adjacent.md`,
`research/_dossier_pinecone_nexus.md`.

**Observation:** every peer surface lacks one of the two bi-temporal
axes gnokee already has. NotebookLM / GraphRAG carry a `source` but
no `valid_at` ≠ `asserted_at` distinction; Pinecone carries
`source_uri + confidence` but no time axes. Adopting a citation
envelope that surfaces BOTH bi-temporal axes plus an optional verbatim
quote is differentiator-positive for gnokee: it's strictly stronger
than NotebookLM-class citations *and* it composes cleanly with the
ADR-0008 contradiction surfacing and ADR-0019 recency-as-proxy
confidence.

The host LLM remains responsible for producing the inline `[cN]`
markers in its answer text — gnokee never paraphrases, never produces
the answer prose itself (AGENTS.md "do not" list § "no LLM hosting").
gnokee's contract is: deliver the envelope, the consumer's LLM emits
the markers.

## Decision

Ship a `citations: dict[str, Citation]` MAP on every MCP read response
(`gnokee_recall`, `gnokee_lab_query`, `gnokee_med_query`, and any
future `gnokee_*` read tool). The map is keyed `c1`, `c2`, `c3`, …
in deterministic emission order so the host LLM can back-reference
entries via inline `[cN]` markers. **Additive**: the existing
provenance handles (`facts[].fact_uuid`, `facts[].episode_uuid`,
`rows[].episode_uuid`) keep working unchanged — both surfaces ship in
the same minor version (v0.5).

### Citation entry shape

```jsonc
{
  "c1": {
    "episode_uuid":    "uuid",          // always present
    "fact_uuid":       "uuid | null",   // populated for FactStatement-backed
                                        // citations; null for excerpt / body
                                        // / typed-store (lab/med) entries
    "valid_at":        "ISO-8601",      // ADR-0001 world-time axis
    "asserted_at":     "ISO-8601",      // ADR-0001 source-tx-time axis
    "extracted_quote": "string | null", // verbatim body span when the
                                        // extraction stage recorded one;
                                        // null otherwise (v0.5 default)
    "source_uri":      "string | null"  // optional consumer-supplied source
                                        // URI; null until ingest carries it
  },
  "c2": { ... },
  "c3": { ... }
}
```

### Emission order

Deterministic so the same query reproduces the same `[cN]` labels:

```
gnokee_recall:
  facts            → c1, c2, …
  excerpts         → c{n+1}, …
  episode_fallback → c{n+m+1}, …

gnokee_lab_query / gnokee_med_query:
  rows             → c1, c2, …   (scalar ops emit zero rows = empty map)
```

### Inline-marker convention

Tool descriptions document that host LLMs should emit `[c1]`, `[c2]`,
… markers in their answer wherever they state a claim that maps to a
citation. `[cN]` is preferred (unambiguous, matches the envelope key);
`[N]` is also accepted by downstream graders — some LLMs rewrite
`[c1]` to `[1]` and we don't fight that.

## Why a map (not a list)

The issue body asked the question explicitly: map vs list. Decided
**map** because:

1. **Easier LLM back-reference.** `[c1]` directly indexes the entry
   without the LLM needing to remember a `citations[0]` offset.
2. **Stable across token-budget truncation.** If `max_tokens` truncates
   the fact list, the surviving entries keep their original `cN` keys
   — a list would re-number and break previously-emitted `[cN]` markers
   in chained responses.
3. **JSON-schema friendly.** MCP clients can validate
   `citations.c1.valid_at` directly; list-of-objects schema would
   require array-index gymnastics.

## Why `extracted_quote` ships as `null` in v0.5

The extraction stage records per-episode body text in
`episode_metadata.content_text` (lite-mode) or in Graphiti (full-mode),
but it does **not** know which body span produced which Graphiti edge
fact. The link is at the episode level — the LLM-summarised fact
statement may reword the digits, drug names, dates, or even invert
the polarity of the source span. Filling `extracted_quote` would
require either:

1. **Synthesising from `FactStatement.text`** — strictly forbidden by
   ADR-0016 § Anti-patterns (would hallucinate a quote the source
   never said).
2. **Substring-matching against the body** — heuristic, locale-fragile,
   silently wrong on a non-trivial fraction of facts.
3. **Re-running extraction with span tracking** — correct, but requires
   a prompt change + extraction stage refactor that is OUT OF SCOPE
   for v0.5 (the issue body explicitly defers it to a follow-up).

v0.5 ships `extracted_quote: null` everywhere. Migration
`0013_episode_extracted_quote.sql` adds the column as nullable
text with no backfill. A follow-up issue wires extraction-stage span
capture and backfills.

This is the **NotebookLM-class trust posture** — gnokee surfaces a
honest `null` rather than a fabricated quote, the same way ADR-0019
ships `confidence` as a documented recency proxy rather than a
calibrated probability. Both are explicit decisions to NOT mislead.

## Why `source_uri` ships as `null` in v0.5

The ingest surface (`gnokee_ingest_episode`) does not currently carry a
`source_uri` parameter. Adding one would be a separate ingest-shape
change. v0.5 emits `source_uri: null` everywhere; a follow-up issue
wires it through if a real consumer asks for it. Consumers needing a
source pointer today can stuff it in `our_id` (the consumer-supplied
stable id surface from `EpisodeIn`).

## Schema change

Single migration: `src/gnokee/storage/migrations/0013_episode_extracted_quote.sql`:

```sql
ALTER TABLE episode_metadata
    ADD COLUMN IF NOT EXISTS extracted_quote TEXT;
```

Read-side: `MetadataStore.get(...)` already returns the column; the
recall pipeline carries it into the `Citation.extracted_quote` field
via the in-flight `metadata_lookup`. Lab / med pipelines do not yet
fetch the metadata row — they emit `extracted_quote: null` for v0.5
and wire the lookup in a follow-up issue.

## Wire surface — recall

`gnokee_recall` adds one field; everything else is unchanged.

```jsonc
{
  "facts": [ /* unchanged — fact_uuid + episode_uuid are still the
                provenance handles */ ],
  "excerpts": [ /* unchanged */ ],
  "episode_fallback": [ /* unchanged */ ],
  "supersession_hints": [ /* unchanged */ ],
  "encrypted_bodies": [ /* unchanged */ ],
  "recall_telemetry": { /* unchanged */ },
  "citations": {        // <-- NEW (ADR-0016)
    "c1": { episode_uuid, fact_uuid, valid_at, asserted_at,
            extracted_quote, source_uri },
    ...
  }
}
```

## Wire surface — lab / med

`gnokee_lab_query` and `gnokee_med_query` add one field. Scalar lab
ops (min/max/avg/count) emit an empty map (zero rows → zero citations).

## Why it fits gnokee's red lines

- **Headless** — gnokee delivers the envelope, the consumer's LLM
  emits the `[cN]` markers. No UI shipped, no LLM hosted, no key held
  (AGENTS.md "do not" list intact).
- **No federation, no IPFS, no Solid** — `source_uri` is an opaque
  consumer string, not a federated content-address.
- **No auto-resolve** — citations PAIR WITH contradictions
  (ADR-0008 + ADR-0013 envelope); citing the contradicting fact's
  episode is explicit, never silenced. The host LLM decides how to
  present the contradiction; gnokee just surfaces both sides.
- **Bi-temporal-first** — every citation carries both axes. The
  whole point.

## Why it differs from peers

- vs NotebookLM `[1] = source_3.pdf`: gnokee adds `fact_uuid` +
  `valid_at` + `asserted_at`. The extraction-stage quote backfill
  closes the remaining gap.
- vs Pinecone KnowQL `confidence + source_uri`: gnokee adds two time
  axes; confidence is deferred to ADR-0019's amendment (recency
  proxy) once it lands on the citation envelope.
- vs GraphRAG per-claim provenance: gnokee delivers headlessly
  (no UI), bi-temporal-aware, MCP-native.

## Anti-patterns to avoid

- **Hallucinated `extracted_quote`.** Fill ONLY when the extraction
  stage produced a verbatim span. Synthesising from `FactStatement.text`
  or fuzzy-matching against the body violates the contract. A wrong
  quote is strictly worse than no quote.
- **Citing a fact without a `valid_at`.** Would defeat the
  bi-temporal point. Pydantic validator on `Citation` rejects naive /
  non-UTC datetimes (already enforced).
- **Auto-resolving cited-fact contradictions in the answer.** Citation
  envelope surfaces both sides; the host LLM presents them. gnokee
  never silences one side (AGENTS.md "do not" § auto-resolve).
- **Mixing citation keys across calls.** Each call gets a fresh
  `c1..cN` sequence — the keys are stable WITHIN a response, not
  across responses. Documented in the tool descriptions.

## Sequencing

- v0.5 — schema + wire envelope, `extracted_quote` everywhere null.
- v0.5.x — eval Spike Q42 cites-mismatch detector ships alongside
  (see `evals/spike_q42_cites_mismatch/`).
- v0.6 — extraction-stage backfill: rerun extraction with span
  tracking, populate `extracted_quote` for new ingest, backfill
  historical rows lazily on the maintenance pass (one-shot or
  on-demand per tenant). File as separate issue per Migration
  strategy in the issue body.
- Pairs naturally with ADR-0013 declarative envelope (#72) once that
  lands — both target the MCP read surface and the same caller-side
  schema.

## Out of scope

- **Per-tenant citation-format overrides.** v0.5 is single-default
  (`[cN]` documented, `[N]` accepted by graders).
- **Per-citation `confidence` field.** Deferred to ADR-0019 amendment
  once the recency-proxy decision is wired through the wire envelope.
  Today the proxy is on `FactStatement.confidence`; promoting it to
  `Citation.confidence` is a v0.5.x decision.
- **`source_uri` on the ingest surface.** Separate ingest-shape issue.
- **Citation diff detector for chained responses.** A v0.6+ feature —
  detect when the host LLM's `[c1]` in response 2 refers to a different
  episode than `[c1]` in response 1. Useful for long-running agent
  loops; not v0.5 scope.

## Cross-refs

- Tracking issue: [#76](https://github.com/gnokeelabs/gnokee/issues/76).
- Umbrella: [#71](https://github.com/gnokeelabs/gnokee/issues/71)
  competitive landscape 2026-Q2.
- Gates: ADR-0019 confidence-decay (#80, verdict
  `SHIP_RECENCY_AS_PROXY`); ADR-0013 declarative envelope (#72) —
  both target the same MCP read surface.
- New eval: `evals/spike_q42_cites_mismatch/` — answer-cites-mismatch
  detector. Pass criterion: detect when host LLM's claim does NOT align
  with the citation's quote.
- AGENTS.md "do not" list — no UI, no LLM hosting, no key holding, no
  auto-resolve. Citation envelope respects each.
- ADR-0001 (bi-temporal axes — `valid_at` vs `asserted_at` semantics).
- ADR-0004 (gnokee owns retrieval — citation envelope is the retrieval
  surface, not Graphiti's).
- ADR-0008 (contradiction storage — citation pairs with contradicting
  facts, both sides surfaced).
- Migration: `src/gnokee/storage/migrations/0013_episode_extracted_quote.sql`.
- Wire serialisation: `src/gnokee/citations.py` (pure builder),
  `src/gnokee/mcp.py` `_serialize_citations` (wire shape).
- Contract test: `tests/unit/test_citations_envelope.py`.
