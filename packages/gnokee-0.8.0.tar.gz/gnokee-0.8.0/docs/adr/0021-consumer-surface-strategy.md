# ADR-0021: Consumer surface strategy — halt first-party, template the rest

- **Status:** Accepted (2026-05-12). Three-tier consumer policy adopted;
  `gnokee-consumer-template` filed as sibling repo follow-up; no spike
  required — this is a scope-and-policy ADR, not a measurement one.
- **Date:** 2026-05-11 (drafted); 2026-05-12 (accepted)
- **Decider:** Vadim Yuzi
- **Context:** v0.4.0 (cf93700, 2026-05-10) and ADR-0020 (Obsidian
  adapter, `consumers/gnokee-obsidian/`, 2026-05-11) are the freshest
  surface changes. Sister product `noggin` is the second
  first-party consumer. The question raised after Obsidian shipped:
  *do we need more consumers?*

## Context

gnokee is a bi-temporal memory backend with a stable lib API
(`ingest_episode`, retrieval) and an MCP surface (`gnokee_query`,
`gnokee_ingest_episode`, `gnokee_recall`, `gnokee_lab_query`,
`gnokee_med_query`, `gnokee_wiki_export`, `gnokee_history_of`,
`gnokee_forget`). Two first-party consumers exist:

1. **noggin** — personal-AI CLI; dogfoods MCP + lib (sister product,
   Python, retires the v0.1 tag-cut gate per memory).
2. **gnokee-obsidian** — vault-as-source adapter, ADR-0020.

These two cover the two dominant capture patterns: structured CLI/agent
input (noggin) and unstructured note-app prose (Obsidian). Every
additional first-party consumer adds a matrix to support: Python
version × OS × lockfile × release cadence × user-facing UX bugs.
Meanwhile the MCP contract itself is still young — `gnokee_query`
(ADR-0013) landed in v0.5-staging branch, citation envelope (ADR-0016)
and confidence model (ADR-0019) shipped 2026-05-11. Hardening that
contract returns more per hour than building a third UI on top of it.

Candidates considered, in roughly descending leverage:

| Candidate | Use case | Risk if first-party |
|---|---|---|
| Browser clipper (Chrome/Firefox ext) | Capture web reading + receipts | Permissions UX, store review, MV3 churn |
| Photo/OCR (lab printout, receipt) | Feeds v0.2 lab/med write path | OCR quality varies wildly; vendor lock |
| Voice memo (Whisper local) | Hands-free capture | Audio + transcription pipeline = big surface |
| IDE plugin (Claude Code / Cursor) | ADR-style decision capture | Already covered by noggin via MCP |
| Email / Google Calendar bridge | Auto-ingest meetings, mail | OAuth tokens, vendor surface, privacy footgun |
| Slack / Discord bot | Team capture | Out of scope — gnokee is single-tenant per ADR-0004 |
| iOS / macOS Shortcuts action | Quick capture | Apple distribution = nontrivial |
| Apple Health / Withings bridge | Wearables off-ramp (ADR-0011) | Already off-ramped — consumer's job |

Most of these are not bad ideas. They are bad *first-party* ideas at
this stage of the project.

## Source-to-shape routing

A second question gets conflated with "which consumer should we build":
*where does data of shape X land in gnokee?* The answer is independent
of which tier owns the adapter — it follows from the data's shape, not
from who wrote the integration. Three shapes, one off-ramp, one
hard-no.

| Shape | Lands in | Examples | ADR |
|---|---|---|---|
| Prose | Episode write path (`ingest_episode`) | Note-app exports (Notion / Roam / Logseq / Bear / Joplin / Apple Notes / Evernote / OneNote / Day One / Obsidian), read-later clips (Readwise / Kindle / Pocket / Instapaper / bookmarks), chat / email dumps **after consumer-side summarisation** (mbox, WhatsApp, Telegram, iMessage `chat.db`, Slack / Discord) | ADR-0004 |
| Structured rows | `*_record` sibling table | Labs, meds, transactions (`transaction_record` future ADR), calendar `.ics`, contacts `.vcf` | ADR-0009 / ADR-0010 |
| High-volume timeseries | Off-ramp — consumer-side store, daily/weekly summary as Episode | Wearable raw (Strava / Garmin / Apple Health / Withings / Oura / Whoop / Fitbit), scrobbles (Spotify / Last.fm), location history, YouTube watch history | ADR-0011 |
| Multi-shape archive | Fan out per-bucket inside the archive | Google Takeout, Meta data download, LinkedIn / X archive, Reddit data request | n/a — Tier 3 |
| Secrets / encrypted | **Never ingest** | Password manager exports, raw API keys, encrypted vaults gnokee cannot decrypt | AGENTS.md "do not" list |

Two cross-cutting patterns this surfaces:

- **Chat / email dumps are prose only after summarisation.** Ingesting
  one Episode per message is the wrong shape — volume swamps recall,
  signal density is low. Template documents the
  summarise-then-ingest pattern; raw chat ingest is a footgun the
  template will refuse to demo.
- **SQLite-as-source is a distinct adapter pattern** (open
  sqlite read-only → query → map rows), separate from the file-walk
  pattern Obsidian uses. iMessage `chat.db`, Apple Notes
  `NoteStore.sqlite`, Bear `database.sqlite`, browser history, and
  Anki `.apkg` all fit it. Template ships one worked example.

If a proposed source does not fit any of these rows, that is a signal
to write an ADR before writing the adapter — not the other way
around.

## Decision

**Halt new first-party consumers after gnokee-obsidian + noggin.**
Publish a `gnokee-consumer-template` repo (Tier 2) and a documented
three-tier policy. Reassess at v0.6.

### Three-tier consumer policy

- **Tier 1 — first-party, supported.** `noggin`, `gnokee-obsidian`.
  These two stay because each falsifies a distinct capture pattern
  (structured-agent vs unstructured-prose) and each has a corresponding
  spike series (noggin via v0.1–v0.4 release evals, Obsidian via Q14).
  Adding a Tier-1 consumer requires its own ADR and a passing spike.
- **Tier 2 — first-party scaffold, unsupported runtime.**
  `gnokee-consumer-template` — a small repo with: skeleton
  `pyproject.toml`, MCP client wiring, frontmatter→`EpisodeIn`
  conversion helper, `our_id` stability pattern (Q1 dup-trap dodge),
  `corrects:` plumbing (v0.2.1 contract), idempotency notes, a
  `make eval` target that runs a minimal A/B spike against a direct
  ingest baseline. Maintained for API breakage only; no UX support.
- **Tier 3 — community.** Listed in `docs/integration_patterns.md`
  with a one-line "use case + repo link". No promise of
  compatibility; no PRs accepted into `gnokee/` for them. Authors own
  their lockfile, release cadence, and bug triage.

### Promotion path

A Tier-3 consumer is eligible to be promoted to Tier 1 if **all** hold:

1. ≥3 unrelated users running it in anger (link to issues / threads).
2. An ADR proposing promotion, with a Q-series spike measuring
   recall-parity vs direct ingest (Q14 template applies).
3. A maintainer willing to own it for ≥one release cycle.

This is intentionally a high bar. The default answer to "should we
adopt X?" is **no**.

## Consequences

### Adopted

1. **No new first-party consumers in v0.5 or v0.6.** Issue triage will
   close "please ship X consumer" requests with a pointer to this ADR
   and the template repo (once published).
2. **`gnokee-consumer-template` lands as a sibling repo**
   (`gnokeelabs/gnokee-consumer-template`), not inside the monorepo.
   Keeps `consumers/` reserved for Tier-1 packages and avoids
   confusing PyPI namespacing.
3. **`docs/integration_patterns.md` gains a "Community consumers"
   section.** Empty at first; populated as projects link in.
4. **The MCP contract becomes the public artifact, not any single UI.**
   v0.5 effort spent on hardening `gnokee_query`,
   per-claim citations (ADR-0016), and the confidence model
   (ADR-0019) instead of building a third surface.

### Deferred

- **Photo/OCR ingest helper.** Ties into v0.2 lab/med write path;
  worth its own ADR + spike once the OCR vendor question is settled.
  Likely v0.6+ unless a user pushes back.
- **Mixed-folder ingest (`.docx` / `.pdf` / `.html` / `.eml` / `.rtf`
  / `.xlsx` / `.csv` / images, all in one folder).** Belongs in
  Tier 2 (`gnokee-consumer-template`), not Tier 1, because the work
  is per-file-type pre-conversion, not memory-backend work. Per-type
  guidance:
  - **Text-bearing docs** (`.docx` / `.pdf` / `.html` / `.eml` /
    `.rtf`): pandoc / marker / docling → `.md`, then re-use the
    Obsidian adapter pipeline. Adapter does not care whether `.md`
    was hand-written or converted.
  - **Images / scans**: same class as the photo/OCR deferral above;
    OCR vendor question gates this.
  - **Spreadsheets** (`.xlsx` / `.csv`): two sub-cases. If the
    columns are structured-clinical (lab panels, med schedules,
    transactions) the right path is the existing `lab_record` /
    `med_record` write paths or a new `*_record` sibling table per
    the ADR-0009 / ADR-0010 pattern — *not* an `EpisodeIn` row per
    spreadsheet row. If the spreadsheet is prose-in-cells (meeting
    notes, journal), pandoc → markdown → Obsidian adapter. The
    template repo documents both branches.
- **Browser clipper.** Highest user-visible leverage of the deferred
  set; lowest first-party leverage because the bottleneck is browser
  extension UX, not gnokee semantics. Recommend a Tier-3 community
  project; revisit if it reaches the promotion bar.
- **IDE plugin (Claude Code / Cursor).** Already reachable via MCP
  from any agent runtime. Building a dedicated plugin is UX work, not
  memory-backend work — out of scope.

### Not adopted

- **Voice memo first-party.** Audio + transcription is a separate
  product; gnokee should not vendor a Whisper runtime any more than
  it vendors an LLM (ADR-0001 / ADR-0004 boundaries).
- **Slack / Discord bot.** Multi-user team capture violates
  single-tenant assumptions in ADR-0004; not a build-vs-buy question,
  it is a scope question.
- **Email / calendar OAuth bridges first-party.** Token storage =
  key-holding, which gnokee refuses by charter (AGENTS.md "do not"
  list).
- **Cloud-drive OAuth bridges first-party** (Google Drive API,
  Dropbox API, iCloud CloudKit, Microsoft Graph). Same class as
  email/cal: refresh tokens = key-holding = charter break.
  Orthogonal case worth naming explicitly so future "ship gdrive
  consumer" requests close fast: a cloud drive **mounted as a local
  folder** by its native sync daemon (Google Drive for Desktop,
  Dropbox client, iCloud Drive, OneDrive client) is *not* a new
  consumer — the Obsidian adapter walks any local path and does not
  inspect the underlying filesystem. Recommend OS-sync mount over
  API integration whenever the user has the choice.
- **Wearables / Health bridges first-party.** Already off-ramped by
  ADR-0011 (Q9). Consumer owns the raw stream; gnokee owns daily
  summaries the consumer hands in via `ingest_episode`.

## Open questions surfaced by this work

Resolved 2026-05-11 during ADR debate; left here for traceability:

- **Q21.1: template repo skeleton choice.** **Resolved → Python-only.**
  `gnokee-consumer-template` ships as Python-only at first; both
  Tier 1 consumers (`noggin`, `gnokee-obsidian`) are Python so the
  skeleton matches the supported pattern. A TypeScript variant is
  added only if a real browser-extension consumer appears.
- **Q21.2: reassessment trigger.** **Resolved → keep proposed default.**
  This ADR holds until v0.6 release scope is being shaped, OR until
  a Tier-3 consumer hits the promotion bar above, whichever comes
  first. No calendar trigger.
- **Q21.3: do we need a public list of refused consumers?**
  **Resolved → Yes, in `faq.md` (plus AGENTS.md + SECURITY.md for the
  secrets sub-class).** `faq.md` gains a "Will gnokee ship a Slack
  bot / gdrive / voice-memo consumer?" entry that one-liners the
  refusal and links here. AGENTS.md `do not` list and SECURITY.md
  carry the "never ingest secrets / encrypted vaults" hard-no rule
  with charter and threat-model framing respectively.
