# ADR-0019: confidence-decay function for gnokee facts

- **Status:** Accepted — verdict `SHIP_RECENCY_AS_PROXY` confirmed by stage-2
  spike Q13.1 (2026-05-12; see § Stage-2 spike verdict). Function B
  (recency-only Ebbinghaus) ships as the gnokee confidence model. Composite
  function C failed the calibration gate at both N=13 (Q13) and N=31 (Q13.1).
  ADR-0019 § Follow-up caveat is now **closed**. No further composite-confidence
  stage is planned until a new primitive (e.g. per-fact cosine scores via #89)
  changes the calibration picture.
  **Amended 2026-05-12** — § LongMemEval-S publish stance: `DECLINE_TO_PUBLISH`
  for v0.5; defer re-spike to v0.6 (closes [#81](https://github.com/gnokeelabs/gnokee/issues/81)).
  **Amended 2026-05-12** — § Stage-2 spike verdict: Q13.1 N=31 confirms
  `KEEP_RECENCY_PROXY`; closes ADR-0019 § Follow-up (closes
  [#88](https://github.com/gnokeelabs/gnokee/issues/88)).
- **Date:** 2026-05-11 (original); amended 2026-05-12 (#81 verdict, #88 verdict)
- **Decider:** Vadim Yuzi
- **Context:** Open question Q1 from competitive-landscape umbrella
  [#71](https://github.com/gnokeelabs/gnokee/issues/71), tracking
  issue [#80](https://github.com/gnokeelabs/gnokee/issues/80). Ranked
  #1 by roadmap impact among the five 2026-Q2 open questions because
  it gates two v0.5 adoption candidates (#72 declarative envelope,
  #76 per-claim citation envelope).

## Context

gnokee's MCP read responses (`gnokee_recall.facts[].confidence`,
`gnokee_lab_query`, `gnokee_med_query`) carry a `confidence ∈ [0,1]`
field today, populated as `null` or a Graphiti-supplied edge confidence.
ADR-0013 (issue #72) wants to expose `confidence_floor` on the
declarative envelope; ADR-0016 (issue #76) wants per-citation
`confidence`. Both adoption candidates need a defensible semantics
for what the number actually means — otherwise gnokee either:

1. Ships **binary** confidence (asserted vs not) and undersells the
   bi-temporal contract that already differentiates gnokee from peers.
2. Ships a **reranker score** (cosine + BM25 + cross-encoder fusion)
   and matches Pinecone's KnowQL `confidence` — losing gnokee's
   contradiction-aware, supersession-aware story.
3. Ships **nothing** (`confidence: null` everywhere) and lets ADR-0013 /
   ADR-0016 expose the field as nullable until the model lands. **This
   is an acceptable v0.5 outcome** if the spike does not produce a
   defensible function.

This ADR exists to make option 3 a deliberate decision rather than
silent drift.

## What other systems publish (2026-Q2 sweep)

| System | Confidence model | Contradiction-aware? | Bi-temporal-aware? |
|---|---|---|---|
| Pinecone KnowQL | reranker fusion (cosine + BM25 + cross-encoder) | No | No |
| GCP Memory Bank | opaque; winner-take-all consolidation | No | No |
| NotebookLM | binary trust ("the source said so") | No | No |
| Microsoft Fabric IQ | no public confidence model | n/a | n/a |
| A-MEM (NeurIPS 2025) | names Ebbinghaus, gives no formula | No | Recency only |
| Rohit-G LLM-Wiki-v2 gist | asks for it; no answer in scope | n/a | n/a |

Source: synthesis at `research/competitive_landscape_2026-05-10.md`,
dossiers `research/_dossier_pinecone_nexus.md`,
`research/_dossier_gcp_knowledge.md`,
`research/_dossier_notebooklm.md`,
`research/_dossier_umbrella_adjacent.md`.

**Observation:** every peer either dodges the question (NotebookLM,
Fabric IQ, Memory Bank) or publishes a reranker score under a
confidence label (Pinecone). Nobody surfaces a contradiction-aware
or bi-temporal-aware confidence. Adopting one is differentiator-positive
if defensible; differentiator-neutral if it just looks like noise.

## What gnokee already has that a model can build on

- **`fact_contradiction`** symmetric table (ADR-0008) — explicit
  contradiction load is queryable; no inference required.
- **Supersession edges** (`corrects:`, Stage 6 ingest) — refinement
  vs supersede vs contradiction verdicts already labelled per pair.
- **Bi-temporal axes** (ADR-0001) — `valid_at` (world-time) and
  `asserted_at` (source-tx-time) on every fact + episode.
- **Reinforcement count** — derivable today as
  `COUNT { (e:Episodic)-[m:MENTIONS]->(f:EntityEdge) }` per fact
  group_id, no schema change.

The four primitives a confidence function would compose are already
present in the gnokee stack. The spike is about *choosing the
composition*, not about new storage.

## Candidate functions for the spike

Three families, evaluated on the corpora named under § Spike.

### A. Constant baseline

```
confidence(fact) = 1.0 if active else null
```

- Pros: trivial; matches NotebookLM's binary semantics.
- Cons: undersells bi-temporal contract; identical to today's
  Graphiti-default edge confidence.

### B. Recency-only (Ebbinghaus-style)

```
confidence(fact) = exp(-Δt / half_life_days)
                   where Δt = now() - valid_at
                         half_life_days = 365  (default)
```

- Pros: monotone, well-known curve; A-MEM cites this family.
- Cons: ignores reinforcement + contradictions. A fact asserted
  ten times still gets the same decay as a single mention.

### C. Contradiction-aware composite (working proposal)

Working formula — spike output should test exact coefficients:

```
confidence(fact)
  = clip(0, 1,
      reinforcement_score
        - 0.5 * contradiction_score
        + 0.2 * recency_factor
    )

reinforcement_score = log(1 + n_supporting_episodes) / log(1 + 10)
contradiction_score = n_active_contradictions / max(1, n_supporting_episodes)
recency_factor      = exp(-Δt / 365)
```

Where `n_active_contradictions` counts contradictions at the
caller's `as_of` (the bi-temporal pin) — superseded contradictions
don't subtract.

- Pros: contradiction-aware (gnokee differentiator); reinforcement
  rewards multi-source corroboration; bi-temporal-aware via
  `recency_factor + as_of`-respecting contradiction count.
- Cons: coefficient tuning; harder to explain in a tool description;
  may correlate so poorly with human grading that we're better off
  with C.

### D. Source-trust prior (future, NOT in scope for v0.5)

Caller-supplied per-topic prior (`clinical.lab` > `email` >
`scraped_web`). Defers because the consumer surface for that prior
doesn't exist yet (would need `tenant_metadata` table). Listed for
completeness; spike does not test this.

## Spike plan

`evals/spike_q13_confidence/` — small-medium spike.

### Corpora

- **Q1, Q3, Q4, Q7, Q8 reused** — known-good gnokee corpora. Provides
  baseline behaviour on non-contradiction-heavy data.
- **Hand-curated contradiction corpus (new)** — 15–20 episodes,
  5 explicit contradictions, 3 supersession chains, 2 entirely-stale
  facts. Authored against personal-AI shape (per `noggin` dogfood).

### Metrics

- **Accuracy on "is this fact still believed?"** — binary classification
  using a 0.5 threshold against hand-graded labels. Higher = better.
- **Spearman correlation with hand-graded confidence** — per-fact
  hand-graded `[0, 1]` against function output. Higher = better.
- **Calibration plot** — bucketed predicted vs actual believed-rate.
- **Latency overhead** — confidence computation against the existing
  retrieval p50.

### Harness shape

Follow `evals/spike_q*/run.py` convention (`GROUP_ID` constant,
`--skip-ingest`, `results/<utc-stamp>.json`, per-question notes).

## Decision matrix (post-spike fill-in)

| Function | Accuracy | Spearman | Calibration | Verdict |
|---|---|---|---|---|
| A. Constant 1.0 | _tbd_ | _tbd_ | _tbd_ | _tbd_ |
| B. Recency-only | _tbd_ | _tbd_ | _tbd_ | _tbd_ |
| C. Composite | _tbd_ | _tbd_ | _tbd_ | _tbd_ |

**Decision rule** — pick C *only if* it beats both A and B by
≥ +0.10 Spearman *and* its calibration plot stays within ±0.15 of
the diagonal. Otherwise:

- If B beats A but not C's threshold → ship B, document as "recency
  proxy" not "confidence model".
- If neither B nor C clears A meaningfully → ship `confidence: null`
  in v0.5 (see § "Acceptable null outcome").

## Acceptable null outcome

If the spike produces no function that clears the thresholds:

- MCP read tools (`gnokee_recall`, `gnokee_lab_query`,
  `gnokee_med_query`, future `gnokee_query`) return `confidence: null`
  in v0.5.
- Tool descriptions document that absence is **deliberate** — gnokee
  refuses to invent a number it cannot defend. This is the
  NotebookLM-class trust posture, framed as a feature not a regression.
- ADR-0013 / ADR-0016 ship with `confidence` typed as nullable but
  populated with `null` until ADR-0019 amendment ships a model.

This outcome is **better** than shipping a misleading number.
Anti-pattern hard-list (§ below) is the constraint.

## Anti-patterns the spike must avoid

- **Reranker score in disguise.** A composite that turns out to be
  dominated by cosine + BM25 is just Pinecone's `confidence` with
  more steps. Spike must include a "model-vs-rerank" delta plot.
- **LLM-supplied confidence.** Asking the consumer's LLM to grade
  its own facts violates the no-key-holding contract (AGENTS.md "do
  not" list) and is non-deterministic.
- **Time-only decay.** Ebbinghaus is a hypothesis, not a verdict —
  ship only if it actually correlates better than constant 1.0.
- **Auto-resolution disguised as confidence.** A confidence model
  that lets the consumer LLM ignore one side of a contradiction is
  a back-door violation of ADR-0008 (no auto-resolve). The model
  must rank, never silence.

## Sequencing

- Resolve **before** ADR-0013 (#72) and ADR-0016 (#76) ship.
- Spike scope: small/medium — single eval dir, hand-curated corpus,
  three candidate functions, ADR amendment with verdict.
- Verdict feeds back into this ADR (amendment section) — the ADR
  moves Proposed → Accepted only when the verdict lands.

## Out of scope

- Source-trust prior (option D). Defer to a follow-up ADR once
  `tenant_metadata` exists.
- Per-tenant confidence-model overrides. v0.5 is single-default.
- Confidence for typed clinical reads beyond direct row-level
  `value_numeric` + `abnormal_flag` — those carry their own bi-temporal
  validity independent of the fact-graph confidence model.

## Spike verdict (2026-05-11)

`evals/spike_q13_confidence/` ran end-to-end against the live gnokee
stack with 20 corpus episodes ingested under `group_id=spike_q13_confidence`.
First pass (N=7 effective) failed to match 6 / 13 probe fragments because
graphiti did not extract literal numeric phrases ("5.1 mmol", "25 mg",
"58 bpm", …) as entities or RELATES_TO facts. Probes were rewritten to
target graphiti's actual emission surface (`Volkswagen Golf`, `metoprolol
succinate`, `knee procedure`, `remote contract`, `Portuguese`, `Cascais
Family Practice`) — the rewrite measures the same confidence-axis signal
on N=13 valid probes.

### Results

Per-run JSON dumps written locally to `evals/spike_q13_confidence/results/`
(gitignored per repo-wide `evals/**/results/` rule — summary inlined here
for the durable record):

| Run | N | Spearman: constant / recency / composite | cal_max | reranker_delta | Verdict |
|---|---|---|---|---|---|
| `20260511T172958Z` | 7 | 0.00 / -0.13 / **+0.25** | 0.43 / 0.30 / 0.32 | +0.38 | SHIP_NULL (calibration gate) |
| `20260511T173441Z` | 13 | 0.00 / **+0.26** / +0.21 | 0.38 / 0.41 / 0.29 | -0.05 | **SHIP_RECENCY_AS_PROXY** |

Sign flip on N=7 → N=13 is informative: the composite's contradiction +
reinforcement terms helped on the small subset that happened to include
the corpus's contradiction-laden probes, then *reverted* once the spike
included single-mention low-recency facts where composite penalised
ones humans still rated mid-credible (knee procedure, Portuguese,
remote contract).

### Decision rule fire (per § Decision matrix)

- Composite (function C): Spearman delta vs constant = +0.21 (< +0.10
  threshold — actually clears it; first fail), but calibration max =
  0.29 (> 0.15 band). **C does NOT clear `SHIP_COMPOSITE` because of
  calibration.** Decision rule then asks whether B beats A meaningfully.
- Recency (function B): Spearman delta vs constant = +0.26 (>> 0.05
  threshold). **B fires `SHIP_RECENCY_AS_PROXY`.**

### What ships in v0.5

- MCP read tools (`gnokee_recall`, `gnokee_lab_query`, `gnokee_med_query`,
  future `gnokee_query`) populate `confidence` using function B:
  `exp(-Δt_days / 365)` where `Δt = caller_as_of - fact.valid_at`.
- **Tool descriptions document the field as a *recency proxy*, NOT a
  calibrated confidence score.** Cal_max = 0.41 means a fact tagged
  `confidence=0.7` could actually be believed by ~30–50% of users at
  that point. gnokee surfaces the number with that caveat in plain
  language — consumers do not get to claim it as a probability.
- ADR-0013 (#72) `confidence_floor` parameter interpretation: applied
  on the recency-proxy value. Documented as "minimum age-credibility
  cutoff".
- ADR-0016 (#76) per-citation `confidence` field: same proxy. The
  citation envelope additionally surfaces `valid_at` so consumers can
  ignore the proxy and compute their own decay if they prefer.

### What does NOT ship

- Function C (contradiction-aware composite). Failed calibration gate at
  N=13. Reinforcement + contradiction signal exists (composite has
  highest calibration *among* the three) but its Spearman lost the
  delta race. Reopen post-v0.5 with a larger corpus + recalibrated
  coefficients.
- A "confidence" framing in MCP tool descriptions. The field is named
  `confidence` for ADR-0013 / ADR-0016 schema compatibility, but every
  surfacing point describes it as a recency proxy. NotebookLM-class
  posture downgraded one notch — we surface a hint, not a probability.

### Follow-up (post-v0.5)

- **Stage-2 spike** (`spike_q13.1_confidence_v2/`) — N=30+ corpus, broader
  domain mix (clinical labs + meds + personal), recalibrate composite
  coefficients (`COMPOSITE_CONTRADICTION_COEF`, `COMPOSITE_RECENCY_COEF`,
  `COMPOSITE_REINFORCEMENT_NORM`). File as a v0.6 candidate, not v0.5
  scope.
- **Real `cosine_top1` now available** — the recency-as-cosine-proxy
  shortcut used in this spike is superseded by issue #89, which ships
  `cosine_top1: float | None` on every `FactStatement` behind the opt-in
  flag `include_cosine_top1=True` (both Python API and MCP `gnokee_recall`
  tool). Similarity is `1 - pgvector_cosine_distance` (cosine_ops,
  `<=>` operator), clamped to [0, 1]. `None` when the flag is off (default
  — keeps wire shape stable) or when the fact arrived via the episode-cosine
  fallback Path A and the episode had no ANN counterpart. The recency-proxy
  framing remains the **default** `confidence` story until #88 (Q13.1
  spike) decides the composite.
- **Graphiti fragment-matching** — Q13 ran into the literal-numeric
  extraction gap (issue [#90](https://github.com/gnokeelabs/gnokee/issues/90)).
  6 / 13 Q13 probes returned "no fact nodes found" because graphiti
  paraphrased narrative and dropped literals like `"58 bpm"`,
  `"5.1 mmol"`, `"25 mg"`, `"50 mg"`, `"fully remote"`, `"car-free"`.
  **Resolution: Accept (option 1 of 4 in #90).** Gnokee's retrieval
  contract is "narrative facts + lazy provenance"; literal-numeric and
  state-adverbial retrieval is covered by triple-coverage already:
  clinical values land in `lab_record` (ADR-0009), dose changes land
  in `med_record` (ADR-0010), and narrative literals land in
  `excerpts[]` (Q3) + `episode_fallback[]` (ADR-0012 Path A). No
  custom extractor, no sibling regex/NER pass. Spike-author guidance
  added to [`docs/evals/methodology.md`](../evals/methodology.md)
  § "Authoring a new spike": probes target extracted facts, never
  literals that may not survive graphiti's pass.

## LongMemEval-S publish stance (#81 verdict, 2026-05-12)

[#81](https://github.com/gnokeelabs/gnokee/issues/81) asked for a
credible LongMemEval-S target for v0.5 publish vs defer. Verdict:
**`DECLINE_TO_PUBLISH` on LongMemEval-S for v0.5; defer re-spike to v0.6
after retrieval-moving primitives land.**

### Evidence

| Source | gnokee recall@5 | strict | N |
|---|---|---|---|
| Q10 `stageC_30q20s` (2026-05-10, v0.3-staging stack) | **0.10** | 0 / 30 | 30 |
| Q10 smoke 5Q × 5-session (2026-05-12, v0.5 main, envelope OFF) | 2 / 2 in-window (gold inside 5-session truncation) | n/a (no judge in this arm) | 5 |
| Issue #81 recommended target | ≥ 0.60 | — | — |
| ByteRover (2026-Q2 SOTA on LongMemEval-S) | — | 0.928 | 500 |
| Mem0 published | — | 0.934 | 500 |

Per-class on the 2026-05-10 baseline: gnokee `knowledge-update` 0.40,
`multi-session` 0.20, the four single-session subclasses +
`temporal-reasoning` all **0.00**. `basic-memory` beat gnokee at 0.20
overall on the same corpus shape; `graphiti-alone` was 0.00.

### Architectural read — re-spike has no signal on recall@5

Four retrieval-relevant commits shipped between the 2026-05-10 judged
file and v0.5 main:

| Commit | Effect on `recall()` primitive |
|---|---|
| `9c1810e` ADR-0013 envelope | Adapter-opt-in (`GNOKEE_Q10_USE_QUERY_ENVELOPE=1`). Envelope ON composes the *same recall pipeline* under the envelope per `gnokee_adapter._query_via_envelope` docstring — `retrieved_episode_external_ids` order is identical to envelope OFF. Response shape changes; retrieved set does not. **Zero signal on recall@5 by construction.** |
| `f6b9362` ADR-0016 citations | Additive on response payload. `retrieved_episode_external_ids` order unchanged. |
| `f0c44c4` Q11 calibration | Eval-side tooling only (`spike_q11_calibration/`). No retrieval-path code. |
| `83483be` #90 resolve | Docs only. |

A v0.5 envelope-on re-spike would reproduce 0.10 by construction.

### Re-spike attempt and TPM-tier constraint

Two attempts at `stageC_30q20s` envelope-on were made on 2026-05-12 to
confirm the architectural read empirically:

| Run | `--per-sut-concurrency` | Outcome |
|---|---|---|
| `stageC_v05_envOn` | 4 (run.py default) | 4 qids `ingest_failure`, killed at qid 5 / 30. `graphiti_core.add_episode` raised hard `RateLimitError` on ~15 K-token extraction bursts against the tier-1 200 K TPM ceiling. |
| `stageC_v05_envOn_r2` | 2 | First qid (`01493427`) failed identically. Killed. |

`graphiti_core.add_episode` propagates `RateLimitError` without
retry-with-backoff. v0.5 at-scale re-spike on tier-1 200 K TPM is
infeasible until either (a) the account tier raises TPM, (b)
`graphiti-core` gains retry-with-backoff (upstream, not gnokee scope),
or (c) corpus shrinks to the point where the architectural read above
is the load-bearing evidence rather than the measurement.

The 2026-05-12 smoke (5Q × 5-session) completed clean — confirms the
v0.5 ingest + retrieval stack is functional. The constraint is corpus
size on tier-1 TPM, not a v0.5 regression.

### Decision

**`DECLINE_TO_PUBLISH`** for v0.5. Rationale:

1. 2026-05-10 baseline (0.10 recall@5) is **6×** under issue #81's
   recommended ≥ 0.60.
2. Publishing 0.10 against `basic-memory`'s 0.20 on identical corpus is
   anti-marketing.
3. No v0.5 retrieval-primitive change moves the number (architectural
   read above).
4. ByteRover 92.8 % / Mem0 93.4 % are structurally out of reach without
   primitives that have not yet landed.
5. Per `docs/evals/methodology.md` and the issue #81 § Anti-patterns
   list, gnokee publishes measured numbers or nothing — no self-rolled
   benchmark dodge (Pinecone anti-pattern), no cherry-picking, no SOTA
   claim without ADR-anchored evidence.

What gnokee publishes for v0.5 instead:

- The **[#109](https://github.com/gnokeelabs/gnokee/issues/109) Q17
  refusal-posture spike** (NotebookLM-class refusal bar) ships
  independently of LongMemEval-S retrieval recall, with its own publish
  surface.
- The **ADR-0013 declarative envelope + ADR-0016 per-claim citations**
  ship as *contract* advances, marketed as such — neither competes on a
  LongMemEval-S number.
- The **ADR-0019 confidence model** (this ADR) ships with its
  recency-proxy framing as documented above.

### Defer to v0.6

LongMemEval-S re-spike reopens in v0.6 only after retrieval-moving
primitives land — at least one of:

- [#88](https://github.com/gnokeelabs/gnokee/issues/88) composite-
  confidence stage-2 (corpus + coef sweep) — may reorder retrieval
  emission.
- [#89](https://github.com/gnokeelabs/gnokee/issues/89) per-fact
  `cosine_top1` surface — enables real rerank-disguise check +
  retrieval-tuning grip.
- [#102](https://github.com/gnokeelabs/gnokee/issues/102) Q15
  cross-`group_id` semantic bridges — new retrieval primitive, may
  unlock cross-session recall gains.

If none of #88 / #89 / #102 ship by v0.6 release shaping, the re-spike
defers further; this ADR will land another `DECLINE_TO_PUBLISH`
amendment.

### Closes

[#81](https://github.com/gnokeelabs/gnokee/issues/81).

## Stage-2 spike verdict (2026-05-12, Q13.1)

`evals/spike_q13.1_confidence_v2/` ran end-to-end against the live gnokee
stack. 45 corpus episodes ingested under `group_id=spike_q13v2_confidence`;
36 probes attempted; 31 effective (5 missed extraction: "home-renovation",
"fasting glucose", "remote work", "annual check", "sulfonamide allergy" —
same class of literal/compound-phrase gap as Q13 issue #90 accepted).

### Results

Per-run JSON: `evals/spike_q13.1_confidence_v2/results/20260511T215702Z.json`
(gitignored — summary inlined here for durable record).

| Function | N | Spearman | Accuracy@0.5 | Cal_max |
|---|---|---|---|---|
| A. Constant | 31 | 0.0000 | 0.5484 | 0.4516 |
| B. Recency | 31 | **0.6073** | 0.6452 | 0.5468 |
| C. Composite (default coefs) | 31 | 0.4495 | 0.6452 | 0.5855 |

### Coefficient sweep (48 variants)

| Gate | Best variant | Value | Other gate value |
|---|---|---|---|
| Best Spearman | cc=0.25, rc=0.5, rn=10 | 0.6236 | cal_max=0.391 (FAIL gate) |
| Best cal_max | cc=0.25, rc=0.3, rn=20 | 0.1948 (FAIL gate) | spearman=0.4983 |
| Best accuracy | cc=0.25, rc=0.2, rn=5 | acc=0.7097 | cal_max=0.7804 |

**Gate-clearers (Spearman delta ≥ 0.10 AND calibration ≤ 0.15): 0 of 48 variants.**

The calibration gate (≤ 0.15) was never cleared by any composite variant in
the sweep. The best-calibration variant hit 0.1948 — 30% above the gate. The
best-Spearman variant cleared the delta gate (+0.62 over constant 0.0) but its
calibration was 0.391.

### Decision rule fire

- Composite (best sweep variant): Spearman delta = +0.62 (clears the +0.10
  gate), but calibration max = 0.391 (> 0.15 band). **No variant clears
  both gates simultaneously. `SHIP_COMPOSITE` does NOT fire.**
- Recency (function B): Spearman = 0.6073 (+0.6073 over constant 0.0 >>
  0.05 threshold). **`KEEP_RECENCY_PROXY` fires.**

### Interpretation

The calibration failure is structural. The composite produces high confidence
scores for multi-mention facts regardless of whether humans grade them as
believed. For example `Lisbon` (19 supporting episodes in the graph — Graphiti
anchors many episodes around the Lisbon move) scored composite=1.0 while it is
also the fragment for non-believed probes at different as_of pins. The
reinforcement term dominates and overrides the hand-graded confidence gradient.
Recency avoids this: it responds only to elapsed time and does not
accumulate graph artefacts.

### What stands

- Function B (`exp(-Δt / 365)`) ships as the gnokee confidence model.
- `SHIP_RECENCY_AS_PROXY` verdict from Q13 confirmed.
- ADR-0019 § Follow-up section is **closed**. No stage-3 composite spike
  is planned until a new primitive changes the calibration picture.
- ADR-0013 / ADR-0016 recency-proxy framing **retained** (no amendment
  needed — the framing was already correct).

### Closes

[#88](https://github.com/gnokeelabs/gnokee/issues/88) — composite-confidence
stage-2 spike.

## Cross-refs

- Tracking issues: [#80](https://github.com/gnokeelabs/gnokee/issues/80)
  (confidence model), [#81](https://github.com/gnokeelabs/gnokee/issues/81)
  (LongMemEval-S publish stance, closed by this ADR's 2026-05-12 amendment),
  [#88](https://github.com/gnokeelabs/gnokee/issues/88) (stage-2 spike,
  closed by 2026-05-12 amendment).
- Umbrella: [#71](https://github.com/gnokeelabs/gnokee/issues/71)
  competitive landscape 2026-Q2.
- Gates: [#72](https://github.com/gnokeelabs/gnokee/issues/72)
  (ADR-0013), [#76](https://github.com/gnokeelabs/gnokee/issues/76)
  (ADR-0016).
- ADR-0001 (bi-temporal axes), ADR-0008 (contradiction storage),
  ADR-0010 (med supersession adopt-with-gaps), ADR-0012 (cross-tool
  eval verdict — the LongMemEval-S Stage-C data this amendment cites).
- AGENTS.md "do not" list — no auto-resolve, no key holding, no
  LLM-graded confidence.

## § LongMemEval-S publish stance refresh (2026-05-15)

Issue #81's `DECLINE_TO_PUBLISH` verdict (2026-05-12) cited "recall at-ceiling on stored data, not broken." Q18 (2026-05-12, [spike](../../evals/spike_q18_recall_at_k_diagnostic/README.md)) confirmed: the 0.10 recall@5 baseline is 100% an ingest-storage gap, not a retrieval defect.

v0.6 (ADR-0023, Z1 storage-first) closes the storage gap. Once v0.6 ships and the Q18 re-spike passes the acceptance thresholds (≥ 14/17 measurable in storage, ≥ 80% recall@5 on measurable per Issue #111), the LongMemEval-S publish stance lifts from `DECLINE_TO_PUBLISH` to `PUBLISH_POST_Z1`.

The publish itself is a separate post-v0.6 PR. The numbers to publish: `gnokee recall@5 on measurable (17-row denominator)`, with a methodology note that the 30-row published baseline conflates corpus truncation (13 structurally unrecoverable rows) with retrieval-relevant signal.

Cross-ref: ADR-0023, Issue [#111](https://github.com/gnokeelabs/gnokee/issues/111), Issue [#81](https://github.com/gnokeelabs/gnokee/issues/81).
