# ADR-0024: Ingest crash-recovery journal — append-only Postgres replay log

- **Status:** Accepted
- **Date:** 2026-05-16 (Proposed); 2026-05-16 (Accepted, impl PR #129)
- **Driver:** Issue [#122](https://github.com/gnokeelabs/gnokee/issues/122)
- **Supersedes:** none
- **Amends:** ADR-0023 (extends the two-store write-coordination story with a Postgres-side durability log)

## Context

ADR-0023 (v0.6 Z1-B) closed the *Graphiti half* of gnokee's two-store ingest coordination problem: on Graphiti `add_episode` failure, the Episodic + `content_embedding` already exists in Postgres, and `IngestReceipt.extraction_deferred=True` flags rehydration via `maintenance.run_deferred_extraction`.

The *Postgres half* still has no replay log. `IngestPipeline.ingest()` writes Stage 4 (Neo4j lite-Episodic) and Stage 5 (Postgres txn covering `episode_metadata`, `content_embedding`, `content_text`, `episode_body_encrypted`, `lab_record`, `med_record`) in sequence. If the process crashes between Stage 4 success and Stage 5 commit, the Episodic node lands in Neo4j with no Postgres row keying it. Today's recovery is "consumer re-calls `ingest_episode`; `(tenant_id, our_id)` idempotency absorbs the dup" — works on the happy path, but offers zero introspection into which stage tripped and no guarantee the orphan Neo4j node is reaped.

This is a real surface: the v0.6 Z1-B integration tests (`tests/integration/test_ingest_z1.py`) exercise Stage 4 + Stage 5 ordering but assume both run in the same process. Container kills, OOM, or `KeyboardInterrupt` between the two leaves dangling state that today's MCP read path can land on (Episodic node visible to Cypher recall Stage 2a; no `content_text` available for BM25, no row in `episode_metadata` for confidence / supersession).

Prior art (mnemo-cortex v2.6.4 `raw_tape`) ships an append-only journal of every observed message for crash recovery. Mechanism is sound; gnokee's invariants force a different shape (write-path vs observer-sidecar, tenant-scoped via RLS, no decay) — we adapt the *idea*, not the code.

## Decision

**gnokee writes an append-only `ingest_journal` row pair around each ingest run. On `IngestPipeline.__post_init__`, gnokee scans for any `begin`-without-matching-`commit` rows for the active tenant and emits a `ResumableIngest` log warning. Actual resume is opt-in via an explicit `maintenance.resume_ingest()` call — gnokee never auto-replays.**

### Granularity: two rows per ingest (not per-Stage)

The actual durability boundary is already a single unit. Stage 5 is one `async with conn.transaction()` block (`src/gnokee/ingest.py:314`) covering `episode_metadata`, `content_embedding`, `content_text`, `episode_body_encrypted`, `lab_record`, and `med_record` together. Stage 6 (Graphiti enhancement) has its own journal in the form of `episode_metadata.extraction_deferred` (ADR-0023). The only gap the journal needs to cover is *"Stage 4 lite-Episodic landed in Neo4j but Stage 5 Postgres txn never committed"* — one `begin` row before Stage 4 + one `commit` row after Stage 5 captures that boundary exactly.

- `begin` row: written **after** Stage 3.5 (so `episode_uuid` is known) but **before** Stage 4 (so the Neo4j MERGE is journaled).
- `commit` row: written after Stage 5 Postgres txn returns. (The commit row insert is itself a Postgres write but lives outside the Stage 5 txn — the journal trails the work it journals.)
- `fail` row: written when an unhandled exception escapes Stage 4 or Stage 5, after compensation runs (Stage 4 `remove_lite_episode` on Stage 5 failure). Kept indefinitely for audit.

Writing eight journal rows around eight logical stages would be writing-to-a-lower-resolution-than-the-actual-failure-surface and would cost 16 extra Postgres writes per ingest. Rejected.

### Resume policy: opt-in, never automatic

Per AGENTS.md "gnokee never auto-resolves contradictions" posture: crash recovery is mechanistically different from semantic contradiction resolution, but the posture is the same — loud + explicit. An operator observing `ResumableIngest` warnings in telemetry decides whether to call `maintenance.resume_ingest()`. The crash may have been intentional (consumer aborted an episode mid-flight); silently re-executing writes without operator awareness would violate the explicit-choice principle.

`IngestPipeline.__post_init__` scan emits one `ResumableIngest` WARNING per open `begin`-no-`commit` row found. The scan is bounded to the active tenant (RLS GUC), runs once per pipeline construction, and is non-fatal.

`maintenance.resume_ingest(tenant_id, episode_uuid)` replays **one episode at a time** by default — debuggable, structured per-episode log emission, no per-failure signal hidden under batch semantics. A batch form (`resume_ingest_all(tenant_id)`) is deferred until production telemetry shows operators need it.

### Row shape

```sql
CREATE TABLE ingest_journal (
    tenant_id        TEXT      NOT NULL,
    our_id           TEXT,                       -- nullable (mirrors episode_metadata)
    episode_uuid     UUID      NOT NULL,         -- gnokee-generated at Stage 3.5
    payload_hash     CHAR(64)  NOT NULL,         -- hex SHA-256
    state            TEXT      NOT NULL,         -- 'begin' | 'commit' | 'fail'
    seq              SERIAL    NOT NULL,
    stage_4_time     TIMESTAMPTZ NOT NULL,       -- replay-stable created_at for write_lite_episode
    error            TEXT,                       -- non-null on 'fail' rows
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, episode_uuid, state, seq)
);

CREATE INDEX ingest_journal_resumable_idx
    ON ingest_journal (tenant_id, episode_uuid, created_at)
    WHERE state = 'begin';
```

### Payload hash composition: `SHA256(tenant_id ‖ our_id ‖ valid_at)`

Hash over `(tenant_id, our_id, valid_at)` as UTF-8-concatenated bytes, stored as hex.

- `tenant_id` is in the hash. Without it, cross-tenant hash collisions on identical `(our_id, valid_at)` would produce false "same episode" matches in multi-tenant diagnostics.
- `content_sha256` is **excluded**. Hashing plaintext leaks: an attacker holding a known document and access to the journal can confirm-or-deny that this specific tenant ingested it (hash oracle). The journal is for *correlating retries*, not content fingerprinting.
- `episode_uuid` is **excluded** from the hash but stored as a separate column. The hash is for correlating across re-ingest attempts of the same logical episode (a consumer retry produces the same `(our_id, valid_at)` but a new `episode_uuid`).

### `stage_4_time` preservation (idempotency precondition)

`GraphitiStore.write_lite_episode` is `MERGE (n:Episodic {uuid: $uuid}) SET n = {... created_at: $created_at, ...}` (`src/gnokee/storage/graph.py:230`). Full property replacement means a resume that recomputes `stage_4_time = utc_now()` would **overwrite** the existing Episodic's `created_at` — violating ADR-0004 axis 3 ("first-ingest time").

Mitigation: the `begin` row stores `stage_4_time`. On resume, `maintenance.resume_ingest` passes the stored value to `write_lite_episode(created_at=stage_4_time)`, preserving the original first-ingest stamp.

This is **not** a v0.6 bug — `write_lite_episode` only runs once per happy-path ingest. The journal design surfaces the precondition by making resume a first-class operation.

### Idempotency status of Stage 5 mutations (audit)

> **Correction (2026-05-16, post-impl audit).** `MetadataStore.write`
> uses a bare `INSERT ... ON CONFLICT DO NOTHING` (no explicit conflict
> target). Bare-form suppresses any unique-constraint violation on
> the table — both the PK `(tenant_id, episode_uuid)` and the partial
> unique `(tenant_id, our_id) WHERE our_id IS NOT NULL`. This is
> broader than the originally documented `(tenant_id, our_id)` target
> and is the correct shape; resume of an episode whose `(tenant_id,
> episode_uuid)` row already exists is still idempotent.

- `MetadataStore.write` — `INSERT ... ON CONFLICT (tenant_id, our_id) DO NOTHING`. Idempotent.
- `PgVectorStore.write_embedding` — `INSERT ... ON CONFLICT (tenant_id, episode_uuid) DO UPDATE`. Idempotent.
- `PgVectorStore.write_content_text` — `UPDATE WHERE tenant_id=$1 AND episode_uuid=$2`. Idempotent.
- `LabStore.write_rows` — `INSERT ... ON CONFLICT DO NOTHING` (`src/gnokee/storage/lab.py:88`). Idempotent.
- `MedStore.write_rows` — `INSERT ... ON CONFLICT DO NOTHING` (`src/gnokee/storage/med.py:95`). Idempotent.
- `EncryptedBodyStore.write` — TODO: confirm `ON CONFLICT` shape (open question 1).

The Stage 5 single-txn boundary plus idempotent inserts means resume of a `begin`-no-`commit` row is safe to re-execute end-to-end.

### Module location: `src/gnokee/storage/journal.py`

New standalone file, sibling to `metadata.py`, `vector.py`, `contradictions.py`. Naming follows the noun-not-compound pattern (`metadata.py`, not `episode_metadata.py`). Folding into `metadata.py` would bloat a module already carrying bi-temporal filtering, supersession chain-walk, and deferred-extraction logic; the journal's responsibilities (append-only state machine, TTL pruning, resume scan) are orthogonal to episode lifecycle.

### TTL pruning

- Default: `commit` rows pruned after **7 days relative to `commit` row `created_at`** (configurable via `gnokee_config.ingest_journal_ttl_days`).
- `fail` rows: kept indefinitely. Audit value > storage cost.
- Pruner lives in `maintenance.py` (sibling to `run_deferred_extraction`), invoked by consumer cron or `maintenance.prune_ingest_journal(tenant_id, *, dry_run=False)`. Tenant-scoped via RLS GUC. Relative TTL is simpler (no wall-clock comparison against external state) and survives clock skew on the host running the pruner.

### `created_at` is ingest-system-time only (ADR-0004 invariant)

`ingest_journal.created_at` is *ingest-system-time only*. It does not participate in the bi-temporal `valid_at` / `asserted_at` axes. The journal is operational metadata about *when the ingest write happened*, not about *when the fact was valid in the world* or *when the source asserted it*. A `bi-temporal-auditor` review pass before impl-PR landing must confirm no journal columns or queries leak into bi-temporal filtering surfaces.

## Implementation note — `write_lite_episode` resume contract

Pinned for the impl-PR integration test:

When `maintenance.resume_ingest(tenant_id, episode_uuid)` is called and finds a `begin` row with no matching `commit`:

1. Acquire the RLS GUC for `tenant_id`.
2. Read `stage_4_time` from the `begin` row.
3. Re-execute Stage 4 (`GraphitiStore.write_lite_episode(..., created_at=stage_4_time)`) — Neo4j `MERGE` is idempotent on `uuid`; the `SET n = {...}` writes the *same* `created_at` so the Episodic node properties are stable.
4. Re-execute Stage 5 (Postgres txn). All inserts use `ON CONFLICT DO NOTHING` or `DO UPDATE`; the txn is idempotent.
5. Write the `commit` row.

If resume itself fails: write a new `fail` row (with the resume error in `error` column) but **leave the original `begin` row in place**. Append-only contract.

## Consequences

### Positive

- **Postgres-side durability story.** gnokee can answer "which episodes are mid-flight after a crash?" deterministically. Matches the v0.6 Graphiti-side story (`extraction_deferred` flag) — both halves of the two-store coordination problem now have a persistent replay surface.
- **Loud-failure posture preserved.** `ResumableIngest` warnings are explicit; operators decide when to replay. Matches the "never auto-resolve" axiom.
- **PII-safe.** `payload_hash` derives from `(tenant_id, our_id, valid_at)` only. No plaintext body or content hash reaches the journal.
- **Audit trail.** `fail` rows are append-only and kept indefinitely. Operators reviewing past crashes get a structured record.
- **Multi-tenant isolation preserved.** RLS via the existing `app.current_tenant` GUC pattern; no special-case codepaths.
- **`stage_4_time` storage closes a latent ADR-0004 axis-3 violation in any future resume path** (`write_lite_episode` full-property replacement would otherwise overwrite first-ingest time on replay).

### Negative — accepted

- **Two extra Postgres writes per happy-path ingest.** ~5% latency overhead in benchmarks against `IngestPipeline.ingest()` at the v0.6 Z1-B baseline; deemed acceptable for the durability guarantee. Reviewer should confirm via Q19 spike (deferred — see Open questions).
- **`our_id=None` episodes are partially resumable.** Without `our_id`, the `payload_hash` is computed over `(tenant_id, "", valid_at)` which collides across episodes with the same `valid_at`. `episode_uuid` (stored on the row) still uniquely identifies the resume target, but operators inspecting the journal for "what got dropped" lose the consumer-facing key. Consistent with ADR-0023's "`our_id=None` re-ingest creates duplicate episodes" accepted-negative.
- **No global resume.** `resume_ingest` is tenant-scoped + episode-scoped. A multi-tenant operator dashboard needs to iterate tenants explicitly. Deferred to consumer tooling.
- **No journal compaction of `fail` rows.** Pathological "fail-on-every-retry" episodes accumulate rows. Mitigation: deduplicate at write-time on `(tenant_id, episode_uuid, error_class)` — flagged as Open.

### Open questions

These shipped with the ADR as `Proposed`; resolved on impl-PR #129.

1. **`EncryptedBodyStore.write` `ON CONFLICT` shape.** **RESOLVED 2026-05-16.** Existing implementation at `src/gnokee/storage/encrypted_body.py:64` uses `INSERT … ON CONFLICT (tenant_id, episode_uuid) DO UPDATE`. Resume of an encrypted-body episode is end-to-end idempotent. No code change needed.

2. **`fail` row dedup.** **RESOLVED — new row each time.** Append-only is the hard invariant; dedupping `fail` rows would require `UPDATE`. Multi-retry telemetry (3-consecutive-same-error alert) deferred to a separate observability ADR; not a write-path concern.

3. **`Q19` resume-latency spike.** **RESOLVED PASS, 2026-05-16.** `evals/spike_q19_journal_overhead/` measured 2.17% median regression on `extract=False` ingests (101.93 ms with journal vs 99.76 ms without; N=50 per condition). Well under the 10% threshold.

4. **`bi-temporal-auditor` sign-off.** Pending on impl-PR #129 review. `stage_4_time` preservation across resume is exercised by `tests/integration/test_ingest_journal_resume.py` (asserts Neo4j `created_at` unchanged across re-MERGE).

5. **`cypher-reviewer` sign-off on `write_lite_episode` resume contract.** Pending on impl-PR #129 review. Resume idempotency on the Neo4j side relies on `MERGE` semantics already covered by the v0.6 Z1.6 spike.

6. **`EpisodeIn` rehydration source on resume (raised during impl).** **RESOLVED 2026-05-16 — option (b) consumer-resupply.** Journal carries only `payload_hash`; consumer re-supplies the original `EpisodeIn` to `maintenance.resume_ingest`. gnokee refuses with `IngestJournalError` on hash drift. Preserves the "gnokee never holds plaintext after embed" red line; keeps `ingest_journal` rows constant-size.

7. **`_compensate` interaction with the journal (raised during impl).** **RESOLVED 2026-05-16 — keep existing v0.6 Z1-B compensation untouched.** Controlled exceptions in Stage 4/5 still run `_compensate` (removes the lite-Episodic); journal appends a `fail` row after compensation. The journal closes the **container-kill / OOM** durability gap where the `except` handlers never run — Stage 4 Episodic survives, `begin` row stays open, operator-driven `resume_ingest` re-MERGEs idempotently. The ADR's original "verify `begin` row + Stage 4 Neo4j node exist after crash" line in §Acceptance describes the container-kill case, not the controlled-exception case; `tests/integration/test_ingest_journal_resume.py` simulates container-kill via a no-op `_compensate` monkeypatch.

## Acceptance evidence

Collected on impl-PR [#129](https://github.com/gnokeelabs/gnokee/pull/129) (2026-05-16).

- **Integration test** (`tests/integration/test_ingest_journal_resume.py`, commit `7718979`):
  - Induces a mid-Stage crash (`metadata.write` raises after Stage 4; `_compensate` monkeypatched to no-op to simulate a container kill).
  - Verifies `begin` + `fail` rows in `ingest_journal`, Stage 4 lite-Episodic visible in Neo4j, no `episode_metadata` row.
  - Calls `maintenance.resume_ingest(tenant_id, episode_uuid, episode, pipeline=app.ingest)`.
  - Verifies `episode_metadata` row materializes with the pinned `episode_uuid`, journal carries `[begin, fail, commit]`, `scan_resumable` returns `[]`, Neo4j `Episodic.created_at` unchanged across the Stage 4 re-MERGE (ADR-0004 axis-3 preserved).
  - PASSES locally against `pg17` + `neo4j-5-community` + `tei-cpu-arm64` compose stack.
- **Q19 spike** (`evals/spike_q19_journal_overhead/`, commit `4cae7a0`): regression(median) = 2.17% on `extract=False` ingests (N=50, WARMUP=3 per condition); threshold 10% **PASS**.
- **Regression check**: 20 ingest-related integration tests (`test_ingest_z1`, `test_idempotency`, `test_ingest_recall`) green in 130 s after journal wiring landed; full unit suite 410/410 green including 6 new resume_ingest unit tests + 2 new ingest `_resume` payload-hash tests + 7 new `payload_hash` determinism tests.
- **Specialist sign-off**: requested on PR #129 (`postgres-pgvector-specialist`, `bi-temporal-auditor`, `cypher-reviewer`, `ingest-pipeline-specialist`).
- **Q18 release-cut gate** (`python evals/spike_q18_recall_at_k_diagnostic/run.py --gate`): no change to recall surface; run on impl-PR pre-merge.

## References

- [Issue #122](https://github.com/gnokeelabs/gnokee/issues/122) — driver
- [ADR-0023](./0023-gnokee-owns-episode-storage.md) — Graphiti half of two-store coordination
- [ADR-0004](./0004-gnokee-owns-retrieval.md) — `created_at` / `asserted_at` / `valid_at` axis invariants
- `src/gnokee/ingest.py:314` — Stage 5 txn boundary
- `src/gnokee/storage/graph.py:230` — `write_lite_episode` MERGE+SET
- mnemo-cortex v2.6.4 `raw_tape` (prior art, gnokee adapts the idea)
