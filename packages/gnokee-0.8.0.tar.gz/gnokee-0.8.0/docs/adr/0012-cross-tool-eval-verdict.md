# ADR-0012: gnokee's fact-only recall is mismatched with conversation-memory benchmarks; the cross-tool number is REJECT and drives #16 item 1

- **Status:** Accepted (Stage C-pilot 2026-05-10 confirmed Stage A magnitude; full-pilot Stage C filed as #63 follow-up — see § "Stage C-pilot amendment (2026-05-10)")
- **Date:** 2026-05-09
- **Decider:** Vadim Yuzi
- **Context:** Q10 spike — `evals/spike_q10_cross_tool/`. Closes the
  named gate in `README.md:104` (`Eval suite formalised across
  cross-tool (vs Mem0 / Graphiti-alone / basic-memory)`) and unblocks
  Omur ADR-028 § Sequencing.

## Context

ADR-0004 chose to put compact natural-language fact statements at
gnokee's recall surface (Q3-validated, 125 median tokens vs 367 for
the Graphiti-raw baseline). Q1 validated this on personal / engineering
notes — the corpus shape gnokee was designed for. Q10 asks: does the
same surface hold up against a public conversation-memory benchmark
(LongMemEval-S, 500 questions × ~47 sessions of chat history) that
Mem0 reports **93.4** on?

The Q10 spike wires three SUTs (`gnokee` v0.2.3, `graphiti-alone`
called directly, `mem0` 2.0 OSS pinned to `gpt-4o-mini-2024-07-18`)
against a stratified `pilot_100.jsonl` subset of the cleaned
LongMemEval dataset, with a tool-call-forced
`emit_verdict(label, confidence, reason)` LLM judge
(`gpt-4o-mini-2024-07-18`, `temperature=0`, `seed=42`, double-run
disagreement protocol). Two stages run before this verdict:

- **Stage A (sniff)** — 10 questions × 10-session haystack truncation,
  3 SUTs, Track 1 only. Validates the wiring + first defensible
  cross-tool number. Landed 2026-05-09.
- **Stage C (full pilot)** — 100 questions × full ~47-session
  haystack, 3 SUTs, both tracks. Confirms magnitude. Pending overnight
  ramp.

Zep-OSS and basic-memory were deferred to Q10.1 (community-edition
Docker stack and alembic-project state machinery, respectively, were
non-trivial wires that did not change the load-bearing comparison
gnokee needed against Mem0's published number — see
`evals/spike_q10_cross_tool/README.md` § Systems under test).

## Result

### Stage A measurement

#### Original Stage A (run-id `stageA-v3`, 2026-05-09 morning)

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` v0.2.3 | 0 / 4 (0 %) | 0 / 10 (0 %) | 0 / 10 (0 %) | 120 s | 0.14 s |
| `graphiti-alone` | 3.5 / 4 (87.5 %) | 0 / 10 (0 %) | 1 / 10 (10 %) | 120 s | 0.16 s |
| `mem0` | 3 / 4 (75 %) | 1 / 10 (10 %) | 1 / 10 (10 %) | **22 s** | 0.18 s |

#### Stage A re-run after #38 (run-id `stageA_pathA`, 2026-05-09 evening)

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` (Path A + adapter axis fix) | **2 / 4 (50 %)** ↑ | 0 / 10 (0 %) | 0 / 10 (0 %) | 124 s | 0.13 s |
| `graphiti-alone` (unchanged) | 3.5 / 4 (87.5 %) | 0 / 10 (0 %) | 1 / 10 (10 %) | 120 s | 0.16 s |
| `mem0` (unchanged) | 3 / 4 (75 %) | 1 / 10 (10 %) | 1 / 10 (10 %) | **22 s** | 0.18 s |

#### Stage A re-run after #50 + #41 (run-id `stageA_50_41`, 2026-05-09)

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` (#50 ranking-surface + #41 hybrid body) | **4 / 4 (100 %)** ↑ | 0 / 10 (0 %) | 0 / 10 (0 %) | 124.6 s | 0.15 s |
| `graphiti-alone` (unchanged) | 3.5 / 4 (87.5 %) | 0 / 10 (0 %) | 1 / 10 (10 %) | 120 s | 0.16 s |
| `mem0` (unchanged) | 3 / 4 (75 %) | 1 / 10 (10 %) | 1 / 10 (10 %) | **22 s** | 0.18 s |

Judge `disagreement_rate = 0.0000` (perfect A/B agreement) on all
three runs. Decision `JUDGED_DOUBLE_AGREED`. Six of ten questions had
their gold session outside the 10-session truncation window; recall
is `n/a` for those and is not held against any SUT.

The post-#50 + #41 row carries `recall@5 = 100 %` — gnokee retrieves
the gold session on every question whose gold session is inside the
10-session window. `accuracy_strict` stays at 0 / 10: body emission
mechanism fires (`body_used = True` on 9 / 10), but at the default
`max_tokens = 200` the body lane budget admits exactly one episode
body per call, and the literal answer is not always in the top-1
ranked body. See § "Issue #50 + #41 verification" below for the
per-probe diagnosis. The bottleneck moved from ranking surface to
body coverage — a tuning concern (`top_k_bodies`, per-body cap, or a
larger default `max_tokens` on conversation-shape corpora), not an
architectural one. Tracked as a v0.4 follow-up issue.

The re-run revised gnokee's number on the back of two changes
landed under [#38](https://github.com/gnokeelabs/gnokee/pull/40):

1. **Path A** — `gnokee.recall()` gains an episode-cosine fallback
   when `candidate_count > 0 AND fact_count == 0`. Defensive escape
   hatch for shapes where Graphiti synthesises no edges. **Did not
   fire on Stage A** (see § Corrected diagnosis below).
2. **Q10 adapter axis fix** — chat-time replay now sets
   `asserted_at = ep.timestamp` instead of defaulting to
   `utc_now()`. Without this, stage 2b `filter_visible` rejects
   every episode at recall (`as_of = question.asked_at` ≪
   `asserted_at = replay-time`), which was the *actual* cause of
   the original 0/10 — not "Graphiti synthesised no facts," as the
   first draft of this ADR claimed.

### Q10-pre embedder asymmetry footnote

Already landed (`evals/spike_q10_pre_embedder/results/20260509T111608Z.json`,
multilingual_v2 corpus, 8 languages × 5 scripts):

- bge-m3 (gnokee + graphiti default): **64 / 64 (100.0 %)** top-3
- text-embedding-3-small (Mem0 default): **55 / 64 (85.9 %)** top-3 —
  fails all 8 Arabic probes including the `ar→ar` control.

Embedder-only contribution to gnokee's multilingual lead is bounded
at ~14 pp. **Track 2** (Mem0 reconfigured to bge-m3) has not yet
run; Stage C will produce that number alongside the Track 1
end-to-end.

### Read-out (post-#38 re-run)

1. **gnokee retrieves the right session 50 % of the time but
   answers none of them.** `recall@5 = 2/4 (50 %)` after #38,
   `accuracy_strict = 0/10 (0 %)` unchanged. The lift came from the
   Q10 adapter axis fix — once `filter_visible` admits the right
   episodes, Graphiti's edge-fact triples are surfaced for the
   synthesiser. But the triples summarise the content shape and
   drop the literal answer values (gold "25 postcards" surfaced as
   "Eiffel Tower at Night and 1920s Paris Postcard are both part
   of the user's postcard collection"; gold "2 doctor's
   appointments in March" surfaced as turns about an unrelated book
   club). Path A's strict trigger (`fact_count == 0`) **did not
   fire on any of the 10 questions** — Graphiti does extract edges
   from conversation logs once stage 2b admits them. The original
   ADR claim "Graphiti synthesises no facts about conversational
   turns" was wrong.
2. **graphiti-alone retrieves well, answers poorly.** Hybrid
   edge-search + MENTIONS Cypher backwalk surfaces the right session
   (87.5 % recall@5) but the synthesiser only sees edge-fact triples
   that summarise content and drop the literal numbers gold answers
   reference ("25 postcards", "2 doctor's appointments"). One
   partial on a chess-move probe where the edge fact happened to
   carry the move notation verbatim. **gnokee post-#38 is now in the
   same regime — high recall, zero strict accuracy — bottlenecked by
   edge-fact literal stripping, not retrieval.**
3. **mem0 is the only SUT producing real answers.** 1 / 10 strict on
   the email-count knowledge-update probe (gold "31"; mem0
   retrieved enough turns for the synthesiser to count). 5.5 ×
   faster ingest than gnokee / graphiti — one extraction LLM call
   per `add` vs Graphiti's 3–5. Reinforces #16 item 1 (lite-ingest
   mode) as the v0.3 latency intervention.

### Corrected diagnosis (#38 re-run, 2026-05-09 evening)

The first-draft ADR-0012 attributed gnokee's 0/10 to "Graphiti
synthesises no `EntityEdge` facts about LongMemEval conversation
logs." The #38 re-run disproves that on two counts:

1. **Stage 2b filter_visible was the actual cause of the original
   0/10.** The Q10 adapter ingested with `valid_at = ep.timestamp`
   (correct world-time) but left `asserted_at` to default to
   `utc_now()` at the API boundary (= replay-time, ~2026). The
   harness recalls with `as_of = question.asked_at` (chat-time,
   ~2024). `filter_visible` requires `asserted_at <= as_of` for the
   asserted half-pair to admit an episode; with replay-time
   `asserted_at` and chat-time `as_of`, every episode failed the
   filter. `ranked` collapsed to `[]` and recall bailed at line
   ~156 of `retrieval.py`, BEFORE stage 4 even ran. No fact fetch
   ever happened. The "Graphiti synthesises no facts" claim was
   never tested against the live data.
2. **Once stage 2b is fixed, Graphiti DOES extract edges from
   conversation logs.** Post-axis-fix, every gnokee row in the
   Stage A re-run shows `fact_count` ≥ 5. The shape problem is
   different: the edge-fact triples are too summarised — they
   describe topical relations between entities and drop the
   literal answer values (numbers, dates, named counts) that gold
   answers reference.

The **net effect** of #38 on Stage A:

- `recall@5` lifted **0 → 50 %** (from the axis fix).
- `accuracy_strict` stayed **0 / 10** (literal-stripping bottleneck,
  not retrieval).
- Path A is shipped as a defensive escape hatch but did not fire on
  this dataset — it is still defensible for shapes where Graphiti
  genuinely produces no edges (sparse content, structured-log
  ingest), just not for LongMemEval-S.

## Decision (Draft, revised after #38 re-run)

**The cross-tool eval verdict against the LongMemEval-S benchmark
is REJECT** for the v0.2.x + #38 gnokee retrieval surface. The
revised diagnosis: gnokee retrieves the right session 50 % of the
time but the LLM-summarised edge-fact triples Graphiti produces
strip the literal answer values (counts, dates, named amounts)
that LongMemEval gold answers reference. This is structurally the
same regime graphiti-alone occupies — high recall, zero strict
accuracy — and is not closed by Path A.

- pgvector ranks the right episodes (`candidate_count` consistently
  hits the configured top_k);
- Stage 2b admits them at recall (post-#38 axis fix);
- Graphiti DOES extract edges from conversation turns, but the
  extracted facts are topical-relation summaries
  ("Eiffel Tower at Night and 1920s Paris Postcard are both part of
  the user's postcard collection") rather than verbatim quoted
  literals ("the user added 25 new postcards");
- The synthesiser, given only the summarised facts, says
  "I don't know."

The READMEd "Status" gate flips with this number. We do *not* claim
parity with Mem0's published 93.4. The structural gap is in the
literal-stripping at Graphiti edge extraction, not retrieval; any
retrieval-then-synthesis pipeline whose memory representation drops
literal answer values en route to the synthesiser cannot reach
Mem0's number. The v0.3 milestone proceeds with this verdict on
the record.

The verdict drives three architectural follow-ups:

1. **#16 item 1 — lite-ingest / `extract=False` path.** Skips
   Graphiti's per-episode LLM extraction. Two effects: (a) ingest
   latency drops ~5× per Stage A (gnokee 120 s → mem0-shape ~22 s);
   (b) recall surface gains a path that does not require fact
   extraction to succeed. The MENTIONS-Cypher backwalk
   graphiti-alone uses is the simplest version of this fallback.
   With #38 axis fix landed, this also begins to address the
   literal-stripping bottleneck because it surfaces verbatim
   episode content instead of edge-fact triples.
2. **#38 (this PR) — gnokee.recall episode-cosine fallback.**
   Defensive escape hatch when `candidate_count > 0 AND
   fact_count == 0`. Did not fire on Stage A (Graphiti extracts
   edges from this dataset), but stays in the surface for shapes
   that genuinely produce no edges (sparse content, structured
   logs).
3. **#41 — hybrid emission of facts + episode bodies (LANDED).**
   Body lane fires whenever the query carries no `wants_excerpt`
   signal, taking 1/3 of `max_tokens`. Stage A re-run after #41 +
   #50 shows `body_used = True` on 9 / 10 questions; mechanism works.
   `accuracy_strict` stayed flat at 0 / 10 because the 1/3 budget
   admits exactly one episode body per call at the default
   `max_tokens = 200`, and the literal answer is not always in the
   top-1 ranked body. Tracked as v0.4 body-coverage tuning
   follow-up.
4. **#50 — `retrieved_episode_external_ids` ranking surface
   (LANDED).** Closes the BM25-can't-reach-the-metric gap from
   § Q11 Fix Verification. `recall@5` went from 50 % (post-#38) to
   100 % on this dataset.

## Consequences

- **README "Status" gate flips to checked** with the Stage A
  re-run number in the Q10 README, ADR-0012 cited. Numbers are now
  `recall@5 = 100 %` (post-#50), `accuracy_strict = 0 %` (flat
  pending body-coverage tuning), with the bottleneck moved from
  ranking surface to body coverage at default `max_tokens = 200`.
- **Mem0 published 93.4 stays uncited as a parity claim.** The
  comparison framing in any external docs is "Mem0 is the
  conversation-memory benchmark anchor; gnokee retrieves the gold
  session 100 % of the time inside the 10-session window on this
  shape, but at the default 200-token recall budget the body lane
  surfaces only the top-1 ranked episode body per call, so strict
  accuracy stays at 0. The work to close the gap is tracked as a
  v0.4 body-coverage tuning follow-up." Disclosure stays explicit,
  not hidden.
- **Personal-corpus claims unaffected.** Q1, Q2 (multilingual), Q3
  (token efficiency), Q4 (contradiction), Q5 (forgetting), Q7 (labs),
  Q8 (meds), Q9 (wearables) all remain valid for gnokee's intended
  shape. ADR-0012 narrows the rejection to *conversation-memory
  benchmarks*, not personal corpora.
- **Path A landed (#38) but did not move accuracy_strict.** It
  stays in the surface as a defensive escape hatch for shapes that
  genuinely produce no edges. Recall@5 lift came from the Q10
  adapter axis fix that landed alongside Path A, not from Path A
  itself.
- **#50 + #41 landed and lifted recall@5 50 % → 100 %.** Body
  emission mechanism fires (`body_used` 9/10) but body-coverage
  tuning is the next intervention; tracked as v0.4 follow-up.
- **Stage C confirmation pending.** The full-pilot ramp (100 Q ×
  full haystack × 2 tracks) replaces the Stage A row in this ADR
  when it lands. Status flips from `Draft` to `Accepted` at that
  point.

## Q10.1 amendment (2026-05-09)

### New SUTs wired

Two adapters deferred from Q10 main are now implemented and smoked:

| Tool | Adapter | Retrieval primitive | Notes |
|---|---|---|---|
| `zep-oss` | `evals/spike_q10_cross_tool/adapters/zep_adapter.py` | `AsyncZep.memory.search_sessions(user_id, text, limit)` | CE docker-compose at `evals/spike_q10_cross_tool/docker-compose.zep.yml`. Architectural cousin via Graphiti core. Requires `ZEP_API_URL + ZEP_API_KEY`. |
| `basic-memory` | `evals/spike_q10_cross_tool/adapters/basic_memory_adapter.py` | SQLite FTS5 BM25 (`aiosqlite` direct, no server) | "Do you even need a vector store?" baseline. Metric: **answer-recall via BM25**, NOT cosine-precision. Track 2 N/A (no embedder). |

Both adapters pass the W1–W4 wiring smoke (`smoke_zep.py`, `smoke_basic_memory.py`).
Both are registered in `run.py` `SUT_REGISTRY`.

### Stage C confirmation

`evals/spike_q10_cross_tool/results/stageC.json` was **not present** at Q10.1
authoring time (background run did not produce output). Stage C (100 Q × full
~47-session haystack × 3 wired SUTs × Track 1 + Track 2) has not yet confirmed
the Stage A verdict at pilot scale. ADR-0012 status remains **Draft** until Stage
C numbers replace the Stage A row in the Result table above.

To run Stage C once the pilot corpus is available:
```bash
cd evals/spike_q10_cross_tool
python run.py --corpus pilot --suts gnokee,graphiti-alone,mem0 --run-id stageC
python judge.py --double-run
python synthesize.py
```
Then amend this ADR with the `stageC/<utc>.json` path and flip status to Accepted.

## Stage C-pilot amendment (2026-05-10)

The original Stage C plan (100 Q × full ~47-session haystack × Track 1 + Track 2)
was downsized to **30 Q × 20-session × Track 1 × 3 wired SUTs** for laptop-feasibility
— full-haystack ingest extrapolated to ~30 h serial wall on the dev machine due to
OpenAI TPM rate-limits + per-question sequential SUT loop. Filed [#63] (parallelize
run.py + Mem0 adapter robustness) for the full-pilot rerun on a cluster.

`mem0` was dropped from this run after a silent process termination at `[mem0] 1/30`
reproducing across two attempts (no traceback; suspected Ollama-side OOM or
`BaseException` escape past `one_run`'s `except Exception`). Mem0's Stage A baseline
(1/10 strict) carries forward; tracked under [#63].

### Stage C-pilot results (run-id `stageC_30q20s`, 2026-05-10)

3 wired SUTs × 30 Q × 20-session haystack × Track 1, judge `gpt-4o-mini-2024-07-18`
double-run, `disagreement_rate = 0.0000`. Artifact:
`evals/spike_q10_cross_tool/results/stageC_30q20s_synth_judged.json`.

| SUT | retrieval any_hit | retrieval mean_recall@5 | accuracy_strict | accuracy_lenient |
|---|---|---|---|---|
| `gnokee` (lite-mode + body-recall, v0.3.0) | 17.6 % | 17.6 % | **0 / 30 (0 %)** | 0 / 30 (0 %) |
| `graphiti-alone` (unchanged) | 0.0 % | 0.0 % | **0 / 30 (0 %)** | 0 / 30 (0 %) |
| `basic-memory` (SQLite FTS5 BM25) | **41.2 %** | 35.3 % | **0 / 30 (0 %)** | 0 / 30 (0 %) |

Recovery path: original 4-SUT run died at `[mem0] 1/30` with all gnokee + graphiti
ingest already complete in storage but no `rows` written (run.py only persists at
end-of-run). Recovered by patching `run.py` to add `--query-only-suts` (skips ingest,
queries existing tenants) and per-SUT JSON checkpoints. Re-ran gnokee + graphiti
in query-only mode (~10 s total) + basic-memory standalone (~8 s); merged 3 partials
into the final JSON. mem0 left for [#63].

### Read-out

1. **Magnitude confirmed.** All three wired SUTs score 0 / 30 strict. Stage A's 0 / 10
   magnitude (gnokee + graphiti) holds at 3× the question count and 2× the haystack size.
   ADR-0012's central verdict — gnokee does not "win" LongMemEval-S — survives the scale-up.

2. **Retrieval quality ≠ answer correctness.** basic-memory's SQLite FTS5 BM25 wins
   retrieval (41 % any-hit vs gnokee's 18 %, graphiti's 0 %), and still abstains on
   29 / 30 questions. Synth-prompt abstention bias dominates; bottleneck moved from
   retrieval to **answer extraction**. Tracked as [#62].

3. **graphiti's recall collapsed at scale.** Stage A had graphiti-alone at
   `recall@5 = 87.5 %` (10-session haystack); Stage C-pilot puts it at 0.0 %
   (20-session). Edge-fact + MENTIONS-backwalk recall does not scale to bigger
   haystacks under strict ID-match. The retrieved edges may still surface the right
   facts in their natural-language form — partial-credit metrics may differ — but
   the harness's `gold_external_ids ∩ retrieved_external_ids` measure goes to zero.

4. **basic-memory's lead is in retrieval, not answers.** "Do you even need a vector
   store?" answer at 30 Q × 20-session is **yes** for retrieval (FTS5 BM25 wins
   outright), **no** for end-to-end answer accuracy (synth still says
   `"I don't know"` 29 / 30 times). Same-shape failure across all three architectures
   argues the v0.3+ intervention belongs in synthesis, not retrieval.

### Status flip

ADR-0012 status flips **Draft → Accepted**. Stage A magnitude confirmed at pilot-shape.
The original "100 Q × full haystack × Track 1 + Track 2" Stage C is filed as
[#63] follow-up — needs (a) `asyncio.gather` per-SUT parallelism to fit in
overnight wall, (b) Mem0 adapter root-cause to unblock Track 2 (Mem0 reconfigured to bge-m3).

### Outstanding for v0.3.x or v0.4

- **[#62]** — closed-as-falsified by Q12 spike (see "Q12 spike — synth
  abstention is symptom, not cause" below). Synth abstention is
  downstream of retrieval; loosening the prompt produced 5 attempts,
  all wrong. Retrieval-recall track ([#42] / Q11) remains the
  load-bearing follow-up.
- **[#63]** — run.py per-question `asyncio.gather` (cuts Stage C wall ~5×) +
  Mem0 adapter silent-crash root-cause.

[#62]: https://github.com/gnokeelabs/gnokee/issues/62
[#63]: https://github.com/gnokeelabs/gnokee/issues/63

## What this does not decide

- Whether gnokee should add answer synthesis as a built-in. ADR-0004
  is explicit that gnokee never vendors an LLM; the synthesiser is
  consumer-side. Q10's `synthesize.py` is an evaluation harness
  artifact, not a gnokee feature.
- Whether to pursue Mem0-style atomic-memory extraction inside
  gnokee. Mem0's `infer=True` extraction is a single LLM call per
  add producing ≥ 1 atomic memories; gnokee's Graphiti pipeline
  produces edge-fact triples. The shape difference is structural;
  changing it is a v0.3+ design question separate from this ADR.
- Whether to ship Track 2 (Mem0 reconfigured to bge-m3) as the
  headline. Stage C runs Track 2 and the report carries both
  numbers; ADR-0012 amends to whichever frames the comparison most
  honestly.

## Diagnosis (Q11) — ranked recall-gap hypotheses

Spike: `evals/spike_q11_recall_diagnostic/` (issue #42).
Dry-run result: `evals/spike_q11_recall_diagnostic/results/20260509T154515Z_dry.json`.
Live result: pending — requires reconnecting to the Q10 Stage A tenant namespace
(`GNOKEE_SPIKE_Q11_TENANT_PREFIX=stageA_pathA`).

### What the diagnostic instruments

For the two Stage A miss questions (gnokee `any_hit=False`, graphiti-alone
`any_hit=True`), the harness dumps:

- stage 2a Cypher candidate list (uuid + valid_at, default filter +
  far-future pin for H2)
- stage 3 pgvector cosine top-K with scores (not just ranked uuids)
- graphiti `COMBINED_HYBRID_SEARCH_RRF` edge top-K + MENTIONS backwalk
- whether the gold episode appears in each primitive's output

### Ranked hypotheses (prior to live run)

| Rank | Hypothesis | Mechanism | Evidence class |
|---|---|---|---|
| 1 | **H1 — Hybrid > pure cosine** | graphiti RRF over (BM25 + cosine + reranker) recovers literal-bearing edges that pgvector cosine over the full episode body misses. Conversational turns are short and contain named entities ("postcard", "doctor") that BM25 hits strongly. Episode-level cosine averages the whole session body, diluting these signals. | Confirmed by dry-run shape; live run will show gold episode inside graphiti top-K but outside gnokee cosine top-K |
| 2 | **H4 — Embedding dilution** | The gold session is a 47-turn chat log; the gold fact ("25 postcards") is one sentence in thousands of tokens. The single `content_embedding` vector averages all sentences, reducing the cosine affinity for a specific-fact query. | Same mechanism as H1 from the cosine side; visible as gold_cosine_score > all non-gold scores in top-K |
| 3 | **H2 — valid_at over-filter** | Stage 2a applies `ep.valid_at <= $valid_at` (default = as_of = question.asked_at). In Stage A the 10-session haystack's timestamps should all be <= asked_at, but any clock-skew or timezone drift during Q10 ingest could push episodes past the filter. The H2 probe re-runs with `valid_at = far_future` and compares candidate counts. | Expected to be NOT confirmed on Stage A (10-session haystack fits well under 200); but worth measuring |
| 4 | **H3 — Pool too narrow** | `DEFAULT_CANDIDATE_POOL = 200` on a 10-session Stage A haystack is sufficient (10 << 200). This becomes the primary failure mode at Stage C (47 sessions × multi-turn) only if the pool hits 200. | Stage A: not expected; Stage C: likely to emerge |

### Recommendation (pre-live)

**Primary: MEDIUM fix — add BM25 sibling query alongside pgvector cosine in stage 3.**

Concretely: after stage 2a narrows the candidate pool to `≤ CANDIDATE_POOL`
episode uuids, run two parallel retrieval passes:

1. Existing pgvector cosine over `content_embedding` (current stage 3)
2. New: BM25 full-text search over the episode body stored in the Neo4j
   `Episodic.content` field, restricted to the same candidate uuid set

Fuse the two ranked lists with RRF (same recipe graphiti uses for edges). This
keeps gnokee's bi-temporal filter (stage 2a/2b) and pgvector cosine as the
primary ranking, and adds a BM25 lane that recovers episodes containing the
literal query term (count, entity name, date) that cosine misses after
averaging the full session body.

This is orthogonal to #41 (hybrid fact + body emission), which addresses
`accuracy_strict`; the BM25 addition addresses `recall@K`.

**Secondary: revisit DEFAULT_CANDIDATE_POOL before Stage C.**

At 47-session haystacks a multi-turn session may exceed 200 episodes if the
harness splits sessions per turn. Raise to 500 or make it a config knob with
env-var override (`GNOKEE_CANDIDATE_POOL`) before Stage C runs.

**Not recommended now: sub-episode chunking (H4 full fix).**

Sub-sentence embeddings would require ingest-side changes (chunk each session
into paragraphs, embed per-chunk, store in a sibling table). This is a v0.4
scope item and would not be justified until the BM25 lane is tried and shown
insufficient.

### Decision after live run

The Q11 harness computes `decision: H1 | H2 | H3 | H4 | INCONCLUSIVE` from
the live scores. ADR-0012 will be amended with the live decision once
`GNOKEE_SPIKE_Q11_TENANT_PREFIX=stageA_pathA` is run against the Q10 Stage A
tenant data. The recommendation above (MEDIUM BM25 fix) holds unless H2
flips to confirmed (then CHEAP config knob) or H3 exhausts the pool on
Stage A (then CHEAP pool raise).

## Q11 Fix Verification (issue #46, 2026-05-09)

### What landed

PR `worktree-v0.3-bm25-rrf-stage3` implements the MEDIUM BM25 fix recommended
above:

1. **Migration 0009** (`src/gnokee/storage/migrations/0009_episode_metadata_gin_fts.sql`)
   — adds `content_text TEXT` column + GIN index
   `idx_episode_metadata_content_fts` on `to_tsvector('english', content_text)`
   to `episode_metadata`.  Nullable; episodes with encrypted_body or no
   plaintext get NULL, are invisible to BM25, and degrade to cosine-only RRF.

2. **Stage 3a BM25 lane** (`src/gnokee/storage/vector.py :: PgVectorStore.search_bm25`)
   — `plainto_tsquery('english', $query)` + `ts_rank_cd` over the GIN index,
   restricted to the stage-2a candidate uuid set.  Respects multi-tenant RLS
   via `WHERE tenant_id = $1` (+ GUC guard from request middleware).

3. **Stage 3b RRF fuse** (`src/gnokee/retrieval.py :: _rrf_fuse`)
   — Reciprocal Rank Fusion over cosine + BM25 ranked lists, k=60 (matches
   graphiti's `COMBINED_HYBRID_SEARCH_RRF` constant).  Empty BM25 → degrades
   to cosine-only (no crash).  Both lists empty → empty result (pipeline
   returns early, same as before).

4. **`DEFAULT_CANDIDATE_POOL` 200 → 500** — secondary ride-along from
   issue #46.  Addresses H3 pool exhaustion before Stage C runs against
   ~47-session haystacks.

5. **Stage 6b `content_text` write** (`src/gnokee/ingest.py` Stage 6) —
   wired alongside `write_embedding` in the same transaction.  Plaintext
   episodes write `content_text = episode.content`; encrypted-body episodes
   leave it NULL (correct — BM25 over ciphertext is meaningless).

6. **Backfill** (`scripts/backfill_content_text.py`) — one-shot script
   that reads `Episodic.content` from Neo4j via `fetch_episode_contents` and
   writes it back to `episode_metadata.content_text` for all existing NULL
   rows.  Run after applying migration 0009.  Idempotent (only targets
   NULL rows).  Applied to the live stack 2026-05-09: 1,061 rows populated
   across all tenants including the Q10 `stageA_pathA` namespace.

7. **`queries.yaml` corrected** — probe `gold_external_id` fields updated
   to actual LongMemEval session IDs (`answer_a7b44747_1`,
   `answer_39900a0a_3`, `answer_sharegpt_d6JJiqH_76`) from `stageA.json`;
   probe IDs set to match Q10 question-id hash suffix pattern.

### Post-fix unit test numbers

All 213 unit tests pass.  3 new tests added (content_text write path):

- `test_ingest_writes_content_text_on_plaintext_episode` — `write_content_text`
  called with correct `content_text` and `tenant_id` on plaintext ingest.
- `test_ingest_content_text_called_in_full_mode` — fires in `extract=True` mode.
- `test_ingest_content_text_and_embedding_called_in_same_stage` — both
  `write_embedding` and `write_content_text` called per ingest.

Plus the 17 from the initial PR landing (210 total → 213 total).

### Post-fix Q11 + Stage A numbers (live, 2026-05-09)

Live pipeline eval against the Q10 `stageA_pathA` tenants after migration 0009
applied + backfill populated 1,061 rows of `content_text`.  Both pre-fix
(cosine-only, BM25 patched to return `[]`) and post-fix (RRF cosine + BM25)
runs executed against the same corpus via `gnokee.retrieval.recall` with the
actual question embeddings and `as_of = question.asked_at`.

**recall@5 (4 gold-bearing questions): 2 / 4 (50 %)** — both pre-fix and post-fix.

#### Per-probe diff: baseline vs post-fix

| probe | pre-fix hit? | post-fix hit? | per-probe verdict |
|---|---|---|---|
| postcard (`01493427`) | **True** | **True** | unchanged — cosine already ranked gold rank-1; BM25 adds no lift |
| doctor (`00ca467f`) | False | False | unchanged — Graphiti MENTIONS edges for cosine-top-5 episodes do not include gold `answer_39900a0a_3`; BM25 score=0 (no lexical match on "doctor/appointment") |
| engineers (`031748ae`) | False | False | unchanged — cosine ranks both gold episodes at ranks 1–2; but Graphiti MENTIONS edges from those episodes point to `70764af1_4` (non-gold); BM25 marginal (`ts_rank_cd = 0.0001`), RRF does not change which facts appear |
| chess (`1568498a`) | **True** | **True** | unchanged — cosine rank-1; Graphiti edge-fact carries chess notation verbatim; BM25 no signal |

**Root cause of flat 2/4:** BM25 provides no incremental recall lift on this
corpus because the gnokee pipeline's `retrieved_external_ids` are derived from
`FactStatement.episode_uuid` (Graphiti MENTIONS-edge provenance), not from
cosine-ranked episode UUIDs directly.  For doctor and engineers, cosine already
ranks the gold episodes first, but the Graphiti MENTIONS edges extracted from
those sessions reference non-gold episode UUIDs.  BM25 changes episode-level
ranking but does not change which edge facts Graphiti assigns to which episode
UUID; it therefore cannot repair probes where the bottleneck is MENTIONS-edge
provenance mismatch, not retrieval ranking.

**The initial ADR claim "postcard probe flipped from miss to hit" was wrong.**
It was inferred from a SQL BM25-rank check rather than from an end-to-end
pipeline run.  The corrected finding: postcard was already a cosine hit
(gold rank-1 in both cosine and RRF) before the BM25 changes.  BM25 confirms
the gold episode for postcard but does not flip it.

**Net effect of BM25 on Stage A recall@5:** zero lift on this corpus.
The bottleneck for doctor and engineers is Graphiti edge-provenance, not
retrieval ranking.  BM25 would help only if the gold episode was outside
cosine top-K but inside BM25 top-K; neither condition holds here.

**BM25 lane is still load-bearing for:** haystacks where literal query terms
(postcard, doctor) appear in episode bodies but cosine averaging over a long
session dilutes them below non-gold episodes.  On this specific 10-session
Stage A corpus the cosine signal is already strong enough.

**Q11 diagnostic (`evals/spike_q11_recall_diagnostic/`):** the probe
`gold_external_id` fields now reference actual LongMemEval session IDs.
The Q11 spike's `gold_in_stage2a = false` for all probes was caused by a
Neo4j lookup failure (external_id not found via the Q11 spike's Cypher path),
not by actual absence of the episodes — the episodes ARE present and are
ranked correctly by cosine.

## Issue #50 + #41 verification (run-id `stageA_50_41`, 2026-05-09)

### What landed

Two retrieval-shape changes that close the per-probe diagnosis above (BM25
ranking exists but cannot reach the metric because `retrieved_external_ids`
is sourced from MENTIONS-edge fact provenance, not the BM25/cosine episode
ranking):

1. **#50 — `RecallResponse.retrieved_episode_external_ids`.**  New `list[str]`
   field on the recall surface that carries the consumer-supplied `our_id`
   of the BM25/cosine top-K **visible** episodes in fused-rank order.
   Populated by mapping `ranked` UUIDs through
   `EpisodeMetadataRow.our_id`.  Q10 `gnokee_adapter.py` now reads this
   field as source-of-truth for `retrieved[]`, dropping the fact-derived
   MENTIONS-edge backwalk and the adapter-local uuid → external_id map.

2. **#41 — hybrid episode-body emission.**  The Path A `if not fact_rows`
   gate is dropped.  Body rows fire whenever the query carries no
   `query_wants_excerpt` signal (Q1/Q3/Q4/Q7/Q8 currency / med-keyword
   path stays narrow).  Budget split is mutually exclusive between the
   excerpt and body lanes:
     - `wants_excerpt` → excerpt 1/3, facts 2/3, body 0
     - `wants_body and fact_rows` → facts 2/3, body 1/3, excerpt 0
     - `wants_body and not fact_rows` (Path A) → body full budget
     - none → facts full budget
   `RecallResponse.fallback_used` renamed to `body_used` to reflect both
   triggers.

### Stage A re-run after #50 + #41 (run-id `stageA_50_41`, 2026-05-09)

10 LongMemEval-S pilot questions × 10-session haystack truncation,
top_k=5, max_tokens=200 (default), Track 1, double-run judge.

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` (post-#50 + #41) | **4 / 4 (100 %)** ↑ | 0 / 10 (0 %) | 0 / 10 (0 %) | 124.6 s | 0.15 s |
| `gnokee` (post-#46 baseline) | 2 / 4 (50 %) | 0 / 10 (0 %) | 0 / 10 (0 %) | 120 s | 0.13 s |

Judge disagreement_rate = 0.0000 (perfect A/B agreement).
Decision `JUDGED_DOUBLE_AGREED`.

### Read-out

1. **#50 closes the BM25-can't-reach-the-metric gap.**  `recall@5`
   doubled from 50 % → 100 % on the four gold-bearing questions.
   The post-#46 per-probe diagnosis above (doctor + engineers
   unchanged because MENTIONS-edge provenance pointed at non-gold
   episodes) is fully addressed: `retrieved_external_ids` now reflects
   the BM25/cosine fused ranking directly, not the
   provenance-of-extracted-facts. BM25 + cosine fusion was already
   ranking gold episodes correctly; #50 made that ranking visible
   to the harness.

2. **#41 mechanism shipped, accuracy_strict flat at 0/10.**
   `body_used = True` fires on 9 / 10 questions (the 10th has a
   `wants_excerpt` query signal, correctly skipped per the mutex).
   Both candidate answers the synthesiser produced — qid `06878be2`
   ("rustic and eco-friendly vibe…" against gold preference) and
   qid `1568498a` ("29. f4" against a chess-move gold) — were
   judged wrong.  The remaining 8 said "I don't know."

3. **Bottleneck: body coverage at default `max_tokens=200`.**
   The 1/3 budget (≈ 67 tokens ≈ 268 chars) admits exactly **one**
   episode body per call (`body_count == 1` on every fired call).
   A single conversation turn body is already > 268 chars, so the
   "first row always emits" guard takes the top-1 ranked body and
   the second / third never fire.  For qid `01493427` (gold "25
   postcards"), the top-1 body shows a postcard-display question;
   the literal "25" is in another top-K episode that didn't emit.
   Single-body coverage at the default budget is the cap, not the
   #41 mechanism itself.

4. **Path forward filed as v0.4 follow-up.**  Body-coverage tuning
   (`top_k_bodies` knob + per-body char cap, or a higher default
   `max_tokens` for conversation-shape corpora) is a measured spike,
   not a guess.  Tracked outside this ADR — Stage A verdict on
   ADR-0012 stays REJECT for `accuracy_strict` on this dataset
   shape; the architectural follow-up list is now exhausted at the
   ranking surface.

5. **Net effect of #50 + #41 on the Stage A row:**
   `recall@5: 50 % → 100 %`, `accuracy_strict: 0 / 10 → 0 / 10`.
   Stage C (full haystack) replaces this row when it lands.

## Issue #54 — `RecallResponse.recall_telemetry` (precondition for Stage C)

The `body_count == 1 on every fired call` claim above came from
manual log inspection. That was tolerable for a 10-question pilot
but unworkable for Stage C (100Q × 4 SUTs) and the body-coverage
tuning spike (#52). Issue #54 promotes the per-lane budget vs
emitted-token accounting onto the recall surface itself.

`RecallResponse.recall_telemetry: RecallTelemetry` carries:

- `budget_max_tokens` — the input cap the caller passed.
- `fact_budget`, `excerpt_budget`, `body_budget` — Stage 6 split,
  computed by the `_compute_budget_split(...)` pure helper (four
  branches: Path A / `wants_excerpt` / hybrid / no-signal).
- `fact_tokens_emitted`, `excerpt_tokens_emitted`,
  `body_tokens_emitted` — sum of `_approx_tokens` per lane over the
  rows that actually fired.
- `fact_count`, `excerpt_count`, `body_count` — duplicate
  `len(facts | excerpts | episode_fallback)` so harness JSON dumps
  stay self-describing without re-walking the response.
- `body_first_row_oversize` — surfaces the always-emit-first guard
  in `_build_episode_body_rows`. When True, `body_count == 1` and
  `body_tokens_emitted > body_budget` — distinguishes "budget too
  tight, raise it" from "single row barely fit, split is healthy".

The Q10 `gnokee_adapter.py` flattens the telemetry into each
per-question `meta` dict, so Stage C dumps land with the data
already attached. Consequence: #52 body-coverage tuning becomes
data-driven (knob → distribution shift on `body_count` /
`body_first_row_oversize`) instead of hypothesis-driven.

## v0.3 status decision (2026-05-09)

**Status flipped Draft → Accepted-with-caveat.** Stage C is deferred
post-v0.3-tag.

### Why defer

1. **Stage C cost vs information gain is dominated by #52.** Pilot is
   100 Q × full ~47-session haystack × 5 SUTs × ~9h × ~$25. Running
   that *before* #52 lands measures the gnokee row at known-broken
   body coverage (every smoke sample shows `body_first_row_oversize =
   True` and overshoot ≈ 56× — see § Issue #54 above). The expensive
   row would invalidate immediately on the next tuning lever.

2. **The smoke run already saturated the diagnostic signal.** 3 / 3
   gold-bearing smoke probes hit `body_count == 1`,
   `body_tokens_emitted ≈ 3700`, `body_budget == 66`. More samples at
   the same configuration give the same conclusion. The `accuracy_strict
   = 0/10` from Stage A re-run (§ Issue #50 + #41 verification) is
   architecturally explained.

3. **#56 (lite-mode ingest does not write the Episodic node) blocks
   the cheapest iteration loop.** Until #56 lands, Q10 cannot use
   `extract=False` to skip the LLM-extraction wall time on the gnokee
   row of Stage C. Either fix #56 + iterate cheaply, or spend the full
   $25 / 9h with the bottleneck unfixed. Both paths argue for "wait
   one ramp."

### What v0.3 ships under this ADR

- `RecallResponse.recall_telemetry` (§ Issue #54) — the per-call
  observability that makes #52 measurable and Stage C interpretable.
- The Stage A pilot row at `recall@5 = 100 % / accuracy_strict = 0/10`
  with the diagnosis nailed to body coverage (not the ranker).
- Updated Q10 adapter that flattens telemetry into per-question `meta`
  dicts; future Stage C runs land with the data automatically.
- (#16) Integration-patterns doc explaining lite-mode + deferred
  extraction so v0.3 consumers can ingest at LLM-free latency without
  hitting the #56 footgun.

### What Stage C confirms when it runs (post-v0.3)

- Whether `accuracy_strict` lifts measurably after #52 ships.
- Whether the cross-tool table positions gnokee within ±5 pp of the
  Mem0 / Graphiti-alone / Zep-OSS / basic-memory distribution.
- Whether the body-count distribution at 100 Q matches the smoke
  sample's saturated `body_count == 1` (sanity).

If Stage C confirms the Stage A diagnosis at scale: this ADR's status
flips Accepted-with-caveat → Accepted, no rewrite required. If Stage C
surfaces a new failure mode: a follow-up ADR opens. Either way, v0.3
is not gated on the cost.

## Q12 spike — synth abstention is symptom, not cause (2026-05-10)

Issue [#62] hypothesised that synth abstention bias was the dominant
cause of `accuracy_strict = 0/30` at the 20-session haystack. Q12 spike
falsifies that hypothesis.

### What landed

- `synthesize.py` gained `SYNTH_SYSTEM_V2` + `--prompt-version v2`
  flag. v2 explicitly permits paraphrase, aggregation, and counting
  from snippets, and reserves "I don't know." for "memories clearly
  unrelated to the question."
- `judge.py` split `wrong` into two row-level outcomes:
  `abstain` (auto-tagged when candidate is empty / "I don't know.",
  set BEFORE the judge runs) and `wrong` (judge attempted comparison
  and rejected). Summary now reports `abstain_rate`,
  `accuracy_strict_attempted`, and `accuracy_lenient_attempted` in
  addition to the original `accuracy_strict / accuracy_lenient`.
- `judge_version` bumped `q10_judge_v1` → `q12_judge_v2`.

### Re-run on `stageC_30q20s.json`

Same input rows as the original Stage C-pilot, no SUT re-run, only
`synthesize.py` + `judge.py` re-execution. Cost ≈ $0.05 total.

| SUT | synth | abstain | wrong | correct | partial | strict_attempted |
|---|---|---|---|---|---|---|
| gnokee | v1 | 30 / 30 | 0 | 0 | 0 | n/a (no attempts) |
| gnokee | v2 | 29 / 30 | 1 | **0** | 0 | 0 / 1 |
| graphiti-alone | v1 | 29 / 30 | 1 | 0 | 0 | 0 / 1 |
| graphiti-alone | v2 | 28 / 30 | 2 | **0** | 0 | 0 / 2 |
| basic-memory | v1 | 29 / 30 | 1 | 0 | 0 | 0 / 1 |
| basic-memory | v2 | 28 / 30 | 2 | **0** | 0 | 0 / 2 |

### Read-out

1. **Prompt iteration alone does not move accuracy.** v2 unlocked
   3 extra attempts across 90 rows (5 vs 2). All 5 attempts were
   judged `wrong`. `accuracy_strict_attempted` = 0/5 even after
   loosening the abstention rule.
2. **Synth abstention is downstream of retrieval, not a separate
   bottleneck.** When forced to attempt, the synth model produces
   wrong answers because the gold session is not in the retrieved
   top-k. Loosening abstention turns "I don't know" into "fabricated
   wrong answer" — net zero gain on strict, and arguably worse for
   user trust.
3. **basic-memory's 41.2 % `any_hit` did not translate to attempts.**
   At 41 % retrieval recall, basic-memory still abstained 28/30 under
   v2. The retrieved snippets contain related content but not the
   exact answer-shape the synth needs to produce a numeric / dated /
   named answer. This is consistent with the LongMemEval-S finding
   that retrieval recall ≠ end-to-end accuracy.
4. **The `accuracy_strict_attempted` metric (Prong 4) is the keeper.**
   Without it, "0 / 30 correct" hides whether the model declined or
   failed; with it, future spikes can distinguish a synth-side
   regression (rising attempted-wrong) from a retrieval-side regression
   (rising abstain).

### Status — issue [#62] CLOSED-AS-FALSIFIED

The four-prong investigation surface in [#62] reduces to:

- **Prong 1 (prompt iter)** — REJECTED. Q12 spike, this section.
- **Prong 4 (lenient + abstain split)** — LANDED. New metrics in
  `q12_judge_v2`; future Stage C runs report them by default.
- **Prong 2 (rerank top-k by literal-answer presence)** — DEFERRED to
  retrieval-side work, since the bottleneck is retrieval. Tracked
  under Q11 follow-up rather than as a synth-side fix.
- **Prong 3 (separate answer-extraction stage)** — DEFERRED. Same
  reasoning: extraction can only extract what retrieval surfaced.

### What this means for the ADR-0012 verdict

- ADR-0012 status remains **Accepted**. Stage C-pilot's `0/30 strict`
  is genuine — it is not a synth-prompt artefact.
- The "synth abstention dominates" hypothesis is removed from
  Outstanding-for-v0.3.x. The retrieval-recall hypothesis (already
  open under [#42] / Q11 / `top_k_bodies`) remains the load-bearing
  follow-up.
- Q10 spike artefacts: `stageC_30q20s_synth_v1.json` (renamed copy
  of the original synth run), `stageC_30q20s_synth_v2.json`,
  `stageC_30q20s_synth_v1_rejudged.json`,
  `stageC_30q20s_synth_v2_judged.json`.

[#42]: https://github.com/gnokeelabs/gnokee/issues/42

## Stage C tooling — parallelism + Zep CE re-enabled (2026-05-10)

Two infrastructure landings unblock the original "100 Q × full
~47-session haystack × Track 1 + Track 2" Stage C without changing
the methodology or the verdict.

### `--per-sut-concurrency` knob ([#63] / PR #66)

`evals/spike_q10_cross_tool/run.py` now fans out per-question execution
within each SUT via `asyncio.gather` + `asyncio.Semaphore` keyed on the
new `--per-sut-concurrency` flag (default 4). Each adapter's existing
backend pooling carries the concurrent load.

- **Wall-clock impact**: at the issue-reported 5–6 min / Q baseline,
  full Stage C drops from ~30 h serial to ~7–8 h on a laptop.
- **Methodology impact**: none. Fairness across SUTs is preserved
  because the semaphore applies uniformly. Per-SUT serial wrapping
  remains so cold-starts and per-SUT JSON checkpoints stay clean.
- **Robustness**: `one_run()` now catches `BaseException` (not just
  `Exception`) so a `SystemExit` / `KeyboardInterrupt` / OS kill
  inside one question records `ingest_error=…` for that row instead
  of silently terminating the whole SUT pass. mem0 adapter adds a
  Track 2 1-shot Ollama healthcheck (`GET /api/tags`, 5 s timeout)
  that raises `Mem0BackendUnavailableError` early if Ollama is down.
  Track 1 mem0 ingest is unchanged. Root cause for the original
  silent crash (suspected Ollama OOM or `httpx.RemoteProtocolError`)
  is still undiagnosed; this is defence-in-depth, not a fix.

### Zep CE compose digest pin ([#64] / PR #67)

`evals/spike_q10_cross_tool/docker-compose.zep.yml` was rewritten to
pin three OCI digests + bind-mount a YAML config:

- `ghcr.io/getzep/zep:0.27.2@sha256:840e31b5ee3cbd0bad3171d88dc6f9b55589e64834840e3b81893076b99d5516`
- `ghcr.io/getzep/zep-nlp-server:0.4.2@sha256:ef7a280a8c8a09b3ee4da7f67d4188444d5833fc84777b9a8483d1e20563d37c`
- `ghcr.io/getzep/postgres:postgres-15.2-bullseye-pgvector@sha256:322a746086a594eeaf2b102beba94c82b1640d7e27af1d1916586ff2e090d23d`

Two preconditions Q10's original compose missed (#64 caught one):

1. Zep CE 0.27.2 reads `store.type` from the bind-mounted
   `zep.config.yaml`, not the previously-set `ZEP_MEMORY_STORE_TYPE`
   env var.
2. `ZEP_OPENAI_API_KEY` is a **hard boot precondition** in Zep CE,
   even when `extractors.*.embeddings.service: local` is configured.
   Compose now defaults to a placeholder string; override only if
   YAML extractors flip to `service: openai`.

A bonus root cause beyond #64's scope: vanilla `postgres:15-alpine`
ships without pgvector, so Zep's first-boot migration crashes on
`CREATE EXTENSION vector`. The pinned `getzep/postgres` digest above
ships pgvector pre-built.

A new `evals/spike_q10_cross_tool/smoke_zep_compose.py` brings the
stack up, polls `/healthz` for ≤60 s, AND verifies the container is
still running (catches Zep's 200-on-fatal failure mode), then tears
down. `--skip-if-no-docker` keeps CI honest in environments without a
daemon.

**Implication for the verdict**: Stage C-pilot's 3-SUT verdict
(gnokee + graphiti-alone + basic-memory, all 0/30 strict) stands as
recorded. Zep CE is now un-deferred — the next Stage C pass can
include it as a 4th SUT under Track 1 without further infrastructure
work. Mem0 Track 2 (re-embedded with bge-m3) is unblocked by the
mem0 adapter healthcheck + run.py BaseException catch from #66.

[#63]: https://github.com/gnokeelabs/gnokee/issues/63
[#64]: https://github.com/gnokeelabs/gnokee/issues/64

## Stage C addendum — Q18 ingest-gap finding (2026-05-12)

[Spike Q18](../../evals/spike_q18_recall_at_k_diagnostic/) re-queried
the 2026-05-10 `stageC_30q20s` tenants at `top_k=100` (no fresh
ingest, no LLM cost — query-only against pre-existing tenants).
Verdict: **`INGEST_GAP_NOT_RETRIEVAL_GAP`**. The 0.10 headline in
§ Stage C is not evidence for any retrieval-side intervention.

### Re-grade

The 0.10 / 0.20 / 0.00 figures in § Stage C divide by N = 30. Of
those 30:

- **13 / 30 questions have no gold session inside the 20-session
  truncation** — structurally unrecoverable by any tool on this
  corpus shape. Same constraint ADR-0012 § Stage A read-out item 4
  flagged ("10-session truncation is structural"); Q18 quantifies it
  at 20-session truncation.
- **17 / 30 are measurable** — gold session in haystack.

Measurable-denominator re-grade:

| SUT | `hits / 30` (published) | `hits / 17 measurable` | Gold-in-storage rate |
|---|---|---|---|
| `gnokee` | 3 / 30 = 0.100 | 3 / 17 = 0.176 | **3 / 17 = 0.176** |
| `basic-memory` | 7 / 30 = 0.233 | 7 / 17 = 0.412 | n / a (FTS5 over sqlite, no Graphiti) |
| `graphiti-alone` | 0 / 30 = 0.000 | 0 / 17 = 0.000 | Inherits gnokee's Graphiti path → same silent-drop expected |

The cross-tool ranking is preserved; the magnitude of gnokee's
underperformance halves once the corpus-truncation noise is removed
(0.10 → 0.176; basic-memory 0.23 → 0.41).

### Where gnokee actually fails

For each row where gold is in haystack but not in retrieval set,
Q18 § Phase 3 queried `episode_metadata` directly for the gold
`our_id`:

```
14 / 14 `beyond` rows have ZERO gold episodes in storage.
```

**The 0.10 baseline is 100 % an ingest-path failure.** Graphiti's
`add_episode` returned success and emitted orphan-edge warnings
(`Target entity not found in nodes for edge relation: ACCESS /
PRESENTS / BROWSES / …`) for the dropped sessions; gnokee's
`ingest_episode` trusted Graphiti's success return and did not
write the `Episodic` node or `content_embedding` for those sessions
either. The episodes silently vanished.

On the 3 measurable rows where gold survived ingest, retrieval
scored:

- gold rank 1, 1, 3 — **3 / 3 = 100 % recall@5** on stored episodes.

So gnokee's retrieval, on what it can see, is at ceiling for this
corpus. ADR-0012 § Stage A read-out item 1 ("gnokee retrieves the
right session 50 % of the time but answers none of them") was
measuring the joint distribution of ingest survival × retrieval
ranking; Q18 separates the two axes and lands the root cause one
stage upstream from where Stage A located it.

### Implications for v0.6 planning

1. **Retrieval-side options (span-level chunked retrieval,
   cross-encoder rerank, query decomposition) are wasted spend on
   this corpus.** Gold either survives ingest and lands in top-5
   (3 / 3), or doesn't survive ingest at all (14 / 17). There is no
   middle bucket for rerank or chunking to address.

2. **Ingest-hardening becomes the highest-leverage retrieval-quality
   intervention.** Three candidates filed as the Z-series in the new
   tracking issue:

   - **Z1**: always-write `Episodic` + `content_embedding` regardless
     of Graphiti extraction outcome. Treat Graphiti's extraction lane
     as enhancement, not source-of-truth for "is this episode
     stored." Spirit of ADR-0012 Path A, made default-on.
   - **Z2**: lite-mode default for narrative episodes
     (`source_type == "chat"` or similar). Skip Graphiti for prose;
     content_embedding + BM25 carry retrieval.
   - **Z3**: `recall_telemetry.episodes_dropped_during_extraction`
     counter — surface the silent-failure footgun even before Z1/Z2
     ship.

3. **Cross-tool publish posture** — gnokee's measurable-denominator
   recall@5 = 0.176 is still under `basic-memory`'s 0.41 and
   nowhere near publishable. Both Q18 and ADR-0019 § LongMemEval-S
   publish stance (#81 verdict, 2026-05-12) hold: defer publish.
   v0.6 re-spike is now gated on Z1 / Z2 landing, not on #88 / #89 /
   #102 alone.

4. **Spike-author discipline** — every spike must verify ingest
   completeness before scoring retrieval. Q18 update lands in
   [`docs/evals/methodology.md`](../evals/methodology.md) §
   "Authoring a new spike": pre-flight `count(distinct our_id) ==
   expected` per tenant. Q1 – Q13 sweep is filed under
   [#107](https://github.com/gnokeelabs/gnokee/issues/107) (Q14.1
   threshold-semantics sweep) — extend that scope to cover
   ingest-completeness pre-flight as well.

### Cross-refs

- [Spike Q18 README](../../evals/spike_q18_recall_at_k_diagnostic/README.md)
  — methodology + per-row results.
- ADR-0019 § LongMemEval-S publish stance (#81 verdict, 2026-05-12)
  — Q18 confirms that amendment's "no v0.5 retrieval-primitive
  change moves the number" architectural read, but for a different
  reason than that amendment stated: retrieval is at ceiling, the
  bottleneck is one stage upstream.
- Issue tracking the Z-series ingest-hardening — see new tracking
  issue (filed 2026-05-12).

## § v0.6 ingest hardening (2026-05-15)

Q18 (2026-05-12) found that the 0.10 recall@5 baseline measured in § Stage C was 100% an ingest-path failure, not a retrieval-path failure: 14/17 measurable LongMemEval-S rows had gold sessions silently dropped from `episode_metadata` during the 2026-05-10 stageC ingest at `--per-sut-concurrency 4`.

ADR-0023 (v0.6 Z1 storage-first) lands the fix: gnokee writes Episodic + episode_metadata + content_embedding FIRST using a gnokee-generated uuid4; Graphiti's `add_episode(uuid=X)` runs after as best-effort enhancement, wrapped in adaptive retry. On graphiti failure, episode stays retrievable; entities can be rehydrated via `maintenance.run_deferred_extraction`.

The original Stage C verdict (`stage_c_recall_at_5 = 0.10`) is **not invalidated**, but its interpretation changes: the magnitude reflects ingest losses, not retrieval misses. Once v0.6 ships, Stage C will be re-measured against the same corpus. Expected: ≥ 0.80 recall@5 on measurable (per Q18 § Per-bucket summary — gold rises to top-5 in 3/3 stored cases at v0.5; v0.6 widens the "stored" denominator from 3 to ≥14 of 17).

Path A spirit (recall fallback when fact_count==0) remains valid for retrieval-side robustness. ADR-0023 is the storage-side counterpart.

Cross-ref: ADR-0023, Issue [#111](https://github.com/gnokeelabs/gnokee/issues/111), [Spike Q18](../../evals/spike_q18_recall_at_k_diagnostic/README.md).
