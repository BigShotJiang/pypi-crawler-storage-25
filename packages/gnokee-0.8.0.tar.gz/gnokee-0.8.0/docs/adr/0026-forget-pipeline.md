# ADR-0026: Forget pipeline — hard-delete with verifiable audit + audit-row-as-journal

- **Status:** Proposed
- **Date:** 2026-05-16
- **Driver:** Issue [#130](https://github.com/gnokeelabs/gnokee/issues/130) — forget-cascade: include `ingest_journal` in tenant-deletion sweep
- **Supersedes:** none
- **Amends:** [ADR-0022](0022-refusal-posture.md) (extends the `cannot_forget_chain_node` refusal surface); [ADR-0023](0023-gnokee-owns-episode-storage.md) (adds a write-path that removes what ADR-0023 asserts gnokee owns); [ADR-0024](0024-ingest-crash-recovery-journal.md) (extends the `gnokee_maintenance` crash-recovery pattern to the forget path)
- **Refs:** [ADR-0004](0004-gnokee-owns-retrieval.md), [ADR-0022](0022-refusal-posture.md), [ADR-0023](0023-gnokee-owns-episode-storage.md), [ADR-0024](0024-ingest-crash-recovery-journal.md), [Spec: docs/superpowers/specs/2026-05-16-gnokee-forget-pipeline-design.md](../superpowers/specs/2026-05-16-gnokee-forget-pipeline-design.md), [Plan: docs/superpowers/plans/2026-05-16-gnokee-forget-pipeline.md](../superpowers/plans/2026-05-16-gnokee-forget-pipeline.md)

gnokee's `architecture.md §Forgetting` names three deletion modes. Mode 1 (soft supersession via `EpisodeIn.corrects:`) shipped in v0.2.1. Mode 2 (hard delete with `ForgetReceipt`) has been stubbed since the v0.5 MCP surface but never shipped a production pipeline. Mode 3 (cryptographic erasure) is deferred because gnokee never holds DEKs; the receipt surfaces affected `key_id`s so the consumer destroys keys in their own KMS. Issue #130, surfaced during ADR-0024 review by `postgres-pgvector-specialist`, found that the planned tenant-forget sweep did not include `ingest_journal` — leaving the journal as an orphaned audit trail after tenant deletion. This ADR ships the complete Mode-2 pipeline, closes #130, and establishes the `gnokee_maintenance.forget_audit` table as both an audit record and a crash-recovery journal (the same audit-row-as-journal pattern introduced by ADR-0024).

## Context

`docs/architecture.md §Forgetting` enumerates three forgetting modes:

- **Mode 1 — soft supersession:** `EpisodeIn.corrects:` marks an episode as superseded in place; the original remains readable via time-travel queries. Shipped v0.2.1.
- **Mode 2 — hard delete:** The episode row and all derived data are physically removed from both Postgres and Neo4j. A `ForgetReceipt` proves the deletion happened. `affected_key_ids` surfaces DEK identifiers for consumer-side KMS destruction. **This ADR ships Mode 2.**
- **Mode 3 — cryptographic erasure:** The ciphertext stays on backup but the DEK is destroyed; the data is permanently unreadable without physically deleting rows. Deferred — gnokee never holds DEKs, so Mode 3 is a documentation note, not a code path. The receipt's `affected_key_ids` field is the handoff point for any consumer who wants to approximate Mode 3 after a Mode 2 call.

Issue #130 surfaced the `ingest_journal` cascade gap during ADR-0024 review: the planned `gnokee_forget_tenant` sweep DELETE'd `episode_metadata` (and its FK-cascade children) but left `ingest_journal` rows intact, because `ingest_journal` has no FK to `episode_metadata` (it was designed append-only, per ADR-0024). After a tenant forget, `ingest_journal` would remain as orphaned metadata about a tenant that no longer exists. Mode-2 must explicitly DELETE from `ingest_journal` before or at the same time as `episode_metadata`.

The pre-ADR-0026 state also has no production forget surface: the Q5 spike (`evals/spike_q5_forgetting/`) exercised an in-memory map + raw Cypher but gnokee exposes no MCP tool and no audit trail. The `AGENTS.md` listing of `gnokee_forget` as an example tool name has never had a real implementation behind it.

## Decision

**gnokee ships two MCP tools — `gnokee_forget_episode` and `gnokee_forget_tenant` — backed by a `ForgetPipeline` that runs a SERIALIZABLE Postgres transaction covering both the sweep DELETEs and an audit-row pair (begin→commit), followed by a separate Neo4j sweep. The `gnokee_maintenance.forget_audit` table is schema-isolated so it survives tenant deletion. `resume_forget` retries Neo4j-only failures using the frozen `cascade_uuids` from the committed audit row.**

### MCP surface — two tools

```
gnokee_forget_episode(tenant_id, episode_uuid, *, cascade=False, reason, actor=None)
gnokee_forget_tenant(tenant_id, *, dry_run=True, reason, actor=None)
```

Both return `ForgetReceipt`. The Python API mirrors at `gnokee.forget.forget_episode(...)` and `gnokee.forget.forget_tenant(...)`.

**`gnokee_forget_episode`** accepts `cascade: bool = False`. When `cascade=False` and the target episode has at least one supersession descendant, the tool refuses with `cannot_forget_chain_node` (ADR-0022 refusal posture):

```json
{
  "error": "cannot_forget_chain_node",
  "descendant_count": 7,
  "deepest_descendant_uuid": "<uuid>",
  "hint": "Use gnokee_history_of(uuid=<target>) to inspect the chain. Resubmit with cascade=True only after explicit operator approval — this is permanent."
}
```

The full descendant UUID list is never inlined in the refusal (compact response contract). When `cascade=True`, the tool hard-deletes the target and all descendants transitively. Ancestors are never cascaded.

**`gnokee_forget_tenant`** defaults to `dry_run=True` — the first call is always a planning call that returns counts without writing. The caller MUST issue a second call with `dry_run=False` to execute the deletion. No `confirm_tenant_id` parameter — the two-call ceremony is the guard.

**DAG behaviour matrix:**

| Has ancestors? | Has descendants? | `cascade=False` | `cascade=True` |
|---|---|---|---|
| No | No | hard-delete this | same |
| Yes | No | hard-delete this; UPDATE clears ancestors' `superseded_by` pointer | same |
| No | Yes | REFUSE `cannot_forget_chain_node` | hard-delete this + all descendants |
| Yes | Yes | REFUSE | hard-delete this + all descendants |

### Audit storage — `gnokee_maintenance.forget_audit`

`forget_audit` is placed in a dedicated `gnokee_maintenance` schema, not the public schema. This ensures the table survives a `gnokee_forget_tenant` call — which is its purpose (proof the deletion happened). Schema-level isolation means the app role retains full CRUD but no SQL-pass-through surface in gnokee today reaches this schema.

```sql
-- Migration 0017: 0017_forget_audit.sql
CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.forget_audit (
    audit_id          UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id         TEXT        NOT NULL,
    scope             TEXT        NOT NULL CHECK (scope IN ('episode','tenant')),
    episode_uuid      UUID,
    cascade           BOOLEAN     NOT NULL DEFAULT FALSE,
    dry_run           BOOLEAN     NOT NULL DEFAULT FALSE,
    state             TEXT        NOT NULL CHECK (state IN ('begin','commit','fail')),
    actor             TEXT,
    reason            TEXT        NOT NULL,
    receipt           JSONB,        -- populated at 'commit'; carries frozen cascade UUID list + per-uuid bi-temporal snapshot
    error             TEXT,         -- populated at 'fail'
    cascade_uuids     JSONB,        -- frozen at begin time when cascade=True; resume_forget reads this exact set
    bitemporal_snap   JSONB,        -- per-deleted-uuid {asserted_at, valid_at, valid_until} captured pre-DELETE
    started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at       TIMESTAMPTZ,
    PRIMARY KEY (audit_id),
    CHECK (
        (scope = 'episode' AND episode_uuid IS NOT NULL)
        OR
        (scope = 'tenant'  AND episode_uuid IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS forget_audit_resumable_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'begin';
```

The `audit_id` primary key (not a `(tenant_id, audit_id)` composite) allows the audit row to remain addressable after the tenant is deleted.

### Pipeline stages and transaction shape

| Stage | Action | Tx |
|---|---|---|
| 1 | Validate args; load existing `commit`-state audit row (idempotency check) | none |
| 2 | DAG walk (episode tool): refuse on chain-node if `cascade=False`; freeze descendant set | none |
| 3 | OPEN serializable Postgres tx; `SET LOCAL app.current_tenant = $1`; capture pre-DELETE `bitemporal_snap`; capture `affected_key_ids` from `episode_body_encrypted` | begin tx |
| 4 | INSERT `forget_audit` row `state='begin'` + `cascade_uuids` + `bitemporal_snap` | same tx |
| 5 | Postgres sweep — DELETE from `fact_contradiction`, `ingest_journal`, `episode_metadata` (per scope; FK CASCADE flows to all child tables) | same tx |
| 6 | UPDATE `forget_audit` SET `state='commit'`, `receipt`, `finished_at`; COMMIT tx | same tx |
| 7 | Neo4j sweep — `DETACH DELETE` per `group_id` (tenant) or by uuid set (episode/cascade) | separate Neo4j tx |
| 8 | If Neo4j sweep fails — open a NEW Postgres tx; INSERT `state='fail'` audit row whose `error` JSONB carries original `audit_id`; raise | new Postgres tx |
| 9 | Return `ForgetReceipt` | n/a |

**Critical invariant:** Stages 4–6 are inside one Postgres transaction. If the Postgres sweep fails, the `state='begin'` audit row rolls back with it — `state='begin'` rows in a committed state therefore do NOT exist after a Postgres-tx crash. A `state='commit'` row is the only proof that Postgres was swept. The Neo4j sweep runs in a separate phase post-commit. If it fails, gnokee writes a separate `state='fail'` audit row (different `audit_id`) referencing the original via its `error` payload.

**Per-tenant Postgres sweep order:**

```sql
DELETE FROM fact_contradiction WHERE tenant_id = $1;
DELETE FROM ingest_journal     WHERE tenant_id = $1;   -- closes #130
DELETE FROM episode_metadata   WHERE tenant_id = $1;
-- FK CASCADE from episode_metadata flows to:
--   content_embedding, content_text, episode_body_encrypted,
--   episode_extracted_quote, lab_record, med_record
```

Tables without FK cascade go first (`fact_contradiction`, `ingest_journal`) so they hold no row-locks when `episode_metadata`'s cascade fires.

**Per-episode Postgres sweep:**

```sql
SELECT key_id FROM episode_body_encrypted WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]) FOR SHARE;
SELECT episode_uuid, asserted_at, valid_at, valid_until
  FROM episode_metadata
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]) FOR UPDATE;
UPDATE episode_metadata SET superseded_by = NULL
 WHERE tenant_id=$1 AND superseded_by = ANY($2::uuid[]);
DELETE FROM fact_contradiction
 WHERE tenant_id=$1 AND (fact_uuid_a = ANY($2::uuid[]) OR fact_uuid_b = ANY($2::uuid[]));
DELETE FROM ingest_journal
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]);
DELETE FROM episode_metadata
 WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]);
```

`$2` is the cascade-frozen UUID set. The `UPDATE ... SET superseded_by = NULL` is critical: `episode_metadata.superseded_by` has no FK constraint. Without this UPDATE, ancestors retain a dangling pointer to the deleted UUID and `gnokee_history_of` walks into a void.

**Neo4j sweep:**

```cypher
-- Tenant scope
MATCH (n {group_id: $tenant_id}) DETACH DELETE n RETURN count(n) AS deleted_nodes;

-- Episode scope (with cascade)
UNWIND $uuids AS uuid
MATCH (ep:Episodic {uuid: uuid, group_id: $tenant_id})
DETACH DELETE ep
RETURN count(ep) AS deleted_nodes;

-- Orphan-entity cleanup (episode scope, post-episode delete)
MATCH (e:Entity {group_id: $tenant_id})
WHERE NOT EXISTS { MATCH (e)<-[:MENTIONS]-(:Episodic) }
DETACH DELETE e;
```

### Bi-temporal honesty and DAG semantics

The DAG walk uses **no temporal predicate** — pure reachability over the `superseded_by` pointer graph. Implementation: recursive CTE inside the SERIALIZABLE Postgres transaction (stage 3) so the descendant set is determined under the same snapshot as the DELETE. The frozen UUID set is written to `forget_audit.cascade_uuids` before any DELETE fires.

When `forget(B)` commits, ancestors' `superseded_by = B.uuid` is set to NULL. The ancestors' `asserted_until` and `valid_until` are **not reopened**. A's prior assertion that B corrected it was historically true; erasing B does not retroactively unmake the correction. A is left in state "transaction-time bounded, world-time bounded, no successor pointer" — readable via time-travel queries with `as_of <= A.asserted_until`, not surfaced as live.

Before any DELETE fires, the pipeline SELECTs `(episode_uuid, asserted_at, valid_at, valid_until)` for the entire cascade set and writes that to `forget_audit.bitemporal_snap`. A compliance auditor can answer "which world-time + transaction-time window did this forget cover?" without reconstructing deleted data.

**Isolation:** SERIALIZABLE isolation on the forget Postgres tx. Concurrent ingest adding a new descendant between the DAG-walk and the DELETE is detected as a `serialization_failure`; the pipeline retries up to 3× with jittered backoff. `SET LOCAL app.current_tenant = $1` inside the tx ensures RLS-gated DELETEs operate on the right tenant scope — without this, `ingest_journal`'s RLS policy returns zero rows and the cascade is silently broken.

### Crash recovery — `resume_forget`

`src/gnokee/maintenance/resume_forget.py` mirrors `maintenance.resume_ingest` from [ADR-0024](0024-ingest-crash-recovery-journal.md).

**Resumability matrix:**

| Original outcome | `forget_audit` state | What resume does |
|---|---|---|
| Crash before stage 4 begin INSERT | no row | nothing — caller re-issues |
| Postgres tx rolled back (crash mid stages 4–6) | row was never committed; no surviving audit row | same — caller re-issues |
| Postgres committed (stage 6), Neo4j sweep failed (stage 7) | TWO rows: original `state='commit'` + new `state='fail'` linking back via `error` JSONB | retry Neo4j sweep using `cascade_uuids` from the linked `state='commit'` row; on success UPDATE fail row to `state='commit'` |
| All stages succeeded | single `state='commit'` row | resume is a no-op |

All DELETEs are idempotent (empty result = no error). The frozen `cascade_uuids` ensures replay scope is identical to the original. `postgres_rows_deleted = 0` on replay is the expected idempotent outcome.

```python
async def scan_resumable_forgets(tenant_id: str) -> list[ResumableForget]: ...
async def resume_forget(tenant_id: str, *, audit_id: UUID | None = None) -> list[ForgetReceiptDetail]: ...
```

CLI surface (not exposed via MCP, matching `resume_ingest` precedent):

```
gnokee maintenance scan-forgets --tenant <t>
gnokee maintenance resume-forget --tenant <t> [--audit-id <uuid>]
```

### Module layout

```
src/gnokee/forget/__init__.py         # public API: forget_episode, forget_tenant
src/gnokee/forget/models.py           # ForgetEpisodeIn, ForgetTenantIn, ForgetReceipt, ForgetReceiptDetail
src/gnokee/forget/pipeline.py         # ForgetPipeline class — stages 1–9
src/gnokee/forget/dag.py              # recursive CTE descendant walk
src/gnokee/forget/audit.py            # gnokee_maintenance.forget_audit CRUD
src/gnokee/maintenance/resume_forget.py
src/gnokee/storage/graphiti_store.py  # add: remove_episode_by_uuid, remove_tenant_group
```

## Consequences

### Positive

- **Mode 2 (hard delete) is production-ready.** `gnokee_forget_episode` and `gnokee_forget_tenant` give operators a verifiable, audited, crash-recoverable path to physically remove data from both stores.
- **Issue #130 closed.** `ingest_journal` is explicitly swept in both the per-tenant and per-episode Postgres DELETE sequences. The cascade gap is closed.
- **Audit-row-as-journal pattern extended.** The `gnokee_maintenance.forget_audit` table functions as both an audit record and a crash-recovery journal — the same two-row-pair design from [ADR-0024](0024-ingest-crash-recovery-journal.md). Operators and `resume_forget` share the same source of truth.
- **Bi-temporal snapshot preserved in audit.** `bitemporal_snap` JSONB captures `(asserted_at, valid_at, valid_until)` for every deleted episode pre-DELETE. Compliance auditors can reconstruct the time-axis window of any forget without accessing the deleted data.
- **Schema-isolated audit survival.** `gnokee_maintenance.forget_audit` rows survive `gnokee_forget_tenant(t)`. The proof of deletion outlives the deleted tenant.
- **Refusal posture enforced at chain nodes.** Mid-chain forget without explicit `cascade=True` is refused with a bounded, LLM-safe payload (ADR-0022 contract). Operators walk the DAG via `gnokee_history_of` before re-submitting.
- **DEK handoff surfaces on receipt.** `affected_key_ids[]` on `ForgetReceipt` is the handoff point for consumer-side KMS destruction, enabling an out-of-band approximation of Mode 3 without gnokee holding keys.

### Negative — accepted

- **Time-travel through pre-forget windows is broken by Mode 2.** Hard-delete is explicitly incompatible with `valid_at` time-travel through pre-forget windows. `gnokee_query(..., valid_at=<T before forget>)` will NOT surface forgotten episodes even if T predates the forget operation. Mode 1 (soft supersession via `EpisodeIn.corrects:`) is the time-travel-preserving path.
- **`gnokee_history_of(A)` after `forget(B, cascade=True)` shows a truncated lineage.** The system cannot distinguish "A was never corrected" from "A was corrected by B which was later forgotten." Compliance trade-off accepted; `bitemporal_snap` in the audit row is the record that the truncation occurred.
- **Ancestor `asserted_until`/`valid_until` are not reopened after `forget(B)`.** A's prior assertion that B corrected it remains historically closed. Ancestors are left with `superseded_by = NULL` but bounded transaction-time and world-time axes — readable via time-travel as-of A's assertion window, not surfaced as live.
- **`forget_audit` grows unbounded** without operator pruning. Default retention is forever. Operator CLI for pruning is a follow-up issue.
- **Single-statement Neo4j DETACH on huge tenants** may OOM. The chunked path is a telemetry-gated follow-up; single-statement ships in v1.
- **Tenant quiescence during forget is not enforced.** Concurrent ingest may surface as `serialization_failure` retries on both sides. Documented in pipeline docstring and `architecture.md`. Advisory-lock mitigation deferred to a follow-up if telemetry shows real contention.
- **No cryptographic-erasure mode as a distinct code path in v1.** `affected_key_ids[]` on the receipt is the consumer handoff; gnokee never touches keys.
- **`reason` is required free-text capped at 500 chars.** gnokee does not PII-scan the field. The Pydantic field description warns callers not to include personal data; `forget_audit` survives tenant deletion so the reason is permanently persisted.

## Acceptance evidence

Integration test suite (`tests/integration/test_forget_pipeline.py`) — 14 cases:

1. `test_forget_episode_no_chain` — single fact, both stores clean, receipt counts correct.
2. `test_forget_episode_refuses_chain_node` — A→B→C; `forget(B, cascade=False)` raises `cannot_forget_chain_node` with bounded payload.
3. `test_forget_episode_cascade_descendants` — `forget(B, cascade=True)`: B + C gone, A live, `A.superseded_by = NULL`.
4. `test_forget_episode_idempotent_replay` — second call returns prior receipt with `replayed=True`; no second audit row.
5. `test_forget_episode_encrypted_body` — receipt's `affected_key_ids[]` populated with all DEK ids of cascaded episodes.
6. `test_forget_episode_bitemporal_snap` — audit row's `bitemporal_snap` JSONB captures the deleted episode's `{asserted_at, valid_at, valid_until}`.
7. `test_forget_tenant_dry_run` — `dry_run=True` returns a populated receipt; nothing deleted; no `state='commit'` audit row.
8. `test_forget_tenant_full_sweep` — 5-episode tenant; all per-tenant tables empty after; `ingest_journal` empty (closes #130 explicitly); Neo4j `group_id` wiped.
9. `test_forget_tenant_audit_survives` — `gnokee_maintenance.forget_audit` row readable AFTER the tenant is wiped.
10. `test_resume_forget_after_neo4j_crash` — inject Neo4j fault between stage 6 commit and stage 7; verify `state='fail'` row; retry via `resume_forget` cleans up.
11. `test_serialization_retry` — concurrent ingest + forget on same tenant; both eventually succeed via retry.
12. `test_fact_contradiction_swept` — tenant with contradictions; tenant-forget DELETEs `fact_contradiction` explicitly.
13. `test_ingest_journal_swept_per_tenant` — `ingest_journal` for the tenant is empty after `forget_tenant`. Direct verification of #130's fix.
14. `test_ingest_journal_swept_per_episode` — episode-grain forget also removes the corresponding `ingest_journal` rows.

## Cross-refs

- [ADR-0004](0004-gnokee-owns-retrieval.md) — `created_at` / `asserted_at` / `valid_at` axis invariants; the bi-temporal axes that `bitemporal_snap` captures.
- [ADR-0022](0022-refusal-posture.md) — refusal posture for `cannot_forget_chain_node`; compact bounded payload; surface to operator before retry.
- [ADR-0023](0023-gnokee-owns-episode-storage.md) — gnokee owns episode write; `group_id` is the Neo4j tenant retention key used by the tenant-scope DETACH DELETE.
- [ADR-0024](0024-ingest-crash-recovery-journal.md) — ingest journal; twin precedent for audit-row-as-journal pattern and `gnokee_maintenance` schema isolation.
- `docs/architecture.md §Forgetting` — Mode 1 / Mode 2 / Mode 3 enumeration; this ADR is the authoritative implementation record for Mode 2.
- `AGENTS.md` — `gnokee_forget_episode` and `gnokee_forget_tenant` added to the MCP tool list.
