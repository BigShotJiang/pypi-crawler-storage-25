# ADR-0022: refusal posture — how gnokee signals "no answer from corpus"

- **Status:** Accepted (verdict: ADOPT_OPTION_D, Q17 spike 2026-05-12; amended 2026-05-12 — Option A landed, #94)
- **Date:** 2026-05-12
- **Decider:** Vadim Yuzi
- **Refs:** Issue [#109](https://github.com/gnokeelabs/gnokee/issues/109)
  (consolidates [#77](https://github.com/gnokeelabs/gnokee/issues/77) source-
  grounded refusal Q-suite and [#94](https://github.com/gnokeelabs/gnokee/issues/94)
  refusal posture UX gap).
  Spike: `evals/spike_q17_refusal_posture/` (run `20260511T213407Z.json`).

## Context

NotebookLM ships an explicit "I cannot answer from these sources" refusal when the
corpus does not carry the answer. gnokee today does NOT: when asked an off-topic
question, `gnokee_recall` returns off-topic but grounded facts (satisfies the
zero-hallucination contract, but is a weaker posture than NotebookLM).

Issue #94 calls this a UX gap. Issue #77 requested a Q-suite measuring it. Issue
#109 consolidates: stage the spike, decide the design.

Q41 (PR #93, 2026-05-11) measured Q-X.3 (not-answerable) on a 10-probe home-
renovation corpus and scored 10/10 strict zero-hallucination, but the refusal posture
was implicit (off-topic facts returned). Q17 formalises Q-X.3 across three tenant
shapes (clinical-only, prose-only, mixed), N=30 probes, to ground this ADR.

## Spike verdict (Q17, 2026-05-12)

`evals/spike_q17_refusal_posture/` — 30 probes, 3 tenant shapes.
Result JSON: `evals/spike_q17_refusal_posture/results/20260511T213407Z.json`.

| Metric | Value | Threshold |
|---|---|---|
| N unanswerable probes | 24 | — |
| hallucination_rate | **0%** | <= 5% (gate) |
| explicit_refusal_rate | **0%** | >= 70% (for ADOPT_OPTION_A) |
| implicit_refusal_rate | **100%** | — |
| pass_rate (zero hallucination) | **100%** | — |
| controls pass | 4/6 | — |

**Harness verdict:** `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL`

Two controls failed due to the graphiti literal-extraction gap (ADR-0019 § Follow-up,
issue #90 — accepted). The allergy episode and yoga episode did not produce keyword-
level fact nodes. This does not affect the hallucination measurement; the
`_CONTROLS_PARTIAL` suffix is informational.

**Key finding:** gnokee's explicit_refusal_rate = 0% across all three tenant shapes.
Every out-of-domain query returns grounded but off-topic facts from the corpus.
Zero hallucinations observed (100% Q-X.3 strict). gnokee currently ships Option D
by default.

## Four design options

### Option A: typed `refused: bool` on `RecallResponse`

Post-retrieval check: if `len(facts) == 0 AND len(episode_fallback) == 0`, set
`refused=True` on the response. No change to the retrieval path. The consumer can
branch on `refused` to generate an explicit "I cannot answer" signal.

**Implementation cost:** ~10 LOC in the recall surface + schema field addition.
**Risk:** Low — additive, no retrieval change, no contradiction suppression.
**ADR-0004:** Compatible — gnokee owns retrieval; the signal is a post-retrieval
annotation.
**ADR-0019:** Coherent — `refused=True` correlates with low or null `confidence`.
**AGENTS.md no-auto-resolve:** Safe — the flag does not suppress contradiction facts.

Caveat: today's explicit_refusal_rate is 0% (gnokee always returns something).
Option A's `refused` flag would fire only on the `len(facts) == 0` branch, which
this spike never observed. The flag would be correct but untriggered until gnokee
is extended to return zero facts when cosine similarity falls below a floor. For
Option A to be meaningful in practice, it needs a companion threshold — see
Option B — or a retrieval path change that is out of scope for v0.5.

### Option B: `confidence_floor` empty-set return

Set a `confidence_floor` on the `gnokee_recall` / `gnokee_query` path. When no
fact clears the floor, return an empty fact list. `confidence_floor` is already
present in ADR-0013 (declarative envelope); this option activates it as a refusal
mechanism.

**Risk:** Medium. The Q17 run shows implicit_refusal_rate = 100% — gnokee always
returns something. A floor that causes zero facts to be returned on unanswerable
probes would also need calibration to avoid returning zero facts on answerable
probes. No measured threshold exists. Requires a Q17.1 follow-up spike to pin the
threshold.

Specific risk: if a contradiction pair exists and the floor silences one side, the
no-auto-resolve contract (ADR-0008) is violated. Needs explicit guard.

**ADR-0019:** `confidence_floor` aligns with the ADR-0013 parameter already on the
roadmap. The recency-proxy `confidence` value would need a measured cutoff point.

**Verdict:** Do not ship without Q17.1 calibration spike.

### Option C: consumer-LLM-owned refusal

gnokee does nothing. The consumer LLM receives the fact list (possibly off-topic)
and generates "I cannot answer from these sources" when the facts don't satisfy the
query. This is the current de facto behaviour when a consumer LLM is present.

**Risk for gnokee:** Low. gnokee's zero-hallucination contract still holds.
**Risk for the ecosystem:** The refusal signal is non-deterministic (LLM-generated)
and inconsistent across consumers.
**ADR-0004:** Partial conflict — gnokee "owns retrieval" framing implies gnokee
should own the retrieval-quality signal, which refusal is. Delegating the posture
to the consumer weakens that claim.
**AGENTS.md:** The consumer LLM may auto-resolve contradictions (AGENTS.md "no
auto-resolve" red line applies to gnokee, not the consumer). Option C creates an
escape hatch that consumers may exploit.

**Verdict:** Acceptable only as documentation of de facto behaviour (Option D
framing), not as a deliberate architectural decision to delegate.

### Option D: stay silent (document current posture)

gnokee surfaces off-topic but grounded facts and does not add a `refused` signal.
Document this explicitly as gnokee's v0.5 posture in this ADR. File Option A as
a v0.5.x follow-up.

**Risk:** Zero additional risk. The zero-hallucination contract holds (measured).
**UX gap (#94):** Remains open until Option A lands.
**ADR-0004:** Fully owned — gnokee returns what it finds, retrieval is deterministic.
**ADR-0008 no-auto-resolve:** Safest option — all facts including contradictions
surface.

## Decision

**Ship Option D as the explicit v0.5 posture. File Option A as #94 follow-up.**

Rationale:

1. Q17 live run confirms hallucination_rate = 0% across 24 probes and 3 tenant
   shapes. The zero-hallucination contract holds without any code change.

2. Option D is what gnokee already ships. This ADR makes it a deliberate decision
   rather than silent drift, closes the "UX gap is undocumented" part of #94.

3. Option A is the recommended next step (v0.5.x). It is low-risk, additive, and
   closes #94 with a typed signal. Implementation: add `refused: bool = False` to
   `RecallResponse`; set `True` when `len(facts) == 0 AND len(episode_fallback) == 0`.
   The field is useful only when combined with a retrieval path that can actually
   produce zero facts on unanswerable queries — which requires either a cosine
   threshold or a query-scope constraint. File as a tracked follow-up.

4. Option B (confidence_floor) requires Q17.1 threshold calibration before it can
   be shipped safely. Do not block v0.5 on it.

5. Option C (consumer-LLM-owned) conflicts with ADR-0004's retrieval-ownership
   framing and creates consumer auto-resolve risk. Not recommended.

## Consequences

**Positive:**

- Zero code change for v0.5 — Option D is the current posture.
- ADR closes the "undocumented silence" reading of #94.
- Option A roadmap is explicit; consumers building on v0.5 know the signal is
  coming and can stub `refused` on their side if needed.

**Negative:**

- #94 UX gap remains open until Option A lands. gnokee does not emit "I cannot
  answer from these sources" in v0.5.
- Option B is not ruled out but deferred — teams that want threshold-based refusal
  will need to wait for Q17.1.

## What this does NOT decide

- Exact wording of any "I cannot answer" consumer-facing string. That is a
  consumer surface copy decision (ADR-0021 § Template pattern).
- Refusal posture for clinical reads (`gnokee_lab_query`, `gnokee_med_query`).
  Structured stores already return `null` or empty rows natively — no `refused`
  field needed there.
- Cross-source-type refusal (e.g. query covers both lab and prose; labs found but
  no prose). Issue #102 / Q15 scope.

## Follow-up

- [#94](https://github.com/gnokeelabs/gnokee/issues/94) — Option A landed in v0.5
  (#94). Implementation: `refused: bool = False` on `RecallResponse` (set True when
  `len(facts) == 0 AND len(episode_fallback) == 0`) + `cosine_floor: float | None`
  knob on `recall()` / `gnokee_recall` MCP tool that prunes below-floor episodes at
  stage 3.6, making the refused flag non-trivial in single-tenant default mode.
  Amendment date: 2026-05-12. Closes #94.
- Q17.1 — calibrate confidence_floor threshold for Option B. Requires Q17 corpus
  re-run with varying floor values. Target: v0.6 if v0.5.x Option A closes #94.

## Cross-refs

- ADR-0004 (gnokee owns retrieval) — Option A/D compatible; Option C conflicts.
- ADR-0008 (contradiction storage) — Option D safest; Option B needs guard.
- ADR-0013 (declarative envelope) — Option B uses `confidence_floor` parameter.
- ADR-0019 (confidence model) — recency-proxy `confidence` is the numerical
  correlate of the refusal signal.
- ADR-0021 (consumer surface strategy) — consumer copy decisions are out of scope.
- Issues [#77](https://github.com/gnokeelabs/gnokee/issues/77),
  [#94](https://github.com/gnokeelabs/gnokee/issues/94),
  [#109](https://github.com/gnokeelabs/gnokee/issues/109).
