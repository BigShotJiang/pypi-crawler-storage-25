# ADR-0023: gnokee owns episode storage; Graphiti is enhancement-only

- **Status:** Accepted
- **Date:** 2026-05-15
- **Driver:** Issue [#111](https://github.com/gnokeelabs/gnokee/issues/111) (Q18 silent-drop fix)
- **Supersedes:** none
- **Amends:** ADR-0004 (gnokee owns retrieval), ADR-0012 (cross-tool eval verdict, § Stage C addendum)

## Context

ADR-0004 established that gnokee owns the retrieval surface. The complementary axis — *who owns the storage surface* — was implicit until v0.6. In practice, v0.1 through v0.5 delegated Episodic-node writes to Graphiti's `add_episode`: gnokee called it, trusted its success, and conditioned all downstream Postgres writes on it.

Q18 (2026-05-12, [spike](../../evals/spike_q18_recall_at_k_diagnostic/README.md)) measured that this contract silently drops 14/17 measurable LongMemEval-S rows under concurrent ingest at OpenAI tier-1 200K TPM. Mechanism: Graphiti's internal extraction tasks hit `RateLimitError`, the exception cascades out of `add_episode`, and gnokee's pg-write stage never runs. The episode disappears with no row in any store.

The Q18 verdict was `INGEST_GAP_NOT_RETRIEVAL_GAP`. The 2026-05-12 reproingest narrowed root cause to concurrency × TPM: serial (`conc=1`) preserves 100/100; concurrent (`conc=4`) preserves 74/100.

## Decision

**gnokee owns the Episodic write surface. Graphiti is an enhancement layer that may fail without losing storage.**

Concrete contract for `IngestPipeline.ingest()` from v0.6 onward:

1. **Stage 3.5:** gnokee generates `episode_uuid` (uuid4). gnokee owns the canonical identifier across full / lite / encrypted paths — Graphiti no longer mints it.

2. **Stage 4:** gnokee writes the Episodic node via `GraphitiStore.write_lite_episode` (direct Cypher MERGE; no Graphiti extractor invocation). Properties written: `uuid`, `name`, `group_id=tenant_id`, `source`, `source_description`, `content`, `entity_edges=[]`, `created_at`, `valid_at`. In full mode, `content` is `augment_for_extraction(original)` so the Stage 6 extractor (which reads the existing node body — see § Implementation note) sees the augmented form.

3. **Stage 5:** gnokee writes `episode_metadata` + `content_embedding` + `content_text` + `lab_record` / `med_record` in a single Postgres transaction. On txn failure, Stage 4's lite-Episodic is compensated via `GraphitiStore.remove_lite_episode` (gnokee-owned Cypher `MATCH ... DETACH DELETE` on `(uuid, group_id)` — does not depend on graphiti-core internal indexing).

4. **Stage 6 (enhancement, best-effort):** gnokee calls `graphiti.add_episode(uuid=<gnokee-uuid>, ...)`. Graphiti runs entity extraction and attaches `MENTIONS` / `RELATES_TO` edges to the existing Episodic. The call is wrapped in an `asyncio.Semaphore` (configurable via `extraction_concurrency`, default 2) and an adaptive retry helper (`_retry_enhancement`, max 3 retries, jittered exponential backoff, honours `RateLimitError.retry_after`).

5. **Stage 6b:** if extraction succeeded AND Stage 4 had written augmented content, gnokee calls `GraphitiStore.overwrite_episode_content(content=original)` to restore the Episodic body for honest recall provenance. Failure of 6b is logged-but-non-fatal (Z1 invariant: episode survives over provenance purity).

6. **Stage 6 failure → lite-fallback:** on retry exhaustion or any non-retryable exception, gnokee logs a warning, sets `extraction_deferred=True` on `episode_metadata`, sets `lite_fallback_engaged=True` on the receipt. The episode is retrievable; entities can be rehydrated later via `maintenance.run_deferred_extraction`.

## Implementation note — graphiti `add_episode(uuid=X)` semantic

Pinned by integration test Z1.6 (`tests/integration/test_ingest_z1.py`):

Per graphiti-core 0.29 source at `graphiti_core/graphiti.py:1052-1065`, when `add_episode` is called with `uuid is not None`, the function SHORT-CIRCUITS: it loads the existing `EpisodicNode` via `EpisodicNode.get_by_uuid(driver, uuid)` and uses ITS field values (`content`, `created_at`, `source_description`, `valid_at`, `name`) for the rest of the extraction pipeline. The new-call kwargs (`episode_body`, etc.) are silently dropped on this branch.

The downstream Cypher (`node_db_queries.py:61-65`) IS `MERGE + SET n = {...}` — Neo4j full-property replacement — but the values plugged into SET come from the LOADED node, so net effect = **preservation, not overwrite**. `entity_edges` IS refreshed from the new extraction run.

Consequences:
- `created_at` (ADR-0004 axis 3) is PRESERVED across Stage 6. The original ADR-0004 "first-ingest time" semantic stands unchanged.
- `content` is PRESERVED — graphiti extracts from whatever Stage 4 wrote. To preserve v0.1.1 preprocessor benefits (issues #2/#3/#4 — numbered IDs, ranked priority, currency), Stage 4 writes `augment_for_extraction(original)`; Stage 6b restores original.
- `source_description` is PRESERVED. Stage 4 must write `"gnokee.ingest"` (not `"gnokee.ingest.lite"`) for episodes that will undergo Stage 6 — otherwise the marker reads "lite" even on the happy path.

The Z1.6 test pins these behaviors so future graphiti-core upgrades that change `add_episode`'s load-by-uuid short-circuit fail loudly here, not silently in production.

## Consequences

### Positive

- **No silent drops.** Episodes are retrievable regardless of Graphiti state — robust to TPM cascades, transient network failures, future Graphiti regressions, malformed extractor output.
- **ADR-0004 axis semantics preserved.** `created_at` = first-ingest time. `valid_at` = world time. `asserted_at` = pg-only source-tx time. No axis redefinition required.
- **Uniform contract.** Full / lite / encrypted paths share the same Stage 4 + Stage 5 surface. The only difference is whether Stage 6 enhancement runs.
- **Existing primitives reused.** `write_lite_episode` and `run_deferred_extraction` were shipped in v0.3 (issue #56 + #16); v0.6 makes them the universal path rather than fallback.
- **Test surface is testable.** Mocking `graphiti.add_episode` to raise produces deterministic lite-fallback behavior in unit / integration tests (no live OpenAI rate-limit required).
- **Pre-existing latent bug fixed.** `maintenance.run_deferred_extraction` had two bugs surfaced by Z1.7: invalid `SET app.current_tenant = $1` SQL (Postgres rejects parametrized SET), and missing `uuid=episode_uuid` on the rehydration `add_episode` call (created new graphiti-owned nodes instead of attaching entities to the existing lite Episodic). Both fixed in commit `f3301e3`.

### Negative — accepted

- **`our_id=None` re-ingest creates duplicate episodes.** Pre-existing v0.5 lite-mode behavior; v0.6 makes it universal. Mitigation: `our_id` is now documented as RECOMMENDED for idempotency in `IngestPipeline.ingest` docstring. Test `Z1.9` pins the contract.

- **Process-global semaphore (not per-tenant).** `extraction_concurrency` bounds all `add_episode` calls in a single process across all tenants. A high-volume tenant could starve a low-volume tenant under contention. Acceptable for v0.6; per-tenant fairness deferred to v0.7 if telemetry (`enhancement_retries` distribution) shows starvation.

- **Non-retryable exceptions silently engage lite-fallback.** A genuine graphiti / Neo4j failure (vs TPM pressure) returns `enhancement_retries=0` + `lite_fallback_engaged=True`. Operators must instrument `enhancement_retries=0` + `lite_fallback_engaged=True` combinations as alerts to distinguish "graphiti unavailable" from "TPM throttled."

### Deprecation

- **`GNOKEE_INGEST_STRICT=1`** env var is deprecated in v0.6 (emits `DeprecationWarning` on `IngestPipeline.__init__`). Hard-removal in v0.7. The Z1 architectural fix closes the silent-drop class by design; the env-flag-based "fail loud on orphan-edge warnings" surface is no longer load-bearing. Replacement: `IngestTelemetry.lite_fallback_engaged` + `enhancement_retries` + `orphan_edge_warnings`.

## Acceptance evidence

[Spike Q18 § Verdict refinement](../../evals/spike_q18_recall_at_k_diagnostic/README.md) confirms:
- v0.5 baseline `INGEST_GAP_NOT_RETRIEVAL_GAP` reproduces at `conc=4`.
- v0.5 baseline at `conc=1` already preserves 100/100 (Z1 not strictly required for serial ingest, but defensive nonetheless).

v0.6 release-cut gate (per spec § Acceptance criteria):
- Q18 re-spike at `conc=4` must pass `≥ 14/17` measurable in storage AND `≥ 80%` recall@5 on measurable.
- Integration tests `Z1.1–Z1.10` + `Z4.1` green.

Gate command: `.venv/bin/python evals/spike_q18_recall_at_k_diagnostic/run.py --gate` (exit 0 on pass).

## Cross-refs

- ADR-0004 § retrieval invariants (gnokee owns retrieval) — this ADR adds the storage-ownership corollary.
- ADR-0012 § Stage C addendum (2026-05-12) — Q18 ingest-gap finding.
- ADR-0019 § LongMemEval-S publish stance — publish deferral lifts post-Q18 re-spike pass.
- Issue [#56](https://github.com/gnokeelabs/gnokee/issues/56) — lite-mode minimal Episodic write (prerequisite primitive).
- Issue [#112](https://github.com/gnokeelabs/gnokee/issues/112) — Z3 ingest telemetry (already shipped v0.5).
- Spec [`docs/superpowers/specs/2026-05-15-v0.6-ingest-hardening-z1-z4-design.md`](../superpowers/specs/2026-05-15-v0.6-ingest-hardening-z1-z4-design.md).
- Plan [`docs/superpowers/plans/2026-05-15-v0.6-ingest-hardening.md`](../superpowers/plans/2026-05-15-v0.6-ingest-hardening.md).
- AGENTS.md "do not" list — Z1 keeps gnokee as storage primitive; no auto-resolve, LLM hosting, or key holding.
