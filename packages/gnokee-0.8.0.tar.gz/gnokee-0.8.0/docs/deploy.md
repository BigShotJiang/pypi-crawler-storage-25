# Deploying gnokee

> Status: pre-1.0. The `docker-compose.yml` shipped in the repo is
> **dev-only**. Production deployment requires pinned images, real
> secret management, RLS GUC wiring per request, and a process
> supervisor outside compose. This page documents the operator
> contract — pair with [`observability.md`](observability.md) and
> [`privacy-posture.md`](privacy-posture.md).

## v0.x topology

```text
┌──────────────────────────────────────────────────────┐
│  Consumer application(s)                             │
│  - gnokee Python library (in-process)                │
│  - or, gnokee MCP server (sub-process or container)  │
└────────────────┬─────────────────────────────────────┘
                  │
       ┌──────────┼──────────┐
       ▼          ▼          ▼
   Postgres    Neo4j        TEI
   pgvector   (Graphiti)   (bge-m3)
   (RLS on)   (group_id    (1024-dim
              isolation)    embedder)
                  ↓
       (consumer-supplied LLM endpoint, OpenAI-compatible)
```

Three backing services. One library / MCP-server process per
consumer. Multi-tenant via `tenant_id` discipline (see
[`privacy-posture.md`](privacy-posture.md) §"Multi-tenancy").

## Image pinning

The dev `docker-compose.yml` uses tags like `pg17` and
`5-community` for convenience. **Production deployments must pin
SHA digests**, not tags — tags are mutable upstream.

```yaml
# Example production override (operator-owned, not committed here)
services:
  postgres:
    image: pgvector/pgvector@sha256:<digest>
  neo4j:
    image: neo4j@sha256:<digest>
  tei:
    image: ghcr.io/huggingface/text-embeddings-inference@sha256:<digest>
```

To capture the current digest from a tag:

```bash
docker pull pgvector/pgvector:pg17
docker inspect --format='{{index .RepoDigests 0}}' pgvector/pgvector:pg17
```

For TEI specifically, see the [embedder pin memory](../docs/architecture.md#service-inventory-v01)
and override `GNOKEE_TEI_IMAGE` per environment:

```text
# Linux x86_64 production
GNOKEE_TEI_IMAGE=ghcr.io/huggingface/text-embeddings-inference:cpu-1.9
# Apple-Silicon dev
GNOKEE_TEI_IMAGE=ghcr.io/huggingface/text-embeddings-inference:cpu-arm64-latest
# GPU production
GNOKEE_TEI_IMAGE=ghcr.io/huggingface/text-embeddings-inference:1.9
```

GPU images significantly improve throughput; the CPU image is fine
for low-volume single-tenant workloads.

## Secrets

Never commit `.env` to a repo. Production secrets live in:

- A real secret manager (Hashicorp Vault / OpenBao, AWS Secrets
  Manager, GCP Secret Manager, k8s Secrets, etc.).
- Injected at process start as environment variables.

The required-in-production secrets:

| Secret | Source | Used by |
|---|---|---|
| `GNOKEE_PG_PASSWORD` (and DSN if not split) | secret manager | Postgres connection |
| `GNOKEE_NEO4J_PASSWORD` | secret manager | Neo4j bolt connection |
| `GNOKEE_OPENAI_API_KEY` | secret manager | LLM endpoint |
| Per-tenant DEKs | consumer KMS — **not gnokee's responsibility** | Encrypted-body branch |

`GNOKEE_TENANT_DEFAULT` is dev-only. **Production must require
`tenant_id` explicitly per call** — `gnokee/__init__.py` reads
`GNOKEE_TENANT_DEFAULT` only in `gnokee.demo` and integration
tests. Strip it from the production env to enforce.

## Healthchecks

Each service exposes a health probe. The compose `healthcheck`
clauses are dev-grade; production schedulers (k8s, ECS, Nomad) want
HTTP-style readiness:

| Service | Probe |
|---|---|
| Postgres | `pg_isready -U $GNOKEE_PG_USER -d $GNOKEE_PG_DB` (TCP also fine) |
| Neo4j | `cypher-shell -u … -p … 'RETURN 1'` or HTTP `GET /` on `:7474` |
| TEI | `GET /health` on the TEI port |
| gnokee MCP server | exit-code 0 on a `python -m gnokee.bootstrap --probe` (TODO; v0.5 candidate) |

For the gnokee process today, the closest readiness signal is
"the process didn't exit on startup". `bootstrap._require_llm_credentials()`
fast-fails when the LLM endpoint is `api.openai.com` with no key.

## Postgres

### Migrations

Run on deploy, not on first request:

```bash
gnokee-migrate                    # CLI, pyproject.toml [project.scripts]
# or
python -m gnokee.storage.migrate
```

Migrations are forward-only raw SQL files in
`src/gnokee/storage/migrations/NNNN_<name>.sql`. The runner is
documented in [ADR-0006](adr/0006-postgres-raw-sql-migrations.md).
No alembic in v0.x.

For zero-downtime: run migrations, then restart application
processes. Migrations don't take exclusive locks beyond what the
underlying `ALTER TABLE` requires.

### RLS GUC pattern

gnokee's tenant isolation in Postgres relies on a GUC variable
plus row-level security policies. **The consumer middleware MUST
set the GUC per request**:

```python
async with pool.acquire() as conn:
    # Transaction-local; auto-resets at txn end. Required for
    # pooled connections shared across tenants.
    await conn.execute(
        "SELECT set_config('app.current_tenant', $1, true)",
        tenant_id,
    )
    async with conn.transaction():
        # ... gnokee API calls ...
```

`run_deferred_extraction` already does this internally for its
own connection. For your own consumer code paths, do it.

The third arg `true` to `set_config` makes the setting
transaction-local — required when the connection is reused for a
different tenant later. Without it, the setting leaks across
requests.

### Connection pool sizing

Defaults (`asyncpg.create_pool` with no `max_size`) cap at 10
connections. For a multi-tenant production deployment:

```python
pool = await asyncpg.create_pool(
    dsn=settings.pg_dsn,
    min_size=2,
    max_size=20,                # tune to load + Postgres max_connections
    command_timeout=30.0,
)
```

Postgres `max_connections` applies globally. If you run N gnokee
processes, each holding a 20-connection pool, you need N * 20 + ops
headroom on the Postgres side.

### Backups

Standard Postgres backup techniques apply. gnokee's data is in
`episode_metadata` + `content_embedding` + `fact_contradiction` +
`lab_record` + `med_record` + `episode_body_encrypted` +
`schema_migrations`. None of these tables hold binary blobs other
than the 1024-dim embedding vectors and the encrypted-body
ciphertexts; both compress poorly.

For tenant-scoped backups (e.g. GDPR right-to-portability):

```sql
COPY (
  SELECT * FROM episode_metadata WHERE tenant_id = 'omur:tenant-xyz'
) TO '/path/tenant-xyz-episode-metadata.csv' WITH CSV HEADER;
-- repeat for content_embedding, fact_contradiction, lab_record, med_record,
-- episode_body_encrypted
```

For tenant-scoped erasure (GDPR right-to-erasure mode 2 — hard
delete with tombstone propagation), `gnokee_forget` + the
ON DELETE CASCADE FK chain handles it. See
[`privacy-posture.md`](privacy-posture.md).

## Neo4j

### Indexes

Graphiti's `build_indices_and_constraints()` runs once on first
connect. gnokee then adds one extra index (per [v0.1
spec](specs/v0.1.md) §3):

```cypher
CREATE INDEX episodic_valid_at IF NOT EXISTS FOR (e:Episodic) ON (e.valid_at);
```

Both runs are idempotent. Smoke test on every deploy that the
expected indexes are present:

```cypher
SHOW INDEXES;
```

Vector indexes (`entity_edge_fact_embedding`,
`entity_node_name_embedding`) are 1024-dim; switching the embedder
dim is a destructive re-embed migration (see
[`extending.md`](extending.md)).

### Memory + page cache

Neo4j 5 needs heap and page cache tuned for the dataset size.
Defaults in the dev image are not production-grade. For a
single-tenant dev workload (~10k episodes, ~50k entity edges),
the defaults are fine. For multi-tenant production:

```text
NEO4J_dbms_memory_heap_initial__size=2g
NEO4J_dbms_memory_heap_max__size=4g
NEO4J_dbms_memory_pagecache_size=4g
```

Tune based on dataset size + query latency. Neo4j has its own
guidance.

### Multi-tenancy

Neo4j Community has no row-level security. gnokee's isolation is
**`group_id` discipline** — every Cypher query includes
`WHERE n.group_id = $tenant` on every node and edge. If you write
your own Cypher (e.g. extending gnokee), follow the same rule.

If you can't trust `group_id` discipline (e.g. running gnokee
behind an untrusted application layer), put each tenant in its own
Neo4j database (Enterprise feature) — but Enterprise licensing
moves you out of the Community-only support contract gnokee tests
against.

## TEI

### Throughput

The dev image is single-process CPU. For production:

- **GPU image** for high throughput per node.
- **Multiple TEI instances** behind a round-robin LB for horizontal
  scaling.
- Tune `--max-batch-tokens` (default 4096 in compose) — higher =
  better GPU utilisation but worse worst-case latency.

### Caching

TEI doesn't cache by default. If you re-embed the same text across
runs (eval harnesses, rebuilds), put a cache in front of TEI:

```text
gnokee → cache (Redis / in-memory LRU) → TEI
```

Cache key = sha256 of the input text. The 1024-dim float vectors
compress reasonably under zstd if you persist them.

### When TEI is down

`gnokee.errors.EmbeddingsUnavailable` raised. Ingest fails before
any Graphiti or pg write. Recall fails — no query embedding can be
computed. There's no graceful-degradation path for TEI in v0.x.

## LLM endpoint

The LLM is consumer-supplied. gnokee has no opinion about which
endpoint, only about the protocol (OpenAI-compatible) and the
default model (`gpt-4o-mini` per Q4).

### Cost control

- Cap candidate-pair count in the contradiction stage (already
  capped to 5 per fact in Q4 spike).
- Use lite-mode ingest for high-cadence sources to skip the
  per-episode LLM call. Pair with deferred extraction on a
  schedule.
- For self-hosted endpoints (Ollama, vLLM) the $/call is implicit
  in your hardware budget; for hosted endpoints, monitor token
  spend.

### Failure modes

`LLMUnavailable` on ingest → contradiction detection skipped;
ingest succeeds with `contradicts=[]`. Operator-visible signal:
log volume of `contradiction_unavailable` events.

`LLMUnavailable` on `run_deferred_extraction` → that episode
remains `extraction_deferred=TRUE` and the next backfill retries.

## Volumes + persistence

The compose file defines named volumes (`postgres-data`,
`neo4j-data`, `neo4j-logs`, `tei-cache`). **For production these
should be operator-managed**, not compose-managed:

- Postgres → managed RDS / Aurora / CloudSQL or your own block
  storage with backup policy.
- Neo4j → managed AuraDS / your own block storage with backup
  policy.
- TEI cache → ephemeral; safe to lose. The model weights re-download
  on container restart.

Don't run production Postgres or Neo4j on compose-managed Docker
volumes. The dev compose file is for development.

## Scaling

### Single-tenant (typical for noggin)

One gnokee process. One Postgres. One Neo4j. One TEI. Done. For
high throughput, use the GPU TEI image.

### Multi-tenant (typical for Omur SaaS)

- N gnokee processes (or one per consumer-app worker), all
  pointing at the same Postgres + Neo4j + TEI.
- Postgres connection pooling per process; size globally below
  Postgres `max_connections`.
- Neo4j tolerates many concurrent connections; tune heap + page
  cache.
- TEI scales horizontally — put a small LB in front for multiple
  instances.

There is no gnokee-internal sharding by tenant. If you outgrow
single-Postgres / single-Neo4j capacity, run separate stacks per
tenant tier (or migrate Neo4j to Enterprise per-tenant database;
see ADR-0005 trade-off).

### Horizontal scaling caveats

- Migrations: only one process should run them. Wire your deploy
  to `gnokee-migrate` once before fanning out to N replicas.
- `run_deferred_extraction`: idempotent and tenant-scoped, but
  multiple workers running it concurrently for the same tenant
  will race. Either (a) lock per tenant or (b) accept duplicate
  Graphiti `add_episode` calls that the idempotency guard catches.
- Schema-migrations are append-only by convention; concurrent
  migrations would conflict but shouldn't happen if deploys are
  serial.

## Resource floors (rough guidance)

For a dev / small-team workload (≤ 10k episodes, ≤ 100k entity
edges, single tenant):

| Service | RAM | CPU | Disk |
|---|---|---|---|
| gnokee process | 256 MB | 0.5 vCPU | ~ |
| Postgres | 512 MB | 1 vCPU | 1–10 GB (data + WAL) |
| Neo4j | 2 GB heap + 2 GB page cache | 1–2 vCPU | 1–10 GB |
| TEI (CPU) | 4 GB | 2 vCPU | 4 GB (model weights) |
| TEI (GPU) | 8 GB GPU + 4 GB host | 2 vCPU + GPU | 4 GB |

For multi-tenant production, scale Postgres + Neo4j + TEI memory
linearly with active tenants. Storage scales linearly with
episodes.

## Process supervision

For the gnokee MCP server in production:

- **systemd** (single host) — `Type=simple`, `Restart=on-failure`.
- **k8s** — Deployment with `restartPolicy: Always` and a
  `livenessProbe` that exits the container if `python -m
  gnokee.bootstrap` fails.
- **ECS / Nomad / Cloud Run** — equivalent.
- For library use (in-process), the consumer's process supervisor
  governs.

Don't use the dev compose stack as the production runtime.

## Pre-deploy checklist

- [ ] Image SHAs pinned (Postgres, Neo4j, TEI, gnokee).
- [ ] Secrets in a real secret manager, not committed.
- [ ] `GNOKEE_TENANT_DEFAULT` removed from production env.
- [ ] Postgres RLS policies present for `episode_metadata`,
      `content_embedding`, `fact_contradiction`, `lab_record`,
      `med_record`, `episode_body_encrypted` (write your own
      policies; gnokee migrations don't ship them by default).
- [ ] RLS GUC (`set_config('app.current_tenant', ...)`) wired
      into consumer middleware.
- [ ] Neo4j heap + page cache sized for the dataset.
- [ ] TEI image picked for the architecture (GPU for production
      throughput; CPU arm64 for Mac dev).
- [ ] Migrations run on deploy via `gnokee-migrate`.
- [ ] Healthchecks / readiness probes wired.
- [ ] Backup policy in place for Postgres + Neo4j.
- [ ] Log shipping configured (see [`observability.md`](observability.md)).
- [ ] LLM endpoint quota / rate-limit defined.

## See also

- [`observability.md`](observability.md) — what gnokee logs and
  what metrics / traces v0.2+ will surface.
- [`privacy-posture.md`](privacy-posture.md) — threat model,
  multi-tenancy, encrypted-body lifecycle.
- [`troubleshooting.md`](troubleshooting.md) — symptom → cause →
  fix for compose stack quirks.
- [`adr/0005-graph-backend-tradeoff.md`](adr/0005-graph-backend-tradeoff.md) — why Neo4j Community.
- [`adr/0004-gnokee-owns-retrieval.md`](adr/0004-gnokee-owns-retrieval.md) — why pgvector + per-episode embeddings.
- [`releasing.md`](releasing.md) — version cadence + upgrade flow.
