# Spike Q13.1 — Confidence-Decay Stage-2 (N≥30 corpus + coefficient sweep)

> Stage-2 re-bench from ADR-0019 § Follow-up. Decides whether to amend
> ADR-0019 verdict from `SHIP_RECENCY_AS_PROXY` to `SHIP_COMPOSITE`.
> Tracking issue: [#88](https://github.com/gnokeelabs/gnokee/issues/88).

## Goal

Q13 (N=13 effective probes) showed composite function C had signal
(Spearman delta +0.21 over constant) but failed the calibration band
(0.29 vs 0.15 threshold). Verdict was `SHIP_RECENCY_AS_PROXY`. The
caveat in ADR-0019 § Follow-up noted that the corpus was too narrow and
the coefficients were untested — stage-2 fixes both.

This spike re-benches at N≥30 effective probes (post-extraction-check)
with a broader corpus mix (12–15 clinical + 12–15 personal-AI + 6–10
reinforcement clusters) and sweeps 48 composite coefficient variants to
find the best-performing configuration. Decision: if any tuned variant
clears both Spearman delta ≥ 0.10 AND calibration ≤ 0.15, ADR-0019 is
amended to `SHIP_COMPOSITE`. Otherwise `SHIP_RECENCY_AS_PROXY` stands.

Either outcome is acceptable and durable. The point is to retire the
caveat from ADR-0019 on real data, completing the last open v0.5
measurement task.

## Decision criterion

| Score class | Headline | Action |
|---|---|---|
| `SHIP_COMPOSITE` | Any tuned composite variant: Spearman delta ≥ 0.10 over constant AND calibration max ≤ 0.15, at N≥30 effective probes | Amend ADR-0019 to `SHIP_COMPOSITE`; bake tuned coefficients into ADR; amend ADR-0013 + ADR-0016 to remove recency-proxy framing |
| `KEEP_RECENCY_PROXY` | No variant clears both gates | `SHIP_RECENCY_AS_PROXY` verdict stands; close ADR-0019 § Follow-up section explicitly |

Exact thresholds (same as Q13, from ADR-0019 § Decision rule):
- Composite must beat constant baseline by **>= 0.10 Spearman** (same gate as Q13).
- Composite calibration max bucket deviation must be **<= 0.15** (Q13 failed at 0.29).
- Recency proxy Spearman bar (for baseline comparison): **> 0.05** over constant.
- Coefficient sweep: 48 variants = {0.25, 0.5, 0.75, 1.0} × {0.1, 0.2, 0.3, 0.5}
  × {5, 10, 20} for (`COMPOSITE_CONTRADICTION_COEF`, `COMPOSITE_RECENCY_COEF`,
  `COMPOSITE_REINFORCEMENT_NORM`).
- Winner: best variant per metric (Spearman, accuracy, calibration).
  A variant "clears both gates" if its Spearman delta ≥ 0.10 AND calibration ≤ 0.15
  simultaneously.

## Methodology

**Candidate functions** (same three as Q13):

- **A. Constant baseline** — `1.0` when active. Matches today's Graphiti default.
- **B. Recency-only (Ebbinghaus)** — `exp(-delta_days / 365)`.
- **C. Contradiction-aware composite** — sweeps 48 coefficient variants of:
  `clip(0, 1, reinforcement_score - CONTRADICTION_COEF * contradiction_score + RECENCY_COEF * recency_factor)`.

**Corpus** (`corpus.jsonl`): 45 hand-curated episodes (exceeds 30 to allow
extraction fallout), ingested under `group_id = spike_q13v2_confidence`.

- Episodes 1–20: clinical — penicillin allergy (4-mention reinforcement cluster),
  GP supersession chain, beta-blocker 3-step supersession, lisinopril→losartan
  chain, iron-deficiency anemia with correction, furosemide + KCl cycle, allergy
  reinforcement, stale glucose, knee procedure, cholesterol management.
- Episodes 21–35: personal-AI — location supersession (Berlin→Lisbon), work
  arrangement supersession, car ownership + sale, diet preferences, fitness
  goal, language learning, home-renovation preferences, travel patterns, pet
  ownership, coffee preference, gym membership supersession, sleep habit,
  subscription supersession, hobby cluster.
- Episodes 36–45: reinforcement-heavy — a single fact (preferred coffee) mentioned
  4+ times across independent episodes; a dietary preference mentioned 4 times;
  an allergy confirmed across 5 sources.

**Extraction pre-check rule**: each probe targets a Graphiti-entity-class fragment
(named entity or RELATES_TO edge predicate), NOT a literal-numeric string. This
avoids the Q13 gap where 6/13 probes returned zero nodes because Graphiti dropped
literals. Probes target entity names or verb-phrase fragments (`furosemide`,
`losartan`, `penicillin allergy`, `bisoprolol`, `Lisbon`, `Cascais Family
Practice`, `home-renovation`, `Portuguese`, etc.).

**Probe set** (`queries.yaml`): 36 probes (over-built to land ≥30 effective).

- 10 high-confidence (0.8+): recent, multi-source, no contradictions.
- 12 mid-confidence (0.4–0.7): single-mention or lightly-contradicted.
- 8 low/stale (0.0–0.3): old, superseded, or directly contradicted.
- 6 reinforcement-cluster probes: facts with 4+ mentions; tests the reinforcement
  term.
- 5 historical `as_of` pins (2023 or earlier): tests bi-temporal sensitivity.
  (3 probes count in multiple categories.)

**Scoring rules** (same as Q13, lifted verbatim):
- `spearman_r` — `scipy.stats.spearmanr` between function outputs and
  `expected_confidence` across all effective probes.
- `accuracy_at_0.5` — binary classification of `believed` at threshold 0.5.
- `calibration_max` — 5-bucket predicted-mean vs actual-believed-rate; max
  absolute deviation from diagonal. Empty buckets skipped.
- `reranker_delta` — `spearman(composite) - spearman(cosine_top1_proxy)`;
  if < 0.05, flagged "reranker in disguise".

**Coefficient sweep**: for each of the 48 `(contradiction_coef, recency_coef,
reinforcement_norm)` combinations, compute per-probe composite score without
additional Neo4j / Postgres calls. All three input signals (n_supporting,
n_contradictions, recency_factor) are fetched once per probe; the 48 variants
are pure arithmetic. Zero additional LLM calls.

## What this does NOT cover

- **Real `cosine_top1` baseline** — tracked as v0.5.x #89. Cosine proxy
  (recency-as-cosine-shortcut) is carried forward from Q13.
- **Source-trust prior (option D)** — defers until `tenant_metadata` table exists.
- **Per-tenant overrides** — v0.5/v0.6 is single-default coefficient set.
- **Cross-tenant corpus** — all episodes under one `group_id`; multi-tenant
  isolation not exercised.
- **Production wire change** — composite ships via ADR-0019 amendment + ADR-0013/
  ADR-0016 framing edits, not a wire-format change in this spike.
- **Literal-numeric extraction** — explicitly out of scope per ADR-0019 § Follow-up
  (issue #90 accepted as "no custom extractor"). Probes avoid literals.
- **LLM-graded confidence** — anti-pattern per ADR-0019. Zero LLM calls.

## Cost & time

- **LLM calls**: 0. No grading via any LLM.
- **Embed calls**: 36 (one per probe query, via gnokee TEI bge-m3). Skipped if
  `GNOKEE_SPIKE_SKIP_INGEST=1`.
- **Neo4j calls**: ~72 Cypher queries (2 per probe: reinforcement walk +
  contradiction UUID fetch). Plus ~72 smaller pass-2 queries for valid_at.
  Total Neo4j: ~144 queries.
- **Postgres calls**: ~36 (ContradictionStore.lookup_counterparts, 1 per probe fact).
- **Coefficient sweep**: 48 variants × 36 probes = 1728 pure-Python arithmetic ops.
  No I/O.
- **Wall time**: < 10 minutes for 36 probes on local docker-compose stack (ingest
  ~5 min, scoring ~4 min, sweep instantaneous).
- **$ estimate**: $0.00. All compute local.

## Run

```bash
# First run (with ingest):
cd evals/spike_q13.1_confidence_v2
set -a && source ../../.env && set +a
../../.venv/bin/python run.py

# Skip ingest (corpus already under spike_q13v2_confidence):
GNOKEE_SPIKE_SKIP_INGEST=1 ../../.venv/bin/python run.py

# Search-limit override:
GNOKEE_SPIKE_SKIP_INGEST=1 GNOKEE_SPIKE_SEARCH_LIMIT=15 ../../.venv/bin/python run.py
```
