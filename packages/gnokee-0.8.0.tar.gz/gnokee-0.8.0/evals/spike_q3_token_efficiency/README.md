# Spike Q3 — MCP token-efficiency

## Goal

Validate gnokee's "token-efficient by default" promise against the
naive baseline of dumping Graphiti's raw search results.

Per `docs/evals/methodology.md`: "**Token efficiency** — mean tokens
per query vs answer quality." This spike uses the Q1 corpus (already
in Neo4j under `group_id=spike`, 20 episodes) and the Q1 query set
(`evals/spike_q1_graphiti/queries.yaml`, 12 queries) to A/B two
response shapes over the same probes.

## Decision criterion

- **gnokee-shape mean tokens per query ≤ 70% of Graphiti-raw mean**
  (≥30% reduction, the bar set when this spike was scoped)
- **Top-3 recall must hold ≥80%** for the gnokee shape (the bar for
  the retrieval primitive itself, inherited from ADR-0001 / Q2)

If both are met → ADOPT the gnokee response shape for v0.1 MCP.

## Response shapes

### Mode A: `graphiti_raw` (the naive baseline)

Dumps the top-K edges from Graphiti's `client.search_()` with
`COMBINED_HYBRID_SEARCH_RRF` as the response, with all per-edge
metadata that an MCP integration might naively pipe through:

```text
Edge {uuid}:
  Fact: {edge.fact}
  Valid at: {valid_at}
  Invalid at: {invalid_at}
  Episodes: {comma-joined episode UUIDs}
```

This is what a "wire it through and ship it" MCP server would return.

### Mode B: `gnokee` (the design per ADR-0004 + architecture.md)

Per `docs/architecture.md` Retrieval contract: "natural-language fact
statements + lazy provenance + contradiction refs (not full bodies)".

Concretely, for the spike:

```text
{N}. {first_sentence_of_episode_content} [ep:{episode_id}, valid_at:{date}]
```

Top-K episodes by direct bge-m3 cosine over full episode content
(Q2's `direct_cosine.py` retrieval primitive), each rendered as a
single-sentence fact statement plus a lazy provenance handle. No edge
dump, no full episode body, no UUID soup.

## Methodology

For each of the 12 Q1 queries:

1. Run mode A (`graphiti_raw`) — call `client.search_()` with the same
   `SearchFilters` Q1 v2.1 used; format response per Mode A above.
2. Run mode B (`gnokee`) — embed query via bge-m3 (Ollama),
   cosine-rank Q1's 20 episodes by content, take top-3, format
   response per Mode B above.
3. Count tokens for each response via `tiktoken` (`cl100k_base`).
4. Score top-3 recall for each: did the Q1-expected episode appear
   in the top-3 of the response?

Headline number: **mean tokens per query (gnokee / graphiti_raw)**.

## What this spike does NOT cover

- Cross-tool comparison (Mem0, basic-memory, mcp-memory-service) —
  deferred to v1.0 published evals per `docs/evals/methodology.md`
- MCP wire-format overhead (tool descriptions, schemas, system
  messages) — different question
- LLM-rendering quality of the gnokee response shape — the spike
  measures token cost only, not whether the shape is pleasant for an
  LLM to consume. That belongs to a Q4-style follow-up against an
  agent-task eval

## Cost & time

Reuses the Q1 corpus already in Neo4j (no re-ingest). Direct cosine
runs against bge-m3 via Ollama (no LLM calls). 12 Graphiti `search_`
calls (entity reranking via gpt-4o-mini) ≈ $0.05 / run, ~2 minutes
wall.
