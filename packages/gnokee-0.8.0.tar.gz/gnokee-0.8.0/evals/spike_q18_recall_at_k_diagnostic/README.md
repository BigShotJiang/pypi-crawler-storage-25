# Spike Q18 — recall@K diagnostic on Q10 stageC_30q20s

> **Verdict (2026-05-12): `INGEST_GAP_NOT_RETRIEVAL_GAP` (concurrency-bound).**
> Of 17 measurable LongMemEval-S pilot questions, gnokee retrieves the
> gold session in top-5 for **3/3 = 100%** of questions whose gold actually
> made it into storage. The remaining 14/17 measurable cases have **zero
> gold episodes in `episode_metadata`** — Graphiti `add_episode` silently
> dropped them during the 2026-05-10 stageC ingest. The headline "gnokee
> 0.10 recall@5" from ADR-0012 § Stage C was 100% an ingest-path failure,
> not a retrieval-path failure.
>
> **Refinement (2026-05-12 reproingest, see § Reproduction confirmation):**
> the silent-drop is **concurrency-bound** — at `--per-sut-concurrency 1`
> on v0.5 main, ingest preserves 100/100 episodes (vs 74/100 in
> 2026-05-10's `--per-sut-concurrency 4` run). The bug is "concurrent
> ingest at tier-1 200 K TPM is silently lossy," not "narrative content
> is always silently lossy." Z-series urgency reorders: **Z3 (loud-failure
> telemetry) becomes highest priority**, Z1/Z2 demote to v0.6
> defense-in-depth, new Z4 (TPM-aware concurrency throttle) joins.

Lands in **ADR-0012 § Stage C addendum** + new tracking issue for
ingest-hardening (Z1/Z2/Z3 candidate list below).

## Goal

Locate where in gnokee's read pipeline the LongMemEval-S 0.10 recall@5
baseline (2026-05-10 stageC_30q20s) actually fails. Three candidate
buckets:

1. **Storage gap** — gold session never made it into `episode_metadata` /
   pgvector. Ingest path lost it.
2. **Retrieval gap** — gold session in storage but not in top-K candidates.
   pgvector cosine + Graphiti BM25 + RRF fusion ranked it out.
3. **Rerank gap** — gold session in top-K candidates but not in top-5
   emitted facts/excerpts/bodies.

The right intervention differs by an order of magnitude across the three.
Issue [#81](https://github.com/gnokeelabs/gnokee/issues/81) (LongMemEval-S
publish stance) and the retrieval-improvement option set (chunked retrieval,
cross-encoder rerank, query decomposition) all assume bucket 2 or 3.
This spike falsifies that assumption.

## Decision criterion

Single dispatch on the dominant bucket among the 17 *measurable* probes
(probes where gold session is within the truncated 20-session haystack):

| Dominant bucket | Verdict | v0.6 implication |
|---|---|---|
| ≥ 70% gold not in storage | `INGEST_GAP_NOT_RETRIEVAL_GAP` | Fix ingest path; retrieval primitives (rerank / chunked) are **wasted spend** on this corpus. |
| ≥ 70% gold in top-100 but not top-5 | `RERANK_GAP` | Add cross-encoder rerank stage; ADR-light. |
| ≥ 70% gold beyond top-100 with gold present in storage | `RETRIEVAL_CANDIDATE_GAP` | Span-level chunked retrieval; ADR-heavy. |
| Mixed | Stage by class — different fixes per question_type. |

## Methodology

### Phase 1 — top_k=100 re-query against existing tenants

Reuses 2026-05-10 stageC_30q20s tenants (28 of 30 survived; 2 had zero
ingest in the original run). No fresh ingest, no LLM cost.

```bash
set -a && source ../../.env && set +a
../../.venv/bin/python ../spike_q10_cross_tool/run.py \
    --suts gnokee --max-questions 30 --max-sessions 20 \
    --top-k 100 --per-sut-concurrency 4 \
    --query-only-suts gnokee \
    --run-id stageC_30q20s \
    --out ../spike_q10_cross_tool/results/stageC_30q20s_topk100.json
```

`--query-only-suts gnokee` skips ingest entirely; the harness only calls
`gnokee_recall(top_k=100)` against pre-existing tenants. The harness's
existing `retrieved_external_ids` field carries up to 100 ranked IDs per
question for post-processing.

### Phase 2 — rank-of-first-gold per question

`run.py` in this spike post-processes the JSON to compute, per question:

- rank of the first gold external_id within `retrieved_external_ids`
- bucket: top-5 / 6–20 / 21–50 / 51–100 / not-in-retrieval
- whether the question is *measurable* (gold_external_ids ≠ ∅)

### Phase 3 — storage check for not-in-retrieval rows

For every row where gold is in haystack but not in retrieval set (the
`beyond` bucket), `run.py` queries pgvector directly:

```sql
SELECT our_id FROM episode_metadata
WHERE tenant_id = '<tenant>' AND our_id IN (<gold our_ids>);
```

If `count(our_id) = 0`, the gold sessions were never written to storage
(ingest gap). If `count(our_id) ≥ 1`, retrieval missed them (real
retrieval gap — investigate ranking).

## Results

Run JSON pinned: `evals/spike_q10_cross_tool/results/stageC_30q20s_topk100.json`
(query-only re-run, 2026-05-12T21:21:00Z).

### Rank-of-gold distribution (gnokee, top_k=100, current v0.5 main)

| Class | n | no_gold_in_haystack | gold@top-5 | gold@6–100 | beyond top-100 |
|---|---|---|---|---|---|
| knowledge-update | 5 | 1 | 2 | 0 | 2 |
| multi-session | 5 | 1 | 1 | 0 | 3 |
| single-session-assistant | 5 | 4 | 0 | 0 | 1 |
| single-session-preference | 5 | 3 | 0 | 0 | 2 |
| single-session-user | 5 | 2 | 0 | 0 | 3 |
| temporal-reasoning | 5 | 2 | 0 | 0 | 3 |
| **TOTAL** | **30** | **13** | **3** | **0** | **14** |

Gold ranks observed in top-5 cluster: 1, 1, 3. **All three are rank ≤ 3.
Zero gold sessions land in the 6–100 buckets at all.** This is the binary
signature of "gold either rises to the top or isn't there."

### Storage check on the 14 `beyond` rows

```
qid          class                        gold_count  gold_in_storage  retrieved
1568498a     single-session-assistant     1           0                3
06f04340     single-session-preference    1           0                4
0bb5a684     temporal-reasoning           2           0                3
078150f1     multi-session                1           0                2
0862e8bf_abs single-session-user          1           0                3
0bc8ad92     temporal-reasoning           2           0                2
06db6396     knowledge-update             1           0                4
099778bb     multi-session                1           0                2
118b2229     single-session-user          1           0                2
0bc8ad93     temporal-reasoning           2           0                2
07741c44     knowledge-update             1           0                2
09ba9854     multi-session                1           0                1
0a34ad58     single-session-preference    1           0                1
15745da0     single-session-user          1           0                0
```

**14 / 14 rows: zero gold external_ids in `episode_metadata`.**

Total gold sessions across the 14 `beyond` rows: 17. **All 17 are missing
from storage.** Tenant episode counts in the table (1–4) confirm the
silent-drop pattern: haystacks were sent with up to 20 sessions each;
most tenants ended up with a handful of episodes, suggesting Graphiti's
`add_episode` succeeded for some sessions and quietly skipped others.

### Per-bucket summary

| Bucket | Count | Story |
|---|---|---|
| no_gold (gold beyond 20-session truncation) | 13 / 30 | Structurally unrecoverable. Same constraint for all tools. |
| Gold ingested AND retrieved in top-5 | **3 / 17 measurable** | gnokee recall@5 on stored episodes: **3 / 3 = 100%** (ranks 1, 1, 3). |
| Gold in haystack but dropped from storage | **14 / 17 measurable** | Graphiti `add_episode` silently failed to write Episodic + content_embedding. **The 0.10 baseline number is 100% this bucket.** |

## Verdict

**`INGEST_GAP_NOT_RETRIEVAL_GAP`** — 14 / 17 measurable rows hit Phase-3
storage-empty. Of the 3 stored measurable, retrieval scores 100%
recall@5.

The 0.10 recall@5 baseline in ADR-0012 § Stage C is **not** evidence
for any retrieval-side intervention (chunked retrieval, cross-encoder
rerank, query decomposition). It is evidence for ingest-side
hardening.

## Follow-ups

### Ingest hardening (Z-series candidates)

Filed as new tracking issue (see below; will get number on file). All
three are v0.6 candidates.

- **Z1. Always-write `Episodic` + `content_embedding` regardless of
  Graphiti extraction outcome.** Today's contract: if Graphiti
  `add_episode` returns successfully, gnokee assumes the episode is
  retrievable. Q18 falsifies this — Graphiti can "succeed" while
  silently emitting orphan-edge warnings and skipping the Episodic
  write. Fix: gnokee's `ingest_episode` writes the content_embedding +
  Episodic node *before* calling Graphiti's add_episode; Graphiti's
  extraction lane becomes an enhancement layer, not the source-of-truth
  for "is this episode stored." Per ADR-0012 Path A spirit, but
  default-on, not fallback.

- **Z2. Lite-mode default for narrative episodes** (ADR-0012 #16 item 1).
  When `EpisodeIn.source_type` indicates conversational / prose content,
  skip Graphiti extraction entirely and rely on content_embedding +
  BM25. Preserves the contradiction-aware story for structured (`lab`,
  `med`) writes.

- **Z3. Loud failure on partial ingest.** Add a counter
  `episodes_dropped_during_extraction` per `add_episode` call, surface
  via `recall_telemetry`. Stops the silent-failure footgun even before
  Z1/Z2 ship.

### Measurement-discipline follow-ups

- **Q-spike template gains an ingest-completeness check** as a
  pre-flight: every spike must verify `count(distinct our_id) ==
  expected` per tenant before scoring retrieval. Without it, retrieval
  numbers conflate ingest drops with retrieval misses. Update
  `docs/evals/methodology.md` § "Authoring a new spike."

- **ADR-0012 § Stage C addendum** — measurable-denominator + ingest-gap
  finding. Cross-tool table re-grades:

  | SUT | hits / 30 (published) | hits / 17 measurable | gold-in-storage rate |
  |---|---|---|---|
  | gnokee | 3 / 30 = 0.100 | 3 / 17 = 0.176 | 3 / 17 = 0.176 |
  | basic-memory | 7 / 30 = 0.233 | 7 / 17 = 0.412 | n/a (no Graphiti) |
  | graphiti-alone | 0 / 30 = 0.000 | 0 / 17 = 0.000 | Same Graphiti path; same silent drop. |

  basic-memory's 41.2% on measurable is the new comparison point, not
  20% on full-30 — and gnokee's gap to basic-memory is entirely
  explained by basic-memory bypassing Graphiti (FTS5 over sqlite). The
  cross-tool ranking is preserved; the magnitude of gnokee's
  underperformance halves once the corpus-truncation noise is removed.

### Reproduction confirmation (2026-05-12, completed)

Fresh ingest of N = 5 LongMemEval pilot questions × 20-session
haystacks on v0.5 main with `--per-sut-concurrency 1` (serial). Run
id `reproingest_v05`, completed 2026-05-12. Result:

| Tenant | reproingest (conc = 1) | 2026-05-10 stageC (conc = 4) | Δ episodes recovered |
|---|---|---|---|
| `001be529` | **20 / 20** | 7 / 20 | +13 |
| `00ca467f` | 20 / 20 | 20 / 20 | 0 |
| `01493427` | 20 / 20 | 20 / 20 | 0 |
| `06878be2` | **20 / 20** | 10 / 20 | +10 |
| `0e5e2d1a` | **20 / 20** | 17 / 20 | +3 |
| TOTAL | **100 / 100 = 100 %** | 74 / 100 = 74 % | **+26** |

`any_hit_rate = 1.0` on measurable subset (2 / 2 qids hit recall@5 =
100 %; 3 qids n / a from no-gold-in-haystack — structural, identical to
the original Q18 § Phase 2 finding). Mean ingest 331 s / qid vs
~62 s / qid in 2026-05-10's parallel run — **5.3× slower wall, 35 %
more recall surface**.

**Verdict refinement: the silent-drop is concurrency-bound, not a
v0.5 steady-state defect.** Q18 § Phase 2's 82 % silent-drop rate on
2026-05-10 tenants was an artifact of `--per-sut-concurrency 4` ×
tier-1 200 K TPM. Graphiti hits the TPM ceiling on parallel
extraction bursts, partial-extraction failures cascade, and Episodic
writes get lost. At concurrency = 1 with TPM headroom, gnokee v0.5
ingest preserves 100 % of episodes on this 5-question sample.

The `INGEST_GAP_NOT_RETRIEVAL_GAP` verdict still holds for the
**2026-05-10 baseline** (the corpus where ADR-0012 § Stage C's 0.10
recall@5 number lives), but the bug class is now precisely named:
**concurrent ingest at tier-1 TPM is silently lossy**, not "narrative
content always silently lossy."

### Implications for Z-series (refined)

The refinement reorders the Z-series urgency from the original
README:

1. **Z3 — loud-failure telemetry now highest priority.** Cheapest to
   ship (v0.5.x candidate), would have caught the concurrency-bound
   drop immediately. Counter:
   `recall_telemetry.episodes_dropped_during_extraction`. Per-episode
   warning log. Optional `GNOKEE_INGEST_STRICT=1` for CI/spike
   harnesses.

2. **Z1 — always-write Episodic stays valid, demoted to v0.6.**
   Defense-in-depth; even with Z3 telemetry, gnokee should make
   Graphiti's extraction lane "best-effort enhancement" rather than
   gating Episodic writes on it. Less urgent at concurrency = 1.

3. **Z2 — lite-mode default for narrative stays v0.6.** Sidesteps the
   noisy extraction layer entirely for prose; preserves contradiction
   primitives for `lab` / `med` writes. Decoupled from the
   concurrency story.

4. **Z4 — new candidate from this finding: TPM-aware concurrency
   throttle in `gnokee_adapter.INGEST_CONCURRENCY` or in
   `gnokee.ingest_episode`.** Today the cap is a hardcoded constant
   (`2` in `gnokee_adapter`, `4` in run.py). A real fix is
   adaptive — back off when graphiti's underlying OpenAI client
   raises `RateLimitError`. Possibly upstream-only (graphiti-core
   change); flag in `docs/upstream-contributions/` if so.

The headline architectural lesson stays: **gnokee's storage path
should not silently lose episodes when graphiti's extraction path
strains.** Either Z1 (decouple) or Z3 + Z4 (surface + throttle).
Cheapest path = Z3 first.

## What this does NOT cover

- A fix for the silent drop — fix lands in the Z-series tracking issue,
  not here.
- LongMemEval-S strict accuracy (end-to-end answer correctness) —
  separate axis. Per ADR-0004, synthesis is consumer-LLM territory.
- The 13 `no_gold` cases — gold session is beyond the 20-session
  truncation. Structural, not gnokee's concern.
- basic-memory's higher recall — likely from FTS5 over the full
  conversation text without lossy fact extraction; not a gnokee target
  to chase before the ingest-gap is closed.

## Cost & time

- LLM: **$0** (no synth, no judge, no ingest in this spike — only
  re-query of existing tenants).
- Postgres + Neo4j + TEI: existing docker-compose stack, ~3 min to spin up.
- Author + run + post-process: ~1h 2026-05-12 evening.

## Run

```bash
# Phase 1 — top_k=100 re-query (query-only against pre-existing stageC tenants)
docker compose --profile embeddings up -d postgres neo4j tei
cd evals/spike_q18_recall_at_k_diagnostic
../../.venv/bin/python run.py

# run.py:
#   1. invokes Q10 harness with --query-only-suts gnokee --top-k 100
#   2. computes rank-of-gold curve per question_type
#   3. for `beyond` rows, queries episode_metadata for gold our_ids
#   4. writes results/<utc>.json with all three phases
#   5. prints summary table mirroring the § Results section above
```

## File layout

```
evals/spike_q18_recall_at_k_diagnostic/
├── README.md              ← this file
├── run.py                 ← post-process; reuses spike_q10_cross_tool harness for phase 1
└── results/               ← gitignored
    └── <utc>.json
```

## Cross-refs

- **ADR-0012** § Stage C addendum (cross-tool eval verdict) — landed
  by this spike's verdict.
- **ADR-0019** § LongMemEval-S publish stance (#81 verdict, 2026-05-12)
  — needs cross-reference to Q18 finding; recall is at-ceiling on
  stored data, not broken.
- **Issue [#81](https://github.com/gnokeelabs/gnokee/issues/81)**
  (closed) — LongMemEval-S publish-vs-defer; this finding may reopen
  the publish stance once Z1/Z2 ship.
- **Issue Z** (new tracking issue, ingest-hardening umbrella) — owns
  the Z1/Z2/Z3 work.
- **Q10** `spike_q10_cross_tool/` — source corpus + harness this spike
  re-uses.
- ADR-0012 Stage A § read-out — predicted "edge-fact triples strip
  literal answer values"; Q18 finds an upstream cause (the episodes
  themselves don't survive `add_episode`).
- AGENTS.md "do not" list — no auto-resolve; this spike does not
  propose one.
