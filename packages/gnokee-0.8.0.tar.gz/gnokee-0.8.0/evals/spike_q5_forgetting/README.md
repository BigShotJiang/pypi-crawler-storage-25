# Spike Q5 — Forgetting smoke test

## Goal

Validate the **propagation chain** in `gnokee.forget(X)` per
`docs/architecture.md`:

> Hard delete with tombstone propagation — vector index, graph,
> derived summaries all touched. Returns a `ForgetReceipt`
> enumerating affected artifacts.

A successful `forget` must remove the episode from **every retrieval
surface** simultaneously. This spike does not test cryptographic
erasure (that requires a KMS) or soft supersession (that requires
`transaction_time_end` machinery). It tests the **hard-delete path**
end-to-end against the Q1 corpus.

## Decision criterion

After `forget(e_X)`:

1. The Neo4j `Episodic` node, all `MENTIONS` relations from it, and
   any `RELATES_TO` edges that referenced it as their sole episode,
   are gone (and orphaned `Entity`s with zero remaining mentions are
   cleaned up).
2. The gnokee-side content-embedding map (the v0.1 pgvector path)
   no longer contains the episode's embedding.
3. A retrieval query that previously surfaced `e_X` no longer
   surfaces it (any rank).

ADOPT if all three hold for **2/2 forget operations** on episodes
that were verifiably retrievable beforehand.

## Test design

Two probes against the Q1 corpus (already in Neo4j under
`group_id=spike`, `episodes.jsonl` available):

| Probe | Forget target | Pre-forget query | Pre-forget expectation |
|---|---|---|---|
| 1 | `e_005` (K+ 3.1 original) | "What was my potassium reading on 2024-04-10?" | `e_005` in top-3 by cosine |
| 2 | `e_002` (MongoDB migration) | "What database does the project use?" | `e_002` in top-3 by cosine |

For each probe:

1. Embed the corpus, compute baseline cosine ranking — assert target
   is in top-3 (otherwise the probe itself is invalid)
2. Read pre-forget Neo4j state: count `Episodic`, `Entity`, `MENTIONS`,
   `RELATES_TO` for the target's neighborhood (provenance for the
   `ForgetReceipt`)
3. Execute `forget(e_X)` against the gnokee-managed in-memory
   embedding map AND the Graphiti-managed Neo4j store (single Cypher
   transaction)
4. Re-rank — assert `e_X` is gone (no longer in any returned
   position)
5. Re-read Neo4j — assert provenance counts have decremented as
   expected
6. Emit a `ForgetReceipt`-shaped record per probe

## What this spike does NOT cover

- **Soft supersession.** Different code path (set
  `transaction_time_end`, leave row queryable via time-travel).
  Belongs in a v0.1 retrieval spec test, not here.
- **Cryptographic erasure.** Requires a KMS-backed DEK; deferred to a
  v0.2+ test against OpenBao or similar.
- **Tombstone propagation to derived summaries.** v0.1 doesn't yet
  generate maintenance summaries; their forget-cascade design lands
  with the maintenance scheduler.
- **Tenant-scoped forget isolation.** Multi-tenancy validation is a
  separate question (Q8-equivalent); this spike runs single-tenant
  on `group_id=spike`.

## Cost & time

No LLM calls. ~12 cosine computations (corpus + 2 queries) via local
bge-m3, plus ~6 Cypher round-trips. Under 30 seconds wall, $0.
