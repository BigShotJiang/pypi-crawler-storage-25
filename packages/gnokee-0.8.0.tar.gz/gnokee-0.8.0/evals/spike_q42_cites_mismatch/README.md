# Spike Q42 — Answer-Cites-Mismatch Detector

> Eval class for ADR-0016 (issue [#76](https://github.com/gnokeelabs/gnokee/issues/76))
> per-claim bi-temporal citation envelope. Pairs with ADR-0019 confidence-decay
> (#80) and ADR-0013 declarative envelope (#72) — all three target the MCP read
> surface.

## Goal

The citation envelope ADR-0016 ships in v0.5 lets the host LLM emit inline
`[c1]`, `[c2]`, … markers in its answer. Each marker maps to a `Citation`
entry that carries `episode_uuid`, `valid_at`, `asserted_at`, and an optional
`extracted_quote` body span.

The new eval class this spike defines: **detect when the host LLM's claim
does NOT align with the citation it cites.** Two failure modes the detector
must catch:

1. **Episode mismatch.** LLM claims a date / drug / value that does not
   appear anywhere in the cited episode's body. Either the LLM
   hallucinated the claim, or it picked the wrong `[cN]` marker.
2. **Bi-temporal mismatch.** LLM claims something is current ("currently
   taking X") but the cited episode's `valid_at` is far in the past AND
   the chain has been superseded by a later episode within the same
   recall response (`supersession_hints[]`). The host LLM read the
   right episode but missed the supersession trail.

The spike is a **detector spec + corpus + queries**, not a full
LLM-on-the-loop run. Pass criterion: the detector flags 100% of seeded
mismatches and produces zero false positives on the seeded aligned
answers. No consumer LLM is called by the harness — host-LLM answers
are simulated by `simulated_answers.jsonl` (aligned + mismatched
variants) so the detector logic is exercised deterministically.

The spike's wider purpose: lock down what `[cN]` mismatch *means*
operationally, so a v0.5.x follow-up that adds an LLM-in-the-loop
grader has a deterministic baseline to regression-test against.

## Decision criterion

| Score class | Headline | Action |
|---|---|---|
| `DETECTOR_OK` | flags all seeded mismatches, zero false positives on aligned | Adopt detector + wire into eval harness for v0.5.x |
| `DETECTOR_PARTIAL` | catches ≥90% of seeded mismatches, ≤1 false positive | Tighten detector rules + re-run before adoption |
| `DETECTOR_FAIL` | misses ≥2 seeded mismatches OR ≥2 false positives | Reopen detector spec; do NOT ship as a gating eval |

Exact thresholds:

- Episode-mismatch recall = 100% on seeded `mismatch_episode` answers.
- Bi-temporal-mismatch recall = 100% on seeded `mismatch_temporal` answers.
- False-positive count on seeded `aligned` answers must be 0 for
  `DETECTOR_OK`, ≤1 for `DETECTOR_PARTIAL`.

## Methodology

The detector is **deterministic** — no LLM calls in the grading loop.
Given a simulated answer + its `citations` map + the recall response
the LLM saw, it checks two invariants:

1. **Claim tokens must appear in cited episode body.** For each `[cN]`
   marker in the simulated answer, fetch the cited episode body via
   `gnokee_fact_provenance(citations[cN].episode_uuid)`. Token-set
   intersection between the claim sentence and the body must clear
   `MIN_TOKEN_OVERLAP` (default 0.4). Below threshold = mismatch.
2. **"Currently / now / today" claims must match supersession state.**
   When the claim sentence contains a temporal-current marker (regex
   `_CURRENT_MARKER_PATTERN` — `currently`, `now`, `today`, `recently`,
   `at the moment`, …), the cited episode's `valid_at` must be the
   chain head at the recall response's `as_of`. If the response's
   `supersession_hints[]` lists the cited episode as superseded,
   that's a mismatch.

Corpus shape (`corpus.jsonl`, 12 episodes):

- 3 supersession chains (med dose changes, location moves, GP changes).
- 2 reinforcement episodes (same fact, different sources).
- 2 unrelated facts (distractors for episode-mismatch testing).
- 5 atomic clinical / personal episodes.

Probe set (`queries.yaml`, 12 questions): 4 with seeded `aligned`
answer variants, 4 with seeded `mismatch_episode` variants, 4 with
seeded `mismatch_temporal` variants. Each question carries the answer
the simulated host LLM produces.

## Anti-patterns this spike must avoid

- **LLM-graded mismatch.** The detector is deterministic. Adding an
  LLM-in-the-loop grader belongs to a v0.5.x follow-up — this spike
  ships the BASELINE the LLM grader must outperform.
- **Synthesised `extracted_quote`.** Even when ADR-0016's
  `extracted_quote` is populated post-v0.5, the detector compares
  against the cited episode's body NOT against the quote. The quote is
  a hint; the body is the ground truth (ADR-0016 § Anti-patterns).
- **Auto-resolving the mismatch.** The detector flags + surfaces; it
  does NOT pick a side, edit the answer, or silence one citation. The
  host LLM owns the answer (AGENTS.md "do not" § auto-resolve).
- **Hidden state.** All inputs are in-repo: `corpus.jsonl`,
  `queries.yaml`, `simulated_answers.jsonl`. No external services
  touched by the harness.

## Files

- `corpus.jsonl` — episodes to ingest under `GROUP_ID="spike_q42_cites"`.
- `queries.yaml` — probe questions + expected citation behaviour.
- `simulated_answers.jsonl` — simulated host-LLM answers (aligned +
  mismatched variants) keyed by probe id + variant label.
- `run.py` — harness. Ingests corpus, calls `gnokee.recall` per probe,
  runs the deterministic detector against each simulated answer
  variant, emits `results/<utc-stamp>.json`.
- `requirements.txt` — minimal deps (gnokee dev install + dotenv +
  PyYAML).

## Pass criterion (operational)

`DETECTOR_OK` iff:

```python
seeded_mismatch_recall  == 1.0
false_positive_rate     == 0.0
```

The detector is intentionally strict — a real LLM grader will trade
some recall for fewer false positives; this baseline does not.

## Cross-refs

- ADR-0016 § "Wire surface — recall" (citation map shape).
- ADR-0019 § "What ships in v0.5" (recency proxy, NOT a confidence
  filter for citations).
- ADR-0008 (contradiction storage — citations pair with
  contradictions, both sides surfaced).
- Issue [#76](https://github.com/gnokeelabs/gnokee/issues/76)
  acceptance criterion 6 (new eval class).
- Sibling spike: `evals/spike_q13_confidence/` (ADR-0019 verdict).
