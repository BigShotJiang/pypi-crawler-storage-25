"""
TestSuite manager class for TestZeus test suite operations.
"""

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.test_suite import TestSuite


class TestSuiteManager(BaseManager[TestSuite]):
    """
    Manager class for TestZeus test suite entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        super().__init__(client, "test_suites", TestSuite)
