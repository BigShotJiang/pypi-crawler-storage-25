"""
HypermindCodeBlocks manager class for TestZeus hypermind_code_blocks operations.
"""

from typing import Any, Dict, List, Literal, Optional, Text

from pocketbase.client import FileUpload

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.hypermind_code_blocks import HypermindCodeBlocks
from testzeus_sdk.utils.helpers import get_id_by_name


class HypermindCodeBlocksManager(BaseManager[HypermindCodeBlocks]):
    """
    Manager class for TestZeus hypermind_code_blocks entities.

    This class provides CRUD operations and specialized methods
    for working with hypermind_code_blocks entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        """
        Initialize a HypermindCodeBlocksManager.

        Args:
            client: TestZeus client instance
        """
        super().__init__(client, "hypermind_code_blocks", HypermindCodeBlocks)

    async def create(self, data: Dict[str, Any]) -> HypermindCodeBlocks:
        """
        Create a new hypermind code blocks.

        Args:
            data: HypermindCodeBlocks data

        Returns:
            Created hypermind_code_blocks instance
        """
        return await super().create(data)

    async def create_hypermind_code_blocks(
        self,
        name: Text,
        status: Literal["draft", "ready", "deleted"] = "draft",
        code_files: Optional[Text] = None,
        tags: Optional[List[Text]] = None,
    ) -> HypermindCodeBlocks:
        """
        Create new hypermind code blocks with individual fields.

        Args:
            name: Name of the code blocks
            status: Status ('draft' by default)
            code_files: Path to code files
            tags: List of tag IDs

        Returns:
            Created hypermind_code_blocks instance
        """
        code_blocks_data: Dict[str, Any] = {
            "name": name,
            "status": status,
            "tags": tags,
            "metadata": {},
        }

        # Check for code_files and upload if present
        if code_files:
            filename = code_files
            code_blocks_data["code_files"] = FileUpload(filename, open(filename, "rb"))

        return await self.create(code_blocks_data)

    async def update(self, id_or_name: Text, data: Dict[str, Any]) -> HypermindCodeBlocks:
        """
        Update existing hypermind code blocks.

        Args:
            id_or_name: HypermindCodeBlocks ID or name
            data: Updated hypermind_code_blocks data

        Returns:
            Updated hypermind_code_blocks instance
        """
        return await super().update(id_or_name, data)

    async def update_hypermind_code_blocks(
        self,
        id_or_name: Text,
        name: Optional[Text] = None,
        status: Optional[Literal["draft", "ready", "deleted"]] = None,
        code_files: Optional[Text] = None,
        tags: Optional[List[Text]] = None,
    ) -> HypermindCodeBlocks:
        """
        Update existing hypermind code blocks with individual fields.

        Args:
            id_or_name: HypermindCodeBlocks ID or name
            name: Name of the code blocks
            status: Status
            code_files: Path to code files
            tags: List of tag IDs

        Returns:
            Updated hypermind_code_blocks instance
        """
        update_data: Dict[str, Any] = {}
        if name:
            update_data["name"] = name
        if status:
            update_data["status"] = status
        if tags:
            update_data["tags"] = tags

        # Check for code_files and upload if present
        if code_files:
            filename = code_files
            update_data["code_files+"] = FileUpload(filename, open(filename, "rb"))

        return await self.update(id_or_name, update_data)

    async def add_file(self, id_or_name: str, file_name: str) -> HypermindCodeBlocks:
        """
        Add a file to hypermind code blocks.
        """
        file = FileUpload(file_name, open(file_name, "rb"))
        return await self.update(id_or_name, {"code_files+": file})

    async def remove_file(self, id_or_name: str, file_name: str) -> HypermindCodeBlocks:
        """
        Remove a file from hypermind code blocks.
        """
        code_blocks = await self.get_one(id_or_name)
        if code_blocks.code_files:
            for file in code_blocks.code_files:
                if file_name.split("/")[-1].split(".")[0] in file:
                    file_name = file
                    break
        return await self.update(id_or_name, {"code_files-": file_name})

    async def remove_all_files(self, id_or_name: str) -> HypermindCodeBlocks:
        """
        Remove all files from hypermind code blocks.
        """
        return await self.update(id_or_name, {"code_files": None})

    async def add_tags(self, id_or_name: str, tags: List[str]) -> HypermindCodeBlocks:
        """
        Add tags to hypermind code blocks.

        Args:
            id_or_name: HypermindCodeBlocks ID or name
            tags: List of tag names or IDs

        Returns:
            Updated hypermind_code_blocks instance
        """
        # Get the code blocks
        code_blocks = await self.get_one(id_or_name)

        # Process tags
        tag_ids = []
        current_tags = code_blocks.tags or []

        # Add existing tags
        if isinstance(current_tags, list):
            tag_ids.extend(current_tags)

        # Process new tags
        for tag in tags:
            if self._is_valid_id(tag):
                if tag not in tag_ids:
                    tag_ids.append(tag)
            else:
                tag_id = get_id_by_name(self.client, "tags", tag)
                if tag_id and tag_id not in tag_ids:
                    tag_ids.append(tag_id)

        # Update the code blocks
        return await self.update(str(code_blocks.id), {"tags": tag_ids})

    def _process_references(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process name-based references to ID-based references.

        Args:
            data: HypermindCodeBlocks data with potential name-based references

        Returns:
            Processed data with ID-based references
        """
        result = data.copy()
        tenant_id = self.client.get_tenant_id()

        # Process tags references
        if "tags" in result and isinstance(result["tags"], list):
            tag_ids = []
            for tag in result["tags"]:
                if isinstance(tag, str):
                    if self._is_valid_id(tag):
                        tag_ids.append(tag)
                    else:
                        tag_id = get_id_by_name(self.client, "tags", tag, tenant_id)
                        if tag_id:
                            tag_ids.append(tag_id)
            result["tags"] = tag_ids

        return result
