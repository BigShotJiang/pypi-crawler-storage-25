"""
UserIntegration manager class for TestZeus user_integration operations.
"""

from typing import Any, Dict, List, Optional, Union

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.user_integration import UserIntegration


class UserIntegrationManager(BaseManager[UserIntegration]):
    """
    Manager class for TestZeus user_integration entities.

    This class provides read-only operations for user_integration entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        """
        Initialize a UserIntegrationManager.

        Args:
            client: TestZeus client instance
        """
        super().__init__(client, "user_integration", UserIntegration)

    async def get_one(self, id_or_name: str, expand: Optional[Union[str, List[str]]] = None) -> UserIntegration:
        """
        Get a single user integration by ID or name.

        Args:
            id_or_name: UserIntegration ID or name
            expand: Fields to expand in the response

        Returns:
            UserIntegration model instance
        """
        await self.client.ensure_authenticated()

        expand_str = None
        if expand:
            if isinstance(expand, list):
                expand_str = ",".join(expand)
            else:
                expand_str = expand

        # Check if the provided string is an ID or name
        if self._is_valid_id(id_or_name):
            result = self.client.pb.collection(self.collection_name).get_one(id_or_name, query_params={"expand": expand_str})
        else:
            # Assume it's a name and try to find it
            tenant_id = self.client.get_tenant_id() or await self.client.get_tenant_id_async()
            if not tenant_id:
                raise ValueError("User must be authenticated with a tenant to find by name")

            filter_str = f'name = "{id_or_name}" && tenant_id = "{tenant_id}"'
            try:
                result = self.client.pb.collection(self.collection_name).get_first_list_item(filter_str)
            except Exception as e:
                raise ValueError(f"Could not find {self.collection_name} with name: {id_or_name}") from e

        return self.model_class(self._record_to_dict(result))

    def _record_to_dict(self, record: Any) -> Dict[str, Any]:
        """
        Convert a PocketBase Record to a dictionary.
        """
        if hasattr(record, "to_dict") and callable(record.to_dict):
            return record.to_dict()
        elif hasattr(record, "export") and callable(record.export):
            return record.export()
        elif hasattr(record, "__dict__"):
            return record.__dict__
        else:
            return {key: getattr(record, key) for key in dir(record) if not key.startswith("_") and not callable(getattr(record, key))}

