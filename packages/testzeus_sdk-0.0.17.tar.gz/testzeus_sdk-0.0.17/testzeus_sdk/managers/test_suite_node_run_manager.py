"""
TestSuiteNodeRun manager class for TestZeus test suite node run operations.
"""

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.test_suite_node_run import TestSuiteNodeRun


class TestSuiteNodeRunManager(BaseManager[TestSuiteNodeRun]):
    """
    Manager class for TestZeus test suite node run entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        super().__init__(client, "test_suite_node_runs", TestSuiteNodeRun)
