"""
TestSuiteSchedule manager class for TestZeus test suite schedule operations.
"""

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.test_suite_schedule import TestSuiteSchedule


class TestSuiteScheduleManager(BaseManager[TestSuiteSchedule]):
    """
    Manager class for TestZeus test suite schedule entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        super().__init__(client, "test_suite_schedule", TestSuiteSchedule)
