"""
TestSuiteRun manager class for TestZeus test suite run operations.
"""

import datetime
from typing import Any, Dict, List, Optional

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.test_suite_run import TestSuiteRun


class TestSuiteRunManager(BaseManager[TestSuiteRun]):
    """
    Manager class for TestZeus test suite run entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        super().__init__(client, "test_suite_runs", TestSuiteRun)

    async def pause(
        self,
        suite_run_id: str,
        mode: str = "graceful",
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"mode": mode}
        if reason:
            payload["reason"] = reason
        return await self.client.request(
            "POST",
            f"/api/test_suite_runs/{suite_run_id}/pause",
            json_data=payload,
        )

    async def resume(self, suite_run_id: str) -> Dict[str, Any]:
        return await self.client.request(
            "POST",
            f"/api/test_suite_runs/{suite_run_id}/resume",
        )

    async def cancel(self, suite_run_id: str) -> Dict[str, Any]:
        return await self.client.request(
            "POST",
            f"/api/test_suite_runs/{suite_run_id}/cancel",
        )

    async def run(
        self,
        display_name: str,
        test_suite: str,
        input_values: Optional[Dict[str, Any]] = None,
        environment: Optional[str] = None,
        notification_channels: Optional[List[str]] = None,
    ) -> TestSuiteRun:
        """
        Create and start a test suite run.

        Args:
            display_name: Display name for the test suite run
            test_suite: Test suite ID or name
            input_values: Input values for the workflow (optional)
            environment: Environment ID or name (optional)
            notification_channels: List of notification channel IDs or names (optional)

        Returns:
            Created test suite run instance
        """
        # Get the test suite to retrieve workflow_definition
        test_suite_obj = await self.client.test_suites.get_one(test_suite)
        
        if not test_suite_obj.workflow_definition:
            raise ValueError(f"Test suite '{test_suite_obj.name}' has no workflow_definition. Please ensure the test suite has a valid workflow.")

        # Generate timestamp in ddyymm_hhmmss format (day-year-month_hour-minute-second)
        timestamp = datetime.datetime.now().strftime("%d%y%m_%H%M%S")
        name = f"{display_name}_{timestamp}"

        # Get user ID for created_by
        user_id = self.client.get_user_id() or await self.client.get_user_id_async()
        if not user_id:
            raise ValueError("Unable to get user ID. Ensure you are authenticated.")

        # Build the test suite run data
        test_suite_run_data: Dict[str, Any] = {
            "name": name,
            "display_name": display_name,
            "test_suite": test_suite_obj.id,
            "status": "pending",
            "created_by": user_id,
            "execution_mode": "lenient",
            "is_deleted": False,
            "workflow_snapshot": test_suite_obj.workflow_definition,
            "input_values": input_values or {},
            "context_store": {},
            "node_statuses": {},
            "metadata": {},
        }

        # Add optional fields
        if environment:
            test_suite_run_data["environment"] = environment
        if notification_channels:
            test_suite_run_data["notification_channels"] = notification_channels

        # Process references (convert names to IDs if needed)
        processed_data = self._process_references(test_suite_run_data)

        # Create the test suite run
        return await self.create(processed_data)
