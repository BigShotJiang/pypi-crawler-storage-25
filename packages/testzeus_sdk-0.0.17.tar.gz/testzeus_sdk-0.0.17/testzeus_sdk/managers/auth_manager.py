"""
Auth Manager for TestZeus SDK.

Handles session exchange and token management operations.
Uses existing PocketBase /api/collections/users/auth-refresh endpoint.
"""

import json
import os
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional

import aiohttp
from aiohttp import ClientTimeout

from testzeus_sdk.client import TestZeusClient

# 5 hours timeout for all HTTP requests (same as client)
DEFAULT_TIMEOUT = 5 * 60 * 60  # 18000 seconds
logger = logging.getLogger("testzeus_sdk.auth_manager")


def _auth_debug_enabled() -> bool:
    return str(os.environ.get("TESTZEUS_AUTH_DEBUG", "")).lower() in {"1", "true", "yes", "on"}


def _debug(msg: str) -> None:
    if _auth_debug_enabled():
        logger.warning("[AUTH_DEBUG] %s", msg)


@dataclass
class SessionExchangeResponse:
    """Response from session exchange via auth-refresh."""
    success: bool
    session_token: str
    user_id: str
    tenant_id: str
    email: str
    token_expires: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SessionExchangeResponse":
        """Create from API response dict."""
        return cls(
            success=True,
            session_token=data.get("token", ""),
            user_id=data.get("record", {}).get("id", "") if data.get("record") else "",
            tenant_id=data.get("record", {}).get("tenant", "") if data.get("record") else "",
            email=data.get("record", {}).get("email", "") if data.get("record") else "",
            token_expires=None,  # PB tokens don't expose expiry in response
        )


@dataclass
class SessionValidateResponse:
    """Response from validating a session token."""
    valid: bool
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    email: Optional[str] = None
    error: Optional[str] = None


class AuthManager:
    """
    Manager for authentication operations.

    Provides session exchange functionality using existing PocketBase auth-refresh.
    This allows Hermes to exchange a UI-provided PocketBase JWT for CLI-compatible auth.
    """

    def __init__(self, client: TestZeusClient) -> None:
        """
        Initialize AuthManager.

        Args:
            client: TestZeusClient instance
        """
        self.client = client

    async def exchange_session(self, pb_token: str) -> SessionExchangeResponse:
        """
        Exchange a PocketBase JWT for a refreshed session token.

        This calls POST /api/collections/users/auth-refresh with the provided
        PocketBase JWT. The refreshed token can be used for CLI operations.

        Args:
            pb_token: PocketBase JWT token from UI

        Returns:
            SessionExchangeResponse with token and user info

        Raises:
            ValueError: If token exchange fails
        """
        if not pb_token:
            raise ValueError("PocketBase token is required")
        _debug(f"exchange_session start base_url={self.client.base_url}")

        endpoint_candidates = [
            "/api/collections/_pb_users_auth_/auth-refresh",
            "/api/collections/users/auth-refresh",
            "/api/users/auth-refresh",
        ]

        # Ensure we have a session for making requests
        if self.client.session is None:
            self.client.session = aiohttp.ClientSession(
                timeout=ClientTimeout(total=DEFAULT_TIMEOUT),
                connector=aiohttp.TCPConnector(ssl=False),
            )

        header_candidates = [pb_token, f"Bearer {pb_token}"]
        errors = []

        for endpoint in endpoint_candidates:
            url = f"{self.client.base_url}{endpoint}"
            for auth_value in header_candidates:
                headers = {
                    "Authorization": auth_value,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                }

                async with self.client.session.post(url, headers=headers) as response:
                    response_text = await response.text()
                    _debug(
                        f"exchange_session probe endpoint={endpoint} auth_mode={'bearer' if auth_value.startswith('Bearer ') else 'raw'} status={response.status}"
                    )

                    if response.status != 200:
                        try:
                            error_data = json.loads(response_text)
                            error_msg = error_data.get("message", response_text)
                        except (json.JSONDecodeError, Exception):
                            error_msg = response_text
                        errors.append(
                            f"{endpoint} auth={('bearer' if auth_value.startswith('Bearer ') else 'raw')} status={response.status} message={error_msg}"
                        )
                        continue

                    try:
                        data = json.loads(response_text)
                    except json.JSONDecodeError as e:
                        raise ValueError(f"Invalid JSON response from auth-refresh: {e}")

                    if not data.get("token"):
                        raise ValueError("Auth-refresh did not return a token")
                    _debug(
                        f"exchange_session success endpoint={endpoint} user_id={data.get('record', {}).get('id', '')} tenant_id={data.get('record', {}).get('tenant', '')}"
                    )

                    return SessionExchangeResponse.from_dict(data)

        _debug("exchange_session failed after all endpoint/header probes")
        raise ValueError(f"Token exchange failed: {'; '.join(errors)}")

    async def validate_token(self, token: str) -> SessionValidateResponse:
        """
        Validate a token by attempting to refresh it.

        Args:
            token: Token to validate

        Returns:
            SessionValidateResponse with validation result
        """
        try:
            result = await self.exchange_session(token)
            return SessionValidateResponse(
                valid=True,
                user_id=result.user_id,
                tenant_id=result.tenant_id,
                email=result.email,
            )
        except ValueError as e:
            return SessionValidateResponse(
                valid=False,
                error=str(e),
            )

    def extract_token_info(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Extract basic info from a JWT without validation.

        This decodes the payload (middle part) of a JWT without
        verifying the signature. Useful for quick token inspection.

        Args:
            token: JWT token

        Returns:
            Dict with token info (userId, tenantId, exp, etc.) or None if invalid
        """
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None

            # Decode payload (second part)
            import base64
            payload_b64 = parts[1]
            # Add padding if needed
            padding = 4 - (len(payload_b64) % 4)
            if padding != 4:
                payload_b64 += "=" * padding

            payload_json = base64.urlsafe_b64decode(payload_b64)
            payload = json.loads(payload_json)

            return {
                "user_id": payload.get("id") or payload.get("sub"),
                "tenant_id": payload.get("tenant"),
                "email": payload.get("email"),
                "expires_at": payload.get("exp"),
                "issued_at": payload.get("iat"),
            }
        except Exception:
            return None

    def is_token_expired(self, token: str) -> bool:
        """
        Check if a token is expired based on its 'exp' claim.

        Args:
            token: JWT token

        Returns:
            True if token is expired, False otherwise
        """
        info = self.extract_token_info(token)
        if not info or not info.get("expires_at"):
            # If we can't determine expiry, assume it's valid
            return False

        import time
        return info["expires_at"] < int(time.time())
