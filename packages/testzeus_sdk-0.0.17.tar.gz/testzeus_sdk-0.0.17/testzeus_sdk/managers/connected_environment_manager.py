"""
ConnectedEnvironment manager class for TestZeus connected environment operations.
"""

from typing import Any, Dict, List, Optional, Text

from pocketbase.client import FileUpload

from testzeus_sdk.client import TestZeusClient
from testzeus_sdk.managers.base import BaseManager
from testzeus_sdk.models.connected_environment import ConnectedEnvironment
from testzeus_sdk.utils.helpers import get_id_by_name


class ConnectedEnvironmentManager(BaseManager[ConnectedEnvironment]):
    """
    Manager class for TestZeus connected environment entities.

    This class provides CRUD operations and specialized methods
    for working with connected environment entities.
    """

    def __init__(self, client: TestZeusClient) -> None:
        """
        Initialize a ConnectedEnvironmentManager.

        Args:
            client: TestZeus client instance
        """
        super().__init__(client, "connected_environment", ConnectedEnvironment)

    async def create(self, data: Dict[str, Any]) -> ConnectedEnvironment:
        """
        Create a new connected environment.

        Args:
            data: Connected environment data

        Returns:
            Created connected environment instance
        """
        return await super().create(data)

    async def create_connected_environment(
        self,
        name: Text,
        connection: Optional[Text] = None,
        tags: Optional[List[Text]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        skip_process: bool = False,
    ) -> ConnectedEnvironment:
        """
        Create a new connected environment with individual fields.

        Args:
            name: Name of the connected environment
            connection: Connection ID to link with
            tags: List of tag IDs
            metadata: Optional metadata dictionary
            skip_process: Whether to skip processing (default: False)

        Returns:
            Created connected environment instance
        """
        conn_env_data: Dict[str, Any] = {
            "name": name,
            "skip_process": skip_process,
        }

        if connection:
            conn_env_data["connection"] = connection

        if tags:
            conn_env_data["tags"] = tags

        if metadata:
            conn_env_data["metadata"] = metadata
        else:
            conn_env_data["metadata"] = {}

        return await self.create(conn_env_data)

    async def update(self, id_or_name: Text, data: Dict[str, Any]) -> ConnectedEnvironment:
        """
        Update an existing connected environment.

        Args:
            id_or_name: Connected environment ID or name
            data: Updated connected environment data

        Returns:
            Updated connected environment instance
        """
        return await super().update(id_or_name, data)

    async def update_connected_environment(
        self,
        id_or_name: Text,
        name: Optional[Text] = None,
        connection: Optional[Text] = None,
        tags: Optional[List[Text]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        skip_process: Optional[bool] = None,
    ) -> ConnectedEnvironment:
        """
        Update an existing connected environment with individual fields.

        Args:
            id_or_name: Connected environment ID or name
            name: New name of the connected environment
            connection: Connection ID to link with
            tags: List of tag IDs
            metadata: Optional metadata dictionary
            skip_process: Whether to skip processing

        Returns:
            Updated connected environment instance
        """
        update_data: Dict[str, Any] = {}

        if name is not None:
            update_data["name"] = name

        if connection is not None:
            update_data["connection"] = connection

        if tags is not None:
            update_data["tags"] = tags

        if metadata is not None:
            update_data["metadata"] = metadata

        if skip_process is not None:
            update_data["skip_process"] = skip_process

        return await self.update(id_or_name, update_data)

    async def add_metadata_file(self, id_or_name: str, file_path: str) -> ConnectedEnvironment:
        """
        Add a metadata file to a connected environment.

        Args:
            id_or_name: Connected environment ID or name
            file_path: Path to the file to add

        Returns:
            Updated connected environment instance
        """
        file = FileUpload(file_path, open(file_path, "rb"))
        return await self.update(id_or_name, {"metadata_files+": file})

    async def remove_metadata_file(self, id_or_name: str, file_name: str) -> ConnectedEnvironment:
        """
        Remove a metadata file from a connected environment.

        Args:
            id_or_name: Connected environment ID or name
            file_name: Name of the file to remove

        Returns:
            Updated connected environment instance
        """
        connected_env = await self.get_one(id_or_name)
        if connected_env.metadata_files:
            for file in connected_env.metadata_files:
                if file_name.split("/")[-1].split(".")[0] in file:
                    file_name = file
                    break
        return await self.update(id_or_name, {"metadata_files-": file_name})

    async def remove_all_metadata_files(self, id_or_name: str) -> ConnectedEnvironment:
        """
        Remove all metadata files from a connected environment.

        Args:
            id_or_name: Connected environment ID or name

        Returns:
            Updated connected environment instance
        """
        return await self.update(id_or_name, {"metadata_files": None})

    async def add_code_file(self, id_or_name: str, file_path: str) -> ConnectedEnvironment:
        """
        Add a code file to a connected environment.

        Args:
            id_or_name: Connected environment ID or name
            file_path: Path to the file to add

        Returns:
            Updated connected environment instance
        """
        file = FileUpload(file_path, open(file_path, "rb"))
        return await self.update(id_or_name, {"code_files+": file})

    async def remove_code_file(self, id_or_name: str, file_name: str) -> ConnectedEnvironment:
        """
        Remove a code file from a connected environment.

        Args:
            id_or_name: Connected environment ID or name
            file_name: Name of the file to remove

        Returns:
            Updated connected environment instance
        """
        connected_env = await self.get_one(id_or_name)
        if connected_env.code_files:
            for file in connected_env.code_files:
                if file_name.split("/")[-1].split(".")[0] in file:
                    file_name = file
                    break
        return await self.update(id_or_name, {"code_files-": file_name})

    async def remove_all_code_files(self, id_or_name: str) -> ConnectedEnvironment:
        """
        Remove all code files from a connected environment.

        Args:
            id_or_name: Connected environment ID or name

        Returns:
            Updated connected environment instance
        """
        return await self.update(id_or_name, {"code_files": None})

    async def add_tags(self, id_or_name: str, tags: List[str]) -> ConnectedEnvironment:
        """
        Add tags to a connected environment.

        Args:
            id_or_name: Connected environment ID or name
            tags: List of tag names or IDs

        Returns:
            Updated connected environment instance
        """
        # Get the connected environment
        connected_env = await self.get_one(id_or_name)

        # Process tags
        tag_ids = []
        current_tags = connected_env.tags or []

        # Add existing tags
        if isinstance(current_tags, list):
            tag_ids.extend(current_tags)

        # Process new tags
        for tag in tags:
            if self._is_valid_id(tag):
                if tag not in tag_ids:
                    tag_ids.append(tag)
            else:
                tag_id = get_id_by_name(self.client, "tags", tag)
                if tag_id and tag_id not in tag_ids:
                    tag_ids.append(tag_id)

        # Update the connected environment
        return await self.update(str(connected_env.id), {"tags": tag_ids})

    def _process_references(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process name-based references to ID-based references.

        Args:
            data: Connected environment data with potential name-based references

        Returns:
            Processed data with ID-based references
        """
        result = data.copy()
        tenant_id = self.client.get_tenant_id()

        # Process tags references
        if "tags" in result and isinstance(result["tags"], list):
            tag_ids = []
            for tag in result["tags"]:
                if isinstance(tag, str):
                    if self._is_valid_id(tag):
                        tag_ids.append(tag)
                    else:
                        tag_id = get_id_by_name(self.client, "tags", tag, tenant_id)
                        if tag_id:
                            tag_ids.append(tag_id)
            result["tags"] = tag_ids

        # Process connection reference
        if "connection" in result and isinstance(result["connection"], str):
            connection = result["connection"]
            if not self._is_valid_id(connection):
                # Assuming connection collection name, adjust if different
                connection_id = get_id_by_name(self.client, "user_integration", connection, tenant_id)
                if connection_id:
                    result["connection"] = connection_id

        return result
