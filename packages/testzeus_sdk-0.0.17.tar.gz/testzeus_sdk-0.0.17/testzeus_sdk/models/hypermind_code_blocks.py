"""
HypermindCodeBlocks model class for TestZeus hypermind_code_blocks entities.
"""

from typing import Any, Dict, List

from testzeus_sdk.models.base import BaseModel


class HypermindCodeBlocks(BaseModel):
    """
    Model class for TestZeus hypermind_code_blocks entities.

    This class represents hypermind code blocks in TestZeus, which can be
    used to store and manage code files for testing.
    """

    def __init__(self, data: Dict[str, Any]):
        """
        Initialize a HypermindCodeBlocks model with data from the API.

        Args:
            data: Dictionary containing hypermind_code_blocks data
        """
        super().__init__(data)

        # Extract common fields (excluding feature_id, spec_hash, is_deleted)
        self.name: str = data.get("name")
        self.status: str = data.get("status")
        self.tenant: str = data.get("tenant")
        self.modified_by: str = data.get("modified_by")
        self.code_files: List[str] = data.get("code_files")
        self.tags: List[str] = data.get("tags")
        self.metadata: str = data.get("metadata")
        self.skip_process: bool = data.get("skip_process")

    def is_ready(self) -> bool:
        """
        Check if the code blocks are ready for use.

        Returns:
            True if code blocks are in ready status
        """
        return self.status == "ready"

    def is_draft(self) -> bool:
        """
        Check if the code blocks are in draft status.

        Returns:
            True if code blocks are in draft status
        """
        return self.status == "draft"

    def is_deleted(self) -> bool:
        """
        Check if the code blocks are deleted.

        Returns:
            True if code blocks are deleted
        """
        return self.status == "deleted"
