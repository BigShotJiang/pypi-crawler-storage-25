"""
TestSuite model class for TestZeus test suite entities.
"""

from typing import Any, Dict, List, Optional

from testzeus_sdk.models.base import BaseModel


class TestSuite(BaseModel):
    """
    Model class for TestZeus test suite entities.
    """

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)

        self.name = data.get("name")
        self.display_name = data.get("display_name")
        self.description = data.get("description")
        self.status = data.get("status")
        self.tenant = data.get("tenant")
        self.created_by = data.get("created_by")
        self.modified_by = data.get("modified_by")
        self.workflow_definition = data.get("workflow_definition")
        self.input_schema = data.get("input_schema")
        self.default_inputs = data.get("default_inputs")
        self.environment = data.get("environment")
        self.execution_mode = data.get("execution_mode")
        self.tags: Optional[List[str]] = data.get("tags")
        self.notification_channels: Optional[List[str]] = data.get("notification_channels")
        self.timeout_seconds = data.get("timeout_seconds")
        self.metadata = data.get("metadata")
        self.tests: Optional[List[str]] = data.get("tests")
        self.nested_suites: Optional[List[str]] = data.get("nested_suites")
        self.is_deleted = data.get("is_deleted")
        self.expand = data.get("expand")
