"""
TestSuiteSchedule model class for TestZeus test suite schedule entities.
"""

from typing import Any, Dict, List, Optional

from testzeus_sdk.models.base import BaseModel


class TestSuiteSchedule(BaseModel):
    """
    Model class for TestZeus test suite schedule entities.
    """

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)

        self.name = data.get("name")
        self.display_name = data.get("display_name")
        self.test_suite = data.get("test_suite")
        self.cron_expression = data.get("cron_expression")
        self.is_active = data.get("is_active")
        self.environment = data.get("environment")
        self.input_values = data.get("input_values")
        self.notification_channels: Optional[List[str]] = data.get("notification_channels")
        self.metadata = data.get("metadata")
        self.last_run_at = self._parse_date(data.get("last_run_at"))
        self.next_run_at = self._parse_date(data.get("next_run_at"))
        self.expand = data.get("expand")
