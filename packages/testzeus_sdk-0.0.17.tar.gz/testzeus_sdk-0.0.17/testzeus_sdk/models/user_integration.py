"""
UserIntegration model class for TestZeus user_integration entities.
"""

from typing import Any, Dict

from testzeus_sdk.models.base import BaseModel


class UserIntegration(BaseModel):
    """
    Model class for TestZeus user_integration entities.

    This class represents user integrations in TestZeus, which can be
    used to manage external service integrations for users.
    """

    def __init__(self, data: Dict[str, Any]):
        """
        Initialize a UserIntegration model with data from the API.

        Args:
            data: Dictionary containing user_integration data
        """
        # Call parent init
        super().__init__(data)

        # Extract only specified fields
        self.name: str = data.get("name")
        self.tenant_id: str = data.get("tenant_id")
        self.integration_type: str = data.get("integration_type")
        self.connection_status: str = data.get("connection_status")

        # Override data to contain only filtered fields
        self.data = {
            "id": self.id,
            "name": self.name,
            "tenant_id": self.tenant_id,
            "integration_type": self.integration_type,
            "connection_status": self.connection_status,
            "created": self.created,
            "updated": self.updated,
        }

    def is_active(self) -> bool:
        """
        Check if the integration is active.

        Returns:
            True if integration connection status is ACTIVE
        """
        return self.connection_status == "ACTIVE"

    def is_inactive(self) -> bool:
        """
        Check if the integration is inactive.

        Returns:
            True if integration connection status is INACTIVE
        """
        return self.connection_status == "INACTIVE"

    def is_pending(self) -> bool:
        """
        Check if the integration is pending.

        Returns:
            True if integration connection status is PENDING
        """
        return self.connection_status == "PENDING"

    def is_failed(self) -> bool:
        """
        Check if the integration has failed.

        Returns:
            True if integration connection status is FAILED
        """
        return self.connection_status == "FAILED"

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert model to dictionary representation with only specified fields.

        Returns:
            Dictionary containing only allowed fields
        """
        return {
            "id": self.id,
            "name": self.name,
            "tenant_id": self.tenant_id,
            "integration_type": self.integration_type,
            "connection_status": self.connection_status,
            "created": self.created,
            "updated": self.updated,
        }
