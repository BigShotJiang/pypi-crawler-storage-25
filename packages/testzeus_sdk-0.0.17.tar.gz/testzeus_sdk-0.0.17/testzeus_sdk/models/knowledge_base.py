"""
Model for knowledge_base collection.
"""

from typing import Any, Dict, List, Optional

from .base import BaseModel


class KnowledgeBase(BaseModel):
    """
    KnowledgeBase model for knowledge_base collection.
    """

    def __init__(self, data: Dict[str, Any]):
        """
        Initialize a KnowledgeBase instance.

        Args:
            data: Dictionary containing model data
        """
        super().__init__(data)
        self.name = data.get("name")
        self.tenant = data.get("tenant")
        self.modified_by = data.get("modified_by")
        self.source = data.get("source")
        self.description = data.get("description")
        self.status = data.get("status")
