"""
TestSuiteNodeRun model class for TestZeus test suite node run entities.
"""

from typing import Any, Dict

from testzeus_sdk.models.base import BaseModel


class TestSuiteNodeRun(BaseModel):
    """
    Model class for TestZeus test suite node run entities.
    """

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)

        self.test_suite_run = data.get("test_suite_run")
        self.node_id = data.get("node_id")
        self.status = data.get("status")
        self.test_run = data.get("test_run")
        self.nested_suite_id = data.get("nested_suite_id")
        self.nested_suite_run = data.get("nested_suite_run")
        self.resolved_inputs = data.get("resolved_inputs")
        self.outputs = data.get("outputs")
        self.retry_count = data.get("retry_count")
        self.max_retries = data.get("max_retries")
        self.metadata = data.get("metadata")
        self.started_at = self._parse_date(data.get("started_at"))
        self.completed_at = self._parse_date(data.get("completed_at"))
        self.expand = data.get("expand")
