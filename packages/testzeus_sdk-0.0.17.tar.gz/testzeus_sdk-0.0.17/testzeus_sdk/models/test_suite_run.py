"""
TestSuiteRun model class for TestZeus test suite run entities.
"""

from typing import Any, Dict, List, Optional

from testzeus_sdk.models.base import BaseModel


class TestSuiteRun(BaseModel):
    """
    Model class for TestZeus test suite run entities.
    """

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)

        self.name = data.get("name")
        self.display_name = data.get("display_name")
        self.status = data.get("status")
        self.tenant = data.get("tenant")
        self.created_by = data.get("created_by")
        self.modified_by = data.get("modified_by")
        self.test_suite = data.get("test_suite")
        self.workflow_snapshot = data.get("workflow_snapshot")
        self.input_values = data.get("input_values")
        self.context_store = data.get("context_store")
        self.outputs = data.get("outputs")
        self.environment = data.get("environment")
        self.execution_mode = data.get("execution_mode")
        self.notification_channels: Optional[List[str]] = data.get("notification_channels")
        self.metadata = data.get("metadata")
        self.orchestrator_run_id = data.get("orchestrator_run_id")
        self.test_report_run = data.get("test_report_run")
        self.execution_checkpoint = data.get("execution_checkpoint")
        self.resumed_from = data.get("resumed_from")
        self.paused_at = self._parse_date(data.get("paused_at"))
        self.start_time = self._parse_date(data.get("start_time"))
        self.end_time = self._parse_date(data.get("end_time"))
        self.is_deleted = data.get("is_deleted")
        self.expand = data.get("expand")
