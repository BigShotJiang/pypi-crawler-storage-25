"""
ConnectedEnvironment model class for TestZeus connected environment entities.
"""

from typing import Any, Dict, List, Optional

from testzeus_sdk.models.base import BaseModel


class ConnectedEnvironment(BaseModel):
    """
    Model class for TestZeus connected environment entities.

    This class represents connected environment entities in TestZeus, which can be
    used to define connections between environments and external systems/connections.
    """

    def __init__(self, data: Dict[str, Any]):
        """
        Initialize a ConnectedEnvironment model with data from the API.

        Args:
            data: Dictionary containing connected environment data
        """
        super().__init__(data)

        # Extract common fields
        self.name: str = data.get("name")
        self.tenant: str = data.get("tenant")
        self.modified_by: str = data.get("modified_by")
        self.connection: Optional[str] = data.get("connection")
        self.metadata: Optional[Dict[str, Any]] = data.get("metadata")
        self.metadata_files: Optional[List[str]] = data.get("metadata_files")
        self.code_files: Optional[List[str]] = data.get("code_files")
        self.tags: Optional[List[str]] = data.get("tags")
        self.skip_process: Optional[bool] = data.get("skip_process")
        self.cached_prompt_details: Optional[str] = data.get("cached_prompt_details")
        self.extra_data: Optional[Dict[str, Any]] = data.get("extra_data")
        self.process_data: Optional[Dict[str, Any]] = data.get("process_data")

    def has_connection(self) -> bool:
        """
        Check if the connected environment has a connection assigned.

        Returns:
            True if connection is assigned
        """
        return self.connection is not None and self.connection != ""

    def has_metadata_files(self) -> bool:
        """
        Check if the connected environment has metadata files.

        Returns:
            True if metadata files exist
        """
        return bool(self.metadata_files)

    def has_code_files(self) -> bool:
        """
        Check if the connected environment has code files.

        Returns:
            True if code files exist
        """
        return bool(self.code_files)

    def is_processing_skipped(self) -> bool:
        """
        Check if processing is skipped for this connected environment.

        Returns:
            True if skip_process is enabled
        """
        return bool(self.skip_process)
