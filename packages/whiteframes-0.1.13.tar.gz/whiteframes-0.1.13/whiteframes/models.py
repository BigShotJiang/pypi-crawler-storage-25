"""Whiteframes SDK data models."""

import time
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, TYPE_CHECKING

from ._internal import (
    F_VISUAL_KEY, F_VISUAL_ALT, F_AUDIO_KEY, F_EDITS, EXT,
    F_VOICE_PROVIDER, F_PROVIDER_PREM, VOICE_TIER_STANDARD, VOICE_TIER_PREMIUM,
)
from .exceptions import WhiteframesError

if TYPE_CHECKING:
    from .client import WhiteframesAI


@dataclass
class Frame:
    id: int
    narration: str
    duration: float
    visual_description: str = ""
    has_visual: bool = False
    has_audio: bool = False
    keywords: List[str] = field(default_factory=list)
    speaker_id: Optional[str] = None
    status: str = "ready"
    animation_speed: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "Frame":
        return cls(
            id=d.get("id", 0),
            narration=d.get("narration", ""),
            duration=d.get("duration", 8.0),
            visual_description=d.get("visualDescription", ""),
            has_visual=bool(d.get(F_VISUAL_KEY) or d.get(F_VISUAL_ALT)),
            has_audio=bool(d.get(F_AUDIO_KEY)),
            keywords=d.get("keywords", []),
            speaker_id=d.get("speakerId"),
            status=d.get("status", "ready"),
            animation_speed=d.get("animationSpeed"),
        )


@dataclass
class Video:
    id: str
    title: str
    status: str
    video_type: str
    voice_id: str
    voice_tier: str
    language: str
    frame_count: int
    created_at: str
    animation_speed: str = "normal"
    frames: List[Frame] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict) -> "Video":
        project_id = d.get("id") or d.get("projectId", "")
        frames = [Frame.from_dict(s) for s in d.get("scenes", [])]
        voice_tier = VOICE_TIER_PREMIUM if d.get(F_VOICE_PROVIDER) == F_PROVIDER_PREM else VOICE_TIER_STANDARD
        v = cls(
            id=project_id,
            title=d.get("title", "Untitled"),
            status=d.get("status", "ready"),
            video_type=d.get("videoType", "whiteboard"),
            voice_id=d.get("voiceId", "Stephen"),
            voice_tier=voice_tier,
            language=d.get("language", "en-US"),
            frame_count=d.get("sceneCount", len(frames)),
            created_at=d.get("createdAt", ""),
            animation_speed=d.get("animationSpeed", "normal"),
            frames=frames,
        )
        # Store raw project data under a name-mangled key so it is not
        # casually accessible from outside this module.
        v.__dict__["_Video__raw"] = d
        return v

    @property
    def social_media(self) -> Dict[str, Any]:
        """AI-generated social media metadata for this video."""
        return self.__raw.get("socialMedia", {})

    def __repr__(self):
        return f"<Video id={self.id!r} title={self.title!r} language={self.language!r} speed={self.animation_speed!r} frames={len(self.frames)}>"


class VideoJob:
    """Represents an in-progress video generation job."""

    def __init__(self, job_id: str, project_id: str, client: "WhiteframesAI"):
        self.job_id = job_id
        self.project_id = project_id
        self._client = client
        self.status = "pending"
        self.progress = 0
        self.message = ""
        self._result = None

    def refresh(self) -> "VideoJob":
        """Poll the job status once."""
        data = self._client._get(f"{EXT}/jobs/{self.job_id}")
        self.status = data.get("status", "pending")
        self.progress = data.get("progress", 0)
        self.message = data.get("message", "")
        if self.status == "ready" and data.get("result"):
            import json
            raw = data["result"]
            self._result = json.loads(raw) if isinstance(raw, str) else raw
        return self

    def wait(self, poll_interval: float = 3.0, timeout: float = 600.0,
             on_progress=None) -> Video:
        """
        Block until the video is ready. Polls every ``poll_interval`` seconds.

        Args:
            poll_interval: Seconds between status checks (default 3).
            timeout: Max seconds to wait before raising TimeoutError (default 600).
            on_progress: Optional callback(progress, message) called on each poll.

        Returns:
            Video object when ready.

        Raises:
            TimeoutError: If video is not ready within timeout.
            WhiteframesError: If generation fails.
        """
        start = time.time()
        backoff = poll_interval
        while True:
            try:
                self.refresh()
                backoff = poll_interval  # reset on success
            except WhiteframesError as e:
                if e.status_code == 429:
                    backoff = min(backoff * 2, 30)  # exponential backoff, max 30s
                    time.sleep(backoff)
                    continue
                raise
            if on_progress:
                on_progress(self.progress, self.message)
            if self.status == "ready":
                return self._client.get_video(self.project_id)
            if self.status == "error":
                raise WhiteframesError(f"Video generation failed: {self.message}")
            if time.time() - start > timeout:
                raise TimeoutError(f"Video not ready after {timeout}s")
            time.sleep(backoff)

    def __repr__(self):
        return f"<VideoJob job_id={self.job_id!r} status={self.status!r} progress={self.progress}%>"


@dataclass
class MonthlyStats:
    """Stats for a single month."""
    month: str
    videos_created: int = 0
    frames_generated: int = 0
    downloads_count: int = 0
    favorited_videos: int = 0
    videos_by_quality: Dict[str, int] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, month: str, d: dict) -> "MonthlyStats":
        return cls(
            month=month,
            videos_created=d.get("videosCreated", 0),
            frames_generated=d.get("scenesGenerated", 0),
            downloads_count=d.get("downloadsCount", 0),
            favorited_videos=d.get("favoritedVideos", 0),
            videos_by_quality=d.get("videosByQuality", {}),
        )


@dataclass
class UsageStats:
    """Account usage statistics (overall + monthly)."""
    total_videos: int = 0
    trashed_videos: int = 0
    favorited_videos: int = 0
    frames_generated: int = 0
    downloads_count: int = 0
    reels_created: int = 0
    frame_regenerations: int = 0
    frames_fixed: int = 0
    videos_by_quality: Dict[str, int] = field(default_factory=dict)
    credits: Optional[int] = None
    credits_used: Optional[int] = None
    credits_via_ui: Optional[int] = None
    credits_via_api: Optional[int] = None
    last_video_at: Optional[str] = None
    monthly: List[MonthlyStats] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict) -> "UsageStats":
        monthly_raw = d.get("monthly", {})
        monthly = [MonthlyStats.from_dict(k, v) for k, v in monthly_raw.items()]
        return cls(
            total_videos=d.get("totalVideos", 0),
            trashed_videos=d.get("trashedVideos", 0),
            favorited_videos=d.get("favoritedVideos", 0),
            frames_generated=d.get("scenesGenerated", 0),
            downloads_count=d.get("downloadsCount", 0),
            reels_created=d.get("reelsCreated", 0),
            frame_regenerations=d.get(F_EDITS, {}).get("sceneRegenerations", 0),
            frames_fixed=d.get(F_EDITS, {}).get("scenesFixed", 0),
            videos_by_quality=d.get("videosByQuality", {}),
            credits=d.get("credits"),
            credits_used=d.get("creditsUsed"),
            credits_via_ui=d.get("creditsViaUI"),
            credits_via_api=d.get("creditsViaAPI"),
            last_video_at=d.get("lastVideoAt"),
            monthly=monthly,
        )

    def __repr__(self):
        return f"<UsageStats videos={self.total_videos} frames={self.frames_generated} downloads={self.downloads_count} months={len(self.monthly)}>"
