"""MCP 搜索服务数据模型

定义 Envelope 响应格式、错误码、搜索结果数据结构。
"""
from __future__ import annotations

import uuid
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ============================================================
# 错误码
# ============================================================

class ErrorCode(str, Enum):
    LOGIN_REQUIRED = "login_required"
    LOGIN_TIMEOUT = "login_timeout"
    SEARCH_TIMEOUT = "search_timeout"
    SEARCH_BLOCKED = "search_blocked"
    RISK_COOLDOWN_ACTIVE = "risk_cooldown_active"
    BROWSER_INIT_FAILED = "browser_init_failed"
    BROWSER_CRASHED = "browser_crashed"
    UNKNOWN_ERROR = "unknown_error"
    CAPTCHA_DETECTED = "captcha_detected"


# ErrorCode → retryable 默认映射 (R8)
_RETRYABLE_MAP: Dict[ErrorCode, bool] = {
    ErrorCode.LOGIN_REQUIRED: False,
    ErrorCode.LOGIN_TIMEOUT: True,
    ErrorCode.SEARCH_TIMEOUT: True,
    ErrorCode.SEARCH_BLOCKED: False,
    ErrorCode.RISK_COOLDOWN_ACTIVE: False,
    ErrorCode.BROWSER_INIT_FAILED: False,
    ErrorCode.BROWSER_CRASHED: False,
    ErrorCode.UNKNOWN_ERROR: False,
    ErrorCode.CAPTCHA_DETECTED: False,
}


# ============================================================
# Envelope 响应格式
# ============================================================

class EnvelopeBuilder:
    """统一的 JSON Envelope 构建器"""

    @staticmethod
    def success(platform: str, tool: str, data: Any) -> str:
        import json
        return json.dumps({
            "ok": True,
            "platform": platform,
            "tool": tool,
            "request_id": str(uuid.uuid4()),
            "data": data,
            "error": None,
        }, ensure_ascii=False)

    @staticmethod
    def error(platform: str, tool: str, code: ErrorCode, message: str,
              retryable: Optional[bool] = None) -> str:
        import json
        if retryable is None:
            retryable = _RETRYABLE_MAP.get(code, False)
        return json.dumps({
            "ok": False,
            "platform": platform,
            "tool": tool,
            "request_id": str(uuid.uuid4()),
            "data": None,
            "error": {
                "code": code.value,
                "message": message,
                "retryable": retryable,
            },
        }, ensure_ascii=False)


# ============================================================
# 搜索结果数据模型
# ============================================================

class SearchResultItem(BaseModel):
    """单条搜索结果"""
    id: str = ""
    title: str = ""
    url: str = ""
    snippet: str = ""
    cover_url: str = ""
    author: str = ""
    likes: int = 0
    xsec_token: str = ""
    note_type: str = ""  # "normal" | "video"
    publish_time: str = ""


class SearchData(BaseModel):
    """搜索结果集合"""
    results: List[SearchResultItem] = Field(default_factory=list)
    total_requested: int = 0
    total_returned: int = 0


class LoginData(BaseModel):
    """登录结果"""
    message: str = ""


class CommentItem(BaseModel):
    """单条评论"""
    text: str = ""
    author: str = ""
    likes: int = 0


class NoteDetail(BaseModel):
    """笔记详情"""
    id: str = ""
    title: str = ""
    url: str = ""
    author: str = ""
    content: str = ""           # 正文全文
    likes: int = 0
    collected: int = 0          # 收藏数
    comments_count: int = 0
    shares: int = 0
    image_urls: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    top_comments: List[CommentItem] = Field(default_factory=list)
    note_type: str = ""         # normal | video
    publish_time: str = ""
