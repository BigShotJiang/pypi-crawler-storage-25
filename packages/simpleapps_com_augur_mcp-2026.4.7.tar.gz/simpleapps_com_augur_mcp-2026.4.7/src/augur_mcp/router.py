"""Router for mapping MCP tool calls to Python SDK methods.

Uses shared/specs/*.json with pre-computed chain and action fields.
The spec IS the mapping — no heuristics, no singularize().
"""

from __future__ import annotations

import json
import re
from importlib.resources import files
from pathlib import Path
from typing import Any

from augur_api import AugurAPI


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def _kebab_to_snake(name: str) -> str:
    """Convert kebab-case to snake_case."""
    return name.replace("-", "_")


# =============================================================================
# Spec Loading
# =============================================================================


def load_specs(specs_dir: Path | None = None) -> dict[str, dict[str, Any]]:
    """Load merged spec files into a service catalog.

    Args:
        specs_dir: Directory containing {service}.json spec files.
            Defaults to bundled package data (endpoints/ for compat)
            or shared/specs/ if available.

    Returns:
        Dict mapping service names to their full spec (with endpoints).
    """
    if specs_dir is None:
        # Try shared/specs first (development), fall back to bundled
        dev_path = Path(__file__).parent.parent.parent.parent.parent / "shared" / "specs"
        if dev_path.is_dir():
            specs_dir = dev_path
        else:
            specs_dir = Path(str(files("augur_mcp") / "specs"))

    catalog: dict[str, dict[str, Any]] = {}
    if not specs_dir.is_dir():
        return catalog

    for spec_file in sorted(specs_dir.glob("*.json")):
        service_name = spec_file.stem
        with open(spec_file) as f:
            catalog[service_name] = json.load(f)

    return catalog


def load_descriptions(specs_dir: Path | None = None) -> dict[str, str]:
    """Load service descriptions from specs or descriptions.json.

    Args:
        specs_dir: Directory containing spec files or descriptions.json.

    Returns:
        Dict mapping service names to description strings.
    """
    # Try bundled descriptions.json first
    if specs_dir is None:
        endpoints_dir = Path(str(files("augur_mcp") / "endpoints"))
    else:
        endpoints_dir = specs_dir

    desc_file = endpoints_dir / "descriptions.json"
    if not desc_file.is_file():
        # Try parent's endpoints dir
        alt = endpoints_dir.parent / "endpoints" / "descriptions.json"
        if alt.is_file():
            desc_file = alt
        else:
            return {}

    with open(desc_file) as f:
        data = json.load(f)

    if not isinstance(data, dict):
        return {}

    return {k: v for k, v in data.items() if isinstance(v, str)}


# =============================================================================
# Spec-Based Resolution
# =============================================================================


def _build_endpoint_index(
    spec: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    """Build an index from (chain.action) to endpoint spec.

    Returns: {"invMast.list": endpoint, "invMast.doc.list": endpoint, ...}
    """
    index: dict[str, dict[str, Any]] = {}
    for ep in spec.get("endpoints", []):
        key = f"{ep['chain']}.{ep['action']}"
        index[key] = ep
        # Also index aliases
        for alias in ep.get("aliases", []):
            alias_key = f"{ep['chain']}.{alias}"
            index[alias_key] = ep
    return index


def _parse_id(record_id: str) -> int | str:
    """Parse a record ID, converting to int if numeric."""
    try:
        return int(record_id)
    except ValueError:
        return record_id


def resolve_and_call(
    api: AugurAPI,
    service: str,
    resource: str,
    action: str,
    record_id: str | None = None,
    data: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
    spec: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve an SDK method and call it using the spec.

    The resource path (e.g., "inv-mast/123/doc") is parsed into:
    - root resource name (snake_case SDK property)
    - parent IDs (numeric segments)
    - child method suffix (nested resource)

    The spec's chain + action fields determine the exact method name.

    Args:
        api: Initialized AugurAPI client.
        service: Service name (kebab-case).
        resource: Resource path (e.g., "settings", "training/1/conversations").
        action: One of "list", "get", "create", "update", "delete".
        record_id: Target record ID (for get/update/delete).
        data: Request body (for create/update).
        params: Query parameters (for list).
        spec: Pre-loaded spec for this service (optional optimization).

    Returns:
        Response as a dictionary.
    """
    # Resolve service SDK property
    sdk_service_name = _kebab_to_snake(service)
    svc = getattr(api, sdk_service_name, None)
    if svc is None:
        available = [k for k in dir(api) if not k.startswith("_")]
        msg = f"Unknown service: {service}. Available: {', '.join(available)}"
        raise ValueError(msg)

    # Parse resource path into segments
    parts = resource.split("/")
    resource_segments: list[str] = []
    parent_ids: list[int | str] = []

    for part in parts:
        try:
            parent_ids.append(int(part))
        except ValueError:
            resource_segments.append(part)

    # Build the chain from resource segments (kebab → camelCase)
    chain_parts = []
    for seg in resource_segments:
        # Convert kebab-case to camelCase
        sub_parts = seg.split("-")
        camel = sub_parts[0] + "".join(p.capitalize() for p in sub_parts[1:])
        chain_parts.append(camel)

    chain = ".".join(chain_parts)

    # Look up the method name from the spec
    # The spec tells us exactly what the SDK method is called
    method_name = _resolve_method_name(chain, action, spec)

    # Resolve the SDK resource object (first chain segment → snake_case property)
    root_snake = _camel_to_snake(chain_parts[0]) if chain_parts else ""
    resource_obj = getattr(svc, root_snake, None)
    if resource_obj is None:
        msg = f"Unknown resource '{root_snake}' on service '{service}'"
        raise ValueError(msg)

    # Resolve the method
    method = getattr(resource_obj, method_name, None)
    if method is None:
        msg = f"No method '{method_name}' on resource '{root_snake}' (service: {service})"
        raise ValueError(msg)

    # Build args
    args: list[Any] = list(parent_ids)

    if action == "list":
        if params:
            args.append(params)
    elif action == "get":
        if record_id is not None:
            args.append(_parse_id(record_id))
    elif action == "create":
        if data is not None:
            args.append(data)
    elif action == "update":
        if record_id is not None:
            args.append(_parse_id(record_id))
        if data is not None:
            args.append(data)
    elif action == "delete":
        if record_id is not None:
            args.append(_parse_id(record_id))

    response = method(*args)

    # Convert BaseResponse to dict
    if hasattr(response, "model_dump"):
        return response.model_dump()  # type: ignore[no-any-return]
    return dict(response)  # type: ignore[call-overload]


def _resolve_method_name(
    chain: str, action: str, spec: dict[str, Any] | None
) -> str:
    """Resolve the Python SDK method name from the spec.

    The spec's chain + action map directly to the method name:
    - chain="invMast", action="list" → "list"
    - chain="invMast.doc", action="list" → "list_doc"
    - chain="invMast.attributes.values", action="list" → "list_attributes_values"

    Falls back to heuristic if no spec provided.
    """
    parts = chain.split(".")

    if len(parts) <= 1:
        # Top-level resource — method is just the action
        return action

    # Nested — method name is action + snake_case suffix
    suffix_parts = parts[1:]
    suffix = "_".join(_camel_to_snake(p) for p in suffix_parts)
    return f"{action}_{suffix}"


# =============================================================================
# Discovery
# =============================================================================


def get_resource_map_from_spec(
    spec: dict[str, Any],
) -> dict[str, list[str]]:
    """Build a resource-to-methods map from a merged spec.

    Args:
        spec: Merged spec with endpoints list.

    Returns:
        Dict mapping resource paths to available actions.
    """
    resource_map: dict[str, list[str]] = {}

    for ep in spec.get("endpoints", []):
        chain = ep["chain"]
        action = ep["action"]

        # Convert chain to display path: invMast.doc → inv-mast/doc
        display = "/".join(
            re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", p).lower()
            for p in chain.split(".")
        )

        if display not in resource_map:
            resource_map[display] = []
        if action not in resource_map[display]:
            resource_map[display].append(action)

    return resource_map


# Legacy compat aliases
def load_catalog(endpoints_dir: Path | None = None) -> dict[str, list[dict[str, Any]]]:
    """Legacy: load endpoints.jsonl catalog. Prefer load_specs()."""
    specs = load_specs(endpoints_dir)
    # Convert specs to catalog format (list of endpoints per service)
    return {
        name: spec.get("endpoints", [])
        for name, spec in specs.items()
    }


def get_resource_map(endpoints: list[dict[str, Any]]) -> dict[str, list[str]]:
    """Legacy: build resource map from endpoint list. Prefer get_resource_map_from_spec()."""
    resource_map: dict[str, list[str]] = {}
    for ep in endpoints:
        path: str = ep.get("path", "")
        method: str = ep.get("method", "")
        clean = path.removeprefix("/api/").lstrip("/")
        parts = clean.split("/")
        resource_parts = [p for p in parts if not p.startswith("{")]
        resource_key = "/".join(resource_parts)
        if resource_key not in resource_map:
            resource_map[resource_key] = []
        if method not in resource_map[resource_key]:
            resource_map[resource_key].append(method)
    return resource_map
