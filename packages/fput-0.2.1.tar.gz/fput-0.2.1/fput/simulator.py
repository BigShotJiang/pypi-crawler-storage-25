"""
FPUT Simulator - Core simulation engine for the Fermi-Pasta-Ulam-Tsingou problem.

The system has N moving particles (Q_1 to Q_N) with fixed endpoints:
Q_0 = 0 and Q_{N+1} = 0.
"""

import numpy as np
from typing import Optional, Tuple, List, Union
from dataclasses import dataclass


@dataclass
class SimulationResult:
    """Container for simulation results."""
    time_points: np.ndarray
    mode_energies: np.ndarray  # Shape: (n_time_points, n_modes)
    coordinates: Optional[np.ndarray] = None  # Shape: (n_time_points, n_particles)
    momenta: Optional[np.ndarray] = None


class FPUTSimulator:
    """
    FPUT system with quadratic (alpha) nonlinearity.

    The system consists of N moving particles with fixed endpoints.
    Hamiltonian: H = sum(1/2*P_k^2) + 1/2*sum((Q_{k+1}-Q_k)^2) + alpha/3*sum((Q_{k+1}-Q_k)^3)

    Fixed boundary conditions: Q_0 = Q_{N+1} = 0

    Parameters
    ----------
    N : int
        Number of MOVING particles (not counting fixed endpoints).
        Total array size is N+2 to include endpoints.
    alpha : float, optional
        Quadratic nonlinear coupling parameter. Default is 0.25.
    dt : float, optional
        Time step for integration. Default is 0.05.
    """

    def __init__(self, N: int, alpha: float = 0.25, dt: float = 0.05):
        """
        Initialize FPUT simulator.

        Parameters
        ----------
        N : int
            Number of moving particles.
        alpha : float
            Nonlinear coupling parameter.
        dt : float
            Time step.
        """
        self.N = N
        self.N_moving = N
        self.alpha = alpha
        self.dt = dt
        # Q and P have N+2 elements: Q[0] and Q[N+1] are fixed endpoints
        self.Q = np.zeros(N + 2)
        self.P = np.zeros(N + 2)
        self.omega = self._compute_frequencies()

    def _compute_frequencies(self) -> np.ndarray:
        """Compute the normal mode frequencies."""
        k = np.arange(1, self.N + 1)  # k = 1, 2, ..., N
        return 2 * np.sin(k * np.pi / (2 * (self.N + 1)))

    def set_initial_mode(self, mode: int = 1, amplitude: float = 4.0):
        """
        Set initial conditions exciting only a single normal mode.

        The displacement pattern for mode m is:
        Q_k = A * sin(k * m * pi / (N+1)), k = 1, 2, ..., N

        Parameters
        ----------
        mode : int
            Mode number to excite (1 to N).
        amplitude : float
            Amplitude of the mode.
        """
        k = np.arange(1, self.N + 1)  # Particle indices: 1, 2, ..., N
        # Initialize moving particles with sine wave pattern
        self.Q[1:self.N + 1] = amplitude * np.sin(k * mode * np.pi / (self.N + 1))
        self.P[:] = 0  # Start from rest

    def set_initial_sine_wave(self, amplitude: float = 1.0):
        """
        Set initial conditions as a sine wave (fundamental mode).

        This is the classic FPUT initial condition: Q_k = A * sin(k*pi/(N+1)).

        Parameters
        ----------
        amplitude : float
            Amplitude of the sine wave.
        """
        self.set_initial_mode(mode=1, amplitude=amplitude)

    def equations_of_motion(self, Q: np.ndarray, P: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute the equations of motion for the FPUT-alpha system.

        dQ/dt = P
        dP/dt = acceleration from springs

        Parameters
        ----------
        Q : ndarray
            Coordinates (including endpoints).
        P : ndarray
            Momenta (including endpoints).

        Returns
        -------
        dQdt : ndarray
            Time derivative of coordinates.
        dPdt : ndarray
            Time derivative of momenta (accelerations).
        """
        dQdt = P.copy()

        # Compute accelerations
        dPdt = np.zeros_like(Q)
        # Linear part: Q[k+1] + Q[k-1] - 2*Q[k]
        dPdt[1:self.N + 1] = Q[2:self.N + 2] + Q[0:self.N] - 2 * Q[1:self.N + 1]

        # Nonlinear part (alpha term)
        if self.alpha != 0:
            delta_plus = (Q[2:self.N + 2] - Q[1:self.N + 1])**2
            delta_minus = (Q[1:self.N + 1] - Q[0:self.N])**2
            dPdt[1:self.N + 1] += self.alpha * (delta_plus - delta_minus)

        return dQdt, dPdt

    def step_rk4(self) -> None:
        """Perform a single Runge-Kutta 4th order integration step."""
        Q = self.Q
        P = self.P
        dt = self.dt

        k1_Q, k1_P = self.equations_of_motion(Q, P)

        k2_Q, k2_P = self.equations_of_motion(
            Q + 0.5 * dt * k1_Q,
            P + 0.5 * dt * k1_P
        )

        k3_Q, k3_P = self.equations_of_motion(
            Q + 0.5 * dt * k2_Q,
            P + 0.5 * dt * k2_P
        )

        k4_Q, k4_P = self.equations_of_motion(
            Q + dt * k3_Q,
            P + dt * k3_P
        )

        self.Q += (dt / 6) * (k1_Q + 2 * k2_Q + 2 * k3_Q + k4_Q)
        self.P += (dt / 6) * (k1_P + 2 * k2_P + 2 * k3_P + k4_P)

    def step_velocity_verlet(self) -> None:
        """Perform a single Velocity Verlet integration step (symplectic)."""
        # Half step for velocity
        _, dPdt = self.equations_of_motion(self.Q, self.P)
        acc = np.zeros_like(self.P)
        acc[1:self.N + 1] = dPdt[1:self.N + 1]

        self.P[1:self.N + 1] += 0.5 * self.dt * acc[1:self.N + 1]

        # Full step for position
        self.Q[1:self.N + 1] += self.dt * self.P[1:self.N + 1]

        # Recompute accelerations
        _, dPdt_new = self.equations_of_motion(self.Q, self.P)
        acc_new = np.zeros_like(self.P)
        acc_new[1:self.N + 1] = dPdt_new[1:self.N + 1]

        # Half step for velocity
        self.P[1:self.N + 1] += 0.5 * self.dt * acc_new[1:self.N + 1]

    def compute_mode_energies(self) -> np.ndarray:
        """
        Compute the energy in each normal mode.

        Returns
        -------
        energies : ndarray
            Energy in each normal mode, shape (N,)
        """
        from fput.normal_modes import compute_normal_mode_energies
        return compute_normal_mode_energies(
            self.Q[1:self.N + 1],
            self.P[1:self.N + 1],
            self.N + 1  # Pass N+1 for proper boundary handling
        )

    def run(
        self,
        total_time: float,
        save_interval: int = 10,
        integrator: str = "rk4"
    ) -> SimulationResult:
        """
        Run the simulation for a specified total time.

        Parameters
        ----------
        total_time : float
            Total simulation time.
        save_interval : int
            Save data every n steps.
        integrator : str
            Integration method: "rk4" or "verlet".

        Returns
        -------
        result : SimulationResult
            Container with time points and mode energies.
        """
        n_steps = int(total_time / self.dt)
        n_saves = n_steps // save_interval + 1

        time_points = np.zeros(n_saves)
        mode_energies = np.zeros((n_saves, self.N))

        # Initial state
        mode_energies[0] = self.compute_mode_energies()

        step_func = self.step_rk4 if integrator == "rk4" else self.step_velocity_verlet

        save_idx = 1
        for step in range(1, n_steps + 1):
            step_func()

            if step % save_interval == 0:
                time_points[save_idx] = step * self.dt
                mode_energies[save_idx] = self.compute_mode_energies()
                save_idx += 1
                if save_idx >= n_saves:
                    break

        return SimulationResult(
            time_points=time_points[:save_idx],
            mode_energies=mode_energies[:save_idx]
        )

    def get_total_energy(self) -> float:
        """Compute the total Hamiltonian of the system."""
        # Kinetic energy
        KE = 0.5 * np.sum(self.P[1:self.N + 1]**2)

        # Potential energy - linear
        delta_Q = self.Q[1:self.N + 2] - self.Q[0:self.N + 1]
        PE_linear = 0.5 * np.sum(delta_Q**2)

        # Potential energy - nonlinear (alpha term)
        PE_nonlinear = (self.alpha / 3) * np.sum(delta_Q**3)

        return KE + PE_linear + PE_nonlinear


class FPUTBetaSimulator(FPUTSimulator):
    """
    FPUT system with quartic (beta) nonlinearity.

    Hamiltonian: H = sum(1/2*P_k^2) + 1/2*sum((Q_{k+1}-Q_k)^2) + beta/4*sum((Q_{k+1}-Q_k)^4)

    Parameters
    ----------
    N : int
        Number of moving particles.
    beta : float, optional
        Quartic nonlinear coupling parameter. Default is 1.0.
    dt : float, optional
        Time step for integration. Default is 0.05.
    """

    def __init__(self, N: int, beta: float = 1.0, dt: float = 0.05):
        super().__init__(N, alpha=0, dt=dt)
        self.beta = beta

    def equations_of_motion(self, Q: np.ndarray, P: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Compute equations of motion for the FPUT-beta system."""
        dQdt = P.copy()

        dPdt = np.zeros_like(Q)
        dPdt[1:self.N + 1] = Q[2:self.N + 2] + Q[0:self.N] - 2 * Q[1:self.N + 1]

        # Nonlinear part (beta term)
        if self.beta != 0:
            delta_plus = (Q[2:self.N + 2] - Q[1:self.N + 1])**3
            delta_minus = (Q[1:self.N + 1] - Q[0:self.N])**3
            dPdt[1:self.N + 1] += self.beta * (delta_plus - delta_minus)

        return dQdt, dPdt

    def get_total_energy(self) -> float:
        """Compute the total Hamiltonian of the system."""
        KE = 0.5 * np.sum(self.P[1:self.N + 1]**2)

        delta_Q = self.Q[1:self.N + 2] - self.Q[0:self.N + 1]
        PE_linear = 0.5 * np.sum(delta_Q**2)
        PE_nonlinear = (self.beta / 4) * np.sum(delta_Q**4)

        return KE + PE_linear + PE_nonlinear
