"""
FPUT GUI - Interactive graphical interface for the FPUT simulator.

A user-friendly interface for exploring the Fermi-Pasta-Ulam-Tsingou problem.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib import font_manager
import threading
import queue
import platform

from fput.simulator import FPUTSimulator, FPUTBetaSimulator
from fput.normal_modes import fundamental_period


class FontManager:
    """Manages font settings for the GUI."""

    # English labels
    LABELS_EN = {
        'title': 'FPUT Simulator',
        'system_params': 'System Parameters',
        'nonlinearity_type': 'Nonlinearity Type:',
        'alpha': 'Alpha (Quadratic)',
        'beta': 'Beta (Quartic)',
        'n_particles': 'Number of Particles N:',
        'moving_particles': 'Moving particles:',
        'alpha_param': 'Alpha Parameter:',
        'beta_param': 'Beta Parameter:',
        'dt': 'Time Step dt:',
        'n_modes': 'Modes to Display:',
        'initial_cond': 'Initial Conditions',
        'init_mode': 'Initial Mode:',
        'mode': 'Mode',
        'amplitude': 'Amplitude A:',
        'quick_preset': 'Quick Presets:',
        'classic': 'Classic',
        'weak': 'Weak',
        'strong': 'Strong',
        'sim_control': 'Simulation Control',
        'sim_time': 'Simulation Time:',
        'periods': '(fundamental periods)',
        'run': 'Run Simulation',
        'pause': 'Pause',
        'resume': 'Resume',
        'reset': 'Reset',
        'progress': 'Progress:',
        'status_ready': 'Ready',
        'status_running': 'Running...',
        'status_paused': 'Paused',
        'status_done': 'Complete!',
        'sim_info': 'Simulation Info',
        'total_energy': 'Total Energy:',
        'mode1_energy': 'Mode 1 Energy:',
        'fput_recurrence': 'FPUT Recurrence:',
        'plot_main': 'Normal Mode Energy Evolution',
        'plot_mode1': 'Mode 1 Energy Detail',
        'plot_part': 'Participation Ratio',
        'plot_phase': 'Mode 1 Phase Space',
        'plot_water': 'Energy Distribution Heatmap',
        'xlabel_time': 'Time (fundamental periods)',
        'xlabel_mode': 'Mode Number',
        'ylabel_energy': 'Energy',
        'ylabel_mode': 'Coordinate A₁',
        'ylabel_momentum': 'Momentum Ā₁',
        'ylabel_modes': 'Effective Modes',
        'initial': 'Initial',
        'language': 'Language / 语言',
        'english': 'English',
        'chinese': '中文',
    }

    # Chinese labels
    LABELS_CN = {
        'title': 'FPUT 模拟器',
        'system_params': '系统参数',
        'nonlinearity_type': '非线性类型:',
        'alpha': 'α (二次)',
        'beta': 'β (四次)',
        'n_particles': '粒子数 N:',
        'moving_particles': '移动粒子:',
        'alpha_param': 'α 参数:',
        'beta_param': 'β 参数:',
        'dt': '时间步长 dt:',
        'n_modes': '显示模数:',
        'initial_cond': '初始条件',
        'init_mode': '激发模数:',
        'mode': '模式',
        'amplitude': '振幅 A:',
        'quick_preset': '快速预设:',
        'classic': '经典FPUT',
        'weak': '弱非线性',
        'strong': '强非线性',
        'sim_control': '模拟控制',
        'sim_time': '模拟时长:',
        'periods': '(基本模周期数)',
        'run': '运行模拟',
        'pause': '暂停',
        'resume': '继续',
        'reset': '重置',
        'progress': '进度:',
        'status_ready': '就绪',
        'status_running': '运行中...',
        'status_paused': '已暂停',
        'status_done': '完成!',
        'sim_info': '模拟信息',
        'total_energy': '总能量:',
        'mode1_energy': '模式1能量:',
        'fput_recurrence': 'FPUT复现:',
        'plot_main': '简正模能量演化',
        'plot_mode1': '模式1 能量详情',
        'plot_part': '参与模数',
        'plot_phase': '模式1 相空间',
        'plot_water': '能量分布热图',
        'xlabel_time': '时间 (基本模周期)',
        'xlabel_mode': '模数',
        'ylabel_energy': '能量',
        'ylabel_mode': '坐标 A₁',
        'ylabel_momentum': '动量 Ā₁',
        'ylabel_modes': '有效模数',
        'initial': '初始值',
        'language': 'Language / 语言',
        'english': 'English',
        'chinese': '中文',
    }

    @staticmethod
    def get_chinese_font():
        """Get a suitable Chinese font for matplotlib."""
        system = platform.system()

        if system == 'Windows':
            # Windows Chinese fonts
            fonts_to_try = ['Microsoft YaHei', 'SimHei', 'SimSun', 'KaiTi']
        elif system == 'Darwin':  # macOS
            fonts_to_try = ['PingFang SC', 'Heiti SC', 'STHeiti', 'Arial Unicode MS']
        else:  # Linux
            fonts_to_try = ['WenQuanYi Micro Hei', 'Droid Sans Fallback', 'Noto Sans CJK']

        # Find available font
        available_fonts = [f.name for f in font_manager.fontManager.ttflist]
        for font in fonts_to_try:
            if font in available_fonts:
                return font

        # Fallback to default
        return 'sans-serif'

    @staticmethod
    def configure_matplotlib_font(use_chinese=False):
        """Configure matplotlib font based on language selection."""
        if use_chinese:
            font = FontManager.get_chinese_font()
            plt.rcParams['font.sans-serif'] = [font, 'DejaVu Sans', 'Arial']
        else:
            plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'sans-serif']

        plt.rcParams['axes.unicode_minus'] = False  # Fix minus sign display


class FPUTSimulatorGUI:
    """Main GUI application for FPUT simulation."""

    def __init__(self, root):
        """Initialize the GUI."""
        self.root = root
        self.root.title("FPUT Simulator - Fermi-Pasta-Ulam-Tsingou Problem")
        self.root.geometry("1400x900")

        # Language setting (default: English)
        self.use_chinese = tk.BooleanVar(value=False)
        FontManager.configure_matplotlib_font(False)

        # Simulation state
        self.sim_running = False
        self.sim_paused = False
        self.simulator = None
        self.result_queue = queue.Queue()

        # Data storage
        self.time_points = []
        self.mode_energies = []
        self.max_modes = 6
        self.phase_coords = []
        self.phase_momenta = []

        # Setup GUI
        self._setup_styles()
        self._create_layout()
        self._init_plots()

    def get_label(self, key):
        """Get label in current language."""
        labels = FontManager.LABELS_CN if self.use_chinese.get() else FontManager.LABELS_EN
        return labels.get(key, key)

    def _setup_styles(self):
        """Setup GUI styles."""
        style = ttk.Style()
        style.theme_use('clam')

        # Custom styles
        style.configure('Title.TLabel', font=('Arial', 14, 'bold'))
        style.configure('Header.TLabel', font=('Arial', 10, 'bold'))
        style.configure('Run.TButton', font=('Arial', 11, 'bold'))

    def _create_layout(self):
        """Create the main layout."""
        # Main container with paned window
        self.paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left panel - Controls
        self.control_frame = ttk.Frame(self.paned, width=300)
        self.paned.add(self.control_frame, weight=0)

        # Right panel - Plots
        self.plot_frame = ttk.Frame(self.paned)
        self.paned.add(self.plot_frame, weight=1)

        self._create_controls()
        self._create_plot_area()

    def _create_controls(self):
        """Create control panel."""
        # Scrollable frame for controls
        canvas = tk.Canvas(self.control_frame)
        scrollbar = ttk.Scrollbar(self.control_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Title
        self.title_label = ttk.Label(self.scrollable_frame, text=self.get_label('title'),
                                     style='Title.TLabel')
        self.title_label.pack(pady=(10, 20))

        # Language selection
        self._create_language_section()

        # Parameters section
        self.param_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('system_params'),
                                          padding=10)
        self.param_frame.pack(fill=tk.X, padx=10, pady=5)
        self.param_frame.bind('<Destroy>', self._save_param_frame)

        self._create_parameter_section()

        # Initial conditions section
        self.init_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('initial_cond'),
                                         padding=10)
        self.init_frame.pack(fill=tk.X, padx=10, pady=5)
        self.init_frame.bind('<Destroy>', self._save_init_frame)

        self._create_initial_conditions_section()

        # Simulation section
        self.sim_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_control'),
                                        padding=10)
        self.sim_frame.pack(fill=tk.X, padx=10, pady=5)
        self.sim_frame.bind('<Destroy>', self._save_sim_frame)

        self._create_simulation_section()

        # Info section
        self.info_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_info'),
                                         padding=10)
        self.info_frame.pack(fill=tk.X, padx=10, pady=5)
        self.info_frame.bind('<Destroy>', self._save_info_frame)

        self._create_info_section()

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _save_param_frame(self, event):
        """Save parameter frame reference."""
        self.param_frame = None

    def _save_init_frame(self, event):
        """Save initial conditions frame reference."""
        self.init_frame = None

    def _save_sim_frame(self, event):
        """Save simulation frame reference."""
        self.sim_frame = None

    def _save_info_frame(self, event):
        """Save info frame reference."""
        self.info_frame = None

    def _create_language_section(self):
        """Create language selection section."""
        lang_frame = ttk.Frame(self.scrollable_frame)
        lang_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        ttk.Label(lang_frame, text=self.get_label('language') + ':').pack(side=tk.LEFT, padx=(0, 10))

        # Language radio buttons
        lang_radio_frame = ttk.Frame(lang_frame)
        lang_radio_frame.pack(side=tk.LEFT)

        self.en_radio = ttk.Radiobutton(lang_radio_frame, text=self.get_label('english'),
                                        variable=self.use_chinese, value=False,
                                        command=self._toggle_language)
        self.en_radio.pack(side=tk.LEFT, padx=(0, 10))

        self.cn_radio = ttk.Radiobutton(lang_radio_frame, text=self.get_label('chinese'),
                                        variable=self.use_chinese, value=True,
                                        command=self._toggle_language)
        self.cn_radio.pack(side=tk.LEFT)

    def _toggle_language(self):
        """Toggle between English and Chinese."""
        use_chinese = self.use_chinese.get()

        # Configure matplotlib font
        FontManager.configure_matplotlib_font(use_chinese)

        # Recreate the GUI with new language
        self._recreate_controls()
        self._update_plot_labels()

        # Redraw canvas
        self.canvas.draw()

    def _recreate_controls(self):
        """Recreate control panel with new language."""
        # Clear existing widgets in scrollable frame
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        # Title
        self.title_label = ttk.Label(self.scrollable_frame, text=self.get_label('title'),
                                     style='Title.TLabel')
        self.title_label.pack(pady=(10, 20))

        # Language selection
        self._create_language_section()

        # Recreate all sections
        self.param_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('system_params'),
                                          padding=10)
        self.param_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_parameter_section()

        self.init_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('initial_cond'),
                                         padding=10)
        self.init_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_initial_conditions_section()

        self.sim_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_control'),
                                        padding=10)
        self.sim_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_simulation_section()

        self.info_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_info'),
                                         padding=10)
        self.info_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_info_section()

    def _create_parameter_section(self):
        """Create parameter input section."""
        # Nonlinearity type
        ttk.Label(self.param_frame, text=self.get_label('nonlinearity_type')).pack(anchor=tk.W)
        self.nonlinearity_type = tk.StringVar(value="alpha")
        type_frame = ttk.Frame(self.param_frame)
        type_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Radiobutton(type_frame, text=self.get_label('alpha'), variable=self.nonlinearity_type,
                       value="alpha").pack(side=tk.LEFT)
        ttk.Radiobutton(type_frame, text=self.get_label('beta'), variable=self.nonlinearity_type,
                       value="beta").pack(side=tk.LEFT, padx=(10, 0))

        # N - Number of particles
        ttk.Label(self.param_frame, text=self.get_label('n_particles')).pack(anchor=tk.W)
        self.n_var = tk.IntVar(value=32)
        n_spinbox = ttk.Spinbox(self.param_frame, from_=8, to=128, textvariable=self.n_var,
                                width=10, command=self._update_n_display)
        n_spinbox.pack(fill=tk.X, pady=(0, 10))
        self.n_info = ttk.Label(self.param_frame,
                                text=f"{self.get_label('moving_particles')} {self.n_var.get()}")
        self.n_info.pack(anchor=tk.W, pady=(0, 10))

        # Alpha parameter
        self.alpha_frame = ttk.Frame(self.param_frame)
        self.alpha_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(self.alpha_frame, text=self.get_label('alpha_param')).pack(anchor=tk.W)
        self.alpha_var = tk.DoubleVar(value=0.25)
        ttk.Scale(self.alpha_frame, from_=0.0, to=2.0, variable=self.alpha_var,
                 orient=tk.HORIZONTAL).pack(fill=tk.X)
        self.alpha_label = ttk.Label(self.alpha_frame, text=f"α = {self.alpha_var.get():.3f}")
        self.alpha_label.pack(anchor=tk.E)
        self.alpha_var.trace('w', lambda *args: self._update_alpha_label())

        # Beta parameter
        self.beta_frame = ttk.Frame(self.param_frame)
        ttk.Label(self.beta_frame, text=self.get_label('beta_param')).pack(anchor=tk.W)
        self.beta_var = tk.DoubleVar(value=1.0)
        ttk.Scale(self.beta_frame, from_=0.0, to=5.0, variable=self.beta_var,
                 orient=tk.HORIZONTAL).pack(fill=tk.X)
        self.beta_label = ttk.Label(self.beta_frame, text=f"β = {self.beta_var.get():.3f}")
        self.beta_label.pack(anchor=tk.E)
        self.beta_var.trace('w', lambda *args: self._update_beta_label())

        # Time step
        ttk.Label(self.param_frame, text=self.get_label('dt')).pack(anchor=tk.W, pady=(10, 0))
        self.dt_var = tk.DoubleVar(value=0.05)
        dt_combo = ttk.Combobox(self.param_frame, textvariable=self.dt_var,
                                values=[0.01, 0.02, 0.05, 0.1], width=10)
        dt_combo.pack(fill=tk.X, pady=(0, 10))

        # Number of modes to display
        ttk.Label(self.param_frame, text=self.get_label('n_modes')).pack(anchor=tk.W)
        self.n_modes_var = tk.IntVar(value=6)
        ttk.Spinbox(self.param_frame, from_=3, to=12, textvariable=self.n_modes_var,
                   width=10).pack(fill=tk.X)

        self.n_var.trace('w', lambda *args: self._update_n_display())

    def _create_initial_conditions_section(self):
        """Create initial conditions section."""
        # Initial mode
        ttk.Label(self.init_frame, text=self.get_label('init_mode')).pack(anchor=tk.W)
        self.init_mode_var = tk.IntVar(value=1)
        mode_frame = ttk.Frame(self.init_frame)
        mode_frame.pack(fill=tk.X, pady=(0, 10))
        for i in range(1, 5):
            ttk.Radiobutton(mode_frame, text=f"{self.get_label('mode')} {i}",
                           variable=self.init_mode_var, value=i).pack(side=tk.LEFT)

        # Amplitude
        ttk.Label(self.init_frame, text=self.get_label('amplitude')).pack(anchor=tk.W)
        self.amplitude_var = tk.DoubleVar(value=4.0)
        amp_scale = ttk.Scale(self.init_frame, from_=0.5, to=10.0, variable=self.amplitude_var,
                             orient=tk.HORIZONTAL)
        amp_scale.pack(fill=tk.X)
        self.amp_label = ttk.Label(self.init_frame, text=f"A = {self.amplitude_var.get():.2f}")
        self.amp_label.pack(anchor=tk.E)
        self.amplitude_var.trace('w', lambda *args: self._update_amp_label())

        # Quick presets
        ttk.Label(self.init_frame, text=self.get_label('quick_preset')).pack(anchor=tk.W, pady=(10, 5))
        preset_frame = ttk.Frame(self.init_frame)
        preset_frame.pack(fill=tk.X)
        ttk.Button(preset_frame, text=self.get_label('classic'),
                  command=lambda: self._load_preset("classic")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text=self.get_label('weak'),
                  command=lambda: self._load_preset("weak")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text=self.get_label('strong'),
                  command=lambda: self._load_preset("strong")).pack(side=tk.LEFT, padx=2)

    def _create_simulation_section(self):
        """Create simulation control section."""
        # Total time
        ttk.Label(self.sim_frame, text=self.get_label('sim_time')).pack(anchor=tk.W)
        time_frame = ttk.Frame(self.sim_frame)
        time_frame.pack(fill=tk.X, pady=(0, 10))
        self.total_time_var = tk.DoubleVar(value=160.0)
        ttk.Entry(time_frame, textvariable=self.total_time_var, width=10).pack(side=tk.LEFT)
        ttk.Label(time_frame, text=self.get_label('periods')).pack(side=tk.LEFT, padx=(5, 0))

        # Buttons
        btn_frame = ttk.Frame(self.sim_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        self.run_btn = ttk.Button(btn_frame, text=self.get_label('run'),
                                 command=self.start_simulation, style='Run.TButton')
        self.run_btn.pack(side=tk.LEFT, padx=2)

        self.pause_btn = ttk.Button(btn_frame, text=self.get_label('pause'),
                                   command=self.pause_simulation, state=tk.DISABLED)
        self.pause_btn.pack(side=tk.LEFT, padx=2)

        self.reset_btn = ttk.Button(btn_frame, text=self.get_label('reset'),
                                   command=self.reset_simulation)
        self.reset_btn.pack(side=tk.LEFT, padx=2)

        # Progress bar
        ttk.Label(self.sim_frame, text=self.get_label('progress')).pack(anchor=tk.W, pady=(10, 0))
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(self.sim_frame, variable=self.progress_var,
                                           maximum=100, length=200)
        self.progress_bar.pack(fill=tk.X, pady=(5, 0))

        # Status
        self.status_label = ttk.Label(self.sim_frame, text=self.get_label('status_ready'),
                                      foreground="green")
        self.status_label.pack(anchor=tk.W, pady=(10, 0))

    def _create_info_section(self):
        """Create information section."""
        self.energy_label = ttk.Label(self.info_frame, text=f"{self.get_label('total_energy')} -")
        self.energy_label.pack(anchor=tk.W)

        self.mode1_label = ttk.Label(self.info_frame, text=f"{self.get_label('mode1_energy')} -")
        self.mode1_label.pack(anchor=tk.W)

        self.recurrence_label = ttk.Label(self.info_frame, text=f"{self.get_label('fput_recurrence')} -")
        self.recurrence_label.pack(anchor=tk.W)

    def _create_plot_area(self):
        """Create plotting area."""
        # Create figure with subplots
        self.fig = Figure(figsize=(12, 8), dpi=100)
        self.fig.patch.set_facecolor('#f0f0f0')

        # Grid spec for layout
        gs = self.fig.add_gridspec(3, 2, hspace=0.35, wspace=0.25)

        # Main energy evolution plot
        self.ax_main = self.fig.add_subplot(gs[0, :])
        self.ax_main.set_title(self.get_label('plot_main'), fontsize=12, fontweight='bold')
        self.ax_main.set_xlabel(self.get_label('xlabel_time'))
        self.ax_main.set_ylabel(self.get_label('ylabel_energy'))
        self.ax_main.grid(True, alpha=0.3)

        # Mode 1 detail
        self.ax_mode1 = self.fig.add_subplot(gs[1, 0])
        self.ax_mode1.set_title(self.get_label('plot_mode1'), fontsize=10)
        self.ax_mode1.set_xlabel(self.get_label('xlabel_time'))
        self.ax_mode1.set_ylabel(self.get_label('ylabel_energy'))
        self.ax_mode1.grid(True, alpha=0.3)

        # Participation ratio
        self.ax_part = self.fig.add_subplot(gs[1, 1])
        self.ax_part.set_title(self.get_label('plot_part'), fontsize=10)
        self.ax_part.set_xlabel(self.get_label('xlabel_time'))
        self.ax_part.set_ylabel(self.get_label('ylabel_modes'))
        self.ax_part.grid(True, alpha=0.3)

        # Phase space (mode 1)
        self.ax_phase = self.fig.add_subplot(gs[2, 0])
        self.ax_phase.set_title(self.get_label('plot_phase'), fontsize=10)
        self.ax_phase.set_xlabel(self.get_label('ylabel_mode'))
        self.ax_phase.set_ylabel(self.get_label('ylabel_momentum'))
        self.ax_phase.grid(True, alpha=0.3)

        # Waterfall plot
        self.ax_water = self.fig.add_subplot(gs[2, 1])
        self.ax_water.set_title(self.get_label('plot_water'), fontsize=10)
        self.ax_water.set_xlabel(self.get_label('xlabel_time'))
        self.ax_water.set_ylabel(self.get_label('xlabel_mode'))
        self.ax_water.grid(True, alpha=0.3)

        # Canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _init_plots(self):
        """Initialize plot lines."""
        self.mode_lines = []
        colors = plt.cm.tab10(np.linspace(0, 1, 12))

        for i in range(12):
            line, = self.ax_main.plot([], [], label=f'M{i+1}',
                                     color=colors[i], linewidth=1.5)
            self.mode_lines.append(line)

        self.mode1_line, = self.ax_mode1.plot([], [], 'b-', linewidth=1.5)
        self.mode1_ref = self.ax_mode1.axhline(y=0, color='r', linestyle='--',
                                              alpha=0.5, label=self.get_label('initial'))

        self.part_line, = self.ax_part.plot([], [], 'purple', linewidth=1.5)

        self.phase_line, = self.ax_phase.plot([], [], 'b-', linewidth=0.8, alpha=0.7)
        self.phase_point, = self.ax_phase.plot([], [], 'ro', markersize=5)

        self.legend = self.ax_main.legend(loc='upper right', fontsize=8)
        self._update_legend()

    def _update_plot_labels(self):
        """Update plot labels after language change."""
        self.ax_main.set_title(self.get_label('plot_main'), fontsize=12, fontweight='bold')
        self.ax_main.set_xlabel(self.get_label('xlabel_time'))
        self.ax_main.set_ylabel(self.get_label('ylabel_energy'))

        self.ax_mode1.set_title(self.get_label('plot_mode1'), fontsize=10)
        self.ax_mode1.set_xlabel(self.get_label('xlabel_time'))
        self.ax_mode1.set_ylabel(self.get_label('ylabel_energy'))
        self.mode1_ref.set_label(self.get_label('initial'))

        self.ax_part.set_title(self.get_label('plot_part'), fontsize=10)
        self.ax_part.set_xlabel(self.get_label('xlabel_time'))
        self.ax_part.set_ylabel(self.get_label('ylabel_modes'))

        self.ax_phase.set_title(self.get_label('plot_phase'), fontsize=10)
        self.ax_phase.set_xlabel(self.get_label('ylabel_mode'))
        self.ax_phase.set_ylabel(self.get_label('ylabel_momentum'))

        self.ax_water.set_title(self.get_label('plot_water'), fontsize=10)
        self.ax_water.set_xlabel(self.get_label('xlabel_time'))
        self.ax_water.set_ylabel(self.get_label('xlabel_mode'))

    def _update_legend(self):
        """Update legend based on number of modes to display."""
        n_modes = self.n_modes_var.get()
        lines = self.mode_lines[:n_modes]
        labels = [f'M{i+1}' for i in range(n_modes)]
        try:
            self.legend.remove()
        except:
            pass
        self.legend = self.ax_main.legend(lines, labels, loc='upper right',
                                          fontsize=8, ncol=min(6, n_modes))

    def _update_n_display(self, *args):
        """Update N display."""
        n = self.n_var.get()
        self.n_info.config(text=f"{self.get_label('moving_particles')} {n}")
        self._update_max_modes()

    def _update_max_modes(self):
        """Update maximum modes based on N."""
        self.max_modes = min(self.n_modes_var.get(), self.n_var.get())

    def _update_alpha_label(self, *args):
        """Update alpha label."""
        self.alpha_label.config(text=f"α = {self.alpha_var.get():.3f}")

    def _update_beta_label(self, *args):
        """Update beta label."""
        self.beta_label.config(text=f"β = {self.beta_var.get():.3f}")

    def _update_amp_label(self, *args):
        """Update amplitude label."""
        self.amp_label.config(text=f"A = {self.amplitude_var.get():.2f}")

    def _load_preset(self, preset):
        """Load a preset configuration."""
        if preset == "classic":
            self.n_var.set(32)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(0.25)
            self.init_mode_var.set(1)
            self.amplitude_var.set(4.0)
            self.total_time_var.set(160.0)
        elif preset == "weak":
            self.n_var.set(32)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(0.1)
            self.init_mode_var.set(1)
            self.amplitude_var.set(2.0)
            self.total_time_var.set(200.0)
        elif preset == "strong":
            self.n_var.set(16)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(1.0)
            self.init_mode_var.set(1)
            self.amplitude_var.set(2.0)
            self.total_time_var.set(100.0)

        self._update_n_display()
        self._update_alpha_label()

    def start_simulation(self):
        """Start the simulation."""
        if self.sim_running:
            return

        # Update settings
        self._update_max_modes()
        self._update_legend()

        # Create simulator
        try:
            N = self.n_var.get()
            alpha = self.alpha_var.get() if self.nonlinearity_type.get() == "alpha" else 0
            beta = self.beta_var.get() if self.nonlinearity_type.get() == "beta" else 1.0
            dt = self.dt_var.get()

            if self.nonlinearity_type.get() == "beta":
                self.simulator = FPUTBetaSimulator(N=N, beta=beta, dt=dt)
            else:
                self.simulator = FPUTSimulator(N=N, alpha=alpha, dt=dt)

            # Set initial conditions
            self.simulator.set_initial_mode(mode=self.init_mode_var.get(),
                                           amplitude=self.amplitude_var.get())

            # Store initial energy
            self.initial_energy = self.simulator.get_total_energy()
            self.initial_mode1_energy = self.simulator.compute_mode_energies()[0]

        except Exception as e:
            messagebox.showerror("Error", f"Failed to initialize simulator: {e}")
            return

        # Reset data
        self.time_points = [0]
        self.mode_energies = [self.simulator.compute_mode_energies()]
        self.phase_coords = []
        self.phase_momenta = []

        # Update info
        self.energy_label.config(text=f"{self.get_label('total_energy')} {self.initial_energy:.6f}")
        self.mode1_label.config(text=f"{self.get_label('mode1_energy')} {self.initial_mode1_energy:.6f}")

        # Clear plots
        self._clear_plots()

        # Start simulation thread
        self.sim_running = True
        self.sim_paused = False
        self.run_btn.config(state=tk.DISABLED)
        self.pause_btn.config(state=tk.NORMAL, text=self.get_label('pause'))
        self.status_label.config(text=self.get_label('status_running'), foreground="blue")

        thread = threading.Thread(target=self._run_simulation, daemon=True)
        thread.start()

        # Start update timer
        self._update_plots()

    def _run_simulation(self):
        """Run simulation in background thread."""
        try:
            total_time = self.total_time_var.get()
            dt = self.dt_var.get()
            n_steps = int(total_time / dt)
            save_interval = max(1, n_steps // 500)

            for step in range(n_steps):
                if not self.sim_running:
                    break

                while self.sim_paused:
                    import time
                    time.sleep(0.1)

                self.simulator.step_rk4()

                if step % save_interval == 0:
                    self.time_points.append((step + 1) * dt)
                    self.mode_energies.append(self.simulator.compute_mode_energies())

                    # Store phase space data
                    Q = self.simulator.Q[1:self.simulator.N + 1]
                    P = self.simulator.P[1:self.simulator.N + 1]
                    from fput.normal_modes import compute_normal_mode_coordinates, compute_normal_mode_velocities
                    A = compute_normal_mode_coordinates(Q, self.simulator.N + 1)
                    A_dot = compute_normal_mode_velocities(P, self.simulator.N + 1)
                    self.phase_coords.append(A[0])
                    self.phase_momenta.append(A_dot[0])

                    progress = (step + 1) / n_steps * 100
                    self.result_queue.put(('progress', progress))

            # Check for recurrence
            mode1_energies = [e[0] for e in self.mode_energies]
            initial = self.initial_mode1_energy
            for i, e in enumerate(mode1_energies[10:]):
                if abs(e - initial) / initial < 0.03:
                    recurrence_time = self.time_points[i + 10]
                    self.result_queue.put(('recurrence', recurrence_time))
                    break

            self.result_queue.put(('done', None))

        except Exception as e:
            self.result_queue.put(('error', str(e)))

    def _update_plots(self):
        """Update plots periodically."""
        try:
            while True:
                msg_type, msg_data = self.result_queue.get_nowait()
                if msg_type == 'progress':
                    self.progress_var.set(msg_data)
                elif msg_type == 'recurrence':
                    self.recurrence_label.config(
                        text=f"{self.get_label('fput_recurrence')} t ≈ {msg_data:.1f}")
                elif msg_type == 'done':
                    self.sim_running = False
                    self.run_btn.config(state=tk.NORMAL)
                    self.pause_btn.config(state=tk.DISABLED)
                    self.status_label.config(text=self.get_label('status_done'), foreground="green")
                elif msg_type == 'error':
                    self.sim_running = False
                    self.run_btn.config(state=tk.NORMAL)
                    self.pause_btn.config(state=tk.DISABLED)
                    self.status_label.config(text="Error!", foreground="red")
                    messagebox.showerror("Simulation Error", msg_data)
        except queue.Empty:
            pass

        if len(self.time_points) > 1:
            time_arr = np.array(self.time_points)
            energies_arr = np.array(self.mode_energies)
            n_modes = min(self.n_modes_var.get(), self.n_var.get())

            # Update main plot
            for i in range(n_modes):
                self.mode_lines[i].set_data(time_arr, energies_arr[:, i])

            for i in range(n_modes, 12):
                self.mode_lines[i].set_data([], [])

            # Update mode 1 detail
            self.mode1_line.set_data(time_arr, energies_arr[:, 0])
            self.mode1_ref.set_ydata([self.initial_mode1_energy])
            self.ax_mode1.set_xlim(0, max(time_arr))
            self.ax_mode1.set_ylim(0, max(energies_arr[:, 0]) * 1.1)

            # Update participation ratio
            p = energies_arr / energies_arr.sum(axis=1, keepdims=True)
            participation = 1.0 / np.sum(p**2, axis=1)
            self.part_line.set_data(time_arr, participation)
            self.ax_part.set_xlim(0, max(time_arr))
            self.ax_part.set_ylim(0, max(participation) * 1.1)

            # Update phase space
            if len(self.phase_coords) > 1:
                self.phase_line.set_data(self.phase_coords, self.phase_momenta)
                self.phase_point.set_data([self.phase_coords[-1]], [self.phase_momenta[-1]])
                self.ax_phase.set_xlim(min(self.phase_coords) * 1.1, max(self.phase_coords) * 1.1)
                self.ax_phase.set_ylim(min(self.phase_momenta) * 1.1, max(self.phase_momenta) * 1.1)

            # Update waterfall
            self.ax_water.clear()
            self.ax_water.set_title(self.get_label('plot_water'), fontsize=10)
            self.ax_water.set_xlabel(self.get_label('xlabel_time'))
            self.ax_water.set_ylabel(self.get_label('xlabel_mode'))
            modes_to_show = list(range(1, min(n_modes + 1, 10)))
            T, M = np.meshgrid(time_arr, modes_to_show)
            E_subset = energies_arr[:, :len(modes_to_show)].T
            self.ax_water.pcolormesh(T, M, E_subset, shading='auto', cmap='viridis')

            # Update main plot limits
            self.ax_main.set_xlim(0, max(time_arr))
            self.ax_main.set_ylim(0, np.max(energies_arr[:, :n_modes]) * 1.1)

            self.canvas.draw()

        if self.sim_running:
            self.root.after(200, self._update_plots)

    def _clear_plots(self):
        """Clear all plots."""
        for line in self.mode_lines:
            line.set_data([], [])
        self.mode1_line.set_data([], [])
        self.phase_line.set_data([], [])
        self.phase_point.set_data([], [])
        self.part_line.set_data([], [])

        self.ax_main.set_xlim(0, 1)
        self.ax_main.set_ylim(0, 1)
        self.ax_mode1.set_xlim(0, 1)
        self.ax_mode1.set_ylim(0, 1)
        self.ax_part.set_xlim(0, 1)
        self.ax_part.set_ylim(0, 1)
        self.ax_phase.set_xlim(-1, 1)
        self.ax_phase.set_ylim(-1, 1)
        self.ax_water.clear()

        self.canvas.draw()

    def pause_simulation(self):
        """Pause/resume simulation."""
        self.sim_paused = not self.sim_paused
        if self.sim_paused:
            self.pause_btn.config(text=self.get_label('resume'))
            self.status_label.config(text=self.get_label('status_paused'), foreground="orange")
        else:
            self.pause_btn.config(text=self.get_label('pause'))
            self.status_label.config(text=self.get_label('status_running'), foreground="blue")

    def reset_simulation(self):
        """Reset simulation."""
        self.sim_running = False
        self.sim_paused = False
        self.time_points = []
        self.mode_energies = []
        self.phase_coords = []
        self.phase_momenta = []

        self.progress_var.set(0)
        self.run_btn.config(state=tk.NORMAL)
        self.pause_btn.config(state=tk.DISABLED, text=self.get_label('pause'))
        self.status_label.config(text=self.get_label('status_ready'), foreground="green")
        self.energy_label.config(text=f"{self.get_label('total_energy')} -")
        self.mode1_label.config(text=f"{self.get_label('mode1_energy')} -")
        self.recurrence_label.config(text=f"{self.get_label('fput_recurrence')} -")

        self._clear_plots()


def main():
    """Launch the FPUT GUI application."""
    root = tk.Tk()
    app = FPUTSimulatorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
