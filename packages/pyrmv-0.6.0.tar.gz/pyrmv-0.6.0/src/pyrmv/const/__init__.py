from .product import PRODUCTS as PRODUCTS
