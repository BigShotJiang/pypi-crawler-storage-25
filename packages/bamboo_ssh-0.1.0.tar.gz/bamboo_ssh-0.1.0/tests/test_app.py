import socket
import subprocess
import sys
import time
import urllib.request
from importlib import import_module
from pathlib import Path

from fastapi.testclient import TestClient

from bamboo_ssh.adapters.fastapi_app import app
from bamboo_ssh.core.session import TerminalSession, stream_terminal_output


client = TestClient(app)
PYTHON_DIR = Path(__file__).resolve().parents[1]
PARENT_DIR = PYTHON_DIR.parent


def test_core_session_api_imports():
    assert callable(TerminalSession.start)
    assert callable(stream_terminal_output)


def test_top_level_package_re_exports_core_api():
    package = import_module("bamboo_ssh")
    core = import_module("bamboo_ssh.core")

    assert package.TerminalSession is TerminalSession
    assert package.stream_terminal_output is stream_terminal_output
    assert core.TerminalSession is TerminalSession
    assert core.stream_terminal_output is stream_terminal_output


def test_adapter_package_and_compatibility_shims_export_expected_surfaces():
    adapters = import_module("bamboo_ssh.adapters")
    packaged_app_module = import_module("bamboo_ssh.adapters.fastapi_app")
    legacy_app_module = import_module("app")
    legacy_terminal_module = import_module("terminal")

    assert adapters.app is packaged_app_module.app
    assert adapters.build_arg_parser is packaged_app_module.build_arg_parser
    assert adapters.main is packaged_app_module.main
    assert legacy_app_module.app is packaged_app_module.app
    assert legacy_app_module.main is packaged_app_module.main
    assert legacy_terminal_module.TerminalSession is TerminalSession
    assert legacy_terminal_module.stream_terminal_output is stream_terminal_output


def test_resolve_static_dir_prefers_package_local_path(tmp_path):
    fastapi_app = import_module("bamboo_ssh.adapters.fastapi_app")
    package_static = tmp_path / "package-static"
    checkout_static = tmp_path / "checkout-static"
    package_static.mkdir()
    checkout_static.mkdir()

    assert fastapi_app._resolve_static_dir(package_static, checkout_static) == package_static


def test_resolve_static_dir_falls_back_to_checkout_path(tmp_path):
    fastapi_app = import_module("bamboo_ssh.adapters.fastapi_app")
    checkout_static = tmp_path / "checkout-static"
    checkout_static.mkdir()

    assert fastapi_app._resolve_static_dir(tmp_path / "missing-package-static", checkout_static) == checkout_static


def test_static_dir_uses_package_owned_assets():
    fastapi_app = import_module("bamboo_ssh.adapters.fastapi_app")
    package_static = Path(fastapi_app.__file__).resolve().parents[1] / "static"

    assert fastapi_app.STATIC_DIR == package_static
    assert (fastapi_app.STATIC_DIR / "index.html").is_file()
    assert (fastapi_app.STATIC_DIR / "app.js").is_file()


def test_index_served():
    response = client.get("/")

    assert response.status_code == 200
    assert "Python Web Terminal" in response.text


def test_index_includes_terminal_bootstrap():
    response = client.get("/")

    assert response.status_code == 200
    assert 'id="terminal"' in response.text
    assert 'src="/static/app.js"' in response.text


def test_static_app_handles_shell_ready_messages():
    response = client.get("/static/app.js")

    assert response.status_code == 200
    assert 'payload.type === "ready"' in response.text


def test_app_py_runs_from_python_directory():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    proc = subprocess.Popen(
        [sys.executable, "app.py", "--host", "127.0.0.1", "--port", str(port)],
        cwd=PYTHON_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        deadline = time.time() + 10
        while time.time() < deadline:
            if proc.poll() is not None:
                output = proc.stdout.read() if proc.stdout else ""
                raise AssertionError(f"app.py exited early with code {proc.returncode}: {output}")
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=0.5) as response:
                    body = response.read().decode()
                    assert "Python Web Terminal" in body
                    return
            except Exception:
                time.sleep(0.2)
        raise AssertionError("timed out waiting for app.py server startup")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def test_package_imports_work_from_parent_directory():
    command = """
from importlib import import_module

package = import_module("bamboo_ssh")
adapters = import_module("bamboo_ssh.adapters")
core = import_module("bamboo_ssh.core")

assert package.TerminalSession is core.TerminalSession
assert package.stream_terminal_output is core.stream_terminal_output
assert callable(adapters.build_arg_parser)
assert callable(adapters.main)
assert adapters.app.title == "Python Web Terminal"
assert import_module("bamboo_ssh.adapters.fastapi_app").STATIC_DIR.is_dir()
print(package.__file__)
"""
    proc = subprocess.run(
        [sys.executable, "-c", command],
        cwd=PARENT_DIR,
        capture_output=True,
        text=True,
    )

    assert proc.returncode == 0, f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
