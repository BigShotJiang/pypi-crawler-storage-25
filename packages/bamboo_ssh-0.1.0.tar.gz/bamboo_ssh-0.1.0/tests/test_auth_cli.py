from __future__ import annotations

from pathlib import Path
import subprocess
import sys
import tomllib
import types

import pytest

from bamboo_ssh.auth.config import load_config
from bamboo_ssh.cli import main


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_auth_init_creates_config_with_prompted_password_hash_and_session_secret(tmp_path, monkeypatch):
    from bamboo_ssh.auth.passwords import verify_password

    config_path = tmp_path / "bamboo-ssh.toml"
    prompts: list[str] = []
    responses = iter(["correct horse battery staple", "correct horse battery staple"])

    def fake_getpass(prompt: str) -> str:
        prompts.append(prompt)
        return next(responses)

    monkeypatch.setattr("getpass.getpass", fake_getpass)
    monkeypatch.setattr("secrets.token_urlsafe", lambda size: "session-secret-value")

    exit_code = main(["auth", "init", "--config", str(config_path), "--username", "admin"])

    config = load_config(config_path)

    assert exit_code == 0
    assert prompts == ["Password: ", "Confirm password: "]
    assert config.auth is not None
    assert config.auth.enabled is True
    assert config.auth.username == "admin"
    assert verify_password("correct horse battery staple", config.auth.password_hash) is True
    assert config.auth.session_secret == "session-secret-value"
    assert config.auth.session_ttl_seconds == 43200


def test_auth_set_password_replaces_only_the_stored_hash(tmp_path, monkeypatch):
    from bamboo_ssh.auth.passwords import hash_password, verify_password

    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text(
        "\n".join(
            [
                "[server]",
                'host = "0.0.0.0"',
                "port = 9000",
                "",
                "[auth]",
                "enabled = false",
                'username = "admin"',
                f'password_hash = "{hash_password("old password")}"',
                'session_secret = "keep-this-secret"',
                "session_ttl_seconds = 900",
                "",
            ]
        ),
        encoding="utf-8",
    )
    original = tomllib.loads(config_path.read_text(encoding="utf-8"))
    prompts: list[str] = []
    responses = iter(["new password", "new password"])

    def fake_getpass(prompt: str) -> str:
        prompts.append(prompt)
        return next(responses)

    monkeypatch.setattr("getpass.getpass", fake_getpass)

    exit_code = main(["auth", "set-password", "--config", str(config_path)])

    updated = load_config(config_path)
    updated_data = tomllib.loads(config_path.read_text(encoding="utf-8"))

    assert exit_code == 0
    assert prompts == ["Password: ", "Confirm password: "]
    assert updated.server.host == "0.0.0.0"
    assert updated.server.port == 9000
    assert updated.auth is not None
    assert updated.auth.enabled is False
    assert updated.auth.username == "admin"
    assert updated.auth.session_secret == "keep-this-secret"
    assert updated.auth.session_ttl_seconds == 900
    assert updated.auth.password_hash != original["auth"]["password_hash"]
    assert verify_password("new password", updated.auth.password_hash) is True
    assert updated_data["server"] == original["server"]
    assert updated_data["auth"]["enabled"] == original["auth"]["enabled"]
    assert updated_data["auth"]["username"] == original["auth"]["username"]
    assert updated_data["auth"]["session_secret"] == original["auth"]["session_secret"]
    assert updated_data["auth"]["session_ttl_seconds"] == original["auth"]["session_ttl_seconds"]


def test_auth_show_config_path_prints_the_default_config_location(tmp_path, monkeypatch, capsys):
    config_home = tmp_path / "xdg-config"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(config_home))

    exit_code = main(["auth", "show-config-path"])

    assert exit_code == 0
    assert capsys.readouterr().out.strip() == str((config_home / "bamboo-ssh" / "config.toml").resolve())


def test_auth_show_config_path_executes_without_argon2_dependency():
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            "\n".join(
                [
                    "import builtins",
                    "real_import = builtins.__import__",
                    "def blocked_import(name, globals=None, locals=None, fromlist=(), level=0):",
                    "    if name == 'argon2' or name.startswith('argon2.'):",
                    "        raise ModuleNotFoundError(\"No module named 'argon2'\", name=name)",
                    "    return real_import(name, globals, locals, fromlist, level)",
                    "builtins.__import__ = blocked_import",
                    "from bamboo_ssh.cli import main",
                    "raise SystemExit(main(['auth', 'show-config-path', '--config', '/tmp/example-config.toml']))",
                ]
            ),
        ],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "/tmp/example-config.toml"


def test_auth_init_reports_aborted_password_prompt(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"

    def interrupted_getpass(prompt: str) -> str:
        raise KeyboardInterrupt

    monkeypatch.setattr("getpass.getpass", interrupted_getpass)

    with pytest.raises(SystemExit, match="Password prompt aborted."):
        main(["auth", "init", "--config", str(config_path)])


def test_auth_set_password_reports_aborted_password_prompt(tmp_path, monkeypatch):
    from bamboo_ssh.auth.passwords import hash_password

    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text(
        "\n".join(
            [
                "[server]",
                'host = "127.0.0.1"',
                "port = 8765",
                "",
                "[auth]",
                "enabled = true",
                'username = "admin"',
                f'password_hash = "{hash_password("old password")}"',
                'session_secret = "keep-this-secret"',
                "session_ttl_seconds = 900",
                "",
            ]
        ),
        encoding="utf-8",
    )

    def eof_getpass(prompt: str) -> str:
        raise EOFError

    monkeypatch.setattr("getpass.getpass", eof_getpass)

    with pytest.raises(SystemExit, match="Password prompt aborted."):
        main(["auth", "set-password", "--config", str(config_path)])


def test_serve_command_passes_config_path_to_app_factory(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"
    calls: dict[str, object] = {}
    fake_adapter = types.ModuleType("bamboo_ssh.adapters.fastapi_app")
    fake_uvicorn = types.ModuleType("uvicorn")

    def fake_create_app(*, config_path=None):
        calls["config_path"] = config_path
        return "fake-app"

    def fake_run(app, host, port):
        calls["app"] = app
        calls["host"] = host
        calls["port"] = port

    fake_adapter.create_app = fake_create_app
    fake_uvicorn.run = fake_run

    monkeypatch.setitem(sys.modules, "bamboo_ssh.adapters.fastapi_app", fake_adapter)
    monkeypatch.setitem(sys.modules, "uvicorn", fake_uvicorn)

    exit_code = main(["serve", "--host", "0.0.0.0", "--port", "9000", "--config", str(config_path)])

    assert exit_code == 0
    assert calls == {
        "config_path": str(config_path.resolve()),
        "app": "fake-app",
        "host": "0.0.0.0",
        "port": 9000,
    }


def test_serve_command_uses_default_config_path_when_present(tmp_path, monkeypatch):
    config_home = tmp_path / "xdg-config"
    config_path = config_home / "bamboo-ssh" / "config.toml"
    config_path.parent.mkdir(parents=True)
    config_path.write_text("[server]\nhost = \"127.0.0.1\"\nport = 8765\n", encoding="utf-8")
    calls: dict[str, object] = {}
    fake_adapter = types.ModuleType("bamboo_ssh.adapters.fastapi_app")
    fake_uvicorn = types.ModuleType("uvicorn")

    def fake_create_app(*, config_path=None):
        calls["config_path"] = config_path
        return "fake-app"

    def fake_run(app, host, port):
        calls["app"] = app
        calls["host"] = host
        calls["port"] = port

    fake_adapter.create_app = fake_create_app
    fake_uvicorn.run = fake_run

    monkeypatch.setenv("XDG_CONFIG_HOME", str(config_home))
    monkeypatch.setitem(sys.modules, "bamboo_ssh.adapters.fastapi_app", fake_adapter)
    monkeypatch.setitem(sys.modules, "uvicorn", fake_uvicorn)

    exit_code = main(["serve"])

    assert exit_code == 0
    assert calls == {
        "config_path": str(config_path.resolve()),
        "app": "fake-app",
        "host": "127.0.0.1",
        "port": 8765,
    }
