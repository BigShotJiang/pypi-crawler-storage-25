from pathlib import Path


PYTHON_DIR = Path(__file__).resolve().parents[1]


def test_docker_support_assets_exist_and_use_python_312():
    docker_dir = PYTHON_DIR / "docker"
    dockerfile = docker_dir / "Dockerfile"
    compose_file = docker_dir / "compose.yml"
    env_example = docker_dir / ".env.example"

    assert docker_dir.is_dir()
    assert dockerfile.is_file()
    assert compose_file.is_file()
    assert env_example.is_file()

    dockerfile_text = dockerfile.read_text(encoding="utf-8")
    compose_text = compose_file.read_text(encoding="utf-8")
    env_text = env_example.read_text(encoding="utf-8")

    assert "FROM python:3.12-slim" in dockerfile_text
    assert "web-terminal:" in compose_text
    assert "WEB_TERMINAL_HOST" in compose_text
    assert "WEB_TERMINAL_PORT" in compose_text
    assert "WEB_TERMINAL_BIND_IP" in compose_text
    assert "WEB_TERMINAL_HOST=0.0.0.0" in env_text
    assert "WEB_TERMINAL_PORT=8765" in env_text
