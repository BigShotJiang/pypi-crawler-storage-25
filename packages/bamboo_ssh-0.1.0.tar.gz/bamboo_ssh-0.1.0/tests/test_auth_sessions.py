from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math

import pytest

from bamboo_ssh.auth.config import AuthSettings
import bamboo_ssh.auth.sessions as auth_sessions_module
from bamboo_ssh.auth.sessions import SessionClaims, issue_session_token, validate_session_token


def _auth_settings() -> AuthSettings:
    return AuthSettings(
        enabled=True,
        username="admin",
        password_hash="$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash",
        session_secret="session-secret",
        session_ttl_seconds=3600,
    )


def _decode_payload(token: str) -> dict[str, object]:
    payload_segment = token.split(".", maxsplit=1)[0]
    return json.loads(_urlsafe_b64decode(payload_segment))


def _signed_token(payload: object, session_secret: str) -> str:
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    signature = hmac.new(session_secret.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
    return f"{_urlsafe_b64encode(payload_bytes)}.{_urlsafe_b64encode(signature)}"


def _urlsafe_b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _urlsafe_b64decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def test_issue_session_token_for_admin_user_keeps_payload_minimal():
    settings = _auth_settings()

    token = issue_session_token(settings, now=1_700_000_000)

    assert _decode_payload(token) == {
        "username": "admin",
        "iat": 1_700_000_000,
        "exp": 1_700_003_600,
    }


def test_validate_session_token_accepts_good_token():
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)

    claims = validate_session_token(token, settings, now=1_700_000_001)

    assert claims == SessionClaims(
        username="admin",
        issued_at=1_700_000_000,
        expires_at=1_700_003_600,
    )


def test_validate_session_token_rejects_expired_token():
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)

    claims = validate_session_token(token, settings, now=1_700_003_601)

    assert claims is None


def test_validate_session_token_rejects_token_at_expiry_boundary():
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)

    claims = validate_session_token(token, settings, now=1_700_003_600)

    assert claims is None


def test_validate_session_token_rejects_future_issued_at():
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)

    claims = validate_session_token(token, settings, now=1_699_999_999)

    assert claims is None


def test_validate_session_token_rejects_tampered_token():
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)
    payload_segment, signature_segment = token.split(".", maxsplit=1)
    tampered_payload = json.dumps(
        {
            "username": "root",
            "iat": 1_700_000_000,
            "exp": 1_700_003_600,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    tampered_token = f"{_urlsafe_b64encode(tampered_payload)}.{signature_segment}"

    claims = validate_session_token(tampered_token, settings, now=1_700_000_001)

    assert claims is None


@pytest.mark.parametrize("token", ["not-a-token", "bm90LWpzb24.!"])
def test_validate_session_token_rejects_malformed_tokens(token: str):
    settings = _auth_settings()

    claims = validate_session_token(token, settings, now=1_700_000_001)

    assert claims is None


def test_validate_session_token_rejects_wrong_payload_schema():
    settings = _auth_settings()
    token = _signed_token(
        {
            "username": "admin",
            "iat": 1_700_000_000,
            "exp": 1_700_003_600,
            "role": "admin",
        },
        settings.session_secret,
    )

    claims = validate_session_token(token, settings, now=1_700_000_001)

    assert claims is None


def test_validate_session_token_rejects_username_mismatch():
    settings = _auth_settings()
    token = _signed_token(
        {
            "username": "root",
            "iat": 1_700_000_000,
            "exp": 1_700_003_600,
        },
        settings.session_secret,
    )

    claims = validate_session_token(token, settings, now=1_700_000_001)

    assert claims is None


def test_issue_and_validate_session_token_normalize_float_now_inputs():
    settings = _auth_settings()

    token = issue_session_token(settings, now=1_700_000_000.9)
    claims = validate_session_token(token, settings, now=1_700_000_001.2)

    assert _decode_payload(token) == {
        "username": "admin",
        "iat": 1_700_000_000,
        "exp": 1_700_003_600,
    }
    assert claims == SessionClaims(
        username="admin",
        issued_at=1_700_000_000,
        expires_at=1_700_003_600,
    )


@pytest.mark.parametrize("now", [math.nan, math.inf, -math.inf])
def test_issue_session_token_rejects_non_finite_now(now: float):
    settings = _auth_settings()

    with pytest.raises(ValueError, match="now must be a finite timestamp"):
        issue_session_token(settings, now=now)


@pytest.mark.parametrize("now", [math.nan, math.inf, -math.inf])
def test_validate_session_token_rejects_non_finite_now(now: float):
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)

    with pytest.raises(ValueError, match="now must be a finite timestamp"):
        validate_session_token(token, settings, now=now)


def test_validate_session_token_uses_constant_time_signature_check(monkeypatch):
    settings = _auth_settings()
    token = issue_session_token(settings, now=1_700_000_000)
    compare_calls: list[tuple[bytes, bytes]] = []
    real_compare_digest = auth_sessions_module.hmac.compare_digest

    def tracking_compare_digest(left: bytes, right: bytes) -> bool:
        compare_calls.append((left, right))
        return real_compare_digest(left, right)

    monkeypatch.setattr("bamboo_ssh.auth.sessions.hmac.compare_digest", tracking_compare_digest)

    claims = validate_session_token(token, settings, now=1_700_000_001)

    assert claims == SessionClaims(
        username="admin",
        issued_at=1_700_000_000,
        expires_at=1_700_003_600,
    )
    assert len(compare_calls) == 1
    assert all(isinstance(side, bytes) for side in compare_calls[0])
