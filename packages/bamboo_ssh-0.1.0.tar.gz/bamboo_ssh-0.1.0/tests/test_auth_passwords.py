from bamboo_ssh.auth.passwords import hash_password, verify_password


def test_hash_password_returns_argon2_hash_that_verifies():
    password_hash = hash_password("correct horse battery staple")

    assert password_hash.startswith("$argon2id$")
    assert password_hash != "correct horse battery staple"
    assert verify_password("correct horse battery staple", password_hash) is True


def test_verify_password_rejects_wrong_password():
    password_hash = hash_password("correct horse battery staple")

    assert verify_password("tr0ub4dor&3", password_hash) is False


def test_verify_password_rejects_malformed_hash():
    assert verify_password("correct horse battery staple", "not-an-argon2-hash") is False
