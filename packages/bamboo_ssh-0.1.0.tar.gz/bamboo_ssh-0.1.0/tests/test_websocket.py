import json
import queue
import threading
import time

from fastapi.testclient import TestClient

from bamboo_ssh.adapters.fastapi_app import app


client = TestClient(app)


def _receive_json_with_timeout(ws, timeout: float = 5.0) -> dict:
    result: "queue.Queue[tuple[bool, object]]" = queue.Queue(maxsize=1)

    def _reader() -> None:
        try:
            result.put((True, ws.receive_json()))
        except Exception as exc:  # pragma: no cover - test helper
            result.put((False, exc))

    thread = threading.Thread(target=_reader, daemon=True)
    thread.start()

    try:
        ok, value = result.get(timeout=timeout)
    except queue.Empty as exc:
        raise AssertionError(f"timed out waiting for websocket message after {timeout:.2f}s") from exc

    if ok:
        return value  # type: ignore[return-value]
    raise value  # type: ignore[misc]


def _receive_until_contains(ws, needle: str, timeout: float = 5.0) -> str:
    deadline = time.time() + timeout
    chunks: list[str] = []
    while time.time() < deadline:
        payload = _receive_json_with_timeout(ws, timeout=max(0.1, deadline - time.time()))
        if payload["type"] != "cmd":
            continue
        data = payload.get("data", "")
        chunks.append(data)
        combined = "".join(chunks)
        if needle in combined:
            return combined
    raise AssertionError(f"did not receive expected output: {needle!r}, got: {json.dumps(chunks)}")


def _receive_until_type(ws, expected_type: str, timeout: float = 5.0) -> dict:
    deadline = time.time() + timeout
    while time.time() < deadline:
        payload = _receive_json_with_timeout(ws, timeout=max(0.1, deadline - time.time()))
        if payload.get("type") == expected_type:
            return payload
    raise AssertionError(f"did not receive expected message type: {expected_type!r}")


def test_websocket_echoes_heartbeat():
    with client.websocket_connect("/ws/terminal?cols=80&rows=24") as websocket:
        payload = {"type": "heartbeat", "timestamp": 123456}

        websocket.send_json(payload)
        response = _receive_until_type(websocket, "heartbeat")

        assert response == payload


def test_websocket_signals_ready_before_terminal_output():
    with client.websocket_connect("/ws/terminal?cols=80&rows=24") as websocket:
        websocket.send_json({"type": "cmd", "data": "printf '__READY_SIGNAL__\\n'\n"})
        payload = _receive_json_with_timeout(websocket)

        assert payload == {"type": "ready"}

        output = _receive_until_contains(websocket, "__READY_SIGNAL__")
        assert "__READY_SIGNAL__" in output


def test_websocket_runs_shell_command():
    with client.websocket_connect("/ws/terminal?cols=80&rows=24") as websocket:
        websocket.send_json({"type": "cmd", "data": "printf '__PYTHON_TERMINAL_OK__\\n'\n"})
        output = _receive_until_contains(websocket, "__PYTHON_TERMINAL_OK__")

        assert "__PYTHON_TERMINAL_OK__" in output


def test_websocket_shell_environment_marks_web_terminal_sessions():
    with client.websocket_connect("/ws/terminal?cols=80&rows=24") as websocket:
        websocket.send_json({"type": "cmd", "data": "printf '__WEB_TERMINAL__:%s\\n' \"$WEB_TERMINAL\"\n"})
        payload = _receive_json_with_timeout(websocket)

        assert payload == {"type": "ready"}

        output = _receive_until_contains(websocket, "__WEB_TERMINAL__:1")

        assert "__WEB_TERMINAL__:1" in output
