from __future__ import annotations

import subprocess
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MAKEFILE_PATH = PROJECT_ROOT / "Makefile"


def _run_make_dry_run(target: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["make", "-n", target],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )


def test_makefile_declares_basic_phony_targets():
    contents = MAKEFILE_PATH.read_text(encoding="utf-8")

    assert ".PHONY:" in contents
    assert "install" in contents
    assert "clean" in contents
    assert "build" in contents
    assert "deploy" in contents


def test_make_install_dry_run_bootstraps_local_virtualenv_and_requirements():
    result = _run_make_dry_run("install")

    assert result.returncode == 0, result.stderr
    assert "python3 -m venv .venv" in result.stdout
    assert ".venv/bin/python -m pip install --upgrade pip" in result.stdout
    assert ".venv/bin/python -m pip install -r requirements.txt" in result.stdout


def test_make_clean_dry_run_removes_build_and_test_artifacts():
    result = _run_make_dry_run("clean")

    assert result.returncode == 0, result.stderr
    assert "rm -rf" in result.stdout
    assert "build" in result.stdout
    assert "dist" in result.stdout
    assert ".pytest_cache" in result.stdout
    assert "bamboo_ssh.egg-info" in result.stdout


def test_make_build_dry_run_creates_sdist_and_wheel_artifacts():
    result = _run_make_dry_run("build")

    assert result.returncode == 0, result.stderr
    assert "mkdir -p dist" in result.stdout
    assert ".venv/bin/python -m pip install --upgrade build" in result.stdout
    assert ".venv/bin/python -m build --outdir dist" in result.stdout


def test_make_deploy_dry_run_uploads_built_artifacts_to_pypi():
    result = _run_make_dry_run("deploy")

    assert result.returncode == 0, result.stderr
    assert ".venv/bin/python -m pip install --upgrade build" in result.stdout
    assert ".venv/bin/python -m build --outdir dist" in result.stdout
    assert ".venv/bin/python -m pip install --upgrade twine" in result.stdout
    assert ".venv/bin/python -m twine upload --repository pypi dist/*" in result.stdout
