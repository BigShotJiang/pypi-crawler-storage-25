from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.request
import zipfile
from email.parser import Parser
from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REQUIREMENTS_PATH = PROJECT_ROOT / "requirements.txt"
README_PATH = PROJECT_ROOT / "README.md"
SETUP_DOC_PATH = PROJECT_ROOT / "docs" / "setup-and-run.md"


@pytest.fixture(scope="module")
def built_wheel(tmp_path_factory: pytest.TempPathFactory) -> Path:
    dist_dir = tmp_path_factory.mktemp("dist")
    command = [
        sys.executable,
        "-m",
        "pip",
        "wheel",
        "--no-deps",
        "--wheel-dir",
        str(dist_dir),
        str(PROJECT_ROOT),
    ]
    result = subprocess.run(command, cwd=PROJECT_ROOT, capture_output=True, text=True)

    assert result.returncode == 0, (
        f"build failed with exit code {result.returncode}\n"
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}"
    )

    wheels = list(dist_dir.glob("*.whl"))
    assert len(wheels) == 1
    return wheels[0]


def _read_wheel_member(wheel_path: Path, suffix: str) -> str:
    with zipfile.ZipFile(wheel_path) as archive:
        matches = [name for name in archive.namelist() if name.endswith(suffix)]
        assert len(matches) == 1
        return archive.read(matches[0]).decode("utf-8")


def _wheel_metadata(wheel_path: Path):
    metadata_text = _read_wheel_member(wheel_path, ".dist-info/METADATA")
    return Parser().parsestr(metadata_text)


def _requirement_lines(metadata, requirement_name: str) -> list[str]:
    return [
        line
        for line in metadata.get_all("Requires-Dist") or []
        if line.lower().startswith(requirement_name.lower())
    ]


def _assert_requirement_uses_compatible_range(requirements: list[str]) -> None:
    assert len(requirements) == 2

    for requirement in requirements:
        version_specifier = requirement.split(";", maxsplit=1)[0]

        assert "==" not in version_specifier
        assert ">=" in version_specifier
        assert "<" in version_specifier


def _venv_python_path(venv_dir: Path) -> Path:
    scripts_dir = "Scripts" if os.name == "nt" else "bin"
    python_name = "python.exe" if os.name == "nt" else "python"
    return venv_dir / scripts_dir / python_name


def _venv_console_script_path(venv_dir: Path, command_name: str) -> Path:
    scripts_dir = "Scripts" if os.name == "nt" else "bin"
    suffix = ".exe" if os.name == "nt" else ""
    return venv_dir / scripts_dir / f"{command_name}{suffix}"


def _isolated_runtime_env() -> dict[str, str]:
    runtime_env = {
        key: value
        for key, value in os.environ.items()
        if key not in {"PYTHONPATH", "VIRTUAL_ENV", "XDG_CONFIG_HOME"}
    }
    runtime_env["PYTHONUNBUFFERED"] = "1"
    return runtime_env


def _wait_for_http_ready(url: str, process: subprocess.Popen[str], timeout: float = 15.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process.poll() is not None:
            output = process.stdout.read() if process.stdout else ""
            raise AssertionError(f"server exited early with code {process.returncode}:\n{output}")

        try:
            with urllib.request.urlopen(url, timeout=0.5) as response:
                if response.status == 200:
                    return
        except Exception:
            time.sleep(0.2)

    output = process.stdout.read() if process.stdout else ""
    raise AssertionError(f"timed out waiting for server startup at {url}\n{output}")


@pytest.fixture(scope="module")
def installed_web_profile(tmp_path_factory: pytest.TempPathFactory, built_wheel: Path) -> dict[str, Path]:
    env_dir = tmp_path_factory.mktemp("web-profile-venv")
    run_dir = tmp_path_factory.mktemp("web-profile-run")
    python_path = _venv_python_path(env_dir)
    console_script_path = _venv_console_script_path(env_dir, "bamboo-ssh")

    create_env = subprocess.run(
        [sys.executable, "-m", "venv", str(env_dir)],
        cwd=run_dir,
        capture_output=True,
        text=True,
    )
    assert create_env.returncode == 0, (
        f"virtualenv creation failed with exit code {create_env.returncode}\n"
        f"stdout:\n{create_env.stdout}\n"
        f"stderr:\n{create_env.stderr}"
    )

    install_web_profile = subprocess.run(
        [str(python_path), "-m", "pip", "install", f"bamboo-ssh[web] @ {built_wheel.as_uri()}"],
        cwd=run_dir,
        capture_output=True,
        text=True,
    )
    assert install_web_profile.returncode == 0, (
        f"web profile install failed with exit code {install_web_profile.returncode}\n"
        f"stdout:\n{install_web_profile.stdout}\n"
        f"stderr:\n{install_web_profile.stderr}"
    )

    assert console_script_path.is_file()

    return {
        "console_script_path": console_script_path,
        "python_path": python_path,
        "run_dir": run_dir,
    }


def test_built_wheel_includes_static_assets_and_console_script_metadata(built_wheel: Path):
    with zipfile.ZipFile(built_wheel) as archive:
        names = set(archive.namelist())

    assert "bamboo_ssh/static/index.html" in names
    assert "bamboo_ssh/static/app.js" in names
    assert "bamboo_ssh/static/styles.css" in names
    assert "bamboo_ssh/static/vendor/xterm.js" in names
    assert "bamboo_ssh/static/vendor/xterm-addon-fit.js" in names
    assert "bamboo_ssh/static/vendor/xterm.css" in names

    entry_points = _read_wheel_member(built_wheel, ".dist-info/entry_points.txt")

    assert "[console_scripts]" in entry_points
    assert "bamboo-ssh = bamboo_ssh.cli:main" in entry_points


def test_built_wheel_metadata_uses_expected_name_python_requirement_and_dependency_ranges(
    built_wheel: Path,
):
    metadata = _wheel_metadata(built_wheel)

    assert metadata["Name"] == "bamboo-ssh"
    assert metadata["Requires-Python"] == ">=3.12"
    assert {"web", "full", "dev"} <= set(metadata.get_all("Provides-Extra") or [])

    fastapi_requirements = _requirement_lines(metadata, "fastapi")
    uvicorn_requirements = _requirement_lines(metadata, "uvicorn")
    websockets_requirements = _requirement_lines(metadata, "websockets")

    _assert_requirement_uses_compatible_range(fastapi_requirements)
    _assert_requirement_uses_compatible_range(uvicorn_requirements)
    _assert_requirement_uses_compatible_range(websockets_requirements)


def test_installed_web_profile_can_accept_websocket_connections(installed_web_profile: dict[str, Path]):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    runtime_env = _isolated_runtime_env()
    runtime_env["HOME"] = str(installed_web_profile["run_dir"])

    process = subprocess.Popen(
        [str(installed_web_profile["console_script_path"]), "serve", "--host", "127.0.0.1", "--port", str(port)],
        cwd=installed_web_profile["run_dir"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=runtime_env,
    )

    try:
        _wait_for_http_ready(f"http://127.0.0.1:{port}/", process)
        websocket_client = subprocess.run(
            [
                str(installed_web_profile["python_path"]),
                "-c",
                """
import asyncio
import json
import pathlib
import sys

import websockets

project_root = pathlib.Path(sys.argv[1]).resolve()
uri = sys.argv[2]

normalized_sys_path = set()
for entry in sys.path:
    if not entry:
        normalized_sys_path.add(str(pathlib.Path.cwd().resolve()))
    else:
        normalized_sys_path.add(str(pathlib.Path(entry).resolve()))

assert str(project_root) not in normalized_sys_path, normalized_sys_path

expected = {"type": "heartbeat", "timestamp": 123456}

async def main() -> None:
    async with websockets.connect(uri) as websocket:
        await websocket.send(json.dumps(expected))

        deadline = asyncio.get_running_loop().time() + 5.0
        while True:
            remaining = deadline - asyncio.get_running_loop().time()
            assert remaining > 0, "timed out waiting for websocket heartbeat response"

            payload = json.loads(await asyncio.wait_for(websocket.recv(), timeout=remaining))
            if payload.get("type") == "heartbeat":
                assert payload == expected, payload
                return

asyncio.run(main())
""",
                str(PROJECT_ROOT),
                f"ws://127.0.0.1:{port}/ws/terminal?cols=80&rows=24",
            ],
            cwd=installed_web_profile["run_dir"],
            capture_output=True,
            text=True,
            env=runtime_env,
        )
        assert websocket_client.returncode == 0, (
            f"installed websocket client failed with exit code {websocket_client.returncode}\n"
            f"stdout:\n{websocket_client.stdout}\n"
            f"stderr:\n{websocket_client.stderr}"
        )
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()


def test_cli_module_exits_nonzero_without_subcommand():
    result = subprocess.run(
        [sys.executable, "-m", "bamboo_ssh.cli"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "usage:" in result.stderr.lower()


def test_requirements_file_installs_project_with_full_and_dev_extras():
    requirements = REQUIREMENTS_PATH.read_text(encoding="utf-8").strip().splitlines()
    normalized_requirements = {line.strip() for line in requirements if line.strip() and not line.startswith("#")}

    assert "-e .[full,dev]" in normalized_requirements or ".[full,dev]" in normalized_requirements


def test_readme_and_setup_docs_cover_install_modes_and_python_3_12_requirement():
    for path in (README_PATH, SETUP_DOC_PATH):
        text = path.read_text(encoding="utf-8")

        assert "Python 3.12 or newer" in text
        assert "pip install bamboo-ssh" in text
        assert "bamboo-ssh[web]" in text
        assert "bamboo-ssh[full]" in text
