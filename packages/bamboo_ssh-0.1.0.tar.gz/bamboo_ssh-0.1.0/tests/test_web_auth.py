from __future__ import annotations

from fastapi.testclient import TestClient
import pytest
from starlette.websockets import WebSocketDisconnect

from bamboo_ssh.adapters.fastapi_app import create_app
from bamboo_ssh.auth.config import AuthSettings, BambooSSHConfig, save_config
from bamboo_ssh.auth.passwords import hash_password


SESSION_COOKIE_NAME = "bamboo_ssh_session"


def _write_auth_config(path) -> None:
    save_config(
        path,
        BambooSSHConfig(
            auth=AuthSettings(
                username="admin",
                password_hash=hash_password("correct horse battery staple"),
                session_secret="test-session-secret",
                enabled=True,
                session_ttl_seconds=3600,
            )
        ),
    )


def test_terminal_page_redirects_to_login_when_auth_is_enabled(tmp_path):
    config_path = tmp_path / "bamboo-ssh.toml"
    _write_auth_config(config_path)
    client = TestClient(create_app(config_path=config_path))

    response = client.get("/", follow_redirects=False)

    assert response.status_code == 303
    assert response.headers["location"] == "/login"


def test_successful_login_sets_session_cookie(tmp_path):
    config_path = tmp_path / "bamboo-ssh.toml"
    _write_auth_config(config_path)
    client = TestClient(create_app(config_path=config_path))

    response = client.post(
        "/login",
        data={"username": "admin", "password": "correct horse battery staple"},
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["location"] == "/"
    assert response.cookies.get(SESSION_COOKIE_NAME)


def test_failed_login_does_not_set_session_cookie(tmp_path):
    config_path = tmp_path / "bamboo-ssh.toml"
    _write_auth_config(config_path)
    client = TestClient(create_app(config_path=config_path))

    response = client.post(
        "/login",
        data={"username": "admin", "password": "wrong password"},
        follow_redirects=False,
    )

    assert response.status_code == 401
    assert SESSION_COOKIE_NAME not in response.cookies


def test_unauthenticated_websocket_is_rejected_before_session_start(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"
    _write_auth_config(config_path)
    client = TestClient(create_app(config_path=config_path))
    start_calls: list[object] = []

    def fail_if_started(*args, **kwargs):
        start_calls.append((args, kwargs))
        raise AssertionError("TerminalSession.start should not run for unauthenticated websocket connections")

    monkeypatch.setattr("bamboo_ssh.adapters.fastapi_app.TerminalSession.start", fail_if_started)

    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws/terminal?cols=80&rows=24"):
            pass

    assert start_calls == []


def test_authenticated_websocket_reaches_terminal_ready(tmp_path):
    config_path = tmp_path / "bamboo-ssh.toml"
    _write_auth_config(config_path)
    client = TestClient(create_app(config_path=config_path))

    login_response = client.post(
        "/login",
        data={"username": "admin", "password": "correct horse battery staple"},
        follow_redirects=False,
    )
    assert login_response.status_code == 303

    with client.websocket_connect("/ws/terminal?cols=80&rows=24") as websocket:
        assert websocket.receive_json() == {"type": "ready"}


def test_create_app_expands_user_paths_for_auth_config(tmp_path, monkeypatch):
    config_home = tmp_path / "home"
    config_path = config_home / "auth.toml"
    config_home.mkdir()
    _write_auth_config(config_path)
    monkeypatch.setenv("HOME", str(config_home))
    client = TestClient(create_app(config_path="~/auth.toml"))

    response = client.get("/", follow_redirects=False)

    assert response.status_code == 303
    assert response.headers["location"] == "/login"


def test_create_app_rejects_missing_explicit_config_path(tmp_path):
    with pytest.raises(FileNotFoundError, match="Config file not found"):
        create_app(config_path=tmp_path / "missing.toml")
