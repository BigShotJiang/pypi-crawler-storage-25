from __future__ import annotations

import os
import tomllib
from pathlib import Path

import pytest

import bamboo_ssh.auth.config as auth_config_module
from bamboo_ssh.auth.config import AuthSettings, BambooSSHConfig, ServerSettings, load_config, save_config


def _example_config() -> BambooSSHConfig:
    return BambooSSHConfig(
        server=ServerSettings(host="127.0.0.1", port=8765),
        auth=AuthSettings(
            enabled=True,
            username="admin",
            password_hash="$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash",
            session_secret="session-secret",
            session_ttl_seconds=43200,
        ),
    )


def _valid_config_text() -> str:
    return "\n".join(
        [
            "[server]",
            'host = "127.0.0.1"',
            "port = 8765",
            "",
            "[auth]",
            "enabled = true",
            'username = "admin"',
            'password_hash = "$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash"',
            'session_secret = "session-secret"',
            "session_ttl_seconds = 43200",
            "",
        ]
    )


def test_load_config_reads_single_admin_auth_settings(tmp_path):
    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text(
        _valid_config_text()
        .replace('host = "127.0.0.1"', 'host = "0.0.0.0"')
        .replace("port = 8765", "port = 9000")
        .replace("session_ttl_seconds = 43200", "session_ttl_seconds = 7200"),
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config == BambooSSHConfig(
        server=ServerSettings(host="0.0.0.0", port=9000),
        auth=AuthSettings(
            enabled=True,
            username="admin",
            password_hash="$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash",
            session_secret="session-secret",
            session_ttl_seconds=7200,
        ),
    )


@pytest.mark.parametrize(
    ("needle", "replacement", "message"),
    [
        ("port = 8765", "port = true", "server.port must be an integer"),
        ("port = 8765", "port = 0", "server.port must be between 1 and 65535"),
        ("port = 8765", "port = 65536", "server.port must be between 1 and 65535"),
        ('username = "admin"', 'username = ""', "auth.username must not be empty"),
        (
            'password_hash = "$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash"',
            'password_hash = ""',
            "auth.password_hash must not be empty",
        ),
        ('session_secret = "session-secret"', 'session_secret = ""', "auth.session_secret must not be empty"),
        ("session_ttl_seconds = 43200", "session_ttl_seconds = true", "auth.session_ttl_seconds must be an integer"),
        ("session_ttl_seconds = 43200", "session_ttl_seconds = 0", "auth.session_ttl_seconds must be positive"),
    ],
)
def test_load_config_rejects_invalid_values(tmp_path, needle, replacement, message):
    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text(_valid_config_text().replace(needle, replacement), encoding="utf-8")

    with pytest.raises(ValueError) as excinfo:
        load_config(config_path)

    assert str(excinfo.value) == message


def test_save_config_writes_toml_and_replaces_destination_atomically(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text("stale = true\n", encoding="utf-8")

    replace_calls: list[tuple[Path, Path]] = []
    real_replace = os.replace

    def tracking_replace(src: str | os.PathLike[str], dst: str | os.PathLike[str]) -> None:
        replace_calls.append((Path(src), Path(dst)))
        real_replace(src, dst)

    monkeypatch.setattr("bamboo_ssh.auth.config.os.replace", tracking_replace)

    save_config(config_path, _example_config())

    assert replace_calls
    temp_path, destination_path = replace_calls[0]
    assert destination_path == config_path
    assert temp_path.parent == config_path.parent
    assert not temp_path.exists()
    assert tomllib.loads(config_path.read_text(encoding="utf-8")) == {
        "server": {"host": "127.0.0.1", "port": 8765},
        "auth": {
            "enabled": True,
            "username": "admin",
            "password_hash": "$argon2id$v=19$m=65536,t=3,p=4$saltsalt$hashhash",
            "session_secret": "session-secret",
            "session_ttl_seconds": 43200,
        },
    }


def test_save_config_cleans_up_temp_file_when_replace_fails(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"
    config_path.write_text("stale = true\n", encoding="utf-8")
    temp_paths: list[Path] = []

    def failing_replace(src: str | os.PathLike[str], dst: str | os.PathLike[str]) -> None:
        temp_paths.append(Path(src))
        raise OSError("replace failed")

    monkeypatch.setattr("bamboo_ssh.auth.config.os.replace", failing_replace)

    with pytest.raises(OSError, match="replace failed"):
        save_config(config_path, _example_config())

    assert temp_paths
    assert not temp_paths[0].exists()
    assert not list(config_path.parent.glob(f".{config_path.name}.*.tmp"))
    assert config_path.read_text(encoding="utf-8") == "stale = true\n"


@pytest.mark.skipif(os.name != "posix", reason="POSIX-only durability behavior")
def test_save_config_fsyncs_parent_directory_after_replace_on_posix(tmp_path, monkeypatch):
    config_path = tmp_path / "bamboo-ssh.toml"
    directory_fsync_calls: list[Path] = []

    def tracking_directory_fsync(path: Path) -> None:
        directory_fsync_calls.append(path)

    monkeypatch.setattr(auth_config_module, "_fsync_parent_directory", tracking_directory_fsync)

    save_config(config_path, _example_config())

    assert directory_fsync_calls == [config_path.parent]
