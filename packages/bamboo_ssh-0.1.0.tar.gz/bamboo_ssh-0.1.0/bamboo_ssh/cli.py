from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Sequence


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="bamboo-ssh", description="Bamboo SSH command-line tools.")
    subcommands = parser.add_subparsers(dest="command", required=True)

    serve_parser = subcommands.add_parser("serve", help="Run the web terminal adapter.")
    serve_parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind")
    serve_parser.add_argument("--port", type=int, default=8765, help="Port to listen on")
    serve_parser.add_argument("--config", help="Path to the Bamboo SSH config file.")
    serve_parser.set_defaults(handler=_run_serve_command)

    _add_auth_subcommands(subcommands)

    return parser


def _run_serve(host: str, port: int, config_path: str | None = None) -> int:
    try:
        import uvicorn
        from bamboo_ssh.adapters.fastapi_app import create_app
    except ModuleNotFoundError as exc:
        if exc.name in {"fastapi", "uvicorn"}:
            raise SystemExit(
                "Web dependencies are not installed. Install with "
                '`pip install "bamboo-ssh[web]"` or `pip install "bamboo-ssh[full]"`.'
            ) from exc
        raise

    uvicorn.run(create_app(config_path=config_path), host=host, port=port)
    return 0


def _run_serve_command(args: argparse.Namespace) -> int:
    return _run_serve(args.host, args.port, _resolve_serve_config_path(args.config))


def _add_auth_subcommands(subcommands: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    auth_parser = subcommands.add_parser("auth", help="Manage standalone auth configuration.")
    auth_subcommands = auth_parser.add_subparsers(dest="auth_command", required=True)

    init_parser = auth_subcommands.add_parser("init", help="Create standalone auth configuration.")
    init_parser.add_argument("--config", help="Path to the Bamboo SSH config file.")
    init_parser.add_argument("--username", default="admin", help="Admin username to configure.")
    init_parser.set_defaults(handler=_run_auth_init_command)

    set_password_parser = auth_subcommands.add_parser("set-password", help="Replace the configured password hash.")
    set_password_parser.add_argument("--config", help="Path to the Bamboo SSH config file.")
    set_password_parser.add_argument("--username", help="Expected configured username.")
    set_password_parser.set_defaults(handler=_run_auth_set_password_command)

    show_config_path_parser = auth_subcommands.add_parser(
        "show-config-path",
        help="Print the resolved config file path.",
    )
    show_config_path_parser.add_argument("--config", help="Path to the Bamboo SSH config file.")
    show_config_path_parser.set_defaults(handler=_run_auth_show_config_path_command)


def _run_auth_init_command(args: argparse.Namespace) -> int:
    from bamboo_ssh.auth.cli import run_init

    return run_init(args)


def _run_auth_set_password_command(args: argparse.Namespace) -> int:
    from bamboo_ssh.auth.cli import run_set_password

    return run_set_password(args)


def _run_auth_show_config_path_command(args: argparse.Namespace) -> int:
    print(_resolve_auth_config_path(args.config))
    return 0


def _resolve_auth_config_path(config_path: str | None) -> Path:
    if config_path:
        return Path(config_path).expanduser().resolve()

    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        base_directory = Path(config_home)
    else:
        base_directory = Path.home() / ".config"

    return (base_directory / "bamboo-ssh" / "config.toml").expanduser().resolve()


def _resolve_serve_config_path(config_path: str | None) -> str | None:
    resolved_path = _resolve_auth_config_path(config_path)
    if config_path is not None or resolved_path.exists():
        return str(resolved_path)
    return None


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    handler = getattr(args, "handler", None)
    if handler is not None:
        return handler(args)

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
