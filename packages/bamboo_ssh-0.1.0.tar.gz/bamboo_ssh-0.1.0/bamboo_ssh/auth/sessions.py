from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
import hashlib
import hmac
import json
import math
import time

from .config import AuthSettings


@dataclass(frozen=True, slots=True)
class SessionClaims:
    username: str
    issued_at: int
    expires_at: int


def issue_session_token(settings: AuthSettings, *, now: int | float | None = None) -> str:
    issued_at = _current_timestamp(now)
    expires_at = issued_at + settings.session_ttl_seconds
    payload = {
        "username": settings.username,
        "iat": issued_at,
        "exp": expires_at,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    signature = _sign_payload(payload_bytes, settings.session_secret)
    return f"{_urlsafe_b64encode(payload_bytes)}.{_urlsafe_b64encode(signature)}"


def validate_session_token(
    token: str,
    settings: AuthSettings,
    *,
    now: int | float | None = None,
) -> SessionClaims | None:
    try:
        payload_segment, signature_segment = token.split(".", maxsplit=1)
    except ValueError:
        return None

    try:
        payload_bytes = _urlsafe_b64decode(payload_segment)
        signature = _urlsafe_b64decode(signature_segment)
    except (ValueError, binascii.Error):
        return None

    expected_signature = _sign_payload(payload_bytes, settings.session_secret)
    if not hmac.compare_digest(signature, expected_signature):
        return None

    claims = _parse_claims(payload_bytes)
    if claims is None:
        return None

    current_time = _current_timestamp(now)
    if claims.username != settings.username:
        return None
    if claims.issued_at > current_time:
        return None
    if claims.expires_at <= current_time:
        return None

    return claims


def _parse_claims(payload_bytes: bytes) -> SessionClaims | None:
    try:
        payload = json.loads(payload_bytes)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None

    if not isinstance(payload, dict):
        return None
    if set(payload) != {"username", "iat", "exp"}:
        return None

    username = payload["username"]
    issued_at = payload["iat"]
    expires_at = payload["exp"]

    if not isinstance(username, str) or not username:
        return None
    if type(issued_at) is not int or type(expires_at) is not int:
        return None
    if expires_at <= issued_at:
        return None

    return SessionClaims(username=username, issued_at=issued_at, expires_at=expires_at)


def _current_timestamp(now: int | float | None) -> int:
    if now is None:
        return int(time.time())
    if isinstance(now, float) and not math.isfinite(now):
        raise ValueError("now must be a finite timestamp")
    return int(now)


def _sign_payload(payload_bytes: bytes, session_secret: str) -> bytes:
    return hmac.new(session_secret.encode("utf-8"), payload_bytes, hashlib.sha256).digest()


def _urlsafe_b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _urlsafe_b64decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.b64decode(data + padding, altchars=b"-_", validate=True)
