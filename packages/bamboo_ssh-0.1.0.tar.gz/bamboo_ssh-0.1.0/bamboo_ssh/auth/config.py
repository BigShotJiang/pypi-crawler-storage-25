from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import tempfile
import tomllib
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class ServerSettings:
    host: str = "127.0.0.1"
    port: int = 8765

    def __post_init__(self) -> None:
        _require_string("server.host", self.host)
        _require_tcp_port("server.port", self.port)

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any] | None) -> "ServerSettings":
        section = data or {}
        host = section.get("host", "127.0.0.1")
        port = section.get("port", 8765)

        return cls(host=host, port=port)

    def to_mapping(self) -> dict[str, Any]:
        return {"host": self.host, "port": self.port}


@dataclass(frozen=True, slots=True)
class AuthSettings:
    username: str
    password_hash: str
    session_secret: str
    enabled: bool = True
    session_ttl_seconds: int = 43200

    def __post_init__(self) -> None:
        _require_bool("auth.enabled", self.enabled)
        _require_non_empty_string("auth.username", self.username)
        _require_non_empty_string("auth.password_hash", self.password_hash)
        _require_non_empty_string("auth.session_secret", self.session_secret)
        _require_positive_integer("auth.session_ttl_seconds", self.session_ttl_seconds)

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "AuthSettings":
        enabled = data.get("enabled", True)
        username = data.get("username")
        password_hash = data.get("password_hash")
        session_secret = data.get("session_secret")
        session_ttl_seconds = data.get("session_ttl_seconds", 43200)

        return cls(
            enabled=enabled,
            username=username,
            password_hash=password_hash,
            session_secret=session_secret,
            session_ttl_seconds=session_ttl_seconds,
        )

    def to_mapping(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "username": self.username,
            "password_hash": self.password_hash,
            "session_secret": self.session_secret,
            "session_ttl_seconds": self.session_ttl_seconds,
        }


@dataclass(frozen=True, slots=True)
class BambooSSHConfig:
    server: ServerSettings = field(default_factory=ServerSettings)
    auth: AuthSettings | None = None


def load_config(path: str | Path) -> BambooSSHConfig:
    config_path = Path(path)
    data = tomllib.loads(config_path.read_text(encoding="utf-8"))

    server_data = data.get("server")
    if server_data is not None and not isinstance(server_data, dict):
        raise ValueError("server section must be a table")

    auth_data = data.get("auth")
    if auth_data is not None and not isinstance(auth_data, dict):
        raise ValueError("auth section must be a table")

    return BambooSSHConfig(
        server=ServerSettings.from_mapping(server_data),
        auth=AuthSettings.from_mapping(auth_data) if auth_data is not None else None,
    )


def save_config(path: str | Path, config: BambooSSHConfig) -> None:
    config_path = Path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    serialized = _serialize_config(config)

    tmp_file = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=config_path.parent,
        prefix=f".{config_path.name}.",
        suffix=".tmp",
        delete=False,
    )
    tmp_path = Path(tmp_file.name)

    try:
        if os.name != "nt":
            os.chmod(tmp_path, 0o600)

        with tmp_file:
            tmp_file.write(serialized)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())

        os.replace(tmp_path, config_path)
        _fsync_parent_directory(config_path.parent)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise


def _serialize_config(config: BambooSSHConfig) -> str:
    sections: list[tuple[str, dict[str, Any]]] = [("server", config.server.to_mapping())]
    if config.auth is not None:
        sections.append(("auth", config.auth.to_mapping()))

    lines: list[str] = []
    for index, (name, values) in enumerate(sections):
        if index:
            lines.append("")
        lines.append(f"[{name}]")
        for key, value in values.items():
            lines.append(f"{key} = {_format_toml_value(value)}")

    lines.append("")
    return "\n".join(lines)


def _format_toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str):
        return json.dumps(value)
    raise TypeError(f"unsupported TOML value: {value!r}")


def _require_bool(field_name: str, value: Any) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{field_name} must be a boolean")
    return value


def _require_string(field_name: str, value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    return value


def _require_non_empty_string(field_name: str, value: Any) -> str:
    text = _require_string(field_name, value)
    if not text:
        raise ValueError(f"{field_name} must not be empty")
    return text


def _require_integer(field_name: str, value: Any) -> int:
    if type(value) is not int:
        raise ValueError(f"{field_name} must be an integer")
    return value


def _require_positive_integer(field_name: str, value: Any) -> int:
    integer = _require_integer(field_name, value)
    if integer <= 0:
        raise ValueError(f"{field_name} must be positive")
    return integer


def _require_tcp_port(field_name: str, value: Any) -> int:
    port = _require_integer(field_name, value)
    if not 1 <= port <= 65535:
        raise ValueError(f"{field_name} must be between 1 and 65535")
    return port


def _fsync_parent_directory(path: Path) -> None:
    if os.name != "posix":
        return

    flags = getattr(os, "O_RDONLY", 0) | getattr(os, "O_DIRECTORY", 0)
    directory_fd = os.open(path, flags)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
