from __future__ import annotations

import argparse
from dataclasses import replace
import getpass
import os
from pathlib import Path
import secrets

from .config import AuthSettings, BambooSSHConfig, load_config, save_config


def resolve_config_path(config_path: str | None) -> Path:
    if config_path:
        return Path(config_path).expanduser().resolve()

    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        base_directory = Path(config_home)
    else:
        base_directory = Path.home() / ".config"

    return (base_directory / "bamboo-ssh" / "config.toml").expanduser().resolve()


def run_init(args: argparse.Namespace) -> int:
    from .passwords import hash_password

    config_path = resolve_config_path(args.config)
    password = _prompt_password()
    existing_config = load_config(config_path) if config_path.exists() else BambooSSHConfig()
    existing_auth = existing_config.auth

    auth_settings = AuthSettings(
        enabled=True if existing_auth is None else existing_auth.enabled,
        username=args.username,
        password_hash=hash_password(password),
        session_secret=secrets.token_urlsafe(32),
        session_ttl_seconds=43200 if existing_auth is None else existing_auth.session_ttl_seconds,
    )
    save_config(config_path, BambooSSHConfig(server=existing_config.server, auth=auth_settings))
    print(config_path)
    return 0


def run_set_password(args: argparse.Namespace) -> int:
    from .passwords import hash_password

    config_path = resolve_config_path(args.config)
    if not config_path.exists():
        raise SystemExit(f"Config file not found: {config_path}")

    config = load_config(config_path)
    if config.auth is None:
        raise SystemExit(f"Config file does not contain an [auth] section: {config_path}")
    if args.username is not None and args.username != config.auth.username:
        raise SystemExit(
            f"Configured username is {config.auth.username!r}, not {args.username!r}."
        )

    password = _prompt_password()
    updated_auth = replace(config.auth, password_hash=hash_password(password))
    save_config(config_path, BambooSSHConfig(server=config.server, auth=updated_auth))
    print(config_path)
    return 0


def run_show_config_path(args: argparse.Namespace) -> int:
    print(resolve_config_path(args.config))
    return 0


def _prompt_password() -> str:
    try:
        password = getpass.getpass("Password: ")
        confirmation = getpass.getpass("Confirm password: ")
    except (EOFError, KeyboardInterrupt) as exc:
        raise SystemExit("Password prompt aborted.") from exc

    if not password:
        raise SystemExit("Password must not be empty.")
    if password != confirmation:
        raise SystemExit("Passwords did not match.")

    return password
