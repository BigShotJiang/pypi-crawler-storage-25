const statusElement = document.getElementById("status");
const connectButton = document.getElementById("connect");
const disconnectButton = document.getElementById("disconnect");
const clearButton = document.getElementById("clear");
const terminalElement = document.getElementById("terminal");

const term = new Terminal({
    cursorBlink: true,
    fontFamily: "Menlo, Consolas, monospace",
    fontSize: 14,
    theme: {
        background: "#0f172a",
        foreground: "#e2e8f0",
    },
});

const fitAddon = new FitAddon.FitAddon();
term.loadAddon(fitAddon);
term.open(terminalElement);
fitAddon.fit();
term.focus();

let socket = null;
let heartbeatTimer = null;

function setStatus(label, state, connected) {
    statusElement.textContent = label;
    statusElement.classList.toggle("online", state === "online");
    statusElement.classList.toggle("offline", state === "offline");
    statusElement.classList.toggle("pending", state === "pending");
    connectButton.disabled = connected;
    disconnectButton.disabled = !connected;
}

function sendMessage(payload) {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
        return;
    }
    socket.send(JSON.stringify(payload));
}

function handleResize() {
    fitAddon.fit();
    sendMessage({
        type: "resize",
        cols: term.cols,
        rows: term.rows,
    });
}

function startHeartbeat() {
    heartbeatTimer = window.setInterval(() => {
        sendMessage({ type: "heartbeat", timestamp: Date.now() });
    }, 10000);
}

function stopHeartbeat() {
    if (heartbeatTimer !== null) {
        window.clearInterval(heartbeatTimer);
        heartbeatTimer = null;
    }
}

function connect() {
    if (socket && socket.readyState === WebSocket.OPEN) {
        return;
    }

    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    socket = new WebSocket(`${protocol}://${window.location.host}/ws/terminal?cols=${term.cols}&rows=${term.rows}`);

    socket.addEventListener("open", () => {
        setStatus("Starting Shell", "pending", true);
        term.focus();
        term.write("\r\n[socket connected, starting shell]\r\n");
        handleResize();
        startHeartbeat();
    });

    socket.addEventListener("message", (event) => {
        const payload = JSON.parse(event.data);
        if (payload.type === "ready") {
            setStatus("Shell Ready", "online", true);
            term.write("\r\n[shell ready]\r\n");
        } else if (payload.type === "cmd" && typeof payload.data === "string") {
            term.write(payload.data);
        }
    });

    socket.addEventListener("close", (event) => {
        stopHeartbeat();
        setStatus("Disconnected", "offline", false);
        if (event.code === 1008) {
            term.write("\r\n[authentication required]\r\n");
            window.location.assign("/login");
            return;
        }
        term.write("\r\n[disconnected]\r\n");
    });

    socket.addEventListener("error", () => {
        term.write("\r\n[websocket error]\r\n");
    });
}

term.onData((data) => {
    sendMessage({ type: "cmd", data });
});

connectButton.addEventListener("click", connect);
disconnectButton.addEventListener("click", () => {
    if (socket) {
        socket.close();
    }
});
clearButton.addEventListener("click", () => {
    term.clear();
});

window.addEventListener("resize", handleResize);
window.addEventListener("beforeunload", () => {
    stopHeartbeat();
    if (socket) {
        socket.close();
    }
});

setStatus("Disconnected", "offline", false);
connect();
