from __future__ import annotations

import argparse
import asyncio
import contextlib
from html import escape
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs

import uvicorn
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, status
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles

from bamboo_ssh.core.session import TerminalSession, stream_terminal_output


SESSION_COOKIE_NAME = "bamboo_ssh_session"


def _resolve_static_dir(
    package_static_dir: Path | None = None,
    checkout_static_dir: Path | None = None,
) -> Path:
    package_root = Path(__file__).resolve().parents[1]
    candidates = (
        package_static_dir or package_root / "static",
        checkout_static_dir or package_root.parent / "static",
    )
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(f"Could not find static assets in: {', '.join(str(path) for path in candidates)}")


def _resolve_login_template(package_template_path: Path | None = None) -> Path:
    package_root = Path(__file__).resolve().parents[1]
    candidate = package_template_path or package_root / "ui" / "templates" / "login.html"
    if candidate.is_file():
        return candidate
    raise FileNotFoundError(f"Could not find login template: {candidate}")


def _load_auth_settings(config: Any | None, config_path: str | Path | None) -> Any | None:
    if config is not None:
        auth_settings = getattr(config, "auth", None)
        return auth_settings if auth_settings is not None and getattr(auth_settings, "enabled", False) else None

    if config_path is None:
        return None

    resolved_config_path = Path(config_path).expanduser().resolve()
    if not resolved_config_path.exists():
        raise FileNotFoundError(f"Config file not found: {resolved_config_path}")

    from bamboo_ssh.auth.config import load_config

    auth_settings = load_config(resolved_config_path).auth
    return auth_settings if auth_settings is not None and auth_settings.enabled else None


def _read_login_template(template_path: Path, error_message: str | None = None) -> str:
    template = template_path.read_text(encoding="utf-8")
    error_html = ""
    if error_message:
        error_html = f'<p class="login-error" role="alert">{escape(error_message)}</p>'
    return template.replace("{{ERROR_BLOCK}}", error_html)


def _parse_form_body(body: bytes) -> dict[str, str]:
    try:
        parsed = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError:
        return {}

    return {key: values[-1] if values else "" for key, values in parsed.items()}


def _validate_session_token(token: str | None, auth_settings: Any | None) -> bool:
    if auth_settings is None or not token:
        return False

    from bamboo_ssh.auth.sessions import validate_session_token

    return validate_session_token(token, auth_settings) is not None


def _is_authenticated(cookies: dict[str, str], auth_settings: Any | None) -> bool:
    if auth_settings is None:
        return True
    return _validate_session_token(cookies.get(SESSION_COOKIE_NAME), auth_settings)


def _redirect(location: str) -> RedirectResponse:
    return RedirectResponse(location, status_code=status.HTTP_303_SEE_OTHER)


def _render_login_page(template_path: Path, error_message: str | None = None, status_code: int = 200) -> HTMLResponse:
    return HTMLResponse(_read_login_template(template_path, error_message), status_code=status_code)


def _parse_positive_int(value: str | None, default: int) -> int:
    try:
        parsed = int(value or "")
    except ValueError:
        return default
    return parsed if parsed > 0 else default


def create_app(
    *,
    config: Any | None = None,
    config_path: str | Path | None = None,
    package_static_dir: Path | None = None,
    checkout_static_dir: Path | None = None,
    login_template_path: Path | None = None,
) -> FastAPI:
    static_dir = _resolve_static_dir(package_static_dir, checkout_static_dir)
    template_path = _resolve_login_template(login_template_path)
    auth_settings = _load_auth_settings(config, config_path)

    app = FastAPI(title="Python Web Terminal")
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/")
    async def index(request: Request) -> Response:
        if not _is_authenticated(request.cookies, auth_settings):
            return _redirect("/login")
        return FileResponse(static_dir / "index.html")

    @app.get("/login")
    async def login_page(request: Request) -> Response:
        if auth_settings is None or _is_authenticated(request.cookies, auth_settings):
            return _redirect("/")
        return _render_login_page(template_path)

    @app.post("/login")
    async def login(request: Request) -> Response:
        if auth_settings is None:
            return _redirect("/")

        form_data = _parse_form_body(await request.body())
        username = form_data.get("username", "")
        password = form_data.get("password", "")

        from bamboo_ssh.auth.passwords import verify_password
        from bamboo_ssh.auth.sessions import issue_session_token

        if username != auth_settings.username or not verify_password(password, auth_settings.password_hash):
            return _render_login_page(template_path, "Invalid username or password.", status.HTTP_401_UNAUTHORIZED)

        response = _redirect("/")
        response.set_cookie(
            SESSION_COOKIE_NAME,
            issue_session_token(auth_settings),
            httponly=True,
            max_age=auth_settings.session_ttl_seconds,
            path="/",
            samesite="lax",
            secure=request.url.scheme == "https",
        )
        return response

    @app.post("/logout")
    async def logout() -> RedirectResponse:
        response = _redirect("/login" if auth_settings is not None else "/")
        response.delete_cookie(SESSION_COOKIE_NAME, path="/")
        return response

    @app.websocket("/ws/terminal")
    async def terminal_socket(websocket: WebSocket) -> None:
        if not _is_authenticated(websocket.cookies, auth_settings):
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return

        await websocket.accept()

        cols = _parse_positive_int(websocket.query_params.get("cols"), 80)
        rows = _parse_positive_int(websocket.query_params.get("rows"), 24)
        command = websocket.query_params.get("command", "")

        session = TerminalSession.start(cols=cols, rows=rows, command=command)
        send_lock = asyncio.Lock()

        async def send_json(payload: dict) -> None:
            async with send_lock:
                await websocket.send_json(payload)

        reader_task = asyncio.create_task(stream_terminal_output(session, send_json))

        try:
            while True:
                payload = await websocket.receive_json()
                msg_type = payload.get("type")

                if msg_type == "cmd":
                    data = payload.get("data", "")
                    if isinstance(data, str) and data:
                        session.write(data)
                elif msg_type == "resize":
                    next_cols = _parse_positive_int(str(payload.get("cols", "")), cols)
                    next_rows = _parse_positive_int(str(payload.get("rows", "")), rows)
                    session.resize(next_cols, next_rows)
                    cols, rows = next_cols, next_rows
                elif msg_type == "heartbeat":
                    await send_json({"type": "heartbeat", "timestamp": payload.get("timestamp")})
                else:
                    await send_json({"type": "error", "data": f"unsupported message type: {msg_type}"})
        except WebSocketDisconnect:
            pass
        finally:
            session.close()
            reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await reader_task

    return app


STATIC_DIR = _resolve_static_dir()
LOGIN_TEMPLATE = _resolve_login_template()
app = create_app()


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the Python web terminal server.")
    parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind")
    parser.add_argument("--port", type=int, default=8765, help="Port to listen on")
    parser.add_argument("--config", help="Path to the Bamboo SSH config file.")
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()
    uvicorn.run(create_app(config_path=args.config), host=args.host, port=args.port)
