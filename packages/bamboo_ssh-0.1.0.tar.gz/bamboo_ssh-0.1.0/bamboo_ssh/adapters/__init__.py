"""FastAPI adapter exports."""

from .fastapi_app import app, build_arg_parser, main

__all__ = ["app", "build_arg_parser", "main"]

