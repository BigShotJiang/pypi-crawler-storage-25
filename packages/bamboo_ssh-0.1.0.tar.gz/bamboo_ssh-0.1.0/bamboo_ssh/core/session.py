from __future__ import annotations

import asyncio
import contextlib
import fcntl
import os
import pty
import shutil
import signal
import struct
import subprocess
import termios
from dataclasses import dataclass
from typing import Awaitable, Callable


SendJson = Callable[[dict], Awaitable[None]]


def _pick_shell() -> str:
    shell = os.environ.get("SHELL")
    if shell and os.path.exists(shell):
        return shell
    return shutil.which("bash") or shutil.which("sh") or "/bin/sh"


@dataclass
class TerminalSession:
    master_fd: int
    process: subprocess.Popen
    closed: bool = False

    @classmethod
    def start(cls, cols: int, rows: int, command: str = "") -> "TerminalSession":
        master_fd, slave_fd = pty.openpty()
        env = os.environ.copy()
        env["TERM"] = env.get("TERM", "xterm-256color")
        env["WEB_TERMINAL"] = "1"
        shell = _pick_shell()

        process = subprocess.Popen(
            [shell, "-l"],
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            start_new_session=True,
            env=env,
            close_fds=True,
        )
        os.close(slave_fd)

        session = cls(master_fd=master_fd, process=process)
        session.resize(cols, rows)
        if command:
            session.write(command if command.endswith("\n") else f"{command}\n")
        return session

    def write(self, data: str) -> None:
        if self.closed:
            return
        os.write(self.master_fd, data.encode())

    def resize(self, cols: int, rows: int) -> None:
        if self.closed:
            return
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, winsize)

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True

        with contextlib.suppress(ProcessLookupError):
            os.killpg(self.process.pid, signal.SIGTERM)
        with contextlib.suppress(subprocess.TimeoutExpired):
            self.process.wait(timeout=1)
        if self.process.poll() is None:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(self.process.pid, signal.SIGKILL)
        with contextlib.suppress(OSError):
            os.close(self.master_fd)


async def stream_terminal_output(session: TerminalSession, send_json: SendJson) -> None:
    loop = asyncio.get_running_loop()
    chunks: asyncio.Queue[bytes | None] = asyncio.Queue()
    ready_sent = False
    reader_installed = False

    def stop_reader() -> None:
        nonlocal reader_installed
        if not reader_installed:
            return
        with contextlib.suppress(Exception):
            loop.remove_reader(session.master_fd)
        reader_installed = False

    def on_terminal_readable() -> None:
        try:
            chunk = os.read(session.master_fd, 4096)
        except OSError:
            chunk = b""

        if chunk:
            chunks.put_nowait(chunk)
            return

        stop_reader()
        chunks.put_nowait(None)

    loop.add_reader(session.master_fd, on_terminal_readable)
    reader_installed = True

    try:
        while not session.closed:
            chunk = await chunks.get()
            if chunk is None:
                break
            if not ready_sent:
                ready_sent = True
                await send_json({"type": "ready"})
            await send_json({"type": "cmd", "data": chunk.decode(errors="replace")})
    finally:
        stop_reader()

