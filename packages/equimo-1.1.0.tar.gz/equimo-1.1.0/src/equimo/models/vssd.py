__all__ = ["Vssd"]

from typing import Callable, List, Optional, Tuple

import equinox as eqx
import jax
import jax.random as jr
from einops import reduce
from jaxtyping import Array, Float, PRNGKeyArray

from equimo.layers.activation import get_act
from equimo.layers.convolution import Stem
from equimo.layers.ffn import get_ffn
from equimo.layers.generic import BlockChunk
from equimo.layers.norm import get_norm
from equimo.models.registry import register_model
from equimo.utils import make_drop_path_schedule, to_list


@register_model("vssd")
class Vssd(eqx.Module):
    """Vision Mamba with Non-Causal State Space Duality (VSSD)[1].

    A hybrid vision architecture that combines Mamba state space models with attention
    mechanisms in a hierarchical structure. Features progressive spatial reduction
    and channel expansion through multiple stages.

    The model processes images through:
    1. Patch embedding using a stem layer
    2. Multiple stages of Mamba/Attention blocks with downsampling
    3. Global pooling and classification head

    Attributes:
        num_features: Number of features in final stage
        patch_embed: Initial patch embedding stem
        pos_drop: Positional dropout layer
        blocks: List of processing blocks with downsampling
        head: Classification head with normalization

    References:
        [1]: Shi, et al., 2024. https://arxiv.org/abs/2407.18559
    """

    num_features: int = eqx.field(static=True)

    patch_embed: eqx.Module
    pos_drop: eqx.Module
    blocks: Tuple[eqx.Module, ...]
    norm: eqx.Module
    head: eqx.Module

    def __init__(
        self,
        img_size: int,
        in_channels: int,
        *,
        key: PRNGKeyArray,
        dim: int = 64,
        d_state: int = 64,
        d_conv: int = 3,
        expand: int = 2,
        patch_size: int = 4,
        depths: List[int] = [2, 4, 12, 4],
        num_heads: List[int] = [2, 4, 8, 16],
        attentions_layers: Tuple[str | type[eqx.Module], ...]
        | str
        | type[eqx.Module] = (
            "mamba2mixer",
            "mamba2mixer",
            "mamba2mixer",
            "attention",
        ),
        act_layer: str | Callable = "gelu",
        ffn_layer: str | type[eqx.Module] = "mlp",
        norm_layer: str | type[eqx.Module] = "layernorm",
        drop_rate: float = 0.0,
        drop_path_rate: float = 0.0,
        drop_path_uniform: bool = False,
        mlp_ratio: float = 4.0,
        eps: float = 1e-5,
        num_classes: int | None = 1000,
        **kwargs,
    ):
        """Initialize VSSD model.

        Args:
            img_size: Input image size
            in_channels: Number of input channels
            key: PRNG key for initialization
            dim: Initial model dimension
            d_state: Dimension of Mamba state space
            d_conv: Kernel size for Mamba convolution
            expand: Expansion factor for attention head dimension
            patch_size: Size of image patches
            depths: Number of blocks in each stage
            num_heads: Number of attention heads in each stage
            attentions_layers: Types of attention/mixing layers per stage (names or classes)
            act_layer: Activation function (name or callable)
            ffn_layer: FFN block type (name or class)
            norm_layer: Normalization layer type (name or class)
            drop_rate: Dropout rate
            drop_path_rate: Stochastic depth rate
            drop_path_uniform: Whether to use uniform drop path rate
            mlp_ratio: MLP expansion ratio
            eps: Epsilon for normalization layers
            num_classes: Number of classification classes
            **kwargs: Additional arguments
        """
        act_layer = get_act(act_layer)
        ffn_layer = get_ffn(ffn_layer)
        norm_layer = get_norm(norm_layer)

        key_stem, key_head, *block_subkeys = jr.split(key, 2 + len(depths))

        n_chunks = len(depths)
        self.num_features = int(dim * 2 ** (n_chunks - 1))

        self.patch_embed = Stem(
            in_channels=in_channels,
            img_size=img_size,
            patch_size=patch_size,
            embed_dim=dim,
            key=key_stem,
        )
        patches_resolution = self.patch_embed.patches_resolution

        self.pos_drop = eqx.nn.Dropout(drop_rate)

        dpr = make_drop_path_schedule(drop_path_rate, depths, uniform=drop_path_uniform)

        num_heads = to_list(num_heads, n_chunks)
        attentions_layers = tuple(to_list(attentions_layers, n_chunks))
        self.blocks = tuple(
            BlockChunk(
                depth=depth,
                module="mllablock",
                module_kwargs={
                    "dim": int(dim * 2**i),
                    "input_resolution": (
                        patches_resolution[0] // (2**i),
                        patches_resolution[1] // (2**i),
                    ),
                    "num_heads": num_heads[i],
                    "head_dim": int(dim * 2**i) * expand // num_heads[i],
                    "act_layer": act_layer,
                    "use_dwc": False,
                    "attn_layer": attentions_layers[i],
                    "mlp_ratio": mlp_ratio,
                    "ffn_layer": ffn_layer,
                    "eps": eps,
                },
                downsampler="patchmerging" if (i < n_chunks - 1) else None,
                downsampler_kwargs={"dim": int(dim * 2**i)} if i < n_chunks - 1 else {},
                downsample_last=True,
                drop_path=dpr[sum(depths[:i]) : sum(depths[: i + 1])],
                key=block_subkeys[i],
            )
            for i, depth in enumerate(depths)
        )

        self.norm = norm_layer(self.num_features, eps=eps)
        self.head = (
            eqx.nn.Linear(self.num_features, num_classes, key=key_head)
            if num_classes is not None and num_classes > 0
            else eqx.nn.Identity()
        )

    def features(
        self,
        x: Float[Array, "..."],
        key: PRNGKeyArray = jr.PRNGKey(42),
        inference: Optional[bool] = None,
    ) -> Float[Array, "..."]:
        key_pd, *keys = jr.split(key, 1 + len(self.blocks))

        x = self.patch_embed(x)
        x = self.pos_drop(x, inference=inference, key=key_pd)
        for i, blk in enumerate(self.blocks):
            x = blk(x, inference=inference, key=keys[i])

        return x

    def __call__(
        self,
        x: Float[Array, "..."],
        key: PRNGKeyArray = jr.PRNGKey(42),
        inference: Optional[bool] = None,
    ) -> Float[Array, "..."]:
        """Process input image through the VSSD network.

        Args:
            x: Input image tensor
            inference: Whether to enable dropout during inference
            key: PRNG key for random operations

        Returns:
            Classification logits for each class

        The forward pass consists of:
        1. Patch embedding and optional dropout
        2. Processing through multiple stages of blocks
        3. Global average pooling
        4. Classification head
        """
        x = self.features(x, inference=inference, key=key)
        x = jax.vmap(self.norm)(x)
        x = reduce(x, "s d -> d", "mean")
        x = self.head(x)

        return x
