"""
mempalace-refresh — incremental / targeted mine for Claude Code session jsonls.

Per-file mining is done via a fresh Python subprocess that monkey-patches:
  mempalace.palace.file_already_mined   → always False (allow re-scan)
  mempalace.convo_miner.scan_convos     → return exactly one real .jsonl path

Then calls mempalace.convo_miner.mine_convos(convo_dir=<real projects dir>)
against the real tree. Result:

  • source_file metadata = real .jsonl path          (searches by path work)
  • wing = "projects" (from real projects dir name)  (matches normal mines)
  • drawer_id = hash(real_path + chunk_index)        (identical to a
      from-scratch mine)
  • collection.upsert() + stable ids means old chunks are no-op updates,
    only genuinely new content (appended to the file since last mine)
    creates new drawers. Looks identical to "always mined as it grew".

Subprocess per file isolates ChromaDB crashes to a single file.

Usage:
  mempalace-refresh                       # incremental: all changed files
  mempalace-refresh STATUS                # show per-file change status
  mempalace-refresh ONLY <uuid-substring> # mine one specific session only
  mempalace-refresh RESET                 # wipe state
  mempalace-refresh REPAIR                # `mempalace repair --yes`
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


HOME = Path.home()
PROJECTS = Path(os.environ.get("PROJECTS_DIR") or HOME / ".claude" / "projects")
PALACE = os.environ.get("MEMPALACE_PALACE") or str(HOME / ".mempalace")
STATE_FILE = HOME / ".cache" / "mempalace-refresh" / "state.json"


# Mempalace symbols we depend on. Checked at runtime so a future mempalace
# release that renames these fails loudly instead of silently no-op'ing our
# monkey-patches.
_REQUIRED_SYMBOLS = (
    ("mempalace.palace", "file_already_mined"),
    ("mempalace.convo_miner", "file_already_mined"),
    ("mempalace.convo_miner", "scan_convos"),
    ("mempalace.convo_miner", "mine_convos"),
)
# Tested against these mempalace versions. If a newer one is installed we
# warn but still run (the monkey-patches might still work). If something
# breaks, check the symbol list above and this comment.
_TESTED_VERSIONS = {"3.2.0"}

# Worker code run inside a subprocess, one per file. Uses mempalace's own
# miner against the REAL file path and REAL projects dir — no tmp/symlink
# games — so drawer metadata is identical to a normal mine.
_WORKER = """
import sys, inspect
from pathlib import Path
import mempalace, mempalace.palace, mempalace.convo_miner as cm

# ---- Guard against mempalace API drift -------------------------------------
required = [
    ("mempalace.palace", "file_already_mined", mempalace.palace, "file_already_mined"),
    ("mempalace.convo_miner", "file_already_mined", cm, "file_already_mined"),
    ("mempalace.convo_miner", "scan_convos", cm, "scan_convos"),
    ("mempalace.convo_miner", "mine_convos", cm, "mine_convos"),
]
missing = [f"{mod}.{name}" for mod, name, obj, attr in required if not hasattr(obj, attr)]
if missing:
    sys.stderr.write(
        "mempalace-refresh: mempalace API has changed — missing symbol(s): "
        + ", ".join(missing) + "\\n"
        "  This script was written for mempalace 3.2.x. Either pin mempalace\\n"
        "  to that version (pip install 'mempalace>=3.2,<4') or update the\\n"
        "  _REQUIRED_SYMBOLS list in this script to match the new API.\\n"
    )
    sys.exit(99)

# mine_convos signature must accept these named args
sig = inspect.signature(cm.mine_convos)
for needed_kw in ("convo_dir", "palace_path", "extract_mode"):
    if needed_kw not in sig.parameters:
        sys.stderr.write(
            f"mempalace-refresh: mempalace.convo_miner.mine_convos no longer\\n"
            f"  accepts the '{needed_kw}' kwarg. API changed. Script needs update.\\n"
        )
        sys.exit(99)
# ---------------------------------------------------------------------------

target_file = Path(sys.argv[1])
projects_dir = sys.argv[2]
palace_path  = sys.argv[3]

def _never_mined(*a, **kw):
    return False

cm.file_already_mined = _never_mined
mempalace.palace.file_already_mined = _never_mined
cm.scan_convos = lambda _dir: [target_file]

cm.mine_convos(
    convo_dir=projects_dir,
    palace_path=palace_path,
    extract_mode="general",
)
"""


def _check_mempalace_version() -> None:
    """Warn once at startup if installed mempalace differs from tested versions."""
    try:
        import mempalace.version as v
        installed = getattr(v, "__version__", None) or getattr(v, "VERSION", None)
    except Exception:
        installed = None
    if installed and installed not in _TESTED_VERSIONS:
        print(
            f"note: mempalace-refresh is tested on {', '.join(sorted(_TESTED_VERSIONS))}; "
            f"you have {installed}. If things misbehave, check for API changes.",
            file=sys.stderr,
        )


def load_state() -> dict:
    try:
        data = json.loads(STATE_FILE.read_text())
        if data and all(isinstance(v, int) and v < 10**9 for v in data.values()):
            return {}  # old line-count schema; treat as empty
        return data
    except (FileNotFoundError, ValueError):
        return {}


def save_state(state: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True))
    tmp.replace(STATE_FILE)


def iter_jsonls():
    if not PROJECTS.exists():
        return
    for f in PROJECTS.rglob("*.jsonl"):
        yield f


def fmt_ts(ts: float) -> str:
    if not ts:
        return "never"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def mine_one_file(jsonl: Path) -> bool:
    """Mine one real .jsonl via a subprocess. Returns True on clean exit.

    Streams mempalace's own stdout to the terminal so you can see progress
    (`[1/1] filename +N drawers`). Stderr is captured and only shown on
    failure, to avoid clobbering the screen with noisy grpc/BLAS warnings.
    """
    print()  # newline so mempalace's banner doesn't overwrite our header
    try:
        # stdout=None → inherits parent's stdout (terminal).
        # stderr=PIPE  → capture for failure reporting.
        result = subprocess.run(
            [sys.executable, "-c", _WORKER, str(jsonl), str(PROJECTS), PALACE],
            stdout=None,
            stderr=subprocess.PIPE,
            timeout=1800,  # 30 min ceiling — big sessions are slow on ARM
        )
    except subprocess.TimeoutExpired:
        print("  [timeout after 30min]")
        return False
    if result.returncode != 0:
        sig = f"signal {-result.returncode}" if result.returncode < 0 else f"exit {result.returncode}"
        tail = (result.stderr or b"").decode(errors="replace").strip().splitlines()
        # Filter out noisy warnings
        tail = [l for l in tail if not any(n in l for n in ("RuntimeWarning", "warnings.warn", "grpc pack", "BLAS"))]
        msg = " | ".join(tail[-2:]) if tail else ""
        print(f"  [FAIL/{sig}] {msg[:120]}")
        return False
    return True


def cmd_status() -> int:
    state = load_state()
    changed, upto = [], []
    for jsonl in iter_jsonls():
        try:
            mtime = os.path.getmtime(jsonl)
        except OSError:
            continue
        last = state.get(str(jsonl), 0)
        (changed if mtime > last else upto).append((jsonl.stem, last, mtime))
    if changed:
        print(f"Changed since last refresh ({len(changed)} file(s)):")
        for uuid, last, mtime in sorted(changed, key=lambda x: -x[2]):
            print(f"  [changed]    {uuid}  (last mined: {fmt_ts(last)})")
    if upto:
        print(f"\nUp-to-date: {len(upto)} file(s)")
    if not changed and not upto:
        print("No .jsonl files found under", PROJECTS)
    return 0


def cmd_reset() -> int:
    if STATE_FILE.exists():
        STATE_FILE.unlink()
    print("State wiped. Next run treats every file as fresh.")
    return 0


def cmd_repair() -> int:
    return subprocess.call(["mempalace", "--palace", PALACE, "repair", "--yes"])


def cmd_only(query: str) -> int:
    query = query.strip()
    if not query:
        print("Usage: mempalace-refresh ONLY <uuid-or-substring>")
        return 2
    matches = [f for f in iter_jsonls() if query in f.stem]
    if not matches:
        print(f"No .jsonl under {PROJECTS} matching '{query}'.")
        return 1
    if len(matches) > 1:
        print(f"'{query}' matches {len(matches)} files — be more specific:")
        for m in matches[:10]:
            print(f"  {m.stem}")
        if len(matches) > 10:
            print(f"  ...and {len(matches) - 10} more")
        return 1
    jsonl = matches[0]
    print(f"Mining only: {jsonl.stem}")
    ok = mine_one_file(jsonl)
    if ok:
        state = load_state()
        state[str(jsonl)] = os.path.getmtime(jsonl)
        save_state(state)
        print(" ok — state updated for this file only")
        return 0
    print("Mine failed — state NOT updated (will retry next run).")
    return 1


def cmd_refresh() -> int:
    state = load_state()
    changed: list[tuple[Path, float]] = []
    for jsonl in iter_jsonls():
        try:
            mtime = os.path.getmtime(jsonl)
        except OSError:
            continue
        if mtime > state.get(str(jsonl), 0):
            changed.append((jsonl, mtime))

    if not changed:
        print("Nothing new since last refresh — all caught up.")
        return 0

    # Oldest first so progress reads chronologically
    changed.sort(key=lambda x: x[1])
    total = len(changed)
    print(f"Incremental mine: {total} file(s) changed since last run\n")

    ok_count = fail_count = 0
    for i, (jsonl, mtime) in enumerate(changed, 1):
        print(f"[{i:3}/{total}] {jsonl.stem[:48]:48}", end="", flush=True)
        if mine_one_file(jsonl):
            state[str(jsonl)] = mtime
            save_state(state)  # commit per-file — survives any later crash
            ok_count += 1
            print(" ok")
        else:
            fail_count += 1
            # mine_one_file already printed the failure detail

    print(f"\n=== Done: {ok_count} mined, {fail_count} failed of {total} ===")
    if fail_count:
        print("Failed files stay 'changed' and retry on next run.")
        print("If failures persist: mempalace-refresh REPAIR  then retry.")
    return 0 if fail_count == 0 else 1


def main() -> int:
    args = sys.argv[1:]
    arg = args[0].upper() if args else ""
    # One-shot version check (prints only if mismatch)
    _check_mempalace_version()
    if arg in ("", "REFRESH"):
        return cmd_refresh()
    if arg == "STATUS":
        return cmd_status()
    if arg == "RESET":
        return cmd_reset()
    if arg == "REPAIR":
        return cmd_repair()
    if arg == "ONLY":
        return cmd_only(args[1] if len(args) > 1 else "")
    print(f"Unknown arg: {args[0]!r}  (use: STATUS | RESET | REPAIR | ONLY <id> | no-arg)")
    return 2


if __name__ == "__main__":
    sys.exit(main())
