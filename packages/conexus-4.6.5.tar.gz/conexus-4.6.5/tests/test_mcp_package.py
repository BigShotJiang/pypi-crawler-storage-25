# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tests for the nexus.mcp package split (RDR-062).

Verifies that core.py and catalog.py are importable, tools are registered
with the correct FastMCP instances, and demoted functions remain callable
but unregistered.
"""
from __future__ import annotations


def test_core_module_importable():
    """core.py exists and has a FastMCP instance."""
    from nexus.mcp.core import mcp
    assert mcp.name == "nexus"


def test_catalog_module_importable():
    """catalog.py exists and has a FastMCP instance."""
    from nexus.mcp.catalog import mcp
    assert mcp.name == "nexus-catalog"


def test_core_registered_tools():
    """25 core tools are registered with @mcp.tool()."""
    from nexus.mcp.core import mcp

    tool_names = {t.name for t in mcp._tool_manager.list_tools()}
    expected = {
        "search", "query", "store_put", "store_get", "store_list", "store_get_many",
        "memory_put", "memory_get", "memory_delete", "memory_search", "memory_consolidate",
        "scratch", "scratch_manage", "collection_list",
        "plan_save", "plan_search",
        "traverse",
        "operator_extract", "operator_rank", "operator_compare",
        "operator_summarize", "operator_generate",
        "nx_answer", "nx_tidy", "nx_enrich_beads", "nx_plan_audit",
    }
    assert expected == tool_names, f"Missing: {expected - tool_names}, Extra: {tool_names - expected}"


def test_catalog_registered_tools():
    """10 catalog tools are registered with short names (no catalog_ prefix)."""
    from nexus.mcp.catalog import mcp

    tool_names = {t.name for t in mcp._tool_manager.list_tools()}
    expected = {
        "search", "show", "list", "register",
        "update", "link", "links", "link_query",
        "resolve", "stats",
    }
    assert expected == tool_names, f"Missing: {expected - tool_names}, Extra: {tool_names - expected}"


def test_demoted_core_functions_callable():
    """Demoted core functions are importable and callable (not registered)."""
    from nexus.mcp.core import store_delete, collection_info, collection_verify
    assert callable(store_delete)
    assert callable(collection_info)
    assert callable(collection_verify)


def test_demoted_catalog_functions_callable():
    """Demoted catalog functions are importable and callable (not registered)."""
    from nexus.mcp.catalog import catalog_unlink, catalog_link_audit, catalog_link_bulk
    assert callable(catalog_unlink)
    assert callable(catalog_link_audit)
    assert callable(catalog_link_bulk)


def test_init_reexports_all():
    """__init__.py re-exports every tool and demoted function."""
    import nexus.mcp as pkg

    # Core tools
    for name in [
        "search", "query", "store_put", "store_get", "store_list", "store_get_many",
        "memory_put", "memory_get", "memory_delete", "memory_search", "memory_consolidate",
        "scratch", "scratch_manage", "collection_list",
        "plan_save", "plan_search",
        "traverse",
        "operator_extract", "operator_rank", "operator_compare",
        "operator_summarize", "operator_generate",
        "nx_answer", "nx_tidy", "nx_enrich_beads", "nx_plan_audit",
        # demoted
        "store_delete", "collection_info", "collection_verify",
    ]:
        assert hasattr(pkg, name), f"Missing re-export: {name}"

    # Catalog tools
    for name in [
        "catalog_search", "catalog_show", "catalog_list", "catalog_register",
        "catalog_update", "catalog_link", "catalog_links", "catalog_link_query",
        "catalog_resolve", "catalog_stats",
        # demoted
        "catalog_unlink", "catalog_link_audit", "catalog_link_bulk",
    ]:
        assert hasattr(pkg, name), f"Missing re-export: {name}"


def test_core_has_main():
    """core.py exposes a main() entry point."""
    from nexus.mcp.core import main
    assert callable(main)


def test_catalog_has_main():
    """catalog.py exposes a main() entry point."""
    from nexus.mcp.catalog import main
    assert callable(main)


def test_helper_moved_with_store_list():
    """_store_list_docs helper is co-located with store_list in core.py."""
    from nexus.mcp.core import _store_list_docs
    assert callable(_store_list_docs)


# ── Destructive tool safety meta-test (R3-5) ─────────────────────────────────


# Tools that perform bulk / multi-row destructive operations MUST expose a
# dry_run parameter and confirm_destructive gate. Single-row delete tools
# (memory_delete, store_delete) are exempt because they operate on a single
# explicit ID supplied by the caller — the caller already committed to the
# target. Bulk / merge operations need a preview path because the CALLER
# may not realize how many rows will be affected.
_DESTRUCTIVE_BULK_TOOLS = {
    # (module, function_name)
    ("nexus.mcp.core", "memory_consolidate"),           # merge action
    ("nexus.mcp.catalog", "catalog_link_bulk"),         # demoted but still a function
}


def test_destructive_bulk_tools_have_safety_gates():
    """Every bulk/merge destructive tool must expose dry_run + confirm_destructive.

    Regression guard for R3-5: the memory_consolidate(merge) tool was
    originally missing these parameters (caught in round 3 review).
    Any future bulk destructive tool must follow the same pattern:
    - dry_run: bool defaulting to False (opt-in preview)
    - confirm_destructive: bool defaulting to False (opt-in proceed)

    Defaults matter: a tool with dry_run=True by default would silently
    skip all writes; a tool with confirm_destructive=True by default would
    defeat the safety gate entirely.
    """
    import importlib
    import inspect

    for module_name, fn_name in _DESTRUCTIVE_BULK_TOOLS:
        module = importlib.import_module(module_name)
        fn = getattr(module, fn_name)
        sig = inspect.signature(fn)
        params = sig.parameters

        assert "dry_run" in params, (
            f"{module_name}.{fn_name} is a destructive bulk tool but has no "
            f"dry_run parameter — add one (see memory_consolidate or "
            f"catalog_link_bulk for the pattern)"
        )
        assert params["dry_run"].default is False, (
            f"{module_name}.{fn_name}.dry_run default is "
            f"{params['dry_run'].default!r} — must be False (opt-in preview)"
        )

        assert "confirm_destructive" in params, (
            f"{module_name}.{fn_name} is a destructive bulk tool but has no "
            f"confirm_destructive parameter — required to prevent "
            f"accidental multi-row deletes"
        )
        assert params["confirm_destructive"].default is False, (
            f"{module_name}.{fn_name}.confirm_destructive default is "
            f"{params['confirm_destructive'].default!r} — must be False"
        )
