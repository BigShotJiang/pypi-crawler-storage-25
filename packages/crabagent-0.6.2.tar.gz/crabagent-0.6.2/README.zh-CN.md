# 🦀 CrabAgent

> **AI 团队指挥中心** — 组建能持续学习和进化的 AI 专家团队。委派、并行、流水线，从终端或浏览器实时看板监控进度。

CrabAgent 是一个本地优先的 AI Agent 平台。从任意项目目录启动，支持 CLI/TUI/Web 三种模式。数据全在本地，API Key 加密存储，自由选择任意 LLM 提供商。

---

## 为什么选 CrabAgent

不同于其他 Agent 平台"用完即忘的临时工"，CrabAgent 的 Agent **会学习、会进化**：

| 能力 | 说明 |
|-----|------|
| **🧠 自演化 Agent** | 每次任务完成后自动提取经验教训 — 规则引擎捕捉模式，LLM 反思分析策略。用得越多越聪明。 |
| **🤖 AI 团队** | 自定义 Agent 画像，每个 Agent 可限制工具集、指定独立模型。委派、并行、流水线三种协作模式。 |
| **📊 成长追踪** | 查看每个 Agent 的统计数据：任务数、成功率、经验数、常用类别。`ctrl+space agent_stats` |
| **⏱ 定时 + 实时** | Agent 按 cron 表达式自主执行，也支持 @提及即时委派。所有 Agent 输出实时流式显示。 |
| **🦀 快照回滚** | 修改文件前自动拍照，随时回滚，不依赖 Git。 |
| **🔒 本地优先** | 数据全在本地，API Key 加密存储，零遥测。 |

---

## 快速开始

```bash
pip install 'crabagent[serve]'

crabagent init

# TUI — 交互式终端模式（支持斜杠命令）
crabagent

# Web UI
crabagent --serve          # → http://localhost:5210
                           # 默认登录：admin / xcl1989

# CLI 单次查询
crabagent "帮我整理这个目录"
crabagent -p deepseek -m deepseek-chat "写一个 Python 脚本"
```

---

## 自演化 Agent — 核心差异化

Agent 不只是执行任务，**每次执行都会学习成长**。

### 双引擎反思

```
子 Agent 完成任务
    │
    ├─ 规则引擎（即时）
    │   ├─ 迭代数过高 → "考虑将复杂任务拆分为更小的步骤"
    │   ├─ 迭代数低效 → "高效执行模式已记录"
    │   └─ 来源: rule
    │
    └─ LLM 反思（best-effort，约 1 秒）
        ├─ 分析策略：哪里有效、哪里可改进
        ├─ 任务归类：code / research / analysis / writing
        └─ 来源: llm
```

### 知识持久化

- **团队知识**：技术栈、架构决策、用户偏好 — 每次启动自动注入
- **Agent 经验**：每个 Agent 的行为模式教训 — 执行同类任务前自动加载
- **任务记录**：每次执行完整记录（成功/失败、耗时、Token 数、迭代数）

### 查看成长

```bash
# TUI 中
/agent_stats coder
# → 总任务: 23  成功率: 91%  平均耗时: 14s
# → lessons: 18 (规则: 7, LLM: 11)
# → 常用类别: code(14), analysis(4)

/memory list          # 浏览所有记忆
/memory search api    # 关键词搜索
```

---

## AI 团队

### 内置 Agent

| Agent | 角色 | 适用场景 |
|-------|------|----------|
| 🔍 Researcher | 网络调研员 | 搜索、浏览、数据采集 |
| 📊 Analyst | 数据分析师 | 对比分析、模式识别、报告生成 |
| 💻 Coder | 编程专家 | 编写、审查、调试、重构代码 |
| 📝 Writer | 内容写手 | 写作、编辑、翻译、格式化 |

### 委派方式

- `@researcher 找一下竞品价格` — @提及自动委派
- 点击工具栏 Agent 头像插入提及
- `/delegate` 命令交互式选择 Agent
- `delegate_parallel` 多 Agent 并行执行
- `run_pipeline` 串联多个 Agent 按依赖执行

### 实时监控

- 🟣 **运行中** — 实时步骤计数和计时
- 🟢 **已完成** — 耗时 / Token / 迭代次数
- 🔴 **出错** — 错误摘要
- Web 端：右侧任务看板，支持分栏结果对比

---

## 更多功能

### 🖼️ 多模态
粘贴/上传/拖拽图片到对话，自动检测模型是否支持视觉。

### 🌐 浏览器自动化
`pip install 'crabagent[browser]'` + `playwright install chromium`

```
> 打开 https://news.ycombinator.com 显示前 5 条新闻
> 在 Google 搜索 "Python async" 提取结果
```

### 🔌 MCP 客户端
连接外部 MCP 服务器（stdio + HTTP），工具自动发现并加前缀。

### 📋 定时任务
```
> 每天早上 9 点打开 Hacker News 把前 5 条新闻截图给我
> 每 30 分钟检查商品页，价格低于 500 就通知我
```

### 🦀 快照回滚
修改文件前自动拍照，`/molt rollback <id>` 即可回滚。

### 🔧 自定义插件
在 `.crabagent/tools/` 下放 `.py` 文件即可：

```python
name = "hello"
description = "向某人打招呼"
parameters = {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
requires_permission = False

def run(name: str) -> str:
    return f"你好，{name}！"
```

---

## CLI / TUI 命令

| 命令 | 说明 |
|------|------|
| `/exit`, `/quit` | 退出 |
| `/help` | 帮助 |
| `/clear` | 清空上下文 |
| `/model [name]` | 切换模型 |
| `/models` | 列出模型 |
| `/provider [cmd]` | 管理提供商 |
| `/sessions` / `/session [id]` | 列出 / 加载会话 |
| `/new` | 新会话 |
| `/agents [cmd]` | Agent 团队管理 |
| `/agent_stats <name>` | Agent 成长统计 |
| `/delegate [@agent] [task]` | 委派任务 |
| `/memory [list\|search\|clear]` | 团队记忆 |
| `/skills` / `/skill <name>` | 列出 / 查看技能 |
| `/molt [cmd]` | 快照管理 |
| `/todo [cmd]` | 待办管理 |
| `/export` | 导出 Markdown |
| `/image <path> [msg]` | 发送图片 |

---

## 配置

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `CRAB_DB_URL` | `sqlite+aiosqlite:///./crabagent.db` | 数据库地址 |
| `CRAB_JWT_SECRET` | 自动生成 | JWT 签名密钥 |
| `CRAB_SERVE_HOST` | `0.0.0.0` | 服务监听地址 |
| `CRAB_SERVE_PORT` | `5210` | 服务端口 |
| `CRAB_MAX_ITERATIONS` | `50` | Agent 最大迭代次数 |
| `CRAB_MAX_TOKENS` | `4096` | 最大响应 Token 数 |
| `CRAB_BROWSER_HEADLESS` | `true` | 浏览器无头模式 |

---

## 安装

```bash
pip install 'crabagent[serve]'          # Web UI + API
pip install 'crabagent[browser]'        # 浏览器自动化
pip install 'crabagent[dev]'            # 测试 + lint
```

```bash
# 开发模式
make install            # 构建前端 + 安装（可编辑模式）
ruff check src/ tests/  # 代码检查
ruff format src/ tests/ # 代码格式化
pytest                   # 运行测试
```

---

## 项目结构

```
CrabAgent/
├── src/crabagent/
│   ├── cli/           # CLI 入口 + TUI
│   ├── core/agent/    # Agent 循环、工具、压缩、agents
│   ├── core/mcp/      # MCP 客户端管理器
│   └── serve/         # FastAPI + API + 调度器
├── frontend/          # React SPA 前端
└── crabagent.db       # SQLite 数据库
```

---

## 协议

GNU Affero General Public License v3 (AGPLv3)，非商用可自由使用。

商用（企业内部部署、SaaS、或任何营利活动）需要另外授权，请联系作者。

详见 [LICENSE](LICENSE)。
