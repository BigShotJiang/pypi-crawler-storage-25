import time
from datetime import UTC, datetime
from typing import Any, cast

import pytest

import icechunk as ic
import zarr
from tests.conftest import Permission, get_minio_client


def mk_repo(spec_version: int | None) -> tuple[str, ic.Repository]:
    prefix = "test-repo__" + str(time.time())
    access_key_id, secret_access_key = Permission.MODIFY.keys()
    repo = ic.Repository.create(
        storage=ic.s3_storage(
            endpoint_url="http://localhost:4200",
            allow_http=True,
            force_path_style=True,
            region="us-east-1",
            bucket="testbucket",
            prefix=prefix,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
        ),
        config=ic.RepositoryConfig(inline_chunk_threshold_bytes=0),
        spec_version=spec_version,
    )
    return (prefix, repo)


@pytest.mark.filterwarnings("ignore:datetime.datetime.utcnow")
@pytest.mark.parametrize("use_async", [True, False])
async def test_expire_and_gc(use_async: bool, any_spec_version: int | None) -> None:
    prefix, repo = mk_repo(any_spec_version)

    session = repo.writable_session("main")
    store = session.store

    group = zarr.group(store=store, overwrite=True)
    array = group.create_array(
        "array",
        shape=(1000,),
        chunks=(10,),
        dtype="i4",
        fill_value=-1,
    )
    session.commit("array created")

    for i in range(20):
        session = repo.writable_session("main")
        store = session.store
        group = zarr.open_group(store=store)
        array = cast("zarr.core.array.Array[Any]", group["array"])
        array[i] = i
        session.commit(f"written coord {i}")

    old = datetime.now(UTC)

    session = repo.writable_session("main")
    store = session.store
    group = zarr.open_group(store=store)
    array = cast("zarr.core.array.Array[Any]", group["array"])
    array[999] = 0
    session.commit("written coord 999")

    client = get_minio_client()

    # repo initial snap + array creation + 20 old version + 1 new version
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/snapshots")[
                "Contents"
            ]
        )
        == 23
    )
    # 20 old chunks + 1 new
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/chunks")[
                "Contents"
            ]
        )
        == 21
    )
    # 21 commits that modify chunks
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/manifests")[
                "Contents"
            ]
        )
        == 21
    )
    # V2 repos have a transaction log for the initial snapshot
    expected_tx_logs = 23 if any_spec_version != 1 else 22
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/transactions")[
                "Contents"
            ]
        )
        == expected_tx_logs
    )

    if use_async:
        expired_snapshots = await repo.expire_snapshots_async(old)
    else:
        expired_snapshots = repo.expire_snapshots(old)
    # empty array + 20 old versions
    assert len(expired_snapshots) == 21

    def space_used() -> int:
        space = 0
        for obj in client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/snapshots")[
            "Contents"
        ]:
            space += obj["Size"]
        for obj in client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/chunks")[
            "Contents"
        ]:
            space += obj["Size"]
        for obj in client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/manifests")[
            "Contents"
        ]:
            space += obj["Size"]
        for obj in client.list_objects(
            Bucket="testbucket", Prefix=f"{prefix}/transactions"
        )["Contents"]:
            space += obj["Size"]
        return space

    space_before = space_used()

    # let's run GC using dry_run = True
    if use_async:
        gc_result = await repo.garbage_collect_async(old, dry_run=True)
    else:
        gc_result = repo.garbage_collect(old, dry_run=True)
    space_after = space_used()

    assert space_before == space_after
    # there were 21 chunks, and we need 3 alive (for indexes 0..20 and 999)
    assert gc_result.chunks_deleted == 18
    # there were 23 snapshots, we need the initial one and the latest version only
    assert gc_result.snapshots_deleted == 21
    # there were 21 manifests, we need only 1
    assert gc_result.manifests_deleted == 20
    # not implemented yet
    assert gc_result.attributes_deleted == 0
    # same number as snapshots
    assert gc_result.transaction_logs_deleted == 21

    # now let's run real GC, no dry_run.
    if use_async:
        gc_result = await repo.garbage_collect_async(old)
    else:
        gc_result = repo.garbage_collect(old)

    space_after = space_used()

    assert space_before - gc_result.bytes_deleted == space_after
    # there were 21 chunks, and we need 3 alive (for indexes 0..20 and 999)
    assert gc_result.chunks_deleted == 18
    # there were 23 snapshots, we need the initial one and the latest version only
    assert gc_result.snapshots_deleted == 21
    # there were 21 manifests, we need only 1
    assert gc_result.manifests_deleted == 20
    # not implemented yet
    assert gc_result.attributes_deleted == 0
    # same number as snapshots
    assert gc_result.transaction_logs_deleted == 21

    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/snapshots")[
                "Contents"
            ]
        )
        == 2
    )
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/chunks")[
                "Contents"
            ]
        )
        == 3
    )
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/manifests")[
                "Contents"
            ]
        )
        == 1
    )
    # V2 repos keep the initial snapshot's transaction log
    expected_remaining_tx_logs = 2 if any_spec_version != 1 else 1
    assert (
        len(
            client.list_objects(Bucket="testbucket", Prefix=f"{prefix}/transactions")[
                "Contents"
            ]
        )
        == expected_remaining_tx_logs
    )

    # we can still read the array
    session = repo.readonly_session(branch="main")
    store = session.store
    group = zarr.open_group(store=store, mode="r")
    array = cast("zarr.core.array.Array[Any]", group["array"])
    assert array[999] == 0
    for i in range(20):
        assert array[i] == i
