import json
import pickle
from collections.abc import Callable
from typing import Any, TypeVar

import hypothesis.strategies as st
import numpy as np
import pytest
from hypothesis import assume, note
from hypothesis.stateful import (
    initialize,
    invariant,
    precondition,
    rule,
    run_state_machine_as_test,
)
from packaging.version import Version

import icechunk as ic
import zarr
from icechunk import Repository, Storage, in_memory_storage
from icechunk.testing import strategies as icst
from icechunk.testing.invariants import (
    assert_list_dir_equal,
    assert_moves_sorted_by_final_path,
)
from icechunk.testing.models import ModelStore
from icechunk.testing.trees import GroupNode, valid_moves
from icechunk.testing.utils import update_paths_after_move
from zarr import Array
from zarr.core.buffer import default_buffer_prototype
from zarr.testing.stateful import ZarrHierarchyStateMachine, split_prefix_name

PROTOTYPE = default_buffer_prototype()
from zarr.testing.strategies import (
    node_names,
    np_array_and_chunks,
)

Frequency = TypeVar("Frequency", bound=Callable[..., Any])

# pytestmark = [
#     pytest.mark.filterwarnings(
#         "ignore::zarr.core.dtype.common.UnstableSpecificationWarning"
#     ),
# ]


# TODO: more before/after commit invariants?
# TODO: add "/" to self.all_groups, deleting "/" seems to be problematic
class ModifiedZarrHierarchyStateMachine(ZarrHierarchyStateMachine):
    store: ic.IcechunkStore  # Override parent class type annotation
    model: ModelStore  # Override to add move() method
    storage: ic.Storage

    def __init__(self, storage: Storage) -> None:
        self.storage = storage
        self.actor: type[Repository] = Repository
        # keep a version of icechunk module
        # this is necessary for subclasses that use multiple versions of icechunk
        # to do things like construct config types correctly
        self.ic = ic

        # Create a temporary repository with spec_version=1 in a separate storage
        # This will be replaced in init_store with the Hypothesis-sampled version
        # we need this in order to properly initialize the superclass MemoryStore
        # model
        temp_repo = Repository.create(in_memory_storage(), spec_version=1)
        temp_store = temp_repo.writable_session("main").store
        super().__init__(temp_store)
        # Replace parent's MemoryStore with our ModelStore that has move()
        self.model = ModelStore()
        self.model.spec_version = 1
        zarr.group(store=self.model)

    @initialize(spec_version=st.sampled_from([1, 2]))
    def init_store(self, spec_version: int) -> None:
        """Override parent's init_store to sample spec_version and create repository."""
        # necessary to control the order of calling. if multiple intiliazes they will be
        # called by hypothesis in a random order
        note(f"Creating repository with spec_version={spec_version}, actor={self.actor}")

        # Create repository with the drawn spec version
        if Version(self.ic.__version__).major >= 2:
            self.repo = self.actor.create(self.storage, spec_version=spec_version)
        else:
            self.repo = self.actor.create(self.storage)
        self.store = self.repo.writable_session("main").store
        self.model.spec_version = spec_version

        super().init_store()

    @precondition(
        lambda self: (
            Version(self.ic.__version__).major >= 2
            and not self.store.session.has_uncommitted_changes
            and bool(self.all_arrays)
        )
    )
    @rule(data=st.data())
    def reopen_with_config(self, data: st.DataObject) -> None:
        array_paths = data.draw(
            st.lists(st.sampled_from(sorted(self.all_arrays)), max_size=3, unique=True)
        )
        arrays = tuple(zarr.open_array(self.model, path=path) for path in array_paths)
        config = data.draw(
            icst.repository_configs(
                inline_chunk_threshold_bytes=st.just(0),
                splitting=icst.splitting_configs(arrays=arrays),
            )
        )
        note(f"reopening with config {config!r}")
        self.repo = self.actor.open(self.storage, config=config)
        if data.draw(st.booleans()):
            self.repo.save_config()
        self.store = self.repo.writable_session("main").store

    @precondition(lambda self: not self.store.session.has_uncommitted_changes)
    @rule(data=st.data())
    def rewrite_manifests(self, data: st.DataObject) -> None:
        sconfig = self.ic.ManifestSplittingConfig.from_dict(
            {
                self.ic.ManifestSplitCondition.AnyArray(): {
                    self.ic.ManifestSplitDimCondition.Any(): data.draw(
                        st.integers(min_value=1, max_value=10)
                    )
                }
            }
        )

        config = self.ic.RepositoryConfig(
            inline_chunk_threshold_bytes=0,
            manifest=self.ic.ManifestConfig(splitting=sconfig),
        )
        note(f"rewriting manifests with config {sconfig=!r}")
        self.repo = self.actor.open(self.storage, config=config)
        self.repo.rewrite_manifests(
            f"rewriting manifests with {sconfig!s}", branch="main"
        )
        if data.draw(st.booleans()):
            self.repo.save_config()
        self.store = self.repo.writable_session("main").store

    @rule(data=st.data())
    def commit_with_check(self, data: st.DataObject) -> None:
        note("committing and checking list_prefix")

        lsbefore = sorted(self._sync_iter(self.store.list_prefix("")))
        path = data.draw(st.sampled_from(lsbefore))
        get_before = self._sync(self.store.get(path, prototype=PROTOTYPE))
        assert get_before

        allow_empty = not self.store.session.has_uncommitted_changes
        if Version(self.ic.__version__).major >= 2:
            self.store.session.commit("foo", allow_empty=allow_empty)
        else:
            self.store.session.commit("foo")

        self.store = self.repo.writable_session("main").store

        lsafter = sorted(self._sync_iter(self.store.list_prefix("")))
        get_after = self._sync(self.store.get(path, prototype=PROTOTYPE))
        assert get_after

        if lsbefore != lsafter:
            lsexpect = sorted(self._sync_iter(self.model.list_prefix("")))
            raise ValueError(
                f"listing changed before ({len(lsbefore)} items) and after ({len(lsafter)} items) committing."
                f" \n\n Before : {lsbefore!r} \n\n After: {lsafter!r}, \n\n Expected: {lsexpect!r}"
            )

        get_after_cmp: Any
        get_before_cmp: Any
        # if it's metadata, we need to compare the data parsed, not raw (because of map ordering)
        if path.endswith(".json"):
            get_after_cmp = json.loads(get_after.to_bytes())
            get_before_cmp = json.loads(get_before.to_bytes())
        else:
            get_after_cmp = get_after.to_bytes()
            get_before_cmp = get_before.to_bytes()

        if get_before_cmp != get_after_cmp:
            get_expect = self._sync(self.model.get(path, prototype=PROTOTYPE))
            assert get_expect
            raise ValueError(
                f"Value changed before and after commit for path {path}"
                f" \n\n Before : {get_before_cmp!r} \n\n "
                f"After: {get_after_cmp!r}, \n\n "
                f"Expected: {get_expect.to_bytes()!r}"
            )

    @rule(dry_run=st.booleans(), delete_unused_v1_files=st.booleans())
    @precondition(lambda self: self.model.spec_version == 1)
    @precondition(lambda self: not self.store.session.has_uncommitted_changes)
    def upgrade_spec_version(self, dry_run: bool, delete_unused_v1_files: bool) -> None:
        """Upgrade repository from spec version 1 to version 2."""
        self.repo = self.ic.upgrade_icechunk_repository(
            self.repo, dry_run=dry_run, delete_unused_v1_files=delete_unused_v1_files
        )
        self.store = self.repo.writable_session("main").store
        if not dry_run:
            assert self.repo.spec_version == 2
            self.model.spec_version = 2

    @rule(data=st.data(), num_moves=st.integers(min_value=1, max_value=5))
    @precondition(lambda self: self.model.spec_version >= 2)
    @precondition(lambda self: not self.store.session.has_uncommitted_changes)
    @precondition(lambda self: bool(self.all_arrays) or bool(self.all_groups))
    def move_operations(self, data: st.DataObject, num_moves: int) -> None:
        """Perform moves in a single rearrange session, then commit or discard."""
        note(f"starting rearrange session with {num_moves} moves")
        session = self.repo.rearrange_session("main")

        # Copy model to track expected state - apply moves as we go
        pending_model = self._sync(self.model.copy())
        pending_arrays = self.all_arrays.copy()
        pending_groups = self.all_groups.copy()

        tree = GroupNode.from_paths(pending_arrays, pending_groups | {""})
        moves = data.draw(valid_moves(tree, n_moves=st.just(num_moves)))
        for source, dest in moves:
            note(f"moving {source!r} to {dest!r}")
            session.move(f"/{source}", f"/{dest}")
            self._sync(pending_model.move(source, dest))
            pending_arrays, pending_groups = update_paths_after_move(
                source, dest, pending_arrays, pending_groups
            )
            self._compare_list_dir(
                pending_model, session.store, pending_arrays | pending_groups
            )

        if data.draw(st.sampled_from([True, True, True, False])):
            note(f"committing {num_moves} moves")
            snap_before = session.snapshot_id
            self.model = pending_model
            self.all_arrays = pending_arrays
            self.all_groups = pending_groups
            self.store = session.store
            self.commit_with_check(data)
            snap_after = self.repo.lookup_branch("main")

            # Moves in the tx log must be sorted by final path
            diff = self.repo.diff(from_snapshot_id=snap_before, to_snapshot_id=snap_after)
            if diff.moved_nodes:
                assert_moves_sorted_by_final_path(diff.moved_nodes)
        else:
            note("discarding moves")
            self.store = self.repo.writable_session("main").store

    @rule(data=st.data())
    @precondition(
        lambda self: (
            Version(self.ic.__version__).major >= 2 and self.repo.spec_version >= 2
        )
    )
    @precondition(lambda self: bool(self.all_arrays))
    def shift_array(self, data: st.DataObject) -> None:
        """Shift an array's chunks by a random offset."""
        array_path = data.draw(st.sampled_from(sorted(self.all_arrays)))

        arr_model = zarr.open_array(self.model, path=array_path)
        arr_store = zarr.open_array(self.store, path=array_path)
        num_chunks = arr_model.cdata_shape
        chunks = arr_model.chunks

        # Draw offset: negative shifts left, positive shifts right
        offset = data.draw(
            st.tuples(*[st.integers(min_value=-n, max_value=n) for n in num_chunks])
        )

        # Optionally resize before shift to make room (mimics real user behavior)
        # - With resize: preserves data that would otherwise go out of bounds
        # - Without resize: data shifting beyond bounds is lost
        should_resize = data.draw(st.booleans())
        if should_resize and any(o > 0 for o in offset):
            new_shape = tuple(
                arr_model.shape[i] + max(0, offset[i]) * chunks[i]
                for i in range(len(chunks))
            )
            note(f"resizing array '{array_path}' from {arr_model.shape} to {new_shape}")
            arr_model.resize(new_shape)
            arr_store.resize(new_shape)
            num_chunks = arr_model.cdata_shape

        note(f"shifting array '{array_path}' by {offset}")
        self.store.session.shift_array(f"/{array_path}", offset)
        self._sync(self.model.shift_array(array_path, offset, num_chunks))

    @rule(
        data=st.data(),
        name=node_names,
        array_and_chunks=np_array_and_chunks(),
    )
    def add_array(
        self,
        data: st.DataObject,
        name: str,
        array_and_chunks: tuple[np.ndarray[Any, Any], tuple[int, ...]],
    ) -> None:
        array, _ = array_and_chunks
        # TODO: support size-0 arrays GH392
        assume(array.size > 0)
        super().add_array(data, name, array_and_chunks)

    def _compare_list_dir(
        self, model: ModelStore, store: ic.IcechunkStore, paths: set[str]
    ) -> None:
        """Compare list_dir results between model and store for given paths."""
        for path in paths:
            model_ls = sorted(self._sync_iter(model.list_dir(path)))
            store_ls = sorted(self._sync_iter(store.list_dir(path)))
            assert_list_dir_equal(path, model_ls, store_ls)

    @invariant()
    def check_list_dir(self) -> None:
        self._compare_list_dir(self.model, self.store, self.all_groups | self.all_arrays)

    # Override upstream delete_group_using_del to fix precondition bug:
    # upstream checks `len(self.all_groups) >= 2` but filters to only groups
    # with "/" in their path, crashing when only root-level groups remain.
    # Fix: allow deleting any group (root "" is never in all_groups).
    # TODO: remove once https://github.com/zarr-developers/zarr-python/pull/3707 is released
    # and is our minimum required version
    @precondition(lambda self: self.store.supports_deletes)
    @precondition(lambda self: bool(self.all_groups - {"", "/"}))
    @rule(data=st.data())
    def delete_group_using_del(self, data: st.DataObject) -> None:
        group_path = data.draw(
            st.sampled_from(sorted(self.all_groups - {"", "/"})),
            label="Group deletion target",
        )
        prefix, group_name = split_prefix_name(group_path)
        note(
            f"Deleting group '{group_path=!r}', {prefix=!r}, {group_name=!r} using delete"
        )
        members = zarr.open_group(store=self.model, path=group_path).members(
            max_depth=None
        )
        for _, obj in members:
            if isinstance(obj, Array):
                self.all_arrays.remove(obj.path)
            else:
                self.all_groups.remove(obj.path)
        for store in [self.store, self.model]:
            group = zarr.open_group(store=store, path=prefix)
            group[group_name]  # check that it exists
            del group[group_name]
        self.all_groups.remove(group_path)

    @rule(data=st.data())
    def reopen_repository(self, data: st.DataObject) -> None:
        # We use the Zarr's memory store as the model,
        # Since we cannot `reset_branch` on the model; we must commit here.
        if self.store.session.has_uncommitted_changes:
            self.commit_with_check(data)

        self.repo = self.actor.open(self.storage)
        self.store = self.repo.writable_session("main").store

    @rule()
    def pickle_objects(self) -> None:
        if not self.store.session.has_uncommitted_changes:
            session = self.store.session.fork()
            pickle.loads(pickle.dumps(session))

        pickle.loads(pickle.dumps(self.repo))


@pytest.mark.hypothesis
def test_zarr_hierarchy() -> None:
    def mk_test_instance_sync() -> ModifiedZarrHierarchyStateMachine:
        return ModifiedZarrHierarchyStateMachine(in_memory_storage())

    run_state_machine_as_test(mk_test_instance_sync)  # type: ignore[no-untyped-call]


def test_zarr_store() -> None:
    pytest.skip("icechunk is more strict about keys")
    # repo = Repository.create(in_memory_storage())
    # store = repo.writable_session("main").store

    # def mk_test_instance_sync() -> ZarrHierarchyStateMachine:
    #     return ZarrStoreStateMachine(store)

    # run_state_machine_as_test(
    #     mk_test_instance_sync, settings=settings(report_multiple_bugs=False)
    # )
