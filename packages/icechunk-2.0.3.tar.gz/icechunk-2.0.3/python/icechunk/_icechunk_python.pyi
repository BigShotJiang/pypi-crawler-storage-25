import abc
import datetime
from collections.abc import (
    AsyncGenerator,
    AsyncIterator,
    Callable,
    Iterable,
    Mapping,
    Sequence,
)
from enum import Enum, IntEnum
from functools import total_ordering
from typing import Any, final

import numpy as np

from icechunk.types import CommitMethod

class S3Options:
    """Options for accessing an S3-compatible storage backend"""
    def __new__(
        cls,
        region: str | None = None,
        endpoint_url: str | None = None,
        allow_http: bool = False,
        anonymous: bool = False,
        force_path_style: bool = False,
        network_stream_timeout_seconds: int | None = None,
        requester_pays: bool = False,
    ) -> S3Options:
        """
        Create a new `S3Options` object

        Parameters
        ----------
        region: str | None
            Optional, the region to use for the storage backend.
        endpoint_url: str | None
            Optional, the endpoint URL to use for the storage backend.
        allow_http: bool
            Whether to allow HTTP requests to the storage backend.
        anonymous: bool
            Whether to use anonymous credentials to the storage backend. When `True`, the s3 requests will not be signed.
        force_path_style: bool
            Whether to force use of path-style addressing for buckets.
        network_stream_timeout_seconds: int | None
            Timeout requests if no bytes can be transmitted during this period of time.
            If set to 0, timeout is disabled. Default: 60.
        requester_pays: bool
            Enable requester pays for S3 buckets
        """

    @property
    def region(self) -> str | None:
        """
        Optional region to use for the storage backend.

        Returns
        -------
        str | None
            The region configured for the storage backend.
        """
        ...

    @region.setter
    def region(self, value: str | None) -> None:
        """
        Set the region to use for the storage backend.

        Parameters
        ----------
        value: str | None
            The region to use for the storage backend.
        """
        ...

    @property
    def endpoint_url(self) -> str | None:
        """
        Optional endpoint URL for the storage backend.

        Returns
        -------
        str | None
            The endpoint URL configured for the storage backend.
        """
        ...

    @endpoint_url.setter
    def endpoint_url(self, value: str | None) -> None:
        """
        Set the endpoint URL for the storage backend.

        Parameters
        ----------
        value: str | None
            The endpoint URL to use for the storage backend.
        """
        ...

    @property
    def allow_http(self) -> bool:
        """
        Whether HTTP requests are allowed for the storage backend.

        Returns
        -------
        bool
            ``True`` when HTTP requests to the storage backend are permitted.
        """
        ...

    @allow_http.setter
    def allow_http(self, value: bool) -> None:
        """
        Set whether HTTP requests are allowed for the storage backend.

        Parameters
        ----------
        value: bool
            ``True`` to allow HTTP requests to the storage backend, ``False`` otherwise.
        """
        ...

    @property
    def anonymous(self) -> bool:
        """
        Whether to use anonymous credentials (unsigned requests).

        Returns
        -------
        bool
            ``True`` when anonymous access is configured.
        """
        ...

    @anonymous.setter
    def anonymous(self, value: bool) -> None:
        """
        Set whether to use anonymous credentials.

        Parameters
        ----------
        value: bool
            ``True`` to perform unsigned requests, ``False`` to sign requests.
        """
        ...

    @property
    def force_path_style(self) -> bool:
        """
        Whether to force path-style bucket addressing.

        Returns
        -------
        bool
            ``True`` when path-style addressing is forced.
        """
        ...

    @force_path_style.setter
    def force_path_style(self, value: bool) -> None:
        """
        Set whether to force path-style bucket addressing.

        Parameters
        ----------
        value: bool
            ``True`` to always use path-style addressing, ``False`` to allow virtual-host style.
        """
        ...

    @property
    def network_stream_timeout_seconds(self) -> int | None:
        """
        Timeout in seconds for idle network streams.

        Returns
        -------
        int | None
            The timeout duration; ``0`` disables the timeout and ``None`` uses the default.
        """
        ...

    @network_stream_timeout_seconds.setter
    def network_stream_timeout_seconds(self, value: int | None) -> None:
        """
        Set the timeout for idle network streams.

        Parameters
        ----------
        value: int | None
            Timeout duration in seconds. Use ``0`` to disable or ``None`` for the default.
        """
        ...

class ObjectStoreConfig:
    class InMemory:
        def __new__(cls) -> ObjectStoreConfig.InMemory: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class LocalFileSystem:
        def __new__(cls, path: str) -> ObjectStoreConfig.LocalFileSystem: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class S3Compatible:
        def __new__(cls, options: S3Options) -> ObjectStoreConfig.S3Compatible: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class S3:
        def __new__(cls, options: S3Options) -> ObjectStoreConfig.S3: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class Gcs:
        def __new__(
            cls, opts: Mapping[str, str] | None = None
        ) -> ObjectStoreConfig.Gcs: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class Azure:
        def __new__(
            cls, opts: Mapping[str, str] | None = None
        ) -> ObjectStoreConfig.Azure: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class Tigris:
        def __new__(cls, opts: S3Options) -> ObjectStoreConfig.Tigris: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    class Http:
        def __new__(
            cls, opts: Mapping[str, str] | None = None
        ) -> ObjectStoreConfig.Http: ...
        def __repr__(self) -> str: ...
        def __str__(self) -> str: ...
        def _repr_html_(self) -> str: ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

_AnyObjectStoreConfig = (
    ObjectStoreConfig.InMemory
    | ObjectStoreConfig.LocalFileSystem
    | ObjectStoreConfig.S3
    | ObjectStoreConfig.S3Compatible
    | ObjectStoreConfig.Gcs
    | ObjectStoreConfig.Azure
    | ObjectStoreConfig.Tigris
    | ObjectStoreConfig.Http
)

class VirtualChunkContainer:
    """A virtual chunk container is a configuration that allows Icechunk to read virtual references from a storage backend.

    Attributes
    ----------
    name: str | None
        Optional name for this container. When set, chunks can use relative ``vcc://name/path``
        locations instead of full absolute URLs.
    url_prefix: str
        The prefix of urls that will use this containers configuration for reading virtual references.
    store: ObjectStoreConfig
        The storage backend to use for the virtual chunk container.
    """

    name: str | None
    url_prefix: str
    store: ObjectStoreConfig

    def __new__(
        cls,
        url_prefix: str,
        store: _AnyObjectStoreConfig,
        name: str | None = None,
    ) -> VirtualChunkContainer:
        """
        Create a new `VirtualChunkContainer` object

        Parameters
        ----------
        url_prefix: str
            The prefix of urls that will use this containers configuration for reading virtual references.
        store: ObjectStoreConfig
            The storage backend to use for the virtual chunk container.
        name: str | None
            Optional name for this container. When set, chunks can use relative ``vcc://name/path``
            locations instead of full absolute URLs.
        """

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

class VirtualChunkSpec:
    """The specification for a virtual chunk reference."""
    @property
    def index(self) -> list[int]:
        """The chunk index, in chunk coordinates space"""
        ...
    @property
    def location(self) -> str:
        """The URL to the virtual chunk data, something like 's3://bucket/foo.nc'"""
        ...
    @property
    def offset(self) -> int:
        """The chunk offset within the pointed object, in bytes"""
        ...
    @property
    def length(self) -> int:
        """The length of the chunk in bytes"""
        ...
    @property
    def etag_checksum(self) -> str | None:
        """Optional object store e-tag for the containing object.

        Icechunk will refuse to serve data from this chunk if the etag has changed.
        """
        ...
    @property
    def last_updated_at_checksum(self) -> datetime.datetime | None:
        """Optional timestamp for the containing object.

        Icechunk will refuse to serve data from this chunk if it has been modified in object store after this time.
        """
        ...

    def __new__(
        cls,
        index: list[int],
        location: str,
        offset: int,
        length: int,
        etag_checksum: str | None = None,
        last_updated_at_checksum: datetime.datetime | None = None,
    ) -> VirtualChunkSpec: ...

class CompressionAlgorithm(Enum):
    """Enum for selecting the compression algorithm used by Icechunk to write its metadata files

    Attributes
    ----------
    Zstd: int
        The Zstd compression algorithm.
    """

    Zstd = 0

    def __new__(cls) -> CompressionAlgorithm: ...
    @staticmethod
    def default() -> CompressionAlgorithm:
        """
        The default compression algorithm used by Icechunk to write its metadata files.

        Returns
        -------
        CompressionAlgorithm
            The default compression algorithm.
        """
        ...

class CompressionConfig:
    """Configuration for how Icechunk compresses its metadata files"""

    def __new__(
        cls, algorithm: CompressionAlgorithm | None = None, level: int | None = None
    ) -> CompressionConfig:
        """
        Create a new `CompressionConfig` object

        Parameters
        ----------
        algorithm: CompressionAlgorithm | None
            The compression algorithm to use.
            Default: Zstd
        level: int | None
            The compression level to use.
            Default: 3
        """
        ...
    @property
    def algorithm(self) -> CompressionAlgorithm | None:
        """
        The compression algorithm used by Icechunk to write its metadata files.

        Returns
        -------
        CompressionAlgorithm | None
            The compression algorithm used by Icechunk to write its metadata files.
        """
        ...
    @algorithm.setter
    def algorithm(self, value: CompressionAlgorithm | None) -> None:
        """
        Set the compression algorithm used by Icechunk to write its metadata files.

        Parameters
        ----------
        value: CompressionAlgorithm | None
            The compression algorithm to use.
        """
        ...
    @property
    def level(self) -> int | None:
        """
        The compression level used by Icechunk to write its metadata files.

        Returns
        -------
        int | None
            The compression level used by Icechunk to write its metadata files.
        """
        ...
    @level.setter
    def level(self, value: int | None) -> None:
        """
        Set the compression level used by Icechunk to write its metadata files.

        Parameters
        ----------
        value: int | None
            The compression level to use.
        """
        ...
    @staticmethod
    def default() -> CompressionConfig:
        """
        The default compression configuration used by Icechunk to write its metadata files.

        Returns
        -------
        CompressionConfig
        """

class CachingConfig:
    """Configuration for how Icechunk caches its metadata files"""

    def __new__(
        cls,
        num_snapshot_nodes: int | None = None,
        num_chunk_refs: int | None = None,
        num_transaction_changes: int | None = None,
        num_bytes_attributes: int | None = None,
        num_bytes_chunks: int | None = None,
    ) -> CachingConfig:
        """
        Create a new `CachingConfig` object

        Parameters
        ----------
        num_snapshot_nodes: int | None
            The number of snapshot nodes to cache.
            Default: 500,000
        num_chunk_refs: int | None
            The number of chunk references to cache.
            Default: 15,000,000
        num_transaction_changes: int | None
            The number of transaction changes to cache.
            Default: 0
        num_bytes_attributes: int | None
            The number of bytes of attributes to cache.
            Default: 0
        num_bytes_chunks: int | None
            The number of bytes of chunks to cache.
            Default: 0
        """
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_html_(self, /) -> str: ...
    @property
    def num_snapshot_nodes(self) -> int | None:
        """
        The number of snapshot nodes to cache.

        Returns
        -------
        int | None
            The number of snapshot nodes to cache.
        """
        ...
    @num_snapshot_nodes.setter
    def num_snapshot_nodes(self, value: int | None) -> None:
        """
        Set the number of snapshot nodes to cache.

        Parameters
        ----------
        value: int | None
            The number of snapshot nodes to cache.
        """
        ...
    @property
    def num_chunk_refs(self) -> int | None:
        """
        The number of chunk references to cache.

        Returns
        -------
        int | None
            The number of chunk references to cache.
        """
        ...
    @num_chunk_refs.setter
    def num_chunk_refs(self, value: int | None) -> None:
        """
        Set the number of chunk references to cache.

        Parameters
        ----------
        value: int | None
            The number of chunk references to cache.
        """
        ...
    @property
    def num_transaction_changes(self) -> int | None:
        """
        The number of transaction changes to cache.

        Returns
        -------
        int | None
            The number of transaction changes to cache.
        """
        ...
    @num_transaction_changes.setter
    def num_transaction_changes(self, value: int | None) -> None:
        """
        Set the number of transaction changes to cache.

        Parameters
        ----------
        value: int | None
            The number of transaction changes to cache.
        """
        ...
    @property
    def num_bytes_attributes(self) -> int | None:
        """
        The number of bytes of attributes to cache.

        Returns
        -------
        int | None
            The number of bytes of attributes to cache.
        """
        ...
    @num_bytes_attributes.setter
    def num_bytes_attributes(self, value: int | None) -> None:
        """
        Set the number of bytes of attributes to cache.

        Parameters
        ----------
        value: int | None
            The number of bytes of attributes to cache.
        """
        ...
    @property
    def num_bytes_chunks(self) -> int | None:
        """
        The number of bytes of chunks to cache.

        Returns
        -------
        int | None
            The number of bytes of chunks to cache.
        """
        ...
    @num_bytes_chunks.setter
    def num_bytes_chunks(self, value: int | None) -> None:
        """
        Set the number of bytes of chunks to cache.

        Parameters
        ----------
        value: int | None
            The number of bytes of chunks to cache.
        """
        ...

class ManifestPreloadCondition:
    """Configuration for conditions under which manifests will preload on session creation"""

    @staticmethod
    def or_conditions(
        conditions: list[ManifestPreloadCondition],
    ) -> ManifestPreloadCondition:
        """Create a preload condition that matches if any of `conditions` matches"""
        ...
    @staticmethod
    def and_conditions(
        conditions: list[ManifestPreloadCondition],
    ) -> ManifestPreloadCondition:
        """Create a preload condition that matches only if all passed `conditions` match"""
        ...
    @staticmethod
    def path_matches(regex: str) -> ManifestPreloadCondition:
        """Create a preload condition that matches if the full path to the array matches the passed regex.

        Array paths are absolute, as in `/path/to/my/array`
        """
        ...
    @staticmethod
    def name_matches(regex: str) -> ManifestPreloadCondition:
        """Create a preload condition that matches if the array's name matches the passed regex.

        Example, for an array  `/model/outputs/temperature`, the following will match:
        ```
        name_matches(".*temp.*")
        ```
        """
        ...
    @staticmethod
    def num_refs(from_refs: int | None, to_refs: int | None) -> ManifestPreloadCondition:
        """Create a preload condition that matches only if the number of chunk references in the manifest is within the given range.

        from_refs is inclusive, to_refs is exclusive.
        """
        ...
    @staticmethod
    def true() -> ManifestPreloadCondition:
        """Create a preload condition that always matches any manifest"""
        ...
    @staticmethod
    def false() -> ManifestPreloadCondition:
        """Create a preload condition that never matches any manifests"""
        ...
    def __and__(self, other: ManifestPreloadCondition, /) -> ManifestPreloadCondition:
        """Create a preload condition that matches if both this condition and `other` match."""
        ...
    def __or__(self, other: ManifestPreloadCondition, /) -> ManifestPreloadCondition:
        """Create a preload condition that matches if either this condition or `other` match."""
        ...

class ManifestPreloadConfig:
    """Configuration for how Icechunk manifest preload on session creation"""

    def __new__(
        cls,
        max_total_refs: int | None = None,
        preload_if: ManifestPreloadCondition | None = None,
        max_arrays_to_scan: int | None = None,
    ) -> ManifestPreloadConfig:
        """
        Create a new `ManifestPreloadConfig` object

        Parameters
        ----------
        max_total_refs: int | None
            The maximum number of references to preload.
        preload_if: ManifestPreloadCondition | None
            The condition under which manifests will be preloaded.
        max_arrays_to_scan: int | None
            The maximum number of arrays to scan when looking for manifests to preload.
            Default is 50. Increase for repositories with many nested groups.
        """
        ...
    @property
    def max_total_refs(self) -> int | None:
        """
        The maximum number of references to preload.

        Returns
        -------
        int | None
            The maximum number of references to preload.
        """
        ...
    @max_total_refs.setter
    def max_total_refs(self, value: int | None) -> None:
        """
        Set the maximum number of references to preload.

        Parameters
        ----------
        value: int | None
            The maximum number of references to preload.
        """
        ...
    @property
    def preload_if(self) -> ManifestPreloadCondition | None:
        """
        The condition under which manifests will be preloaded.

        Returns
        -------
        ManifestPreloadCondition | None
            The condition under which manifests will be preloaded.
        """
        ...
    @preload_if.setter
    def preload_if(self, value: ManifestPreloadCondition | None) -> None:
        """
        Set the condition under which manifests will be preloaded.

        Parameters
        ----------
        value: ManifestPreloadCondition | None
            The condition under which manifests will be preloaded.
        """
        ...
    @property
    def max_arrays_to_scan(self) -> int | None:
        """
        The maximum number of arrays to scan when looking for manifests to preload.

        Returns
        -------
        int | None
            The maximum number of arrays to scan. Default is 50.
        """
        ...
    @max_arrays_to_scan.setter
    def max_arrays_to_scan(self, value: int | None) -> None:
        """
        Set the maximum number of arrays to scan when looking for manifests to preload.

        Parameters
        ----------
        value: int | None
            The maximum number of arrays to scan.
        """
        ...

class ManifestSplitCondition:
    """Configuration for conditions under which manifests will be split into splits"""

    @staticmethod
    def or_conditions(
        conditions: list[ManifestSplitCondition],
    ) -> ManifestSplitCondition:
        """Create a splitting condition that matches if any of `conditions` matches"""
        ...
    @staticmethod
    def and_conditions(
        conditions: list[ManifestSplitCondition],
    ) -> ManifestSplitCondition:
        """Create a splitting condition that matches only if all passed `conditions` match"""
        ...
    @staticmethod
    def path_matches(regex: str) -> ManifestSplitCondition:
        """Create a splitting condition that matches if the full path to the array matches the passed regex.

        Array paths are absolute, as in `/path/to/my/array`
        """
        ...
    @staticmethod
    def name_matches(regex: str) -> ManifestSplitCondition:
        """Create a splitting condition that matches if the array's name matches the passed regex.

        Example, for an array  `/model/outputs/temperature`, the following will match:
        ```
        name_matches(".*temp.*")
        ```
        """
        ...

    @staticmethod
    def AnyArray() -> ManifestSplitCondition:
        """Create a splitting condition that matches any array."""
        ...

    def __or__(self, other: ManifestSplitCondition, /) -> ManifestSplitCondition:
        """Create a splitting condition that matches if either this condition or `other` matches"""
        ...

    def __and__(self, other: ManifestSplitCondition, /) -> ManifestSplitCondition:
        """Create a splitting condition that matches if both this condition and `other` match"""
        ...

class ManifestSplitDimCondition:
    """Conditions for specifying dimensions along which to shard manifests."""
    class Axis:
        """Split along specified integer axis."""
        def __new__(cls, axis: int) -> ManifestSplitDimCondition.Axis: ...

    class DimensionName:
        """Split along specified named dimension."""
        def __new__(cls, regex: str) -> ManifestSplitDimCondition.DimensionName: ...

    class Any:
        """Split along any other unspecified dimension."""
        def __new__(cls) -> ManifestSplitDimCondition.Any: ...

type _DimSplitSize = int
type _SplitSizes = tuple[
    tuple[
        ManifestSplitCondition,
        tuple[
            tuple[
                ManifestSplitDimCondition.Axis
                | ManifestSplitDimCondition.DimensionName
                | ManifestSplitDimCondition.Any,
                _DimSplitSize,
            ],
            ...,
        ],
    ],
    ...,
]

class ManifestSplittingConfig:
    """Configuration for manifest splitting."""

    @staticmethod
    def from_dict(
        split_sizes: dict[
            ManifestSplitCondition,
            dict[
                ManifestSplitDimCondition.Axis
                | ManifestSplitDimCondition.DimensionName
                | ManifestSplitDimCondition.Any,
                int,
            ],
        ],
    ) -> ManifestSplittingConfig: ...
    def to_dict(
        self,
    ) -> dict[
        ManifestSplitCondition,
        dict[
            ManifestSplitDimCondition.Axis
            | ManifestSplitDimCondition.DimensionName
            | ManifestSplitDimCondition.Any,
            int,
        ],
    ]: ...
    def __new__(cls, split_sizes: _SplitSizes | None = None) -> ManifestSplittingConfig:
        """Configuration for how Icechunk manifests will be split.

        Parameters
        ----------
        split_sizes: tuple[tuple[ManifestSplitCondition, tuple[tuple[ManifestSplitDimCondition, int], ...]], ...]
            The configuration for how Icechunk manifests will be preloaded.

        Examples
        --------

        Split manifests for the `temperature` array, with 3 chunks per shard along the `longitude` dimension.
        >>> ManifestSplittingConfig.from_dict(
        ...     {
        ...         ManifestSplitCondition.name_matches("temperature"): {
        ...             ManifestSplitDimCondition.DimensionName("longitude"): 3
        ...         }
        ...     }
        ... )
        """
        pass

    @property
    def split_sizes(self) -> _SplitSizes:
        """
        Configuration for how Icechunk manifests will be split.

        Returns
        -------
        tuple[tuple[ManifestSplitCondition, tuple[tuple[ManifestSplitDimCondition, int], ...]], ...]
            The configuration for how Icechunk manifests will be preloaded.
        """
        ...

    @split_sizes.setter
    def split_sizes(self, value: _SplitSizes) -> None:
        """
        Set the sizes for how Icechunk manifests will be split.

        Parameters
        ----------
        value: tuple[tuple[ManifestSplitCondition, tuple[tuple[ManifestSplitDimCondition, int], ...]], ...]
            The configuration for how Icechunk manifests will be preloaded.
        """
        ...

class ManifestVirtualChunkLocationCompressionConfig:
    """Configuration for zstd dictionary-based compression of virtual chunk location URLs in manifests."""

    def __new__(
        cls,
        min_num_chunks: int | None = None,
        *,
        dictionary_max_training_samples: int | None = None,
        dictionary_max_size_bytes: int | None = None,
        compression_level: int | None = None,
    ) -> ManifestVirtualChunkLocationCompressionConfig:
        """
        Create a new `ManifestVirtualChunkLocationCompressionConfig` object

        Parameters
        ----------
        min_num_chunks: int | None
            Minimum number of virtual chunks required to enable compression. Default: 1000.
        dictionary_max_training_samples: int | None
            Maximum number of URL samples used to train the compression dictionary. Default: 100.
        dictionary_max_size_bytes: int | None
            Maximum size of the trained compression dictionary in bytes. Default: 2048.
        compression_level: int | None
            Zstd compression level. Default: 3.
        """
        ...

    @property
    def min_num_chunks(self) -> int | None: ...
    @min_num_chunks.setter
    def min_num_chunks(self, value: int | None) -> None: ...
    @property
    def dictionary_max_training_samples(self) -> int | None: ...
    @dictionary_max_training_samples.setter
    def dictionary_max_training_samples(self, value: int | None) -> None: ...
    @property
    def dictionary_max_size_bytes(self) -> int | None: ...
    @dictionary_max_size_bytes.setter
    def dictionary_max_size_bytes(self, value: int | None) -> None: ...
    @property
    def compression_level(self) -> int | None: ...
    @compression_level.setter
    def compression_level(self, value: int | None) -> None: ...

class ManifestConfig:
    """Configuration for how Icechunk manifests"""

    def __new__(
        cls,
        preload: ManifestPreloadConfig | None = None,
        splitting: ManifestSplittingConfig | None = None,
        virtual_chunk_location_compression: ManifestVirtualChunkLocationCompressionConfig
        | None = None,
    ) -> ManifestConfig:
        """
        Create a new `ManifestConfig` object

        Parameters
        ----------
        preload: ManifestPreloadConfig | None
            The configuration for how Icechunk manifests will be preloaded.
        splitting: ManifestSplittingConfig | None
            The configuration for how Icechunk manifests will be split.
        virtual_chunk_location_compression: ManifestVirtualChunkLocationCompressionConfig | None
            The configuration for zstd compression of virtual chunk location URLs.
        """
        ...
    @property
    def preload(self) -> ManifestPreloadConfig | None:
        """
        The configuration for how Icechunk manifests will be preloaded.

        Returns
        -------
        ManifestPreloadConfig | None
            The configuration for how Icechunk manifests will be preloaded.
        """
        ...
    @preload.setter
    def preload(self, value: ManifestPreloadConfig | None) -> None:
        """
        Set the configuration for how Icechunk manifests will be preloaded.

        Parameters
        ----------
        value: ManifestPreloadConfig | None
            The configuration for how Icechunk manifests will be preloaded.
        """
        ...

    @property
    def splitting(self) -> ManifestSplittingConfig | None:
        """
        The configuration for how Icechunk manifests will be split.

        Returns
        -------
        ManifestSplittingConfig | None
            The configuration for how Icechunk manifests will be split.
        """
        ...

    @splitting.setter
    def splitting(self, value: ManifestSplittingConfig | None) -> None:
        """
        Set the configuration for how Icechunk manifests will be split.

        Parameters
        ----------
        value: ManifestSplittingConfig | None
            The configuration for how Icechunk manifests will be split.
        """
        ...

    @property
    def virtual_chunk_location_compression(
        self,
    ) -> ManifestVirtualChunkLocationCompressionConfig | None:
        """
        The configuration for zstd compression of virtual chunk location URLs.

        Returns
        -------
        ManifestVirtualChunkLocationCompressionConfig | None
            The compression configuration.
        """
        ...

    @virtual_chunk_location_compression.setter
    def virtual_chunk_location_compression(
        self, value: ManifestVirtualChunkLocationCompressionConfig | None
    ) -> None:
        """
        Set the configuration for zstd compression of virtual chunk location URLs.

        Parameters
        ----------
        value: ManifestVirtualChunkLocationCompressionConfig | None
            The compression configuration.
        """
        ...

class StorageRetriesSettings:
    """Configuration for how Icechunk retries requests.

    Icechunk retries failed requests with an exponential backoff algorithm."""

    def __new__(
        cls,
        max_tries: int | None = None,
        initial_backoff_ms: int | None = None,
        max_backoff_ms: int | None = None,
    ) -> StorageRetriesSettings:
        """
        Create a new `StorageRetriesSettings` object

        Parameters
        ----------
        max_tries: int | None
            The maximum number of tries, including the initial one. Set to 1 to disable retries.
            Default: 10
        initial_backoff_ms: int | None
            The initial backoff duration in milliseconds.
            Default: 100
        max_backoff_ms: int | None
            The limit to backoff duration in milliseconds.
            Default: 180,000 (3 minutes)
        """
        ...
    @property
    def max_tries(self) -> int | None:
        """
        The maximum number of tries, including the initial one.

        Returns
        -------
        int | None
            The maximum number of tries.
        """
        ...
    @max_tries.setter
    def max_tries(self, value: int | None) -> None:
        """
        Set the maximum number of tries. Set to 1 to disable retries.

        Parameters
        ----------
        value: int | None
            The maximum number of tries
        """
        ...
    @property
    def initial_backoff_ms(self) -> int | None:
        """
        The initial backoff duration in milliseconds.

        Returns
        -------
        int | None
            The initial backoff duration in milliseconds.
        """
        ...
    @initial_backoff_ms.setter
    def initial_backoff_ms(self, value: int | None) -> None:
        """
        Set the initial backoff duration in milliseconds.

        Parameters
        ----------
        value: int | None
            The initial backoff duration in milliseconds.
        """
        ...
    @property
    def max_backoff_ms(self) -> int | None:
        """
        The maximum backoff duration in milliseconds.

        Returns
        -------
        int | None
            The maximum backoff duration in milliseconds.
        """
        ...
    @max_backoff_ms.setter
    def max_backoff_ms(self, value: int | None) -> None:
        """
        Set the maximum backoff duration in milliseconds.

        Parameters
        ----------
        value: int | None
            The maximum backoff duration in milliseconds.
        """
        ...

@final
class StorageTimeoutSettings:
    """Configuration for AWS SDK timeout settings.

    Controls connect, read, and operation timeouts for the underlying S3 client."""

    def __new__(
        cls,
        connect_timeout_ms: int | None = None,
        read_timeout_ms: int | None = None,
        operation_timeout_ms: int | None = None,
        operation_attempt_timeout_ms: int | None = None,
    ) -> StorageTimeoutSettings:
        """
        Create a new `StorageTimeoutSettings` object

        All timeouts default to None, meaning the underlying
        `AWS SDK default <https://docs.aws.amazon.com/sdk-for-rust/latest/dg/timeouts.html>`_
        is used.

        Parameters
        ----------
        connect_timeout_ms: int | None
            The timeout for establishing a connection in milliseconds.
        read_timeout_ms: int | None
            The timeout for reading a response in milliseconds.
        operation_timeout_ms: int | None
            The timeout for the entire operation (including retries) in milliseconds.
        operation_attempt_timeout_ms: int | None
            The timeout for a single attempt of an operation in milliseconds.
        """
        ...
    @property
    def connect_timeout_ms(self) -> int | None: ...
    @connect_timeout_ms.setter
    def connect_timeout_ms(self, value: int | None) -> None: ...
    @property
    def read_timeout_ms(self) -> int | None: ...
    @read_timeout_ms.setter
    def read_timeout_ms(self, value: int | None) -> None: ...
    @property
    def operation_timeout_ms(self) -> int | None: ...
    @operation_timeout_ms.setter
    def operation_timeout_ms(self, value: int | None) -> None: ...
    @property
    def operation_attempt_timeout_ms(self) -> int | None: ...
    @operation_attempt_timeout_ms.setter
    def operation_attempt_timeout_ms(self, value: int | None) -> None: ...

class StorageConcurrencySettings:
    """Configuration for how Icechunk uses its Storage instance"""

    def __new__(
        cls,
        max_concurrent_requests_for_object: int | None = None,
        ideal_concurrent_request_size: int | None = None,
    ) -> StorageConcurrencySettings:
        """
        Create a new `StorageConcurrencySettings` object

        Parameters
        ----------
        max_concurrent_requests_for_object: int | None
            The maximum number of concurrent requests for an object.
            Default: 18
        ideal_concurrent_request_size: int | None
            The ideal concurrent request size in bytes.
            Default: 12,582,912 (12 MB)
        """
        ...
    @property
    def max_concurrent_requests_for_object(self) -> int | None:
        """
        The maximum number of concurrent requests for an object.

        Returns
        -------
        int | None
            The maximum number of concurrent requests for an object.
        """
        ...
    @max_concurrent_requests_for_object.setter
    def max_concurrent_requests_for_object(self, value: int | None) -> None:
        """
        Set the maximum number of concurrent requests for an object.

        Parameters
        ----------
        value: int | None
            The maximum number of concurrent requests for an object.
        """
        ...
    @property
    def ideal_concurrent_request_size(self) -> int | None:
        """
        The ideal concurrent request size.

        Returns
        -------
        int | None
            The ideal concurrent request size.
        """
        ...
    @ideal_concurrent_request_size.setter
    def ideal_concurrent_request_size(self, value: int | None) -> None:
        """
        Set the ideal concurrent request size.

        Parameters
        ----------
        value: int | None
            The ideal concurrent request size.
        """
        ...

class StorageSettings:
    """Configuration for how Icechunk uses its Storage instance"""

    def __new__(
        cls,
        concurrency: StorageConcurrencySettings | None = None,
        retries: StorageRetriesSettings | None = None,
        unsafe_use_conditional_create: bool | None = None,
        unsafe_use_conditional_update: bool | None = None,
        unsafe_use_metadata: bool | None = None,
        storage_class: str | None = None,
        metadata_storage_class: str | None = None,
        chunks_storage_class: str | None = None,
        minimum_size_for_multipart_upload: int | None = None,
        timeouts: StorageTimeoutSettings | None = None,
    ) -> StorageSettings:
        """
        Create a new `StorageSettings` object

        Parameters
        ----------
        concurrency: StorageConcurrencySettings | None
            The configuration for how Icechunk uses its Storage instance.

        retries: StorageRetriesSettings | None
            The configuration for how Icechunk retries failed requests.

        unsafe_use_conditional_update: bool | None
            If set to False, Icechunk loses some of its consistency guarantees.
            This is only useful in object stores that don't support the feature.
            Use it at your own risk.
            Default: True

        unsafe_use_conditional_create: bool | None
            If set to False, Icechunk loses some of its consistency guarantees.
            This is only useful in object stores that don't support the feature.
            Use at your own risk.
            Default: True

        unsafe_use_metadata: bool | None
            Don't write metadata fields in Icechunk files.
            This is only useful in object stores that don't support the feature.
            Use at your own risk.
            Default: True

        storage_class: str | None
            Store all objects using this object store storage class
            If None the object store default will be used.
            Currently not supported in GCS.
            Example: STANDARD_IA

        metadata_storage_class: str | None
            Store metadata objects using this object store storage class.
            Currently not supported in GCS.
            Defaults to storage_class.

        chunks_storage_class: str | None
            Store chunk objects using this object store storage class.
            Currently not supported in GCS.
            Defaults to storage_class.

        minimum_size_for_multipart_upload: int | None
            Use object store's multipart upload for objects larger than this size in bytes.
            Default: 100 MB if None is passed.

        timeouts: StorageTimeoutSettings | None
            The configuration for AWS SDK timeout settings.
        """
        ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_html_(self, /) -> str: ...
    @property
    def concurrency(self) -> StorageConcurrencySettings | None:
        """
        The configuration for how much concurrency Icechunk store uses

        Returns
        -------
        StorageConcurrencySettings | None
            The configuration for how Icechunk uses its Storage instance.
        """

    @concurrency.setter
    def concurrency(self, value: StorageConcurrencySettings | None) -> None: ...
    @property
    def retries(self) -> StorageRetriesSettings | None:
        """
        The configuration for how Icechunk retries failed requests.

        Returns
        -------
        StorageRetriesSettings | None
            The configuration for how Icechunk retries failed requests.
        """

    @retries.setter
    def retries(self, value: StorageRetriesSettings | None) -> None: ...
    @property
    def timeouts(self) -> StorageTimeoutSettings | None:
        """
        The configuration for AWS SDK timeout settings.

        Returns
        -------
        StorageTimeoutSettings | None
            The timeout configuration.
        """

    @timeouts.setter
    def timeouts(self, value: StorageTimeoutSettings | None) -> None: ...
    @property
    def unsafe_use_conditional_update(self) -> bool | None:
        """True if Icechunk will use conditional PUT operations for updates in the object store"""
        ...

    @unsafe_use_conditional_update.setter
    def unsafe_use_conditional_update(self, value: bool) -> None: ...
    @property
    def unsafe_use_conditional_create(self) -> bool | None:
        """True if Icechunk will use conditional PUT operations for creation in the object store"""
        ...

    @unsafe_use_conditional_create.setter
    def unsafe_use_conditional_create(self, value: bool) -> None: ...
    @property
    def unsafe_use_metadata(self) -> bool | None:
        """True if Icechunk will write object metadata in the object store"""
        ...

    @unsafe_use_metadata.setter
    def unsafe_use_metadata(self, value: bool) -> None: ...
    @property
    def storage_class(self) -> str | None:
        """All objects in object store will use this storage class or the default if None"""
        ...

    @storage_class.setter
    def storage_class(self, value: str) -> None: ...
    @property
    def metadata_storage_class(self) -> str | None:
        """Metadata objects in object store will use this storage class or self.storage_class if None"""
        ...

    @metadata_storage_class.setter
    def metadata_storage_class(self, value: str) -> None: ...
    @property
    def chunks_storage_class(self) -> str | None:
        """Chunk objects in object store will use this storage class or self.storage_class if None"""
        ...

    @chunks_storage_class.setter
    def chunks_storage_class(self, value: str) -> None: ...
    @property
    def minimum_size_for_multipart_upload(self) -> int | None:
        """Use object store's multipart upload for objects larger than this size in bytes"""
        ...

    @minimum_size_for_multipart_upload.setter
    def minimum_size_for_multipart_upload(self, value: int) -> None: ...

class RepoUpdateRetryConfig:
    """Configuration for retries when updating the repo info object."""

    def __new__(
        cls,
        default: StorageRetriesSettings | None = None,
    ) -> RepoUpdateRetryConfig:
        """
        Create a new `RepoUpdateRetryConfig` object

        Parameters
        ----------
        default: StorageRetriesSettings | None
            Default retry settings for all repo update operations.
            Defaults: `max_tries`=100, `initial_backoff_ms`=50, `max_backoff_ms`=30,000
        """
        ...
    @property
    def default(self) -> StorageRetriesSettings | None: ...
    @default.setter
    def default(self, value: StorageRetriesSettings | None) -> None: ...

class RepositoryConfig:
    """Configuration for an Icechunk repository"""

    def __new__(
        cls,
        inline_chunk_threshold_bytes: int | None = None,
        get_partial_values_concurrency: int | None = None,
        compression: CompressionConfig | None = None,
        max_concurrent_requests: int | None = None,
        caching: CachingConfig | None = None,
        storage: StorageSettings | None = None,
        virtual_chunk_containers: dict[str, VirtualChunkContainer] | None = None,
        manifest: ManifestConfig | None = None,
        repo_update_retries: RepoUpdateRetryConfig | None = None,
        num_updates_per_repo_info_file: int | None = None,
    ) -> RepositoryConfig:
        """
        Create a new `RepositoryConfig` object

        Parameters
        ----------
        inline_chunk_threshold_bytes: int | None
            The maximum size of a chunk that will be stored inline in the repository.
            Default: 512
        get_partial_values_concurrency: int | None
            The number of concurrent requests to make when getting partial values from storage.
            Default: 10
        compression: CompressionConfig | None
            The compression configuration for the repository.
        max_concurrent_requests: int | None
            The maximum number of concurrent HTTP requests Icechunk will do for this repo.
            Default: 256
        caching: CachingConfig | None
            The caching configuration for the repository.
        storage: StorageSettings | None
            The storage configuration for the repository.
        virtual_chunk_containers: dict[str, VirtualChunkContainer] | None
            The virtual chunk containers for the repository.
        manifest: ManifestConfig | None
            The manifest configuration for the repository.
        repo_update_retries: RepoUpdateRetryConfig | None
            Retry configuration for repo info update operations.
        num_updates_per_repo_info_file: int | None
            Maximum number of updates stored in a single repo info file. When this
            limit is reached, a new repo info file is created. Lower values produce
            slightly smaller repo info files but require more object fetches to
            reconstruct the ops log. Default: 1000
        """
        ...
    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_html_(self, /) -> str: ...
    @staticmethod
    def default() -> RepositoryConfig:
        """Create a default repository config instance"""
        ...
    @property
    def inline_chunk_threshold_bytes(self) -> int | None:
        """
        The maximum size of a chunk that will be stored inline in the repository. Chunks larger than this size will be written to storage.
        """
        ...
    @inline_chunk_threshold_bytes.setter
    def inline_chunk_threshold_bytes(self, value: int | None) -> None:
        """
        Set the maximum size of a chunk that will be stored inline in the repository. Chunks larger than this size will be written to storage.
        """
        ...
    @property
    def get_partial_values_concurrency(self) -> int | None:
        """
        The number of concurrent requests to make when getting partial values from storage.

        Returns
        -------
        int | None
            The number of concurrent requests to make when getting partial values from storage.
        """
        ...
    @get_partial_values_concurrency.setter
    def get_partial_values_concurrency(self, value: int | None) -> None:
        """
        Set the number of concurrent requests to make when getting partial values from storage.

        Parameters
        ----------
        value: int | None
            The number of concurrent requests to make when getting partial values from storage.
        """
        ...
    @property
    def compression(self) -> CompressionConfig | None:
        """
        The compression configuration for the repository.

        Returns
        -------
        CompressionConfig | None
            The compression configuration for the repository.
        """
        ...
    @compression.setter
    def compression(self, value: CompressionConfig | None) -> None:
        """
        Set the compression configuration for the repository.

        Parameters
        ----------
        value: CompressionConfig | None
            The compression configuration for the repository.
        """
        ...
    @property
    def max_concurrent_requests(self) -> int | None:
        """
        The maximum number of concurrent HTTP requests Icechunk will do for this repo.

        Returns
        -------
        int | None
            The maximum number of concurrent HTTP requests Icechunk will do for this repo.
        """
        ...
    @max_concurrent_requests.setter
    def max_concurrent_requests(self, value: int | None) -> None:
        """
        Set the maximum number of concurrent HTTP requests Icechunk should do for this repo.

        Parameters
        ----------
        value: int | None
            The maximum allowed.
        """
        ...
    @property
    def caching(self) -> CachingConfig | None:
        """
        The caching configuration for the repository.

        Returns
        -------
        CachingConfig | None
            The caching configuration for the repository.
        """
        ...
    @caching.setter
    def caching(self, value: CachingConfig | None) -> None:
        """
        Set the caching configuration for the repository.

        Parameters
        ----------
        value: CachingConfig | None
            The caching configuration for the repository.
        """
        ...
    @property
    def storage(self) -> StorageSettings | None:
        """
        The storage configuration for the repository.

        Returns
        -------
        StorageSettings | None
            The storage configuration for the repository.
        """
        ...
    @storage.setter
    def storage(self, value: StorageSettings | None) -> None:
        """
        Set the storage configuration for the repository.

        Parameters
        ----------
        value: StorageSettings | None
            The storage configuration for the repository.
        """
        ...
    @property
    def manifest(self) -> ManifestConfig | None:
        """
        The manifest configuration for the repository.

        Returns
        -------
        ManifestConfig | None
            The manifest configuration for the repository.
        """
        ...
    @manifest.setter
    def manifest(self, value: ManifestConfig | None) -> None:
        """
        Set the manifest configuration for the repository.

        Parameters
        ----------
        value: ManifestConfig | None
            The manifest configuration for the repository.
        """
        ...
    @property
    def virtual_chunk_containers(self) -> dict[str, VirtualChunkContainer] | None:
        """
        The virtual chunk containers for the repository.

        Returns
        -------
        dict[str, VirtualChunkContainer] | None
            The virtual chunk containers for the repository.
        """
        ...
    def get_virtual_chunk_container(self, name: str) -> VirtualChunkContainer | None:
        """
        Get the virtual chunk container for the repository associated with the given name.

        Parameters
        ----------
        name: str
            The name of the virtual chunk container to get.

        Returns
        -------
        VirtualChunkContainer | None
            The virtual chunk container for the repository associated with the given name.
        """
        ...
    def set_virtual_chunk_container(self, cont: VirtualChunkContainer) -> None:
        """
        Add or update a virtual chunk container in the repository configuration.

        For named containers, the name is the identity: if a container with the
        same name already exists (even with a different url_prefix), it will be
        replaced. For unnamed containers, the url_prefix is the key.

        Parameters
        ----------
        cont: VirtualChunkContainer
            The virtual chunk container to set.
        """
        ...
    def clear_virtual_chunk_containers(self) -> None:
        """
        Clear all virtual chunk containers from the repository.
        """
        ...
    @property
    def repo_update_retries(self) -> RepoUpdateRetryConfig | None:
        """Retry configuration for repo info update operations."""
        ...
    @repo_update_retries.setter
    def repo_update_retries(self, value: RepoUpdateRetryConfig | None) -> None: ...
    @property
    def num_updates_per_repo_info_file(self) -> int | None:
        """Maximum number of updates stored in a single repo info file. When this
        limit is reached, a new repo info file is created. Lower values produce
        slightly smaller repo info files but require more object fetches to
        reconstruct the ops log. Default is 1000.
        """
        ...
    @num_updates_per_repo_info_file.setter
    def num_updates_per_repo_info_file(self, value: int | None) -> None: ...
    def merge(self, other: RepositoryConfig) -> RepositoryConfig:
        """
        Merge another RepositoryConfig with this one.

        When merging, values from the other config take precedence. For nested configs
        (compression, caching, manifest, storage), the merge is applied recursively.
        For virtual_chunk_containers, entries from the other config extend this one.

        Parameters
        ----------
        other: RepositoryConfig
            The configuration to merge with this one.

        Returns
        -------
        RepositoryConfig
            A new merged configuration.
        """
        ...

class Diff:
    """The result of comparing two snapshots"""
    def is_empty(self) -> bool:
        """
        Returns True if the diff contains no changes.
        """
        ...
    @property
    def new_groups(self) -> set[str]:
        """
        The groups that were added to the target ref.
        """
        ...
    @property
    def new_arrays(self) -> set[str]:
        """
        The arrays that were added to the target ref.
        """
        ...
    @property
    def deleted_groups(self) -> set[str]:
        """
        The groups that were deleted in the target ref.
        """
        ...
    @property
    def deleted_arrays(self) -> set[str]:
        """
        The arrays that were deleted in the target ref.
        """
        ...
    @property
    def updated_groups(self) -> set[str]:
        """
        The groups that were updated via zarr metadata in the target ref.
        """
        ...
    @property
    def updated_arrays(self) -> set[str]:
        """
        The arrays that were updated via zarr metadata in the target ref.
        """
        ...
    @property
    def updated_chunks(self) -> dict[str, list[list[int]]]:
        """
        The chunks indices that had data updated in the target ref, keyed by the path to the array.
        """
        ...
    @property
    def moved_nodes(self) -> list[tuple[str, str]]:
        """
        The list of node moves, in order of application, as tuples (from_path, to_path).
        """
        ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

class GCSummary:
    """Summarizes the results of a garbage collection operation on an icechunk repo"""
    @property
    def bytes_deleted(self) -> int:
        """
        How many bytes were deleted.
        """
        ...
    @property
    def chunks_deleted(self) -> int:
        """
        How many chunks were deleted.
        """
        ...
    @property
    def manifests_deleted(self) -> int:
        """
        How many manifests were deleted.
        """
        ...
    @property
    def snapshots_deleted(self) -> int:
        """
        How many snapshots were deleted.
        """
        ...
    @property
    def attributes_deleted(self) -> int:
        """
        How many attributes were deleted.
        """
        ...
    @property
    def transaction_logs_deleted(self) -> int:
        """
        How many transaction logs were deleted.
        """
        ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

@final
class RepoAvailability(Enum):
    """The availability status of a repository.

    Attributes
    ----------
    online: int
        The repository is fully available for reads and writes.
    read_only: int
        The repository is available for reads only.
    """

    online = 0
    read_only = 1

@final
class RepoStatus:
    """The current status of a repository."""

    availability: RepoAvailability
    set_at: datetime.datetime
    limited_availability_reason: str | None

    def __new__(
        cls,
        availability: RepoAvailability,
        set_at: datetime.datetime | None = None,
        limited_availability_reason: str | None = None,
    ) -> RepoStatus:
        """
        Create a new `RepoStatus` object

        Parameters
        ----------
        availability: RepoAvailability
            The availability status of the repository.
        set_at: datetime.datetime | None
            The time at which the status was set. Defaults to the current time.
        limited_availability_reason: str | None
            An optional reason for limited availability.
        """
        ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

@final
class Update:
    """A single entry in the repository operations log.

    Each update records an administrative action taken on the repository,
    along with when it occurred.

    Attributes
    ----------
    kind : UpdateType
        The type of operation that was performed.
    updated_at : datetime.datetime
        When the operation occurred.
    backup_path : str | None
        Path to a backup created before the operation, if any.
    """
    @property
    def kind(self) -> UpdateType: ...
    @property
    def updated_at(self) -> datetime.datetime: ...
    @property
    def backup_path(self) -> str | None: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

class UpdateType:
    """The type of operation recorded in an ``Update``.

    This is a tagged union — each variant is a nested class with its own
    fields describing what happened.
    """
    @final
    class BranchCreated(UpdateType):
        """A new branch was created."""
        @property
        def name(self) -> str: ...

    @final
    class BranchDeleted(UpdateType):
        """A branch was deleted."""
        @property
        def name(self) -> str: ...
        @property
        def previous_snap_id(self) -> str: ...

    @final
    class BranchReset(UpdateType):
        """A branch was reset to a different snapshot."""
        @property
        def name(self) -> str: ...
        @property
        def previous_snap_id(self) -> str: ...

    @final
    class CommitAmended(UpdateType):
        """A commit on a branch was amended."""
        @property
        def branch(self) -> str: ...
        @property
        def previous_snap_id(self) -> str: ...
        @property
        def new_snap_id(self) -> str: ...

    @final
    class ConfigChanged(UpdateType):
        """The repository configuration was changed."""

        ...

    @final
    class ExpirationRan(UpdateType):
        """Snapshot expiration was run."""

        ...

    @final
    class FeatureFlagChanged(UpdateType):
        """A feature flag was changed."""
        @property
        def id(self) -> int: ...
        @property
        def new_value(self) -> bool | None: ...

    @final
    class GCRan(UpdateType):
        """Garbage collection was run."""

        ...

    @final
    class MetadataChanged(UpdateType):
        """Repository metadata was changed."""

        ...

    @final
    class NewCommit(UpdateType):
        """A new commit was made on a branch."""
        @property
        def branch(self) -> str: ...
        @property
        def new_snap_id(self) -> str: ...

    @final
    class NewDetachedSnapshot(UpdateType):
        """A new detached snapshot was created."""
        @property
        def new_snap_id(self) -> str: ...

    @final
    class RepoInitialized(UpdateType):
        """The repository was initialized."""

        ...

    @final
    class RepoMigrated(UpdateType):
        """The repository was migrated to a new spec version."""
        @property
        def from_version(self) -> int: ...
        @property
        def to_version(self) -> int: ...

    @final
    class RepoStatusChanged(UpdateType):
        """The repository availability status was changed."""
        @property
        def status(self) -> RepoStatus: ...

    @final
    class TagCreated(UpdateType):
        """A new tag was created."""
        @property
        def name(self) -> str: ...

    @final
    class TagDeleted(UpdateType):
        """A tag was deleted."""
        @property
        def name(self) -> str: ...
        @property
        def previous_snap_id(self) -> str: ...

class FeatureFlag:
    @property
    def id(self) -> int: ...
    @property
    def name(self) -> str: ...
    @property
    def default_enabled(self) -> bool: ...
    @property
    def setting(self) -> bool | None: ...
    @property
    def enabled(self) -> bool: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

class ManifestFileInfo:
    """Manifest file metadata"""

    def __repr__(self, /) -> str: ...
    def __str__(self, /) -> str: ...
    def _repr_html_(self, /) -> str: ...
    @property
    def id(self) -> str:
        """The manifest id"""
        ...
    @property
    def size_bytes(self) -> int:
        """The size in bytes of the"""
        ...
    @property
    def num_chunk_refs(self) -> int:
        """The number of chunk references contained in this manifest"""
        ...

@final
@total_ordering
class SpecVersion(IntEnum):
    v1 = 1
    v2 = 2

    def __eq__(self, other: object, /) -> bool: ...
    def __lt__(self, other: object, /) -> bool: ...
    @staticmethod
    def current() -> SpecVersion: ...

class PyRepository:
    def _repr_html_(self) -> str: ...
    @classmethod
    def create(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
        spec_version: SpecVersion | int | None = None,
        check_clean_root: bool = True,
    ) -> PyRepository: ...
    @classmethod
    async def create_async(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
        spec_version: SpecVersion | int | None = None,
        check_clean_root: bool = True,
    ) -> PyRepository: ...
    @classmethod
    def open(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
    ) -> PyRepository: ...
    @classmethod
    async def open_async(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
    ) -> PyRepository: ...
    @classmethod
    def open_or_create(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
        create_version: SpecVersion | int | None = None,
        check_clean_root: bool = True,
    ) -> PyRepository: ...
    @classmethod
    async def open_or_create_async(
        cls,
        storage: Storage,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = None,
        create_version: SpecVersion | int | None = None,
        check_clean_root: bool = True,
    ) -> PyRepository: ...
    @staticmethod
    def exists(
        storage: Storage, storage_settings: StorageSettings | None = None
    ) -> bool: ...
    @staticmethod
    async def exists_async(
        storage: Storage, storage_settings: StorageSettings | None = None
    ) -> bool: ...
    @staticmethod
    def fetch_spec_version(
        storage: Storage, storage_settings: StorageSettings | None = None
    ) -> SpecVersion | None: ...
    @staticmethod
    async def fetch_spec_version_async(
        storage: Storage, storage_settings: StorageSettings | None = None
    ) -> SpecVersion | None: ...
    @classmethod
    def from_bytes(cls, bytes: bytes) -> PyRepository: ...
    def as_bytes(self) -> bytes: ...
    @staticmethod
    def fetch_config(storage: Storage) -> RepositoryConfig | None: ...
    @staticmethod
    async def fetch_config_async(storage: Storage) -> RepositoryConfig | None: ...
    def save_config(self) -> None: ...
    async def save_config_async(self) -> None: ...
    def config(self) -> RepositoryConfig: ...
    def storage_settings(self) -> StorageSettings: ...
    def storage(self) -> Storage: ...
    @property
    def authorized_virtual_container_prefixes(self) -> set[str]: ...
    def reopen(
        self,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = ...,
    ) -> PyRepository: ...
    async def reopen_async(
        self,
        *,
        config: RepositoryConfig | None = None,
        authorize_virtual_chunk_access: dict[str, _AnyCredential | None] | None = ...,
    ) -> PyRepository: ...
    def set_default_commit_metadata(self, metadata: dict[str, Any]) -> None: ...
    def default_commit_metadata(self) -> dict[str, Any]: ...
    def get_metadata(self) -> dict[str, Any]: ...
    async def get_metadata_async(self) -> dict[str, Any]: ...
    def set_metadata(self, metadata: dict[str, Any]) -> None: ...
    async def set_metadata_async(self, metadata: dict[str, Any]) -> None: ...
    def update_metadata(self, metadata: dict[str, Any]) -> dict[str, Any]: ...
    async def update_metadata_async(self, metadata: dict[str, Any]) -> dict[str, Any]: ...
    def get_status(self) -> RepoStatus: ...
    async def get_status_async(self) -> RepoStatus: ...
    def set_status(self, status: RepoStatus) -> None: ...
    async def set_status_async(self, status: RepoStatus) -> None: ...
    def feature_flags(self) -> list[FeatureFlag]: ...
    async def feature_flags_async(self) -> list[FeatureFlag]: ...
    def enabled_feature_flags(self) -> list[FeatureFlag]: ...
    async def enabled_feature_flags_async(self) -> list[FeatureFlag]: ...
    def disabled_feature_flags(self) -> list[FeatureFlag]: ...
    async def disabled_feature_flags_async(self) -> list[FeatureFlag]: ...
    def set_feature_flag(self, name: str, setting: bool | None) -> None: ...
    async def set_feature_flag_async(self, name: str, setting: bool | None) -> None: ...
    def async_ancestry(
        self,
        *,
        branch: str | None = None,
        tag: str | None = None,
        snapshot_id: str | None = None,
    ) -> AsyncIterator[SnapshotInfo]: ...
    def ancestry_graph(
        self,
        *,
        branch: str | None = None,
        tag: str | None = None,
        snapshot_id: str | None = None,
        plain: bool = False,
    ) -> AncestryGraph: ...
    async def ancestry_graph_async(
        self,
        *,
        branch: str | None = None,
        tag: str | None = None,
        snapshot_id: str | None = None,
        plain: bool = False,
    ) -> AncestryGraph: ...
    def async_ops_log(self) -> AsyncIterator[Update]: ...
    def create_branch(self, branch_name: str, snapshot_id: str) -> None: ...
    async def create_branch_async(self, branch_name: str, snapshot_id: str) -> None: ...
    def list_branches(self) -> set[str]: ...
    async def list_branches_async(self) -> set[str]: ...
    def lookup_branch(self, branch_name: str) -> str: ...
    async def lookup_branch_async(self, branch_name: str) -> str: ...
    def lookup_snapshot(self, snapshot_id: str) -> SnapshotInfo: ...
    async def lookup_snapshot_async(self, snapshot_id: str) -> SnapshotInfo: ...
    def list_manifest_files(self, snapshot_id: str) -> list[ManifestFileInfo]: ...
    async def list_manifest_files_async(
        self, snapshot_id: str
    ) -> list[ManifestFileInfo]: ...
    def reset_branch(
        self, branch_name: str, to_snapshot_id: str, from_snapshot_id: str | None
    ) -> None: ...
    async def reset_branch_async(
        self, branch_name: str, to_snapshot_id: str, from_snapshot_id: str | None
    ) -> None: ...
    def delete_branch(self, branch: str) -> None: ...
    async def delete_branch_async(self, branch: str) -> None: ...
    def delete_tag(self, tag: str) -> None: ...
    async def delete_tag_async(self, tag: str) -> None: ...
    def create_tag(self, tag_name: str, snapshot_id: str) -> None: ...
    async def create_tag_async(self, tag_name: str, snapshot_id: str) -> None: ...
    def list_tags(self) -> set[str]: ...
    async def list_tags_async(self) -> set[str]: ...
    def lookup_tag(self, tag: str) -> str: ...
    async def lookup_tag_async(self, tag: str) -> str: ...
    def diff(
        self,
        *,
        from_branch: str | None = None,
        from_tag: str | None = None,
        from_snapshot_id: str | None = None,
        to_branch: str | None = None,
        to_tag: str | None = None,
        to_snapshot_id: str | None = None,
    ) -> Diff: ...
    async def diff_async(
        self,
        *,
        from_branch: str | None = None,
        from_tag: str | None = None,
        from_snapshot_id: str | None = None,
        to_branch: str | None = None,
        to_tag: str | None = None,
        to_snapshot_id: str | None = None,
    ) -> Diff: ...
    def readonly_session(
        self,
        *,
        branch: str | None = None,
        tag: str | None = None,
        snapshot_id: str | None = None,
        as_of: datetime.datetime | None = None,
    ) -> PySession: ...
    async def readonly_session_async(
        self,
        *,
        branch: str | None = None,
        tag: str | None = None,
        snapshot_id: str | None = None,
        as_of: datetime.datetime | None = None,
    ) -> PySession: ...
    def writable_session(self, branch: str) -> PySession: ...
    async def writable_session_async(self, branch: str) -> PySession: ...
    def rearrange_session(self, branch: str) -> PySession: ...
    async def rearrange_session_async(self, branch: str) -> PySession: ...
    def expire_snapshots(
        self,
        older_than: datetime.datetime,
        *,
        delete_expired_branches: bool = False,
        delete_expired_tags: bool = False,
    ) -> set[str]: ...
    async def expire_snapshots_async(
        self,
        older_than: datetime.datetime,
        *,
        delete_expired_branches: bool = False,
        delete_expired_tags: bool = False,
    ) -> set[str]: ...
    def rewrite_manifests(
        self,
        message: str,
        *,
        branch: str,
        metadata: dict[str, Any] | None = None,
        commit_method: CommitMethod = "new_commit",
    ) -> str: ...
    async def rewrite_manifests_async(
        self,
        message: str,
        *,
        branch: str,
        metadata: dict[str, Any] | None = None,
        commit_method: CommitMethod = "new_commit",
    ) -> str: ...
    def garbage_collect(
        self,
        delete_object_older_than: datetime.datetime,
        *,
        dry_run: bool = False,
        max_snapshots_in_memory: int = 50,
        max_compressed_manifest_mem_bytes: int = 512 * 1024 * 1024,
        max_concurrent_manifest_fetches: int = 500,
    ) -> GCSummary: ...
    async def garbage_collect_async(
        self,
        delete_object_older_than: datetime.datetime,
        *,
        dry_run: bool = False,
        max_snapshots_in_memory: int = 50,
        max_compressed_manifest_mem_bytes: int = 512 * 1024 * 1024,
        max_concurrent_manifest_fetches: int = 500,
    ) -> GCSummary: ...
    def chunk_storage_stats(
        self,
        *,
        max_snapshots_in_memory: int = 50,
        max_compressed_manifest_mem_bytes: int = 512 * 1024 * 1024,
        max_concurrent_manifest_fetches: int = 500,
    ) -> ChunkStorageStats: ...
    async def chunk_storage_stats_async(
        self,
        *,
        max_snapshots_in_memory: int = 50,
        max_compressed_manifest_mem_bytes: int = 512 * 1024 * 1024,
        max_concurrent_manifest_fetches: int = 500,
    ) -> ChunkStorageStats: ...
    def inspect_snapshot(self, snapshot_id: str, *, pretty: bool = True) -> str: ...
    async def inspect_snapshot_async(
        self, snapshot_id: str, *, pretty: bool = True
    ) -> str: ...
    def inspect_repo_info(self, *, pretty: bool = True) -> str: ...
    async def inspect_repo_info_async(self, *, pretty: bool = True) -> str: ...
    def inspect_manifest(self, manifest_id: str, *, pretty: bool = True) -> str: ...
    async def inspect_manifest_async(
        self, manifest_id: str, *, pretty: bool = True
    ) -> str: ...
    def inspect_transaction_log(
        self, snapshot_id: str, *, pretty: bool = True
    ) -> str: ...
    async def inspect_transaction_log_async(
        self, snapshot_id: str, *, pretty: bool = True
    ) -> str: ...
    @property
    def spec_version(self) -> SpecVersion: ...

class ChunkType(Enum):
    """Enum for Zarr chunk types

    Attributes
    ----------
    Uninitialized: int
        Chunk doesn't have a materialized type yet
    Native: int
        Regular Zarr chunks
    Virtual: int
        Chunk conforming to the VirtualiZarr spec
    Inline: int
        Chunk is store inline in the manifest
    """

    uninitialized = 0
    native = 1
    virtual = 2
    inline = 3

class SessionMode(Enum):
    """Enum for session access modes

    Attributes
    ----------
    readonly: int
        Session can only read data
    writable: int
        Session can read and write data
    rearrange: int
        Session can only move nodes and reindex arrays
    """

    readonly = 0
    writable = 1
    rearrange = 2

class PySession:
    def _repr_html_(self) -> str: ...
    @classmethod
    def from_bytes(cls, bytes: bytes) -> PySession: ...
    def __eq__(self, value: object, /) -> bool: ...
    def as_bytes(self) -> bytes: ...
    def fork(self) -> PySession: ...
    @property
    def read_only(self) -> bool: ...
    @property
    def is_fork(self) -> bool: ...
    @property
    def mode(self) -> SessionMode: ...
    @property
    def snapshot_id(self) -> str: ...
    @property
    def branch(self) -> str | None: ...
    @property
    def has_uncommitted_changes(self) -> bool: ...
    def status(self) -> Diff: ...
    def discard_changes(self) -> None: ...
    def move_node(self, from_path: str, to_path: str) -> None: ...
    def get_node_id(self, path: str) -> str: ...
    async def get_node_id_async(self, path: str) -> str: ...
    def reindex_array(
        self,
        array_path: str,
        forward: Callable[[Iterable[int]], Iterable[int] | None],
        backward: Callable[[Iterable[int]], Iterable[int] | None] | None = None,
    ) -> None:
        """Reindex chunks in an array by applying a transformation function.

        Only existing (non-empty) chunks are visited — empty positions are
        skipped. This means that if an empty chunk would have shifted into an
        occupied position, that position retains stale data unless a backward
        function is also provided.

        Parameters
        ----------
        array_path : str
            Path to the array.
        forward : Callable[[Iterable[int]], Iterable[int] | None]
            Function that maps old chunk coordinates to new coordinates. Receives
            a list of non-negative integers (the current chunk index) and must return
            either a new index (as a list/tuple of non-negative integers within the
            array's chunk grid bounds) or ``None`` to skip the chunk (leave it in place).
        backward : Callable[[Iterable[int]], Iterable[int] | None], optional
            Inverse of ``forward``: given a chunk position, returns the position
            that would have mapped there under ``forward``. Must follow the same
            return conventions as ``forward``. When provided, each existing chunk
            position is checked to determine whether it should be cleared — if
            ``backward`` returns ``None`` (out of bounds) or points to a position
            with no chunk, that position is reset to the fill value.
        """
        ...
    def shift_array(self, array_path: str, chunk_offset: Iterable[int]) -> None: ...
    async def move_node_async(self, from_path: str, to_path: str) -> None: ...
    def all_virtual_chunk_locations(self) -> list[str]: ...
    async def all_virtual_chunk_locations_async(self) -> list[str]: ...
    def chunk_coordinates(
        self, array_path: str, batch_size: int
    ) -> AsyncIterator[list[list[int]]]: ...
    def chunk_type(self, array_path: str, coords: Sequence[int]) -> ChunkType: ...
    async def chunk_type_async(
        self, array_path: str, coords: Sequence[int]
    ) -> ChunkType: ...
    @property
    def store(self) -> PyStore: ...
    @property
    def config(self) -> RepositoryConfig: ...
    def merge(self, other: PySession) -> None: ...
    async def merge_async(self, other: PySession) -> None: ...
    def commit(
        self,
        message: str,
        metadata: dict[str, Any] | None = None,
        rebase_with: ConflictSolver | None = None,
        rebase_tries: int = 1_000,
        allow_empty: bool = False,
    ) -> str: ...
    async def commit_async(
        self,
        message: str,
        metadata: dict[str, Any] | None = None,
        rebase_with: ConflictSolver | None = None,
        rebase_tries: int = 1_000,
        allow_empty: bool = False,
    ) -> str: ...
    def flush(
        self,
        message: str,
        metadata: dict[str, Any] | None = None,
    ) -> str: ...
    async def flush_async(
        self,
        message: str,
        metadata: dict[str, Any] | None,
    ) -> str: ...
    def amend(
        self,
        message: str,
        metadata: dict[str, Any] | None = None,
        allow_empty: bool = False,
    ) -> str: ...
    async def amend_async(
        self,
        message: str,
        metadata: dict[str, Any] | None = None,
        allow_empty: bool = False,
    ) -> str: ...
    def rebase(self, solver: ConflictSolver) -> None: ...
    async def rebase_async(self, solver: ConflictSolver) -> None: ...

class PyStore:
    def _repr_html_(self) -> str: ...
    @classmethod
    def from_bytes(cls, bytes: bytes) -> PyStore: ...
    def __eq__(self, value: object, /) -> bool: ...
    @property
    def read_only(self) -> bool: ...
    @property
    def session(self) -> PySession: ...
    def as_bytes(self) -> bytes: ...
    async def is_empty(self, prefix: str) -> bool: ...
    async def clear(self) -> None: ...
    def sync_clear(self) -> None: ...
    async def get(
        self, key: str, byte_range: tuple[int | None, int | None] | None = None
    ) -> bytes: ...
    async def get_partial_values(
        self, key_ranges: list[tuple[str, tuple[int | None, int | None]]]
    ) -> list[bytes]: ...
    async def exists(self, key: str) -> bool: ...
    @property
    def supports_writes(self) -> bool: ...
    @property
    def supports_consolidated_metadata(self) -> bool: ...
    @property
    def supports_deletes(self) -> bool: ...
    async def set(self, key: str, value: bytes) -> None: ...
    async def set_if_not_exists(self, key: str, value: bytes) -> None: ...
    def set_virtual_ref(
        self,
        key: str,
        location: str,
        offset: int,
        length: int,
        checksum: str | datetime.datetime | None,
        validate_container: bool,
    ) -> None: ...
    async def set_virtual_ref_async(
        self,
        key: str,
        location: str,
        offset: int,
        length: int,
        checksum: str | datetime.datetime | None,
        validate_container: bool,
    ) -> None: ...
    def set_virtual_refs(
        self,
        array_path: str,
        chunks: list[VirtualChunkSpec],
        validate_containers: bool,
    ) -> list[tuple[int, ...]] | None: ...
    async def set_virtual_refs_async(
        self,
        array_path: str,
        chunks: list[VirtualChunkSpec],
        validate_containers: bool,
    ) -> list[tuple[int, ...]] | None: ...
    def set_virtual_refs_arr(
        self,
        array_path: str,
        chunk_grid_shape: list[int],
        locations: list[str],
        offsets: np.ndarray[Any, np.dtype[np.uint64]],
        lengths: np.ndarray[Any, np.dtype[np.uint64]],
        *,
        validate_containers: bool = True,
        arr_offset: list[int] | None = None,
        checksum: datetime.datetime | str | None = None,
    ) -> list[tuple[int, ...]] | None: ...
    async def set_virtual_refs_arr_async(
        self,
        array_path: str,
        chunk_grid_shape: list[int],
        locations: list[str],
        offsets: np.ndarray[Any, np.dtype[np.uint64]],
        lengths: np.ndarray[Any, np.dtype[np.uint64]],
        *,
        validate_containers: bool = True,
        arr_offset: list[int] | None = None,
        checksum: datetime.datetime | str | None = None,
    ) -> list[tuple[int, ...]] | None: ...
    async def delete(self, key: str) -> None: ...
    async def delete_dir(self, prefix: str) -> None: ...
    @property
    def supports_partial_writes(self) -> bool: ...
    async def set_partial_values(
        self, key_start_values: list[tuple[str, int, bytes]]
    ) -> None: ...
    @property
    def supports_listing(self) -> bool: ...
    def list(self) -> _PyAsyncStringGenerator: ...
    def list_prefix(self, prefix: str) -> _PyAsyncStringGenerator: ...
    def list_dir(self, prefix: str) -> _PyAsyncStringGenerator: ...
    async def getsize(self, key: str) -> int: ...
    async def getsize_prefix(self, prefix: str) -> int: ...

class _PyAsyncStringGenerator(AsyncGenerator[str], metaclass=abc.ABCMeta):
    def __aiter__(self) -> _PyAsyncStringGenerator: ...
    async def __anext__(self) -> str: ...

class SnapshotInfo:
    """Metadata for a snapshot"""
    @property
    def id(self) -> str:
        """The snapshot ID"""
        ...
    @property
    def parent_id(self) -> str | None:
        """The snapshot ID"""
        ...
    @property
    def written_at(self) -> datetime.datetime:
        """
        The timestamp when the snapshot was written
        """
        ...
    @property
    def message(self) -> str:
        """
        The commit message of the snapshot
        """
        ...
    @property
    def metadata(self) -> dict[str, Any]:
        """
        The metadata of the snapshot
        """
        ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...

class _PyAsyncSnapshotGenerator(AsyncGenerator[SnapshotInfo], metaclass=abc.ABCMeta):
    def __aiter__(self) -> _PyAsyncSnapshotGenerator: ...
    async def __anext__(self) -> SnapshotInfo: ...

@final
class AncestryGraph:
    """A visual representation of commit history.

    Use ``print()`` for colored Unicode output in a terminal, or display
    in Jupyter for an SVG diagram. Pass ``plain=True`` to
    ``ancestry_graph()`` for output without colors (useful for CI, files,
    or LLM agents).

    Note: only commits reachable from branches are included. Anonymous/detached
    snapshots are not attached to any branch and will not appear.
    """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def _repr_svg_(self) -> str:
        """Return a raw SVG string for Jupyter notebooks."""
        ...

class S3StaticCredentials:
    """Credentials for an S3 storage backend

    Attributes:
        access_key_id: str
            The access key ID to use for authentication.
        secret_access_key: str
            The secret access key to use for authentication.
        session_token: str | None
            The session token to use for authentication.
        expires_after: datetime.datetime | None
            Optional, the expiration time of the credentials.
    """

    access_key_id: str
    secret_access_key: str
    session_token: str | None
    expires_after: datetime.datetime | None

    def __new__(
        cls,
        access_key_id: str,
        secret_access_key: str,
        session_token: str | None = None,
        expires_after: datetime.datetime | None = None,
    ) -> S3StaticCredentials:
        """
        Create a new `S3StaticCredentials` object

        Parameters
        ----------
        access_key_id: str
            The access key ID to use for authentication.
        secret_access_key: str
            The secret access key to use for authentication.
        session_token: str | None
            Optional, the session token to use for authentication.
        expires_after: datetime.datetime | None
            Optional, the expiration time of the credentials.
        """
        ...

class S3Credentials:
    """Credentials for an S3 storage backend"""
    class FromEnv:
        """Uses credentials from environment variables"""
        def __new__(cls) -> S3Credentials.FromEnv: ...

    class Anonymous:
        """Does not sign requests, useful for public buckets"""
        def __new__(cls) -> S3Credentials.Anonymous: ...

    class Static:
        """Uses s3 credentials without expiration"""
        def __new__(cls, credentials: S3StaticCredentials) -> S3Credentials.Static:
            """Create static S3 credentials.

            Parameters
            ----------
            credentials: S3StaticCredentials
                The credentials to use for authentication.
            """
            ...

    class Refreshable:
        """Allows for an outside authority to pass in a function that can be used to provide credentials.

        This is useful for credentials that have an expiration time, or are otherwise not known ahead of time.
        """
        def __new__(
            cls, pickled_function: bytes, current: S3StaticCredentials | None = None
        ) -> S3Credentials.Refreshable:
            """Create refreshable S3 credentials.

            Parameters
            ----------
            pickled_function: bytes
                The pickled function to use to provide credentials.
            current: S3StaticCredentials
                The initial credentials. They will be returned the first time credentials
                are requested and then deleted.
            """
            ...

_AnyS3Credential = (
    S3Credentials.Static
    | S3Credentials.Anonymous
    | S3Credentials.FromEnv
    | S3Credentials.Refreshable
)

class GcsBearerCredential:
    """Credentials for a google cloud storage backend

    This is a bearer token that has an expiration time.
    """

    def __new__(
        cls, bearer: str, *, expires_after: datetime.datetime | None = None
    ) -> GcsBearerCredential:
        """Create a GcsBearerCredential object

        Parameters
        ----------
        bearer: str
            The bearer token to use for authentication.
        expires_after: datetime.datetime | None
            The expiration time of the bearer token.
        """

    @property
    def bearer(self) -> str: ...
    @property
    def expires_after(self) -> datetime.datetime | None: ...

class GcsStaticCredentials:
    """Credentials for a google cloud storage backend"""
    class ServiceAccount:
        """Credentials for a google cloud storage backend using a service account json file"""
        def __new__(cls, path: str) -> GcsStaticCredentials.ServiceAccount:
            """Create service account credentials.

            Parameters
            ----------
            path: str
                The path to the service account json file.
            """
            ...

    class ServiceAccountKey:
        """Credentials for a google cloud storage backend using a serialized service account key"""
        def __new__(cls, key: str) -> GcsStaticCredentials.ServiceAccountKey:
            """Create service account key credentials.

            Parameters
            ----------
            key: str
                The serialized service account key.
            """
            ...

    class ApplicationCredentials:
        """Credentials for a google cloud storage backend using application default credentials"""
        def __new__(cls, path: str) -> GcsStaticCredentials.ApplicationCredentials:
            """Create application default credentials.

            Parameters
            ----------
            path: str
                The path to the application default credentials (ADC) file.
            """
            ...

    class BearerToken:
        """Credentials for a google cloud storage backend using a bearer token"""
        def __new__(cls, token: str) -> GcsStaticCredentials.BearerToken:
            """Create bearer token credentials.

            Parameters
            ----------
            token: str
                The bearer token to use for authentication.
            """
            ...

_AnyGcsStaticCredential = (
    GcsStaticCredentials.ServiceAccount
    | GcsStaticCredentials.ServiceAccountKey
    | GcsStaticCredentials.ApplicationCredentials
    | GcsStaticCredentials.BearerToken
)

class GcsCredentials:
    """Credentials for a google cloud storage backend

    This can be used to authenticate with a google cloud storage backend.
    """
    class Anonymous:
        """Uses anonymous credentials"""
        def __new__(cls) -> GcsCredentials.Anonymous: ...

    class FromEnv:
        """Uses credentials from environment variables"""
        def __new__(cls) -> GcsCredentials.FromEnv: ...

    class Static:
        """Uses gcs credentials without expiration"""
        def __new__(
            cls, credentials: _AnyGcsStaticCredential
        ) -> GcsCredentials.Static: ...

    class Refreshable:
        """Allows for an outside authority to pass in a function that can be used to provide credentials.

        This is useful for credentials that have an expiration time, or are otherwise not known ahead of time.
        """
        def __new__(
            cls, pickled_function: bytes, current: GcsBearerCredential | None = None
        ) -> GcsCredentials.Refreshable: ...

_AnyGcsCredential = (
    GcsCredentials.Anonymous
    | GcsCredentials.FromEnv
    | GcsCredentials.Static
    | GcsCredentials.Refreshable
)

class AzureRefreshableCredential:
    """A refreshable credential for Azure storage with optional expiration."""

    class AccessKey:
        """Refreshable access key credential."""
        def __new__(
            cls, key: str, *, expires_after: datetime.datetime | None = None
        ) -> AzureRefreshableCredential.AccessKey: ...

    class SasToken:
        """Refreshable SAS token credential."""
        def __new__(
            cls, token: str, *, expires_after: datetime.datetime | None = None
        ) -> AzureRefreshableCredential.SasToken: ...

    class BearerToken:
        """Refreshable bearer token credential."""
        def __new__(
            cls, bearer: str, *, expires_after: datetime.datetime | None = None
        ) -> AzureRefreshableCredential.BearerToken: ...

_AnyAzureRefreshableCredential = (
    AzureRefreshableCredential.AccessKey
    | AzureRefreshableCredential.SasToken
    | AzureRefreshableCredential.BearerToken
)

class AzureStaticCredentials:
    """Credentials for an azure storage backend"""
    class AccessKey:
        """Credentials for an azure storage backend using an access key"""
        def __new__(cls, key: str) -> AzureStaticCredentials.AccessKey:
            """Create access key credentials.

            Parameters
            ----------
            key: str
                The access key to use for authentication.
            """
            ...

    class SasToken:
        """Credentials for an azure storage backend using a shared access signature token"""
        def __new__(cls, token: str) -> AzureStaticCredentials.SasToken:
            """Create SAS token credentials.

            Parameters
            ----------
            token: str
                The shared access signature token to use for authentication.
            """
            ...

    class BearerToken:
        """Credentials for an azure storage backend using a bearer token"""
        def __new__(cls, token: str) -> AzureStaticCredentials.BearerToken:
            """Create bearer token credentials.

            Parameters
            ----------
            token: str
                The bearer token to use for authentication.
            """
            ...

_AnyAzureStaticCredential = (
    AzureStaticCredentials.AccessKey
    | AzureStaticCredentials.SasToken
    | AzureStaticCredentials.BearerToken
)

class AzureCredentials:
    """Credentials for an azure storage backend

    This can be used to authenticate with an azure storage backend.
    """
    class FromEnv:
        """Uses credentials from environment variables"""
        def __new__(cls) -> AzureCredentials.FromEnv: ...

    class Static:
        """Uses azure credentials without expiration"""
        def __new__(
            cls, credentials: _AnyAzureStaticCredential
        ) -> AzureCredentials.Static: ...

    class Refreshable:
        """Allows for an outside authority to pass in a function that can be used to provide credentials.

        This is useful for credentials that have an expiration time, or are otherwise not known ahead of time.
        """
        def __new__(
            cls,
            pickled_function: bytes,
            current: AzureRefreshableCredential | None = None,
        ) -> AzureCredentials.Refreshable: ...

_AnyAzureCredential = (
    AzureCredentials.FromEnv | AzureCredentials.Static | AzureCredentials.Refreshable
)

class Credentials:
    class S3:
        def __new__(cls, credentials: _AnyS3Credential) -> Credentials.S3: ...

    class Gcs:
        def __new__(cls, credentials: GcsCredentials) -> Credentials.Gcs: ...

    class Azure:
        def __new__(cls, credentials: AzureCredentials) -> Credentials.Azure: ...

_AnyCredential = Credentials.S3 | Credentials.Gcs | Credentials.Azure

@final
class LatencyStorage(Storage):
    """Storage wrapper that adds artificial read/write latency for testing.

    Wraps any ``Storage`` backend and injects configurable delays before
    write and read operations. Useful for reproducing timing-sensitive bugs
    or for benchmarking.

    Parameters
    ----------
    inner : Storage
        The storage backend to wrap.
    write_latency_ms : int, default 0
        Delay in milliseconds before each write operation.
    read_latency_ms : int, default 0
        Delay in milliseconds before each read operation.

    Examples
    --------
    >>> from icechunk.testing import LatencyStorage
    >>> storage = LatencyStorage(ic.in_memory_storage(), write_latency_ms=15)
    >>> repo = ic.Repository.create(storage=storage, ...)
    >>> storage.write_latency_ms = 50  # adjust at runtime
    """

    def __new__(
        cls,
        inner: Storage,
        *,
        write_latency_ms: int = 0,
        read_latency_ms: int = 0,
    ) -> LatencyStorage: ...
    @property
    def write_latency_ms(self) -> int: ...
    @write_latency_ms.setter
    def write_latency_ms(self, ms: int) -> None: ...
    @property
    def read_latency_ms(self) -> int: ...
    @read_latency_ms.setter
    def read_latency_ms(self, ms: int) -> None: ...

@final
class StorageObjectInfo:
    """Metadata for an object in storage.

    Parameters
    ----------
    key : str
        The object key (path relative to the storage prefix).
    size_bytes : int
        Size of the object in bytes.
    created_at : datetime.datetime
        Timestamp when the object was written to storage.
    """

    @property
    def key(self) -> str: ...
    @property
    def size_bytes(self) -> int: ...
    @property
    def created_at(self) -> datetime.datetime: ...

class Storage:
    """Storage configuration for an IcechunkStore

    Currently supports memory, filesystem S3, azure blob, and google cloud storage backends.
    Use the following methods to create a Storage object with the desired backend.

    Ex:
    ```
    storage = icechunk.in_memory_storage()
    storage = icechunk.local_filesystem_storage("/path/to/root")
    storage = icechunk.s3_storage("bucket", "prefix", ...)
    storage = icechunk.gcs_storage("bucket", "prefix", ...)
    storage = icechunk.azure_storage("container", "prefix", ...)
    ```
    """

    @classmethod
    def new_s3(
        cls,
        config: S3Options,
        bucket: str,
        prefix: str | None,
        credentials: _AnyS3Credential | None = None,
    ) -> Storage: ...
    @classmethod
    def new_s3_object_store(
        cls,
        config: S3Options,
        bucket: str,
        prefix: str | None,
        credentials: _AnyS3Credential | None = None,
    ) -> Storage: ...
    @classmethod
    def new_tigris(
        cls,
        config: S3Options,
        bucket: str,
        prefix: str | None,
        use_weak_consistency: bool,
        credentials: _AnyS3Credential | None = None,
    ) -> Storage: ...
    @classmethod
    def new_in_memory(cls) -> Storage: ...
    @classmethod
    def new_local_filesystem(cls, path: str) -> Storage: ...
    @classmethod
    def new_gcs(
        cls,
        bucket: str,
        prefix: str | None,
        credentials: _AnyGcsCredential | None = None,
        *,
        config: dict[str, str] | None = None,
    ) -> Storage: ...
    @classmethod
    def new_r2(
        cls,
        config: S3Options,
        bucket: str | None = None,
        prefix: str | None = None,
        account_id: str | None = None,
        credentials: _AnyS3Credential | None = None,
    ) -> Storage: ...
    @classmethod
    def new_azure_blob(
        cls,
        account: str,
        container: str,
        prefix: str,
        credentials: _AnyAzureCredential | None = None,
        *,
        config: dict[str, str] | None = None,
    ) -> Storage: ...
    @classmethod
    def new_http(
        cls,
        base_url: str,
        config: dict[str, str] | None = None,
    ) -> Storage: ...
    @classmethod
    def new_redirect(
        cls,
        base_url: str,
    ) -> Storage: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...
    def default_settings(self) -> StorageSettings: ...
    def list_objects(
        self, settings: StorageSettings | None = None, prefix: str | None = None
    ) -> list[tuple[str, int]]:
        """List objects in the storage backend, optionally filtered by a key prefix.

        Deprecated: use ``list_objects_metadata`` instead, which also returns
        the ``created_at`` timestamp.

        Parameters
        ----------
        settings : StorageSettings | None
            Optional storage settings to override the defaults (retries, concurrency, etc.).
        prefix : str | None
            If provided, only objects whose keys start with this prefix are returned.
            When ``None`` or empty, all objects under the repository root are listed.

        Returns
        -------
        list[tuple[str, int]]
            A list of ``(key, size_in_bytes)`` tuples for each object found.
        """
        ...
    def list_objects_metadata(
        self, settings: StorageSettings | None = None, prefix: str | None = None
    ) -> list[StorageObjectInfo]:
        """List objects with full metadata, optionally filtered by a key prefix.

        Parameters
        ----------
        settings : StorageSettings | None
            Optional storage settings to override the defaults.
        prefix : str | None
            If provided, only objects whose keys start with this prefix are returned.

        Returns
        -------
        list[StorageObjectInfo]
            A list of :class:`StorageObjectInfo` objects.
        """
        ...

class VersionSelection(Enum):
    """Enum for selecting the which version of a conflict

    Attributes
    ----------
    Fail: int
        Fail the rebase operation
    UseOurs: int
        Use the version from the source store
    UseTheirs: int
        Use the version from the target store
    """

    Fail = 0
    UseOurs = 1
    UseTheirs = 2

class ConflictSolver:
    """An abstract conflict solver that can be used to detect or resolve conflicts between two stores

    This should never be used directly, but should be subclassed to provide specific conflict resolution behavior
    """

    ...

class BasicConflictSolver(ConflictSolver):
    """A basic conflict solver that allows for simple configuration of resolution behavior

    This conflict solver allows for simple configuration of resolution behavior for conflicts that may occur during a rebase operation.
    It will attempt to resolve a limited set of conflicts based on the configuration options provided.

    - When a chunk conflict is encountered, the behavior is determined by the `on_chunk_conflict` option
    - When an array is deleted that has been updated, `fail_on_delete_of_updated_array` will determine whether to fail the rebase operation
    - When a group is deleted that has been updated, `fail_on_delete_of_updated_group` will determine whether to fail the rebase operation
    """

    def __new__(
        cls,
        *,
        on_chunk_conflict: VersionSelection = VersionSelection.UseOurs,
        fail_on_delete_of_updated_array: bool = False,
        fail_on_delete_of_updated_group: bool = False,
    ) -> BasicConflictSolver:
        """Create a BasicConflictSolver object with the given configuration options

        Parameters
        ----------
        on_chunk_conflict: VersionSelection
            The behavior to use when a chunk conflict is encountered, by default VersionSelection.use_theirs()
        fail_on_delete_of_updated_array: bool
            Whether to fail when a chunk is deleted that has been updated, by default False
        fail_on_delete_of_updated_group: bool
            Whether to fail when a group is deleted that has been updated, by default False
        """
        ...

class ConflictDetector(ConflictSolver):
    """A conflict solver that can be used to detect conflicts between two stores, but does not resolve them

    Where the `BasicConflictSolver` will attempt to resolve conflicts, the `ConflictDetector` will only detect them. This means
    that during a rebase operation the `ConflictDetector` will raise a `RebaseFailed` error if any conflicts are detected, and
    allow the rebase operation to be retried with a different conflict resolution strategy. Otherwise, if no conflicts are detected
    the rebase operation will succeed.
    """

    def __new__(cls) -> ConflictDetector: ...

class IcechunkError(Exception):
    """Base class for all Icechunk errors"""

    @property
    def message(self) -> str: ...

class ConflictError(Exception):
    """An error that occurs when a conflict is detected"""

    def __new__(
        cls,
        expected_parent: str | None = None,
        actual_parent: str | None = None,
    ) -> ConflictError:
        """
        Create a new ConflictError.

        Parameters
        ----------
        expected_parent: str | None
            The expected parent snapshot ID.
        actual_parent: str | None
            The actual parent snapshot ID of the branch.
        """
        ...

    @property
    def expected_parent(self) -> str:
        """The expected parent snapshot ID.

        This is the snapshot ID that the session was based on when the
        commit operation was called.
        """
        ...
    @property
    def actual_parent(self) -> str:
        """
        The actual parent snapshot ID of the branch that the session attempted to commit to.

        When the session is based on a branch, this is the snapshot ID of the branch tip. If this
        error is raised, it means the branch was modified and committed by another session after
        the session was created.
        """
        ...
    ...

__version__: str

class ConflictType(Enum):
    """Type of conflict detected"""

    NewNodeConflictsWithExistingNode = (1,)
    """A new node conflicts with an existing node"""

    NewNodeInInvalidGroup = (2,)
    """A new node is in an invalid group"""

    ZarrMetadataDoubleUpdate = (3,)
    """A zarr metadata update conflicts with an existing zarr metadata update"""

    ZarrMetadataUpdateOfDeletedArray = (4,)
    """A zarr metadata update is attempted on a deleted array"""

    ZarrMetadataUpdateOfDeletedGroup = (5,)
    """A zarr metadata update is attempted on a deleted group"""

    ChunkDoubleUpdate = (6,)
    """A chunk update conflicts with an existing chunk update"""

    ChunksUpdatedInDeletedArray = (7,)
    """Chunks are updated in a deleted array"""

    ChunksUpdatedInUpdatedArray = (8,)
    """Chunks are updated in an updated array"""

    DeleteOfUpdatedArray = (9,)
    """A delete is attempted on an updated array"""

    DeleteOfUpdatedGroup = (10,)
    """A delete is attempted on an updated group"""

    (MoveOperationCannotBeRebased,) = (11,)
    """Move operation cannot be rebased"""

class Conflict:
    """A conflict detected between snapshots"""

    def __new__(
        cls,
        conflict_type: ConflictType,
        path: str,
        conflicted_chunks: list[list[int]] | None = None,
    ) -> Conflict:
        """
        Create a new Conflict.

        Parameters
        ----------
        conflict_type: ConflictType
            The type of conflict.
        path: str
            The path of the node that caused the conflict.
        conflicted_chunks: list[list[int]] | None
            If the conflict is a chunk conflict, the list of chunk indices in conflict.
        """
        ...

    @property
    def conflict_type(self) -> ConflictType:
        """The type of conflict detected

        Returns:
            ConflictType: The type of conflict detected
        """
        ...

    @property
    def path(self) -> str:
        """The path of the node that caused the conflict

        Returns:
            str: The path of the node that caused the conflict
        """
        ...

    @property
    def conflicted_chunks(self) -> list[list[int]] | None:
        """If the conflict is a chunk conflict, this will return the list of chunk indices that are in conflict

        Returns:
            list[list[int]] | None: The list of chunk indices that are in conflict
        """
        ...

class RebaseFailedError(IcechunkError):
    """An error that occurs when a rebase operation fails"""

    def __new__(cls, snapshot: str, conflicts: list[Conflict]) -> RebaseFailedError:
        """
        Create a new RebaseFailedError.

        Parameters
        ----------
        snapshot: str
            The snapshot ID that the session was rebased to.
        conflicts: list[Conflict]
            The conflicts that occurred during the rebase operation.
        """
        ...

    @property
    def snapshot(self) -> str:
        """The snapshot ID that the session was rebased to"""
        ...

    @property
    def conflicts(self) -> list[Conflict]:
        """The conflicts that occurred during the rebase operation

        Returns:
            list[Conflict]: The conflicts that occurred during the rebase operation
        """
    ...

def initialize_logs() -> None:
    """
    Initialize the logging system for the library.

    Reads the value of the environment variable ICECHUNK_LOG to obtain the filters.
    This is autamtically called on `import icechunk`.
    """
    ...

def set_logs_filter(log_filter_directive: str | None) -> None:
    """
    Set filters and log levels for the different modules.

    Examples:
      - set_logs_filter("trace")  # trace level for all modules
      - set_logs_filter("error")  # error level for all modules
      - set_logs_filter("icechunk=debug,info")  # debug level for icechunk, info for everything else

    Full spec for the log_filter_directive syntax is documented in
    https://docs.rs/tracing-subscriber/latest/tracing_subscriber/filter/struct.EnvFilter.html#directives

    Parameters
    ----------
    log_filter_directive: str | None
        The comma separated list of directives for modules and log levels.
        If None, the directive will be read from the environment variable
        ICECHUNK_LOG
    """
    ...

def spec_version() -> SpecVersion:
    """
    The version of the Icechunk specification that the library is compatible with.

    Returns:
        int: The version of the Icechunk specification that the library is compatible with
    """
    ...

def user_agent() -> str:
    """
    The user-agent string sent with icechunk storage requests.

    Returns:
        str: The user-agent string (e.g., "icechunk-rust-2.0.0-alpha.3")
    """
    ...

def _upgrade_icechunk_repository(
    repo: PyRepository,
    *,
    dry_run: bool = True,
    delete_unused_v1_files: bool = True,
    prefetch_concurrency: int | None = None,
) -> PyRepository:
    """
    Migrate a repository to the latest version of Icechunk.

    This is an administrative operation, and must be executed in isolation from
    other readers and writers. Other processes running concurrently on the same
    repo may see undefined behavior.

    At this time, this function supports only migration from Icechunk spec version 1
    to Icechunk spec version 2. This means Icechunk versions 1.x to 2.x.

    The operation is usually fast, but it can take several minutes if there is a very
    large version history (thousands of snapshots).
    """
    ...

class ChunkStorageStats:
    """Statistics about chunk storage across different chunk types."""

    @property
    def native_bytes(self) -> int:
        """Total bytes stored in native chunks (stored in icechunk's chunk storage)"""
        ...

    @property
    def virtual_bytes(self) -> int:
        """Total bytes stored in virtual chunks (references to external data)"""
        ...

    @property
    def inlined_bytes(self) -> int:
        """Total bytes stored in inline chunks (stored directly in manifests)"""
        ...

    def non_virtual_bytes(self) -> int:
        """
        Total bytes excluding virtual chunks.

        This represents the approximate size of all objects stored in the
        icechunk repository itself (native chunks plus inline chunks).
        Virtual chunks are not included since they reference external data.

        Returns:
            int: The sum of native_bytes and inlined_bytes
        """
        ...

    def total_bytes(self) -> int:
        """
        Total bytes across all chunk types.

        Returns the sum of native_bytes, virtual_bytes, and inlined_bytes.
        This represents the total size of all data referenced by the repository,
        including both data stored in icechunk and external virtual references.

        Returns:
            int: The sum of all chunk storage bytes
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
    def _repr_html_(self) -> str: ...
    def __add__(self, other: ChunkStorageStats, /) -> ChunkStorageStats: ...
