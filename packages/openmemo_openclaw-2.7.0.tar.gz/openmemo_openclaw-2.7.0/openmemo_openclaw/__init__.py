"""
OpenMemo × OpenClaw Adapter v2.6.0

Automatic Cognitive Memory Infrastructure for OpenClaw Agents.
install → run → memory works automatically.

v2.6.0: Memory Experience Runtime
  - Event Bridge: unified event stream (on_task_start/recall/inject/workflow_adopt/complete/store)
  - UI Controller: unified card interface (show_activation/rule_card/insight/reuse_indicator)
  - Full adapter flow instrumentation: every step emits typed events
  - New APIs: GET /events/recent, GET /events/stats, GET /ui/current, GET /ui/cards
  - Inspector UI: Activation Status section with Rule Card + Insight Card

v2.5.0: Memory Policy + Activation System
  - PolicyEngine: Smart Memory Mode filter (store/ignore lists)
  - ActivationStore: InsightCards, Reuse Indicators, Guided First Task
  - APIs: GET /policy/current, POST /policy/generate, POST /policy/update
         GET /activation/status, GET /activation/first-task
"""

from openmemo_openclaw.adapter import OpenMemoAdapter
from openmemo_openclaw.plugin import OpenClawMemoryPlugin
from openmemo_openclaw.config import AdapterConfig
from openmemo_openclaw.health import HealthCheckError
from openmemo_openclaw.pre_check import PreCheckResult
from openmemo_openclaw.fingerprint import generate_fingerprint
from openmemo_openclaw.task_extractor import TaskTracker
from openmemo_openclaw.version_check import VersionInfo, check_version
from openmemo_openclaw.inspector import InspectorServer
from openmemo_openclaw.memory_rules import MemoryRulesEngine, DEFAULT_MEMORY_RULES
from openmemo_openclaw.soul_merger import merge_soul, merge_into_messages
from openmemo_openclaw.memory_policy import PolicyEngine, RuleStore, should_store
from openmemo_openclaw.activation import ActivationStore
from openmemo_openclaw.event_bridge import EventBridge
from openmemo_openclaw.ui_controller import UIController

__version__ = "2.6.0"
__all__ = [
    "OpenMemoAdapter",
    "OpenClawMemoryPlugin",
    "AdapterConfig",
    "HealthCheckError",
    "PreCheckResult",
    "generate_fingerprint",
    "TaskTracker",
    "VersionInfo",
    "check_version",
    "InspectorServer",
    "MemoryRulesEngine",
    "DEFAULT_MEMORY_RULES",
    "merge_soul",
    "merge_into_messages",
    "PolicyEngine",
    "RuleStore",
    "should_store",
    "ActivationStore",
    "EventBridge",
    "UIController",
]
