# -*- coding: utf-8 -*-

import never_primp

def test_concurrent_requests():

    session = never_primp.Client(impersonate='chrome_145')

    chrome_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "upgrade-insecure-requests": "1",
        "sec-fetch-site": "cross-site",
        "sec-fetch-mode": "navigate",
        "sec-fetch-user": "?1",
        "sec-fetch-dest": "document",
        "accept-language": "en,zh-CN;q=0.9,zh;q=0.8,zh-HK;q=0.7",
        "priority": "u=0, i"
    }
    try:
        response = session.get(f"https://www.ma2e.top:4445/", headers=chrome_headers)
        print(response)
        print(response.status_code)
        print(response.text)
    except :
        print('========================')

    response = session.get(f"https://www.ma2e.top:4445/", headers=chrome_headers, verify=False)
    print(response)
    print(response.status_code)
    print(response.text)


if __name__ == "__main__":
    test_concurrent_requests()
