"""
并发请求性能测试

演示移除 Arc<Mutex<Client>> 后的真实并发性能提升。
ThreadPoolExecutor 中每个线程持有同一 Client 引用，
Rust 层直接 clone（内部 Arc，零锁争用），真正并行发请求。
"""
import time
import statistics
from concurrent.futures import ThreadPoolExecutor, as_completed

import never_primp

# ── 共享同一个 Client 实例（线程安全，无锁） ──────────────────────────────
client = never_primp.Client(
    impersonate="chrome_143",
    impersonate_os="windows",
    timeout=30.0,
    max_retries=1,
)

TARGET_URL = "https://httpbin.org/get"


def fetch(task_id: int) -> dict:
    t0 = time.perf_counter()
    try:
        r = client.get(TARGET_URL, params={"task": str(task_id)})
        return {"id": task_id, "status": r.status_code, "ms": (time.perf_counter() - t0) * 1000}
    except Exception as e:
        return {"id": task_id, "status": "error", "error": str(e), "ms": (time.perf_counter() - t0) * 1000}


def run_benchmark(n_requests: int, n_workers: int) -> None:
    print(f"\n{'─'*55}")
    print(f"  {n_requests} requests  ×  {n_workers} workers")
    print(f"{'─'*55}")

    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=n_workers) as pool:
        futures = {pool.submit(fetch, i): i for i in range(n_requests)}
        results = [f.result() for f in as_completed(futures)]
    elapsed = time.perf_counter() - t0

    success = [r for r in results if r["status"] == 200]
    latencies = [r["ms"] for r in success]

    print(f"  总耗时   : {elapsed*1000:.0f} ms")
    print(f"  成功率   : {len(success)}/{n_requests} ({len(success)/n_requests*100:.1f}%)")
    if latencies:
        print(f"  P50 延迟 : {statistics.median(latencies):.0f} ms")
        print(f"  P95 延迟 : {sorted(latencies)[int(len(latencies)*0.95)]:.0f} ms")
        print(f"  吞吐量   : {n_requests/elapsed:.1f} req/s")


if __name__ == "__main__":
    print("=" * 55)
    print("  never_primp 并发性能测试")
    print("  Client 共享模式（wreq::Client 内部 Arc，无 Mutex）")
    print("=" * 55)

    # 热身
    print("\n[热身] 建立初始连接...")
    client.get(TARGET_URL)

    run_benchmark(n_requests=20,  n_workers=10)
    run_benchmark(n_requests=50,  n_workers=25)
    run_benchmark(n_requests=100, n_workers=50)

    print(f"\n{'='*55}")
    print("  测试完成")
    print(f"  连接池配置: 每主机 512 空闲连接 / 全局 2048")
    print(f"  TCP Keepalive: 15s 探测 / 5s 间隔 / 3次重试")
    print(f"{'='*55}")
