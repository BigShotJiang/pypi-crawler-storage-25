import never_primp

client = never_primp.Client(impersonate="chrome_131")

# ── 全局 cookie（无需 URL，随所有请求发送）──────────────────────
client.cookies["token"] = "abc123"
client.cookies.update({"uid": "999", "lang": "zh"})

del client.cookies["lang"]
print("token" in client.cookies)        # True
print(client.cookies.get("token"))      # abc123
print(client.cookies.items())           # [('token', 'abc123'), ('uid', '999')]
print(client.cookies.get_dict())
# ── 发请求（全局 cookie 自动附带）────────────────────────────────
resp = client.get("https://www.baidu.com")
print(resp)

# ── 读取响应返回的新 cookie ───────────────────────────────────────
print(resp.cookies)                     # {'set-cookie-name': 'value', ...}

# ── 从 jar 查询（session 累积的 domain-scoped cookie）────────────
# 跨所有 path 按名字查（解决子路径 cookie 找不到的问题）
val = client.cookies.find("sec_cpt")

# 按 URL 查（RFC 6265 path 匹配）
jar = client.cookies.get_cookies_for_url("https://example.com/")

# 查看 jar 里所有 cookie（含响应 Set-Cookie 积累的）
for name, value, domain, path in client.cookies.get_jar_cookies():
    print(f"{name}={value}  domain={domain}  path={path}")

    # ── 域名限定 cookie ───────────────────────────────────────────────
client.cookies.set("admin", "1", domain="api.example.com", path="/v2")

# ── 持久化 ───────────────────────────────────────────────────────
import json
data = client.export_cookies()
with open("cookies.json", "w") as f:
    json.dump(data, f)

client2 = never_primp.Client()
client2.import_cookies([tuple(c) for c in json.load(open("cookies.json"))])

# ── 清除 ──────────────────────────────────────────────────────────
client.cookies.clear_global()   # 只清全局
client.cookies.clear_jar()      # 只清 jar
client.cookies.clear()          # 全清