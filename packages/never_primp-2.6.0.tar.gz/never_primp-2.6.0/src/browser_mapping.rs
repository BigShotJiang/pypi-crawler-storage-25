// Browser name mapping (Python → wreq_util::Profile / Platform)
use anyhow::{anyhow, Result};
use wreq_util::{Platform, Profile};

/// Map Python browser name to wreq_util::Profile enum
pub fn map_browser_to_profile(name: &str) -> Result<Profile> {
    match name.to_lowercase().as_str() {
        // Chrome versions
        "chrome_100" => Ok(Profile::Chrome100),
        "chrome_101" => Ok(Profile::Chrome101),
        "chrome_104" => Ok(Profile::Chrome104),
        "chrome_105" => Ok(Profile::Chrome105),
        "chrome_106" => Ok(Profile::Chrome106),
        "chrome_107" => Ok(Profile::Chrome107),
        "chrome_108" => Ok(Profile::Chrome108),
        "chrome_109" => Ok(Profile::Chrome109),
        "chrome_110" => Ok(Profile::Chrome110),
        "chrome_114" => Ok(Profile::Chrome114),
        "chrome_116" => Ok(Profile::Chrome116),
        "chrome_117" => Ok(Profile::Chrome117),
        "chrome_118" => Ok(Profile::Chrome118),
        "chrome_119" => Ok(Profile::Chrome119),
        "chrome_120" => Ok(Profile::Chrome120),
        "chrome_123" => Ok(Profile::Chrome123),
        "chrome_124" => Ok(Profile::Chrome124),
        "chrome_126" => Ok(Profile::Chrome126),
        "chrome_127" => Ok(Profile::Chrome127),
        "chrome_128" => Ok(Profile::Chrome128),
        "chrome_129" => Ok(Profile::Chrome129),
        "chrome_130" => Ok(Profile::Chrome130),
        "chrome_131" => Ok(Profile::Chrome131),
        "chrome_132" => Ok(Profile::Chrome132),
        "chrome_133" => Ok(Profile::Chrome133),
        "chrome_134" => Ok(Profile::Chrome134),
        "chrome_135" => Ok(Profile::Chrome135),
        "chrome_136" => Ok(Profile::Chrome136),
        "chrome_137" => Ok(Profile::Chrome137),
        "chrome_138" => Ok(Profile::Chrome138),
        "chrome_139" => Ok(Profile::Chrome139),
        "chrome_140" => Ok(Profile::Chrome140),
        "chrome_141" => Ok(Profile::Chrome141),
        "chrome_142" => Ok(Profile::Chrome142),
        "chrome_143" => Ok(Profile::Chrome143),
        "chrome_144" => Ok(Profile::Chrome144),
        "chrome_145" => Ok(Profile::Chrome145),
        "chrome_146" => Ok(Profile::Chrome146),
        "chrome_147" => Ok(Profile::Chrome147),

        // Edge versions
        "edge_101" => Ok(Profile::Edge101),
        "edge_122" => Ok(Profile::Edge122),
        "edge_127" => Ok(Profile::Edge127),
        "edge_131" => Ok(Profile::Edge131),
        "edge_134" => Ok(Profile::Edge134),
        "edge_135" => Ok(Profile::Edge135),
        "edge_136" => Ok(Profile::Edge136),
        "edge_137" => Ok(Profile::Edge137),
        "edge_138" => Ok(Profile::Edge138),
        "edge_139" => Ok(Profile::Edge139),
        "edge_140" => Ok(Profile::Edge140),
        "edge_141" => Ok(Profile::Edge141),
        "edge_142" => Ok(Profile::Edge142),
        "edge_143" => Ok(Profile::Edge143),
        "edge_144" => Ok(Profile::Edge144),
        "edge_145" => Ok(Profile::Edge145),
        "edge_146" => Ok(Profile::Edge146),
        "edge_147" => Ok(Profile::Edge147),

        // Opera versions
        "opera_116" => Ok(Profile::Opera116),
        "opera_117" => Ok(Profile::Opera117),
        "opera_118" => Ok(Profile::Opera118),
        "opera_119" => Ok(Profile::Opera119),
        "opera_120" => Ok(Profile::Opera120),
        "opera_121" => Ok(Profile::Opera121),
        "opera_122" => Ok(Profile::Opera122),
        "opera_123" => Ok(Profile::Opera123),
        "opera_124" => Ok(Profile::Opera124),
        "opera_125" => Ok(Profile::Opera125),
        "opera_126" => Ok(Profile::Opera126),
        "opera_127" => Ok(Profile::Opera127),
        "opera_128" => Ok(Profile::Opera128),
        "opera_129" => Ok(Profile::Opera129),
        "opera_130" => Ok(Profile::Opera130),

        // Safari versions
        "safari_15.3" | "safari_15_3" => Ok(Profile::Safari15_3),
        "safari_15.5" | "safari_15_5" => Ok(Profile::Safari15_5),
        "safari_15.6.1" | "safari_15_6_1" => Ok(Profile::Safari15_6_1),
        "safari_16" => Ok(Profile::Safari16),
        "safari_16.5" | "safari_16_5" => Ok(Profile::Safari16_5),
        "safari_17.0" | "safari_17_0" => Ok(Profile::Safari17_0),
        "safari_17.2.1" | "safari_17_2_1" => Ok(Profile::Safari17_2_1),
        "safari_17.4.1" | "safari_17_4_1" => Ok(Profile::Safari17_4_1),
        "safari_17.5" | "safari_17_5" => Ok(Profile::Safari17_5),
        "safari_17.6" | "safari_17_6" => Ok(Profile::Safari17_6),
        "safari_18" => Ok(Profile::Safari18),
        "safari_18.2" | "safari_18_2" => Ok(Profile::Safari18_2),
        "safari_18.3" | "safari_18_3" => Ok(Profile::Safari18_3),
        "safari_18.3.1" | "safari_18_3_1" => Ok(Profile::Safari18_3_1),
        "safari_18.5" | "safari_18_5" => Ok(Profile::Safari18_5),
        "safari_26" => Ok(Profile::Safari26),
        "safari_26.1" | "safari_26_1" => Ok(Profile::Safari26_1),
        "safari_26.2" | "safari_26_2" => Ok(Profile::Safari26_2),

        // Safari iOS versions
        "safari_ios_16.5" | "safari_ios_16_5" => Ok(Profile::SafariIos16_5),
        "safari_ios_17.2" | "safari_ios_17_2" => Ok(Profile::SafariIos17_2),
        "safari_ios_17.4.1" | "safari_ios_17_4_1" => Ok(Profile::SafariIos17_4_1),
        "safari_ios_18.1.1" | "safari_ios_18_1_1" => Ok(Profile::SafariIos18_1_1),
        "safari_ios_26" => Ok(Profile::SafariIos26),
        "safari_ios_26.2" | "safari_ios_26_2" => Ok(Profile::SafariIos26_2),

        // Safari iPad versions
        "safari_ipad_18" => Ok(Profile::SafariIPad18),
        "safari_ipad_26" => Ok(Profile::SafariIPad26),
        "safari_ipad_26.2" | "safari_ipad_26_2" => Ok(Profile::SafariIpad26_2),

        // Firefox versions
        "firefox_109" => Ok(Profile::Firefox109),
        "firefox_117" => Ok(Profile::Firefox117),
        "firefox_128" => Ok(Profile::Firefox128),
        "firefox_133" => Ok(Profile::Firefox133),
        "firefox_135" => Ok(Profile::Firefox135),
        "firefox_136" => Ok(Profile::Firefox136),
        "firefox_139" => Ok(Profile::Firefox139),
        "firefox_142" => Ok(Profile::Firefox142),
        "firefox_143" => Ok(Profile::Firefox143),
        "firefox_144" => Ok(Profile::Firefox144),
        "firefox_145" => Ok(Profile::Firefox145),
        "firefox_146" => Ok(Profile::Firefox146),
        "firefox_147" => Ok(Profile::Firefox147),
        "firefox_148" => Ok(Profile::Firefox148),
        "firefox_149" => Ok(Profile::Firefox149),

        // Firefox Private/Android versions
        "firefox_private_135" => Ok(Profile::FirefoxPrivate135),
        "firefox_private_136" => Ok(Profile::FirefoxPrivate136),
        "firefox_android_135" => Ok(Profile::FirefoxAndroid135),

        // OkHttp versions
        "okhttp_3.9" | "okhttp_3_9" => Ok(Profile::OkHttp3_9),
        "okhttp_3.11" | "okhttp_3_11" => Ok(Profile::OkHttp3_11),
        "okhttp_3.13" | "okhttp_3_13" => Ok(Profile::OkHttp3_13),
        "okhttp_3.14" | "okhttp_3_14" => Ok(Profile::OkHttp3_14),
        "okhttp_4.9" | "okhttp_4_9" => Ok(Profile::OkHttp4_9),
        "okhttp_4.10" | "okhttp_4_10" => Ok(Profile::OkHttp4_10),
        "okhttp_4.12" | "okhttp_4_12" => Ok(Profile::OkHttp4_12),
        "okhttp_5" => Ok(Profile::OkHttp5),

        // Generic browser names (map to latest stable versions)
        "chrome" => Ok(Profile::Chrome147),
        "edge" => Ok(Profile::Edge147),
        "opera" => Ok(Profile::Opera130),
        "safari" => Ok(Profile::Safari26_2),
        "firefox" => Ok(Profile::Firefox149),
        "okhttp" => Ok(Profile::OkHttp5),

        // Unsupported browser
        _ => Err(anyhow!("Unsupported browser: {}. Please use a specific browser version (e.g., 'chrome_147', 'firefox_149', 'safari_26.2') or a generic name ('chrome', 'firefox', 'safari', 'edge', 'opera', 'okhttp').", name))
    }
}

/// Map Python OS name to wreq_util::Platform enum
pub fn map_os_to_platform(os: &str) -> Result<Platform> {
    match os.to_lowercase().as_str() {
        "windows" => Ok(Platform::Windows),
        "macos" | "mac" | "osx" => Ok(Platform::MacOS),
        "linux" => Ok(Platform::Linux),
        "android" => Ok(Platform::Android),
        "ios" | "iphone" | "ipad" => Ok(Platform::IOS),
        _ => Err(anyhow!("Unsupported OS: {}. Please use one of: 'windows', 'macos', 'linux', 'android', 'ios'.", os))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chrome_mapping() {
        assert!(matches!(map_browser_to_profile("chrome_147"), Ok(Profile::Chrome147)));
        assert!(matches!(map_browser_to_profile("chrome_131"), Ok(Profile::Chrome131)));
        assert!(matches!(map_browser_to_profile("chrome"), Ok(Profile::Chrome147)));
    }

    #[test]
    fn test_firefox_mapping() {
        assert!(matches!(map_browser_to_profile("firefox_149"), Ok(Profile::Firefox149)));
        assert!(matches!(map_browser_to_profile("firefox_136"), Ok(Profile::Firefox136)));
        assert!(matches!(map_browser_to_profile("firefox"), Ok(Profile::Firefox149)));
    }

    #[test]
    fn test_safari_mapping() {
        assert!(matches!(map_browser_to_profile("safari_26.2"), Ok(Profile::Safari26_2)));
        assert!(matches!(map_browser_to_profile("safari_18"), Ok(Profile::Safari18)));
        assert!(matches!(map_browser_to_profile("safari"), Ok(Profile::Safari26_2)));
    }

    #[test]
    fn test_os_mapping() {
        assert!(matches!(map_os_to_platform("windows"), Ok(Platform::Windows)));
        assert!(matches!(map_os_to_platform("macos"), Ok(Platform::MacOS)));
        assert!(matches!(map_os_to_platform("mac"), Ok(Platform::MacOS)));
        assert!(matches!(map_os_to_platform("linux"), Ok(Platform::Linux)));
        assert!(matches!(map_os_to_platform("android"), Ok(Platform::Android)));
        assert!(matches!(map_os_to_platform("ios"), Ok(Platform::IOS)));
    }

    #[test]
    fn test_invalid_browser() {
        assert!(map_browser_to_profile("invalid_browser").is_err());
    }

    #[test]
    fn test_invalid_os() {
        assert!(map_os_to_platform("invalid_os").is_err());
    }
}
