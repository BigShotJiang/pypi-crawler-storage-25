// Utility functions for never_primp
use wreq::tls::trust::CertStore;

/// Load CA certificates from a PEM file path.
/// Returns the CertStore on success, or an error if the file cannot be read or parsed.
pub fn load_ca_cert_from_file(path: &str) -> anyhow::Result<CertStore> {
    let pem_data = std::fs::read(path)
        .map_err(|e| anyhow::anyhow!("Failed to read CA cert file '{}': {}", path, e))?;
    let store = CertStore::builder()
        .add_stack_pem_certs(&pem_data)
        .build()
        .map_err(|e| anyhow::anyhow!("Failed to parse CA cert file '{}': {}", path, e))?;
    Ok(store)
}
