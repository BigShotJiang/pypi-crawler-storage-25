// RClient (synchronous client) implementation
use std::sync::{Arc, RwLock};
use std::time::Duration;

use pyo3::prelude::*;
use pyo3::types::PyAny;
use pythonize::depythonize;
use serde_json::Value;
use wreq::Method;
use wreq::cookie::CookieStore;
use wreq::retry::Policy as RetryPolicy;
use http::Version;

use crate::browser_mapping::{map_browser_to_profile, map_os_to_platform};
use crate::error::anyhow_to_pyerr;
use crate::response::Response;
use crate::runtime::RUNTIME;
use crate::types::IndexMapSSR;

// ===== Cookie helpers =====

/// Parse cookies from a `Jar` for a given URI into an existing map (without locking).
fn parse_jar_cookies_into(jar: &wreq::cookie::Jar, uri: &http::Uri, map: &mut IndexMapSSR) {
    match jar.cookies(uri, Version::HTTP_11) {
        wreq::cookie::Cookies::Compressed(header) => {
            if let Ok(s) = header.to_str() {
                for pair in s.split(';') {
                    if let Some((k, v)) = pair.trim().split_once('=') {
                        map.insert(k.trim().to_string(), v.to_string());
                    }
                }
            }
        }
        wreq::cookie::Cookies::Uncompressed(headers) => {
            for header in headers {
                if let Ok(s) = header.to_str() {
                    if let Some((k, v)) = s.split_once('=') {
                        map.insert(k.to_string(), v.to_string());
                    }
                }
            }
        }
        wreq::cookie::Cookies::Empty | _ => {}
    }
}

// ===== CookieJarIter =====

/// Python iterator returned by `RequestsCookieJar.__iter__`.
#[pyclass]
struct CookieJarIter {
    inner: std::vec::IntoIter<String>,
}

#[pymethods]
impl CookieJarIter {
    fn __iter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }
    fn __next__(mut slf: PyRefMut<'_, Self>) -> Option<String> {
        slf.inner.next()
    }
}

// ===== RequestsCookieJar =====

/// A dict-like cookie jar that mirrors Python `requests.cookies.RequestsCookieJar`.
///
/// Cookies set through this object (without a `domain`) are **global** — they are
/// sent with every request regardless of URL.  Cookies stored via `.set(domain=…)`
/// are scoped to the matching domain using RFC 6265 rules (backed by the wreq `Jar`).
///
/// Access it via `client.cookies`.
#[pyclass]
pub struct RequestsCookieJar {
    /// Domain-free cookies sent with every request.
    pub(crate) global: Arc<RwLock<IndexMapSSR>>,
    /// Domain-scoped cookie store (shared with the wreq client).
    jar: Option<Arc<wreq::cookie::Jar>>,
}

#[pymethods]
impl RequestsCookieJar {
    // ----- dict protocol -----

    fn __getitem__(&self, name: &str) -> PyResult<String> {
        self._merged()
            .get(name)
            .cloned()
            .ok_or_else(|| PyErr::new::<pyo3::exceptions::PyKeyError, _>(name.to_string()))
    }

    fn __setitem__(&self, name: String, value: String) {
        self.global.write().unwrap().insert(name, value);
    }

    fn __delitem__(&self, name: &str) -> PyResult<()> {
        if self.global.write().unwrap().shift_remove(name).is_some() {
            Ok(())
        } else {
            Err(PyErr::new::<pyo3::exceptions::PyKeyError, _>(name.to_string()))
        }
    }

    fn __contains__(&self, name: &str) -> bool {
        if self.global.read().unwrap().contains_key(name) {
            return true;
        }
        self.jar
            .as_ref()
            .map(|jar| jar.get_all().any(|c| c.name() == name))
            .unwrap_or(false)
    }

    fn __len__(&self) -> usize {
        self._merged().len()
    }

    fn __repr__(&self) -> String {
        let merged = self._merged();
        let pairs: Vec<String> = merged
            .iter()
            .map(|(k, v)| format!("{:?}: {:?}", k, v))
            .collect();
        format!("<RequestsCookieJar {{{}}}>", pairs.join(", "))
    }

    fn __iter__(&self, py: Python<'_>) -> PyResult<Py<CookieJarIter>> {
        let keys: Vec<String> = self._merged().into_keys().collect();
        Py::new(py, CookieJarIter { inner: keys.into_iter() })
    }

    // ----- requests-style API -----

    /// Get a cookie value by name (checks global first, then jar), returning `default` if not found.
    #[pyo3(signature = (name, default=None))]
    fn get(&self, name: &str, default: Option<String>) -> Option<String> {
        self._merged()
            .get(name)
            .cloned()
            .or(default)
    }

    /// Set a cookie.
    ///
    /// * Without `domain` — stored as a **global** cookie (sent to all URLs).
    /// * With `domain`    — stored in the domain-scoped jar (RFC 6265 matching).
    #[pyo3(signature = (name, value, domain=None, path=None))]
    fn set(
        &self,
        name: String,
        value: String,
        domain: Option<String>,
        path: Option<String>,
    ) -> PyResult<()> {
        match domain {
            Some(ref d) => {
                let jar = self.jar.as_ref().ok_or_else(|| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        "Cookie store is disabled",
                    )
                })?;
                let mut cookie_str = format!("{}={}", name, value);
                cookie_str.push_str(&format!("; Domain={}", d));
                cookie_str
                    .push_str(&format!("; Path={}", path.as_deref().unwrap_or("/")));
                let url = format!("https://{}", d.trim_start_matches('.'));
                jar.add(cookie_str.as_str(), url.as_str());
                Ok(())
            }
            None => {
                self.global.write().unwrap().insert(name, value);
                Ok(())
            }
        }
    }

    /// Batch-update global cookies from a dict.
    fn update(&self, cookies: IndexMapSSR) {
        let mut g = self.global.write().unwrap();
        for (k, v) in cookies {
            g.insert(k, v);
        }
    }

    /// Clear **all** cookies — both global cookies and domain-scoped jar cookies.
    fn clear(&self) {
        self.global.write().unwrap().clear();
        if let Some(jar) = &self.jar {
            jar.clear();
        }
    }

    /// Clear only the global (domain-free) cookies.
    fn clear_global(&self) {
        self.global.write().unwrap().clear();
    }

    /// Clear only the domain-scoped jar cookies (e.g. those received in `Set-Cookie` responses).
    fn clear_jar(&self) -> PyResult<()> {
        self.jar
            .as_ref()
            .ok_or_else(|| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Cookie store is disabled")
            })?
            .clear();
        Ok(())
    }

    // ----- views -----

    /// All cookies (global + jar) as `(name, value)` pairs.
    /// Jar cookies with the same name as a global cookie are shadowed by the global value.
    fn items(&self) -> Vec<(String, String)> {
        self._merged()
            .into_iter()
            .collect()
    }

    fn keys(&self) -> Vec<String> {
        self._merged().into_keys().collect()
    }

    fn values(&self) -> Vec<String> {
        self._merged().into_values().collect()
    }

    /// Return all cookies (global + jar) as a plain `dict[str, str]`.
    ///
    /// This is the easiest way to serialise the full session cookie state::
    ///
    ///     import json
    ///     json.dumps(client.cookies.get_dict())
    ///
    /// When the same cookie name appears in both global and jar, the **global**
    /// value wins (highest priority).
    fn get_dict(&self) -> IndexMapSSR {
        self._merged()
    }

    /// All domain-scoped cookies from the jar as `(name, value, domain, path)` tuples.
    /// Includes cookies received via `Set-Cookie` responses and those added with `.set(domain=…)`.
    fn get_jar_cookies(&self) -> Vec<(String, String, String, String)> {
        self.jar
            .as_ref()
            .map(|jar| {
                jar.get_all()
                    .map(|c| {
                        (
                            c.name().to_string(),
                            c.value().to_string(),
                            c.domain().unwrap_or("").to_string(),
                            c.path().unwrap_or("/").to_string(),
                        )
                    })
                    .collect()
            })
            .unwrap_or_default()
    }

    /// Find a cookie value by name across **all domains and paths** in the jar.
    ///
    /// Unlike URL-based lookups (which apply RFC 6265 path-prefix matching), this
    /// method ignores path restrictions and returns the value from the entry with the
    /// **longest (most specific) path** for that name — which is typically the one
    /// set most recently by a response `Set-Cookie` header.
    ///
    /// This is the recommended way to read response cookies when the request URL and
    /// the current lookup URL differ in path (e.g. cookie set at `/_sec/verify` but
    /// you query with the root `orig_url`).
    ///
    /// Also checks the global (domain-free) cookie map first.
    #[pyo3(signature = (name, default=None))]
    fn find(&self, name: &str, default: Option<String>) -> Option<String> {
        // Check global cookies first
        if let Some(v) = self.global.read().unwrap().get(name) {
            return Some(v.clone());
        }

        // Search jar across all domains/paths, pick the most specific (longest) path
        self.jar
            .as_ref()
            .and_then(|jar| {
                jar.get_all()
                    .filter(|c| c.name() == name)
                    .max_by_key(|c| c.path().map(|p| p.len()).unwrap_or(0))
                    .map(|c| c.value().to_string())
            })
            .or(default)
    }

    /// Get cookies from the jar that would be sent to `url` (RFC 6265 domain + path matching).
    ///
    /// Note: if the target cookie was stored from a response at a *more specific* path
    /// (e.g. `/_sec/verify`) and you query with a less specific URL (e.g. root `/`),
    /// the cookie will **not** appear here — use `.find(name)` in that case.
    #[pyo3(signature = (url))]
    fn get_cookies_for_url(&self, url: &str) -> PyResult<IndexMapSSR> {
        let mut map = IndexMapSSR::default();
        // Global cookies are always included
        for (k, v) in self.global.read().unwrap().iter() {
            map.insert(k.clone(), v.clone());
        }
        if let Some(jar) = &self.jar {
            let uri: http::Uri = url
                .parse()
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    format!("Invalid URL: {}", e),
                ))?;
            parse_jar_cookies_into(jar, &uri, &mut map);
        }
        Ok(map)
    }
}

impl RequestsCookieJar {
    /// Build a merged `IndexMapSSR` of all cookies: jar cookies first (lowest priority),
    /// then global cookies override (highest priority).  When the same name appears in
    /// both, the global value wins.
    fn _merged(&self) -> IndexMapSSR {
        let mut map = IndexMapSSR::default();

        // 1. Jar cookies (most-specific path wins within the jar)
        if let Some(jar) = &self.jar {
            // Collect all jar cookies, sorted so longest path comes last
            // (inserting last = wins for duplicate keys in IndexMap)
            let mut jar_cookies: Vec<_> = jar.get_all().collect();
            jar_cookies.sort_by_key(|c| c.path().map(|p| p.len()).unwrap_or(0));
            for c in jar_cookies {
                map.insert(c.name().to_string(), c.value().to_string());
            }
        }

        // 2. Global cookies override jar cookies with the same name
        for (k, v) in self.global.read().unwrap().iter() {
            map.insert(k.clone(), v.clone());
        }

        map
    }
}

#[pyclass(subclass)]
/// HTTP client with browser impersonation support
pub struct RClient {
    client: wreq::Client,
    /// Domain-scoped cookie store (RFC 6265, backed by wreq).
    ///
    /// NOTE: When enabled, this Jar accumulates ALL Set-Cookie headers from every
    /// response indefinitely. Under high concurrency hitting many domains, it grows
    /// without bound and its internal RwLock becomes a write-contention hotspot.
    /// Disable with cookie_store=False when session persistence is not needed.
    cookie_jar: Option<Arc<wreq::cookie::Jar>>,
    /// Domain-free global cookies shared with `RequestsCookieJar`.
    global_cookies: Arc<RwLock<IndexMapSSR>>,

    // Client-level configuration (exposed to Python)
    #[pyo3(get, set)]
    pub auth: Option<(String, Option<String>)>,

    #[pyo3(get, set)]
    pub auth_bearer: Option<String>,

    #[pyo3(get, set)]
    pub params: Option<IndexMapSSR>,

    #[pyo3(get, set)]
    pub proxy: Option<String>,

    #[pyo3(get, set)]
    pub timeout: Option<f64>,

    #[pyo3(get)]
    pub impersonate: Option<String>,

    #[pyo3(get)]
    pub impersonate_os: Option<String>,

    // Internal configuration (not exposed)
    headers: Option<IndexMapSSR>,
    referer: Option<bool>,
    follow_redirects: Option<bool>,
    max_redirects: Option<usize>,
    verify: Option<bool>,
    ca_cert_file: Option<String>,
    https_only: Option<bool>,
    http1_only: Option<bool>,
    http2_only: Option<bool>,
    #[pyo3(get, set)]
    split_cookies: Option<bool>,

    // Connection pool settings — stored so create_temp_client() reuses same values
    pool_max_idle_per_host: usize,
    pool_max_size: usize,
    pool_idle_timeout: f64,
}

#[pymethods]
impl RClient {
    /// Create a new HTTP client with default settings (for convenience functions)
    #[staticmethod]
    pub(crate) fn new_default() -> PyResult<Self> {
        Self::new(
            None, None, None, None,
            Some(true), Some(true),
            None, None, None, None,
            Some(true), Some(20),
            Some(true), None,
            Some(false), Some(false), Some(false),
            None, None,
            None, None, None,
        )
    }

    /// Create a new HTTP client
    ///
    /// # Arguments
    ///
    /// * `auth` - Basic authentication (username, password)
    /// * `auth_bearer` - Bearer token authentication
    /// * `params` - Default query parameters
    /// * `headers` - Default headers
    /// * `cookie_store` - Enable cookie persistence (default: true)
    /// * `referer` - Auto-set Referer header (default: true)
    /// * `proxy` - Proxy URL
    /// * `timeout` - Request timeout in seconds
    /// * `impersonate` - Browser to impersonate (e.g., "chrome_143", "firefox_146")
    /// * `impersonate_os` - OS to impersonate (e.g., "windows", "macos")
    /// * `follow_redirects` - Follow redirects (default: true)
    /// * `max_redirects` - Maximum redirects (default: 20)
    /// * `verify` - Verify SSL certificates (default: true)
    /// * `ca_cert_file` - Path to CA certificate file
    /// * `https_only` - Restrict to HTTPS only (default: false)
    /// * `http1_only` - Use HTTP/1.1 only (default: false)
    /// * `http2_only` - Use HTTP/2 only (default: false)
    /// * `split_cookies` - Send cookies in separate headers (HTTP/2 style, default: None)
    #[new]
    #[pyo3(signature = (
        auth=None, auth_bearer=None, params=None, headers=None, cookie_store=Some(true),
        referer=Some(true), proxy=None, timeout=None, impersonate=None, impersonate_os=None,
        follow_redirects=Some(true), max_redirects=Some(20), verify=Some(true), ca_cert_file=None,
        https_only=Some(false), http1_only=Some(false), http2_only=Some(false), split_cookies=None,
        max_retries=None,
        pool_max_idle_per_host=None, pool_max_size=None, pool_idle_timeout=None
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        auth: Option<(String, Option<String>)>,
        auth_bearer: Option<String>,
        params: Option<IndexMapSSR>,
        headers: Option<IndexMapSSR>,
        cookie_store: Option<bool>,
        referer: Option<bool>,
        proxy: Option<String>,
        timeout: Option<f64>,
        impersonate: Option<String>,
        impersonate_os: Option<String>,
        follow_redirects: Option<bool>,
        max_redirects: Option<usize>,
        verify: Option<bool>,
        ca_cert_file: Option<String>,
        https_only: Option<bool>,
        http1_only: Option<bool>,
        http2_only: Option<bool>,
        split_cookies: Option<bool>,
        max_retries: Option<u32>,
        pool_max_idle_per_host: Option<usize>,
        pool_max_size: Option<usize>,
        pool_idle_timeout: Option<f64>,
    ) -> PyResult<Self> {
        let mut client_builder = wreq::Client::builder();

        // Browser impersonation
        if let Some(browser) = &impersonate {
            let profile = map_browser_to_profile(browser).map_err(anyhow_to_pyerr)?;
            if let Some(os) = &impersonate_os {
                let platform = map_os_to_platform(os).map_err(anyhow_to_pyerr)?;
                let emulation = wreq_util::Emulation::builder()
                    .profile(profile)
                    .platform(platform)
                    .build();
                client_builder = client_builder.emulation(emulation);
            } else {
                client_builder = client_builder.emulation(profile);
            }
        }

        // Connection pool — defaults tuned for typical multi-host scraping workloads.
        // pool_max_idle_per_host: keep at most N idle connections per host.
        //   Lower = less idle memory; higher = fewer TCP reconnects when bursting to the same host.
        // pool_max_size: hard cap on total connections across all hosts.
        // pool_idle_timeout: close idle connections after N seconds to reclaim memory faster.
        let eff_idle_per_host = pool_max_idle_per_host.unwrap_or(32);
        let eff_pool_max      = pool_max_size.unwrap_or(512);
        let eff_idle_timeout  = pool_idle_timeout.unwrap_or(30.0);
        client_builder = client_builder
            .pool_max_idle_per_host(eff_idle_per_host)
            .pool_max_size(eff_pool_max)
            .pool_idle_timeout(Duration::from_secs_f64(eff_idle_timeout))
            .tcp_keepalive(Duration::from_secs(30))
            .tcp_keepalive_interval(Duration::from_secs(15))
            .tcp_keepalive_retries(3u32)
            .tcp_nodelay(true);

        // Retry policy
        if let Some(retries) = max_retries {
            let policy = RetryPolicy::default().max_retries_per_request(retries);
            client_builder = client_builder.retry(policy);
        }

        // Cookie store - create Jar and pass to client
        // compressed=true  → single merged "Cookie: a=1; b=2" header (HTTP/1.1 style)
        // compressed=false → separate "cookie: a=1" / "cookie: b=2" headers (HTTP/2 style)
        // When split_cookies=true, use uncompressed so session-level cookies are also split.
        let cookie_jar = if cookie_store.unwrap_or(true) {
            let jar = Arc::new(wreq::cookie::Jar::default());
            client_builder = client_builder.cookie_provider(jar.clone());
            Some(jar)
        } else {
            None
        };

        // Referer
        if referer.unwrap_or(true) {
            client_builder = client_builder.referer(true);
        }

        // Proxy
        let proxy = proxy.or_else(|| std::env::var("PRIMP_PROXY").ok());
        if let Some(proxy_url) = &proxy {
            let proxy = wreq::Proxy::all(proxy_url)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
            client_builder = client_builder.proxy(proxy);
        }

        // Timeout
        if let Some(seconds) = timeout {
            client_builder = client_builder.timeout(Duration::from_secs_f64(seconds));
        }

        // Redirects
        if follow_redirects.unwrap_or(true) {
            client_builder = client_builder
                .redirect(wreq::redirect::Policy::limited(max_redirects.unwrap_or(20)));
        } else {
            client_builder = client_builder.redirect(wreq::redirect::Policy::none());
        }

        // SSL verification
        if !verify.unwrap_or(true) {
            client_builder = client_builder.tls_cert_verification(false);
        } else if let Some(ca_path) = &ca_cert_file {
            let cert_store = crate::utils::load_ca_cert_from_file(ca_path)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
            client_builder = client_builder.tls_cert_store(cert_store);
        }

        // HTTPS only
        if https_only.unwrap_or(false) {
            client_builder = client_builder.https_only(true);
        }

        // HTTP version control (http1_only takes priority over http2_only)
        if http1_only.unwrap_or(false) {
            client_builder = client_builder.http1_only();
        } else if http2_only.unwrap_or(false) {
            client_builder = client_builder.http2_only();
        }

        // Build client
        let client = client_builder
            .build()
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

        Ok(RClient {
            client,
            cookie_jar,
            global_cookies: Arc::new(RwLock::new(IndexMapSSR::default())),
            auth,
            auth_bearer,
            params,
            proxy,
            timeout,
            impersonate,
            impersonate_os,
            headers,
            referer,
            follow_redirects,
            max_redirects,
            verify,
            ca_cert_file,
            https_only,
            http1_only,
            http2_only,
            split_cookies,
            pool_max_idle_per_host: eff_idle_per_host,
            pool_max_size: eff_pool_max,
            pool_idle_timeout: eff_idle_timeout,
        })
    }

    // ===== Cookie management (requests-style API) =====

    /// The cookie jar for this session.
    ///
    /// Behaves like Python `requests.Session.cookies` — supports dict-style access
    /// (`cookies['name'] = 'value'`) without needing to specify a URL or domain.
    ///
    /// * `client.cookies['name'] = 'value'`  → global cookie sent with every request
    /// * `client.cookies.set('name', 'value', domain='x.com')` → domain-scoped cookie
    /// * `client.cookies.update({'a': '1'})` → batch-set global cookies
    /// * `del client.cookies['name']`         → remove global cookie
    /// * `client.cookies.clear()`             → clear all cookies (global + jar)
    /// * `client.cookies.get_jar_cookies()`   → list domain-scoped cookies from jar
    #[getter]
    pub fn cookies(&self) -> RequestsCookieJar {
        RequestsCookieJar {
            global: self.global_cookies.clone(),
            jar: self.cookie_jar.clone(),
        }
    }

    /// Replace the entire set of global cookies at once.
    #[setter]
    pub fn set_cookies_prop(&self, cookies: IndexMapSSR) {
        let mut g = self.global_cookies.write().unwrap();
        g.clear();
        for (k, v) in cookies {
            g.insert(k, v);
        }
    }

    /// Export all cookies (global + jar) for cross-session persistence.
    ///
    /// Returns a list of `(name, value, domain, path)` tuples.
    /// Global (domain-free) cookies are exported with an empty domain string.
    /// Pass the result to `import_cookies()` to restore.
    #[pyo3(signature = ())]
    pub fn export_cookies(&self) -> PyResult<Vec<(String, String, String, String)>> {
        let mut out: Vec<(String, String, String, String)> = Vec::new();

        // Global cookies (domain = "")
        for (name, value) in self.global_cookies.read().unwrap().iter() {
            out.push((name.clone(), value.clone(), String::new(), String::new()));
        }

        // Domain-scoped jar cookies
        if let Some(jar) = &self.cookie_jar {
            for c in jar.get_all() {
                out.push((
                    c.name().to_string(),
                    c.value().to_string(),
                    c.domain().unwrap_or("").to_string(),
                    c.path().unwrap_or("/").to_string(),
                ));
            }
        }

        Ok(out)
    }

    /// Import cookies from a list of `(name, value, domain, path)` tuples.
    ///
    /// * Tuples with an empty domain are restored as **global** cookies.
    /// * Tuples with a domain are stored in the domain-scoped jar.
    #[pyo3(signature = (cookies))]
    pub fn import_cookies(&self, cookies: Vec<(String, String, String, String)>) -> PyResult<()> {
        for (name, value, domain, path) in cookies {
            if domain.is_empty() {
                // Restore as global cookie
                self.global_cookies.write().unwrap().insert(name, value);
            } else {
                let jar = self.cookie_jar.as_ref().ok_or_else(|| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        "Cookie store is disabled. Enable it by setting cookie_store=True",
                    )
                })?;
                let cookie_str = format!(
                    "{}={}; Domain={}; Path={}",
                    name,
                    value,
                    domain,
                    if path.is_empty() { "/" } else { &path }
                );
                let url = format!("https://{}", domain.trim_start_matches('.'));
                jar.add(cookie_str.as_str(), url.as_str());
            }
        }
        Ok(())
    }

    /// Get client-level headers
    ///
    /// # Returns
    /// Dictionary of header name-value pairs
    #[pyo3(signature = ())]
    pub fn get_headers(&self) -> PyResult<IndexMapSSR> {
        Ok(self.headers.clone().unwrap_or_default())
    }

    /// Set client-level headers (replaces all existing headers)
    ///
    /// # Arguments
    /// * `headers` - Dictionary of header name-value pairs
    #[pyo3(signature = (headers))]
    pub fn set_headers(&mut self, headers: Option<IndexMapSSR>) -> PyResult<()> {
        self.headers = headers;
        Ok(())
    }

    /// Update client-level headers (merges with existing headers)
    ///
    /// # Arguments
    /// * `headers` - Dictionary of header name-value pairs to add/update
    #[pyo3(signature = (headers))]
    pub fn headers_update(&mut self, headers: IndexMapSSR) -> PyResult<()> {
        if let Some(ref mut existing_headers) = self.headers {
            // Update existing headers (preserves insertion order)
            for (key, value) in headers {
                existing_headers.insert(key, value);
            }
        } else {
            // No existing headers, set new ones
            self.headers = Some(headers);
        }
        Ok(())
    }

    /// Set a single header
    ///
    /// # Arguments
    /// * `name` - Header name
    /// * `value` - Header value
    #[pyo3(signature = (name, value))]
    pub fn set_header(&mut self, name: String, value: String) -> PyResult<()> {
        if let Some(ref mut existing_headers) = self.headers {
            existing_headers.insert(name, value);
        } else {
            let mut new_headers = IndexMapSSR::default();
            new_headers.insert(name, value);
            self.headers = Some(new_headers);
        }
        Ok(())
    }

    /// Get a single header value by name
    ///
    /// # Arguments
    /// * `name` - Header name
    ///
    /// # Returns
    /// Header value as string, or None if not found
    #[pyo3(signature = (name))]
    pub fn get_header(&self, name: String) -> PyResult<Option<String>> {
        if let Some(ref headers) = self.headers {
            return Ok(headers.get(&name).cloned());
        }
        Ok(None)
    }

    /// Delete a single header by name
    ///
    /// # Arguments
    /// * `name` - Header name to remove
    #[pyo3(signature = (name))]
    pub fn delete_header(&mut self, name: String) -> PyResult<()> {
        if let Some(ref mut headers) = self.headers {
            headers.shift_remove(&name);
        }
        Ok(())
    }

    /// Clear all client-level headers
    #[pyo3(signature = ())]
    pub fn clear_headers(&mut self) -> PyResult<()> {
        self.headers = None;
        Ok(())
    }

    /// Close the client and release all idle TCP connections immediately.
    ///
    /// Replaces the internal wreq::Client with a minimal placeholder, dropping
    /// the Arc ref to the old connection pool. If no requests are in-flight at
    /// the time of the call, all idle connections are closed synchronously.
    /// In-flight requests hold their own Arc clone and complete normally.
    ///
    /// After calling close(), the client must not be used for further requests.
    #[pyo3(signature = ())]
    pub fn close(&mut self) -> PyResult<()> {
        // Build a minimal replacement client — this drops the old Arc<ClientService>.
        // If our ref was the last one, the connection pool is immediately freed.
        self.client = wreq::Client::new();
        // Drop the cookie jar so its memory is also released.
        self.cookie_jar = None;
        Ok(())
    }

    /// Generic request method with full parameter support
    ///
    /// # Arguments
    ///
    /// * `method` - HTTP method (GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS)
    /// * `url` - URL to request
    /// * `params` - Query parameters
    /// * `headers` - HTTP headers
    /// * `cookies` - Cookies to send
    /// * `content` - Raw bytes content
    /// * `data` - Form data (dict/bytes/string)
    /// * `json` - JSON data
    /// * `files` - Files for multipart upload
    /// * `auth` - Basic authentication
    /// * `auth_bearer` - Bearer token authentication
    /// * `timeout` - Request timeout
    /// * `read_timeout` - Read timeout
    /// * `proxy` - Proxy URL
    /// * `impersonate` - Browser to impersonate
    /// * `impersonate_os` - OS to impersonate
    /// * `verify` - Verify SSL certificates
    /// * `ca_cert_file` - CA certificate file
    /// * `follow_redirects` - Follow redirects
    /// * `max_redirects` - Maximum redirects
    /// * `https_only` - HTTPS only
    /// * `http1_only` - HTTP/1.1 only
    /// * `http2_only` - HTTP/2 only
    /// * `split_cookies` - Split cookies into separate headers
    #[pyo3(signature = (method, url, params=None, headers=None, cookies=None, content=None,
        data=None, json=None, files=None, auth=None, auth_bearer=None, timeout=None,
        read_timeout=None, proxy=None, impersonate=None, impersonate_os=None, verify=None,
        ca_cert_file=None, _follow_redirects=None, _max_redirects=None, https_only=None,
        http1_only=None, http2_only=None, split_cookies=None))]
    #[allow(clippy::too_many_arguments)]
    pub fn request(
        &self,
        py: Python,
        method: &str,
        url: &str,
        params: Option<IndexMapSSR>,
        headers: Option<IndexMapSSR>,
        cookies: Option<IndexMapSSR>,
        content: Option<Vec<u8>>,
        data: Option<&Bound<'_, PyAny>>,
        json: Option<&Bound<'_, PyAny>>,
        files: Option<IndexMapSSR>,
        auth: Option<(String, Option<String>)>,
        auth_bearer: Option<String>,
        timeout: Option<f64>,
        read_timeout: Option<f64>,
        proxy: Option<String>,
        impersonate: Option<String>,
        impersonate_os: Option<String>,
        verify: Option<bool>,
        ca_cert_file: Option<String>,
        _follow_redirects: Option<bool>,
        _max_redirects: Option<usize>,
        https_only: Option<bool>,
        http1_only: Option<bool>,
        http2_only: Option<bool>,
        split_cookies: Option<bool>,
    ) -> PyResult<Response> {
        // Parse method
        let method = match method.to_uppercase().as_str() {
            "GET" => Method::GET,
            "POST" => Method::POST,
            "PUT" => Method::PUT,
            "DELETE" => Method::DELETE,
            "PATCH" => Method::PATCH,
            "HEAD" => Method::HEAD,
            "OPTIONS" => Method::OPTIONS,
            _ => {
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    format!("Invalid HTTP method: {}", method)
                ))
            }
        };

        let is_post_put_patch = matches!(method, Method::POST | Method::PUT | Method::PATCH);

        // Determine if we need a temporary client
        let need_temp_client = impersonate.is_some()
            || impersonate_os.is_some()
            || verify.is_some()
            || ca_cert_file.is_some()
            || https_only.is_some()
            || http1_only.is_some()
            || http2_only.is_some();

        // Handle data parameter - support bytes, dict/json types, and strings
        let mut data_bytes: Option<Vec<u8>> = None;
        let mut data_value: Option<Value> = None;

        if let Some(data_param) = data {
            // Check if data is bytes
            if let Ok(bytes) = data_param.extract::<Vec<u8>>() {
                data_bytes = Some(bytes);
            }
            // Check if data is a string (send as-is, don't parse)
            else if let Ok(string_data) = data_param.extract::<String>() {
                data_bytes = Some(string_data.into_bytes());
            }
            // Otherwise try to deserialize as JSON value (dict, list, etc.)
            else {
                data_value = Some(depythonize(data_param)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                        format!("Failed to parse data: {}", e)
                    ))?);
            }
        }

        let json_value: Option<Value> = json.map(depythonize).transpose()
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                format!("Failed to parse json: {}", e)
            ))?;

        let params = params.or_else(|| self.params.clone());
        let auth = auth.or(self.auth.clone());
        let auth_bearer = auth_bearer.or(self.auth_bearer.clone());

        // Determine effective settings
        let effective_split_cookies = split_cookies.or(self.split_cookies);
        let effective_timeout = timeout.or(self.timeout);
        let effective_proxy = if !need_temp_client {
            proxy.as_ref().cloned().or_else(|| self.proxy.clone())
        } else {
            None
        };

        // Clone client or create temporary one.
        // wreq::Client is internally Arc-based so clone is cheap (no lock).
        let client = if need_temp_client {
            self.create_temp_client(
                impersonate,
                impersonate_os,
                verify,
                ca_cert_file,
                https_only,
                http1_only,
                http2_only,
                proxy,
                timeout,
            )?
        } else {
            self.client.clone()
        };

        // Check if user explicitly set Content-Type to application/json
        let content_type_is_json = headers.as_ref()
            .and_then(|h| h.get("content-type"))
            .or_else(|| headers.as_ref().and_then(|h| h.get("Content-Type")))
            .map(|s| s.to_lowercase().contains("application/json"))
            .unwrap_or(false);

        // Clone client-level headers for use in async block
        let client_headers = self.headers.clone();

        // Snapshot global cookies (domain-free) before entering the async block.
        // Non-empty → we manually merge jar + global + explicit and set the Cookie header
        // ourselves (which also prevents the inject_cookies middleware from double-injecting jar
        // cookies, since they are already included in the merge).
        let global_cookies_snap: Option<IndexMapSSR> = {
            let g = self.global_cookies.read().unwrap();
            if g.is_empty() { None } else { Some(g.clone()) }
        };
        // Clone the jar Arc for potential manual merge inside the async block.
        let session_jar = self.cookie_jar.clone();

        // Execute request asynchronously with GIL release
        let future = async move {
            // Create request builder (Client::request takes &self, no lock needed)
            let mut request_builder = client.request(method, url);

            // Params
            if let Some(params) = params {
                request_builder = request_builder.query(&params);
            }

            // ===== Enhanced Header Processing with Order Control =====
            // Using OrigHeaderMap for precise header ordering (anti-detection)
            // Using HeaderMap for efficient header storage with insert (override) behavior

            use wreq::header::{HeaderMap, HeaderValue, OrigHeaderMap, OrigHeaderName};

            // Step 1: Collect all user headers into a HeaderMap (insert = override, not append)
            let mut user_headermap = HeaderMap::new();

            // Apply client-level headers first
            if let Some(ref client_hdrs) = client_headers {
                for (key, value) in client_hdrs.iter() {
                    if let (Ok(header_name), Ok(header_value)) = (
                        key.parse::<wreq::header::HeaderName>(),
                        value.parse::<HeaderValue>()
                    ) {
                        user_headermap.insert(header_name, header_value);  // insert = override
                    }
                }
            }

            // Step 2: Apply request-level headers (override client headers)
            if let Some(ref request_headers) = headers {
                for (key, value) in request_headers.iter() {
                    if let (Ok(header_name), Ok(header_value)) = (
                        key.parse::<wreq::header::HeaderName>(),
                        value.parse::<HeaderValue>()
                    ) {
                        user_headermap.insert(header_name, header_value);  // insert = override
                    }
                }
            }

            // Step 3: Build OrigHeaderMap from user headers order (anti-detection)
            // The order of headers in the user's IndexMap determines the sending order
            // This is critical for evading bot detection that analyzes header ordering
            let mut orig_headers = OrigHeaderMap::new();

            // First add client-level headers in their order
            if let Some(ref client_hdrs) = client_headers {
                for (key, _) in client_hdrs.iter() {
                    orig_headers.insert(key.clone());
                }
            }

            // Then add request-level headers (may override order for duplicates)
            if let Some(ref request_headers) = headers {
                for (key, _) in request_headers.iter() {
                    orig_headers.insert(key.clone());
                }
            }

            // Step 3.5: Merge global cookies + jar cookies + explicit cookies.
            //
            // Priority (lowest → highest): jar cookies < global cookies < explicit cookies
            //
            // When global_cookies is non-empty we build the merged map ourselves and set the
            // Cookie header manually. The inject_cookies middleware will then see that the header
            // already exists and skip its own injection — which is correct because we've already
            // included the jar cookies in the merge.
            //
            // When global_cookies is empty, behaviour is unchanged: explicit cookies go through
            // Step 6 and the middleware handles jar cookies automatically.
            let effective_cookies: Option<IndexMapSSR> = if let Some(ref global) = global_cookies_snap {
                let mut merged = IndexMapSSR::default();

                // 1. Jar cookies for this specific URL (matched by RFC 6265 domain/path rules)
                if let Some(ref jar) = session_jar {
                    if let Ok(uri) = url.parse::<http::Uri>() {
                        parse_jar_cookies_into(jar, &uri, &mut merged);
                    }
                }

                // 2. Global cookies override jar cookies with the same name
                for (k, v) in global.iter() {
                    merged.insert(k.clone(), v.clone());
                }

                // 3. Explicit per-request cookies have the highest priority
                if let Some(ref explicit) = cookies {
                    for (k, v) in explicit.iter() {
                        merged.insert(k.clone(), v.clone());
                    }
                }

                if merged.is_empty() { None } else { Some(merged) }
            } else {
                // No global cookies — use the explicit cookies as-is (jar handled by middleware)
                cookies
            };

            // Add "cookie" to orig_headers for correct position control.
            // Covers: explicit cookies, global cookies, and split session-jar cookies.
            let needs_cookie_in_orig = effective_cookies.is_some()
                || effective_split_cookies == Some(true);
            if needs_cookie_in_orig {
                // Browser behavior (HTTP/2): split cookie headers appear *before* the
                // "priority" header. If priority is currently last, rebuild orig_headers
                // with cookie inserted immediately before it.
                let last_is_priority = effective_split_cookies == Some(true)
                    && orig_headers
                        .iter()
                        .last()
                        .map(|(name, _)| name.as_str().eq_ignore_ascii_case("priority"))
                        .unwrap_or(false);

                if last_is_priority {
                    // Collect all OrigHeaderName values preserving original casing
                    let all_orig: Vec<OrigHeaderName> = orig_headers
                        .iter()
                        .map(|(_, orig_name)| orig_name.clone())
                        .collect();
                    orig_headers = OrigHeaderMap::new();
                    // Re-insert all except the last (priority)
                    for orig_name in all_orig[..all_orig.len() - 1].iter() {
                        orig_headers.insert(orig_name.clone());
                    }
                    // Insert cookie before priority
                    orig_headers.insert("cookie".to_string());
                    // Re-insert priority (preserving original casing)
                    orig_headers.insert(all_orig.last().unwrap().clone());
                } else {
                    orig_headers.insert("cookie".to_string());
                }
            }

            // Step 4: Apply all user headers at once using insert (override) behavior
            // This ensures user headers completely replace emulation defaults for same names
            request_builder = request_builder.headers(user_headermap);

            // Step 5: Apply header ordering (critical for anti-detection)
            request_builder = request_builder.orig_headers(orig_headers);

            // Step 6: Apply effective cookies (merged global + jar + explicit) as headers.
            // HTTP/2 style: multiple separate "cookie" headers (split_cookies=true)
            // HTTP/1.1 style: single merged "Cookie" header (split_cookies=false, default)
            if let Some(cookies_map) = effective_cookies {
                match effective_split_cookies {
                    Some(true) => {
                        // Split mode: each cookie in its own header (HTTP/2 browser behavior)
                        for (key, value) in cookies_map.iter() {
                            let cookie_string = format!("{}={}", key, value);
                            request_builder =
                                request_builder.header("cookie", cookie_string.as_str());
                        }
                    }
                    Some(false) | None => {
                        // Merged mode: single Cookie header (HTTP/1.1 standard)
                        let cookie_string: String = cookies_map
                            .iter()
                            .map(|(k, v)| format!("{}={}", k, v))
                            .collect::<Vec<_>>()
                            .join("; ");
                        request_builder =
                            request_builder.header(wreq::header::COOKIE, cookie_string);
                    }
                }
            }

            // Body data (only for POST/PUT/PATCH)
            if is_post_put_patch {
                // Content (raw bytes from content parameter)
                if let Some(content) = content {
                    request_builder = request_builder.body(content);
                }
                // Data as bytes (raw bytes from data parameter)
                else if let Some(data_bytes) = data_bytes {
                    request_builder = request_builder.body(data_bytes);
                }
                // Smart handling of data and json parameters
                else if content_type_is_json {
                    // When Content-Type is application/json, prefer json parameter, fallback to data
                    if let Some(json_data) = json_value {
                        request_builder = request_builder.json(&json_data);
                    } else if let Some(form_data) = data_value {
                        request_builder = request_builder.json(&form_data);
                    }
                } else {
                    // No explicit Content-Type: application/json header
                    // json parameter -> JSON encoding
                    // data parameter -> form encoding (or JSON if contains complex types)
                    if let Some(json_data) = json_value {
                        request_builder = request_builder.json(&json_data);
                    } else if let Some(form_data) = data_value {
                        // Check if data contains complex types (arrays/objects) that can't be form-encoded
                        let has_complex_type = form_data.as_object().is_some_and(|obj| {
                            obj.values().any(|v| v.is_array() || v.is_object())
                        });

                        if has_complex_type {
                            // Use JSON encoding for complex types
                            request_builder = request_builder.json(&form_data);
                        } else {
                            // Use form encoding for simple key-value pairs
                            request_builder = request_builder.form(&form_data);
                        }
                    }
                }

                // Files (multipart upload): Dict[str, str] where value is a local file path
                if let Some(files_map) = files {
                    let mut form = wreq::multipart::Form::new();
                    for (field_name, file_path) in files_map {
                        let data = tokio::fs::read(&file_path).await
                            .map_err(|e| anyhow::anyhow!("Failed to read file '{}': {}", file_path, e))?;
                        let file_name = std::path::Path::new(&file_path)
                            .file_name()
                            .and_then(|n| n.to_str())
                            .unwrap_or(&file_path)
                            .to_string();
                        let part = wreq::multipart::Part::bytes(data)
                            .file_name(file_name);
                        form = form.part(field_name, part);
                    }
                    request_builder = request_builder.multipart(form);
                }
            }

            // Auth
            if let Some((username, password)) = auth {
                request_builder = request_builder.basic_auth(&username, password.as_deref());
            } else if let Some(token) = auth_bearer {
                request_builder = request_builder.bearer_auth(&token);
            }

            // Timeout (request-level override)
            if let Some(seconds) = effective_timeout {
                request_builder = request_builder.timeout(Duration::from_secs_f64(seconds));
            }

            // Read timeout (request-level)
            if let Some(seconds) = read_timeout {
                request_builder = request_builder.read_timeout(Duration::from_secs_f64(seconds));
            }

            // Proxy (request-level override for non-temp clients)
            if let Some(prx) = effective_proxy {
                request_builder = request_builder.proxy(wreq::Proxy::all(&prx)?);
            }

            // Send the request and await the response
            let resp = request_builder.send().await?;
            Ok::<wreq::Response, anyhow::Error>(resp)
        };

        // Execute async future, releasing the Python GIL for concurrency
        let wreq_response = py.detach(|| RUNTIME.block_on(future))
            .map_err(anyhow_to_pyerr)?;

        // Convert to Python Response
        Ok(Response::from_wreq_response(wreq_response))
    }
}

impl RClient {
    /// Create a temporary client with request-specific settings.
    /// Shares the same cookie jar and connection pool parameters as the main client.
    fn create_temp_client(
        &self,
        impersonate: Option<String>,
        impersonate_os: Option<String>,
        verify: Option<bool>,
        ca_cert_file: Option<String>,
        https_only: Option<bool>,
        http1_only: Option<bool>,
        http2_only: Option<bool>,
        proxy: Option<String>,
        timeout: Option<f64>,
    ) -> PyResult<wreq::Client> {
        let mut client_builder = wreq::Client::builder()
            .pool_max_idle_per_host(self.pool_max_idle_per_host)
            .pool_max_size(self.pool_max_size)
            .pool_idle_timeout(Duration::from_secs_f64(self.pool_idle_timeout))
            .tcp_keepalive(Duration::from_secs(30))
            .tcp_keepalive_interval(Duration::from_secs(15))
            .tcp_keepalive_retries(3u32)
            .tcp_nodelay(true);

        // Browser impersonation
        let imp = impersonate.or_else(|| self.impersonate.clone());
        if let Some(browser) = &imp {
            let profile = map_browser_to_profile(browser).map_err(anyhow_to_pyerr)?;
            let imp_os = impersonate_os.or_else(|| self.impersonate_os.clone());
            if let Some(os) = &imp_os {
                let platform = map_os_to_platform(os).map_err(anyhow_to_pyerr)?;
                let emulation = wreq_util::Emulation::builder()
                    .profile(profile)
                    .platform(platform)
                    .build();
                client_builder = client_builder.emulation(emulation);
            } else {
                client_builder = client_builder.emulation(profile);
            }
        }

        // Share the main cookie jar so session cookies from temp requests are preserved.
        // Falls back to no cookie store if cookie_store was disabled at construction.
        if let Some(ref jar) = self.cookie_jar {
            client_builder = client_builder.cookie_provider(jar.clone());
        }

        // Referer
        if self.referer.unwrap_or(true) {
            client_builder = client_builder.referer(true);
        }

        // Proxy
        let req_proxy = proxy.or_else(|| self.proxy.clone())
            .or_else(|| std::env::var("PRIMP_PROXY").ok());
        if let Some(proxy_url) = &req_proxy {
            let proxy = wreq::Proxy::all(proxy_url)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
            client_builder = client_builder.proxy(proxy);
        }

        // Timeout
        let req_timeout = timeout.or(self.timeout);
        if let Some(seconds) = req_timeout {
            client_builder = client_builder.timeout(Duration::from_secs_f64(seconds));
        }

        // Verify — request-level ca_cert_file takes priority; fall back to client-level.
        let req_verify = verify.or(self.verify);
        let effective_ca_cert = ca_cert_file.or_else(|| self.ca_cert_file.clone());
        if !req_verify.unwrap_or(true) {
            client_builder = client_builder.tls_cert_verification(false);
        } else if let Some(ca_path) = &effective_ca_cert {
            let cert_store = crate::utils::load_ca_cert_from_file(ca_path)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
            client_builder = client_builder.tls_cert_store(cert_store);
        }

        // HTTPS only
        let req_https_only = https_only.or(self.https_only);
        if req_https_only.unwrap_or(false) {
            client_builder = client_builder.https_only(true);
        }

        // HTTP version control (http1_only takes priority over http2_only)
        let req_http1_only = http1_only.or(self.http1_only);
        let req_http2_only = http2_only.or(self.http2_only);
        if req_http1_only.unwrap_or(false) {
            client_builder = client_builder.http1_only();
        } else if req_http2_only.unwrap_or(false) {
            client_builder = client_builder.http2_only();
        }

        // Redirect settings
        if self.follow_redirects.unwrap_or(true) {
            client_builder = client_builder
                .redirect(wreq::redirect::Policy::limited(self.max_redirects.unwrap_or(20)));
        } else {
            client_builder = client_builder.redirect(wreq::redirect::Policy::none());
        }

        // Build client
        let client = client_builder
            .build()
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

        Ok(client)
    }
}
