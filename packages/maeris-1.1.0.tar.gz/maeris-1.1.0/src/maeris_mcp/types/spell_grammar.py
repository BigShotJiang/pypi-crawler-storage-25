"""Spell and grammar checking types."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class CorrectionType(str, Enum):
    """Type of text correction."""

    SPELLING = "spelling"
    GRAMMAR = "grammar"


class SpellGrammarCorrection(BaseModel):
    """A single spell/grammar correction."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    original_text: str = Field(alias="originalText")
    corrected_text: str = Field(alias="correctedText")
    correction_type: str = Field(alias="correctionType")
    incorrect: str
    correct: str
    file_path: str = Field(default="", alias="filePath")
    line_start: int = Field(default=0, alias="lineStart")
    line_end: int | None = Field(default=None, alias="lineEnd")
    page_id: str = Field(default="", alias="pageId")
    page_name: str = Field(default="", alias="pageName")
    component_context: str = Field(default="", alias="componentContext")


class SpellGrammarScanSummary(BaseModel):
    """Summary statistics for a spell/grammar scan."""

    model_config = ConfigDict(populate_by_name=True)

    total_corrections: int = Field(alias="totalCorrections")
    spelling_count: int = Field(default=0, alias="spellingCount")
    grammar_count: int = Field(default=0, alias="grammarCount")
    files_scanned: int = Field(default=0, alias="filesScanned")


class SpellGrammarScanResult(BaseModel):
    """Complete spell/grammar scan result."""

    model_config = ConfigDict(populate_by_name=True)

    scan_id: str = Field(alias="scanId")
    target_path: str = Field(alias="targetPath")
    scan_timestamp: str = Field(alias="scanTimestamp")
    summary: SpellGrammarScanSummary
    corrections: list[SpellGrammarCorrection] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class StoredSpellGrammarScan(BaseModel):
    """Stored spell/grammar scan with metadata."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    target_path: str = Field(alias="targetPath")
    result: SpellGrammarScanResult
    stored_at: str = Field(alias="storedAt")
    last_accessed: str = Field(alias="lastAccessed")
    status: str = "pending"
    file_list: list[str] = Field(default_factory=list, alias="fileList")
    pushed_to_maeris: bool = Field(default=False, alias="pushedToMaeris")
    pushed_at: str | None = Field(default=None, alias="pushedAt")
