"""GDPR/privacy scanning types."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class GdprSeverity(str, Enum):
    """GDPR finding severity levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class GdprCategory(str, Enum):
    """GDPR finding categories."""

    PRE_CONSENT_COOKIES = "pre_consent_cookies"
    LOCAL_STORAGE_PII = "local_storage_pii"
    THIRD_PARTY_TRACKER = "third_party_tracker"
    SENSITIVE_DATA_EXPOSURE = "sensitive_data_exposure"
    HTTPS_ENFORCEMENT = "https_enforcement"
    CONSENT_MECHANISM = "consent_mechanism"
    DATA_RETENTION = "data_retention"
    PRIVACY_POLICY = "privacy_policy"


class GdprFinding(BaseModel):
    """A single GDPR/privacy finding."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    page_url: str = Field(alias="pageUrl")
    category: str
    severity: GdprSeverity
    issue: str
    details: dict | list | str = Field(default_factory=dict)
    suggested_fix: str = Field(default="", alias="suggestedFix")
    file_path: str = Field(default="", alias="filePath")
    line_start: int = Field(default=0, alias="lineStart")
    line_end: int | None = Field(default=None, alias="lineEnd")
    code_snippet: str | None = Field(default=None, alias="codeSnippet")
    page_id: str = Field(default="", alias="pageId")
    page_gdpr_compliance_score: float = Field(default=100.0, alias="pageGdprComplianceScore")


class GdprSeverityCounts(BaseModel):
    """Count of findings by severity."""

    low: int = 0
    medium: int = 0
    high: int = 0
    critical: int = 0


class GdprScanSummary(BaseModel):
    """Summary statistics for a GDPR scan."""

    model_config = ConfigDict(populate_by_name=True)

    total_findings: int = Field(alias="totalFindings")
    by_severity: GdprSeverityCounts = Field(alias="bySeverity")
    by_category: dict[str, int] = Field(default_factory=dict, alias="byCategory")
    files_scanned: int = Field(default=0, alias="filesScanned")
    compliance_score: float = Field(default=100.0, alias="complianceScore")


class GdprScanResult(BaseModel):
    """Complete GDPR scan result."""

    model_config = ConfigDict(populate_by_name=True)

    scan_id: str = Field(alias="scanId")
    target_path: str = Field(alias="targetPath")
    scan_timestamp: str = Field(alias="scanTimestamp")
    summary: GdprScanSummary
    findings: list[GdprFinding] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class StoredGdprScan(BaseModel):
    """Stored GDPR scan with metadata."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    target_path: str = Field(alias="targetPath")
    result: GdprScanResult
    stored_at: str = Field(alias="storedAt")
    last_accessed: str = Field(alias="lastAccessed")
    status: str = "pending"
    file_list: list[str] = Field(default_factory=list, alias="fileList")
    pushed_to_maeris: bool = Field(default=False, alias="pushedToMaeris")
    pushed_at: str | None = Field(default=None, alias="pushedAt")
