"""Data classes for the convert_tests_to_structure output schema."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FluRecord:
    """One record per functional user action (WAIT steps excluded)."""

    flu_id: str             # UUID
    testcase_id: str
    action: str             # ActionType enum value
    description: str
    selector: str | None
    selector_type: str | None
    value: str | None
    url: str | None         # only for navigate steps
    timeout: int | None
    condition: str | None
    step_index: int


@dataclass
class FluTreeRecord:
    """Sequential parent→child relationship between steps within a test case."""

    tree_id: str            # UUID
    testcase_id: str
    parent_flu_id: str      # UUID
    child_flu_id: str       # UUID
    relationship: str       # always "sequential"


@dataclass
class ComponentRecord:
    """UI element interacted with in a flu (WAIT steps excluded). One record per flu."""

    component_id: str               # UUID
    flu_id: str                     # UUID (FK → FluRecord)
    testcase_id: str                # testcase this component belongs to
    css_selector: str               # mandatory — step.selector or step.url or ""
    nth_appearance: int             # which occurrence of selector on page (default 1)
    page_url: str | None            # URL of page where component appears
    action_taken: str | None        # "click" | "send_keys" | "go_to" | "hover"
    html_of_component: str | None   # inferred HTML representation
    tag: str | None                 # HTML tag name
    validation_type: str | None     # input type / "select" / None
    mock_input: str | None          # value filled (FILL/PRESS steps only)
    component_representation_string: str | None  # short description


@dataclass
class TestCaseRecord:
    """One record per test case."""

    testcase_id: str        # "tc_{session_id[:8]}_{idx}"
    session_id: str
    name: str
    description: str
    path: str               # URL path from first navigate step, e.g. "/login"
    test_type: str          # "happy_path" | "error_path"
    priority: str
    tags: list[str] = field(default_factory=list)
    custom_input_data: dict[str, Any] = field(default_factory=dict)
    # custom_input_data shape: {"rows": {"<component_id>": "<filled_value>", ...}}
    execution_status: str | None = None   # "passed"|"failed"|"unfixable"|None
    test_file: str | None = None


@dataclass
class TestCaseVerificationRecord:
    """One record per assertion in a test case."""

    verification_id: str    # "ver_{tc_idx}_{assertion_idx}"
    testcase_id: str
    assertion_type: str     # AssertionType enum value
    description: str
    selector: str | None
    expected: str | None
    assertion_nature: str   # "positive" | "negative"
    timeout: int | None
    attribute: str | None
    api_endpoint: str | None
    assertion_index: int


@dataclass
class TestStructureOutput:
    """Top-level container returned by convert_tests_to_structure."""

    session_id: str
    exec_session_id: str | None
    flow_description: str
    generated_at: str
    filter_mode: str        # "passed_only" | "all"
    testcases: list[TestCaseRecord] = field(default_factory=list)
    flus: list[FluRecord] = field(default_factory=list)
    flu_tree: list[FluTreeRecord] = field(default_factory=list)
    components: list[ComponentRecord] = field(default_factory=list)
    testcases_verifications: list[TestCaseVerificationRecord] = field(default_factory=list)
    output_file: str = ""
    summary: dict[str, int] = field(default_factory=dict)
