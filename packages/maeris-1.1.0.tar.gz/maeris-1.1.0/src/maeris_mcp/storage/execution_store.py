"""Thread-safe in-memory + disk-persisted storage for test execution sessions."""

import dataclasses
import json
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from maeris_mcp.storage.test_store import _get_sessions_dir


@dataclass
class TestResult:
    """Result of a single test execution attempt."""

    test_file: str
    test_name: str
    status: str  # "passed" | "failed" | "error" | "unfixable"
    attempts: int
    logs: str


@dataclass
class TestExecutionSession:
    """Active session for iterative test execution and auto-fixing."""

    exec_session_id: str
    gen_session_id: str | None
    output_dir: str
    test_files: list[str]  # relative filenames like "my_test.py"
    base_url: str | None = None  # locked base URL — fixes must not change this domain
    headless: bool = True  # run browser in headless mode by default
    skip_iframe_search: bool = True  # skip iframe fallback for faster locator failure
    step_retries: int = 3  # max LLM fix attempts per failing step
    current_index: int = 0
    step_fix_counts: dict[str, int] = field(default_factory=dict)  # "testIdx:stepIdx" -> fix count
    results: list[TestResult] = field(default_factory=list)
    failed_descriptions: list[str] = field(default_factory=list)
    status: str = "running"  # "running" | "completed"
    created_at: str = ""
    scripts_decision_made: bool = False  # True once save_failing_scripts has been answered
    testcase_id: str | None = None        # server-side testcase ID for post-fix update
    original_steps: list | None = None   # ordered step snapshot (with flu_id/component_id) for diff
    # Common prefix optimization (phases 2a–2d)
    # -1 = not yet detected, 0 = no common prefix, >0 = length of shared prefix
    common_prefix_length: int = -1
    common_prefix_verified: bool = False  # True once prefix is proven and applied to all files
    common_prefix_steps: list | None = None  # corrected prefix steps after 2b passes
    # Cross-test learning: selector replacements confirmed working in earlier tests.
    # Each entry: {"absent_selector": str, "working_replacement": str,
    #              "from_test_index": int, "from_test_name": str}
    session_findings: list[dict] = field(default_factory=list)


class TestExecutionStore:
    """Thread-safe storage for test execution sessions, persisted to disk."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._sessions: dict[str, TestExecutionSession] = {}

    # ------------------------------------------------------------------
    # Disk helpers
    # ------------------------------------------------------------------

    def _session_path(self, exec_session_id: str) -> Path:
        return _get_sessions_dir() / f"exec_{exec_session_id}.json"

    def _save(self, session: TestExecutionSession) -> None:
        """Write session to disk. Never raises — persistence failure is non-fatal."""
        try:
            data = dataclasses.asdict(session)
            self._session_path(session.exec_session_id).write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
        except Exception:
            pass

    def _load(self, exec_session_id: str) -> TestExecutionSession | None:
        """Load session from disk. Returns None if not found or corrupt."""
        try:
            path = self._session_path(exec_session_id)
            if not path.exists():
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
            # Reconstruct nested TestResult dataclasses from plain dicts
            data["results"] = [TestResult(**r) for r in data.get("results", [])]
            return TestExecutionSession(**data)
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create_session(
        self,
        output_dir: str,
        test_files: list[str],
        gen_session_id: str | None = None,
        base_url: str | None = None,
        headless: bool = True,
        skip_iframe_search: bool = True,
        step_retries: int = 3,
        testcase_id: str | None = None,
        original_steps: list | None = None,
    ) -> str:
        """Create a new execution session and return its ID."""
        with self._lock:
            exec_session_id = str(uuid4())
            session = TestExecutionSession(
                exec_session_id=exec_session_id,
                gen_session_id=gen_session_id,
                output_dir=output_dir,
                test_files=test_files,
                base_url=base_url,
                headless=headless,
                skip_iframe_search=skip_iframe_search,
                step_retries=step_retries,
                created_at=datetime.now(timezone.utc).isoformat(),
                testcase_id=testcase_id,
                original_steps=original_steps,
            )
            self._sessions[exec_session_id] = session
            self._save(session)
            return exec_session_id

    def get_session(self, exec_session_id: str) -> TestExecutionSession | None:
        """Retrieve a session by ID.

        Checks memory first; falls back to disk so sessions survive MCP restarts.
        """
        with self._lock:
            session = self._sessions.get(exec_session_id)
            if session:
                return session
            # Try loading from disk (e.g. after MCP restart)
            session = self._load(exec_session_id)
            if session:
                self._sessions[exec_session_id] = session  # warm the in-memory cache
            return session

    def record_result(
        self,
        exec_session_id: str,
        test_file: str,
        test_name: str,
        status: str,
        logs: str,
    ) -> None:
        """Record or update the result for the given test file."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if not session:
                return
            existing = next((r for r in session.results if r.test_file == test_file), None)
            if existing:
                existing.status = status
                existing.attempts += 1
                existing.logs = logs
            else:
                session.results.append(
                    TestResult(
                        test_file=test_file,
                        test_name=test_name,
                        status=status,
                        attempts=1,
                        logs=logs,
                    )
                )
            self._save(session)

    def advance(self, exec_session_id: str) -> None:
        """Advance to the next test."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.current_index += 1
                self._save(session)

    def increment_step_fix(self, exec_session_id: str, step_index: int) -> int:
        """Increment and return the fix count for a specific step in the current test."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if not session:
                return 0
            key = f"{session.current_index}:{step_index}"
            session.step_fix_counts[key] = session.step_fix_counts.get(key, 0) + 1
            self._save(session)
            return session.step_fix_counts[key]

    def get_step_fix_count(self, exec_session_id: str, step_index: int) -> int:
        """Return how many times a specific step has been fixed."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if not session:
                return 0
            key = f"{session.current_index}:{step_index}"
            return session.step_fix_counts.get(key, 0)

    def add_failed_description(self, exec_session_id: str, description: str) -> None:
        """Record a failure description for an unfixable test."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.failed_descriptions.append(description)
                self._save(session)

    def add_session_finding(self, exec_session_id: str, finding: dict) -> None:
        """Record a cross-test learning finding (absent selector → working replacement)."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.session_findings.append(finding)
                self._save(session)

    def finalize(self, exec_session_id: str) -> None:
        """Mark session as completed."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.status = "completed"
                self._save(session)

    def mark_scripts_resolved(self, exec_session_id: str) -> None:
        """Record that the save_failing_scripts decision has been applied."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.scripts_decision_made = True
                self._save(session)

    def set_common_prefix(
        self,
        exec_session_id: str,
        length: int,
        steps: list | None = None,
        verified: bool = False,
    ) -> None:
        """Update the common prefix state for a session."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if session:
                session.common_prefix_length = length
                if steps is not None:
                    session.common_prefix_steps = steps
                session.common_prefix_verified = verified
                self._save(session)

    def increment_prefix_step_fix(self, exec_session_id: str, step_index: int) -> int:
        """Increment and return the fix count for a specific common-prefix step."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if not session:
                return 0
            key = f"prefix:{step_index}"
            session.step_fix_counts[key] = session.step_fix_counts.get(key, 0) + 1
            self._save(session)
            return session.step_fix_counts[key]

    def get_prefix_step_fix_count(self, exec_session_id: str, step_index: int) -> int:
        """Return how many times a common-prefix step has been fixed."""
        with self._lock:
            session = self.get_session(exec_session_id)
            if not session:
                return 0
            key = f"prefix:{step_index}"
            return session.step_fix_counts.get(key, 0)
