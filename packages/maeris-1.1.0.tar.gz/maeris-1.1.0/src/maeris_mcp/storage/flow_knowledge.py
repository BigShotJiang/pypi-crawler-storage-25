"""
Per-repo unified learning store. Records proven test cases, selector corrections,
required steps, and user corrections from all sources (portal, run_and_fix, user
feedback) and injects them into Phase 2 generation as authoritative ground truth.

Storage location: ~/.maeris/repos/<repo_hash>/flow_knowledge.json
"""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Union
import structlog

logger = structlog.get_logger()

_SCHEMA_VERSION = 2

_STOP_WORDS = {
    "a", "an", "the", "for", "to", "of", "in", "on", "at", "is", "are",
    "and", "or", "with", "from", "that", "this", "it", "as", "be", "by",
    "generate", "testcases", "test", "cases", "steps", "flow", "create",
    "write", "run", "check", "verify", "make",
}


class RepoFlowKnowledge:
    def __init__(self, repo_root: Union[str, Path]):
        self.repo_root = str(Path(repo_root).resolve())
        repo_hash = hashlib.sha256(self.repo_root.encode()).hexdigest()[:16]
        self._path = Path.home() / ".maeris" / "repos" / repo_hash / "flow_knowledge.json"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _flow_key(self, command: str) -> str:
        words = re.findall(r"[a-zA-Z]+", command)
        keywords = sorted(
            w.lower() for w in words
            if w.lower() not in _STOP_WORDS and len(w) > 2
        )
        return "_".join(keywords) if keywords else "default"

    def _keywords(self, command: str) -> set:
        words = re.findall(r"[a-zA-Z]+", command)
        return {w.lower() for w in words if w.lower() not in _STOP_WORDS and len(w) > 2}

    def _load(self) -> dict:
        try:
            if self._path.exists():
                data = json.loads(self._path.read_text(encoding="utf-8"))
                if data.get("version") == _SCHEMA_VERSION:
                    return data
        except Exception as e:
            logger.warning("flow_knowledge.load_failed", error=str(e))
        return {"version": _SCHEMA_VERSION, "flows": {}}

    def _save(self, data: dict) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("flow_knowledge.save_failed", error=str(e))

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _get_or_create_flow(self, data: dict, command: str) -> dict:
        key = self._flow_key(command)
        flows = data.setdefault("flows", {})
        if key not in flows:
            flows[key] = {
                "representative_command": command,
                "keywords": sorted(self._keywords(command)),
                "last_updated": self._now(),
                "proven_test_cases": [],
                "selector_corrections": [],
                "required_steps": [],
                "user_corrections": [],
                "stored_findings": "",
            }
        return flows[key]

    def _find_flow_by_keyword_overlap(self, data: dict, command: str) -> dict | None:
        """Find the best-matching flow by keyword overlap (>= 1 keyword match)."""
        cmd_kw = self._keywords(command)
        if not cmd_kw:
            return None
        best_score = 0
        best_flow = None
        for flow in data.get("flows", {}).values():
            flow_kw = set(flow.get("keywords", []))
            overlap = len(cmd_kw & flow_kw)
            if overlap >= 1 and overlap > best_score:
                best_score = overlap
                best_flow = flow
        return best_flow

    def _extract_common_prefix(self, data: dict) -> list:
        """Find steps shared at the start of >= 2 proven test cases across all flows.

        For each position, finds the most common step description. If >= 2 sequences
        agree on that description, the step is part of the common prefix. Stops as
        soon as no description appears >= 2 times at a position.

        Among candidates for the same position, prefers the step with the most stable
        selector (non-empty, doesn't use :text-is).
        """
        all_sequences = []
        for flow in data.get("flows", {}).values():
            for tc in flow.get("proven_test_cases", []):
                steps = tc.get("steps", [])
                if steps:
                    all_sequences.append(steps)

        if len(all_sequences) < 2:
            return []

        prefix = []
        max_pos = max(len(seq) for seq in all_sequences)

        for i in range(max_pos):
            desc_candidates: dict[str, list] = {}
            for seq in all_sequences:
                if i < len(seq):
                    desc = (seq[i].get("description") or "").strip().lower()
                    if desc:
                        desc_candidates.setdefault(desc, []).append(seq[i])

            # Most common description at this position
            best_desc = max(
                desc_candidates,
                key=lambda d: len(desc_candidates[d]),
                default="",
            )
            if not best_desc or len(desc_candidates.get(best_desc, [])) < 2:
                break

            # Among matching steps, prefer the most stable selector
            candidates = desc_candidates[best_desc]
            best_step = max(
                candidates,
                key=lambda s: (
                    bool(s.get("css_selector")),
                    ":text-is" not in (s.get("css_selector") or ""),
                    (s.get("wait_after") or 0),  # prefer steps with waits — usually more deliberate
                ),
            )
            prefix.append(best_step)

        return prefix

    def _update_common_prefix(self, data: dict) -> None:
        """Recompute and store the common prefix in-place on data."""
        data["common_prefix"] = self._extract_common_prefix(data)

    # ------------------------------------------------------------------
    # Public write methods
    # ------------------------------------------------------------------

    def record_portal_results(
        self,
        command: str,
        test_cases: list,
    ) -> None:
        """Write/update proven_test_cases from Maeris portal passing tests."""
        try:
            data = self._load()
            flow = self._get_or_create_flow(data, command)
            now = self._now()

            existing_by_name = {
                tc["test_name"]: tc
                for tc in flow["proven_test_cases"]
                if isinstance(tc, dict) and tc.get("test_name")
            }

            for tc in test_cases:
                if not isinstance(tc, dict):
                    continue
                name = tc.get("test_name", "")
                steps = tc.get("steps", [])
                passes = tc.get("confirmed_passes", 1)
                if not name or not steps:
                    continue

                if name in existing_by_name:
                    entry = existing_by_name[name]
                    entry["steps"] = steps
                    entry["confirmed_passes"] = entry.get("confirmed_passes", 0) + passes
                    entry["last_updated"] = now
                    # Upgrade source to portal if it was only run_and_fix
                    if entry.get("source") != "portal":
                        entry["source"] = "portal"
                else:
                    new_entry = {
                        "test_name": name,
                        "steps": steps,
                        "confirmed_passes": passes,
                        "source": "portal",
                        "recorded_at": now,
                        "last_updated": now,
                    }
                    flow["proven_test_cases"].append(new_entry)
                    existing_by_name[name] = new_entry

            flow["last_updated"] = now
            self._update_common_prefix(data)
            self._save(data)
            logger.info("flow_knowledge.portal_results_recorded", command=command[:60])
        except Exception as e:
            logger.warning("flow_knowledge.record_portal_results_failed", error=str(e))

    def record_run_and_fix_result(
        self,
        command: str,
        original_cases: list,
        passing_cases: list,
        session_findings: list,
    ) -> None:
        """Write corrections from a completed run_and_fix loop."""
        try:
            data = self._load()
            flow = self._get_or_create_flow(data, command)
            now = self._now()

            # 1. Upsert proven_test_cases from passing cases
            existing_by_name = {
                tc["test_name"]: tc
                for tc in flow["proven_test_cases"]
                if isinstance(tc, dict) and tc.get("test_name")
            }
            for tc in (passing_cases or []):
                if not isinstance(tc, dict):
                    continue
                name = tc.get("test_name", "")
                steps = tc.get("steps", [])
                if not name or not steps:
                    continue
                if name in existing_by_name:
                    entry = existing_by_name[name]
                    entry["steps"] = steps
                    entry["confirmed_passes"] = entry.get("confirmed_passes", 0) + 1
                    entry["last_updated"] = now
                    if entry.get("source") == "portal":
                        pass  # keep portal source — higher trust
                    else:
                        entry["source"] = "run_and_fix"
                else:
                    new_entry = {
                        "test_name": name,
                        "steps": steps,
                        "confirmed_passes": 1,
                        "source": "run_and_fix",
                        "recorded_at": now,
                        "last_updated": now,
                    }
                    flow["proven_test_cases"].append(new_entry)
                    existing_by_name[name] = new_entry

            # 2. Upsert selector corrections from session findings
            existing_corrections = {
                (c.get("broken", ""), c.get("working", "")): c
                for c in flow["selector_corrections"]
                if isinstance(c, dict)
            }
            for finding in (session_findings or []):
                if not isinstance(finding, dict):
                    continue
                broken = finding.get("absent_selector", "")
                working = finding.get("working_replacement", "")
                context = finding.get("context", finding.get("from_test_name", ""))
                if not broken or not working or broken == working:
                    continue
                key = (broken, working)
                if key in existing_corrections:
                    existing_corrections[key]["confirmed_passes"] = (
                        existing_corrections[key].get("confirmed_passes", 1) + 1
                    )
                else:
                    new_correction = {
                        "broken": broken,
                        "working": working,
                        "action": finding.get("action", ""),
                        "context": context,
                        "confirmed_passes": 1,
                        "source": "run_and_fix",
                    }
                    flow["selector_corrections"].append(new_correction)
                    existing_corrections[key] = new_correction

            # 3. Diff original vs passing — find steps in passing not in original
            orig_by_name: dict[str, list] = {
                tc.get("test_name", ""): tc.get("steps", [])
                for tc in (original_cases or [])
                if isinstance(tc, dict) and tc.get("test_name")
            }
            for tc in (passing_cases or []):
                if not isinstance(tc, dict):
                    continue
                name = tc.get("test_name", "")
                passing_steps = tc.get("steps", [])
                orig_steps = orig_by_name.get(name, [])
                if not orig_steps or not passing_steps:
                    continue

                orig_descs = {
                    (s.get("description") or "").strip().lower()
                    for s in orig_steps
                    if isinstance(s, dict)
                }
                orig_sels = {
                    (s.get("css_selector") or "").strip()
                    for s in orig_steps
                    if isinstance(s, dict) and s.get("css_selector")
                }

                for idx, step in enumerate(passing_steps):
                    if not isinstance(step, dict):
                        continue
                    desc = (step.get("description") or "").strip().lower()
                    sel = (step.get("css_selector") or "").strip()

                    # Step is in passing but description not in original — required_step
                    if desc and desc not in orig_descs:
                        existing_req = [
                            r for r in flow["required_steps"]
                            if isinstance(r, dict)
                            and (r.get("description") or "").strip().lower() == desc
                        ]
                        if existing_req:
                            existing_req[0]["confirmed_passes"] = (
                                existing_req[0].get("confirmed_passes", 1) + 1
                            )
                        else:
                            flow["required_steps"].append({
                                "description": step.get("description", ""),
                                "step": step,
                                "position_after_index": max(0, idx - 1),
                                "confirmed_passes": 1,
                                "source": "run_and_fix",
                            })

                    # Step has selector not in original — selector correction
                    if sel and sel not in orig_sels and step.get("action_taken"):
                        # Find matching original step by description
                        orig_match = next(
                            (
                                s for s in orig_steps
                                if isinstance(s, dict)
                                and (s.get("description") or "").strip().lower() == desc
                                and (s.get("css_selector") or "").strip()
                                and (s.get("css_selector") or "").strip() != sel
                            ),
                            None,
                        )
                        if orig_match:
                            broken = (orig_match.get("css_selector") or "").strip()
                            if broken:
                                key = (broken, sel)
                                if key not in existing_corrections:
                                    new_correction = {
                                        "broken": broken,
                                        "working": sel,
                                        "action": step.get("action_taken", ""),
                                        "context": step.get("description", ""),
                                        "confirmed_passes": 1,
                                        "source": "run_and_fix",
                                    }
                                    flow["selector_corrections"].append(new_correction)
                                    existing_corrections[key] = new_correction

            flow["last_updated"] = now
            self._update_common_prefix(data)
            self._save(data)
            logger.info("flow_knowledge.run_and_fix_recorded", command=command[:60])
        except Exception as e:
            logger.warning("flow_knowledge.record_run_and_fix_failed", error=str(e))

    def record_user_correction(
        self,
        command: str,
        feedback: str,
        previous_findings: str = "",
        app_path: str = "",
    ) -> None:
        """Write user explicit feedback."""
        try:
            data = self._load()
            flow = self._get_or_create_flow(data, command)
            now = self._now()

            flow["user_corrections"].append({
                "timestamp": now,
                "feedback": feedback,
                "previous_findings": previous_findings,
            })

            if previous_findings:
                flow["stored_findings"] = previous_findings

            flow["last_updated"] = now
            self._save(data)
            logger.info("flow_knowledge.user_correction_recorded", command=command[:60])
        except Exception as e:
            logger.warning("flow_knowledge.record_user_correction_failed", error=str(e))

    # ------------------------------------------------------------------
    # Public read methods
    # ------------------------------------------------------------------

    def get_authoritative_block(self, command: str) -> str:
        """Return a hard constraint prompt block for Phase 2 injection.

        Always includes the common auth/navigation prefix (steps shared across
        >= 2 proven flows in this repo) regardless of keyword match, so new flows
        get the proven login sequence even if they've never been run before.
        Flow-specific proven test cases and corrections are appended when a keyword
        match is found.
        """
        try:
            data = self._load()
            common_prefix = data.get("common_prefix", [])
            flow = self._find_flow_by_keyword_overlap(data, command)

            proven = flow.get("proven_test_cases", []) if flow else []
            corrections = flow.get("selector_corrections", []) if flow else []
            user_corrections = flow.get("user_corrections", []) if flow else []

            if not common_prefix and not proven and not corrections and not user_corrections:
                return ""

            lines = [
                "═══ GROUND TRUTH — AUTHORITATIVE, DO NOT OVERRIDE ═══",
                "These were proven correct in real browser runs and/or Maeris portal test history.",
                "Any conflict with the source scan below resolves in favour of this block.",
                "",
            ]

            # Common prefix — always injected regardless of keyword match
            if common_prefix:
                lines.append(
                    "PROVEN COMMON STEPS (always include these at the start of every test case —"
                    " confirmed across multiple flows in this repo):"
                )
                for i, step in enumerate(common_prefix, 1):
                    lines.append("  " + self._format_step(i, step))
                lines.append("")

            # Flow-specific proven test cases — run_and_fix first, then portal
            if proven:
                lines.append("PROVEN TEST CASES FOR THIS FLOW (use as primary structure reference):")
                sorted_proven = sorted(
                    proven,
                    key=lambda tc: (0 if tc.get("source") == "run_and_fix" else 1),
                )
                for tc in sorted_proven:
                    name = tc.get("test_name", "")
                    steps = tc.get("steps", [])
                    passes = tc.get("confirmed_passes", 1)
                    source = tc.get("source", "unknown")
                    lines.append(f'  "{name}" [{source}: {passes} passes]')
                    for i, step in enumerate(steps, 1):
                        lines.append("    " + self._format_step(i, step))
                    lines.append("")

            # Selector corrections
            if corrections:
                lines.append(
                    "SELECTOR CORRECTIONS (mandatory — never revert to broken selectors):"
                )
                for c in corrections:
                    broken = c.get("broken", "")
                    working = c.get("working", "")
                    action = c.get("action", "")
                    context = c.get("context", "")
                    passes = c.get("confirmed_passes", 1)
                    lines.append(
                        f'  {action} "{context}": use {working} NOT {broken} [{passes} passes]'
                    )
                lines.append("")

            # User corrections
            if user_corrections:
                lines.append("USER CORRECTIONS (apply these to the generated test cases):")
                for uc in user_corrections[-5:]:
                    fb = uc.get("feedback", "")
                    if fb:
                        lines.append(f'  "{fb}"')
                lines.append("")

            lines.append("═══════════════════════════════════════════════════════")
            return "\n".join(lines)
        except Exception as e:
            logger.warning("flow_knowledge.get_authoritative_block_failed", error=str(e))
            return ""

    def _format_step(self, i: int, step: dict) -> str:
        """Format a single step for display in the authoritative block."""
        action = step.get("action_taken", "")
        sel = (step.get("css_selector") or "").strip()
        mock = (step.get("mock_input") or "").strip()
        if not action:
            a_nature = step.get("assertion_nature", "")
            a_type = step.get("assertion_type", "")
            a_val = step.get("assertion_value", "")
            line = f"{i}. [assert] {a_nature} → {a_type}"
            if a_val:
                line += f" → {a_val}"
            return line
        sel_part = f" {sel}" if sel else ""
        mock_part = f" → {mock}" if mock else " → (no input)"
        return f"{i}. {action}{sel_part}{mock_part}"

    def get_stored_findings(self, command: str) -> str:
        """Return stored exploration findings for use_stored_findings path."""
        try:
            data = self._load()
            flow = self._find_flow_by_keyword_overlap(data, command)
            if flow:
                return flow.get("stored_findings", "")
        except Exception as e:
            logger.warning("flow_knowledge.get_stored_findings_failed", error=str(e))
        return ""

    def get_selector_corrections(self, command: str) -> list:
        """Return selector_corrections for pre-seeding exec_dir files."""
        try:
            data = self._load()
            flow = self._find_flow_by_keyword_overlap(data, command)
            if flow:
                return flow.get("selector_corrections", [])
        except Exception as e:
            logger.warning("flow_knowledge.get_selector_corrections_failed", error=str(e))
        return []

    def get_relevant_user_corrections(self, command: str) -> list:
        """Return user_corrections for feedback injection."""
        try:
            data = self._load()
            flow = self._find_flow_by_keyword_overlap(data, command)
            if flow:
                return flow.get("user_corrections", [])
        except Exception as e:
            logger.warning("flow_knowledge.get_relevant_user_corrections_failed", error=str(e))
        return []

    def get_stored_app_path(self, command: str) -> str:
        """Return app_path from stored_findings metadata if available."""
        try:
            data = self._load()
            flow = self._find_flow_by_keyword_overlap(data, command)
            if not flow:
                return ""
            # Try to extract app_path from stored_findings (it may be embedded as a line)
            findings = flow.get("stored_findings", "")
            if findings:
                for line in findings.splitlines():
                    if line.strip().startswith("app_path:") or line.strip().startswith("App path:"):
                        parts = line.split(":", 1)
                        if len(parts) == 2:
                            candidate = parts[1].strip()
                            if candidate:
                                return candidate
        except Exception as e:
            logger.warning("flow_knowledge.get_stored_app_path_failed", error=str(e))
        return ""
