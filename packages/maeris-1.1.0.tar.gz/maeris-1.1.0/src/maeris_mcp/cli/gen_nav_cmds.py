"""generate-nav CLI command — subprocess fallback for terminal use."""

import json
import shutil
import subprocess
import time
from pathlib import Path

import click

from ._core import cli

_EXPLORE_FLAGS = [
    "--print",
    "--dangerously-skip-permissions",
    "--no-session-persistence",
    "--mcp-config", '{"mcpServers":{}}',
    "--strict-mcp-config",
]

_STRUCTURE_FLAGS = [
    "--print",
    "--no-session-persistence",
    "--tools", "",
]


@cli.command("generate-nav")
def generate_nav_cmd() -> None:
    """Explore the codebase navigation and auth flow, save to .maeris/navigation.md.

    \b
    Run once per project, or when routing/auth changes.
    The generate tool uses this map to produce complete step flows.
    """
    claude_bin = shutil.which("claude.exe") or shutil.which("claude")
    if not claude_bin:
        click.secho("Error: Claude CLI not found on PATH.", fg="red")
        return

    explore_prompt = (
        "Explore the codebase and extract the app's navigation and auth structure.\n\n"
        "Find and report ALL of the following:\n"
        "1. Entry point URL and what happens to unauthenticated users\n"
        "2. How authentication works (login URL, fields/methods, where user lands after login)\n"
        "3. Primary navigation structure (sidebar, topbar, tabs — how users move between major sections)\n"
        "4. The major sections/pages and how to reach each one\n"
        "5. Any prerequisites before a user can access features "
        "(must be logged in, must select an app, role requirements, etc.)\n\n"
        "Be framework-agnostic — look at routing config, auth guards, "
        "navigation components, and page structure regardless of framework used.\n"
        "Report only what you find in the source. Do not infer or assume."
    )

    click.echo("→ Exploring app navigation and auth structure...")
    t0 = time.monotonic()

    try:
        r1 = subprocess.run(
            [claude_bin, *_EXPLORE_FLAGS, explore_prompt],
            capture_output=True, text=True, encoding="utf-8", timeout=300,
        )
        explore_secs = round(time.monotonic() - t0, 1)

        if r1.returncode != 0:
            click.secho(f"✗ Explore error: {r1.stderr[:200]}", fg="red")
            return

        findings = r1.stdout.strip()
        if not findings:
            click.secho("✗ Explore returned empty output.", fg="red")
            return

        nav_dir = Path(".maeris")
        nav_dir.mkdir(exist_ok=True)
        (nav_dir / "navigation.md").write_text(findings, encoding="utf-8")

        total = round(time.monotonic() - t0, 1)
        click.echo(f"  explore: {explore_secs}s  |  total: {total}s")
        click.secho(f"✓ Navigation map saved to .maeris/navigation.md", fg="green")

    except subprocess.TimeoutExpired:
        total = round(time.monotonic() - t0, 1)
        click.secho(f"✗ Timed out after 300s.  ({total}s)", fg="red")
    except Exception as e:  # noqa: BLE001
        total = round(time.monotonic() - t0, 1)
        click.secho(f"✗ Error: {e}  ({total}s)", fg="red")
