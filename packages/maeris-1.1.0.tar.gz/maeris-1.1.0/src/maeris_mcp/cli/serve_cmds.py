"""MCP server launcher commands.

The repo-level `.mcp.json` expects to run:
  command: maeris
  args: ["serve"]

So the CLI must provide a `maeris serve` command that runs the MCP server
over stdio by default.
"""

from __future__ import annotations

import sys

import click

from ._core import cli


@cli.command(
    "serve",
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
    add_help_option=False,
)
@click.pass_context
def serve_cmd(ctx: click.Context) -> None:
    """Start the Maeris MCP server (stdio by default).

    This command delegates to `python -m maeris_mcp` so the MCP server
    implementation (and its CLI options) stay centralized.

    Examples:
      maeris serve
      maeris serve --mode http --port 8080
      maeris serve --help
    """
    # On Windows os.execv() spawns a new process and exits the current one,
    # which causes Claude Code to think the MCP server died (connection failed).
    # Call main() directly so the current process becomes the MCP server.
    import sys as _sys
    _sys.argv = [_sys.argv[0], *ctx.args]
    from maeris_mcp.main import main
    main(standalone_mode=False)

