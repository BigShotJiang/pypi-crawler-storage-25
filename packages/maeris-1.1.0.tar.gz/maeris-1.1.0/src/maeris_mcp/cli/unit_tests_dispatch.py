"""Execute UI-dispatched unit-test actions locally.

The Maeris web UI POSTs actions to `/unit-tests/dispatch`, which insert a row
into `command_queue` with `message_type='unit_tests_action'` and a JSON
payload. `maeris listen` picks it up and routes it here.

Supported actions (mapped to the Must-Have ACs in the spec):

  generate              AC-05  Generate tests for a file/folder picked in UI
  regenerate            AC-15  Re-read a file and rewrite its tests
  run                   AC-25  Run a single test / file / folder / full suite
  sync                  --      Rescan on-disk tests and push metadata
  analyze_critical_path AC-19  Run the critical-path analyzer

Each action runs the matching tool handler, reports progress lines, and
completes the command with an "output" string the UI renders as a toast.
"""

from __future__ import annotations

import asyncio
import json
import re
import shutil
from pathlib import Path
from typing import Any

import click
from mcp.types import TextContent

from maeris_mcp.tools.unit_tests import (
    _get_client_id,
    handle_generate_unit_tests,
    handle_generate_unit_tests_focused,
    handle_run_unit_tests,
    handle_run_mutation_tests,
    handle_analyze_test_failure,
    handle_fix_unit_test,
    handle_auto_fix_unit_test,
    handle_check_unit_test_setup,
    handle_apply_unit_test_setup_fix,
    handle_run_canary_check,
    handle_sync_unit_tests_to_maeris,
    handle_analyze_unit_test_critical_path,
    handle_delete_test_file,
)

# Refresh the server's view of our heartbeat every 10s during any action so
# that an HTTP burst from the action (e.g. the 4-5 calls fired on run
# completion) cannot starve the main 20s heartbeat long enough for the
# backend's 45s staleness cutoff to trip and flicker the UI pill offline.
_MCP_KEEPER_INTERVAL_S = 10.0


async def _keep_mcp_alive(client, cid: str):
    """Background task: ping unit_tests_heartbeat while an action runs."""
    try:
        while True:
            await asyncio.sleep(_MCP_KEEPER_INTERVAL_S)
            try:
                await client.unit_tests_heartbeat(cid)
            except Exception:
                # Best-effort — the main heartbeat task still handles
                # persistent connection loss via its own reconnect loop.
                pass
    except asyncio.CancelledError:
        return

# Whitelist of npm packages the SetupWizardBanner is allowed to install.
# Mirrors the install_hint the /framework endpoint emits — anything outside
# this set is rejected so a malicious dispatch can't invoke npm install on
# arbitrary packages.
_ALLOWED_SETUP_PACKAGES = {
    # Frameworks
    "jest", "vitest", "mocha", "chai", "jasmine",
    # Jest env + assertions
    "jest-environment-jsdom", "jsdom",
    "@testing-library/react", "@testing-library/jest-dom",
    "@testing-library/user-event",
    # TS support
    "ts-jest", "ts-node", "@types/jest", "@types/mocha", "@types/jasmine",
    # Babel (for plain React + Jest)
    "babel-jest", "@babel/core", "@babel/preset-env", "@babel/preset-react",
    # CSS Modules mock used by Next.js / React Jest configs
    "identity-obj-proxy",
    # Mutation testing — Stryker core + runner plugins. Gated behind the
    # same whitelist so the mutation UI can offer a one-click install when
    # the package is missing instead of making users copy/paste commands.
    "@stryker-mutator/core",
    "@stryker-mutator/jest-runner",
    "@stryker-mutator/vitest-runner",
}

_PKG_NAME_RE = re.compile(r"^(?:@[a-z0-9-]+/)?[a-z0-9][a-z0-9._-]*$", re.IGNORECASE)


_STRUCTURED_ACTIONS = {"generate_preview", "mutation", "analyze_failure", "fix_test", "auto_fix", "check_setup", "apply_setup_fix", "canary_check", "analyze_critical_path"}



def _pretty_summary(action: str, payload: dict) -> str:
    """Turn the tool's raw JSON response into a one-line toast-friendly string."""
    try:
        data = json.loads(payload) if isinstance(payload, str) else payload
    except Exception:
        return f"{action}: done"

    if action in ("generate", "regenerate", "generate_focused"):
        if data.get("status") == "error":
            return f"Generation failed: {data.get('message', 'unknown error')}"
        if action == "generate_focused":
            return data.get("summary") or f"{data.get('tests_generated', 0)} test(s) added."
        count = data.get("tests_generated", 0)
        files = data.get("files_processed", 0)
        return f"{count} tests generated across {files} files."
    if action == "run":
        t = data.get("totals") or {}
        return (
            f"Run complete — passed {t.get('passed', 0)}, "
            f"failed {t.get('failed', 0)}, skipped {t.get('skipped', 0)} "
            f"in {t.get('duration_ms', 0)}ms."
        )
    if action == "sync":
        return f"Synced {data.get('registered', 0)} tests to Maeris."
    if action == "analyze_critical_path":
        total = data.get("total_tests", 0)
        flagged = data.get("critical_count", 0)
        if total == 0:
            return "Critical path: 0 tests synced to Maeris — run sync first."
        return f"Critical path: {flagged}/{total} tests flagged as critical."
    if action == "analyze_failure":
        a = data.get("analysis") or {}
        d = a.get("diagnosis") or {}
        if data.get("status") == "completed" and d.get("headline"):
            return f"Analysis: {d['headline']}"
        if data.get("status") == "unavailable":
            return "Failure analysis unavailable (see output for reason)."
        return f"Analysis finished with status {data.get('status', 'unknown')}."
    if action == "install_packages":
        if data.get("status") == "ok":
            n = data.get("count", 0)
            return f"Installed {n} package(s) — you're ready to generate tests."
        return f"Install failed: {data.get('message', 'unknown error')}"
    if action == "fix_test":
        if data.get("status") == "applied":
            return f"Fix applied to {data.get('file_path', 'file')}."
        return f"Fix failed: {data.get('message', 'unknown error')}"
    if action == "auto_fix":
        status = data.get("status")
        applied = data.get("fixes_applied", 0)
        if status == "passed":
            return f"Auto-fix succeeded — test green after {applied} fix(es)."
        if status == "no_fix_suggested":
            return "Auto-fix stopped: analyzer had no concrete suggestion."
        if status == "max_iterations_reached":
            return f"Auto-fix stopped after {applied} fix(es); test still failing."
        return f"Auto-fix: {status} — {data.get('message', '')[:140]}"
    if action == "check_setup":
        if data.get("status") == "completed":
            s = data.get("summary") or {}
            overall = data.get("overall", "unknown")
            return (
                f"Setup check: {overall} — "
                f"{s.get('pass', 0)} ok, {s.get('warn', 0)} warn, "
                f"{s.get('fail', 0)} fail, {s.get('skipped', 0)} skipped."
            )
        return f"Setup check failed: {data.get('message', 'unknown')}"
    if action == "apply_setup_fix":
        if data.get("status") == "applied":
            return f"Setup fix applied: created {data.get('path', 'file')}."
        if data.get("status") == "exists":
            return f"Setup fix skipped: {data.get('path', 'file')} already exists."
        return f"Setup fix failed: {data.get('message', 'unknown')}"
    if action == "canary_check":
        s = data.get("status")
        if s == "healthy":
            return "Deep check: canary rendered — your setup works."
        if s == "skipped":
            return f"Deep check skipped: {data.get('reason', '')[:140]}"
        if s == "run_error":
            return f"Deep check couldn't run: {data.get('message', '')[:140]}"
        if s == "broken":
            n = len(data.get("diagnoses") or [])
            return f"Deep check: found {n} issue(s) blocking React renders."
        return f"Deep check: {s}"
    if action == "mutation":
        s = data.get("summary") or {}
        if data.get("status") == "not_installed":
            return "Mutation testing needs Stryker — see instructions in the output."
        if data.get("status") == "completed":
            return (
                f"Mutation score {s.get('overall_score', 0)}% — "
                f"{s.get('killed', 0)} killed, {s.get('survived', 0)} survived "
                f"({s.get('total_mutants', 0)} mutants)."
            )
        return f"Mutation run finished with status {data.get('status', 'unknown')}."
    if action == "delete_test_file":
        if data.get("status") == "deleted":
            return f"Deleted {data.get('file_path', 'test file')}."
        if data.get("status") == "not_found":
            return f"File not found: {data.get('file_path', '')}."
        return f"Delete failed: {data.get('message', 'unknown error')}"
    return f"{action}: done"


async def execute_unit_tests_action(client, cmd_id: str, command_text: str, cwd: str):
    """Parse the queued command, call the matching tool, report progress/completion."""
    try:
        payload = json.loads(command_text)
    except Exception as exc:
        await client.complete_command(cmd_id, error=f"bad payload: {exc}", success=False)
        return

    action = payload.get("action")
    args = dict(payload.get("args") or {})
    # Always run against the listener's cwd unless the UI picked something else.
    args.setdefault("repo_path", cwd)

    click.secho(f"  UnitTests action: {action} args={args}", fg="cyan")
    await client.post_progress(cmd_id, [f"Starting {action}…"])

    # Keep the MCP connection fresh throughout the action. The main 20s
    # heartbeat task can be delayed behind concurrent HTTP traffic on long or
    # bursty actions; this keeper pings on a faster cadence so the UI pill
    # stays "Connected" no matter which action ran or how long it took.
    cid = _get_client_id()
    keeper = asyncio.create_task(_keep_mcp_alive(client, cid))

    try:
        if action == "generate":
            # AC-07: stream per-file progress while the tool runs. Sync sink —
            # we schedule fire-and-forget posts back to Maeris.
            args["_progress_sink"] = lambda line: asyncio.ensure_future(
                client.post_progress(cmd_id, [line])
            )
            result = await handle_generate_unit_tests(args)
        elif action == "generate_preview":
            # Diff preview for AC-17 — runs the generator without touching disk
            # or pushing metadata, so the UI can show a real Added/Removed list
            # before the user confirms the regenerate.
            args["dry_run"] = True
            args["sync_to_maeris"] = False
            result = await handle_generate_unit_tests(args)
        elif action == "regenerate":
            # Regenerate = force-overwrite so the diff swap is visible.
            args["overwrite"] = True
            result = await handle_generate_unit_tests(args)
        elif action == "run":
            result = await handle_run_unit_tests(args)
        elif action == "mutation":
            result = await handle_run_mutation_tests(args)
        elif action == "analyze_failure":
            result = await handle_analyze_test_failure(args)
        elif action == "fix_test":
            result = await handle_fix_unit_test(args)
        elif action == "auto_fix":
            result = await handle_auto_fix_unit_test(args)
        elif action == "check_setup":
            result = await handle_check_unit_test_setup(args)
        elif action == "apply_setup_fix":
            result = await handle_apply_unit_test_setup_fix(args)
        elif action == "canary_check":
            result = await handle_run_canary_check(args)
        elif action == "sync":
            result = await handle_sync_unit_tests_to_maeris(args)
        elif action == "analyze_critical_path":
            result = await handle_analyze_unit_test_critical_path(args)
        elif action == "delete_test_file":
            result = await handle_delete_test_file(args)
        elif action == "generate_focused":
            args["_progress_sink"] = lambda line: asyncio.ensure_future(
                client.post_progress(cmd_id, [line])
            )
            result = await handle_generate_unit_tests_focused(args)
        elif action == "install_packages":
            result = await _handle_install_packages(args, client, cmd_id)
        else:
            await client.complete_command(cmd_id, error=f"unknown action '{action}'", success=False)
            return

        raw = result[0].text if result else "{}"
        # Always compute the toast summary; structured actions (diff previews,
        # mutation reports) ship the raw JSON back to the UI as well.
        summary_line = _pretty_summary(action, raw)
        output = raw if action in _STRUCTURED_ACTIONS else summary_line
        click.secho(f"  ✓ {summary_line}", fg="green")
        await client.post_progress(cmd_id, [summary_line])
        await client.complete_command(cmd_id, output=output, success=True)
    except Exception as exc:
        click.secho(f"  ✗ {action} failed: {exc}", fg="red")
        await client.complete_command(cmd_id, error=str(exc), success=False)
    finally:
        keeper.cancel()
        try:
            await keeper
        except (asyncio.CancelledError, Exception):
            pass
        # One final heartbeat so the server's last_heartbeat_at is fresh at
        # the exact moment the UI receives the completion toast and re-polls.
        try:
            await client.unit_tests_heartbeat(cid)
        except Exception:
            pass


async def _handle_install_packages(args: dict, client, cmd_id: str) -> list:
    """Run `npm install --save-dev <packages>` for the SetupWizardBanner.

    Packages are restricted to the whitelist the /framework endpoint itself
    suggests — the UI never sends freeform package names, but this guards
    against a rogue dispatch row slipping arbitrary commands through.
    """
    repo = Path(args.get("repo_path") or ".").resolve()
    requested = args.get("packages") or []
    if not isinstance(requested, list) or not requested:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "no packages specified",
        }))]

    cleaned: list[str] = []
    for name in requested:
        if not isinstance(name, str):
            continue
        name = name.strip()
        if not name or not _PKG_NAME_RE.match(name):
            continue
        if name not in _ALLOWED_SETUP_PACKAGES:
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": f"package '{name}' is not in the allowed setup list",
            }))]
        cleaned.append(name)

    if not cleaned:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "no valid packages after filtering",
        }))]

    npm_bin = shutil.which("npm")
    if not npm_bin:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "npm not found on PATH — install Node.js and try again",
        }))]

    try:
        await client.post_progress(cmd_id, [f"Running: npm install --save-dev {' '.join(cleaned)}"])
    except Exception:
        pass

    proc = await asyncio.create_subprocess_exec(
        npm_bin, "install", "--save-dev", *cleaned,
        cwd=str(repo),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout_bytes, _ = await proc.communicate()
    out = (stdout_bytes or b"").decode("utf-8", errors="replace")

    if proc.returncode != 0:
        tail = "\n".join(out.strip().splitlines()[-12:]) or "npm install exited non-zero"
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": tail,
            "exit_code": proc.returncode,
        }))]

    return [TextContent(type="text", text=json.dumps({
        "status": "ok",
        "count": len(cleaned),
        "packages": cleaned,
    }))]
