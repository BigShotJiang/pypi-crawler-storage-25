"""Maeris CLI — thin entry point.

All command groups are defined in _core.py.
Commands are registered in the submodule files below, which are imported
here solely for their side-effects (decorator-based registration).
"""

from ._core import cli  # noqa: F401 — re-exported for pyproject [console_scripts]

# Register commands via side-effects
import maeris_mcp.cli.auth_cmds  # noqa: F401
import maeris_mcp.cli.test_cmds  # noqa: F401
import maeris_mcp.cli.resource_cmds  # noqa: F401
import maeris_mcp.cli.fix_cmds  # noqa: F401
import maeris_mcp.cli.coverage_cmds  # noqa: F401
import maeris_mcp.cli.scan_cmds  # noqa: F401
import maeris_mcp.cli.listen_cmds  # noqa: F401
import maeris_mcp.cli.report_cmds  # noqa: F401
import maeris_mcp.cli.ci_cmd  # noqa: F401
import maeris_mcp.cli.config_cmds  # noqa: F401
import maeris_mcp.cli.repair_cmds  # noqa: F401
import maeris_mcp.cli.baseline_cmds  # noqa: F401
import maeris_mcp.cli.welcome_cmds  # noqa: F401
import maeris_mcp.cli.serve_cmds  # noqa: F401
import maeris_mcp.cli.doctor_cmds  # noqa: F401
import maeris_mcp.cli.gen_cmds  # noqa: F401
import maeris_mcp.cli.gen_nav_cmds  # noqa: F401

__all__ = ["cli"]

if __name__ == "__main__":
    cli()
