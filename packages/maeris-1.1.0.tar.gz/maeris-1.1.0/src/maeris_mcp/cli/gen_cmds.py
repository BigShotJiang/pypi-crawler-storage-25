"""Generate CLI command — calls handle_generate directly.

Uses the same generate tool logic as the MCP/chat interface, with
interactive terminal prompts for credentials and feedback. Fallbacks
are provided where CLI cannot replicate AI-driven behaviour (e.g. the
iterative run-and-fix loop).
"""

import asyncio
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import click

from ._core import cli

_EXPLORE_FLAGS = [
    "--print",
    "--dangerously-skip-permissions",
    "--no-session-persistence",
    "--mcp-config", '{"mcpServers":{}}',
    "--strict-mcp-config",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_response(result: list) -> dict:
    """Extract JSON payload from handle_generate's TextContent list."""
    if not result:
        return {}
    text = result[0].text
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"raw": text}


def _display_test_cases(test_cases: list) -> None:
    """Show test cases with every step listed (Phase 3b format)."""
    for i, tc in enumerate(test_cases, 1):
        name = tc.get("test_name", f"Test {i}")
        ttype = tc.get("test_type", "")
        click.echo(f"\n{i}. {name} [{ttype}]")
        for step in tc.get("steps", []):
            desc = step.get("description", "")
            action = step.get("action_taken", "")
            assertion_nature = step.get("assertion_nature", "")
            if assertion_nature:
                atype = step.get("assertion_type", "")
                avalue = step.get("assertion_value", "")
                click.echo(f"   - [assert] {assertion_nature} \u2192 {atype} \u2192 {avalue}")
            elif action:
                click.echo(f"   - {action}: {desc}")
            else:
                click.echo(f"   - {desc}")


def _show_uncertain_selectors(uncertain: list) -> None:
    """Show uncertain-selector warnings."""
    if not uncertain:
        return
    click.secho(
        f"\n\u26a0\ufe0f  {len(uncertain)} step(s) have uncertain or fragile selectors:",
        fg="yellow",
    )
    for entry in uncertain:
        step_desc = entry.get("step_description", "")
        test_name = entry.get("test_name", "")
        selector = entry.get("css_selector", "")
        reason = entry.get("reason", "")
        click.echo(f'   - "{step_desc}" in "{test_name}": {selector} \u2014 {reason}')


def _run_explore_subprocess(claude_bin: str, instructions: str) -> str | None:
    """Run Claude CLI subprocess for codebase exploration. Returns findings or None."""
    try:
        r = subprocess.run(
            [claude_bin, *_EXPLORE_FLAGS, instructions],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=300,
        )
        if r.returncode != 0:
            click.secho(f"\n\u2717 Explore error: {r.stderr[:200]}", fg="red")
            return None
        findings = r.stdout.strip()
        if not findings:
            click.secho("\n\u2717 Explore returned empty output.", fg="red")
            return None
        return findings
    except subprocess.TimeoutExpired:
        click.secho("\n\u2717 Explore timed out after 300s.", fg="red")
        return None


# ---------------------------------------------------------------------------
# Nav refresh helper
# ---------------------------------------------------------------------------

async def _ensure_nav(claude_bin: str) -> bool:
    """Build / refresh navigation.md if needed. Returns True on success."""
    from maeris_mcp.tools.generate_nav_tool import handle_generate_nav

    # Phase 1 — get explore instructions
    nav_resp = _parse_response(await handle_generate_nav({}))
    status = nav_resp.get("status", "")

    if status != "explore_needed":
        # Already up-to-date or error
        if "error" in status:
            click.secho(f"  \u2717 Nav build failed: {nav_resp.get('message', '')}", fg="red")
            return False
        return True

    instructions = nav_resp.get("instructions", "")
    if not instructions:
        click.secho("  \u2717 No nav exploration instructions returned.", fg="red")
        return False

    click.echo("  \u2192 Exploring navigation structure...")
    findings = _run_explore_subprocess(claude_bin, instructions)
    if not findings:
        return False

    # Phase 2 — save navigation.md
    nav_resp = _parse_response(await handle_generate_nav({"findings": findings}))
    if nav_resp.get("status") == "error":
        click.secho(f"  \u2717 Nav save failed: {nav_resp.get('message', '')}", fg="red")
        return False

    click.echo("  \u2713 Navigation map built")
    return True


# ---------------------------------------------------------------------------
# Push-to-Maeris helper
# ---------------------------------------------------------------------------

async def _push_to_maeris(
    user_command: str,
    test_cases: list,
    base_url: str,
    test_email: str,
    test_password: str,
    folder: str | None,
    from_exec_dir: str | None = None,
) -> None:
    from maeris_mcp.tools.generate_tool import handle_generate

    if not folder:
        folder = click.prompt("Maeris test folder name").strip()

    count = len(test_cases) if test_cases else "corrected"
    click.echo(f"  \u2192 Pushing {count} test case(s) to Maeris folder '{folder}'...")

    push_args: dict = {
        "command": user_command,
        "push_to_maeris": True,
        "base_url": base_url,
        "test_email": test_email,
        "test_password": test_password,
        "credentials_confirmed": True,
        "test_folder": folder,
    }
    if from_exec_dir:
        push_args["from_exec_dir"] = from_exec_dir
    else:
        push_args["test_cases"] = test_cases

    response = _parse_response(await handle_generate(push_args))
    status = response.get("status", "")

    if status == "error":
        click.secho(
            f"  \u2717 Push failed: {response.get('message', 'Unknown error')}",
            fg="red",
        )
        return

    pushed = response.get("testsPushed", 0)
    skipped = response.get("skipped", [])
    click.secho(f"  \u2713 Pushed {pushed} test case(s) to Maeris", fg="green")
    if skipped:
        click.secho(f"  \u26a0 {len(skipped)} skipped by quality gate", fg="yellow")


# ---------------------------------------------------------------------------
# Run-and-fix helper (with CLI fallback)
# ---------------------------------------------------------------------------

async def _run_and_fix_flow(
    user_command: str,
    test_cases: list,
    base_url: str,
    test_email: str,
    test_password: str,
    folder: str | None,
) -> None:
    """Seed run-and-fix, attempt execution, then push.

    The full iterative AI-driven fix loop requires an LLM to inspect
    failures and produce corrected code — something CLI cannot do.
    CLI runs the tests once and pushes whatever passes. For the full
    experience, use the generate MCP tool in Claude chat.
    """
    from maeris_mcp.tools.generate_tool import handle_generate

    # -- Hop 1: Seed --
    click.echo("  \u2192 Seeding run-and-fix session...")
    seed_args = {
        "command": user_command,
        "run_and_fix": True,
        "test_cases": test_cases,
        "base_url": base_url,
        "test_email": test_email,
        "test_password": test_password,
        "credentials_confirmed": True,
    }
    seed_resp = _parse_response(await handle_generate(seed_args))

    if seed_resp.get("status") != "run_and_fix_ready":
        click.secho(
            f"  \u2717 Seed failed: {seed_resp.get('message', 'Unknown error')}",
            fg="red",
        )
        return

    exec_dir = seed_resp.get("exec_dir", "")
    auto_run_args = seed_resp.get("autoRun", {}).get("arguments", {})
    if not exec_dir or not auto_run_args:
        click.secho("  \u2717 Seed response missing exec_dir or autoRun arguments.", fg="red")
        return

    # -- Hop 2: Run tests (single pass — CLI fallback) --
    click.secho(
        "\n  \u26a0 CLI limitation: the full iterative AI-driven fix loop requires\n"
        "    Claude to inspect failures and produce corrected test code.\n"
        "    CLI will run the tests once and push whatever passes.\n"
        "    For the full run-fix-push experience, use the generate MCP tool\n"
        "    in Claude chat (option C in the post-generation menu).\n",
        fg="yellow",
    )

    try:
        from maeris_mcp.storage.execution_store import TestExecutionStore
        from maeris_mcp.storage.test_store import TestGenerationStore
        from maeris_mcp.tools.test_execution import handle_run_and_fix_tests

        exec_store = TestExecutionStore()
        test_store = TestGenerationStore()

        click.echo("  \u2192 Running tests...")
        result = _parse_response(
            await handle_run_and_fix_tests(exec_store, test_store, auto_run_args)
        )
        run_status = result.get("status", "")

        if run_status == "all_complete":
            click.secho("  \u2713 All tests passed!", fg="green")
        elif "app" in str(result.get("message", "")).lower() and (
            "unavailable" in str(result.get("message", "")).lower()
            or "refused" in str(result.get("message", "")).lower()
        ):
            click.secho(
                "  \u2717 App appears unavailable. Start your app, then retry.",
                fg="red",
            )
            return
        else:
            passed = result.get("passed", "?")
            failed = result.get("failed", "?")
            click.secho(
                f"  \u26a0 Test run complete \u2014 passed: {passed}, failed: {failed}",
                fg="yellow",
            )
            click.echo(
                "    Failed tests need AI-driven fixing. Use the generate MCP tool\n"
                "    in Claude chat for iterative fix loops."
            )

    except ImportError as e:
        click.secho(
            f"  \u2717 Run-and-fix dependencies not available: {e}\n"
            "    Skipping test execution \u2014 pushing test cases as-is.",
            fg="red",
        )
    except Exception as e:  # noqa: BLE001
        click.secho(f"  \u2717 Run-and-fix error: {e}", fg="red")

    # -- Hop 3: Push --
    if not folder:
        folder = click.prompt("Maeris test folder name").strip()

    push = click.confirm(
        f"Push test cases to Maeris folder '{folder}'?", default=True,
    )
    if push:
        await _push_to_maeris(
            user_command, test_cases, base_url, test_email, test_password,
            folder, from_exec_dir=exec_dir,
        )


# ---------------------------------------------------------------------------
# Feedback loop
# ---------------------------------------------------------------------------

async def _feedback_loop(
    user_command: str,
    test_cases: list,
    stored_findings: str,
    output_file: str,
    app_path: str,
    base_url: str,
    test_email: str,
    test_password: str,
    claude_bin: str,
    folder: str | None,
) -> None:
    from maeris_mcp.tools.generate_tool import handle_generate

    raw_feedback = click.prompt("Describe what's missing or incorrect").strip()
    if not raw_feedback:
        return

    clarified_feedback = raw_feedback
    while True:
        followup = click.prompt(
            "Anything to clarify or add? (press Enter when done)",
            default="",
            show_default=False,
        ).strip()
        if not followup:
            break
        clarified_feedback = f"{clarified_feedback}. {followup}"

    # Save feedback via handle_generate
    click.echo("  \u2192 Saving feedback...")
    save_args = {
        "command": user_command,
        "feedback": clarified_feedback,
        "previous_findings": stored_findings,
        "app_path": app_path,
        "credentials_confirmed": True,
    }
    save_resp = _parse_response(await handle_generate(save_args))

    if save_resp.get("status") != "feedback_saved":
        click.secho(f"  \u2717 Feedback save failed: {json.dumps(save_resp)[:200]}", fg="red")
        return

    click.secho("  \u2713 Feedback saved.", fg="cyan")

    fast_available = (
        save_resp.get("options", {})
        .get("update_now_fast", {})
        .get("available", False)
    )

    click.echo("")
    click.echo("What would you like to do?")
    if fast_available:
        click.echo("  [1] Update now \u2014 fast (re-structure using stored findings, ~10-15s)")
    else:
        click.echo("  [1] (unavailable \u2014 no stored findings for fast update)")
    click.echo("  [2] Regenerate fully (re-explore codebase, then regenerate)")
    click.echo("  [3] Save for next time (apply automatically on next generation)")

    choice = click.prompt("Choice", default="3", show_default=True).strip()

    if choice == "1" and fast_available:
        click.echo("  \u2192 Updating test cases with feedback...")
        t = time.monotonic()
        update_args = {
            "command": user_command,
            "use_stored_findings": True,
            "feedback": clarified_feedback,
            "app_path": app_path,
            "base_url": base_url,
            "test_email": test_email,
            "test_password": test_password,
            "credentials_confirmed": True,
        }
        update_resp = _parse_response(await handle_generate(update_args))
        if update_resp.get("success"):
            test_cases = update_resp.get("test_cases", test_cases)
            Path(output_file).write_text(
                json.dumps(test_cases, indent=2), encoding="utf-8",
            )
            elapsed = round(time.monotonic() - t, 1)
            click.secho(
                f"  \u2713 {len(test_cases)} test cases updated \u2192 {output_file} ({elapsed}s)",
                fg="green",
            )
            _display_test_cases(test_cases)

            stored_findings = update_resp.get("storedFindings", stored_findings)
            await _post_generation_menu(
                user_command, test_cases, stored_findings, output_file, app_path,
                base_url, test_email, test_password, claude_bin, folder,
            )
        else:
            msg = update_resp.get("message") or update_resp.get("raw", "Unknown error")
            click.secho(f"  \u2717 Update failed: {msg}", fg="red")

    elif choice == "1" and not fast_available:
        click.secho("  \u2717 Fast update unavailable. Use option 2 instead.", fg="red")

    elif choice == "2":
        click.secho(
            "  \u2192 Run 'maeris generate' again \u2014 feedback will be applied automatically.",
            fg="cyan",
        )

    else:
        click.secho(
            "  \u2713 Feedback stored. Will be applied next time you generate for a similar flow.",
            fg="cyan",
        )


# ---------------------------------------------------------------------------
# Post-generation menu
# ---------------------------------------------------------------------------

async def _post_generation_menu(
    user_command: str,
    test_cases: list,
    stored_findings: str,
    output_file: str,
    app_path: str,
    base_url: str,
    test_email: str,
    test_password: str,
    claude_bin: str,
    folder: str | None,
) -> None:
    click.echo("")
    click.echo("What would you like to do?")
    click.echo("  [1] Report missing or incorrect steps (feedback)")
    click.echo("  [2] Push these to Maeris as-is")
    click.echo("  [3] Auto run and fix, then push (requires app running)")
    click.echo("  [4] Done \u2014 keep the JSON file")

    choice = click.prompt("Choice", default="4", show_default=True).strip()

    if choice == "1":
        await _feedback_loop(
            user_command, test_cases, stored_findings, output_file, app_path,
            base_url, test_email, test_password, claude_bin, folder,
        )

    elif choice == "2":
        await _push_to_maeris(
            user_command, test_cases, base_url, test_email, test_password, folder,
        )

    elif choice == "3":
        await _run_and_fix_flow(
            user_command, test_cases, base_url, test_email, test_password, folder,
        )


# ---------------------------------------------------------------------------
# Main generate flow
# ---------------------------------------------------------------------------

async def _generate_flow(
    user_command: str,
    output_file: str,
    app_path: str,
    base_url: str,
    test_email: str,
    test_password: str,
    claude_bin: str,
    folder: str | None,
) -> None:
    from maeris_mcp.tools.generate_tool import handle_generate

    # ----------------------------------------------------------------
    # Phase 1 — ask handle_generate for explore instructions
    # ----------------------------------------------------------------
    click.echo(f"\u2192 Preparing exploration for: {user_command}")
    t0 = time.monotonic()

    phase1_args = {
        "command": user_command,
        "base_url": base_url,
        "test_email": test_email,
        "test_password": test_password,
        "credentials_confirmed": True,  # CLI asked the user directly
    }
    response = _parse_response(await handle_generate(phase1_args))
    status = response.get("status", "")

    # -- Handle nav_refresh_needed: build nav automatically --
    if status == "nav_refresh_needed":
        click.echo("  \u2192 Navigation map missing or stale, building it first...")
        if not await _ensure_nav(claude_bin):
            return
        # Retry Phase 1
        response = _parse_response(await handle_generate(phase1_args))
        status = response.get("status", "")

    if status == "error":
        click.secho(f"\u2717 {response.get('message', 'Unknown error')}", fg="red")
        return

    if status == "credentials_required":
        fields = response.get("missingFields", [])
        click.secho(f"\u2717 Missing credentials: {', '.join(fields)}", fg="red")
        return

    if status != "explore_needed":
        click.secho(f"\u2717 Unexpected response status: {status}", fg="red")
        if response.get("raw"):
            click.echo(response["raw"][:300])
        return

    # ----------------------------------------------------------------
    # Explore — Claude CLI subprocess scans the codebase
    # ----------------------------------------------------------------
    explore_instructions = response.get("instructions", "")
    click.echo("  \u2192 Exploring codebase...")
    t1 = time.monotonic()

    findings = _run_explore_subprocess(claude_bin, explore_instructions)
    if not findings:
        return

    explore_secs = round(time.monotonic() - t1, 1)
    click.echo(f"  explore: {explore_secs}s", nl=False)

    # ----------------------------------------------------------------
    # Phase 2 — pass findings to handle_generate for structuring
    # (selector inventory, proven context, nav context — all handled
    # by the tool, same as the MCP/chat path)
    # ----------------------------------------------------------------
    click.echo("  \u2192 structuring...", nl=False)
    t2 = time.monotonic()

    phase2_args = {
        "command": user_command,
        "findings": findings,
        "app_path": app_path,
        "base_url": base_url,
        "test_email": test_email,
        "test_password": test_password,
        "credentials_confirmed": True,
    }
    response = _parse_response(await handle_generate(phase2_args))

    structure_secs = round(time.monotonic() - t2, 1)
    total_secs = round(time.monotonic() - t0, 1)

    if not response.get("success"):
        error_msg = (
            response.get("message")
            or response.get("raw")
            or response.get("error", "Unknown error")
        )
        click.secho(f"\n\u2717 Generation failed: {error_msg}", fg="red")
        return

    test_cases = response.get("test_cases", [])
    uncertain_selectors = response.get("uncertain_selectors", [])
    uncertain_files = response.get("uncertain_files", [])
    stored_findings = response.get("storedFindings", findings)

    # Save to file
    Path(output_file).write_text(
        json.dumps(test_cases, indent=2), encoding="utf-8",
    )
    click.echo(f"  structure: {structure_secs}s  |  total: {total_secs}s")
    click.secho(f"\u2713 {len(test_cases)} test cases \u2192 {output_file}", fg="green")

    if response.get("count_warning"):
        click.secho(f"  \u26a0 {response['count_warning']}", fg="yellow")

    # ----------------------------------------------------------------
    # Phase 3a — Uncertain selectors
    # ----------------------------------------------------------------
    if uncertain_selectors:
        _show_uncertain_selectors(uncertain_selectors)
        click.echo("")
        apply = click.confirm(
            "Add stable automation attributes (data-automation-id) to these elements in your source code?",
            default=False,
        )
        if apply:
            attr_name = click.prompt(
                "Attribute name",
                default="data-automation-id",
                show_default=True,
            ).strip()

            click.echo("  \u2192 Applying automation attributes...")
            attr_args = {
                "apply_automation_attrs": True,
                "app_path": app_path,
                "attr_name": attr_name,
                "target_files": uncertain_files,
                "test_cases": test_cases,
            }
            attr_resp = _parse_response(await handle_generate(attr_args))
            attr_status = attr_resp.get("status", "")

            if "applied" in attr_status or "swapped" in attr_status:
                # Use the updated test_cases (old array is stale)
                test_cases = attr_resp.get("test_cases", test_cases)
                Path(output_file).write_text(
                    json.dumps(test_cases, indent=2), encoding="utf-8",
                )
                patched = attr_resp.get("files_patched", 0)
                swaps = attr_resp.get("selector_swaps", [])
                click.secho(
                    f"  \u2713 {patched} file(s) patched, {len(swaps)} selector(s) swapped",
                    fg="green",
                )
                remaining = attr_resp.get("uncertain_selectors", [])
                if remaining:
                    click.secho(
                        f"  \u26a0 {len(remaining)} selector(s) still uncertain",
                        fg="yellow",
                    )
            else:
                click.secho(
                    f"  \u2717 Attribute injection failed: {attr_resp.get('message', '')}",
                    fg="red",
                )

            click.secho(
                "\n  \u26a0 Note: Updated tests will only work locally until your"
                " source changes are deployed.",
                fg="yellow",
            )

    # ----------------------------------------------------------------
    # Phase 3b — Show test cases
    # ----------------------------------------------------------------
    _display_test_cases(test_cases)

    # ----------------------------------------------------------------
    # Phase 3c — Post-generation menu
    # ----------------------------------------------------------------
    await _post_generation_menu(
        user_command, test_cases, stored_findings, output_file, app_path,
        base_url, test_email, test_password, claude_bin, folder,
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

@cli.command("generate")
@click.argument("command", nargs=-1, required=True)
@click.option("--out", default=None, help="Output filename, e.g. --out login_steps.json")
@click.option("--base-url", default=None, help="App starting URL, e.g. http://localhost:3000")
@click.option("--email", default=None, help="Test account email")
@click.option("--password", default=None, help="Test account password")
@click.option("--app-path", default=None, help="Absolute path to app root (default: cwd)")
@click.option("--folder", default=None, help="Maeris test folder name for push")
def generate_cmd(
    command: tuple[str, ...],
    out: str | None,
    base_url: str | None,
    email: str | None,
    password: str | None,
    app_path: str | None,
    folder: str | None,
) -> None:
    """Explore the codebase and generate plain test steps as a JSON file.

    \b
    Uses the same generate tool as the MCP/chat interface — including
    selector inventory, proven context, navigation map, and reachability
    validation.

    \b
    Examples:
      maeris generate testcases for login flow --base-url http://localhost:3000 --email u@e.com --password secret
      maeris generate steps for the checkout page --out checkout_steps.json
    """
    user_command = " ".join(command)
    output_file = str(Path.cwd() / (out if out else "generated_steps.json"))
    app_path = (app_path or str(Path.cwd())).strip()
    base_url = (base_url or "").strip()
    test_email = (email or "").strip()
    test_password = (password or "").strip()

    # --- Credential gate (interactive prompts for missing) ---
    if not base_url:
        base_url = click.prompt("App starting URL (e.g. http://localhost:3000)").strip()
    if not test_email:
        test_email = click.prompt("Test account email").strip()
    if not test_password:
        test_password = click.prompt("Test account password", hide_input=True).strip()

    # --- Claude CLI required for codebase exploration ---
    claude_bin = shutil.which("claude.exe") or shutil.which("claude")
    if not claude_bin:
        click.secho(
            "\u2717 Claude CLI not found on PATH. Required for codebase exploration.",
            fg="red",
        )
        sys.exit(1)

    asyncio.run(
        _generate_flow(
            user_command, output_file, app_path, base_url, test_email,
            test_password, claude_bin, folder,
        )
    )
