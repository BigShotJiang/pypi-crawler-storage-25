"""Localhost-only HTTP endpoint that serves test file contents to the browser.

Satisfies spec AC-36/AC-42 without violating AC-37 — code never reaches the
Maeris backend. The server only binds to 127.0.0.1, only serves files under
the listener's cwd, only serves test files (*.test.*, *.spec.*), and adds
permissive CORS so the Maeris web UI (http://localhost:3000 or cloud) can
fetch via the user's own browser.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import threading
import time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import urlparse, parse_qs

import structlog

# ── LLM anonymous-function naming ──────────────────────────────────────────────
# Cache: abs_file_path -> (mtime_ns, {fn_id: resolved_name})
_anon_name_cache: dict[str, tuple[int, dict[str, str]]] = {}
_anon_name_lock = threading.Lock()

# ── Persistent file-based MCP cache ───────────────────────────────────────────
# Stored at ~/.maeris/mcp_cache/<type>_<md5(abs_path)>.json
# Each file: {"mtime_ns": int, "data": {...}}
# Invalidated when the source file (or coverage-final.json) mtime changes.

def _mcp_cache_dir() -> Path:
    d = Path.home() / ".maeris" / "mcp_cache"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d

def _mcp_cache_read(cache_type: str, abs_path: str, mtime_ns: int) -> dict | None:
    """Return cached data dict if the entry exists and mtime matches, else None."""
    try:
        h = hashlib.md5(abs_path.encode("utf-8")).hexdigest()
        p = _mcp_cache_dir() / f"{cache_type}_{h}.json"
        if not p.exists():
            return None
        entry = json.loads(p.read_text(encoding="utf-8"))
        if entry.get("mtime_ns") == mtime_ns:
            return entry.get("data")
    except Exception:
        pass
    return None

def _mcp_cache_write(cache_type: str, abs_path: str, mtime_ns: int, data: dict) -> None:
    """Write data to the file cache. Silently swallows errors."""
    try:
        h = hashlib.md5(abs_path.encode("utf-8")).hexdigest()
        p = _mcp_cache_dir() / f"{cache_type}_{h}.json"
        p.write_text(
            json.dumps({"mtime_ns": mtime_ns, "data": data}, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass

# ── In-process LLM debt ranking cache (avoids duplicate LLM calls within a
# single maeris listen session; file cache handles cross-session persistence).
_debt_cache: dict[str, tuple[int, list]] = {}
_debt_cache_lock = threading.Lock()

_ANON_RE = re.compile(r"^\(anonymous_\d+\)$")
_LLM_MODEL = "claude-haiku-4-5"


def _llm_name_anonymous(
    src_path: Path,
    src_lines: list[str],
    anon_fns: list[dict],  # list of fn dicts that still have (anonymous_N) names
) -> dict[str, str]:
    """Return {fn_id: suggested_name} for anonymous functions via a single LLM call.

    Results are cached by file mtime so the LLM is only called once per
    file version. Falls back to empty dict on any error so callers degrade
    gracefully.
    """
    if not anon_fns:
        return {}

    try:
        mtime = src_path.stat().st_mtime_ns
    except Exception:
        mtime = 0

    cache_key = str(src_path)
    with _anon_name_lock:
        cached = _anon_name_cache.get(cache_key)
        if cached and cached[0] == mtime:
            return cached[1]

    try:
        from maeris_mcp.ai_adapter.repair_suggestions import _claude_run
    except ImportError:
        return {}

    file_name = src_path.name
    snippets: list[str] = []
    for fn in anon_fns:
        start = max(0, fn["start_line"] - 1)
        end = min(len(src_lines), fn["end_line"])
        snippet = "\n".join(src_lines[start:end])[:400]  # cap at 400 chars each
        snippets.append(f'[{fn["id"]}] (L{fn["start_line"]}–{fn["end_line"]}):\n{snippet}')

    prompt = (
        f"The following anonymous JavaScript functions are from '{file_name}'. "
        f"Give each a short camelCase name (≤25 chars) that clearly describes what it does. "
        f"Return ONLY a JSON object mapping each bracket ID to its name — no prose.\n\n"
        + "\n\n".join(snippets)
        + '\n\nExample output: {"0": "handleAddToCart", "1": "validateFormInput"}'
    )

    try:
        raw = _claude_run(prompt, model=_LLM_MODEL, timeout=30)
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            result = json.loads(match.group())
            # Sanitise: values must be non-empty strings
            clean = {str(k): str(v) for k, v in result.items() if v and isinstance(v, str)}
            with _anon_name_lock:
                _anon_name_cache[cache_key] = (mtime, clean)
            return clean
    except Exception as exc:
        logger.debug("llm_anon_name_failed", file=file_name, error=str(exc))

    return {}


_explain_cache: dict[str, tuple[int, list]] = {}
_explain_cache_lock = threading.Lock()


def _llm_explain_functions(
    src_path: Path,
    src_lines: list[str],
    fns: list[dict],
    force: bool = False,
) -> tuple[list[dict], str | None]:
    """Analyse each function for unit-test quality — complexity, side-effects,
    purity, async behaviour, error handling — completely independent of coverage.

    Batches all functions in one LLM call. Cached by file mtime.
    Returns (explanations_list, error_message).
    """
    if not fns:
        return [], None

    try:
        mtime = src_path.stat().st_mtime_ns
    except Exception:
        mtime = 0

    cache_key = str(src_path)
    if not force:
        with _explain_cache_lock:
            cached = _explain_cache.get(cache_key)
            if cached and cached[0] == mtime:
                return cached[1], None
        file_cached = _mcp_cache_read("explain", cache_key, mtime)
        if file_cached is not None and isinstance(file_cached, list):
            with _explain_cache_lock:
                _explain_cache[cache_key] = (mtime, file_cached)
            return file_cached, None

    try:
        from maeris_mcp.ai_adapter.repair_suggestions import _direct_ai_run
    except ImportError:
        return [], "Maeris AI adapter not available"

    file_name = src_path.name
    fn_blocks: list[str] = []
    for fn in fns:
        start = max(0, fn["start_line"] - 1)
        end = min(len(src_lines), fn["end_line"])
        snippet = "\n".join(src_lines[start:end])[:700]
        fn_blocks.append(f'Function: {fn["name"]}\n{snippet}')

    prompt = (
        f"You are a senior engineer reviewing '{file_name}' for unit-test quality.\n"
        f"Ignore coverage percentages entirely. Evaluate each function purely on its code.\n\n"
        f"For each function assess:\n"
        f"  - testability: is it pure/deterministic, or does it have side-effects, async ops, "
        f"external deps (API, router, DOM)? Rate: 'easy' | 'moderate' | 'hard'\n"
        f"  - quality_issues: what code-level problems make it hard to unit-test well? "
        f"(e.g. mixed responsibilities, no error handling, implicit state, tight coupling) — 1-2 sentences\n"
        f"  - key_scenarios: the specific test cases that would give the most confidence — 1-2 sentences\n"
        f"  - improvement: one concrete refactor or pattern that would make this function "
        f"more testable and robust (e.g. extract pure helper, add error boundary, accept deps as params)\n\n"
        + "\n\n---\n\n".join(fn_blocks)
        + "\n\nReturn ONLY a JSON array. Each item:\n"
        '  {"name": str, "testability": "easy"|"moderate"|"hard", '
        '"quality_issues": str, "key_scenarios": str, "improvement": str}\n'
        "Use the exact function name as given. No prose outside the JSON."
    )

    try:
        raw = _direct_ai_run(prompt, model=_LLM_MODEL)
        match = re.search(r"\[[\s\S]*\]", raw)
        if match:
            items = json.loads(match.group())
            clean = []
            for item in items:
                if not isinstance(item, dict) or "name" not in item:
                    continue
                testability = item.get("testability", "moderate")
                if testability not in ("easy", "moderate", "hard"):
                    testability = "moderate"
                clean.append({
                    "name": str(item.get("name", "")),
                    "testability": testability,
                    "quality_issues": str(item.get("quality_issues", ""))[:400],
                    "key_scenarios": str(item.get("key_scenarios", ""))[:400],
                    "improvement": str(item.get("improvement", ""))[:300],
                })
            with _explain_cache_lock:
                _explain_cache[cache_key] = (mtime, clean)
            _mcp_cache_write("explain", cache_key, mtime, clean)
            return clean, None
        return [], "No parseable JSON returned"
    except Exception as exc:
        logger.debug("llm_explain_failed", file=file_name, error=str(exc))
        return [], str(exc)


def _llm_debt_rank(
    src_path: Path,
    src_lines: list[str],
    uncovered_fns: list[dict],
    force: bool = False,
) -> tuple[list[dict], str | None]:
    """Rank uncovered/partial functions by testing priority using Claude Haiku.

    Returns (ranked_list, error_message). error_message is None on success.
    Cached by file mtime so the LLM is only called once per file version.
    """
    if not uncovered_fns:
        return [], None

    try:
        mtime = src_path.stat().st_mtime_ns
    except Exception:
        mtime = 0

    cache_key = str(src_path)
    if not force:
        with _debt_cache_lock:
            cached = _debt_cache.get(cache_key)
            if cached and cached[0] == mtime:
                return cached[1], None

        # Check persistent file cache before running the LLM.
        file_cached = _mcp_cache_read("debt", cache_key, mtime)
        if file_cached is not None and isinstance(file_cached, list):
            with _debt_cache_lock:
                _debt_cache[cache_key] = (mtime, file_cached)
            return file_cached, None

    try:
        from maeris_mcp.ai_adapter.repair_suggestions import _direct_ai_run
    except ImportError:
        return [], "Maeris AI adapter not available"

    file_name = src_path.name
    full_src = "\n".join(src_lines)
    _BRANCH_KW = re.compile(r"\b(if|else|for|while|switch|case|catch)\b|&&|\|\||\?[^:]")

    def _complexity(fn: dict) -> int:
        start = max(0, fn["start_line"] - 1)
        end = min(len(src_lines), fn["end_line"])
        return 1 + len(_BRANCH_KW.findall("\n".join(src_lines[start:end])))

    def _fan_in(name: str) -> int:
        if not name or name.startswith("("):
            return 0
        # Subtract 1 for the definition itself
        return max(0, len(re.findall(r"\b" + re.escape(name) + r"\b", full_src)) - 1)

    fn_blocks: list[str] = []
    fn_meta: list[dict] = []
    for fn in uncovered_fns:
        start = max(0, fn["start_line"] - 1)
        end = min(len(src_lines), fn["end_line"])
        snippet = "\n".join(src_lines[start:end])[:500]
        cx = _complexity(fn)
        fi = _fan_in(fn["name"])
        fn_meta.append({**fn, "complexity": cx, "fan_in": fi})
        fn_blocks.append(
            f"Function: {fn['name']} (L{fn['start_line']}–{fn['end_line']})\n"
            f"Coverage: {fn.get('coverage_pct', 0)}%  Complexity: {cx}  Called internally: {fi}×\n"
            f"Code:\n{snippet}"
        )

    prompt = (
        f"You are a test coverage advisor for '{file_name}'.\n"
        f"The following functions have insufficient test coverage. Rank them by testing priority "
        f"(priority 1 = most important to write a test for first).\n\n"
        f"Factors to weigh: cyclomatic complexity, how often the function is called by other code, "
        f"whether it handles user-visible logic, error paths, or side effects.\n\n"
        + "\n\n".join(fn_blocks)
        + "\n\nReturn ONLY a JSON array (no prose). Each item:\n"
        '  {"name": str, "risk": "high"|"medium"|"low", "reason": str (≤15 words why), "priority": int}\n'
        "Order by priority ascending (1 first)."
    )

    try:
        raw = _direct_ai_run(prompt, model=_LLM_MODEL)
        match = re.search(r"\[[\s\S]*\]", raw)
        if match:
            ranked = json.loads(match.group())
            meta_by_name = {m["name"]: m for m in fn_meta}
            clean: list[dict] = []
            for i, item in enumerate(ranked):
                if not isinstance(item, dict) or "name" not in item:
                    continue
                m = meta_by_name.get(item["name"], {})
                clean.append({
                    "name": str(item.get("name", "")),
                    "risk": item.get("risk") if item.get("risk") in ("high", "medium", "low") else "medium",
                    "reason": str(item.get("reason", ""))[:200],
                    "priority": int(item.get("priority", i + 1)),
                    "start_line": m.get("start_line", 0),
                    "end_line": m.get("end_line", 0),
                    "coverage_pct": m.get("coverage_pct", 0),
                    "complexity": m.get("complexity", 1),
                    "fan_in": m.get("fan_in", 0),
                })
            clean.sort(key=lambda x: x["priority"])
            with _debt_cache_lock:
                _debt_cache[cache_key] = (mtime, clean)
            _mcp_cache_write("debt", cache_key, mtime, clean)
            return clean, None
        return [], "Claude returned no parseable JSON array"
    except Exception as exc:
        logger.debug("llm_debt_rank_failed", file=file_name, error=str(exc))
        return [], str(exc)

    return [], "unknown error"


logger = structlog.get_logger()

DEFAULT_PORT = int(os.getenv("MAERIS_MCP_SOURCE_PORT", "41459"))
TEST_FILE_RE = re.compile(r"(?:\.|-)(?:test|spec)\.(?:[cm]?jsx?|tsx?)$")
# Matches .js, .jsx, .ts, .tsx, .mjs, .cjs — all JS/TS source extensions
# the unit-test feature targets.
SOURCE_FILE_RE = re.compile(r"\.(?:[cm]?jsx?|tsx?)$")
# Folders we never descend into. Same list shared with the /folders endpoint.
_SKIP_DIRS = frozenset({
    "node_modules", ".git", ".next", "dist", "build", "coverage", ".cache",
    "__pycache__", ".venv", "venv", ".turbo", "out", ".vercel", ".idea",
    ".vscode", "__mocks__", "__snapshots__", ".pytest_cache",
})
# Hard ceiling — enough for medium-sized repos, not enough to blow up the
# UI or timeout a JSON parse. Larger repos surface a "too many files"
# warning and need scoped browsing.
MAX_FILES = 5000


def _make_handler(repo_root: Path):
    root = repo_root.resolve()

    class Handler(BaseHTTPRequestHandler):
        # Silence the default logger — we're stdio-sensitive.
        def log_message(self, *args, **kwargs):
            pass

        def _cors_headers(self):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")

        def do_OPTIONS(self):
            self.send_response(204)
            self._cors_headers()
            self.end_headers()

        def do_POST(self):
            parsed = urlparse(self.path)
            # POST /framework/setup — writes a jest.config.js template at the
            # project root so the one-click "Create config" button in the
            # SetupWizardBanner can remove the manual copy-paste step.
            if parsed.path == "/framework/setup":
                try:
                    length = int(self.headers.get("Content-Length") or 0)
                    raw = self.rfile.read(length) if length > 0 else b"{}"
                    body = json.loads(raw.decode("utf-8") or "{}")
                except Exception as exc:
                    payload = json.dumps({"ok": False, "error": f"bad body: {exc}"}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return

                filename = (body.get("filename") or "").strip()
                content = body.get("content") or ""
                # Restrict to bare filenames at the project root — no path
                # traversal, no overwriting arbitrary project files.
                if (not filename or "/" in filename or "\\" in filename
                        or filename.startswith(".")
                        or not filename.startswith("jest.config.")):
                    payload = json.dumps({
                        "ok": False,
                        "error": "filename must be a bare jest.config.* at project root",
                    }).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return

                target = root / filename
                if target.exists():
                    payload = json.dumps({
                        "ok": False,
                        "error": f"{filename} already exists — refusing to overwrite",
                    }).encode()
                    self.send_response(409)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return
                try:
                    target.write_text(content, encoding="utf-8")
                except Exception as exc:
                    payload = json.dumps({"ok": False, "error": f"write failed: {exc}"}).encode()
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return

                payload = json.dumps({"ok": True, "path": str(target)}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors_headers(); self.end_headers()
                self.wfile.write(payload); return

            self.send_response(404); self._cors_headers(); self.end_headers()

        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/folders":
                # Enumerate source folders under the repo root so the Maeris UI
                # can show a folder picker before any tests have been registered.
                max_depth = 4
                results = []
                def _walk(dir_path: Path, depth: int):
                    if depth > max_depth or len(results) >= 500:
                        return
                    try:
                        entries = sorted(dir_path.iterdir(), key=lambda p: p.name.lower())
                    except Exception:
                        return
                    for entry in entries:
                        if not entry.is_dir() or entry.name.startswith(".") or entry.name in _SKIP_DIRS:
                            continue
                        try:
                            rel = entry.relative_to(root).as_posix()
                        except Exception:
                            continue
                        results.append(rel)
                        if len(results) >= 500:
                            return
                        _walk(entry, depth + 1)
                _walk(root, 0)
                payload = json.dumps({"root": str(root), "folders": results}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self._cors_headers()
                self.end_headers()
                self.wfile.write(payload); return

            if parsed.path == "/files":
                # CTO request: feed the Maeris UI a VSCode-style file
                # explorer of every JS/TS source file in the repo, paired
                # with its on-disk test file (if any) and a freshness
                # signal (mtime + size — cheap; the backend may join with
                # source_hash from past runs to mark stale tests later).
                # Returns at most MAX_FILES; UI surfaces a notice if hit.
                files = []
                truncated = False
                test_to_source: dict[str, str] = {}
                source_set: set[str] = set()
                def _walk_files(dir_path: Path):
                    nonlocal truncated
                    try:
                        entries = sorted(dir_path.iterdir(), key=lambda p: p.name.lower())
                    except Exception:
                        return
                    for entry in entries:
                        if entry.name.startswith("."):
                            continue
                        if entry.is_dir():
                            if entry.name in _SKIP_DIRS:
                                continue
                            _walk_files(entry)
                            if truncated:
                                return
                            continue
                        if not entry.is_file() or not SOURCE_FILE_RE.search(entry.name):
                            continue
                        try:
                            rel = entry.relative_to(root).as_posix()
                        except Exception:
                            continue
                        is_test = bool(TEST_FILE_RE.search(entry.name))
                        try:
                            stat = entry.stat()
                            mtime = int(stat.st_mtime)
                            size = stat.st_size
                        except Exception:
                            mtime = 0
                            size = 0
                        files.append({
                            "path": rel,
                            "name": entry.name,
                            "is_test": is_test,
                            "size": size,
                            "mtime": mtime,
                        })
                        if is_test:
                            # Map "X.test.js" -> "X.js" (or .ts variants) so
                            # the UI can pair a test with its source row.
                            base = re.sub(
                                r"(?:\.|-)(?:test|spec)\.([cm]?jsx?|tsx?)$",
                                r".\1",
                                rel,
                            )
                            test_to_source[base] = rel
                        else:
                            source_set.add(rel)
                        if len(files) >= MAX_FILES:
                            truncated = True
                            return
                _walk_files(root)
                # Annotate sources with their paired test path (if any).
                for f in files:
                    if not f["is_test"]:
                        f["test_path"] = test_to_source.get(f["path"])
                payload = json.dumps({
                    "root": str(root),
                    "files": files,
                    "truncated": truncated,
                    "max_files": MAX_FILES,
                }).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self._cors_headers()
                self.end_headers()
                self.wfile.write(payload); return
            if parsed.path == "/coverage":
                # Return per-function coverage for a source file.
                # Priority: Istanbul runtime data (coverage-final.json) → static analysis fallback.
                params = parse_qs(parsed.query)
                rel = (params.get("path") or [""])[0].strip().lstrip("/")
                if not rel:
                    self.send_response(400); self._cors_headers(); self.end_headers()
                    self.wfile.write(b'{"error":"path required"}'); return

                # ── Static analysis helpers ──────────────────────────────────
                _EXPORT_RE = [
                    re.compile(r"^export\s+(?:async\s+)?function\s+(\w+)\s*\(", re.MULTILINE),
                    re.compile(r"^export\s+const\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*=>", re.MULTILINE),
                    re.compile(r"^export\s+(?:default\s+)?(?:async\s+)?function\s*(\w*)\s*\(", re.MULTILINE),
                    re.compile(r"^export\s+class\s+(\w+)\b", re.MULTILINE),
                    re.compile(r"^export\s+const\s+(\w+)\s*=", re.MULTILINE),
                ]
                _FN_DECL_RE = re.compile(
                    r"^(?:export\s+)?(?:async\s+)?function\s*\*?\s*(\w+)\s*\(|"
                    r"^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*=>|"
                    r"^(?:export\s+)?class\s+(\w+)\b",
                    re.MULTILINE,
                )
                _IT_RE = re.compile(r'\b(?:it|test)\s*\(\s*[\'"`]([^\'"`]+)[\'"`]', re.MULTILINE)

                def _static_coverage(src_path: Path) -> dict:
                    """Build function list + test coverage from source + test files without running tests."""
                    try:
                        src_text = src_path.read_text(encoding="utf-8", errors="ignore")
                    except Exception:
                        return {"has_data": False, "reason": "could not read source file"}

                    lines = src_text.splitlines()
                    total_lines = len(lines)

                    # Find test file alongside source (foo.test.js / foo.spec.js).
                    stem = src_path.stem
                    test_text = ""
                    for ext in (src_path.suffix, ".js", ".ts", ".jsx", ".tsx"):
                        for suffix in (f".test{ext}", f".spec{ext}"):
                            candidate = src_path.with_name(stem + suffix)
                            if candidate.is_file():
                                try:
                                    test_text = candidate.read_text(encoding="utf-8", errors="ignore")
                                except Exception:
                                    pass
                                break
                        if test_text:
                            break

                    # Collect all it()/test() body text from the test file so we
                    # can check which source names are exercised.
                    test_bodies: list[str] = []
                    if test_text:
                        for m in re.finditer(
                            r'\b(?:it|test)\s*\([^,]+,\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{([\s\S]*?)\}\s*\)',
                            test_text,
                        ):
                            test_bodies.append(m.group(1))
                        # Fallback: use full test file text for name matching.
                        if not test_bodies:
                            test_bodies = [test_text]

                    combined_test_body = "\n".join(test_bodies)

                    # Extract named functions/classes/components from the source.
                    functions = []
                    seen: set[str] = set()
                    for m in _FN_DECL_RE.finditer(src_text):
                        name = m.group(1) or m.group(2) or m.group(3) or ""
                        if not name or name in seen:
                            continue
                        seen.add(name)
                        start_line = src_text[:m.start()].count("\n") + 1
                        # Estimate end line: scan ahead for balanced braces,
                        # skipping characters inside string literals so that
                        # `{`/`}` in strings/template-literals don't corrupt depth.
                        brace_depth = 0
                        end_line = start_line
                        in_fn = False
                        in_str: str | None = None
                        prev_ch = ""
                        for i, ch in enumerate(src_text[m.start():], start=m.start()):
                            if in_str:
                                if ch == in_str and prev_ch != "\\":
                                    in_str = None
                            elif ch in ('"', "'", "`"):
                                in_str = ch
                            elif ch == "{":
                                brace_depth += 1; in_fn = True
                            elif ch == "}":
                                brace_depth -= 1
                                if in_fn and brace_depth <= 0:
                                    end_line = src_text[:i].count("\n") + 1
                                    break
                            prev_ch = ch
                        if end_line == start_line:
                            end_line = min(start_line + 20, total_lines)
                        total_stmts = max(1, end_line - start_line)
                        # Covered = function name appears in test file body.
                        is_covered = bool(test_text) and bool(
                            re.search(rf'\b{re.escape(name)}\b', combined_test_body)
                        )
                        functions.append({
                            "id": name,
                            "name": name,
                            "start_line": start_line,
                            "end_line": end_line,
                            "hit_count": 1 if is_covered else 0,
                            "covered_statements": total_stmts if is_covered else 0,
                            "total_statements": total_stmts,
                            "coverage_pct": 100.0 if is_covered else 0.0,
                            "static": True,
                        })

                    if not functions:
                        return {"has_data": False, "reason": "no named functions found in source file"}

                    covered_count = sum(1 for f in functions if f["coverage_pct"] > 0)
                    overall_pct = round(covered_count / len(functions) * 100, 1) if functions else 0.0
                    total_stmts_all = sum(f["total_statements"] for f in functions)
                    covered_stmts_all = sum(f["covered_statements"] for f in functions)
                    return {
                        "has_data": True,
                        "static": True,
                        "file_path": rel,
                        "overall_pct": overall_pct,
                        "statements": {"total": total_stmts_all, "covered": covered_stmts_all},
                        "functions": sorted(functions, key=lambda f: f["start_line"]),
                    }

                # ── Try Istanbul runtime data first ──────────────────────────
                force_coverage = (params.get("force") or [""])[0] == "1"
                coverage_path = root / "coverage" / "coverage-final.json"

                # Coverage cache is keyed on coverage-final.json mtime so it
                # auto-invalidates whenever a new test run updates that file.
                # force=1 bypasses the cache entirely and re-reads from disk.
                _cov_cache_key = str(coverage_path)
                _cov_mtime_ns: int = 0
                if coverage_path.is_file():
                    try:
                        _cov_mtime_ns = coverage_path.stat().st_mtime_ns
                    except Exception:
                        pass
                    # Incorporate the file path in the cache key to differentiate
                    # per-file entries even though they all share one coverage file.
                    _cov_cache_key = f"{coverage_path}::{rel}"
                    _cached_cov = None if force_coverage else _mcp_cache_read("coverage", _cov_cache_key, _cov_mtime_ns)
                    if _cached_cov is not None:

                        payload = json.dumps(_cached_cov).encode()
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Content-Length", str(len(payload)))
                        self._cors_headers(); self.end_headers()
                        self.wfile.write(payload); return


                # When force=1 (called right after a test run), Jest/Vitest may
                # not have finished writing coverage-final.json yet. Retry up to
                # 3× with a 1s gap before falling back to static analysis so the
                # UI doesn't flash 0% when the file is about to appear.
                _cov_retries = 3 if force_coverage else 1
                file_entry = None
                for _cov_attempt in range(_cov_retries):
                  if coverage_path.is_file():
                    try:
                        coverage_data = json.loads(coverage_path.read_text(encoding="utf-8"))
                        for abs_key in coverage_data:
                            try:
                                candidate_rel = Path(abs_key).relative_to(root).as_posix()
                            except Exception:
                                candidate_rel = abs_key.replace("\\", "/")
                            if candidate_rel == rel or candidate_rel.endswith("/" + rel):
                                file_entry = coverage_data[abs_key]
                                break
                        if file_entry is not None:
                            break
                    except Exception:
                        pass
                  if _cov_attempt < _cov_retries - 1:
                      time.sleep(1.0)
                if not file_entry:
                    # Fall back to static analysis — no test run needed.
                    src_path = (root / rel).resolve()
                    try:
                        src_path.relative_to(root)
                    except Exception:
                        payload = json.dumps({"has_data": False, "reason": "path outside project"}).encode()
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json; charset=utf-8")
                        self.send_header("Content-Length", str(len(payload)))
                        self._cors_headers(); self.end_headers()
                        self.wfile.write(payload); return
                    result = _static_coverage(src_path)
                    payload = json.dumps(result).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(payload)))
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return

                # ── Parse Istanbul runtime data ──────────────────────────────
                # Build per-function coverage from Istanbul fnMap + f hit counts.
                fn_map = file_entry.get("fnMap") or {}
                f_hits = file_entry.get("f") or {}
                stmt_map = file_entry.get("statementMap") or {}
                s_hits = file_entry.get("s") or {}

                # Load source lines for anonymous name resolution.
                _src_lines: list[str] | None = None
                try:
                    src_path = (root / rel).resolve()
                    _src_lines = src_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                except Exception:
                    pass

                _IDENT_RE = re.compile(r"\b(\w+)\s*=?\s*$")

                def _resolve_fn_name(fn_info: dict, fn_id: str) -> str:
                    """Return the real variable name for anonymous arrow functions."""
                    raw = fn_info.get("name") or ""
                    if not re.match(r"^\(anonymous_\d+\)$", raw):
                        return raw or f"(anonymous_{fn_id})"
                    # Istanbul's `decl` points to the `=` of `const Name = () =>`.
                    # Scan back on that line to find the identifier.
                    decl = fn_info.get("decl") or {}
                    decl_line = (decl.get("start") or {}).get("line", 0)   # 1-indexed
                    decl_col  = (decl.get("start") or {}).get("column", 0) # 0-indexed
                    if _src_lines and 1 <= decl_line <= len(_src_lines):
                        snippet = _src_lines[decl_line - 1][:decl_col]
                        m = _IDENT_RE.search(snippet)
                        if m:
                            return m.group(1)
                    return raw or f"(anonymous_{fn_id})"

                functions = []
                for fn_id, fn_info in fn_map.items():
                    hit_count = int(f_hits.get(str(fn_id), 0))
                    loc = fn_info.get("loc") or fn_info.get("decl") or {}
                    start_line = (loc.get("start") or {}).get("line", 0)
                    end_line = (loc.get("end") or {}).get("line", start_line)
                    fn_name = _resolve_fn_name(fn_info, fn_id)
                    # Count statements that fall within this function's line range.
                    total_stmts = covered_stmts = 0
                    for stmt_id, stmt_loc in stmt_map.items():
                        s_start = (stmt_loc.get("start") or {}).get("line", 0)
                        if start_line <= s_start <= end_line:
                            total_stmts += 1
                            if int(s_hits.get(str(stmt_id), 0)) > 0:
                                covered_stmts += 1
                    cov_pct = round((covered_stmts / total_stmts * 100) if total_stmts else (100 if hit_count > 0 else 0), 1)
                    functions.append({
                        "id": str(fn_id),
                        "name": fn_name,
                        "start_line": start_line,
                        "end_line": end_line,
                        "hit_count": hit_count,
                        "covered_statements": covered_stmts,
                        "total_statements": total_stmts,
                        "coverage_pct": cov_pct,
                    })
                # Sort by start line.
                functions.sort(key=lambda f: f["start_line"])

                # ── LLM naming for any still-anonymous functions ─────────────
                # Regex resolution handles `const Name = () =>` but not callbacks,
                # IIFE, map/filter lambdas, etc. Ask Claude for those in one call.
                if _src_lines:
                    still_anon = [f for f in functions if _ANON_RE.match(f["name"])]
                    if still_anon:
                        src_path_for_llm = (root / rel).resolve()
                        llm_names = _llm_name_anonymous(src_path_for_llm, _src_lines, still_anon)
                        for fn in functions:
                            if _ANON_RE.match(fn["name"]) and fn["id"] in llm_names:
                                fn["name"] = llm_names[fn["id"]]

                # Overall statement coverage for this file.
                total_s = len(s_hits)
                covered_s = sum(1 for v in s_hits.values() if int(v) > 0)
                overall_pct = round((covered_s / total_s * 100) if total_s else 0, 1)
                # Include source file mtime so the frontend can skip re-fetching
                # when the file hasn't changed since the last coverage fetch.
                try:
                    src_mtime = int((root / rel).stat().st_mtime)
                except Exception:
                    src_mtime = None

                # ── Line-level hit map ──────────────────────────────────────
                # Keys are string line numbers (JSON requires string keys).
                # Value is the total hit count across all statements on that line.
                line_hits: dict[str, int] = {}
                for stmt_id, stmt_loc in stmt_map.items():
                    s_line = (stmt_loc.get("start") or {}).get("line", 0)
                    if not s_line:
                        continue
                    hits = int(s_hits.get(str(stmt_id), 0))
                    key = str(s_line)
                    line_hits[key] = line_hits.get(key, 0) + hits

                # ── Per-line branch coverage ────────────────────────────────
                branch_map_raw = file_entry.get("branchMap") or {}
                b_hits_raw = file_entry.get("b") or {}
                branch_lines: dict[str, dict] = {}
                for br_id, br_info in branch_map_raw.items():
                    br_loc = br_info.get("loc") or {}
                    br_line = (br_loc.get("start") or {}).get("line", 0)
                    if not br_line:
                        continue
                    counts = b_hits_raw.get(str(br_id)) or []
                    total_br = len(counts)
                    covered_br = sum(1 for c in counts if int(c) > 0)
                    key = str(br_line)
                    if key not in branch_lines:
                        branch_lines[key] = {"total": 0, "covered": 0}
                    branch_lines[key]["total"] += total_br
                    branch_lines[key]["covered"] += covered_br

                result = {
                    "has_data": True,
                    "file_path": rel,
                    "overall_pct": overall_pct,
                    "statements": {"total": total_s, "covered": covered_s},
                    "functions": functions,
                    "source_mtime": src_mtime,
                    "coverage_mtime": _cov_mtime_ns or None,
                    "line_hits": line_hits,
                    "branch_lines": branch_lines,
                    "source_lines": _src_lines or [],
                }
                if _cov_mtime_ns:
                    _mcp_cache_write("coverage", _cov_cache_key, _cov_mtime_ns, result)
                payload = json.dumps(result).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self._cors_headers(); self.end_headers()
                self.wfile.write(payload); return

            if parsed.path == "/coverage/debt":
                params = parse_qs(parsed.query)
                rel = (params.get("path") or [""])[0].strip().lstrip("/")
                force_debt = (params.get("force") or [""])[0] == "1"
                if not rel:
                    payload = json.dumps({"error": "path required"}).encode()
                    self.send_response(400); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                src_path = (root / rel).resolve()
                try:
                    src_path.relative_to(root)
                except Exception:
                    payload = json.dumps({"error": "path outside project"}).encode()
                    self.send_response(403); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                try:
                    src_lines = src_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                except Exception:
                    payload = json.dumps({"error": "could not read source file"}).encode()
                    self.send_response(500); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                # Load Istanbul coverage for this file.
                coverage_path = root / "coverage" / "coverage-final.json"
                file_entry = None
                if coverage_path.is_file():
                    try:
                        cov_data = json.loads(coverage_path.read_text(encoding="utf-8"))
                        for abs_key in cov_data:
                            try:
                                cand = Path(abs_key).relative_to(root).as_posix()
                            except Exception:
                                cand = abs_key.replace("\\", "/")
                            if cand == rel or cand.endswith("/" + rel):
                                file_entry = cov_data[abs_key]
                                break
                    except Exception:
                        pass

                if not file_entry:
                    payload = json.dumps({"error": "no coverage data — run tests with --coverage first", "ranked": []}).encode()
                    self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                # Build per-function coverage (same logic as /coverage).
                fn_map_d = file_entry.get("fnMap") or {}
                f_hits_d = file_entry.get("f") or {}
                stmt_map_d = file_entry.get("statementMap") or {}
                s_hits_d = file_entry.get("s") or {}

                _IDENT_RE = re.compile(
                    r"(?:const|let|var|function)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*(?:=|\()"
                )

                def _resolve_fn_name(raw_name: str, start_line: int) -> str:
                    """Return a meaningful name for anonymous Istanbul functions."""
                    if raw_name:
                        return raw_name
                    # Check the declaration line and the line above it (0-indexed).
                    for ln in (start_line - 1, start_line - 2):
                        if 0 <= ln < len(src_lines):
                            m = _IDENT_RE.search(src_lines[ln])
                            if m:
                                return m.group(1)
                    return f"(anonymous_{fn_id})"

                fns_for_debt = []
                for fn_id, fn_info in fn_map_d.items():
                    hit_count = int(f_hits_d.get(str(fn_id), 0))
                    loc = fn_info.get("loc") or fn_info.get("decl") or {}
                    s_line = (loc.get("start") or {}).get("line", 0)
                    e_line = (loc.get("end") or {}).get("line", s_line)
                    fn_name = _resolve_fn_name(fn_info.get("name", ""), s_line)
                    total_st = covered_st = 0
                    for sid, sloc in stmt_map_d.items():
                        sl = (sloc.get("start") or {}).get("line", 0)
                        if s_line <= sl <= e_line:
                            total_st += 1
                            if int(s_hits_d.get(str(sid), 0)) > 0:
                                covered_st += 1
                    cov_pct = round((covered_st / total_st * 100) if total_st else (100.0 if hit_count > 0 else 0.0), 1)
                    if cov_pct < 100:
                        fns_for_debt.append({"id": str(fn_id), "name": fn_name, "start_line": s_line, "end_line": e_line, "hit_count": hit_count, "coverage_pct": cov_pct})

                try:
                    debt_src_mtime = int(src_path.stat().st_mtime_ns)
                except Exception:
                    debt_src_mtime = None

                ranked, llm_err = _llm_debt_rank(src_path, src_lines, fns_for_debt, force=force_debt)
                resp: dict = {"ranked": ranked, "total_uncovered": len(fns_for_debt), "source_mtime": debt_src_mtime}
                if llm_err:
                    resp["llm_error"] = llm_err
                payload = json.dumps(resp).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(payload))); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

            if parsed.path == "/coverage/explain":
                params = parse_qs(parsed.query)
                rel = (params.get("path") or [""])[0].strip().lstrip("/")
                force_explain = (params.get("force") or [""])[0] == "1"
                if not rel:
                    payload = json.dumps({"error": "path required"}).encode()
                    self.send_response(400); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                src_path = (root / rel).resolve()
                try:
                    src_path.relative_to(root)
                except Exception:
                    payload = json.dumps({"error": "path outside project"}).encode()
                    self.send_response(403); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                try:
                    src_lines = src_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                except Exception:
                    payload = json.dumps({"error": "could not read source file"}).encode()
                    self.send_response(500); self.send_header("Content-Type", "application/json"); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

                coverage_path = root / "coverage" / "coverage-final.json"
                file_entry = None
                if coverage_path.is_file():
                    try:
                        cov_data = json.loads(coverage_path.read_text(encoding="utf-8"))
                        for abs_key in cov_data:
                            try:
                                cand = Path(abs_key).relative_to(root).as_posix()
                            except Exception:
                                cand = abs_key.replace("\\", "/")
                            if cand == rel or cand.endswith("/" + rel):
                                file_entry = cov_data[abs_key]
                                break
                    except Exception:
                        pass

                fn_map_d = (file_entry or {}).get("fnMap") or {}

                _IDENT_RE_EX = re.compile(r"(?:const|let|var|function)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*(?:=|\()")

                fns_for_explain = []
                for fn_id, fn_info in fn_map_d.items():
                    loc = fn_info.get("loc") or fn_info.get("decl") or {}
                    s_line = (loc.get("start") or {}).get("line", 0)
                    e_line = (loc.get("end") or {}).get("line", s_line)
                    if not s_line or e_line - s_line < 2:
                        continue  # skip trivial one-liners
                    raw_name = fn_info.get("name", "")
                    if not raw_name:
                        for ln in (s_line - 1, s_line - 2):
                            if 0 <= ln < len(src_lines):
                                m = _IDENT_RE_EX.search(src_lines[ln])
                                if m:
                                    raw_name = m.group(1)
                                    break
                    fn_name = raw_name or f"(anonymous_{fn_id})"
                    fns_for_explain.append({"id": str(fn_id), "name": fn_name, "start_line": s_line, "end_line": e_line})

                explanations, llm_err = _llm_explain_functions(src_path, src_lines, fns_for_explain, force=force_explain)
                resp = {"explanations": explanations}
                if llm_err:
                    resp["llm_error"] = llm_err
                payload = json.dumps(resp).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(payload))); self._cors_headers(); self.end_headers(); self.wfile.write(payload); return

            if parsed.path == "/flowchart":
                # Return a React-Flow-compatible graph describing the component's
                # internal structure: states, handlers, effects, data functions,
                # and edges connecting them.  Coverage data is overlaid from
                # Istanbul (or degraded to static analysis).
                params = parse_qs(parsed.query)
                rel = (params.get("path") or [""])[0].strip().lstrip("/")
                if not rel:
                    payload = json.dumps({"error": "path required"}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                src_path = (root / rel).resolve()
                try:
                    src_path.relative_to(root)
                except Exception:
                    payload = json.dumps({"error": "path outside project"}).encode()
                    self.send_response(403)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                if not src_path.is_file():
                    payload = json.dumps({"error": "file not found"}).encode()
                    self.send_response(404)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                # ── Check mtime cache ──────────────────────────────────────
                force_refresh = (params.get("force") or [""])[0] == "1"
                try:
                    src_mtime_ns = src_path.stat().st_mtime_ns
                except Exception:
                    src_mtime_ns = 0
                cached_flow = None if force_refresh else _mcp_cache_read("flowchart", str(src_path), src_mtime_ns)
                if cached_flow is not None:
                    payload = json.dumps(cached_flow).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(payload)))
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                try:
                    src_text = src_path.read_text(encoding="utf-8", errors="ignore")
                except Exception as exc:
                    payload = json.dumps({"error": f"could not read source: {exc}"}).encode()
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                src_lines = src_text.splitlines()
                _is_test_file = bool(re.search(r"\.(test|spec)\.[jt]sx?$", src_path.name))

                # ── Load Istanbul coverage for this file (optional) ────────
                cov_fn_map: dict[str, dict] = {}   # fn_name → coverage dict
                cov_line_hits: dict[str, int] = {}  # str(line) → hit count
                cov_overall_pct: float = 0.0

                coverage_path = root / "coverage" / "coverage-final.json"
                if coverage_path.is_file():
                    try:
                        cov_data = json.loads(coverage_path.read_text(encoding="utf-8"))
                        for abs_key, entry in cov_data.items():
                            try:
                                cand_rel = Path(abs_key).relative_to(root).as_posix()
                            except Exception:
                                cand_rel = abs_key.replace("\\", "/")
                            if cand_rel == rel or cand_rel.endswith("/" + rel):
                                # Build fn coverage map
                                fn_map_c = entry.get("fnMap") or {}
                                f_hits_c = entry.get("f") or {}
                                stmt_map_c = entry.get("statementMap") or {}
                                s_hits_c = entry.get("s") or {}

                                # Line hits
                                for sid, sloc in stmt_map_c.items():
                                    s_line = (sloc.get("start") or {}).get("line", 0)
                                    if s_line:
                                        hits = int(s_hits_c.get(str(sid), 0))
                                        key = str(s_line)
                                        cov_line_hits[key] = cov_line_hits.get(key, 0) + hits

                                # Per-function coverage (keyed by fn name)
                                _IDENT_RE2 = re.compile(r"\b(\w+)\s*=?\s*$")
                                for fn_id, fn_info in fn_map_c.items():
                                    hit_count = int(f_hits_c.get(str(fn_id), 0))
                                    loc = fn_info.get("loc") or fn_info.get("decl") or {}
                                    s_l = (loc.get("start") or {}).get("line", 0)
                                    e_l = (loc.get("end") or {}).get("line", s_l)
                                    raw_name = fn_info.get("name") or ""
                                    if re.match(r"^\(anonymous_\d+\)$", raw_name) and 1 <= s_l <= len(src_lines):
                                        snippet = src_lines[s_l - 1][:((loc.get("start") or {}).get("column", 80))]
                                        m2 = _IDENT_RE2.search(snippet)
                                        if m2:
                                            raw_name = m2.group(1)
                                    tot_st = cov_st = 0
                                    for sid2, sloc2 in stmt_map_c.items():
                                        sl2 = (sloc2.get("start") or {}).get("line", 0)
                                        if s_l <= sl2 <= e_l:
                                            tot_st += 1
                                            if int(s_hits_c.get(str(sid2), 0)) > 0:
                                                cov_st += 1
                                    pct = round((cov_st / tot_st * 100) if tot_st else (100.0 if hit_count > 0 else 0.0), 1)
                                    cov_fn_map[raw_name] = {
                                        "start_line": s_l,
                                        "end_line": e_l,
                                        "hit_count": hit_count,
                                        "covered_statements": cov_st,
                                        "total_statements": tot_st,
                                        "coverage_pct": pct,
                                    }

                                tot_s = len(s_hits_c)
                                cov_s = sum(1 for v in s_hits_c.values() if int(v) > 0)
                                cov_overall_pct = round((cov_s / tot_s * 100) if tot_s else 0.0, 1)
                                break
                    except Exception:
                        pass

                # ── LLM flowchart generation ───────────────────────────────
                _llm_flow_result = None
                _llm_error_msg = None
                try:
                    from maeris_mcp.ai_adapter.repair_suggestions import _claude_run

                    # Send numbered source so the LLM can report exact line numbers.
                    # Single-shot up to 600 lines; batch beyond that (rare for components).
                    _SINGLE_SHOT_LIMIT = 600
                    _CHUNK = 200
                    _OVERLAP = 30

                    _numbered_lines = [f"{i + 1}: {l}" for i, l in enumerate(src_lines)]
                    _total_lines = len(src_lines)

                    def _extract_json_obj(raw: str):
                        _s = raw.find("{")
                        if _s == -1:
                            return None
                        _d = 0
                        for _xi, _xc in enumerate(raw[_s:], start=_s):
                            if _xc == "{": _d += 1
                            elif _xc == "}":
                                _d -= 1
                                if _d == 0:
                                    try:
                                        return json.loads(raw[_s:_xi + 1])
                                    except Exception:
                                        return None
                        return None

                    _FC_SCHEMA = (
                        '{"component_name":"Name","nodes":['
                        '{"id":"start","type":"start","label":"Start","start_line":1,"end_line":1},'
                        '{"id":"n_init","type":"state_init","label":"Initial state (useState)","subtitle":"var1=false\\nvar2=[]","start_line":3,"end_line":6},'
                        '{"id":"n1","type":"process","label":"Human readable step","subtitle":"Technical detail","fn_name":"enclosingFunctionName","start_line":10,"end_line":18},'
                        '{"id":"n2","type":"decision","label":"condition = true?","fn_name":"enclosingFunctionName","start_line":20,"end_line":20},'
                        '{"id":"n3","type":"api_call","label":"POST /api/endpoint","subtitle":"await axios.post(...)","fn_name":"submitHandler","start_line":25,"end_line":30},'
                        '{"id":"end1","type":"end","label":"Outcome description","start_line":35,"end_line":35}'
                        '],"edges":['
                        '{"id":"e1","source":"start","target":"n_init"},'
                        '{"id":"e2","source":"n2","target":"n3","label":"Yes"},'
                        '{"id":"e3","source":"n2","target":"end1","label":"No"}'
                        "]}"
                    )
                    _FC_RULES = (
                        "Rules:\n"
                        "- 8-20 nodes total\n"
                        "- start_line/end_line = exact line numbers from the numbered source above\n"
                        "- label: human-readable (e.g. 'User selects category', not 'handleCategorySelect')\n"
                        "- fn_name: enclosing JS function name; for guard clauses, early returns, and "
                        "inline conditions use the surrounding function's name\n"
                        "- every decision node must have exactly 2 outgoing edges each with a label\n"
                        "- include all major branches, conditional renders, and API calls\n"
                        "- valid DAG, no cycles"
                    )

                    if _total_lines <= _SINGLE_SHOT_LIMIT:
                        _src_block = "\n".join(_numbered_lines)
                        _fc_prompt = (
                            f"Analyze this React component and generate a user interaction flowchart.\n\n"
                            f"Component: {src_path.name}\nSource (all {_total_lines} lines):\n```\n{_src_block}\n```\n\n"
                            f"Return ONLY valid JSON — no markdown fences, no prose:\n{_FC_SCHEMA}\n\n{_FC_RULES}"
                        )
                        _raw = _claude_run(_fc_prompt, model=_LLM_MODEL, timeout=120)
                        _llm_flow = _extract_json_obj(_raw)
                        if not (_llm_flow and isinstance(_llm_flow.get("nodes"), list) and len(_llm_flow["nodes"]) >= 2):
                            _llm_error_msg = "AI returned an empty or malformed graph"
                    else:
                        # File exceeds single-shot limit — process in overlapping batches.
                        # Each batch extends the previous flowchart with new nodes only.
                        _chunks = []
                        _pos = 0
                        while _pos < _total_lines:
                            _cend = min(_pos + _CHUNK, _total_lines)
                            _chunks.append((_pos, _cend))
                            if _cend == _total_lines:
                                break
                            _pos = _cend - _OVERLAP

                        _llm_flow = None
                        for _bi, (_bs, _be) in enumerate(_chunks):
                            _chunk_src = "\n".join(_numbered_lines[_bs:_be])
                            _lr = f"lines {_bs + 1}–{_be} of {_total_lines}"
                            if _bi == 0:
                                _fc_prompt = (
                                    f"Analyze this React component and generate a user interaction flowchart.\n\n"
                                    f"Component: {src_path.name}\nSource ({_lr}):\n```\n{_chunk_src}\n```\n\n"
                                    f"Return ONLY valid JSON — no markdown fences, no prose:\n{_FC_SCHEMA}\n\n{_FC_RULES}"
                                )
                            else:
                                _fc_prompt = (
                                    f"You are extending a flowchart for {src_path.name}.\n\n"
                                    f"Existing flowchart:\n{json.dumps(_llm_flow)}\n\n"
                                    f"Additional source ({_lr}):\n```\n{_chunk_src}\n```\n\n"
                                    "Return the COMPLETE updated flowchart JSON (all existing nodes + new nodes "
                                    "for logic in the new code not yet covered). "
                                    "Preserve all existing node ids and edges unchanged. "
                                    "start_line/end_line must be exact line numbers from the source above. "
                                    "fn_name must be the enclosing JS function name. "
                                    "Return ONLY valid JSON — no prose, no markdown fences."
                                )
                            _raw = _claude_run(_fc_prompt, model=_LLM_MODEL, timeout=120)
                            _parsed = _extract_json_obj(_raw)
                            if _parsed and isinstance(_parsed.get("nodes"), list) and len(_parsed["nodes"]) >= 2:
                                _llm_flow = _parsed
                            elif _bi == 0:
                                _llm_error_msg = "AI returned empty or malformed graph on first batch"
                                break
                            # On continuation failures keep the last good result

                        if not _llm_flow:
                            _llm_error_msg = _llm_error_msg or "AI returned an empty or malformed graph"

                    if _llm_flow and isinstance(_llm_flow.get("nodes"), list) and len(_llm_flow["nodes"]) >= 2:
                        # Patch Istanbul coverage percentages onto nodes whose fn_name matches.
                        # Line ranges come from the LLM directly — Istanbul is coverage-only here.
                        for _nd in _llm_flow["nodes"]:
                            _fn = (_nd.get("fn_name") or "").strip()
                            if _fn and _fn in cov_fn_map:
                                _cov = cov_fn_map[_fn]
                                _nd["coverage_pct"] = _cov.get("coverage_pct", 0)
                                _nd["covered_statements"] = _cov.get("covered_statements", 0)
                                _nd["total_statements"] = _cov.get("total_statements", 0)

                        _out_edges = _llm_flow["edges"]
                        if _is_test_file:
                            # Remove any edge that crosses between sub-graphs.
                            # Each node carries fn_name identifying which function
                            # it belongs to. An edge is cross-graph if its source
                            # and target have different (non-empty) fn_names.
                            _node_fn = {
                                _nd2["id"]: (_nd2.get("fn_name") or "").strip()
                                for _nd2 in _llm_flow["nodes"]
                            }
                            _out_edges = [
                                _e for _e in _out_edges
                                if not (
                                    _node_fn.get(_e["source"])
                                    and _node_fn.get(_e["target"])
                                    and _node_fn[_e["source"]] != _node_fn[_e["target"]]
                                )
                            ]
                        _llm_flow_result = {
                            "component_name": _llm_flow.get("component_name", src_path.stem),
                            "file_path": rel,
                            "overall_pct": cov_overall_pct,
                            "has_istanbul": bool(cov_fn_map),
                            "is_llm_flowchart": True,
                            "nodes": _llm_flow["nodes"],
                            "edges": _out_edges,
                        }
                except ImportError:
                    _llm_error_msg = "AI adapter not available — check maeris installation"
                except Exception as _llm_exc:
                    _llm_error_msg = str(_llm_exc) or "unknown AI error"
                    logger.debug("llm_flowchart_failed", error=_llm_error_msg)

                if _llm_flow_result is not None:
                    _mcp_cache_write("flowchart", str(src_path), src_mtime_ns, _llm_flow_result)
                    payload = json.dumps(_llm_flow_result).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(payload)))
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                # When the user explicitly requested a refresh (force=1), return
                # a 500 with the AI error so the browser surfaces it clearly.
                # On a normal (non-forced) first load, fall through to static analysis.
                if force_refresh and _llm_error_msg:
                    payload = json.dumps({"error": _llm_error_msg}).encode()
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(payload)))
                    self._cors_headers()
                    self.end_headers()
                    self.wfile.write(payload)
                    return

                # ── Regexes for JSX/JS/TS component parsing ────────────────
                _COMP_RE = re.compile(
                    r"^(?:export\s+default\s+|export\s+)?(?:async\s+)?function\s+([A-Z]\w*)\s*\(",
                    re.MULTILINE,
                )
                _STATE_RE = re.compile(
                    r"const\s+\[\s*(\w+)\s*,\s*set\w+\s*\]\s*=\s*use(?:State|Reducer)\s*\(([^;]*?)\)",
                    re.MULTILINE | re.DOTALL,
                )
                _EFFECT_RE = re.compile(r"\buseEffect\s*\(", re.MULTILINE)
                _HANDLER_RE = re.compile(
                    r"(?:const|function|let|var)\s+(handle\w+|on[A-Z]\w*)\s*[=\(]",
                    re.MULTILINE,
                )
                _DATA_FN_RE = re.compile(
                    r"(?:const|function|async function|let|var)\s+((?:fetch|load|save|submit|upload|send|post|put|patch|delete|request|call|query|mutate|sync)\w*)\s*[=\(]",
                    re.MULTILINE | re.IGNORECASE,
                )
                _SETTER_CALL_RE = re.compile(r"\bset([A-Z]\w*)\s*[\(\[]")
                _STATE_READ_RE = re.compile(r"\b(\w+)\b")

                # ── Extract main component name ────────────────────────────
                comp_name = ""
                comp_start = 1
                comp_end = len(src_lines)
                for m in _COMP_RE.finditer(src_text):
                    comp_name = m.group(1)
                    comp_start = src_text[:m.start()].count("\n") + 1
                    # Find end via brace depth
                    brace = 0
                    in_fn = False
                    for i, ch in enumerate(src_text[m.start():], start=m.start()):
                        if ch == "{":
                            brace += 1; in_fn = True
                        elif ch == "}":
                            brace -= 1
                            if in_fn and brace <= 0:
                                comp_end = src_text[:i].count("\n") + 1
                                break
                    break  # First exported component is the target

                if not comp_name:
                    comp_name = src_path.stem

                # Coverage for the component as a whole
                comp_cov = cov_fn_map.get(comp_name, {})
                comp_cov_pct = comp_cov.get("coverage_pct", cov_overall_pct)

                # ── Extract state variables ────────────────────────────────
                state_nodes: list[dict] = []
                seen_state_names: set[str] = set()
                for m in _STATE_RE.finditer(src_text):
                    var_name = m.group(1)
                    if var_name in seen_state_names:
                        continue
                    seen_state_names.add(var_name)
                    line = src_text[:m.start()].count("\n") + 1
                    initial_raw = (m.group(2) or "").strip().split(",")[0].strip()[:40]
                    line_hit = cov_line_hits.get(str(line), None)
                    cov_pct = 0.0
                    if line_hit is not None:
                        cov_pct = 100.0 if line_hit > 0 else 0.0
                    elif cov_overall_pct > 0:
                        cov_pct = cov_overall_pct
                    state_nodes.append({
                        "id": f"n_state_{var_name}",
                        "node_type": "state",
                        "label": var_name,
                        "setter": f"set{var_name[0].upper()}{var_name[1:]}",
                        "initial_value": initial_raw,
                        "line": line,
                        "coverage_pct": cov_pct,
                    })

                # ── Extract event handlers ─────────────────────────────────
                handler_nodes: list[dict] = []
                seen_handlers: set[str] = set()
                for m in _HANDLER_RE.finditer(src_text):
                    fn_name = m.group(1)
                    if fn_name in seen_handlers:
                        continue
                    seen_handlers.add(fn_name)
                    fn_start = src_text[:m.start()].count("\n") + 1
                    # Find body range via brace depth
                    fn_end = fn_start
                    brace = 0
                    in_fn = False
                    for i, ch in enumerate(src_text[m.start():], start=m.start()):
                        if ch == "{":
                            brace += 1; in_fn = True
                        elif ch == "}":
                            brace -= 1
                            if in_fn and brace <= 0:
                                fn_end = src_text[:i].count("\n") + 1
                                break
                    fn_cov = cov_fn_map.get(fn_name, {})
                    cov_pct = fn_cov.get("coverage_pct", 0.0)
                    covered_st = fn_cov.get("covered_statements", 0)
                    total_st = fn_cov.get("total_statements", max(1, fn_end - fn_start))
                    # Find which state setters this handler calls
                    fn_body_start = src_text.find("{", m.start())
                    fn_body = src_text[fn_body_start: fn_body_start + 3000] if fn_body_start != -1 else ""
                    updates_states = sorted({
                        s[0].lower() + s[1:] for s in _SETTER_CALL_RE.findall(fn_body)
                        if (s[0].lower() + s[1:]) in seen_state_names
                    })
                    handler_nodes.append({
                        "id": f"n_handler_{fn_name}",
                        "node_type": "handler",
                        "label": fn_name,
                        "start_line": fn_start,
                        "end_line": fn_end,
                        "coverage_pct": cov_pct,
                        "covered_statements": covered_st,
                        "total_statements": total_st,
                        "updates_states": updates_states,
                    })

                # ── Extract data functions ─────────────────────────────────
                data_nodes: list[dict] = []
                seen_data_fns: set[str] = set()
                for m in _DATA_FN_RE.finditer(src_text):
                    fn_name = m.group(1)
                    if fn_name in seen_data_fns or fn_name in seen_handlers:
                        continue
                    seen_data_fns.add(fn_name)
                    fn_start = src_text[:m.start()].count("\n") + 1
                    fn_end = fn_start
                    brace = 0
                    in_fn = False
                    for i, ch in enumerate(src_text[m.start():], start=m.start()):
                        if ch == "{":
                            brace += 1; in_fn = True
                        elif ch == "}":
                            brace -= 1
                            if in_fn and brace <= 0:
                                fn_end = src_text[:i].count("\n") + 1
                                break
                    fn_cov = cov_fn_map.get(fn_name, {})
                    cov_pct = fn_cov.get("coverage_pct", 0.0)
                    data_nodes.append({
                        "id": f"n_data_{fn_name}",
                        "node_type": "data",
                        "label": fn_name,
                        "start_line": fn_start,
                        "end_line": fn_end,
                        "coverage_pct": cov_pct,
                        "covered_statements": fn_cov.get("covered_statements", 0),
                        "total_statements": fn_cov.get("total_statements", max(1, fn_end - fn_start)),
                    })

                # ── Extract useEffect hooks ────────────────────────────────
                effect_nodes: list[dict] = []
                for idx, m in enumerate(_EFFECT_RE.finditer(src_text)):
                    line = src_text[:m.start()].count("\n") + 1
                    # Extract dependency array (rough: find [...] after the effect body)
                    effect_start = m.start()
                    fn_end = line
                    brace = 0
                    in_fn = False
                    for i, ch in enumerate(src_text[effect_start:], start=effect_start):
                        if ch == "{":
                            brace += 1; in_fn = True
                        elif ch == "}":
                            brace -= 1
                            if in_fn and brace <= 0:
                                fn_end = src_text[:i].count("\n") + 1
                                break
                    # Find dep array
                    after_body = src_text[effect_start: effect_start + 2000]
                    dep_m = re.search(r"\[\s*([^\]]*)\](?:\s*\))", after_body)
                    deps_raw = dep_m.group(1).strip() if dep_m else ""
                    deps = [d.strip() for d in deps_raw.split(",") if d.strip()] if deps_raw else []
                    label = f"effect #{idx + 1}"
                    if deps:
                        dep_str = ", ".join(deps[:3])
                        if len(deps) > 3:
                            dep_str += f" +{len(deps) - 3}"
                        label = f"effect [{dep_str}]"
                    elif not deps_raw and dep_m is None:
                        label = f"effect (on mount)"
                    line_hit = cov_line_hits.get(str(line), None)
                    cov_pct = 0.0
                    if line_hit is not None:
                        cov_pct = 100.0 if line_hit > 0 else 0.0
                    effect_nodes.append({
                        "id": f"n_effect_{idx}",
                        "node_type": "effect",
                        "label": label,
                        "line": line,
                        "end_line": fn_end,
                        "deps": deps,
                        "coverage_pct": cov_pct,
                    })

                # ── Build component node ────────────────────────────────────
                component_node = {
                    "id": "n_component",
                    "node_type": "component",
                    "label": comp_name,
                    "start_line": comp_start,
                    "end_line": comp_end,
                    "coverage_pct": comp_cov_pct,
                    "covered_statements": comp_cov.get("covered_statements", 0),
                    "total_statements": comp_cov.get("total_statements", 0),
                    "description": "Entry point",
                }

                # ── Assemble all nodes ─────────────────────────────────────
                all_nodes = [component_node] + state_nodes + handler_nodes + data_nodes + effect_nodes

                # ── Build edges ────────────────────────────────────────────
                edges: list[dict] = []

                # Component → each state (component initialises state)
                for sn in state_nodes:
                    edges.append({
                        "id": f"e_comp_{sn['id']}",
                        "source": "n_component",
                        "target": sn["id"],
                        "label": "declares",
                    })

                # Handler → states it updates
                for hn in handler_nodes:
                    for state_name in hn.get("updates_states", []):
                        state_id = f"n_state_{state_name}"
                        if any(sn["id"] == state_id for sn in state_nodes):
                            edges.append({
                                "id": f"e_{hn['id']}_{state_id}",
                                "source": hn["id"],
                                "target": state_id,
                                "label": "updates",
                            })
                    # If a handler calls a data function, connect them
                    fn_body_start_pos = src_text.find("{", src_text.find(hn["label"]))
                    fn_body_snippet = src_text[fn_body_start_pos: fn_body_start_pos + 3000] if fn_body_start_pos != -1 else ""
                    for dn in data_nodes:
                        if re.search(r"\b" + re.escape(dn["label"]) + r"\s*\(", fn_body_snippet):
                            edges.append({
                                "id": f"e_{hn['id']}_{dn['id']}",
                                "source": hn["id"],
                                "target": dn["id"],
                                "label": "calls",
                            })

                # Effect → states it depends on
                for en in effect_nodes:
                    for dep in en.get("deps", []):
                        state_id = f"n_state_{dep}"
                        if any(sn["id"] == state_id for sn in state_nodes):
                            edges.append({
                                "id": f"e_{en['id']}_{state_id}",
                                "source": state_id,
                                "target": en["id"],
                                "label": "triggers",
                            })

                # Data fn → states it updates
                for dn in data_nodes:
                    fn_body_start_pos = src_text.find("{", src_text.find(dn["label"]))
                    fn_body_snippet = src_text[fn_body_start_pos: fn_body_start_pos + 3000] if fn_body_start_pos != -1 else ""
                    for state_name in {s[0].lower() + s[1:] for s in _SETTER_CALL_RE.findall(fn_body_snippet) if (s[0].lower() + s[1:]) in seen_state_names}:
                        state_id = f"n_state_{state_name}"
                        edges.append({
                            "id": f"e_{dn['id']}_{state_id}",
                            "source": dn["id"],
                            "target": state_id,
                            "label": "updates",
                        })

                result = {
                    "component_name": comp_name,
                    "file_path": rel,
                    "overall_pct": cov_overall_pct,
                    "has_istanbul": bool(cov_fn_map),
                    "nodes": all_nodes,
                    "edges": edges,
                }
                _mcp_cache_write("flowchart", str(src_path), src_mtime_ns, result)
                payload = json.dumps(result).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self._cors_headers()
                self.end_headers()
                self.wfile.write(payload)
                return

            if parsed.path == "/framework":
                # Return the detected test framework + installation status so the
                # Maeris UI can guide new users through first-time setup without
                # leaving them stuck at "no framework detected".
                _FW_SIGNALS = {
                    "jest": ["jest"],
                    "vitest": ["vitest"],
                    "mocha": ["mocha"],
                    "jasmine": ["jasmine", "jasmine-core"],
                }

                def _build_install_cmd(fw: str, is_ts: bool, is_react: bool, is_next: bool, is_vite: bool) -> str:
                    """Return a precise install command for the exact project stack."""
                    pkgs: list[str] = []
                    if fw == "jest":
                        pkgs.append("jest")
                        if is_react or is_next:
                            pkgs += ["jest-environment-jsdom", "@testing-library/react", "@testing-library/jest-dom"]
                        if is_ts:
                            if is_next:
                                # Next.js handles TS transforms itself — only types needed
                                pkgs.append("@types/jest")
                            else:
                                pkgs += ["ts-jest", "@types/jest"]
                        elif not is_next and is_react:
                            # Plain JS + React needs Babel transform
                            pkgs += ["babel-jest", "@babel/core", "@babel/preset-env", "@babel/preset-react"]
                    elif fw == "vitest":
                        pkgs.append("vitest")
                        if is_react:
                            pkgs += ["jsdom", "@testing-library/react", "@testing-library/user-event"]
                        elif not is_vite:
                            pkgs.append("jsdom")
                        # Vitest handles TS natively via Vite — no extra packages
                    elif fw == "mocha":
                        pkgs += ["mocha", "chai"]
                        if is_ts:
                            pkgs += ["@types/mocha", "ts-node"]
                    elif fw == "jasmine":
                        pkgs.append("jasmine")
                        if is_ts:
                            pkgs += ["@types/jasmine", "ts-node"]
                    else:
                        pkgs.append(fw)
                    return "npm install --save-dev " + " ".join(pkgs)

                fw_result: dict = {
                    "framework": None,
                    "language": "javascript",
                    "stack": [],
                    "installed": False,
                    "missing_packages": [],
                    "install_hint": None,
                    "has_package_json": False,
                }
                pkg_path = root / "package.json"
                if pkg_path.exists():
                    fw_result["has_package_json"] = True
                    try:
                        pkg_data = json.loads(pkg_path.read_text(encoding="utf-8"))
                        all_deps: dict = {}
                        all_deps.update(pkg_data.get("dependencies") or {})
                        all_deps.update(pkg_data.get("devDependencies") or {})

                        is_ts = (root / "tsconfig.json").exists() or "typescript" in all_deps
                        is_next = "next" in all_deps
                        is_vite = "vite" in all_deps
                        is_react = "react" in all_deps

                        fw_result["language"] = "typescript" if is_ts else "javascript"
                        stack = []
                        if is_next: stack.append("nextjs")
                        if is_vite: stack.append("vite")
                        if is_react: stack.append("react")
                        if is_ts: stack.append("typescript")
                        fw_result["stack"] = stack

                        # Check scripts.test first (explicit developer intent),
                        # then fall back to devDependencies — mirrors detect_framework().
                        test_script = (pkg_data.get("scripts") or {}).get("test", "")
                        script_fw = None
                        for fw_name in _FW_SIGNALS:
                            if re.search(rf"\b{fw_name}\b", test_script):
                                script_fw = fw_name
                                break

                        # Build ordered candidate list: script-detected first, then deps.
                        _candidates = []
                        if script_fw:
                            _candidates.append(script_fw)
                        for fw_name in _FW_SIGNALS:
                            if fw_name != script_fw and any(s in all_deps for s in _FW_SIGNALS[fw_name]):
                                _candidates.append(fw_name)

                        for fw_name in _candidates:
                            signals = _FW_SIGNALS[fw_name]
                            fw_result["framework"] = fw_name
                            primary = signals[0]
                            installed = (root / "node_modules" / primary).exists()
                            fw_result["installed"] = installed
                            if not installed:
                                fw_result["missing_packages"] = signals
                                fw_result["install_hint"] = _build_install_cmd(fw_name, is_ts, is_react, is_next, is_vite)
                            break

                        if not fw_result["framework"]:
                            # Nothing configured — suggest jest (or vitest for Vite projects)
                            suggested = "vitest" if is_vite else "jest"
                            fw_result["suggested_framework"] = suggested
                            fw_result["install_hint"] = _build_install_cmd(suggested, is_ts, is_react, is_next, is_vite)

                        # ── Config detection ─────────────────────────────
                        # Having Jest installed isn't enough: a Next.js / React
                        # project also needs a jest.config.* that knows about
                        # next/jest + CSS module mocking. Without it, every
                        # generated test dies with "suite failed to run"
                        # because the source imports .scss / uses JSX / uses
                        # path aliases. Surface this as a concrete gap so the
                        # SetupWizard can offer a fix.
                        fw_name_effective = fw_result["framework"] or fw_result.get("suggested_framework")
                        if fw_name_effective == "jest" and (is_react or is_next):
                            config_files = [
                                "jest.config.js", "jest.config.ts", "jest.config.mjs",
                                "jest.config.cjs", "jest.config.json",
                            ]
                            has_config_file = any((root / f).exists() for f in config_files)
                            has_config_in_pkg = bool(pkg_data.get("jest"))
                            config_present = has_config_file or has_config_in_pkg
                            config_issues: list[str] = []
                            if not config_present:
                                config_issues.append("missing_jest_config")
                            # Needed for CSS Modules in Next.js / React projects.
                            if "identity-obj-proxy" not in all_deps:
                                config_issues.append("missing_css_mock_package")
                            fw_result["config_present"] = config_present
                            fw_result["config_issues"] = config_issues
                            # Template we can auto-write. Uses next/jest for
                            # Next.js projects (handles SWC / path aliases /
                            # asset imports) or a plain jsdom config for
                            # non-Next React.
                            if config_issues:
                                if is_next:
                                    fw_result["config_template"] = {
                                        "filename": "jest.config.js",
                                        "content": (
                                            "const nextJest = require('next/jest');\n"
                                            "const createJestConfig = nextJest({ dir: './' });\n"
                                            "module.exports = createJestConfig({\n"
                                            "  testEnvironment: 'jsdom',\n"
                                            "  moduleNameMapper: {\n"
                                            "    '^@/(.*)$': '<rootDir>/$1',\n"
                                            "    '\\\\.(scss|sass|css)$': 'identity-obj-proxy',\n"
                                            "  },\n"
                                            "  setupFilesAfterEnv: ['@testing-library/jest-dom'],\n"
                                            "});\n"
                                        ),
                                    }
                                else:
                                    fw_result["config_template"] = {
                                        "filename": "jest.config.js",
                                        "content": (
                                            "module.exports = {\n"
                                            "  testEnvironment: 'jsdom',\n"
                                            "  moduleNameMapper: {\n"
                                            "    '^@/(.*)$': '<rootDir>/$1',\n"
                                            "    '\\\\.(scss|sass|css)$': 'identity-obj-proxy',\n"
                                            "  },\n"
                                            "  transform: {\n"
                                            "    '^.+\\\\.(js|jsx|ts|tsx)$': 'babel-jest',\n"
                                            "  },\n"
                                            "};\n"
                                        ),
                                    }
                                # Build a combined install command that also
                                # adds identity-obj-proxy when CSS mocking is
                                # missing. Keeps the UI to one copy-paste line.
                                extra: list[str] = []
                                if "missing_css_mock_package" in config_issues:
                                    extra.append("identity-obj-proxy")
                                base_cmd = _build_install_cmd(
                                    fw_name_effective, is_ts, is_react, is_next, is_vite,
                                )
                                if extra:
                                    fw_result["install_hint"] = base_cmd + " " + " ".join(extra)
                                elif not fw_result.get("install_hint"):
                                    fw_result["install_hint"] = base_cmd
                    except Exception as exc:
                        fw_result["error"] = f"package.json parse error: {exc}"
                else:
                    # No package.json at all — init + install jest as baseline
                    fw_result["install_hint"] = "npm init -y && npm install --save-dev jest"
                    fw_result["suggested_framework"] = "jest"
                payload = json.dumps(fw_result).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self._cors_headers()
                self.end_headers()
                self.wfile.write(payload)
                return

            if parsed.path == "/open":
                # Open a test file in the user's editor (VSCode) at the line
                # where the given test_name appears. Called by the run-history
                # "Open in editor" button.
                params = parse_qs(parsed.query)
                rel = (params.get("path") or [""])[0].strip().lstrip("/")
                test_name = (params.get("test_name") or [""])[0].strip()
                if not rel:
                    payload = json.dumps({"ok": False, "error": "path required"}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return
                try:
                    abs_path = (root / rel).resolve()
                    abs_path.relative_to(root)
                except Exception:
                    payload = json.dumps({"ok": False, "error": "path outside project"}).encode()
                    self.send_response(403)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return
                if not abs_path.is_file():
                    payload = json.dumps({"ok": False, "error": "file not found"}).encode()
                    self.send_response(404)
                    self.send_header("Content-Type", "application/json")
                    self._cors_headers(); self.end_headers()
                    self.wfile.write(payload); return
                # Find the line number of the test name in the file.
                # Jest stores test_name as the fully-qualified "fullName"
                # (describe block + test title concatenated), so no single
                # line contains it. Try progressively shorter word-suffixes
                # so we still land on the it()/test() call even when the
                # describe prefix is prepended.
                line = 1
                if test_name:
                    try:
                        file_lines = abs_path.read_text(encoding="utf-8", errors="replace").splitlines()
                        words = test_name.split()
                        for start in range(len(words)):
                            suffix = " ".join(words[start:])
                            if len(suffix) < 4:
                                break
                            for i, ln in enumerate(file_lines, 1):
                                if suffix in ln:
                                    line = i
                                    break
                            else:
                                continue
                            break
                    except Exception:
                        pass
                try:
                    subprocess.Popen(
                        ["code", "--goto", f"{abs_path}:{line}"],
                        shell=(os.name == "nt"),
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    payload = json.dumps({"ok": True}).encode()
                    self.send_response(200)
                except Exception as exc:
                    payload = json.dumps({"ok": False, "error": str(exc)}).encode()
                    self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self._cors_headers(); self.end_headers()
                self.wfile.write(payload); return

            if parsed.path != "/source":
                self.send_response(404); self._cors_headers(); self.end_headers(); return
            params = parse_qs(parsed.query)
            rel = (params.get("path") or [""])[0].strip().lstrip("/")
            if not rel:
                self.send_response(400); self._cors_headers(); self.end_headers()
                self.wfile.write(b'{"error":"path required"}'); return

            # Allow any JS/TS source file (source files + test files).
            # Confine to the repo root — refuse anything that escapes via `..`.
            if not SOURCE_FILE_RE.search(rel):
                self.send_response(403); self._cors_headers(); self.end_headers()
                self.wfile.write(b'{"error":"only JS/TS source files are served"}'); return
            try:
                abs_path = (root / rel).resolve()
                abs_path.relative_to(root)
            except Exception:
                self.send_response(403); self._cors_headers(); self.end_headers()
                self.wfile.write(b'{"error":"path outside project"}'); return
            if not abs_path.is_file():
                self.send_response(404); self._cors_headers(); self.end_headers()
                self.wfile.write(b'{"error":"not found"}'); return

            try:
                data = abs_path.read_bytes()
            except Exception as exc:
                self.send_response(500); self._cors_headers(); self.end_headers()
                self.wfile.write(f'{{"error":"read failed: {exc}"}}'.encode()); return

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(data)

    return Handler


class LocalSourceServer:
    """Small daemon thread exposing GET http://127.0.0.1:<port>/source?path=…"""

    def __init__(self, repo_root: Path, port: int = DEFAULT_PORT):
        self.repo_root = Path(repo_root).resolve()
        self.port = port
        self._httpd = None
        self._thread: Thread | None = None

    def start(self) -> int | None:
        try:
            handler = _make_handler(self.repo_root)
            self._httpd = ThreadingHTTPServer(("127.0.0.1", self.port), handler)
        except OSError as exc:
            logger.warning("local_source_server_bind_failed", port=self.port, error=str(exc))
            return None
        self._thread = Thread(target=self._httpd.serve_forever, name="maeris-source-server", daemon=True)
        self._thread.start()
        logger.info("local_source_server_started", port=self.port, root=str(self.repo_root))
        return self.port

    def stop(self) -> None:
        try:
            if self._httpd:
                self._httpd.shutdown()
                self._httpd.server_close()
        except Exception:
            pass
