"""Session context and smart suggestions tools for the Maeris assistant."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from mcp.types import TextContent, Tool

from maeris_mcp.storage.api_store import APIStore
from maeris_mcp.storage.execution_store import TestExecutionStore
from maeris_mcp.storage.security_store import SecurityScanStore
from maeris_mcp.storage.test_store import TestGenerationStore


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

def get_session_context_tool() -> Tool:
    return Tool(
        name="get_session_context",
        description=(
            "Returns the current session context: active scans, pending items, "
            "recent activity, and what has been pushed to Maeris. Use this to "
            "understand the current state before suggesting next actions."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    )


def get_smart_suggestions_tool() -> Tool:
    return Tool(
        name="get_smart_suggestions",
        description=(
            "Returns context-aware next action suggestions based on current "
            "session state. Use this to provide intelligent follow-up recommendations "
            "to the user after any operation."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    )


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def handle_get_session_context(
    api_store: APIStore,
    security_store: SecurityScanStore,
    test_store: TestGenerationStore,
    exec_store: TestExecutionStore,
    accessibility_store=None,
    gdpr_store=None,
    arguments: dict | None = None,
) -> list[TextContent]:
    """Gather and return the full session context."""

    context: dict = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "security_scans": _get_security_context(security_store),
        "api_scans": _get_api_context(api_store),
        "test_generation": _get_test_gen_context(test_store),
        "test_execution": _get_test_exec_context(exec_store),
        "accessibility_scans": _get_accessibility_context(accessibility_store),
        "gdpr_scans": _get_gdpr_context(gdpr_store),
    }

    # Remove empty sections
    context = {k: v for k, v in context.items() if v}

    if len(context) <= 1:  # only timestamp
        context["status"] = "no_activity"
        context["message"] = "No scans or tests have been run in this session yet."

    return [TextContent(type="text", text=json.dumps(context, indent=2, default=str))]


async def handle_get_smart_suggestions(
    api_store: APIStore,
    security_store: SecurityScanStore,
    test_store: TestGenerationStore,
    exec_store: TestExecutionStore,
    accessibility_store=None,
    gdpr_store=None,
    arguments: dict | None = None,
) -> list[TextContent]:
    """Generate context-aware suggestions based on session state."""

    suggestions: list[dict] = []

    # Check security scan state
    sec_ctx = _get_security_context(security_store)
    if sec_ctx:
        for scan in sec_ctx.get("scans", []):
            if scan.get("status") == "completed" and not scan.get("pushed"):
                suggestions.append({
                    "action": f"push_to_maeris(scan_id=\"{scan['scan_id']}\")",
                    "reason": f"Security scan has {scan.get('total_findings', 0)} findings that haven't been pushed to Maeris yet",
                    "priority": "high",
                })
    else:
        suggestions.append({
            "action": "security_scan(include_content=true)",
            "reason": "No security scan has been run yet. Scanning helps find vulnerabilities early.",
            "priority": "medium",
        })

    # Check API scan state
    api_ctx = _get_api_context(api_store)
    if not api_ctx:
        suggestions.append({
            "action": "api_scan(include_content=true)",
            "reason": "No API scan has been run. Discovering APIs helps with coverage analysis.",
            "priority": "medium",
        })

    # Check test generation state
    test_ctx = _get_test_gen_context(test_store)
    if test_ctx:
        for session in test_ctx.get("sessions", []):
            if session.get("status") == "completed" and session.get("total_tests", 0) > 0:
                suggestions.append({
                    "action": f"run_and_fix_tests(session_id=\"{session['session_id']}\")",
                    "reason": f"{session['total_tests']} tests generated but not yet executed",
                    "priority": "high",
                })
    else:
        suggestions.append({
            "action": "generate(command=<flow description>)",
            "reason": "No tests generated yet. Test generation creates comprehensive test coverage.",
            "priority": "medium",
        })

    # Check test execution state
    exec_ctx = _get_test_exec_context(exec_store)
    if exec_ctx:
        for session in exec_ctx.get("sessions", []):
            if session.get("status") == "completed":
                failed = session.get("failed", 0)
                passed = session.get("passed", 0)
                if failed > 0:
                    suggestions.append({
                        "action": f"run_and_fix_tests(exec_session_id=\"{session['exec_session_id']}\")",
                        "reason": f"{failed} tests still failing — try running again to auto-fix",
                        "priority": "high",
                    })
                if passed > 0:
                    suggestions.append({
                        "action": f"push_tests_to_maeris(session_id=\"{session.get('gen_session_id', '')}\")",
                        "reason": f"{passed} passing tests can be pushed to Maeris for tracking",
                        "priority": "medium",
                    })

    # Check accessibility
    acc_ctx = _get_accessibility_context(accessibility_store)
    if not acc_ctx:
        suggestions.append({
            "action": "accessibility_scan(include_content=true)",
            "reason": "No accessibility scan run. Check WCAG compliance.",
            "priority": "low",
        })

    # Check GDPR
    gdpr_ctx = _get_gdpr_context(gdpr_store)
    if not gdpr_ctx:
        suggestions.append({
            "action": "gdpr_scan(include_content=true)",
            "reason": "No GDPR scan run. Check privacy compliance.",
            "priority": "low",
        })

    # Sort by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    suggestions.sort(key=lambda s: priority_order.get(s["priority"], 3))

    result = {
        "suggestions": suggestions[:6],  # Top 6 suggestions
        "total_suggestions": len(suggestions),
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_security_context(store: SecurityScanStore) -> dict | None:
    if not store:
        return None
    scans = []
    for scan_id, scan in store._scans.items():
        scans.append({
            "scan_id": scan_id,
            "status": "completed" if scan.finalized else "in_progress",
            "total_findings": len(scan.result.findings) if scan.result else 0,
            "pushed": scan.pushed if hasattr(scan, "pushed") else False,
            "profile": scan.scan_profile if hasattr(scan, "scan_profile") else None,
            "created_at": scan.created_at.isoformat() if hasattr(scan, "created_at") and scan.created_at else None,
        })
    return {"scans": scans, "total": len(scans)} if scans else None


def _get_api_context(store: APIStore) -> dict | None:
    if not store:
        return None
    sessions = []
    for scan_id, session in store._sessions.items():
        sessions.append({
            "scan_id": scan_id,
            "status": "completed" if session.finalized else "in_progress",
            "total_apis": len(session.apis) if hasattr(session, "apis") else 0,
            "project_name": session.project_name if hasattr(session, "project_name") else None,
        })
    return {"sessions": sessions, "total": len(sessions)} if sessions else None


def _get_test_gen_context(store: TestGenerationStore) -> dict | None:
    if not store:
        return None
    sessions = []
    for session_id, session in store._sessions.items():
        sessions.append({
            "session_id": session_id,
            "status": "completed" if session.finalized else "in_progress",
            "total_tests": len(session.test_cases) if hasattr(session, "test_cases") and session.test_cases else 0,
            "flow_description": session.flow_description if hasattr(session, "flow_description") else None,
            "output_dir": session.output_dir if hasattr(session, "output_dir") else None,
        })
    return {"sessions": sessions, "total": len(sessions)} if sessions else None


def _get_test_exec_context(store: TestExecutionStore) -> dict | None:
    if not store:
        return None
    sessions = []
    for exec_id, session in store._sessions.items():
        results = session.results if hasattr(session, "results") else []
        passed = sum(1 for r in results if r.get("status") == "passed") if results else 0
        failed = sum(1 for r in results if r.get("status") in ("failed", "unfixable")) if results else 0
        sessions.append({
            "exec_session_id": exec_id,
            "status": "completed" if session.finalized else "in_progress",
            "passed": passed,
            "failed": failed,
            "total": len(results),
            "gen_session_id": session.gen_session_id if hasattr(session, "gen_session_id") else None,
        })
    return {"sessions": sessions, "total": len(sessions)} if sessions else None


def _get_accessibility_context(store) -> dict | None:
    if not store or not hasattr(store, "_scans"):
        return None
    scans = []
    for scan_id, scan in store._scans.items():
        scans.append({
            "scan_id": scan_id,
            "status": "completed" if scan.finalized else "in_progress",
            "total_findings": len(scan.result.findings) if hasattr(scan, "result") and scan.result else 0,
        })
    return {"scans": scans, "total": len(scans)} if scans else None


def _get_gdpr_context(store) -> dict | None:
    if not store or not hasattr(store, "_scans"):
        return None
    scans = []
    for scan_id, scan in store._scans.items():
        scans.append({
            "scan_id": scan_id,
            "status": "completed" if scan.finalized else "in_progress",
            "total_findings": len(scan.result.findings) if hasattr(scan, "result") and scan.result else 0,
        })
    return {"scans": scans, "total": len(scans)} if scans else None
