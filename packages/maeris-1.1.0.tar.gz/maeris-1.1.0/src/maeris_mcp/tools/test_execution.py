"""LLM-guided Playwright test execution and auto-fix tool."""

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcp.types import TextContent, Tool

from maeris_mcp.storage.execution_store import TestExecutionStore
from maeris_mcp.storage.test_store import TestGenerationStore


def _coerce_bool(value: object, default: bool = True) -> bool:
    """Coerce string 'true'/'false' to bool — Claude sometimes passes booleans as strings."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() not in ("false", "0", "no", "")
    if value is None:
        return default
    return bool(value)


def _page_timeout_for_fix_count(fix_count: int) -> int:
    """Return page_timeout (ms) scaled to the number of fix attempts made.

    First run / no fix yet: 2 s — fast-fail on clearly wrong selectors.
    After 1 fix applied:    5 s — allow slightly slower apps to settle.
    After 2+ fixes applied: 8 s — full patience for persistent failures.

    This avoids burning 8 s × every step on obviously broken selectors while
    still giving legitimate elements time to render on later retries.
    """
    if fix_count == 0:
        return 2000
    if fix_count == 1:
        return 5000
    return 8000


def _normalize_base_url(url: str | None) -> str | None:
    if not url:
        return None
    u = url.strip()
    if not u:
        return None
    if u.startswith("//"):
        u = "https:" + u
    if not u.startswith(("http://", "https://")):
        u = "https://" + u
    return u.rstrip("/")


def _extract_app_url(app: dict) -> str | None:
    for key in (
        "app_url", "appUrl", "url", "base_url", "baseUrl",
        "host", "domain", "app_domain", "appDomain",
        "frontend_url", "frontendUrl", "website", "site_url", "siteUrl",
    ):
        val = app.get(key)
        if isinstance(val, str) and val.strip():
            return val
    for key in ("app", "application", "meta", "metadata"):
        val = app.get(key)
        if isinstance(val, dict):
            nested = _extract_app_url(val)
            if nested:
                return nested
    return None


async def _resolve_base_url_from_app() -> str | None:
    """Look up the active application's URL from the Maeris portal.

    Returns the normalized base URL or None if it cannot be resolved.
    """
    try:
        from maeris_mcp.auth.token_store import TokenStore
        from maeris_mcp.maeris.client import MaerisClient

        token_store = TokenStore()
        app_id = token_store.get_app_id()

        async with MaerisClient() as client:
            apps = await client.get_applications()
    except Exception:
        return None

    if not apps:
        return None

    match = None
    if app_id:
        for app in apps:
            for key in ("appid", "app_id", "id", "_id"):
                if str(app.get(key, "")).strip() == str(app_id):
                    match = app
                    break
            if match:
                break

    if not match:
        for app in apps:
            if _extract_app_url(app):
                match = app
                break
    if not match:
        return None

    return _normalize_base_url(_extract_app_url(match))


def _update_codemap_selector(repo_root: str | Path, old_selector: str, new_selector: str) -> None:
    """Replace *old_selector* with *new_selector* everywhere in the project's codemap.json.

    Searches elements, form fields, form submit selectors, and modal triggers.
    Non-critical — callers should wrap in try/except.
    """
    from maeris_mcp.tools.code_map_tool import codemap_path_for

    cm_path = codemap_path_for(repo_root)
    if not cm_path.exists():
        return
    data = json.loads(cm_path.read_text(encoding="utf-8"))
    nodes = data.get("nodes", {})
    changed = False

    for _route, node in nodes.items():
        # elements[].selector
        for el in node.get("elements", []):
            if el.get("selector") == old_selector:
                el["selector"] = new_selector
                changed = True
        # forms[].fields[] and forms[].submit
        for form in node.get("forms", []):
            for field in form.get("fields", []):
                if field.get("selector") == old_selector:
                    field["selector"] = new_selector
                    changed = True
            if form.get("submit") == old_selector:
                form["submit"] = new_selector
                changed = True
        # modals[].trigger_selector
        for modal in node.get("modals", []):
            if modal.get("trigger_selector") == old_selector:
                modal["trigger_selector"] = new_selector
                changed = True

    if changed:
        cm_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _mark_proven_paths_in_codemap(repo_root: str | Path, passing_test_json: str) -> None:
    """Mark navigation_tree entries and node selectors as proven based on a passing test.

    Parses the passing test's steps to extract the navigation sequence and
    selectors used. Marks matching navigation_tree entries with proven=true
    and records the proven step sequence. Also marks used selectors as proven
    in node elements.

    Non-critical — callers should wrap in try/except.
    """
    from maeris_mcp.tools.code_map_tool import codemap_path_for

    cm_path = codemap_path_for(repo_root)
    if not cm_path.exists():
        return

    try:
        test_data = json.loads(passing_test_json)
    except Exception:
        return

    steps = test_data.get("steps", [])
    if not steps:
        return

    data = json.loads(cm_path.read_text(encoding="utf-8"))
    nav_tree = data.get("navigation_tree", {})
    nodes = data.get("nodes", {})
    changed = False

    # Extract visited URLs and used selectors from passing steps
    visited_urls: list[str] = []
    used_selectors: list[str] = []
    proven_step_sequence: list[dict] = []

    for step in steps:
        action = (step.get("action_taken") or "").lower()
        selector = (step.get("css_selector") or "").strip()
        mock_input = (step.get("mock_input") or "").strip()

        if action == "go_to" and mock_input:
            # Extract path from URL
            try:
                from urllib.parse import urlparse
                path = urlparse(mock_input).path or "/"
                visited_urls.append(path)
            except Exception:
                pass
            proven_step_sequence.append({
                "action": action,
                "mock_input": mock_input,
            })
        elif action in ("click", "send_keys", "select", "on_blur") and selector:
            used_selectors.append(selector)
            proven_step_sequence.append({
                "action": action,
                "css_selector": selector,
                "description": step.get("description", ""),
            })

    # Mark navigation_tree entries as proven
    for route, entry in nav_tree.items():
        if route in visited_urls:
            if not entry.get("proven"):
                entry["proven"] = True
                entry["proven_via_steps"] = proven_step_sequence
                changed = True
            elif entry.get("proven"):
                # Already proven — increment confidence
                entry["proven_passes"] = entry.get("proven_passes", 1) + 1
                changed = True

    # Mark used selectors as proven in node elements
    for _route, node in nodes.items():
        for el in node.get("elements", []):
            sel = el.get("selector", "")
            if sel and sel in used_selectors:
                if not el.get("proven"):
                    el["proven"] = True
                    changed = True

    if changed:
        data["navigation_tree"] = nav_tree
        data["nodes"] = nodes
        cm_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _update_codemap_learned_selectors(
    repo_root: str | Path,
    corrections: list[tuple[str, str]],
    test_name: str,
) -> None:
    """Persist selector corrections to codemap["learned_selector_fixes"].

    Unlike _update_codemap_selector (which updates node elements in-place and
    can be overwritten by a source re-scan), this writes to a dedicated
    top-level array that survives re-scans.

    Non-critical — callers should wrap in try/except.
    """
    from maeris_mcp.tools.code_map_tool import codemap_path_for

    cm_path = codemap_path_for(repo_root)
    if not cm_path.exists():
        return
    data = json.loads(cm_path.read_text(encoding="utf-8"))
    fixes = data.setdefault("learned_selector_fixes", [])

    for broken, working in corrections:
        # Deduplicate by (broken, working)
        is_dup = any(
            f.get("broken") == broken and f.get("working") == working
            for f in fixes
        )
        if not is_dup:
            fixes.append({
                "broken": broken,
                "working": working,
                "context": test_name,
                "learned_at": datetime.now(timezone.utc).isoformat(),
            })

    data["learned_selector_fixes"] = fixes
    cm_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


import re as _re

_EMAIL_SELECTORS = ('[type="email"]', "[type='email']", 'input[type="email"]')
_PASSWORD_SELECTORS = ('[type="password"]', "[type='password']", 'input[type="password"]')
_EMAIL_DESC_WORDS = ("email", "username", "user name", "e-mail", "login id")
_PASSWORD_DESC_WORDS = ("password", "pass word", "passphrase", "secret")

_NEGATIVE_TEST_RE = _re.compile(
    r"invalid|wrong|incorrect|bad.cred|fail|nonexistent|non.exist|fake|bogus",
    _re.IGNORECASE,
)


def _is_negative_test_name(name: str) -> bool:
    """Return True if the test case name indicates it uses intentionally wrong credentials."""
    return bool(_NEGATIVE_TEST_RE.search(name))


def _should_inject_email(step: dict) -> bool:
    mock = step.get("mock_input") or ""
    if mock == "$MAERIS_TEST_EMAIL":
        return True
    sel = (step.get("css_selector") or "").lower()
    desc = (step.get("description") or "").lower()
    return any(s in sel for s in _EMAIL_SELECTORS) or any(w in desc for w in _EMAIL_DESC_WORDS)


def _should_inject_password(step: dict) -> bool:
    mock = step.get("mock_input") or ""
    if mock == "$MAERIS_TEST_PASSWORD":
        return True
    sel = (step.get("css_selector") or "").lower()
    desc = (step.get("description") or "").lower()
    return any(s in sel for s in _PASSWORD_SELECTORS) or any(w in desc for w in _PASSWORD_DESC_WORDS)


def _inject_base_url_into_dir(output_dir: str, old_base_url: str | None, new_base_url: str) -> int:
    """Replace the base_url and go_to URLs in all JSON step files.

    Rewrites the top-level ``base_url`` field and replaces any ``go_to``
    step whose ``mock_input`` starts with the old base URL so that
    navigation points at the user-provided URL instead.

    Returns the number of files modified.
    """
    # Strip trailing slash for consistent matching
    new_base = new_base_url.rstrip("/")
    old_base = old_base_url.rstrip("/") if old_base_url else None

    modified = 0
    for fpath in sorted(Path(output_dir).glob("*.json")):
        try:
            data = json.loads(fpath.read_text(encoding="utf-8"))
        except Exception:
            continue

        changed = False

        # Replace top-level base_url field
        if "base_url" in data and data["base_url"] != new_base:
            if old_base is None:
                old_base = data["base_url"].rstrip("/") if data.get("base_url") else None
            data["base_url"] = new_base
            changed = True

        # Replace go_to step URLs that match the old base
        for step in data.get("steps", []):
            if step.get("action_taken") != "go_to":
                continue
            mock_input = step.get("mock_input", "")
            if old_base and mock_input.startswith(old_base):
                step["mock_input"] = new_base + mock_input[len(old_base):]
                changed = True
            elif mock_input == new_base or mock_input.startswith(new_base):
                pass  # already correct
            elif old_base is None:
                # No old base known — replace the entire URL with new base
                step["mock_input"] = new_base
                changed = True

        if changed:
            try:
                fpath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                modified += 1
            except Exception:
                pass

    return modified


def _inject_credentials_into_dir(output_dir: str, test_email: str, test_password: str) -> int:
    """Overwrite mock_input in JSON step files for email/password send_keys steps.

    Skips files whose test name indicates they use intentionally wrong credentials
    (negative tests), so their mock values are preserved unchanged.

    Returns the number of files modified.
    """
    modified = 0
    for fpath in sorted(Path(output_dir).glob("*.json")):
        try:
            data = json.loads(fpath.read_text(encoding="utf-8"))
        except Exception:
            continue

        # Skip negative tests — they need their intentionally wrong values intact
        test_name = data.get("name") or fpath.stem
        if _is_negative_test_name(test_name):
            continue

        changed = False
        for step in data.get("steps", []):
            if step.get("action_taken") != "send_keys":
                continue
            if test_email and _should_inject_email(step):
                step["mock_input"] = test_email
                changed = True
            elif test_password and _should_inject_password(step):
                step["mock_input"] = test_password
                changed = True

        if changed:
            try:
                fpath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                modified += 1
            except Exception:
                pass

    return modified


def run_and_fix_tests_tool() -> Tool:
    """Return the tool definition for run_and_fix_tests."""
    return Tool(
        name="run_and_fix_tests",
        description=(
            "LLM-guided E2E test execution and auto-fix using the Mirabilis in-process runner. "
            "Runs each generated JSON step file one by one. When a step fails, returns to "
            "the LLM with failure info so it can provide fixed_code. Each failing step gets "
            "up to step_retries (default: 3) fix attempts before the test is auto-advanced. "
            "Use mark_unfixable to explicitly skip a test. "
            "Tracks state via exec_session_id across calls. "
            "When all tests are processed, returns a summary with passing/failing results "
            "and stores the final correct step files on disk."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": (
                        "Test generation session ID from the generate tool. "
                        "Used to locate the output directory on first call."
                    ),
                },
                "output_dir": {
                    "type": "string",
                    "description": (
                        "Direct path to the generated test directory "
                        "(alternative to session_id on first call)."
                    ),
                },
                "exec_session_id": {
                    "type": "string",
                    "description": "Existing execution session ID to continue across calls.",
                },
                "fixed_code": {
                    "type": "string",
                    "description": (
                        "Full corrected JSON step file content (as a JSON string) to apply before "
                        "re-running the current failing test. Must be valid JSON with a 'steps' array."
                    ),
                },
                "pre_fixed_code": {
                    "type": "string",
                    "description": (
                        "Proactive fix for the NEXT test in the session, applied before its first run. "
                        "Submit alongside fixed_code when you recognise that an upcoming test contains "
                        "the same absent selectors or structural issues just resolved in the current test. "
                        "Must be valid JSON with a 'steps' array. Does NOT consume the next test's retry "
                        "budget — if it fails, the normal fix loop starts with a full budget."
                    ),
                },
                "mark_unfixable": {
                    "type": "boolean",
                    "description": (
                        "Mark the current failing test as unfixable and advance to the next test."
                    ),
                    "default": False,
                },
                "headless": {
                    "anyOf": [{"type": "boolean"}, {"type": "string"}],
                    "description": (
                        "Run the browser in headless mode (default: true). "
                        "ALWAYS leave this as true unless the USER explicitly asks to watch the browser. "
                        "Do NOT set to false for debugging — use logs and DOM snapshots instead. "
                        "Only used on the first call when creating a new execution session."
                    ),
                    "default": True,
                },
                "step_retries": {
                    "anyOf": [{"type": "integer"}, {"type": "string"}],
                    "description": "Max LLM fix attempts per failing step (default: 3). When a step fails, the LLM gets up to this many chances to provide fixed_code before the test is auto-advanced.",
                    "default": 3,
                },
                "base_url": {
                    "type": "string",
                    "description": (
                        "Base URL of the application under test (e.g. https://app.example.com). "
                        "Overrides the auto-resolved URL from the generation session. "
                        "Required on the first call when starting a new execution session."
                    ),
                },
                "test_email": {
                    "type": "string",
                    "description": (
                        "Real test account email to inject into all login/email steps before running. "
                        "Replaces placeholder email values in mock_input across all generated step files. "
                        "Only needed on the first call when starting a new execution session."
                    ),
                },
                "test_password": {
                    "type": "string",
                    "description": (
                        "Real test account password to inject into all password steps before running. "
                        "Replaces placeholder password values in mock_input across all generated step files. "
                        "Only needed on the first call when starting a new execution session."
                    ),
                },
                "skip_iframe_search": {
                    "anyOf": [{"type": "boolean"}, {"type": "string"}],
                    "description": (
                        "Skip iframe fallback when locating elements (default: true). "
                        "Set to false only if the application under test uses iframes. "
                        "Skipping iframes speeds up failure detection significantly. "
                        "Only used on the first call when creating a new execution session."
                    ),
                    "default": True,
                },
            },
        },
    )


def _review_instructions() -> str:
    """Return generic review prompt for LLM to validate a passing test's logical completeness."""
    return (
        "=== MANDATORY STEP REVIEW — DO NOT SKIP ===\n"
        "⚠️  A passing test is NOT necessarily a correct test. The browser may have cached\n"
        "state, auto-filled fields, or skipped validation. You MUST review the steps below\n"
        "and FIX any gaps — do NOT rationalize them away.\n"
        "\n"
        "RULE: If you suspect a step might be missing, it IS missing. Add it.\n"
        "Do NOT assume the app has passwordless login, optional fields, or magic behavior.\n"
        "Do NOT confirm a test that has obvious gaps just because it passed.\n"
        "\n"
        "CHECK EACH OF THESE — if ANY fails, submit fixed_code:\n"
        "\n"
        "1. FORM COMPLETENESS\n"
        "   - Login flow: email AND password steps MUST both exist before submit.\n"
        "   - Any form: ALL visible required fields must have send_keys steps.\n"
        "   - Every form must end with a submit/save/confirm click.\n"
        "\n"
        "2. NAVIGATION COHERENCE\n"
        "   - Can each step be reached from the previous one?\n"
        "   - Are there missing intermediate clicks or page transitions?\n"
        "\n"
        "3. ASSERTIONS (MANDATORY)\n"
        "   - A test with ZERO assertions is NEVER complete — add at least one.\n"
        "   - After login → assert dashboard URL or welcome element.\n"
        "   - After form submit → assert success message or state change.\n"
        "   - After navigation → assert target page content.\n"
        "\n"
        "4. DATA ENTRY\n"
        "   - Do mock_input values make sense for their fields?\n"
        "   - Are credentials realistic and complete?\n"
        "\n"
        "ACTION REQUIRED:\n"
        "- If steps are missing or assertions are absent → call with exec_session_id + fixed_code.\n"
        "- ONLY call confirm_passed=true when ALL checks above pass with no gaps.\n"
    )


def _fix_instructions(timed_out: bool = False, selector_only: bool = False) -> str:
    if selector_only:
        timeout_note = (
            "\n⚠️  TIMEOUT: Fix the css_selector on the failing step — do NOT add wait_before.\n"
        ) if timed_out else ""
        return (
            timeout_note
            + "=== SELECTOR-ONLY FIX MODE ===\n"
            "You may change: css_selector, xpath, nth_appearance, wait_before, wait_after.\n"
            "⛔ Do NOT change action_taken, mock_input, assertion fields, description, or any other field.\n"
            "⛔ Do NOT add or remove steps — the step count must stay exactly the same.\n"
            "Provide the full corrected JSON with only the allowed fields updated.\n"
            "\n"
            "How to pick the right selector:\n"
            "  1. [data-testid=\"foo\"] or [data-automation-id=\"foo\"]  ← most stable\n"
            "  2. [aria-label=\"foo\"]                                  ← stable if set\n"
            "  3. [id=\"foo\"] or [name=\"foo\"]                         ← stable if unique\n"
            "  4. [type=\"submit\"] or [placeholder=\"foo\"]             ← for inputs\n"
            "  5. button:has-text(\"exact text\")                      ← when no attribute exists\n"
            "  6. nth_appearance (0-based) to disambiguate multiple matches.\n"
            "If logs include '--- DOM SNAPSHOT ---', pick your selector from there.\n"
        )
    timeout_warning = (
        "\n⚠️  TIMEOUT DETECTED — MANDATORY RULES:\n"
        "   - DO NOT call with mark_unfixable=true. Timeout = fixable step issue.\n"
        "   - DO NOT tell the user to run commands.\n"
        "   - Fix the step file and call again with fixed_code.\n"
        "   Common timeout fixes:\n"
        "     * Add wait_before (ms) on the failing step to wait for the page to settle\n"
        "     * Fix the css_selector — if element not found, timeout occurs\n"
        "     * Check if element is in an iframe (the runner handles iframes, but\n"
        "       the selector must still be correct)\n"
        "\n"
    ) if timed_out else ""

    return (
        timeout_warning
        + "=== HOW TO FIX A FAILING TEST (JSON STEP FORMAT) ===\n"
        "⛔ fixed_code MUST be valid JSON only — the full corrected .json step file.\n"
        "   NO Python code, NO prose, NO explanations. Just the corrected JSON.\n"
        "1. Read the 'logs' field carefully — it shows exactly what failed and why.\n"
        "2. Read 'currentCode' to see the full current step file JSON.\n"
        "3. Common failures and fixes:\n"
        "   - '[FAIL] Element not found': css_selector didn't match any element.\n"
        "     Fix: Update css_selector to a more specific/correct [attr=\"value\"] selector.\n"
        "     ⚠️  CSS MODULE SELECTOR: If css_selector looks like '.submitButton' or\n"
        "     'button.loginBtn' — it's a CSS Module class (hashed at runtime).\n"
        "     Fix immediately with stable alternatives:\n"
        "       [type=\"submit\"]         ← for submit buttons\n"
        "       [placeholder=\"foo\"]    ← for inputs with placeholder\n"
        "       [aria-label=\"Submit\"]  ← if aria-label is set\n"
        "       [data-testid=\"foo\"]    ← preferred if available\n"
        "   - '[FAIL] Expected ... to be visible/to contain url/to have value':\n"
        "     assertion_value doesn't match the actual page content.\n"
        "     Fix: Update assertion_value to match EXACT rendered text or URL.\n"
        "   - '[TIMEOUT]': Step took too long — element probably not found.\n"
        "     Fix: Add wait_before ms on the step, or fix the css_selector.\n"
        "   - 'Multiple elements matched' or '(ambiguous: N elements matched)':\n"
        "     css_selector matched more than one element on the page.\n"
        "     The runner auto-retries with alternative nth_appearance values,\n"
        "     but if all alternatives fail, you must fix the selector.\n"
        "     Fix: Use a more specific selector, or set nth_appearance to the\n"
        "     correct 0-based index for the intended element.\n"
        "4. **ELEMENT INVENTORY**: The response includes an 'elementInventory' field.\n"
        "   USE IT — it lists every visible interactive element on the page at failure time\n"
        "   with a pre-computed 'computed_selector' for each one.\n"
        "   ➜ Copy the computed_selector directly into css_selector — no guessing needed.\n"
        "   If logs also contain '--- DOM SNAPSHOT ---', it contains the same data in detail.\n"
        "   Selector priority (best → worst):\n"
        "     1. [data-testid=\"foo\"] or [data-automation-id=\"foo\"]  ← most stable\n"
        "     2. [aria-label=\"foo\"]                                  ← stable if set\n"
        "     3. [id=\"foo\"] or [name=\"foo\"]                         ← stable if unique\n"
        "     4. [type=\"submit\"] or [placeholder=\"foo\"]             ← for inputs\n"
        "     5. button:has-text(\"exact text\")                      ← USE THIS when no attribute exists\n"
        "        Examples: button:has-text(\"Save\"), a:has-text(\"Sign in\"), li:has-text(\"light\")\n"
        "        This is ALWAYS better than a bare tag like 'button' which matches every button.\n"
        "     6. nth_appearance (integer, 0-based) to disambiguate when multiple elements match.\n"
        "   ⛔ NEVER use a bare tag name alone (button, div, a, span, li) as the css_selector.\n"
        "      A bare tag matches every element of that type — it is not a fix, it is a guess.\n"
        "      If no attribute exists and no text is visible, increase nth_appearance instead.\n"
        "5. Provide the FULL corrected JSON in 'fixed_code' (not just the changed step).\n"
        "6. Use mark_unfixable=true to explicitly skip a test before running it.\n"
        "\n"
        "=== STEP REMOVAL POLICY — READ BEFORE REMOVING ANY STEP ===\n"
        "\n"
        "Each step may have a '_source' field — this means the element EXISTS in the\n"
        "source code and was intentionally generated. The response also includes\n"
        "'failingStepVisible' — whether the failing step's element is currently visible\n"
        "on the live page (true/false/null if not checked).\n"
        "\n"
        "Use both signals together to decide what to do with the failing step:\n"
        "\n"
        "  '_source' present  +  failingStepVisible=true\n"
        "    → Element exists in source AND is visible. Fix the css_selector.\n"
        "\n"
        "  '_source' present  +  failingStepVisible=false\n"
        "    → Element exists in source but is NOT visible right now (conditional\n"
        "      rendering). Set \"optional\": true on the step — do NOT remove it.\n"
        "\n"
        "  No '_source'       +  failingStepVisible=true\n"
        "    → Element is visible on the page. Fix the css_selector.\n"
        "\n"
        "  No '_source'       +  failingStepVisible=false\n"
        "    → No source evidence and not visible. Step is safe to remove.\n"
        "\n"
        "⛔ NEVER remove a step that has '_source' — fix or mark optional instead.\n"
        "⛔ NEVER remove steps just because they are hard to fix. If the element\n"
        "   exists in source ('_source' present), exhaust all selector fixes first.\n"
        "   Only use mark_unfixable=true when retries are gone and the element is\n"
        "   genuinely unreachable.\n"
        "\n"
        "=== JOURNEY-LEVEL FAILURES (test logic is wrong, not just selectors) ===\n"
        "\n"
        "7. MISSING LOGIN: If test interacts with a protected page but gets redirect:\n"
        "   - Add go_to step to login URL, then send_keys for email/password, then click submit.\n"
        "   - Use 'test@example.com' as mock_input for credentials, or env vars if specified.\n"
        "\n"
        "8. MISSING NAVIGATION: If go_to step lands on wrong page (redirect):\n"
        "   - Navigate via click steps through the UI instead of direct go_to.\n"
        "\n"
        "9. MISSING FORM FIELDS: If form submit fails due to validation:\n"
        "   - Add send_keys steps for all required fields before the click submit step.\n"
        "\n"
        "10. CONDITIONAL UI: If element doesn't exist when expected:\n"
        "    - Add the trigger action step first (e.g. click a checkbox to reveal the element).\n"
        "\n"
        "11. ASYNC CONTENT: If interacting with empty list/table:\n"
        "    - Add wait_before ms on the step (e.g. 2000) to let async data load.\n"
    )


def _extract_selector_corrections(old_json: str, new_json: str) -> list[tuple[str, str]]:
    """Extract css_selector replacements from old vs new JSON step files.

    Compares css_selector fields across steps. Returns list of
    (old_selector, new_selector) tuples for selectors that changed.
    """
    try:
        old_steps = json.loads(old_json).get("steps", [])
        new_steps = json.loads(new_json).get("steps", [])
    except Exception:
        return []

    corrections: list[tuple[str, str]] = []
    for i, (old_s, new_s) in enumerate(zip(old_steps, new_steps)):
        old_sel = (old_s.get("css_selector") or "").strip()
        new_sel = (new_s.get("css_selector") or "").strip()
        if old_sel and new_sel and old_sel != new_sel:
            corrections.append((old_sel, new_sel))
    return corrections


# Fields that should be propagated when a fix modifies an existing step.
_PROPAGATABLE_FIELDS = (
    "css_selector", "assertion_value", "assertion_type", "assertion_nature",
    "mock_input", "nth_appearance", "wait_before", "wait_after",
)


def _extract_step_field_corrections(old_json: str, new_json: str) -> list[dict]:
    """Extract all field-level changes between aligned old/new step files.

    Uses alignment to pair old steps with new steps (skipping insertions).
    For each aligned pair where any propagatable field changed, emits a
    correction record with match_key, changes, and old_values.
    """
    try:
        old_steps = json.loads(old_json).get("steps", [])
        new_steps = json.loads(new_json).get("steps", [])
    except Exception:
        return []

    corrections: list[dict] = []

    def _emit(oi: int, ni: int) -> None:
        changes: dict[str, Any] = {}
        old_values: dict[str, Any] = {}
        for field in _PROPAGATABLE_FIELDS:
            old_val = old_steps[oi].get(field)
            new_val = new_steps[ni].get(field)
            old_norm = (str(old_val).strip() if old_val is not None else "")
            new_norm = (str(new_val).strip() if new_val is not None else "")
            if old_norm != new_norm:
                changes[field] = new_val
                old_values[field] = old_val
        if changes:
            corrections.append({
                "match_key": {
                    "action_taken": (old_steps[oi].get("action_taken") or "").strip(),
                    "css_selector": (old_steps[oi].get("css_selector") or "").strip(),
                    "mock_input": (old_steps[oi].get("mock_input") or "").strip(),
                    "description": (old_steps[oi].get("description") or "").strip(),
                    "assertion_type": (old_steps[oi].get("assertion_type") or "").strip(),
                    "assertion_value": (old_steps[oi].get("assertion_value") or "").strip(),
                },
                "changes": changes,
                "old_values": old_values,
            })

    old_i = 0
    new_i = 0
    while old_i < len(old_steps) and new_i < len(new_steps):
        if _steps_match(old_steps[old_i], new_steps[new_i]):
            _emit(old_i, new_i)
            old_i += 1
            new_i += 1
        else:
            # Look ahead in new_steps for a match (insertions in between)
            found = False
            for look in range(new_i + 1, min(new_i + 6, len(new_steps))):
                if _steps_match(old_steps[old_i], new_steps[look]):
                    new_i = look
                    _emit(old_i, new_i)
                    old_i += 1
                    new_i += 1
                    found = True
                    break
            if not found:
                # No match ahead — pair by same action_taken if next old doesn't match here
                old_act = (old_steps[old_i].get("action_taken") or "").strip().lower()
                new_act = (new_steps[new_i].get("action_taken") or "").strip().lower()
                next_old_matches = (
                    old_i + 1 < len(old_steps)
                    and _steps_match(old_steps[old_i + 1], new_steps[new_i])
                )
                if old_act and old_act == new_act and not next_old_matches:
                    _emit(old_i, new_i)
                    old_i += 1
                    new_i += 1
                else:
                    new_i += 1  # skip insertion

    return corrections


def _step_matches_key(step: dict, match_key: dict) -> bool:
    """Return True if *step* matches a correction's identification key.

    Two matching modes, picked by whether the key represents an assertion or a
    journey action:

    * Assertion step  — action_taken is empty *and* assertion_type/value are
      present. Match requires assertion_nature + assertion_type +
      assertion_value to all be equal. Description is compared as a tiebreaker
      when both sides supply one.

    * Journey step    — action_taken is non-empty. Match requires
      action_taken + css_selector + mock_input to *all* match (empty ==
      empty counts as matching). Description alone or css_selector alone is
      NOT sufficient — previous OR-based matching caused unrelated steps in
      sibling tests to inherit corrections, overwriting their selectors.
    """
    key_action = (match_key.get("action_taken") or "").strip()
    step_action = (step.get("action_taken") or "").strip()
    if step_action != key_action:
        return False

    key_atype = (match_key.get("assertion_type") or "").strip()
    key_aval = (match_key.get("assertion_value") or "").strip()

    # Assertion-step match (no journey action). Action_taken is empty on both
    # sides. Require nature + type + value to match exactly so assertion text
    # changes don't bleed across tests.
    if not key_action and (key_atype or key_aval):
        step_nature = (step.get("assertion_nature") or "").strip()
        key_nature = (match_key.get("assertion_nature") or "").strip()
        step_atype = (step.get("assertion_type") or "").strip()
        step_aval = (step.get("assertion_value") or "").strip()
        if key_nature and step_nature != key_nature:
            return False
        if step_atype != key_atype or step_aval != key_aval:
            return False
        # Optional description tiebreaker — when both sides set one, they
        # should agree to guard against two tests that happen to assert the
        # same text for different purposes.
        step_desc = (step.get("description") or "").strip().lower()
        key_desc = (match_key.get("description") or "").strip().lower()
        if step_desc and key_desc and step_desc != key_desc:
            return False
        return True

    # Journey-step match — require selector AND mock_input to both match.
    step_sel = (step.get("css_selector") or "").strip()
    key_sel = (match_key.get("css_selector") or "").strip()
    step_input = (step.get("mock_input") or "").strip()
    key_input = (match_key.get("mock_input") or "").strip()
    if step_sel != key_sel:
        return False
    if step_input != key_input:
        return False

    # Description is a tiebreaker — if both sides set one, they must agree.
    # (Description alone is never sufficient; two different clicks in
    # different tests may share a generic description like "Click submit".)
    step_desc = (step.get("description") or "").strip().lower()
    key_desc = (match_key.get("description") or "").strip().lower()
    if step_desc and key_desc and step_desc != key_desc:
        return False
    return True


def _propagate_field_corrections(
    output_dir: str,
    field_corrections: list[dict],
    test_files: list[str],
    current_index: int,
) -> int:
    """Apply field-level corrections to matching steps in remaining test files.

    Only modifies a field if the step still has the OLD value.
    Returns the number of files modified.
    """
    if not field_corrections:
        return 0

    modified_count = 0
    for filename in test_files[current_index + 1:]:
        filepath = Path(output_dir) / filename
        if not filepath.exists():
            continue
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
        except Exception:
            continue

        steps = data.get("steps", [])
        changed = False
        for step in steps:
            for correction in field_corrections:
                if not _step_matches_key(step, correction["match_key"]):
                    continue
                for field, new_val in correction["changes"].items():
                    old_val = correction["old_values"].get(field)
                    step_norm = (str(step.get(field)).strip() if step.get(field) is not None else "")
                    old_norm = (str(old_val).strip() if old_val is not None else "")
                    if step_norm == old_norm:
                        step[field] = new_val
                        changed = True

        if changed:
            data["steps"] = steps
            try:
                filepath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                modified_count += 1
            except Exception:
                pass

    return modified_count


def _steps_match(a: dict, b: dict, *, strict_assertion: bool = False) -> bool:
    """Return True if two step dicts represent the same logical action.

    When *strict_assertion* is True, assertion steps must also have the same
    ``assertion_value`` to match.  Use strict=True for duplicate guards and
    strict=False for alignment (pairing old/new steps that may have modified values).
    """
    if a.get("action_taken") != b.get("action_taken"):
        return False
    # Match on description (case-insensitive)
    a_desc = (a.get("description") or "").lower().strip()
    b_desc = (b.get("description") or "").lower().strip()
    if a_desc and b_desc and a_desc == b_desc:
        return True
    # Match on css_selector
    a_sel = (a.get("css_selector") or "").strip()
    b_sel = (b.get("css_selector") or "").strip()
    if a_sel and a_sel == b_sel:
        return True
    # Match on mock_input (covers go_to / navigate steps)
    a_inp = (a.get("mock_input") or "").strip()
    b_inp = (b.get("mock_input") or "").strip()
    if a_inp and a_inp == b_inp:
        return True
    # For go_to steps, also match if URLs share the same origin (domain)
    # so a URL change like "example.com" → "example.com/login" still aligns.
    if (a.get("action_taken") or "").strip().lower() == "go_to" and a_inp and b_inp:
        try:
            from urllib.parse import urlparse
            a_origin = urlparse(a_inp).netloc
            b_origin = urlparse(b_inp).netloc
            if a_origin and a_origin == b_origin:
                return True
        except Exception:
            pass
    # Match on assertion fields (covers page/existence/input assertions).
    # Both strict and non-strict modes require assertion_value to match exactly —
    # non-strict only skips the value check when both values are empty (state-only
    # assertions like "to be visible" that carry no value).
    a_nature = (a.get("assertion_nature") or "").strip().lower()
    b_nature = (b.get("assertion_nature") or "").strip().lower()
    a_atype = (a.get("assertion_type") or "").strip().lower()
    b_atype = (b.get("assertion_type") or "").strip().lower()
    if a_nature and a_nature == b_nature and a_atype and a_atype == b_atype:
        a_aval = (a.get("assertion_value") or "").strip()
        b_aval = (b.get("assertion_value") or "").strip()
        # Both empty → state-only assertion (to be visible, to be enabled, etc.) — match by nature+type
        if not a_aval and not b_aval:
            return True
        # One or both have a value → must match exactly to prevent cross-test value propagation
        if a_aval and b_aval and a_aval == b_aval:
            return True
    return False


def _is_assertion_step(step: dict) -> bool:
    """Return True if the step is a verification/assertion (not a journey action)."""
    return bool((step.get("assertion_nature") or "").strip())


def _nearest_journey_step(steps: list[dict], idx: int, direction: int = -1) -> dict | None:
    """Find the nearest non-assertion step at or before/after *idx*.

    *direction* -1 searches backward (for anchor_before), +1 searches forward (for anchor_after).
    """
    i = idx
    while 0 <= i < len(steps):
        if not _is_assertion_step(steps[i]):
            return steps[i]
        i += direction
    return None


def _count_old_steps_in_verified_prefix(old_steps: list, new_prefix: list) -> int:
    """Return how many old steps align to new_prefix using the same alignment
    logic as _extract_step_field_corrections.  Used to slice old_steps to the
    portion that corresponds to verified (passed) new steps."""
    old_i = 0
    new_i = 0
    while old_i < len(old_steps) and new_i < len(new_prefix):
        if _steps_match(old_steps[old_i], new_prefix[new_i]):
            old_i += 1
            new_i += 1
        else:
            found = False
            for look in range(new_i + 1, min(new_i + 6, len(new_prefix))):
                if _steps_match(old_steps[old_i], new_prefix[look]):
                    new_i = look
                    old_i += 1
                    new_i += 1
                    found = True
                    break
            if not found:
                old_act = (old_steps[old_i].get("action_taken") or "").strip().lower()
                new_act = (new_prefix[new_i].get("action_taken") or "").strip().lower()
                next_matches = (
                    old_i + 1 < len(old_steps)
                    and _steps_match(old_steps[old_i + 1], new_prefix[new_i])
                )
                if old_act and old_act == new_act and not next_matches:
                    old_i += 1
                    new_i += 1
                else:
                    new_i += 1
    return old_i


def _propagate_verified_changes(
    output_dir: str,
    current_file: str,
    old_json: str,
    new_json: str,
    test_files: list,
    current_index: int,
    verified_up_to: int | None,
    common_prefix_length: int | None = None,
) -> None:
    """Propagate insertions, selector corrections, and field corrections for
    steps that have been verified to pass in a real browser run.

    Scope guardrail — cross-test propagation is limited to the common-prefix
    window [0, common_prefix_length). Steps beyond the common prefix are
    considered test-specific: two different tests happening to share a single
    step description or selector does NOT mean they share that flow segment,
    and propagating a fix across them corrupts the sibling test. Changes to
    post-prefix steps are still persisted to the CURRENT test file via its
    own fix path; they just aren't broadcast to other files here.

    common_prefix_length — number of leading steps shared across all tests in
                           the batch. Pass None to disable the scope guard
                           (legacy behaviour), 0 to forbid all cross-test
                           propagation.

    verified_up_to — index of the failing step (exclusive upper bound).
                     Pass None or -1 to propagate all verified changes.
    """
    if not old_json or not new_json:
        return
    try:
        new_steps = json.loads(new_json).get("steps", [])
        old_steps = json.loads(old_json).get("steps", [])
    except Exception:
        return

    # Slice to only the verified portion of new_steps
    n_verified = len(new_steps) if (verified_up_to is None or verified_up_to < 0) else verified_up_to
    if n_verified <= 0:
        return

    # Further constrain propagation to the common-prefix window. Propagating
    # post-prefix changes across tests is the root cause of cross-test step
    # splicing (fixes bleeding from one test's middle into another's middle).
    if common_prefix_length is not None:
        n_verified = min(n_verified, max(0, common_prefix_length))
        if n_verified <= 0:
            return

    verified_new = new_steps[:n_verified]
    n_old = _count_old_steps_in_verified_prefix(old_steps, verified_new)
    verified_old = old_steps[:n_old]

    v_old_json = json.dumps({"steps": verified_old})
    v_new_json = json.dumps({"steps": verified_new})

    corrections = _extract_selector_corrections(v_old_json, v_new_json)
    if corrections:
        _propagate_selector_fixes(output_dir, current_file, corrections, test_files, current_index)

    field_corrections = _extract_step_field_corrections(v_old_json, v_new_json)
    if field_corrections:
        _propagate_field_corrections(output_dir, field_corrections, test_files, current_index)

    insertions = _extract_step_insertions(v_old_json, v_new_json)
    if insertions:
        _propagate_step_insertions(output_dir, insertions, test_files, current_index)


def _extract_step_insertions(old_json: str, new_json: str) -> list[dict]:
    """Detect steps that were inserted during a fix using a linear alignment.

    Anchors prefer journey (non-assertion) steps so that propagation works
    across tests with the same journey but different assertions.
    """
    try:
        old_steps = json.loads(old_json).get("steps", [])
        new_steps = json.loads(new_json).get("steps", [])
    except Exception:
        return []

    if len(new_steps) <= len(old_steps):
        return []

    insertions: list[dict] = []
    old_i = 0
    new_i = 0

    while new_i < len(new_steps):
        if old_i >= len(old_steps):
            insertions.append({
                "insert_after": old_i - 1, "step": new_steps[new_i],
                # Prefer journey-step anchors; fall back to any step
                "anchor_before_old": _nearest_journey_step(old_steps, old_i - 1, -1) or (old_steps[old_i - 1] if old_i > 0 else None),
                "anchor_before_new": _nearest_journey_step(new_steps, new_i - 1, -1) or (new_steps[new_i - 1] if new_i > 0 else None),
                "anchor_after": None,
            })
            new_i += 1
            continue

        if _steps_match(old_steps[old_i], new_steps[new_i]):
            old_i += 1
            new_i += 1
        else:
            insertions.append({
                "insert_after": old_i - 1, "step": new_steps[new_i],
                "anchor_before_old": _nearest_journey_step(old_steps, old_i - 1, -1) or (old_steps[old_i - 1] if old_i > 0 else None),
                "anchor_before_new": _nearest_journey_step(new_steps, new_i - 1, -1) or (new_steps[new_i - 1] if new_i > 0 else None),
                "anchor_after": _nearest_journey_step(old_steps, old_i, +1) or (old_steps[old_i] if old_i < len(old_steps) else None),
            })
            new_i += 1

    return insertions


def _propagate_step_insertions(
    output_dir: str,
    insertions: list[dict],
    test_files: list[str],
    current_index: int,
) -> int:
    """Insert new steps into remaining untested JSON step files.

    Structural-equivalence guard (prevents cross-test step splicing):

      * Both anchor_before AND anchor_after must be locatable in the target
        file and must sit at adjacent positions (anchor_after immediately
        follows anchor_before, allowing only assertion steps between them).
        This confirms the target truly has the same flow point — having a
        single anchor step alone is no longer sufficient, because the same
        step can appear in unrelated tests (e.g. "Click Sign in") without
        the surrounding flow being the same.

      * An anchor-before with no anchor-after (tail insertion) additionally
        requires the anchor-before to be the LAST journey step in the target,
        otherwise we'd splice into the middle of an unrelated flow.
    """
    if not insertions:
        return 0

    def _find_last(steps: list[dict], anchor: dict | None) -> int:
        if not anchor:
            return -1
        for si in range(len(steps) - 1, -1, -1):
            if _steps_match(steps[si], anchor, strict_assertion=True):
                return si
        return -1

    def _find_first(steps: list[dict], anchor: dict | None, start: int = 0) -> int:
        if not anchor:
            return -1
        for si in range(start, len(steps)):
            if _steps_match(steps[si], anchor, strict_assertion=True):
                return si
        return -1

    def _next_journey_idx(steps: list[dict], start: int) -> int:
        """Return the first journey-step index at or after *start* (or len(steps))."""
        i = start
        while i < len(steps) and _is_assertion_step(steps[i]):
            i += 1
        return i

    def _last_journey_idx(steps: list[dict]) -> int:
        for si in range(len(steps) - 1, -1, -1):
            if not _is_assertion_step(steps[si]):
                return si
        return -1

    modified_count = 0
    for filename in test_files[current_index + 1:]:
        filepath = Path(output_dir) / filename
        if not filepath.exists():
            continue
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
        except Exception:
            continue

        steps: list[dict] = data.get("steps", [])
        changed = False

        for ins in insertions:
            new_step = ins["step"]
            is_journey_insert = not _is_assertion_step(new_step)

            anchor_old = ins.get("anchor_before_old")
            anchor_new = ins.get("anchor_before_new")
            anchor_after = ins.get("anchor_after")

            # Locate the before-anchor in the target (prefer the new-world
            # anchor so propagation respects the most recent intent).
            before_pos = -1
            for anchor in (anchor_new, anchor_old):
                before_pos = _find_last(steps, anchor)
                if before_pos >= 0:
                    break

            if before_pos < 0 and (anchor_old or anchor_new):
                # Before-anchor exists in the source but not here — different flow.
                continue

            if anchor_after:
                # After-anchor MUST immediately follow the before-anchor
                # (allowing only assertion steps between them). This is the
                # key structural-equivalence check that prevents splicing
                # test-1 middle steps into test-2's middle.
                if before_pos < 0:
                    # No before-anchor — accept only if after-anchor is the
                    # very first journey step of the target.
                    after_pos = _find_first(steps, anchor_after)
                    if after_pos < 0:
                        continue
                    first_journey = _next_journey_idx(steps, 0)
                    if after_pos != first_journey:
                        continue
                    insert_pos = after_pos
                else:
                    expected_after = _next_journey_idx(steps, before_pos + 1)
                    if expected_after >= len(steps):
                        continue
                    if not _steps_match(steps[expected_after], anchor_after, strict_assertion=True):
                        # The step that SHOULD come after the anchor doesn't
                        # match — this target has diverging flow at this
                        # point. Skip to avoid corrupting it.
                        continue
                    insert_pos = expected_after
            else:
                # No after-anchor ⇒ tail-insertion. Require before-anchor to
                # be the last journey step in the target so we don't splice
                # into the middle of another flow that happens to start with
                # the same step.
                if before_pos < 0:
                    # Neither anchor matches — refuse.
                    continue
                last_journey = _last_journey_idx(steps)
                if before_pos != last_journey:
                    continue
                insert_pos = before_pos + 1

            # For journey-step insertions, skip past any assertion steps
            # that immediately follow the anchor so assertions stay grouped
            # with the step they verify and the new journey step goes after them.
            if is_journey_insert:
                while insert_pos < len(steps) and _is_assertion_step(steps[insert_pos]):
                    insert_pos += 1

            # Duplicate guard — skip if identical step near insertion point
            dup_found = False
            for si, s in enumerate(steps):
                if _steps_match(s, new_step, strict_assertion=True) and abs(si - insert_pos) <= 2:
                    dup_found = True
                    break
            if dup_found:
                continue

            steps.insert(insert_pos, new_step)
            changed = True

        if changed:
            data["steps"] = steps
            try:
                filepath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                modified_count += 1
            except Exception:
                pass

    return modified_count


# ── Step alignment for run_and_fix_test_case add/delete ───────────────────

_SYNTHETIC_GOTO_DESC = "Navigate to app (auto-prepended for local run)"


def _align_steps_for_diff(
    old_steps: list[dict],
    new_steps: list[dict],
) -> tuple[list[tuple[int, int]], list[tuple[int, dict]], list[tuple[int, dict]]]:
    """Align old and new step lists and classify each step as matched, inserted, or deleted.

    Returns:
        matched  — list of (old_index, new_index) pairs for steps present in both
        inserted — list of (new_index, step_dict) for steps only in new
        deleted  — list of (old_index, step_dict) for steps only in old
    """
    matched: list[tuple[int, int]] = []
    inserted: list[tuple[int, dict]] = []

    old_i = 0
    new_i = 0
    matched_old_indices: set[int] = set()

    while new_i < len(new_steps):
        if old_i >= len(old_steps):
            # Remaining new steps are all insertions
            inserted.append((new_i, new_steps[new_i]))
            new_i += 1
            continue

        if _steps_match(old_steps[old_i], new_steps[new_i]):
            matched.append((old_i, new_i))
            matched_old_indices.add(old_i)
            old_i += 1
            new_i += 1
        else:
            # Check if this new step matches any future old step (deletion scenario)
            found_old = False
            for lookahead in range(old_i + 1, min(old_i + 5, len(old_steps))):
                if _steps_match(old_steps[lookahead], new_steps[new_i]):
                    # Steps between old_i and lookahead were deleted
                    matched.append((lookahead, new_i))
                    matched_old_indices.add(lookahead)
                    old_i = lookahead + 1
                    new_i += 1
                    found_old = True
                    break

            if not found_old:
                # This new step has no match — it's an insertion
                inserted.append((new_i, new_steps[new_i]))
                new_i += 1

    # Any old steps not matched were deleted
    deleted: list[tuple[int, dict]] = [
        (i, old_steps[i]) for i in range(len(old_steps)) if i not in matched_old_indices
    ]

    return matched, inserted, deleted


def _propagate_selector_fixes(
    output_dir: str,
    current_file: str,
    corrections: list[tuple[str, str]],
    test_files: list[str],
    current_index: int,
) -> int:
    """Apply css_selector corrections to remaining untested JSON step files.

    Only modifies files that haven't been tested yet (index > current_index).
    Returns the number of files modified.
    """
    if not corrections:
        return 0

    modified_count = 0
    remaining_files = test_files[current_index + 1:]
    correction_map = dict(corrections)

    for filename in remaining_files:
        filepath = Path(output_dir) / filename
        if not filepath.exists():
            continue
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
        except Exception:
            continue

        steps = data.get("steps", [])
        changed = False
        for step in steps:
            sel = (step.get("css_selector") or "").strip()
            if sel in correction_map:
                step["css_selector"] = correction_map[sel]
                changed = True

        if changed:
            try:
                filepath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                modified_count += 1
            except Exception:
                pass

    return modified_count


# ---------------------------------------------------------------------------
# Common prefix optimization — phases 2a / 2b / 2c / 2d
# ---------------------------------------------------------------------------

_PREFIX_RETRIES = 4  # max LLM fix attempts per failing step in the prefix phase
_PREFIX_FILENAME = "_common_prefix.json"


def _detect_common_prefix(output_dir: str, test_files: list[str]) -> int:
    """Phase 2a — find the length of the shared step prefix across all test files.

    A position is part of the prefix only when *every* test has the same
    action_taken + css_selector + mock_input at that index.

    Returns 0 if fewer than 2 files exist or no common prefix is found.
    """
    if len(test_files) < 2:
        return 0

    all_steps: list[list[dict]] = []
    for filename in test_files:
        try:
            data = json.loads((Path(output_dir) / filename).read_text(encoding="utf-8"))
            steps = data.get("steps", [])
            if not steps:
                return 0  # Any empty test → no common prefix
            all_steps.append(steps)
        except Exception:
            return 0  # Unreadable file → skip optimization

    min_len = min(len(s) for s in all_steps)
    prefix_length = 0

    for i in range(min_len):
        ref = all_steps[0][i]
        ref_action = (ref.get("action_taken") or "").strip()
        ref_sel = (ref.get("css_selector") or "").strip()
        ref_input = (ref.get("mock_input") or "").strip()

        for steps in all_steps[1:]:
            s = steps[i]
            if (
                (s.get("action_taken") or "").strip() != ref_action
                or (s.get("css_selector") or "").strip() != ref_sel
                or (s.get("mock_input") or "").strip() != ref_input
            ):
                return prefix_length  # diverges here

        prefix_length += 1

    return prefix_length


def _apply_common_prefix_to_all_files(
    output_dir: str,
    test_files: list[str],
    corrected_steps: list[dict],
    prefix_length: int,
) -> int:
    """Phase 2c — replace the first *prefix_length* steps in every test file.

    Returns the number of files modified.
    """
    modified = 0
    for filename in test_files:
        filepath = Path(output_dir) / filename
        try:
            data = json.loads(filepath.read_text(encoding="utf-8"))
        except Exception:
            continue

        steps = data.get("steps", [])
        if len(steps) < prefix_length:
            continue  # file has fewer steps than prefix — skip safely

        data["steps"] = corrected_steps + steps[prefix_length:]
        try:
            filepath.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            modified += 1
        except Exception:
            pass

    return modified


def _assert_locked_steps_unchanged(
    original_steps: list[dict],
    new_steps: list[dict],
    lock_count: int,
) -> str | None:
    """Phase 2d lock — return a rejection reason if any locked prefix step was modified.

    Checks action_taken, css_selector, mock_input, and assertion fields.
    Returns None when all locked steps are intact.
    """
    _LOCKED_FIELDS = (
        "action_taken", "css_selector", "mock_input",
        "assertion_nature", "assertion_type", "assertion_value",
    )
    for i in range(min(lock_count, len(original_steps), len(new_steps))):
        orig = original_steps[i]
        new = new_steps[i]
        for field in _LOCKED_FIELDS:
            if (orig.get(field) or "").strip() != (new.get(field) or "").strip():
                return (
                    f"step {i + 1} (locked common-prefix step) was modified: "
                    f"field '{field}' changed from {orig.get(field)!r} to {new.get(field)!r}"
                )
    return None


async def _handle_common_prefix_phase(
    exec_store: "TestExecutionStore",
    exec_session_id: str,
    session: "TestExecutionSession",
    fixed_code: str | None,
) -> "list | None":
    """Drive phases 2a / 2b / 2c for the common prefix.

    Returns:
        None          — prefix phase complete (verified or skipped), caller continues normally.
        list[TextContent] — response to return to the LLM (failure or fix needed).
    """
    output_dir = session.output_dir
    test_files = session.test_files
    prefix_path = Path(output_dir) / _PREFIX_FILENAME

    # ── 2a: Detect prefix if not yet done ────────────────────────────────────
    if session.common_prefix_length == -1:
        # Old session mid-run (current_index > 0) should skip the prefix phase.
        if session.current_index > 0:
            exec_store.set_common_prefix(exec_session_id, 0, verified=True)
            return None

        prefix_length = _detect_common_prefix(output_dir, test_files)
        exec_store.set_common_prefix(exec_session_id, prefix_length)
        session = exec_store.get_session(exec_session_id)  # reload after mutation

        if prefix_length == 0:
            exec_store.set_common_prefix(exec_session_id, 0, verified=True)
            return None

        # Write the mini prefix test file (steps 0..prefix_length from file 0)
        try:
            source_data = json.loads(
                (Path(output_dir) / test_files[0]).read_text(encoding="utf-8")
            )
            prefix_data = {
                "name": "_common_prefix",
                "base_url": source_data.get("base_url", ""),
                "steps": source_data["steps"][:prefix_length],
            }
            prefix_path.write_text(
                json.dumps(prefix_data, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as e:
            # Can't write prefix file — skip optimization
            exec_store.set_common_prefix(exec_session_id, 0, verified=True)
            return None

    prefix_length = session.common_prefix_length

    # ── Apply fixed_code to the prefix file (2b fix loop) ───────────────────
    if fixed_code:
        try:
            fixed_data = json.loads(fixed_code)
            if not isinstance(fixed_data.get("steps"), list):
                raise ValueError("'steps' array is missing")
        except Exception as parse_err:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "phase": "common_prefix",
                "previousFixRejected": True,
                "rejectionReason": str(parse_err),
                "error": "fixed_code is not valid JSON — rejected without writing to disk.",
                "nextStep": (
                    "The fixed_code you provided is not valid JSON or is missing the 'steps' array. "
                    "Your retry budget was NOT consumed — fix the JSON and call again."
                ),
            }, indent=2))]

        try:
            prefix_path.write_text(
                json.dumps(fixed_data, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as e:
            return [TextContent(type="text", text=f"Error: could not write prefix fix: {e}")]

    # ── 2b: Run the prefix mini-test ─────────────────────────────────────────
    if not prefix_path.exists():
        # File missing — skip optimization
        exec_store.set_common_prefix(exec_session_id, 0, verified=True)
        return None

    # Escalate page_timeout for the prefix based on how many prefix fixes have
    # been attempted so far (prefix fix counts use "prefix:{step}" keys).
    _prefix_max_fixes = max(
        (v for k, v in session.step_fix_counts.items() if k.startswith("prefix:")),
        default=0,
    )
    run_result = await _run_test(
        output_dir,
        _PREFIX_FILENAME,
        headless=session.headless,
        exec_session_id=exec_session_id,
        skip_iframe_search=session.skip_iframe_search,
        page_timeout=_page_timeout_for_fix_count(_prefix_max_fixes),
    )

    if run_result["passed"]:
        # ── 2c: Prefix passed — propagate corrected steps to all test files ─
        try:
            corrected_data = json.loads(prefix_path.read_text(encoding="utf-8"))
            corrected_steps = corrected_data.get("steps", [])
        except Exception:
            corrected_steps = []

        files_updated = 0
        if corrected_steps:
            files_updated = _apply_common_prefix_to_all_files(
                output_dir, test_files, corrected_steps, len(corrected_steps)
            )

        exec_store.set_common_prefix(
            exec_session_id, prefix_length, steps=corrected_steps, verified=True
        )

        # Clean up the mini-test file
        try:
            prefix_path.unlink()
        except Exception:
            pass

        return None  # Prefix done — fall through to normal batch loop

    # ── Prefix failed — check per-step retry budget ───────────────────────────
    failed_step_idx = run_result.get("failed_step_index", -1)
    fix_count = (
        exec_store.increment_prefix_step_fix(exec_session_id, failed_step_idx)
        if failed_step_idx >= 0
        else 0
    )

    if fix_count > _PREFIX_RETRIES:
        # Budget exhausted — skip prefix optimization, proceed to normal loop
        exec_store.set_common_prefix(exec_session_id, 0, verified=True)
        try:
            prefix_path.unlink()
        except Exception:
            pass
        return None

    timed_out = "[TIMEOUT]" in run_result["logs"]
    fixes_left = _PREFIX_RETRIES - fix_count
    current_code = ""
    try:
        current_code = prefix_path.read_text(encoding="utf-8")
    except Exception:
        pass

    return [TextContent(type="text", text=json.dumps({
        "execSessionId": exec_session_id,
        "status": "timeout" if timed_out else "failed",
        "phase": "common_prefix",
        "message": (
            f"Fixing common prefix — {prefix_length} step(s) shared across all "
            f"{len(test_files)} tests. Once this passes, all test files are updated "
            "automatically before individual tests run."
        ),
        "commonPrefixLength": prefix_length,
        "currentTest": {
            "file": _PREFIX_FILENAME,
            "name": "Common Prefix",
            "total": len(test_files),
        },
        "failedStep": {
            "index": failed_step_idx,
            "fixAttempt": fix_count,
            "maxFixAttempts": _PREFIX_RETRIES,
            "fixesLeft": fixes_left,
        },
        "logs": _truncate_logs(run_result["logs"]),
        "elementInventory": run_result.get("element_inventory", ""),
        "failingStepVisible": run_result.get("failing_step_visible"),
        "currentCode": current_code,
        "fixInstructions": _fix_instructions(timed_out=timed_out),
        "nextStep": (
            f"Fix step {failed_step_idx + 1} in the common prefix and call with fixed_code. "
            f"You have {fixes_left} attempt(s) left. "
            "Once the prefix passes, all test files are updated and individual tests begin."
        ),
    }, indent=2))]


async def _capture_dom_snapshot(page) -> str:
    """Capture interactive elements from the live page for LLM fix context.

    Returns a structured element inventory with pre-computed stable selectors.
    Each entry shows the computed_selector to use directly in css_selector fields —
    no HTML parsing required.  Priority order: data-testid > data-cy >
    data-automation-id > aria-label > id (non-auto) > name > placeholder >
    text-based has-text().
    """
    try:
        elements = await page.evaluate(r"""
            () => {
                const INTERACTIVE_SEL = [
                    'input', 'button', 'a', 'select', 'textarea',
                    '[role="button"]', '[role="link"]', '[role="checkbox"]',
                    '[role="menuitem"]', '[role="tab"]', '[role="combobox"]',
                    '[role="radio"]', '[role="switch"]', '[role="option"]',
                    // Overlay / portal elements — modals, dropdowns, dialogs
                    '[role="dialog"]', '[role="alertdialog"]', '[role="listbox"]',
                    '[role="menu"]', '[role="tooltip"]', '[role="status"]',
                    // Explicit data-* automation attributes
                    '[data-testid]', '[data-cy]', '[data-automation-id]'
                ].join(', ');

                // Auto-generated ID patterns to skip (UUIDs, long numeric suffixes, react IDs)
                const AUTO_ID = /^(react-|r:|ember\d|__|\d{4,}$|[a-f0-9]{8}-[a-f0-9]{4})/i;

                const KEEP_ATTRS = [
                    'id', 'name', 'type', 'placeholder', 'aria-label',
                    'data-testid', 'data-cy', 'data-automation-id',
                    'role', 'href', 'value', 'for', 'aria-checked', 'aria-expanded'
                ];

                const isVisible = el => {
                    try {
                        const r = el.getBoundingClientRect();
                        const s = window.getComputedStyle(el);
                        return (
                            r.width > 0 && r.height > 0 &&
                            s.display !== 'none' &&
                            s.visibility !== 'hidden' &&
                            s.opacity !== '0'
                        );
                    } catch { return false; }
                };

                // Detect React fiber event handler key (varies by React version)
                const _reactFiberKey = Object.keys(document.body || {}).find(
                    k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalFiber')
                ) || null;
                const _reactEventsPrefix = '__reactEvents';

                const hasReactHandler = el => {
                    if (_reactFiberKey && el[_reactFiberKey]) {
                        // Walk the fiber to check for onClick
                        let fiber = el[_reactFiberKey];
                        while (fiber) {
                            const props = fiber.memoizedProps || fiber.pendingProps;
                            if (props && (props.onClick || props.onMouseDown || props.onPointerDown))
                                return true;
                            fiber = fiber.return;
                            // Stop at root to avoid infinite walk
                            if (fiber && fiber.tag === 3) break;
                        }
                    }
                    // Also check __reactEvents$... keys (React 17+ synthetic events)
                    return Object.keys(el).some(k => k.startsWith(_reactEventsPrefix));
                };

                const seen = new Set();

                // Pass 1: standard interactive selector
                const stdEls = [...document.querySelectorAll(INTERACTIVE_SEL)]
                    .filter(el => {
                        if (seen.has(el)) return false;
                        seen.add(el);
                        return isVisible(el);
                    });

                // Pass 2: div/span with React onClick handlers not already captured
                const reactClickEls = [...document.querySelectorAll('div, span')]
                    .filter(el => {
                        if (seen.has(el)) return false;
                        if (!isVisible(el)) return false;
                        if (!hasReactHandler(el)) return false;
                        seen.add(el);
                        return true;
                    });

                // Detect open modal/overlay containers — anything role=dialog,
                // aria-modal=true, or with data-automation-id containing 'modal'.
                // Background-layer elements (behind these overlays) are still useful
                // for the LLM to see, especially when targeting a row hidden under
                // a modal that hasn't closed yet.
                const _modalRoots = [...document.querySelectorAll(
                    '[role="dialog"], [aria-modal="true"], [data-automation-id*="modal" i]'
                )].filter(isVisible);

                const _isInsideModal = el => {
                    for (const m of _modalRoots) {
                        if (m.contains(el)) return true;
                    }
                    return false;
                };

                const _allEls = [...stdEls, ...reactClickEls];
                const _modalEls = [];
                const _bgEls = [];
                for (const e of _allEls) {
                    if (_isInsideModal(e)) _modalEls.push(e);
                    else _bgEls.push(e);
                }

                // Quota: when a modal is open, reserve at least 25 slots for
                // background-layer elements so test rows / notebook list stay
                // visible to the LLM. Otherwise use the full 80 for the page.
                const _hasModal = _modalRoots.length > 0;
                const _modalCap = _hasModal ? 55 : 80;
                const _bgCap = _hasModal ? 25 : 80;
                const _selected = [
                    ..._modalEls.slice(0, _modalCap),
                    ..._bgEls.slice(0, _bgCap),
                ];
                // Tag each element so the Python side can group them into
                // "modal layer" vs "background layer" sections.
                const _selectedSet = new Set(_selected);
                const els = _selected;
                const _layerOf = el => _isInsideModal(el) ? 'modal' : 'page';

                return els.map(el => {
                    const tag = el.tagName.toLowerCase();
                    // rawText: from innerText for human-readable display in the snapshot.
                    const rawText = (
                        el.innerText || el.value || el.textContent || ''
                    ).replace(/\s+/g, ' ').trim().slice(0, 60);

                    // selectorText: from textContent for has-text() selectors.
                    // Playwright's has-text() matches against textContent (normalized),
                    // NOT innerText. Using innerText here produces selectors with spaces
                    // where flex/grid CSS creates visual gaps — those spaces are not in
                    // textContent so the selector silently never matches.
                    const selectorText = (
                        el.value || el.textContent || ''
                    ).replace(/\s+/g, ' ').trim().slice(0, 60);

                    // When textContent has no internal whitespace, all text is split
                    // across child elements with no separator text nodes (e.g. flex cards
                    // with <div>L</div><span>App</span><span>url</span>).
                    // has-text on the concatenated string is ugly and fragile — instead
                    // find the longest single leaf child and use :has(:text-is()) on it.
                    const _buildHasText = (baseTag) => {
                        if (selectorText && !/\s/.test(selectorText)) {
                            const leaves = [...el.querySelectorAll('span, div, p, td, li')]
                                .filter(c => c.children.length === 0 && c.textContent.trim());
                            const best = leaves.sort(
                                (a, b) => b.textContent.trim().length - a.textContent.trim().length
                            )[0];
                            if (best) {
                                const leafText = best.textContent.trim().slice(0, 40);
                                return `${baseTag}:has(:text-is("${leafText}"))`;
                            }
                        }
                        return selectorText
                            ? `${baseTag}:has-text("${selectorText.slice(0, 40)}")`
                            : null;
                    };

                    const attrs = {};
                    for (const k of KEEP_ATTRS) {
                        const v = el.getAttribute(k);
                        if (v && v.trim()) attrs[k] = v.trim();
                    }

                    // Compute stable selector — priority order
                    let selector = null;

                    if (attrs['data-testid'])
                        selector = `[data-testid="${attrs['data-testid']}"]`;
                    else if (attrs['data-cy'])
                        selector = `[data-cy="${attrs['data-cy']}"]`;
                    else if (attrs['data-automation-id'])
                        selector = `[data-automation-id="${attrs['data-automation-id']}"]`;
                    else if (attrs['aria-label'])
                        selector = `[aria-label="${attrs['aria-label']}"]`;
                    else if (attrs['id'] && !AUTO_ID.test(attrs['id']))
                        selector = `#${attrs['id']}`;
                    else if (attrs['name'] && (tag === 'input' || tag === 'textarea' || tag === 'select'))
                        selector = `${tag}[name="${attrs['name']}"]`;
                    else if (attrs['type'] === 'submit' || (tag === 'button' && attrs['type'] === 'button'))
                        selector = _buildHasText('button') || `[type="${attrs['type']}"]`;
                    else if (attrs['placeholder'])
                        selector = `[placeholder="${attrs['placeholder']}"]`;
                    else if (attrs['type'] && tag === 'input')
                        selector = `input[type="${attrs['type']}"]`;
                    else if (selectorText && (tag === 'button' || tag === 'a'))
                        selector = _buildHasText(tag);
                    else if (selectorText && attrs['role'])
                        selector = `[role="${attrs['role']}"]:has-text("${selectorText.slice(0, 40)}")`;

                    return { tag, text: rawText, attrs, selector, layer: _layerOf(el) };
                });
            }
        """)

        if not elements:
            return "(no interactive elements found on page)"

        modal_els = [e for e in (elements or []) if e.get("layer") == "modal"]
        page_els = [e for e in (elements or []) if e.get("layer") != "modal"]
        has_modal = bool(modal_els)

        lines = [
            "=== INTERACTIVE ELEMENTS ON THIS PAGE ===",
            "Use 'computed_selector' directly as css_selector in your fix.",
            "Pick the most specific stable selector from this list.",
            "",
        ]

        def _render(group: list[dict], start_idx: int) -> int:
            idx = start_idx
            for el in group:
                tag = el.get("tag", "?")
                text = el.get("text", "")
                sel = el.get("selector") or "(fragile — use nth_appearance to disambiguate)"
                attrs = el.get("attrs", {})

                key_parts: list[str] = []
                for k in ("id", "name", "type", "placeholder", "aria-label",
                          "data-testid", "data-cy", "data-automation-id", "href", "role"):
                    v = attrs.get(k)
                    if v:
                        key_parts.append(f'{k}="{v}"')

                attr_str = "  attrs: " + ", ".join(key_parts) if key_parts else ""
                text_disp = f'  text:  "{text}"' if text else ""

                lines.append(f"[{idx:02d}] <{tag}>  computed_selector: {sel}")
                if attr_str:
                    lines.append(attr_str)
                if text_disp:
                    lines.append(text_disp)
                lines.append("")
                idx += 1
            return idx

        next_idx = 1
        if has_modal:
            lines.append("--- MODAL / DIALOG LAYER (topmost) ---")
            lines.append("")
            next_idx = _render(modal_els, next_idx)
            lines.append("--- BACKGROUND (PAGE) LAYER (beneath the modal) ---")
            lines.append(
                "These elements exist but are covered by the modal. Useful if the "
                "modal failed to close and you need to target what's behind it."
            )
            lines.append("")
            next_idx = _render(page_els, next_idx)
        else:
            next_idx = _render(page_els, next_idx)

        return "\n".join(lines)
    except Exception as exc:
        return f"(snapshot failed: {exc})"


def _validate_intent(
    current_steps: list[dict],
    original_plan_flow: dict | None,
    test_name: str,
) -> list[dict]:
    """Gate 3: Verify a passing test still implements its original plan intent.

    Checks that fixing failures didn't silently:
    - Drop assertions to make the test pass trivially
    - Remove steps that were part of the original scenario
    - Substitute a different (easier) flow

    Returns a list of intent violations. Empty list = intent preserved.
    """
    if not original_plan_flow or not isinstance(original_plan_flow, dict):
        return []

    issues: list[dict] = []

    # Check 1: Planned assertions are still present in current steps
    planned_assertions = original_plan_flow.get("assertions_planned") or []
    current_assertion_values = [
        (s.get("assertion_value") or "").strip().lower()
        for s in current_steps
        if isinstance(s, dict) and s.get("assertion_nature") and s.get("assertion_value")
    ]

    missing_assertions: list[str] = []
    for planned in planned_assertions:
        if not isinstance(planned, str):
            continue
        planned_lower = planned.lower().strip()
        covered = any(
            planned_lower in av or av in planned_lower
            for av in current_assertion_values if av
        )
        if not covered:
            missing_assertions.append(planned)

    if missing_assertions:
        issues.append({
            "issueType": "intent_assertion_dropped",
            "testName": test_name,
            "description": (
                f"Test passes but planned assertions are no longer present: {missing_assertions}. "
                "These were dropped during fixing, making the test pass trivially."
            ),
            "instruction": (
                "Restore the missing assertions. The test must verify the outcome, not just run steps. "
                "Add assertion steps for each item listed above."
            ),
        })

    # Check 2: Minimum step count vs planned journey
    planned_journey = original_plan_flow.get("user_journey_steps") or []
    if planned_journey and len(current_steps) < len(planned_journey) * 0.4:
        issues.append({
            "issueType": "intent_steps_gutted",
            "testName": test_name,
            "description": (
                f"Test passes but has only {len(current_steps)} steps "
                f"vs {len(planned_journey)} planned — more than 60% were removed during fixing."
            ),
            "instruction": (
                "Restore the removed steps. The fix should correct individual failing steps, "
                "not gut the test to make it trivially pass."
            ),
        })

    return issues


async def _dismiss_overlays(page) -> None:
    """Silently dismiss cookie banners, GDPR consent dialogs, and blocking modals.

    Uses a single JS evaluation for speed — no per-selector Python awaits.
    Called after page navigation steps so overlays don't block subsequent interactions.
    Non-fatal: all exceptions are swallowed.
    """
    try:
        dismissed = await page.evaluate("""
            () => {
                // Priority 1: Known cookie/consent IDs and data attributes
                const consentSelectors = [
                    '#onetrust-accept-btn-handler',
                    '#accept-cookies', '#cookie-accept', '#acceptCookies',
                    '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
                    '[data-testid="cookie-accept"]', '[data-testid="accept-cookies"]',
                    '[aria-label="Accept cookies"]', '[aria-label="Accept all cookies"]',
                    '.cookie-accept', '.cc-accept', '.js-accept-cookies',
                ];
                for (const sel of consentSelectors) {
                    const el = document.querySelector(sel);
                    if (el && el.offsetParent !== null) { el.click(); return 'consent'; }
                }

                // Priority 2: Buttons with exact cookie-accept text inside overlay containers
                const cookieTexts = [
                    'Accept All Cookies', 'Accept All', 'Accept Cookies',
                    'Allow All Cookies', 'Allow All', 'I Accept', 'Agree', 'Got it',
                ];
                const overlayRoots = document.querySelectorAll(
                    '[role="dialog"], [role="alertdialog"], ' +
                    '[class*="cookie" i], [class*="consent" i], [class*="gdpr" i], ' +
                    '[class*="banner" i], [class*="overlay" i], [class*="popup" i]'
                );
                for (const root of overlayRoots) {
                    const btns = root.querySelectorAll('button, [role="button"], a');
                    for (const btn of btns) {
                        const text = (btn.textContent || '').trim();
                        if (cookieTexts.includes(text) && btn.offsetParent !== null) {
                            btn.click(); return 'overlay-text';
                        }
                    }
                }

                // Priority 2.5: Non-interactive nuisance overlays — feedback/NPS
                // prompts, "What's new" announcements, onboarding tours. These
                // appear unpredictably and steal focus from tested elements but
                // are NOT what the test wants to interact with. We only dismiss
                // when the overlay root has a clear topical marker (feedback,
                // nps, announcement, whatsnew, onboarding, tour, tooltip) AND
                // a close / dismiss / skip control is available.
                const nuisanceRootSelectors = [
                    '[class*="feedback" i]', '[id*="feedback" i]',
                    '[aria-label*="feedback" i]',
                    '[class*="nps" i]', '[id*="nps" i]',
                    '[class*="announcement" i]', '[class*="whatsnew" i]',
                    '[class*="what-s-new" i]', '[class*="whats-new" i]',
                    '[class*="onboarding" i]', '[class*="tour" i]',
                    '[class*="product-tour" i]', '[class*="walkthrough" i]',
                    '[class*="tooltip" i][role="dialog"]',
                    '[class*="pendo" i]',  // Pendo tour/feedback
                    '[class*="intercom" i]',  // Intercom launcher messages
                    '[class*="appcues" i]',  // Appcues flows
                ];
                const nuisanceCloseAttrs = [
                    'button[aria-label="Close feedback"]',
                    'button[aria-label="Close" i]',
                    'button[aria-label="Dismiss" i]',
                    'button[aria-label="Skip" i]',
                    'button[aria-label="No thanks" i]',
                    'button[aria-label="Not now" i]',
                    'button[aria-label="Maybe later" i]',
                    'button[aria-label*="close" i]',
                    'button[aria-label*="dismiss" i]',
                    '[data-testid*="close" i]',
                    '[data-testid*="dismiss" i]',
                    '.close', '.btn-close', '[class*="closeButton" i]',
                ];
                const nuisanceTextButtons = [
                    'No thanks', 'Not now', 'Maybe later', 'Skip', 'Skip tour',
                    'Dismiss', 'Close', 'Later', 'Remind me later',
                ];
                for (const rootSel of nuisanceRootSelectors) {
                    const roots = document.querySelectorAll(rootSel);
                    for (const root of roots) {
                        if (!root || root.offsetParent === null) continue;
                        // Guard: don't dismiss roots that contain form inputs —
                        // those are likely real product modals the test wants.
                        if (root.querySelector('input:not([type="hidden"]):not([type="button"]):not([type="submit"]), textarea, select')) {
                            continue;
                        }
                        // Try attribute-based close first.
                        for (const sel of nuisanceCloseAttrs) {
                            const btn = root.querySelector(sel);
                            if (btn && btn.offsetParent !== null) {
                                btn.click(); return 'nuisance-' + rootSel;
                            }
                        }
                        // Fallback: text-match a dismiss-style button inside.
                        const btns = root.querySelectorAll('button, [role="button"], a');
                        for (const btn of btns) {
                            const text = (btn.textContent || '').trim();
                            if (nuisanceTextButtons.includes(text) && btn.offsetParent !== null) {
                                btn.click(); return 'nuisance-text';
                            }
                        }
                    }
                }

                // Priority 3: Close button inside dialog/modal (non-cookie modals)
                const closeSelectors = [
                    '[role="dialog"] button[aria-label="Close"]',
                    '[role="dialog"] button[aria-label="close"]',
                    '[role="dialog"] button[aria-label="Dismiss"]',
                    '[role="dialog"] button[aria-label="Close feedback"]',
                    '[role="alertdialog"] button[aria-label="Close"]',
                    '.modal button[aria-label="Close"]', '.modal .close',
                    '.modal-close', '.popup-close', '.dialog-close',
                    '[class*="Modal"] [class*="close" i]',
                    '[class*="Overlay"] [class*="close" i]',
                    '[class*="Dialog"] [class*="close" i]',
                ];
                for (const sel of closeSelectors) {
                    const el = document.querySelector(sel);
                    if (el && el.offsetParent !== null) {
                        // Same safety check: skip if this dialog contains
                        // form inputs (likely a real product modal).
                        const dlg = el.closest('[role="dialog"], .modal, [class*="Modal"]');
                        if (dlg && dlg.querySelector('input:not([type="hidden"]):not([type="button"]):not([type="submit"]), textarea, select')) {
                            continue;
                        }
                        el.click(); return 'close';
                    }
                }

                return null;
            }
        """)
        if dismissed:
            await page.wait_for_timeout(400)  # allow overlay animation to complete
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Browser pool — reuse a single browser process across all tests in a session.
# Each test run gets a fresh BrowserContext (clean cookies / localStorage / state).
# ---------------------------------------------------------------------------

import threading as _pool_threading

_browser_pool: dict[str, Any] = {}  # exec_session_id → Browser instance
_playwright_pool: dict[str, Any] = {}  # exec_session_id → Playwright context manager
_pool_lock = _pool_threading.Lock()


async def _get_or_launch_browser(exec_session_id: str, headless: bool = True):
    """Return a shared Browser for *exec_session_id*, launching one if needed.

    The browser is cached in ``_browser_pool`` and reused for every test run
    within the same execution session.  Only the first call pays the startup cost.
    """
    with _pool_lock:
        if exec_session_id in _browser_pool:
            browser = _browser_pool[exec_session_id]
            if browser.is_connected():
                return browser
            # Browser died — clean up stale entry and re-launch below
            _browser_pool.pop(exec_session_id, None)
            _playwright_pool.pop(exec_session_id, None)

    from playwright.async_api import async_playwright

    pw_cm = async_playwright()
    pw = await pw_cm.start()
    browser = await pw.chromium.launch(headless=headless)

    with _pool_lock:
        _playwright_pool[exec_session_id] = (pw_cm, pw)
        _browser_pool[exec_session_id] = browser

    return browser


async def _close_browser_pool(exec_session_id: str) -> None:
    """Shut down the pooled browser for *exec_session_id* and free resources."""
    with _pool_lock:
        browser = _browser_pool.pop(exec_session_id, None)
        pw_tuple = _playwright_pool.pop(exec_session_id, None)

    if browser:
        try:
            await browser.close()
        except Exception:
            pass
    if pw_tuple:
        pw_cm, pw = pw_tuple
        try:
            await pw_cm.__aexit__(None, None, None)
        except Exception:
            pass


# ─── Auth / URL state cache for skip-to-failure ──────────────────────────────
# Keyed by exec_session_id.  Stores cookies + URL recorded after login, so
# retries can skip login and navigate directly to the failure point.
_skip_state_cache: dict[str, dict] = {}
# {exec_session_id: {"cookies": [...], "step_urls": {step_idx: url}, "login_end": int}}


async def _run_test(output_dir: str, test_filename: str, timeout: int = 120, headless: bool = True, exec_session_id: str | None = None, skip_iframe_search: bool = True, page_timeout: int = 8000, skip_to_step: int = 0, app_path: str | None = None) -> dict[str, Any]:
    """Run a JSON step file using the in-process Mirabilis Playwright engine.

    Loads the step file, creates a *fresh* browser context (clean cookies,
    localStorage, sessionStorage) on a shared browser instance, and executes
    each step via execute_step.  Per-step results are logged.  A DOM snapshot
    is captured on failure.

    When *exec_session_id* is provided the browser is reused across calls via
    ``_browser_pool``, avoiding the ~5 s launch overhead on every run/retry.

    When *skip_to_step* > 0 AND saved auth cookies exist, creates a context
    with injected cookies, navigates to the saved URL, and begins execution
    from that step — skipping login and navigation replay.  Falls back to
    full replay if the skip fails.
    """
    from maeris_mcp.tools.step_executor import execute_step

    test_path = Path(output_dir) / test_filename
    log_file = Path(output_dir) / "logs.txt"

    # Write run header and record byte offset so we can isolate this run's output
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    separator = "=" * 60
    header = f"\n{separator}\n=== TEST: {test_filename} | {timestamp} ===\n{separator}\n"
    try:
        with open(log_file, "a", encoding="utf-8") as lf:
            lf.write(header)
            lf.flush()
        output_start = log_file.stat().st_size
    except Exception:
        output_start = 0

    logs_collected: list[str] = []
    timed_out = False
    passed = False
    # Mutable holder so the nested _execute_all_steps closure can write the
    # DOM snapshot back to the outer scope without changing the return tuple.
    _dom_snapshot_holder: list[str] = [""]
    # Holds whether the failing step's css_selector was visible on the live page.
    # None = not checked (no failure or no selector); True/False = is_visible result.
    _failing_step_visible_holder: list = [None]
    failed_step_index = -1
    ambiguous_info: list[dict] = []

    try:
        # ── Obtain browser (pooled when exec_session_id is set) ──────────
        if exec_session_id:
            browser = await _get_or_launch_browser(exec_session_id, headless=headless)
            owns_browser = False  # pool owns the lifecycle
        else:
            # Fallback for standalone calls without a session
            from playwright.async_api import async_playwright
            _pw_cm = async_playwright()
            _pw = await _pw_cm.start()
            browser = await _pw.chromium.launch(headless=headless)
            owns_browser = True

        data = json.loads(test_path.read_text(encoding="utf-8"))
        steps = data.get("steps", [])
        base_url = data.get("base_url", "")
        test_name_str = data.get("name", test_filename)
        logs_collected.append(f"Running: {test_name_str}")
        logs_collected.append(f"Steps: {len(steps)}")

        # ── Helper: run all steps in a fresh context, return result ────────
        async def _execute_all_steps(
            step_list: list[dict],
            _skip_from: int = 0,
        ) -> tuple[bool, bool, int, list[str], list[dict], object]:
            """Run steps in a fresh browser context.

            When _skip_from > 0 AND cached auth cookies exist, the context
            is initialised with those cookies and navigated to the URL
            recorded at that step — skipping login and earlier navigation.
            Falls back to full replay if the skip navigation fails.

            Returns: (all_passed, timed_out, failed_step_index,
                      logs, ambiguous_steps_info, last_page)
            ambiguous_steps_info: list of dicts with keys
                {step_index, match_count, css_selector, nth_used}
            """
            # ── Skip logic: inject saved auth cookies to avoid re-login ─────
            # Two modes:
            #   A) _skip_from > 0 (retry): jump to the step before failure.
            #   B) _skip_from == 0 (fresh test): if saved cookies exist from
            #      a previous test in the same session, skip the login steps
            #      by navigating to the first post-login URL.
            #
            # skip_works flag: None = untested, True = confirmed working,
            # False = confirmed broken (e.g. IndexedDB/OAuth auth). Once False,
            # cookie injection is never attempted again for this session —
            # avoiding the 500ms navigation cost on every subsequent retry.
            _actual_start = 0
            _skip_state = _skip_state_cache.get(exec_session_id or "", {})
            _saved_cookies = _skip_state.get("cookies", [])
            _saved_urls = _skip_state.get("step_urls", {})
            _login_end_idx = _skip_state.get("login_end", -1)
            _skip_works = _skip_state.get("skip_works", None)  # None = untested

            # Determine the resume URL and target start step
            _resume_url = ""
            _target_start = 0
            if _skip_works is not False:
                if _skip_from > 0 and _saved_cookies and str(_skip_from - 1) in _saved_urls:
                    # Mode A: retry — jump to failure point
                    _resume_url = _saved_urls[str(_skip_from - 1)]
                    _target_start = _skip_from
                elif _skip_from == 0 and _saved_cookies and _login_end_idx >= 0:
                    # Mode B: fresh test — skip login steps only.
                    # Find the first go_to step AFTER login in this test's steps
                    # (the first navigation after the login sequence).
                    for _si, _ss in enumerate(step_list):
                        if _si <= _login_end_idx:
                            continue
                        _sa = (_ss.get("action_taken") or "").lower()
                        if _sa == "go_to" and _ss.get("mock_input"):
                            _resume_url = _ss["mock_input"]
                            _target_start = _si  # start from this go_to step
                            break
                    if not _resume_url and _login_end_idx + 1 < len(step_list):
                        # No explicit go_to after login — use the saved URL at login_end
                        _resume_url = _saved_urls.get(str(_login_end_idx), "")
                        _target_start = _login_end_idx + 1

            if _target_start > 0 and _saved_cookies and _resume_url:
                ctx = await browser.new_context()
                pg = await ctx.new_page()
                try:
                    await ctx.add_cookies(_saved_cookies)
                    await pg.goto(_resume_url, wait_until="domcontentloaded", timeout=12000)
                    await pg.wait_for_timeout(500)
                    _cur_url = pg.url
                    if "/login" not in _cur_url.lower() and "/signin" not in _cur_url.lower():
                        _actual_start = _target_start
                        # Mark skip as confirmed working for this session
                        if exec_session_id and _skip_works is None:
                            _skip_state_cache[exec_session_id]["skip_works"] = True
                    else:
                        # Auth cookies didn't work — redirect to login.
                        # Mark as incompatible so we never try again this session.
                        if exec_session_id:
                            _skip_state_cache.setdefault(exec_session_id, {})["skip_works"] = False
                        await ctx.close()
                        ctx = await browser.new_context()
                        pg = await ctx.new_page()
                except Exception:
                    if exec_session_id:
                        _skip_state_cache.setdefault(exec_session_id, {})["skip_works"] = False
                    try:
                        await ctx.close()
                    except Exception:
                        pass
                    ctx = await browser.new_context()
                    pg = await ctx.new_page()
            else:
                ctx = await browser.new_context()
                pg = await ctx.new_page()

            last_pg = pg
            _logs: list[str] = []
            _ambiguous: list[dict] = []
            _failed_idx = -1
            _all_ok = True
            _timed_out = False

            if _actual_start > 0:
                _logs.append(
                    f"[SKIP-TO-STEP] Skipped steps 1–{_actual_start} using saved auth cookies. "
                    f"Resuming from step {_actual_start + 1}."
                )

            try:
                _prev_action = ""  # track previous step's action for post-click retry
                _login_url = ""    # detect login URL for cookie saving
                _step_url_map: dict[str, str] = {}  # step index → URL after step passes

                for i, step in enumerate(step_list):
                    if i < _actual_start:
                        continue  # skip already-covered steps
                    step_desc = step.get("description") or f"Step {i + 1}"
                    wait_before_ms = int(step.get("wait_before") or 0)
                    wait_after_ms = int(step.get("wait_after") or 0)
                    step_action = (step.get("action_taken") or "").lower()
                    try:
                        if wait_before_ms > 0:
                            await pg.wait_for_timeout(wait_before_ms)
                        status, msg, last_pg, step_match_count = await asyncio.wait_for(
                            execute_step(pg, step, skip_iframe_search=skip_iframe_search, page_timeout=page_timeout),
                            timeout=timeout,
                        )
                        if wait_after_ms > 0:
                            await pg.wait_for_timeout(wait_after_ms)

                        # Track ambiguous selectors for retry logic
                        if step_match_count > 1:
                            _ambiguous.append({
                                "step_index": i,
                                "match_count": step_match_count,
                                "css_selector": step.get("css_selector") or "",
                                "nth_used": int(step.get("nth_appearance") or 0),
                            })
                        # Dismiss cookie banners / modals after navigation steps
                        if step_action in ("go_to", "click"):
                            await _dismiss_overlays(last_pg)
                        log_line = f"[{status.upper()}] {step_desc}: {msg}"
                        _logs.append(log_line)

                        if status not in ("pass", "ok"):
                            _is_not_found = "not found" in msg.lower() or "not visible" in msg.lower()
                            _recovered = False

                            # ── Recovery 1: Post-click retry — portal may not
                            # have mounted yet after the previous click.
                            if not _recovered and _prev_action == "click" and _is_not_found:
                                _logs.append(
                                    f"[POST-CLICK-RETRY] Previous step was a click — "
                                    f"waiting 1.2 s for portal/overlay to mount and retrying..."
                                )
                                await pg.wait_for_timeout(1200)
                                status2, msg2, last_pg, step_match_count2 = await asyncio.wait_for(
                                    execute_step(pg, step, skip_iframe_search=skip_iframe_search, page_timeout=page_timeout),
                                    timeout=timeout,
                                )
                                log_line2 = f"[{status2.upper()}] {step_desc} (retry): {msg2}"
                                _logs.append(log_line2)
                                if status2 in ("pass", "ok"):
                                    if step_match_count2 > 1:
                                        _ambiguous.append({
                                            "step_index": i,
                                            "match_count": step_match_count2,
                                            "css_selector": step.get("css_selector") or "",
                                            "nth_used": int(step.get("nth_appearance") or 0),
                                        })
                                    _recovered = True

                            if _recovered:
                                _prev_action = step_action
                                continue

                            _all_ok = False
                            _failed_idx = i
                            break
                    except asyncio.TimeoutError:
                        _timed_out = True
                        _logs.append(f"[TIMEOUT] {step_desc}: exceeded {timeout}s")
                        _all_ok = False
                        _failed_idx = i
                        break
                    except Exception as exc:
                        _logs.append(f"[ERROR] {step_desc}: {type(exc).__name__}: {exc}")
                        _all_ok = False
                        _failed_idx = i
                        break

                    _prev_action = step_action

                    # ── Save URL at each passing step for skip-to-failure ──
                    try:
                        _step_url_map[str(i)] = last_pg.url
                    except Exception:
                        pass
                    # ── Save auth cookies once after login completes ──
                    # Detect login end: a go_to step to a login-like URL
                    # followed by a URL change away from it.
                    if step_action == "go_to" and not _login_url:
                        _mock = (step.get("mock_input") or "").lower()
                        if "login" in _mock or "signin" in _mock or "sign-in" in _mock:
                            _login_url = _mock
                    if _login_url and exec_session_id:
                        try:
                            _cur = last_pg.url.lower()
                            if _login_url and "login" not in _cur and "signin" not in _cur:
                                # We've navigated away from login — save cookies
                                _cookies = await ctx.cookies()
                                if _cookies:
                                    _skip_state_cache[exec_session_id] = {
                                        "cookies": _cookies,
                                        "step_urls": _step_url_map,
                                        "login_end": i,
                                    }
                                _login_url = ""  # only save once
                        except Exception:
                            pass

                # ── Update skip cache with step URLs after every run ──
                if exec_session_id and _step_url_map:
                    _existing = _skip_state_cache.get(exec_session_id, {})
                    _existing.setdefault("step_urls", {}).update(_step_url_map)
                    _skip_state_cache[exec_session_id] = _existing

                # DOM snapshot on failure — also written to outer holder so
                # _phase2_run_loop can include it as a structured field.
                # Captured on BOTH regular failures and timeouts so the LLM
                # always has context about what's on the page.
                if not _all_ok:
                    try:
                        # Brief wait to let React portals, overlays, and
                        # async-rendered content (dropdowns, modals, toasts)
                        # mount after the last action.  Without this, portaled
                        # content that renders outside the main DOM tree is
                        # invisible to the snapshot.
                        try:
                            await last_pg.wait_for_timeout(600)
                        except Exception:
                            pass
                        snapshot = await _capture_dom_snapshot(last_pg)
                        _logs.append(f"\n--- DOM SNAPSHOT ---\n{snapshot}")
                        _dom_snapshot_holder[0] = snapshot
                    except Exception:
                        pass

                    # Targeted visibility check for the specific failing selector.
                    # Uses Playwright's is_visible() — no element cap, checks exactly
                    # whether the failing step's element is currently visible/interactable.
                    if _failed_idx >= 0 and _failed_idx < len(step_list):
                        _fail_sel = (step_list[_failed_idx].get("css_selector") or "").strip()
                        if _fail_sel:
                            try:
                                _failing_step_visible_holder[0] = await last_pg.is_visible(_fail_sel)
                            except Exception:
                                pass
            finally:
                try:
                    await ctx.close()
                except Exception:
                    pass

            return _all_ok, _timed_out, _failed_idx, _logs, _ambiguous, last_pg

        # ── Primary run ───────────────────────────────────────────────────────
        try:
            all_passed, timed_out, failed_step_index, run_logs, ambiguous_info, last_page = (
                await _execute_all_steps(steps, _skip_from=skip_to_step)
            )
            logs_collected.extend(run_logs)

            # ── Persist resolved nth_appearance values ────────────────────────
            # execute_step() mutates step dicts in-place when _pick_best_visible
            # picks a different nth than the stored nth_appearance. Write the
            # updated steps back to disk so that Maeris / cloud runs use the
            # same winning nth (mirrors the write in the AMBIGUOUS-RETRY block).
            if all_passed:
                try:
                    data["steps"] = steps
                    test_path.write_text(
                        json.dumps(data, indent=2, ensure_ascii=False),
                        encoding="utf-8",
                    )
                except Exception:
                    pass

            # ── Ambiguous-selector retry ──────────────────────────────────────
            # When a step fails and a *prior* step had multiple selector
            # matches, the failure may be caused by clicking the wrong
            # element.  Instead of blindly trying all nth values, we first
            # probe which candidates are visible+enabled and only retry those.
            if not all_passed and not timed_out and ambiguous_info:
                # Find the last ambiguous step that is *before* the failed step
                retry_candidates = [
                    a for a in ambiguous_info if a["step_index"] < failed_step_index
                ]
                if retry_candidates:
                    amb = retry_candidates[-1]
                    amb_idx = amb["step_index"]
                    amb_count = amb["match_count"]
                    amb_nth_used = amb["nth_used"]
                    amb_selector = amb["css_selector"]

                    logs_collected.append(
                        f"\n[AMBIGUOUS-RETRY] Step {amb_idx + 1} matched {amb_count} elements "
                        f"(selector: {amb_selector!r}, used nth={amb_nth_used}). "
                        f"Probing for visible+enabled alternatives..."
                    )

                    # ── Probe: replay up to the ambiguous step, then check
                    # which nth candidates are visible+enabled on the live page.
                    viable_nths: list[int] = []
                    try:
                        probe_ctx = await browser.new_context()
                        probe_pg = await probe_ctx.new_page()
                        try:
                            # Replay steps before the ambiguous one to reach the right page state
                            for pi in range(amb_idx):
                                p_step = steps[pi]
                                p_wait = int(p_step.get("wait_before") or 0)
                                if p_wait > 0:
                                    await probe_pg.wait_for_timeout(p_wait)
                                _s, _m, probe_pg, _mc = await asyncio.wait_for(
                                    execute_step(probe_pg, p_step, skip_iframe_search=skip_iframe_search, page_timeout=page_timeout),
                                    timeout=timeout,
                                )
                                p_action = (p_step.get("action_taken") or "").lower()
                                if p_action in ("go_to", "click"):
                                    await _dismiss_overlays(probe_pg)

                            # Now probe each nth candidate on the live page
                            from maeris_mcp.tools.locator_engine import escape_css_selector, _try_css_locator
                            escaped_sel, _sel_nth = escape_css_selector(amb_selector)
                            if escaped_sel:
                                probe_loc, probe_count, _err = await _try_css_locator(
                                    probe_pg, escaped_sel, 5000
                                )
                                if probe_loc and probe_count > 1:
                                    for ci in range(probe_count):
                                        candidate = probe_loc.nth(ci)
                                        try:
                                            is_vis = await candidate.is_visible()
                                            if not is_vis:
                                                continue
                                            try:
                                                is_en = await candidate.is_enabled()
                                            except Exception:
                                                is_en = True
                                            if is_en and ci != amb_nth_used:
                                                viable_nths.append(ci)
                                        except Exception:
                                            continue
                        finally:
                            try:
                                await probe_ctx.close()
                            except Exception:
                                pass
                    except Exception as probe_exc:
                        logs_collected.append(f"[AMBIGUOUS-RETRY] Probe failed: {probe_exc}")

                    _per_nth_outcomes: list[tuple[int, str, int | None]] = []
                    if not viable_nths:
                        logs_collected.append(
                            "[AMBIGUOUS-RETRY] No visible+enabled alternatives found. "
                            "Skipping retry."
                        )
                    else:
                        logs_collected.append(
                            f"[AMBIGUOUS-RETRY] Found {len(viable_nths)} viable alternative(s): "
                            f"nth={viable_nths}. Retrying..."
                        )

                        for try_nth in viable_nths:
                            # Build a modified step list with the new nth_appearance
                            modified_steps = []
                            for si, s in enumerate(steps):
                                if si == amb_idx:
                                    s_copy = dict(s)
                                    s_copy["nth_appearance"] = try_nth
                                    modified_steps.append(s_copy)
                                else:
                                    modified_steps.append(s)

                            logs_collected.append(
                                f"[AMBIGUOUS-RETRY] Trying nth={try_nth} for step {amb_idx + 1}..."
                            )

                            (
                                retry_passed, retry_timed_out, retry_failed_idx,
                                retry_logs, _retry_amb, last_page,
                            ) = await _execute_all_steps(modified_steps)

                            if retry_passed:
                                logs_collected.append(
                                    f"[AMBIGUOUS-RETRY] nth={try_nth} PASSED — "
                                    f"updating step {amb_idx + 1} nth_appearance to {try_nth}"
                                )
                                logs_collected.extend(retry_logs)
                                _per_nth_outcomes.append((try_nth, "passed", None))
                                # Persist the fix: update the step in-place and on disk
                                steps[amb_idx]["nth_appearance"] = try_nth
                                try:
                                    data["steps"] = steps
                                    test_path.write_text(
                                        json.dumps(data, indent=2, ensure_ascii=False),
                                        encoding="utf-8",
                                    )
                                except Exception:
                                    pass
                                all_passed = True
                                timed_out = False
                                failed_step_index = -1
                                break
                            else:
                                # Report how far nth got — reaching a later step than
                                # the original failure means nth=X is a more promising
                                # candidate even though it ultimately failed.
                                if retry_failed_idx > amb_idx:
                                    logs_collected.append(
                                        f"[AMBIGUOUS-RETRY] nth={try_nth} advanced past "
                                        f"ambiguous step {amb_idx + 1}, failed at step "
                                        f"{retry_failed_idx + 1} (root cause selector is on "
                                        f"step {amb_idx + 1} — fix that step, not step "
                                        f"{retry_failed_idx + 1})"
                                    )
                                else:
                                    logs_collected.append(
                                        f"[AMBIGUOUS-RETRY] nth={try_nth} failed at step "
                                        f"{retry_failed_idx + 1} (same as original ambiguous step)"
                                    )
                                _per_nth_outcomes.append(
                                    (try_nth, "failed", retry_failed_idx + 1)
                                )

                        if not all_passed:
                            # Summary line so the LLM can see every nth attempted and
                            # which one reached furthest — useful to pick a different
                            # selector strategy next round.
                            if _per_nth_outcomes:
                                summary_parts = [
                                    f"nth={n}:{r}"
                                    + (f"@step{idx}" if idx is not None else "")
                                    for n, r, idx in _per_nth_outcomes
                                ]
                                logs_collected.append(
                                    "[AMBIGUOUS-RETRY] Per-nth outcomes: "
                                    + ", ".join(summary_parts)
                                )
                            logs_collected.append(
                                "[AMBIGUOUS-RETRY] All visible alternatives failed. "
                                "Reporting original failure."
                            )

            passed = all_passed
        finally:
            # Only close the browser when we launched it ourselves (no pool)
            if owns_browser:
                try:
                    await browser.close()
                    await _pw_cm.__aexit__(None, None, None)
                except Exception:
                    pass

    except asyncio.TimeoutError:
        timed_out = True
        logs_collected.append(f"[TIMEOUT] Test exceeded {timeout}s limit")
    except Exception as exc:
        logs_collected.append(f"RESULT: ERROR\n  Exception -> {type(exc).__name__}: {exc}")

    captured = "\n".join(logs_collected)

    # Write captured output to log file
    try:
        with open(log_file, "a", encoding="utf-8") as lf:
            lf.write(captured + "\n")
    except Exception:
        pass

    current_logs = _read_from(log_file, output_start)
    _append_footer(log_file, test_filename, timed_out=timed_out)

    if timed_out:
        return {
            "passed": False,
            "logs": f"[TIMEOUT] Test exceeded {timeout}s limit\n{current_logs}".strip(),
            "return_code": -1,
            "failed_step_index": failed_step_index,
            "ambiguous_steps": ambiguous_info,
            "element_inventory": _dom_snapshot_holder[0],
            "failing_step_visible": _failing_step_visible_holder[0],
        }

    return {
        "passed": passed,
        "logs": current_logs.strip(),
        "return_code": 0 if passed else 1,
        "failed_step_index": failed_step_index,
        "ambiguous_steps": ambiguous_info,
        "element_inventory": _dom_snapshot_holder[0],  # structured inventory for LLM
        "failing_step_visible": _failing_step_visible_holder[0],
    }


def _read_from(log_file: Path, byte_offset: int) -> str:
    """Read log_file content starting from byte_offset."""
    try:
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            f.seek(byte_offset)
            return f.read()
    except Exception:
        return ""


def _append_footer(log_file: Path, test_filename: str, timed_out: bool = False) -> None:
    """Append an end marker to logs.txt after a test run."""
    try:
        suffix = " [TIMED OUT]" if timed_out else ""
        separator = "=" * 60
        footer = f"\n{separator}\n=== END: {test_filename}{suffix} ===\n{separator}\n\n"
        with open(log_file, "a", encoding="utf-8") as lf:
            lf.write(footer)
    except Exception:
        pass


import re as _re_crud

# CRUD-aware ordering: tests that create/add/register/sign-up run first,
# then view/read/list/verify, then edit/update/modify, then delete/remove last.
# Within each tier, alphabetical order is preserved.
_CRUD_TIERS: list[tuple[int, _re_crud.Pattern]] = [
    (0, _re_crud.compile(r"create|add|new|register|sign.?up|setup|onboard", _re_crud.IGNORECASE)),
    (1, _re_crud.compile(r"view|read|list|get|fetch|load|display|show|verify|check|search|filter|browse", _re_crud.IGNORECASE)),
    (2, _re_crud.compile(r"edit|update|modify|change|rename|toggle|enable|disable|activate|deactivate|switch", _re_crud.IGNORECASE)),
    (3, _re_crud.compile(r"delete|remove|discard|archive|cancel|revoke|logout|sign.?out", _re_crud.IGNORECASE)),
]


def _sort_tests_by_crud(filenames) -> list[str]:
    """Sort test filenames by CRUD lifecycle order so dependent tests run in sequence.

    Create/add tests run first, then read/view, then edit/update, then delete/remove.
    Files that don't match any pattern get tier 1.5 (between read and edit).
    """
    def _tier(name: str) -> tuple[int, str]:
        lower = name.lower()
        for tier, pattern in _CRUD_TIERS:
            if pattern.search(lower):
                return (tier, name)
        # Default: between read and edit
        return (1, name)

    return sorted(filenames, key=_tier)


def _truncate_logs(logs: str, max_chars: int = 6000) -> str:
    """Return truncated logs with both beginning and ending context."""
    if len(logs) <= max_chars:
        return logs

    marker = "\n[... truncated ...]\n"
    if max_chars <= len(marker) + 2:
        return logs[-max_chars:]

    # Keep early setup/navigation context and failure tail.
    head_chars = min(1500, max(200, (max_chars - len(marker)) // 2))
    tail_chars = max_chars - len(marker) - head_chars
    if tail_chars < 200:
        tail_chars = 200
        head_chars = max_chars - len(marker) - tail_chars

    return logs[:head_chars] + marker + logs[-tail_chars:]


def _write_execution_report(session) -> str:
    """Write a markdown execution report to disk and return its path."""
    passed = [r for r in session.results if r.status == "passed"]
    failed = [r for r in session.results if r.status in ("failed", "error", "unfixable")]
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    lines = [
        "# Test Execution Report",
        f"",
        f"**Generated:** {timestamp}  ",
        f"**Output directory:** `{session.output_dir}`  ",
        f"",
        "## Summary",
        f"",
        f"| Total | Passed | Failed/Unfixable |",
        f"|-------|--------|-----------------|",
        f"| {len(session.test_files)} | {len(passed)} | {len(failed)} |",
        f"",
        "## Results",
        f"",
    ]

    for r in session.results:
        icon = "✅" if r.status == "passed" else "❌"
        lines.append(f"### {icon} {r.test_name} (`{r.test_file}`)")
        lines.append(f"")
        lines.append(f"- **Status:** {r.status.upper()}")
        lines.append(f"- **Attempts:** {r.attempts}")
        if r.status != "passed" and r.logs:
            lines.append(f"")
            lines.append(f"**Last error log:**")
            lines.append(f"```")
            lines.append(_truncate_logs(r.logs, max_chars=2000))
            lines.append(f"```")
        lines.append(f"")

    if session.failed_descriptions:
        lines.append("## Unfixable Test Descriptions")
        lines.append("")
        for desc in session.failed_descriptions:
            lines.append(f"- {desc}")
        lines.append("")

    report_content = "\n".join(lines)
    report_path = Path(session.output_dir) / "test_execution_report.md"
    try:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(report_content, encoding="utf-8")
    except Exception:
        pass  # Don't fail the whole operation if report writing fails

    return str(report_path)


def _build_final_summary(session) -> dict[str, Any]:
    """Build the final execution summary and write the execution report."""
    passed = [r for r in session.results if r.status == "passed"]
    failed = [r for r in session.results if r.status in ("failed", "error", "unfixable")]
    report_path = _write_execution_report(session)
    response: dict[str, Any] = {
        "execSessionId": session.exec_session_id,
        "status": "completed",
        "outputDir": session.output_dir,
        "summary": {
            "total": len(session.test_files),
            "passed": len(passed),
            "failed": len(failed),
        },
        "passedTests": [
            {"file": r.test_file, "name": r.test_name, "attempts": r.attempts}
            for r in passed
        ],
        "failedTests": [
            {
                "file": r.test_file,
                "name": r.test_name,
                "attempts": r.attempts,
                "finalLogs": _truncate_logs(r.logs),
            }
            for r in failed
        ],
        "failedDescriptions": session.failed_descriptions,
        "correctScriptsStoredAt": session.output_dir,
        "logsFile": str(Path(session.output_dir) / "logs.txt"),
        "executionReportPath": report_path,
        "note": (
            "Passing test scripts are stored in the output directory. "
            "Cumulative execution logs are in logs.txt. "
            "Full execution report is in test_execution_report.md."
        ),
    }
    if session.gen_session_id:
        passed_count = len(passed)
        failed_count = len(failed)
        total_count = len(session.results)
        response["pendingDecision"] = {
            "question": (
                f"Execution complete: {passed_count} passed, {failed_count} failed out of {total_count}. "
                "Which tests do you want to push to Maeris?"
            ),
            "options": {
                "1_push_passed_only": {
                    "label": "Push only passed tests",
                    "description": (
                        f"Push only the {passed_count} passing test(s) to Maeris."
                    ),
                    "tool": "push_tests_to_maeris",
                    "arguments": {
                        "session_id": session.gen_session_id,
                        "exec_session_id": session.exec_session_id,
                    },
                },
                "2_push_all": {
                    "label": "Push all tests",
                    "description": (
                        f"Push all {total_count} test(s) (including {failed_count} failed) to Maeris."
                    ),
                    "tool": "push_tests_to_maeris",
                    "arguments": {
                        "session_id": session.gen_session_id,
                    },
                },
                "3_skip_push": {
                    "label": "Skip for now",
                    "description": "Do not push tests to Maeris",
                    "tool": None,
                    "arguments": {},
                },
            },
        }
    else:
        response["nextStep"] = (
            "Execution completed. If you want to push tests to Maeris, "
            "call push_tests_to_maeris with the generation session_id."
        )
    return response




async def _phase1_init_session(
    exec_store: "TestExecutionStore",
    test_store: "TestGenerationStore",
    *,
    session_id: str | None,
    output_dir: str | None,
    base_url_override: str | None,
    test_email: str | None,
    test_password: str | None,
    headless: bool,
    skip_iframe_search: bool,
    step_retries: int,
) -> "str | list":
    """Phase 1 — resolve output directory, create execution session, inject credentials.

    Returns exec_session_id (str) on success, or a list[TextContent] error response.
    """
    # First call — resolve output_dir
    gen_session = None
    if session_id and not output_dir:
        gen_session = test_store.get_session(session_id)
        if not gen_session:
            return [TextContent(type="text", text=f"Error: generation session not found: {session_id}")]
        if not gen_session.output_dir:
            return [TextContent(
                type="text",
                text="Error: generation session has no output directory. Has the generate tool finished writing tests to disk?",
            )]
        output_dir = gen_session.output_dir

    if not output_dir:
        return [TextContent(
            type="text",
            text="Error: provide session_id (from the generate tool) or output_dir to start execution.",
        )]

    if not Path(output_dir).exists():
        return [TextContent(type="text", text=f"Error: directory does not exist: {output_dir}")]

    tests_dir = Path(output_dir)
    test_files = _sort_tests_by_crud(f.name for f in tests_dir.glob("*.json"))
    if not test_files:
        return [TextContent(type="text", text=f"Error: no test .json files found in {tests_dir}")]

    # Prefer user-provided base_url; fall back to auto-resolved from generation session
    locked_base_url = base_url_override or (gen_session.base_url if gen_session else None)

    exec_session_id = exec_store.create_session(
        output_dir=output_dir,
        test_files=test_files,
        gen_session_id=session_id,
        base_url=locked_base_url,
        headless=headless,
        skip_iframe_search=skip_iframe_search,
        step_retries=step_retries,
    )

    # Inject user-provided base_url into step files before any test runs.
    if base_url_override:
        _inject_base_url_into_dir(output_dir, gen_session.base_url if gen_session else None, base_url_override)

    # Inject real credentials into step files before any test runs.
    # Also persist them on the generation session for use during push.
    if test_email or test_password:
        _inject_credentials_into_dir(output_dir, test_email or "", test_password or "")
        if session_id:
            creds = {}
            if test_email:
                creds["email"] = test_email
            if test_password:
                creds["password"] = test_password
            test_store.set_credentials(session_id, creds)
    return exec_session_id


async def _phase2_run_loop(
    exec_store: "TestExecutionStore",
    test_store: "TestGenerationStore",
    exec_session_id: str,
    *,
    fixed_code: str | None,
    pre_fixed_code: str | None = None,
    mark_unfixable: bool,
    app_path: str | None = None,
) -> list:
    """Phase 2 — Playwright preflight, apply fix if any, then run the batch loop."""
    session = exec_store.get_session(exec_session_id)

    # ── Playwright pre-flight check ───────────────────────────────────────────
    # Only run on first call (current_index == 0, no fixed_code) to avoid
    # slowing down every iteration.
    if session.current_index == 0 and not fixed_code:
        try:
            import subprocess as _sp
            _pw_check = _sp.run(
                ["python", "-m", "playwright", "--version"],
                capture_output=True,
                timeout=10,
            )
            if _pw_check.returncode != 0:
                return [TextContent(type="text", text=json.dumps({
                    "status": "playwright_not_installed",
                    "message": (
                        "Playwright is not installed. Please run the following commands and "
                        "then call run_and_fix_tests again:\n\n"
                        "  pip install playwright\n"
                        "  playwright install chromium\n"
                    ),
                }, indent=2))]
        except Exception:
            pass  # If check itself fails, let the test run fail naturally

    # ── Already finished? ────────────────────────────────────────────────────
    if session.status == "completed":
        await _close_browser_pool(exec_session_id)
        return [TextContent(type="text", text=json.dumps(_build_final_summary(session), indent=2))]

    if session.current_index >= len(session.test_files):
        await _close_browser_pool(exec_session_id)
        exec_store.finalize(exec_session_id)
        return [TextContent(type="text", text=json.dumps(_build_final_summary(session), indent=2))]

    # ── Common prefix phase (2a / 2b / 2c) ───────────────────────────────────
    # Runs once before the first individual test.  Detects shared steps at the
    # start of all tests, fixes them as a unit, then propagates the corrected
    # steps to all test files before individual runs begin.
    if not session.common_prefix_verified:
        prefix_result = await _handle_common_prefix_phase(
            exec_store, exec_session_id, session, fixed_code
        )
        if prefix_result is not None:
            return prefix_result  # Still in prefix phase — return response to LLM
        # Prefix phase complete — consume fixed_code so it is not re-applied below
        fixed_code = None
        session = exec_store.get_session(exec_session_id)  # reload after mutations

    current_file = session.test_files[session.current_index]
    test_path = Path(session.output_dir) / current_file
    test_name = current_file.removesuffix(".json").replace("_", " ").title()

    # Tracks how many remaining test files were pre-patched from the latest fix
    selector_patched: int = 0
    step_patched: int = 0

    # ── Apply fixed code ─────────────────────────────────────────────────────
    old_json = ""  # populated below if fixed_code is present
    if fixed_code and not mark_unfixable:
        # Validate that fixed_code is valid JSON with a steps array
        try:
            fixed_data = json.loads(fixed_code)
            if not isinstance(fixed_data.get("steps"), list):
                raise ValueError("'steps' array is missing")
        except Exception as parse_err:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "previousFixRejected": True,
                "rejectionReason": str(parse_err),
                "error": "fixed_code is not valid JSON — rejected without writing to disk.",
                "parseError": str(parse_err),
                "nextStep": (
                    "The fixed_code you provided is not valid JSON or is missing the 'steps' array. "
                    "Your retry budget for the failing step was NOT consumed — fix the JSON "
                    "and call again with corrected fixed_code. No retry attempt was used."
                ),
            }, indent=2))]

        # Guard the base URL — don't let fixes silently switch domains
        from urllib.parse import urlparse

        locked_host = ""
        old_json = ""
        if session.base_url:
            locked_host = urlparse(session.base_url).netloc

        try:
            old_json = test_path.read_text(encoding="utf-8")
        except Exception:
            pass

        if not locked_host and old_json:
            try:
                old_data = json.loads(old_json)
                for step in old_data.get("steps", []):
                    if step.get("action_taken") == "go_to" and step.get("mock_input"):
                        locked_host = urlparse(step["mock_input"]).netloc
                        if locked_host:
                            break
            except Exception:
                pass

        if locked_host:
            for step in fixed_data.get("steps", []):
                if step.get("action_taken") == "go_to" and step.get("mock_input"):
                    new_host = urlparse(step["mock_input"]).netloc
                    if new_host and new_host != locked_host:
                        return [TextContent(type="text", text=json.dumps({
                            "execSessionId": exec_session_id,
                            "previousFixRejected": True,
                            "rejectionReason": f"base URL changed from '{locked_host}' to '{new_host}'",
                            "error": f"fixed_code changed the base URL from '{locked_host}' to '{new_host}' — rejected.",
                            "originalHost": locked_host,
                            "attemptedHost": new_host,
                            "nextStep": (
                                f"Your fix changed the domain from '{locked_host}' to '{new_host}'. "
                                f"Keep the original base URL and only fix the selectors/assertions. "
                                f"Your retry budget for the failing step was NOT consumed — submit a corrected fix."
                            ),
                        }, indent=2))]
                    break

        # Guard assertions — don't let fixes silently strip verification steps
        new_assertion_count = sum(
            1 for s in fixed_data.get("steps", [])
            if isinstance(s, dict) and s.get("assertion_nature")
        )
        old_assertion_count = 0
        if old_json:
            try:
                old_steps = json.loads(old_json).get("steps", [])
                old_assertion_count = sum(
                    1 for s in old_steps
                    if isinstance(s, dict) and s.get("assertion_nature")
                )
            except Exception:
                pass

        if new_assertion_count == 0 and old_assertion_count > 0:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "previousFixRejected": True,
                "rejectionReason": f"removed all {old_assertion_count} assertion step(s)",
                "error": (
                    f"fixed_code removed all {old_assertion_count} assertion step(s) — rejected. "
                    "Every test must have at least 1 verification step."
                ),
                "oldAssertionCount": old_assertion_count,
                "newAssertionCount": 0,
                "nextStep": (
                    "Your fix removed all assertion steps (steps with assertion_nature). "
                    "Do NOT remove assertions to make a test pass. Instead, fix the root cause: "
                    "use the correct selector, wait for the right element, or update the "
                    "assertion_value to match what the page actually shows. "
                    "Your retry budget for the failing step was NOT consumed — submit a corrected fix."
                ),
            }, indent=2))]

        # Guard against silent assertion stripping, while still allowing
        # legitimate rewrites of impossible assertions (e.g. a generator-
        # invented toast that never fires on a file download).
        #
        # Rule of thumb:
        #   * Must keep at least half of the original assertions (rounded up).
        #   * If the fix shrinks the total step count significantly (>1) AND
        #     drops assertions, require the LLM to opt-in via the
        #     ``_assertions_replaced`` flag on fixed_data, which signals a
        #     deliberate rewrite rather than a silent deletion.
        assertions_dropped = old_assertion_count - new_assertion_count
        old_total_steps = 0
        new_total_steps = len(fixed_data.get("steps", []))
        if old_json:
            try:
                old_total_steps = len(json.loads(old_json).get("steps", []))
            except Exception:
                pass

        import math
        min_kept = max(1, math.ceil(old_assertion_count / 2))
        size_shrank = new_total_steps < (old_total_steps - 1)
        opt_in_rewrite = bool(fixed_data.get("_assertions_replaced"))

        reject_reason: str | None = None
        if new_assertion_count < min_kept:
            reject_reason = (
                f"kept only {new_assertion_count} of {old_assertion_count} "
                f"assertion step(s) — must keep at least {min_kept}"
            )
        elif assertions_dropped >= 2 and size_shrank and not opt_in_rewrite:
            reject_reason = (
                f"dropped {assertions_dropped} assertion step(s) while shrinking "
                f"total steps from {old_total_steps} to {new_total_steps}"
            )

        if reject_reason:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "previousFixRejected": True,
                "rejectionReason": (
                    f"reduced assertion steps from {old_assertion_count} to {new_assertion_count}"
                ),
                "error": (
                    f"fixed_code {reject_reason} — rejected."
                ),
                "oldAssertionCount": old_assertion_count,
                "newAssertionCount": new_assertion_count,
                "oldTotalSteps": old_total_steps,
                "newTotalSteps": new_total_steps,
                "nextStep": (
                    f"Your fix dropped {assertions_dropped} assertion step(s) and shrank the test. "
                    "If the removed assertions were impossible to verify (e.g. a toast that never "
                    "fires), you can replace rather than remove them: rewrite the assertion to "
                    "check a real observable outcome (a DOM element that IS visible after the "
                    "action — button still present, row appears in list, modal closed) and set "
                    "`_assertions_replaced: true` on the top-level fixed_code JSON to opt into the "
                    "rewrite. Otherwise, fix the failing assertion in place by correcting the "
                    "selector, assertion_value, or adding wait_before. "
                    "Your retry budget for the failing step was NOT consumed — submit a corrected fix."
                ),
            }, indent=2))]

        # Meta keys like `_assertions_replaced` must not survive into the
        # written JSON (they're opt-in signals, not step data).
        fixed_data.pop("_assertions_replaced", None)

        # Guard assertion step correctness — reject malformed verification steps.
        # "image" is intentionally excluded: image assertions are not supported in maeris-mcp.
        _VALID_NATURES = {"existence", "page", "input"}
        _VALID_TYPES_BY_NATURE: dict[str, frozenset[str]] = {
            "existence": frozenset({
                "to be visible", "not to be visible",
            }),
            "page": frozenset({
                "to have title", "to have url", "to contain url",
            }),
            "input": frozenset({
                "to be visible", "to be hidden",
                "to be enabled", "to be disabled",
                "to be checked", "to be not checked",
                "to have text", "to contain text",
                "to have value", "to contain value",
                "to be editable", "to be focused", "to be focussed",
                "to be empty", "to be selected", "not to be selected",
                "to be password", "to be email", "to be number", "to be date",
                "has option", "assert all options",
                "has default option", "to have default option",
            }),
        }
        _BARE_TAGS = frozenset({
            "button", "div", "a", "span", "li", "input", "p", "section",
            "form", "label", "select", "textarea", "img", "h1", "h2", "h3",
            "h4", "h5", "h6", "table", "tr", "td", "th", "ul", "ol", "nav",
            "header", "footer", "main", "aside", "article",
        })
        assertion_issues: list[str] = []
        for si, s in enumerate(fixed_data.get("steps", [])):
            if not isinstance(s, dict):
                continue
            a_nature = (s.get("assertion_nature") or "").strip().lower()
            if not a_nature:
                continue

            if a_nature not in _VALID_NATURES:
                assertion_issues.append(
                    f"Step {si + 1}: invalid assertion_nature '{a_nature}' "
                    f"— must be one of {sorted(_VALID_NATURES)}"
                )
                continue

            a_type = (s.get("assertion_type") or "").strip().lower()
            valid_types = _VALID_TYPES_BY_NATURE.get(a_nature)
            if valid_types and a_type and a_type not in valid_types:
                assertion_issues.append(
                    f"Step {si + 1}: invalid assertion_type '{a_type}' for "
                    f"assertion_nature '{a_nature}' — must be one of {sorted(valid_types)}"
                )

            css_sel = (s.get("css_selector") or "").strip()

            # input assertions require a css_selector to locate the element
            if a_nature == "input" and not css_sel:
                assertion_issues.append(
                    f"Step {si + 1}: input assertion '{a_type}' has no css_selector "
                    "— input assertions require a selector to locate the element"
                )

            # Bare tag selectors on assertions — auto-fix where possible,
            # reject only on input assertions where a selector is required.
            if css_sel and css_sel.lower() in _BARE_TAGS:
                if a_nature in ("existence", "page"):
                    # existence/page assertions don't need a selector — strip
                    # the bare tag silently instead of rejecting.  The
                    # assertion still checks for the text / URL.
                    s["css_selector"] = ""
                else:
                    # input assertions NEED a real selector — reject.
                    assertion_issues.append(
                        f"Step {si + 1}: css_selector '{css_sel}' is a bare tag name — "
                        "use a specific selector like [data-testid=\"...\"], [id=\"...\"], "
                        "or [aria-label=\"...\"] instead"
                    )

        if assertion_issues:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "previousFixRejected": True,
                "rejectionReason": f"{len(assertion_issues)} invalid assertion step(s)",
                "error": "fixed_code contains invalid assertion steps — rejected.",
                "assertionIssues": assertion_issues,
                "nextStep": (
                    "Fix the assertion steps listed above and call again with corrected fixed_code. "
                    "Valid assertion_nature values: existence, page, input. "
                    "input assertions MUST have a specific css_selector (not a bare tag). "
                    "existence assertions verify text on the page (no selector needed). "
                    "page assertions verify the URL or title (no selector needed). "
                    "Your retry budget for the failing step was NOT consumed — submit a corrected fix."
                ),
            }, indent=2))]

        # Guard locked common-prefix steps (phase 2d) — don't let individual test
        # fixes modify the steps that were already proven in the prefix phase.
        if session.common_prefix_length > 0 and old_json:
            try:
                _orig_steps_for_lock = json.loads(old_json).get("steps", [])
                _lock_err = _assert_locked_steps_unchanged(
                    _orig_steps_for_lock,
                    fixed_data.get("steps", []),
                    session.common_prefix_length,
                )
                if _lock_err:
                    return [TextContent(type="text", text=json.dumps({
                        "execSessionId": exec_session_id,
                        "previousFixRejected": True,
                        "rejectionReason": _lock_err,
                        "error": "fixed_code modified locked common-prefix step(s) — rejected.",
                        "lockedStepCount": session.common_prefix_length,
                        "nextStep": (
                            f"The first {session.common_prefix_length} step(s) are locked — "
                            "they were verified and applied to all tests in the common prefix phase. "
                            f"Do NOT modify steps 1 through {session.common_prefix_length}. "
                            "Only fix steps after the common prefix. "
                            "Your retry budget for the failing step was NOT consumed — submit a corrected fix."
                        ),
                    }, indent=2))]
            except Exception:
                pass  # Lock check is non-fatal — proceed if it errors

        try:
            test_path.write_text(
                json.dumps(fixed_data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            return [TextContent(type="text", text=f"Error: could not write fixed code: {e}")]

        # No propagation here — changes are propagated only after the run
        # verifies which steps actually passed (see pass/fail branches below).

    # ── Mark unfixable ──────────────────────────────────────────────────────
    if mark_unfixable:
        failure_desc = f"Test '{test_name}' ({current_file}) skipped — marked unfixable by user"
        exec_store.add_failed_description(exec_session_id, failure_desc)
        exec_store.record_result(
            exec_session_id,
            current_file,
            test_name,
            "unfixable",
            logs=failure_desc,
        )
        exec_store.advance(exec_session_id)

        if session.current_index >= len(session.test_files):
            await _close_browser_pool(exec_session_id)
            exec_store.finalize(exec_session_id)
            return [TextContent(type="text", text=json.dumps(_build_final_summary(session), indent=2))]

        # Update to next test after advance
        current_file = session.test_files[session.current_index]
        test_path = Path(session.output_dir) / current_file
        test_name = current_file.removesuffix(".json").replace("_", " ").title()

    # ── Batch-run loop ─────────────────────────────────────────────────────
    # Run tests sequentially.  Passing tests are batched — we keep running
    # the next test without returning to the LLM.  The loop only breaks
    # (returns to Claude) when a test fails, an intent issue is found, or
    # all tests are done.
    batched_passes: list[dict[str, Any]] = []

    while True:
        # Snapshot pre-run JSON so we can diff after (for auto-fix/ambiguous-retry propagation)
        _pre_run_json = ""
        try:
            _pre_run_json = (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
        except Exception:
            pass

        # Escalate page_timeout based on how many LLM fixes have been applied
        # to the current test.  fix_count=0 → 2 s (fast-fail), 1 fix → 5 s,
        # 2+ fixes → 8 s (full patience).  Only looks at step_fix_counts for
        # the current test index so fixing one test never bleeds into another.
        _current_max_fixes = max(
            (v for k, v in session.step_fix_counts.items()
             if k.startswith(f"{session.current_index}:")),
            default=0,
        )
        # ── Skip-to-failure: when retrying after a fix, determine if we
        # can skip login/navigation and jump directly to the failing step.
        # Only skips when (a) fixed_code was provided, (b) the fix only
        # modified the failing step or later, and (c) saved auth cookies
        # exist from a previous run.
        _skip_to = 0
        if fixed_code and old_json and _current_max_fixes > 0:
            try:
                _old_steps = json.loads(old_json).get("steps", [])
                _new_steps = json.loads(
                    (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                ).get("steps", [])
                # Find the first step that changed
                _first_changed = len(_old_steps)
                for _ci in range(min(len(_old_steps), len(_new_steps))):
                    _os = _old_steps[_ci]
                    _ns = _new_steps[_ci]
                    if (
                        (_os.get("css_selector") or "") != (_ns.get("css_selector") or "")
                        or (_os.get("mock_input") or "") != (_ns.get("mock_input") or "")
                        or (_os.get("assertion_value") or "") != (_ns.get("assertion_value") or "")
                        or (_os.get("wait_before") or 0) != (_ns.get("wait_before") or 0)
                    ):
                        _first_changed = _ci
                        break
                # Only skip if all changes are at or after a mid-test step
                # (don't skip if login/first few steps changed)
                if _first_changed >= 3:  # at least 3 untouched leading steps
                    _skip_to = _first_changed
            except Exception:
                _skip_to = 0

        run_result = await _run_test(
            session.output_dir, current_file,
            headless=session.headless,
            exec_session_id=exec_session_id,
            skip_iframe_search=session.skip_iframe_search,
            page_timeout=_page_timeout_for_fix_count(_current_max_fixes),
            skip_to_step=_skip_to,
            app_path=app_path,
        )

        if run_result["passed"]:
            # Propagate runtime changes (auto-fix selectors, ambiguous-retry nth, etc.)
            # Like LLM-driven propagation, runtime propagation is scoped to the
            # common-prefix window to avoid corrupting test-specific middle
            # steps in sibling tests. Runtime fixes are typically nth_appearance
            # or selector refinements that still live in the shared login/setup
            # prefix — beyond that, each test is considered independent.
            if _pre_run_json:
                try:
                    _post_run_json = (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                except Exception:
                    _post_run_json = ""
                if _post_run_json and _post_run_json != _pre_run_json:
                    _prefix_len = session.common_prefix_length or 0
                    if _prefix_len > 0:
                        def _truncate_steps(raw: str, n: int) -> str:
                            try:
                                _d = json.loads(raw)
                                _d["steps"] = _d.get("steps", [])[:n]
                                return json.dumps(_d)
                            except Exception:
                                return raw

                        _pre_scoped = _truncate_steps(_pre_run_json, _prefix_len)
                        _post_scoped = _truncate_steps(_post_run_json, _prefix_len)
                        _rt_field = _extract_step_field_corrections(_pre_scoped, _post_scoped)
                        if _rt_field:
                            _propagate_field_corrections(
                                session.output_dir, _rt_field, session.test_files, session.current_index,
                            )
                        _rt_ins = _extract_step_insertions(_pre_scoped, _post_scoped)
                        if _rt_ins:
                            _propagate_step_insertions(
                                session.output_dir, _rt_ins, session.test_files, session.current_index,
                            )
                    # When common_prefix_length is 0, tests are fully
                    # independent — no cross-test propagation at all.

            # Gate 3: Intent validation
            _intent_issues: list[dict] = []
            try:
                _original_plan_flow: dict | None = None
                if session.gen_session_id:
                    _gen = test_store.get_session(session.gen_session_id)
                    if _gen and _gen.test_plan and isinstance(_gen.test_plan, dict):
                        _tc_name_lower = test_name.lower().strip()
                        for _flow in (_gen.test_plan.get("discovered_flows") or []):
                            if not isinstance(_flow, dict):
                                continue
                            _fname = (_flow.get("flow_name") or "").lower().strip()
                            if _fname and (_fname in _tc_name_lower or _tc_name_lower in _fname):
                                _original_plan_flow = _flow
                                break

                if _original_plan_flow:
                    _current_step_data = json.loads(
                        (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                    )
                    _current_steps = _current_step_data.get("steps") or []
                    _intent_issues = _validate_intent(_current_steps, _original_plan_flow, test_name)
            except Exception:
                pass

            if _intent_issues:
                # Intent lost — must return to Claude for a fix
                response: dict[str, Any] = {
                    "execSessionId": exec_session_id,
                    "status": "intent_validation_failed",
                    "testName": test_name,
                    "intentIssues": _intent_issues,
                    "logs": run_result.get("logs", ""),
                    "currentCode": (Path(session.output_dir) / current_file).read_text(encoding="utf-8"),
                    "instruction": (
                        "The test passed but its intent was lost during fixing. "
                        "Provide fixed_code that restores the missing assertions and steps "
                        "while keeping the test passing.\n\n"
                        "CRITICAL: Do NOT remove assertions to make a test pass. "
                        "Fix the root cause instead — use the correct selector, wait for the "
                        "right element, or adjust the assertion value to match what the page shows."
                    ),
                }
                if batched_passes:
                    response["batchedPasses"] = batched_passes
                return [TextContent(type="text", text=json.dumps(response, indent=2))]

            exec_store.record_result(exec_session_id, current_file, test_name, "passed", run_result["logs"])

            # Mark proven paths in codemap for EVERY passing test
            try:
                _repo_root_proven = None
                if session.gen_session_id:
                    _gen_proven = test_store.get_session(session.gen_session_id)
                    if _gen_proven:
                        _repo_root_proven = _gen_proven.scan_root
                if not _repo_root_proven:
                    _repo_root_proven = session.output_dir
                _passing_json = (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                _mark_proven_paths_in_codemap(_repo_root_proven, _passing_json)
            except Exception:
                pass

            # Record selector corrections in fix cache + codemap (from ALL sources)
            _all_sel_corrections: list[tuple[str, str]] = []
            # Source 1: LLM fixed_code (alignment-aware)
            if fixed_code and old_json:
                for fc in _extract_step_field_corrections(old_json, fixed_code):
                    o_sel = (fc["old_values"].get("css_selector") or "").strip()
                    n_sel = (fc["changes"].get("css_selector") or "").strip()
                    if o_sel and n_sel and o_sel != n_sel and (o_sel, n_sel) not in _all_sel_corrections:
                        _all_sel_corrections.append((o_sel, n_sel))
                for o_sel, n_sel in _extract_selector_corrections(old_json, fixed_code):
                    if (o_sel, n_sel) not in _all_sel_corrections:
                        _all_sel_corrections.append((o_sel, n_sel))
            # Source 2: Runtime auto-fix / ambiguous-retry
            # Skip any o_sel that is already a *working* value from Source 1 — that
            # means it's an intermediate selector produced by a previous fix iteration,
            # not the original broken selector.  Recording it would create broken chains
            # like: A→B, B→C instead of the correct A→C.
            _src1_working = {n for _, n in _all_sel_corrections}
            if _pre_run_json:
                try:
                    _post_p_json = (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                except Exception:
                    _post_p_json = ""
                if _post_p_json and _post_p_json != _pre_run_json:
                    for fc in _extract_step_field_corrections(_pre_run_json, _post_p_json):
                        o_sel = (fc["old_values"].get("css_selector") or "").strip()
                        n_sel = (fc["changes"].get("css_selector") or "").strip()
                        if o_sel and n_sel and o_sel != n_sel and o_sel not in _src1_working and (o_sel, n_sel) not in _all_sel_corrections:
                            _all_sel_corrections.append((o_sel, n_sel))

            # Propagate all changes — every step was verified (full pass).
            # Scope propagation to the common prefix so test-specific fixes
            # don't bleed across sibling tests (see _propagate_verified_changes
            # docstring for rationale).
            _propagate_verified_changes(
                session.output_dir, current_file, old_json, fixed_code,
                session.test_files, session.current_index, verified_up_to=None,
                common_prefix_length=session.common_prefix_length or 0,
            )

            if _all_sel_corrections:
                try:
                    _repo_root = None
                    if session.gen_session_id:
                        _gen = test_store.get_session(session.gen_session_id)
                        if _gen:
                            _repo_root = _gen.scan_root
                    if not _repo_root:
                        _repo_root = app_path or session.output_dir
                    _BARE_TAGS = {"button", "div", "a", "span", "li", "input", "p", "section", "form", "label"}
                    for broken_sel, working_sel in _all_sel_corrections:
                        if working_sel.lower().strip() in _BARE_TAGS:
                            continue
                        try:
                            from maeris_mcp.storage.scan_cache import RepoScanCache
                            RepoScanCache(_repo_root).update_selector(
                                old_selector=broken_sel, new_selector=working_sel,
                            )
                        except Exception:
                            pass
                        try:
                            _update_codemap_selector(_repo_root, broken_sel, working_sel)
                        except Exception:
                            pass
                    try:
                        _update_codemap_learned_selectors(_repo_root, _all_sel_corrections, test_name)
                    except Exception:
                        pass
                except Exception:
                    pass

            # Persist selector replacements as cross-test findings so the LLM can
            # submit pre_fixed_code for upcoming tests that share the same broken selectors.
            if _all_sel_corrections:
                for _o_sel, _n_sel in _all_sel_corrections:
                    try:
                        exec_store.add_session_finding(exec_session_id, {
                            "absent_selector": _o_sel,
                            "working_replacement": _n_sel,
                            "from_test_index": session.current_index,
                            "from_test_name": test_name,
                        })
                    except Exception:
                        pass

            # Write to unified flow knowledge store (selector corrections + proven test cases).
            try:
                from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
                _fk_repo_root = None
                if session.gen_session_id:
                    _fk_gen = test_store.get_session(session.gen_session_id)
                    if _fk_gen:
                        _fk_repo_root = _fk_gen.scan_root
                if not _fk_repo_root:
                    _fk_repo_root = app_path or session.output_dir
                _fk_passing_steps = json.loads(
                    (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                ).get("steps", [])
                if _fk_passing_steps:
                    _fk = RepoFlowKnowledge(_fk_repo_root)
                    _fk.record_run_and_fix_result(
                        command=test_name,
                        original_cases=[],  # no original available per-test; diff skipped
                        passing_cases=[{"test_name": test_name, "steps": _fk_passing_steps}],
                        session_findings=list(session.session_findings),
                    )
            except Exception:
                pass

            batched_passes.append({
                "index": session.current_index,
                "file": current_file,
                "name": test_name,
            })

            exec_store.advance(exec_session_id)

            # All tests done?
            if session.current_index >= len(session.test_files):
                await _close_browser_pool(exec_session_id)
                exec_store.finalize(exec_session_id)
                return [TextContent(type="text", text=json.dumps(_build_final_summary(session), indent=2))]

            # Advance to next test and continue the loop (no return to Claude)
            current_file = session.test_files[session.current_index]
            test_path = Path(session.output_dir) / current_file
            test_name = current_file.removesuffix(".json").replace("_", " ").title()
            # Apply pre_fixed_code to the next test if the LLM submitted one proactively.
            # This lets the LLM front-load a known fix (e.g. absent selector discovered in
            # the test that just passed) so the next test starts with it already applied.
            fixed_code = pre_fixed_code
            pre_fixed_code = None
            old_json = ""
            continue  # ← run next test immediately

        else:
            # ── Test failed — check per-step fix budget ───────────────────
            failed_step_idx = run_result.get("failed_step_index", -1)

            # Propagate only changes whose step was verified (step_index < failed_step_idx).
            # LLM fix changes: old_json → fixed_code
            _propagate_verified_changes(
                session.output_dir, current_file, old_json, fixed_code,
                session.test_files, session.current_index, verified_up_to=failed_step_idx,
                common_prefix_length=session.common_prefix_length or 0,
            )
            # Runtime auto-fix changes (ambiguous-retry etc): pre-run → post-run
            if _pre_run_json:
                try:
                    _post_fail_json = (Path(session.output_dir) / current_file).read_text(encoding="utf-8")
                except Exception:
                    _post_fail_json = ""
                if _post_fail_json and _post_fail_json != _pre_run_json:
                    _propagate_verified_changes(
                        session.output_dir, current_file, _pre_run_json, _post_fail_json,
                        session.test_files, session.current_index, verified_up_to=failed_step_idx,
                        common_prefix_length=session.common_prefix_length or 0,
                    )
            timed_out = "[TIMEOUT]" in run_result["logs"]
            test_content = test_path.read_text(encoding="utf-8") if test_path.exists() else ""

            # Track how many times LLM has tried to fix this specific step
            fix_count = exec_store.increment_step_fix(exec_session_id, failed_step_idx) if failed_step_idx >= 0 else 0

            if fix_count > session.step_retries:
                # Exhausted fix attempts for this step — advance to next test
                exec_store.record_result(exec_session_id, current_file, test_name, "failed", run_result["logs"])
                failure_desc = (
                    f"Test '{test_name}' ({current_file}) failed — "
                    f"step {failed_step_idx + 1} exhausted {session.step_retries} fix attempts"
                )
                exec_store.add_failed_description(exec_session_id, failure_desc)
                exec_store.advance(exec_session_id)

                batched_passes.append({
                    "index": session.current_index - 1,
                    "file": current_file,
                    "name": test_name,
                    "status": "failed",
                })

                # All tests done?
                if session.current_index >= len(session.test_files):
                    await _close_browser_pool(exec_session_id)
                    exec_store.finalize(exec_session_id)
                    return [TextContent(type="text", text=json.dumps(_build_final_summary(session), indent=2))]

                # Advance to next test and continue the loop
                current_file = session.test_files[session.current_index]
                test_path = Path(session.output_dir) / current_file
                test_name = current_file.removesuffix(".json").replace("_", " ").title()
                fixed_code = pre_fixed_code
                pre_fixed_code = None
                old_json = ""
                continue

            # Still have fix attempts — return to LLM for fixing
            exec_store.record_result(exec_session_id, current_file, test_name, "failed", run_result["logs"])
            fixes_left = session.step_retries - fix_count

            if timed_out:
                status = "timeout"
                next_step = (
                    "TIMEOUT — the subprocess was killed after 60s. This is a CODE issue, not an app issue. "
                    "Fix the css_selector or add wait_before on the failing step, then call with fixed_code. "
                    "DO NOT call with mark_unfixable=true. DO NOT give the user shell commands."
                )
            else:
                status = "failed"
                next_step = (
                    "Analyze the logs and currentCode above. "
                    "Call run_and_fix_tests with exec_session_id + fixed_code "
                    "to apply your fix and re-run."
                )

            _elem_inv = run_result.get("element_inventory", "")
            response = {
                "execSessionId": exec_session_id,
                "currentTest": {
                    "index": session.current_index,
                    "file": current_file,
                    "name": test_name,
                    "total": len(session.test_files),
                },
                "failedStep": {
                    "index": failed_step_idx,
                    "fixAttempt": fix_count,
                    "maxFixAttempts": session.step_retries,
                    "fixesLeft": fixes_left,
                    **({"lockedPrefixSteps": session.common_prefix_length} if session.common_prefix_length > 0 else {}),
                },
                "status": status,
                "logs": _truncate_logs(run_result["logs"]),
                # Structured element inventory — use computed_selector values here
                # to fix css_selector fields.  Empty string when test timed out.
                "elementInventory": _elem_inv,
                "failingStepVisible": run_result.get("failing_step_visible"),
                "currentCode": test_content,
                "fixInstructions": _fix_instructions(timed_out=timed_out),
                "nextStep": next_step,
                # Cross-test findings: selector replacements confirmed working in earlier tests.
                # If any absent_selector appears in currentCode, submit pre_fixed_code
                # alongside fixed_code to pre-apply the same fix to the next test.
                "sessionFindings": session.session_findings,
            }
            if batched_passes:
                response["batchedPasses"] = batched_passes
            return [TextContent(type="text", text=json.dumps(response, indent=2))]


async def handle_run_and_fix_tests(
    exec_store: TestExecutionStore,
    test_store: TestGenerationStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the run_and_fix_tests tool call."""
    exec_session_id = arguments.get("exec_session_id") or arguments.get("execSessionId")
    session_id = arguments.get("session_id") or arguments.get("sessionId")
    output_dir = arguments.get("output_dir") or arguments.get("outputDir")
    fixed_code: str | None = arguments.get("fixed_code") or arguments.get("fixedCode")
    pre_fixed_code: str | None = arguments.get("pre_fixed_code") or arguments.get("preFixedCode")
    mark_unfixable = bool(arguments.get("mark_unfixable") or arguments.get("markUnfixable", False))
    base_url_override: str | None = arguments.get("base_url") or arguments.get("baseUrl")
    test_email: str | None = arguments.get("test_email") or arguments.get("testEmail")
    test_password: str | None = arguments.get("test_password") or arguments.get("testPassword")
    headless: bool = _coerce_bool(arguments.get("headless"), default=True)
    skip_iframe_search: bool = _coerce_bool(arguments.get("skip_iframe_search"), default=True)
    step_retries = int(arguments.get("step_retries") or arguments.get("stepRetries") or 3)
    app_path: str | None = (arguments.get("app_path") or arguments.get("appPath") or "").strip() or None

    # ── Phase 1 — create session on first call ───────────────────────────────
    if not exec_session_id:
        result = await _phase1_init_session(
            exec_store, test_store,
            session_id=session_id,
            output_dir=output_dir,
            base_url_override=base_url_override,
            test_email=test_email,
            test_password=test_password,
            headless=headless,
            skip_iframe_search=skip_iframe_search,
            step_retries=step_retries,
        )
        if isinstance(result, list):
            return result
        exec_session_id = result
    else:
        if not exec_store.get_session(exec_session_id):
            return [TextContent(type="text", text=f"Error: execution session not found: {exec_session_id}")]

    # ── Phase 2 — run the fix loop ───────────────────────────────────────────
    return await _phase2_run_loop(
        exec_store, test_store, exec_session_id,
        fixed_code=fixed_code,
        pre_fixed_code=pre_fixed_code,
        mark_unfixable=mark_unfixable,
        app_path=app_path,
    )



# ─────────────────────────────────────────────────────────────────────────────
# run_and_fix_test_case — run & auto-fix a single server-side testcase by ID
# ─────────────────────────────────────────────────────────────────────────────

def run_and_fix_test_case_tool() -> Tool:
    """Return the tool definition for run_and_fix_test_case."""
    return Tool(
        name="run_and_fix_test_case",
        description=(
            "Fetch a single testcase from the Maeris server by ID, run it locally with "
            "the Playwright in-process runner, and auto-fix any failing steps. "
            "The base URL and all step data (including credentials) are taken directly "
            "from the fetched testcase — no additional input needed. "
            "When the test passes, it returns 'passed_pending_review' with the steps "
            "for you to verify logical completeness before pushing to the server. "
            "Review the steps, then call with confirm_passed=true to finalize, or "
            "submit fixed_code to add/fix steps before re-running. "
            "On first call provide testcase_id. "
            "On subsequent calls provide exec_session_id and either fixed_code or "
            "confirm_passed=true. "
            "fixed_code may add new steps or remove unnecessary steps in addition to "
            "fixing selectors on existing steps."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "testcase_id": {
                    "type": "string",
                    "description": (
                        "Server-side testcase ID to fetch, run, fix, and update. "
                        "Required on the first call."
                    ),
                },
                "exec_session_id": {
                    "type": "string",
                    "description": "Existing execution session ID to continue across calls.",
                },
                "fixed_code": {
                    "type": "string",
                    "description": (
                        "Full corrected JSON step file content (as a JSON string) to apply "
                        "before re-running the failing test. Must be valid JSON with a 'steps' array. "
                        "You may add new steps, delete unnecessary steps, or fix selectors on "
                        "existing steps. Existing steps must keep their action_taken and mock_input unchanged."
                    ),
                },
                "confirm_passed": {
                    "type": "boolean",
                    "description": (
                        "Confirm that a passed test's steps are logically complete and should be "
                        "pushed to the server. Required after the tool returns status "
                        "'passed_pending_review'. Call with exec_session_id + confirm_passed=true."
                    ),
                    "default": False,
                },
                "mark_unfixable": {
                    "type": "boolean",
                    "description": "Mark the test as unfixable and abort without updating the server.",
                    "default": False,
                },
                "headless": {
                    "anyOf": [{"type": "boolean"}, {"type": "string"}],
                    "description": "Run browser in headless mode (default: true).",
                    "default": True,
                },
                "skip_iframe_search": {
                    "anyOf": [{"type": "boolean"}, {"type": "string"}],
                    "description": "Skip iframe fallback when locating elements (default: true).",
                    "default": True,
                },
                "step_retries": {
                    "anyOf": [{"type": "integer"}, {"type": "string"}],
                    "description": "Max LLM fix attempts per failing step (default: 3).",
                    "default": 3,
                },
            },
        },
    )


async def _push_fixed_steps_to_server(
    testcase_id: str,
    original_steps: list[dict],
    fixed_steps: list[dict],
    changes_id: str = "",
) -> list[str]:
    """Push selector/xpath/nth_appearance edits on matched steps to the server.

    Add and delete operations are handled separately via apply_fix_changes
    payloads (step_added / step_deleted change types). This function only
    updates component data for steps that exist in both the original and
    fixed lists.
    """
    from maeris_mcp.maeris.client import MaerisClient

    applied: list[str] = []
    matched, _inserted, _deleted = _align_steps_for_diff(original_steps, fixed_steps)

    async with MaerisClient() as client:
        for old_i, new_i in matched:
            original = original_steps[old_i]
            fixed_step = fixed_steps[new_i]
            flu_id = original.get("flu_id") or ""
            component_id = original.get("component_id") or ""
            if not flu_id:
                continue

            payload: dict[str, Any] = {"testcase_id": testcase_id, "flu_id": flu_id}
            if component_id:
                payload["component_id"] = component_id

            new_css = fixed_step.get("css_selector") or ""
            if new_css != (original.get("css_selector") or ""):
                payload["css_selector"] = new_css

            new_xpath = fixed_step.get("xpath") or ""
            if new_xpath != (original.get("xpath") or ""):
                payload["xpath"] = new_xpath

            new_nth = fixed_step.get("nth_appearance")
            if new_nth is not None and new_nth != original.get("nth_appearance"):
                payload["nth_appearance"] = new_nth

            if changes_id:
                payload["updated_deactivated_change_id"] = changes_id

            field_changes = {k: v for k, v in payload.items() if k not in ("testcase_id", "flu_id", "component_id")}
            if not field_changes:
                continue

            try:
                await client.edit_test_step(payload)
                applied.append(f"Step {old_i}: updated {list(field_changes.keys())}")
            except Exception as e:
                applied.append(f"Step {old_i}: update failed — {e}")

    return applied


def _build_apply_changes_payloads(
    original_steps: list[dict],
    fixed_steps: list[dict],
) -> list[dict]:
    """Build apply-changes payloads for all change types.

    Uses alignment-aware diffing so that added/deleted steps don't cause
    mis-paired comparisons.

    Returns a list of payloads — one per change type that has actual changes:
      - component_replaced  (selector/xpath edits on matched steps)
      - step_deleted        (steps removed)
      - step_added          (steps inserted)
    Returns an empty list if nothing changed.
    """
    from uuid import uuid4

    payloads: list[dict] = []
    matched, inserted, deleted = _align_steps_for_diff(original_steps, fixed_steps)

    # ── component_replaced payload (selector edits on matched steps) ──────
    old_component_map: dict[str, dict] = {}
    failed_flu_id: str = ""

    for old_i, new_i in matched:
        orig = original_steps[old_i]
        fixed = fixed_steps[new_i]

        orig_css = orig.get("css_selector") or ""
        new_css = fixed.get("css_selector") or ""
        orig_xpath = orig.get("xpath") or ""
        new_xpath = fixed.get("xpath") or ""
        orig_nth = orig.get("nth_appearance")
        new_nth = fixed.get("nth_appearance")

        if orig_css == new_css and orig_xpath == new_xpath and orig_nth == new_nth:
            continue

        old_comp_id = orig.get("component_id") or ""
        flu_id = orig.get("flu_id") or ""
        if not old_comp_id or not flu_id:
            continue

        if not failed_flu_id:
            failed_flu_id = flu_id

        old_component_map[old_comp_id] = {
            "component_id": str(uuid4()),
            "flu_id": flu_id,
            "css_selector": new_css,
            "xpath": new_xpath,
            "nth_appearance": new_nth if new_nth is not None else (orig.get("nth_appearance") or 0),
            "tag": orig.get("tag") or "",
            "text": orig.get("text") or "",
            "action_taken": orig.get("action_taken") or "click",
            "mock_input": orig.get("mock_input") or None,
            "html_of_component": orig.get("html_of_component") or "",
            "dom_hash": orig.get("dom_hash") or "",
            "component_representation_string": orig.get("component_representation_string") or "",
            "vector_id": orig.get("vector_id") or "",
        }

    if old_component_map and failed_flu_id:
        payloads.append({
            "failed_flu_id": failed_flu_id,
            "old_component_id_new_component_map": old_component_map,
            "new_component_id_top_ranked_components_map": {},
            "new_top_ranked_components": [],
            "update_component_id_vector_id_map": {},
        })

    # ── step_deleted payload ──────────────────────────────────────────────
    deleted_flu_ids = [
        original_steps[old_i].get("flu_id") or ""
        for old_i, _ in deleted
    ]
    deleted_flu_ids = [fid for fid in deleted_flu_ids if fid]

    if deleted_flu_ids:
        step_changes: dict[str, Any] = (
            {"flu_id": deleted_flu_ids[0]}
            if len(deleted_flu_ids) == 1
            else {"flu_ids": deleted_flu_ids}
        )
        payloads.append({
            "change_type": "step_deleted",
            "failed_flu_id": deleted_flu_ids[0],
            "step_changes": step_changes,
        })

    # ── step_added payload ────────────────────────────────────────────────
    if inserted:
        deleted_indices = {d[0] for d in deleted}
        add_entries: list[dict[str, Any]] = []

        for new_i, new_step in inserted:
            # Compute server-side insertion index relative to remaining
            # original steps (after deletions) + previously inserted steps.
            server_index = 0
            for old_i, matched_new_i in matched:
                if matched_new_i < new_i and old_i not in deleted_indices:
                    server_index = old_i + 1 - sum(1 for di in deleted_indices if di < old_i + 1)
            insert_offset = sum(1 for ni, _ in inserted if ni < new_i)
            server_index += insert_offset

            component: dict[str, Any] = {
                "css_selector": new_step.get("css_selector") or "",
                "nth_appearance": new_step.get("nth_appearance") or 0,
                "action_taken": new_step.get("action_taken") or "click",
                "cname": new_step.get("description") or "New Step",
                "component_label": new_step.get("description") or "New Step",
            }
            if new_step.get("mock_input"):
                component["mock_input"] = new_step["mock_input"]
            if new_step.get("xpath"):
                component["xpath"] = new_step["xpath"]
            if new_step.get("assertion_nature"):
                component["assertion_nature"] = new_step["assertion_nature"]
                component["assertion_type"] = new_step.get("assertion_type") or ""
                component["assertion_value"] = new_step.get("assertion_value") or ""

            add_entries.append({
                "step_index": server_index,
                "component_of_new_flu": component,
            })

        payloads.append({
            "change_type": "step_added",
            "step_changes": add_entries[0] if len(add_entries) == 1 else add_entries,
        })

    return payloads


async def handle_run_and_fix_test_case(
    exec_store: TestExecutionStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the run_and_fix_test_case tool call."""
    import tempfile

    from maeris_mcp.maeris.client import AuthenticationError, MaerisClient

    testcase_id: str | None = arguments.get("testcase_id") or arguments.get("testcaseId")
    exec_session_id: str | None = arguments.get("exec_session_id") or arguments.get("execSessionId")
    fixed_code: str | None = arguments.get("fixed_code") or arguments.get("fixedCode")
    confirm_passed: bool = bool(arguments.get("confirm_passed") or arguments.get("confirmPassed", False))
    mark_unfixable: bool = bool(arguments.get("mark_unfixable") or arguments.get("markUnfixable", False))
    headless: bool = _coerce_bool(arguments.get("headless"), default=True)
    skip_iframe_search: bool = _coerce_bool(arguments.get("skip_iframe_search"), default=True)
    step_retries: int = int(arguments.get("step_retries") or arguments.get("stepRetries") or 3)

    # ── Resolve / create session ──────────────────────────────────────────────
    if exec_session_id:
        session = exec_store.get_session(exec_session_id)
        if not session:
            return [TextContent(type="text", text=f"Error: execution session not found: {exec_session_id}")]
    else:
        # First call — fetch testcase from server
        if not testcase_id:
            return [TextContent(type="text", text="Error: testcase_id is required on the first call.")]

        async with MaerisClient() as client:
            try:
                testcases = await client.get_testcases()
            except AuthenticationError as e:
                return [TextContent(type="text", text=f"Error: {e}")]
            except Exception as e:
                return [TextContent(type="text", text=f"Error: could not fetch testcases: {e}")]

            tc = next(
                (t for t in testcases if (t.get("testcase_id") or t.get("id") or "") == testcase_id),
                None,
            )
            if tc is None:
                return [TextContent(type="text", text=f"Error: testcase not found with id: '{testcase_id}'")]

            path = tc.get("path") or tc.get("testcase_path") or ""
            flu_ids = [fid.strip() for fid in path.split("->") if fid.strip()]
            if not flu_ids:
                return [TextContent(type="text", text="Error: testcase has no steps (empty path).")]

            try:
                components = await client.get_components_by_flu_ids(flu_ids)
            except Exception as e:
                return [TextContent(type="text", text=f"Error: could not fetch step components: {e}")]

        tc_name = tc.get("testcase_name") or tc.get("name") or testcase_id
        comp_map: dict[str, dict] = {
            (c.get("flu_id") or ""): c for c in components if c.get("flu_id")
        }

        # Build ordered step lists — one for the temp JSON file, one for the server diff
        original_steps: list[dict] = []
        json_steps: list[dict] = []
        for flu_id in flu_ids:
            comp = comp_map.get(flu_id, {})
            action = comp.get("action_taken") or "click"
            mock_input = comp.get("mock_input") or ""
            # go_to steps store the URL in page_url on the server
            if action == "go_to" and not mock_input:
                mock_input = comp.get("page_url") or ""
            comp_id = (
                comp.get("component_id") or comp.get("componentId")
                or comp.get("id") or comp.get("_id")
                or comp.get("testcase_component_id") or ""
            )

            original_steps.append({
                "flu_id": flu_id,
                "component_id": comp_id,
                "css_selector": comp.get("css_selector") or "",
                "xpath": comp.get("xpath") or "",
                "action_taken": action,
                "mock_input": mock_input,
                "assertion_nature": comp.get("assertion_nature") or "",
                "assertion_type": comp.get("assertion_type") or "",
                "assertion_value": comp.get("assertion_value") or "",
                # Extra fields for apply-changes payload
                "tag": comp.get("tag") or "",
                "text": comp.get("text") or "",
                "nth_appearance": comp.get("nth_appearance") or 0,
                "html_of_component": comp.get("html_of_component") or "",
                "dom_hash": comp.get("dom_hash") or "",
                "component_representation_string": comp.get("component_representation_string") or "",
                "vector_id": comp.get("vector_id") or "",
            })

            json_step: dict[str, Any] = {
                "action_taken": action,
                "css_selector": comp.get("css_selector") or "",
                "xpath": comp.get("xpath") or "",
                "mock_input": mock_input,
                "nth_appearance": comp.get("nth_appearance") or 0,
                "wait_before": comp.get("wait_before") or 0,
                "wait_after": comp.get("wait_after") or 0,
                "description": comp.get("name") or comp.get("step_name") or "",
            }
            if comp.get("assertion_nature"):
                json_step["assertion_nature"] = comp["assertion_nature"]
                json_step["assertion_type"] = comp.get("assertion_type") or ""
                json_step["assertion_value"] = comp.get("assertion_value") or ""
            json_steps.append(json_step)

        # Derive base_url from the current app's url field
        base_url: str = (await _resolve_base_url_from_app()) or ""

        # Prepend a go_to step for local execution if the first step isn't
        # already navigating. This synthetic step is NOT added to
        # original_steps so it is never pushed back to the server.
        if base_url and (not json_steps or json_steps[0].get("action_taken") != "go_to"):
            json_steps.insert(0, {
                "action_taken": "go_to",
                "css_selector": "",
                "mock_input": base_url,
                "nth_appearance": 0,
                "wait_before": 0,
                "wait_after": 0,
                "description": "Navigate to app (auto-prepended for local run)",
            })

        # Write to temp directory
        tmp_dir = tempfile.mkdtemp(prefix="maeris_fix_")
        test_filename = "test_case.json"
        test_data: dict[str, Any] = {"name": tc_name, "base_url": base_url, "steps": json_steps}
        (Path(tmp_dir) / test_filename).write_text(json.dumps(test_data, indent=2), encoding="utf-8")

        exec_session_id = exec_store.create_session(
            output_dir=tmp_dir,
            test_files=[test_filename],
            gen_session_id=None,
            base_url=base_url,
            headless=headless,
            skip_iframe_search=skip_iframe_search,
            step_retries=step_retries,
            testcase_id=testcase_id,
            original_steps=original_steps,
        )
        session = exec_store.get_session(exec_session_id)

    test_filename = session.test_files[0] if session.test_files else "test_case.json"
    test_path = Path(session.output_dir) / test_filename
    tc_display = session.testcase_id or "test_case"

    # ── Mark unfixable ────────────────────────────────────────────────────────
    if mark_unfixable:
        exec_store.record_result(exec_session_id, test_filename, tc_display, "unfixable", "Marked unfixable.")
        exec_store.finalize(exec_session_id)
        await _close_browser_pool(exec_session_id)
        return [TextContent(type="text", text=json.dumps({
            "execSessionId": exec_session_id,
            "status": "unfixable",
            "message": "Test marked as unfixable. Server was not updated.",
        }, indent=2))]

    # ── Apply fixed code ──────────────────────────────────────────────────────
    if fixed_code:
        try:
            fixed_data = json.loads(fixed_code)
            if not isinstance(fixed_data.get("steps"), list):
                raise ValueError("'steps' array is missing")
        except Exception as parse_err:
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "error": "fixed_code is not valid JSON — rejected without writing to disk.",
                "parseError": str(parse_err),
                "nextStep": "Fix the JSON and call again with corrected fixed_code.",
            }, indent=2))]

        # Align old vs new steps — allow additions and deletions
        current_data: dict = {}
        try:
            current_data = json.loads(test_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        current_steps: list = current_data.get("steps", [])
        fixed_steps_list: list = fixed_data.get("steps", [])

        matched, inserted, deleted = _align_steps_for_diff(current_steps, fixed_steps_list)

        # Guard: matched steps may only change css_selector, xpath, nth_appearance,
        # wait_before, wait_after — all other fields are immutable.
        _IMMUTABLE_FIELDS = (
            "action_taken", "mock_input",
            "description", "assertion_nature", "assertion_type", "assertion_value",
            "tag", "validation_type",
        )
        for old_i, new_i in matched:
            orig_step = current_steps[old_i]
            new_step = fixed_steps_list[new_i]
            for field in _IMMUTABLE_FIELDS:
                orig_val = orig_step.get(field)
                new_val = new_step.get(field)
                if orig_val != new_val:
                    return [TextContent(type="text", text=json.dumps({
                        "execSessionId": exec_session_id,
                        "error": (
                            f"Step {new_i}: field '{field}' was modified on an existing step — rejected. "
                            "Only css_selector or xpath may be changed on existing steps. "
                            "To change action_taken or mock_input, delete the step and add a new one."
                        ),
                        "originalValue": orig_val,
                        "attemptedValue": new_val,
                        "nextStep": f"Revert '{field}' on step {new_i} to its original value and only update css_selector/xpath.",
                    }, indent=2))]

        test_path.write_text(json.dumps(fixed_data, indent=2), encoding="utf-8")

    # ── Already completed? ────────────────────────────────────────────────────
    if session.status == "completed":
        await _close_browser_pool(exec_session_id)
        result = next((r for r in session.results if r.test_file == test_filename), None)
        return [TextContent(type="text", text=json.dumps({
            "execSessionId": exec_session_id,
            "status": result.status if result else "completed",
            "message": "Session already completed.",
        }, indent=2))]

    # ── Run the test ──────────────────────────────────────────────────────────
    run_result = await _run_test(
        session.output_dir,
        test_filename,
        headless=session.headless,
        exec_session_id=exec_session_id,
        skip_iframe_search=session.skip_iframe_search,
        page_timeout=60000,
    )

    if run_result.get("passed"):
        exec_store.record_result(exec_session_id, test_filename, tc_display, "passed", run_result["logs"])

        if not confirm_passed:
            # ── Phase A: passed but pending LLM review ────────────────────
            # Do NOT finalize or push — let the LLM verify step completeness.
            test_content = test_path.read_text(encoding="utf-8") if test_path.exists() else ""
            return [TextContent(type="text", text=json.dumps({
                "execSessionId": exec_session_id,
                "status": "passed_pending_review",
                "testcase_id": session.testcase_id,
                "currentCode": test_content,
                "reviewInstructions": _review_instructions(),
                "nextStep": (
                    "MANDATORY: Review every step in currentCode. Do NOT confirm blindly. "
                    "A login flow MUST have both email AND password steps. "
                    "Every test MUST have at least one assertion step. "
                    "If ANY step is missing, submit fixed_code with the added steps — "
                    "do NOT rationalize gaps away (e.g., 'maybe it's passwordless'). "
                    "ONLY call confirm_passed=true after verifying ALL form fields are "
                    "filled, ALL navigation is coherent, and at least one assertion exists."
                ),
            }, indent=2))]

        # ── Phase B: LLM confirmed — finalize and push to server ──────────
        exec_store.finalize(exec_session_id)
        await _close_browser_pool(exec_session_id)

        # Push fixed steps back to server: apply-changes → component update → run test
        update_report: list[str] = []
        apply_changes_reports: list[dict] = []
        run_test_report: dict = {}
        changes_id: str = ""

        if session.testcase_id and session.original_steps:
            try:
                final_steps = json.loads(test_path.read_text(encoding="utf-8")).get("steps", [])
                # Skip synthetic go_to preamble step (local-only, not on server)
                if (
                    final_steps
                    and final_steps[0].get("action_taken") == "go_to"
                    and final_steps[0].get("description") == _SYNTHETIC_GOTO_DESC
                ):
                    final_steps = final_steps[1:]

                # 1. Apply changes to changes table (generates changes_id)
                apply_payloads = _build_apply_changes_payloads(session.original_steps, final_steps)
                for ap in apply_payloads:
                    try:
                        async with MaerisClient() as client:
                            report = await client.apply_fix_changes(
                                session.testcase_id, ap
                            )
                        apply_changes_reports.append(report)
                        if not changes_id:
                            changes_id = report.get("changes_id") or ""
                    except Exception as ac_err:
                        apply_changes_reports.append({"error": str(ac_err)})

                # 2. Push fixed steps (component update — passes changes_id)
                update_report = await _push_fixed_steps_to_server(
                    session.testcase_id, session.original_steps, final_steps,
                    changes_id=changes_id,
                )

                # 3. Trigger server-side test run
                try:
                    async with MaerisClient() as client:
                        run_test_report = await client.run_testcases([session.testcase_id])
                except Exception as rt_err:
                    run_test_report = {"error": str(rt_err)}

            except Exception as push_err:
                update_report = [f"Warning: could not push step updates to server: {push_err}"]

        return [TextContent(type="text", text=json.dumps({
            "execSessionId": exec_session_id,
            "exec_dir": session.output_dir,
            "status": "passed",
            "testcase_id": session.testcase_id,
            "serverUpdate": update_report or ["No step changes — server already up to date."],
            "applyChanges": apply_changes_reports or [],
            "serverTestRun": run_test_report or {},
        }, indent=2))]

    # ── Test failed ───────────────────────────────────────────────────────────
    failed_step_idx = run_result.get("failed_step_index", -1)
    timed_out = "[TIMEOUT]" in run_result["logs"]
    fix_count = exec_store.increment_step_fix(exec_session_id, failed_step_idx) if failed_step_idx >= 0 else 0
    exec_store.record_result(exec_session_id, test_filename, tc_display, "failed", run_result["logs"])

    if fix_count > session.step_retries:
        exec_store.finalize(exec_session_id)
        await _close_browser_pool(exec_session_id)
        return [TextContent(type="text", text=json.dumps({
            "execSessionId": exec_session_id,
            "status": "failed",
            "message": (
                f"Exhausted {session.step_retries} fix attempts for step {failed_step_idx + 1}. "
                "Server was not updated."
            ),
            "logs": _truncate_logs(run_result["logs"]),
        }, indent=2))]

    test_content = test_path.read_text(encoding="utf-8") if test_path.exists() else ""
    fixes_left = session.step_retries - fix_count

    return [TextContent(type="text", text=json.dumps({
        "execSessionId": exec_session_id,
        "status": "timeout" if timed_out else "failed",
        "failedStep": {
            "index": failed_step_idx,
            "fixAttempt": fix_count,
            "maxFixAttempts": session.step_retries,
            "fixesLeft": fixes_left,
        },
        "logs": _truncate_logs(run_result["logs"]),
        "elementInventory": run_result.get("element_inventory", ""),
        "failingStepVisible": run_result.get("failing_step_visible"),
        "currentCode": test_content,
        "fixInstructions": _fix_instructions(timed_out=timed_out, selector_only=False),
        "nextStep": (
            "Analyze the logs and currentCode. "
            "Call run_and_fix_test_case with exec_session_id + fixed_code. "
            "You may change css_selector/xpath on existing steps. "
            "You may also ADD new steps or DELETE unnecessary steps to complete the test."
        ),
    }, indent=2))]
