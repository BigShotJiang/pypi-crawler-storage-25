"""Detail query tools for conversational follow-up.

These tools let users ask "why did my tests fail?", "show me the critical
findings", "what tests were generated?" etc. after operations complete.
They query stored session data that would otherwise be lost to truncation.
"""

from __future__ import annotations

import json
from mcp.types import TextContent, Tool

from maeris_mcp.storage.execution_store import TestExecutionStore
from maeris_mcp.storage.security_store import SecurityScanStore
from maeris_mcp.storage.test_store import TestGenerationStore
from maeris_mcp.storage.api_store import APIStore


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

def get_test_execution_details_tool() -> Tool:
    return Tool(
        name="get_test_execution_details",
        description=(
            "Retrieve detailed test execution results including per-test failure reasons, "
            "logs, fix attempts, and step-level details. Use this when the user asks "
            "'why did my tests fail?', 'what went wrong?', 'show me the errors', etc. "
            "Can look up by exec_session_id or return the most recent execution."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "exec_session_id": {
                    "type": "string",
                    "description": "Execution session ID. If omitted, returns the most recent execution.",
                },
                "status_filter": {
                    "type": "string",
                    "enum": ["failed", "passed", "unfixable", "all"],
                    "description": "Filter results by status. Defaults to 'all'.",
                },
            },
            "additionalProperties": False,
        },
    )


def get_test_generation_details_tool() -> Tool:
    return Tool(
        name="get_test_generation_details",
        description=(
            "Retrieve details about a test generation session: what tests were generated, "
            "the test plan, discovered flows, auth configuration, and scan notes. "
            "Use when user asks 'what tests did you generate?', 'show me the test plan', etc."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Test generation session ID. If omitted, returns the most recent session.",
                },
            },
            "additionalProperties": False,
        },
    )


def search_security_findings_tool() -> Tool:
    return Tool(
        name="search_security_findings",
        description=(
            "Search and filter security scan findings by severity, OWASP category, file path, "
            "or rule ID. Use when user asks 'show me the critical issues', 'what vulnerabilities "
            "are in auth.js?', 'list all XSS findings', etc."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {
                    "type": "string",
                    "description": "Security scan ID. If omitted, uses the most recent scan.",
                },
                "severity": {
                    "type": "string",
                    "enum": ["critical", "high", "medium", "low", "info"],
                    "description": "Filter by severity level.",
                },
                "file_path": {
                    "type": "string",
                    "description": "Filter findings that match this file path (partial match).",
                },
                "owasp_category": {
                    "type": "string",
                    "description": "Filter by OWASP category (e.g., 'A01', 'A03', 'injection').",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max findings to return. Defaults to 20.",
                },
            },
            "additionalProperties": False,
        },
    )


def search_accessibility_findings_tool() -> Tool:
    return Tool(
        name="search_accessibility_findings",
        description=(
            "Search accessibility scan findings by impact level, file, or rule. "
            "Use when user asks 'show critical accessibility issues', 'what WCAG violations "
            "are in my forms?', etc."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {
                    "type": "string",
                    "description": "Accessibility scan ID. If omitted, uses the most recent scan.",
                },
                "impact": {
                    "type": "string",
                    "enum": ["critical", "serious", "moderate", "minor"],
                    "description": "Filter by impact level.",
                },
                "file_path": {
                    "type": "string",
                    "description": "Filter findings matching this file path.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max findings to return. Defaults to 20.",
                },
            },
            "additionalProperties": False,
        },
    )


def search_gdpr_findings_tool() -> Tool:
    return Tool(
        name="search_gdpr_findings",
        description=(
            "Search GDPR/privacy scan findings by category, severity, or file. "
            "Use when user asks 'what privacy issues were found?', 'show cookie violations', etc."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {
                    "type": "string",
                    "description": "GDPR scan ID. If omitted, uses the most recent scan.",
                },
                "severity": {
                    "type": "string",
                    "enum": ["critical", "high", "medium", "low"],
                    "description": "Filter by severity.",
                },
                "category": {
                    "type": "string",
                    "description": "Filter by category (e.g., 'pre-consent cookies', 'localStorage PII').",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max findings to return. Defaults to 20.",
                },
            },
            "additionalProperties": False,
        },
    )


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def handle_get_test_execution_details(
    exec_store: TestExecutionStore,
    arguments: dict,
) -> list[TextContent]:
    exec_id = arguments.get("exec_session_id")
    status_filter = arguments.get("status_filter", "all")

    session = None
    if exec_id:
        session = exec_store.get_session(exec_id)
    else:
        # Find most recent
        for sid, s in exec_store._sessions.items():
            if not session or s.created_at > session.created_at:
                session = s

    if not session:
        return [TextContent(type="text", text="Error: No test execution session found. Run tests first.")]

    results = session.results
    if status_filter != "all":
        results = [r for r in results if r.status == status_filter]

    output = {
        "exec_session_id": session.exec_session_id,
        "gen_session_id": session.gen_session_id,
        "status": session.status,
        "base_url": session.base_url,
        "created_at": session.created_at,
        "total_tests": len(session.results),
        "passed": sum(1 for r in session.results if r.status == "passed"),
        "failed": sum(1 for r in session.results if r.status in ("failed", "error")),
        "unfixable": sum(1 for r in session.results if r.status == "unfixable"),
        "results": [],
    }

    for r in results:
        entry = {
            "test_name": r.test_name,
            "test_file": r.test_file,
            "status": r.status,
            "attempts": r.attempts,
        }
        if r.status in ("failed", "error", "unfixable") and r.logs:
            # Extract meaningful failure info from logs
            entry["failure_details"] = _extract_failure_details(r.logs)
            entry["full_logs"] = r.logs[:3000] if len(r.logs) > 3000 else r.logs
        output["results"].append(entry)

    # Include failed descriptions if any
    if session.failed_descriptions:
        output["failure_summary"] = session.failed_descriptions

    # Include fix attempt counts
    if session.step_fix_counts:
        output["fix_attempts"] = session.step_fix_counts

    output["_summary"] = f"Execution details: {output['passed']} passed, {output['failed']} failed, {output['unfixable']} unfixable"
    output["_next_actions"] = [
        {"action": f"run_and_fix_tests(exec_session_id=\"{session.exec_session_id}\")", "label": "Re-run failing tests"},
    ]

    return [TextContent(type="text", text=json.dumps(output, indent=2, default=str))]


async def handle_get_test_generation_details(
    test_store: TestGenerationStore,
    arguments: dict,
) -> list[TextContent]:
    session_id = arguments.get("session_id")

    session = None
    if session_id:
        session = test_store.get_session(session_id)
    else:
        for sid, s in test_store._sessions.items():
            if not session:
                session = s

    if not session:
        return [TextContent(type="text", text="Error: No test generation session found. Generate tests first.")]

    test_cases = []
    if hasattr(session, "test_cases") and session.test_cases:
        for tc in session.test_cases:
            tc_data = {"name": tc.name if hasattr(tc, "name") else str(tc)}
            if hasattr(tc, "steps"):
                tc_data["step_count"] = len(tc.steps)
                tc_data["steps"] = [
                    {
                        "action": s.get("action_taken", s.get("action", "")),
                        "selector": s.get("css_selector", ""),
                        "description": s.get("description", s.get("step_name", "")),
                    }
                    for s in (tc.steps if isinstance(tc.steps, list) else [])
                ][:10]  # First 10 steps
            test_cases.append(tc_data)

    output = {
        "session_id": session.session_id if hasattr(session, "session_id") else session_id,
        "flow_description": session.flow_description if hasattr(session, "flow_description") else None,
        "status": "completed" if (hasattr(session, "finalized") and session.finalized) else "in_progress",
        "output_dir": session.output_dir if hasattr(session, "output_dir") else None,
        "total_tests": len(test_cases),
        "test_cases": test_cases,
    }

    # Include test plan if available
    if hasattr(session, "test_plan") and session.test_plan:
        output["test_plan"] = session.test_plan

    # Include auth config
    if hasattr(session, "auth_config") and session.auth_config:
        output["auth_config"] = session.auth_config

    output["_summary"] = f"Generation session: {len(test_cases)} tests for '{output.get('flow_description', 'unknown')}'"

    return [TextContent(type="text", text=json.dumps(output, indent=2, default=str))]


async def handle_search_security_findings(
    security_store: SecurityScanStore,
    arguments: dict,
) -> list[TextContent]:
    scan_id = arguments.get("scan_id")
    severity = arguments.get("severity")
    file_path = arguments.get("file_path")
    owasp_cat = arguments.get("owasp_category")
    limit = arguments.get("limit", 20)

    scan = None
    if scan_id:
        scan = security_store.get(scan_id)
    else:
        for sid, s in security_store._scans.items():
            if s.finalized:
                scan = s
                scan_id = sid

    if not scan or not scan.result:
        return [TextContent(type="text", text="Error: No security scan found. Run a security scan first.")]

    findings = scan.result.findings if hasattr(scan.result, "findings") else []

    # Apply filters
    if severity:
        findings = [f for f in findings if getattr(f, "severity", "").lower() == severity.lower()]
    if file_path:
        findings = [f for f in findings if file_path.lower() in getattr(f, "file_path", "").lower()]
    if owasp_cat:
        findings = [f for f in findings if owasp_cat.lower() in getattr(f, "owasp_category", "").lower()]

    total = len(findings)
    findings = findings[:limit]

    output = {
        "scan_id": scan_id,
        "total_matching": total,
        "showing": len(findings),
        "filters": {k: v for k, v in {"severity": severity, "file_path": file_path, "owasp_category": owasp_cat}.items() if v},
        "findings": [
            {
                "id": getattr(f, "id", ""),
                "severity": getattr(f, "severity", ""),
                "description": getattr(f, "description", ""),
                "file_path": getattr(f, "file_path", ""),
                "line_start": getattr(f, "line_start", None),
                "owasp_category": getattr(f, "owasp_category", ""),
                "code_snippet": getattr(f, "code_snippet", ""),
                "suggested_fix": getattr(f, "suggested_fix", ""),
                "confidence": getattr(f, "confidence", ""),
            }
            for f in findings
        ],
    }

    output["_summary"] = f"{total} finding{'s' if total != 1 else ''} matching filters"

    return [TextContent(type="text", text=json.dumps(output, indent=2, default=str))]


async def handle_search_accessibility_findings(
    accessibility_store,
    arguments: dict,
) -> list[TextContent]:
    scan_id = arguments.get("scan_id")
    impact = arguments.get("impact")
    file_path = arguments.get("file_path")
    limit = arguments.get("limit", 20)

    scan = None
    if not accessibility_store or not hasattr(accessibility_store, "_scans"):
        return [TextContent(type="text", text="Error: No accessibility scan found.")]

    if scan_id:
        scan = accessibility_store._scans.get(scan_id)
    else:
        for sid, s in accessibility_store._scans.items():
            if s.finalized:
                scan = s
                scan_id = sid

    if not scan or not scan.result:
        return [TextContent(type="text", text="Error: No accessibility scan found. Run an accessibility scan first.")]

    findings = scan.result.findings if hasattr(scan.result, "findings") else []

    if impact:
        findings = [f for f in findings if getattr(f, "impact", "").lower() == impact.lower()]
    if file_path:
        findings = [f for f in findings if file_path.lower() in getattr(f, "file_path", "").lower()]

    total = len(findings)
    findings = findings[:limit]

    output = {
        "scan_id": scan_id,
        "total_matching": total,
        "showing": len(findings),
        "findings": [
            {
                "id": getattr(f, "id", ""),
                "impact": getattr(f, "impact", ""),
                "rule_id": getattr(f, "rule_id", ""),
                "description": getattr(f, "description", ""),
                "file_path": getattr(f, "file_path", ""),
                "line_start": getattr(f, "line_start", None),
                "code_snippet": getattr(f, "code_snippet", ""),
                "help_url": getattr(f, "helpUrl", getattr(f, "help_url", "")),
            }
            for f in findings
        ],
    }

    output["_summary"] = f"{total} accessibility finding{'s' if total != 1 else ''} matching filters"

    return [TextContent(type="text", text=json.dumps(output, indent=2, default=str))]


async def handle_search_gdpr_findings(
    gdpr_store,
    arguments: dict,
) -> list[TextContent]:
    scan_id = arguments.get("scan_id")
    severity = arguments.get("severity")
    category = arguments.get("category")
    limit = arguments.get("limit", 20)

    if not gdpr_store or not hasattr(gdpr_store, "_scans"):
        return [TextContent(type="text", text="Error: No GDPR scan found.")]

    scan = None
    if scan_id:
        scan = gdpr_store._scans.get(scan_id)
    else:
        for sid, s in gdpr_store._scans.items():
            if s.finalized:
                scan = s
                scan_id = sid

    if not scan or not scan.result:
        return [TextContent(type="text", text="Error: No GDPR scan found. Run a GDPR scan first.")]

    findings = scan.result.findings if hasattr(scan.result, "findings") else []

    if severity:
        findings = [f for f in findings if getattr(f, "severity", "").lower() == severity.lower()]
    if category:
        findings = [f for f in findings if category.lower() in getattr(f, "category", "").lower()]

    total = len(findings)
    findings = findings[:limit]

    output = {
        "scan_id": scan_id,
        "total_matching": total,
        "showing": len(findings),
        "findings": [
            {
                "id": getattr(f, "id", ""),
                "severity": getattr(f, "severity", ""),
                "category": getattr(f, "category", ""),
                "issue": getattr(f, "issue", ""),
                "details": getattr(f, "details", ""),
                "file_path": getattr(f, "file_path", ""),
                "line_start": getattr(f, "line_start", None),
                "code_snippet": getattr(f, "code_snippet", ""),
                "suggested_fix": getattr(f, "suggested_fix", ""),
            }
            for f in findings
        ],
    }

    output["_summary"] = f"{total} GDPR finding{'s' if total != 1 else ''} matching filters"

    return [TextContent(type="text", text=json.dumps(output, indent=2, default=str))]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_failure_details(logs: str) -> str:
    """Extract the most meaningful failure information from raw logs."""
    if not logs:
        return "No failure details available"

    lines = logs.strip().split("\n")
    # Look for error lines, assertion failures, timeout messages
    error_indicators = ["error:", "Error:", "FAILED", "TimeoutError", "AssertionError",
                        "ElementNotFound", "selector", "locator", "timeout", "not found",
                        "could not", "Cannot", "unable"]

    relevant = []
    for line in lines:
        if any(ind.lower() in line.lower() for ind in error_indicators):
            relevant.append(line.strip())

    if relevant:
        return "\n".join(relevant[:10])  # Top 10 error lines

    # Fallback: last 5 lines
    return "\n".join(lines[-5:])
