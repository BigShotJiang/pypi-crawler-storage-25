"""Post-processing layer that enriches tool responses with summary and next_actions.

This module is applied AFTER handlers return results, so individual tool
files do not need to be modified. It parses the JSON response and injects
`summary` and `next_actions` fields based on the tool name and response content.
"""

from __future__ import annotations

import json

from mcp.types import TextContent


def enrich_response(
    tool_name: str,
    result: list[TextContent],
) -> list[TextContent]:
    """Add summary + next_actions to a tool response if applicable.

    Only enriches responses that are:
    - A single TextContent item
    - Valid JSON (dict or list)
    - Not already an error response
    """
    if not result or len(result) != 1:
        return result

    text = result[0].text
    if text.startswith("Error:"):
        return result

    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return result

    # Only enrich dict responses (not plain lists)
    if isinstance(data, dict):
        enricher = _ENRICHERS.get(tool_name)
        if enricher:
            enricher(data, tool_name)
            return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

    # For list responses (like list_apis, list_collections), wrap with metadata
    if isinstance(data, list):
        enricher = _LIST_ENRICHERS.get(tool_name)
        if enricher:
            wrapped = enricher(data, tool_name)
            return [TextContent(type="text", text=json.dumps(wrapped, indent=2, default=str))]

    return result


# ---------------------------------------------------------------------------
# Enrichment functions for dict responses
# ---------------------------------------------------------------------------

def _enrich_security_scan(data: dict, tool_name: str) -> None:
    if data.get("status") == "completed" and "summary" in data:
        s = data["summary"]
        total = s.get("total_findings", 0)
        by_sev = s.get("by_severity", {})
        critical = by_sev.get("critical", 0)
        high = by_sev.get("high", 0)
        files = s.get("files_scanned", 0)

        parts = [f"Security scan complete: {total} finding{'s' if total != 1 else ''}"]
        if critical:
            parts.append(f"{critical} critical")
        if high:
            parts.append(f"{high} high")
        parts.append(f"across {files} files")

        data["_summary"] = " - ".join(parts[:2]) + (f" across {files} files" if files else "")
        scan_id = data.get("scanId", "")
        data["_next_actions"] = [
            {"action": f"push_to_maeris(scan_id=\"{scan_id}\")", "label": "Push findings to Maeris"},
            {"action": "api_scan(include_content=true)", "label": "Scan APIs for more coverage"},
            {"action": "accessibility_scan(include_content=true)", "label": "Run accessibility scan"},
        ]
    elif data.get("status") in ("pending", "in_progress", "scanning"):
        pagination = data.get("pagination", {})
        total = pagination.get("total", 0)
        offset = pagination.get("offset", 0)
        returned = pagination.get("returned", 0)
        data["_summary"] = f"Scanning: processed {offset + returned}/{total} files"


def _enrich_api_scan(data: dict, tool_name: str) -> None:
    if data.get("status") == "completed" and "summary" in data:
        s = data["summary"]
        total = s.get("total_apis", 0)
        by_method = s.get("by_method", {})
        method_parts = [f"{v} {k}" for k, v in by_method.items() if v]

        data["_summary"] = f"API scan complete: {total} endpoint{'s' if total != 1 else ''} found ({', '.join(method_parts[:3])})"
        data["_next_actions"] = [
            {"action": "add_apis_bulk(apis=<from scan>, auto_environment=true)", "label": "Save APIs to Maeris"},
            {"action": "security_scan(include_content=true)", "label": "Run security scan"},
            {"action": "check_api_coverage()", "label": "Check API test coverage"},
        ]
    elif data.get("status") in ("in_progress",):
        pagination = data.get("pagination", {})
        total = pagination.get("total", 0)
        offset = pagination.get("offset", 0)
        returned = pagination.get("returned", 0)
        data["_summary"] = f"Scanning: processed {offset + returned}/{total} files"




def _enrich_run_and_fix_tests(data: dict, tool_name: str) -> None:
    if data.get("status") == "completed":
        passed = data.get("passed", 0)
        failed = data.get("failed", 0)
        unfixable = data.get("unfixable", 0)
        total = data.get("totalTests", passed + failed + unfixable)
        session_id = data.get("execSessionId", "")

        data["_summary"] = f"Test execution complete: {passed}/{total} passed, {failed} failed" + (f", {unfixable} unfixable" if unfixable else "")
        actions = []
        if passed > 0:
            gen_sid = data.get("genSessionId", "")
            actions.append({"action": f"push_tests_to_maeris(session_id=\"{gen_sid}\")", "label": f"Push {passed} passing tests to Maeris"})
        if failed > 0:
            actions.append({"action": f"run_and_fix_tests(exec_session_id=\"{session_id}\")", "label": f"Retry {failed} failing tests"})
        actions.append({"action": "generate(command=<flow description>)", "label": "Generate more tests"})
        data["_next_actions"] = actions
    elif data.get("status") == "step_failed":
        data["_summary"] = f"Step failed in '{data.get('testName', '')}' — fix needed for selector: {data.get('selector', '')}"
    elif data.get("status") == "passed":
        data["_summary"] = f"Test '{data.get('testName', '')}' passed"


def _enrich_push_to_maeris(data: dict, tool_name: str) -> None:
    status = data.get("status", "")
    created = len(data.get("findings_created", []))
    data["_summary"] = f"Pushed {created} finding{'s' if created != 1 else ''} to Maeris" if status == "pushed" else f"Push partially failed — {created} created"
    data["_next_actions"] = [
        {"action": "security_scan(include_content=true)", "label": "Run another security scan"},
        {"action": "generate(command=<flow description>)", "label": "Generate tests"},
    ]


def _enrich_push_tests(data: dict, tool_name: str) -> None:
    count = data.get("pushed_count", data.get("totalPushed", 0))
    data["_summary"] = f"Pushed {count} test{'s' if count != 1 else ''} to Maeris"
    data["_next_actions"] = [
        {"action": "list_test_cases()", "label": "View all test cases"},
        {"action": "run_test_cases()", "label": "Run test cases on portal"},
    ]


def _enrich_add_apis_bulk(data: dict, tool_name: str) -> None:
    created = data.get("created", 0)
    coll = data.get("collection_id", "")
    data["_summary"] = f"Created {created} API{'s' if created != 1 else ''} in collection"
    data["_next_actions"] = [
        {"action": "generate_assertions()", "label": "Generate assertions for APIs"},
        {"action": f"run_collection(collection_id=\"{coll}\")", "label": "Run API collection"},
        {"action": "security_scan(include_content=true)", "label": "Run security scan"},
    ]


def _enrich_create_collection(data: dict, tool_name: str) -> None:
    name = data.get("name", "")
    data["_summary"] = f"Collection '{name}' created"
    data["_next_actions"] = [
        {"action": f"add_api(collection_name=\"{name}\")", "label": "Add APIs to collection"},
    ]


def _enrich_add_api(data: dict, tool_name: str) -> None:
    name = data.get("name", "")
    method = data.get("method", "")
    data["_summary"] = f"API '{method} {name}' created"
    data["_next_actions"] = [
        {"action": f"run_api(api_name=\"{name}\")", "label": "Run this API"},
        {"action": f"generate_assertions(api_name=\"{name}\")", "label": "Generate assertions"},
    ]


def _enrich_create_test_folder(data: dict, tool_name: str) -> None:
    name = data.get("folder_name", "")
    data["_summary"] = f"Test folder '{name}' created"
    data["_next_actions"] = [
        {"action": "list_test_cases()", "label": "View test cases"},
        {"action": "generate(command=<flow description>)", "label": "Generate tests"},
    ]


def _enrich_accessibility_scan(data: dict, tool_name: str) -> None:
    if data.get("status") == "completed" and "summary" in data:
        s = data["summary"]
        total = s.get("total_findings", 0)
        scan_id = data.get("scanId", "")
        data["_summary"] = f"Accessibility scan complete: {total} violation{'s' if total != 1 else ''} found"
        data["_next_actions"] = [
            {"action": f"push_accessibility_to_maeris(scan_id=\"{scan_id}\")", "label": "Push to Maeris"},
            {"action": "gdpr_scan(include_content=true)", "label": "Run GDPR scan"},
        ]


def _enrich_gdpr_scan(data: dict, tool_name: str) -> None:
    if data.get("status") == "completed" and "summary" in data:
        s = data["summary"]
        total = s.get("total_findings", 0)
        scan_id = data.get("scanId", "")
        data["_summary"] = f"GDPR scan complete: {total} privacy issue{'s' if total != 1 else ''} found"
        data["_next_actions"] = [
            {"action": f"push_gdpr_to_maeris(scan_id=\"{scan_id}\")", "label": "Push to Maeris"},
            {"action": "security_scan(include_content=true)", "label": "Run security scan"},
        ]


def _enrich_run_api(data: dict, tool_name: str) -> None:
    status = data.get("status_code", data.get("statusCode", ""))
    name = data.get("api_name", data.get("name", ""))
    data["_summary"] = f"API '{name}' returned status {status}"
    data["_next_actions"] = [
        {"action": f"generate_assertions(api_name=\"{name}\")", "label": "Generate assertions from response"},
    ]


def _enrich_switch_app(data: dict, tool_name: str) -> None:
    if data.get("status") == "switched":
        name = data.get("name", "")
        data["_summary"] = f"Switched to application '{name}'"
        data["_next_actions"] = [
            {"action": "list_test_cases()", "label": "View tests"},
            {"action": "list_collections()", "label": "View API collections"},
            {"action": "security_scan(include_content=true)", "label": "Run security scan"},
        ]


def _enrich_login(data: dict, tool_name: str) -> None:
    if data.get("status") == "authenticated":
        data["_summary"] = "Successfully authenticated"
        data["_next_actions"] = [
            {"action": "get_applications()", "label": "List applications"},
            {"action": "maeris_status()", "label": "Check status"},
        ]


# ---------------------------------------------------------------------------
# Enrichment functions for list responses (wrap in dict with metadata)
# ---------------------------------------------------------------------------

def _enrich_list_apis(data: list, tool_name: str) -> dict:
    methods = {}
    for api in data:
        m = api.get("method", "UNKNOWN")
        methods[m] = methods.get(m, 0) + 1
    method_str = ", ".join(f"{v} {k}" for k, v in methods.items())

    return {
        "data": data,
        "_summary": f"{len(data)} API{'s' if len(data) != 1 else ''} found ({method_str})",
        "_next_actions": [
            {"action": "run_collection()", "label": "Run API collection"},
            {"action": "api_scan(include_content=true)", "label": "Scan for more APIs"},
            {"action": "check_api_coverage()", "label": "Check coverage"},
        ],
    }


def _enrich_list_collections(data: list, tool_name: str) -> dict:
    return {
        "data": data,
        "_summary": f"{len(data)} collection{'s' if len(data) != 1 else ''}",
        "_next_actions": [
            {"action": "create_collection(name=<name>)", "label": "Create new collection"},
            {"action": "list_apis()", "label": "List all APIs"},
        ],
    }


def _enrich_list_test_cases(data: list, tool_name: str) -> dict:
    return {
        "data": data,
        "_summary": f"{len(data)} test case{'s' if len(data) != 1 else ''}",
        "_next_actions": [
            {"action": "run_test_cases()", "label": "Run tests"},
            {"action": "generate(command=<flow description>)", "label": "Generate more tests"},
        ],
    }


def _enrich_list_test_folders(data: list, tool_name: str) -> dict:
    return {
        "data": data,
        "_summary": f"{len(data)} test folder{'s' if len(data) != 1 else ''}",
        "_next_actions": [
            {"action": "create_test_folder(name=<name>)", "label": "Create folder"},
            {"action": "list_test_cases()", "label": "List test cases"},
        ],
    }


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_ENRICHERS: dict[str, callable] = {
    "security_scan": _enrich_security_scan,
    "api_scan": _enrich_api_scan,
    "run_and_fix_tests": _enrich_run_and_fix_tests,
    "run_and_fix_test_case": _enrich_run_and_fix_tests,
    "push_to_maeris": _enrich_push_to_maeris,
    "push_tests_to_maeris": _enrich_push_tests,
    "add_apis_bulk": _enrich_add_apis_bulk,
    "create_collection": _enrich_create_collection,
    "add_api": _enrich_add_api,
    "create_test_folder": _enrich_create_test_folder,
    "accessibility_scan": _enrich_accessibility_scan,
    "gdpr_scan": _enrich_gdpr_scan,
    "run_api": _enrich_run_api,
    "switch_application": _enrich_switch_app,
    "login": _enrich_login,
}

_LIST_ENRICHERS: dict[str, callable] = {
    "list_apis": _enrich_list_apis,
    "list_apis_in_collection": _enrich_list_apis,
    "list_collections": _enrich_list_collections,
    "list_test_cases": _enrich_list_test_cases,
    "list_test_folders": _enrich_list_test_folders,
}
