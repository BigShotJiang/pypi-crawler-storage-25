import json
import os
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import structlog
from mcp.types import TextContent, Tool

log = structlog.get_logger(__name__)

_STRUCTURE_FLAGS = [
    "--print",
    "--no-session-persistence",
]

_NAV_FILE_RE = re.compile(
    r"(route|router|routing|navigation|navbar|sidebar|menu|auth|guard|middleware|layout)",
    re.IGNORECASE,
)

_STOP_WORDS = {
    "a", "an", "the", "for", "to", "of", "in", "on", "at", "is", "are",
    "and", "or", "with", "from", "that", "this", "it", "as", "be", "by",
    "generate", "testcases", "test", "cases", "steps", "flow", "create",
    "write", "run", "check", "verify", "make",
}


def _extract_json_array(text: str) -> str | None:
    """Return the outermost JSON array from *text* by walking backwards from the
    last ``]`` to its matching ``[``.  This avoids the greedy ``.*`` pitfall where
    prose containing ``[`` before the real array is included in the match."""
    end = text.rfind("]")
    if end == -1:
        return None
    depth = 0
    for i in range(end, -1, -1):
        if text[i] == "]":
            depth += 1
        elif text[i] == "[":
            depth -= 1
            if depth == 0:
                return text[i : end + 1]
    return None


def _keywords(text: str) -> set[str]:
    return {
        w.lower() for w in re.findall(r"[a-zA-Z]+", text)
        if w.lower() not in _STOP_WORDS and len(w) > 2
    }



def _parse_test_count(command: str) -> int | None:
    """Extract an explicit test case count from the command string."""
    match = re.search(
        r"\b(\d+)\s+(?:test\s*cases?|tests?|testcases?|e2e\s+tests?|scenarios?)\b",
        command,
        re.IGNORECASE,
    )
    return int(match.group(1)) if match else None


def _get_proven_context() -> tuple[str, str]:
    """Read RepoFeedbackCache and return (phase1_hint, phase2_section).

    phase1_hint  — nav sequences injected into the exploration task so Claude
                   knows which paths are already confirmed and can verify them.
    phase2_section — proven selectors grouped by page, injected into the
                     structure prompt so the subprocess uses confirmed selectors.

    Returns ("", "") if cache is unavailable, empty, or auth is missing.
    """
    try:
        from maeris_mcp.auth.token_store import TokenStore
        from maeris_mcp.storage.feedback_cache import RepoFeedbackCache

        token_store = TokenStore()
        app_id = token_store.get_app_id()
        if not app_id:
            return "", ""

        entry = RepoFeedbackCache(os.getcwd(), app_id).load()
        if not entry.proven_selectors and not entry.proven_nav_sequences:
            return "", ""

        # --- Phase 1: nav sequences only ---
        phase1_hint = ""
        if entry.proven_nav_sequences:
            nav_lines = []
            for nav in entry.proven_nav_sequences[:10]:
                from_page = nav.get("from_page", "")
                to_page = nav.get("to_page", "")
                pass_count = nav.get("pass_count", 1)
                nav_lines.append(f"  - {from_page} → {to_page} (passed {pass_count}×)")
            if nav_lines:
                phase1_hint = (
                    "\n\nVERIFIED NAVIGATION PATHS FROM PASSING TESTS:\n"
                    + "\n".join(nav_lines)
                    + "\nThese paths are confirmed working. "
                    "Verify the selectors still exist in source and report any changes.\n"
                )

        # --- Phase 2: proven selectors grouped by page ---
        phase2_section = ""
        if entry.proven_selectors:
            by_page: dict[str, list[dict]] = {}
            for sel in entry.proven_selectors[:40]:
                page = sel.get("page_url", "unknown")
                by_page.setdefault(page, []).append(sel)
            sel_lines = []
            for page, sels in sorted(by_page.items()):
                sel_lines.append(f"  Page: {page}")
                for s in sels[:5]:
                    sel_lines.append(
                        f"    {s.get('selector', '')} → {s.get('action', '')} "
                        f"[{s.get('pass_count', 0)} passes]"
                    )
            if sel_lines:
                phase2_section = (
                    "VERIFIED SELECTORS FROM PASSING TESTS — use these exactly "
                    "where they match the flow being generated:\n"
                    + "\n".join(sel_lines)
                    + "\n\n"
                )

        return phase1_hint, phase2_section
    except Exception:
        return "", ""


def _nav_is_stale() -> bool:
    """Return True if navigation.md is missing or outdated based on git changes.

    Compares the git hash stored when navigation.md was last written against
    the current HEAD. If they differ, checks whether any changed files match
    routing/auth patterns. Degrades gracefully — returns False if git is
    unavailable or any step fails, so generation is never blocked.
    """
    config_dir = Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
    nav_path = config_dir / "navigation.md"
    meta_path = config_dir / "navigation.meta.json"

    if not nav_path.exists():
        return True

    if not meta_path.exists():
        # navigation.md exists but was written before hash tracking — treat as stale
        return True

    try:
        stored_hash = json.loads(meta_path.read_text(encoding="utf-8")).get("git_hash", "")
        if not stored_hash:
            return True

        _no_window = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        current = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL, **_no_window,
        )
        if current.returncode != 0:
            return False  # not a git repo or git unavailable — don't block

        if current.stdout.strip() == stored_hash:
            return False  # nothing changed at all

        diff = subprocess.run(
            ["git", "diff", stored_hash, "HEAD", "--name-only"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL, **_no_window,
        )
        if diff.returncode != 0:
            return False  # graceful degradation

        return any(_NAV_FILE_RE.search(f) for f in diff.stdout.strip().splitlines())

    except Exception:
        return False  # graceful degradation


_NAVIGATE_ACTIONS = frozenset({"navigate", "go_to", "goto", "open"})

# ---------------------------------------------------------------------------
# Mirabilis assertion schema — single source of truth
# ---------------------------------------------------------------------------
# Changing a type here automatically updates the Phase 2 prompt.

MIRABILIS_ASSERTIONS: dict[str, dict] = {
    "existence": {
        "css_selector": "empty string — ALWAYS set to empty string. The css_selector is completely ignored for existence assertions at runtime.",
        "assertion_value": (
            "REQUIRED — the exact visible text rendered on the page that you expect to find. "
            "This is passed verbatim to page.get_by_text(). "
            "IMPORTANT: page.get_by_text() only matches rendered text nodes — it does NOT "
            "read values inside <input>, <select>, <textarea>, or any other form element. "
            "To check a form element's value, use nature='input' with 'to have value' instead. "
            "Never omit or leave empty."
        ),
        "types": [
            "to be visible",
            "not to be visible",
        ],
    },
    "page": {
        "css_selector": "empty string",
        "assertion_value": "REQUIRED — URL path fragment (for to contain url / to have url) or exact page title (for to have title). Never omit.",
        "types": [
            "to have url",
            "to contain url",   # prefer over "to have url" for partial matches
            "to have title",
        ],
    },
    "input": {
        "css_selector": "required",
        "assertion_value": "expected value or text",
        "types": [
            "to have value",
            "to contain value",
            "to have text",
            "to contain text",
            "to be visible",
            "to be hidden",
            "to be enabled",
            "to be disabled",
            "to be editable",
            "to be empty",
            "to be focussed",   # double-s spelling required
            "to be checked",
            "to be not checked",
            "to be selected",
            "not to be selected",
            "has default option",
            "has option",
            "assert all options",
            "to be password",
            "to be email",
            "to be number",
            "to be date",
        ],
    },
}


def _build_assertion_rules() -> str:
    """Generate the assertion rules block for the Phase 2 prompt from MIRABILIS_ASSERTIONS.

    Produces a self-contained, copy-paste-ready block that lists every allowed
    assertion_nature / assertion_type combination with css_selector and
    assertion_value guidance.
    """
    lines: list[str] = [
        "ALLOWED ASSERTION VALUES (assertion steps only -- no action_taken field):",
        "",
    ]
    for nature, meta in MIRABILIS_ASSERTIONS.items():
        types_str = " | ".join(f'"{t}"' for t in meta["types"])
        lines.append(f'  assertion_nature="{nature}"')
        lines.append(f'    css_selector : {meta["css_selector"]}')
        lines.append(f'    assertion_value: {meta["assertion_value"]}')
        lines.append(f'    assertion_type : {types_str}')
        lines.append("")

    lines += [
        'NEVER use shorthand like "visible", "url_contains", "value_equals" -- use exact strings only.',
        'Prefer "to contain url" over "to have url" for partial URL matches.',
        "",
        "URL ASSERTION RULES:",
        '  For "to contain url": assertion_value MUST be a plain path fragment, e.g. "/settings".',
        "  NEVER construct a full URL (do not append paths to login_url or app_origin).",
        "  NEVER use a path fragment that appears only in feedback text -- it must exist in the",
        "  findings or navigation map. If you cannot confirm the route, omit the URL assertion.",
        "",
        "ASSERTION QUICK REFERENCE:",
        '  Page URL check      -> nature="page",      type="to contain url",    css_selector="",  assertion_value="/path-fragment"',
        '  Text on page        -> nature="existence", type="to be visible",     css_selector="",  assertion_value="<exact rendered text>"',
        '  Text absent         -> nature="existence", type="not to be visible", css_selector="",  assertion_value="<exact rendered text>"',
        '  Element visible     -> nature="input",     type="to be visible",     css_selector="<sel>", assertion_value=""',
        '  Input has value     -> nature="input",     type="to have value",     css_selector="<sel>", assertion_value="<expected val>"',
        '  Element text        -> nature="input",     type="to contain text",   css_selector="<sel>", assertion_value="<expected text>"',
        "",
        "EXISTENCE vs INPUT — choosing the right nature:",
        "  existence: use when you want to confirm text is (or is not) visible anywhere on the page.",
        "             Runs page.get_by_text(assertion_value). css_selector is ALWAYS empty string.",
        "             Does NOT check <input> values, <select> values, or any form element content.",
        "             Wrong choice: existence to check that a form field contains 'john@example.com'.",
        "             Right choice: input with 'to have value' and the field's css_selector.",
        "  input:     use when you have a specific element (by selector) whose state or value to check.",
        "",
        "CRITICAL — assertion_value is NEVER optional:",
        "  existence assertions: always set assertion_value to the exact rendered text you expect on the page. Never use a selector, attribute name, or form value here.",
        "  page assertions: always set assertion_value to the URL path fragment or exact page title.",
        "  input assertions: set assertion_value for to have value / to contain value / to have text / to contain text / has option / assert all options; use empty string for state checks (to be visible, to be hidden, to be enabled, etc.).",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Stage-3 enforcement: static selector inventory
# ---------------------------------------------------------------------------

_SKIP_DIRS = frozenset({
    "node_modules", ".next", ".git", "dist", "build", "out",
    "__pycache__", ".cache", "coverage", ".turbo", "vendor", ".venv",
    "venv", "env", ".pytest_cache", "storybook-static", "public",
})
_SOURCE_EXTS = frozenset({".js", ".jsx", ".ts", ".tsx", ".html", ".vue", ".svelte"})

# Matches an opening tag for interactive elements.
# Captures: group(1)=tag, group(2)=attribute string (may be multi-line in JSX).
_TAG_RE = re.compile(
    r"<(input|button|select|textarea|a)(\s(?:[^<>]|\"[^\"]*\"|'[^']*')*?)(?:/>|>)",
    re.DOTALL | re.IGNORECASE,
)

# Same structure as _TAG_RE but for div/span — only kept when _DIV_SPAN_INTERACTIVE matches.
_DIV_SPAN_RE = re.compile(
    r"<(div|span)(\s(?:[^<>]|\"[^\"]*\"|'[^']*')*?)(?:/>|>)",
    re.DOTALL | re.IGNORECASE,
)
# Signals that a div/span is interactive and worth including in the inventory.
_DIV_SPAN_INTERACTIVE = re.compile(
    r"\bonClick\b|role=[\"']|data-testid=|data-automation-id=|data-cy=|data-test=",
    re.IGNORECASE,
)


def _extract_literal_attr(attrs: str, attr_name: str) -> str | None:
    """Return the literal string value of *attr_name* from an attribute blob.

    Skips JSX/template expressions like attr={value} or attr={`${x}`} — only
    returns values that are quoted string literals so we know they are stable.
    """
    pattern = rf"\b{re.escape(attr_name)}=[\"']([^\"'{{}}]+)[\"']"
    m = re.search(pattern, attrs, re.IGNORECASE)
    return m.group(1).strip() if m else None


def _element_label(tag: str, attrs: str) -> str:
    """Short human-readable label for an interactive element."""
    for attr in ("data-testid", "data-automation-id", "data-cy", "data-test", "data-test-id", "aria-label", "name", "placeholder"):
        v = _extract_literal_attr(attrs, attr)
        if v:
            return v
    type_v = _extract_literal_attr(attrs, "type")
    if type_v:
        return f"{type_v} {tag}"
    return tag


def _best_selector(tag: str, attrs: str) -> tuple[str | None, str | None, str]:
    """Return (selector_string, attribute_used, tier) following the stability priority.

    Tier values:
    - "stable"  — data-testid, id, name, aria-label: safe to rely on in tests
    - "fragile" — type (non-generic), placeholder: works but may break with refactors
    - "none"    — no usable literal attribute found

    The caller uses the tier to decide whether to mark the element [UNCERTAIN].
    """
    # 1. data automation attributes — stable (highest priority)
    for auto_attr in ("data-testid", "data-automation-id", "data-cy", "data-test", "data-test-id"):
        v = _extract_literal_attr(attrs, auto_attr)
        if v:
            return f'[{auto_attr}="{v}"]', auto_attr, "stable"
    # 2. id — stable
    v = _extract_literal_attr(attrs, "id")
    if v:
        return f"#{v}", "id", "stable"
    # 3. name — stable
    v = _extract_literal_attr(attrs, "name")
    if v:
        return f'[name="{v}"]', "name", "stable"
    # 4. aria-label — stable
    v = _extract_literal_attr(attrs, "aria-label")
    if v:
        return f'[aria-label="{v}"]', "aria-label", "stable"
    # 5. type — stable for non-generic values (input[type="email"], button[type="submit"], etc.)
    if tag in ("input", "button"):
        v = _extract_literal_attr(attrs, "type")
        if v and v.lower() not in ("text", "hidden"):
            return f'{tag}[type="{v}"]', "type", "stable"
    # 6. placeholder — stable (works reliably in Playwright; existence check catches invented values)
    v = _extract_literal_attr(attrs, "placeholder")
    if v:
        return f'[placeholder="{v}"]', "placeholder", "stable"
    return None, None, "none"


def _classify_selector_confidence(css_selector: str) -> tuple[str, str]:
    """Classify a CSS selector as 'stable' (valid Playwright pattern) or 'uncertain'
    (structurally broken regardless of value).

    "Stable" here means the *pattern* is valid Playwright syntax and will work if
    the value exists in source.  The caller is responsible for the value-existence
    check (via _selector_in_inventory / _class_in_source).

    Rules:
    - Any ``[attr="value"]`` selector (with or without a tag prefix) → stable pattern.
      The existence check decides if it actually works.
    - ``#id`` → stable pattern.
    - Positional, bare-tag, structural, class, bare-type selectors → always uncertain
      because they can match the wrong element or break regardless of value existence.
    """
    if not css_selector:
        return "uncertain", "no selector provided"
    s = css_selector.strip()

    # Always-uncertain: positional selectors
    if ":nth-child" in s or ":nth-of-type" in s:
        return "uncertain", "positional selector — breaks if DOM order changes"

    # Always-uncertain: structural / combinator selectors (spaces or > + ~)
    if re.search(r"[\s>+~]", s):
        return "uncertain", "structural selector — breaks if DOM nesting changes"

    # Always-uncertain: class selectors (fragile regardless of whether class exists)
    if s.startswith("."):
        return "uncertain", "class selector — fragile if CSS is refactored"

    # Always-uncertain: bare tag only (no attribute qualifier)
    if re.match(r"^[a-zA-Z][\w-]*$", s):
        return "uncertain", "bare tag — not unique, matches any element of this type"

    # Always-uncertain: bare [type="..."] without a tag prefix — too generic
    if re.match(r"^\[type=", s):
        return "uncertain", "bare type attribute — not unique without a tag prefix"

    # Stable pattern: #id
    if re.match(r"^#[\w-]+$", s):
        return "stable", "id selector"

    # Stable pattern: any [attr="value"] or tag[attr="value"]
    if re.match(r"^(?:\w[\w-]*)?\[[\w-]+=", s):
        attr_m = re.search(r"\[([\w-]+)=", s)
        attr_name = attr_m.group(1) if attr_m else "attribute"
        return "stable", f"{attr_name} attribute selector"

    # Default uncertain for anything unrecognised
    return "uncertain", "unrecognised selector pattern — stability unknown"


def _selector_in_inventory(css_selector: str, inventory_text: str) -> bool:
    """Return True if the key attribute=value pair from *css_selector* appears
    in the inventory (meaning that element was actually found in source).

    Handles tag-prefixed selectors: ``input[name="email"]`` checks for ``name="email"``.
    Handles ``#id`` by checking for ``id="<value>"``.
    """
    # Extract all attr="value" pairs — works for [data-automation-id="x"], input[name="x"], etc.
    for m in re.finditer(r'([\w-]+)=["\']([^"\']+)["\']', css_selector):
        attr, val = m.group(1), m.group(2)
        if f'{attr}="{val}"' in inventory_text or f"{attr}='{val}'" in inventory_text:
            return True
    # Handle #id → look for id="value" in inventory
    id_m = re.match(r'^#([\w-]+)$', css_selector.strip())
    if id_m:
        id_val = id_m.group(1)
        return f'id="{id_val}"' in inventory_text or f"id='{id_val}'" in inventory_text
    return False


def _class_in_source(class_name: str, known_classes: frozenset[str]) -> bool:
    """Return True if *class_name* was seen in any source file during the last
    inventory scan.  O(1) set lookup — no filesystem walk needed.
    """
    return class_name in known_classes


_INVENTORY_CACHE_FILE = (
    Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
    / "selector_inventory.cache.json"
)

# Bump this whenever the inventory format changes (e.g. new tier markers, new
# column layout). A mismatch forces a full rebuild so Claude always sees the
# current format, even if the app code hasn't changed.
_INVENTORY_FORMAT_VERSION = "3"

def _git_head(scan_root: str) -> str:
    """Return the current git HEAD hash for *scan_root*, or '' on failure.

    Reads .git/HEAD and the pointed-at ref file directly — no subprocess,
    no shell overhead. Falls back to ``git rev-parse HEAD`` only when the
    direct-read path fails (e.g. worktrees, submodules, bare repos).
    """
    try:
        git_dir = Path(scan_root) / ".git"
        head_file = git_dir / "HEAD"
        if not head_file.exists():
            raise FileNotFoundError
        head = head_file.read_text(encoding="utf-8").strip()
        if head.startswith("ref: "):
            ref_path = git_dir / head[5:]   # e.g. refs/heads/main
            if ref_path.exists():
                return ref_path.read_text(encoding="utf-8").strip()
        elif len(head) == 40:               # detached HEAD
            return head
    except Exception:
        pass
    # Fallback: subprocess (worktrees, submodules, etc.)
    try:
        _no_window = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=4,
            cwd=scan_root, stdin=subprocess.DEVNULL, **_no_window,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _load_inventory_cache(scan_root: str, git_hash: str) -> str | None:
    """Return cached inventory text if it is still valid, otherwise None."""
    if not git_hash:
        return None
    try:
        if not _INVENTORY_CACHE_FILE.exists():
            return None
        data = json.loads(_INVENTORY_CACHE_FILE.read_text(encoding="utf-8"))
        if (
            data.get("git_hash") == git_hash
            and data.get("scan_root") == scan_root
            and data.get("format_version") == _INVENTORY_FORMAT_VERSION
        ):
            return data.get("inventory", "")
    except Exception:
        pass
    return None


def _uncertain_files_from_cache() -> list[str]:
    """Return absolute paths of source files that have [UNCERTAIN] elements in
    the cached selector inventory.

    These are the only files that need automation-attribute injection — files
    with all-stable selectors do not need to be touched.
    """
    try:
        if not _INVENTORY_CACHE_FILE.exists():
            return []
        data = json.loads(_INVENTORY_CACHE_FILE.read_text(encoding="utf-8"))
        inventory: str = data.get("inventory", "")
        scan_root: str = data.get("scan_root", "")
        if not inventory or not scan_root:
            return []

        files: list[str] = []
        seen: set[str] = set()
        for line in inventory.splitlines():
            if "[UNCERTAIN" not in line:
                continue
            # Lines look like:  "  rel/path/file.tsx:42  label  →  [UNCERTAIN ..."
            stripped = line.strip()
            if not stripped:
                continue
            # rel path is everything before the first ":"
            rel_part = stripped.split(":")[0].strip()
            abs_path = str(Path(scan_root) / rel_part)
            if abs_path not in seen:
                seen.add(abs_path)
                files.append(abs_path)
        return files
    except Exception:
        return []


def _save_inventory_cache(
    scan_root: str,
    git_hash: str,
    inventory: str,
    known_classes: set[str] | None = None,
) -> None:
    if not git_hash:
        return
    try:
        _INVENTORY_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _INVENTORY_CACHE_FILE.write_text(
            json.dumps({
                "git_hash": git_hash,
                "scan_root": scan_root,
                "inventory": inventory,
                "known_classes": sorted(known_classes) if known_classes else [],
                "format_version": _INVENTORY_FORMAT_VERSION,
            }),
            encoding="utf-8",
        )
    except Exception:
        pass


def _load_known_classes_from_cache() -> frozenset[str]:
    """Return the set of CSS class names collected during the last inventory scan.
    Fast — reads the already-written cache file, no filesystem walk needed.
    """
    try:
        if not _INVENTORY_CACHE_FILE.exists():
            return frozenset()
        data = json.loads(_INVENTORY_CACHE_FILE.read_text(encoding="utf-8"))
        return frozenset(data.get("known_classes", []))
    except Exception:
        return frozenset()


def _build_selector_inventory(
    scan_root: str,
    findings_hint: str = "",
    max_rows: int = 400,
) -> tuple[str, str]:
    """Statically scan the repo and return ``(filtered_inventory, full_inventory)``.

    ``filtered_inventory`` is prompt-ready (filtered to files mentioned in findings,
    capped at max_rows) — inject this into the Phase 2 prompt.
    ``full_inventory`` is the complete unfiltered text — use this for selector
    existence checks without a second cache read.

    Deterministic — no LLM involved. Results are cached by git HEAD hash so
    repeated calls within the same commit cost only a cache file read.
    """
    root = Path(scan_root)

    # ── cache check (fast path) ──────────────────────────────────────────────
    git_hash = _git_head(scan_root)
    cached = _load_inventory_cache(scan_root, git_hash)
    if cached is not None:
        log.info("generate.selector_inventory.cache_hit")
        return _filter_inventory_by_findings(cached, findings_hint, max_rows), cached

    # ── collect source files — single pruned os.walk, priority-sorted ────────
    # One walk builds a complete filename→paths index (skipping all _SKIP_DIRS
    # in-place so node_modules etc. are never descended into).
    # Mentioned files are then put at the front so they are always scanned and
    # included in the inventory regardless of how many other files exist.
    # This avoids a separate rglob per mentioned file, which would walk the
    # entire tree — including node_modules — for each filename.
    filename_index: dict[str, list[Path]] = {}
    for dirpath, dirnames, filenames in os.walk(scan_root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fname in filenames:
            if Path(fname).suffix.lower() not in _SOURCE_EXTS:
                continue
            fpath = Path(dirpath) / fname
            filename_index.setdefault(fname.lower(), []).append(fpath)

    # Extract mentioned file names from findings (basenames only)
    mentioned_names: list[str] = []
    if findings_hint:
        for m in re.finditer(
            r"([\w./ \\-]+\.(?:jsx|tsx|js|ts|html|vue|svelte))",
            findings_hint,
            re.IGNORECASE,
        ):
            name = Path(m.group(1).strip()).name.lower()
            if name not in mentioned_names:
                mentioned_names.append(name)

    # Build ordered source_files: mentioned first, then everything else
    source_files: list[Path] = []
    seen_paths: set[Path] = set()

    for name in mentioned_names:
        for fpath in filename_index.get(name, []):
            if fpath not in seen_paths:
                seen_paths.add(fpath)
                source_files.append(fpath)

    for paths in filename_index.values():
        for fpath in paths:
            if fpath not in seen_paths:
                seen_paths.add(fpath)
                source_files.append(fpath)

    # ── scan files, collect all rows (no filtering yet — full result gets cached) ─
    rows: list[tuple[str, int, str, str | None, str | None, str]] = []
    # Collect all CSS class names seen in source so _class_in_source can be a
    # simple set lookup instead of a second full directory walk at uncertain-check time.
    _CLASS_ATTR_RE = re.compile(r'class(?:Name)?\s*=\s*["\']([^"\']+)["\']')
    known_classes: set[str] = set()

    for fpath in source_files:
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        rel = fpath.relative_to(root).as_posix()

        # Collect class names from this file
        for cm in _CLASS_ATTR_RE.finditer(content):
            for cls in cm.group(1).split():
                known_classes.add(cls)

        for m in _TAG_RE.finditer(content):
            tag = m.group(1).lower()
            attrs = m.group(2) or ""
            line_num = content[: m.start()].count("\n") + 1
            label = _element_label(tag, attrs)
            selector, attr_src, tier = _best_selector(tag, attrs)
            rows.append((rel, line_num, label, selector, attr_src, tier))

        for m in _DIV_SPAN_RE.finditer(content):
            attrs = m.group(2) or ""
            if not _DIV_SPAN_INTERACTIVE.search(attrs):
                continue
            tag = m.group(1).lower()
            line_num = content[: m.start()].count("\n") + 1
            label = _element_label(tag, attrs)
            selector, attr_src, tier = _best_selector(tag, attrs)
            rows.append((rel, line_num, label, selector, attr_src, tier))

    if not rows:
        return "", ""

    # ── sort by file + line ──────────────────────────────────────────────────
    rows.sort(key=lambda r: (r[0], r[1]))

    # ── deduplicate identical selectors within the same file ─────────────────
    # No row cap here — the full deduplicated set goes into the cache.
    # max_rows is applied later, only to the filtered output injected into
    # the prompt, so it never silently drops coverage for uncapped files.
    seen: set[tuple[str, str | None]] = set()
    deduped: list[tuple[str, int, str, str | None, str | None, str]] = []
    for rel, line_num, label, selector, attr_src, tier in rows:
        key = (rel, selector)
        if key in seen:
            continue
        seen.add(key)
        deduped.append((rel, line_num, label, selector, attr_src, tier))

    # ── format the full inventory (this is what gets cached) ─────────────────
    header = [
        "VERIFIED SELECTORS FROM SOURCE",
        'Use ONLY the selectors in this list for every "target" field.',
        "NEVER invent, guess, or derive a selector not present here.",
        (
            "Entries marked [UNCERTAIN] have no stable attribute. "
            "DO NOT omit these steps — include them using the best selector you can infer from source "
            "(prefer class names like .btn-primary, then text content, then positional). "
            'Add "needs_stable_selector": true to that step dict so it can be flagged for the user.'
        ),
        "",
    ]
    data_lines: list[str] = []
    for rel, line_num, label, selector, attr_src, tier in deduped:
        if tier in ("stable", "fragile"):
            data_lines.append(f"  {rel}:{line_num}  {label}  →  {selector}  [{attr_src}]")
        else:
            data_lines.append(
                f"  {rel}:{line_num}  {label}  →  "
                f"[UNCERTAIN — no stable selector; use best-effort selector from source and add needs_stable_selector=true]"
            )

    full_inventory = "\n".join(header + data_lines + [""])

    # ── persist to cache so next call is a fast cache-hit ────────────────────
    _save_inventory_cache(scan_root, git_hash, full_inventory, known_classes)

    return _filter_inventory_by_findings(full_inventory, findings_hint, max_rows), full_inventory


def _filter_inventory_by_findings(
    inventory: str, findings_hint: str, max_rows: int = 400
) -> str:
    """Return inventory rows whose file is mentioned in *findings_hint*.

    When no hint is given (or no file names can be extracted), the full
    inventory is returned.  Header lines are always preserved.

    *max_rows* caps the number of data rows in the returned string — this is
    the only place the cap is applied, so the cached inventory always contains
    full coverage and the cap only affects what goes into the prompt.
    """
    if not inventory:
        return inventory

    mentioned: set[str] = set()
    if findings_hint:
        for m in re.finditer(
            r"([\w./-]+\.(?:jsx|tsx|js|ts|html|vue|svelte))",
            findings_hint,
            re.IGNORECASE,
        ):
            mentioned.add(Path(m.group(1)).name.lower())

    # When a findings-based file filter is active, the mention set already bounds
    # the output to only relevant files — skip the row cap in that case.
    # Only apply max_rows as a safety net when there are no findings to filter by
    # (unfiltered = potentially the whole repo).
    apply_cap = not mentioned

    row_count = 0
    filtered: list[str] = []
    for line in inventory.splitlines():
        # Header lines (no leading "  ") are always kept
        if not line.startswith("  "):
            filtered.append(line)
            continue
        # When we have a mention set, keep only rows for mentioned files
        if mentioned:
            file_part = line.strip().split(":")[0].lower()
            file_name = Path(file_part).name.lower()
            if file_name not in mentioned and not any(m in file_part for m in mentioned):
                continue
        if apply_cap and row_count >= max_rows:
            continue
        filtered.append(line)
        row_count += 1

    return "\n".join(filtered)


_SELECTOR_PATTERN = re.compile(
    r"""
    (?:
        \#[\w-]+                                         # #id
        | \[[\w-]+\s*=\s*['"][^'"]+['"]\]               # [attr="val"]
        | \.\w[\w-]*                                     # .class
        | (?:input|button|a|div|span)\[[\w-]+[^\]]*\]   # tag[attr...]
    )
    """,
    re.VERBOSE,
)

# Prose patterns LLMs use to describe selectors — e.g. "the input with id 'email'",
# "selector: #email", "targets the #email field", "using id=\"password\"".
_PROSE_SELECTOR_PATTERNS = [
    # "selector: #foo" / "selector: [attr='val']" / "selector: .cls"
    re.compile(r"selector\s*:\s*[^\s,\n]+", re.IGNORECASE),
    # "with id 'foo'" / "with id \"foo\"" / "with id foo"
    re.compile(r"\bwith\s+id\s+['\"]?[\w-]+['\"]?", re.IGNORECASE),
    # "id='foo'" / 'id="foo"'
    re.compile(r"\bid\s*=\s*['\"][\w-]+['\"]", re.IGNORECASE),
    # "the #foo" / "targets #foo" / "using #foo"
    re.compile(r"\b(?:the|targets?|using|via|on|at)\s+#[\w-]+", re.IGNORECASE),
    # "the #foo field/element/input/button" (already caught above, belt+suspenders)
    re.compile(r"#[\w-]+\s+(?:field|element|input|button|selector|attribute)", re.IGNORECASE),
    # "targets the #foo" (possessive phrase with hash)
    re.compile(r"#[\w-]+", re.IGNORECASE),  # catch any remaining bare #id references
]


def _strip_selectors_from_findings(findings: str) -> str:
    """Remove CSS selector patterns and prose selector descriptions from findings text.

    Phase 1 LLMs hallucinate selectors both as raw CSS (``#email``) and in
    natural-language prose ("the input with id 'email'", "selector: #password").
    Both forms are stripped so Phase 2 cannot reconstruct them.
    The verified selector inventory is the single authoritative source.
    """
    result = _SELECTOR_PATTERN.sub("[selector omitted — see inventory]", findings)
    for pattern in _PROSE_SELECTOR_PATTERNS:
        result = pattern.sub("[selector omitted — see inventory]", result)
    return result


_ASSERT_ACTIONS = frozenset({"assert", "verify", "expect"})


def _convert_generate_step(step: dict) -> dict:
    """Normalise a generate-tool step dict to the Mirabilis-compatible format.

    New format (post-update): steps are already in Mirabilis format with
    action_taken / css_selector / mock_input / assertion_* fields — pass through
    with only a field-name alias (step → description).

    Legacy format (pre-update): steps use action / target / value — convert:

    navigate → go_to:
        target = URL to navigate to (NOT a CSS selector)
        value  = ignored / fallback URL
        ↓
        mock_input = target (URL)   — what Maeris uses to drive navigation
        css_selector = ""           — empty; navigation has no DOM target

    type/click/hover/select → send_keys/click/…:
        target = CSS selector of the DOM element
        value  = text to type (send_keys only)
        ↓
        css_selector = target
        mock_input   = value

    assert → Mirabilis assertion fields (assertion_nature / assertion_type / assertion_value):
        target = CSS selector (existence check) or empty (page-level check)
        value  = expected text or URL fragment to assert against
        ↓
        If target is a CSS selector:
            assertion_nature = "existence", assertion_type = "to be visible"
        If target looks like a URL or is empty:
            assertion_nature = "page", assertion_type = "to contain url"
        action is cleared so _build_steps_from_mirabilis_steps treats this as assertion.
    """
    out = dict(step)

    # Map 'step' field → 'description' (both formats use this alias)
    if "step" in out and "description" not in out:
        out["description"] = out["step"]

    # ── New Mirabilis format: already has action_taken or assertion_nature ──
    # Pass through with no further conversion needed.
    if "action_taken" in out or "assertion_nature" in out:
        return out

    # ── Legacy format: has action / target / value ─────────────────────────
    action = (out.get("action") or "").strip().lower()

    if action in _NAVIGATE_ACTIONS:
        # For navigate: 'target' holds the destination URL, NOT a DOM selector.
        # Priority: target → value → mock_input (already set). Never leave it as a credential.
        url = (
            (out.get("target") or "").strip()
            or (out.get("value") or "").strip()
            or (out.get("mock_input") or "").strip()
        )
        out["action_taken"] = "go_to"
        out["mock_input"] = url    # URL goes into mock_input for go_to
        out["css_selector"] = ""   # navigation has no DOM element target
        out["value"] = url         # keep for _build_steps… fallback (reads mock_input first)

    elif action in _ASSERT_ACTIONS:
        # assert → convert to Mirabilis assertion fields
        val = (out.get("value") or out.get("mock_input") or "").strip()
        raw_target = (out.get("target") or "").strip()
        # Treat target as a CSS selector only if it doesn't look like a URL/path
        # and is non-empty; otherwise fall back to a page-level URL assertion.
        is_css_target = bool(raw_target) and not raw_target.startswith(("http", "/"))
        if is_css_target:
            out["css_selector"] = raw_target
            out["assertion_nature"] = "existence"
            out["assertion_type"] = "to be visible"
            out["assertion_value"] = val
        else:
            out["css_selector"] = ""
            out["assertion_nature"] = "page"
            out["assertion_type"] = "to contain url"
            out["assertion_value"] = val or raw_target
        # Clear action so _build_steps_from_mirabilis_steps routes to assertion handler
        out.pop("action", None)
        out.pop("action_taken", None)

    else:
        # All other actions (click, send_keys, select, on_blur):
        # 'target' is the CSS selector of the DOM element.
        if "target" in out and "css_selector" not in out and "selector" not in out:
            out["css_selector"] = out["target"]
        # 'value' is the text to type (for send_keys); map to mock_input.
        # Only set if not already present — don't override explicit mock_input.
        if "value" in out and "mock_input" not in out:
            out["mock_input"] = out["value"]
        # Map legacy action names to supported action_taken values
        _legacy_action_map = {
            "type": "send_keys",
            "click_select": "click",
        }
        if "action_taken" not in out:
            out["action_taken"] = _legacy_action_map.get(action, action)

    return out


def _slugify_cmd(text: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() or ch.isspace() else "_" for ch in text)
    return ("_".join([p for p in cleaned.split() if p]) or "generated_tests")[:50]


def _extract_uncertain_steps(
    test_cases: list,
    inventory_text: str = "",
    known_classes: frozenset[str] = frozenset(),
) -> list[dict]:
    """Return metadata for every step whose selector may fail at runtime.

    Three sources trigger an entry:
    1. ``needs_stable_selector=True`` — Claude flagged it (inventory had [UNCERTAIN]).
    2. Pattern-based: positional (:nth-child), bare tags, structural combinators,
       class selectors whose class name is not found in source.
    3. Value-not-in-source: stable-pattern selector (data-*, #id, [name=], etc.)
       whose specific attr=value pair does not appear in the scanned inventory —
       meaning Claude invented a selector that doesn't exist in the codebase.

    ``inventory_text``: full (unfiltered) inventory text from cache, used for
    value existence checks.  Pass empty string to skip those checks.
    ``known_classes``: set of CSS class names collected during inventory scan.
    """
    uncertain: list[dict] = []
    for tc in test_cases:
        name = tc.get("test_name") or tc.get("name", "")
        for idx, step in enumerate(tc.get("steps", [])):
            sel = (step.get("css_selector") or "").strip()
            flagged_by_claude = bool(step.get("needs_stable_selector"))
            if not sel and not flagged_by_claude:
                continue

            confidence, reason = _classify_selector_confidence(sel) if sel else ("uncertain", "no selector provided")

            # --- additional existence checks ---
            if sel and confidence == "stable" and inventory_text:
                # Pattern looks stable — but did this value actually exist in source?
                if not _selector_in_inventory(sel, inventory_text):
                    confidence = "uncertain"
                    reason = "selector value not found in scanned source — may be invented"

            elif sel and confidence == "uncertain" and sel.startswith(".") and known_classes:
                # Class selector: check whether the class name exists in source at all
                # to give a more precise reason (invented vs fragile-but-real)
                class_name = re.split(r'[\s:>\[+~]', sel.lstrip("."))[0]
                if class_name and not _class_in_source(class_name, known_classes):
                    reason = f"class '{class_name}' not found in source — element may not exist"

            if confidence == "uncertain" or flagged_by_claude:
                uncertain.append({
                    "test_name": name,
                    "step_index": idx,
                    "description": step.get("description", f"step {idx + 1}"),
                    "css_selector": sel or "(none)",
                    "reason": reason,
                    "flagged_by_claude": flagged_by_claude,
                })
    return uncertain


def _swap_uncertain_selectors_via_llm(
    test_cases: list,
    uncertain_steps: list[dict],
    inventory_text: str,
) -> list | None:
    """Run a constrained Claude subprocess to pick new css_selectors for the
    uncertain steps from the fresh inventory.

    The prompt is tightly scoped to a single job — return the same test_cases
    array with ONLY the css_selector field updated on the specified uncertain
    steps. Every other field, and the overall structure, must stay identical.

    Returns the LLM-proposed array on success, or ``None`` on any failure
    (missing CLI, subprocess error, malformed output, structural drift).
    The caller is responsible for validating and merging the result — the
    LLM's output is NEVER copied verbatim.
    """
    if not test_cases or not uncertain_steps or not inventory_text:
        return None

    claude_bin = shutil.which("claude.exe") or shutil.which("claude")
    if not claude_bin:
        log.warning("selector_swap.claude_cli_missing")
        return None

    # Compact list of uncertain steps for the prompt
    uncertain_lines = []
    for u in uncertain_steps:
        tname = u.get("test_name", "")
        sidx = u.get("step_index", -1)
        desc = u.get("description", "")
        old_sel = u.get("css_selector", "")
        uncertain_lines.append(
            f'  - test "{tname}" step {sidx}: "{desc}" '
            f'(current css_selector: {old_sel})'
        )
    uncertain_block = "\n".join(uncertain_lines)

    prompt = f"""You are a CSS-selector swap utility. Your ONLY job is to replace fragile selectors in an existing test_cases array with stable ones from a fresh selector inventory. Do nothing else.

EXISTING TEST CASES (input):
{json.dumps(test_cases, indent=2)}

STEPS THAT NEED A NEW css_selector (swap only these — identified by test_name + step_index):
{uncertain_block}

FRESH SELECTOR INVENTORY (the only source of valid replacement selectors):
{inventory_text}

STRICT RULES — violations invalidate your entire output:
1. Return the EXACT same JSON array: same number of test cases, same test_name values, same test_type values, same number of steps per test case, same step order.
2. Change ONLY the `css_selector` field on the steps listed above. Leave every other field (`description`, `action_taken`, `mock_input`, `assertion_nature`, `assertion_type`, `assertion_value`, `needs_stable_selector`, etc.) BYTE-IDENTICAL to the input.
3. For each uncertain step, pick the inventory entry that best matches the step's description and context. STRONGLY prefer `[data-automation-id="..."]` (or whatever stable attr appears in the inventory).
4. The replacement `css_selector` MUST be copied verbatim from the inventory — do NOT invent new selectors, do NOT combine selectors, do NOT add class/tag prefixes.
5. If no inventory entry clearly matches an uncertain step, LEAVE ITS css_selector UNCHANGED — do not guess.
6. Do NOT add, remove, reorder, merge, or rename any test case or step.
7. Return ONLY a JSON array starting with `[` and ending with `]`. No prose, no markdown, no code fences, no explanation.
"""

    try:
        t0 = time.monotonic()
        result = subprocess.run(
            [claude_bin, *_STRUCTURE_FLAGS],
            input=prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        elapsed = round(time.monotonic() - t0, 1)
        log.info("selector_swap.subprocess_done",
                 returncode=result.returncode,
                 elapsed_s=elapsed,
                 stdout_len=len(result.stdout))

        if result.returncode != 0:
            log.warning("selector_swap.subprocess_failed",
                        stderr_preview=result.stderr[:200])
            return None

        raw = result.stdout.strip()
        _arr = _extract_json_array(raw)
        if _arr is None:
            log.warning("selector_swap.no_json_array", raw_preview=raw[:200])
            return None

        swapped = json.loads(_arr)
        if not isinstance(swapped, list) or len(swapped) != len(test_cases):
            log.warning("selector_swap.structure_mismatch",
                        orig_count=len(test_cases),
                        swapped_count=len(swapped) if isinstance(swapped, list) else -1)
            return None

        # Per-test-case structural validation
        for orig_tc, new_tc in zip(test_cases, swapped):
            if not isinstance(new_tc, dict):
                log.warning("selector_swap.non_dict_test_case")
                return None
            orig_steps = orig_tc.get("steps", [])
            new_steps = new_tc.get("steps", [])
            if len(orig_steps) != len(new_steps):
                log.warning("selector_swap.step_count_mismatch",
                            test_name=orig_tc.get("test_name"),
                            orig=len(orig_steps),
                            new=len(new_steps))
                return None

        return swapped
    except json.JSONDecodeError as e:
        log.warning("selector_swap.json_decode_error", error=str(e))
        return None
    except Exception as e:  # noqa: BLE001
        log.warning("selector_swap.exception", error=str(e))
        return None


def _merge_swapped_selectors(
    original: list,
    llm_output: list,
    uncertain_steps: list[dict],
    inventory_text: str,
) -> tuple[list, list[dict]]:
    """Safely merge LLM-proposed css_selector changes into the original array.

    Guarantees structural integrity by treating the LLM output as a read-only
    suggestion source: only the `css_selector` field on steps listed in
    *uncertain_steps* is allowed to change, and only if the new selector both:
      1. Differs from the original, AND
      2. Exists in *inventory_text* (i.e. was not hallucinated).

    Everything else — step order, step count, descriptions, actions, assertion
    fields, test case names — is preserved verbatim from *original*.

    Returns ``(merged_test_cases, swap_log)`` where swap_log is a list of
    dicts describing each successful swap for diagnostics.
    """
    import copy

    # Build a quick lookup of which (test_name, step_index) pairs may change
    allowed: set[tuple[str, int]] = set()
    for u in uncertain_steps:
        name = u.get("test_name", "") or ""
        idx = u.get("step_index", -1)
        if idx >= 0:
            allowed.add((name, idx))

    merged = copy.deepcopy(original)
    swap_log: list[dict] = []

    for tc_idx, tc in enumerate(merged):
        if tc_idx >= len(llm_output):
            break
        llm_tc = llm_output[tc_idx]
        if not isinstance(llm_tc, dict):
            continue
        tname = tc.get("test_name") or tc.get("name", "")
        orig_steps = tc.get("steps", [])
        llm_steps = llm_tc.get("steps", [])

        for step_idx, step in enumerate(orig_steps):
            if (tname, step_idx) not in allowed:
                continue
            if step_idx >= len(llm_steps):
                continue
            llm_step = llm_steps[step_idx]
            if not isinstance(llm_step, dict):
                continue

            new_sel = (llm_step.get("css_selector") or "").strip()
            old_sel = (step.get("css_selector") or "").strip()
            if not new_sel or new_sel == old_sel:
                continue

            # Hallucination guard: reject swaps whose new selector isn't in
            # the inventory (pattern-based check for #id / [attr="val"]).
            if not _selector_in_inventory(new_sel, inventory_text):
                log.info("selector_swap.rejected_not_in_inventory",
                         test_name=tname, step_index=step_idx,
                         proposed=new_sel)
                continue

            step["css_selector"] = new_sel
            # Clear the needs_stable_selector flag — this step now has one
            if "needs_stable_selector" in step:
                step.pop("needs_stable_selector", None)
            swap_log.append({
                "test_name": tname,
                "step_index": step_idx,
                "old_selector": old_sel,
                "new_selector": new_sel,
            })

    return merged, swap_log


async def _handle_apply_automation_attrs(
    arguments: dict,
) -> list[TextContent]:
    """Inject automation attributes into source files and perform a
    constrained, in-place selector swap on the caller's existing test_cases
    array — returning the SAME tests with only uncertain css_selectors
    updated.

    This deliberately does NOT regenerate the test suite from scratch. The
    previous implementation (full Phase 2 re-run) could drift test scenarios
    because the Phase 2 LLM subprocess is non-deterministic. Keeping the
    test_cases structure fixed and only rewriting css_selector values on the
    uncertain steps eliminates that drift entirely.

    Required arguments:
        app_path          absolute path to the app root
        test_cases        the test_cases array from the previous generate call
                          (source of truth for test structure/scenarios)
    Optional arguments:
        attr_name         attribute to inject (default: data-automation-id)
        target_files      specific files to patch (default: uncertain_files
                          from the previous response, otherwise full app_path)

    If test_cases is missing, falls back to the legacy "files patched — call
    generate again" response for backward compatibility.
    """
    from maeris_mcp import tidy as _tidy  # local import — tidy is always available

    app_path = (arguments.get("app_path") or arguments.get("appPath") or "").strip()
    attr_name = (arguments.get("attr_name") or "data-automation-id").strip() or "data-automation-id"
    target_files: list[str] | None = arguments.get("target_files") or None
    existing_test_cases = arguments.get("test_cases")

    resolved_path = _resolve_scan_root(app_path, findings="")
    root = Path(resolved_path)
    if not root.exists():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"app_path does not exist: {resolved_path}",
        }, indent=2))]

    # ── Step 1: patch source files via tidy ──────────────────────────────
    if target_files:
        resolved_targets = [Path(f) for f in target_files if Path(f).exists()]
        summaries = _tidy.scan(root, attr_name=attr_name, files=resolved_targets)
        scope = f"{len(resolved_targets)} file(s) from the test cases with uncertain selectors"
    else:
        summaries = _tidy.scan(root, attr_name=attr_name)
        scope = "all source files under app_path"

    files_modified = _tidy.apply_patches(summaries)
    total_elements = sum(len(s.patches) for s in summaries)

    # Clear selector inventory cache — force rebuild with the new stable selectors
    try:
        _INVENTORY_CACHE_FILE.unlink(missing_ok=True)
    except Exception:
        pass

    attrs_meta = {
        "attr_name": attr_name,
        "files_modified": files_modified,
        "elements_tagged": total_elements,
        "scope": scope,
    }

    # ── Step 2: if no test_cases were passed, fall back to legacy response ──
    if not isinstance(existing_test_cases, list) or not existing_test_cases:
        return [TextContent(type="text", text=json.dumps({
            "status": "automation_attrs_applied",
            **attrs_meta,
            "instruction": (
                f"Tell the user: '{files_modified} file(s) updated ({scope}), "
                f"{total_elements} element(s) tagged with `{attr_name}`. "
                f"The test cases shown above still reference the old selectors. "
                f"Call generate again with the same command to get test cases that use "
                f"the new stable `{attr_name}` selectors.'"
            ),
            "note": (
                "To get an in-place selector swap (no regeneration, no drift), "
                "pass the `test_cases` array from the previous generate response "
                "as an argument on the next apply_automation_attrs call."
            ),
        }, indent=2))]

    # ── Step 3: rebuild inventory from the now-patched source files ──────
    _, full_inventory = _build_selector_inventory(resolved_path, findings_hint="")
    known_classes = _load_known_classes_from_cache()

    # ── Step 4: identify which steps in the existing test_cases still have
    #           uncertain selectors against the NEW inventory ──────────────
    uncertain_before = _extract_uncertain_steps(
        existing_test_cases,
        inventory_text=full_inventory,
        known_classes=known_classes,
    )

    swap_log: list[dict] = []
    merged_test_cases = existing_test_cases

    if uncertain_before:
        # ── Step 5: constrained LLM selector swap ───────────────────────
        log.info("selector_swap.start",
                 test_count=len(existing_test_cases),
                 uncertain_count=len(uncertain_before))
        llm_output = _swap_uncertain_selectors_via_llm(
            existing_test_cases,
            uncertain_before,
            full_inventory,
        )

        if llm_output is not None:
            # ── Step 6: safely merge only css_selector changes ──────────
            merged_test_cases, swap_log = _merge_swapped_selectors(
                existing_test_cases,
                llm_output,
                uncertain_before,
                full_inventory,
            )
            log.info("selector_swap.done", swapped_count=len(swap_log))
        else:
            log.warning("selector_swap.llm_failed_keeping_original")
    else:
        log.info("selector_swap.no_uncertain_steps")

    # ── Step 7: re-extract uncertain selectors on the merged result so the
    #           agent sees what (if anything) is still fragile ───────────
    uncertain_after = _extract_uncertain_steps(
        merged_test_cases,
        inventory_text=full_inventory,
        known_classes=known_classes,
    )
    uncertain_files = _uncertain_files_from_cache() if uncertain_after else []

    # ── Step 8: build the response ───────────────────────────────────────
    resolved_count = len(uncertain_before) - len(uncertain_after)
    message_parts = [
        f"{files_modified} file(s) updated ({scope}), "
        f"{total_elements} element(s) tagged with `{attr_name}`.",
    ]
    if swap_log:
        message_parts.append(
            f"Swapped {len(swap_log)} selector(s) in-place — test case structure is unchanged."
        )
    if uncertain_after:
        message_parts.append(
            f"{len(uncertain_after)} step(s) still have uncertain selectors "
            f"(no stable match found in the inventory)."
        )
    elif uncertain_before:
        message_parts.append("All previously uncertain selectors have been resolved.")

    result_payload: dict = {
        "agent_instructions": (
            "MANDATORY POST-GENERATION SEQUENCE — follow these steps in STRICT ORDER.\n"
            "Do NOT combine steps. Do NOT skip ahead. STOP and wait for the user between steps.\n\n"
            "IMPORTANT: Any test_cases from earlier in the conversation are now STALE — discard them.\n"
            "Automation attributes were injected and selectors were swapped in-place. Structure\n"
            "(names, order, steps, descriptions, actions, assertions) is IDENTICAL to the previous\n"
            "response — only css_selector values on formerly uncertain steps changed.\n"
            "Use ONLY the test_cases array from THIS response for all subsequent steps.\n\n"
            "DISPLAY RULE: Never show test cases in a table. Always use a numbered list with\n"
            "every step expanded inline. Use the `description` field for each step. For assertion\n"
            "steps also show: assertion_nature → assertion_type → assertion_value.\n\n"
            "=== IF uncertain_selectors IS NON-EMPTY: show residual notice, then go to 3b ===\n"
            "Show this notice BEFORE the test case list (fill in N and each entry):\n"
            "'⚠️ N step(s) still have uncertain/fragile selectors after injection:\n"
            " - \"[description]\" in \"[test_name]\": `[css_selector]` — [reason]'\n"
            "Then proceed directly to 3b (no second data-automation-id offer needed here).\n\n"
            "=== IF uncertain_selectors IS EMPTY: skip straight to 3b ===\n\n"
            "=== STEP 3b: SHOW ALL TEST CASES ===\n"
            "Numbered list. Every step on its own line. No table. No abbreviation.\n\n"
            "=== STEP 3c: OUTPUT THIS EXACT TEXT to the user — do NOT paraphrase or shorten ===\n"
            "Were any steps missing or incorrect? Or would you like to:\n"
            "(a) push these to Maeris as-is, or\n"
            "(b) auto run and fix them first, then push?\n\n"
            "Wait for the answer. Three branches:\n"
            "  - User reports missing/wrong steps → explore the codebase to find the missing\n"
            "    element, report what you found, then offer options A (update+push),\n"
            "    B (push as-is), C (run-and-fix then push) and act on their choice.\n"
            "  - (a) push as-is → call generate with push_to_maeris=true + test_cases\n"
            "  - (b) auto run and fix → seed with run_and_fix=true, drive run_and_fix_tests\n"
            "    to all_complete, then push with push_to_maeris=true + from_exec_dir\n"
        ),
        "required_next_message": (
            "Were any steps missing or incorrect? Or would you like to:\n"
            "(a) push these to Maeris as-is, or\n"
            "(b) auto run and fix them first, then push?"
        ),
        "success": True,
        "status": "automation_attrs_applied_and_swapped",
        "automation_attrs_applied": attrs_meta,
        "test_cases_count": len(merged_test_cases),
        "test_cases": merged_test_cases,
        "uncertain_selectors": uncertain_after,
        "uncertain_files": uncertain_files,
        "selector_swaps": {
            "uncertain_before": len(uncertain_before),
            "uncertain_after": len(uncertain_after),
            "resolved": resolved_count,
            "details": swap_log,
        },
        "message": " ".join(message_parts),
    }
    return [TextContent(type="text", text=json.dumps(result_payload, indent=2))]


def _annotate_steps_with_source(test_cases: list[dict], inventory_text: str) -> list[dict]:
    """Add a ``_source`` field to each step whose css_selector is found in the
    selector inventory.

    ``_source`` carries the file:line and element label from the inventory so
    the run-and-fix loop can distinguish source-grounded steps from hallucinated
    ones when deciding whether to remove a failing step.

    Steps with no inventory match are left unannotated — the absence of
    ``_source`` signals the selector may be hallucinated.
    """
    if not inventory_text:
        return test_cases

    # Build selector → "file:line — label" from inventory data lines.
    # Line format (stable/fragile):  "  rel/path.jsx:42  Button label  →  [sel]  [attr_src]"
    # UNCERTAIN lines are skipped — they have no real selector to match against.
    selector_to_source: dict[str, str] = {}
    for line in inventory_text.splitlines():
        stripped = line.strip()
        if "→" not in stripped or "[UNCERTAIN" in stripped:
            continue
        parts = stripped.split("  →  ", 1)
        if len(parts) != 2:
            continue
        left = parts[0].strip()   # "rel/path.jsx:42  Button label"
        right = parts[1].strip()  # "[sel]  [attr_src]"
        # Selector sits before the trailing "  [{attr_src}]" token
        sel = right.rsplit("  [", 1)[0].strip()
        if not sel:
            continue
        left_parts = left.split("  ", 1)
        file_ref = left_parts[0].strip()
        label = left_parts[1].strip() if len(left_parts) > 1 else ""
        selector_to_source[sel] = f"{file_ref} — {label}" if label else file_ref

    if not selector_to_source:
        return test_cases

    for tc in test_cases:
        for step in tc.get("steps") or []:
            if not isinstance(step, dict):
                continue
            sel = (step.get("css_selector") or "").strip()
            if sel and sel in selector_to_source:
                step["_source"] = selector_to_source[sel]

    return test_cases


def _write_generate_test_cases_to_dir(
    test_cases: list[dict],
    output_dir: Path,
    base_url: str,
) -> list[str]:
    """Write generate-tool test cases to disk as Mirabilis JSON step files.

    Each file matches the shape the in-process Playwright runner reads
    (see test_execution.py:1862 — `read_text` + `json.loads` of `{steps: [...]}`).
    Steps are written verbatim because the generate tool already emits
    Mirabilis-format steps with literal credentials baked into mock_input —
    no preamble injection or placeholder substitution is needed.

    Returns the list of relative filenames written.
    """
    from maeris_mcp.tools.test_push import _slugify

    output_dir.mkdir(parents=True, exist_ok=True)

    written: list[str] = []
    used_slugs: set[str] = set()
    for idx, tc in enumerate(test_cases, start=1):
        tc_name = tc.get("test_name") or tc.get("name") or tc.get("title") or f"test_{idx}"
        tc_type = tc.get("test_type") or "positive"
        steps = tc.get("steps") or []

        slug = _slugify(tc_name)
        if slug in used_slugs:
            slug = f"{slug}_{idx}"
        used_slugs.add(slug)
        filename = f"{slug}.json"

        payload = {
            "name": tc_name,
            "description": tc_name,
            "priority": "medium",
            "tags": [],
            "test_type": tc_type,
            "base_url": base_url or "",
            "steps": steps,
        }
        (output_dir / filename).write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        written.append(filename)
    return written


def _load_test_cases_from_exec_dir(exec_dir: str) -> list[dict] | dict:
    """Read corrected JSON step files written by run_and_fix_tests and
    reconstruct generate-shape test cases for the push handler.

    Returns either:
      - a list of test_case dicts in the {test_name, test_type, steps} shape
        the push handler expects, or
      - an error dict ({status, message}) on failure.
    """
    p = Path(exec_dir).expanduser()
    if not p.exists() or not p.is_dir():
        return {
            "status": "error",
            "message": f"from_exec_dir does not exist or is not a directory: {exec_dir}",
        }

    files = sorted(p.glob("*.json"))
    if not files:
        return {
            "status": "error",
            "message": f"No .json test files found in {exec_dir}",
        }

    test_cases: list[dict] = []
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to parse corrected test file {f.name}: {e}",
            }
        if not isinstance(data, dict):
            continue
        steps = data.get("steps") or []
        if not isinstance(steps, list) or not steps:
            continue
        # Strip internal metadata fields (prefixed with "_") from each step
        # before handing off to the push handler so they never reach Maeris.
        clean_steps = [
            {k: v for k, v in s.items() if not k.startswith("_")}
            if isinstance(s, dict) else s
            for s in steps
        ]
        test_cases.append({
            "test_name": data.get("name") or f.stem,
            "test_type": data.get("test_type") or "positive",
            "steps": clean_steps,
        })

    if not test_cases:
        return {
            "status": "error",
            "message": f"No valid test cases recovered from {exec_dir}",
        }
    return test_cases


async def _handle_run_and_fix_seed(arguments: dict) -> list[TextContent]:
    """Seed an auto run-and-fix loop from generate-tool test cases.

    Writes the in-memory test_cases to a temp directory as Mirabilis JSON
    files, then returns an `autoRun` block instructing the agent to drive
    `run_and_fix_tests` against that directory. After the loop completes,
    the agent calls generate again with `push_to_maeris=true` and
    `from_exec_dir=<that directory>` so the *corrected* JSON files (not the
    stale in-memory array) are pushed to Maeris.
    """
    command = arguments.get("command", "")
    base_url = (arguments.get("base_url") or "").strip()
    test_email = (arguments.get("test_email") or "").strip()
    test_password = (arguments.get("test_password") or "").strip()
    raw_test_cases = arguments.get("test_cases")
    app_path = (arguments.get("app_path") or arguments.get("appPath") or "").strip()
    explicit_dir = (arguments.get("exec_dir") or arguments.get("execDir") or "").strip()

    # -- Validate test_cases --
    if not isinstance(raw_test_cases, list) or not raw_test_cases:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": (
                "No test cases provided. Pass test_cases from the previous generate "
                "response directly as a parameter when calling with run_and_fix=true."
            ),
        }, indent=2))]

    # -- Validate credentials (run_and_fix actually drives a real browser) --
    missing = [
        k for k, v in (
            ("base_url", base_url),
            ("test_email", test_email),
            ("test_password", test_password),
        ) if not v
    ]
    if missing:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": (
                f"Missing required credentials for run_and_fix: {', '.join(missing)}. "
                "All three (base_url, test_email, test_password) must be passed because "
                "the auto-fix loop runs the tests against a real browser."
            ),
        }, indent=2))]

    # -- Resolve output directory --
    if explicit_dir:
        exec_dir = Path(explicit_dir).expanduser().resolve()
    else:
        ts = int(time.time())
        slug = _slugify_cmd(command)
        exec_dir = (
            Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
            / "run_and_fix"
            / f"{ts}_{slug}"
        )

    # Resolve the scan root once so it can be passed to run_and_fix_tests.
    # This must happen before the annotation try-block so the resolved path
    # is available even when annotation fails.
    _resolved_app_path = _resolve_scan_root(app_path, "")

    # -- Annotate steps with _source from the selector inventory (cache hit) --
    # This lets the run-and-fix loop know which steps reference real source
    # elements vs hallucinated ones, so it can make the right fix/remove call.
    try:
        _, _seed_inventory = _build_selector_inventory(_resolved_app_path)
        raw_test_cases = _annotate_steps_with_source(raw_test_cases, _seed_inventory)
    except Exception:
        pass  # annotation is best-effort; missing _source just means no guard

    # -- Pre-apply proven selector corrections from flow knowledge store --
    try:
        from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
        _fk_corrections = RepoFlowKnowledge(_resolved_app_path).get_selector_corrections(command)
        if _fk_corrections:
            _correction_map = {
                c["broken"]: c["working"]
                for c in _fk_corrections
                if c.get("broken") and c.get("working")
            }
            for tc in raw_test_cases:
                for step in tc.get("steps", []):
                    sel = step.get("css_selector", "")
                    if sel in _correction_map:
                        step["css_selector"] = _correction_map[sel]
    except Exception:
        pass

    # -- Write JSON files --
    try:
        written = _write_generate_test_cases_to_dir(raw_test_cases, exec_dir, base_url)
    except Exception as e:
        log.error("generate.run_and_fix.write_failed", error=str(e))
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"Failed to write test files for run_and_fix: {e}",
        }, indent=2))]

    if not written:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "No test files were written — every test case in the input was empty or invalid.",
        }, indent=2))]

    log.info("generate.run_and_fix.seeded",
             exec_dir=str(exec_dir),
             files=len(written))

    return [TextContent(type="text", text=json.dumps({
        "status": "run_and_fix_ready",
        "exec_dir": str(exec_dir),
        "filesWritten": written,
        "autoRun": {
            "tool": "run_and_fix_tests",
            "arguments": {
                "output_dir": str(exec_dir),
                "base_url": base_url,
                "test_email": test_email,
                "test_password": test_password,
                "headless": True,
                "step_retries": 3,
                "app_path": _resolved_app_path,
            },
        },
        "instruction": (
            "Step 1 — Call run_and_fix_tests with the arguments under autoRun.arguments. "
            "Drive the fix loop per the existing run-and-fix rules: inspect logs and "
            "currentCode on failure, submit fixed_code, continue until status is "
            "'all_complete' (or retries are exhausted).\n\n"
            "Step 2 — Once the loop reports all_complete, call generate again with:\n"
            "  push_to_maeris=true\n"
            f"  from_exec_dir='{exec_dir}'\n"
            "  command, base_url, test_email, test_password, credentials_confirmed=true\n"
            "  test_folder (ask the user if not already known)\n\n"
            "Do NOT pass test_cases on the push call — the corrected versions will be "
            "loaded from disk at from_exec_dir. Report the final summary to the user "
            "(passed/failed/unfixable counts from the fix loop + the Maeris push result)."
        ),
    }, indent=2))]


async def _handle_push_generate_to_maeris(arguments: dict) -> list[TextContent]:
    """Push test cases produced by the generate tool to Maeris.

    Two input modes:
      1. Direct — pass `test_cases` as an in-memory array (default path).
      2. From-disk — pass `from_exec_dir` pointing to a directory of corrected
         JSON step files written by run_and_fix_tests. The corrected versions
         are loaded from disk and pushed instead of any in-memory array.
    """
    command = arguments.get("command", "")
    test_folder = (arguments.get("test_folder") or "").strip() or _slugify_cmd(command)
    base_url = (arguments.get("base_url") or "").strip() or None
    test_email = (arguments.get("test_email") or "").strip()
    test_password = (arguments.get("test_password") or "").strip()
    from_exec_dir = (arguments.get("from_exec_dir") or arguments.get("fromExecDir") or "").strip()

    # Also accept exec_session_id — resolve output_dir from the execution store so
    # push can follow run_and_fix_test_case without requiring from_exec_dir explicitly.
    if not from_exec_dir:
        _esi = (arguments.get("exec_session_id") or arguments.get("execSessionId") or "").strip()
        if _esi:
            from maeris_mcp.storage.execution_store import TestExecutionStore as _TES
            _sess = _TES().get_session(_esi)
            if _sess:
                from_exec_dir = _sess.output_dir

    # -- Source test cases: from disk if from_exec_dir, otherwise from arguments --
    if from_exec_dir:
        loaded = _load_test_cases_from_exec_dir(from_exec_dir)
        if isinstance(loaded, dict):  # error payload
            return [TextContent(type="text", text=json.dumps(loaded, indent=2))]
        raw_test_cases: list[dict] = loaded
        log.info("generate.push.loaded_from_exec_dir",
                 exec_dir=from_exec_dir,
                 count=len(raw_test_cases))
    else:
        raw_test_cases = arguments.get("test_cases")

    if not isinstance(raw_test_cases, list) or not raw_test_cases:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": (
                "No test cases provided. Pass test_cases from the generate response "
                "directly as a parameter when calling with push_to_maeris=true, or "
                "pass from_exec_dir to load corrected tests from a run_and_fix output dir."
            ),
        }, indent=2))]

    # -- Auth check --
    try:
        from maeris_mcp.auth.token_store import TokenStore
        token_store = TokenStore()
        if not token_store.load_token():
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": "Not authenticated. Run 'maeris login' first, then try again.",
            }, indent=2))]
        if token_store.is_token_expired():
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": "Session expired. Run 'maeris login' to re-authenticate.",
            }, indent=2))]
        stored_creds = token_store.get_token_data() or {}
        app_id = stored_creds.get("app_id") or ""
        if not app_id:
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": "No application selected. Run 'maeris switch-app' to link an application.",
            }, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"Auth check failed: {e}",
        }, indent=2))]

    # -- Build Maeris payloads --
    try:
        from maeris_mcp.tools.test_push import (
            _build_steps_from_mirabilis_steps,
            _slugify,
            _is_negative_test_name,
        )
    except ImportError as e:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"Internal import error: {e}",
        }, indent=2))]

    payloads = []
    skipped_details: list[str] = []

    for tc in raw_test_cases:
        tc_name = tc.get("test_name") or tc.get("name") or tc.get("title") or "Unnamed Test"
        tc_type = tc.get("test_type") or "positive"
        raw_steps = tc.get("steps") or []

        if not raw_steps:
            skipped_details.append(f"{tc_name}: no steps")
            continue

        # Convert generate-format steps to Mirabilis-compatible
        converted_steps = [_convert_generate_step(s) for s in raw_steps]

        steps_payload, _ = _build_steps_from_mirabilis_steps(
            converted_steps,
            tc_name,
            base_url,
            None,
            test_email=test_email,
            test_password=test_password,
            is_negative_test=(tc_type == "negative" or _is_negative_test_name(tc_name)),
        )

        action_steps = sum(1 for s in steps_payload if s.get("type") != "verification")
        verifications = sum(1 for s in steps_payload if s.get("type") == "verification")

        if verifications == 0 or action_steps < 1:
            skipped_details.append(
                f"{tc_name}: quality gate — {action_steps} action step(s), {verifications} verification(s)"
            )
            continue

        testcase_type = "smoke" if tc_type == "positive" else "regression"

        payloads.append({
            "name": tc_name,
            "description": tc_name,
            "testcase_type": testcase_type,
            "test_folder": test_folder,
            "labels": [],
            "browser": ["chrome"],
            "mark_as": "pass",
            "steps": steps_payload,
        })

    if not payloads:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "No valid test cases to push after quality filtering.",
            "skipped": skipped_details,
        }, indent=2))]

    # -- Push to Maeris --
    try:
        from maeris_mcp.maeris.client import AuthenticationError, MaerisClient

        async with MaerisClient(base_url=None) as client:
            # Resolve or create the folder
            existing_groups = await client.get_testcase_groups()
            matched = next(
                (g for g in existing_groups if (g.get("name") or "").lower() == test_folder.lower()),
                None,
            )
            if matched:
                resolved_group_id = matched.get("testcase_group_id") or matched.get("id") or test_folder
            else:
                resolved_group_id = await client.create_testcase_group(test_folder)

            for p in payloads:
                p["test_folder"] = resolved_group_id

            merged: dict = {
                "created_tests": [], "added_flus": [],
                "added_test_results": [], "added_verifications": [],
                "total_count": 0,
            }
            for payload in payloads:
                r = await client.create_manual_tests([payload])
                for key in ("created_tests", "added_flus", "added_test_results", "added_verifications"):
                    merged[key].extend(r.get(key, []))
                merged["total_count"] += r.get("total_count", 0)

    except AuthenticationError as e:
        return [TextContent(type="text", text=json.dumps({"status": "error", "message": str(e)}, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"Failed to push to Maeris: {e}",
        }, indent=2))]

    return [TextContent(type="text", text=json.dumps({
        "status": "pushed",
        "testsPushed": len(payloads),
        "testFolder": resolved_group_id,
        "skipped": skipped_details,
        "testIds": [t.get("id") for t in merged.get("created_tests", []) if t.get("id")],
    }, indent=2))]


def _resolve_scan_root(app_path: str, findings: str) -> str:
    """Return the filesystem root of the app being tested.

    Priority:
    1. *app_path* — explicit parameter from the caller (most reliable).
    2. Absolute paths found inside *findings* — Claude mentions the files it
       read; if any contain an absolute path we walk up to find the git root.
    3. ``os.getcwd()`` — last resort, usually wrong (MCP server's own dir).
    """
    # 1. Explicit app_path
    if app_path:
        p = Path(app_path).expanduser().resolve()
        if p.exists():
            return str(p)

    # 2. Extract absolute paths from findings text and find their git root
    if findings:
        # Match Windows and Unix-style absolute paths to source files
        for m in re.finditer(
            r"([A-Za-z]:[/\\][\w/\\ .-]+\.(?:jsx|tsx|js|ts|html|vue|svelte)"
            r"|/[\w/.-]+\.(?:jsx|tsx|js|ts|html|vue|svelte))",
            findings,
        ):
            candidate = Path(m.group(1).strip())
            if candidate.exists():
                # Walk up to find the git root; fall back to the parent dir
                check = candidate.parent
                for _ in range(8):
                    if (check / ".git").exists():
                        return str(check)
                    parent = check.parent
                    if parent == check:
                        break
                    check = parent
                return str(candidate.parent)

    # 3. Fallback
    return os.getcwd()


def generate_tool() -> Tool:
    return Tool(
        name="generate",
        description=(
            "Generate plain test steps for a user flow by exploring the codebase. "
            "IMPORTANT: The required parameter is named 'command' — never 'prompt', 'message', or 'query'. "
            "Call once with just 'command' to get exploration instructions, "
            "then call again with 'findings' after exploring. "
            "base_url, test_email, and test_password are required on the first call. "
            "Supports feedback loop: after generation, collect user feedback, clarify via "
            "conversation if needed, then call with feedback + previous_findings to save and "
            "optionally regenerate immediately using use_stored_findings. "
            "TRIGGER THIS TOOL for ANY of the following user intents — all of these mean the same thing: "
            "explicit commands ('generate test cases for X', 'write tests for Y', 'create test scenarios for Z'); "
            "question-form ('what test cases should I write for X?', 'what are the best test scenarios for X?', 'what should I test in X?'); "
            "help/assist requests ('help me cover X', 'help me with testing X', 'help me think through test coverage for X', 'can you assist with test planning for X?'); "
            "statements of need ('X needs test cases', 'we should have tests for X', 'X coverage is incomplete'); "
            "advisory verbs ('suggest test cases for X', 'recommend scenarios for X', 'propose test scenarios for X'); "
            "verify/ensure/make sure ('verify user is able to do X', 'make sure X works end-to-end', 'ensure X is covered'); "
            "bare imperative ('test login flow', 'test the checkout process', 'test X'); "
            "analysis verbs ('analyze what tests are needed for X', 'think about test cases for X', 'consider test scenarios for X'). "
            "INTENT RULE: if the user's message references testing, test cases, test scenarios, test coverage, "
            "validation, verification, or end-to-end checking of any feature or flow — call this tool."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": (
                        "REQUIRED. What to generate — e.g. 'generate testcases for login flow' or "
                        "'generate 5 testcases for the checkout flow'. "
                        "This parameter MUST be named 'command'. Do NOT use 'prompt', 'message', or any other name."
                    ),
                },
                "findings": {
                    "type": "string",
                    "description": "Your exploration findings from Phase 1. Omit on the first call.",
                },
                "test_cases": {
                    "type": "array",
                    "description": (
                        "The test cases array from a previous generate response. "
                        "Pass this when calling with push_to_maeris=true to push tests to Maeris. "
                        "Also pass this with apply_automation_attrs=true so the tool can perform "
                        "an in-place selector swap (no regeneration, no scenario drift) — the "
                        "response will contain the same test_cases with only uncertain "
                        "css_selector fields updated to the new stable selectors."
                    ),
                },
                "feedback": {
                    "type": "string",
                    "description": (
                        "Clarified user feedback after back-and-forth conversation — "
                        "e.g. 'missed the post-login selection screen, not the header switcher'. "
                        "Always pass alongside previous_findings."
                    ),
                },
                "previous_findings": {
                    "type": "string",
                    "description": (
                        "The findings string from the last successful generation for this command. "
                        "Pass this together with feedback so it is stored and available for "
                        "use_stored_findings fast-update. Available in the success response as "
                        "'storedFindings'."
                    ),
                },
                "use_stored_findings": {
                    "type": "boolean",
                    "description": (
                        "Skip Phase 1 re-exploration and regenerate test cases immediately using "
                        "the findings stored from the last run, with the clarified feedback applied. "
                        "Use when the user chooses 'update now (fast)'. "
                        "Requires feedback to already be saved (call with feedback first, or "
                        "pass feedback + previous_findings in the same call)."
                    ),
                },
                "app_path": {
                    "type": "string",
                    "description": (
                        "Absolute path to the root of the application being tested. "
                        "Pass your current working directory here on the second call (with findings). "
                        "Used to build a verified selector inventory from the actual source files."
                    ),
                },
                "push_to_maeris": {
                    "type": "boolean",
                    "description": (
                        "Push test cases to Maeris. Set to true and pass test_cases from the "
                        "previous generate response. Requires the user to be authenticated "
                        "(maeris login) and an app to be selected. "
                        "Alternatively, pass from_exec_dir to push the corrected tests "
                        "left on disk by a prior run_and_fix loop instead of an in-memory array."
                    ),
                },
                "run_and_fix": {
                    "type": "boolean",
                    "description": (
                        "Auto run the generated tests against a real browser, fix any failing "
                        "selectors/assertions via the LLM-driven run_and_fix_tests loop, then "
                        "(in a follow-up call) push the corrected tests to Maeris. "
                        "REQUIRED params alongside this flag: command, test_cases (from the "
                        "previous generate response), base_url, test_email, test_password, "
                        "credentials_confirmed=true. The response contains an autoRun block "
                        "with the arguments to invoke run_and_fix_tests with, plus an exec_dir "
                        "that must be passed back as from_exec_dir on the eventual push call."
                    ),
                },
                "from_exec_dir": {
                    "type": "string",
                    "description": (
                        "Absolute path to a directory of corrected JSON step files left on disk "
                        "by a prior run_and_fix loop. When passed alongside push_to_maeris=true, "
                        "the corrected tests are loaded from this directory and pushed to Maeris "
                        "instead of any in-memory test_cases array. This is the second hop of "
                        "the auto run-and-fix flow. If both from_exec_dir and test_cases are "
                        "provided, from_exec_dir wins and test_cases is ignored."
                    ),
                },
                "exec_dir": {
                    "type": "string",
                    "description": (
                        "Optional override for the directory where run_and_fix=true should "
                        "write the seed JSON step files. Defaults to "
                        "~/.maeris/run_and_fix/<timestamp>_<command_slug>/. Use only if you "
                        "need a specific location."
                    ),
                },
                "test_folder": {
                    "type": "string",
                    "description": (
                        "Folder / testcase group name in Maeris to push tests into. "
                        "If omitted, a slug of the command is used as the folder name."
                    ),
                },
                "base_url": {
                    "type": "string",
                    "description": "The exact full URL the user provided, including any path (e.g. http://localhost:3000/app/login). Pass verbatim — never strip or modify. Required on first call.",
                },
                "test_email": {
                    "type": "string",
                    "description": "Test account email. Required on first call.",
                },
                "test_password": {
                    "type": "string",
                    "description": "Test account password. Required on first call.",
                },
                "apply_automation_attrs": {
                    "type": "boolean",
                    "description": (
                        "Inject automation attributes into interactable elements under app_path "
                        "that lack a stable selector attribute, then perform an in-place selector "
                        "swap on the caller's existing test_cases array — returning the SAME "
                        "tests with only uncertain css_selector fields rewritten to use the new "
                        "stable selectors. Test case structure (names, order, steps, descriptions, "
                        "actions, assertions) is preserved byte-for-byte; nothing is regenerated. "
                        "REQUIRED params alongside this flag: app_path, test_cases "
                        "(the array from the previous generate response). "
                        "Optional: attr_name, target_files (uncertain_files from previous response). "
                        "After this call, DO NOT reuse any earlier test_cases array — the swapped "
                        "array in this response is the only valid one for push_to_maeris."
                    ),
                },
                "attr_name": {
                    "type": "string",
                    "description": (
                        "Attribute name to inject when apply_automation_attrs=true. "
                        "Defaults to 'data-automation-id'. "
                        "Examples: 'automation-id', 'data-cy', 'data-testid'."
                    ),
                },
                "credentials_confirmed": {
                    "type": "boolean",
                    "description": (
                        "Set to true ONLY after the user has explicitly confirmed the credentials "
                        "in this conversation. Never set this based on inferred or auto-detected values. "
                        "Must be passed on every call once confirmed (Phase 1, Phase 2, feedback loops, etc.)."
                    ),
                },
                "target_files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Absolute paths of specific source files to inject automation attributes into. "
                        "Pass the 'uncertain_files' array from the generate response when calling "
                        "apply_automation_attrs=true. Only those files will be patched. "
                        "Omit to patch all files under app_path (full tidy behaviour)."
                    ),
                },
            },
            "required": ["command"],
        },
    )



async def handle_generate(arguments: dict) -> list[TextContent]:
    command = arguments.get("command", "")
    findings = arguments.get("findings")
    base_url = (arguments.get("base_url") or "").strip()
    test_email = (arguments.get("test_email") or "").strip()
    test_password = (arguments.get("test_password") or "").strip()
    feedback = (arguments.get("feedback") or "").strip()
    previous_findings = (arguments.get("previous_findings") or "").strip()
    app_path = (arguments.get("app_path") or arguments.get("appPath") or "").strip()
    use_stored_findings = bool(
        arguments.get("use_stored_findings") or arguments.get("useStoredFindings")
    )
    apply_automation_attrs = bool(arguments.get("apply_automation_attrs"))
    attr_name = (arguments.get("attr_name") or "data-automation-id").strip() or "data-automation-id"
    target_files: list[str] | None = arguments.get("target_files") or None
    credentials_confirmed = bool(arguments.get("credentials_confirmed"))

    # ----------------------------------------------------------------
    # Push-to-Maeris path — route early before any generation logic
    # ----------------------------------------------------------------
    if arguments.get("push_to_maeris") or arguments.get("pushToMaeris"):
        return await _handle_push_generate_to_maeris(arguments)

    # ----------------------------------------------------------------
    # Auto run-and-fix path — write test cases to a temp dir as JSON
    # step files and return an autoRun block pointing to run_and_fix_tests.
    # The agent then drives the fix loop, and afterwards calls generate
    # with push_to_maeris=true + from_exec_dir to push the corrected tests.
    # ----------------------------------------------------------------
    if arguments.get("run_and_fix") or arguments.get("runAndFix"):
        return await _handle_run_and_fix_seed(arguments)

    # ----------------------------------------------------------------
    # Apply automation attrs path — inject stable selector attributes
    # into source files using the tidy engine, clear inventory cache, then
    # auto-regenerate test cases with the new stable selectors.
    # ----------------------------------------------------------------
    if apply_automation_attrs:
        return await _handle_apply_automation_attrs(arguments)

    # ----------------------------------------------------------------
    # Credentials confirmation gate
    # If credentials were supplied (potentially auto-inferred from context,
    # MCP tools, or config files) but the user hasn't confirmed them yet,
    # require Claude to show them and get explicit user approval before
    # proceeding. This prevents silent use of stale or wrong credentials.
    # ----------------------------------------------------------------
    if not credentials_confirmed and (base_url or test_email or test_password):
        masked_pw = ("*" * min(len(test_password), 8)) if test_password else "(not provided)"
        return [TextContent(type="text", text=json.dumps({
            "status": "credentials_confirmation_required",
            "detected_credentials": {
                "base_url": base_url or "(not provided)",
                "test_email": test_email or "(not provided)",
                "test_password": masked_pw,
            },
            "instruction": (
                "You found credentials from context (MCP tools, config, IDE selection, etc.) "
                "but the user has not confirmed them. "
                "Show the user EXACTLY what was detected:\n"
                f"  URL:      {base_url or '(not provided)'}\n"
                f"  Email:    {test_email or '(not provided)'}\n"
                f"  Password: {masked_pw}\n\n"
                "Ask: 'Are these the correct credentials to use for testing? "
                "If not, please provide the correct values.'\n\n"
                "Once the user confirms or corrects them, re-call generate with the "
                "confirmed values AND credentials_confirmed=true."
            ),
        }, indent=2))]

    # ----------------------------------------------------------------
    # Feedback save path — clarification happened in conversation,
    # feedback is now precise. Save it, then offer the 3 options.
    # If previous_findings provided, store alongside for fast-update.
    # ----------------------------------------------------------------
    if feedback and not findings and not use_stored_findings:
        try:
            from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
            RepoFlowKnowledge(app_path or os.getcwd()).record_user_correction(
                command, feedback, previous_findings, app_path
            )
        except Exception:
            pass
        try:
            from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
            has_stored = bool(previous_findings or RepoFlowKnowledge(app_path or os.getcwd()).get_stored_findings(command))
        except Exception:
            has_stored = bool(previous_findings)
        return [TextContent(type="text", text=json.dumps({
            "status": "feedback_saved",
            "flow": command,
            "feedback": feedback,
            "message": "Feedback recorded.",
            "options": {
                "update_now_fast": {
                    "available": has_stored,
                    "description": (
                        "Regenerate test cases immediately using the stored findings — "
                        "no re-exploration needed (~10-15s)."
                    ) if has_stored else (
                        "Not available — no stored findings for this flow yet. "
                        "Use full_regenerate instead."
                    ),
                    "how": (
                        "Call generate with: command, use_stored_findings=true, "
                        "base_url, test_email, test_password, app_path."
                    ) if has_stored else None,
                },
                "full_regenerate": {
                    "available": True,
                    "description": (
                        "Re-explore the codebase from scratch then regenerate. "
                        "Use when the missing element was completely absent from the last exploration."
                    ),
                    "how": (
                        "Call generate with: command, base_url, test_email, test_password, app_path "
                        "(normal first call — feedback hint will be applied automatically)."
                    ),
                },
                "save_for_next_time": {
                    "available": True,
                    "description": "Feedback is already saved. Next generation for a similar flow will apply it automatically.",
                    "how": "Nothing more to do.",
                },
            },
            "recommendation": (
                "Recommend 'update_now_fast' if the missing element WAS present in the last "
                "exploration findings but was skipped during structuring. "
                "Recommend 'full_regenerate' if the element was completely absent from findings. "
                "Present all three options to the user and ask which they prefer."
            ),
        }, indent=2))]

    # ----------------------------------------------------------------
    # Fast-update path — skip Phase 1, use stored findings + feedback
    # ----------------------------------------------------------------
    if use_stored_findings:
        _fk_stored = ""
        try:
            from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
            _fk = RepoFlowKnowledge(app_path or os.getcwd())
            _fk_stored = previous_findings or _fk.get_stored_findings(command)
            if not app_path:
                app_path = _fk.get_stored_app_path(command)
        except Exception:
            _fk_stored = previous_findings
        if not _fk_stored:
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": (
                    "No stored findings found for this flow. "
                    "Use full_regenerate instead: call generate normally without use_stored_findings."
                ),
            }, indent=2))]
        findings = _fk_stored  # fall through to Phase 2 with stored findings

    # ----------------------------------------------------------------
    # Credential gate — always enforced, regardless of call phase
    # ----------------------------------------------------------------
    _missing: list[str] = []
    if not base_url:
        _missing.append("base_url")
    if not test_email:
        _missing.append("test_email")
    if not test_password:
        _missing.append("test_password")
    if _missing:
        _prompts = {
            "base_url": "The exact full URL where the test first lands, including any path — pass verbatim from the user",
            "test_email": "The test account email address",
            "test_password": "The test account password",
        }
        return [TextContent(type="text", text=json.dumps({
            "status": "credentials_required",
            "missingFields": _missing,
            "message": (
                "Please provide the following before test generation can begin. "
                "Ask the user for each missing value, then re-call generate with "
                "all required fields included."
            ),
            "requiredFields": {k: _prompts[k] for k in _missing},
            "instruction": (
                "DO NOT call generate again until you have collected ALL missing values "
                "from the user. Once you have them, call generate with: "
                "command, base_url, test_email, and test_password."
            ),
        }, indent=2))]

    # ----------------------------------------------------------------
    # Phase 1 — no findings yet: return exploration task to Claude
    # ----------------------------------------------------------------
    test_count = _parse_test_count(command)
    past_feedback = []
    try:
        from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
        past_feedback = RepoFlowKnowledge(app_path or os.getcwd()).get_relevant_user_corrections(command)
    except Exception:
        pass

    if not findings:
        log.info("generate.phase1.start", command=command, use_stored_findings=use_stored_findings)
        config_dir = Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
        nav_path = config_dir / "navigation.md"

        t_stale = time.monotonic()
        nav_stale = _nav_is_stale()
        log.info("generate.phase1.nav_staleness_check",
                 is_stale=nav_stale,
                 elapsed_s=round(time.monotonic() - t_stale, 2))
        if nav_stale:
            nav_missing = not nav_path.exists()
            return [TextContent(type="text", text=json.dumps({
                "status": "nav_refresh_needed",
                "instruction": (
                    "No navigation map found — run generate_nav first to build it, "
                    "then call generate again with the same original parameters."
                    if nav_missing else
                    "The navigation map is outdated — routing or auth files changed "
                    "since it was last built. Call generate_nav first (no arguments needed), "
                    "then call generate again with the same original parameters."
                ),
                "next_step": {
                    "tool": "generate_nav",
                    "arguments": {},
                },
            }, indent=2))]

        nav_context = (
            f"\n\nApp navigation context (from generate_nav):\n{nav_path.read_text(encoding='utf-8')}\n\n"
            "Use the above to produce complete steps from the app entry point to the feature.\n"
            if nav_path.exists() else
            "\n\nNo navigation map found. If the feature requires navigating through login or "
            "multiple screens to reach it, include those steps based on what you find in the source.\n"
        )

        t_proven = time.monotonic()
        proven_phase1_hint, _ = _get_proven_context()
        log.info("generate.phase1.proven_context_loaded",
                 has_hint=bool(proven_phase1_hint),
                 elapsed_s=round(time.monotonic() - t_proven, 2))

        feedback_hint = ""
        if past_feedback:
            hints = "\n".join(
                f"  - \"{e['feedback']}\""
                for e in past_feedback
                if e.get("feedback")
            )
            feedback_hint = (
                f"\n\nPREVIOUSLY REPORTED MISSING STEPS for similar flows:\n{hints}\n"
                "Actively look for these elements in the source. "
                "If they exist in this codebase, report them explicitly in your findings. "
                "Do not assume they are absent — search for them.\n"
            )

        task = {
            "status": "explore_needed",
            "instructions": (
                f"Explore the codebase and find ALL of the following for: {command}\n\n"
                "1. The exact component file(s) containing the UI for this task — report their "
                "full file paths so they can be scanned for selectors\n"
                "2. The COMPLETE navigation path from the app entry point — include login, "
                "any post-login screens (e.g. app/workspace selection after login), and every "
                "intermediate screen a real user passes through before reaching the feature. "
                "Report each screen's file path as well.\n"
                "3. Every interactive element involved in this flow — list them by their visible "
                "label or purpose (e.g. 'email input', 'submit button', 'settings nav item'). "
                "DO NOT report CSS selectors — selectors will be derived directly from source "
                "files. Report only the human-readable purpose of each element.\n"
                "4. The exact save mechanism — save button, or auto-save on blur/change?\n"
                "5. Any role or permission requirements\n"
                f"{nav_context}"
                f"{proven_phase1_hint}"
                f"{feedback_hint}"
                "Report only what you find in the source code. Do not infer or assume anything.\n\n"
                "Once you have all findings, call the generate tool again with:\n"
                f"  command: \"{command}\"\n"
                "  app_path: <your current working directory as an absolute path>\n"
                "  findings: <your complete findings as text>\n"
                "  base_url, test_email, test_password: re-pass the SAME values you used on this call\n"
                "  credentials_confirmed: true  (re-pass this — user already confirmed earlier)"
            ),
        }
        return [TextContent(type="text", text=json.dumps(task, indent=2))]

    # ----------------------------------------------------------------
    # Phase 2 — structure findings into test cases
    # ----------------------------------------------------------------
    log.info("generate.phase2.start", command=command, findings_len=len(findings or ""))

    claude_bin = shutil.which("claude.exe") or shutil.which("claude")
    if not claude_bin:
        return [TextContent(type="text", text="Error: Claude CLI not found on PATH.")]

    config_dir = Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
    nav_path = config_dir / "navigation.md"
    nav_section = (
        f"App Navigation Context:\n{nav_path.read_text(encoding='utf-8')}\n\n"
        "Use the above to prepend the full navigation path (from app entry point through auth) "
        "before the feature-specific steps in the findings.\n\n"
        if nav_path.exists() else ""
    )

    if test_count is not None:
        count_instruction = (
            f"Generate EXACTLY {test_count} test case(s) — no more, no less.\n\n"
            f"Distribute these {test_count} slots across the most important scenarios:\n"
            "- Prioritise: happy path first, then validation/error paths, then edge cases\n"
            "- Group related negative checks into a single test case when needed to stay within budget\n"
            "- Group multiple similar variations into a single test case when needed\n"
            "- If there are fewer meaningful scenarios than the requested count, fill remaining slots "
            "with additional edge cases grounded in the findings\n"
            f"The final JSON array MUST contain exactly {test_count} objects.\n"
        )
    else:
        count_instruction = (
            "For each meaningful scenario you identify, create one test case. Cover:\n"
            "- Happy path (complete successful flow)\n"
            "- One test per form that has validation rules (group ALL required field and input "
            "validation checks for the same form into a single negative test case, not one per field)\n"
            "- One test per meaningful variation type found (group similar variations into one test)\n"
            "- One test per feature flag or permission restriction found in source\n"
            "- One test per error/failure state found in source\n"
        )

    # Separate the login URL from the app root so the subprocess never conflates them.
    # base_url is the full login page URL (e.g. https://example.com/login).
    # app_origin is just the scheme+host (e.g. https://example.com) used to explain
    # that URL assertion values are path fragments, not URLs constructed from base_url.
    _app_origin = ""
    if base_url:
        try:
            from urllib.parse import urlparse as _urlparse
            _parsed = _urlparse(base_url)
            _app_origin = f"{_parsed.scheme}://{_parsed.netloc}"
        except Exception:
            _app_origin = base_url

    _creds_section = ""
    if base_url or test_email or test_password:
        _creds_section = (
            "Test credentials (use these EXACT literal values in the generated steps — never mask, redact, or substitute any value):\n"
            + (f"  login_url (use for go_to): {base_url}\n" if base_url else "")
            + (f"  app_origin (for reference only — NOT for go_to): {_app_origin}\n" if _app_origin else "")
            + (f"  email: {test_email}\n" if test_email else "")
            + (f"  password: {test_password}  ← use this exact string as mock_input for the password field — do NOT replace with *** or any placeholder\n" if test_password else "")
            + "IMPORTANT: go_to steps use login_url exactly as shown above. "
            "URL assertion values must be plain path fragments (e.g. /dashboard) "
            "taken from the findings or navigation map — never constructed by appending "
            "a path to login_url or app_origin.\n\n"
        )

    # Inject the active clarified feedback directly into Phase 2 as an override.
    # This is more precise than the general past_feedback safety net — it's the
    # user's exact clarified words from the current session.
    _active_feedback_section = ""
    if feedback:
        _active_feedback_section = (
            f"APPLY THIS FEEDBACK (user-confirmed, highest priority):\n"
            f"  {feedback}\n\n"
            "═══ FEEDBACK APPLICATION RULES ═══\n\n"
            "GENERAL RULE — surgical changes only:\n"
            "  The feedback targets a SPECIFIC problem. Apply ONLY the minimum change needed "
            "to fix that problem. Do NOT restructure, reorder, or remove any step that the "
            "feedback does not explicitly reference. Preserve the full original test structure "
            "for every step not mentioned in the feedback.\n\n"
            "CASE: feedback says a step or screen was MISSING:\n"
            "  INSERT the missing steps at the correct position in the journey — do NOT "
            "remove or abbreviate any other steps.\n"
            "  For a missing intermediate screen (e.g. app selection, workspace picker):\n"
            "    1. assert step — URL contains that screen's path fragment (must exist in "
            "the navigation map or findings — never taken only from feedback text)\n"
            "    2. click/select/send_keys steps — interact with the screen as a real user "
            "(e.g. click a card, pick an option). These MUST appear BETWEEN the URL assert "
            "for the intermediate screen and the URL assert for the next destination.\n"
            "    3. assert step — verify the next destination URL or a visible element\n"
            "  After inserting the missing steps, continue with ALL original steps that "
            "follow — do NOT drop modal opens, tab clicks, input interactions, or any "
            "feature-specific navigation that was already present.\n\n"
            "CASE: feedback says a selector was WRONG:\n"
            "  Replace ONLY that selector with the correct one from the inventory. "
            "Leave every other step and selector unchanged.\n\n"
            "CASE: feedback says a step was UNNECESSARY or should be REMOVED:\n"
            "  Remove ONLY that step. Leave every other step unchanged.\n\n"
            "CASE: feedback says the test logic or assertion value was WRONG:\n"
            "  Fix ONLY that assertion or logic. Leave every other step unchanged.\n\n"
            "ABSOLUTE RULES (apply regardless of feedback type):\n"
            "  - Two consecutive page-URL assertions (assertion_nature=\"page\") with no "
            "action step between them is ALWAYS a bug — never generate this pattern.\n"
            "  - assertion_value for URL assertions MUST be a plain path fragment "
            "(e.g. /onboarding/select-app) from the navigation map or findings. "
            "Never append a path to login_url or app_origin.\n"
            "  - Look up all selectors for inserted steps in the inventory — never invent them.\n\n"
        )

    # General safety net from all past relevant feedback (lower priority).
    _feedback_safety_net = ""
    if past_feedback and not feedback:  # skip if active feedback already covers it
        hints = "\n".join(
            f"  - \"{e['feedback']}\""
            for e in past_feedback
            if e.get("feedback")
        )
        _feedback_safety_net = (
            f"PREVIOUSLY REPORTED MISSING STEPS (apply if findings reference them):\n{hints}\n"
            "Include as steps only if the findings actually mention these screens or elements.\n\n"
        )

    t_proven2 = time.monotonic()
    _, _proven_selectors_section = _get_proven_context()
    log.info("generate.phase2.proven_context_loaded",
             has_selectors=bool(_proven_selectors_section),
             elapsed_s=round(time.monotonic() - t_proven2, 2))

    t_inv = time.monotonic()
    _scan_root = _resolve_scan_root(app_path, findings or "")
    _inventory_section, _full_inventory_text = _build_selector_inventory(_scan_root, findings_hint=findings or "")
    _flow_knowledge_block = ""
    try:
        from maeris_mcp.storage.flow_knowledge import RepoFlowKnowledge
        _flow_knowledge_block = RepoFlowKnowledge(_scan_root).get_authoritative_block(command)
    except Exception:
        pass
    log.info("generate.phase2.selector_inventory_built",
             scan_root=_scan_root,
             has_inventory=bool(_inventory_section),
             elapsed_s=round(time.monotonic() - t_inv, 2))

    # Guard: if inventory is empty and we're scanning what looks like the MCP server's own
    # directory (not the app), abort rather than silently generating selector-free tests.
    if not _inventory_section and not app_path:
        _cwd = os.getcwd()
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": (
                "Selector inventory is empty — the app source files could not be found. "
                f"Scanned: {_scan_root!r} (resolved from findings; fell back to cwd: {_cwd!r}). "
                "Re-call generate with app_path set to the absolute path of the application "
                "being tested (e.g. the directory containing package.json or app source). "
                "Pass the same command, findings, base_url, test_email, test_password, and "
                "app_path. If using use_stored_findings=true, also pass app_path."
            ),
            "required_param": "app_path",
        }, indent=2))]

    _entry_point = (
        f"Start every test with a go_to step using the login_url above ({base_url})."
        if base_url
        else "Start every test from the app entry point (go_to the login page first)."
    )

    structure_prompt = f"""You are a QA engineer. Based on the findings below, generate a test suite.

{count_instruction}
Only generate test cases that are grounded in the findings. Do not invent scenarios not evidenced by the source.

{"" if not _flow_knowledge_block else _flow_knowledge_block + chr(10) + chr(10)}{_creds_section}{_active_feedback_section}{_proven_selectors_section}{_feedback_safety_net}{nav_section}Each test case must include:
- "test_name": short descriptive name
- "test_type": "positive", "negative", or "edge"
- "steps": array of step objects in Mirabilis format (see below)

═══ STEP FORMAT — TWO TYPES ONLY ═══

TYPE 1 — ACTION STEP (navigation, interaction):
  {{
    "description": "human-readable description",
    "action_taken": "<one of the allowed values below>",
    "css_selector": "<CSS selector — empty string for go_to>",
    "mock_input": "<URL for go_to | text to type for send_keys | empty string for all others>"
  }}

Allowed action_taken values:
  go_to        — navigate to a URL (mock_input = full URL, css_selector = "")
  click        — click a button, link, or element (mock_input = "")
  send_keys    — type into an input (mock_input = the text to type)
  select       — select a dropdown option (mock_input = option text)

NEVER use: navigate, fill, type, triple_click, assert, hover, check, click_select, set_range, or any Playwright API name.

go_to is ONLY valid for the login page URL or the app root URL.
Every other page must be reached via click steps that mirror real user navigation.

TYPE 2 — ASSERTION STEP (no action_taken field at all):
  {{
    "description": "human-readable description",
    "css_selector": "<CSS selector — empty string for page-level assertions>",
    "assertion_nature": "<existence | page | input>",
    "assertion_type": "<exact string from the allowed list below>",
    "assertion_value": "<see assertion rules below — REQUIRED for existence and page>"
  }}

{_build_assertion_rules()}

═══ SELECTOR RULES ═══

Every css_selector MUST come from the inventory below — never invent or guess a selector.
When an element has a selector shown in the inventory, pick in this order of preference:
  1. data-testid, data-automation-id, data-cy, data-test (automation attributes — always prefer these)
  2. id (#element-id)
  3. name ([name="field"])
  4. aria-label
  5. placeholder
For elements marked [UNCERTAIN] in the inventory, follow the inventory header instructions for those entries.

TEXT-BASED SELECTORS (:text-is vs :has-text) — avoid ambiguous substring matches:

When the inventory offers a text-based selector for a button/link (no stable attribute
available), pay attention to which Playwright text operator you pick:

  :text-is("X")    — EXACT match: matches a button whose trimmed text equals "X".
  :has-text("X")   — SUBSTRING match: matches any ancestor whose text CONTAINS "X".

Default to :text-is for short, generic, or prefix-risky labels. A button labelled
"Create" written as :has-text("Create") will also match "+ Create new secret key",
"Create application", "Create Release", etc. — which is almost always the wrong one.

Rules of thumb:
  * Labels of ≤ 2 words or ≤ 12 characters → use :text-is("<full label>")
  * Labels that could be a prefix of another visible label on the same screen → use :text-is
  * Labels that are a full sentence or unique phrase → :has-text is fine
  * When in doubt, :text-is is safer — false-negatives are easier to fix than wrong-element clicks.

Examples:
  Good: button:text-is("Create")           — matches ONLY the "Create" submit button
  Bad:  button:has-text("Create")          — also matches "+ Create new secret key"
  Good: button:has-text("Sign in with email") — long enough to be unambiguous
  Good: button:text-is("Add")              — very short label, exact match required
  Bad:  button:has-text("Add")             — matches "+ Add new application", "Add email", etc.

{_inventory_section if _inventory_section else "No inventory available — do NOT invent selectors. If a selector cannot be confirmed, omit the step entirely."}

═══ GENERATION RULES ═══

{_entry_point} Follow the complete navigation path from the findings including ALL intermediate screens (login, post-login app selection, etc.).
If findings say save is automatic (blur/change), do not add a save step.

═══ ASSERTION PLACEMENT RULES ═══

A test that only checks page URLs is a BAD test. You MUST use existence and input assertions — not just page URL assertions.
Only add assertions when the findings clearly show what to expect — never guess.

MANDATORY assertion variety — every test case MUST include at least one "existence" or "input" assertion. A test with only "page" assertions is rejected.

AFTER login or navigation to a new page:
  - ONE page URL assertion is fine ("to contain url")
  - ALSO assert a heading, page title, or key element is visible ("existence" / "to be visible") — look in the findings for headings, h1/h2 text, page titles, or prominent labels on that page

AFTER form submission (save, create, update):
  - PREFER asserting the visible outcome over a URL change:
    - toast or success message shown in findings → assert it ("existence" / "to be visible")
    - created record appears in a list/table → assert it ("existence" / "to be visible")
    - saved value displayed on a detail page → assert it ("input" / "to contain text")
  - a URL assertion alone after form submission is NOT enough — add a visible outcome assertion too

AFTER typing into an input (send_keys):
  - do NOT assert the input value right after typing — only assert it if the test is specifically verifying pre-filled or persisted values

AFTER a toggle, checkbox, or selection:
  - assert the new state ("input" / "to be checked", "to be selected", etc.) only if the findings show the state change

FOR validation / negative tests:
  - assert the error message text ("existence" / "to be visible") — the exact text must come from the findings
  - assert the page does NOT navigate away if the findings show form stays open on error

NEVER:
  - add an assertion for something not mentioned in the findings
  - add more than 2 assertions after a single action unless each verifies a distinct, source-confirmed outcome
  - add consecutive page URL assertions with no action step between them
  - use only "page" assertions for an entire test case — mix in "existence" and "input" assertions

Findings (navigation and flow context only — do NOT use selector strings from findings; use ONLY the inventory above for all css_selector fields):
{_strip_selectors_from_findings(findings)}

No markdown, no prose. Return a JSON array of test case objects only."""

    try:
        log.info("generate.phase2.claude_subprocess_start",
                 prompt_len=len(structure_prompt))
        t0 = time.monotonic()
        result = subprocess.run(
            [claude_bin, *_STRUCTURE_FLAGS],
            input=structure_prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        structure_secs = round(time.monotonic() - t0, 1)
        log.info("generate.phase2.claude_subprocess_done",
                 returncode=result.returncode,
                 structure_secs=structure_secs,
                 stdout_len=len(result.stdout))

        if result.returncode != 0:
            _combined = result.stdout + result.stderr
            if "out of extra usage" in _combined or "extra_usage" in _combined:
                return [TextContent(type="text", text=json.dumps({
                    "status": "error",
                    "error": "claude_usage_limit",
                    "message": (
                        "The test generation subprocess hit your Claude usage limit. "
                        "Your Sonnet quota is likely exhausted — the Phase 2 subprocess "
                        "uses the same account quota as this session.\n\n"
                        "Options:\n"
                        "  1. Enable extra usage at claude.ai/settings/usage\n"
                        "  2. Wait for your quota to reset\n\n"
                        "Once quota is available, call generate again with the same "
                        "command, app_path, findings, and credentials."
                    ),
                }, indent=2))]
            _diag = (
                f"exit_code={result.returncode} | "
                f"stderr={result.stderr[:200]!r} | "
                f"stdout_preview={result.stdout[:200]!r}"
            )
            return [TextContent(type="text", text=f"Structure error: {_diag}")]

        raw = result.stdout.strip()
        _arr = _extract_json_array(raw)
        if _arr is None:
            return [TextContent(type="text", text=f"No JSON array in output:\n{raw[:400]}")]

        test_cases = json.loads(_arr)
        log.info("generate.phase2.test_cases_parsed", count=len(test_cases))

        # Ensure every assertion step has assertion_nature.  The LLM occasionally
        # emits assertion_type/assertion_value but omits assertion_nature, which
        # causes a silent validator error at runtime and kills the entire session.
        for _tc in test_cases:
            for _step in _tc.get("steps") or []:
                if "assertion_nature" not in _step and (
                    "assertion_type" in _step or "assertion_value" in _step
                ):
                    _step["assertion_nature"] = (
                        "existence" if (_step.get("css_selector") or "").strip() else "page"
                    )

        # _full_inventory_text came directly from _build_selector_inventory — no second
        # cache read needed.  known_classes is also already in cache from that same build.
        _known_classes = _load_known_classes_from_cache()

        uncertain_selectors = _extract_uncertain_steps(
            test_cases,
            inventory_text=_full_inventory_text,
            known_classes=_known_classes,
        )
        uncertain_files = _uncertain_files_from_cache() if uncertain_selectors else []

        result_payload: dict = {
            "agent_instructions": (
                "MANDATORY POST-GENERATION SEQUENCE — follow these steps in STRICT ORDER.\n"
                "Do NOT combine steps. Do NOT skip ahead. STOP and wait for the user between steps.\n\n"
                "DISPLAY RULE: Never show test cases in a table. Always use a numbered list with\n"
                "every step expanded inline. Use the `description` field for each step. For assertion\n"
                "steps also show: assertion_nature → assertion_type → assertion_value.\n\n"
                "=== IF uncertain_selectors IS NON-EMPTY: do ONLY this, then STOP ===\n"
                "1. Show this notice (fill in N and each entry):\n"
                "   '⚠️ N step(s) use uncertain/fragile selectors that may cause test failures:\n"
                "    - \"[description]\" in \"[test_name]\": `[css_selector]` — [reason]'\n"
                "2. Ask exactly:\n"
                "   'Would you like me to add stable automation attributes (data-automation-id) to\n"
                "   these elements in your source code? This injects a unique data-automation-id on\n"
                "   each interactable element so tests stay reliable. (You can also specify a different\n"
                "   attribute name, e.g. automation-id or data-cy.)\n"
                "   ⚠️ Note: These changes will only work locally until your source is deployed.\n"
                "   Tests on the hosted environment will fail until the new attributes are pushed.'\n"
                "3. STOP HERE. Do NOT show test cases yet. Do NOT ask the 3c question yet.\n"
                "   Wait for the user's answer.\n"
                "   - If yes: call generate with apply_automation_attrs=true, app_path, attr_name\n"
                "     (default: data-automation-id), target_files=<uncertain_files>, test_cases=<test_cases>.\n"
                "     The response replaces the current test_cases — discard this array, use only\n"
                "     the returned one. Then proceed to step 3b with the new test_cases.\n"
                "   - If no: proceed to step 3b with the current test_cases.\n\n"
                "=== IF uncertain_selectors IS EMPTY: skip straight to 3b ===\n\n"
                "=== STEP 3b: SHOW ALL TEST CASES ===\n"
                "Numbered list. Every step on its own line. No table. No abbreviation.\n\n"
                "=== STEP 3c: OUTPUT THIS EXACT TEXT to the user — do NOT paraphrase or shorten ===\n"
                "Were any steps missing or incorrect? Or would you like to:\n"
                "(a) push these to Maeris as-is, or\n"
                "(b) auto run and fix them first, then push?\n\n"
                "Wait for the answer. Three branches:\n"
                "  - User reports missing/wrong steps → explore the codebase to find the missing\n"
                "    element, report what you found, then offer options A (update+push),\n"
                "    B (push as-is), C (run-and-fix then push) and act on their choice.\n"
                "  - (a) push as-is → call generate with push_to_maeris=true + test_cases\n"
                "  - (b) auto run and fix → seed with run_and_fix=true, drive run_and_fix_tests\n"
                "    to all_complete, then push with push_to_maeris=true + from_exec_dir\n"
            ),
            "required_next_message": (
                "Were any steps missing or incorrect? Or would you like to:\n"
                "(a) push these to Maeris as-is, or\n"
                "(b) auto run and fix them first, then push?"
            ),
            "success": True,
            "test_cases_count": len(test_cases),
            "timing": {"structure_secs": structure_secs},
            "test_cases": test_cases,
            "uncertain_selectors": uncertain_selectors,
            "uncertain_files": uncertain_files,
            # Expose findings so Claude can pass them back as previous_findings
            # when saving feedback — enables the fast-update path.
            "storedFindings": findings,
        }
        if test_count is not None:
            result_payload["requested_test_count"] = test_count
            if len(test_cases) != test_count:
                result_payload["count_warning"] = (
                    f"Requested {test_count} test cases but generated {len(test_cases)}. "
                    "The model may have found fewer/more grounded scenarios than requested."
                )
        return [TextContent(type="text", text=json.dumps(result_payload, indent=2))]

    except json.JSONDecodeError as e:
        return [TextContent(type="text", text=f"JSON parse error: {e}")]
    except Exception as e:  # noqa: BLE001
        return [TextContent(type="text", text=f"Error: {e}")]
