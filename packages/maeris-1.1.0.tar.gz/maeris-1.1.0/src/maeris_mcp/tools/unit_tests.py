"""Unit Test Generation feature (Maeris spec v1.0, April 2026).

All generation and execution runs locally on the user's machine. Only metadata
(test names, paths, statuses, durations, coverage numbers) is streamed to
Maeris. Source code, stack traces, and raw runner output never leave this
process — enforced at the ingress validator on the backend and reinforced
here by only sending narrow metadata dicts.

Exposed tools:
  - detect_unit_test_framework
  - generate_unit_tests
  - run_unit_tests
  - analyze_unit_test_critical_path
  - sync_unit_tests_to_maeris  (explicit push)

Supported frameworks (v1.0): Jest, Vitest, Mocha (+ Chai), Jasmine.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import socket
import subprocess
import uuid
from pathlib import Path
from typing import Any

import click
import structlog
from mcp.types import TextContent, Tool

from maeris_mcp.maeris.client import APIRequestError, MaerisClient

logger = structlog.get_logger()


# -----------------------------------------------------------------------------
# Framework detection — reads package.json only.
# -----------------------------------------------------------------------------
FRAMEWORK_SIGNALS = {
    "jest": ("jest",),
    "vitest": ("vitest",),
    "mocha": ("mocha",),
    "jasmine": ("jasmine", "jasmine-core"),
}


def detect_framework(repo_root: Path) -> dict:
    """Read package.json at the repo root and identify the test framework.

    Resolution order:
      1. `scripts.test` command inspection (explicit developer intent)
      2. Explicit devDependency match (jest/vitest/mocha/jasmine)
    Returns dict with {framework, language, runner_command, source_files,
    confidence, detected_from}. Returns framework=None if nothing matches.
    """
    pkg_path = repo_root / "package.json"
    if not pkg_path.exists():
        return {"framework": None, "reason": "no package.json at repo root"}

    try:
        pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"framework": None, "reason": f"package.json parse error: {exc}"}

    all_deps = {}
    all_deps.update(pkg.get("dependencies") or {})
    all_deps.update(pkg.get("devDependencies") or {})

    framework = None
    detected_from = None

    # scripts.test is the authoritative source — check it first.
    script = (pkg.get("scripts") or {}).get("test", "")
    for name in FRAMEWORK_SIGNALS:
        if re.search(rf"\b{name}\b", script):
            framework = name
            detected_from = "scripts.test"
            break

    # Fall back to devDependencies if scripts.test gave no signal.
    if framework is None:
        for name, signals in FRAMEWORK_SIGNALS.items():
            if any(sig in all_deps for sig in signals):
                framework = name
                detected_from = "devDependencies"
                break

    has_ts = (
        (repo_root / "tsconfig.json").exists()
        or "typescript" in all_deps
    )
    language = "typescript" if has_ts else "javascript"

    return {
        "framework": framework,
        "language": language,
        "runner_command": (pkg.get("scripts") or {}).get("test"),
        "confidence": "high" if detected_from == "scripts.test" else "medium" if framework else "low",
        "detected_from": detected_from,
    }


# -----------------------------------------------------------------------------
# Source file scanning
# -----------------------------------------------------------------------------
_SOURCE_EXTS = {".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"}
_IGNORED_DIRS = {
    "node_modules", ".git", "dist", "build", "out", ".next", ".nuxt",
    "coverage", ".turbo", ".cache", ".vite", ".svelte-kit",
}
_TEST_FILE_RE = re.compile(r"(?:\.|-)(?:test|spec)\.(?:[cm]?js|jsx|tsx|ts)$")


def _iter_source_files(root: Path, subpath: str | None = None) -> list[Path]:
    """Yield JS/TS source + test files under `root/subpath`."""
    base = root if not subpath else (root / subpath).resolve()
    if not base.exists():
        return []
    if base.is_file():
        return [base] if base.suffix in _SOURCE_EXTS else []
    results: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in _IGNORED_DIRS and not d.startswith(".")]
        for f in filenames:
            p = Path(dirpath) / f
            if p.suffix in _SOURCE_EXTS:
                results.append(p)
    return results


def _is_test_file(p: Path) -> bool:
    return bool(_TEST_FILE_RE.search(p.name)) or "__tests__" in p.parts


def _hash_file(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception:
        return ""


# -----------------------------------------------------------------------------
# Per-file analysis cache — avoids re-running (expensive) behavioral generation
# for files that have not changed between MCP sessions.
#
# Cache location: ~/.maeris/repos/<repo_hash>/unit_test_analysis.json
# Cache key:      repo-relative source path
# Invalidation:   SHA-256 of file content + framework + language
# -----------------------------------------------------------------------------
_ANALYSIS_CACHE_VERSION = 1
_ANALYSIS_CACHE_MAX_ENTRIES = 500
# Bump this whenever the generator post-processing changes (hoisting rules,
# import scanning, assembler layout). Cached entries with an older tag are
# treated as stale — users get fresh output instead of last week's bug.
_GENERATOR_TAG = "2026-04-22.bare-export-aliases"


def _analysis_cache_path(repo_root: Path) -> Path:
    repo_hash = hashlib.sha256(str(repo_root).encode()).hexdigest()[:16]
    return Path.home() / ".maeris" / "repos" / repo_hash / "unit_test_analysis.json"


def _load_analysis_cache(repo_root: Path) -> dict:
    """Load per-file analysis cache from disk. Returns empty dict on any failure."""
    try:
        p = _analysis_cache_path(repo_root)
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if data.get("version") == _ANALYSIS_CACHE_VERSION:
                return data.get("entries", {})
    except Exception:
        pass
    return {}


def _save_analysis_cache(repo_root: Path, entries: dict) -> None:
    """Persist analysis cache to disk. Never raises."""
    try:
        p = _analysis_cache_path(repo_root)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"version": _ANALYSIS_CACHE_VERSION, "entries": entries}, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


def _get_cached_analysis(
    entries: dict, rel_path: str, file_hash: str, framework: str, language: str
) -> dict | None:
    """Return cached result for *rel_path* if the hash + framework + language match."""
    entry = entries.get(rel_path)
    if not entry:
        return None
    if (
        entry.get("file_hash") == file_hash
        and entry.get("framework") == framework
        and entry.get("language") == language
        and entry.get("generator_tag") == _GENERATOR_TAG
    ):
        return entry.get("result")
    return None


def _set_cached_analysis(
    entries: dict, rel_path: str, file_hash: str,
    framework: str, language: str, result: dict,
) -> None:
    """Store analysis result. Evicts oldest entries when over the size cap."""
    import time as _time
    # Evict oldest if at capacity
    if len(entries) >= _ANALYSIS_CACHE_MAX_ENTRIES:
        oldest = min(entries, key=lambda k: entries[k].get("cached_at", 0))
        del entries[oldest]
    entries[rel_path] = {
        "file_hash": file_hash,
        "framework": framework,
        "language": language,
        "generator_tag": _GENERATOR_TAG,
        "result": result,
        "cached_at": _time.time(),
    }


# -----------------------------------------------------------------------------
# Light AST-ish scan for exported symbols — no LLM needed for the structural
# part. Regex is intentionally conservative; we surface what we see and let the
# MCP test generator (below) produce bodies.
# -----------------------------------------------------------------------------
_ASSERTION_PATTERNS = [
    # expect(...).toXxx(...)
    re.compile(r"\bexpect\s*\([^)]*\)\s*\.\s*(\w+)\s*\("),
    # assert(...), chai expect(...).to.be.xxx
    re.compile(r"\.\s*to\s*\.\s*(\w[\w.]*)"),
]


# Each entry: (regex, is_default_export, kind). `kind` is one of:
#   "function" — invokable; tests will assert typeof === function
#   "class"    — instantiable; tests will assert new X() doesn't throw
#   "value"    — constant/object/primitive; just assert defined and not undefined
#   "unknown"  — re-exports (`export { x }`) — kind is opaque, fall back to defined
_EXPORT_PATTERNS = [
    # export function foo() / export async function foo()
    (re.compile(r"^export\s+(?:async\s+)?function\s+(\w+)\s*\(", re.MULTILINE), False, "function"),
    # export const foo = (...) => / export const foo = x =>
    (re.compile(r"^export\s+const\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*=>", re.MULTILINE), False, "function"),
    # export const foo = <value> (catches primitives, objects, function calls)
    (re.compile(r"^export\s+const\s+(\w+)\s*=", re.MULTILINE), False, "value"),
    # export let / export var
    (re.compile(r"^export\s+(?:let|var)\s+(\w+)\s*=", re.MULTILINE), False, "value"),
    # export class Foo
    (re.compile(r"^export\s+class\s+(\w+)\b", re.MULTILINE), False, "class"),
    # export default function foo / export default async function foo
    (re.compile(r"^export\s+default\s+(?:async\s+)?function\s+(\w+)?", re.MULTILINE), True, "function"),
    # export default ClassName — catch identifier-only default. Could be a
    # class, function, or React component — treat as function (most common).
    (re.compile(r"^export\s+default\s+(\w+)\s*;?\s*$", re.MULTILINE), True, "function"),
    # export { foo, bar as baz }
    (re.compile(r"^export\s*\{\s*([^}]+?)\s*\}", re.MULTILINE), False, "unknown"),
]
_IMPORT_RE = re.compile(r"^import[^;]+from\s+['\"]([^'\"]+)['\"]", re.MULTILINE)


def _scan_source_symbols(path: Path) -> dict:
    """Extract top-level exports + imports so we know what's testable.

    Returns {exports: [names], import_specifiers: [strings]}. Source content
    itself is read locally and never leaves this process.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"exports": [], "import_specifiers": []}

    # Each export is (display_name, is_default, kind). See _EXPORT_PATTERNS.
    exports: list[tuple[str, bool, str]] = []
    seen: set[str] = set()
    for pat, is_default, kind in _EXPORT_PATTERNS:
        for m in pat.finditer(text):
            raw = m.group(1) or "default"
            if "," in raw or " as " in raw:
                # `export { foo, bar as baz }` — split the captured group.
                for piece in raw.split(","):
                    name = piece.strip().split(" as ")[-1].strip()
                    if name and name.isidentifier() and name not in seen:
                        seen.add(name)
                        exports.append((name, False, kind))
            else:
                name = raw.strip()
                if name and name.isidentifier() and name not in seen:
                    seen.add(name)
                    # PascalCase identifiers from `function` / `default` are
                    # very likely React components — treat them as values for
                    # assertion purposes (calling them with no args throws).
                    resolved_kind = kind
                    if kind == "function" and name[:1].isupper():
                        resolved_kind = "component"
                    exports.append((name, is_default, resolved_kind))

    imports = list({m.group(1) for m in _IMPORT_RE.finditer(text)})
    return {"exports": exports, "import_specifiers": imports}


# -----------------------------------------------------------------------------
# Test generation — produces test files locally in framework-appropriate shape.
# -----------------------------------------------------------------------------
def _test_file_path_for(source: Path, framework: str) -> Path:
    """Derive the conventional test file path next to the source file."""
    # Prefer ``foo.test.ts`` colocated next to the source.
    stem = source.stem
    ext = source.suffix
    return source.with_name(f"{stem}.test{ext}")


def _test_header(framework: str, language: str) -> str:
    """Return the framework-specific imports/preamble."""
    if framework == "vitest":
        return 'import { describe, it, expect } from "vitest";\n'
    if framework == "jest":
        # Jest globals are ambient; add describe/it/expect typing for TS only.
        return "" if language == "javascript" else ""
    if framework == "mocha":
        return 'import { describe, it } from "mocha";\nimport { expect } from "chai";\n'
    if framework == "jasmine":
        return ""
    return ""


def _assertion_fn(framework: str) -> str:
    """Return the assertion call template the generator should use."""
    if framework == "mocha":
        return "expect({value}).to.exist;"
    # jest / vitest / jasmine all support expect()
    return "expect({value}).toBeDefined();"


def _generate_behavioral_tests_for_source(source: Path, repo_root: Path,
                                           framework: str, language: str,
                                           focus_range: tuple[int, int] | None = None,
                                           focus_function: str | None = None,
                                           is_closure_target: bool = False) -> dict:
    """Behavioral (AI-powered) test generation. Raises on any failure; the
    caller falls back to the deterministic smoke generator below.

    Output has the exact same shape as `_generate_tests_for_source` so the
    two paths are swappable without any downstream churn.
    """
    from maeris_mcp.ai_adapter.unit_test_generator import (
        generate_behavioral_tests,
        BehavioralGenerationUnavailable,
    )

    info = _scan_source_symbols(source)
    if not info["exports"]:
        return {"skipped": True, "reason": "no exported symbols"}

    rel_source = source.relative_to(repo_root).as_posix()
    test_path = _test_file_path_for(source, framework)
    rel_test = test_path.relative_to(repo_root).as_posix()
    import_spec = "./" + source.stem

    # Ask Claude. Propagate BehavioralGenerationUnavailable so the caller
    # can log + fall back cleanly.
    ai_result = generate_behavioral_tests(
        source_path=source,
        framework=framework,
        language=language,
        import_spec=import_spec,
        exports=info["exports"],
        import_specifiers=info["import_specifiers"],
        repo_root=repo_root,
        focus_range=focus_range,
        focus_function=focus_function,
        is_closure_target=is_closure_target,
    )

    # Defensive escape so an LLM-generated quote/backslash can't produce a
    # syntactically broken JS file. Order matters: backslash first.
    def _js_string(s: str) -> str:
        return (s or "")\
            .replace("\\", "\\\\")\
            .replace('"', '\\"')\
            .replace("\n", " ")\
            .replace("\r", " ")\
            .strip() or source.stem

    describe_title = _js_string(ai_result["describe"] or source.stem)
    ai_tests = ai_result["tests"]

    # jest.mock()/jest.unmock() calls are statically hoisted by babel-jest
    # ONLY when they appear at the top level of the file. The LLM often
    # places them inside the test body, which means the mock runs *after*
    # the module under test has already been imported — no effect, the
    # real component renders, RTL blows up inside next/image, and every
    # test reports a runtime error that has nothing to do with the user's
    # intent. Lift every jest.mock() call out of every test body and
    # emit a deduped block at the top of the file so hoisting works.
    hoisted_mocks: list[str] = []
    _seen_mock: set[str] = set()

    def _extract_hoist_calls(body: str) -> tuple[list[str], str]:
        """Pull jest.mock(...) / jest.unmock(...) statements out of a body.

        Returns (hoistable_statements, body_without_them). Paren-balanced
        so multi-line factories with nested arrow functions still come
        out whole.
        """
        out_hoist: list[str] = []
        out_lines: list[str] = []
        src_lines = body.split("\n")
        i = 0
        while i < len(src_lines):
            ln = src_lines[i]
            stripped = ln.lstrip()
            if stripped.startswith("jest.mock(") or stripped.startswith("jest.unmock("):
                chunk = [ln]
                depth = ln.count("(") - ln.count(")")
                while depth > 0 and i + 1 < len(src_lines):
                    i += 1
                    chunk.append(src_lines[i])
                    depth += src_lines[i].count("(") - src_lines[i].count(")")
                out_hoist.append("\n".join(chunk).rstrip())
                i += 1
                continue
            out_lines.append(ln)
            i += 1
        return out_hoist, "\n".join(out_lines)

    # Regex to pull the module path out of `jest.mock('foo', ...)`.
    # Dedupe by module path: hoisted mocks are one-per-module-per-file, so
    # keeping multiple factories for the same path is a bug — only the last
    # one would win at runtime. Ship the first factory the LLM emitted and
    # drop the rest.
    _mock_path_re = re.compile(r"jest\.(?:mock|unmock)\s*\(\s*['\"]([^'\"]+)['\"]")
    _seen_paths: set[str] = set()

    # Pass 1: walk every test body, pull out jest.mock calls, dedupe.
    rewritten_bodies: dict[int, str] = {}
    for idx, t in enumerate(ai_tests):
        extracted, cleaned = _extract_hoist_calls(t.get("body") or "")
        if extracted:
            for stmt in extracted:
                path_match = _mock_path_re.search(stmt)
                path_key = path_match.group(1) if path_match else " ".join(stmt.split())
                if path_key not in _seen_paths:
                    _seen_paths.add(path_key)
                    hoisted_mocks.append(stmt)
            rewritten_bodies[idx] = cleaned

    # Strip inline require('@testing-library/react') / require('react') from bodies
    # so they don't shadow the top-level imports we're about to add.
    _inline_rtl_re = re.compile(
        r"(?:const\s+\{[^}]+\}\s*=\s*require\s*\(\s*['\"]@testing-library/react['\"]\s*\)\s*;?\s*"
        r"|const\s+\w+\s*=\s*require\s*\(\s*['\"]@testing-library/react['\"]\s*\)\s*;?\s*"
        r"|const\s+React\s*=\s*require\s*\(\s*['\"]react['\"]\s*\)\s*;?\s*)"
    )
    cleaned_bodies: dict[int, str] = {}
    for idx, t in enumerate(ai_tests):
        body = rewritten_bodies.get(idx, t.get("body") or "")
        cleaned = _inline_rtl_re.sub("", body)
        if cleaned != body:
            cleaned_bodies[idx] = cleaned
    rewritten_bodies.update(cleaned_bodies)

    # Scan all test bodies to detect RTL/React usage and build needed imports.
    # Use the cleaned bodies so inline requires don't affect detection.
    all_bodies = " ".join(
        (rewritten_bodies.get(i, t.get("body") or "")) for i, t in enumerate(ai_tests)
    )
    needs_react = bool(re.search(r'\bReact\b', all_bodies))
    _rtl_candidates = [
        ("render",    re.compile(r'\brender\s*\(')),
        ("screen",    re.compile(r'\bscreen\.')),
        ("fireEvent", re.compile(r'\bfireEvent\b')),
        ("act",       re.compile(r'\bact\s*\(')),
        ("waitFor",   re.compile(r'\bwaitFor\s*\(')),
        ("within",    re.compile(r'\bwithin\s*\(')),
    ]
    rtl_names = [name for name, pat in _rtl_candidates if pat.search(all_bodies)]

    # Detect bare export name references — Claude sometimes uses the exported
    # symbol directly (e.g. React.createElement(AddProductForm)) instead of
    # via mod.Name, producing a ReferenceError at runtime. Inject const aliases
    # after the namespace import so both access styles work.
    _bare_export_aliases: list[str] = []
    if not is_closure_target:
        for exp_name, is_default, _kind in info.get("exports", []):
            bare_pat = re.compile(r'(?<!mod\.)\b' + re.escape(exp_name) + r'\b')
            if bare_pat.search(all_bodies):
                rhs = f"mod.default ?? mod.{exp_name}" if is_default else f"mod.{exp_name}"
                _bare_export_aliases.append(f"const {exp_name} = {rhs};\n")

    # Assemble the test file.
    lines: list[str] = [_test_header(framework, language)]
    if needs_react:
        lines.append('import React from "react";\n')
    if rtl_names:
        lines.append(f'import {{ {", ".join(rtl_names)} }} from "@testing-library/react";\n')
    if needs_react or rtl_names:
        lines.append("\n")
    # Mock declarations FIRST — babel-jest hoists these above imports at
    # transform time, but emitting them first also makes the source read
    # the way it executes, which helps anyone who opens the file.
    for stmt in hoisted_mocks:
        lines.append(stmt + "\n")
    if hoisted_mocks:
        lines.append("\n")
    # Closure/factory tests are self-contained — the function body is copied
    # directly into the factory helper. Importing the parent module would load
    # its entire dependency tree (Redux, contexts, next/image, etc.) which Jest
    # cannot resolve without mocks, aborting the file before any test runs.
    if not is_closure_target:
        lines.append(f'import * as mod from "{import_spec}";\n')
        for alias in _bare_export_aliases:
            lines.append(alias)
        lines.append("\n")
    lines.append(f'describe("{describe_title}", () => {{\n')

    preamble = (ai_result.get("preamble") or "").strip()
    if preamble:
        indented_preamble = "\n".join(
            ("  " + ln if ln.strip() else "") for ln in preamble.splitlines()
        )
        lines.append(indented_preamble + "\n\n")

    test_cases: list[dict] = []
    # Use the RAW describe_title (unescaped but whitespace-normalised) for
    # metadata so it matches the `fullName` Jest emits at runtime.
    def _collapse_ws(s: str) -> str:
        return " ".join((s or "").split())

    raw_describe = _collapse_ws(ai_result["describe"] or source.stem) or source.stem

    # Build a map of the LLM's scenario ids so each test can carry its
    # corresponding scenario_key through to register_tests. The backend
    # will then resolve scenario_key -> backend scenario_id after
    # register-scenarios runs.
    scenarios_by_local_id: dict[str, dict] = {
        s["id"]: s for s in (ai_result.get("scenarios") or [])
    }

    _em_dash_sep = " — "  # " — "
    for _ai_idx, t in enumerate(ai_tests):
        raw_name = _collapse_ws(t["name"])
        # Strip a leading "DescribeTitle — " prefix — test runners concatenate
        # the describe and it titles, so "AddProductForm — rendered — ..." inside
        # describe("AddProductForm") renders as "AddProductForm AddProductForm — ..."
        # in the UI. The describe block already provides the component/function
        # context, so the prefix is pure duplication.
        if raw_name.startswith(raw_describe + _em_dash_sep):
            raw_name = raw_name[len(raw_describe) + len(_em_dash_sep):]
        safe_name = _js_string(raw_name)
        body = (rewritten_bodies.get(_ai_idx, t["body"])).rstrip()
        # Indent body uniformly so the output reads cleanly.
        indented_body = "\n".join(
            ("    " + ln if ln.strip() else "") for ln in body.splitlines()
        )
        is_async = "await " in body
        async_kw = "async " if is_async else ""
        lines.append(f'  it("{safe_name}", {async_kw}() => {{\n')
        lines.append(indented_body + "\n")
        lines.append('  });\n\n')

        # Count `expect(` calls in the body for AC-40 (graphical view scale).
        # Cap at 20 per the Definition of Done.
        assertion_count = min(20, max(1, body.count("expect(")))
        # Thread the scenario's stable key through so the backend can link
        # the test row to the scenario row after it's registered.
        linked_scenario = scenarios_by_local_id.get(t.get("scenario_id") or "")
        scenario_key = linked_scenario.get("scenario_key") if linked_scenario else None
        test_cases.append({
            "test_name": f"{raw_describe} {raw_name}",
            "file_path": rel_test,
            "framework": framework,
            "assertion_count": assertion_count,
            # New metadata so the UI can show a "Behavioral" badge and
            # trends can distinguish depth over time. Consumed by the
            # backend (unit_tests model) if it knows the column; ignored
            # otherwise so this stays backwards-compatible.
            "depth": "behavioral",
            # Scenario-key linkage (CTO scenario tree) — backend swaps it
            # for scenario_id after register-scenarios completes.
            "scenario_key": scenario_key,
        })

    lines.append("});\n")

    return {
        "skipped": False,
        "rel_source": rel_source,
        "rel_test": rel_test,
        "test_file_abs": str(test_path),
        "content": "".join(lines),
        "cases": test_cases,
        # Scenarios are forwarded unchanged; the outer generate handler
        # registers them with Maeris *before* the tests so the linkage
        # survives the round-trip.
        "scenarios": ai_result.get("scenarios", []),
    }


def _generate_tests_for_source(source: Path, repo_root: Path,
                               framework: str, language: str) -> dict:
    """Build a simple, meaningful smoke test file for the given source.

    We import every top-level export and assert it's defined. For functions,
    we also emit an invocation placeholder the user is expected to refine.
    This keeps generated tests grounded in the source (AC-06) without ever
    inventing behavior.
    """
    info = _scan_source_symbols(source)
    if not info["exports"]:
        return {"skipped": True, "reason": "no exported symbols"}

    rel_source = source.relative_to(repo_root).as_posix()
    test_path = _test_file_path_for(source, framework)
    rel_test = test_path.relative_to(repo_root).as_posix()

    # Build relative import — drop extension for TS/JS module resolution.
    import_spec = "./" + source.stem

    lines: list[str] = [_test_header(framework, language)]
    lines.append(f'import * as mod from "{import_spec}";\n\n')
    lines.append(f'describe("{source.stem}", () => {{\n')

    test_cases: list[dict] = []
    assertion = _assertion_fn(framework)

    for name, is_default, kind in info["exports"]:
        # Default exports live at `mod.default`; named exports at `mod[name]`.
        # Accept either so we don't false-fail when the regex misclassifies.
        if is_default:
            accessor = f'(mod.default ?? mod["{name}"])'
        else:
            accessor = f'(mod["{name}"] ?? mod.default)'

        # Kind-aware test bodies — generic `toBeDefined()` is a fallback only.
        # Functions assert callability; classes assert constructability;
        # components and values stick with defined+typeof so we don't try to
        # render JSX (would need a DOM env per AC scope decisions).
        body_lines: list[str] = []
        assertion_count = 1
        if kind == "function":
            case_title = f"exports {name} as a callable function"
            body_lines.append(f'    const fn = {accessor};')
            body_lines.append(f'    expect(fn).toBeDefined();')
            body_lines.append(f'    expect(typeof fn).toBe("function");')
            assertion_count = 2
        elif kind == "class":
            case_title = f"exports {name} as an instantiable class"
            body_lines.append(f'    const Cls = {accessor};')
            body_lines.append(f'    expect(Cls).toBeDefined();')
            body_lines.append(f'    expect(typeof Cls).toBe("function");')
            assertion_count = 2
        elif kind == "component":
            case_title = f"exports {name} as a React component"
            body_lines.append(f'    const Component = {accessor};')
            body_lines.append(f'    expect(Component).toBeDefined();')
            body_lines.append(f'    expect(typeof Component === "function" || typeof Component === "object").toBe(true);')
            assertion_count = 2
        elif kind == "value":
            case_title = f"exports {name} with a defined value"
            body_lines.append(f'    const value = {accessor};')
            body_lines.append(f'    expect(value).toBeDefined();')
            body_lines.append(f'    expect(value).not.toBeNull();')
            assertion_count = 2
        else:  # unknown / re-export
            case_title = f"exposes {name}"
            body_lines.append(f'    expect({accessor}).toBeDefined();')

        body_text = "\n".join(body_lines)
        is_async = "await " in body_text
        async_kw = "async " if is_async else ""
        lines.append(f'  it("{case_title}", {async_kw}() => {{\n')
        for ln in body_lines:
            lines.append(ln + "\n")
        lines.append('  });\n\n')
        # Test name mirrors the runner's own `fullName` (describe + it joined by
        # space) so run-time results match the registered metadata by key.
        test_cases.append({
            "test_name": f"{source.stem} {case_title}",
            "file_path": rel_test,
            "framework": framework,
            "assertion_count": assertion_count,
            "depth": "smoke",
        })

    lines.append("});\n")

    return {
        "skipped": False,
        "rel_source": rel_source,
        "rel_test": rel_test,
        "test_file_abs": str(test_path),
        "content": "".join(lines),
        "cases": test_cases,
    }


def _generate_tests_dispatched(source: Path, repo_root: Path,
                                framework: str, language: str,
                                *, prefer_behavioral: bool,
                                focus_range: tuple[int, int] | None = None,
                                focus_function: str | None = None,
                                is_closure_target: bool = False) -> dict:
    """Dispatch layer: try behavioral first when enabled, fall back to smoke.

    Guarantees every failure mode of the LLM path is absorbed — we only give
    up and return a skip when the regex fallback ALSO has nothing to offer.
    """
    if prefer_behavioral:
        try:
            return _generate_behavioral_tests_for_source(
                source, repo_root, framework, language,
                focus_range=focus_range, focus_function=focus_function,
                is_closure_target=is_closure_target,
            )
        except Exception as exc:
            # BehavioralGenerationUnavailable + any other surprise goes
            # here. Log and fall through to smoke — never abort the run.
            reason = getattr(exc, "reason", None) or str(exc)[:200]
            logger.info(
                "unit_test_gen.behavioral_fallback",
                source=str(source),
                reason=reason,
            )
    return _generate_tests_for_source(source, repo_root, framework, language)


def _sidecar_path(test_file: Path) -> Path:
    """Return the .maeris-meta.json sidecar path for a given test file."""
    return test_file.parent / (test_file.stem + ".maeris-meta.json")


def _write_sidecar(test_file: Path, cases: list[dict]) -> None:
    """Persist test_name → scenario_key mapping alongside the test file.

    Written once at generation time and read back on every run so the
    run handler can re-register tests with their scenario linkage intact.
    """
    mapping = {
        c["test_name"]: c.get("scenario_key")
        for c in cases
        if c.get("scenario_key")
    }
    if not mapping:
        return
    sidecar = _sidecar_path(test_file)
    try:
        sidecar.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
    except Exception as exc:
        logger.warning("unit_test_gen.sidecar_write_failed",
                       path=str(sidecar), error=str(exc))


def _read_sidecar(test_file: Path) -> dict[str, str]:
    """Load test_name → scenario_key mapping from the sidecar, or {} if absent."""
    sidecar = _sidecar_path(test_file)
    if not sidecar.exists():
        return {}
    try:
        return json.loads(sidecar.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_test_file_if_new(path: Path, content: str, overwrite: bool) -> dict:
    """Write test content to disk; by default do not clobber existing tests."""
    if path.exists() and not overwrite:
        return {"written": False, "reason": "exists"}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return {"written": True}


def _extract_describe_block(content: str) -> str:
    """Extract the outermost describe(...) block from generated content, stripping imports."""
    lines = content.splitlines(keepends=True)
    result = []
    inside = False
    depth = 0
    in_string: str | None = None
    for line in lines:
        if not inside:
            if re.match(r"^\s*describe\s*\(", line):
                inside = True
            else:
                continue
        result.append(line)
        for ch in line:
            if in_string:
                if ch == in_string:
                    in_string = None
            elif ch in ('"', "'", "`"):
                in_string = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth <= 0:
                    return "".join(result).strip()
    return "".join(result).strip()


def _append_tests_to_file(path: Path, new_content: str) -> dict:
    """Append a new describe block after the existing outermost describe block in the file."""
    try:
        existing = path.read_text(encoding="utf-8")
    except Exception as exc:
        return {"written": False, "reason": f"read failed: {exc}"}
    new_describe = _extract_describe_block(new_content)
    if not new_describe.strip():
        return {"written": False, "reason": "no describe block extracted"}

    # Find the OUTERMOST describe block's closing brace by tracking depth from
    # the first describe( opener. The old regex (last `});` at col-0) was
    # wrong for files with nested describe blocks — it inserted into the inner one.
    lines = existing.splitlines(keepends=True)
    describe_started = False
    depth = 0
    insert_byte_pos = -1
    byte_pos = 0
    in_string: str | None = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if not describe_started:
            if re.match(r"\s*describe\s*\(", line):
                describe_started = True
                depth = 0
        if describe_started:
            for ch in line:
                if in_string:
                    if ch == in_string:
                        in_string = None
                elif ch in ('"', "'", "`"):
                    in_string = ch
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth <= 0:
                        # byte_pos now points just past the previous chars;
                        # insert_byte_pos is the position of this closing `}`
                        insert_byte_pos = byte_pos + line.index("}", line.index("}") if "}" in line else 0)
                        # More precisely: find position in `existing` string
                        break
            if depth <= 0 and describe_started:
                break
        byte_pos += len(line)
        i += 1

    # Fallback: compute insert position from accumulated byte offset of lines up to i
    if insert_byte_pos == -1 or depth > 0:
        return {"written": False, "reason": "could not locate outermost describe closing brace"}

    # Insert after the full closing line of the outermost describe block.
    prefix = "".join(lines[:i])
    closing_line = lines[i] if i < len(lines) else ""
    end_pos = len(prefix) + len(closing_line)

    patched = existing[:end_pos] + "\n\n" + new_describe + "\n" + existing[end_pos:]
    try:
        path.write_text(patched, encoding="utf-8")
        return {"written": True, "mode": "appended"}
    except Exception as exc:
        return {"written": False, "reason": f"write failed: {exc}"}


# -----------------------------------------------------------------------------
# Critical path analysis — static only (per spec Q4 for v1.0).
# -----------------------------------------------------------------------------
def _compute_critical_path(repo_root: Path, tests: list[dict]) -> tuple[list[str], list[dict]]:
    """Rank source files by risk and return (test_ids, details) for the
    tests whose source files fall in the top third.

    `details` carries the reasoning the UI needs to explain "why this
    test is critical": risk_score, in_degree, depth, coverage_gap, and a
    short human-readable reason. Without this the panel can flag tests
    but can't tell the user *why*, leaving them stuck.

    Per spec AC-20, risk combines:
      1. call_frequency   → number of files that import this one (in-degree)
      2. dependency_depth → how deep the import tree under this file goes
      3. coverage_gap     → multiplier; uncovered files weigh much more
    """
    src_files = [p for p in _iter_source_files(repo_root) if not _is_test_file(p)]
    if not src_files:
        return [], []

    rel = {p.relative_to(repo_root).as_posix(): p for p in src_files}
    in_degree: dict[str, int] = {k: 0 for k in rel}
    imports_by_file: dict[str, set[str]] = {k: set() for k in rel}

    for rel_path, path in rel.items():
        symbols = _scan_source_symbols(path)
        for spec in symbols["import_specifiers"]:
            # Resolve relative imports only — local files matter for risk.
            if not spec.startswith("."):
                continue
            resolved = (path.parent / spec).resolve()
            # Try common suffixes
            candidates = [resolved.with_suffix(ext) for ext in _SOURCE_EXTS]
            candidates.append(resolved / "index.ts")
            candidates.append(resolved / "index.js")
            for cand in candidates:
                try:
                    rel_cand = cand.resolve().relative_to(repo_root).as_posix()
                except Exception:
                    continue
                if rel_cand in in_degree:
                    in_degree[rel_cand] += 1
                    imports_by_file[rel_path].add(rel_cand)
                    break

    # Dependency depth via BFS.
    depth: dict[str, int] = {k: 0 for k in rel}
    for start in rel:
        seen = {start}
        frontier = [(start, 0)]
        while frontier:
            node, d = frontier.pop()
            if d > depth[node]:
                depth[node] = d
            for nxt in imports_by_file.get(node, ()):
                if nxt not in seen and d < 8:
                    seen.add(nxt)
                    frontier.append((nxt, d + 1))

    # Build the inverse map: which source files already have tests pointing
    # at them. Sources missing here are uncovered and get a higher weight.
    # Carry the test_name + file_path through so the UI can match flagged
    # tests by a stable composite key — backend sync paths sometimes
    # re-mint unit_test_ids, which would otherwise drop rows from the
    # critical-path panel after a run.
    test_source_map: dict[str, str] = {}
    test_meta: dict[str, dict] = {}
    covered_sources: set[str] = set()
    for t in tests:
        test_id = t.get("unit_test_id") or t.get("test_name")
        fp = t.get("file_path") or ""
        source_guess = fp.replace(".test.", ".").replace(".spec.", ".")
        test_source_map[test_id] = source_guess
        test_meta[test_id] = {"test_name": t.get("test_name"), "file_path": fp}
        covered_sources.add(source_guess)

    # Coverage gap: 3x weight when a source has no tests at all (per AC-20).
    def coverage_weight(src: str) -> int:
        return 1 if src in covered_sources else 3

    scores = {
        k: (in_degree[k] + 1) * (depth[k] + 1) * coverage_weight(k)
        for k in rel
    }

    if not scores:
        return [], []

    # Top third by score. We then return the tests whose sources are in that
    # top set — uncovered hot files surface in the panel even though they
    # have no tests yet (the user can use that signal to generate them).
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    cutoff = max(1, len(ranked) // 3)
    critical_sources = {k for k, _ in ranked[:cutoff]}
    max_score = ranked[0][1] if ranked else 1

    ids: list[str] = []
    details: list[dict] = []
    for test_id, source in test_source_map.items():
        if source not in critical_sources:
            continue
        ids.append(test_id)
        deg = in_degree.get(source, 0)
        dep = depth.get(source, 0)
        cov_gap = coverage_weight(source) > 1
        score = scores.get(source, 0)
        # Normalize 0-100 against the highest-ranked file so the UI can
        # render a comparable risk badge.
        norm = int(round((score / max_score) * 100)) if max_score else 0
        risk_level = "high" if norm >= 70 else ("medium" if norm >= 40 else "low")

        # Human-readable reason — the UI shows this as the "why critical" chip.
        bits: list[str] = []
        if deg > 0:
            bits.append(f"imported by {deg} file{'s' if deg != 1 else ''}")
        if dep > 0:
            bits.append(f"depth {dep} in import tree")
        if cov_gap:
            bits.append("uncovered upstream module")
        reason = ", ".join(bits) if bits else "high-traffic source file"

        meta = test_meta.get(test_id, {})
        details.append({
            "unit_test_id": test_id,
            "test_name": meta.get("test_name"),
            "file_path": meta.get("file_path"),
            "source_file": source,
            "risk_score": norm,
            "risk_level": risk_level,
            "in_degree": deg,
            "depth": dep,
            "coverage_gap": cov_gap,
            "reason": reason,
        })

    # Sort details by risk descending so the UI list is already ranked.
    details.sort(key=lambda d: d["risk_score"], reverse=True)
    return ids, details


# -----------------------------------------------------------------------------
# Test runner — shells out to the project's own runner, parses output.
# -----------------------------------------------------------------------------
def _runner_argv(framework: str, scope_type: str, scope_ref: str | None) -> list[str]:
    """Build a shell argv for the framework. Prefer JSON reporters where
    available so we can parse results reliably.

    scope_type distinguishes between targeting by file/folder vs a specific
    test name (AC-25 "single test"). For test-name scope each runner takes a
    different flag.
    """
    is_test_name = scope_type == "test"

    if framework == "jest":
        args = ["npx", "jest", "--json", "--silent"]
        if not is_test_name:
            # AC-30: coverage only for file/folder/suite runs — not single-test
            # runs, where instrumentation overhead dominates and numbers are meaningless.
            args += ["--coverage", "--coverageReporters=json-summary", "--coverageReporters=json"]
        if scope_ref:
            if is_test_name:
                args += ["-t", scope_ref]
            elif scope_type == "file":
                # Pass the path literally — paths with parens (e.g. Next.js
                # route groups like `app/(shop)/...`) would otherwise be
                # parsed as a regex and match nothing.
                args += ["--runTestsByPath", scope_ref]
            else:
                # Folder scope. Jest 30 renamed --testPathPattern to
                # --testPathPatterns (plural) and rejects the old name.
                # The pattern is a regex, so escape special chars first.
                args += ["--testPathPatterns", re.escape(scope_ref)]
    elif framework == "vitest":
        args = ["npx", "vitest", "run", "--reporter=json"]
        if not is_test_name:
            args.append("--coverage")
        if scope_ref:
            if is_test_name:
                args += ["-t", scope_ref]
            else:
                args.append(scope_ref)
    elif framework == "mocha":
        args = ["npx", "mocha", "--reporter", "json"]
        if scope_ref:
            if is_test_name:
                args += ["--grep", scope_ref]
            else:
                args.append(scope_ref)
    elif framework == "jasmine":
        args = ["npx", "jasmine", "--reporter=jasmine-reporters/ConsoleReporter"]
        if scope_ref and not is_test_name:
            args.append(scope_ref)
        if scope_ref and is_test_name:
            args += ["--filter", scope_ref]
    else:
        args = ["npm", "test", "--"]
        if scope_ref:
            args.append(scope_ref)
    return args


def _read_jest_coverage_pct(repo_root: Path) -> float | None:
    """Read coverage/coverage-summary.json (written by Jest --coverage
    --coverageReporters=json-summary) and return the overall statements %.

    Returns None if the file is missing or unparseable. Delta vs previous
    runs is computed by the backend, which already has full run history —
    keeping the MCP logic simple and deterministic.
    """
    summary_path = repo_root / "coverage" / "coverage-summary.json"
    if not summary_path.is_file():
        return None
    try:
        data = json.loads(summary_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    total = (data.get("total") or {})
    stmt = (total.get("statements") or {})
    pct = stmt.get("pct")
    if pct is None:
        return None
    try:
        return round(float(pct), 2)
    except (TypeError, ValueError):
        return None


def _parse_jest_output(raw: str) -> list[dict]:
    """Jest --json: top-level testResults[] → testResults[] array per file.
    Each inner test has fullName, status ('passed'|'failed'|'pending'|'skipped'),
    duration, failureMessages[]."""
    try:
        data = json.loads(raw)
    except Exception:
        return []
    results: list[dict] = []
    for file_result in data.get("testResults", []):
        file_path = file_result.get("name") or file_result.get("testFilePath") or ""
        inner_tests = file_result.get("testResults") or file_result.get("assertionResults") or []
        if not inner_tests:
            # Suite failed to load (compile error, missing dep, etc.) — surface
            # it as a single failed entry so the user sees what went wrong
            # instead of a misleading "0 passed / 0 failed". Jest puts the
            # suite-level error in `message` (or `failureMessage` historically).
            suite_err = file_result.get("message") or file_result.get("failureMessage") or ""
            if suite_err or (file_result.get("status") or "").lower() == "failed":
                # Pick the first non-empty line — jest prefixes with whitespace
                # and a bullet, then a blank line, then the actual error.
                first_line = next(
                    (ln.strip().lstrip("●").strip()
                     for ln in (suite_err or "").splitlines() if ln.strip()),
                    "",
                )
                results.append({
                    "file_path": file_path,
                    "test_name": "<suite load>",
                    "status": "failed",
                    "duration_ms": 0,
                    "error_message": (first_line[:500] if first_line else "test suite failed to run"),
                })
            continue
        for test in inner_tests:
            status_raw = (test.get("status") or "").lower()
            status = {"pending": "skipped", "todo": "skipped"}.get(status_raw, status_raw)
            failure_messages = test.get("failureMessages") or []
            # Strip stack traces → keep the first line only.
            error_message = ""
            if failure_messages:
                first = failure_messages[0].split("\n", 1)[0].strip()
                error_message = first[:500]
            results.append({
                "file_path": file_path,
                "test_name": test.get("fullName") or test.get("title") or "",
                "status": status,
                "duration_ms": int(test.get("duration") or 0),
                "error_message": error_message or None,
            })
    return results


def _parse_vitest_output(raw: str) -> list[dict]:
    # Vitest JSON reporter is Jest-compatible.
    return _parse_jest_output(raw)


def _parse_mocha_output(raw: str) -> list[dict]:
    try:
        data = json.loads(raw)
    except Exception:
        return []
    results: list[dict] = []
    for bucket, status in (("passes", "passed"), ("failures", "failed"), ("pending", "skipped")):
        for test in data.get(bucket, []) or []:
            err = (test.get("err") or {}).get("message") or ""
            results.append({
                "file_path": test.get("file") or "",
                "test_name": test.get("fullTitle") or test.get("title") or "",
                "status": status,
                "duration_ms": int(test.get("duration") or 0),
                "error_message": (err.split("\n", 1)[0])[:500] if err else None,
            })
    return results


def _parse_runner_output(framework: str, raw: str) -> list[dict]:
    if framework == "jest":
        return _parse_jest_output(raw)
    if framework == "vitest":
        return _parse_vitest_output(raw)
    if framework == "mocha":
        return _parse_mocha_output(raw)
    # Fallback: attempt jest shape, else empty.
    parsed = _parse_jest_output(raw)
    return parsed


async def _execute_runner(repo_root: Path, framework: str,
                          scope_type: str, scope_ref: str | None,
                          timeout_s: int = 600,
                          cancel_check=None) -> dict:
    """Run the test framework subprocess. cancel_check is an async callable
    that returns True when the run should be aborted (AC-28)."""
    import shutil as _shutil
    import time as _time
    argv = _runner_argv(framework, scope_type, scope_ref)
    # asyncio.create_subprocess_exec uses CreateProcess on Windows, which
    # cannot resolve .cmd shims (e.g. npx.cmd, npm.cmd) from a bare name.
    # shutil.which() resolves the full executable path including extensions
    # on Windows (PATHEXT) and symlinks on Unix, so we resolve argv[0] here
    # regardless of platform to get a reliable absolute path.
    _t = _time.monotonic()
    if argv:
        resolved = _shutil.which(argv[0])
        if resolved:
            argv = [resolved] + list(argv[1:])
    click.secho(f"  [timing] which: {(_time.monotonic() - _t) * 1000:.0f}ms  argv={argv}", fg="yellow")
    _t = _time.monotonic()
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv, cwd=str(repo_root),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        click.secho(f"  [timing] subprocess spawned (pid={proc.pid}): {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
    except FileNotFoundError:
        return {"ok": False, "error": "npx not found — is Node installed?"}
    except Exception as exc:
        return {"ok": False, "error": f"runner exec failed: {exc}"}
    _proc_start = _time.monotonic()

    # Poll in 5-second slices so we can check for cancellation between slices.
    # communicate() is started as a single persistent task — never cancelled
    # mid-read, which would corrupt the pipe reader state and cause early return
    # with empty output while the subprocess is still running.
    deadline = asyncio.get_event_loop().time() + timeout_s
    poll_interval = 5.0
    comm_task = asyncio.ensure_future(proc.communicate())
    stdout = stderr = b""
    while True:
        done, _ = await asyncio.wait({comm_task}, timeout=poll_interval)
        if done:
            stdout, stderr = comm_task.result()
            click.secho(f"  [timing] subprocess finished (exit={proc.returncode}): {(_time.monotonic() - _proc_start) * 1000:.0f}ms", fg="yellow")
            break  # finished cleanly
        # Slice timed out — check deadline and cancellation without touching the task.
        if asyncio.get_event_loop().time() >= deadline:
            try:
                proc.kill()
                await proc.wait()
            except Exception:
                pass
            comm_task.cancel()
            return {"ok": False, "error": f"timeout after {timeout_s}s"}
        if cancel_check:
            try:
                if await cancel_check():
                    try:
                        proc.kill()
                        await proc.wait()
                    except Exception:
                        pass
                    comm_task.cancel()
                    return {"ok": False, "cancelled": True}
            except Exception:
                pass

    return {
        "ok": True,
        "exit_code": proc.returncode,
        "stdout": (stdout or b"").decode("utf-8", errors="replace"),
        "stderr_first_line": ((stderr or b"").decode("utf-8", errors="replace")
                              .split("\n", 1)[0])[:500],
    }


# -----------------------------------------------------------------------------
# Tool definitions + handlers
# -----------------------------------------------------------------------------
def detect_unit_test_framework_tool() -> Tool:
    return Tool(
        name="detect_unit_test_framework",
        description=(
            "Detect the JavaScript/TypeScript unit test framework used by the "
            "project (Jest / Vitest / Mocha+Chai / Jasmine) by inspecting "
            "package.json. Returns the framework name, language (JS/TS), the "
            "runner command from scripts.test, and a confidence indicator. "
            "Used before calling generate_unit_tests or run_unit_tests so the "
            "UI can show a framework icon and the right runner argv."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string",
                              "description": "Absolute or relative path to the project root. Defaults to current working directory."},
            },
        },
    )


async def handle_detect_unit_test_framework(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    result = detect_framework(repo)
    return [TextContent(type="text", text=json.dumps({"repo_path": str(repo), **result}, indent=2))]


def generate_unit_tests_tool() -> Tool:
    return Tool(
        name="generate_unit_tests",
        description=(
            "Generate unit tests for a JavaScript/TypeScript file or folder. "
            "Tests are written to disk locally next to the source file "
            "(*.test.ts / *.test.js) using the project's detected framework "
            "and pushed as METADATA only to Maeris. No source code is ever "
            "sent to the server.\n\n"
            "Use when the user asks to generate/write/create unit tests, "
            "or says things like 'generate tests for src/utils'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "target": {"type": "string",
                           "description": "File or folder path relative to the repo root."},
                "overwrite": {"type": "boolean", "default": False},
                "sync_to_maeris": {"type": "boolean", "default": True,
                                   "description": "Push metadata of generated tests to the Maeris portal."},
                "depth": {"type": "string",
                          "enum": ["behavioral", "smoke", "auto"],
                          "default": "auto",
                          "description": "Test depth. 'behavioral' generates 3-6 real tests per export (inputs, edge cases, errors). 'smoke' uses the deterministic regex generator. 'auto' tries behavioral then falls back to smoke per file."},
            },
            "required": ["target"],
        },
    )


async def handle_generate_unit_tests(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    target = arguments.get("target") or "."
    overwrite = bool(arguments.get("overwrite"))
    sync = arguments.get("sync_to_maeris", True)
    dry_run = bool(arguments.get("dry_run"))
    depth = (arguments.get("depth") or "auto").lower()
    # AC-06: behavioral generation is the default — tests that actually
    # exercise behavior, not just existence. `smoke` forces the regex path
    # for cases where AI is unavailable by policy or the user wants speed.
    prefer_behavioral = depth in ("behavioral", "auto")
    # AC-07: optional callback that receives a progress line per file processed.
    # The caller (cli/unit_tests_dispatch.py) wires this up to post_progress.
    progress_sink = arguments.get("_progress_sink")

    framework_info = detect_framework(repo)
    framework = framework_info.get("framework")
    if not framework:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "no supported framework detected in package.json",
            "detected": framework_info,
        }, indent=2))]
    language = framework_info.get("language", "javascript")

    source_files = [p for p in _iter_source_files(repo, target) if not _is_test_file(p)]
    # Diagnostic: log what we found so a "0 tests / 0 files" summary is
    # traceable back to scope resolution rather than a silent parser miss.
    logger.info(
        "unit_test_gen.scope",
        repo=str(repo), target=target,
        source_file_count=len(source_files),
        samples=[p.relative_to(repo).as_posix() for p in source_files[:5]],
    )
    if progress_sink:
        try:
            progress_sink(f"Found {len(source_files)} source file(s) under {target}")
        except Exception:
            pass

    generated: list[dict] = []
    metadata_tests: list[dict] = []
    # CTO scenario tree: per source file, the scenario batch we register
    # with Maeris before submitting tests. Keyed by source's repo-relative
    # path (matches the backend's scenarios.file_path).
    scenario_batches: dict[str, dict] = {}
    # Per-file reasons so we surface why a file was skipped (no exports,
    # generator fell back, on-disk test exists and overwrite=False, etc.)
    # back to the UI instead of silently dropping them from the summary.
    skipped_summary: list[dict] = []

    # Load per-file analysis cache once — avoids re-running behavioral generation
    # for unchanged files across MCP reconnects.
    _analysis_cache = _load_analysis_cache(repo)
    _cache_dirty = False

    total_files = len(source_files)
    for idx, src in enumerate(source_files, start=1):
        rel = src.relative_to(repo).as_posix()
        src_hash = _hash_file(src)

        # Fast cache check before any analysis
        _cached = _get_cached_analysis(_analysis_cache, rel, src_hash, framework, language)
        if _cached is not None:
            logger.info("unit_test_gen.cache_hit", file=rel)
            if _cached.get("skipped"):
                reason = _cached.get("reason", "unknown")
                skipped_summary.append({"file": rel, "reason": reason})
                if progress_sink:
                    try:
                        progress_sink(f"[{idx}/{total_files}] cached (skipped) {rel}")
                    except Exception:
                        pass
                continue
            result = dict(_cached)
            # Recompute abs path for this machine (may differ across environments)
            result["test_file_abs"] = str(_test_file_path_for(src, framework))
            if progress_sink:
                try:
                    progress_sink(f"[{idx}/{total_files}] cached {rel}")
                except Exception:
                    pass
        else:
            if progress_sink:
                try:
                    mode = "analyzing" if prefer_behavioral else "scanning"
                    progress_sink(f"[{idx}/{total_files}] {mode} {rel}")
                except Exception:
                    pass
            try:
                # Run the blocking subprocess call (Claude CLI) in a thread so
                # the asyncio event loop stays free to fire heartbeat ticks.
                # Without this, subprocess.run() starves the loop for the full
                # AI generation duration (30-120s) and the backend marks the
                # connection disconnected.
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: _generate_tests_dispatched(
                        src, repo, framework, language, prefer_behavioral=prefer_behavioral,
                    ),
                )
            except Exception as exc:
                logger.warning("unit_test_gen.file_failed", file=rel, error=str(exc)[:300])
                skipped_summary.append({"file": rel, "reason": f"exception: {str(exc)[:200]}"})
                if progress_sink:
                    try:
                        progress_sink(f"  ✗ {rel}: {str(exc)[:200]}")
                    except Exception:
                        pass
                continue
            if result.get("skipped"):
                reason = result.get("reason", "unknown")
                logger.info("unit_test_gen.skipped", file=rel, reason=reason)
                skipped_summary.append({"file": rel, "reason": reason})
                if progress_sink:
                    try:
                        progress_sink(f"  — {rel} skipped ({reason})")
                    except Exception:
                        pass
                # Cache skipped result too — avoids re-scanning unchanged files
                _set_cached_analysis(
                    _analysis_cache, rel, src_hash, framework, language,
                    {"skipped": True, "reason": reason},
                )
                _cache_dirty = True
                continue
            # Store successful analysis (without the machine-specific abs path)
            _cacheable = {k: v for k, v in result.items() if k != "test_file_abs"}
            _set_cached_analysis(_analysis_cache, rel, src_hash, framework, language, _cacheable)
            _cache_dirty = True
        if dry_run:
            # Preview only — don't touch disk, don't push metadata.
            generated.append({
                "source": result["rel_source"],
                "test_file": result["rel_test"],
                "written": False,
                "reason": "dry_run",
                "cases": [c["test_name"] for c in result["cases"]],
            })
        else:
            test_file_path = Path(result["test_file_abs"])
            writeout = _write_test_file_if_new(test_file_path, result["content"], overwrite)
            generated.append({
                "source": result["rel_source"],
                "test_file": result["rel_test"],
                "written": writeout["written"],
                "reason": writeout.get("reason"),
                "cases": [c["test_name"] for c in result["cases"]],
            })
            # Always (re)write the sidecar so scenario linkage stays current
            # even when the test file itself wasn't overwritten.
            _write_sidecar(test_file_path, result["cases"])
        for c in result["cases"]:
            metadata_tests.append({**c, "source_hash": src_hash})

        # Accumulate scenarios per file so we can bulk-register them just
        # before the tests (the backend returns scenario_ids keyed by
        # scenario_key, which we thread onto tests for the linkage).
        file_scenarios = result.get("scenarios") or []
        if file_scenarios:
            scenario_batches.setdefault(result["rel_source"], {
                "source_hash": src_hash,
                "scenarios": [],
            })
            # Reshape scenarios for the API: stable-key + human fields.
            for s in file_scenarios:
                scenario_batches[result["rel_source"]]["scenarios"].append({
                    "export_name": s.get("export_name", ""),
                    "scenario_key": s.get("scenario_key", ""),
                    "category": s.get("category", "happy"),
                    "condition": s.get("condition", ""),
                    "expected": s.get("expected", ""),
                })

    # Persist analysis cache if any new entries were written
    if _cache_dirty:
        _save_analysis_cache(repo, _analysis_cache)

    sync_result: dict = {"skipped": True}
    if sync and metadata_tests and not dry_run:
        try:
            async with MaerisClient() as client:
                # Register scenarios FIRST so the backend can match
                # scenario_key -> scenario_id, then swap that id onto each
                # test before register-tests runs. Kept sequential per
                # file (small N; lets a single file's failure not block
                # the rest).
                key_to_id: dict[str, str] = {}
                for src_rel, batch in scenario_batches.items():
                    try:
                        resp = await client.unit_tests_register_scenarios(
                            file_path=src_rel,
                            source_hash=batch["source_hash"],
                            scenarios=batch["scenarios"],
                        )
                        for row in (resp or {}).get("scenarios", []):
                            if row.get("scenario_key"):
                                key_to_id[row["scenario_key"]] = row["scenario_id"]
                    except Exception as exc:
                        logger.warning(
                            "unit_tests.register_scenarios_failed",
                            file=src_rel, error=str(exc)[:200],
                        )
                # Swap scenario_key → scenario_id on each test. Tests whose
                # scenario upsert failed just stay unlinked (scenario_id
                # NULL); they appear in the UI's "Uncategorized" bucket.
                for t in metadata_tests:
                    key = t.pop("scenario_key", None)
                    if key and key in key_to_id:
                        t["scenario_id"] = key_to_id[key]
                sync_result = await client.unit_tests_register(metadata_tests)
        except Exception as exc:
            sync_result = {"ok": False, "error": str(exc)}

    payload = {
        "status": "ok",
        "framework": framework,
        "language": language,
        "dry_run": dry_run,
        "files_processed": len(source_files),
        "tests_generated": len(metadata_tests),
        "skipped_files": skipped_summary[:100],
        "generated": generated[:200],
        "candidate_tests": [
            {"file_path": t["file_path"], "test_name": t["test_name"], "framework": t.get("framework")}
            for t in metadata_tests
        ],
        "maeris_sync": sync_result,
        "summary": f"{len(metadata_tests)} tests generated across {len(generated)} files."
    }
    return [TextContent(type="text", text=json.dumps(payload, indent=2))]


async def handle_generate_unit_tests_focused(arguments: dict) -> list[TextContent]:
    """Generate tests for a single function/export and append them to the existing
    test file without touching existing tests.

    Extra args vs handle_generate_unit_tests:
      focus_function  — the export / function name to target
      focus_start     — first line of the function (1-based, inclusive); used to slice source sent to Claude
      focus_end       — last line of the function (1-based, inclusive)
    """
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    target = arguments.get("target") or "."
    focus_function = (arguments.get("focus_function") or "").strip()
    sync = arguments.get("sync_to_maeris", True)
    progress_sink = arguments.get("_progress_sink")

    _start = arguments.get("focus_start")
    _end = arguments.get("focus_end")
    focus_range: tuple[int, int] | None = (int(_start), int(_end)) if _start and _end else None

    framework_info = detect_framework(repo)
    framework = framework_info.get("framework")
    if not framework:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "no supported framework detected in package.json",
        }, indent=2))]
    language = framework_info.get("language", "javascript")

    source_files = [p for p in _iter_source_files(repo, target) if not _is_test_file(p)]
    if not source_files:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"no source files found at: {target}",
        }, indent=2))]

    src = source_files[0]
    rel = src.relative_to(repo).as_posix()

    if progress_sink:
        try:
            label = f"function '{focus_function}'" if focus_function else rel
            progress_sink(f"Generating focused test for {label} in {rel}…")
        except Exception:
            pass

    # If a function name is specified, temporarily filter the source symbols
    # so the generator only produces tests for that one export.
    original_scan = _scan_source_symbols

    # Pre-scan to determine closure status BEFORE monkey-patching and dispatching.
    # We can't read this from inside the lambda because _focused_scan only runs
    # inside _generate_behavioral_tests_for_source — after is_closure_target
    # would already have been evaluated at the call site.
    if focus_function:
        _pre_scan = original_scan(src)
        _is_closure_flag = not any(
            e[0] == focus_function for e in _pre_scan.get("exports", [])
        )
    else:
        _is_closure_flag = False

    if focus_function:
        def _focused_scan(path: Path) -> dict:
            result = original_scan(path)
            # First: direct export match (exported function)
            filtered = [e for e in result["exports"] if e[0] == focus_function]
            if filtered:
                return {**result, "exports": filtered}
            # Second: focus_function is an inner (non-exported) closure.
            # Keep only the parent component/function export so generation
            # doesn't abort — the closure-specific prompt handles the strategy.
            component_exports = [
                e for e in result["exports"] if e[2] in ("component", "function")
            ]
            if component_exports:
                return {**result, "exports": component_exports[:1]}
            # Last resort: one export of any kind so generation doesn't abort.
            if result["exports"]:
                return {**result, "exports": result["exports"][:1]}
            return result
        import maeris_mcp.tools.unit_tests as _self_mod
        _self_mod._scan_source_symbols = _focused_scan

    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: _generate_tests_dispatched(
                src, repo, framework, language,
                prefer_behavioral=True,
                focus_range=focus_range,
                focus_function=focus_function,
                is_closure_target=_is_closure_flag,
            ),
        )
    finally:
        if focus_function:
            _self_mod._scan_source_symbols = original_scan

    if result.get("skipped"):
        return [TextContent(type="text", text=json.dumps({
            "status": "skipped", "reason": result.get("reason"),
        }, indent=2))]

    test_file_path = Path(result["test_file_abs"])
    if test_file_path.exists():
        writeout = _append_tests_to_file(test_file_path, result["content"])
    else:
        writeout = _write_test_file_if_new(test_file_path, result["content"], overwrite=False)

    if progress_sink:
        try:
            mode = writeout.get("mode", "written" if writeout.get("written") else "skipped")
            progress_sink(f"  {mode}: {result['rel_test']}")
        except Exception:
            pass

    _write_sidecar(test_file_path, result["cases"])

    metadata_tests = [{**c, "source_hash": _hash_file(src)} for c in result["cases"]]
    sync_result: dict = {"skipped": True}
    if sync and metadata_tests and writeout.get("written"):
        try:
            async with MaerisClient() as client:
                sync_result = await client.unit_tests_register(metadata_tests)
        except Exception as exc:
            sync_result = {"ok": False, "error": str(exc)}

    return [TextContent(type="text", text=json.dumps({
        "status": "ok",
        "framework": framework,
        "target": rel,
        "focus_function": focus_function,
        "written": writeout.get("written"),
        "write_mode": writeout.get("mode", "new"),
        "write_reason": writeout.get("reason"),
        "tests_generated": len(metadata_tests),
        "maeris_sync": sync_result,
        "summary": f"{len(metadata_tests)} test(s) added for '{focus_function or rel}'.",
    }, indent=2))]


def run_unit_tests_tool() -> Tool:
    return Tool(
        name="run_unit_tests",
        description=(
            "Run unit tests locally via the project's detected framework and "
            "stream metadata-only results (name, status, duration, short error "
            "message) to Maeris. No stack traces, no stdout, no source code "
            "leaves the machine.\n\n"
            "Scope can be a single test name, a file, a folder, or the whole "
            "suite. Use when the user says 'run the tests', 'run unit tests "
            "for X', or triggers a run from the Maeris UI.\n\n"
            "Set coverage_only=true to refresh the coverage percentage without "
            "recording individual test results. In that mode only the coverage "
            "number is pushed to Maeris; any test failures are surfaced as a "
            "warning and the coverage is computed from passing tests only."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "scope_type": {"type": "string", "enum": ["test", "file", "folder", "suite"],
                               "default": "suite"},
                "scope_ref": {"type": "string",
                              "description": "Target of the scope — a test name, file path, or folder path."},
                "timeout_s": {"type": "integer", "default": 600},
                "coverage_only": {
                    "type": "boolean",
                    "default": False,
                    "description": (
                        "When true, runs tests solely to refresh the coverage percentage. "
                        "Individual test results are NOT saved to Maeris. "
                        "If any tests fail a warning is returned and coverage is "
                        "reported based on the tests that passed."
                    ),
                },
                "save_results": {
                    "type": "boolean",
                    "default": True,
                    "description": (
                        "Whether to persist individual test results to Maeris after the run. "
                        "When false, results are streamed to the UI in real time but not written "
                        "to the database. The run summary (totals, coverage) is always saved. "
                        "Defaults to true; controlled by the app's 'Save unit test results' setting."
                    ),
                },
            },
        },
    )


async def handle_run_unit_tests(arguments: dict) -> list[TextContent]:
    import time as _time
    _t0 = _time.monotonic()

    def _elapsed() -> str:
        return f"{(_time.monotonic() - _t0) * 1000:.0f}ms"

    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    scope_type = arguments.get("scope_type", "suite")
    scope_ref = arguments.get("scope_ref")
    timeout_s = int(arguments.get("timeout_s") or 600)
    coverage_only = bool(arguments.get("coverage_only", False))

    click.secho(f"  [timing] run start  scope_type={scope_type}", fg="yellow")

    _t = _time.monotonic()
    framework_info = detect_framework(repo)
    framework = framework_info.get("framework")
    click.secho(f"  [timing] detect_framework: {(_time.monotonic() - _t) * 1000:.0f}ms  framework={framework}", fg="yellow")
    if not framework:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "no framework detected", "detected": framework_info,
        }, indent=2))]

    # Open a single persistent client for the entire run lifecycle so all
    # API calls (start_run, cancel polls, stream_results, complete_run) share
    # one TCP connection instead of opening a new one per call. This prevents
    # the TimeWait storm that was causing request_retry_transport_error warnings.
    _t = _time.monotonic()
    async with MaerisClient() as client:
        click.secho(f"  [timing] client open: {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")

        # Open a run record on Maeris first so the UI can reflect "running" state (AC-27).
        run_record: dict | None = None
        _t = _time.monotonic()
        try:
            run_record = await client.unit_tests_start_run(scope_type, scope_ref)
            click.secho(f"  [timing] start_run: {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
        except Exception as exc:
            click.secho(f"  [timing] start_run FAILED ({exc}): {(_time.monotonic() - _t) * 1000:.0f}ms", fg="red")

        # Determine whether individual results should be persisted.
        # Tool arg (direct call) takes priority; otherwise use the app setting
        # that start_run embeds in its response (set in Advanced Settings UI).
        if "save_results" in arguments:
            save_results = bool(arguments["save_results"])
        else:
            save_results = bool((run_record or {}).get("save_results", True))

        # AC-28: build a cancel check that polls the backend for this run's status.
        # Avoids blocking forever when the user cancels from the web UI.
        _run_id_for_cancel = (run_record or {}).get("unit_test_run_id")
        async def _cancel_check():
            if not _run_id_for_cancel:
                return False
            try:
                status = await client.get_unit_test_run_status(_run_id_for_cancel)
                return status == "cancelled"
            except Exception:
                return False

        _t = _time.monotonic()
        click.secho(f"  [timing] executor start", fg="yellow")
        exec_result = await _execute_runner(repo, framework, scope_type, scope_ref, timeout_s,
                                            cancel_check=_cancel_check)
        click.secho(f"  [timing] executor total: {(_time.monotonic() - _t) * 1000:.0f}ms  ok={exec_result.get('ok')}", fg="yellow")
        if not exec_result.get("ok"):
            run_id = (run_record or {}).get("unit_test_run_id")
            if exec_result.get("cancelled"):
                if run_id:
                    try:
                        await client.unit_tests_complete_run(run_id, {"status": "cancelled"})
                    except Exception as exc:
                        logger.warning("unit_tests.complete_run(cancelled) failed", error=str(exc))
                return [TextContent(type="text", text=json.dumps({
                    "status": "cancelled", "message": "run cancelled by user",
                }, indent=2))]
            if run_id:
                try:
                    await client.unit_tests_complete_run(run_id, {
                        "status": "failed",
                        "duration_ms": 0,
                    })
                except Exception as exc:
                    logger.warning("unit_tests.complete_run(failed) failed", error=str(exc))
            return [TextContent(type="text", text=json.dumps({
                "status": "error", "message": exec_result.get("error"),
            }, indent=2))]

        parsed = _parse_runner_output(framework, exec_result.get("stdout", ""))
        # Normalize absolute file paths to relative-to-repo so the Maeris tree
        # doesn't create bogus parent folders for the user's home directory.
        for r in parsed:
            fp = r.get("file_path") or ""
            try:
                rel = Path(fp).resolve().relative_to(repo).as_posix()
                r["file_path"] = rel
            except Exception:
                # Not under the repo — leave as-is; the backend will still validate.
                pass
        run_id = (run_record or {}).get("unit_test_run_id")

        passed = sum(1 for r in parsed if r["status"] == "passed")
        failed = sum(1 for r in parsed if r["status"] == "failed")
        skipped = sum(1 for r in parsed if r["status"] == "skipped")
        total_duration = sum(r["duration_ms"] for r in parsed)

        # Fire optimistic preview + preliminary "completed" so the UI exits the
        # running state immediately — before any DB round-trips. Non-fatal.
        if run_id and parsed and not coverage_only:
            try:
                preview = [
                    {"file_path": r["file_path"], "test_name": r["test_name"], "status": r["status"]}
                    for r in parsed
                ]
                run_summary = {
                    **(run_record or {}),
                    "status": "completed" if failed == 0 else "failed",
                    "passed": passed,
                    "failed": failed,
                    "skipped": skipped,
                    "total_tests": len(parsed),
                    "duration_ms": total_duration,
                }
                _t = _time.monotonic()
                await client.unit_tests_preview_results(run_id, preview, run_summary)
                click.secho(f"  [timing] preview_results ({len(preview)} tests): {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
            except Exception:
                pass

        # Pack results with minimal metadata. `unit_test_id` is resolved server-side
        # when we add a server-side lookup endpoint; for now the server validator
        # accepts these (backend: TODO lookup by file_path+test_name). We send
        # what we have; the backend can match.
        stream_payload = [
            {
                "file_path": r["file_path"],
                "test_name": r["test_name"],
                "status": r["status"],
                "duration_ms": r["duration_ms"],
                "error_message": r.get("error_message"),
            }
            for r in parsed
        ]

        # AC-30: parse Jest's coverage-summary.json (written because we pass
        # --coverage --coverageReporters=json-summary above) and attach the
        # overall % to the complete-run payload. The backend computes the
        # delta vs the previous run — it already has full run history.
        coverage_pct = _read_jest_coverage_pct(repo)
        complete_payload = {
            "status": "completed",
            "duration_ms": total_duration,
        }
        if coverage_pct is not None:
            complete_payload["coverage_pct"] = coverage_pct

        # Push results + complete the run.
        # In coverage_only mode skip streaming individual results — coverage
        # refreshes must not pollute the result history in the database.
        failed_tests_warning: str | None = None
        if coverage_only and failed > 0:
            failed_tests_warning = (
                f"{failed} test{'s' if failed > 1 else ''} failed during coverage calculation. "
                f"Coverage is being updated based on the {passed} passing "
                f"test{'s' if passed != 1 else ''} only."
            )
            logger.info("unit_tests.coverage_only.failures", failed=failed, passed=passed)

        try:
            if not coverage_only and run_id and stream_payload:
                # Resolve test_ids by re-registering the metadata first so the
                # server has unit_test_ids to attach results to.
                # Load scenario_key mappings from per-file sidecars so the
                # re-register call preserves the test → scenario linkage that
                # was established at generation time.
                sidecar_cache: dict[str, dict[str, str]] = {}
                def _scenario_key_for(file_path: str, test_name: str) -> str | None:
                    if file_path not in sidecar_cache:
                        sidecar_cache[file_path] = _read_sidecar(repo / file_path)
                    return sidecar_cache[file_path].get(test_name)

                register_payload = []
                for r in stream_payload:
                    entry: dict = {
                        "file_path": r["file_path"],
                        "test_name": r["test_name"],
                        "framework": framework,
                    }
                    sk = _scenario_key_for(r["file_path"], r["test_name"])
                    if sk:
                        entry["scenario_key"] = sk
                    register_payload.append(entry)
                _t = _time.monotonic()
                reg = await client.unit_tests_register(register_payload)
                click.secho(f"  [timing] register ({len(register_payload)} tests): {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
                # The server returned tests with unit_test_id; map back.
                by_key = {(t["file_path"], t["test_name"]): t["unit_test_id"]
                          for t in reg.get("tests") or []}
                to_stream = []
                for r in stream_payload:
                    test_id = by_key.get((r["file_path"], r["test_name"]))
                    if not test_id:
                        continue
                    to_stream.append({
                        "unit_test_id": test_id,
                        "status": r["status"],
                        "duration_ms": r["duration_ms"],
                        "error_message": r["error_message"],
                    })
                if to_stream:
                    if save_results:
                        _t = _time.monotonic()
                        await client.unit_tests_stream_results(run_id, to_stream)
                        click.secho(f"  [timing] stream_results ({len(to_stream)} results): {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
                    else:
                        click.secho(f"  [save_results=false] skipping stream_results ({len(to_stream)} results)", fg="yellow")
            if run_id:
                _t = _time.monotonic()
                await client.unit_tests_complete_run(run_id, complete_payload)
                click.secho(f"  [timing] complete_run: {(_time.monotonic() - _t) * 1000:.0f}ms", fg="yellow")
        except Exception as exc:
            logger.warning("unit_tests.stream/complete failed", error=str(exc))

    click.secho(f"  [timing] run TOTAL: {(_time.monotonic() - _t0) * 1000:.0f}ms", fg="yellow")
    response: dict = {
        "status": "ok",
        "framework": framework,
        "run_id": run_id,
        "coverage_only": coverage_only,
        "totals": {"passed": passed, "failed": failed, "skipped": skipped, "duration_ms": total_duration},
        "exit_code": exec_result.get("exit_code"),
        "runner_stderr_hint": exec_result.get("stderr_first_line"),
    }
    if coverage_only:
        response["results_saved"] = False
        response["coverage_pct"] = complete_payload.get("coverage_pct")
    if failed_tests_warning:
        response["warning"] = failed_tests_warning
    return [TextContent(type="text", text=json.dumps(response, indent=2))]


def analyze_unit_test_critical_path_tool() -> Tool:
    return Tool(
        name="analyze_unit_test_critical_path",
        description=(
            "Analyze the codebase to suggest the critical path — the unit "
            "tests whose source files are most connected and most at risk if "
            "untested. v1.0 uses static analysis only (import graph + "
            "dependency depth). Pushes the suggestion to Maeris so the UI "
            "can flag those tests with a critical-path badge."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "apply": {"type": "boolean", "default": True,
                          "description": "If true, push the suggestion to Maeris immediately."},
            },
        },
    )


async def handle_analyze_unit_test_critical_path(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    apply_it = arguments.get("apply", True)

    # Fetch registered tests from Maeris so we can match unit_test_ids.
    tests: list[dict] = []
    try:
        async with MaerisClient() as client:
            url = f"{client.base_url}/unit-tests/tests"
            resp = await client._make_request("GET", url, headers=client._get_headers())
            payload = client._parse_json(resp)
            tests = payload if isinstance(payload, list) else payload.get("tests", [])
    except Exception as exc:
        logger.warning("could not fetch tests from maeris", error=str(exc))

    critical_ids, critical_details = _compute_critical_path(repo, tests)

    result: dict = {
        "status": "ok",
        "total_tests": len(tests),
        "critical_count": len(critical_ids),
        "critical_unit_test_ids": critical_ids[:200],
        "critical_details": critical_details[:200],
    }
    if apply_it and critical_ids:
        try:
            async with MaerisClient() as client:
                push = await client.unit_tests_set_critical_path(critical_ids, source="suggested")
                result["maeris_sync"] = push
        except Exception as exc:
            result["maeris_sync"] = {"ok": False, "error": str(exc)}
    return [TextContent(type="text", text=json.dumps(result, indent=2))]


def sync_unit_tests_to_maeris_tool() -> Tool:
    return Tool(
        name="sync_unit_tests_to_maeris",
        description=(
            "Rescan local test files and push their METADATA (name, path, "
            "framework, source hash) to Maeris. Used to reconcile state "
            "after manual edits to the local filesystem. No code is sent."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
            },
        },
    )


async def handle_sync_unit_tests_to_maeris(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    framework_info = detect_framework(repo)
    framework = framework_info.get("framework") or "jest"

    test_files = [p for p in _iter_source_files(repo) if _is_test_file(p)]
    tests_meta: list[dict] = []
    for tf in test_files:
        src_hash = _hash_file(tf)
        rel = tf.relative_to(repo).as_posix()
        try:
            text = tf.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        # Split the file into per-test blocks by finding each it()/test() call
        # and slicing until the next one — counting assertions inside each block
        # so the Graphical view can scale to the test's real structure (AC-40).
        spans = []
        for m in re.finditer(r"\b(?:it|test)\(\s*['\"]([^'\"]+)['\"]", text):
            spans.append((m.start(), m.group(1)))
        for i, (start, title) in enumerate(spans):
            end = spans[i + 1][0] if i + 1 < len(spans) else len(text)
            block = text[start:end]
            assertion_count = 0
            for pat in _ASSERTION_PATTERNS:
                assertion_count += len(pat.findall(block))
            tests_meta.append({
                "file_path": rel,
                "test_name": title,
                "framework": framework,
                "source_hash": src_hash,
                "assertion_count": max(1, assertion_count),
            })

    if not tests_meta:
        return [TextContent(type="text", text=json.dumps({
            "status": "ok", "count": 0, "message": "no tests found"
        }, indent=2))]

    async with MaerisClient() as client:
        result = await client.unit_tests_register(tests_meta)
    return [TextContent(type="text", text=json.dumps(
        {"status": "ok", "registered": len(tests_meta), "maeris": result}, indent=2))]


# -----------------------------------------------------------------------------
# MCP connection lifecycle — ensures the UI pill reflects reality (AC-01..04).
# -----------------------------------------------------------------------------
_HEARTBEAT_INTERVAL_S = 20
_client_id_cache: dict = {"id": None}


def _get_client_id() -> str:
    if _client_id_cache["id"]:
        return _client_id_cache["id"]
    cid = f"mcp-{socket.gethostname()}-{uuid.uuid4().hex[:8]}"
    _client_id_cache["id"] = cid
    return cid


class _BackendFeatureMissing(Exception):
    """Raised internally to signal that the MCP unit-tests endpoints are not deployed
    on the configured backend. Stops the heartbeat loop for the life of the process."""


async def start_unit_tests_heartbeat() -> asyncio.Task | None:
    """Background heartbeat loop. Call once at server startup; cancel on shutdown."""
    cid = _get_client_id()

    async def _loop():
        # Outer reconnect loop: if the connection drops (heartbeat fails twice),
        # we close the client and open a fresh one rather than silently spinning
        # with a broken session (which caused random "disconnected" UI state even
        # while the listener was running).
        while True:
            try:
                async with MaerisClient() as client:
                    try:
                        await client.unit_tests_connect(
                            client_id=cid,
                            mcp_version=os.getenv("MAERIS_MCP_VERSION") or "dev",
                            hostname=socket.gethostname(),
                        )
                    except APIRequestError as exc:
                        if exc.status_code == 404:
                            # Backend predates the /mcp/unit-tests/* routes; no point
                            # retrying — skip the heartbeat entirely for this process.
                            raise _BackendFeatureMissing from exc
                        logger.warning("unit_tests.connect failed; will retry", error=str(exc))
                    except Exception as exc:
                        logger.warning("unit_tests.connect failed; will retry", error=str(exc))

                    consecutive_failures = 0
                    while True:
                        await asyncio.sleep(_HEARTBEAT_INTERVAL_S)
                        try:
                            await client.unit_tests_heartbeat(cid)
                            consecutive_failures = 0
                        except APIRequestError as exc:
                            if exc.status_code == 404:
                                raise _BackendFeatureMissing from exc
                            consecutive_failures += 1
                            logger.debug("unit_tests.heartbeat failed", error=str(exc), consecutive_failures=consecutive_failures)
                            if consecutive_failures >= 2:
                                raise
                        except Exception as exc:
                            consecutive_failures += 1
                            logger.debug("unit_tests.heartbeat failed", error=str(exc), consecutive_failures=consecutive_failures)
                            if consecutive_failures >= 2:
                                # Force reconnect by escaping the client context
                                raise
            except asyncio.CancelledError:
                raise
            except _BackendFeatureMissing:
                logger.info(
                    "unit_tests heartbeat disabled: /mcp/unit-tests endpoints not available on this backend"
                )
                return
            except Exception as exc:
                logger.info("unit_tests heartbeat: reconnecting after connection loss", error=str(exc))
                await asyncio.sleep(5)

    return asyncio.create_task(_loop(), name="unit_tests_heartbeat")


async def stop_unit_tests_heartbeat(task: asyncio.Task | None) -> None:
    if not task:
        return
    task.cancel()
    try:
        await task
    except (asyncio.CancelledError, Exception):
        pass
    cid = _client_id_cache.get("id")
    if cid:
        try:
            async with MaerisClient() as client:
                await client.unit_tests_disconnect(cid)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Mutation testing — prove the tests actually catch bugs.
#
# Wraps Stryker (https://stryker-mutator.io/) for JS/TS projects. Stryker
# mutates the source (flips operators, drops statements, etc.) and re-runs
# the test suite for each mutant. A surviving mutant means some code path
# isn't actually verified by any test — i.e. a false positive in the green
# run. The output of this tool is a "mutation score" (% of mutants killed)
# plus per-file breakdown. No source or mutant code leaves the machine.
# -----------------------------------------------------------------------------
def run_mutation_tests_tool() -> Tool:
    return Tool(
        name="run_mutation_tests",
        description=(
            "Run mutation testing on the project's unit tests via Stryker. "
            "Mutation testing deliberately breaks the source and checks "
            "whether tests catch each break — the industry standard for "
            "proving tests are real (not just green). Returns a mutation "
            "score and per-file breakdown. JavaScript/TypeScript only."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "target": {"type": "string",
                           "description": "Folder to mutate. Defaults to the whole project."},
                "timeout_s": {"type": "integer", "default": 1800,
                              "description": "Stryker is slow — default 30 minutes."},
            },
        },
    )


def _find_stryker(repo: Path) -> dict:
    """Detect whether Stryker is installed in the user's project.

    Returns a dict with `installed`, `version`, `jest_runner_installed`,
    and `install_hint` (shell command the user can copy-paste).
    """
    pkg = repo / "package.json"
    if not pkg.is_file():
        return {"installed": False, "install_hint": "no package.json found"}
    try:
        data = json.loads(pkg.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return {"installed": False, "install_hint": "package.json unreadable"}
    deps = {**(data.get("dependencies") or {}), **(data.get("devDependencies") or {})}
    stryker = deps.get("@stryker-mutator/core")
    jest_runner = deps.get("@stryker-mutator/jest-runner")
    vitest_runner = deps.get("@stryker-mutator/vitest-runner")
    return {
        "installed": bool(stryker),
        "version": stryker,
        "jest_runner_installed": bool(jest_runner),
        "vitest_runner_installed": bool(vitest_runner),
        "install_hint": (
            "npm install --save-dev @stryker-mutator/core "
            "@stryker-mutator/jest-runner"
        ),
    }


def _parse_stryker_report(repo: Path) -> dict | None:
    """Parse Stryker's JSON report. Returns None if the file isn't present."""
    candidates = [
        repo / "reports" / "mutation" / "mutation.json",
        repo / "reports" / "mutation" / "mutation-report.json",
        repo / ".stryker-tmp" / "reports" / "mutation.json",
    ]
    for path in candidates:
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
    return None


def _summarize_mutation_report(report: dict) -> dict:
    """Boil the Stryker report down to metadata only (no source, no diffs).

    Stryker's report is large and contains mutant source snippets; we
    deliberately drop those before anything touches the network.
    """
    # Stryker emits PascalCase status values ('Killed', 'Survived',
    # 'NoCoverage', 'Timeout', 'CompileError', 'RuntimeError'). We store
    # camelCase internally for API consistency, so normalise on ingest.
    _STATUS_MAP = {
        "killed": "killed",
        "survived": "survived",
        "nocoverage": "noCoverage",
        "timeout": "timeout",
        "compileerror": "compileError",
        "runtimeerror": "runtimeError",
    }

    # Human-friendly descriptions for Stryker mutator names — so the UI can
    # show "Changed `&&` to `||`" instead of "LogicalOperator". Keep the map
    # conservative; unknown mutators fall back to the raw name.
    _MUTATOR_LABELS = {
        "ArithmeticOperator": "Arithmetic operator changed (e.g. + → -, * → /)",
        "ArrayDeclaration": "Array literal replaced with empty array",
        "ArrowFunction": "Arrow function body replaced",
        "AssignmentOperator": "Assignment operator changed (e.g. += → -=)",
        "BlockStatement": "Block emptied (statements removed)",
        "BooleanLiteral": "Boolean flipped (true ↔ false)",
        "ConditionalExpression": "Conditional forced true / false",
        "EqualityOperator": "Equality operator flipped (e.g. === → !==)",
        "LogicalOperator": "Logical operator changed (e.g. && → ||)",
        "MethodExpression": "Method call removed or replaced",
        "ObjectLiteral": "Object literal replaced with {}",
        "OptionalChaining": "Optional chaining removed",
        "Regex": "Regex replaced",
        "StringLiteral": "String literal replaced",
        "UnaryOperator": "Unary operator changed (e.g. +x → -x)",
        "UpdateOperator": "Update operator changed (e.g. ++ → --)",
    }

    def _describe_mutant(m: dict) -> dict:
        """Shape a Stryker mutant record for the UI.

        Deliberately drops `replacement` source text to avoid shipping
        mutated code snippets off-machine; keeps location + mutator name
        + a human label so the UI can direct the user to the exact line.
        """
        loc = m.get("location") or {}
        start = loc.get("start") or {}
        mutator = m.get("mutatorName") or "Unknown"
        return {
            "mutator": mutator,
            "description": _MUTATOR_LABELS.get(mutator, mutator),
            "line": start.get("line"),
            "column": start.get("column"),
        }

    files = report.get("files") or {}
    total = killed = survived = no_coverage = timeout = compile_error = runtime_error = 0
    per_file: list[dict] = []
    for file_path, file_info in files.items():
        mutants = file_info.get("mutants") or []
        counts = {"killed": 0, "survived": 0, "noCoverage": 0, "timeout": 0,
                  "compileError": 0, "runtimeError": 0}
        survivors: list[dict] = []
        for m in mutants:
            raw_status = (m.get("status") or "").strip().lower().replace("_", "")
            key = _STATUS_MAP.get(raw_status)
            if key:
                counts[key] += 1
            # Keep survivor and no-coverage mutants so the UI can show the
            # user *what* tests are missing. Cap per-file to keep the wire
            # payload manageable (10 worst per file is plenty to act on).
            if key in ("survived", "noCoverage") and len(survivors) < 10:
                survivors.append({**_describe_mutant(m), "status": key})
        file_total = sum(counts.values())
        # Mutation score per file — killed / (killed + survived + no-coverage + timeout).
        # We ignore compile/runtime errors in the denominator (they're
        # invalid mutants, not survived ones).
        denom = counts["killed"] + counts["survived"] + counts["noCoverage"] + counts["timeout"]
        score = (counts["killed"] / denom * 100) if denom else 0.0
        per_file.append({
            "file_path": file_path,
            "total": file_total,
            "killed": counts["killed"],
            "survived": counts["survived"],
            "no_coverage": counts["noCoverage"],
            "timeout": counts["timeout"],
            "mutation_score": round(score, 1),
            "survivors": survivors,
        })
        killed += counts["killed"]
        survived += counts["survived"]
        no_coverage += counts["noCoverage"]
        timeout += counts["timeout"]
        compile_error += counts["compileError"]
        runtime_error += counts["runtimeError"]
        total += file_total

    denom_total = killed + survived + no_coverage + timeout
    overall_score = (killed / denom_total * 100) if denom_total else 0.0

    # Sort worst-first so the UI highlights files that need attention.
    per_file.sort(key=lambda f: (f["survived"], -f["mutation_score"]), reverse=True)

    return {
        "overall_score": round(overall_score, 1),
        "total_mutants": total,
        "killed": killed,
        "survived": survived,
        "no_coverage": no_coverage,
        "timeout": timeout,
        "compile_error": compile_error,
        "runtime_error": runtime_error,
        "files": per_file[:50],  # cap the wire payload
    }


def _diagnose_stryker_failure(log: str, info: dict, exit_code: int) -> dict:
    """Turn a Stryker failure log into a plain-English, actionable message.

    The UI renders the returned `message` verbatim, so it needs to tell the
    user *exactly* what went wrong and what to do about it — not "Exit code
    1, check stryker.conf". We also return `next_steps` (a list of bullet
    strings) and, where relevant, an `install_command` so the UI's install-
    hint UX kicks in.
    """
    low = log.lower()

    # Tests failed in the initial (pre-mutation) run. Stryker refuses to
    # proceed because it can't distinguish a real mutation kill from a
    # pre-existing failure.
    if "failed tests in the initial test run" in low:
        return {
            "reason": "initial_tests_failing",
            "message": (
                "Your test suite has failing tests. Mutation testing needs "
                "a clean green run to start — Stryker can't tell a real bug "
                "catch from a pre-existing failure. Fix the failing tests "
                "first, then run mutation testing again."
            ),
            "next_steps": [
                "Run `npm test` (or your test command) to see which tests fail.",
                "Use 'Analyze test failure' on any failing test for a plain-"
                "English diagnosis and suggested fix.",
                "Once `npm test` is green, come back and click 'Run mutation test'.",
            ],
        }

    # The default `command` runner tried `npm test` but there's no script.
    # Happens when Stryker is installed without a runner plugin.
    if 'missing script: "test"' in low or "missing script: test" in low:
        have_jest = info.get("jest_runner_installed")
        have_vitest = info.get("vitest_runner_installed")
        if not (have_jest or have_vitest):
            return {
                "reason": "no_test_runner_plugin",
                "message": (
                    "Stryker is installed but no test-runner plugin is. "
                    "Install the plugin for your framework (jest or vitest) "
                    "so Stryker knows how to run your tests."
                ),
                "next_steps": [
                    "Click 'Install now' below, or run the command yourself.",
                    "Then click 'Run mutation test' again.",
                ],
                "install_command": (
                    "npm install --save-dev @stryker-mutator/jest-runner"
                ),
                "install_packages": ["@stryker-mutator/jest-runner"],
            }
        # Plugin is installed — this shouldn't happen after our fix, but
        # still give a useful hint.
        return {
            "reason": "no_test_script",
            "message": (
                "Your `package.json` has no `\"test\"` script, and Stryker "
                "fell back to running `npm test`. Either add a `\"test\"` "
                "script or make sure Stryker is using the jest/vitest plugin."
            ),
            "next_steps": [
                "Add `\"test\": \"jest\"` (or `vitest`) to your package.json scripts.",
                "Run mutation testing again.",
            ],
        }

    # No source files matched. Either the project layout is non-standard or
    # the target picker pointed at the wrong folder.
    if "no files found for mutation" in low or "instrumented 0 source" in low:
        return {
            "reason": "no_files_matched",
            "message": (
                "Stryker didn't find any source files to mutate. This "
                "usually means the project's source lives somewhere other "
                "than the defaults (`src/`, `lib/`, `app/`, `components/`)."
            ),
            "next_steps": [
                "Pick a specific folder in the target selector and run again.",
                "Or add a `mutate` field to a `stryker.conf.json` at the project root.",
            ],
        }

    # Hook nesting — the test file itself is malformed.
    if "hooks cannot be defined inside tests" in low:
        return {
            "reason": "malformed_test_file",
            "message": (
                "A test file has Jest hooks (beforeAll / afterEach / etc.) "
                "defined inside a test block, which Jest rejects. This "
                "usually happens when a test `require()`s @testing-library "
                "inside an `it()` — move that import to the top of the file."
            ),
            "next_steps": [
                "Open the failing test file and move all `require(...)` calls "
                "from inside `it(...)` blocks to the top of the file.",
                "Run `npm test` to confirm it now passes.",
                "Then run mutation testing again.",
            ],
        }

    # Fallback — couldn't classify. Surface the last few lines of stderr so
    # the user at least sees the real error instead of a generic message.
    tail = [ln for ln in log.splitlines() if ln.strip()][-8:]
    return {
        "reason": "unknown",
        "message": (
            f"Stryker exited with code {exit_code} and produced no report. "
            f"The last few lines of its output:\n\n" + "\n".join(tail)
        ),
        "next_steps": [
            "Run `npx stryker run` directly in your project root to see the "
            "full error output.",
            "If the failure looks like a missing config, run `npx stryker "
            "init` to generate a `stryker.conf.json`.",
        ],
    }


async def handle_run_mutation_tests(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    target = arguments.get("target")
    timeout_s = int(arguments.get("timeout_s") or 1800)

    info = _find_stryker(repo)
    if not info["installed"]:
        return [TextContent(type="text", text=json.dumps({
            "status": "not_installed",
            "message": (
                "Stryker isn't installed in this project. Click 'Install "
                "now' below, or run the command yourself."
            ),
            "install_command": info["install_hint"],
            "install_packages": [
                "@stryker-mutator/core",
                "@stryker-mutator/jest-runner",
            ],
        }, indent=2))]

    # Build argv. Stryker reads its own `stryker.conf.*` if present; we pass
    # `--mutate` for scope and `--reporters json,clear-text` to force a JSON
    # report we can parse.
    argv = ["npx", "stryker", "run", "--reporters", "json,clear-text"]
    # Without `--testRunner`, Stryker falls back to the `command` runner which
    # invokes `npm test` — projects without a `"test"` script (common in
    # Next.js apps) error out before any mutants run. Pick the runner that
    # matches the installed plugin.
    if not (repo / "stryker.conf.json").is_file() and not list(repo.glob("stryker.conf.*")):
        if info.get("jest_runner_installed"):
            argv += ["--testRunner", "jest"]
        elif info.get("vitest_runner_installed"):
            argv += ["--testRunner", "vitest"]
    # Stryker splits `--mutate` on commas, so brace-expand extensions
    # manually into an explicit CSV of globs.
    exts = ("js", "jsx", "ts", "tsx")
    if target:
        # Explicit target — user asked for a folder; mutate everything in it
        # (still exclude the test files themselves).
        globs = [f"{target}/**/*.{ext}" for ext in exts]
        globs += [f"!{target}/**/*.test.*", f"!{target}/**/*.spec.*"]
        argv += ["--mutate", ",".join(globs)]
    else:
        # Scope to source files that *have a neighboring test file*. Mutating
        # every file in the tree (Stryker's default behaviour) drags the
        # overall score toward 0 because untested code has no mutants killed
        # — measuring coverage, not test quality. Pairing each test with its
        # sibling source lets the score answer "are my existing tests
        # strong?", which is what users actually want when they click
        # "Run mutation test".
        search_roots = [d for d in ("src", "lib", "app", "components", "pages")
                        if (repo / d).is_dir()]
        mutate_paths: list[str] = []
        for root in search_roots:
            for test_file in (repo / root).rglob("*"):
                if not test_file.is_file():
                    continue
                name = test_file.name
                # Match `foo.test.js`, `foo.spec.tsx`, etc.
                for marker in (".test.", ".spec."):
                    if marker in name and name.rsplit(".", 1)[-1] in exts:
                        base, sep, rest = name.partition(marker)
                        for ext in exts:
                            candidate = test_file.with_name(f"{base}.{ext}")
                            if candidate.is_file():
                                mutate_paths.append(
                                    str(candidate.relative_to(repo))
                                )
                                break
                        break
        if mutate_paths:
            argv += ["--mutate", ",".join(mutate_paths)]
        elif search_roots:
            # No paired tests found — fall back to the broad folder glob so
            # something still runs, and at least exclude test files from it.
            globs = [f"{t}/**/*.{ext}" for t in search_roots for ext in exts]
            globs += [f"!{t}/**/*.test.*" for t in search_roots]
            globs += [f"!{t}/**/*.spec.*" for t in search_roots]
            argv += ["--mutate", ",".join(globs)]

    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(repo),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
        except asyncio.TimeoutError:
            try:
                proc.kill()
                await proc.wait()
            except Exception:
                pass
            return [TextContent(type="text", text=json.dumps({
                "status": "timeout",
                "message": f"Stryker exceeded {timeout_s}s. Try a narrower `target`.",
            }, indent=2))]
    except FileNotFoundError:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "npx not found on PATH. Make sure Node.js is installed.",
        }, indent=2))]

    report = _parse_stryker_report(repo)
    if not report:
        stderr_text = (stderr or b"").decode("utf-8", errors="replace")
        stdout_text = (stdout or b"").decode("utf-8", errors="replace")
        combined = stderr_text + "\n" + stdout_text
        diagnosis = _diagnose_stryker_failure(combined, info, proc.returncode)
        first_err = stderr_text.splitlines()
        return [TextContent(type="text", text=json.dumps({
            "status": "no_report",
            "reason": diagnosis["reason"],
            "message": diagnosis["message"],
            "next_steps": diagnosis["next_steps"],
            "install_command": diagnosis.get("install_command"),
            "stderr_first_lines": first_err[:10],
        }, indent=2))]

    summary = _summarize_mutation_report(report)

    # Narrative for non-technical readers.
    score = summary["overall_score"]
    if score >= 85:
        verdict = "strong"
        narrative = f"Mutation score is {score}% — your tests catch most bugs that a mutation would introduce."
    elif score >= 60:
        verdict = "okay"
        narrative = f"Mutation score is {score}% — your tests catch the majority of bugs, but there are notable gaps."
    else:
        verdict = "weak"
        narrative = f"Mutation score is {score}% — many mutations survived, meaning tests miss a lot of real behavior."

    guidance = _build_mutation_guidance(summary, verdict)

    return [TextContent(type="text", text=json.dumps({
        "status": "completed",
        "verdict": verdict,
        "narrative": narrative,
        "summary": summary,
        "guidance": guidance,
    }, indent=2))]


def _build_mutation_guidance(summary: dict, verdict: str) -> dict:
    """Turn the raw score into a 'what do I do next?' plan for the UI.

    Returns a headline + tailored checklist of next steps + the top three
    files to focus on. The UI pastes this straight in above the file list
    so users are never left staring at a number without a direction.
    """
    survived = summary.get("survived", 0)
    no_coverage = summary.get("no_coverage", 0)
    total = summary.get("total_mutants", 0)
    files = summary.get("files") or []

    # Files worth working on first — highest absolute survivor count wins,
    # ties broken by the lowest score. Skip perfect / empty files.
    actionable = [f for f in files if (f.get("survived", 0) + f.get("no_coverage", 0)) > 0]
    actionable.sort(key=lambda f: (-(f.get("survived", 0) + f.get("no_coverage", 0)),
                                    f.get("mutation_score", 100)))
    focus_files = [
        {
            "file_path": f["file_path"],
            "mutation_score": f.get("mutation_score"),
            "gaps": f.get("survived", 0) + f.get("no_coverage", 0),
        }
        for f in actionable[:3]
    ]

    if verdict == "strong":
        headline = (
            f"Nice — {summary.get('killed', 0)}/{total} mutants killed. Your "
            f"tests are strong. Only {survived} gap(s) left to close."
        )
        next_steps = (
            [
                "Review the surviving mutants below and decide whether each "
                "is worth a dedicated test.",
                "Aim for 90%+ on critical modules (billing, auth, pricing).",
            ]
            if survived
            else ["Keep this quality as the code evolves — rerun after major changes."]
        )
    elif verdict == "okay":
        headline = (
            f"{survived} surviving mutant(s) — small bugs your tests would "
            f"miss. Fixing them usually means adding one assertion per gap."
        )
        next_steps = [
            "Open the worst file in the list below. Each survivor is a "
            "specific behaviour that isn't asserted.",
            "For each survivor, add a test case that would fail if that "
            "mutation were real (e.g. a test where the condition is false).",
            "Rerun mutation testing to confirm the survivor is now killed.",
        ]
    else:
        headline = (
            f"{survived} surviving + {no_coverage} never-run mutants. Your "
            f"tests miss a lot of real behaviour — time to add coverage."
        )
        next_steps = [
            "Start with the highest-impact file at the top of the list.",
            "Use 'Generate tests' on that file to get an initial test "
            "scaffold from Maeris, then expand the assertions.",
            "Focus on branches and boundary conditions — those are where "
            "mutants hide.",
            "Rerun mutation testing after each batch of test additions.",
        ]

    return {
        "headline": headline,
        "next_steps": next_steps,
        "focus_files": focus_files,
    }


# -----------------------------------------------------------------------------
# Deep failure analysis (CTO request) — "why is this test failing, in depth".
#
# Given a failing unit test, read the source + test locally, feed them to
# Claude with the error message and scenario context, and emit a
# structured report: diagnosis (plain English, root-cause line, confidence)
# + expected/actual + fix suggestions (source or test) + steps_taken.
# -----------------------------------------------------------------------------
def analyze_test_failure_tool() -> Tool:
    return Tool(
        name="analyze_test_failure",
        description=(
            "Diagnose a failing unit test. Reads the source file, the test "
            "file, and the recorded error locally, then returns a plain-"
            "English root-cause report with concrete fix suggestions. "
            "Source code never leaves the user's machine — the Claude call "
            "is made from this process. JavaScript / TypeScript only."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "file_path": {"type": "string",
                              "description": "Relative path to the TEST file whose failure to analyse (e.g. 'app/calc/math.test.js')."},
                "test_name": {"type": "string",
                              "description": "The exact Jest/Vitest fullName of the failing test."},
                "source_path": {"type": "string",
                                "description": "Optional. Relative path to the source file under test. Derived from file_path if omitted."},
                "last_status": {"type": "string",
                                "description": "Optional. 'failed' / 'passed' — defaults to 'failed'."},
                "last_error": {"type": "string",
                               "description": "The short error message captured from the last run (Jest first line etc.). Truncated to 2000 chars."},
                "scenario": {"type": "object",
                             "description": "Optional. {category, condition, expected} for the scenario this test covers."},
            },
            "required": ["file_path", "test_name"],
        },
    )


def _derive_source_from_test(test_path: Path) -> Path:
    """Map foo.test.js → foo.js (or .ts variants). Falls back to the test
    path itself if the pattern doesn't match."""
    name = test_path.name
    stripped = re.sub(
        r"(?:\.|-)(?:test|spec)\.([cm]?jsx?|tsx?)$",
        r".\1",
        name,
    )
    return test_path.with_name(stripped) if stripped != name else test_path


async def handle_analyze_test_failure(arguments: dict) -> list[TextContent]:
    from maeris_mcp.ai_adapter.failure_analyzer import (
        analyze_test_failure,
        FailureAnalysisUnavailable,
    )

    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    file_path_arg = (arguments.get("file_path") or "").strip()
    test_name = (arguments.get("test_name") or "").strip()
    if not file_path_arg or not test_name:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "file_path and test_name are required.",
        }, indent=2))]

    test_path = (repo / file_path_arg).resolve()
    if not test_path.is_file():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"test file not found on disk: {file_path_arg}",
        }, indent=2))]

    # Resolve the source path: explicit arg wins, otherwise derive.
    source_path_arg = (arguments.get("source_path") or "").strip()
    if source_path_arg:
        source_path = (repo / source_path_arg).resolve()
    else:
        source_path = _derive_source_from_test(test_path)
    if not source_path.is_file():
        # Not fatal — the analyzer handles missing source with a
        # fallback text, but we surface the fact so the UI can flag it.
        source_missing = True
    else:
        source_missing = False

    # Language inference from extension.
    ext = test_path.suffix.lower()
    language = "typescript" if ext in (".ts", ".tsx") else "javascript"

    try:
        result = analyze_test_failure(
            source_path=source_path,
            test_path=test_path,
            test_name=test_name,
            last_status=arguments.get("last_status") or "failed",
            last_error=arguments.get("last_error"),
            language=language,
            scenario=arguments.get("scenario"),
        )
    except FailureAnalysisUnavailable as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "unavailable",
            "reason": exc.reason,
            "hint": (
                "Deep analysis needs Claude CLI on PATH or the Maeris AI proxy. "
                "You can still open the test file for manual inspection."
            ),
        }, indent=2))]
    except Exception as exc:  # pragma: no cover — defensive
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": str(exc)[:500],
        }, indent=2))]

    # Rewrite fix.file to full repo-relative paths. The LLM only sees basenames
    # in the prompt (so it cites them in suggestions), but fix_unit_test resolves
    # paths against repo_root — basenames alone don't exist at repo root for any
    # nested file.
    rel_test = file_path_arg
    rel_source = (
        source_path.relative_to(repo).as_posix()
        if source_path.is_relative_to(repo)
        else source_path.name
    )
    for fix in result.get("fix_suggestions") or []:
        if fix.get("target") == "test":
            fix["file"] = rel_test
        elif fix.get("target") == "source":
            fix["file"] = rel_source

    return [TextContent(type="text", text=json.dumps({
        "status": "completed",
        "source_missing": source_missing,
        "test_file": file_path_arg,
        "source_file": rel_source,
        "analysis": result,
    }, indent=2))]


# -----------------------------------------------------------------------------
# fix_unit_test — apply a Claude-suggested before→after text replacement
# -----------------------------------------------------------------------------
def fix_unit_test_tool() -> Tool:
    return Tool(
        name="fix_unit_test",
        description=(
            "Apply a single fix suggestion from a failure analysis to the "
            "file on disk. Replaces the first occurrence of `before` with "
            "`after` in the target file. JavaScript / TypeScript only."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the file to patch (test or source).",
                },
                "before": {
                    "type": "string",
                    "description": "Exact text to find and replace (first occurrence).",
                },
                "after": {
                    "type": "string",
                    "description": "Replacement text.",
                },
            },
            "required": ["file_path", "before", "after"],
        },
    )


async def handle_fix_unit_test(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    file_path_arg = (arguments.get("file_path") or "").strip()
    before = arguments.get("before") or ""
    after = arguments.get("after") or ""

    if not file_path_arg:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "file_path is required.",
        }, indent=2))]
    if not before:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "before text is required.",
        }, indent=2))]

    try:
        abs_path = (repo / file_path_arg).resolve()
        abs_path.relative_to(repo)  # ensure no path escape
    except Exception:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "file_path escapes the repo root.",
        }, indent=2))]

    if not abs_path.is_file():
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"file not found: {file_path_arg}",
        }, indent=2))]

    try:
        content = abs_path.read_text(encoding="utf-8")
    except Exception as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"could not read file: {exc}",
        }, indent=2))]

    if before not in content:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "The 'before' text was not found in the file. It may have already been applied or the file changed.",
        }, indent=2))]

    patched = content.replace(before, after, 1)
    try:
        abs_path.write_text(patched, encoding="utf-8")
    except Exception as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"could not write file: {exc}",
        }, indent=2))]

    return [TextContent(type="text", text=json.dumps({
        "status": "applied",
        "file_path": file_path_arg,
        "message": f"Fix applied to {file_path_arg}.",
    }, indent=2))]


# -----------------------------------------------------------------------------
# check_unit_test_setup — pre-flight diagnostics for the user's project.
# Catches environment bugs that masquerade as test-code bugs: missing jsdom,
# missing RTL, jest-dom not wired, tsconfig paths out of sync with Jest's
# moduleNameMapper, App Router projects without a next/navigation mock.
# Read-only. Each failing check returns a structured fix_action the UI can
# dispatch individually, or bundle into a "Fix all" one-click flow.
# -----------------------------------------------------------------------------
def _setup_read_package_json(repo: Path) -> dict:
    p = repo / "package.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _setup_all_deps(pkg: dict) -> dict:
    merged: dict = {}
    for key in ("dependencies", "devDependencies", "peerDependencies"):
        d = pkg.get(key)
        if isinstance(d, dict):
            merged.update(d)
    return merged


def _setup_find_jest_config(repo: Path) -> tuple[str | None, str]:
    """Locate the Jest config. Returns (label, text). No config is legal —
    Jest runs on defaults, which is exactly the state that silently breaks
    rendering tests."""
    for name in ("jest.config.ts", "jest.config.mts", "jest.config.cts",
                 "jest.config.js", "jest.config.mjs", "jest.config.cjs",
                 "jest.config.json"):
        p = repo / name
        if p.is_file():
            try:
                return (name, p.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                return (name, "")
    pkg = _setup_read_package_json(repo)
    jest_section = pkg.get("jest")
    if isinstance(jest_section, dict):
        try:
            return ("package.json#jest", json.dumps(jest_section, indent=2))
        except Exception:
            return ("package.json#jest", "")
    return (None, "")


def _setup_parse_jsonc(text: str) -> dict | None:
    """Parse JSON-with-comments (what tsc, VSCode, etc. accept). Returns None
    on any failure so callers can soft-skip a malformed file."""
    try:
        cleaned = re.sub(r"//[^\n]*", "", text)
        cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.S)
        cleaned = re.sub(r",\s*([\]}])", r"\1", cleaned)
        return json.loads(cleaned)
    except Exception:
        return None


def _setup_read_tsconfig_paths(repo: Path) -> dict[str, list[str]]:
    """Return TypeScript path aliases, or {} if none. Follows `extends` one
    level (covers Next.js's tsconfig extending `./tsconfig.base.json` pattern
    and the `@tsconfig/*` preset family). Tolerates JSONC comments and
    trailing commas that tsc accepts but json.loads doesn't.

    Visits a capped chain to prevent pathological cycles: if a user's configs
    extend in a loop we bail at depth 5 and return whatever we collected.
    """
    seen: set[Path] = set()
    for start_name in ("tsconfig.json", "jsconfig.json"):
        start = repo / start_name
        if not start.is_file():
            continue
        current = start
        merged_paths: dict[str, list[str]] = {}
        for _ in range(5):
            if current in seen or not current.is_file():
                break
            seen.add(current)
            try:
                data = _setup_parse_jsonc(current.read_text(encoding="utf-8")) or {}
            except Exception:
                break
            compiler_opts = data.get("compilerOptions") or {}
            paths = compiler_opts.get("paths") or {}
            if isinstance(paths, dict):
                for k, v in paths.items():
                    if k in merged_paths:
                        continue  # child wins over parent
                    if isinstance(v, list):
                        merged_paths[k] = v
                    elif isinstance(v, str):
                        merged_paths[k] = [v]
            extends = data.get("extends")
            if not isinstance(extends, str):
                break
            # "extends" can be a relative path, a bare specifier resolved
            # through node_modules, or a path without extension. Try the
            # common forms; anything we can't resolve is skipped silently.
            candidates = [
                current.parent / extends,
                current.parent / (extends + ".json"),
                repo / "node_modules" / extends / "tsconfig.json",
                repo / "node_modules" / extends,
            ]
            nxt = next((c.resolve() for c in candidates if c.is_file()), None)
            if nxt is None:
                break
            current = nxt
        if merged_paths:
            return merged_paths
    return {}


def _setup_extract_setup_files(cfg_text: str) -> list[str]:
    """Pull the entries of setupFilesAfterEnv / setupFiles out of a Jest
    config. String-based because the config may be .js/.ts; handles the two
    common shapes (array literal and the quoted single-string shortcut).
    Returns an empty list if the keys aren't present."""
    results: list[str] = []
    for key in ("setupFilesAfterEnv", "setupFiles"):
        m = re.search(rf"{key}\s*[:=]\s*\[([\s\S]*?)\]", cfg_text)
        if m:
            for item in re.findall(r"['\"]([^'\"]+)['\"]", m.group(1)):
                results.append(item)
            continue
        m = re.search(rf"{key}\s*[:=]\s*['\"]([^'\"]+)['\"]", cfg_text)
        if m:
            results.append(m.group(1))
    return results


def _setup_skip(check_id: str, title: str, reason: str) -> dict:
    return {
        "id": check_id, "title": title, "status": "skipped",
        "detail": reason, "fix_action": None,
    }


def _setup_check_framework(framework_info: dict, repo_root: Path | None = None) -> dict:
    fw = framework_info.get("framework")
    if fw:
        # Verify the framework binary actually exists in node_modules — a
        # declaration in package.json without npm install is not enough.
        if repo_root is not None:
            bin_path = repo_root / "node_modules" / ".bin" / fw
            if not bin_path.exists():
                return {
                    "id": "framework",
                    "title": f"Test framework declared but not installed: {fw}",
                    "status": "fail",
                    "detail": (
                        f"{fw} is listed in package.json but not found in "
                        f"node_modules. Run `npm install` (or `yarn`) to install dependencies."
                    ),
                    "fix_action": {
                        "type": "install_packages",
                        "packages": [fw],
                        "label": f"Install {fw}",
                    },
                }
        return {
            "id": "framework",
            "title": f"Test framework: {fw}",
            "status": "pass",
            "detail": (
                f"Detected {fw} from "
                f"{framework_info.get('detected_from') or 'unknown source'}."
            ),
            "fix_action": None,
        }
    return {
        "id": "framework",
        "title": "No test framework detected",
        "status": "fail",
        "detail": (
            "Tests can't run without a framework. Install Jest + jsdom, "
            "then re-check."
        ),
        "fix_action": {
            "type": "install_packages",
            "packages": ["jest", "jest-environment-jsdom"],
            "label": "Install Jest + jsdom",
        },
    }


def _setup_check_rtl_installed(deps: dict, repo_root: Path | None = None) -> dict:
    declared_missing = [
        p for p in ("@testing-library/react", "@testing-library/jest-dom")
        if p not in deps
    ]
    # Also check node_modules for packages that are declared but not installed.
    installed_missing: list[str] = []
    if repo_root is not None:
        for p in ("@testing-library/react", "@testing-library/jest-dom"):
            if p not in declared_missing:
                pkg_dir = repo_root / "node_modules" / p
                if not pkg_dir.is_dir():
                    installed_missing.append(p)
    missing = declared_missing + installed_missing
    if not missing:
        return {
            "id": "rtl_installed",
            "title": "React Testing Library installed",
            "status": "pass",
            "detail": (
                f"@testing-library/react {deps.get('@testing-library/react')}, "
                f"@testing-library/jest-dom {deps.get('@testing-library/jest-dom')}."
            ),
            "fix_action": None,
        }
    detail = (
        "render() needs @testing-library/react; matchers like "
        "toBeInTheDocument need @testing-library/jest-dom."
    )
    if installed_missing and not declared_missing:
        detail = (
            f"{', '.join(installed_missing)} declared in package.json but not found "
            "in node_modules. Run `npm install` to install dependencies."
        )
    return {
        "id": "rtl_installed",
        "title": f"Missing: {', '.join(missing)}",
        "status": "fail",
        "detail": detail,
        "fix_action": {
            "type": "install_packages",
            "packages": missing,
            "label": f"Install {len(missing)} package(s)",
        },
    }


def _setup_check_jsdom_env(framework: str, cfg_source: str | None,
                           cfg_text: str,
                           repo_root: Path | None = None) -> dict:
    if framework != "jest":
        return _setup_skip(
            "jsdom_env",
            "jsdom test environment (Jest-only check)",
            "Only evaluated for Jest projects — your framework is different.",
        )
    # next/jest automatically sets jsdom; detect via require/import of it.
    if "next/jest" in cfg_text:
        return {
            "id": "jsdom_env",
            "title": "jsdom environment via next/jest",
            "status": "pass",
            "detail": "next/jest defaults testEnvironment to jsdom.",
            "fix_action": None,
        }
    # Explicit jsdom (by either short name or full package name).
    if re.search(
        r"testEnvironment\s*[:=]\s*['\"](?:jsdom|jest-environment-jsdom)['\"]",
        cfg_text,
    ):
        # Config declares jsdom — verify the package is actually installed.
        if repo_root is not None:
            jsdom_dir = repo_root / "node_modules" / "jest-environment-jsdom"
            if not jsdom_dir.is_dir():
                return {
                    "id": "jsdom_env",
                    "title": "jest-environment-jsdom configured but not installed",
                    "status": "fail",
                    "detail": (
                        "testEnvironment is set to 'jsdom' in "
                        f"{cfg_source or 'jest config'} but jest-environment-jsdom "
                        "is not in node_modules. Run `npm install jest-environment-jsdom`."
                    ),
                    "fix_action": {
                        "type": "install_packages",
                        "packages": ["jest-environment-jsdom"],
                        "label": "Install jest-environment-jsdom",
                    },
                }
        return {
            "id": "jsdom_env",
            "title": "jsdom test environment configured",
            "status": "pass",
            "detail": f"testEnvironment set in {cfg_source or 'jest config'}.",
            "fix_action": None,
        }
    # Project uses a custom environment we don't recognise. Could be
    # legitimate (miniflare for workers, happy-dom, @edge-runtime/jest-env).
    # Don't false-fail — flag as warn and let the user decide.
    m = re.search(r"testEnvironment\s*[:=]\s*['\"]([^'\"]+)['\"]", cfg_text)
    if m:
        detected = m.group(1)
        # happy-dom is a common jsdom alternative that works with RTL.
        if "happy-dom" in detected:
            return {
                "id": "jsdom_env",
                "title": f"DOM environment via {detected}",
                "status": "pass",
                "detail": "happy-dom supports RTL renders.",
                "fix_action": None,
            }
        if detected == "node":
            return {
                "id": "jsdom_env",
                "title": "testEnvironment explicitly set to 'node'",
                "status": "fail",
                "detail": (
                    "Tests that call render() will crash with 'document is "
                    "not defined'. Change testEnvironment to 'jsdom'."
                ),
                "fix_action": {
                    "type": "config_snippet",
                    "target": cfg_source or "jest.config.js",
                    "snippet": "testEnvironment: 'jsdom',\n",
                    "label": "Copy snippet into jest config",
                },
            }
        return {
            "id": "jsdom_env",
            "title": f"Unknown testEnvironment: {detected}",
            "status": "warn",
            "detail": (
                f"Jest is configured with a non-standard environment "
                f"({detected}). If your tests render React components, "
                "make sure it exposes document/window — otherwise switch "
                "to 'jsdom'."
            ),
            "fix_action": None,
        }
    return {
        "id": "jsdom_env",
        "title": "Missing: jsdom test environment",
        "status": "fail",
        "detail": (
            "Jest's default testEnvironment is 'node'. Tests that call "
            "render() will crash with 'document is not defined' immediately."
        ),
        "fix_action": {
            "type": "config_snippet",
            "target": cfg_source or "jest.config.js",
            "snippet": (
                "/** @type {import('jest').Config} */\n"
                "module.exports = {\n"
                "  testEnvironment: 'jsdom',\n"
                "  // keep your existing settings below\n"
                "};\n"
            ),
            "label": "Copy snippet into jest config",
        },
    }


def _setup_check_jest_dom_wired(framework: str, deps: dict,
                                 cfg_text: str, repo: Path,
                                 cfg_source: str | None = None) -> dict:
    if framework != "jest":
        return _setup_skip(
            "jest_dom_wired", "jest-dom matchers (Jest-only check)", "",
        )
    if "@testing-library/jest-dom" not in deps:
        return _setup_skip(
            "jest_dom_wired",
            "jest-dom matchers (install package first)",
            "Covered by the package-install check above.",
        )
    # Direct reference in the jest config text itself (short form).
    if "@testing-library/jest-dom" in cfg_text:
        return {
            "id": "jest_dom_wired",
            "title": "jest-dom matchers wired via jest config",
            "status": "pass",
            "detail": "Direct reference in jest config.",
            "fix_action": None,
        }
    # Follow the actual setup files the user wired into the config. Resolves
    # <rootDir> / relative / absolute. If any file imports jest-dom, we're
    # good. Works for *any* naming convention, not just our sample's.
    for entry in _setup_extract_setup_files(cfg_text):
        resolved = entry.replace("<rootDir>", str(repo))
        candidate = Path(resolved)
        if not candidate.is_absolute():
            candidate = (repo / candidate).resolve()
        if not candidate.is_file():
            # Also try common extensions appended.
            for ext in (".ts", ".tsx", ".js", ".mjs", ".cjs"):
                alt = candidate.with_suffix(ext) if candidate.suffix == "" else Path(str(candidate) + ext)
                if alt.is_file():
                    candidate = alt
                    break
        if candidate.is_file():
            try:
                t = candidate.read_text(encoding="utf-8", errors="ignore")
                if "@testing-library/jest-dom" in t:
                    return {
                        "id": "jest_dom_wired",
                        "title": "jest-dom matchers wired via setup file",
                        "status": "pass",
                        "detail": f"Imported in {candidate.relative_to(repo) if candidate.is_relative_to(repo) else candidate.name}.",
                        "fix_action": None,
                    }
            except Exception:
                pass
    config_file = cfg_source or "jest.config.js"
    if cfg_source:
        # A jest config already exists — patch it to add the missing key.
        fix_action = {
            "type": "patch_file",
            "path": config_file,
            "patch_key": "setupFilesAfterEnv",
            "patch_value": "['@testing-library/jest-dom']",
            "label": "Add to jest config",
        }
    else:
        # No jest config yet — create one with the setting included.
        fix_action = {
            "type": "create_file",
            "path": "jest.config.js",
            "content": (
                "/** @type {import('jest').Config} */\n"
                "module.exports = {\n"
                "  setupFilesAfterEnv: ['@testing-library/jest-dom'],\n"
                "};\n"
            ),
            "label": "Create jest.config.js",
        }
    return {
        "id": "jest_dom_wired",
        "title": "@testing-library/jest-dom installed but not loaded",
        "status": "warn",
        "detail": (
            "The package is in node_modules, but Jest doesn't import it. "
            "Matchers like toBeInTheDocument / toBeVisible will not exist."
        ),
        "fix_action": fix_action,
    }


def _setup_check_path_aliases(framework: str, repo: Path, cfg_text: str) -> dict:
    if framework != "jest":
        return _setup_skip(
            "path_aliases", "Path aliases (Jest-only check)", "",
        )
    ts_paths = _setup_read_tsconfig_paths(repo)
    if not ts_paths:
        return {
            "id": "path_aliases",
            "title": "No path aliases to reconcile",
            "status": "pass",
            "detail": "tsconfig/jsconfig has no `paths` — nothing to map.",
            "fix_action": None,
        }
    # For each ts alias prefix, check that it appears somewhere near
    # moduleNameMapper. If next/jest is used, it auto-forwards tsconfig paths.
    if "next/jest" in cfg_text:
        return {
            "id": "path_aliases",
            "title": "Path aliases forwarded by next/jest",
            "status": "pass",
            "detail": "next/jest wires tsconfig paths into Jest automatically.",
            "fix_action": None,
        }
    # Narrow the search to the moduleNameMapper block so stray `@` characters
    # in comments or unrelated strings don't pass the check falsely.
    mapper_block_match = re.search(
        r"moduleNameMapper\s*[:=]\s*\{([\s\S]*?)\}", cfg_text,
    )
    mapper_block = mapper_block_match.group(1) if mapper_block_match else ""
    missing = []
    for alias in ts_paths:
        prefix = alias.rstrip("/*").rstrip("/")
        if not prefix:
            continue
        # Look for the alias prefix inside moduleNameMapper specifically.
        # `re.escape` handles `@`, `~`, `$`, etc.
        if not re.search(re.escape(prefix), mapper_block):
            missing.append(alias)
    if not missing:
        return {
            "id": "path_aliases",
            "title": "Path aliases mapped for Jest",
            "status": "pass",
            "detail": f"All {len(ts_paths)} tsconfig path(s) present in Jest config.",
            "fix_action": None,
        }
    mapper_lines: list[str] = []
    for alias, targets in ts_paths.items():
        target = targets[0] if targets else ""
        js_alias = "^" + alias.replace("/*", "/(.*)$")
        js_target = "<rootDir>/" + target.replace("/*", "/$1")
        mapper_lines.append(f"  '{js_alias}': '{js_target}',")
    snippet = (
        "// Add (or merge) into your jest config:\n"
        "moduleNameMapper: {\n"
        + "\n".join(mapper_lines)
        + "\n},\n"
    )
    return {
        "id": "path_aliases",
        "title": f"Path aliases missing in Jest: {', '.join(missing)}",
        "status": "fail",
        "detail": (
            "tsconfig.json has path aliases Jest doesn't know about. "
            "Any test importing with these aliases will fail with "
            "'Cannot find module'."
        ),
        "fix_action": {
            "type": "config_snippet",
            "target": "jest.config.js",
            "snippet": snippet,
            "label": "Copy snippet into jest config",
        },
    }


def _setup_find_app_dir(repo: Path) -> Path | None:
    """Find the Next.js App Router directory. Checks the standard locations
    (app/, src/app/) and, for monorepos, scans one level deep under common
    workspace folders (apps/*, packages/*). Returns None if none found."""
    for candidate in (repo / "app", repo / "src" / "app"):
        if candidate.is_dir() and any(candidate.glob("layout.*")):
            return candidate
    for workspace in ("apps", "packages"):
        base = repo / workspace
        if not base.is_dir():
            continue
        for child in base.iterdir():
            if not child.is_dir():
                continue
            for sub in (child / "app", child / "src" / "app"):
                if sub.is_dir() and any(sub.glob("layout.*")):
                    return sub
    return None


def _setup_find_pages_dir(repo: Path) -> Path | None:
    """Find the Next.js Pages Router directory. Same monorepo-aware search
    as _setup_find_app_dir."""
    for candidate in (repo / "pages", repo / "src" / "pages"):
        if candidate.is_dir():
            return candidate
    for workspace in ("apps", "packages"):
        base = repo / workspace
        if not base.is_dir():
            continue
        for child in base.iterdir():
            if not child.is_dir():
                continue
            for sub in (child / "pages", child / "src" / "pages"):
                if sub.is_dir():
                    return sub
    return None


def _setup_check_next_router_mock(repo: Path, deps: dict,
                                   cfg_text: str) -> dict:
    is_next = "next" in deps
    if not is_next:
        return _setup_skip(
            "next_router_mock", "Next.js router mock (non-Next project)", "",
        )
    app_dir = _setup_find_app_dir(repo)
    pages_dir = _setup_find_pages_dir(repo)
    if not app_dir and not pages_dir:
        return _setup_skip(
            "next_router_mock",
            "Next.js router mock (no app/ or pages/ detected)",
            "Project depends on `next` but no router directory is visible.",
        )
    # App Router and Pages Router expose different modules. Check the one
    # that applies (or both, when a project migrates incrementally).
    needed: list[str] = []
    if app_dir:
        needed.append("next/navigation")
    if pages_dir:
        needed.append("next/router")

    def _mock_present(module_name: str) -> Path | None:
        base = module_name.replace("next/", "next/")
        for ext in ("js", "ts", "tsx", "jsx"):
            p = repo / "__mocks__" / f"{base}.{ext}"
            if p.is_file():
                return p
        return None

    missing = [m for m in needed if not _mock_present(m) and m not in cfg_text]
    if not missing:
        locations = ", ".join(needed) or "n/a"
        return {
            "id": "next_router_mock",
            "title": f"Next.js router mock(s) present: {locations}",
            "status": "pass",
            "detail": "Mock files found or referenced in Jest config.",
            "fix_action": None,
        }

    # Pick the most important missing one to offer a one-click scaffold for.
    primary = missing[0]
    if primary == "next/navigation":
        content = (
            "// Generated by Maeris setup check.\n"
            "// Stubs App Router navigation hooks so RTL renders work.\n"
            "module.exports = {\n"
            "  useRouter: () => ({\n"
            "    push: () => {}, replace: () => {}, back: () => {},\n"
            "    forward: () => {}, refresh: () => {}, prefetch: () => {},\n"
            "  }),\n"
            "  useParams: () => ({}),\n"
            "  useSearchParams: () => new URLSearchParams(),\n"
            "  usePathname: () => '/',\n"
            "  redirect: () => { throw new Error('redirect called'); },\n"
            "  notFound: () => { throw new Error('notFound called'); },\n"
            "};\n"
        )
        path = "__mocks__/next/navigation.js"
    else:  # next/router (Pages Router)
        content = (
            "// Generated by Maeris setup check.\n"
            "// Stubs Pages Router hook so RTL renders work.\n"
            "module.exports = {\n"
            "  useRouter: () => ({\n"
            "    route: '/', pathname: '/', query: {}, asPath: '/',\n"
            "    push: () => Promise.resolve(true),\n"
            "    replace: () => Promise.resolve(true),\n"
            "    back: () => {}, reload: () => {}, prefetch: () => Promise.resolve(),\n"
            "    events: { on: () => {}, off: () => {}, emit: () => {} },\n"
            "  }),\n"
            "};\n"
        )
        path = "__mocks__/next/router.js"

    return {
        "id": "next_router_mock",
        "title": f"No mock for {', '.join(missing)}",
        "status": "warn",
        "detail": (
            "Next.js router hooks need a test-side mock or rendered components "
            "will throw 'invariant expected app router to be mounted' "
            "(App Router) or 'No router instance found' (Pages Router). "
            "Jest auto-resolves files under __mocks__/ — one scaffold fixes it."
        ),
        "fix_action": {
            "type": "create_file",
            "path": path,
            "content": content,
            "label": f"Create {path}",
        },
    }


def check_unit_test_setup_tool() -> Tool:
    return Tool(
        name="check_unit_test_setup",
        description=(
            "Pre-flight health check for the project's unit-test setup. "
            "Verifies framework, Testing Library install, jsdom env, "
            "jest-dom matchers, tsconfig path aliases, and Next.js App "
            "Router mocks. Read-only. Returns checks[] with pass/fail/warn "
            "status and a fix_action per failure the UI can dispatch."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
            },
        },
    )


async def handle_check_unit_test_setup(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    if not repo.is_dir():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"repo_path is not a directory: {repo}",
        }, indent=2))]

    pkg = _setup_read_package_json(repo)
    if not pkg:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "No readable package.json at repo root.",
        }, indent=2))]

    deps = _setup_all_deps(pkg)
    framework_info = detect_framework(repo)
    framework = framework_info.get("framework") or ""
    if framework == "jest":
        cfg_source, cfg_text = _setup_find_jest_config(repo)
    else:
        cfg_source, cfg_text = (None, "")

    checks = [
        _setup_check_framework(framework_info, repo_root=repo),
        _setup_check_rtl_installed(deps, repo_root=repo),
        _setup_check_jsdom_env(framework, cfg_source, cfg_text, repo_root=repo),
        _setup_check_jest_dom_wired(framework, deps, cfg_text, repo, cfg_source),
        _setup_check_path_aliases(framework, repo, cfg_text),
        _setup_check_next_router_mock(repo, deps, cfg_text),
    ]

    fail = sum(1 for c in checks if c.get("status") == "fail")
    warn = sum(1 for c in checks if c.get("status") == "warn")
    passed = sum(1 for c in checks if c.get("status") == "pass")
    skipped = sum(1 for c in checks if c.get("status") == "skipped")

    if fail > 0:
        overall = "broken"
    elif warn > 0:
        overall = "needs_attention"
    else:
        overall = "healthy"

    return [TextContent(type="text", text=json.dumps({
        "status": "completed",
        "overall": overall,
        "summary": {"pass": passed, "warn": warn, "fail": fail, "skipped": skipped},
        "framework": framework,
        "jest_config_source": cfg_source,
        "checks": checks,
    }, indent=2))]


# -----------------------------------------------------------------------------
# run_canary_check — write a minimal RTL test, actually run it via the user's
# Jest, and read the result. This is the authoritative counterpart to the
# static check above: we stop guessing at configs and let the real toolchain
# tell us whether rendering a React component works *in this exact project*.
# Works for any project shape (Next, Remix, CRA, custom Jest configs, monorepo
# subpackages) because the framework's own error messages become our diagnosis.
# -----------------------------------------------------------------------------
_CANARY_FILE_NAME = "__maeris_canary__.test.jsx"

_CANARY_FILE_CONTENT = (
    "// Auto-generated by Maeris setup check. Written, executed, and deleted\n"
    "// in a single request — safe to ignore if you ever see it in a diff.\n"
    "import { render } from '@testing-library/react';\n"
    "\n"
    "test('maeris canary — can render a <div/>', () => {\n"
    "  const { container } = render(<div data-testid=\"maeris\" />);\n"
    "  if (!container) throw new Error('container missing');\n"
    "});\n"
)

# Pattern → diagnosis. Ordered: first match wins, so put the most specific
# earlier. Each tuple is (regex, check_id, headline, remedy, fix_action).
# The goal is a helpful "what's wrong and how to fix it" — not an exhaustive
# taxonomy. Anything we can't classify falls into a generic "unknown" bucket
# with the raw error text surfaced so the user isn't left guessing.
_CANARY_PATTERNS: list[tuple[str, str, str, str, dict | None]] = [
    (
        r"Cannot find module ['\"]@testing-library/react['\"]",
        "rtl_missing",
        "React Testing Library is not installed",
        "Install @testing-library/react (and @testing-library/jest-dom).",
        {
            "type": "install_packages",
            "packages": ["@testing-library/react", "@testing-library/jest-dom"],
            "label": "Install RTL + jest-dom",
        },
    ),
    (
        r"document is not defined|window is not defined|ReferenceError: document",
        "jsdom_env_missing",
        "Jest is using the 'node' test environment",
        (
            "Rendering React needs a DOM. Set testEnvironment: 'jsdom' in "
            "your Jest config, or switch to next/jest / @edge-runtime/jest-env."
        ),
        {
            "type": "config_snippet",
            "target": "jest.config.js",
            "snippet": "testEnvironment: 'jsdom',\n",
            "label": "Copy snippet into jest config",
        },
    ),
    (
        r"(?:SyntaxError|Unexpected token).*?(?:\<|jsx|\'\<\')",
        "jsx_transform_missing",
        "JSX is not being transformed",
        (
            "Jest isn't converting JSX into JavaScript. For Next.js projects "
            "use next/jest; otherwise add @babel/preset-react (or @swc/jest) "
            "to your transform config."
        ),
        None,
    ),
    (
        r"invariant expected app router to be mounted",
        "next_app_router_missing",
        "Missing mock for Next.js App Router",
        (
            "The page under test calls useRouter/useParams but Jest has no "
            "mock. Create __mocks__/next/navigation.js."
        ),
        {
            "type": "create_file",
            "path": "__mocks__/next/navigation.js",
            "content": (
                "module.exports = {\n"
                "  useRouter: () => ({ push: () => {}, replace: () => {}, back: () => {}, forward: () => {}, refresh: () => {}, prefetch: () => {} }),\n"
                "  useParams: () => ({}),\n"
                "  useSearchParams: () => new URLSearchParams(),\n"
                "  usePathname: () => '/',\n"
                "  redirect: () => { throw new Error('redirect called'); },\n"
                "  notFound: () => { throw new Error('notFound called'); },\n"
                "};\n"
            ),
            "label": "Create __mocks__/next/navigation.js",
        },
    ),
    (
        r"No router instance found",
        "next_pages_router_missing",
        "Missing mock for Next.js Pages Router",
        (
            "Pages Router pages call useRouter but Jest has no mock. "
            "Create __mocks__/next/router.js."
        ),
        {
            "type": "create_file",
            "path": "__mocks__/next/router.js",
            "content": (
                "module.exports = {\n"
                "  useRouter: () => ({ route: '/', pathname: '/', query: {}, asPath: '/', push: () => Promise.resolve(true), replace: () => Promise.resolve(true), back: () => {}, reload: () => {}, prefetch: () => Promise.resolve(), events: { on: () => {}, off: () => {}, emit: () => {} } }),\n"
                "};\n"
            ),
            "label": "Create __mocks__/next/router.js",
        },
    ),
    (
        r"Cannot find module ['\"](@[^'\"]+/[^'\"]+)['\"]",
        "path_alias_or_module_missing",
        "Jest can't resolve an imported module",
        (
            "Either a dependency isn't installed, or a tsconfig path alias "
            "hasn't been mirrored into Jest's moduleNameMapper. Re-run the "
            "static check above — it will name the specific alias."
        ),
        None,
    ),
    (
        r"(?:toBeInTheDocument|toBeVisible|toBeDisabled|toHaveTextContent) is not a function",
        "jest_dom_not_wired",
        "@testing-library/jest-dom is installed but not loaded",
        (
            "Jest-dom matchers aren't registered. Add "
            "setupFilesAfterEnv: ['@testing-library/jest-dom'] to your Jest config."
        ),
        {
            "type": "config_snippet",
            "target": "jest.config.js",
            "snippet": "setupFilesAfterEnv: ['@testing-library/jest-dom'],\n",
            "label": "Copy snippet into jest config",
        },
    ),
    (
        r"No tests found",
        "test_match_excludes_root",
        "Jest can't see the canary file",
        (
            "The project's testMatch excludes the file we wrote. Your "
            "generated tests should live in one of the directories your "
            "testMatch covers — check package.json#jest.testMatch or the "
            "testMatch field in jest.config.*."
        ),
        None,
    ),
    (
        r"jest: command not found|sh: jest:",
        "jest_binary_missing",
        "Jest binary is not available",
        (
            "Jest is not installed in this project's node_modules. "
            "Run `npm install` (or your package manager's equivalent) first."
        ),
        None,
    ),
]


def run_canary_check_tool() -> Tool:
    return Tool(
        name="run_canary_check",
        description=(
            "Authoritative project-setup check. Writes a minimal RTL test, "
            "runs it with the project's own Jest, reads the actual error "
            "output, and maps it to a plain-English diagnosis + fix_action. "
            "Complements the static check by catching setup problems no "
            "static scan can see (custom transforms, resolved-config "
            "surprises, framework-specific runtime errors). Always cleans "
            "up the canary file — even on timeout."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "timeout_s": {
                    "type": "integer", "default": 90,
                    "description": "Max seconds for Jest to run the canary.",
                },
            },
        },
    )


async def handle_run_canary_check(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    if not repo.is_dir():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"repo_path is not a directory: {repo}",
        }, indent=2))]

    framework_info = detect_framework(repo)
    framework = framework_info.get("framework") or ""
    if framework != "jest":
        return [TextContent(type="text", text=json.dumps({
            "status": "skipped",
            "reason": (
                f"Canary check supports Jest only in v1. Detected framework: "
                f"{framework or 'none'}."
            ),
        }, indent=2))]

    # Find a canary filename that doesn't collide with anything on disk. If
    # the standard name is taken (a previous run crashed mid-cleanup, say),
    # suffix with a short uuid until we get a free slot.
    canary_path = repo / _CANARY_FILE_NAME
    if canary_path.exists():
        canary_path = repo / f".maeris-canary-{uuid.uuid4().hex[:8]}.test.jsx"

    timeout_s = max(10, min(int(arguments.get("timeout_s") or 90), 300))

    try:
        canary_path.write_text(_CANARY_FILE_CONTENT, encoding="utf-8")
    except Exception as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"Could not write canary file: {exc}",
        }, indent=2))]

    try:
        # Reuse the shared runner — it already handles Jest/Vitest CLI flags,
        # cancel plumbing, etc. scope_type='file' + --runTestsByPath bypasses
        # any project-specific testMatch so the file is guaranteed to run.
        exec_result = await _execute_runner(
            repo, framework, "file", str(canary_path), timeout_s=timeout_s,
        )
    finally:
        # Always clean up — we never want to leave a canary behind, even
        # if the runner hung, crashed, was cancelled, or anything else went
        # wrong above.
        try:
            if canary_path.exists():
                canary_path.unlink()
        except Exception:
            pass

    if not exec_result.get("ok"):
        return [TextContent(type="text", text=json.dumps({
            "status": "run_error",
            "message": (
                exec_result.get("stderr_first_line")
                or "The canary runner could not execute."
            ),
            "exit_code": exec_result.get("exit_code"),
        }, indent=2))]

    stdout = exec_result.get("stdout") or ""
    stderr = exec_result.get("stderr") or ""
    combined = stdout + "\n" + stderr
    parsed = _parse_runner_output(framework, stdout)
    passed_any = any(r.get("status") == "passed" for r in parsed)
    failed_any = any(r.get("status") == "failed" for r in parsed)

    if passed_any and not failed_any:
        return [TextContent(type="text", text=json.dumps({
            "status": "healthy",
            "headline": "Canary rendered successfully — your setup works.",
            "detail": (
                "Rendering a React component in this project's Jest "
                "configuration succeeded. Any remaining test failures are "
                "code bugs, not environment issues."
            ),
            "diagnoses": [],
        }, indent=2))]

    # Some kind of failure — try to classify. Surface EVERY matching
    # pattern so the user sees stacked issues at once, not one-at-a-time.
    diagnoses: list[dict] = []
    seen_ids: set[str] = set()
    for pattern, check_id, headline, remedy, fix in _CANARY_PATTERNS:
        if check_id in seen_ids:
            continue
        if re.search(pattern, combined, flags=re.I):
            diagnoses.append({
                "id": check_id,
                "headline": headline,
                "remedy": remedy,
                "fix_action": fix,
            })
            seen_ids.add(check_id)

    if not diagnoses:
        # Truncate raw error so we never ship a 10MB stack back to the UI.
        snippet = combined.strip().splitlines()[-30:]
        diagnoses.append({
            "id": "unknown",
            "headline": "Canary failed with an unclassified error",
            "remedy": (
                "Review the error snippet below. If you share it back, we "
                "can add a recogniser for this case in a future version."
            ),
            "fix_action": None,
            "error_snippet": "\n".join(snippet)[:4000],
        })

    return [TextContent(type="text", text=json.dumps({
        "status": "broken",
        "headline": (
            f"{len(diagnoses)} issue{'s' if len(diagnoses) != 1 else ''} "
            "blocking React renders in this project."
        ),
        "detail": "Fix each item below, then re-run the canary.",
        "diagnoses": diagnoses,
    }, indent=2))]


# -----------------------------------------------------------------------------
# apply_unit_test_setup_fix — safe, additive-only. Creates the file at the
# exact path supplied by a prior check_unit_test_setup call. Refuses to
# overwrite existing files — the user's edits always win.
# -----------------------------------------------------------------------------
def apply_unit_test_setup_fix_tool() -> Tool:
    return Tool(
        name="apply_unit_test_setup_fix",
        description=(
            "Apply a safe setup fix returned by check_unit_test_setup. "
            "Currently supports fix_type='create_file' only — writes the "
            "file if and only if it does not already exist. Path-escape "
            "safe. Other fix types (config_snippet, install_packages) are "
            "handled by separate actions; attempting them here returns an "
            "error so nothing is silently ignored."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "fix_type": {"type": "string"},
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["fix_type"],
        },
    )


def _patch_jest_config(text: str, key: str, value: str) -> str | None:
    """Inject `key: value` into a module.exports = { ... } Jest config.

    Inserts before the last closing brace so existing settings are preserved.
    Returns the patched text, or None if the pattern isn't recognised.
    """
    # Already present — nothing to do.
    if key in text:
        return text
    # Find the last `}` that closes module.exports (handles trailing whitespace/semicolons).
    idx = text.rfind("}")
    if idx == -1:
        return None
    indent = "  "
    line = f"{indent}{key}: {value},\n"
    return text[:idx] + line + text[idx:]


async def handle_apply_unit_test_setup_fix(arguments: dict) -> list[TextContent]:
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    fix_type = (arguments.get("fix_type") or "").strip()

    if fix_type not in ("create_file", "patch_file"):
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": (
                f"fix_type '{fix_type}' is not auto-applicable. "
                "Supported: 'create_file', 'patch_file'."
            ),
        }, indent=2))]

    rel = (arguments.get("path") or "").strip()
    if not rel:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "path is required.",
        }, indent=2))]

    # Normalize and confine: no absolute paths, no '..' escape.
    rel_path = Path(rel)
    if rel_path.is_absolute():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "path must be relative to repo_path.",
        }, indent=2))]
    target = (repo / rel_path).resolve()
    try:
        target.relative_to(repo)
    except Exception:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "path escapes the repo root.",
        }, indent=2))]

    if fix_type == "patch_file":
        patch_key = (arguments.get("patch_key") or "").strip()
        patch_value = (arguments.get("patch_value") or "").strip()
        if not patch_key or not patch_value:
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": "fix_type=patch_file requires 'patch_key' and 'patch_value'.",
            }, indent=2))]
        if not target.is_file():
            return [TextContent(type="text", text=json.dumps({
                "status": "error",
                "message": f"{rel} does not exist — use create_file instead.",
            }, indent=2))]
        try:
            original = target.read_text(encoding="utf-8", errors="ignore")
            patched = _patch_jest_config(original, patch_key, patch_value)
            if patched is None:
                return [TextContent(type="text", text=json.dumps({
                    "status": "error",
                    "message": f"Could not locate insertion point in {rel}. Edit manually.",
                }, indent=2))]
            if patched == original:
                return [TextContent(type="text", text=json.dumps({
                    "status": "exists",
                    "path": rel,
                    "message": f"{patch_key} is already set in {rel}.",
                }, indent=2))]
            target.write_text(patched, encoding="utf-8")
        except Exception as exc:
            return [TextContent(type="text", text=json.dumps({
                "status": "error", "message": f"could not patch {rel}: {exc}",
            }, indent=2))]
        return [TextContent(type="text", text=json.dumps({
            "status": "applied",
            "path": rel,
            "message": f"Patched {rel}: added {patch_key}.",
        }, indent=2))]

    # fix_type == "create_file"
    content = arguments.get("content") or ""
    if not content:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "fix_type=create_file requires 'content'.",
        }, indent=2))]

    if target.exists():
        return [TextContent(type="text", text=json.dumps({
            "status": "exists",
            "path": rel,
            "message": (
                f"{rel} already exists — not overwritten. The user's "
                "version wins; re-check if you intended a different change."
            ),
        }, indent=2))]

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    except Exception as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"could not write {rel}: {exc}",
        }, indent=2))]

    return [TextContent(type="text", text=json.dumps({
        "status": "applied",
        "path": rel,
        "message": f"Created {rel}.",
    }, indent=2))]


# -----------------------------------------------------------------------------
# auto_fix_unit_test — iterate run → analyze → apply → run until green
# -----------------------------------------------------------------------------
def auto_fix_unit_test_tool() -> Tool:
    return Tool(
        name="auto_fix_unit_test",
        description=(
            "Auto-fix a failing unit test by looping: run the test file, "
            "analyze the failure, apply the top fix suggestion, then run "
            "again. Stops when the test passes, no more fixes are suggested, "
            "or max_iterations is reached. Saves the user from the manual "
            "analyze→apply→rerun loop when a generated test has multiple "
            "small bugs. JavaScript / TypeScript only."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string"},
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the test file (e.g. 'app/cart/page.test.js').",
                },
                "test_name": {
                    "type": "string",
                    "description": "Full Jest/Vitest test name to target.",
                },
                "source_path": {
                    "type": "string",
                    "description": "Optional override for the source file under test.",
                },
                "max_iterations": {
                    "type": "integer",
                    "default": 3,
                    "description": "Maximum analyze/apply/rerun cycles. Capped to 5.",
                },
            },
            "required": ["file_path", "test_name"],
        },
    )


async def handle_auto_fix_unit_test(arguments: dict) -> list[TextContent]:
    """Run → analyze → apply → run, for ONE target test, up to N iterations.

    This is the "Auto-fix" button in the UI. The manual loop is fine when
    a test has one bug but painful when an LLM-generated test has 2-3
    stacked bugs (missing import, misplaced jest.mock, etc.). Each
    iteration re-runs the file so we always react to the *current* error,
    not a cached one.
    """
    from maeris_mcp.ai_adapter.failure_analyzer import (
        analyze_test_failure,
        FailureAnalysisUnavailable,
    )

    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    file_path_arg = (arguments.get("file_path") or "").strip()
    test_name = (arguments.get("test_name") or "").strip()
    max_iterations = max(1, min(int(arguments.get("max_iterations") or 3), 5))

    if not file_path_arg or not test_name:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "file_path and test_name are required.",
        }, indent=2))]

    test_path = (repo / file_path_arg).resolve()
    if not test_path.is_file():
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": f"test file not found: {file_path_arg}",
        }, indent=2))]

    framework_info = detect_framework(repo)
    framework = framework_info.get("framework")
    if not framework:
        return [TextContent(type="text", text=json.dumps({
            "status": "error",
            "message": "no test framework detected.",
        }, indent=2))]

    source_path_arg = (arguments.get("source_path") or "").strip()
    if source_path_arg:
        source_path = (repo / source_path_arg).resolve()
    else:
        source_path = _derive_source_from_test(test_path)

    ext = test_path.suffix.lower()
    language = "typescript" if ext in (".ts", ".tsx") else "javascript"

    iterations: list[dict] = []
    final_status = "unknown"
    final_message: str | None = None
    last_error_text: str | None = None

    # Track which (before, after) patches we've applied so we don't loop on
    # an ineffective fix — if the analyzer keeps suggesting the same patch
    # and it's not fixing anything, bail out.
    applied_patches: set[tuple[str, str]] = set()

    for i in range(max_iterations):
        iteration_num = i + 1
        # 1. Run the single test file.
        exec_result = await _execute_runner(
            repo, framework, "file", str(test_path), timeout_s=300,
        )
        if not exec_result.get("ok"):
            final_status = "run_error"
            final_message = exec_result.get("stderr_first_line") or "runner failed"
            iterations.append({
                "iteration": iteration_num, "phase": "run",
                "result": "error", "detail": final_message,
            })
            break

        parsed = _parse_runner_output(framework, exec_result.get("stdout", ""))
        target = next((r for r in parsed if r.get("test_name") == test_name), None)
        if target is None:
            final_status = "test_not_found"
            final_message = f"test '{test_name}' not present in run output"
            iterations.append({
                "iteration": iteration_num, "phase": "run",
                "result": "test_not_found",
            })
            break

        if target.get("status") == "passed":
            final_status = "passed"
            final_message = (
                f"Test is now passing after {i} fix(es)."
                if i > 0 else "Test already passing — nothing to fix."
            )
            iterations.append({
                "iteration": iteration_num, "phase": "run", "result": "passed",
            })
            break

        last_error_text = target.get("error_message") or "test failed"
        iterations.append({
            "iteration": iteration_num, "phase": "run",
            "result": "failed", "error": last_error_text[:300],
        })

        # 2. Ask the analyzer what to change.
        try:
            analysis = analyze_test_failure(
                source_path=source_path,
                test_path=test_path,
                test_name=test_name,
                last_status="failed",
                last_error=last_error_text,
                language=language,
            )
        except FailureAnalysisUnavailable as exc:
            final_status = "analysis_unavailable"
            final_message = exc.reason
            iterations.append({
                "iteration": iteration_num, "phase": "analyze",
                "result": "unavailable", "detail": exc.reason,
            })
            break

        fixes = analysis.get("fix_suggestions") or []
        if not fixes:
            final_status = "no_fix_suggested"
            final_message = "Analyzer could not suggest a concrete fix — manual review required."
            iterations.append({
                "iteration": iteration_num, "phase": "analyze", "result": "no_fix",
            })
            break

        primary = fixes[0]
        before = (primary.get("before") or "").strip()
        after = (primary.get("after") or "").strip()
        if not before:
            final_status = "fix_invalid"
            final_message = "Analyzer returned a fix with no `before` text."
            iterations.append({
                "iteration": iteration_num, "phase": "analyze", "result": "fix_invalid",
            })
            break

        if (before, after) in applied_patches:
            final_status = "fix_loop_detected"
            final_message = (
                "The same fix was suggested twice in a row without resolving "
                "the failure — stopping to avoid a loop. Manual review required."
            )
            iterations.append({
                "iteration": iteration_num, "phase": "analyze",
                "result": "loop_detected",
            })
            break

        # 3. Resolve the patch target (test vs source) using full relative paths.
        rel_test = file_path_arg
        rel_source = (
            source_path.relative_to(repo).as_posix()
            if source_path.is_relative_to(repo) else source_path.name
        )
        target_rel = rel_test if primary.get("target") == "test" else rel_source
        target_abs = (repo / target_rel).resolve()
        try:
            target_abs.relative_to(repo)
        except Exception:
            final_status = "fix_path_escape"
            final_message = f"fix target escapes repo: {target_rel}"
            iterations.append({
                "iteration": iteration_num, "phase": "apply",
                "result": "path_escape",
            })
            break
        if not target_abs.is_file():
            final_status = "fix_target_missing"
            final_message = f"fix target not on disk: {target_rel}"
            iterations.append({
                "iteration": iteration_num, "phase": "apply",
                "result": "target_missing",
            })
            break

        try:
            content = target_abs.read_text(encoding="utf-8")
        except Exception as exc:
            final_status = "fix_read_failed"
            final_message = f"could not read {target_rel}: {exc}"
            iterations.append({
                "iteration": iteration_num, "phase": "apply",
                "result": "read_failed",
            })
            break

        if before not in content:
            final_status = "fix_not_applicable"
            final_message = (
                "The analyzer's `before` snippet was not found in the file — "
                "skipping the fix so we don't corrupt unrelated code."
            )
            iterations.append({
                "iteration": iteration_num, "phase": "apply",
                "result": "before_not_found", "file": target_rel,
            })
            break

        patched = content.replace(before, after, 1)
        try:
            target_abs.write_text(patched, encoding="utf-8")
        except Exception as exc:
            final_status = "fix_write_failed"
            final_message = f"could not write {target_rel}: {exc}"
            iterations.append({
                "iteration": iteration_num, "phase": "apply",
                "result": "write_failed",
            })
            break

        applied_patches.add((before, after))
        iterations.append({
            "iteration": iteration_num, "phase": "apply", "result": "applied",
            "file": target_rel, "headline": (analysis.get("diagnosis") or {}).get("headline", "")[:160],
            "rationale": (primary.get("rationale") or "")[:200],
        })
    else:
        final_status = "max_iterations_reached"
        final_message = (
            f"Test still failing after {max_iterations} fix attempts. "
            "Last error: " + (last_error_text or "unknown")[:200]
        )

    applied_count = sum(1 for it in iterations if it.get("result") == "applied")
    return [TextContent(type="text", text=json.dumps({
        "status": final_status,
        "test_name": test_name,
        "file_path": file_path_arg,
        "iterations_run": len(iterations),
        "fixes_applied": applied_count,
        "iterations": iterations,
        "message": final_message or f"Auto-fix finished: {final_status}",
    }, indent=2))]


async def handle_delete_test_file(arguments: dict) -> list[TextContent]:
    """Delete a test file from disk.

    Args:
        repo_path: Absolute path to the project root (defaults to cwd).
        file_path: Path to the test file, relative to repo_path.
    """
    repo = Path(arguments.get("repo_path") or os.getcwd()).resolve()
    file_path_arg = (arguments.get("file_path") or "").strip()

    if not file_path_arg:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "file_path is required.",
        }, indent=2))]

    try:
        abs_path = (repo / file_path_arg).resolve()
        abs_path.relative_to(repo)  # ensure no path escape
    except Exception:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": "file_path escapes the repo root.",
        }, indent=2))]

    if not abs_path.exists():
        return [TextContent(type="text", text=json.dumps({
            "status": "not_found", "file_path": file_path_arg,
            "message": f"File not found: {file_path_arg}",
        }, indent=2))]

    try:
        abs_path.unlink()
        sidecar = _sidecar_path(abs_path)
        if sidecar.exists():
            sidecar.unlink()
    except Exception as exc:
        return [TextContent(type="text", text=json.dumps({
            "status": "error", "message": f"Could not delete file: {exc}",
        }, indent=2))]

    return [TextContent(type="text", text=json.dumps({
        "status": "deleted",
        "file_path": file_path_arg,
        "message": f"Deleted {file_path_arg}.",
    }, indent=2))]
