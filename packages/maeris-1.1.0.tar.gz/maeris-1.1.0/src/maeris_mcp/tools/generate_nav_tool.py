import asyncio
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import structlog
from mcp.types import TextContent, Tool

log = structlog.get_logger(__name__)


def _nav_path() -> Path:
    """Resolve navigation.md to the repo-specific config dir (MAERIS_CONFIG_DIR)."""
    config_dir = Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir / "navigation.md"


def _nav_meta_path() -> Path:
    config_dir = Path(os.environ.get("MAERIS_CONFIG_DIR", Path.home() / ".maeris")).expanduser()
    return config_dir / "navigation.meta.json"


def _get_git_hash() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ""


async def _run_analysis_background() -> None:
    """Fire-and-forget: fetch testcases + results from Mirabilis and update feedback cache.

    Runs while Claude explores the codebase so the cache is ready by Phase 2.
    Never raises — all failures are silently swallowed.
    """
    t_start = time.monotonic()
    log.info("analysis_background.start")
    try:
        from maeris_mcp.analysis.feedback_analyzer import analyze_test_results
        from maeris_mcp.auth.token_store import TokenStore
        from maeris_mcp.maeris.client import MaerisClient
        from maeris_mcp.storage.feedback_cache import RepoFeedbackCache

        token_store = TokenStore()
        app_id = token_store.get_app_id()
        if not app_id:
            log.info("analysis_background.skip", reason="no_app_id")
            return

        cache = RepoFeedbackCache(os.getcwd(), app_id)

        async with MaerisClient() as client:
            t_fetch = time.monotonic()
            testcases = await client.get_testcases()
            log.info("analysis_background.testcases_fetched",
                     count=len(testcases) if testcases else 0,
                     elapsed_s=round(time.monotonic() - t_fetch, 2))
            if not testcases:
                log.info("analysis_background.skip", reason="no_testcases")
                return

            tc_count = len(testcases)
            needs_full = cache.is_stale(tc_count, current_codemap_hash="")
            log.info("analysis_background.staleness_check",
                     tc_count=tc_count, needs_full=needs_full)

            needs_incremental = False
            if not needs_full:
                tc_ids = [
                    tc.get("_id") or tc.get("id") or tc.get("testcase_id") or ""
                    for tc in testcases[:10]
                    if tc.get("_id") or tc.get("id") or tc.get("testcase_id")
                ]
                latest_ts = ""
                if tc_ids:
                    try:
                        t_results = time.monotonic()
                        sample = await client.get_test_results_for_testcases(tc_ids)
                        log.info("analysis_background.results_sampled",
                                 tc_ids_checked=len(tc_ids),
                                 elapsed_s=round(time.monotonic() - t_results, 2))
                        for results in sample.values():
                            for r in results:
                                ts = r.get("created_at") or ""
                                if ts and ts > latest_ts:
                                    latest_ts = ts
                    except Exception as e:
                        log.warning("analysis_background.results_sample_failed", error=str(e))
                needs_incremental = cache.needs_incremental_update(latest_ts)
                log.info("analysis_background.incremental_check",
                         needs_incremental=needs_incremental, latest_ts=latest_ts)

            if needs_full or needs_incremental:
                t_analyze = time.monotonic()
                log.info("analysis_background.analyze_start",
                         mode="full" if needs_full else "incremental")
                await analyze_test_results(
                    client=client,
                    cache=cache,
                    incremental=needs_incremental and not needs_full,
                    codemap_hash="",
                )
                log.info("analysis_background.analyze_done",
                         elapsed_s=round(time.monotonic() - t_analyze, 2))
            else:
                log.info("analysis_background.skip", reason="cache_fresh")

        log.info("analysis_background.done",
                 total_elapsed_s=round(time.monotonic() - t_start, 2))
    except Exception as e:
        log.warning("analysis_background.error",
                    error=str(e),
                    elapsed_s=round(time.monotonic() - t_start, 2))


def _load_proven_nav_lines() -> list[str]:
    """Read proven nav sequences from feedback cache and format as display lines.

    Returns empty list if cache is unavailable, empty, or auth is missing.
    """
    try:
        from maeris_mcp.auth.token_store import TokenStore
        from maeris_mcp.storage.feedback_cache import RepoFeedbackCache

        token_store = TokenStore()
        app_id = token_store.get_app_id()
        if not app_id:
            return []

        entry = RepoFeedbackCache(os.getcwd(), app_id).load()
        if not entry.proven_nav_sequences:
            return []

        lines = []
        for nav in entry.proven_nav_sequences[:20]:
            from_page = nav.get("from_page", "")
            to_page = nav.get("to_page", "")
            pass_count = nav.get("pass_count", 1)
            steps = nav.get("steps", [])
            step_str = " → ".join(
                f"{s.get('action', '')} {s.get('selector', '')}".strip()
                for s in steps[:3]
                if s.get("action") or s.get("selector")
            )
            line = f"  - {from_page} → {to_page} (passed {pass_count}×)"
            if step_str:
                line += f": {step_str}"
            lines.append(line)
        return lines
    except Exception:
        return []


def generate_nav_tool() -> Tool:
    return Tool(
        name="generate_nav",
        description="Explore the codebase to understand the app's navigation and auth flow, "
                    "then store it as .maeris/navigation.md for use by the generate tool. "
                    "Run this once per project, or when routing/auth changes.",
        inputSchema={
            "type": "object",
            "properties": {
                "findings": {
                    "type": "string",
                    "description": "Your navigation findings from exploring the codebase. "
                                   "Omit on the first call.",
                },
            },
            "required": [],
        },
    )


async def handle_generate_nav(arguments: dict) -> list[TextContent]:
    findings = arguments.get("findings")

    # ----------------------------------------------------------------
    # Phase 1 — return exploration task to Claude
    # ----------------------------------------------------------------
    if not findings:
        log.info("generate_nav.phase1.start")
        # Fire background fetch while Claude explores — results will be ready by Phase 2
        asyncio.create_task(_run_analysis_background())
        log.info("generate_nav.phase1.background_task_scheduled")

        # Read whatever is already in the cache from a previous run
        t_cache = time.monotonic()
        nav_lines = _load_proven_nav_lines()
        log.info("generate_nav.phase1.cache_read",
                 proven_sequences=len(nav_lines),
                 elapsed_s=round(time.monotonic() - t_cache, 2))
        proven_hint = ""
        if nav_lines:
            proven_hint = (
                "\n\nVERIFIED NAVIGATION PATHS FROM PASSING TESTS:\n"
                + "\n".join(nav_lines)
                + "\n\nFor each path above: verify it still exists in source and report "
                "any selectors, route names, or intermediate screens that have changed. "
                "If a path no longer exists, note that explicitly.\n"
            )

        task = {
            "status": "explore_needed",
            "instructions": (
                "Explore the codebase and extract the app's COMPLETE auth flow and navigation structure.\n\n"

                "═══ PART 1 — TRACE THE FULL AUTH CHAIN ═══\n\n"

                "Your goal is to document every screen a real user passes through from opening the app "
                "to reaching any protected feature — as ordered user interactions, not route descriptions.\n\n"

                "STEP A — Find every auth guard / middleware / protected route:\n"
                "  - Read each guard/middleware/ProtectedRoute file\n"
                "  - For each one, extract: what state does it check? "
                "(localStorage keys, session tokens, user object fields, role flags, etc.)\n"
                "  - What does it redirect to if the check FAILS?\n"
                "  - List every check and its failure destination.\n\n"

                "STEP B — For each redirect destination found in Step A:\n"
                "  - Open that component/page file\n"
                "  - Find what the user sees there\n"
                "  - Find what the user must click, select, or fill to proceed\n"
                "  - Find where that action takes the user next\n"
                "  - Document as: URL → user action (element + what they do) → next URL\n"
                "  - If the action sets localStorage/sessionStorage, note which key and value\n\n"

                "STEP C — Trace the complete chain in order:\n"
                "  Write the full path from unauthenticated → first protected page as numbered steps:\n"
                "  1. User opens app → lands on [URL]\n"
                "  2. User [action] → [result / next URL]\n"
                "  3. Guard checks [what] → if not set, redirects to [URL]\n"
                "  4. User [action on that screen] → [result]\n"
                "  ... continue until the user reaches the main app\n\n"

                "CRITICAL: if there is ANY screen between login and the main app that the user "
                "must interact with (app selection, workspace picker, onboarding step, email "
                "verification, plan selection, etc.) — document it as a user action, not just a route. "
                "Read the component file for that screen. Find the button/card/element the user clicks. "
                "Report its tag, visible text, and any data attributes.\n\n"

                "═══ PART 2 — NAVIGATION STRUCTURE ═══\n\n"

                "1. Primary navigation elements (sidebar, topbar, tabs) — for each: component file, "
                "visible labels, and the URL each item navigates to\n"
                "2. Major sections/pages: URL, how to reach from the main landing page, "
                "any role or plan restrictions (look for conditional renders: isPro, isLocked, "
                "plan === 'free', role checks)\n"
                "3. Any modals or overlays that are NOT full-page routes but are key user destinations "
                "(opened by clicking a button, not by navigating to a URL) — document the trigger element\n\n"

                "Be framework-agnostic — look at routing config, middleware, auth context, "
                "guards, layout wrappers, and page components regardless of framework.\n"
                "Read source files. Do not infer or assume.\n"
                f"{proven_hint}"
                "\nOnce you have all findings, call the generate_nav tool again with:\n"
                "  findings: <your complete findings as text>\n\n"
                "IMPORTANT: Your findings must include the COMPLETE AUTH CHAIN from Part 1 "
                "written as numbered user interaction steps. Do not summarise it as a redirect — "
                "write each screen the user lands on and each action they take."
            ),
        }
        return [TextContent(type="text", text=json.dumps(task, indent=2))]

    # ----------------------------------------------------------------
    # Phase 2 — write navigation.md
    # ----------------------------------------------------------------
    log.info("generate_nav.phase2.start")
    nav_path = _nav_path()

    # Re-read cache — background task likely completed during codebase exploration
    t_cache2 = time.monotonic()
    nav_lines = _load_proven_nav_lines()
    log.info("generate_nav.phase2.cache_read",
             proven_sequences=len(nav_lines),
             elapsed_s=round(time.monotonic() - t_cache2, 2))

    # ----------------------------------------------------------------
    # Reformat findings into structured navigation.md via Claude subprocess.
    # Raw findings are narrative text — we need the auth chain expressed as
    # ordered user interactions so generate can reliably build test steps from it.
    # ----------------------------------------------------------------
    import shutil
    claude_bin = shutil.which("claude.exe") or shutil.which("claude")

    format_prompt = (
        "You are writing a navigation.md file for a test generation tool. "
        "Convert the raw exploration findings below into a structured document.\n\n"

        "The document MUST contain these sections in this order:\n\n"

        "## 1. Entry Point\n"
        "One line: what URL the app opens on and what happens to unauthenticated users.\n\n"

        "## 2. Complete Auth Flow (as ordered user interactions)\n"
        "Write EVERY step a real user takes from opening the app to reaching the main app. "
        "Use this exact format for each step:\n"
        "  Step N: [action] — [element description] — [result / next URL]\n"
        "  (Guard: [what is checked] — if missing → [redirect URL])\n\n"
        "Rules:\n"
        "- Every intermediate screen between login and the main app MUST appear as steps\n"
        "- If a guard redirects to a screen, that screen MUST have its own step(s) "
        "showing what the user clicks/selects there\n"
        "- If an action sets localStorage or session state, note which key\n"
        "- Do NOT collapse multiple screens into one step\n"
        "- Do NOT write 'redirects to X' without also writing the step(s) on screen X\n\n"
        "Example format:\n"
        "  Step 1: go_to /login — login page — user sees email + password fields\n"
        "  Step 2: send_keys email field — [placeholder='you@example.com'] — enter email\n"
        "  Step 3: send_keys password field — [placeholder='Enter your password'] — enter password\n"
        "  Step 4: click Sign In button — button:has-text('Sign in') — submits credentials\n"
        "  (Guard: ProtectedRoute checks localStorage.application_id — if missing → /onboarding/select-app)\n"
        "  Step 5: go_to /onboarding/select-app — app selection screen — user sees list of apps\n"
        "  Step 6: click app card/button — [selector from source] — sets localStorage.application_id → /notebook\n"
        "  Step 7: lands on /notebook — main app hub\n\n"

        "## 3. Primary Navigation\n"
        "For each nav element: label | URL it navigates to | component file\n\n"

        "## 4. Major Sections\n"
        "Table: Section | URL | How to reach | Restrictions (role/plan gates)\n\n"

        "## 5. Key Modals and Overlays\n"
        "For each modal that is a key user destination (not a full-page route): "
        "name | trigger element (selector) | what it contains\n\n"

        "## 6. Key Files\n"
        "Auth context, route guards, login page, main landing page — file paths only.\n\n"

        "RULES:\n"
        "- Use only information from the findings below — do not invent anything\n"
        "- If the findings do not have selector information for a step, write the element description "
        "and note 'selector: unknown — check source'\n"
        "- The auth flow section is the most important — a test generator reads it to build "
        "login steps for every test case. It must be complete and expressed as actions.\n\n"
        f"RAW FINDINGS:\n{findings}"
    )

    structured_content = findings  # fallback
    if claude_bin:
        try:
            result = subprocess.run(
                [claude_bin, "--print", "--no-session-persistence"],
                input=format_prompt,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=120,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if result.returncode == 0 and result.stdout.strip():
                structured_content = result.stdout.strip()
                log.info("generate_nav.phase2.structured_by_claude")
            else:
                log.warning("generate_nav.phase2.claude_format_failed",
                            stderr=result.stderr[:200] if result.stderr else "")
        except Exception as e:
            log.warning("generate_nav.phase2.claude_format_error", error=str(e))

    content = structured_content
    if nav_lines:
        content += (
            "\n\n## Verified Navigation Sequences (from passing tests)\n\n"
            "These paths have been confirmed working by test execution. "
            "Use them as ground truth for step ordering and URL targets.\n\n"
            + "\n".join(nav_lines)
        )

    nav_path.write_text(content, encoding="utf-8")
    log.info("generate_nav.phase2.nav_written", path=str(nav_path))

    git_hash = _get_git_hash()
    if git_hash:
        _nav_meta_path().write_text(
            json.dumps({
                "git_hash": git_hash,
                "written_at": datetime.now(timezone.utc).isoformat(),
            }, indent=2),
            encoding="utf-8",
        )

    return [TextContent(type="text", text=json.dumps({
        "success": True,
        "output_file": str(nav_path),
        "proven_sequences_added": len(nav_lines),
        "message": "Navigation map saved. The generate tool will now use this for complete step flows.",
    }, indent=2))]
