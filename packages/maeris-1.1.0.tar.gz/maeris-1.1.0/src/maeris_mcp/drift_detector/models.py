"""Drift detection data models — pure dataclasses, no I/O, no AI."""

from dataclasses import dataclass, field
from enum import Enum


class DriftSeverity(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class DriftKind(str, Enum):
    SELECTOR_MISSING = "selector_missing"
    ROUTE_MISSING = "route_missing"
    ROUTE_UNREGISTERED = "route_unregistered"
    FLOW_STEP_STALE = "flow_step_stale"
    FLOW_STEP_METHOD_MISMATCH = "flow_step_method_mismatch"


@dataclass
class DriftIssue:
    kind: DriftKind
    severity: DriftSeverity
    description: str
    resource_type: str    # "ui" | "api" | "flow"
    resource_id: str
    resource_name: str
    detail: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "kind": self.kind.value,
            "severity": self.severity.value,
            "description": self.description,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "resource_name": self.resource_name,
            "detail": self.detail,
        }


@dataclass
class DriftReport:
    domain: str   # "ui" | "api" | "flow" | "contract"
    issues: list[DriftIssue] = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    @property
    def has_drift(self) -> bool:
        return bool(self.issues)

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "has_drift": self.has_drift,
            "issue_count": len(self.issues),
            "issues": [i.to_dict() for i in self.issues],
            "meta": self.meta,
        }


@dataclass
class RepairResult:
    fixed: int = 0
    skipped: int = 0
    failed: int = 0

    @property
    def success(self) -> bool:
        return self.failed == 0

    def to_dict(self) -> dict:
        return {"fixed": self.fixed, "skipped": self.skipped, "failed": self.failed}
