"""Behavioral unit-test generator — Claude-powered.

Produces 10-20 meaningful test cases per source file instead of the 1-2
smoke assertions the regex generator emits. Reuses the same Claude CLI
subprocess + HTTP proxy plumbing the repair engine already relies on, so
there is no new dependency, no new auth flow, and no source code ever
leaves the user's machine en route to a third party — the proxy call is
made *from* the user's laptop.

The module is intentionally defensive: any failure (no Claude, malformed
JSON, empty tests, invalid generated code) raises
`BehavioralGenerationUnavailable`, letting the caller fall back to the
deterministic regex generator without aborting the whole run.
"""

from __future__ import annotations

import hashlib
import json
import re
import structlog
from pathlib import Path
from typing import Any

from maeris_mcp.ai_adapter.repair_suggestions import (
    _claude_run,
    _direct_ai_run,
    _parse_json,
)

logger = structlog.get_logger()


# -----------------------------------------------------------------------------
# Constants — easy to tune without touching call sites.
# -----------------------------------------------------------------------------
DEFAULT_MODEL = "claude-sonnet-4-6"
DEFAULT_TARGET_TESTS = 20
MAX_SOURCE_BYTES = 40_000          # ~10k tokens; larger files are summarised.
MAX_SOURCE_LINES = 600             # hard cap even for smaller byte counts
PROMPT_TIMEOUT_S = 180              # whole generation call budget
MAX_RETRIES_ON_BAD_JSON = 1         # one retry, then fall back.


class BehavioralGenerationUnavailable(RuntimeError):
    """Raised when AI behavioral generation can't be performed (any reason).

    Callers should catch this and fall back to the regex smoke generator.
    Carries a short `reason` attribute for logging / telemetry.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


# -----------------------------------------------------------------------------
# Prompt — structured, deterministic, and framework-aware.
# -----------------------------------------------------------------------------
_PROMPT_TEMPLATE = """You are generating a single production-grade unit test file for a JavaScript/TypeScript module.

RULES — these are hard constraints; violations make your output unusable:
1. Output ONLY a JSON object. No prose, no markdown fences, no commentary.
2. Do not invent exports. Only test what the source actually exports.
3. Use the __FRAMEWORK__ framework syntax. Assume `describe`, `it`, `expect` are globals (Jest-style).
4. Import the module under test with the exact import path `__IMPORT_SPEC__`.
5. Every test must be independent — no shared mutable state between tests.
6. DOM environment availability: __DOM_AVAILABLE__.
7. React Testing Library availability: __RTL_AVAILABLE__.
8. Prefer pure behavioral checks (inputs -> outputs) over type-of / toBeDefined.
9. For each testable export, produce BETWEEN 3 AND 6 test cases that probe different behaviors: happy path, edge cases (empty, zero, negative, null/undefined where sensible), and error cases (wrong type or invalid input, ONLY if the source clearly validates input).
10. React components (PascalCase functions returning JSX):
    - If RTL is available AND DOM is available: render the component with `import { render } from "@testing-library/react"`, then assert on the DOM — screen queries, role checks, visible text, disabled state. Produce 3-5 behavioral tests per component.
    - If RTL/DOM is NOT available: do NOT render. Instead, test the component's logic directly by mocking its dependencies (see Rule 14). Cover handler branches, dispatch calls, routing calls, and conditional early returns — anything visible in the source. Only fall back to a single structural test if the component is purely presentational with no handlers, no conditional logic, and no side effects.
__MOCKING_GUIDANCE__
11. If an export is a class, cover: instantiable, instance has expected methods, method behavior.
12. Never call functions with `require('fs')`, `fetch`, or any I/O. Keep tests in-memory.
13. Target roughly __TARGET_TESTS__ total test cases across all exports.

RESPONSE SCHEMA — return exactly this shape (single JSON object):
{
  "describe": "<string: describe block title, usually the module stem>",
  "preamble": "<string | null: JavaScript code placed INSIDE the describe() block, BEFORE the first it(). Use this for factory function definitions (e.g. makeFetchAllResults) when testing closures. Omit or set to null when not needed.>",
  "scenarios": [
    {
      "id":          "<string: short kebab-case ID unique within this file, e.g. 'add-positive-numbers'. Reused as the linkage key with tests.>",
      "export_name": "<string: the exported symbol this scenario tests>",
      "category":    "<one of: 'happy' | 'edge' | 'error' | 'boundary' | 'structural'>",
      "condition":   "<plain English: one sentence describing the input/state, e.g. 'two positive integers'>",
      "expected":    "<plain English: one sentence describing the expected outcome, e.g. 'returns their arithmetic sum'>"
    }
  ],
  "tests": [
    {
      "scenario_id": "<string: id of the scenario above this test verifies; must match exactly>",
      "name":        "<string: the `it` title; keep short, no colons>",
      "body":        "<string: ONLY the body of the it() arrow function, no braces, no function wrapper; use `expect(...)` calls; may span multiple lines>"
    }
  ]
}

SCENARIOS RULES:
- Enumerate every reasonable scenario for each export — happy paths first,
  then edge cases (empty/zero/negative/null/undefined), then error cases
  (only when the source clearly validates input). 5–10 scenarios per
  export is normal; React components without RTL should still have 3-6
  logic/branch scenarios (not just 1 structural) when handler logic is
  present in the source.
- Each scenario must be uniquely identifiable by its (export_name, condition)
  pair. Use a stable, kebab-case id: e.g. 'add-positive-numbers',
  'invite-team-empty-list', 'parse-input-rejects-non-string'.
- Tests are OPTIONAL per scenario in this response — you may emit fewer
  tests than scenarios if a scenario is trivial-to-list-but-low-priority.
  Every test you DO emit must reference a scenario.id.

GUIDELINES:
- Use `mod.default ?? mod.<Name>` to access default exports safely.
- Use `mod.<Name>` for named exports.
- Keep each test body under 20 lines.
- Assertions must be real: `expect(fn(1, 2)).toBe(3)`, not `expect(fn).toBeDefined()`.
- When you cannot infer behavior from the source, fall back to `expect(typeof fn).toBe("function")` but do not pad the list with useless existence checks.
- NEVER wrap queries or assertions in `if (element)` guards. Tests must be unconditional — if an element is missing the test should throw, not silently pass. Use `getBy*` (throws on miss) not `queryBy*` (returns null) for elements you expect to exist.
- For React component element queries: prefer `container.querySelector('[data-automation-id="..."]')` or `container.querySelector('#id')` using ids/data attributes visible in the source. Only use `getByLabelText` when a `<label htmlFor>` is explicitly present in the source. Do NOT guess accessible names that aren't set in the source.
- Do NOT use inline `require(...)` inside test bodies for modules already imported at the top of the file.
- ALWAYS include `beforeEach(() => jest.clearAllMocks())` as the first statement inside every `describe` block. This is mandatory — omitting it causes mock call counts to bleed between tests and makes assertions non-deterministic.
- NEVER wrap assertions in `if (element)` guards anywhere in the file. If an element or value may be absent, that absence is itself a test failure — let the test throw loudly rather than silently pass.
- NEVER wrap assertions in `try/catch` blocks. Swallowed exceptions produce false-green tests that give zero confidence. NOTE: this rule applies to TEST code only — do NOT skip testing error paths that the SOURCE code catches silently (see try/catch rule below).
- Assert ONLY on values that come from explicitly configured mocks or the source's own deterministic logic. Do NOT invent specific values (UUIDs, status codes, timestamps, message strings) unless that exact value is visible in the source code shown below.
- Aim for ONE primary assertion per `it()`. A second assertion on a directly related side-effect (e.g. confirming a mock was also called) is acceptable; stacking four unrelated assertions in one test is not.
- Name every `it()` using this format: `"functionName — condition — expected outcome"` (em dash between segments). Example: `"fetchAllResults — appId is missing — returns early without calling setLatestResultsMap"`. EXCEPTION: when a NAMING override is given in the focus hint below, follow that instead — it takes precedence over this rule.

COVERAGE RULES — apply these mechanically for each pattern found in the source:
- try/catch in source: When the source contains a try/catch block, produce a test that triggers the exception (make a dependency throw) and verifies the catch outcome — e.g., processing continues for remaining items, function returns a fallback, or a flag is set. Every silent catch is a code path that must be exercised.
- if/else branches in handlers: For every if/else (or ternary) inside an event handler, callback, or utility function, produce one test per branch. Do not cover only the truthy branch and skip the else.
- Multiple async return paths: For async functions with more than one return statement, produce one independent test per distinct return path. Do not combine multiple return paths into a single test.
- Conditional rendering null guard: For React components with a top-level guard like `if (!prop) return null`, always produce one test with that prop set to its falsy value and assert `expect(container.firstChild).toBeNull()`.
- Optional chaining fallback: When source uses `?.` on a value that could realistically be null/undefined, produce one test where that value IS null/undefined (chain short-circuits to undefined) and one where it is defined (property is accessed normally).
- OR / nullish fallback operators: When source uses `X || fallback` or `X ?? fallback`, produce one test where X is falsy/null (the fallback value is used) and one where X is truthy/defined (the real value is used).
- useEffect cleanup functions: When source has a useEffect with a cleanup return (`return () => clearTimeout(t)` / `clearInterval` / subscription unsubscribe), and RTL is available, produce one test that calls `unmount()` from `render(...)` and asserts the cleanup ran — use `jest.spyOn(global, 'clearTimeout')` or equivalent to observe it.
- setTimeout / setInterval callbacks: When source calls setTimeout or setInterval, call `jest.useFakeTimers()` in a `beforeEach` (paired with `jest.useRealTimers()` in `afterEach`), then `jest.advanceTimersByTime(ms)` to fire the callback. Assert the expected side-effect after time advances.
- Promise.all partial failure: When source uses `Promise.all(...)`, produce at least one test where one promise in the batch rejects and verify whether the error propagates, is caught, or leaves state in a known shape.
- Mixed array iteration with skip logic: When source iterates an array and skips items based on a guard (missing field, duplicate, failed condition), produce at least one test with mixed input — some items that pass the guard and some that do not — and assert only the passing items are processed.

CONTEXT — the module under test:

File path (for reference only): __FILE_PATH__
Detected exports (name, kind):
__EXPORTS_SUMMARY__

Detected imports (potential mock targets):
__IMPORTS_SUMMARY__
__FOCUS_HINT__
SOURCE CODE:
```__LANGUAGE__
__SOURCE_CODE__
```

Now produce the JSON object. Remember: only JSON, nothing else.
"""


# -----------------------------------------------------------------------------
# Validation — keep Maeris safe from garbage / hostile LLM output.
# -----------------------------------------------------------------------------
# Disallowed patterns in generated test bodies. We never execute code server
# side, but we do write it to the user's disk — so block obvious foot-guns.
_FORBIDDEN_PATTERNS = [
    r"\brequire\s*\(\s*['\"]fs['\"]",        # fs I/O
    r"\brequire\s*\(\s*['\"]child_process",  # shelling out
    r"\bfetch\s*\(",                          # network
    r"\beval\s*\(",                           # eval
    r"\bnew\s+Function\s*\(",                 # Function ctor
    r"\bprocess\.exit",                       # suicide
]
_FORBIDDEN_RE = re.compile("|".join(_FORBIDDEN_PATTERNS))


def _truncate_source(text: str) -> str:
    """Cap source at MAX_SOURCE_BYTES / MAX_SOURCE_LINES for prompt safety.

    Large files (auto-generated exports, mega-components) would blow the
    token budget. We keep the head, trim the rest with a marker so the LLM
    knows it's truncated and doesn't invent behaviour for the dropped tail.
    """
    lines = text.splitlines()
    if len(lines) > MAX_SOURCE_LINES:
        lines = lines[:MAX_SOURCE_LINES] + [
            f"// … truncated, {len(text.splitlines()) - MAX_SOURCE_LINES} lines omitted"
        ]
        text = "\n".join(lines)
    if len(text.encode("utf-8")) > MAX_SOURCE_BYTES:
        # Binary-safe truncation on UTF-8 boundary.
        trimmed = text.encode("utf-8")[:MAX_SOURCE_BYTES].decode("utf-8", errors="ignore")
        text = trimmed + "\n// … truncated by size"
    return text


def _format_exports(exports: list[tuple[str, bool, str]]) -> str:
    """Pretty-print the regex-scanned exports for the prompt."""
    if not exports:
        return "  (none detected by static scan)"
    return "\n".join(
        f"  - {name}  (default={'yes' if is_default else 'no'}, kind={kind})"
        for name, is_default, kind in exports
    )


def _format_imports(import_specifiers: list[str]) -> str:
    """Pretty-print detected import specifiers so Claude knows what to mock."""
    if not import_specifiers:
        return "  (none detected)"
    return "\n".join(f"  - {spec}" for spec in sorted(import_specifiers))


def _build_mocking_guidance(import_specifiers: list[str], dom_available: bool,
                            is_closure_target: bool = False) -> str:
    """Return Rule 14 text when there are mockable dependencies, else empty."""
    # Non-relative, non-react imports are mock candidates. We emit this
    # guidance for BOTH DOM-available and non-DOM cases because RTL renders
    # also need their component dependencies mocked (next/image, nested
    # components hitting real APIs, etc.).
    external = [
        s for s in import_specifiers
        if not s.startswith(".")
        and s not in ("react", "react-dom")
        and not s.startswith("@testing-library")
    ]
    if not external:
        return ""
    examples = ", ".join(f'"{s}"' for s in external[:3])

    if is_closure_target:
        # For inner-function (closure) tests the factory pattern is used —
        # all dependencies are injected as jest.fn() arguments, not hoisted
        # jest.mock() calls. Module-level mocks would freeze state across
        # tests and make per-test variation impossible.
        return (
            f"14. This test targets an inner closure. Its dependencies "
            f"({examples}) must be injected as `jest.fn()` stubs inside the "
            f"make<FunctionName>(overrides) factory helper — NOT via top-level "
            f"`jest.mock()` calls.\n"
            f"    a. Do NOT emit any top-level `jest.mock(...)` for these modules.\n"
            f"    b. Create fresh `jest.fn()` stubs per test by passing them as "
            f"       overrides to the factory: `make<FunctionName>({{ dep: jest.fn().mockReturnValue(...) }})`.\n"
            f"    c. Only use `jest.mock()` for a module that is a true singleton "
            f"       with absolutely no DI path (e.g. a global polyfill). "
            f"       In all other cases, inject via the factory."
        )

    return (
        f"14. Mockable dependencies in this module ({examples}) may need `jest.mock(...)`.\n"
        "    CRITICAL mock rules — the generator hoists mocks to the file top,\n"
        "    so design for ONE mock per module path across the whole file:\n"
        "    a. Emit `jest.mock('module-path', () => ({...}))` AS THE FIRST LINES\n"
        "       of your test body. The generator lifts them out and dedupes by\n"
        "       module path — only the first factory per path survives.\n"
        "    b. Design that single factory to be generic enough for every test in\n"
        "       this file. Do NOT rely on different mocks per test — Jest's module\n"
        "       cache is shared across tests and the per-test variant silently wins\n"
        "       or gets dropped.\n"
        "    c. To vary behavior per test, have the factory export a mutable\n"
        "       object, then set properties/spies inside each `it()` body using\n"
        "       `jest.requireMock('module-path').someFn.mockReturnValue(...)`.\n"
        "    Test handler branches, dispatch calls, routing calls, and early\n"
        "    returns directly — do not skip behavioral tests just because a\n"
        "    dependency needs mocking."
    )


def _validate_test(test: dict[str, Any]) -> tuple[bool, str]:
    """Return (ok, reason). Rejects garbage test bodies early."""
    name = test.get("name")
    body = test.get("body")
    if not isinstance(name, str) or not name.strip():
        return False, "missing test name"
    if not isinstance(body, str) or not body.strip():
        return False, "missing test body"
    if len(body) > 4000:
        return False, "body too large"
    if _FORBIDDEN_RE.search(body):
        return False, "body contains forbidden I/O / eval pattern"
    if "expect(" not in body and "assert" not in body:
        return False, "no assertion call"
    return True, ""


_VALID_CATEGORIES = frozenset({"happy", "edge", "error", "boundary", "structural"})


def _validate_scenario(s: dict[str, Any]) -> tuple[bool, str]:
    """Return (ok, reason). Catches malformed LLM scenario entries early."""
    sid = s.get("id")
    export_name = s.get("export_name")
    category = (s.get("category") or "happy").strip().lower()
    condition = s.get("condition")
    expected = s.get("expected")
    if not isinstance(sid, str) or not sid.strip():
        return False, "missing scenario id"
    if not isinstance(export_name, str) or not export_name.strip():
        return False, "missing export_name"
    if category not in _VALID_CATEGORIES:
        return False, f"unknown category {category!r}"
    if not isinstance(condition, str) or not condition.strip():
        return False, "missing condition"
    if not isinstance(expected, str) or not expected.strip():
        return False, "missing expected"
    if len(condition) > 300 or len(expected) > 300:
        return False, "condition/expected too long"
    return True, ""


def _scenario_key(file_path: str, export_name: str, condition: str) -> str:
    """Stable upsert key. Same (file, export, condition) → same key forever
    so the backend can dedupe across regenerations even if the LLM picks
    a slightly different short id between runs.
    """
    norm = " ".join((condition or "").lower().split())
    payload = f"{file_path}|{export_name}|{norm}".encode("utf-8")
    return hashlib.sha1(payload).hexdigest()[:32]


# -----------------------------------------------------------------------------
# Runner — wraps the Claude call with retry + fallback.
# -----------------------------------------------------------------------------
def _call_claude(prompt: str, model: str, *, force_proxy: bool = False) -> str:
    """Try the Claude CLI first; fall through to the HTTP proxy on failure.

    Raises BehavioralGenerationUnavailable on any infrastructure failure so
    the caller can fall back to smoke tests without stopping the whole run.

    force_proxy=True skips the CLI and goes straight to the proxy — useful
    on retries when a prior CLI response was likely truncated.
    """
    if not force_proxy:
        try:
            return _claude_run(prompt, model=model, timeout=PROMPT_TIMEOUT_S, retries=1)
        except RuntimeError as e:
            logger.warning("unit_test_gen.claude_cli_failed", error=str(e)[:200])
    try:
        return _direct_ai_run(prompt, model=model)
    except Exception as e:
        raise BehavioralGenerationUnavailable(
            f"no AI backend available: {e}"
        ) from e


def _parse_and_validate(raw: str, import_spec: str, file_path: str) -> dict:
    """Parse LLM response and drop invalid scenario/test entries.

    Returns:
      {
        "describe":  str,
        "scenarios": [{id, export_name, scenario_key, category,
                       condition, expected}, ...],
        "tests":     [{name, body, scenario_id}, ...],    # scenario_id = LLM's
      }

    Raises BehavioralGenerationUnavailable if nothing survives validation.

    Tolerates older response shapes (no scenarios array) by auto-deriving
    a single structural scenario per test — keeps the function forward- and
    backward-compatible as the prompt evolves.
    """
    try:
        parsed = _parse_json(raw)
    except (ValueError, json.JSONDecodeError) as e:
        raise BehavioralGenerationUnavailable(f"malformed JSON: {e}") from e

    if not isinstance(parsed, dict) or not isinstance(parsed.get("tests"), list):
        raise BehavioralGenerationUnavailable("response missing 'tests' array")

    # ---- scenarios ----------------------------------------------------------
    scenarios_in = parsed.get("scenarios") or []
    scenarios_by_id: dict[str, dict] = {}
    good_scenarios: list[dict] = []
    for s in scenarios_in:
        if not isinstance(s, dict):
            continue
        ok, reason = _validate_scenario(s)
        if not ok:
            logger.info("unit_test_gen.dropped_scenario",
                        reason=reason, id=s.get("id"))
            continue
        sid = s["id"].strip()
        entry = {
            "id": sid,
            "export_name": s["export_name"].strip()[:200],
            "scenario_key": _scenario_key(file_path, s["export_name"].strip(), s["condition"]),
            "category": (s.get("category") or "happy").strip().lower(),
            "condition": s["condition"].strip()[:300],
            "expected": s["expected"].strip()[:300],
        }
        scenarios_by_id[sid] = entry
        good_scenarios.append(entry)

    # ---- tests --------------------------------------------------------------
    good_tests: list[dict] = []
    orphan_test_index = 0
    for entry in parsed["tests"]:
        if not isinstance(entry, dict):
            continue
        ok, reason = _validate_test(entry)
        if not ok:
            logger.info("unit_test_gen.dropped_test", reason=reason, name=entry.get("name"))
            continue
        # Thread scenario_id if the LLM linked one; otherwise null (legacy).
        linked_id = (entry.get("scenario_id") or "").strip() or None
        if linked_id and linked_id not in scenarios_by_id:
            # LLM referenced a scenario it didn't define. Synthesize one so
            # the link survives — category 'structural' because we can't
            # derive intent. Avoids dropping perfectly good tests.
            orphan_test_index += 1
            synthesized = {
                "id": linked_id,
                "export_name": "unknown",
                "scenario_key": _scenario_key(file_path, "unknown",
                                              f"auto-scenario-{linked_id}"),
                "category": "structural",
                "condition": f"auto-derived scenario for test '{entry['name'][:80]}'",
                "expected": "test passes",
            }
            scenarios_by_id[linked_id] = synthesized
            good_scenarios.append(synthesized)
        good_tests.append({
            "name": entry["name"].strip(),
            "body": entry["body"].strip(),
            "scenario_id": linked_id,
        })

    if not good_tests:
        raise BehavioralGenerationUnavailable("all tests failed validation")

    preamble = (parsed.get("preamble") or "").strip() or None

    return {
        "describe": (parsed.get("describe") or "").strip() or "module",
        "preamble": preamble,
        "scenarios": good_scenarios,
        "tests": good_tests,
    }


# -----------------------------------------------------------------------------
# Public entry point — called by the unit_tests tool.
# -----------------------------------------------------------------------------
def _detect_react_testing_library(repo_root: Path) -> tuple[bool, bool]:
    """Detect whether @testing-library/react and a DOM env are available.

    Returns (dom_available, rtl_available). DOM is considered available if
    jest-environment-jsdom is installed, OR @testing-library/react is a dep
    (Next.js bundles jsdom natively so RTL implies a DOM env), OR the project's
    jest config explicitly sets testEnvironment to 'jsdom'. RTL is considered
    available if @testing-library/react is a dep.
    """
    pkg_path = repo_root / "package.json"
    if not pkg_path.is_file():
        return False, False
    try:
        pkg = json.loads(pkg_path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return False, False
    deps = {**(pkg.get("dependencies") or {}), **(pkg.get("devDependencies") or {})}
    rtl = "@testing-library/react" in deps
    has_jsdom = "jest-environment-jsdom" in deps

    # Also check jest config files for an explicit testEnvironment: 'jsdom'
    # declaration. Next.js projects set this in jest.config.js without listing
    # jest-environment-jsdom as a package dependency, so the package.json check
    # above would incorrectly report dom_available=False for those projects.
    cfg_has_jsdom = False
    for name in (
        "jest.config.js", "jest.config.ts", "jest.config.mjs",
        "jest.config.cjs", "jest.config.mts", "jest.config.cts",
        "jest.config.json",
    ):
        cfg_path = repo_root / name
        if cfg_path.is_file():
            try:
                cfg_text = cfg_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if re.search(
                r"testEnvironment\s*[:=]\s*['\"](?:jsdom|jest-environment-jsdom)['\"]",
                cfg_text,
            ):
                cfg_has_jsdom = True
            break
    # Also check package.json#jest section.
    if not cfg_has_jsdom:
        jest_section = pkg.get("jest")
        if isinstance(jest_section, dict):
            env = jest_section.get("testEnvironment", "")
            if env in ("jsdom", "jest-environment-jsdom"):
                cfg_has_jsdom = True

    dom = has_jsdom or rtl or cfg_has_jsdom
    return dom, rtl


def generate_behavioral_tests(
    source_path: Path,
    framework: str,
    language: str,
    import_spec: str,
    exports: list[tuple[str, bool, str]],
    *,
    import_specifiers: list[str] | None = None,
    repo_root: Path | None = None,
    model: str = DEFAULT_MODEL,
    target_tests: int = DEFAULT_TARGET_TESTS,
    focus_range: tuple[int, int] | None = None,
    focus_function: str | None = None,
    is_closure_target: bool = False,
) -> dict:
    """Ask Claude to produce behavioral tests for `source_path`.

    Returns {"describe": str, "tests": [{"name": str, "body": str}, ...]}.

    When `focus_range` is (start_line, end_line) (1-based, inclusive), only
    those lines are sent to Claude instead of the full file, so the model
    targets exactly the right function body.

    Raises BehavioralGenerationUnavailable on any failure the caller should
    treat as "fall back to the regex generator".
    """
    if framework not in ("jest", "vitest", "mocha", "jasmine"):
        raise BehavioralGenerationUnavailable(f"unsupported framework: {framework}")

    if not exports:
        raise BehavioralGenerationUnavailable("no exports to test")

    try:
        raw_source = source_path.read_text(encoding="utf-8", errors="ignore")
    except OSError as e:
        raise BehavioralGenerationUnavailable(f"cannot read source: {e}") from e

    if focus_range:
        start, end = focus_range
        all_lines = raw_source.splitlines()
        # 1-based inclusive → 0-based slice; clamp to actual file length
        fn_lines = all_lines[max(0, start - 1): min(end, len(all_lines))]

        # Prepend file-level context so Claude can see imports, constants, and
        # state variables the function references — without this it invents
        # selectors and dependencies that don't exist in the actual DOM/scope.
        _toplevel_re = re.compile(
            r"^(?:import\s|export\s+(?:default\s+)?(?:const|let|var|function|class)\s"
            r"|(?:const|let|var)\s+[A-Z_][A-Z0-9_]*\s*=)"  # ALL_CAPS constants
        )
        # Matches enclosing-scope declarations that an inner function closes over:
        # const [state, setState] = useState(...)
        # const { appId } = useContext(...)
        # let counter = 0
        _closure_scope_re = re.compile(
            r"^\s*(?:const|let)\s+(?:\[|\{|\w)"
        )
        preamble: list[str] = []
        for line in all_lines[:max(0, start - 1)]:
            if line.strip().startswith("import ") or _toplevel_re.match(line):
                preamble.append(line)
            elif is_closure_target and _closure_scope_re.match(line):
                preamble.append(line)

        omission_marker = (
            "// ... (enclosing scope context above; target function body below) ..."
            if is_closure_target
            else "// ... (intervening component code omitted) ..."
        )
        parts: list[str] = []
        if preamble:
            parts.extend(preamble)
            parts.append("")
            parts.append(omission_marker)
            parts.append("")
        parts.extend(fn_lines)
        raw_source = "\n".join(parts)

    source = _truncate_source(raw_source)

    # AC-8 support: detect whether the project has a DOM test env + RTL so
    # Claude can emit `render()` tests for React components when possible.
    root = repo_root or source_path.parent
    # Walk up to find package.json (the file we care about).
    for candidate in (root, *root.parents):
        if (candidate / "package.json").is_file():
            root = candidate
            break
    dom_available, rtl_available = _detect_react_testing_library(root)
    dom_hint = "available (jsdom)" if dom_available else "NOT available — assume Node only"
    rtl_hint = "available via @testing-library/react" if rtl_available else "NOT available"

    specs = import_specifiers or []
    mocking_guidance = _build_mocking_guidance(specs, dom_available, is_closure_target=is_closure_target)

    # Use explicit sentinel replacement — .format() would blow up on the
    # countless `{` `}` in JS/TS source. This is safer and deterministic.
    if focus_function and focus_range:
        if is_closure_target:
            factory_name = f"make{focus_function[0].upper()}{focus_function[1:]}"
            focus_hint = (
                f"\nIMPORTANT: `{focus_function}` is an INNER (non-exported) function "
                f"defined at lines {focus_range[0]}–{focus_range[1]}. "
                f"It captures variables from the enclosing scope shown in the preamble above.\n"
                f"Do NOT render the parent component. Do NOT import or use React Testing Library.\n"
                f"Use the FACTORY PATTERN:\n"
                f"  1. Emit the complete `function {factory_name}(overrides = {{}})` definition in the "
                f"     `preamble` field of your JSON response (NOT inside any `it()` body). "
                f"     It should accept all closure dependencies as named overrides with sensible defaults "
                f"     (derive the full list from the `const`/`let` declarations in the preamble). "
                f"     The function body must exactly mirror the logic of `{focus_function}` in the source. "
                f"     Return an object with the function under test and the dependency stubs so each "
                f"     `it()` body can inspect them.\n"
                f"  2. In each `it()` body call `{factory_name}({{ dep: jest.fn()... }})` to get a fresh "
                f"     instance with exactly the inputs that test needs. Never share instances across tests.\n"
                f"  3. Assert ONLY on the stubs' call counts / arguments and on the function's return value. "
                f"     Never assert on DOM nodes, rendered output, or React component state.\n"
                f"  CRITICAL: the `preamble` field is the ONLY place for the factory definition. "
                f"  If it is missing from `preamble`, every test will throw ReferenceError at runtime.\n"
                f"\nNAMING for this focused test file:\n"
                f"  - Set `describe` to exactly `\"{focus_function}\"` — just the function name, nothing else.\n"
                f"  - Name each `it()` as `\"condition — expected outcome\"` only. "
                f"    Do NOT prefix with the function name. The describe block already provides that context. "
                f"    Example: `\"appId is missing — returns early without calling setLatestResultsMap\"` "
                f"    NOT `\"{focus_function} — appId is missing — returns early\"`.\n"
            )
        else:
            focus_hint = (
                f"\nIMPORTANT: Generate tests ONLY for the inner function `{focus_function}` "
                f"(lines {focus_range[0]}–{focus_range[1]} of the full file, shown below). "
                f"Do not test any other behaviour of the component/module. "
                f"Exercise `{focus_function}` through the component's interface — "
                f"render it, trigger the relevant events/inputs, and assert only on outcomes "
                f"driven by `{focus_function}`'s logic.\n"
            )
    elif focus_function:
        focus_hint = (
            f"\nIMPORTANT: Generate tests ONLY for the inner function `{focus_function}`. "
            f"Do not test any other behaviour of the component/module.\n"
        )
    elif focus_range:
        focus_hint = (
            f"\nNOTE: The source below is an excerpt of lines {focus_range[0]}–{focus_range[1]} "
            f"from the full file. Focus your tests exclusively on the listed export(s).\n"
        )
    else:
        focus_hint = ""

    prompt = (
        _PROMPT_TEMPLATE
        .replace("__FRAMEWORK__", framework)
        .replace("__LANGUAGE__", language or "javascript")
        .replace("__IMPORT_SPEC__", import_spec)
        .replace("__FILE_PATH__", source_path.name)
        .replace("__TARGET_TESTS__", str(target_tests))
        .replace("__EXPORTS_SUMMARY__", _format_exports(exports))
        .replace("__IMPORTS_SUMMARY__", _format_imports(specs))
        .replace("__MOCKING_GUIDANCE__", mocking_guidance)
        .replace("__FOCUS_HINT__", focus_hint)
        .replace("__SOURCE_CODE__", source)
        .replace("__DOM_AVAILABLE__", dom_hint)
        .replace("__RTL_AVAILABLE__", rtl_hint)
    )

    last_error: Exception | None = None
    # Pass the repo-relative file path into the parser so scenario_keys are
    # computed consistently — the upsert in mirabilis uses (appid,file_path,key).
    try:
        file_path_rel = source_path.relative_to(root).as_posix()
    except Exception:
        file_path_rel = source_path.name
    for attempt in range(MAX_RETRIES_ON_BAD_JSON + 1):
        # On retry, go straight to the proxy with a higher token ceiling —
        # the CLI path may have truncated the previous response.
        use_proxy_directly = attempt > 0
        raw = _call_claude(prompt, model=model, force_proxy=use_proxy_directly)
        try:
            result = _parse_and_validate(raw, import_spec=import_spec,
                                         file_path=file_path_rel)
        except BehavioralGenerationUnavailable as e:
            last_error = e
            logger.warning(
                "unit_test_gen.parse_failed",
                attempt=attempt + 1,
                reason=e.reason,
            )
            continue

        # When a focus function was requested, verify Claude actually generated
        # tests that reference it. Claude sometimes ignores the focus hint and
        # produces generic component tests — those give zero coverage for the
        # target function. Treat this as a retryable failure so the proxy path
        # (higher token ceiling, no CLI truncation) gets a chance to do better.
        if focus_function:
            all_test_text = " ".join(
                t.get("body", "") + " " + t.get("name", "")
                for t in result.get("tests", [])
            )
            if focus_function not in all_test_text:
                last_error = BehavioralGenerationUnavailable(
                    f"Claude ignored focus hint for '{focus_function}' — none of the "
                    f"{len(result.get('tests', []))} generated tests reference it"
                )
                logger.warning(
                    "unit_test_gen.focus_not_referenced",
                    focus_function=focus_function,
                    source=str(source_path),
                    attempt=attempt + 1,
                    test_count=len(result.get("tests", [])),
                )
                continue

        return result

    raise BehavioralGenerationUnavailable(
        f"giving up after {MAX_RETRIES_ON_BAD_JSON + 1} attempts: {last_error}"
    )
