"""AI adapter layer — wraps Claude CLI for repair suggestions.

This module is ONLY used by repair_engine. It must NEVER be imported
from drift_detector (which is deterministic and AI-free).
"""

from .repair_suggestions import (
    suggest_selector_fix,
    suggest_api_update,
    suggest_flow_fix,
)

__all__ = [
    "suggest_selector_fix",
    "suggest_api_update",
    "suggest_flow_fix",
]
