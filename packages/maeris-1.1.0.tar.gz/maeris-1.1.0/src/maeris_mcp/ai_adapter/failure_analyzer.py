"""Deep failure analysis — Claude-powered.

Given a failing unit test (source file, test file, error message, and any
context we already know), produces a structured root-cause report:

  diagnosis      — headline + plain-English explanation + confidence
  expected_vs_actual — what the test asked for vs what it got + why
  timeline       — when it last passed, what's changed since
  fix_suggestions — concrete before/after patches (source OR test)
  impact_radius  — other tests that likely break for the same reason
  steps_taken    — every check Claude ran, surfaced so the user sees the work

Design goals — same as the scenario generator:
  - Reuses the existing Claude CLI subprocess + HTTP proxy plumbing. No
    new auth flow, no new dependency, and the call is made *from* the
    user's machine so source code never crosses the wire to Maeris.
  - Defensive: malformed JSON / empty diagnosis / forbidden patterns all
    raise FailureAnalysisUnavailable so callers can show the raw error
    instead of silently returning garbage.
"""

from __future__ import annotations

import json
import re
import structlog
from pathlib import Path
from typing import Any

from maeris_mcp.ai_adapter.repair_suggestions import (
    _claude_run,
    _direct_ai_run,
    _parse_json,
)

logger = structlog.get_logger()


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------
DEFAULT_MODEL = "claude-sonnet-4-6"
MAX_SOURCE_BYTES = 40_000
MAX_SOURCE_LINES = 600
MAX_TEST_BYTES = 20_000
PROMPT_TIMEOUT_S = 120
MAX_RETRIES_ON_BAD_JSON = 1


class FailureAnalysisUnavailable(RuntimeError):
    """Raised when Claude-powered failure analysis can't run (any reason)."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


# -----------------------------------------------------------------------------
# Prompt — structured, schema-driven.
# -----------------------------------------------------------------------------
_PROMPT_TEMPLATE = """You are a senior JavaScript/TypeScript engineer diagnosing a failing unit test. Produce a thorough, honest root-cause analysis for a non-developer audience, then give concrete fix suggestions.

RULES — hard constraints; violating any makes your output unusable:
1. Output ONLY a JSON object. No prose, no markdown fences, no commentary.
2. Every claim you make about the code must cite a specific line number from the provided source or test. If you cannot cite a line, say so in `confidence` and lower it.
3. Never invent behaviour. If the error message isn't enough to be certain of the cause, say `confidence: "low"` and explain what additional info would resolve it.
4. Keep language plain. A QA lead or PM should understand the diagnosis without needing the error text.
5. `steps_taken` must faithfully record what you actually checked, in order. It is read by the user — it is NOT a performance. Short honest entries beat eloquent ones.
6. No source code in `diagnosis.plain_english` or any narrative field — use `before`/`after` in `fix_suggestions` for code fragments.
7. Prefer source fixes over test fixes UNLESS the test is clearly wrong. If you recommend a test fix, say why in `rationale`.

RESPONSE SCHEMA — return exactly this shape:
{
  "diagnosis": {
    "headline": "<string: ~12 words, plain English, no jargon>",
    "plain_english": "<string: 2-4 sentences explaining what went wrong and why, for a non-developer>",
    "root_cause_file": "<'source' | 'test' | 'unknown'>",
    "root_cause_line": <integer line number, or null>,
    "confidence": "<'high' | 'medium' | 'low'>"
  },
  "expected_vs_actual": {
    "expected": "<string: what the test wanted>",
    "actual": "<string: what actually happened>",
    "why": "<string: one sentence linking actual to the root cause>"
  },
  "fix_suggestions": [
    {
      "target":    "<'source' | 'test'>",
      "file":      "<string: which file to change>",
      "line":      <integer line number>,
      "before":    "<string: the current line(s) of code; keep under 200 chars>",
      "after":     "<string: the proposed replacement; keep under 200 chars>",
      "rationale": "<string: one sentence explaining why this fix works>"
    }
  ],
  "steps_taken": [
    "<string: short factual entry like 'Read source file (47 lines)'>"
  ]
}

CONTEXT:

Test name:       __TEST_NAME__
Source file:     __SOURCE_FILE__
Test file:       __TEST_FILE__
Last run status: __LAST_STATUS__
Last error:      __LAST_ERROR__

SCENARIO (what the test was supposed to verify, if known):
__SCENARIO_BLOCK__

SOURCE CODE (__SOURCE_LINES__ lines):
```__LANGUAGE__
__SOURCE_CODE__
```

TEST CODE (__TEST_LINES__ lines):
```__LANGUAGE__
__TEST_CODE__
```

Now produce the JSON object. Remember: only JSON, nothing else.
"""


# -----------------------------------------------------------------------------
# Input sanitisation + validation
# -----------------------------------------------------------------------------
_FORBIDDEN_PATTERNS = [
    r"\brequire\s*\(\s*['\"]fs['\"]",
    r"\brequire\s*\(\s*['\"]child_process",
    r"\bfetch\s*\(",
    r"\beval\s*\(",
    r"\bnew\s+Function\s*\(",
    r"\bprocess\.exit",
]
_FORBIDDEN_RE = re.compile("|".join(_FORBIDDEN_PATTERNS))

_VALID_CONFIDENCE = frozenset({"high", "medium", "low"})
_VALID_ROOT_CAUSE_FILE = frozenset({"source", "test", "unknown"})
_VALID_FIX_TARGET = frozenset({"source", "test"})


def _annotate_lines(text: str) -> str:
    """Prefix every source line with '<lineno>| ' so Claude can cite lines
    precisely. Stable formatting so the LLM learns what to reference.
    """
    return "\n".join(
        f"{i + 1:4d}| {ln}" for i, ln in enumerate(text.splitlines())
    )


def _truncate(text: str, max_bytes: int, max_lines: int, tag: str) -> str:
    """Cap input at both a byte and a line limit for prompt safety.
    Preserves the head of the file (where exports and imports live).
    """
    lines = text.splitlines()
    note: str | None = None
    if len(lines) > max_lines:
        omitted = len(lines) - max_lines
        lines = lines[:max_lines]
        note = f"    | … truncated, {omitted} {tag} lines omitted"
    text = "\n".join(lines)
    if len(text.encode("utf-8")) > max_bytes:
        trimmed = text.encode("utf-8")[:max_bytes].decode("utf-8", errors="ignore")
        text = trimmed
        note = f"    | … truncated by size ({tag})"
    if note:
        text = text + "\n" + note
    return text


def _safe_read(path: Path, fallback: str = "<not available>") -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return fallback


# -----------------------------------------------------------------------------
# LLM caller (same pattern as the generator)
# -----------------------------------------------------------------------------
def _call_claude(prompt: str, model: str) -> str:
    try:
        return _claude_run(prompt, model=model, timeout=PROMPT_TIMEOUT_S, retries=1)
    except RuntimeError as e:
        logger.warning("failure_analysis.claude_cli_failed", error=str(e)[:200])
    try:
        return _direct_ai_run(prompt, model=model)
    except Exception as e:
        raise FailureAnalysisUnavailable(f"no AI backend available: {e}") from e


# -----------------------------------------------------------------------------
# Response parsing / validation
# -----------------------------------------------------------------------------
def _validate_response(parsed: Any) -> dict:
    """Validate structure and drop garbage fields. Raises
    FailureAnalysisUnavailable if the response is unusable.
    """
    if not isinstance(parsed, dict):
        raise FailureAnalysisUnavailable("response is not a JSON object")

    diagnosis = parsed.get("diagnosis") or {}
    if not isinstance(diagnosis, dict):
        raise FailureAnalysisUnavailable("diagnosis is not an object")
    headline = (diagnosis.get("headline") or "").strip()
    plain = (diagnosis.get("plain_english") or "").strip()
    if not headline or not plain:
        raise FailureAnalysisUnavailable("diagnosis missing headline or explanation")

    confidence = (diagnosis.get("confidence") or "medium").strip().lower()
    if confidence not in _VALID_CONFIDENCE:
        confidence = "medium"
    root_cause_file = (diagnosis.get("root_cause_file") or "unknown").strip().lower()
    if root_cause_file not in _VALID_ROOT_CAUSE_FILE:
        root_cause_file = "unknown"

    root_line_raw = diagnosis.get("root_cause_line")
    try:
        root_cause_line = int(root_line_raw) if root_line_raw is not None else None
    except (TypeError, ValueError):
        root_cause_line = None

    # expected_vs_actual — always present, empty strings allowed
    eva = parsed.get("expected_vs_actual") or {}
    if not isinstance(eva, dict):
        eva = {}
    expected = (eva.get("expected") or "").strip()[:1000]
    actual = (eva.get("actual") or "").strip()[:1000]
    why = (eva.get("why") or "").strip()[:400]

    # fix_suggestions — validated individually, bad entries dropped
    fixes_in = parsed.get("fix_suggestions") or []
    fixes: list[dict] = []
    if isinstance(fixes_in, list):
        for entry in fixes_in:
            if not isinstance(entry, dict):
                continue
            target = (entry.get("target") or "").strip().lower()
            if target not in _VALID_FIX_TARGET:
                continue
            before = (entry.get("before") or "").strip()
            after = (entry.get("after") or "").strip()
            if not before and not after:
                continue
            # Guard against LLM stuffing dangerous patterns into `after`.
            if _FORBIDDEN_RE.search(after):
                logger.info("failure_analysis.dropped_fix",
                            reason="forbidden pattern in 'after'")
                continue
            if len(before) > 600 or len(after) > 600:
                # Too long — we're meant to show one-line fixes; longer
                # than this usually means the LLM misread the prompt.
                continue
            try:
                line = int(entry.get("line")) if entry.get("line") is not None else None
            except (TypeError, ValueError):
                line = None
            fixes.append({
                "target": target,
                "file": (entry.get("file") or "").strip()[:300],
                "line": line,
                "before": before[:600],
                "after": after[:600],
                "rationale": (entry.get("rationale") or "").strip()[:400],
            })

    # steps_taken — trimmed, non-empty strings only
    steps_in = parsed.get("steps_taken") or []
    steps: list[str] = []
    if isinstance(steps_in, list):
        for s in steps_in:
            if isinstance(s, str) and s.strip():
                steps.append(s.strip()[:300])
    steps = steps[:20]  # hard cap

    return {
        "diagnosis": {
            "headline": headline[:200],
            "plain_english": plain[:1500],
            "root_cause_file": root_cause_file,
            "root_cause_line": root_cause_line,
            "confidence": confidence,
        },
        "expected_vs_actual": {
            "expected": expected,
            "actual": actual,
            "why": why,
        },
        "fix_suggestions": fixes[:5],  # at most 5 — keeps UI focused
        "steps_taken": steps,
    }


# -----------------------------------------------------------------------------
# Public entry point
# -----------------------------------------------------------------------------
def analyze_test_failure(
    source_path: Path,
    test_path: Path,
    test_name: str,
    last_status: str | None,
    last_error: str | None,
    language: str = "javascript",
    scenario: dict | None = None,
    *,
    model: str = DEFAULT_MODEL,
) -> dict:
    """Produce a structured root-cause report for one failing test.

    Raises FailureAnalysisUnavailable on any recoverable failure; callers
    should surface the reason to the user and show the raw error as
    fallback.
    """
    source_text = _safe_read(source_path)
    test_text = _safe_read(test_path)

    source_line_count = len(source_text.splitlines())
    test_line_count = len(test_text.splitlines())

    # Annotate each line with its line number so Claude can cite precisely
    # and drop lines Claude couldn't see (truncation) rather than invent them.
    source_trunc = _truncate(source_text, MAX_SOURCE_BYTES, MAX_SOURCE_LINES, "source")
    test_trunc = _truncate(test_text, MAX_TEST_BYTES, MAX_SOURCE_LINES, "test")
    source_annotated = _annotate_lines(source_trunc)
    test_annotated = _annotate_lines(test_trunc)

    # Give Claude enough context about the scenario so it can reason about
    # intent, not just the surface symptom.
    if scenario:
        scenario_block = (
            f"  category:  {scenario.get('category', 'unknown')}\n"
            f"  condition: {scenario.get('condition', '')}\n"
            f"  expected:  {scenario.get('expected', '')}"
        )
    else:
        scenario_block = "  (no scenario metadata available)"

    # Sentinel-based template substitution — safer than .format() given
    # the source itself is full of `{` / `}` braces.
    prompt = (
        _PROMPT_TEMPLATE
        .replace("__TEST_NAME__", test_name or "<unnamed test>")
        .replace("__SOURCE_FILE__", source_path.name)
        .replace("__TEST_FILE__", test_path.name)
        .replace("__LAST_STATUS__", last_status or "failed")
        .replace("__LAST_ERROR__", (last_error or "(no error message recorded)")[:2000])
        .replace("__SCENARIO_BLOCK__", scenario_block)
        .replace("__SOURCE_LINES__", str(source_line_count))
        .replace("__TEST_LINES__", str(test_line_count))
        .replace("__LANGUAGE__", language or "javascript")
        .replace("__SOURCE_CODE__", source_annotated)
        .replace("__TEST_CODE__", test_annotated)
    )

    last_error_reason: str | None = None
    for attempt in range(MAX_RETRIES_ON_BAD_JSON + 1):
        raw = _call_claude(prompt, model=model)
        try:
            parsed = _parse_json(raw)
        except (ValueError, json.JSONDecodeError) as e:
            last_error_reason = f"malformed JSON: {e}"
            logger.warning("failure_analysis.parse_failed",
                           attempt=attempt + 1, reason=last_error_reason)
            continue
        try:
            return _validate_response(parsed)
        except FailureAnalysisUnavailable as e:
            last_error_reason = e.reason
            logger.warning("failure_analysis.validation_failed",
                           attempt=attempt + 1, reason=last_error_reason)
            continue

    raise FailureAnalysisUnavailable(
        f"giving up after {MAX_RETRIES_ON_BAD_JSON + 1} attempts: {last_error_reason}"
    )
