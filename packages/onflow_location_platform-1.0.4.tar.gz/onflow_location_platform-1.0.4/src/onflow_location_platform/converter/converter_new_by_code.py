import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Union

from ..parser.objects import AdminUnit
from ..parser.utils import key_normalize, unicode_normalize


MODULE_DIR = Path(__file__).parent.parent

with open(MODULE_DIR / "data/converter_2025.json", "r", encoding="utf-8") as f:
    converter_data = json.load(f)

with open(MODULE_DIR / "data/parser_legacy.json", "r", encoding="utf-8") as f:
    parser_legacy_data = json.load(f)

with open(MODULE_DIR / "data/parser_from_2025.json", "r", encoding="utf-8") as f:
    parser_2025_data = json.load(f)


DICT_PROVINCE = converter_data["DICT_PROVINCE"]
DICT_PROVINCE_WARD_NO_DIVIDED = converter_data["DICT_PROVINCE_WARD_NO_DIVIDED"]
DICT_PROVINCE_WARD_DIVIDED = converter_data["DICT_PROVINCE_WARD_DIVIDED"]

LEGACY_DICT_PROVINCE = parser_legacy_data["DICT_PROVINCE"]
LEGACY_DICT_PROVINCE_DISTRICT = parser_legacy_data["DICT_PROVINCE_DISTRICT"]
LEGACY_DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED = parser_legacy_data[
    "DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED"
]
LEGACY_DICT_PROVINCE_DISTRICT_WARD_ACCENTED = parser_legacy_data[
    "DICT_PROVINCE_DISTRICT_WARD_ACCENTED"
]

NEW_DICT_PROVINCE = parser_2025_data["DICT_PROVINCE"]
NEW_DICT_PROVINCE_WARD_NO_ACCENTED = parser_2025_data["DICT_PROVINCE_WARD_NO_ACCENTED"]
NEW_DICT_PROVINCE_WARD_ACCENTED = parser_2025_data["DICT_PROVINCE_WARD_ACCENTED"]
NEW_DICT_PROVINCE_WARD_SHORT_ACCENTED = parser_2025_data[
    "DICT_PROVINCE_WARD_SHORT_ACCENTED"
]

OPS_NH_DATA_DIR = MODULE_DIR / "data" / "ops"
PK_ID = Union[str, int]


# ---------------------------------------------------------------------------
# Internal helpers: data loading
# ---------------------------------------------------------------------------

def _normalize_pk_id(pk_id: PK_ID, width: int) -> str:
    pk_str = str(pk_id).strip()
    if not pk_str:
        raise ValueError("pk_id must not be empty")
    if not pk_str.isdigit():
        raise ValueError(f"pk_id must contain only digits, got {pk_id!r}")
    return pk_str.zfill(width)


def _keyword_from_code_name(code_name: str | None) -> str | None:
    if not code_name:
        return None
    return code_name.replace("_", "")


def _load_ops_records(filename: str, width: int) -> dict[str, dict[str, Any]]:
    path = OPS_NH_DATA_DIR / filename
    if not path.exists():
        return {}

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    records = {}
    for item in data:
        pk = _normalize_pk_id(item["pk"], width)
        fields = dict(item.get("fields", {}))
        fields["pk"] = pk
        records[pk] = fields
    return records


@lru_cache(maxsize=1)
def _ops_provinces() -> dict[str, dict[str, Any]]:
    return _load_ops_records("ops_nh_provinces.json", width=2)


@lru_cache(maxsize=1)
def _ops_districts() -> dict[str, dict[str, Any]]:
    return _load_ops_records("ops_nh_districts.json", width=3)


@lru_cache(maxsize=1)
def _ops_wards() -> dict[str, dict[str, Any]]:
    return _load_ops_records("ops_nh_wards.json", width=5)


@lru_cache(maxsize=1)
def _ops_administrative_regions() -> dict[str, dict[str, Any]]:
    return _load_ops_records("ops_nh_administrative_regions.json", width=1)


@lru_cache(maxsize=1)
def _ops_administrative_units() -> dict[str, dict[str, Any]]:
    return _load_ops_records("ops_nh_administrative_units.json", width=1)


@lru_cache(maxsize=1)
def _build_legacy_code_indexes() -> dict[str, dict[str, dict[str, Any]]]:
    provinces: dict[str, dict[str, Any]] = {}
    districts: dict[str, dict[str, Any]] = {}
    wards_no_accented: dict[str, dict[str, Any]] = {}
    wards_accented: dict[str, dict[str, Any]] = {}

    for province_key, province_value in LEGACY_DICT_PROVINCE.items():
        province_code = province_value["provinceCode"]
        provinces[province_code] = {
            "legacy_province_key": province_key,
            "province_code": province_code,
            "province": province_value["province"],
            "short_province": province_value["provinceShort"],
            "province_keywords": province_value["provinceKeywords"],
        }

    for province_key, districts_value in LEGACY_DICT_PROVINCE_DISTRICT.items():
        for district_key, district_value in districts_value.items():
            district_code = district_value["districtCode"]
            districts[district_code] = {
                "legacy_province_key": province_key,
                "legacy_district_key": district_key,
                "district_code": district_code,
                "district": district_value["district"],
                "short_district": district_value["districtShort"],
                "district_keywords": district_value["districtKeywords"],
            }

    for province_key, districts_value in LEGACY_DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED.items():
        for district_key, wards_value in districts_value.items():
            for ward_key, ward_value in wards_value.items():
                ward_code = ward_value["wardCode"]
                wards_no_accented[ward_code] = {
                    "legacy_province_key": province_key,
                    "legacy_district_key": district_key,
                    "legacy_ward_key": ward_key,
                    "ward_code": ward_code,
                    "ward": ward_value["ward"],
                    "short_ward": ward_value["wardShort"],
                    "ward_keywords": ward_value["wardKeywords"],
                }
                
    for province_key, districts_value in LEGACY_DICT_PROVINCE_DISTRICT_WARD_ACCENTED.items():
        for district_key, wards_value in districts_value.items():
            for ward_key, ward_value in wards_value.items():
                ward_code = ward_value["wardCode"]
                wards_accented[ward_code] = {
                    "legacy_province_key": province_key,
                    "legacy_district_key": district_key,
                    "legacy_ward_key": ward_key,
                    "ward_code": ward_code,
                    "ward": ward_value["ward"],
                    "short_ward": ward_value["wardShort"],
                    "ward_keywords": ward_value["wardKeywords"],
                } 

    return {
        "provinces": provinces,
        "districts": districts,
        "wards_no_accented": wards_no_accented,
        "wards_accented": wards_accented,
    }


# ---------------------------------------------------------------------------
# Internal helpers: 2025 metadata resolution
# ---------------------------------------------------------------------------

def _new_province_keys_for_old_province(old_province_key: str) -> list[str]:
    return sorted(
        new_province_key
        for new_province_key, old_province_keys in DICT_PROVINCE.items()
        if old_province_key in old_province_keys
    )


def _new_province_metadata(new_province_key: str) -> dict[str, Any] | None:
    province_info = NEW_DICT_PROVINCE.get(new_province_key)
    if not province_info:
        return None
    return {
        "provinceKey": new_province_key,
        **province_info,
    }


def _new_ward_metadata(new_province_key: str, new_ward_key: str) -> dict[str, Any] | None:
    for dataset in (
        NEW_DICT_PROVINCE_WARD_NO_ACCENTED,
        NEW_DICT_PROVINCE_WARD_ACCENTED,
        NEW_DICT_PROVINCE_WARD_SHORT_ACCENTED,
    ):
        ward_info = dataset.get(new_province_key, {}).get(new_ward_key)
        if ward_info:
            return {
                "wardKey": new_ward_key,
                **ward_info,
            }
    return None


# ---------------------------------------------------------------------------
# Internal helpers: keyword matching (for fallback ops-based resolution)
# ---------------------------------------------------------------------------

def _candidate_keywords(*values: Any) -> set[str]:
    candidates = set()
    for value in values:
        if not value or not isinstance(value, str):
            continue
        normalized = key_normalize(unicode_normalize(value))
        if normalized:
            candidates.add(normalized)
    return candidates

def _best_match_district(data_dict: dict, district_pk: str, legacy_province_key: str):
    for (
        district_key, 
        parser_district_info
    ) in data_dict.get(legacy_province_key, {}).items():
        
        if str(parser_district_info.get("districtCode")) == str(district_pk):
            return{
                "legacy_province_key": legacy_province_key,
                "legacy_district_key": district_key,
                "district_code": parser_district_info["districtCode"],
                "district": parser_district_info["district"],
                "short_district": parser_district_info["districtShort"],
                "district_keywords": parser_district_info["districtKeywords"],
            }
    return None

def _resolve_legacy_district_info(district_pk: str) -> dict[str, Any]:
    district_info = _build_legacy_code_indexes()["districts"].get(district_pk)
    if district_info:
        return district_info

    ops_info = _ops_districts().get(district_pk)
    if not ops_info:
        raise KeyError(f"Unknown legacy district pk_id: {district_pk}")

    province_info = _build_legacy_code_indexes()["provinces"].get(
        ops_info["province_code"]
    )
    if not province_info:
        raise KeyError(
            f"Cannot resolve province_code={ops_info['province_code']} for district pk_id {district_pk}"
        )

    legacy_province_key = province_info["legacy_province_key"]
    best_match = _best_match_district(LEGACY_DICT_PROVINCE_DISTRICT, district_pk, legacy_province_key)
    if best_match:
        return best_match
    raise KeyError(f"Unknown legacy district pk_id: {district_pk}")

def _best_match_ward(data_dict: dict, ward_pk: str, legacy_province_key: str, legacy_district_key: str):
    for (
        ward_key, 
        parser_ward_info
    ) in data_dict.get(legacy_province_key, {}).get(legacy_district_key, {}).items():
        
        if str(parser_ward_info.get("wardCode")) == str(ward_pk):
            return {
                "legacy_province_key": legacy_province_key,
                "legacy_district_key": legacy_district_key,
                "legacy_ward_key": ward_key,
                "ward_code": parser_ward_info["wardCode"],
                "ward": parser_ward_info["ward"],
                "short_ward": parser_ward_info["wardShort"],
                "ward_keywords": parser_ward_info["wardKeywords"],
            }
    return None

def _resolve_legacy_ward_info(ward_pk: str) -> dict[str, Any]:
    ward_info = _build_legacy_code_indexes()["wards_no_accented"].get(ward_pk)
    if ward_info:
        return ward_info
    
    ward_info = _build_legacy_code_indexes()["wards_accented"].get(ward_pk)
    if ward_info:
        return ward_info
    
    raise KeyError(f"Unknown legacy ward pk_id: {ward_pk}")

# ---------------------------------------------------------------------------
# Internal helpers: resolve 2025 ward+province from a composite legacy key
# ---------------------------------------------------------------------------

def _resolve_new_admin_unit(
    legacy_composite_key: str,
    new_province_keys: list[str],
    address: str | None = None
) -> AdminUnit | None:
    """
    Given a legacy composite key and the candidate 2025 province keys,
    return an AdminUnit with the resolved 2025 ward and province.
    Prefers no_divided (1-to-1); falls back to divided (isDefaultNewWard).
    Returns None if no mapping found.
    """
    for new_province_key in new_province_keys:
        # no_divided: one legacy ward maps to exactly one new ward
        for new_ward_key, old_keys in DICT_PROVINCE_WARD_NO_DIVIDED.get(new_province_key, {}).items():
            if legacy_composite_key in old_keys:
                ward_meta = _new_ward_metadata(new_province_key, new_ward_key)
                province_meta = _new_province_metadata(new_province_key)
                if ward_meta and province_meta:
                    return AdminUnit(
                        address=address,
                        street=address,
                        ward=ward_meta.get("ward"),
                        short_ward=ward_meta.get("wardShort"),
                        ward_type=ward_meta.get("wardType"),
                        ward_code=ward_meta.get("wardCode"),
                        ward_key=new_ward_key,
                        province=province_meta.get("province"),
                        short_province=province_meta.get("provinceShort"),
                        province_code=province_meta.get("provinceCode"),
                        province_key=new_province_key,
                        latitude=ward_meta.get("wardLat"),
                        longitude=ward_meta.get("wardLon"),
                    )

        # divided: one legacy ward maps to multiple new wards; pick the default one
        new_ward_entries = DICT_PROVINCE_WARD_DIVIDED\
            .get(new_province_key, {})\
            .get(legacy_composite_key, [])
            
        for entry in new_ward_entries:
            if entry.get("isDefaultNewWard") and entry.get("newWardKey"):
                new_ward_key = entry["newWardKey"]
                ward_meta = _new_ward_metadata(new_province_key, new_ward_key)
                province_meta = _new_province_metadata(new_province_key)
                if ward_meta and province_meta:
                    return AdminUnit(
                        address=address,
                        street=address,
                        ward=ward_meta.get("ward"),
                        short_ward=ward_meta.get("wardShort"),
                        ward_type=ward_meta.get("wardType"),
                        ward_code=ward_meta.get("wardCode"),
                        ward_key=new_ward_key,
                        province=province_meta.get("province"),
                        short_province=province_meta.get("provinceShort"),
                        province_code=province_meta.get("provinceCode"),
                        province_key=new_province_key,
                        latitude=ward_meta.get("wardLat"),
                        longitude=ward_meta.get("wardLon"),
                    )

    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def convert_province_old_to_new_by_code(pk_id: PK_ID) -> AdminUnit:
    """
    Resolve a legacy province pk_id to the corresponding 2025 province.
    Returns an AdminUnit with province fields populated.
    """
    province_pk = _normalize_pk_id(pk_id, width=2)
    province_info = _build_legacy_code_indexes()["provinces"].get(province_pk)
    if not province_info:
        raise KeyError(f"Unknown legacy province pk_id: {province_pk}")

    new_province_keys = _new_province_keys_for_old_province(
        province_info["legacy_province_key"]
    )
    if not new_province_keys:
        raise KeyError(f"No 2025 mapping found for province pk_id: {province_pk}")

    # A legacy province always maps to exactly one 2025 province
    new_province_key = new_province_keys[0]
    province_meta = _new_province_metadata(new_province_key)
    if not province_meta:
        raise KeyError(f"No 2025 province metadata for key: {new_province_key}")

    return AdminUnit(
        province=province_meta.get("province"),
        short_province=province_meta.get("provinceShort"),
        province_code=province_meta.get("provinceCode"),
        province_key=new_province_key,
        latitude=province_meta.get("provinceLat"),
        longitude=province_meta.get("provinceLon"),
    )


def convert_district_old_to_new_by_code(pk_id: PK_ID) -> AdminUnit:
    """
    Resolve a legacy district pk_id to the corresponding 2025 province.
    Returns an AdminUnit with province fields populated.
    (Districts do not exist in the 2025 format; only the province is returned.)
    """
    district_pk = _normalize_pk_id(pk_id, width=3)
    district_info = _resolve_legacy_district_info(district_pk)

    new_province_keys = _new_province_keys_for_old_province(
        district_info["legacy_province_key"]
    )
    if not new_province_keys:
        raise KeyError(f"No 2025 mapping found for district pk_id: {district_pk}")

    new_province_key = new_province_keys[0]
    province_meta = _new_province_metadata(new_province_key)
    if not province_meta:
        raise KeyError(f"No 2025 province metadata for key: {new_province_key}")

    return AdminUnit(
        province=province_meta.get("province"),
        short_province=province_meta.get("provinceShort"),
        province_code=province_meta.get("provinceCode"),
        province_key=new_province_key,
        latitude=province_meta.get("provinceLat"),
        longitude=province_meta.get("provinceLon"),
    )


def convert_ward_old_to_new_by_code(pk_id: PK_ID) -> AdminUnit:
    """
    Resolve a legacy ward pk_id to the corresponding 2025 ward and province.
    Returns an AdminUnit with ward and province fields populated.
    """
    ward_pk = _normalize_pk_id(pk_id, width=5)
    ward_info = _resolve_legacy_ward_info(ward_pk)

    legacy_province_key = ward_info["legacy_province_key"]
    legacy_district_key = ward_info["legacy_district_key"]
    legacy_ward_key = ward_info["legacy_ward_key"]
    legacy_composite_key = f"{legacy_province_key}_{legacy_district_key}_{legacy_ward_key}"

    new_province_keys = _new_province_keys_for_old_province(legacy_province_key)

    result = _resolve_new_admin_unit(legacy_composite_key, new_province_keys)
    if result is None:
        raise KeyError(
            f"No 2025 mapping found for ward {ward_pk} "
            f"(composite key: {legacy_composite_key})"
        )
    return result


def convert_address_old_to_new_by_code(
    provide_code: PK_ID,
    district_code: PK_ID,
    ward_code: PK_ID,
    address: str | None = None,
) -> AdminUnit:
    """
    Look up all 3 legacy codes (province, district, ward) and return the
    corresponding 2025 ward and province as an AdminUnit.

    Args:
        provide_code: Legacy province code (e.g. 79 for Ho Chi Minh City).
        district_code: Legacy district code (e.g. 123 for Tan Binh District).
        ward_code: Legacy ward code (e.g. 766 for Tan Son Hoa Ward).

    Returns:
        AdminUnit with ward and province fields populated in the 2025 format.

    Raises:
        KeyError: If any code is not found or has no 2025 mapping.
        ValueError: If the district does not belong to the given province,
                    or the ward does not belong to the given district.
    """
    province_pk = _normalize_pk_id(provide_code, width=2)
    district_pk = _normalize_pk_id(district_code, width=3)
    ward_pk = _normalize_pk_id(ward_code, width=5)

    # Validate province exists
    province_index = _build_legacy_code_indexes()["provinces"].get(province_pk)
    if not province_index:
        raise KeyError(f"Unknown legacy province code: {province_pk}")

    # Validate district belongs to the given province
    district_info = _resolve_legacy_district_info(district_pk)
    expected_province_code = LEGACY_DICT_PROVINCE[district_info["legacy_province_key"]][
        "provinceCode"
    ]
    if expected_province_code != province_pk:
        raise ValueError(
            f"District {district_pk} does not belong to province {province_pk}"
        )

    # Validate ward belongs to the given district
    ward_info = _resolve_legacy_ward_info(ward_pk)
    expected_district_code = LEGACY_DICT_PROVINCE_DISTRICT\
        .get(ward_info["legacy_province_key"], {})\
        .get(ward_info["legacy_district_key"], {})\
        .get("districtCode")
    
    if expected_district_code != district_pk:
        raise ValueError(
            f"Ward {ward_pk} does not belong to district {district_pk}"
        )

    # Build the legacy composite key for mapping lookup
    legacy_province_key = ward_info["legacy_province_key"]
    legacy_district_key = ward_info["legacy_district_key"]
    legacy_ward_key = ward_info["legacy_ward_key"]
    legacy_composite_key = f"{legacy_province_key}_{legacy_district_key}_{legacy_ward_key}"
    # Get new province keys
    new_province_keys = _new_province_keys_for_old_province(legacy_province_key)
    # Resolve 2025 admin unit
    result = _resolve_new_admin_unit(legacy_composite_key, new_province_keys, address)
    if result is None:
        raise KeyError(
            f"No 2025 mapping found for ward {ward_pk} "
            f"(composite key: {legacy_composite_key})"
        )
    return result
