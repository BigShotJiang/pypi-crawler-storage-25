from typing import Union
from .parser.objects import AdminUnit
from .parser import parse_address_new, parse_address_old
from .converter import (
    convert_address_new_to_old,
    convert_address_old_to_new,
    convert_address_old_to_new_by_code,
    convert_province_old_to_new_by_code,
    convert_district_old_to_new_by_code,
    convert_ward_old_to_new_by_code
)

class OnFlowLocation:
    """
    Unified entry point for OnFlow Location Platform operations.
    Supports parsing and converting Vietnamese addresses and codes.
    
    :param address: Optional[str] - The address to parse or convert (can be new format or old format)
        *address not provided, CAN NOT USE
            parse_address_new
            parse_address_old
            convert_address_new_to_old
            convert_address_old_to_new
            
    :param multi_match: Optional[str] - The multi-match strategy to use for address conversion, default is "geo"
    
    :param street: Optional[str] - The street to use for address conversion, default is None
    
    :param provide_code: Optional[str] - The old province code to use for address conversion, default is None
        *provide_code not provided, CAN NOT USE 
            convert_address_old_to_new_by_code
            convert_province_old_to_new_by_code
    
    :param district_code: Optional[str] - The old district code to use for address conversion, default is None
        *district_code not provided, CAN NOT USE 
            convert_address_old_to_new_by_code
            convert_district_old_to_new_by_code
    
    :param ward_code: Optional[str] - The old ward code to use for address conversion, default is None
        *ward_code not provided, CAN NOT USE 
            convert_address_old_to_new_by_code
            convert_ward_old_to_new_by_code
    
    :param keep_street: bool - Whether to keep the street in the converted address, default is True
    
    :param level_address_new: int - The level of address to use for address conversion, default is 2
    
    :param level_address_old: int - The level of address to use for address conversion, default is 3
    """
    def __init__(
        self,
        address: str | None = None,
        multi_match: str = "geo",
        street: str | None = None,
        provide_code: str | int | None = None,
        district_code: str | int | None = None,
        ward_code: str | int | None = None,
        keep_street: bool = True,
        level_address_new: int = 2,
        level_address_old: int = 3,
    ):
        self.address = address
        self.multi_match = multi_match
        self.street = street
        self.provide_code = provide_code
        self.district_code = district_code
        self.ward_code = ward_code
        self.keep_street = keep_street
        self.level_address_new = level_address_new
        self.level_address_old = level_address_old
        

    @property
    def parse_address_new(self) -> AdminUnit:
        '''
        Parse an 34-province address to an AdminUnit object.
        :return: AdminUnit object.
        '''
        if not self.address:
            raise ValueError("address is not provided")
        
        return parse_address_new(
            address=self.address,
            keep_street=self.keep_street,
            level=self.level_address_new
        )

    @property
    def parse_address_old(self) -> AdminUnit:
        """Parse a old-format address."""
        if not self.address:
            raise ValueError("address is not provided")
        
        return parse_address_old(
            address=self.address,
            keep_street=self.keep_street,
            level=self.level_address_old
        )

    @property
    def convert_address_new_to_old(self) -> Union[AdminUnit, list[AdminUnit]]:
        """
        Strict reverse converter from new address -> old address.

        Rules:
        - Must start from a valid new province. If no new province -> return empty AdminUnit/list.
        - Province-only input returns mapped old province(s).
        - Full input (ward + province) maps by converter data.
        - When multiple old units match, the strategy is selected by `multi_match`:
        'first' returns the first match -> AdminUnit
        'geo' uses geolocation -> AdminUnit
        'all' returns all matches -> list of AdminUnit
        """
        if not self.address:
            raise ValueError("address is not provided")
        
        return convert_address_new_to_old(
            address=self.address,
            multi_match=self.multi_match
        )

    @property
    def convert_address_old_to_new(self) -> AdminUnit:
        '''
        Convert address from old format to new format based on the Vietnam administrative unit changes in new
        '''
        if not self.address:
            raise ValueError("address is not provided")
        
        return convert_address_old_to_new(address=self.address)

    @property
    def convert_address_old_to_new_by_code(self) -> AdminUnit:
        """
        Look up all 3 old codes (province, district, ward) and return the
        corresponding new ward and province as an AdminUnit.

        Using
            provide_code: Legacy province code (e.g. 79 for Ho Chi Minh City).
            district_code: Legacy district code (e.g. 123 for Tan Binh District).
            ward_code: Legacy ward code (e.g. 766 for Tan Son Hoa Ward).

        :return: AdminUnit with ward and province fields populated in the new format.
        """
        if not self.provide_code or not self.district_code or not self.ward_code:
            raise ValueError("provide_code, district_code, ward_code are required")
        
        return convert_address_old_to_new_by_code(
            provide_code=self.provide_code,
            district_code=self.district_code,
            ward_code=self.ward_code,
            address=self.street
        )

    @property
    def convert_province_old_to_new_by_code(self) -> AdminUnit:
        """
        Resolve a old province pk_id to the corresponding new province.
        Returns an AdminUnit with province fields populated.
        """
        if not self.provide_code:
            raise ValueError("provide_code is not provided")
        
        return convert_province_old_to_new_by_code(pk_id=self.provide_code)

    @property
    def convert_district_old_to_new_by_code(self) -> AdminUnit:
        """
        Resolve a old district pk_id to the corresponding new province.
        Returns an AdminUnit with province fields populated.
        (Districts do not exist in the new format; only the province is returned.)
        """
        if not self.district_code:
            raise ValueError("district_code is not provided")
        
        return convert_district_old_to_new_by_code(pk_id=self.district_code)

    @property
    def convert_ward_old_to_new_by_code(self) -> AdminUnit:
        """
        Resolve a old ward pk_id to the corresponding new ward and province.
        Returns an AdminUnit with ward and province fields populated.
        """
        if not self.ward_code:
            raise ValueError("ward_code is not provided")
        
        return convert_ward_old_to_new_by_code(pk_id=self.ward_code)
