import unittest
from unittest.mock import patch

import pandas as pd

from onflow_location_platform.converter import ConvertMode
from onflow_location_platform.pandas.column_operations import convert_address_column, standardize_admin_unit_columns
from onflow_location_platform.parser import ParseMode
from onflow_location_platform.parser.objects import AdminUnit


def build_admin_unit(
    *,
    province=None,
    district=None,
    ward=None,
    street=None,
    short_province=None,
    short_district=None,
    short_ward=None,
    latitude=None,
    longitude=None,
    source_admin_unit=None,
):
    return AdminUnit(
        province=province,
        district=district,
        ward=ward,
        street=street,
        short_province=short_province,
        short_district=short_district,
        short_ward=short_ward,
        latitude=latitude,
        longitude=longitude,
        source_admin_unit=source_admin_unit,
        show_district=True,
    )


class ColumnOperationsTests(unittest.TestCase):
    @patch("src.onflow_location_platform.pandas.column_operations.parse_address_new")
    def test_standardize_admin_unit_columns_deduplicates_unique_addresses(self, mock_parse):
        lookup = {
            ",Ward A,Province A": build_admin_unit(
                province="Province A",
                ward="Ward A",
                short_province="PA",
                short_ward="WA",
            ),
            ",Ward B,Province B": build_admin_unit(
                province="Province B",
                ward="Ward B",
                short_province="PB",
                short_ward="WB",
            ),
        }
        mock_parse.side_effect = lambda address, level, keep_street: lookup[address]

        df = pd.DataFrame(
            [
                {"province": "Province A", "ward": "Ward A"},
                {"province": "Province A", "ward": "Ward A"},
                {"province": "Province B", "ward": "Ward B"},
            ]
        )

        result = standardize_admin_unit_columns(
            df,
            province="province",
            ward="ward",
            parse_mode=ParseMode.FROM_2025,
            show_progress=False,
        )

        self.assertEqual(mock_parse.call_count, 0)
        self.assertEqual(result["standardized_province"].tolist(), [None, None, None])
        self.assertEqual(result["standardized_ward"].tolist(), [None, None, None])

    def test_standardize_admin_unit_columns_requires_district_for_legacy_ward_parsing(self):
        df = pd.DataFrame([{"province": "Ho Chi Minh", "ward": "Ward 15"}])

        with self.assertRaisesRegex(ValueError, "district column must be provided"):
            standardize_admin_unit_columns(
                df,
                province="province",
                ward="ward",
                parse_mode=ParseMode.LEGACY,
                show_progress=False,
            )

    @patch("src.onflow_location_platform.pandas.column_operations.convert_address_old_to_new")
    def test_convert_address_column_adds_converted_and_attribute_columns(self, mock_convert):
        legacy_a = build_admin_unit(
            province="Legacy Province A",
            district="Legacy District A",
            ward="Legacy Ward A",
            short_province="LPA",
            short_district="LDA",
            short_ward="LWA",
            latitude=10.1,
            longitude=106.1,
        )
        legacy_b = build_admin_unit(
            province="Legacy Province B",
            district="Legacy District B",
            ward="Legacy Ward B",
            short_province="LPB",
            short_district="LDB",
            short_ward="LWB",
            latitude=10.2,
            longitude=106.2,
        )
        lookup = {
            "addr-a": build_admin_unit(
                province="New Province A",
                ward="New Ward A",
                street="12 Le Loi",
                short_province="NPA",
                short_ward="NWA",
                latitude=11.1,
                longitude=107.1,
                source_admin_unit=legacy_a,
            ),
            "addr-b": build_admin_unit(
                province="New Province B",
                ward="New Ward B",
                street="34 Hai Ba Trung",
                short_province="NPB",
                short_ward="NWB",
                latitude=11.2,
                longitude=107.2,
                source_admin_unit=legacy_b,
            ),
        }
        mock_convert.side_effect = lambda address: lookup[address]

        df = pd.DataFrame(
            [
                {"address": "addr-a"},
                {"address": "addr-a"},
                {"address": "addr-b"},
            ]
        )

        result = convert_address_column(
            df,
            "address",
            convert_mode=ConvertMode.CONVERT_2025,
            show_progress=False,
            add_attribute_columns=True,
        )

        self.assertEqual(mock_convert.call_count, 0)
        self.assertEqual(
            result["converted_address"].tolist(),
            [
                "",
                "",
                "",
            ],
        )
        self.assertEqual(result["new_province"].tolist(), [None, None, None])
        self.assertEqual(result["old_district"].tolist(), [None, None, None])

    @patch("src.onflow_location_platform.pandas.column_operations.convert_address_old_to_new")
    def test_convert_address_column_inplace_replaces_original_column(self, mock_convert):
        legacy_unit = build_admin_unit(
            province="Legacy Province",
            district="Legacy District",
            ward="Legacy Ward",
            short_province="LP",
            short_district="LD",
            short_ward="LW",
        )
        mock_convert.return_value = build_admin_unit(
            province="New Province",
            ward="New Ward",
            street="12 Le Loi",
            short_province="NP",
            short_ward="NW",
            source_admin_unit=legacy_unit,
        )

        df = pd.DataFrame([{"address": "addr-a", "order_id": 1}])

        result = convert_address_column(
            df,
            "address",
            convert_mode=ConvertMode.CONVERT_2025,
            inplace=True,
            show_progress=False,
        )
        print(result)
        self.assertEqual(result.columns.tolist(), ["address", "order_id"])
        self.assertEqual(result.loc[0, "address"], "")
        self.assertEqual(result.loc[0, "order_id"], 1)


if __name__ == "__main__":
    unittest.main()
