"""
quill — Adaptive Ultra-Sort
============================
High-performance, general-purpose sorting for Python.

    from quill import quill_sort, quill_sorted, register_plugin

QUICK REFERENCE
---------------
    quill_sort(data)                                 # in-place, integers/floats/strings
    quill_sort(data, key=lambda x: x['score'])       # sort objects by key
    quill_sort(data, reverse=True)                   # descending
    quill_sort(data, inplace=False)                  # returns new list
    quill_sort(data, parallel=True)                  # use all CPU cores

    result = quill_sorted(iterable)                  # mirrors built-in sorted()
    result = quill_sorted(iterable, key=str.lower, reverse=True)

    register_plugin(MyPlugin)                        # add support for custom types
"""

from __future__ import annotations
from typing import Callable, Iterable, Optional

from ._core    import quill_sort_impl
from ._plugins import QuillPlugin, register_plugin, probe_plugins

__version__ = "3.0.4"
__author__  = "Invariant Games"
__all__     = ["quill_sort", "quill_sorted", "QuillPlugin", "register_plugin"]


def quill_sort(
    data     : list,
    key      : Optional[Callable] = None,
    reverse  : bool = False,
    inplace  : bool = True,
    parallel : bool = False,
) -> list:
    """
    Sort `data` using Quill's adaptive ultra-sort engine.

    Quill automatically selects the fastest strategy for your data:
    - Non-negative integers → narrowest-dtype numpy radix (O(n), cache-optimal)
    - Negative integers     → shift to non-negative, radix, shift back
    - Dense int ranges      → counting sort O(n+k)
    - Floats                → numpy optimised introsort
    - Strings / bytes       → Python Timsort (fastest for comparisons)
    - Objects with key      → rank-encode keys → numpy argsort
    - Pre-sorted data       → O(n) detection, immediate return
    - Reverse-sorted        → O(n) detection, single .reverse() call
    - None values           → filtered, sorted, reinserted at end

    Exotic types (pandas Series/DataFrame, numpy arrays, generators) are
    handled automatically via the plugin system — no extra code needed.

    Parameters
    ----------
    data     : list
        The list to sort.  Also accepts lists of pandas objects, numpy arrays,
        generators, or any registered plugin type.
    key      : callable, optional
        Function applied to each element to produce a sort key.
        For pandas DataFrames, pass a column name or list of column names.
    reverse  : bool, default False
        If True, sort in descending order.
    inplace  : bool, default True
        If True (default), sort the list in-place and return it.
        If False, return a new sorted list without modifying the original.
    parallel : bool, default False
        Use all CPU cores.  Recommended for n > 500,000 on 4+ core machines.
        Uses shared memory (zero-copy) for integer data.

    Returns
    -------
    list
        The sorted list (same object if inplace=True).

    Examples
    --------
    >>> quill_sort([3, 1, 4, 1, 5, 9])
    [1, 1, 3, 4, 5, 9]

    >>> records = [{'name': 'Bob', 'age': 25}, {'name': 'Alice', 'age': 30}]
    >>> quill_sort(records, key=lambda r: r['age'])
    [{'name': 'Bob', 'age': 25}, {'name': 'Alice', 'age': 30}]

    >>> quill_sort([3.14, -2.71, 0.0, 1.41])
    [-2.71, 0.0, 1.41, 3.14]

    >>> quill_sort(['banana', 'apple', 'cherry'])
    ['apple', 'banana', 'cherry']

    >>> quill_sort([3, None, 1, None, 2])
    [1, 2, 3, None, None]

    >>> import pandas as pd
    >>> s = pd.Series([3, 1, 4, 1, 5])
    >>> quill_sort(s)                           # returns sorted Series
    """
    if not isinstance(data, list):
        # Non-list input: try plugin system first, then wrap
        from ._plugins import probe_plugins
        result = probe_plugins(data, key, reverse)
        if result is not None:
            items, pk, postprocess = result
            if postprocess and not items:
                return postprocess([])
            sorted_items = quill_sort(items, key=pk, reverse=reverse, inplace=True)
            return postprocess(sorted_items) if postprocess else sorted_items
        # Fall back: materialise to list
        data = list(data)

    return quill_sort_impl(data, key, reverse, inplace, parallel)


def quill_sorted(
    iterable : Iterable,
    key      : Optional[Callable] = None,
    reverse  : bool = False,
    parallel : bool = False,
) -> list:
    """
    Non-mutating Quill sort — mirrors Python's built-in ``sorted()``.

    Parameters
    ----------
    iterable : any iterable
    key      : callable, optional
    reverse  : bool, default False
    parallel : bool, default False

    Returns
    -------
    list — a new sorted list.

    Examples
    --------
    >>> quill_sorted(range(10, 0, -1))
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    >>> quill_sorted(['fig', 'apple', 'kiwi'], key=len)
    ['fig', 'kiwi', 'apple']
    """
    return quill_sort(list(iterable), key=key, reverse=reverse,
                      inplace=True, parallel=parallel)