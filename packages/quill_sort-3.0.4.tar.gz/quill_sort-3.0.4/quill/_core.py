"""
quill/_core.py
--------------
Main strategy dispatcher.  Reads the profiler output and routes to the
optimal sort strategy.  This is the only place that knows about ALL
strategies — the strategies themselves are ignorant of each other.
"""

from __future__ import annotations
from typing import Callable, Optional

from ._profile   import profile as _profile
from ._strategies import (
    insertion_sort, counting_sort,
    numpy_sort_ints, numpy_sort_floats, numpy_sort_by_key,
    pure_radix,
)
from ._plugins import probe_plugins

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

_INSERTION_THRESHOLD = 32


def _identity(x):
    return x


# ─────────────────────────────────────────────────────────────────────────────
# NONE HANDLING
# ─────────────────────────────────────────────────────────────────────────────

def _strip_nones(data: list) -> tuple:
    """
    Remove None values, returning (clean_list, none_count).
    Nones are sorted to the end by default (mirrors Python behaviour).
    """
    nones = sum(1 for x in data if x is None)
    clean = [x for x in data if x is not None]
    return clean, nones


def _reinsert_nones(data: list, none_count: int, reverse: bool) -> None:
    """Put Nones back at the end (ascending) or start (descending)."""
    nones = [None] * none_count
    if reverse:
        data[:] = nones + data
    else:
        data.extend(nones)


# ─────────────────────────────────────────────────────────────────────────────
# SEQUENTIAL DISPATCHER
# ─────────────────────────────────────────────────────────────────────────────

def sort_sequential(data: list, key_fn: Callable, p: dict) -> None:
    n = p["n"]

    if n <= 1:
        return

    if n <= _INSERTION_THRESHOLD:
        insertion_sort(data, key_fn)
        return

    # ── Pre-flight fast exits ─────────────────────────────────────────────────
    if p["all_same"]:
        return
    if p["presorted"]:
        return
    if p["reversed"]:
        data.reverse()
        return

    dtype = p["dtype"]

    # ── Integer fast paths (identity key only) ────────────────────────────────
    if dtype in ("int_pos", "int_neg", "int_mixed") and key_fn is _identity:
        mn = min(data)
        mx = max(data)
        rng = mx - mn

        if rng == 0:
            return                          # all same value
        if rng <= 2 * n:
            counting_sort(data, mn, mx)     # O(n+k) — densest path
            return
        if _NUMPY:
            numpy_sort_ints(data, mn, mx)   # narrowest-dtype numpy radix
            return
        pure_radix(data)                    # precomputed-histogram radix fallback
        return

    # ── Float path ────────────────────────────────────────────────────────────
    if dtype == "float" and key_fn is _identity:
        if _NUMPY:
            numpy_sort_floats(data)
            return
        data.sort()                         # Python's sort handles floats fine
        return

    # ── String / bytes — Python's Timsort is faster than numpy for strings ───
    if dtype in ("str", "bytes") and key_fn is _identity:
        data.sort()
        return

    # ── Object / generic path ─────────────────────────────────────────────────
    if n <= 256:
        data.sort(key=key_fn)
        return
    if _NUMPY:
        numpy_sort_by_key(data, key_fn)
        return
    data.sort(key=key_fn)


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC SORT ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def quill_sort_impl(
    data     : list,
    key      : Optional[Callable],
    reverse  : bool,
    inplace  : bool,
    parallel : bool,
) -> list:
    n = len(data)
    if n <= 1:
        return data if inplace else data[:]

    work   = data if inplace else data[:]
    key_fn = key if key is not None else _identity

    # ── Plugin probe: autonomous support for exotic types ─────────────────────
    if work and not isinstance(work[0], (int, float, str, bytes, type(None))):
        plugin_result = probe_plugins(work, key, reverse)
        if plugin_result is not None:
            items, pk, postprocess = plugin_result
            if postprocess and not items:
                # Plugin handled everything (e.g. DataFrame.sort_values)
                result = postprocess([])
                if not inplace:
                    return result
                # Can't write back to list if plugin returned a different type
                return result
            if items is not work:
                work = items
            if pk is not None:
                key_fn = pk
            # Fall through to normal sort on the prepared items

    # ── None handling ─────────────────────────────────────────────────────────
    none_count = 0
    if p_has_none := any(x is None for x in work):
        work, none_count = _strip_nones(work)
        if not work:
            if reverse:
                data[:] = [None] * none_count
            return data if inplace else [None] * none_count

    # ── Profile ───────────────────────────────────────────────────────────────
    p = _profile(work, key_fn)
    p["n"] = len(work)

    # ── Parallel or sequential ────────────────────────────────────────────────
    if parallel and p["n"] >= 10_000:
        from ._parallel import parallel_sort
        parallel_sort(work, key_fn, p)
    else:
        sort_sequential(work, key_fn, p)

    # ── Reverse ───────────────────────────────────────────────────────────────
    if reverse:
        work.reverse()

    # ── Reinsert Nones ────────────────────────────────────────────────────────
    if none_count:
        _reinsert_nones(work, none_count, reverse)

    # ── Write back if we made a copy ─────────────────────────────────────────
    if inplace and work is not data:
        data[:] = work

    return work
