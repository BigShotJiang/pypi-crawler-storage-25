"""
quill/_strategies.py
--------------------
Individual sort strategies.  Each function sorts `data` in-place and returns
nothing.  The dispatcher in _core.py picks which one to call.
"""

from __future__ import annotations
import math

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False


def insertion_sort(arr: list, key_fn) -> None:
    for i in range(1, len(arr)):
        p = arr[i]; pk = key_fn(p); j = i - 1
        while j >= 0 and key_fn(arr[j]) > pk:
            arr[j + 1] = arr[j]; j -= 1
        arr[j + 1] = p


def counting_sort(arr: list, mn: int, mx: int) -> None:
    counts = [0] * (mx - mn + 1)
    for v in arr:
        counts[v - mn] += 1
    idx = 0
    for offset, cnt in enumerate(counts):
        for _ in range(cnt):
            arr[idx] = offset + mn
            idx += 1


def numpy_sort_ints(arr: list, mn: int, mx: int) -> None:
    shift = mn if mn < 0 else 0
    rng   = mx - mn

    if rng < 256:          dtype = np.uint8
    elif rng < 65_536:     dtype = np.uint16
    elif rng < 2**31:      dtype = np.int32
    else:                  dtype = np.int64; shift = 0

    if shift:
        a = (np.array(arr, dtype=np.int64) - shift).astype(dtype)
    else:
        a = np.array(arr, dtype=dtype)

    a.sort()

    if shift:
        arr[:] = (a.astype(np.int64) + shift).tolist()
    else:
        arr[:] = a.tolist()


def numpy_sort_floats(arr: list) -> None:
    a = np.array(arr, dtype=np.float64)
    a.sort()
    arr[:] = a.tolist()


def numpy_sort_by_key(data: list, key_fn) -> None:
    raw = [key_fn(x) for x in data]

    # Tuple keys can't be numpy-encoded — fall back to Timsort immediately
    if raw and isinstance(raw[0], tuple):
        data.sort(key=key_fn)
        return

    try:
        keys = np.array(raw, dtype=np.int64)
        mn   = int(keys.min())
        if mn < 0:
            keys = keys - mn
        rng = int(keys.max())
        if rng < 256:           ktype = np.uint8
        elif rng < 65_536:      ktype = np.uint16
        elif rng < 2**31:       ktype = np.int32
        else:                   ktype = np.int64
        idx = np.argsort(keys.astype(ktype), kind='stable')
        data[:] = [data[i] for i in idx.tolist()]
    except (TypeError, ValueError):
        try:
            unique_vals = sorted(set(raw))
            rank        = {v: i for i, v in enumerate(unique_vals)}
            n_uniq      = len(unique_vals)
            ktype       = np.uint16 if n_uniq < 65_536 else np.int32
            keys        = np.array([rank[k] for k in raw], dtype=ktype)
            idx         = np.argsort(keys, kind='stable')
            data[:] = [data[i] for i in idx.tolist()]
        except (TypeError, ValueError):
            data.sort(key=key_fn)


def pure_radix(arr: list) -> None:
    n       = len(arr)
    max_val = max(arr)
    if max_val == 0:
        return

    needed = max(1, (max_val.bit_length() + 7) // 8)

    hists = [[0] * 256 for _ in range(needed)]
    for v in arr:
        for p in range(needed):
            hists[p][(v >> (p * 8)) & 0xFF] += 1

    buf = arr[:]
    out = [0] * n
    for p in range(needed):
        h = hists[p]
        if sum(1 for x in h if x > 0) == 1:
            continue
        pos = [0] * 256
        acc = 0
        for i in range(256):
            pos[i] = acc
            acc += h[i]
        for v in buf:
            d = (v >> (p * 8)) & 0xFF
            out[pos[d]] = v
            pos[d] += 1
        buf, out = out, buf

    arr[:] = buf