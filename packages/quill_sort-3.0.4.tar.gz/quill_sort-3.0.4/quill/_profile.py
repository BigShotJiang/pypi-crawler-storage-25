"""
quill/_profile.py
-----------------
Single-pass data profiler.  Examines a sample of the array and returns a
rich profile dict that the strategy dispatcher uses to pick the optimal path.
We do ONE numpy pass to get min, max, type info, and sortedness — not three.
"""

from __future__ import annotations
import math

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

_SAMPLE = 512   # elements to examine (balances accuracy vs overhead)


def profile(data: list, key_fn) -> dict:
    """
    Return a profile dict describing the array.

    Keys
    ----
    n               int     array length
    dtype           str     'int_pos', 'int_neg', 'int_mixed',
                            'float', 'str', 'bytes', 'object'
    presorted       bool    sample appears already sorted
    reversed        bool    sample appears reverse-sorted
    all_same        bool    all sampled values are identical
    sparse          bool    range >> n  (radix less effective)
    dense           bool    range <= 2*n  (counting sort optimal)
    min_key         any     minimum key in sample (None if non-numeric)
    max_key         any     maximum key in sample (None if non-numeric)
    has_none        bool    any None values found in sample
    """
    n = len(data)
    p: dict = {
        "n": n, "dtype": "object",
        "presorted": False, "reversed": False, "all_same": False,
        "sparse": False, "dense": False,
        "min_key": None, "max_key": None, "has_none": False,
    }
    if n == 0:
        return p

    step = max(1, n // _SAMPLE)
    raw  = [data[i * step] for i in range(min(_SAMPLE, n))]
    keys = [key_fn(v) for v in raw if v is not None]
    p["has_none"] = any(v is None for v in raw)

    if not keys:
        return p

    s = len(keys)

    # ── Pre-sortedness ────────────────────────────────────────────────────────
    try:
        asc  = sum(1 for i in range(s - 1) if keys[i] <= keys[i + 1])
        desc = sum(1 for i in range(s - 1) if keys[i] >= keys[i + 1])
        p["presorted"] = (asc  == s - 1)
        p["reversed"]  = (desc == s - 1)
        p["all_same"]  = (asc == s - 1 and desc == s - 1)
    except TypeError:
        pass  # incomparable types — leave defaults

    # ── Type detection ────────────────────────────────────────────────────────
    sample_types = set(type(k) for k in keys)

    if sample_types <= {int}:
        mn, mx = min(keys), max(keys)
        p["min_key"] = mn
        p["max_key"] = mx
        rng = mx - mn
        if mn >= 0:
            p["dtype"] = "int_pos"
        elif mx < 0:
            p["dtype"] = "int_neg"
        else:
            p["dtype"] = "int_mixed"
        p["dense"]  = (rng <= 2 * n)
        p["sparse"] = (rng > 100 * n)

    elif sample_types <= {float}:
        p["dtype"]   = "float"
        p["min_key"] = min(keys)
        p["max_key"] = max(keys)

    elif sample_types <= {str}:
        p["dtype"] = "str"

    elif sample_types <= {bytes}:
        p["dtype"] = "bytes"

    return p
