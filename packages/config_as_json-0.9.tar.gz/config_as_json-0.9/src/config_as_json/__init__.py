#! /usr/local/bin/python3
"""Define application configuration classes that serialize to JSON.

The package centers on :class:`config_as_json.config.Config`. Applications
derive their own configuration classes, declare supported settings as
instance attributes, and use the library to read, validate, migrate, and
write JSON configuration files.
"""

# Copyright (c) 2026 Tom Björkholm
# MIT License


from config_as_json.config import Config, ConfigBadJson, ParseConverter
from config_as_json.config_nesting import ConfigNestingKind, ConfigNesting, \
    ConfigFactory, NestedConfigs
from config_as_json.commontypes import JsonType, PathOrStr, ConfigPath
from config_as_json.config_factory import config_factory_from_json, \
    MatchConfig, MatchConfigSeq, JsonValueMatcher
from config_as_json.config_auto_change_hook import ConfigAutoChangeHook
from config_as_json.read_old_configuration import ReadOldConfiguration, \
    RocfConflictError, RocfIncompatiblePathError, RocfKeyMove, \
    RocfKeyRename, RocfPath
from config_as_json.csv_dialect import CsvDialectConfig, \
    CsvDialectValidator, get_csv_dialect
from config_as_json.char_encoding import check_char_encoding, \
    CharEncodingValidator, valid_char_encoding
from config_as_json.migrate_cfg_warn_hook import MigrateCfgWarnHook
from config_as_json.migrate_cfg import migrate_cfg
from config_as_json.optional_validator import OptionalMemberValidator
from config_as_json.validator import ValidationPlan, ValidationStep, \
    WholeConfigValidationStep, MemberValidationStep, WholeConfigValidator, \
    MemberValidator, IntFloatValidator, CallingMemberValidator, \
    CallingWholeConfigValidator, \
    MemberValidatorSequence, string_best_match, InvalidConfiguration, \
    InvalidConfigurationValue
from config_as_json.type_validators import InvalidConfigurationType, \
    ValueAsTypeValidator, ValueTypeValidator
from config_as_json.str_validators import StrValidator, StrLenValidator, \
    StrCaseSpec, StrPositionSpec, StrCaseValidator, StrCaseChangeValidator
from config_as_json.list_validators import ListValueValidator, \
    ListSizeValidator, ListIsOrderedValidator, ListOrderingValidator, \
    ListValueTypeValidator, ListForEachValidator, ListOfDictsKeysValidator
from config_as_json.dict_validators import DictKeysValidator, DictRule, \
    DictForEachValidator, DictKeyValueTypesValidator, accept_all_keys
from config_as_json.discriminated_dict_validators import DictVariant, \
    DiscriminatedDictValidator
from config_as_json.projected_validators import ProjectedMemberValidator, \
    ProjectedWholeConfigValidator, WholeConfigProjector, MemberProjector
from config_as_json.list_relation_validator import ListRelationKind, \
    ListRelationValidator
from config_as_json.as_dict_view_validator import AsDictViewValidator, \
    public_attrs_to_dict
from config_as_json.json_write_hooks import SerializeConverter, \
    SerializeSelector, SerializeConverters, JsonWriteHookError, \
    SerializeSelectorError, apply_serialize_converters
from config_as_json.str_to_enum import string_to_enum_best_match
from config_as_json.assert_dict_equal import assert_dict_equal


__all__ = ['Config',
           'RocfKeyRename',
           'RocfPath',
           'RocfKeyMove',
           'ReadOldConfiguration',
           'RocfConflictError',
           'RocfIncompatiblePathError',
           'ConfigBadJson',
           'ConfigNestingKind',
           'ConfigNesting',
           'ConfigFactory',
           'NestedConfigs',
           'JsonType',
           'PathOrStr',
           'ConfigPath',
           'SerializeSelector',
           'SerializeConverter',
           'SerializeConverters',
           'JsonWriteHookError',
           'SerializeSelectorError',
           'apply_serialize_converters',
           'ParseConverter',
           'ConfigAutoChangeHook',
           'CsvDialectConfig',
           'CsvDialectValidator',
           'get_csv_dialect',
           'check_char_encoding',
           'CharEncodingValidator',
           'valid_char_encoding',
           'MigrateCfgWarnHook',
           'migrate_cfg',
           'config_factory_from_json',
           'MatchConfig',
           'MatchConfigSeq',
           'JsonValueMatcher',
           'ValidationPlan',
           'ValidationStep',
           'WholeConfigValidationStep',
           'MemberValidationStep',
           'WholeConfigValidator',
           'MemberValidator',
           'InvalidConfigurationType',
           'ValueTypeValidator',
           'ValueAsTypeValidator',
           'StrValidator',
           'StrLenValidator',
           'StrCaseSpec',
           'StrPositionSpec',
           'StrCaseValidator',
           'StrCaseChangeValidator',
           'IntFloatValidator',
           'CallingMemberValidator',
           'CallingWholeConfigValidator',
           'MemberValidatorSequence',
           'OptionalMemberValidator',
           'string_best_match',
           'string_to_enum_best_match',
           'InvalidConfiguration',
           'InvalidConfigurationValue',
           'ListValueValidator',
           'ListSizeValidator',
           'ListIsOrderedValidator',
           'ListOrderingValidator',
           'ListValueTypeValidator',
           'ListForEachValidator',
           'ListOfDictsKeysValidator',
           'DictKeysValidator',
           'DictRule',
           'DictForEachValidator',
           'DictKeyValueTypesValidator',
           'accept_all_keys',
           'DictVariant',
           'DiscriminatedDictValidator',
           'ProjectedMemberValidator',
           'ProjectedWholeConfigValidator',
           'WholeConfigProjector',
           'MemberProjector',
           'ListRelationKind',
           'ListRelationValidator',
           'AsDictViewValidator',
           'public_attrs_to_dict',
           'assert_dict_equal']
