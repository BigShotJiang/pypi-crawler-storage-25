"""Spacetime PLATO — unified temporal + spatial reasoning."""
from .tile import SpatialTile, TemporalTile, SpacetimeTile
from .room import SpatialRoom, SpacetimeRoom
from .index import ZOrderIndex
from .query import SpacetimeQuery, QueryResult

__version__ = "0.1.0"
__all__ = [
    "SpatialTile", "TemporalTile", "SpacetimeTile",
    "SpatialRoom", "SpacetimeRoom", "ZOrderIndex",
    "SpacetimeQuery", "QueryResult",
]
