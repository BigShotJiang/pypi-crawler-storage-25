"""Spacetime query language — find tiles by space, time, domain, and content."""
import time
from dataclasses import dataclass, field
from .tile import SpacetimeTile
from .room import SpacetimeRoom


@dataclass
class SpacetimeQuery:
    """A query for spacetime tiles."""
    x_range: tuple[float, float] | None = None
    y_range: tuple[float, float] | None = None
    z_range: tuple[float, float] | None = None
    time_range: tuple[float, float] | None = None
    domain: str | None = None
    content_match: str | None = None
    min_confidence: float = 0.0
    limit: int = 100

    def execute(self, room: SpacetimeRoom) -> "QueryResult":
        """Execute query against a spacetime room."""
        tiles = room.tiles
        start = time.time()

        # Spatial filter
        if self.x_range:
            tiles = [t for t in tiles if self.x_range[0] <= t.x <= self.x_range[1]]
        if self.y_range:
            tiles = [t for t in tiles if self.y_range[0] <= t.y <= self.y_range[1]]
        if self.z_range:
            tiles = [t for t in tiles if self.z_range[0] <= t.z <= self.z_range[1]]

        # Temporal filter
        if self.time_range:
            tiles = [t for t in tiles if self.time_range[0] <= t.timestamp <= self.time_range[1]]

        # Domain filter
        if self.domain:
            tiles = [t for t in tiles if t.domain == self.domain]

        # Content filter
        if self.content_match:
            tiles = [t for t in tiles if self.content_match.lower() in t.content.lower()]

        # Confidence filter
        if self.min_confidence > 0:
            tiles = [t for t in tiles if t.confidence >= self.min_confidence]

        # Sort by timestamp descending (most recent first)
        tiles = sorted(tiles, key=lambda t: t.timestamp, reverse=True)

        total = len(tiles)
        tiles = tiles[:self.limit]
        elapsed = time.time() - start

        return QueryResult(
            tiles=tiles,
            total_matched=total,
            returned=len(tiles),
            elapsed_ms=elapsed * 1000,
        )

    def to_dict(self) -> dict:
        return {
            "x_range": self.x_range, "y_range": self.y_range, "z_range": self.z_range,
            "time_range": self.time_range, "domain": self.domain,
            "min_confidence": self.min_confidence, "limit": self.limit,
        }


@dataclass
class QueryResult:
    tiles: list[SpacetimeTile]
    total_matched: int
    returned: int
    elapsed_ms: float

    def to_dict(self) -> dict:
        return {
            "total_matched": self.total_matched,
            "returned": self.returned,
            "elapsed_ms": round(self.elapsed_ms, 2),
            "tiles": [t.to_dict() for t in self.tiles],
        }
