"""Spatial and spacetime rooms — accumulate tiles over space and time."""
from dataclasses import dataclass, field
from .tile import SpatialTile, SpacetimeTile


@dataclass
class SpatialRoom:
    """A room that accumulates spatial tiles in a bounded region."""
    name: str
    bounds: tuple[float, float, float, float, float, float] = (0, 100, 0, 100, 0, 100)
    tiles: list[SpatialTile] = field(default_factory=list)

    @property
    def tile_count(self) -> int:
        return len(self.tiles)

    def add_tile(self, tile: SpatialTile) -> bool:
        """Add tile if within bounds."""
        x1, x2, y1, y2, z1, z2 = self.bounds
        if x1 <= tile.x <= x2 and y1 <= tile.y <= y2 and z1 <= tile.z <= z2:
            self.tiles.append(tile)
            return True
        return False

    def tiles_in_region(self, x1: float, x2: float, y1: float, y2: float,
                        z1: float, z2: float) -> list[SpatialTile]:
        return [t for t in self.tiles
                if x1 <= t.x <= x2 and y1 <= t.y <= y2 and z1 <= t.z <= z2]


@dataclass
class SpacetimeRoom:
    """A room that accumulates spacetime tiles in bounded space + time."""
    name: str
    spatial_bounds: tuple[float, float, float, float, float, float] = (0, 100, 0, 100, 0, 100)
    tiles: list[SpacetimeTile] = field(default_factory=list)

    @property
    def tile_count(self) -> int:
        return len(self.tiles)

    def add_tile(self, tile: SpacetimeTile) -> bool:
        x1, x2, y1, y2, z1, z2 = self.spatial_bounds
        if x1 <= tile.x <= x2 and y1 <= tile.y <= y2 and z1 <= tile.z <= z2:
            self.tiles.append(tile)
            return True
        return False

    def query(self, x1: float, x2: float, y1: float, y2: float,
              z1: float, z2: float, t1: float, t2: float) -> list[SpacetimeTile]:
        """Query tiles within spatial bounds and time range."""
        return [t for t in self.tiles
                if x1 <= t.x <= x2 and y1 <= t.y <= y2 and z1 <= t.z <= z2
                and t1 <= t.timestamp <= t2]

    def spatial_density(self) -> dict[tuple[int, int, int], int]:
        """Count tiles per voxel."""
        density = {}
        for t in self.tiles:
            key = t.voxel_key
            density[key] = density.get(key, 0) + 1
        return density
