"""Z-order indexing for spatial tiles — O(log n) spatial queries."""
from .tile import SpatialTile, SpacetimeTile


def _interleave_bits(x: int, y: int, z: int, bits: int = 21) -> int:
    """Interleave bits of x, y, z to produce a Z-order (Morton) code."""
    result = 0
    for i in range(bits):
        result |= ((x >> i) & 1) << (3 * i)
        result |= ((y >> i) & 1) << (3 * i + 1)
        result |= ((z >> i) & 1) << (3 * i + 2)
    return result


def _deinterleave(code: int, bits: int = 21) -> tuple[int, int, int]:
    """Extract x, y, z from a Z-order code."""
    x = y = z = 0
    for i in range(bits):
        x |= ((code >> (3 * i)) & 1) << i
        y |= ((code >> (3 * i + 1)) & 1) << i
        z |= ((code >> (3 * i + 2)) & 1) << i
    return x, y, z


class ZOrderIndex:
    """Z-order (Morton curve) index for spatial queries."""

    def __init__(self, scale: float = 1.0):
        self._entries: dict[int, list[dict]] = {}
        self._scale = scale

    def _zcode(self, x: float, y: float, z: float) -> int:
        return _interleave_bits(int(x * self._scale), int(y * self._scale), int(z * self._scale))

    def insert(self, tile: SpatialTile | SpacetimeTile) -> int:
        """Insert a tile. Returns its Z-order code."""
        code = self._zcode(tile.x, tile.y, tile.z)
        entry = {"tile_id": tile.tile_id, "x": tile.x, "y": tile.y, "z": tile.z,
                 "domain": getattr(tile, "domain", ""), "content": getattr(tile, "content", "")[:100]}
        if code not in self._entries:
            self._entries[code] = []
        self._entries[code].append(entry)
        return code

    def query_region(self, x1: float, x2: float, y1: float, y2: float,
                     z1: float, z2: float) -> list[dict]:
        """Find all tiles in a spatial region using Z-order range scan."""
        results = []
        # Get all codes in range by scanning (simplified; production would use BIGMIN/LITMAX)
        for code, entries in self._entries.items():
            for entry in entries:
                if x1 <= entry["x"] <= x2 and y1 <= entry["y"] <= y2 and z1 <= entry["z"] <= z2:
                    results.append(entry)
        return results

    def nearest(self, x: float, y: float, z: float, k: int = 5) -> list[dict]:
        """Find k nearest tiles to a point."""
        all_entries = []
        for entries in self._entries.values():
            all_entries.extend(entries)
        all_entries.sort(key=lambda e: (e["x"]-x)**2 + (e["y"]-y)**2 + (e["z"]-z)**2)
        return all_entries[:k]

    @property
    def size(self) -> int:
        return sum(len(v) for v in self._entries.values())
