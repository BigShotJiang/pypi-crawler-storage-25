"""Tiles with spatial and temporal coordinates."""
import hashlib
import time
from dataclasses import dataclass, field


@dataclass
class SpatialTile:
    """A tile anchored to a 3D location."""
    x: float
    y: float
    z: float
    volume: float = 1.0  # voxel size in m³
    domain: str = ""
    content: str = ""
    confidence: float = 0.5
    agent: str = ""
    timestamp: float = field(default_factory=time.time)

    @property
    def tile_id(self) -> str:
        raw = f"{self.x:.2f}:{self.y:.2f}:{self.z:.2f}:{self.domain}:{self.content[:50]}"
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    @property
    def voxel_key(self) -> tuple[int, int, int]:
        """Discrete voxel coordinates (1m resolution)."""
        return (int(self.x), int(self.y), int(self.z))

    def to_dict(self) -> dict:
        return {
            "tile_id": self.tile_id, "x": self.x, "y": self.y, "z": self.z,
            "volume": self.volume, "domain": self.domain, "content": self.content[:200],
            "confidence": self.confidence, "timestamp": self.timestamp,
        }


@dataclass
class TemporalTile:
    """A tile anchored to a point in time."""
    timestamp: float
    domain: str = ""
    content: str = ""
    confidence: float = 0.5
    agent: str = ""
    parent_ids: list[str] = field(default_factory=list)

    @property
    def tile_id(self) -> str:
        raw = f"{self.timestamp}:{self.domain}:{self.content[:50]}"
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    def to_dict(self) -> dict:
        return {
            "tile_id": self.tile_id, "timestamp": self.timestamp,
            "domain": self.domain, "content": self.content[:200],
            "confidence": self.confidence,
        }


@dataclass
class SpacetimeTile:
    """A tile with both spatial and temporal coordinates."""
    x: float
    y: float
    z: float
    timestamp: float
    domain: str = ""
    content: str = ""
    confidence: float = 0.5
    agent: str = ""
    parent_ids: list[str] = field(default_factory=list)

    @property
    def tile_id(self) -> str:
        raw = f"{self.x:.2f}:{self.y:.2f}:{self.z:.2f}:{self.timestamp}:{self.domain}"
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    @property
    def voxel_key(self) -> tuple[int, int, int]:
        return (int(self.x), int(self.y), int(self.z))

    def to_dict(self) -> dict:
        return {
            "tile_id": self.tile_id, "x": self.x, "y": self.y, "z": self.z,
            "timestamp": self.timestamp, "domain": self.domain,
            "content": self.content[:200], "confidence": self.confidence,
        }
