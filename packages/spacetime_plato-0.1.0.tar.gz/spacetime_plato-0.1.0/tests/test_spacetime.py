"""Tests for spacetime-plato."""
import time
import pytest
from spacetime_plato import (
    SpatialTile, TemporalTile, SpacetimeTile,
    SpatialRoom, SpacetimeRoom, ZOrderIndex,
    SpacetimeQuery, QueryResult,
)


class TestSpatialTile:
    def test_create(self):
        t = SpatialTile(x=10.5, y=20.3, z=5.0, domain="harbor", content="ship detected")
        assert t.tile_id != ""
        assert t.voxel_key == (10, 20, 5)

    def test_voxel_quantization(self):
        t = SpatialTile(x=10.9, y=20.1, z=5.5)
        assert t.voxel_key == (10, 20, 5)


class TestTemporalTile:
    def test_create(self):
        t = TemporalTile(timestamp=1000.0, domain="bridge", content="alert")
        assert t.tile_id != ""
        assert t.timestamp == 1000.0


class TestSpacetimeTile:
    def test_has_both_coords(self):
        t = SpacetimeTile(x=1.0, y=2.0, z=3.0, timestamp=1000.0, domain="test", content="data")
        assert t.voxel_key == (1, 2, 3)
        assert t.timestamp == 1000.0
        assert t.tile_id != ""


class TestSpatialRoom:
    def test_add_within_bounds(self):
        room = SpatialRoom("harbor", bounds=(0, 50, 0, 50, 0, 50))
        tile = SpatialTile(x=10, y=20, z=5)
        assert room.add_tile(tile)
        assert room.tile_count == 1

    def test_reject_outside_bounds(self):
        room = SpatialRoom("harbor", bounds=(0, 10, 0, 10, 0, 10))
        tile = SpatialTile(x=50, y=50, z=50)
        assert not room.add_tile(tile)

    def test_region_query(self):
        room = SpatialRoom("test", bounds=(0, 100, 0, 100, 0, 100))
        for i in range(10):
            room.add_tile(SpatialTile(x=float(i*10), y=float(i*10), z=float(i)))
        found = room.tiles_in_region(0, 30, 0, 30, 0, 3)
        assert len(found) == 4  # 0,0,0 / 10,10,1 / 20,20,2 / 30,30,3


class TestSpacetimeRoom:
    def test_spacetime_query(self):
        room = SpacetimeRoom("test", spatial_bounds=(0, 100, 0, 100, 0, 100))
        now = time.time()
        room.add_tile(SpacetimeTile(x=10, y=10, z=1, timestamp=now - 100, domain="old"))
        room.add_tile(SpacetimeTile(x=20, y=20, z=2, timestamp=now, domain="new"))
        room.add_tile(SpacetimeTile(x=50, y=50, z=5, timestamp=now, domain="far"))
        results = room.query(0, 30, 0, 30, 0, 3, now - 10, now + 10)
        assert len(results) == 1
        assert results[0].domain == "new"

    def test_density(self):
        room = SpacetimeRoom("test")
        room.add_tile(SpacetimeTile(x=5, y=5, z=5, timestamp=1.0))
        room.add_tile(SpacetimeTile(x=5, y=5, z=5, timestamp=2.0))
        room.add_tile(SpacetimeTile(x=10, y=10, z=10, timestamp=3.0))
        density = room.spatial_density()
        assert density[(5, 5, 5)] == 2
        assert density[(10, 10, 10)] == 1


class TestZOrderIndex:
    def test_insert_and_query(self):
        idx = ZOrderIndex(scale=1.0)
        idx.insert(SpatialTile(x=10, y=10, z=1, content="a"))
        idx.insert(SpatialTile(x=20, y=20, z=2, content="b"))
        idx.insert(SpatialTile(x=50, y=50, z=5, content="c"))
        assert idx.size == 3
        found = idx.query_region(0, 25, 0, 25, 0, 3)
        assert len(found) == 2

    def test_nearest(self):
        idx = ZOrderIndex(scale=1.0)
        idx.insert(SpatialTile(x=10, y=10, z=10))
        idx.insert(SpatialTile(x=11, y=11, z=11))
        idx.insert(SpatialTile(x=50, y=50, z=50))
        nearest = idx.nearest(10, 10, 10, k=2)
        assert len(nearest) == 2


class TestSpacetimeQuery:
    def test_full_query(self):
        room = SpacetimeRoom("test")
        now = time.time()
        room.add_tile(SpacetimeTile(x=5, y=5, z=1, timestamp=now - 200, domain="old", content="legacy"))
        room.add_tile(SpacetimeTile(x=10, y=10, z=2, timestamp=now, domain="sensor", content="temperature 25"))
        room.add_tile(SpacetimeTile(x=15, y=15, z=3, timestamp=now, domain="sensor", content="humidity 60", confidence=0.9))
        room.add_tile(SpacetimeTile(x=50, y=50, z=10, timestamp=now, domain="far", content="distant"))

        q = SpacetimeQuery(
            x_range=(0, 20), y_range=(0, 20), z_range=(0, 5),
            time_range=(now - 10, now + 10),
            domain="sensor", min_confidence=0.8, limit=10,
        )
        result = q.execute(room)
        assert result.total_matched == 1
        assert result.returned == 1
        assert result.tiles[0].content == "humidity 60"

    def test_content_search(self):
        room = SpacetimeRoom("test")
        now = time.time()
        room.add_tile(SpacetimeTile(x=1, y=1, z=1, timestamp=now, content="temperature anomaly"))
        room.add_tile(SpacetimeTile(x=2, y=2, z=2, timestamp=now, content="pressure normal"))

        q = SpacetimeQuery(content_match="anomaly")
        result = q.execute(room)
        assert result.total_matched == 1
