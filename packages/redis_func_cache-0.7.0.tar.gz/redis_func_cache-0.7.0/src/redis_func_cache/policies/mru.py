"""Most Recently Used eviction cache policies."""

from typing import final

from ..mixins.hash import PickleMd5HashMixin
from ..mixins.scripts import MruScriptsMixin
from .base import BaseClusterMultiplePolicy, BaseClusterSinglePolicy, BaseMultiplePolicy, BaseSinglePolicy

__all__ = ("MruPolicy", "MruMultiplePolicy", "MruClusterPolicy", "MruClusterMultiplePolicy")


class _MruPolicyExtArgsMixin:
    def calc_ext_args(self, *args, **kwargs):
        return ("mru",)


@final
class MruPolicy(_MruPolicyExtArgsMixin, MruScriptsMixin, PickleMd5HashMixin, BaseSinglePolicy):
    """
    MRU eviction policy, single key pair.

    .. inheritance-diagram:: MruPolicy
        :parts: 1

    All decorated functions share the same Redis key pair.
    """

    __key__ = "mru"


@final
class MruMultiplePolicy(_MruPolicyExtArgsMixin, MruScriptsMixin, PickleMd5HashMixin, BaseMultiplePolicy):
    """
    MRU eviction policy, multiple key pairs.

    .. inheritance-diagram:: MruMultiplePolicy
        :parts: 1

    Each decorated function has its own Redis key pair.
    """

    __key__ = "mru-m"


@final
class MruClusterPolicy(_MruPolicyExtArgsMixin, MruScriptsMixin, PickleMd5HashMixin, BaseClusterSinglePolicy):
    """
    MRU eviction policy with Redis cluster support, single key pair.

    .. inheritance-diagram:: MruClusterPolicy
        :parts: 1

    All decorated functions share the same Redis key pair.
    """

    __key__ = "mru-c"


@final
class MruClusterMultiplePolicy(_MruPolicyExtArgsMixin, MruScriptsMixin, PickleMd5HashMixin, BaseClusterMultiplePolicy):
    """
    MRU eviction policy with Redis cluster support, multiple key pairs.

    .. inheritance-diagram:: MruClusterMultiplePolicy
        :parts: 1

    Each decorated function has its own Redis key pair.
    """

    __key__ = "mru-cm"
