from __future__ import annotations

import json
import threading
import time
from typing import Iterator

import websocket  # websocket-client

RECONNECT_DELAY = 3.0
AUTH_TIMEOUT = 10.0


class HoplynkStream:
    """Synchronous WebSocket stream over the Hoplynk telemetry endpoint.

    Iterating yields data events as dicts::

        for event in stream:
            # event = {"type": "data", "feed": "gps", "payload": {...}, "ts": "..."}
            print(event["payload"]["lat"])

    The stream auto-reconnects on disconnect. Call ``close()`` to stop permanently.
    Use as a context manager for automatic cleanup::

        with client.stream(kit_id, asset_id) as stream:
            for event in stream:
                ...
    """

    def __init__(self, ws_url: str, api_key: str) -> None:
        self._ws_url = ws_url
        self._api_key = api_key
        self._closed = False
        self._queue: list[dict] = []
        self._lock = threading.Lock()
        self._event = threading.Event()
        self._ws: websocket.WebSocketApp | None = None
        self._thread: threading.Thread | None = None
        self._connect()

    def __enter__(self) -> "HoplynkStream":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    def __iter__(self) -> Iterator[dict]:
        while not self._closed:
            self._event.wait(timeout=1.0)
            self._event.clear()
            with self._lock:
                items = self._queue[:]
                self._queue.clear()
            for item in items:
                yield item

    def close(self) -> None:
        self._closed = True
        if self._ws:
            self._ws.close()

    # ── Internal ──────────────────────────────────────────────────────────

    def _connect(self) -> None:
        def on_open(ws):
            ws.send(json.dumps({"type": "auth", "key": self._api_key}))

        def on_message(ws, raw):
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                return
            if msg.get("type") == "data":
                with self._lock:
                    self._queue.append(msg)
                self._event.set()

        def on_error(ws, error):
            pass  # on_close fires next; retry handled there

        def on_close(ws, code, msg):
            if not self._closed:
                time.sleep(RECONNECT_DELAY)
                self._connect()

        self._ws = websocket.WebSocketApp(
            self._ws_url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
        )
        self._thread = threading.Thread(
            target=self._ws.run_forever,
            kwargs={"ping_interval": 20},
            daemon=True,
        )
        self._thread.start()
