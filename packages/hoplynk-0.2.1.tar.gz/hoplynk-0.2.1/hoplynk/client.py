from __future__ import annotations

import threading
import time
from typing import Callable

import httpx

from .models import GpsPayload, LinkStatus, StatusPayload, TelemetrySnapshot
from .stream import HoplynkStream

DEFAULT_BASE_URL = "https://argus.hoplynk.com"


class HoplynkClient:
    """Partner-facing client for the Hoplynk API.

    Example::

        import os
        from hoplynk import HoplynkClient

        client = HoplynkClient(api_key=os.environ["HOPLYNK_API_KEY"])

        # REST — one-shot snapshot
        loc = client.get_location(kit_id, asset_id)
        print(loc.lat, loc.lon)

        # WebSocket — live stream
        stream = client.stream(kit_id, asset_id, feeds=["gps"])
        for event in stream:
            if event["feed"] == "gps":
                payload = event["payload"]
                print(payload["lat"], payload["lon"])
    """

    def __init__(self, *, api_key: str, base_url: str = DEFAULT_BASE_URL) -> None:
        if not api_key.startswith("hlk_"):
            raise ValueError('api_key must start with "hlk_". Get one from the Hoplynk dashboard.')
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={"X-API-Key": self._api_key},
            timeout=15.0,
        )

    def __enter__(self) -> "HoplynkClient":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    # ── Kits ──────────────────────────────────────────────────────────────

    def get_kits(self) -> list[dict]:
        """Return all kits associated with this API key.

        Each kit contains: id, name, online, last_seen, location, created_at.
        Use the id as kit_id in all other SDK calls.
        """
        r = self._http.get("/api/kits")
        r.raise_for_status()
        data = r.json()
        return data if isinstance(data, list) else data.get("kits", [])

    # ── Assets ────────────────────────────────────────────────────────────

    def create_asset(
        self,
        kit_id: str,
        *,
        name: str,
        type: str,
        vendor: str | None = None,
        model: str | None = None,
        metadata: dict | None = None,
        parent_id: str | None = None,
    ) -> dict:
        """Create a partner-managed asset and return it (including its ``id``).

        A ``gps`` feed is registered automatically — call :meth:`push_location`
        right after to start streaming positions.

        Example::

            asset = client.create_asset(kit_id, name="Skydio X10", type="drone")
            client.push_location(kit_id, asset["id"], lat=31.12, lon=-93.45)
        """
        body: dict = {"name": name, "type": type}
        if vendor is not None:
            body["vendor"] = vendor
        if model is not None:
            body["model"] = model
        if metadata is not None:
            body["metadata"] = metadata
        if parent_id is not None:
            body["parent_id"] = parent_id
        r = self._http.post(f"/api/kits/{kit_id}/assets", json=body)
        r.raise_for_status()
        return r.json()

    def push_location(
        self,
        kit_id: str,
        asset_id: str,
        *,
        lat: float,
        lon: float,
        alt_m: float | None = None,
        bearing: float | None = None,
        speed_mps: float | None = None,
    ) -> None:
        """Push a GPS fix for a partner-managed asset.

        The location appears on the Argus map immediately and is
        streamable via the asset WebSocket.

        Example::

            client.push_location(kit_id, asset["id"], lat=31.12, lon=-93.45, alt_m=120, bearing=245)
        """
        body: dict = {"lat": lat, "lon": lon}
        if alt_m is not None:
            body["alt_m"] = alt_m
        if bearing is not None:
            body["bearing"] = bearing
        if speed_mps is not None:
            body["speed_mps"] = speed_mps
        r = self._http.post(f"/api/kits/{kit_id}/assets/{asset_id}/location", json=body)
        r.raise_for_status()

    def get_asset_tree(self, kit_id: str) -> list[dict]:
        """Return all assets as a nested tree (roots with 'children' lists).

        Example::

            tree = client.get_asset_tree(kit_id)
            for root in tree:
                print(root["name"], [c["name"] for c in root["children"]])
        """
        r = self._http.get(f"/api/kits/{kit_id}/assets/tree")
        r.raise_for_status()
        return r.json().get("assets", [])

    def get_asset_children(self, kit_id: str, asset_id: str) -> list[dict]:
        """Return direct child assets of a given asset."""
        r = self._http.get(f"/api/kits/{kit_id}/assets/{asset_id}/children")
        r.raise_for_status()
        return r.json().get("assets", [])

    def track(
        self,
        kit_id: str,
        asset_id: str,
        *,
        source: Callable[[], dict | None],
        interval: float = 1.0,
        daemon: bool = True,
    ) -> threading.Thread:
        """Start a background thread that calls *source* every *interval* seconds
        and pushes the result via :meth:`push_location`.

        *source* must return a dict with at least ``lat`` and ``lon`` keys,
        optionally ``alt_m``, ``bearing``, ``speed_mps``. Return ``None`` to
        skip a cycle without error.

        The thread is started immediately and runs until the process exits
        (daemon=True by default). Call ``.join()`` or set ``daemon=False``
        to block until it stops.

        Example::

            def get_pos():
                lat, lon = gps.read()
                return {"lat": lat, "lon": lon, "alt_m": gps.alt}

            client.track(kit_id, asset["id"], source=get_pos, interval=1)
        """
        def _loop() -> None:
            while True:
                try:
                    pos = source()
                    if pos is not None:
                        self.push_location(
                            kit_id,
                            asset_id,
                            lat=pos["lat"],
                            lon=pos["lon"],
                            alt_m=pos.get("alt_m"),
                            bearing=pos.get("bearing"),
                            speed_mps=pos.get("speed_mps"),
                        )
                except Exception:
                    pass  # silently retry next cycle
                time.sleep(interval)

        t = threading.Thread(target=_loop, daemon=daemon, name=f"hoplynk-track-{asset_id[:8]}")
        t.start()
        return t

    def get_assets(self, kit_id: str) -> list[dict]:
        """List all assets in a kit.

        Each asset dict contains: id, name, type, status, whep_url (cameras), etc.
        """
        r = self._http.get(f"/api/kits/{kit_id}/assets")
        r.raise_for_status()
        return r.json().get("assets", [])

    def get_asset(self, kit_id: str, asset_id: str) -> dict:
        """Return a single asset by ID."""
        r = self._http.get(f"/api/kits/{kit_id}/assets/{asset_id}")
        r.raise_for_status()
        return r.json()

    # ── Links ─────────────────────────────────────────────────────────────

    def get_links(self, kit_id: str) -> list[LinkStatus]:
        """Return all WAN links for a kit (Starlink, cellular, etc.)."""
        r = self._http.get(f"/api/kits/{kit_id}/links")
        r.raise_for_status()
        return [LinkStatus.from_dict(l) for l in r.json().get("links", [])]

    def get_link(self, kit_id: str, name: str) -> LinkStatus | None:
        """Return a single WAN link by name (e.g. 'starlink', 'cellular').

        Returns None if the link is not found.
        """
        r = self._http.get(f"/api/kits/{kit_id}/links/{name}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return LinkStatus.from_dict(r.json())

    # ── Kit-level telemetry (Starlink GPS) ───────────────────────────────

    def get_kit_telemetry(self, kit_id: str) -> dict:
        """Return full telemetry snapshot for a kit.

        Includes: location, starlink, wans, gateway, clients, speedtest, battery.
        Use this when you need multiple fields at once to avoid multiple requests.
        """
        r = self._http.get(f"/api/kits/{kit_id}/telemetry")
        r.raise_for_status()
        return r.json()

    def get_battery(self, kit_id: str) -> dict | None:
        """Return battery level and charging state.

        Returns dict with keys: level (0-100), charging (bool).
        Returns None if kit has no battery hardware.
        """
        data = self.get_kit_telemetry(kit_id)
        level = data.get("battery")
        if level is None:
            return None
        return {
            "level":    level,
            "charging": data.get("battery_charging"),
        }

    def get_gateway(self, kit_id: str) -> dict | None:
        """Return UniFi gateway info (model, CPU, memory, uptime)."""
        data = self.get_kit_telemetry(kit_id)
        return data.get("gateway") or None

    def get_clients(self, kit_id: str) -> list[dict]:
        """Return list of devices currently connected to the kit's network."""
        data = self.get_kit_telemetry(kit_id)
        return data.get("clients") or []

    def get_speedtest(self, kit_id: str) -> dict | None:
        """Return the last speedtest result (download, upload, latency)."""
        data = self.get_kit_telemetry(kit_id)
        return data.get("speedtest") or None

    def get_kit_location(self, kit_id: str) -> GpsPayload | None:
        """Fetch the latest Starlink GPS fix for a kit.

        Returns None if no GPS data is available yet.
        """
        r = self._http.get(f"/api/kits/{kit_id}/location")
        r.raise_for_status()
        loc = r.json()
        if not loc.get("latitude"):
            return None
        return GpsPayload(
            lat=loc["latitude"],
            lon=loc["longitude"],
            source=loc.get("source", "starlink"),
            stale=loc.get("stale", False),
            alt_m=loc.get("altitude"),
            accuracy_m=loc.get("accuracy_m"),
            timestamp=loc.get("timestamp"),
        )

    def kit_stream(
        self,
        kit_id: str,
        *,
        feeds: list[str] | None = None,
        interval: float = 1.0,
        ws_base_url: str | None = None,
    ) -> HoplynkStream:
        """Open a live WebSocket stream for kit-level data (GPS, Starlink status).

        feeds: list of 'gps', 'starlink', or both. Default: ['gps']
        """
        feeds = feeds or ["gps"]
        http_base = ws_base_url or self._base_url
        ws_base = http_base.replace("https://", "wss://").replace("http://", "ws://")
        params = f"feeds={','.join(feeds)}&interval={interval}"
        url = f"{ws_base}/api/kits/{kit_id}/ws?{params}"
        return HoplynkStream(url, self._api_key)

    # ── Asset telemetry (REST) ────────────────────────────────────────────

    def get_telemetry(self, kit_id: str, asset_id: str) -> TelemetrySnapshot:
        """Fetch the latest telemetry snapshot for an asset."""
        r = self._http.get(f"/api/kits/{kit_id}/assets/{asset_id}/telemetry")
        r.raise_for_status()
        return TelemetrySnapshot.from_dict(r.json())

    def get_location(self, kit_id: str, asset_id: str) -> GpsPayload | None:
        """Fetch the latest GPS fix. Returns None if no GPS data available."""
        snap = self.get_telemetry(kit_id, asset_id)
        return snap.gps

    def get_status(self, kit_id: str, asset_id: str) -> StatusPayload | None:
        """Fetch the latest Starlink link status. Returns None if unavailable."""
        snap = self.get_telemetry(kit_id, asset_id)
        return snap.status

    # ── WebSocket stream ──────────────────────────────────────────────────

    def stream(
        self,
        kit_id: str,
        asset_id: str,
        *,
        feeds: list[str] | None = None,
        interval: float = 1.0,
        ws_base_url: str | None = None,
    ) -> HoplynkStream:
        """Open a live WebSocket stream for an asset.

        Returns a :class:`HoplynkStream` that is both an iterator and a context manager::

            with client.stream(kit_id, asset_id, feeds=["gps"]) as stream:
                for event in stream:
                    print(event["feed"], event["payload"])

        Or iterate without context manager (call ``stream.close()`` when done).

        Events are dicts: ``{"type": "data", "feed": str, "payload": dict, "ts": str}``
        """
        feeds = feeds or ["gps"]
        http_base = ws_base_url or self._base_url
        ws_base = http_base.replace("https://", "wss://").replace("http://", "ws://")
        params = f"feeds={','.join(feeds)}&interval={interval}"
        url = f"{ws_base}/api/kits/{kit_id}/assets/{asset_id}/ws?{params}"
        return HoplynkStream(url, self._api_key)
