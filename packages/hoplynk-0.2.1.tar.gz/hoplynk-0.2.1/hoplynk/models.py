from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class GpsPayload:
    lat: float
    lon: float
    source: str
    stale: bool
    alt_m: Optional[float] = None
    accuracy_m: Optional[float] = None
    timestamp: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "GpsPayload":
        return cls(
            lat=d["lat"],
            lon=d["lon"],
            source=d.get("source", "unknown"),
            stale=d.get("stale", False),
            alt_m=d.get("alt_m"),
            accuracy_m=d.get("accuracy_m"),
            timestamp=d.get("timestamp"),
        )


@dataclass
class StatusPayload:
    state: Optional[str] = None
    uptime_s: Optional[float] = None
    downlink_mbps: Optional[float] = None
    uplink_mbps: Optional[float] = None
    pop_ping_latency_ms: Optional[float] = None
    pop_ping_drop_rate: Optional[float] = None
    obstruction_pct: Optional[float] = None
    snr: Optional[float] = None
    alerts: list[str] = field(default_factory=list)
    timestamp: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "StatusPayload":
        return cls(
            state=d.get("state"),
            uptime_s=d.get("uptime_s"),
            downlink_mbps=d.get("downlink_mbps"),
            uplink_mbps=d.get("uplink_mbps"),
            pop_ping_latency_ms=d.get("pop_ping_latency_ms"),
            pop_ping_drop_rate=d.get("pop_ping_drop_rate"),
            obstruction_pct=d.get("obstruction_pct"),
            snr=d.get("snr"),
            alerts=d.get("alerts") or [],
            timestamp=d.get("timestamp"),
        )


@dataclass
class LinkUsage:
    today_rx_gb: Optional[float] = None
    today_tx_gb: Optional[float] = None
    month_rx_gb: Optional[float] = None
    month_tx_gb: Optional[float] = None

    @classmethod
    def from_dict(cls, d: dict) -> "LinkUsage":
        return cls(
            today_rx_gb=d.get("today_rx_gb"),
            today_tx_gb=d.get("today_tx_gb"),
            month_rx_gb=d.get("month_rx_gb"),
            month_tx_gb=d.get("month_tx_gb"),
        )


@dataclass
class LinkStatus:
    name: str
    type: Optional[str] = None  # 'starlink' | 'cellular' | 'ethernet' | 'wifi'
    status: Optional[str] = None
    isp: Optional[str] = None
    ip: Optional[str] = None
    slot: Optional[int] = None
    rx_bps: Optional[float] = None
    tx_bps: Optional[float] = None
    rx_bps_max: Optional[float] = None
    tx_bps_max: Optional[float] = None
    latency_ms: Optional[float] = None
    jitter_ms: Optional[float] = None
    packet_loss_pct: Optional[float] = None
    availability_pct: Optional[float] = None
    usage: Optional[LinkUsage] = None  # today + month-to-date GB

    @classmethod
    def from_dict(cls, d: dict) -> "LinkStatus":
        return cls(
            name=d.get("name", "unknown"),
            type=d.get("type"),
            status=d.get("status"),
            isp=d.get("isp"),
            ip=d.get("ip"),
            slot=d.get("slot"),
            rx_bps=d.get("rx_bps"),
            tx_bps=d.get("tx_bps"),
            rx_bps_max=d.get("rx_bps_max"),
            tx_bps_max=d.get("tx_bps_max"),
            latency_ms=d.get("latency_ms"),
            jitter_ms=d.get("jitter_ms"),
            packet_loss_pct=d.get("packet_loss_pct"),
            availability_pct=d.get("availability_pct"),
            usage=LinkUsage.from_dict(d["usage"]) if d.get("usage") else None,
        )


@dataclass
class TelemetrySnapshot:
    gps: Optional[GpsPayload] = None
    status: Optional[StatusPayload] = None
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "TelemetrySnapshot":
        gps = GpsPayload.from_dict(d["gps"]) if d.get("gps") else None
        status = StatusPayload.from_dict(d["status"]) if d.get("status") else None
        return cls(gps=gps, status=status, raw=d)
