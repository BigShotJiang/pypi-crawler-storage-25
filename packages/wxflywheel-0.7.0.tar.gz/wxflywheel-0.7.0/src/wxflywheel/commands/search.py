from __future__ import annotations

import base64
import json
import re
from html import unescape
from typing import Any
from urllib.parse import unquote

import click
from click.core import ParameterSource

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import NETWORK_ERROR_CODE, WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload

ARTICLE_SEARCH_PATH = "/v1/Finder/WebSearch"
ARTICLE_DETAIL_V2_PATH = "/v1/Gh/ArticleDetailV2"
STICKER_DETAIL_PATH = "/v1/Gh/StickerDetail"
ARTICLE_BUSINESS_TYPE = 2
ARTICLE_SCENE = 101
CURSOR_VERSION = 1
DEFAULT_SORT = "default"
NEWEST_SORT = "newest"
HOT_SORT = "hot"
SORT_CHOICES = (DEFAULT_SORT, NEWEST_SORT, HOT_SORT)

HIGHLIGHT_TAG_RE = re.compile(r"</?em\b[^>]*>")
READ_COUNT_RE = re.compile(r"(?:^|&)show_tag=R_2_1_(\d+)(?:&|$)")


@click.group()
def search() -> None:
    """WeChat Search (微信搜一搜) — the in-app WeChat search engine that indexes official-account articles, videos, mini-programs and more. These commands cover four search intents: search-suggestion related keywords (`search related`), normalized official-account article result lists (`search article`), single official-account article detail retrieval (`search article-detail`), and single sticker (贴图/photo-essay) detail retrieval (`search sticker-detail`)."""


@search.command()
@click.option("--seed", required=True, help="Seed keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, seed: str) -> JsonObject:
    """Get long-tail user-query related keywords for a seed term from WeChat Search (e.g. seed='咖啡' → ['附近咖啡店', '星巴克咖啡', '中国咖啡十大品牌']). These are phrase-level actual user queries from WeChat Search's suggestion aggregator, NOT short word associations — for short word-level terms use 'wxflywheel wxindex related' instead. Requires the WeChat account (identified by --key) to be online. Returns {seed, related[]}."""
    client = require_client(runtime)
    payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": seed})
    words = payload["data"]["words"]
    return success_payload({"seed": seed, "related": words}, payload["message"])


@search.command()
@click.option(
    "--url",
    "article_url",
    required=True,
    help="Full WeChat official-account article URL. Prefer the exact url returned by 'wxflywheel search article' so query parameters like chksm stay intact.",
)
@click.pass_obj
@json_command
def article_detail(runtime: RuntimeContext, article_url: str) -> JsonObject:
    """Fetch one WeChat official-account article detail page as a single Agent-facing payload: article info, full body HTML, six engagement metrics, and selected comments. This command wraps the backend's new ArticleDetailV2 aggregation endpoint, so the CLI caller does NOT manually chain 'BatchGetAppMsg + AppMsgCommentList'. Returns {article, metrics, comments, comments_error?}. The comments block is explicitly selected comments, not all raw comments."""
    client = require_client(runtime)
    payload = client.get(ARTICLE_DETAIL_V2_PATH, url=article_url)
    detail = _build_article_detail_output(payload["data"])
    return success_payload(detail, payload["message"])


@search.command()
@click.option(
    "--url",
    "sticker_url",
    required=True,
    help=(
        "Full WeChat sticker article URL (贴图 URL). Use the exact url returned by "
        "'wxflywheel search article' or the docUrl field from StickerSearchWithDetails "
        "results. Stickers are photo-essay posts (item_show_type=8) on official accounts, "
        "similar to Xiaohongshu image-text notes — they carry an image gallery instead of "
        "a long-form HTML body."
    ),
)
@click.pass_obj
@json_command
def sticker_detail(runtime: RuntimeContext, sticker_url: str) -> JsonObject:
    """Fetch one WeChat official-account sticker (贴图) detail page — a photo-essay post (类似小红书图文) whose primary content is an image gallery plus short body text, NOT a long-form HTML article. Use `search article-detail` for long-form articles; use this command for sticker/photo-essay posts (item_show_type=8, page_type=2). This command wraps the backend's StickerDetail aggregation endpoint which internally calls BatchGetAppMsg(CGI 2594) + AppMsgCommentList(CGI 25246). The returned fields are 100% aligned with the web management console's sticker detail drawer: sticker_info (title, account, location, date, originality), pictures (image gallery with dimensions and QR detection), engagement_metrics (read/like/watching/share/collect/comment counts), text_content, hashtags, topics (with read counts and article counts), monetization (tipping/ads/product window/paid subscription), and selected comments with threaded replies. Returns {sticker_info, pictures, engagement_metrics, text_content, hashtags, topics, monetization, comments, comments_error?}."""
    client = require_client(runtime)
    payload = client.get(STICKER_DETAIL_PATH, url=sticker_url)
    detail = _build_sticker_detail_output(payload["data"])
    return success_payload(detail, payload["message"])


@search.command()
@click.option(
    "--keyword",
    default=None,
    help="Keyword for a new article-list search.",
)
@click.option(
    "--cursor",
    default=None,
    help="Opaque next-page cursor returned by a previous 'wxflywheel search article' response.",
)
@click.option(
    "--sort",
    "sort_name",
    type=click.Choice(SORT_CHOICES, case_sensitive=False),
    default=DEFAULT_SORT,
    show_default=True,
    help="Article list order. Use only with --keyword.",
)
@click.pass_obj
@json_command
def article(
    runtime: RuntimeContext,
    keyword: str | None,
    cursor: str | None,
    sort_name: str,
) -> JsonObject:
    """Search WeChat Search official-account article results and return a normalized article list, NOT article bodies, comments or engagement-detail pages. Use --keyword to start a new search and choose one of the three live-verified list orders (`default`, `newest`, `hot`); use --cursor to fetch the next page of a previous result set without manually handling offset, search_id or cookies. Returns {keyword, sort, has_more, next_cursor?, items[]} where each item keeps only article_id/title/summary/source_name/published_at_ts/url/cover_url plus read_count/read_count_text when the live response actually includes reading-hotness metadata."""
    ctx = click.get_current_context()
    sort_source = ctx.get_parameter_source("sort_name")
    if (keyword is None) == (cursor is None):
        raise click.UsageError(
            "Provide exactly one of --keyword or --cursor. Use --keyword to start a new article search and --cursor to fetch the next page of a previous article result set."
        )
    if cursor is not None and sort_source != ParameterSource.DEFAULT:
        raise click.UsageError(
            "Do not pass --sort together with --cursor. The cursor already contains the original article-search order."
        )

    if cursor is not None:
        cursor_payload = _decode_cursor(cursor)
        request_keyword = cursor_payload["keyword"]
        request_sort = cursor_payload["sort"]
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=cursor_payload["offset"],
            search_id=cursor_payload["search_id"],
            cookies=cursor_payload.get("cookies"),
        )
    else:
        request_keyword = keyword if keyword is not None else ""
        request_sort = sort_name
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=0,
            search_id="",
            cookies=None,
        )

    client = require_client(runtime)
    payload = client.post(ARTICLE_SEARCH_PATH, body=body)
    article_data = _build_article_output(payload["data"], keyword=request_keyword, sort_name=request_sort)
    return success_payload(article_data, payload["message"])


def _build_article_search_body(
    *, keyword: str, sort_name: str, offset: int, search_id: str, cookies: str | None
) -> JsonObject:
    body: JsonObject = {
        "KeyWord": keyword,
        "Offset": offset,
        "BusinessType": ARTICLE_BUSINESS_TYPE,
        "Scene": ARTICLE_SCENE,
        "SearchId": search_id,
    }
    ext_req_params = _build_article_ext_req_params(sort_name=sort_name, cookies=cookies)
    if ext_req_params:
        body["ExtReqParams"] = ext_req_params
    return body


def _build_article_ext_req_params(*, sort_name: str, cookies: str | None) -> list[JsonObject]:
    params: list[JsonObject] = []
    if sort_name == NEWEST_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"2\"]"})
    elif sort_name == HOT_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"4\"]"})

    if isinstance(cookies, str) and cookies:
        params.append({"Key": "cookies", "TextValue": cookies})
    return params


def _build_article_output(payload_data: Any, *, keyword: str, sort_name: str) -> JsonObject:
    outer_data = _require_dict(payload_data, field_name="WebSearch outer data")
    raw_inner_json = outer_data.get("json")
    if not isinstance(raw_inner_json, str) or not raw_inner_json.strip():
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is missing or empty, so the article result list cannot be parsed.",
        )

    try:
        inner_payload = json.loads(raw_inner_json)
    except ValueError as exc:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is not valid JSON, so the article result list cannot be parsed.",
        ) from exc

    inner_data = _require_dict(inner_payload, field_name="WebSearch inner data.json")
    raw_groups = inner_data.get("data")
    if not isinstance(raw_groups, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article search payload is missing the inner data[] groups, so the article result list cannot be parsed.",
        )

    article_group = _find_article_group(raw_groups)
    if article_group is None:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    items = _normalize_article_items(article_group.get("items"))
    if not items:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    has_more = _coerce_intlike(inner_data.get("continueFlag"), field_name="continueFlag") == 1

    result: JsonObject = {
        "keyword": keyword,
        "sort": sort_name,
        "has_more": has_more,
        "items": items,
    }
    if has_more:
        result["next_cursor"] = _encode_cursor(
            {
                "v": CURSOR_VERSION,
                "keyword": keyword,
                "sort": sort_name,
                "offset": _coerce_intlike(inner_data.get("offset"), field_name="offset"),
                "search_id": _require_string(inner_data.get("searchID"), field_name="searchID"),
                "cookies": _require_string(inner_data.get("cookies"), field_name="cookies"),
            }
        )
    return result


def _find_article_group(raw_groups: list[object]) -> dict[str, Any] | None:
    for group in raw_groups:
        if not isinstance(group, dict):
            continue
        raw_type = group.get("type")
        if _try_coerce_intlike(raw_type) == ARTICLE_BUSINESS_TYPE:
            return group
    return None


def _normalize_article_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article group exists but its items field is not a list, so the article result list cannot be normalized.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"article item #{index}")
        source = _require_dict(item.get("source"), field_name=f"article item #{index}.source")
        article: JsonObject = {
            "article_id": _require_string(item.get("docID"), field_name=f"article item #{index}.docID"),
            "title": _clean_highlight_text(
                _require_string(item.get("title"), field_name=f"article item #{index}.title")
            ),
            "summary": _clean_highlight_text(
                _require_string(
                    item.get("desc"),
                    field_name=f"article item #{index}.desc",
                    allow_empty=True,
                )
            ),
            "source_name": _require_string(
                source.get("title"), field_name=f"article item #{index}.source.title"
            ),
            "published_at_ts": _coerce_intlike(
                item.get("timestamp"), field_name=f"article item #{index}.timestamp"
            ),
            "url": _require_string(item.get("doc_url"), field_name=f"article item #{index}.doc_url"),
            "cover_url": _require_string(
                item.get("thumbUrl"), field_name=f"article item #{index}.thumbUrl"
            ),
        }

        read_count_text = _extract_read_count_text(source.get("tag"))
        if read_count_text is not None:
            article["read_count_text"] = read_count_text

        read_count = _extract_read_count(item.get("report_extinfo_str"))
        if read_count is not None:
            article["read_count"] = read_count

        normalized.append(article)
    return normalized


def _build_article_detail_output(payload_data: Any) -> JsonObject:
    data = _require_dict(payload_data, field_name="ArticleDetailV2 data")
    article = _require_dict(data.get("article"), field_name="ArticleDetailV2 article")
    metrics = _require_dict(data.get("metrics"), field_name="ArticleDetailV2 metrics")
    comments = _require_dict(data.get("comments"), field_name="ArticleDetailV2 comments")

    normalized: JsonObject = {
        "article": {
            "title": _require_string(article.get("title"), field_name="ArticleDetailV2 article.title", allow_empty=True),
            "source_name": _require_string(
                article.get("source_name"),
                field_name="ArticleDetailV2 article.source_name",
                allow_empty=True,
            ),
            "author": _require_string(article.get("author"), field_name="ArticleDetailV2 article.author", allow_empty=True),
            "summary": _require_string(article.get("summary"), field_name="ArticleDetailV2 article.summary", allow_empty=True),
            "published_at_text": _require_string(
                article.get("published_at_text"),
                field_name="ArticleDetailV2 article.published_at_text",
                allow_empty=True,
            ),
            "published_at_ts": _coerce_intlike(
                article.get("published_at_ts"), field_name="ArticleDetailV2 article.published_at_ts"
            ),
            "url": _require_string(article.get("url"), field_name="ArticleDetailV2 article.url"),
            "content_html": _require_string(
                article.get("content_html"),
                field_name="ArticleDetailV2 article.content_html",
                allow_empty=True,
            ),
        },
        "metrics": {
            "read_count": _coerce_intlike(metrics.get("read_count"), field_name="ArticleDetailV2 metrics.read_count"),
            "like_count": _coerce_intlike(metrics.get("like_count"), field_name="ArticleDetailV2 metrics.like_count"),
            "watching_count": _coerce_intlike(
                metrics.get("watching_count"), field_name="ArticleDetailV2 metrics.watching_count"
            ),
            "share_count": _coerce_intlike(metrics.get("share_count"), field_name="ArticleDetailV2 metrics.share_count"),
            "collect_count": _coerce_intlike(
                metrics.get("collect_count"), field_name="ArticleDetailV2 metrics.collect_count"
            ),
            "comment_count": _coerce_intlike(
                metrics.get("comment_count"), field_name="ArticleDetailV2 metrics.comment_count"
            ),
            "comment_enabled": _require_bool(
                metrics.get("comment_enabled"), field_name="ArticleDetailV2 metrics.comment_enabled"
            ),
        },
        "comments": {
            "scope": _require_selected_comment_scope(comments.get("scope")),
            "returned_count": _coerce_intlike(
                comments.get("returned_count"), field_name="ArticleDetailV2 comments.returned_count"
            ),
            "items": _normalize_comment_items(comments.get("items")),
        },
    }

    comments_error = data.get("comments_error")
    if isinstance(comments_error, str) and comments_error:
        normalized["comments_error"] = comments_error

    return normalized


def _normalize_comment_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "ArticleDetailV2 comments.items is not a list, so selected comments cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"ArticleDetailV2 comments.items[{index}]")
        normalized_item: JsonObject = {
            "user_comment_id": _coerce_intlike(
                item.get("userCommentId"),
                field_name=f"ArticleDetailV2 comments.items[{index}].userCommentId",
            ),
            "nick_name": _require_string(
                item.get("nickName"),
                field_name=f"ArticleDetailV2 comments.items[{index}].nickName",
                allow_empty=True,
            ),
            "content": _require_string(
                item.get("content"),
                field_name=f"ArticleDetailV2 comments.items[{index}].content",
                allow_empty=True,
            ),
            "create_time": _coerce_intlike(
                item.get("createTime"),
                field_name=f"ArticleDetailV2 comments.items[{index}].createTime",
            ),
            "like_count": _coerce_intlike(
                item.get("likeNum"),
                field_name=f"ArticleDetailV2 comments.items[{index}].likeNum",
            ),
            "is_top": _coerce_intlike(
                item.get("isTop"),
                field_name=f"ArticleDetailV2 comments.items[{index}].isTop",
            ),
        }
        reply = item.get("reply")
        if reply is not None:
            normalized_item["reply"] = _normalize_comment_reply(
                reply, field_name=f"ArticleDetailV2 comments.items[{index}].reply"
            )
        normalized.append(normalized_item)
    return normalized


def _normalize_comment_reply(raw_reply: Any, *, field_name: str) -> JsonObject:
    reply = _require_dict(raw_reply, field_name=field_name)
    raw_list = reply.get("replyList")
    if not isinstance(raw_list, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name}.replyList is not a list, so selected comment replies cannot be normalized safely.",
        )
    normalized_replies: list[JsonObject] = []
    for index, raw_item in enumerate(raw_list, start=1):
        item = _require_dict(raw_item, field_name=f"{field_name}.replyList[{index}]")
        normalized_replies.append(
            {
                "content": _require_string(
                    item.get("content"),
                    field_name=f"{field_name}.replyList[{index}].content",
                    allow_empty=True,
                ),
                "create_time": _coerce_intlike(
                    item.get("createTime"),
                    field_name=f"{field_name}.replyList[{index}].createTime",
                ),
                "reply_id": _coerce_intlike(
                    item.get("replyId"),
                    field_name=f"{field_name}.replyList[{index}].replyId",
                ),
                "like_count": _coerce_intlike(
                    item.get("replyLikeNum"),
                    field_name=f"{field_name}.replyList[{index}].replyLikeNum",
                ),
            }
        )
    return {"reply_list": normalized_replies}


def _clean_highlight_text(text: str) -> str:
    return unescape(HIGHLIGHT_TAG_RE.sub("", text))


def _extract_read_count_text(raw_tags: Any) -> str | None:
    if not isinstance(raw_tags, list):
        return None
    for raw_tag in raw_tags:
        if not isinstance(raw_tag, dict):
            continue
        title = raw_tag.get("title")
        if isinstance(title, str) and title.startswith("阅读"):
            return title
    return None


def _extract_read_count(raw_report_extinfo: Any) -> int | None:
    if not isinstance(raw_report_extinfo, str) or not raw_report_extinfo:
        return None
    decoded = unquote(raw_report_extinfo)
    match = READ_COUNT_RE.search(decoded)
    if match is None:
        return None
    return int(match.group(1))


def _encode_cursor(cursor_payload: JsonObject) -> str:
    raw = json.dumps(cursor_payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_cursor(raw_cursor: str) -> dict[str, Any]:
    cursor_value = raw_cursor.strip()
    if not cursor_value:
        raise click.BadParameter(
            "Cursor is empty. Pass the exact next_cursor string returned by a previous 'wxflywheel search article' response.",
            param_hint="--cursor",
        )

    padding = "=" * (-len(cursor_value) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(f"{cursor_value}{padding}")
        payload = json.loads(decoded_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise click.BadParameter(
            "Cursor is not a valid article-search cursor. It may have been truncated, copied incorrectly, or generated by a different command/version.",
            param_hint="--cursor",
        ) from exc

    if not isinstance(payload, dict):
        raise click.BadParameter(
            "Cursor is not a JSON object. Pass the exact next_cursor string returned by 'wxflywheel search article'.",
            param_hint="--cursor",
        )

    version = payload.get("v")
    if version != CURSOR_VERSION:
        raise click.BadParameter(
            f"Cursor version is unsupported (expected v={CURSOR_VERSION}). Generate a fresh cursor with the current 'wxflywheel search article' command.",
            param_hint="--cursor",
        )

    keyword = payload.get("keyword")
    sort_name = payload.get("sort")
    search_id = payload.get("search_id")
    cookies = payload.get("cookies")

    if not isinstance(keyword, str) or not keyword:
        raise click.BadParameter(
            "Cursor is missing a valid keyword field.", param_hint="--cursor"
        )
    if sort_name not in SORT_CHOICES:
        raise click.BadParameter(
            "Cursor is missing a valid sort field.", param_hint="--cursor"
        )
    if not isinstance(search_id, str) or not search_id:
        raise click.BadParameter(
            "Cursor is missing a valid search_id field.", param_hint="--cursor"
        )
    if cookies is not None and not isinstance(cookies, str):
        raise click.BadParameter(
            "Cursor cookies field must be a string when present.", param_hint="--cursor"
        )

    try:
        offset = _coerce_intlike(payload.get("offset"), field_name="cursor.offset")
    except WxflywheelError as exc:
        raise click.BadParameter(exc.message, param_hint="--cursor") from exc

    return {
        "keyword": keyword,
        "sort": sort_name,
        "offset": offset,
        "search_id": search_id,
        "cookies": cookies,
    }


def _require_dict(value: Any, *, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is not a JSON object, so the payload cannot be normalized safely.",
        )
    return value


def _require_string(value: Any, *, field_name: str, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        requirement = "string" if allow_empty else "non-empty string"
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not a {requirement}, so the payload cannot be normalized safely.",
        )
    return value


def _require_bool(value: Any, *, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not a bool, so the payload cannot be normalized safely.",
        )
    return value


def _require_selected_comment_scope(value: Any) -> str:
    if value != "selected":
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "ArticleDetailV2 comments.scope is not 'selected', so the article detail payload does not match the curated CLI contract.",
        )
    return "selected"


def _coerce_intlike(value: Any, *, field_name: str) -> int:
    coerced = _try_coerce_intlike(value)
    if coerced is None:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not numeric, so the payload cannot be normalized safely.",
        )
    return coerced


def _try_coerce_intlike(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError:
            return None
    return None


# ---------------------------------------------------------------------------
# Sticker detail normalizers — 100% aligned with StickerDetailDrawer.tsx
# ---------------------------------------------------------------------------


def _build_sticker_detail_output(payload_data: Any) -> JsonObject:
    data = _require_dict(payload_data, field_name="StickerDetail data")

    raw_info = _require_dict(data.get("sticker_info"), field_name="StickerDetail sticker_info")
    raw_metrics = _require_dict(
        data.get("engagement_metrics"), field_name="StickerDetail engagement_metrics"
    )
    raw_copyright = _require_dict(data.get("copyright"), field_name="StickerDetail copyright")
    raw_monetization = _require_dict(
        data.get("monetization"), field_name="StickerDetail monetization"
    )
    raw_comments = _require_dict(data.get("comments"), field_name="StickerDetail comments")

    normalized: JsonObject = {
        "sticker_info": {
            "title": _require_string(
                raw_info.get("title"),
                field_name="StickerDetail sticker_info.title",
                allow_empty=True,
            ),
            "account_name": _require_string(
                raw_info.get("account_name"),
                field_name="StickerDetail sticker_info.account_name",
                allow_empty=True,
            ),
            "ip_location": _require_string(
                raw_info.get("ip_location"),
                field_name="StickerDetail sticker_info.ip_location",
                allow_empty=True,
            ),
            "published_at": _require_string(
                raw_info.get("published_at"),
                field_name="StickerDetail sticker_info.published_at",
                allow_empty=True,
            ),
            "published_at_timestamp": _coerce_intlike(
                raw_info.get("published_at_timestamp"),
                field_name="StickerDetail sticker_info.published_at_timestamp",
            ),
            "article_url": _require_string(
                raw_info.get("article_url"),
                field_name="StickerDetail sticker_info.article_url",
            ),
            "is_original": _require_bool(
                raw_copyright.get("is_original"),
                field_name="StickerDetail copyright.is_original",
            ),
        },
        "pictures": _normalize_sticker_pictures(data.get("pictures")),
        "engagement_metrics": {
            "read_count": _coerce_intlike(
                raw_metrics.get("read_count"),
                field_name="StickerDetail engagement_metrics.read_count",
            ),
            "like_count": _coerce_intlike(
                raw_metrics.get("like_count"),
                field_name="StickerDetail engagement_metrics.like_count",
            ),
            "watching_count": _coerce_intlike(
                raw_metrics.get("watching_count"),
                field_name="StickerDetail engagement_metrics.watching_count",
            ),
            "share_count": _coerce_intlike(
                raw_metrics.get("share_count"),
                field_name="StickerDetail engagement_metrics.share_count",
            ),
            "collect_count": _coerce_intlike(
                raw_metrics.get("collect_count"),
                field_name="StickerDetail engagement_metrics.collect_count",
            ),
            "comment_count": _coerce_intlike(
                raw_metrics.get("comment_count"),
                field_name="StickerDetail engagement_metrics.comment_count",
            ),
            "comment_enabled": _require_bool(
                raw_metrics.get("comment_enabled"),
                field_name="StickerDetail engagement_metrics.comment_enabled",
            ),
        },
        "text_content": _require_string(
            data.get("text_content"),
            field_name="StickerDetail text_content",
            allow_empty=True,
        ),
        "hashtags": _normalize_sticker_hashtags(data.get("hashtags")),
        "topics": _normalize_sticker_topics(data.get("topics")),
        "monetization": _normalize_sticker_monetization(raw_monetization),
        "comments": _normalize_sticker_comments(raw_comments),
    }

    comments_error = data.get("comments_error")
    if isinstance(comments_error, str) and comments_error:
        normalized["comments_error"] = comments_error

    return normalized


def _normalize_sticker_pictures(raw_pictures: Any) -> list[JsonObject]:
    if not isinstance(raw_pictures, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail pictures is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_pic in enumerate(raw_pictures, start=1):
        pic = _require_dict(raw_pic, field_name=f"StickerDetail pictures[{index}]")
        normalized.append(
            {
                "image_url": _require_string(
                    pic.get("image_url"),
                    field_name=f"StickerDetail pictures[{index}].image_url",
                ),
                "width_px": _coerce_intlike(
                    pic.get("width_px"),
                    field_name=f"StickerDetail pictures[{index}].width_px",
                ),
                "height_px": _coerce_intlike(
                    pic.get("height_px"),
                    field_name=f"StickerDetail pictures[{index}].height_px",
                ),
                "is_qr_code": _require_bool(
                    pic.get("is_qr_code"),
                    field_name=f"StickerDetail pictures[{index}].is_qr_code",
                ),
            }
        )
    return normalized


def _normalize_sticker_hashtags(raw_hashtags: Any) -> list[str]:
    if not isinstance(raw_hashtags, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail hashtags is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    result: list[str] = []
    for index, raw_tag in enumerate(raw_hashtags, start=1):
        result.append(
            _require_string(
                raw_tag,
                field_name=f"StickerDetail hashtags[{index}]",
                allow_empty=True,
            )
        )
    return result


def _normalize_sticker_topics(raw_topics: Any) -> list[JsonObject]:
    if not isinstance(raw_topics, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail topics is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_topic in enumerate(raw_topics, start=1):
        topic = _require_dict(raw_topic, field_name=f"StickerDetail topics[{index}]")
        normalized.append(
            {
                "topic_name": _require_string(
                    topic.get("topic_name"),
                    field_name=f"StickerDetail topics[{index}].topic_name",
                ),
                "topic_read_count": _coerce_intlike(
                    topic.get("topic_read_count"),
                    field_name=f"StickerDetail topics[{index}].topic_read_count",
                ),
                "topic_article_count": _coerce_intlike(
                    topic.get("topic_article_count"),
                    field_name=f"StickerDetail topics[{index}].topic_article_count",
                ),
            }
        )
    return normalized


def _normalize_sticker_monetization(raw_monetization: dict[str, Any]) -> JsonObject:
    raw_paid = _require_dict(
        raw_monetization.get("paid_subscription"),
        field_name="StickerDetail monetization.paid_subscription",
    )
    raw_product_items = raw_monetization.get("product_window_items")
    if not isinstance(raw_product_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail monetization.product_window_items is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    return {
        "tipping_enabled": _require_bool(
            raw_monetization.get("tipping_enabled"),
            field_name="StickerDetail monetization.tipping_enabled",
        ),
        "has_advertisement": _require_bool(
            raw_monetization.get("has_advertisement"),
            field_name="StickerDetail monetization.has_advertisement",
        ),
        "product_window_item_count": len(raw_product_items),
        "paid_subscription": {
            "is_paid": _require_bool(
                raw_paid.get("is_paid"),
                field_name="StickerDetail monetization.paid_subscription.is_paid",
            ),
            "fee": _coerce_intlike(
                raw_paid.get("fee"),
                field_name="StickerDetail monetization.paid_subscription.fee",
            ),
        },
    }


def _normalize_sticker_comments(raw_comments: dict[str, Any]) -> JsonObject:
    scope = raw_comments.get("scope")
    if scope != "selected":
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail comments.scope is not 'selected', so the sticker detail payload does not match the curated CLI contract.",
        )

    raw_items = raw_comments.get("items")
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail comments.items is not a list, so selected comments cannot be normalized safely.",
        )
    normalized_items: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"StickerDetail comments.items[{index}]")
        normalized_item: JsonObject = {
            "nick_name": _require_string(
                item.get("nick_name"),
                field_name=f"StickerDetail comments.items[{index}].nick_name",
                allow_empty=True,
            ),
            "content": _require_string(
                item.get("content"),
                field_name=f"StickerDetail comments.items[{index}].content",
                allow_empty=True,
            ),
            "like_count": _coerce_intlike(
                item.get("like_count"),
                field_name=f"StickerDetail comments.items[{index}].like_count",
            ),
            "posted_at_timestamp": _coerce_intlike(
                item.get("posted_at_timestamp"),
                field_name=f"StickerDetail comments.items[{index}].posted_at_timestamp",
            ),
            "ip_location": _require_string(
                item.get("ip_location"),
                field_name=f"StickerDetail comments.items[{index}].ip_location",
                allow_empty=True,
            ),
            "is_top": _require_bool(
                item.get("is_top"),
                field_name=f"StickerDetail comments.items[{index}].is_top",
            ),
            "is_author_reply": _require_bool(
                item.get("is_author_reply"),
                field_name=f"StickerDetail comments.items[{index}].is_author_reply",
            ),
        }
        raw_replies = item.get("replies")
        if isinstance(raw_replies, list) and raw_replies:
            normalized_item["replies"] = _normalize_sticker_comment_replies(
                raw_replies,
                field_name=f"StickerDetail comments.items[{index}].replies",
            )
        normalized_items.append(normalized_item)

    return {
        "scope": "selected",
        "returned_count": _coerce_intlike(
            raw_comments.get("returned_count"),
            field_name="StickerDetail comments.returned_count",
        ),
        "total_selected_count": _coerce_intlike(
            raw_comments.get("total_selected_count"),
            field_name="StickerDetail comments.total_selected_count",
        ),
        "items": normalized_items,
    }


def _normalize_sticker_comment_replies(
    raw_replies: list[Any], *, field_name: str
) -> list[JsonObject]:
    normalized: list[JsonObject] = []
    for index, raw_reply in enumerate(raw_replies, start=1):
        reply = _require_dict(raw_reply, field_name=f"{field_name}[{index}]")
        normalized.append(
            {
                "nick_name": _require_string(
                    reply.get("nick_name"),
                    field_name=f"{field_name}[{index}].nick_name",
                    allow_empty=True,
                ),
                "content": _require_string(
                    reply.get("content"),
                    field_name=f"{field_name}[{index}].content",
                    allow_empty=True,
                ),
                "like_count": _coerce_intlike(
                    reply.get("like_count"),
                    field_name=f"{field_name}[{index}].like_count",
                ),
                "posted_at_timestamp": _coerce_intlike(
                    reply.get("posted_at_timestamp"),
                    field_name=f"{field_name}[{index}].posted_at_timestamp",
                ),
                "is_author": _require_bool(
                    reply.get("is_author"),
                    field_name=f"{field_name}[{index}].is_author",
                ),
            }
        )
    return normalized
