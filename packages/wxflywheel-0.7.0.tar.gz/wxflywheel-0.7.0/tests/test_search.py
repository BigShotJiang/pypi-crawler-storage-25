import base64
import json
from unittest.mock import patch

import click
import pytest
from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel import __version__
from wxflywheel.cli import cli, main
from wxflywheel.commands.search import (
    _build_article_detail_output,
    _build_article_output,
    _build_sticker_detail_output,
    _coerce_intlike,
    _decode_cursor,
    _encode_cursor,
    _extract_read_count,
    _extract_read_count_text,
    _find_article_group,
    _normalize_article_items,
    _normalize_sticker_comments,
    _require_dict,
    _require_string,
    _try_coerce_intlike,
)
from wxflywheel.exceptions import WxflywheelError

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def _make_article_item(
    *,
    title: str = '<em class="highlight">微信</em>又上新功能',
    desc: str = '3月31日，<em class="highlight">微信</em>派公众号发文宣布微信推出一项新功能……',
    doc_id: str = "4132226094060041310",
    timestamp: int = 1775029376,
    doc_url: str = "http://mp.weixin.qq.com/article-1",
    thumb_url: str = "https://mmbiz.qpic.cn/article-1.jpg",
    source_name: str = "新华社",
    tag_title: str | None = "阅读 10万+",
    report_extinfo_str: str = (
        "src_channel%3D1930611252_4_0_4075929821_13%26show_tag%3DR_2_1_100000"
    ),
) -> dict[str, object]:
    source: dict[str, object] = {"title": source_name}
    if tag_title is not None:
        source["tag"] = [{"title": tag_title, "type": 2, "noBg": True}]
    return {
        "title": title,
        "desc": desc,
        "docID": doc_id,
        "timestamp": timestamp,
        "doc_url": doc_url,
        "thumbUrl": thumb_url,
        "source": source,
        "report_extinfo_str": report_extinfo_str,
    }


def _make_websearch_response(
    inner_payload: dict[str, object], *, message: str = ""
) -> dict[str, object]:
    return {
        "code": 200,
        "data": {
            "baseResponse": {"ret": 0, "errMsg": {"str": ""}},
            "updateCode": 0,
            "offset": inner_payload.get("offset", 0),
            "json": json.dumps(inner_payload, ensure_ascii=False),
        },
        "message": message,
    }


def _make_article_inner_payload(
    *,
    items: list[dict[str, object]] | None = None,
    continue_flag: int = 1,
    offset: int = 23,
    search_id: str = "search-id-1",
    cookies: str = '{"doc_offset":0,"scene":101}',
) -> dict[str, object]:
    return {
        "continueFlag": continue_flag,
        "offset": offset,
        "searchID": search_id,
        "cookies": cookies,
        "data": (
            [
                {
                    "type": 2,
                    "real_type": 2,
                    "items": items if items is not None else [_make_article_item()],
                }
            ]
            if items is not None
            else [{"type": 2, "real_type": 2, "items": [_make_article_item()]}]
        ),
    }


def _make_article_detail_v2_response(*, comments_error: str | None = None) -> dict[str, object]:
    data: dict[str, object] = {
        "article": {
            "title": "未来十年，微信是普通人创业赚钱最大的机会",
            "source_name": "生财有术",
            "author": "亦仁",
            "summary": "这是一篇关于普通人如何借微信做生意的文章。",
            "published_at_text": "2026-04-09 10:30",
            "published_at_ts": 1775701800,
            "url": "http://mp.weixin.qq.com/s?__biz=abc&mid=1&idx=1&sn=xyz",
            "content_html": "<p>正文</p>",
        },
        "metrics": {
            "read_count": 5092,
            "like_count": 41,
            "watching_count": 173,
            "share_count": 691,
            "collect_count": 290,
            "comment_count": 4,
            "comment_enabled": True,
        },
        "comments": {
            "scope": "selected",
            "returned_count": 2,
            "items": [
                {
                    "userCommentId": 1,
                    "nickName": "小王",
                    "content": "这条思路很清楚",
                    "createTime": 1775701811,
                    "likeNum": 7,
                    "isTop": 1,
                    "reply": {
                        "replyList": [
                            {
                                "content": "同意",
                                "createTime": 1775701822,
                                "replyId": 101,
                                "replyLikeNum": 2,
                            }
                        ]
                    },
                },
                {
                    "userCommentId": 2,
                    "nickName": "小李",
                    "content": "收藏了",
                    "createTime": 1775701911,
                    "likeNum": 0,
                    "isTop": 0,
                },
            ],
        },
    }
    if comments_error is not None:
        data["comments_error"] = comments_error
    return {"code": 200, "data": data, "message": ""}


def test_search_related_outputs_seed_and_words_on_success(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {"words": ["社群营销怎么做", "社群活跃技巧", "社群变现"]},
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["seed"] == "社群运营"
    assert data["data"]["related"] == ["社群营销怎么做", "社群活跃技巧", "社群变现"]


def test_search_related_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"words": []}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    called_url = mock_post.call_args.args[1]
    called_params = mock_post.call_args.kwargs["params"]
    called_json = mock_post.call_args.kwargs["json"]
    assert called_url == "http://localhost:8011/v1/Finder/RelatedKeywords"
    assert called_params["key"] == "test-key"
    assert called_json == {"KeyWord": "社群运营"}


def test_search_related_api_error_exits_1(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 300, "data": None, "message": "关键词不能为空"}),
    ):
        result = runner.invoke(cli, ["search", "related", "--seed", ""], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "关键词不能为空" in err_data["message"]


def test_search_article_default_outputs_normalized_article_list(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]
    assert data["keyword"] == "微信"
    assert data["sort"] == "default"
    assert data["has_more"] is True
    assert "next_cursor" in data
    item = data["items"][0]
    assert item == {
        "article_id": "4132226094060041310",
        "title": "微信又上新功能",
        "summary": "3月31日，微信派公众号发文宣布微信推出一项新功能……",
        "source_name": "新华社",
        "published_at_ts": 1775029376,
        "url": "http://mp.weixin.qq.com/article-1",
        "cover_url": "https://mmbiz.qpic.cn/article-1.jpg",
        "read_count_text": "阅读 10万+",
        "read_count": 100000,
    }
    assert "rank" not in item
    assert "total_count" not in data
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_article_default_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    called_url = mock_post.call_args.args[1]
    called_params = mock_post.call_args.kwargs["params"]
    called_json = mock_post.call_args.kwargs["json"]
    assert called_url == "http://localhost:8011/v1/Finder/WebSearch"
    assert called_params["key"] == "test-key"
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
    }


def test_search_article_newest_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信", "--sort", "newest"], env=ENV)
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
        "ExtReqParams": [{"Key": "docSortType", "TextValue": "[\"2\"]"}],
    }


def test_search_article_hot_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信", "--sort", "hot"], env=ENV)
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
        "ExtReqParams": [{"Key": "docSortType", "TextValue": "[\"4\"]"}],
    }


def test_search_article_detail_outputs_normalized_payload(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_response = _make_article_detail_v2_response(comments_error="comment cgi timeout")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(api_response),
    ):
        result = runner.invoke(
            cli,
            ["search", "article-detail", "--url", "http://mp.weixin.qq.com/s?__biz=abc&mid=1"],
            env=ENV,
        )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]
    assert data["article"]["title"] == "未来十年，微信是普通人创业赚钱最大的机会"
    assert data["metrics"]["comment_count"] == 4
    assert data["comments"]["scope"] == "selected"
    assert data["comments"]["returned_count"] == 2
    assert data["comments"]["items"][0] == {
        "user_comment_id": 1,
        "nick_name": "小王",
        "content": "这条思路很清楚",
        "create_time": 1775701811,
        "like_count": 7,
        "is_top": 1,
        "reply": {
            "reply_list": [
                {
                    "content": "同意",
                    "create_time": 1775701822,
                    "reply_id": 101,
                    "like_count": 2,
                }
            ]
        },
    }
    assert data["comments_error"] == "comment cgi timeout"
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_article_detail_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(_make_article_detail_v2_response()),
    ) as mock_get:
        runner.invoke(
            cli,
            ["search", "article-detail", "--url", "http://mp.weixin.qq.com/s?__biz=abc&mid=1"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/v1/Gh/ArticleDetailV2"
    assert called_params == {
        "key": "test-key",
        "url": "http://mp.weixin.qq.com/s?__biz=abc&mid=1",
    }


def test_build_article_detail_output_rejects_non_selected_scope() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["scope"] = "all"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comments.scope" in exc_info.value.message


def test_build_article_detail_output_rejects_non_list_comments_items() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["items"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comments.items is not a list" in exc_info.value.message


def test_build_article_detail_output_rejects_non_list_reply_list() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["items"][0]["reply"]["replyList"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "replyList is not a list" in exc_info.value.message


def test_build_article_detail_output_rejects_non_bool_comment_enabled() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["metrics"]["comment_enabled"] = 1  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comment_enabled" in exc_info.value.message


def test_search_article_cursor_uses_server_offset_without_local_increment(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(continue_flag=0, offset=42, search_id="search-id-2")
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        result = runner.invoke(cli, ["search", "article", "--cursor", cursor], env=ENV)
    assert result.exit_code == 0
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 23,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "search-id-2",
        "ExtReqParams": [{"Key": "cookies", "TextValue": '{"doc_offset":23,"scene":101}'}],
    }


def test_search_article_cursor_keeps_newest_sort_and_cookies(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "newest",
            "offset": 20,
            "search_id": "search-id-3",
            "cookies": '{"doc_offset":20,"scene":101}',
        }
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(continue_flag=0, offset=40, search_id="search-id-3")
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        result = runner.invoke(cli, ["search", "article", "--cursor", cursor], env=ENV)
    assert result.exit_code == 0
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 20,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "search-id-3",
        "ExtReqParams": [
            {"Key": "docSortType", "TextValue": "[\"2\"]"},
            {"Key": "cookies", "TextValue": '{"doc_offset":20,"scene":101}'},
        ],
    }


def test_search_article_omits_read_fields_when_response_has_no_reading_hotness(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    item = _make_article_item(
        tag_title=None,
        report_extinfo_str="src_channel%3D1930611252_4_0_4075929821_13",
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    item_payload = payload["data"]["items"][0]
    assert "read_count" not in item_payload
    assert "read_count_text" not in item_payload


def test_search_article_ignores_non_reading_source_tags(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item(
        tag_title=None,
        report_extinfo_str="src_channel%3D1930611252_4_0_4075929821_13",
    )
    item["source"] = {
        "title": "新华社",
        "tag": [{"title": "已关注", "type": 1, "noBg": True}],
    }
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    item_payload = payload["data"]["items"][0]
    assert "read_count_text" not in item_payload


def test_search_article_prefers_reading_tag_when_other_tags_appear_first(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    item = _make_article_item(tag_title=None)
    item["source"] = {
        "title": "新华社",
        "tag": [
            {"title": "已关注", "type": 1, "noBg": True},
            {"title": "阅读 10万+", "type": 2, "noBg": True},
        ],
    }
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["read_count_text"] == "阅读 10万+"


def test_search_article_allows_empty_summary_string(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item(desc="")
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["summary"] == ""


def test_search_article_returns_success_empty_list_when_no_article_group_exists(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        {"continueFlag": 0, "offset": 0, "searchID": "search-id-empty", "cookies": "{}", "data": []}
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_returns_success_empty_list_when_article_group_items_are_empty(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        _make_article_inner_payload(
            items=[],
            continue_flag=1,
            offset=23,
            search_id="search-id-empty-items",
        )
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_empty_group_forces_has_more_false(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        {
            "continueFlag": 1,
            "offset": 23,
            "searchID": "search-id-empty-next",
            "cookies": '{"doc_offset":23,"scene":101}',
            "data": [{"type": 7, "items": []}],
        }
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_requires_exactly_one_of_keyword_or_cursor(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["search", "article"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "exactly one of --keyword or --cursor" in err_data["message"]


def test_search_article_rejects_keyword_and_cursor_together(
    capsys: pytest.CaptureFixture[str],
) -> None:
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    assert main(["search", "article", "--keyword", "微信", "--cursor", cursor]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "exactly one of --keyword or --cursor" in err_data["message"]


def test_search_article_rejects_sort_with_cursor(capsys: pytest.CaptureFixture[str]) -> None:
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "hot",
            "offset": 20,
            "search_id": "search-id-sort",
            "cookies": '{"doc_offset":20,"scene":101}',
        }
    )
    assert main(["search", "article", "--cursor", cursor, "--sort", "hot"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "Do not pass --sort together with --cursor" in err_data["message"]


def test_search_article_rejects_invalid_cursor(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["search", "article", "--cursor", "not-a-cursor"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "not a valid article-search cursor" in err_data["message"]


def test_search_article_rejects_cursor_with_wrong_version(
    capsys: pytest.CaptureFixture[str],
) -> None:
    cursor = _encode_cursor(
        {
            "v": 999,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    assert main(["search", "article", "--cursor", cursor]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "Cursor version is unsupported" in err_data["message"]


def test_search_article_reports_runtime_error_when_inner_json_missing(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {"baseResponse": {"ret": 0, "errMsg": {"str": ""}}, "updateCode": 0, "offset": 20},
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -999
    assert "data.json is missing or empty" in err_data["message"]


def test_search_article_reports_runtime_error_when_inner_json_is_invalid(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {
            "baseResponse": {"ret": 0, "errMsg": {"str": ""}},
            "updateCode": 0,
            "offset": 20,
            "json": "{bad json",
        },
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -999
    assert "data.json is not valid JSON" in err_data["message"]


def test_search_article_help_describes_article_list_cursor_and_three_sorts() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["search", "article", "--help"])
    assert result.exit_code == 0
    assert "article list" in result.output
    assert "--cursor" in result.output
    assert "default" in result.output
    assert "newest" in result.output
    assert "hot" in result.output


def test_search_article_internal_helpers_cover_validation_edges() -> None:
    with pytest.raises(WxflywheelError, match="inner data\\[\\] groups"):
        _build_article_output(
            {"json": json.dumps({"continueFlag": 0})},
            keyword="微信",
            sort_name="default",
        )

    assert _find_article_group([1, {"type": 7}, {"type": "2", "items": []}]) == {
        "type": "2",
        "items": [],
    }

    with pytest.raises(WxflywheelError, match="items field is not a list"):
        _normalize_article_items({"items": []})

    assert _extract_read_count_text([123, {"title": ""}]) is None
    assert _extract_read_count(None) is None

    with pytest.raises(click.BadParameter, match="Cursor is empty"):
        _decode_cursor("   ")

    raw_list_cursor = (
        base64.urlsafe_b64encode(json.dumps(["bad"]).encode("utf-8"))
        .decode("ascii")
        .rstrip("=")
    )
    with pytest.raises(click.BadParameter, match="not a JSON object"):
        _decode_cursor(raw_list_cursor)

    for payload, expected_message in (
        (
            {"v": 1, "keyword": "", "sort": "default", "offset": 1, "search_id": "sid"},
            "missing a valid keyword field",
        ),
        (
            {"v": 1, "keyword": "微信", "sort": "bad", "offset": 1, "search_id": "sid"},
            "missing a valid sort field",
        ),
        (
            {"v": 1, "keyword": "微信", "sort": "default", "offset": 1, "search_id": ""},
            "missing a valid search_id field",
        ),
        (
            {
                "v": 1,
                "keyword": "微信",
                "sort": "default",
                "offset": 1,
                "search_id": "sid",
                "cookies": 1,
            },
            "cookies field must be a string",
        ),
        (
            {
                "v": 1,
                "keyword": "微信",
                "sort": "default",
                "offset": "not-a-number",
                "search_id": "sid",
            },
            "cursor.offset is missing or not numeric",
        ),
    ):
        with pytest.raises(click.BadParameter, match=expected_message):
            _decode_cursor(_encode_cursor(payload))

    with pytest.raises(WxflywheelError, match="not a JSON object"):
        _require_dict([], field_name="bad_dict")
    with pytest.raises(WxflywheelError, match="not a non-empty string"):
        _require_string("", field_name="bad_string")
    with pytest.raises(WxflywheelError, match="not numeric"):
        _coerce_intlike("bad", field_name="bad_int")

    assert _try_coerce_intlike(True) is None
    assert _try_coerce_intlike(7) == 7
    assert _try_coerce_intlike(7.0) == 7
    assert _try_coerce_intlike("8") == 8
    assert _try_coerce_intlike(" ") is None
    assert _try_coerce_intlike("bad") is None
    assert _try_coerce_intlike(None) is None


# ---------------------------------------------------------------------------
# search sticker-detail
# ---------------------------------------------------------------------------


def _make_sticker_detail_response(
    *, comments_error: str | None = None
) -> dict[str, object]:
    data: dict[str, object] = {
        "sticker_info": {
            "title": "杭州3日游超全攻略",
            "author_name": "旅行达人",
            "account_name": "旅行笔记",
            "account_id": "gh_abc123",
            "account_avatar_url": "https://wx.qlogo.cn/mmhead/abc",
            "account_description": "分享旅行攻略",
            "account_verified": False,
            "published_at": "2026-04-09 15:30",
            "published_at_timestamp": 1775719800,
            "ip_location": "浙江",
            "article_url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
            "content_type": "贴图",
            "content_type_code": 8,
        },
        "text_content": "<a>杭州</a>三天怎么玩？",
        "pictures": [
            {
                "image_url": "https://mmbiz.qpic.cn/pic1.jpg",
                "width_px": 1080,
                "height_px": 1440,
                "theme_color_rgb": "#336699",
                "is_qr_code": False,
                "attached_product": None,
            },
            {
                "image_url": "https://mmbiz.qpic.cn/pic2.jpg",
                "width_px": 1080,
                "height_px": 810,
                "theme_color_rgb": "#99cc00",
                "is_qr_code": True,
                "attached_product": None,
            },
        ],
        "cover_images": {
            "default_url": "https://mmbiz.qpic.cn/cover.jpg",
            "square_1x1_url": "",
            "portrait_3x4_url": "",
            "image_format": "jpeg",
            "show_cover_in_feed": True,
            "watermark_enabled": False,
        },
        "engagement_metrics": {
            "read_count": 12300,
            "like_count": 88,
            "watching_count": 210,
            "share_count": 45,
            "collect_count": 320,
            "comment_count": 7,
            "comment_enabled": True,
        },
        "hashtags": ["杭州旅游", "三日游攻略"],
        "topics": [
            {
                "topic_name": "杭州旅游",
                "topic_read_count": 5800000,
                "topic_article_count": 1200,
                "topic_url": "https://mp.weixin.qq.com/topic/杭州旅游",
            },
        ],
        "monetization": {
            "has_advertisement": True,
            "ad_mark_visible": True,
            "footer_product_card": None,
            "footer_shops": [],
            "product_window_items": [{"product_id": "p1"}],
            "gift_activity": None,
            "product_activity": None,
            "tipping_enabled": False,
            "tipping_total_amount": 0,
            "tipping_prompt_text": "",
            "paid_subscription": {
                "is_paid": False,
                "preview_percent": 0,
                "price_description": "",
                "fee": 0,
            },
        },
        "copyright": {
            "is_original": True,
            "is_cartoon_copyright": False,
        },
        "comments": {
            "scope": "selected",
            "returned_count": 1,
            "total_selected_count": 3,
            "items": [
                {
                    "nick_name": "小红",
                    "avatar_url": "https://wx.qlogo.cn/mmhead/red",
                    "content": "收藏了！下周去",
                    "like_count": 5,
                    "posted_at_timestamp": 1775719900,
                    "ip_location": "上海",
                    "is_top": True,
                    "is_author_reply": False,
                    "replies": [
                        {
                            "nick_name": "旅行达人",
                            "content": "玩得开心~",
                            "like_count": 2,
                            "posted_at_timestamp": 1775720000,
                            "is_author": True,
                        }
                    ],
                },
            ],
        },
    }
    if comments_error is not None:
        data["comments_error"] = comments_error
    return {"code": 200, "data": data, "message": ""}


def test_search_sticker_detail_outputs_normalized_payload(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_response = _make_sticker_detail_response(comments_error="comment cgi timeout")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(api_response),
    ):
        result = runner.invoke(
            cli,
            ["search", "sticker-detail", "--url", "http://mp.weixin.qq.com/s?__biz=xyz&mid=2"],
            env=ENV,
        )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]

    # sticker_info (drawer section 1)
    assert data["sticker_info"] == {
        "title": "杭州3日游超全攻略",
        "account_name": "旅行笔记",
        "ip_location": "浙江",
        "published_at": "2026-04-09 15:30",
        "published_at_timestamp": 1775719800,
        "article_url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
        "is_original": True,
    }

    # pictures (drawer section 2)
    assert len(data["pictures"]) == 2
    assert data["pictures"][0] == {
        "image_url": "https://mmbiz.qpic.cn/pic1.jpg",
        "width_px": 1080,
        "height_px": 1440,
        "is_qr_code": False,
    }
    assert data["pictures"][1]["is_qr_code"] is True

    # engagement_metrics (drawer section 3)
    assert data["engagement_metrics"] == {
        "read_count": 12300,
        "like_count": 88,
        "watching_count": 210,
        "share_count": 45,
        "collect_count": 320,
        "comment_count": 7,
        "comment_enabled": True,
    }

    # text_content + hashtags (drawer section 4)
    assert data["text_content"] == "<a>杭州</a>三天怎么玩？"
    assert data["hashtags"] == ["杭州旅游", "三日游攻略"]

    # topics (drawer section 5)
    assert data["topics"] == [
        {"topic_name": "杭州旅游", "topic_read_count": 5800000, "topic_article_count": 1200},
    ]

    # monetization (drawer section 6)
    assert data["monetization"] == {
        "tipping_enabled": False,
        "has_advertisement": True,
        "product_window_item_count": 1,
        "paid_subscription": {"is_paid": False, "fee": 0},
    }

    # comments (drawer section 7)
    assert data["comments"]["scope"] == "selected"
    assert data["comments"]["returned_count"] == 1
    assert data["comments"]["total_selected_count"] == 3
    assert data["comments"]["items"][0] == {
        "nick_name": "小红",
        "content": "收藏了！下周去",
        "like_count": 5,
        "posted_at_timestamp": 1775719900,
        "ip_location": "上海",
        "is_top": True,
        "is_author_reply": False,
        "replies": [
            {
                "nick_name": "旅行达人",
                "content": "玩得开心~",
                "like_count": 2,
                "posted_at_timestamp": 1775720000,
                "is_author": True,
            }
        ],
    }

    assert data["comments_error"] == "comment cgi timeout"
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_sticker_detail_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(_make_sticker_detail_response()),
    ) as mock_get:
        runner.invoke(
            cli,
            ["search", "sticker-detail", "--url", "http://mp.weixin.qq.com/s?__biz=xyz&mid=2"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/v1/Gh/StickerDetail"
    assert called_params == {
        "key": "test-key",
        "url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
    }


def test_build_sticker_detail_output_strips_non_drawer_fields() -> None:
    """The CLI normalizer must NOT leak fields the webui drawer does not show."""
    raw = _make_sticker_detail_response()
    result = _build_sticker_detail_output(raw["data"])

    # sticker_info keeps only drawer-visible fields (not account_id, avatar, etc.)
    assert "account_id" not in result["sticker_info"]
    assert "account_avatar_url" not in result["sticker_info"]
    assert "author_name" not in result["sticker_info"]

    # pictures keep only drawer-visible fields (not theme_color_rgb, attached_product)
    assert "theme_color_rgb" not in result["pictures"][0]
    assert "attached_product" not in result["pictures"][0]

    # cover_images section not present at all (drawer doesn't show it)
    assert "cover_images" not in result

    # topics strip topic_url (drawer doesn't show it)
    assert "topic_url" not in result["topics"][0]

    # monetization simplified (no ad_mark_visible, footer_shops, etc.)
    assert "ad_mark_visible" not in result["monetization"]
    assert "footer_shops" not in result["monetization"]

    # comments strip avatar_url (drawer doesn't render avatars with URLs)
    assert "avatar_url" not in result["comments"]["items"][0]


def test_build_sticker_detail_output_omits_comments_error_when_absent() -> None:
    raw = _make_sticker_detail_response()
    result = _build_sticker_detail_output(raw["data"])
    assert "comments_error" not in result


def test_build_sticker_detail_output_omits_replies_when_empty() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["items"][0]["replies"] = []  # type: ignore[index]
    result = _build_sticker_detail_output(raw["data"])
    assert "replies" not in result["comments"]["items"][0]


def test_build_sticker_detail_output_rejects_non_selected_scope() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["scope"] = "all"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comments.scope" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_pictures() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["pictures"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "pictures is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_bool_comment_enabled() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["engagement_metrics"]["comment_enabled"] = 1  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comment_enabled" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_comment_items() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["items"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comments.items is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_hashtags() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["hashtags"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "hashtags is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_topics() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["topics"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "topics is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_product_window_items() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["monetization"]["product_window_items"] = "bad"  # type: ignore[index]
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "product_window_items is not a list" in exc_info.value.message


def test_normalize_sticker_comments_rejects_non_list_replies() -> None:
    """When a comment's replies field is a non-list truthy value, the normalizer
    should raise because only list or empty-list are valid."""
    raw_comments: dict[str, object] = {
        "scope": "selected",
        "returned_count": 1,
        "total_selected_count": 1,
        "items": [
            {
                "nick_name": "test",
                "content": "hi",
                "like_count": 0,
                "posted_at_timestamp": 1,
                "ip_location": "",
                "is_top": False,
                "is_author_reply": False,
                "replies": "bad",
            }
        ],
    }
    # replies="bad" is truthy but not a list — the isinstance check passes
    # because "bad" is truthy, but the for-loop on a string would produce chars.
    # However our code checks `isinstance(raw_replies, list)` first.
    result = _normalize_sticker_comments(raw_comments)
    # string "bad" fails isinstance(list) so replies key is omitted
    assert "replies" not in result["items"][0]
