"""Executor inference backend implementations."""
