"""Task and step-run domain models."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

from cognis.models.deliverable import Deliverable
from cognis.models.workflow import (
    CompletionDeliveryPolicy,
    StepEvaluation,
    StepOutput,
    WorkflowState,
)


class TaskStatus(StrEnum):
    """Task lifecycle states."""

    DRAFT = "draft"
    QUEUED = "queued"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepRunStatus(StrEnum):
    """Step run lifecycle states."""

    PENDING = "pending"
    RUNNING = "running"
    EVALUATING = "evaluating"
    APPROVED = "approved"
    REJECTED = "rejected"
    PAUSED = "paused"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SUPERSEDED = "superseded"


class TaskDelivery(BaseModel):
    """How task results are delivered to the user."""

    mode: str = "same_conversation"
    # same_conversation | specific_conversation | latest_active_for_agent
    # | preferred_channel | silent
    target: str | None = None


class TaskModel(BaseModel):
    """Durable work item visible in the kanban board."""

    task_id: str
    title: str
    description: str = ""
    expected_output: str | None = None
    status: TaskStatus = TaskStatus.DRAFT
    priority: int = 0
    created_by: str
    agent_id: str
    created_by_agent_id: str | None = None
    source_type: str = "api"  # "chat" | "api" | "scheduler" | "webhook"
    source_ref: str | None = None
    delivery: TaskDelivery = Field(default_factory=TaskDelivery)
    completion_delivery: CompletionDeliveryPolicy = Field(default_factory=CompletionDeliveryPolicy)
    interaction_mode_override: str | None = None
    workflow_id: str | None = None
    project_id: str | None = None
    attempt_number: int = 1
    workspace_root: str | None = None
    working_directory: str | None = None
    workflow_state: WorkflowState | None = None
    active_executor_id: str | None = None
    active_executor_assigned_at: datetime | None = None
    active_executor_expires_at: datetime | None = None
    active_executor_source: str | None = None
    queue_name: str = "default"
    scheduled_for: datetime | None = None
    created_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    updated_at: datetime | None = None
    result_summary: str | None = None
    result_data: dict[str, Any] | None = None
    applied_completion_mode: str | None = None
    applied_completion_reason: str | None = None


class StepRunModel(BaseModel):
    """Current execution state for one workflow step within a workflow run."""

    step_run_id: str
    task_id: str
    step_name: str
    step_type: str  # "run" | "gate"
    status: StepRunStatus = StepRunStatus.PENDING
    attempt: int = 1
    attempt_number: int = 1
    superseded_by_step_run_id: str | None = None
    agent_id: str
    workspace_root: str | None = None
    working_directory: str | None = None
    session_id: str | None = None
    intaris_session_id: str | None = None
    deliverable_id: str | None = None
    require_deliverable: bool | None = None
    output: StepOutput | None = None
    evaluation: StepEvaluation | None = None
    deliverables: list[Deliverable] = Field(default_factory=list)
    todos: list[dict[str, Any]] = []
    started_at: datetime | None = None
    completed_at: datetime | None = None
