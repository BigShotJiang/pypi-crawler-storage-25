from hestia_earth.models.utils.lookup import get_region_lookup_value
from hestia_earth.models.utils.impacts import run_from_resourceUses
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": "freshwaterWithdrawalsDuringCycle",
                "value": "",
            }
        ],
        "optional": {
            "country": {"@type": "Term", "termType": "region"},
            "emissionsResourceUse": [
                {
                    "@type": "Indicator",
                    "term.@id": "freshwaterWithdrawalsInputsProduction",
                    "value": "",
                }
            ],
        },
    }
}

LOOKUPS = {"region-environmentalFootprintV31WaterUse": ""}
RETURNS = {"Indicator": {"value": ""}}
TERM_ID = "scarcityWeightedWaterUse"


def _extend_data(blank_node: dict, country_id: str):
    factor = get_region_lookup_value(
        lookup_name="region-environmentalFootprintV31WaterUse.csv",
        term_id=country_id,
        column="factor",
        fallback_world=True,
        skip_debug=True,
    )

    return {
        "factor": factor,
    }


def run(impact_assessment: dict):
    return run_from_resourceUses(
        model=MODEL,
        term_id=TERM_ID,
        indicator_prefix="freshwaterWithdrawals",
        impact_assessment=impact_assessment,
        extend_data_func=_extend_data,
    )
