from hestia_earth.models.utils.practice import _new_practice
from . import MODEL
from .permanent_crops_utils import should_run

REQUIREMENTS = {
    "Cycle": {
        "products": [{"@type": "Product", "value": "", "term.termType": "crop"}],
        "practices": [
            {"@type": "Practice", "term.@id": "plantationLifespan", "value": ""},
            {
                "@type": "Practice",
                "term.@id": "plantationProductiveLifespan",
                "value": "",
            },
        ],
        "optional": {
            "practices": [{"@type": "Practice", "term.@id": "currentPlantationAge"}]
        },
    }
}
RETURNS = {"Practice": [{"value": ""}]}
TERM_ID = "productivePhasePermanentCrops"


def _run(practices: list):
    currentPlantationAge, lifespan, productive_lifespan = practices

    max_age = max(365, lifespan - productive_lifespan)

    value = currentPlantationAge is None or currentPlantationAge > max_age

    return [_new_practice(term=TERM_ID, model=MODEL, value=value)]


def run(cycle: dict):
    _should_run, practices = should_run(TERM_ID, cycle)
    return _run(practices) if _should_run else []
