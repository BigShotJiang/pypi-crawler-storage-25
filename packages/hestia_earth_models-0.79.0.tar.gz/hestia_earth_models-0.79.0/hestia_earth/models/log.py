import os
import platform
import resource
from functools import wraps
from typing import Callable, Union

from hestia_earth.utils.log import get_logger, log_join_args, log_node_suffix
from hestia_earth.utils.tools import to_precision

logger = get_logger("hestia_earth.models")


def debugValues(log_node: dict, **kwargs):
    logger.debug(log_node_suffix(log_node) + log_join_args(**kwargs))


def logRequirements(log_node: dict, **kwargs):
    logger.info(
        log_node_suffix(log_node) + "requirements=true, " + log_join_args(**kwargs)
    )


def logShouldRun(
    log_node: dict, model: str, term: Union[str, None], should_run: bool, **kwargs
):
    extra = (", " + log_join_args(**kwargs)) if len(kwargs.keys()) > 0 else ""
    logger.info(
        log_node_suffix(log_node) + "should_run=%s, model=%s, term=%s" + extra,
        should_run,
        model,
        term,
    )


def debugMissingLookup(
    lookup_name: str, row: str, row_value: str, col: str, value, **kwargs
):
    if value is None or value == "":
        extra = (", " + log_join_args(**kwargs)) if len(kwargs.keys()) > 0 else ""
        logger.warning(
            f"Missing lookup={lookup_name}, {row}={row_value}, column={col}" + extra
        )


def logErrorRun(model: str, term: str, error: str):
    logger.error("model=%s, term=%s, error=%s", model, term, error)


def _get_memory_use():
    factor = 1024 * (1024 if platform.system() in ["Darwin", "Windows"] else 1)
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / factor


def log_memory(**kwargs):
    """
    Log memory usage at a specific moment.
    """
    value = _get_memory_use()
    extra = (", " + log_join_args(**kwargs)) if len(kwargs.keys()) > 0 else ""
    logger.info("memory_used=%s, unit=MB" + extra, value)


def log_memory_use(func: Callable):
    """
    Log the memory usage of a function when it is called.
    """
    name = func.__name__
    module = os.path.basename(func.__code__.co_filename)

    @wraps(func)
    def wrapper(*args, **kwargs):
        before = _get_memory_use()
        result = func(*args, **kwargs)
        after = _get_memory_use()
        value = after - before
        logger.info(
            log_join_args(
                memory_used=to_precision(value),
                before=to_precision(before),
                after=to_precision(after),
                unit="MB",
                name=name,
                module=module,
            )
        )
        return result

    return wrapper
