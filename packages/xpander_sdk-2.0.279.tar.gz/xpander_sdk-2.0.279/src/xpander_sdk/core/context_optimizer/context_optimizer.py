"""
Agno Context Optimizer for xpander.ai SDK.

3-layer context management pipeline:
  Layer 1 — Microcompaction: offload large tool outputs to sandbox, keep preview (zero LLM cost).
  Layer 2 — Auto-compaction: LLM summarisation when approaching token ceiling (placeholder).
  Layer 3 — Manual compaction: agent-triggered on-demand compression (placeholder).

Thresholds based on industry best practices for agentic context management.
"""

import json
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type, Union

from pydantic import BaseModel

from loguru import logger

from agno.compression import CompressionManager
from agno.models.base import Model
from agno.models.message import Message

from xpander_sdk.consts.api_routes import APIRoute
from xpander_sdk.core.context_optimizer.encryption import derive_key, encrypt
from xpander_sdk.core.xpander_api_client import APIClient
from xpander_sdk.utils.event_loop import run_sync

if TYPE_CHECKING:
    from agno.metrics import RunMetrics
    from xpander_sdk.modules.agents.sub_modules.agent import Agent
    from xpander_sdk.modules.tasks.sub_modules.task import Task


@dataclass
class XPanderContextOptimizer(CompressionManager):
    """3-layer context optimizer for xpander.ai agents.

    Plugs into agno’s ``compression_manager`` slot but implements its own
    optimisation logic instead of relying on agno’s built-in patterns.

    Attributes:
        agent: The xpander Agent instance (provides config + IDs for sandbox calls).
        task: The xpander Task instance (provides task ID for storage paths;
              will be used in Layers 2/3 for plan following).
        min_content_length: Skip processing for tool results shorter than this.
        max_content_length: Offload threshold — results larger than this are
            saved to sandbox and replaced with a preview.
        preview_length: Characters kept inline as preview for offloaded results.
        context_window: Model context window size in tokens.
        reserved_for_output: Tokens reserved for LLM output.
        buffer_tokens: Safety buffer before auto-compact threshold.
    """

    # xpander context (use Any to avoid dataclass/pydantic conflict)
    agent: Any = None
    task: Any = None

    # Layer 1 settings
    min_content_length: int = 100
    max_content_length: int = 8_000
    preview_length: int = 2_000

    # Layer 2 settings
    context_window: int = 200_000
    reserved_for_output: int = 20_000
    buffer_tokens: int = 13_000

    def __post_init__(self):
        self.compress_tool_results = True
        super().__post_init__()
        logger.info(
            f"[context-optimizer] initialized "
            f"(max_content={self.max_content_length}, preview={self.preview_length}, "
            f"context_window={self.context_window}, threshold={self._auto_compact_threshold})"
        )

    # ------------------------------------------------------------------ #
    #  Token estimation
    # ------------------------------------------------------------------ #

    @staticmethod
    def _estimate_tokens(messages: List[Message]) -> int:
        """Rough token count: ~4 chars per token."""
        return len(json.dumps([m.to_dict() for m in messages], default=str)) // 4

    @property
    def _auto_compact_threshold(self) -> int:
        return self.context_window - self.reserved_for_output - self.buffer_tokens

    # ------------------------------------------------------------------ #
    #  Sandbox storage
    # ------------------------------------------------------------------ #

    async def _save_to_sandbox(self, content: str) -> Optional[str]:
        """Persist full tool output to the agent’s sandbox filesystem.

        Returns the sandbox path on success, or None on failure.
        """
        if not self.agent or not self.task:
            logger.warning("[context-optimizer] sandbox save skipped: agent or task not set")
            return None

        file_id = str(uuid.uuid4())
        path = f"/CONTEXT_OPTIMIZATION/{file_id}.xp"

        try:
            # Encrypt content before writing to sandbox
            key = derive_key(
                org_id=self.agent.configuration.organization_id,
                agent_id=self.agent.id,
                task_id=self.task.id,
            )
            encrypted_content = encrypt(content, key)

            client = APIClient(configuration=self.agent.configuration)
            await client.make_request(
                path=str(APIRoute.SandboxToolInvoke).format(
                    agent_id=self.agent.id,
                    tool_name="file_write",
                ),
                method="POST",
                payload={"path": path, "content": encrypted_content},
            )
            logger.info(f"[context-optimizer] saved encrypted tool result to sandbox: {path} ({len(content):,} chars)")
            return path
        except Exception as e:
            logger.warning(f"[context-optimizer] sandbox save failed: {e}")
            return None

    # ------------------------------------------------------------------ #
    #  Agno interface — should_compress
    # ------------------------------------------------------------------ #

    async def ashould_compress(
        self,
        messages: List[Message],
        tools: Optional[List] = None,
        model: Optional[Model] = None,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    ) -> bool:
        """Always returns True — Layer 1 runs every turn."""
        return True

    def should_compress(
        self,
        messages: List[Message],
        tools: Optional[List] = None,
        model: Optional[Model] = None,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    ) -> bool:
        return True

    # ------------------------------------------------------------------ #
    #  Agno interface — compress  (orchestrates all layers)
    # ------------------------------------------------------------------ #

    async def acompress(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
    ) -> None:
        """Run the optimisation pipeline (called by agno every turn)."""
        # Layer 1: offload large tool results to sandbox, keep preview
        await self.layer_1_microcompact(messages)

        # Layer 2: auto-compact if approaching token ceiling
        if self._should_auto_compact(messages):
            estimated = self._estimate_tokens(messages)
            logger.info(
                f"[context-optimizer] layer 2 triggered: "
                f"{estimated:,} tokens >= {self._auto_compact_threshold:,} threshold"
            )
            await self.layer_2_auto_compact(messages, run_metrics)

    def compress(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
    ) -> None:
        run_sync(self.acompress(messages, run_metrics=run_metrics))

    # ------------------------------------------------------------------ #
    #  Agno interface — _compress_tool_result  (unused, kept for compat)
    # ------------------------------------------------------------------ #

    async def _acompress_tool_result(
        self,
        tool_result: Message,
        run_metrics: Optional["RunMetrics"] = None,
    ) -> Optional[str]:
        """Not used directly — Layer 1 handles compression in bulk."""
        return None

    def _compress_tool_result(
        self,
        tool_result: Message,
        run_metrics: Optional["RunMetrics"] = None,
    ) -> Optional[str]:
        return None

    # ================================================================== #
    #  Layer 1 — Microcompaction (sandbox offload + preview)
    # ================================================================== #

    async def layer_1_microcompact(self, messages: List[Message]) -> None:
        """Offload large tool results to sandbox, keep a preview in context.

        Runs every turn before the LLM call.  Zero LLM cost.
        Results > max_content_length are persisted to the sandbox filesystem
        and replaced with a preview + retrieval pointer.  The agent can
        fetch the full output later via ``xpsandbox-file_read``.
        """
        offloaded_count = 0
        passthrough_count = 0
        skipped_count = 0
        turn_saved_chars = 0

        for msg in messages:
            if msg.role != "tool":
                continue
            if msg.compressed_content is not None:
                skipped_count += 1
                continue
            # Skip xpander built-in tools (plan tools, sandbox file ops, etc.)
            # but allow xpsandbox-bash through — bash output can be very large.
            if msg.tool_name and msg.tool_name.startswith("xp") and msg.tool_name != "xpsandbox-bash":
                skipped_count += 1
                continue

            content = str(msg.content) if msg.content else ""
            if len(content) <= self.min_content_length:
                skipped_count += 1
                continue

            original_len = len(content)
            tool_name = msg.tool_name or "unknown"

            if original_len > self.max_content_length:
                # Save full output to sandbox and replace with preview
                sandbox_path = await self._save_to_sandbox(content)

                if sandbox_path:
                    preview = content[: self.preview_length]
                    msg.compressed_content = (
                        f"{preview}\n\n"
                        f"[TRUNCATED OUTPUT - {original_len:,} chars total, showing first {self.preview_length:,}]\n"
                        f"Full result saved to: {sandbox_path}\n"
                        f"To retrieve the full output, call xpsandbox-file-read "
                        f"with path=\"{sandbox_path}\" (use the file-read tool, not bash cat). "
                        f"Do this if the preview above is insufficient for your current task."
                    )
                    compressed_len = len(msg.compressed_content)
                    saved = original_len - compressed_len
                    turn_saved_chars += saved
                    offloaded_count += 1
                    logger.info(
                        f"[context-optimizer] layer 1: offloaded '{tool_name}' to sandbox "
                        f"({original_len:,} -> {compressed_len:,} chars, saved {saved:,} chars, "
                        f"path={sandbox_path})"
                    )
                else:
                    # Sandbox failed — keep full result in context, skip compression
                    logger.warning(
                        f"[context-optimizer] layer 1: keeping full result for '{tool_name}' "
                        f"({original_len:,} chars) — sandbox unavailable, skipping compression"
                    )
                    continue
            else:
                # Between min and max -- mark as processed so we don't revisit.
                msg.compressed_content = content
                compressed_len = original_len
                passthrough_count += 1
                logger.debug(
                    f"[context-optimizer] layer 1: passthrough '{tool_name}' "
                    f"({original_len:,} chars, below {self.max_content_length:,} threshold)"
                )

            self.stats["tool_results_compressed"] = (
                self.stats.get("tool_results_compressed", 0) + 1
            )
            self.stats["original_size"] = (
                self.stats.get("original_size", 0) + original_len
            )
            self.stats["compressed_size"] = (
                self.stats.get("compressed_size", 0) + compressed_len
            )

        total_processed = offloaded_count + passthrough_count
        if total_processed > 0 or skipped_count > 0:
            total_original = self.stats.get("original_size", 0)
            total_compressed = self.stats.get("compressed_size", 0)
            total_saved = total_original - total_compressed
            savings_pct = (total_saved / total_original * 100) if total_original > 0 else 0
            logger.info(
                f"[context-optimizer] layer 1 summary: "
                f"offloaded={offloaded_count}, passthrough={passthrough_count}, "
                f"already_processed={skipped_count} | "
                f"this turn saved {turn_saved_chars:,} chars | "
                f"cumulative: {total_original:,} -> {total_compressed:,} chars "
                f"({savings_pct:.1f}% savings)"
            )

    # ================================================================== #
    #  Layer 2 — Auto-compaction (LLM summarisation) — PLACEHOLDER
    # ================================================================== #

    def _should_auto_compact(self, messages: List[Message]) -> bool:
        """Check whether token usage has crossed the auto-compact threshold."""
        return self._estimate_tokens(messages) >= self._auto_compact_threshold

    async def layer_2_auto_compact(
        self,
        messages: List[Message],
        run_metrics: Optional["RunMetrics"] = None,
    ) -> None:
        # TODO: implement LLM-based summarisation
        pass

    # ================================================================== #
    #  Layer 3 — Manual compaction (agent-triggered) — PLACEHOLDER
    # ================================================================== #

    async def layer_3_manual_compact(
        self,
        messages: List[Message],
        focus: str = "",
    ) -> None:
        # TODO: implement agent-triggered compaction
        pass
