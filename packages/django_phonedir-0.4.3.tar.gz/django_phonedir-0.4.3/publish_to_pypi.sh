#!/usr/bin/env bash
# Remove dist folder as it will be generated again in the next step with a new build.
if [ -d "dist" ]
then
echo "Deleting dist directory"
rm -r dist
fi
# Install/update needed tools
pipenv run pip install --upgrade twine build
# Create new build
pipenv run python -m build
# Upload new build to pypi using twine
pipenv run python -m twine upload --repository pypi dist/* --verbose