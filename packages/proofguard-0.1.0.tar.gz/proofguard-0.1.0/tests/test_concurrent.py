#!/usr/bin/env python3
"""
test_concurrent.py — H-3: Concurrent append smoke test

Spawns N threads, each calling record_decision() simultaneously.
After all threads complete, verifies:
  - chain_valid=True (no corruption)
  - total entry count == N
  - all entry_hashes unique

Run: python tests/test_concurrent.py
"""
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import importlib
import types

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


def run_concurrent_test(n_threads: int, label: str) -> None:
    """Run n_threads concurrent record_decision() calls against a temp ledger."""
    with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as tmp:
        tmp_path = Path(tmp.name)

    # Patch _LEDGER in proofguard.ledger to use temp file
    import proofguard.ledger as dl
    original_ledger = dl._LEDGER
    dl._LEDGER = tmp_path

    errors = []
    barrier = threading.Barrier(n_threads)

    def worker(i: int) -> None:
        try:
            barrier.wait()  # all threads start at the same time
            dl.record_decision(
                {"task_id": f"concurrent-task-{i}", "source": "test"},
                "PASS"
            )
        except Exception as e:
            errors.append(str(e))

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Restore
    dl._LEDGER = original_ledger

    from verify_proof import verify_chain
    result = verify_chain(str(tmp_path))

    import json
    lines = [l for l in tmp_path.read_text().splitlines() if l.strip()]
    entries = [json.loads(l) for l in lines]
    hashes = [e.get("entry_hash") for e in entries]
    unique_hashes = len(set(hashes)) == len(hashes)

    tmp_path.unlink()

    print(f"\n[Concurrent {label}: {n_threads} threads]")
    check(f"{label} no write errors", len(errors) == 0,
          f"errors: {errors[:3]}")
    check(f"{label} entry count == {n_threads}", len(entries) == n_threads,
          f"got {len(entries)}")
    check(f"{label} chain_valid=True", result.get("chain_valid") is True,
          f"result: {result}")
    check(f"{label} all entry_hashes unique", unique_hashes,
          f"duplicates found")


run_concurrent_test(2,  "2-threads")
run_concurrent_test(10, "10-threads")
run_concurrent_test(20, "20-threads (burst)")

print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All concurrency tests PASSED")
    sys.exit(0)
