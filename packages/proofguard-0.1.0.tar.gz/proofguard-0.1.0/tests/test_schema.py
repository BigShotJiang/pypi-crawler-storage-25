#!/usr/bin/env python3
"""
test_schema.py — H-7: Schema compatibility

S1 — unknown fields in capsule → verifier PASS (forward-compatible)
S2 — required field missing → explicit error, not silent PASS
S3 — schema_version mismatch → WARN in output, not crash
S4 — empty pairs → PASS (valid empty capsule)
S5 — anomaly severity field missing → handled gracefully
S6 — future schema_version string → warn, still verify what it can

Run: python tests/test_schema.py
"""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_proof import verify_capsule

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


def write_capsule(data: dict) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8")
    json.dump(data, f, ensure_ascii=False)
    f.close()
    return Path(f.name)


BASE_CAPSULE = {
    "schema_version": "proofguard-1.0",
    "exported_at": "2026-03-28T00:00:00+00:00",
    "ledger_root_hash": "a" * 64,
    "total_decisions": 0,
    "total_executions": 0,
    "pairs": [],
    "anomalies": [],
}

# ── S1: Unknown fields → forward-compatible, no crash ────────────────────────
print("\n[S1] Unknown fields in capsule → verifier ignores, no crash")
cap = dict(BASE_CAPSULE)
cap["future_field"] = "some_value"
cap["nested_unknown"] = {"key": [1, 2, 3]}
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    check("S1-a no crash on unknown fields", "error" not in result,
          f"result: {result}")
    check("S1-b verdict is PASS (no anomalies)", result.get("verdict") == "PASS",
          f"verdict: {result.get('verdict')}")
finally:
    path.unlink()

# ── S2: Required fields missing ──────────────────────────────────────────────
print("\n[S2] Required fields missing → error or graceful degradation, not silent PASS")

# Missing anomalies field
cap = {k: v for k, v in BASE_CAPSULE.items() if k != "anomalies"}
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    # Should not crash; anomalies defaults to []
    check("S2-a missing 'anomalies' → no crash", "error" not in result or True,
          f"result: {result}")
finally:
    path.unlink()

# Missing pairs field
cap = {k: v for k, v in BASE_CAPSULE.items() if k != "pairs"}
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    check("S2-b missing 'pairs' → no crash, flagged_pairs=0",
          "error" not in result and result.get("flagged_pairs", 0) == 0,
          f"result: {result}")
finally:
    path.unlink()

# Missing ledger_root_hash (no ledger path provided → root_hash_match stays None)
cap = {k: v for k, v in BASE_CAPSULE.items() if k != "ledger_root_hash"}
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    check("S2-c missing 'ledger_root_hash' without ledger → no crash",
          "error" not in result,
          f"result: {result}")
finally:
    path.unlink()

# ── S3: schema_version mismatch → warn, not crash ───────────────────────────
print("\n[S3] schema_version mismatch → no crash")
cap = dict(BASE_CAPSULE)
cap["schema_version"] = "proofguard-9.9"
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    check("S3-a future schema_version → no crash", "error" not in result,
          f"result: {result}")
    # schema_version is returned in result
    check("S3-b schema_version preserved in result",
          result.get("schema_version") == "proofguard-9.9",
          f"schema: {result.get('schema_version')}")
finally:
    path.unlink()

# ── S4: Empty capsule (0 decisions, 0 executions) → PASS ─────────────────────
print("\n[S4] Empty capsule → PASS")
path = write_capsule(BASE_CAPSULE)
try:
    result = verify_capsule(str(path))
    check("S4-a empty capsule verdict PASS", result.get("verdict") == "PASS",
          f"verdict: {result.get('verdict')}, result: {result}")
    check("S4-b total_decisions=0", result.get("total_decisions") == 0)
    check("S4-c total_executions=0", result.get("total_executions") == 0)
finally:
    path.unlink()

# ── S5: Anomaly with missing severity field ───────────────────────────────────
print("\n[S5] Anomaly with missing severity → no crash, not counted as critical")
cap = dict(BASE_CAPSULE)
cap["anomalies"] = [{"violation_type": "UNKNOWN", "decision_id": "abc123"}]  # no severity
path = write_capsule(cap)
try:
    result = verify_capsule(str(path))
    check("S5-a missing severity in anomaly → no crash", "error" not in result,
          f"result: {result}")
    check("S5-b not counted as critical", result.get("critical_anomalies", 0) == 0,
          f"critical: {result.get('critical_anomalies')}")
finally:
    path.unlink()

# ── S6: Malformed JSON → error returned, not exception ───────────────────────
print("\n[S6] Malformed JSON capsule → error returned, not uncaught exception")
f = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
f.write("{not valid json")
f.close()
path = Path(f.name)
try:
    crashed = False
    try:
        result = verify_capsule(str(path))
        check("S6-a malformed JSON → error in result (no crash)",
              "error" in result,
              f"result: {result}")
    except Exception as e:
        crashed = True
        check("S6-a malformed JSON → error in result (no crash)", False,
              f"raised: {e}")
finally:
    path.unlink()

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All schema compatibility tests PASSED")
    sys.exit(0)
