#!/usr/bin/env python3
"""
test_tamper_chain.py — H-4: Hash-chain tamper detection (4 scenarios)

T1 — middle entry body modified  → FAIL
T2 — last entry body modified    → FAIL
T3 — middle entry deleted        → FAIL
T4 — entry order swapped         → FAIL

Each must produce chain_valid=False + first_mismatch_index set.

Run: python tests/test_tamper_chain.py
"""
import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_proof import verify_chain

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _canon_dumps(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _build_chain(n: int) -> list:
    """Build a valid hash-chain of n entries."""
    entries = []
    prev_hash = "genesis"
    for i in range(n):
        body = {
            "type": "decision",
            "decision_id": f"test-id-{i:04d}",
            "actor": "test",
            "timestamp": f"2026-03-28T00:0{i}:00+00:00",
            "judgment_result": "PASS",
            "input_hash": _sha256(f"input-{i}"),
            "artifact_hash": _sha256(f"artifact-{i}"),
            "token_id": None,
            "authority_id": None,
            "prev_hash": prev_hash,
        }
        entry_hash = _sha256(_canon_dumps(body))
        entry = {**body, "entry_hash": entry_hash}
        entries.append(entry)
        prev_hash = entry_hash
    return entries


def _write_ledger(entries: list) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8")
    for e in entries:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    f.close()
    return Path(f.name)


def check(name: str, result: dict, expect_valid: bool) -> None:
    chain_valid = result.get("chain_valid", True)
    mismatch = result.get("first_mismatch_index")
    ok = (chain_valid == expect_valid)
    if ok and not expect_valid:
        ok = ok and (mismatch is not None)
    if ok:
        detail = f"chain_valid={chain_valid}, first_mismatch={mismatch}"
        print(f"  {PASS_STR}  {name} [{detail}]")
    else:
        print(f"  {FAIL_STR}  {name} — chain_valid={chain_valid}, first_mismatch={mismatch}, result={result}")
        failures.append(name)


# ── Build baseline clean chain ────────────────────────────────────────────────
entries = _build_chain(5)

# Baseline: clean chain must PASS
print("\n[Baseline] Clean chain")
path = _write_ledger(entries)
result = verify_chain(str(path))
path.unlink()
check("Baseline clean 5-entry chain", result, expect_valid=True)

# ── T1: Middle entry body modified ───────────────────────────────────────────
print("\n[T1] Middle entry body modified (index 2)")
tampered = copy.deepcopy(entries)
tampered[2]["judgment_result"] = "STOP"  # change value, keep entry_hash
path = _write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("T1 middle entry body change → FAIL", result, expect_valid=False)

# ── T2: Last entry body modified ─────────────────────────────────────────────
print("\n[T2] Last entry body modified (index 4)")
tampered = copy.deepcopy(entries)
tampered[4]["actor"] = "attacker"
path = _write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("T2 last entry body change → FAIL", result, expect_valid=False)

# ── T3: Middle entry deleted ──────────────────────────────────────────────────
print("\n[T3] Middle entry deleted (index 2 removed)")
tampered = copy.deepcopy(entries)
del tampered[2]
path = _write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("T3 middle entry deleted → FAIL", result, expect_valid=False)

# ── T4: Entry order swapped ───────────────────────────────────────────────────
print("\n[T4] Entry order swapped (index 1 ↔ 2)")
tampered = copy.deepcopy(entries)
tampered[1], tampered[2] = tampered[2], tampered[1]
path = _write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("T4 entry order swapped → FAIL", result, expect_valid=False)

# ── T5: entry_hash tampered but body intact ───────────────────────────────────
print("\n[T5] entry_hash field itself tampered (body intact)")
tampered = copy.deepcopy(entries)
original_hash = tampered[1]["entry_hash"]
tampered[1]["entry_hash"] = original_hash[:-1] + ("0" if original_hash[-1] != "0" else "1")
path = _write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("T5 entry_hash field tampered → FAIL", result, expect_valid=False)

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All tamper-chain tests PASSED")
    sys.exit(0)
