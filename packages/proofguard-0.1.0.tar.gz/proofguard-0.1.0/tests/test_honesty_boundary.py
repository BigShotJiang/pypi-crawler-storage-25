#!/usr/bin/env python3
"""
test_honesty_boundary.py — H-10: Product Honesty Boundary

README, HARDENING_NOTES, 데모 스크립트에서
과장된 표현이 없는지 기계적으로 확인한다.

쓰면 안 되는 말:
  - "perfect security"
  - "impossible to hack"
  - "blockchain-grade"
  - "future standard"
  - "fully production-secure" / "production-ready" (단독 사용)
  - "unhackable"
  - "100% secure"

써도 되는 말 (검증 가능한 것만):
  - tamper-evident
  - cryptographically verifiable
  - execution bound to decision
  - standalone verification
  - fail-closed
  - append-only chain

Run: python tests/test_honesty_boundary.py
"""
import re
import sys
from pathlib import Path

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []

ROOT = Path(__file__).resolve().parents[1]

# Files that face the public or define claims
# HARDENING_NOTES and KEY_POLICY explicitly list banned terms as examples of what NOT to say.
# Exclude them from the banned-phrase scan to avoid false positives.
PUBLIC_DOCS = [
    ROOT / "README.md",
    ROOT / "demo_script.md",
    ROOT / "proofguard_spec.md",
    ROOT / "ciso_onepager.html",
    ROOT / "investor_onepager.html",
]

# Patterns that must NOT appear (case-insensitive)
BANNED = [
    r"perfect security",
    r"impossible to hack",
    r"unhackable",
    r"blockchain.grade",      # blockchain-grade, blockchain grade
    r"future standard",
    r"fully production.secure",
    r"100% secure",
    r"cannot be hacked",
    r"unbreakable",
]

# Patterns that MUST appear in README (core claims — verifiable)
REQUIRED_IN_README = [
    "tamper-evident",
    "cryptographically verifiable",
    "fail-closed",
    "append-only",
    "standalone",
]


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


# ── B1: Banned phrases absent from all public docs ───────────────────────────
print("\n[B1] Banned phrases absent from public docs")
for doc in PUBLIC_DOCS:
    if not doc.exists():
        print(f"  NOTE  {doc.name} not found — skipping")
        continue
    content = doc.read_text(encoding="utf-8", errors="replace").lower()
    for pattern in BANNED:
        found = re.search(pattern, content, re.IGNORECASE)
        check(f"B1 {doc.name}: no '{pattern}'",
              found is None,
              f"found at: '{found.group()}'" if found else "")

# ── B2: Required accurate claims present in README ───────────────────────────
print("\n[B2] Required accurate claims present in README")
readme = ROOT / "README.md"
if readme.exists():
    content = readme.read_text(encoding="utf-8", errors="replace").lower()
    for phrase in REQUIRED_IN_README:
        check(f"B2 README contains '{phrase}'",
              phrase.lower() in content,
              "missing from README")
else:
    print("  NOTE  README.md not found")

# ── B3: HARDENING_NOTES honesty section exists ───────────────────────────────
print("\n[B3] HARDENING_NOTES.md contains Honesty Boundary section")
hn = ROOT / "HARDENING_NOTES.md"
if hn.exists():
    content = hn.read_text(encoding="utf-8", errors="replace")
    check("B3-a Honesty Boundary section exists",
          "Honesty Boundary" in content or "honesty" in content.lower())
    check("B3-b 'do not claim' or banned items documented",
          "do not claim" in content.lower() or "쓰면 안 되는" in content or "Do not claim" in content)
else:
    print("  NOTE  HARDENING_NOTES.md not found")

# ── B4: KEY_POLICY.md states private key never in capsule ────────────────────
print("\n[B4] KEY_POLICY.md states private key exclusion")
kp = ROOT / "KEY_POLICY.md"
if kp.exists():
    content = kp.read_text(encoding="utf-8", errors="replace").lower()
    check("B4 KEY_POLICY states private key never in capsule",
          "never" in content and ("capsule" in content or "private" in content))
else:
    print("  NOTE  KEY_POLICY.md not found")

# ── B5: HARDENING_RESULTS.md has bugs-found table ────────────────────────────
print("\n[B5] HARDENING_RESULTS.md discloses bugs found during hardening")
hr = ROOT / "HARDENING_RESULTS.md"
if hr.exists():
    content = hr.read_text(encoding="utf-8", errors="replace").lower()
    check("B5 bugs found table present",
          "bug" in content and ("found" in content or "fixed" in content))
else:
    print("  NOTE  HARDENING_RESULTS.md not found")

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All honesty boundary checks PASSED")
    sys.exit(0)
