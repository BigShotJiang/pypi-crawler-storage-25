#!/usr/bin/env python3
"""
test_crash_safety.py — H-2: Crash safety / partial write detection

Tests:
  P1 — partial line (no newline) → verifier FAIL or skip
  P2 — truncated JSON mid-object → verifier FAIL or skip
  P3 — valid entries + partial line → valid entries still verified, partial flagged
  P4 — empty file → chain_valid=True, total_entries=0

Run: python tests/test_crash_safety.py
"""
import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_proof import verify_chain

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _make_entry(i: int, prev_hash: str) -> dict:
    body = {
        "type": "decision",
        "decision_id": f"crash-test-{i:04d}",
        "actor": "test",
        "timestamp": f"2026-03-28T00:0{i}:00+00:00",
        "judgment_result": "PASS",
        "input_hash": _sha256(f"in-{i}"),
        "artifact_hash": _sha256(f"art-{i}"),
        "token_id": None,
        "authority_id": None,
        "prev_hash": prev_hash,
    }
    entry_hash = _sha256(_canon(body))
    return {**body, "entry_hash": entry_hash}


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


# Build 3 valid entries
e0 = _make_entry(0, "genesis")
e1 = _make_entry(1, e0["entry_hash"])
e2 = _make_entry(2, e1["entry_hash"])

# ── P1: Partial line (truncated mid-JSON, no closing brace) ──────────────────
print("\n[P1] Partial line — truncated JSON, no closing brace")
with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
    f.write(json.dumps(e0, ensure_ascii=False) + "\n")
    f.write(json.dumps(e1, ensure_ascii=False) + "\n")
    # Simulate crash mid-write: partial JSON, no newline
    partial = json.dumps(e2, ensure_ascii=False)[:30]
    f.write(partial)
    tmp = Path(f.name)

result = verify_chain(str(tmp))
tmp.unlink()
# verifier must NOT silently PASS — either error or chain broken
not_silent_pass = not (result.get("chain_valid") is True and result.get("total_entries") == 3)
# If it parsed 2 valid + skipped partial line, chain_valid=True with 2 entries is also acceptable
two_clean = result.get("chain_valid") is True and result.get("total_entries") == 2
check("P1 partial line not silently accepted as 3 valid entries",
      not_silent_pass or two_clean,
      f"result: {result}")

# ── P2: Truncated JSON that is still parseable but chain-broken ───────────────
print("\n[P2] Valid JSON line but entry_hash mismatch (simulated mid-crash corruption)")
with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
    f.write(json.dumps(e0, ensure_ascii=False) + "\n")
    # Corrupt e1: change a field after entry_hash was computed
    corrupted = dict(e1)
    corrupted["actor"] = "corrupted"
    f.write(json.dumps(corrupted, ensure_ascii=False) + "\n")
    f.write(json.dumps(e2, ensure_ascii=False) + "\n")
    tmp = Path(f.name)

result = verify_chain(str(tmp))
tmp.unlink()
check("P2 corrupted entry detected (chain_valid=False)",
      result.get("chain_valid") is False,
      f"result: {result}")
check("P2 first_mismatch_index set",
      result.get("first_mismatch_index") is not None,
      f"result: {result}")

# ── P3: Empty file ────────────────────────────────────────────────────────────
print("\n[P3] Empty file")
with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
    tmp = Path(f.name)

result = verify_chain(str(tmp))
tmp.unlink()
check("P3 empty file → chain_valid=True, 0 entries",
      result.get("chain_valid") is True and result.get("total_entries") == 0,
      f"result: {result}")

# ── P4: Blank lines in ledger ─────────────────────────────────────────────────
print("\n[P4] Blank lines interspersed")
with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
    f.write("\n")
    f.write(json.dumps(e0, ensure_ascii=False) + "\n")
    f.write("\n\n")
    f.write(json.dumps(e1, ensure_ascii=False) + "\n")
    f.write("\n")
    tmp = Path(f.name)

result = verify_chain(str(tmp))
tmp.unlink()
check("P4 blank lines skipped, chain_valid=True, 2 entries",
      result.get("chain_valid") is True and result.get("total_entries") == 2,
      f"result: {result}")

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All crash-safety tests PASSED")
    sys.exit(0)
