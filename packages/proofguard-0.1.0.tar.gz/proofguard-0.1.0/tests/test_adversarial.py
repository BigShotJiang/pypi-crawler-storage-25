#!/usr/bin/env python3
"""
test_adversarial.py — H-9: Adversarial Testing

공격 관점에서 verifier와 enforcement gate가 버티는지 확인.

A1  — capsule field reorder (different JSON key order in file)
A2  — unicode confusion (lookalike chars in decision_id)
A3  — null / empty / missing fields in ledger entry
A4  — oversized payload (large input_hash field)
A5  — fake anomaly injection (forged anomaly in capsule)
A6  — forged decision_id linkage (execution points to non-existent decision)
A7  — reused decision_id (duplicate decision entries)
A8  — expired / mismatched entry_hash (field tampered after signing)
A9  — prev_hash set to "genesis" on non-first entry (chain splice attempt)
A10 — extra entry appended after export (ledger extended post-capsule)

Run: python tests/test_adversarial.py
"""
import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from verify_proof import verify_chain, verify_capsule

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _make_entry(i: int, prev_hash: str, decision_id: str = None, override: dict = None) -> dict:
    did = decision_id or f"test-adv-{i:04d}"
    body = {
        "type": "decision",
        "decision_id": did,
        "actor": "test",
        "timestamp": f"2026-03-28T00:{i:02d}:00+00:00",
        "judgment_result": "PASS",
        "input_hash": _sha256(f"in-{i}"),
        "artifact_hash": _sha256(f"art-{i}"),
        "token_id": None,
        "authority_id": None,
        "prev_hash": prev_hash,
    }
    if override:
        body.update(override)
    entry_hash = _sha256(_canon(body))
    return {**body, "entry_hash": entry_hash}


def write_ledger(entries: list) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8")
    for e in entries:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    f.close()
    return Path(f.name)


def write_capsule(data: dict) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8")
    json.dump(data, f, ensure_ascii=False)
    f.close()
    return Path(f.name)


def build_valid_chain(n: int) -> list:
    entries, prev = [], "genesis"
    for i in range(n):
        e = _make_entry(i, prev)
        entries.append(e)
        prev = e["entry_hash"]
    return entries


BASE_CAPSULE = {
    "schema_version": "proofguard-1.0",
    "exported_at": "2026-03-28T00:00:00+00:00",
    "ledger_root_hash": "a" * 64,
    "total_decisions": 0,
    "total_executions": 0,
    "pairs": [],
    "anomalies": [],
}

# ── A1: Field reorder in JSON file ───────────────────────────────────────────
print("\n[A1] JSON field reorder in ledger file (different serialization order)")
entries = build_valid_chain(3)
# Write entries with fields in non-canonical order
f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8")
for e in entries:
    # Reverse the key order in the written line
    reordered = {k: e[k] for k in reversed(list(e.keys()))}
    f.write(json.dumps(reordered, ensure_ascii=False) + "\n")
f.close()
path = Path(f.name)
result = verify_chain(str(path))
path.unlink()
# entry_hash was computed with sort_keys, so field order in file doesn't affect recomputation
# (verifier does {k:v for k,v if k != entry_hash} then canon_dumps with sort_keys)
check("A1 field reorder in file → chain_valid=True (sort_keys normalizes)",
      result.get("chain_valid") is True,
      f"result: {result}")

# ── A2: Unicode lookalike in decision_id ──────────────────────────────────────
print("\n[A2] Unicode lookalike chars in decision_id")
# Cyrillic 'а' (U+0430) looks like Latin 'a' but is different byte
real_id    = "decision-abcdef"
lookalike  = "decision-\u0430bcdef"  # Cyrillic а
check("A2-a real vs lookalike decision_id → different hash",
      _sha256(_canon({"id": real_id})) != _sha256(_canon({"id": lookalike})))

# Enforcement: lookalike ID not found in ledger → blocked
import proofguard.ledger as dl
orig_l, orig_v = dl._LEDGER, dl._VIOLATION_LOG
tl = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tl.close()
tv = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tv.close()
dl._LEDGER = Path(tl.name)
dl._VIOLATION_LOG = Path(tv.name)
try:
    d = dl.record_decision({"task_id": real_id}, "PASS")
    raised = False
    try:
        dl.pre_execution_guard(lookalike)  # lookalike should NOT match real_id
    except dl.ExecutionBoundaryViolation:
        raised = True
    check("A2-b lookalike decision_id not accepted as valid", raised)
finally:
    dl._LEDGER = orig_l
    dl._VIOLATION_LOG = orig_v
    Path(tl.name).unlink(missing_ok=True)
    Path(tv.name).unlink(missing_ok=True)

# ── A3: Null / empty / missing fields ────────────────────────────────────────
print("\n[A3] Null / empty / missing fields in ledger entry")
entries = build_valid_chain(2)
# Inject entry with null entry_hash
tampered = copy.deepcopy(entries)
tampered[1]["entry_hash"] = None
path = write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("A3-a null entry_hash → chain_valid=False",
      result.get("chain_valid") is False,
      f"result: {result}")

# Entry with empty string entry_hash
tampered = copy.deepcopy(entries)
tampered[1]["entry_hash"] = ""
path = write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("A3-b empty string entry_hash → chain_valid=False",
      result.get("chain_valid") is False,
      f"result: {result}")

# ── A4: Oversized payload ─────────────────────────────────────────────────────
print("\n[A4] Oversized payload (1MB input_hash field)")
big_value = "x" * (1024 * 1024)  # 1MB string
entries = []
prev = "genesis"
body = {
    "type": "decision", "decision_id": "big-payload-test", "actor": "test",
    "timestamp": "2026-03-28T00:00:00+00:00", "judgment_result": "PASS",
    "input_hash": _sha256(big_value),  # hash of big value, not big value itself
    "artifact_hash": _sha256("art"), "token_id": None, "authority_id": None,
    "prev_hash": prev,
}
entry_hash = _sha256(_canon(body))
entry = {**body, "entry_hash": entry_hash}
path = write_ledger([entry])
result = verify_chain(str(path))
path.unlink()
check("A4 1MB-derived payload → chain_valid=True (hash stored, not raw value)",
      result.get("chain_valid") is True,
      f"result: {result}")

# ── A5: Fake anomaly injection in capsule ────────────────────────────────────
print("\n[A5] Fake CRITICAL anomaly injected into capsule")
cap = dict(BASE_CAPSULE)
cap["anomalies"] = [{
    "violation_type": "FAKE_CRITICAL",
    "severity": "CRITICAL",
    "decision_id": "forged-id",
    "detail": "attacker injected anomaly"
}]
path = write_capsule(cap)
result = verify_capsule(str(path))
path.unlink()
# Injected CRITICAL anomaly should cause verdict=FAIL
check("A5 injected CRITICAL anomaly → verdict=FAIL",
      result.get("verdict") == "FAIL",
      f"verdict: {result.get('verdict')}, critical: {result.get('critical_anomalies')}")
check("A5 critical_anomalies=1",
      result.get("critical_anomalies") == 1,
      f"got: {result.get('critical_anomalies')}")

# ── A6: Forged decision_id linkage ───────────────────────────────────────────
print("\n[A6] Execution entry with forged decision_id (non-existent)")
orig_l, orig_v = dl._LEDGER, dl._VIOLATION_LOG
tl = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tl.close()
tv = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tv.close()
dl._LEDGER = Path(tl.name)
dl._VIOLATION_LOG = Path(tv.name)
try:
    raised = False
    try:
        dl.record_execution("forged-decision-id-99999", {"result": "ok"}, True)
    except dl.ExecutionBoundaryViolation:
        raised = True
    viols = json.loads(Path(tv.name).read_text().strip().split('\n')[-1]) if Path(tv.name).stat().st_size > 0 else {}
    check("A6-a forged decision_id → ExecutionBoundaryViolation", raised)
    check("A6-b CRITICAL violation logged",
          viols.get("severity") == "CRITICAL" and viols.get("violation_type") == "EXECUTION_WITHOUT_DECISION",
          f"got: {viols}")
finally:
    dl._LEDGER = orig_l
    dl._VIOLATION_LOG = orig_v
    Path(tl.name).unlink(missing_ok=True)
    Path(tv.name).unlink(missing_ok=True)

# ── A7: Duplicate decision_id (replayed decision) ────────────────────────────
print("\n[A7] Duplicate decision_id in ledger (replay attack)")
orig_l, orig_v = dl._LEDGER, dl._VIOLATION_LOG
tl = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tl.close()
tv = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False); tv.close()
dl._LEDGER = Path(tl.name)
dl._VIOLATION_LOG = Path(tv.name)
try:
    d1 = dl.record_decision({"task_id": "orig-task"}, "PASS")
    d2 = dl.record_decision({"task_id": "orig-task"}, "STOP")  # same task, different result
    # Both have different UUIDs, so chain stays valid
    result = verify_chain(str(dl._LEDGER))
    check("A7-a two records with same task_id → chain_valid=True (UUIDs differ)",
          result.get("chain_valid") is True,
          f"result: {result}")
    # But _lookup_decision returns the FIRST matching entry
    found = dl._lookup_decision(d1["decision_id"])
    check("A7-b first decision_id still found correctly",
          found is not None and found["judgment_result"] == "PASS",
          f"found: {found}")
finally:
    dl._LEDGER = orig_l
    dl._VIOLATION_LOG = orig_v
    Path(tl.name).unlink(missing_ok=True)
    Path(tv.name).unlink(missing_ok=True)

# ── A8: prev_hash = "genesis" on non-first entry (chain splice) ──────────────
print("\n[A8] Chain splice: non-first entry has prev_hash='genesis'")
entries = build_valid_chain(3)
tampered = copy.deepcopy(entries)
# Attacker tries to make entry[2] look like a fresh chain start
tampered[2]["prev_hash"] = "genesis"
# Must recompute entry_hash to make it look valid
body = {k: v for k, v in tampered[2].items() if k != "entry_hash"}
tampered[2]["entry_hash"] = _sha256(_canon(body))
path = write_ledger(tampered)
result = verify_chain(str(path))
path.unlink()
check("A8 chain splice (prev_hash='genesis' at index 2) → chain_valid=False",
      result.get("chain_valid") is False,
      f"result: {result}")

# ── A9: Entry appended to ledger after capsule export ────────────────────────
print("\n[A9] Ledger extended after capsule export → root_hash mismatch")
entries = build_valid_chain(3)
path = write_ledger(entries)

# Simulate: capsule was exported with root_hash of 3-entry chain
chain_hashes = [e["entry_hash"] for e in entries]
original_root = _sha256("|".join(chain_hashes))
cap = dict(BASE_CAPSULE)
cap["ledger_root_hash"] = original_root

# Now add a 4th entry to the ledger file
extra = _make_entry(3, entries[-1]["entry_hash"])
with path.open("a", encoding="utf-8") as f:
    f.write(json.dumps(extra, ensure_ascii=False) + "\n")

cap_path = write_capsule(cap)
result = verify_capsule(str(cap_path), str(path))
path.unlink()
cap_path.unlink()
check("A9 extra entry appended post-export → root_hash_match=False",
      result.get("root_hash_match") is False,
      f"result: {result}")

# ── A10: Capsule claims 0 anomalies but ledger has violations ────────────────
print("\n[A10] Capsule claims 0 anomalies (clean) but has flagged pairs")
cap = dict(BASE_CAPSULE)
cap["anomalies"] = []  # attacker wiped anomaly list
cap["pairs"] = [{
    "decision": {"decision_id": "abc", "judgment_result": "PASS"},
    "execution": None,
    "anomaly_flag": True,      # but pair is flagged
    "severity": "CRITICAL",
}]
path = write_capsule(cap)
result = verify_capsule(str(path))
path.unlink()
# verifier counts flagged_pairs independently of anomalies list
check("A10 flagged_pairs counted independently of anomalies field",
      result.get("flagged_pairs", 0) == 1,
      f"flagged_pairs: {result.get('flagged_pairs')}, result: {result}")

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All adversarial tests PASSED")
    sys.exit(0)
