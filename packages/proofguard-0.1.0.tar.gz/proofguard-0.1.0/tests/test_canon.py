#!/usr/bin/env python3
"""
test_canon.py — H-1: Canonicalization tests

Rules under test:
  - Same logical object → always same bytes (key order independent)
  - Whitespace differences → same hash
  - Separators: no spaces ((',', ':'))
  - ensure_ascii=False preserved
  - unicode: NFC vs NFD behavior documented

Run: python -m pytest tests/test_canon.py -v
  or: python tests/test_canon.py
"""
import hashlib
import json
import sys
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from proofguard.ledger import _canon_dumps
from verify_proof import _canon_dumps as verifier_canon_dumps


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


PASS = "\033[32mPASS\033[0m"
FAIL = "\033[31mFAIL\033[0m"
failures = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS}  {name}")
    else:
        print(f"  {FAIL}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


# ── C1: Key order independence ────────────────────────────────────────────────
print("\n[C1] Key order independence")
obj_a = {"z": 1, "a": 2, "m": 3}
obj_b = {"a": 2, "m": 3, "z": 1}
obj_c = {"m": 3, "z": 1, "a": 2}
h_a = _sha256(_canon_dumps(obj_a))
h_b = _sha256(_canon_dumps(obj_b))
h_c = _sha256(_canon_dumps(obj_c))
check("C1-a same dict different key order → same hash (a==b)", h_a == h_b)
check("C1-b same dict different key order → same hash (a==c)", h_a == h_c)

nested_a = {"x": {"z": 1, "a": 2}, "b": 3}
nested_b = {"b": 3, "x": {"a": 2, "z": 1}}
check("C1-c nested objects key order → same hash",
      _sha256(_canon_dumps(nested_a)) == _sha256(_canon_dumps(nested_b)))

# ── C2: No whitespace in output ──────────────────────────────────────────────
print("\n[C2] No whitespace in canonical output")
canonical = _canon_dumps({"key": "value", "num": 42})
check("C2-a no space after colon", ": " not in canonical,
      f"got: {canonical!r}")
check("C2-b no space after comma", ", " not in canonical,
      f"got: {canonical!r}")
check("C2-c exact format", canonical == '{"key":"value","num":42}',
      f"got: {canonical!r}")

# ── C3: Producer == Verifier ─────────────────────────────────────────────────
print("\n[C3] Producer (proofguard.ledger) == Verifier (verify_proof)")
test_obj = {"type": "decision", "actor": "test", "prev_hash": "genesis", "z_field": True}
prod = _canon_dumps(test_obj)
verif = verifier_canon_dumps(test_obj)
check("C3-a producer and verifier output identical", prod == verif,
      f"\n      producer : {prod!r}\n      verifier : {verif!r}")
check("C3-b hash matches", _sha256(prod) == _sha256(verif))

# ── C4: Whitespace in input values is preserved (not stripped) ───────────────
print("\n[C4] Input whitespace preserved in values")
obj_space = {"key": "val ue"}
obj_nospace = {"key": "value"}
check("C4-a whitespace in value is NOT normalized (different hash)",
      _sha256(_canon_dumps(obj_space)) != _sha256(_canon_dumps(obj_nospace)))

# ── C5: int vs float ─────────────────────────────────────────────────────────
print("\n[C5] int vs float behavior (documented)")
int_val  = _canon_dumps({"n": 1})
flt_val  = _canon_dumps({"n": 1.0})
# Document the behavior — Python json treats 1 and 1.0 differently
check("C5-a int 1 serializes to '1' (not '1.0')", '"n":1' in int_val,
      f"got: {int_val!r}")
# Note: 1.0 in Python json → "1.0" — different from int 1. This is expected.
# Producers must use consistent types for reproducible hashes.
same_type = (_sha256(int_val) == _sha256(_canon_dumps({"n": 1})))
check("C5-b same int input → same hash", same_type)

# ── C6: Unicode — ensure_ascii=False ─────────────────────────────────────────
print("\n[C6] Unicode encoding")
uni_obj = {"msg": "한국어"}
canon_uni = _canon_dumps(uni_obj)
check("C6-a Korean chars not escaped (ensure_ascii=False)", "한국어" in canon_uni,
      f"got: {canon_uni!r}")
check("C6-b hash stable across calls",
      _sha256(_canon_dumps(uni_obj)) == _sha256(_canon_dumps(uni_obj)))

# NFC vs NFD — document behavior
nfc_str = unicodedata.normalize("NFC", "café")
nfd_str = unicodedata.normalize("NFD", "café")
nfc_hash = _sha256(_canon_dumps({"k": nfc_str}))
nfd_hash = _sha256(_canon_dumps({"k": nfd_str}))
# These will likely differ — document this as a known limitation
same_unicode = (nfc_hash == nfd_hash)
print(f"  NOTE  C6-c NFC vs NFD → {'same hash (normalized)' if same_unicode else 'DIFFERENT hash (not normalized)'}")
print(f"        Producers must ensure consistent unicode normalization (NFC recommended).")

# ── C7: Negative — different values must differ ───────────────────────────────
print("\n[C7] Negative: different logical content → different hash")
check("C7-a different values → different hash",
      _sha256(_canon_dumps({"a": 1})) != _sha256(_canon_dumps({"a": 2})))
check("C7-b extra field → different hash",
      _sha256(_canon_dumps({"a": 1})) != _sha256(_canon_dumps({"a": 1, "b": 2})))
check("C7-c None vs missing key → different hash",
      _sha256(_canon_dumps({"a": None})) != _sha256(_canon_dumps({})))

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print(f"All canonicalization tests PASSED")
    sys.exit(0)
