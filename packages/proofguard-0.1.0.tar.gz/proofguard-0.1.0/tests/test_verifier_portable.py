#!/usr/bin/env python3
"""
test_verifier_portable.py — H-8: Standalone verifier portability

Verifies that verify_proof.py:
  P1 — uses only Python stdlib (no third-party imports)
  P2 — runs in a clean venv (no installed packages)
  P3 — produces consistent results across multiple runs (deterministic)
  P4 — verify_chain result is identical whether called from source or subprocess
  P5 — root_hash is deterministic for same ledger content

Run: python tests/test_verifier_portable.py
"""
import ast
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []

PROOFHALT_ROOT = Path(__file__).resolve().parents[1]
VERIFY_PY = PROOFHALT_ROOT / "verify_proof.py"

STDLIB_MODULES = {
    # builtins & __future__
    "__future__", "builtins",
    # stdlib used by verify_proof.py
    "argparse", "hashlib", "json", "pathlib", "sys", "typing",
    # common stdlib (allowed)
    "os", "re", "io", "abc", "copy", "math", "time", "datetime",
    "collections", "itertools", "functools", "contextlib",
    "struct", "enum", "dataclasses", "inspect", "warnings",
    "unicodedata", "string", "textwrap",
}


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _build_ledger(n: int) -> list:
    entries = []
    prev_hash = "genesis"
    for i in range(n):
        body = {
            "type": "decision", "decision_id": f"id-{i:04d}", "actor": "test",
            "timestamp": f"2026-03-28T00:0{i}:00+00:00", "judgment_result": "PASS",
            "input_hash": _sha256(f"in-{i}"), "artifact_hash": _sha256(f"art-{i}"),
            "token_id": None, "authority_id": None, "prev_hash": prev_hash,
        }
        entry_hash = _sha256(_canon(body))
        entry = {**body, "entry_hash": entry_hash}
        entries.append(entry)
        prev_hash = entry_hash
    return entries


def write_ledger(entries: list) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False, encoding="utf-8")
    for e in entries:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    f.close()
    return Path(f.name)


# ── P1: Only stdlib imports ───────────────────────────────────────────────────
print("\n[P1] verify_proof.py uses only stdlib")
source = VERIFY_PY.read_text()
tree = ast.parse(source)
imports = []
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        for alias in node.names:
            imports.append(alias.name.split('.')[0])
    elif isinstance(node, ast.ImportFrom):
        if node.module:
            imports.append(node.module.split('.')[0])
        elif node.names:
            imports.append(node.names[0].name.split('.')[0])

non_stdlib = [m for m in imports if m not in STDLIB_MODULES and not m.startswith('_')]
check("P1 no third-party imports", len(non_stdlib) == 0,
      f"non-stdlib: {non_stdlib}")
print(f"  NOTE  imports found: {sorted(set(imports))}")

# ── P2: Runs under clean Python (subprocess with minimal env) ─────────────────
print("\n[P2] Runs in subprocess with no installed packages")
entries = _build_ledger(3)
ledger_path = write_ledger(entries)
try:
    result = subprocess.run(
        [sys.executable, str(VERIFY_PY), "--help"],
        capture_output=True, text=True, timeout=10,
        env={"PATH": "/usr/bin:/bin", "HOME": str(Path.home())}
    )
    check("P2-a --help exits without ImportError",
          result.returncode == 0 and "ImportError" not in result.stderr,
          f"rc={result.returncode}, stderr={result.stderr[:200]}")
finally:
    ledger_path.unlink()

# ── P3: Deterministic — same ledger → same root_hash across 3 runs ───────────
print("\n[P3] Deterministic root_hash across multiple calls")
sys.path.insert(0, str(PROOFHALT_ROOT))
from verify_proof import verify_chain

entries = _build_ledger(5)
ledger_path = write_ledger(entries)
try:
    results = [verify_chain(str(ledger_path)) for _ in range(3)]
    hashes = [r["root_hash"] for r in results]
    check("P3-a root_hash identical across 3 calls",
          len(set(hashes)) == 1,
          f"hashes: {hashes}")
    check("P3-b chain_valid=True all 3 runs",
          all(r["chain_valid"] for r in results))
finally:
    ledger_path.unlink()

# ── P4: verify_chain result consistent — in-process vs subprocess ─────────────
print("\n[P4] In-process vs subprocess result consistency")
entries = _build_ledger(4)
ledger_path = write_ledger(entries)
try:
    # in-process
    in_proc = verify_chain(str(ledger_path))

    # subprocess call via a small inline script
    script = f"""
import sys, json
sys.path.insert(0, {str(PROOFHALT_ROOT)!r})
from verify_proof import verify_chain
r = verify_chain({str(ledger_path)!r})
print(json.dumps({{"chain_valid": r["chain_valid"], "total_entries": r["total_entries"], "root_hash": r["root_hash"]}}))
"""
    proc = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True, text=True, timeout=10
    )
    sub_proc = json.loads(proc.stdout.strip())

    check("P4-a chain_valid matches",
          in_proc["chain_valid"] == sub_proc["chain_valid"],
          f"in={in_proc['chain_valid']} sub={sub_proc['chain_valid']}")
    check("P4-b total_entries matches",
          in_proc["total_entries"] == sub_proc["total_entries"],
          f"in={in_proc['total_entries']} sub={sub_proc['total_entries']}")
    check("P4-c root_hash matches",
          in_proc["root_hash"] == sub_proc["root_hash"],
          f"in={in_proc['root_hash'][:16]} sub={sub_proc['root_hash'][:16]}")
finally:
    ledger_path.unlink()

# ── P5: root_hash is a function of content only (not time, pid, etc.) ─────────
print("\n[P5] root_hash deterministic — two identical ledger files → same root_hash")
entries = _build_ledger(3)
path_a = write_ledger(entries)
path_b = write_ledger(entries)
try:
    r_a = verify_chain(str(path_a))
    r_b = verify_chain(str(path_b))
    check("P5 identical content → identical root_hash",
          r_a["root_hash"] == r_b["root_hash"],
          f"a={r_a['root_hash'][:16]} b={r_b['root_hash'][:16]}")
finally:
    path_a.unlink()
    path_b.unlink()

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All verifier portability tests PASSED")
    sys.exit(0)
