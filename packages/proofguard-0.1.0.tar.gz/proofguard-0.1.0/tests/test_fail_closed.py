#!/usr/bin/env python3
"""
test_fail_closed.py — H-5: Fail-closed behavior

Tests:
  F1 — decision without PASS → execution blocked (not silently allowed)
  F2 — non-existent decision_id → execution blocked (CRITICAL violation logged)
  F3 — STOP decision → execution blocked (violation logged)
  F4 — HOLD decision → execution blocked (violation logged)
  F5 — pre_execution_guard + record_execution double enforcement (same decision)
  F6 — malformed action_context (not a dict) → no crash, still blocks if no decision
  F7 — violation log is written on every blocked attempt

Run: python tests/test_fail_closed.py
"""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import proofguard.ledger as dl
from proofguard.ledger import (
    ExecutionBoundaryViolation,
    record_decision,
    record_execution,
    pre_execution_guard,
)

PASS_STR = "\033[32mPASS\033[0m"
FAIL_STR = "\033[31mFAIL\033[0m"
failures = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  {PASS_STR}  {name}")
    else:
        print(f"  {FAIL_STR}  {name}" + (f" — {detail}" if detail else ""))
        failures.append(name)


def setup_temp_ledger():
    """Return temp paths and patch dl module. Returns (ledger_path, violation_path, restore_fn)."""
    tl = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False)
    tv = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False)
    tl.close()
    tv.close()
    orig_l, orig_v = dl._LEDGER, dl._VIOLATION_LOG
    dl._LEDGER = Path(tl.name)
    dl._VIOLATION_LOG = Path(tv.name)

    def restore():
        dl._LEDGER = orig_l
        dl._VIOLATION_LOG = orig_v
        Path(tl.name).unlink(missing_ok=True)
        Path(tv.name).unlink(missing_ok=True)

    return Path(tl.name), Path(tv.name), restore


def count_violations(vlog: Path) -> list:
    if not vlog.exists():
        return []
    lines = [l for l in vlog.read_text().splitlines() if l.strip()]
    return [json.loads(l) for l in lines]


# ── F1: pre_execution_guard blocks STOP decision ────────────────────────────
print("\n[F1] STOP decision → pre_execution_guard blocks")
ledger, vlog, restore = setup_temp_ledger()
try:
    d = record_decision({"task_id": "f1-stop"}, "STOP")
    raised = False
    try:
        pre_execution_guard(d["decision_id"])
    except ExecutionBoundaryViolation:
        raised = True
    check("F1-a pre_execution_guard raises on STOP", raised)
    viols = count_violations(vlog)
    check("F1-b violation logged", len(viols) == 1,
          f"violations: {viols}")
    check("F1-c severity HIGH or CRITICAL",
          viols[0]["severity"] in ("HIGH", "CRITICAL") if viols else False,
          f"got: {viols}")
finally:
    restore()

# ── F2: Non-existent decision_id → CRITICAL ──────────────────────────────────
print("\n[F2] Non-existent decision_id → CRITICAL block")
ledger, vlog, restore = setup_temp_ledger()
try:
    raised = False
    try:
        pre_execution_guard("non-existent-uuid-12345")
    except ExecutionBoundaryViolation:
        raised = True
    check("F2-a pre_execution_guard raises on missing id", raised)
    viols = count_violations(vlog)
    check("F2-b CRITICAL violation logged", len(viols) == 1 and viols[0]["severity"] == "CRITICAL",
          f"violations: {viols}")
finally:
    restore()

# ── F3: record_execution without decision → blocked ──────────────────────────
print("\n[F3] record_execution with non-existent decision_id → blocked")
ledger, vlog, restore = setup_temp_ledger()
try:
    raised = False
    try:
        record_execution("ghost-decision-id", {"result": "ok"}, True)
    except ExecutionBoundaryViolation:
        raised = True
    check("F3-a record_execution raises on missing decision", raised)
    viols = count_violations(vlog)
    check("F3-b CRITICAL violation logged",
          len(viols) == 1 and viols[0]["severity"] == "CRITICAL",
          f"violations: {viols}")
    check("F3-c violation_type EXECUTION_WITHOUT_DECISION",
          viols and viols[0]["violation_type"] == "EXECUTION_WITHOUT_DECISION",
          f"got: {viols}")
finally:
    restore()

# ── F4: HOLD decision → both gates block ─────────────────────────────────────
print("\n[F4] HOLD decision → both pre_execution_guard and record_execution block")
ledger, vlog, restore = setup_temp_ledger()
try:
    d = record_decision({"task_id": "f4-hold"}, "HOLD")
    # gate 1
    raised1 = False
    try:
        pre_execution_guard(d["decision_id"])
    except ExecutionBoundaryViolation:
        raised1 = True
    check("F4-a pre_execution_guard raises on HOLD", raised1)
    # gate 2
    raised2 = False
    try:
        record_execution(d["decision_id"], {}, True)
    except ExecutionBoundaryViolation:
        raised2 = True
    check("F4-b record_execution raises on HOLD", raised2)
    viols = count_violations(vlog)
    check("F4-c two violations logged", len(viols) == 2,
          f"got {len(viols)}: {viols}")
finally:
    restore()

# ── F5: PASS → double enforcement (both gates pass) ──────────────────────────
print("\n[F5] PASS decision → both gates allow, execution recorded")
ledger, vlog, restore = setup_temp_ledger()
try:
    d = record_decision({"task_id": "f5-pass"}, "PASS")
    error = None
    try:
        pre_execution_guard(d["decision_id"])
        e = record_execution(d["decision_id"], {"ok": True}, True)
    except ExecutionBoundaryViolation as ex:
        error = str(ex)
    check("F5-a no violation raised on PASS", error is None,
          f"raised: {error}")
    check("F5-b execution entry recorded", "execution_id" in (e if error is None else {}))
    viols = count_violations(vlog)
    check("F5-c no violations in log", len(viols) == 0,
          f"violations: {viols}")
finally:
    restore()

# ── F6: Malformed action_context (None, string) → no crash ───────────────────
print("\n[F6] Malformed action_context types → no crash, still blocks")
ledger, vlog, restore = setup_temp_ledger()
try:
    for ctx in [None, "not-a-dict", 42, []]:
        raised = False
        crashed = False
        try:
            pre_execution_guard("missing-id", ctx)
        except ExecutionBoundaryViolation:
            raised = True
        except Exception as ex:
            crashed = True
        check(f"F6 action_context={ctx!r} → blocked without crash",
              raised and not crashed,
              f"raised={raised}, crashed={crashed}")
finally:
    restore()

# ── F7: Every blocked attempt writes to violation log ────────────────────────
print("\n[F7] Multiple blocked attempts → all written to violation log")
ledger, vlog, restore = setup_temp_ledger()
try:
    for i in range(5):
        try:
            pre_execution_guard(f"missing-{i}")
        except ExecutionBoundaryViolation:
            pass
    viols = count_violations(vlog)
    check("F7 all 5 violations logged", len(viols) == 5,
          f"got {len(viols)}")
    types = {v["violation_type"] for v in viols}
    check("F7 all are PRE_GUARD_NO_DECISION", types == {"PRE_GUARD_NO_DECISION"},
          f"got: {types}")
finally:
    restore()

# ── Summary ──────────────────────────────────────────────────────────────────
print(f"\n{'='*50}")
if failures:
    print(f"FAILED: {len(failures)} test(s): {', '.join(failures)}")
    sys.exit(1)
else:
    print("All fail-closed tests PASSED")
    sys.exit(0)
