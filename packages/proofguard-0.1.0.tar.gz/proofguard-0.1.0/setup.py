from setuptools import setup, find_packages

setup(
    name="proofguard",
    version="0.1.0",
    packages=find_packages(include=["proofguard", "proofguard.*"]),
    python_requires=">=3.8",
)
