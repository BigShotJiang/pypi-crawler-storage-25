"""
proofguard/schema.py
====================
Field definitions and schema version for ProofGuard ledger entries.

schema_version: "proofguard-1.0"

Decision entry fields (required):
  type            — "decision"
  decision_id     — UUID str
  actor           — str
  timestamp       — ISO 8601 UTC
  judgment_result — "PASS" | "STOP" | "HOLD" | "RETRY"
  input_hash      — SHA-256(canonical(decision_context))
  artifact_hash   — SHA-256(f"{judgment_result}:{token_id}")
  token_id        — str | None
  authority_id    — str | None
  prev_hash       — entry_hash of previous entry, or "genesis"
  entry_hash      — SHA-256(canonical(entry_body))

Execution entry fields (required):
  type            — "execution"
  execution_id    — UUID str
  decision_id     — links to decision entry
  actor           — str
  timestamp       — ISO 8601 UTC
  success         — bool
  result_hash     — SHA-256(canonical(execution_result))
  error_message   — str | None
  prev_hash       — entry_hash of previous entry
  entry_hash      — SHA-256(canonical(entry_body))

Violation severity:
  EXECUTION_WITHOUT_DECISION → CRITICAL
  EXECUTION_ON_NON_PASS      → CRITICAL
  PRE_GUARD_NO_DECISION      → CRITICAL
  PRE_GUARD_NON_PASS         → HIGH
  (all others)               → LOW
"""

SCHEMA_VERSION = "proofguard-1.0"

JUDGMENT_RESULTS = frozenset({"PASS", "STOP", "HOLD", "RETRY"})

VIOLATION_SEVERITY = {
    "EXECUTION_WITHOUT_DECISION": "CRITICAL",
    "EXECUTION_ON_NON_PASS":      "CRITICAL",
    "PRE_GUARD_NO_DECISION":      "CRITICAL",
    "PRE_GUARD_NON_PASS":         "HIGH",
}

DECISION_FIELDS = (
    "type", "decision_id", "actor", "timestamp", "judgment_result",
    "input_hash", "artifact_hash", "token_id", "authority_id",
    "prev_hash",  # entry_hash excluded — computed from these
)

EXECUTION_FIELDS = (
    "type", "execution_id", "decision_id", "actor", "timestamp",
    "success", "result_hash", "error_message",
    "prev_hash",  # entry_hash excluded
)
