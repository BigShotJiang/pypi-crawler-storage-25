"""
proofguard/ledger.py
====================
ProofGuard decision + execution ledger (append-only, hash-chain).

Standalone module — no external system dependencies.

Usage:
    from proofguard.ledger import record_decision, record_execution, pre_execution_guard

Default ledger path: .proofguard-ledger.jsonl (cwd)
Override: set PROOFGUARD_LEDGER env var or assign proofguard.ledger._LEDGER = Path(...)

Entry schema
------------
decision:
  type, decision_id, actor, timestamp, judgment_result,
  input_hash, artifact_hash, token_id, authority_id, prev_hash, entry_hash

execution:
  type, execution_id, decision_id, actor, timestamp,
  success, result_hash, error_message, prev_hash, entry_hash
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

# Canonical JSON — must match verify_proof._canon_dumps() exactly.
_CANON_SEP = (',', ':')

# Default paths — override by setting these module-level variables directly
# or via environment variable PROOFGUARD_LEDGER / PROOFGUARD_VIOLATION_LOG.
_LEDGER        = Path(os.environ.get("PROOFGUARD_LEDGER",        ".proofguard-ledger.jsonl"))
_VIOLATION_LOG = Path(os.environ.get("PROOFGUARD_VIOLATION_LOG", ".proofguard-violations.jsonl"))


class ExecutionBoundaryViolation(Exception):
    """Raised when execution is attempted without a valid PASS decision."""
    pass


# ── Crypto utils ──────────────────────────────────────────────────────────────

def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _canon_dumps(obj: Any) -> str:
    """Canonical JSON: keys sorted, no whitespace, ensure_ascii=False.
    Must stay in sync with verify_proof._canon_dumps().
    """
    return json.dumps(obj, sort_keys=True, separators=_CANON_SEP, ensure_ascii=False)


# ── Atomic append ─────────────────────────────────────────────────────────────

def _last_entry_hash_unlocked(f) -> str:
    """Read last entry_hash from open file handle (must hold LOCK_EX)."""
    last_hash = "genesis"
    f.seek(0)
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            last_hash = entry.get("entry_hash") or last_hash
        except json.JSONDecodeError:
            continue
    f.seek(0, 2)
    return last_hash


def _append_ledger_entry(build_fn) -> Dict:
    """Atomic append with LOCK_EX + fsync.

    build_fn(prev_hash: str) → dict  (without entry_hash)
    prev_hash is read inside the lock — no concurrent race possible.
    """
    _LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with _LEDGER.open("a+", encoding="utf-8") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            prev_hash  = _last_entry_hash_unlocked(f)
            body       = build_fn(prev_hash)
            entry_hash = _sha256(_canon_dumps(body))
            entry      = {**body, "entry_hash": entry_hash}
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)
    return entry


def _append_violation(v: Dict) -> None:
    _VIOLATION_LOG.parent.mkdir(parents=True, exist_ok=True)
    with _VIOLATION_LOG.open("a", encoding="utf-8") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            f.write(json.dumps(v, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


# ── Lookup ────────────────────────────────────────────────────────────────────

def _lookup_decision(decision_id: str) -> Optional[Dict]:
    if not _LEDGER.exists():
        return None
    try:
        with _LEDGER.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    if e.get("type") == "decision" and e.get("decision_id") == decision_id:
                        return e
                except json.JSONDecodeError:
                    continue
    except Exception:
        pass
    return None


# ── Violation ─────────────────────────────────────────────────────────────────

_SEVERITY = {
    "EXECUTION_WITHOUT_DECISION": "CRITICAL",
    "EXECUTION_ON_NON_PASS":      "CRITICAL",
    "PRE_GUARD_NO_DECISION":      "CRITICAL",
    "PRE_GUARD_NON_PASS":         "HIGH",
}


def _record_violation(vtype: str, decision_id: str, detail: str) -> Dict:
    v = {
        "timestamp":      datetime.now(timezone.utc).isoformat(),
        "violation_type": vtype,
        "severity":       _SEVERITY.get(vtype, "LOW"),
        "decision_id":    decision_id,
        "detail":         detail,
        "anomaly_flag":   True,
    }
    _append_violation(v)
    return v


# ── Public API ────────────────────────────────────────────────────────────────

def pre_execution_guard(decision_id: str, action_context: Optional[Dict] = None) -> None:
    """Gate 1: block execution if no valid PASS decision exists.

    Raises ExecutionBoundaryViolation and logs to violation log on any block.
    Safe with malformed action_context (None / non-dict).
    """
    entry   = _lookup_decision(decision_id)
    ctx_str = _canon_dumps(action_context if isinstance(action_context, dict) else {})[:120]

    if entry is None:
        _record_violation("PRE_GUARD_NO_DECISION", decision_id,
                          f"decision_id not found. ctx={ctx_str}")
        raise ExecutionBoundaryViolation(
            f"[pre_execution_guard] decision_id={decision_id!r} not found")

    judgment = entry.get("judgment_result", "")
    if judgment != "PASS":
        _record_violation("PRE_GUARD_NON_PASS", decision_id,
                          f"judgment={judgment!r}. ctx={ctx_str}")
        raise ExecutionBoundaryViolation(
            f"[pre_execution_guard] judgment={judgment!r} — execution blocked")


def record_decision(
    decision_context: Dict[str, Any],
    judgment_result: str,
    token: Optional[str] = None,
) -> Dict:
    """Append a decision entry to the ledger.

    Args:
        decision_context: input context dict (task info, source, etc.)
        judgment_result:  "PASS" | "STOP" | "HOLD" | "RETRY"
        token:            ProofGuard Authority Token JSON string (optional)

    Returns:
        ledger entry dict
    """
    decision_id = str(uuid.uuid4())
    ts          = datetime.now(timezone.utc).isoformat()
    actor = (decision_context.get("task_id") or decision_context.get("id")
             or decision_context.get("source") or "unknown")

    token_id = authority_id = None
    if token:
        try:
            tok          = json.loads(token)
            token_id     = tok.get("tokenId")
            pub_key      = tok.get("issuerPublicKey", "")
            authority_id = pub_key[:16] if pub_key else None
        except Exception:
            pass

    input_hash    = _sha256(_canon_dumps(decision_context))
    artifact_hash = _sha256(f"{judgment_result}:{token_id or ''}")

    def _build(prev_hash: str) -> Dict:
        return {
            "type":            "decision",
            "decision_id":     decision_id,
            "actor":           actor,
            "timestamp":       ts,
            "judgment_result": judgment_result,
            "input_hash":      input_hash,
            "artifact_hash":   artifact_hash,
            "token_id":        token_id,
            "authority_id":    authority_id,
            "prev_hash":       prev_hash,
        }

    return _append_ledger_entry(_build)


def record_execution(
    decision_id: str,
    execution_result: Any,
    success_flag: bool,
    error_message: Optional[str] = None,
    actor: Optional[str] = None,
) -> Dict:
    """Gate 2 + append execution entry.

    Enforces: decision must exist and be PASS. Logs violation and raises on any block.

    Args:
        decision_id:      links to a decision entry
        execution_result: fn() return value (must be JSON-serializable)
        success_flag:     True if execution succeeded
        error_message:    error string on failure (optional)
        actor:            override actor name (optional)

    Returns:
        execution entry dict
    """
    decision_entry = _lookup_decision(decision_id)

    if decision_entry is None:
        _record_violation("EXECUTION_WITHOUT_DECISION", decision_id,
                          f"decision_id={decision_id!r} not found")
        raise ExecutionBoundaryViolation(
            f"[record_execution] decision_id={decision_id!r} not found — blocked")

    judgment = decision_entry.get("judgment_result", "")
    if judgment != "PASS":
        _record_violation("EXECUTION_ON_NON_PASS", decision_id,
                          f"judgment={judgment!r} — not PASS")
        raise ExecutionBoundaryViolation(
            f"[record_execution] judgment={judgment!r} — only PASS allowed")

    execution_id = str(uuid.uuid4())
    ts           = datetime.now(timezone.utc).isoformat()

    try:
        result_str = json.dumps(execution_result, sort_keys=True,
                                separators=_CANON_SEP, ensure_ascii=False, default=str)
    except Exception:
        result_str = str(execution_result)
    result_hash = _sha256(result_str)

    def _build(prev_hash: str) -> Dict:
        return {
            "type":          "execution",
            "execution_id":  execution_id,
            "decision_id":   decision_id,
            "actor":         actor or decision_entry.get("actor", "unknown"),
            "timestamp":     ts,
            "success":       success_flag,
            "result_hash":   result_hash,
            "error_message": error_message,
            "prev_hash":     prev_hash,
        }

    return _append_ledger_entry(_build)


def export_proof_capsule(output_path: str) -> Dict:
    """Export ledger as a portable proof capsule JSON for external verification.

    The capsule contains all decision+execution pairs and the ledger root_hash.
    It can be verified with verify_proof.py without any ProofGuard dependency.

    Args:
        output_path: path to write proof_capsule.json

    Returns:
        capsule dict
    """
    entries = []
    if _LEDGER.exists():
        for line in _LEDGER.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

    decisions  = {e["decision_id"]: e for e in entries if e.get("type") == "decision"}
    executions = {e["decision_id"]: e for e in entries if e.get("type") == "execution"}

    pairs = []
    for did, dec in decisions.items():
        pairs.append({
            "decision":  dec,
            "execution": executions.get(did),
        })

    all_hashes = [e.get("entry_hash") or "" for e in entries]
    root_hash  = _sha256("|".join(all_hashes))

    capsule = {
        "schema_version":   "proofguard-1.0",
        "exported_at":      datetime.now(timezone.utc).isoformat(),
        "ledger_root_hash": root_hash,
        "total_entries":    len(entries),
        "total_decisions":  len(decisions),
        "total_executions": len(executions),
        "pairs":            pairs,
    }

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(capsule, indent=2, ensure_ascii=False), encoding="utf-8")
    return capsule
