"""
proofguard/canonical.py
=======================
Canonical JSON serialization.

Rule: keys sorted, separators=(',',':'), ensure_ascii=False.
This is the single source of truth for hash computation.
Must stay in sync with verify_proof._canon_dumps().
"""
from __future__ import annotations

import json
from typing import Any

_SEP = (',', ':')


def canon_dumps(obj: Any) -> str:
    """Serialize obj to canonical JSON bytes (as str).

    Properties:
      - Key order is always alphabetical (at every nesting level)
      - No whitespace between tokens
      - Non-ASCII characters preserved (not escaped)
      - Deterministic: same logical object → always same bytes
    """
    return json.dumps(obj, sort_keys=True, separators=_SEP, ensure_ascii=False)
