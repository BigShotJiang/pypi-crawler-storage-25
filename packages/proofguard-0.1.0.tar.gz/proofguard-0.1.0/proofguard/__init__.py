"""
ProofGuard — No Proof, No Execution.

Every execution is cryptographically bound to a prior decision.

Quick start:
    from proofguard import record_decision, pre_execution_guard, record_execution

    decision = record_decision({"task": "deploy"}, "PASS")
    pre_execution_guard(decision["decision_id"])
    result   = do_work()
    record_execution(decision["decision_id"], result, success=True)
"""

from proofguard.ledger import (
    ExecutionBoundaryViolation,
    pre_execution_guard,
    record_decision,
    record_execution,
)
from proofguard.guard import Guard, guarded
from proofguard.schema import SCHEMA_VERSION

__version__ = "0.1.0"

__all__ = [
    "ExecutionBoundaryViolation",
    "pre_execution_guard",
    "record_decision",
    "record_execution",
    "Guard",
    "guarded",
    "SCHEMA_VERSION",
]
