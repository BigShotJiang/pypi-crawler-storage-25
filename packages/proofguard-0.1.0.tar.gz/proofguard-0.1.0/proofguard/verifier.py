"""
proofguard/verifier.py
======================
In-process ledger and capsule verification.
Thin wrapper around verify_proof for use as a library.

For standalone CLI use: python verify_proof.py <capsule.json>
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

# verify_proof is the canonical standalone verifier — import from package root
import sys as _sys
_sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from verify_proof import verify_chain as _verify_chain
from verify_proof import verify_capsule as _verify_capsule


def verify_chain(ledger_path: str) -> Dict:
    """Verify hash-chain integrity of a ledger file.

    Returns:
        {
          "chain_valid": bool,
          "total_entries": int,
          "broken_at": int | None,
          "entry_hash_errors": list,
          "first_mismatch_index": int | None,
          "root_hash": str,
        }
    """
    return _verify_chain(ledger_path)


def verify_capsule(capsule_path: str, ledger_path: Optional[str] = None) -> Dict:
    """Verify a proof capsule JSON file.

    Args:
        capsule_path: path to proof_capsule.json
        ledger_path:  optional path to ledger file for root_hash cross-validation

    Returns:
        {
          "verdict": "PASS" | "FAIL",
          "chain_valid": bool | None,
          "root_hash_match": bool | None,
          "total_decisions": int,
          "total_executions": int,
          "anomalies": list,
          "critical_anomalies": int,
          ...
        }
    """
    return _verify_capsule(capsule_path, ledger_path)
