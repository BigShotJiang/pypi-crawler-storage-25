"""
proofguard/guard.py
===================
High-level guard decorator and context manager.

Usage — decorator:

    from proofguard.guard import guarded

    @guarded(judgment_result="PASS", context={"task": "deploy"})
    def deploy():
        ...  # only runs if judgment_result == "PASS"


Usage — explicit:

    from proofguard.guard import Guard

    with Guard(context={"task": "deploy"}, judgment_result="PASS") as g:
        result = do_work()
        g.record(result, success=True)
"""
from __future__ import annotations

import functools
from typing import Any, Callable, Dict, Optional

from proofguard.ledger import (
    ExecutionBoundaryViolation,
    pre_execution_guard,
    record_decision,
    record_execution,
)


class Guard:
    """Context manager that wraps decision → gate → execution → record."""

    def __init__(self, context: Dict[str, Any], judgment_result: str = "PASS",
                 token: Optional[str] = None) -> None:
        self._context  = context
        self._judgment = judgment_result
        self._token    = token
        self._decision = None

    def __enter__(self) -> "Guard":
        self._decision = record_decision(self._context, self._judgment, self._token)
        pre_execution_guard(self._decision["decision_id"])
        return self

    def record(self, result: Any, success: bool = True,
               error: Optional[str] = None) -> Dict:
        """Record execution result. Call inside the with block."""
        if self._decision is None:
            raise RuntimeError("Guard.record() called outside context manager")
        return record_execution(
            self._decision["decision_id"], result, success, error
        )

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        # Do not suppress exceptions — caller decides
        return False


def guarded(context: Dict[str, Any], judgment_result: str = "PASS",
            token: Optional[str] = None) -> Callable:
    """Decorator: wraps a function with ProofGuard decision + execution recording.

    The wrapped function only executes if judgment_result == "PASS".
    Result is automatically recorded on success/failure.

    Example:
        @guarded({"task": "send_report"}, judgment_result="PASS")
        def send_report():
            return {"sent": True}
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            decision = record_decision(context, judgment_result, token)
            pre_execution_guard(decision["decision_id"])
            try:
                result = fn(*args, **kwargs)
                record_execution(decision["decision_id"], result, True)
                return result
            except Exception as exc:
                record_execution(decision["decision_id"], {}, False,
                                 error_message=str(exc))
                raise
        return wrapper
    return decorator
