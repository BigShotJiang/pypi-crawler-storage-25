"""Drive Nix to build targets and materialize outputs."""

from __future__ import annotations

import fnmatch
import shutil
import subprocess
import sys
from pathlib import Path

from rigx import nix_gen
from rigx.config import Project

OUTPUT_DIR = "output"
FLAKE_FILE = "flake.nix"
NIX_EXPERIMENTAL = ["--extra-experimental-features", "nix-command flakes"]


class BuildError(RuntimeError):
    pass


class NixNotFoundError(BuildError):
    """Raised when the `nix` binary is not on PATH."""


NIX_INSTALL_INSTRUCTIONS = """\
Nix is required but was not found on PATH.

rigx runs all builds inside Nix's sandbox. Install Nix, restart your shell,
then re-run `rigx`.

Install instructions
--------------------

macOS / Linux (official installer):
  sh <(curl -L https://nixos.org/nix/install) --daemon

macOS / Linux (Determinate Systems installer, recommended for most users):
  curl --proto '=https' --tlsv1.2 -sSf -L \\
    https://install.determinate.systems/nix | sh -s -- install

After installing, restart your shell or source:
  . /nix/var/nix/profiles/default/etc/profile.d/nix-daemon.sh

Docs: https://nixos.org/download
"""


def _flake_path(project: Project) -> Path:
    return project.root / FLAKE_FILE


def _output_dir(project: Project) -> Path:
    return project.root / OUTPUT_DIR


def _nix_bin() -> str:
    nix = shutil.which("nix")
    if not nix:
        raise NixNotFoundError(NIX_INSTALL_INSTRUCTIONS)
    return nix


def write_flake(project: Project) -> Path:
    """Regenerate flake.nix at the project root. Returns the file path.

    Recursively regenerates flake.nix for every transitive local-dep so the
    sub-flakes referenced as path inputs are themselves valid flakes."""
    for ldep in project.local_deps.values():
        if ldep.sub_project:
            write_flake(ldep.sub_project)
    flake_path = _flake_path(project)
    new_content = nix_gen.generate(project)
    changed = (
        not flake_path.is_file()
        or flake_path.read_text() != new_content
    )
    flake_path.write_text(new_content)
    if changed:
        _hint_commit_generated(project, ["flake.nix"])
    return flake_path


def _is_git_work_tree(root: Path) -> bool:
    git = shutil.which("git")
    if not git:
        return False
    r = subprocess.run(
        [git, "rev-parse", "--is-inside-work-tree"],
        cwd=root, check=False, capture_output=True, text=True,
    )
    return r.returncode == 0 and r.stdout.strip() == "true"


def _hint_commit_generated(project: Project, files: list[str]) -> None:
    """Print a one-line reminder when rigx-generated files change inside a
    git work-tree. Stays silent outside git (no actionable advice). rigx
    never touches the index itself — committing is the user's call."""
    if not _is_git_work_tree(project.root):
        return
    joined = " ".join(files)
    print(
        f"[rigx] regenerated {joined} — commit when stable so future "
        f"runs reuse the same lock.",
        file=sys.stderr,
    )


def _flake_ref(project: Project, attr: str | None = None) -> str:
    # Use the explicit "path:" scheme so Nix treats the directory as a flake
    # regardless of any enclosing git repo (which otherwise hides untracked
    # files like the generated flake.nix).
    ref = f"path:{project.root.resolve()}"
    return f"{ref}#{attr}" if attr else ref


def run_nixpkgs_tool(
    project: Project,
    attr: str,
    args: list[str],
    cwd: Path | None = None,
) -> int:
    """Invoke a binary from the project's pinned nixpkgs via `nix run`.

    Lets rigx wrap tools like `uv` without requiring the user to install them
    on their host — the project's `[nixpkgs].ref` (pinned via flake.lock)
    provides a reproducible binary.
    """
    nix = _nix_bin()
    cmd = [
        nix,
        *NIX_EXPERIMENTAL,
        "run",
        f"nixpkgs/{project.nixpkgs_ref}#{attr}",
        "--",
        *args,
    ]
    result = subprocess.run(cmd, cwd=cwd, check=False)
    return result.returncode


def update_lock(project: Project) -> None:
    write_flake(project)
    lock_path = project.root / "flake.lock"
    before = lock_path.read_bytes() if lock_path.is_file() else b""
    nix = _nix_bin()
    cmd = [nix, *NIX_EXPERIMENTAL, "flake", "lock", _flake_ref(project)]
    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        raise BuildError(f"nix flake lock failed (exit {result.returncode})")
    after = lock_path.read_bytes() if lock_path.is_file() else b""
    if before != after:
        _hint_commit_generated(project, ["flake.lock"])


def _resolve_attr(project: Project, spec: str) -> str:
    """Map a user target spec to a Nix attr name. Accepted shapes:

    - `hello`                — own target, no variant.
    - `hello@debug`          — own target, variant.
    - `frontend.app`         — local-dep (cross-flake) target, no variant.
    - `frontend.app@release` — local-dep target, variant.

    Cross-flake variants are validated against the sub-project's metadata
    (loaded recursively at config time), so a typo'd variant fails fast here
    instead of producing a missing-attr error from `nix build`."""
    if "@" in spec:
        name, variant = spec.split("@", 1)
    else:
        name, variant = spec, None

    dotted = "." in name
    if dotted and name in project.targets:
        # B-merged target (`frontend.greet` is a key in this flake's targets).
        target = project.targets[name]
    elif dotted:
        # A-style cross-flake ref into a sibling local-dep.
        resolved = project.find_target(name)
        if resolved is None:
            raise BuildError(f"no such target: {name}")
        owning, target_name = resolved
        target = owning.targets[target_name]
    else:
        if name not in project.targets:
            raise BuildError(f"no such target: {name}")
        target = project.targets[name]

    if variant is not None and variant not in target.variants:
        available = ", ".join(target.variant_names()) or "(none)"
        raise BuildError(
            f"target {name!r} has no variant {variant!r}; available: {available}"
        )

    raw = name if variant is None else f"{name}-{variant}"
    # Any dotted form (B-merged or cross-flake) gets sanitized for the Nix
    # attr; plain own-target names pass through unchanged so existing
    # hyphenated variant attrs (`hello-debug`) keep working.
    return _nix_id(raw) if dotted else raw


def _nix_id(name: str) -> str:
    """Map a possibly-dotted rigx name to a Nix identifier. Mirrors
    `nix_gen._nix_id` — kept duplicated to avoid a builder→nix_gen
    private-symbol import. Hyphens are valid Nix identifier characters
    and pass through unchanged."""
    return name.replace(".", "_")


def _all_attrs(project: Project) -> list[str]:
    """Every build attribute (targets with variants expand to one per variant).

    `script`/`testbed`-kind targets are excluded so `rigx build` with no
    arguments does not inadvertently run side-effecting tasks (publish,
    deploy, interactive testbeds). Run them explicitly with
    `rigx run <name>`.

    Names are sanitized when dotted (B-merged module targets) so they match
    the Nix attrs emitted by `nix_gen._target_block`.
    """
    attrs: list[str] = []
    for name, target in project.targets.items():
        if target.kind in ("script", "test", "testbed"):
            continue
        attr_base = _nix_id(name) if "." in name else name
        if not target.variants:
            attrs.append(attr_base)
        else:
            for v in target.variant_names():
                attrs.append(f"{attr_base}-{v}")
    return attrs


def run_script_target(
    project: Project, target, extra_args: list[str] | None = None
) -> int:
    """Execute a `kind = "script"` target via `nix shell` on the host.

    Tools listed in `deps.nixpkgs` are brought onto PATH from the project's
    pinned nixpkgs. Runs in the project root; no sandbox. The target's script
    is passed to `bash -eo pipefail`. `extra_args` (typed after `--` on the
    command line) are forwarded as `$1`, `$2`, … inside the script.
    """
    assert target.script is not None
    nix = _nix_bin()
    refs = [
        f"nixpkgs/{project.nixpkgs_ref}#{pkg}"
        for pkg in target.deps.nixpkgs
    ]
    cmd = [
        nix,
        *NIX_EXPERIMENTAL,
        "shell",
        *refs,
        "--command",
        "bash",
        "-eo",
        "pipefail",
        "-c",
        target.script,
        target.name,
        *(extra_args or []),
    ]
    result = subprocess.run(cmd, cwd=project.root, check=False)
    return result.returncode


def run_named_script(
    project: Project, name: str, extra_args: list[str] | None = None
) -> None:
    """CLI helper: look up a script-style target by name and execute it.

    Accepts both `kind = "script"` (one-shot host-side task) and
    `kind = "testbed"` (interactive scenario that sets things up and
    waits for input). Both share the `script` field and the same
    host-side execution path; the distinct kinds let `rigx list
    --kind testbed` discover scenarios separately from generic
    scripts."""
    if name not in project.targets:
        raise BuildError(f"no such target: {name}")
    target = project.targets[name]
    if target.kind not in ("script", "testbed"):
        raise BuildError(
            f"target {name!r} (kind={target.kind!r}) is not a script or "
            f"testbed target; use `rigx build {name}` instead"
        )
    print(f"[rigx] running {name}")
    rc = run_script_target(project, target, extra_args)
    if rc != 0:
        raise BuildError(f"{target.kind} target {name!r} failed (exit {rc})")


def run_tests(
    project: Project, filters: list[str] | None = None, jobs: int | None = None,
) -> list[tuple[str, int]]:
    """Discover and execute every `kind = "test"` target. Returns
    [(qualified_name, exit_code), …].

    A test's `sandbox` field decides how it runs:
      - `sandbox = true` (default): the test is its own Nix derivation.
        `nix build` it; success = build succeeds. Sandbox isolation, no
        host filesystem, no network, **automatic input-hash caching**.
      - `sandbox = false`: host-side via `nix shell` + `bash -c <script>`,
        cwd = project root. No caching; parallelism only safe if the test
        body is. Mark such tests with `exclusive = true` if they touch
        shared state.

    `filters` are fnmatch patterns; a target runs if it matches any.

    `jobs` controls outer parallelism. Default (None or ≤ 1) is sequential.
    With `jobs > 1`:
      - **Sandboxed tests** run in a `ThreadPoolExecutor` of size `jobs`.
      - **Host tests** run in two phases: `exclusive = true` ones first
        sequentially (streaming), then non-exclusives in a pool of size
        `jobs` (output captured).

    The pools never overlap (sandboxed first, then host)."""
    host_tests: list[tuple[str, object]] = []
    sandboxed: list[tuple[str, object]] = []
    for name, target in project.targets.items():
        if target.kind != "test":
            continue
        if filters and not any(fnmatch.fnmatchcase(name, f) for f in filters):
            continue
        if target.sandbox:
            sandboxed.append((name, target))
        else:
            host_tests.append((name, target))

    if not host_tests and not sandboxed:
        return []

    results: list[tuple[str, int]] = []
    if sandboxed:
        results.extend(_run_sandboxed_tests(project, sandboxed, jobs))
    if host_tests:
        # Sandboxed tests pull their `deps.internal` in via Nix derivation
        # edges. Host tests don't — the script runs in the project root
        # and references `output/<dep>/...` paths, which only exist after
        # an explicit `nix build` with `--out-link`. Build them now.
        _ensure_host_test_deps_built(project, host_tests, jobs)
        if not jobs or jobs <= 1 or len(host_tests) == 1:
            results.extend(_run_tests_sequential(project, host_tests))
        else:
            results.extend(_run_tests_parallel(project, host_tests, jobs))
    return results


def _ensure_host_test_deps_built(
    project: Project, host_tests: list[tuple[str, object]], jobs: int | None,
) -> None:
    """Build host tests' `deps.internal` so the `output/<dep>/` symlinks
    exist before the test scripts reference them. Test/script deps are
    skipped — `kind = "test"` / `kind = "script"` aren't buildable
    (`build()` would error)."""
    seen: set[str] = set()
    to_build: list[str] = []
    for _, target in host_tests:
        for dep in target.deps.internal:
            if dep in seen:
                continue
            seen.add(dep)
            resolved = project.find_target(dep)
            if resolved is not None:
                owner, dep_name = resolved
                dep_target = owner.targets.get(dep_name)
                if dep_target is not None and dep_target.kind in (
                    "test", "script", "testbed",
                ):
                    continue
            to_build.append(dep)
    if not to_build:
        return
    print(f"[rigx test] building host-test deps: {', '.join(to_build)}")
    build(project, to_build, jobs=jobs)


def _cross_arch_qemu_capsules(
    project: Project, names: list[str],
) -> list[tuple[str, str]]:
    """Return [(name, target_triple)] for each entry in `names` that is a
    `kind = "capsule"`, `backend = "qemu"` target whose `target` field
    differs from the empty default — i.e. wants a VM whose arch is not
    the host's. Building those needs binfmt + nix `extra-platforms` on
    the host."""
    out: list[tuple[str, str]] = []
    for name in names:
        resolved = project.find_target(name)
        if resolved is None:
            continue
        owner, dep_name = resolved
        t = owner.targets.get(dep_name)
        if t is None:
            continue
        if t.kind == "capsule" and t.backend == "qemu" and t.target:
            out.append((name, t.target))
    return out


def _cross_arch_hint(cross_arch: list[tuple[str, str]]) -> str:
    """Friendly post-failure note for cross-arch qemu capsule builds.
    Stays distro-agnostic — names the *what* (binfmt registration plus
    `extra-platforms`) and leaves the *how* to the user's package
    manager."""
    listing = ", ".join(f"{n!r} (target = {t!r})" for n, t in cross_arch)
    arches = sorted({t for _, t in cross_arch})
    arches_line = " ".join(arches)
    if len(cross_arch) == 1:
        head = f"Hint: {listing} is a cross-arch qemu capsule. "
        subj = "Building it"
    else:
        head = f"Hint: {listing} are cross-arch qemu capsules. "
        subj = "Building them"
    return (
        "\n\n"
        f"{head}{subj} on a different host arch needs two pieces of host "
        "setup:\n"
        "  1. binfmt_misc registered for the target arch — so the kernel "
        "can run cross-arch ELF binaries through qemu's user-mode emulator. "
        "Verify with `cat /proc/sys/fs/binfmt_misc/qemu-<arch>` (e.g. "
        "qemu-aarch64); look for `enabled`.\n"
        f"  2. `extra-platforms = {arches_line}` in your Nix daemon config "
        "(typically /etc/nix/nix.conf), then restart the daemon.\n"
        "On NixOS, `boot.binfmt.emulatedSystems = [ \"<target>\" ];` "
        "configures both in one step. On other systems, install a "
        "qemu-user package for your distro and add the nix.conf line."
    )


def _run_sandboxed_tests(
    project: Project, tests: list[tuple[str, object]], jobs: int | None,
) -> list[tuple[str, int]]:
    """Run sandboxed `kind = "test"` targets via `nix build`. Each test
    is its own derivation; building it succeeds iff its `script` exited 0.

    With `jobs > 1`, dispatches via a `ThreadPoolExecutor` so independent
    derivations build in parallel. Within each `nix build` call, Nix may
    further fan out internally (controlled by the user's `nix.conf`
    `max-jobs`). For sequential mode (jobs ≤ 1), each test streams output
    live."""
    write_flake(project)
    nix = _nix_bin()

    def run_one(name: str) -> tuple[int, str]:
        cmd = [
            nix, *NIX_EXPERIMENTAL, "build", _flake_ref(project, name),
            "--no-link",
        ]
        # Capture only when running in parallel — sequential mode streams
        # for live progress.
        if jobs and jobs > 1:
            r = subprocess.run(
                cmd, check=False,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            )
            return r.returncode, r.stdout or ""
        r = subprocess.run(cmd, check=False)
        return r.returncode, ""

    results: list[tuple[str, int]] = []
    if not jobs or jobs <= 1 or len(tests) == 1:
        for name, _ in tests:
            print(f"[rigx test] {name} (sandboxed)")
            rc, _ = run_one(name)
            results.append((name, rc))
        return results

    import concurrent.futures
    print(
        f"[rigx test] {len(tests)} sandboxed test(s) in parallel "
        f"(jobs={jobs}; output captured per-test)"
    )
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as ex:
        futures = {ex.submit(run_one, n): n for n, _ in tests}
        for fut in concurrent.futures.as_completed(futures):
            name = futures[fut]
            rc, output = fut.result()
            _print_test_block(f"{name} (sandboxed)", rc, output)
            results.append((name, rc))
    return results


def _run_tests_sequential(
    project: Project, selected: list[tuple[str, object]]
) -> list[tuple[str, int]]:
    results: list[tuple[str, int]] = []
    for name, target in selected:
        marker = " (exclusive)" if getattr(target, "exclusive", False) else ""
        print(f"[rigx test] {name}{marker}")
        rc = run_script_target(project, target)
        results.append((name, rc))
    return results


def _run_tests_parallel(
    project: Project, selected: list[tuple[str, object]], jobs: int,
) -> list[tuple[str, int]]:
    """Two phases: exclusives first (one at a time, streaming) then the
    rest in a thread pool (output captured + printed on completion)."""
    import concurrent.futures
    exclusives = [(n, t) for n, t in selected if getattr(t, "exclusive", False)]
    parallel = [(n, t) for n, t in selected if not getattr(t, "exclusive", False)]

    results: list[tuple[str, int]] = []
    for name, target in exclusives:
        print(f"[rigx test] {name} (exclusive)")
        rc = run_script_target(project, target)
        results.append((name, rc))

    if not parallel:
        return results

    print(
        f"[rigx test] {len(parallel)} test(s) in parallel "
        f"(jobs={jobs}; output captured per-test)"
    )
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as ex:
        futures = {
            ex.submit(_run_test_capture, project, t): n
            for n, t in parallel
        }
        for fut in concurrent.futures.as_completed(futures):
            name = futures[fut]
            rc, output = fut.result()
            _print_test_block(name, rc, output)
            results.append((name, rc))
    return results


def _run_test_capture(project: Project, target) -> tuple[int, str]:
    """Like `run_script_target` but captures stdout+stderr together so
    parallel test output doesn't interleave on the parent terminal."""
    assert target.script is not None
    nix = _nix_bin()
    refs = [
        f"nixpkgs/{project.nixpkgs_ref}#{pkg}"
        for pkg in target.deps.nixpkgs
    ]
    cmd = [
        nix, *NIX_EXPERIMENTAL, "shell", *refs, "--command",
        "bash", "-eo", "pipefail", "-c", target.script, target.name,
    ]
    result = subprocess.run(
        cmd, cwd=project.root, check=False,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    return result.returncode, result.stdout or ""


def _print_test_block(name: str, rc: int, output: str) -> None:
    status = "PASS" if rc == 0 else f"FAIL (exit {rc})"
    print(f"\n[rigx test] {name}  {status}")
    if output:
        # Two-space indent makes the boundary between rigx's framing
        # and the test's own output unambiguous.
        for line in output.rstrip("\n").splitlines():
            print(f"  {line}")


def _has_glob(s: str) -> bool:
    return any(c in s for c in "*?[")


def _expand_build_spec(project: Project, spec: str) -> list[str]:
    """Resolve one CLI build spec to a list of Nix attrs.

    - Literal `hello`            → existing alias resolution.
    - Literal `hello@release`    → existing variant resolution.
    - Glob `hello*`              → match target names (variants ignored when
                                   matching), expand all variants per match.
                                   `*` alone is equivalent to `rigx build`
                                   with no args.

    Globs match own and `[modules]`-merged target names (`project.targets`).
    Cross-flake (A) refs aren't reachable through globs in v1 — name them
    explicitly or run `rigx build` from inside the sibling project."""
    base = spec.split("@", 1)[0]
    if _has_glob(base):
        if "@" in spec:
            raise BuildError(
                f"glob spec {spec!r} cannot include @variant — variants "
                f"are expanded automatically for matched targets"
            )
        names = sorted(
            n for n in project.targets if fnmatch.fnmatchcase(n, base)
        )
        if not names:
            raise BuildError(f"glob {spec!r} matched no targets")
        attrs: list[str] = []
        for name in names:
            target = project.targets[name]
            if target.kind in ("script", "test", "testbed", "check"):
                continue
            attr_base = _nix_id(name) if "." in name else name
            if not target.variants:
                attrs.append(attr_base)
            else:
                for v in target.variant_names():
                    attrs.append(f"{attr_base}-{v}")
        if not attrs:
            raise BuildError(
                f"glob {spec!r} matched only non-buildable targets "
                f"(script/test)"
            )
        return attrs
    name = base
    tgt_kind = (
        project.targets[name].kind if name in project.targets else None
    )
    if tgt_kind == "test":
        raise BuildError(
            f"target {name!r} is a test target; use `rigx test {name}` instead"
        )
    if tgt_kind in ("script", "testbed"):
        raise BuildError(
            f"target {name!r} is a {tgt_kind} target (produces no artifact); "
            f"use `rigx run {name}` instead"
        )
    return [_resolve_attr(project, spec)]


def build(
    project: Project, specs: list[str], jobs: int | None = None,
) -> list[tuple[str, Path]]:
    """Build the given target specs (empty list = all). Returns (attr, out_link).

    Specs accept three shapes:
      - `hello`            — own / B-merged target by exact name.
      - `hello@release`    — pick a specific variant.
      - `hello*` / `*`     — fnmatch glob over target names. Variants are
                             ignored when matching; matched targets expand
                             all variants automatically.

    `script` and `test` targets are NOT buildable — naming one literally
    errors with a pointer at `rigx run` / `rigx test`; globs skip them
    silently.
    """
    if specs:
        attrs: list[str] = []
        for spec in specs:
            attrs.extend(_expand_build_spec(project, spec))
    else:
        attrs = _all_attrs(project)

    if not attrs:
        return []

    write_flake(project)
    output_dir = _output_dir(project)
    output_dir.mkdir(exist_ok=True)

    nix = _nix_bin()

    def build_one(attr: str) -> tuple[str, Path | None, int]:
        out_link = output_dir / attr
        cmd = [
            nix, *NIX_EXPERIMENTAL, "build",
            _flake_ref(project, attr),
            "--out-link", str(out_link),
        ]
        # Each rigx-side worker invokes its own `nix build`; the Nix daemon
        # serializes the underlying derivation builds across all clients so
        # we never duplicate work. Per-attr isolation means one failure
        # never cancels the others (the previous single-`nix build` rewrite
        # had that all-or-nothing behavior, which surprised users).
        result = subprocess.run(cmd, check=False)
        return attr, (out_link if result.returncode == 0 else None), result.returncode

    workers = jobs if (jobs and jobs > 1) else 1
    if workers == 1 or len(attrs) == 1:
        results: list[tuple[str, Path]] = []
        failures: list[tuple[str, int]] = []
        for attr in attrs:
            print(f"[rigx] building {attr}")
            a, link, rc = build_one(attr)
            if link is not None:
                results.append((a, link))
            else:
                failures.append((a, rc))
    else:
        import concurrent.futures
        print(
            f"[rigx] building {len(attrs)} target(s) with -j {workers}: "
            f"{', '.join(attrs)}"
        )
        results = []
        failures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
            for fut in concurrent.futures.as_completed(
                {ex.submit(build_one, a): a for a in attrs}
            ):
                a, link, rc = fut.result()
                if link is not None:
                    print(f"  {a} -> {link}")
                    results.append((a, link))
                else:
                    print(f"  {a}: FAILED (exit {rc})")
                    failures.append((a, rc))

    if failures:
        names = ", ".join(f"{a} (exit {rc})" for a, rc in failures)
        msg = (
            f"{len(failures)}/{len(attrs)} target(s) failed: {names}; "
            f"{len(results)} succeeded"
        )
        # If any failed target is a cross-arch qemu capsule, the platform-
        # mismatch errors from `nix build` are almost certainly because
        # the host doesn't have binfmt + extra-platforms set up. Append a
        # distro-agnostic note pointing the user at what to fix.
        cross_arch = _cross_arch_qemu_capsules(project, [a for a, _ in failures])
        if cross_arch:
            msg += _cross_arch_hint(cross_arch)
        raise BuildError(msg)

    return results


def clean(project: Project) -> None:
    output_dir = _output_dir(project)
    if output_dir.exists():
        # Remove symlinks and their contents (but not the Nix store paths themselves).
        for child in output_dir.iterdir():
            if child.is_symlink():
                child.unlink()
            elif child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
        output_dir.rmdir()
