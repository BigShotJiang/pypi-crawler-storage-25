from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

from mdo_agent_deck import AgentDeck

# Edit this dict directly to switch between Docker, Native, and HPC deployments.
# For the Docker mode, DO NOT change the default work_dir
# For the Native and HPC modes, change work_dir to the absolute path of the working directory.
AGENT_DECK_CONFIG = {
    "run_mode": "Docker",
    "work_dir": "/home/dafoamuser/mount",
    "load_modules": "",
}

if os.environ.get("AGENT_DECK_WORK_DIR"):
    # CI runs from a writable repo copy, so allow the workflow to override the default Docker mount path.
    AGENT_DECK_CONFIG["work_dir"] = os.environ["AGENT_DECK_WORK_DIR"]

if AGENT_DECK_CONFIG["run_mode"] in {"Native", "HPC"} and not os.environ.get("DAFOAM_ROOT_PATH"):
    raise RuntimeError(
        "DAFOAM_ROOT_PATH is not set. Source loadDAFoam.sh before starting the agent in Native or HPC mode."
    )

if os.environ.get("DAFOAM_ROOT_PATH"):
    os.environ["AGENT_DECK_DAFOAM_ROOT_PATH"] = os.environ["DAFOAM_ROOT_PATH"]

if AGENT_DECK_CONFIG["run_mode"] in {"Native", "HPC"}:
    os.environ["AGENT_DECK_LOAD_MODULES"] = AGENT_DECK_CONFIG.get("load_modules", "")

# Export the selected run mode so all skills see the same runtime mode.
os.environ["AGENT_DECK_RUN_MODE"] = AGENT_DECK_CONFIG["run_mode"]
WORK_DIR = AGENT_DECK_CONFIG["work_dir"]

mcp = FastMCP("mdo_agent_deck")
agent_deck = AgentDeck(WORK_DIR)


@mcp.tool()
async def must_call_first() -> dict:
    """
    ALWAYS CALL THIS FIRST before any other tools.

    Trigger: Call tool_search() at the start of ANY user request
    that could involve simulation, meshing, optimization for engineering analysis
    or design. Then, immediately call must_call_first() before get_skills()
    or any other tools.

    Skipping must_call_first() will cause incorrect behavior. It returns the
    working directory and the exact workflow steps you MUST follow for
    all subsequent tool calls.

    You MUST call this at the start of every new conversation where
    tools are used, even if you called it in a prior session.

    You MUST keep the returned information in context and follow the exact workflow. No need to load it again for later requests.

    """
    return {
        "work_dir": WORK_DIR,
        "run_mode": AGENT_DECK_CONFIG["run_mode"],
        "workflow": [
            "1. Call get_skills() to learn what agent+skill pairs are available.",
            "2. Choose the best agent+skill for the user's request.",
            "3. Call get_skill_input_info(agent, skill) to learn what inputs are needed and whether the skill depends on a prereq_skill.",
            "4. For every skill, choose a concise filesystem-safe case_name in the format `<short_skill_tag>_<case_specific_info>`, where `<short_skill_tag>` is a one-word tag chosen by the LLM from the selected skill name, such as `mesh`, `cfd`, `bemt`, or `opt`. Then call set_skill_inputs(agent, skill, inputs, case_name). AgentDeck prefixes the agent name, appends a four-digit run-id suffix such as `_0000` or `_0001`, resolves the case directory under work_dir, and stages or copies the case as needed.",
            "5. Call prepare(agent, skill).",
            "6. Read review_prepare. If review_prepare.status is pass or warning, continue to run. If it is fail, stop and ask the user how to resolve the issue.",
            "7. Call run(agent, skill). In Docker or Native mode this may start a detached local run. In HPC mode this may submit one scheduler job for the run phase.",
            "8. Read review_run. Only the run phase may be detached. If review_run.status is running, tell the user the job is running in the background and call review_run(agent, skill) later to poll its status. If review_run.status is pass or warning, continue to analyze. If it is fail, stop and ask the user how to resolve the issue.",
            "9. Call analyze(agent, skill). Prepare and analyze are expected to run synchronously and return promptly.",
            "10. Read review_analyze. If review_analyze.status is pass or warning, the skill is marked complete for this suffixed case directory. Dependent skills start later runs from a fresh copy of the prerequisite case directory into their own newly named case directory. If it is fail, stop and ask the user how to resolve the issue. When review_analyze contains plots, show the exact relative paths from review_analyze.plots to the user.",
            "11. For multiple cases, repeat set_skill_inputs -> prepare -> run -> analyze one case at a time.",
        ],
    }


@mcp.tool()
async def get_skills() -> list[dict]:
    """
    List all registered skills across all agents.

    Meaning of `prereq_skill`:
    - `null` means the skill is standalone and starts a new case directory.
    - a skill name means this skill depends on that prerequisite skill and will create a fresh case directory by copying that earlier run first.

    Return format:
    [
        {
            "agent": "<agent_name>",
            "skill": "<skill_name>",
            "description": "<short skill description>",
            "prereq_skill": "<skill_name_or_none>"
        },
        ...
    ]
    """
    return agent_deck.get_skills()


@mcp.tool()
async def get_skill_input_info(agent: str, skill: str) -> dict:
    """
    Return the detailed input information for the selected agent+skill.

    Return format:
    {
        "agent": "<agent_name>",
        "skill": "<skill_name>",
        "prereq_skill": "<skill_name_or_none>",
        "input_info": {...}
    }
    """
    return agent_deck.get_skill_input_info(agent, skill)


@mcp.tool()
async def set_skill_inputs(agent: str, skill: str, inputs: dict, case_name: str | None = None) -> dict:
    """
    Store the inputs for the selected agent+skill and resolve its case directory.

    Inputs:
    - `agent`: selected agent name.
    - `skill`: selected skill name.
    - `inputs`: full input dictionary for the skill.
    - `case_name`: concise filesystem-safe case name chosen by the LLM for every skill. Use the format `<short_skill_tag>_<case_specific_info>`, where `<short_skill_tag>` is a one-word tag chosen from the selected skill name. AgentDeck prefixes the agent name and appends a four-digit run-id suffix such as `_0000` to create a fresh case directory. If the skill has a `prereq_skill`, AgentDeck first copies the prerequisite case into that new case directory.

    Return format:
    {
        "agent": "<agent_name>",
        "skill": "<skill_name>",
        "case_name": "<final_case_folder_name>",
        "prereq_skill": "<skill_name_or_none>",
        "inputs": {...}
    }
    """
    return agent_deck.set_skill_inputs(agent, skill, inputs, case_name=case_name)


@mcp.tool()
async def prepare(agent: str, skill: str) -> dict:
    """
    Run the selected skill prepare phase for the resolved case directory and return only review_prepare.
    """
    return agent_deck.prepare(agent, skill)


@mcp.tool()
async def run(agent: str, skill: str) -> dict:
    """
    Run the selected skill run phase for the resolved case directory and return only review_run.
    """
    return agent_deck.run(agent, skill)


@mcp.tool()
async def review_run(agent: str, skill: str) -> dict:
    """
    Review the selected skill run phase for the resolved case directory without launching it again.
    """
    return agent_deck.review_run(agent, skill)


@mcp.tool()
async def analyze(agent: str, skill: str) -> dict:
    """
    Run the selected skill analyze phase for the resolved case directory and return only review_analyze.
    """
    return agent_deck.analyze(agent, skill)


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
