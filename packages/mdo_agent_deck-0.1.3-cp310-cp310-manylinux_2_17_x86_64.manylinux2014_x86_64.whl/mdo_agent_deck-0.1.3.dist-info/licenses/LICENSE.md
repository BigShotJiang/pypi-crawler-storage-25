Copyright (c) 2026 Iowa State University

Developed by the iDesign Lab, Aerospace Engineering Department, Iowa State University

Contact: Ping He, phe@iastate.edu

All rights reserved.

This software is provided as a beta version for evaluation and feedback.

Permission is hereby granted to any person or entity ("users") to use this software for academic,
research, and commercial purposes, subject to the following conditions:

1. This software is provided as a beta evaluation version to demonstrate current
   capabilities and support assessment of potential future extensions.

2. Users may not redistribute this software, in whole or in part, without prior written 
   permission from Iowa State University.

3. Users may not reverse engineer or create derivative works of the software. However,
   use of the software as part of an internal or commercial workflow, pipeline, or
   process is permitted.

4. Commercial use of this software is permitted, including use in commercial products,
   services, and other for-profit activities.

5. This software is provided "as is", without warranty of any kind, express or implied, 
   including but not limited to the warranties of merchantability, fitness for a 
   particular purpose, and noninfringement.

6. In no event shall Iowa State University or the developers be liable for any claim, damages, or
   other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in 
   connection with the software or the use or other dealings in the software.

7. Iowa State University reserves the right to change the licensing terms in future versions.
