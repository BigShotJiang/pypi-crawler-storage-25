from setuptools import setup, find_packages

setup(
    name="psi-cloud", 
    version="1.1.0",
    author="Ian Amaro", 
    author_email="amaroian2010@gmail.com",
    description="SDK Oficial para el Motor PSI (Proposición de Suficiencia Informativa).",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://psi-cloud-v1.onrender.com",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1", 
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)