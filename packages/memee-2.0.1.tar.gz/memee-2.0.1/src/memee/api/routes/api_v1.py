"""REST API v1 — JSON endpoints for dashboard and integrations."""

from __future__ import annotations

from collections import defaultdict

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session, sessionmaker

from memee.storage.database import get_engine, init_db
from memee.storage.models import (
    AntiPattern,
    Memory,
    MemoryConnection,
    MemoryValidation,
    Project,
    ProjectMemory,
)

router = APIRouter(tags=["api"])


# Engine + sessionmaker are expensive to rebuild (init_db runs DDL + alembic
# stamp on every call). Cache them lazily at module level so every request
# reuses one engine and pulls a new Session from a single factory. The old
# ``get_db()`` ran ``init_db()`` per request — 2.4ms × N requests in hot paths.
_ENGINE = None
_SESSION_FACTORY: sessionmaker | None = None


def _get_factory() -> sessionmaker:
    global _ENGINE, _SESSION_FACTORY
    if _SESSION_FACTORY is None:
        _ENGINE = init_db(get_engine())
        _SESSION_FACTORY = sessionmaker(bind=_ENGINE, autoflush=False)
    return _SESSION_FACTORY


def get_db():
    """FastAPI dependency — yields a Session and guarantees close().

    Must be a generator: FastAPI only runs teardown for generator deps.
    The previous plain-return version leaked a connection per request
    and would eventually exhaust the SQLite pool.
    """
    factory = _get_factory()
    session = factory()
    try:
        yield session
    finally:
        session.close()


@router.get("/stats")
def get_stats(session: Session = Depends(get_db)):
    """Overall org stats."""
    total = session.query(func.count(Memory.id)).scalar() or 0
    if total == 0:
        return {"empty": True}

    maturity = dict(
        session.query(Memory.maturity, func.count(Memory.id))
        .group_by(Memory.maturity).all()
    )
    types = dict(
        session.query(Memory.type, func.count(Memory.id))
        .group_by(Memory.type).all()
    )
    avg_conf = session.query(func.avg(Memory.confidence_score)).scalar() or 0
    projects = session.query(func.count(Project.id)).scalar() or 0
    connections = session.query(func.count(MemoryConnection.source_id)).scalar() or 0

    canon_r = maturity.get("canon", 0) / total
    valid_r = maturity.get("validated", 0) / total
    org_iq = canon_r * 30 + valid_r * 25 + avg_conf * 20 + 0.5 * 15 + 0.97 * 10

    return {
        "total_memories": total,
        "projects": projects,
        "connections": connections,
        "avg_confidence": round(avg_conf, 3),
        "maturity": maturity,
        "types": types,
        "org_iq": round(org_iq, 1),
    }


@router.get("/memories")
def list_memories(
    type: str = "",
    maturity: str = "",
    limit: int = 50,
    session: Session = Depends(get_db),
):
    """List memories with optional filters."""
    q = session.query(Memory).order_by(Memory.confidence_score.desc())
    if type:
        q = q.filter(Memory.type == type)
    if maturity:
        q = q.filter(Memory.maturity == maturity)

    memories = q.limit(limit).all()
    return [
        {
            "id": m.id[:8],
            "type": m.type,
            "maturity": m.maturity,
            "title": m.title,
            "confidence": round(m.confidence_score, 3),
            "validations": m.validation_count,
            "projects": m.project_count,
            "tags": m.tags or [],
            "agent": m.source_agent,
        }
        for m in memories
    ]


@router.get("/anti-patterns")
def list_anti_patterns(session: Session = Depends(get_db)):
    """List all anti-patterns with details."""
    results = (
        session.query(Memory, AntiPattern)
        .join(AntiPattern, AntiPattern.memory_id == Memory.id)
        .order_by(Memory.confidence_score.desc())
        .all()
    )
    return [
        {
            "id": m.id[:8],
            "title": m.title,
            "severity": ap.severity,
            "trigger": ap.trigger,
            "consequence": ap.consequence,
            "alternative": ap.alternative,
            "confidence": round(m.confidence_score, 3),
            "occurrences": ap.occurrences,
            "tags": m.tags or [],
        }
        for m, ap in results
    ]


@router.get("/timeline")
def get_timeline(session: Session = Depends(get_db)):
    """Validation timeline — all validation events over time."""
    validations = (
        session.query(MemoryValidation)
        .order_by(MemoryValidation.created_at)
        .all()
    )
    return [
        {
            "memory_id": v.memory_id[:8],
            "project_id": v.project_id[:8] if v.project_id else None,
            "validated": v.validated,
            "evidence": v.evidence,
            "created_at": v.created_at.isoformat() if v.created_at else None,
        }
        for v in validations
    ]


@router.get("/projects")
def list_projects(session: Session = Depends(get_db)):
    """List projects with memory counts.

    One LEFT OUTER JOIN + GROUP BY replaces the 1 + N pattern that scaled
    linearly with project count (50 projects → 51 queries previously).
    """
    rows = (
        session.query(
            Project.id,
            Project.name,
            Project.stack,
            Project.tags,
            func.count(ProjectMemory.memory_id).label("memories"),
        )
        .outerjoin(ProjectMemory, ProjectMemory.project_id == Project.id)
        .group_by(Project.id)
        .all()
    )
    result = [
        {
            "id": r.id[:8],
            "name": r.name,
            "stack": r.stack or [],
            "tags": r.tags or [],
            "memories": int(r.memories or 0),
        }
        for r in rows
    ]
    return sorted(result, key=lambda x: -x["memories"])


@router.get("/agents")
def list_agents(session: Session = Depends(get_db)):
    """Agent effectiveness stats.

    Two grouped queries replace 1 + 2*N: the old code ran an avg + a
    type-count query per agent (1001 queries at 500 agents). Now:
      Q1: per-agent (count, avg_confidence)
      Q2: per-(agent, type) count → pivoted in Python
    """
    base_rows = (
        session.query(
            Memory.source_agent,
            func.count(Memory.id).label("memories"),
            func.avg(Memory.confidence_score).label("avg_conf"),
        )
        .filter(Memory.source_agent.isnot(None))
        .group_by(Memory.source_agent)
        .all()
    )

    type_rows = (
        session.query(
            Memory.source_agent,
            Memory.type,
            func.count(Memory.id).label("count"),
        )
        .filter(Memory.source_agent.isnot(None))
        .group_by(Memory.source_agent, Memory.type)
        .all()
    )

    types_by_agent: dict[str, dict[str, int]] = defaultdict(dict)
    for agent_name, mtype, mcount in type_rows:
        types_by_agent[agent_name][mtype] = int(mcount or 0)

    result = []
    for agent_name, mem_count, avg_conf in base_rows:
        tcounts = types_by_agent.get(agent_name, {})
        result.append({
            "name": agent_name,
            "memories": int(mem_count or 0),
            "avg_confidence": round(float(avg_conf or 0.0), 3),
            "patterns": tcounts.get("pattern", 0),
            "anti_patterns": tcounts.get("anti_pattern", 0),
            "decisions": tcounts.get("decision", 0),
            "lessons": tcounts.get("lesson", 0),
        })

    return sorted(result, key=lambda x: -x["avg_confidence"])


@router.get("/confidence-distribution")
def confidence_distribution(session: Session = Depends(get_db)):
    """Confidence score distribution in buckets."""
    memories = session.query(Memory.confidence_score).all()
    buckets = defaultdict(int)
    for (conf,) in memories:
        bucket = round(conf * 10) / 10
        buckets[f"{bucket:.1f}"] += 1
    return dict(sorted(buckets.items()))


@router.get("/retrieval")
def get_retrieval_metrics(session: Session = Depends(get_db)):
    """Retrieval health: hit@1, hit@3, acceptance rate, p50 latency.

    Rolled up over 1 / 7 / 30 day trailing windows. Also returns a 30-day
    daily sparkline of hit@1 so the dashboard can render a small trend line
    without a separate request.

    Notes on honesty:
      * ``hit_at_1``: share of events where ``accepted_memory_id == top_memory_id``.
      * ``hit_at_3``: events where the caller recorded ``position_of_accepted < 3``.
        Acceptances without a known position do NOT count toward hit@3.
      * ``time_to_solution_p50_ms`` is a **proxy** — we use search latency for
        events that ended in an acceptance. Until Memee emits a real "solved"
        event from the agent, this understates true time-to-solution.
    """
    from memee.engine.telemetry import compute_retrieval_metrics, hit_at_1_sparkline

    windows = {
        "day_1": compute_retrieval_metrics(session, window_days=1),
        "day_7": compute_retrieval_metrics(session, window_days=7),
        "day_30": compute_retrieval_metrics(session, window_days=30),
    }
    return {
        "windows": windows,
        "hit_at_1_sparkline_30d": hit_at_1_sparkline(session, days=30),
        "notes": {
            "time_to_solution_p50_ms": (
                "Proxy: search latency for events that ended in acceptance. "
                "No separate 'solved' event is emitted yet."
            ),
            "hit_at_3": (
                "Counts acceptances with a known 0-based position < 3. "
                "Acceptances without position are excluded."
            ),
        },
    }


@router.get("/impact")
def get_impact(session: Session = Depends(get_db)):
    """Honest impact counters: warnings shown / acknowledged / avoided.

    Mirrors ``memee.engine.impact.get_impact_summary``. The ``mistakes_avoided``
    figure only counts project_memories rows with ``outcome = 'avoided'`` AND
    ``outcome_evidence_type`` set (diff, test_failure, review_comment, pr_url,
    or agent_feedback) — no evidence, no avoidance.
    """
    from memee.engine.impact import get_impact_summary

    return get_impact_summary(session)
