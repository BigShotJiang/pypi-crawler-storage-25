import botocore
import logging
import re
import traceback
import uuid
from botocore.exceptions import (
    ConnectTimeoutError,
    ReadTimeoutError,
    TokenRetrievalError,
)
from fastapi import HTTPException
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    AnyMessage,
    UsageMetadata,
)
from langchain_core.runnables import RunnableConfig
from langchain_core.runnables.schema import CustomStreamEvent, StandardStreamEvent
from langchain_core.tools import BaseTool, ToolException
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from oidcauthlib.auth.exceptions.authorization_needed_exception import (
    AuthorizationNeededException,
)
from openai.types import CompletionUsage
from starlette.responses import StreamingResponse, JSONResponse
from typing import (
    Any,
    List,
    Sequence,
    Optional,
    Dict,
    AsyncGenerator,
    Iterable,
    Tuple,
    Literal,
    cast,
)

from languagemodelcommon.converters.streaming_manager import LangGraphStreamingManager
from languagemodelcommon.exceptions.bailey_exception import BaileyException
from languagemodelcommon.mcp.tool_catalog import ToolCatalog
from languagemodelcommon.mcp.tool_discovery_middleware import ToolDiscoveryMiddleware
from languagemodelcommon.state.messages_state import MyMessagesState
from languagemodelcommon.structures.openai.message.chat_message_wrapper import (
    ChatMessageWrapper,
)
from languagemodelcommon.structures.openai.request.chat_request_wrapper import (
    ChatRequestWrapper,
)
from languagemodelcommon.utilities.environment.language_model_common_environment_variables import (
    LanguageModelCommonEnvironmentVariables,
)
from languagemodelcommon.utilities.logger.exception_logger import ExceptionLogger
from languagemodelcommon.utilities.logger.log_levels import SRC_LOG_LEVELS
from languagemodelcommon.utilities.request_information import RequestInformation
from languagemodelcommon.utilities.token_reducer.token_reducer import TokenReducer

logger = logging.getLogger(__name__)
logger.setLevel(SRC_LOG_LEVELS.LLM)


class LangGraphToOpenAIConverter:
    @staticmethod
    def _is_timeout_exception(exception: Exception) -> bool:
        if isinstance(exception, (TimeoutError, ReadTimeoutError, ConnectTimeoutError)):
            return True
        cause = exception.__cause__
        if isinstance(cause, (TimeoutError, ReadTimeoutError, ConnectTimeoutError)):
            return True
        class_name = exception.__class__.__name__
        cause_class_name = cause.__class__.__name__ if cause is not None else ""
        return (
            class_name in {"ReadTimeoutError", "ConnectTimeoutError"}
            or cause_class_name in {"ReadTimeoutError", "ConnectTimeoutError"}
            or "Timeout" in class_name
            or "Timeout" in cause_class_name
        )

    @staticmethod
    def _find_cause(
        exception: BaseException, target_type: type[BaseException]
    ) -> BaseException | None:
        """Walk the ``__cause__`` chain looking for *target_type*."""
        current: BaseException | None = exception
        while current is not None:
            if isinstance(current, target_type):
                return current
            current = current.__cause__
        return None

    def __init__(
        self,
        *,
        environment_variables: LanguageModelCommonEnvironmentVariables,
        token_reducer: TokenReducer,
        streaming_manager: LangGraphStreamingManager,
    ) -> None:
        if environment_variables is None:
            raise ValueError("environment_variables must not be None")
        if not isinstance(
            environment_variables, LanguageModelCommonEnvironmentVariables
        ):
            raise TypeError(
                f"environment_variables must be EnvironmentVariables, got {type(environment_variables)}"
            )
        self.environment_variables: LanguageModelCommonEnvironmentVariables = (
            environment_variables
        )

        if token_reducer is None:
            raise ValueError("token_reducer must not be None")
        if not isinstance(token_reducer, TokenReducer):
            raise TypeError(
                f"token_reducer must be TokenReducer, got {type(token_reducer)}"
            )
        self.token_reducer = token_reducer

        self.streaming_manager = streaming_manager
        if self.streaming_manager is None:
            raise ValueError("streaming_manager must not be None")
        if not isinstance(self.streaming_manager, LangGraphStreamingManager):
            raise TypeError(
                f"streaming_manager must be LangGraphStreamingManager, got {type(self.streaming_manager)}"
            )

    async def _stream_resp_async_generator(
        self,
        *,
        chat_request_wrapper: ChatRequestWrapper,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        messages: List[ChatMessageWrapper],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> AsyncGenerator[str, None]:
        """
        Asynchronously generate streaming responses from the agent.

        Args:
            chat_request_wrapper: The chat request.
            compiled_state_graph: The compiled state graph.
            messages: The list of chat completion message parameters.
            request_information: The request information.

        Yields:
            The streaming response as a string.
        """
        request_id = request_information.request_id

        # Track tool start times for concurrent tool runs
        tool_start_times: Dict[str, float] = {}

        try:
            # Process streamed events from the graph and yield messages over the SSE stream.
            event: StandardStreamEvent | CustomStreamEvent
            async for event in self.astream_events(
                compiled_state_graph=compiled_state_graph,
                messages=messages,
                request_information=request_information,
                config=config,
                state=state,
            ):
                if not event:
                    continue

                async for chunk in self.streaming_manager.handle_langchain_event(
                    event=event,
                    chat_request_wrapper=chat_request_wrapper,
                    request_information=request_information,
                    tool_start_times=tool_start_times,
                    user_id=request_information.user_id,
                ):
                    yield chunk
        except TokenRetrievalError as e:
            message: str = f"Token retrieval error: {e}.  If you are running locally, your AWS session may have expired.  Please re-authenticate using `aws sso login --profile [role]`."
            logger.exception(message)
            yield chat_request_wrapper.create_sse_message(
                request_id=request_id,
                usage_metadata=None,
                content=message,
                source="error",
            )
        except AuthorizationNeededException as e:
            # Show the login prompt to the user and stop processing.  The
            # on_tool_error handler may have already streamed this, but it is
            # not guaranteed (the event can be lost when the exception
            # terminates the async generator), so we yield it here as well.
            logger.info(
                "AuthorizationNeededException caught in stream — sending login prompt: %s",
                e.message,
            )
            yield chat_request_wrapper.create_sse_message(
                request_id=request_id,
                content=str(e.message),
                usage_metadata=None,
                source="on_tool_error",
            )
            # The on_chat_model_end event never fires because the exception
            # terminates the event stream early.  Write the messages log here
            # so that the debug download link is still available.
            if chat_request_wrapper.enable_debug_logging:
                streamed_output = self.streaming_manager._pop_streamed_text(
                    request_id=str(request_id),
                )
                content_text = ""
                if streamed_output:
                    content_text += "--- Streamed assistant output ---\n"
                    content_text += f"{streamed_output}\n"
                content_text += f"--- AuthorizationNeededException ---\n{e.message}\n"
                write_result = (
                    await self.streaming_manager.debug_file_writer.write_to_file_async(
                        file_name="messages",
                        content=content_text,
                        user_id=request_information.user_id,
                    )
                )
                if write_result and write_result.file_url:
                    debug_msg = chat_request_wrapper.create_debug_sse_message(
                        request_id=request_id,
                        content=f"\n\n[Click to download full messages log]({write_result.file_url})\n\n",
                        usage_metadata=None,
                        source="on_chat_model_end",
                    )
                    if debug_msg is not None:
                        yield debug_msg
                elif content_text:
                    debug_msg = chat_request_wrapper.create_debug_sse_message(
                        request_id=request_id,
                        content=(
                            f"\n\n<details>\n<summary>Messages log</summary>\n\n"
                            f"```\n{content_text}\n```\n\n"
                            f"</details>\n\n"
                        ),
                        usage_metadata=None,
                        source="on_chat_model_end",
                    )
                    if debug_msg is not None:
                        yield debug_msg
        except Exception as e:
            tb = traceback.format_exc()
            logger.exception("Exception in _stream_resp_async_generator: %s\n%s", e, tb)

            # Check if a TokenRetrievalError is wrapped inside another exception
            token_retrieval_error = self._find_cause(e, TokenRetrievalError)
            if token_retrieval_error is not None:
                message = (
                    f"Token retrieval error: {token_retrieval_error}."
                    "  If you are running locally, your AWS session may have expired."
                    "  Please re-authenticate using `aws sso login --profile [role]`."
                )
                yield chat_request_wrapper.create_sse_message(
                    request_id=request_id,
                    usage_metadata=None,
                    content=message,
                    source="error",
                )
                yield chat_request_wrapper.create_final_sse_message(
                    request_id=request_id, usage_metadata=None, source="final"
                )
                return

            # if the request is not enabled for debug logging, return a generic error message instead of the actual error
            error_message: str
            if request_information.enable_debug_logging:
                error_message = f"Error: {e}\n{tb}"
            else:
                error_message = ExceptionLogger.get_user_friendly_message(
                    e,
                    enable_debug_logging=chat_request_wrapper.enable_debug_logging,
                    generic_message=self.environment_variables.generic_error_message,
                )

            yield chat_request_wrapper.create_sse_message(
                request_id=request_id,
                usage_metadata=None,
                content=f"\n{error_message}\n",
                source="error",
            )

        yield chat_request_wrapper.create_final_sse_message(
            request_id=request_id, usage_metadata=None, source="final"
        )

    async def call_agent_with_input(
        self,
        *,
        chat_request_wrapper: ChatRequestWrapper,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        system_messages: List[ChatMessageWrapper],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> StreamingResponse | JSONResponse:
        """
        Call the agent with the provided input and return the response.

        Args:
            chat_request_wrapper: The chat request.
            compiled_state_graph: The compiled state graph.
            system_messages: The list of chat completion message parameters.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will be created using the messages and request information.

        Returns:
            The response as a StreamingResponse or JSONResponse.
        """
        if chat_request_wrapper is None:
            raise ValueError("chat_request must not be None")

        if chat_request_wrapper.stream:
            return StreamingResponse(
                content=await self.get_streaming_response_async(
                    chat_request_wrapper=chat_request_wrapper,
                    compiled_state_graph=compiled_state_graph,
                    system_messages=system_messages,
                    request_information=request_information,
                    config=config,
                    state=state,
                ),
                media_type="text/event-stream",
            )
        else:
            try:
                json_output_requested: bool
                chat_request_wrapper, json_output_requested = (
                    self.add_system_messages_for_json(
                        chat_request_wrapper=chat_request_wrapper
                    )
                )

                chat_request_wrapper = self.add_system_message_for_user_info(
                    chat_request_wrapper=chat_request_wrapper,
                    user_id=request_information.user_id,
                    user_name=request_information.user_name,
                    email=request_information.user_email,
                )

                responses: List[AnyMessage] = await self.ainvoke(
                    compiled_state_graph=compiled_state_graph,
                    chat_request_wrapper=chat_request_wrapper,
                    system_messages=system_messages,
                    request_information=request_information,
                    config=config,
                    state=state,
                )

                content_json: Dict[str, Any] = (
                    chat_request_wrapper.create_non_streaming_response(
                        request_id=request_information.request_id,
                        responses=responses,
                        json_output_requested=json_output_requested,
                    )
                )
                if self.environment_variables.log_input_and_output and content_json:
                    logger.info("Returning content: %s", content_json)

                return JSONResponse(content=content_json)
            except* TokenRetrievalError as e:
                error_message = (
                    f"AWS Bedrock Token retrieval error: {ExceptionLogger.format_exception_message(e)}."
                    "  If you are running locally, your AWS session may have expired."
                    "  Please re-authenticate using `aws sso login --profile [role]`."
                )
                logger.exception(error_message)
                raise HTTPException(
                    status_code=401,
                    detail=error_message,
                )
            except* botocore.exceptions.NoCredentialsError as e:
                error_message = (
                    f"AWS Bedrock Login error: {ExceptionLogger.format_exception_message(e)}."
                    "  If you are running locally, your AWS session may have expired."
                    "  Please re-authenticate using `aws sso login --profile [role]`."
                )
                logger.exception(error_message)
                raise HTTPException(
                    status_code=401,
                    detail=error_message,
                )
            except* Exception as e:
                first_exception = ExceptionLogger.get_first_exception(e)
                logger.exception(
                    "ExceptionGroup in call_agent_with_input: %s",
                    ExceptionLogger.format_exception_message(e),
                )
                # Get the traceback for the first exception
                stack = "".join(
                    traceback.format_exception(
                        type(first_exception),
                        first_exception,
                        first_exception.__traceback__,
                    )
                )
                log_message = f"Unexpected error: {ExceptionLogger.format_exception_message(e)}\nStack trace:\n{stack}"
                logger.exception(log_message)
                raise HTTPException(
                    status_code=500,
                    detail=f"Unexpected error: {first_exception}",
                )

    @staticmethod
    def add_system_message_for_user_info(
        *,
        chat_request_wrapper: ChatRequestWrapper,
        user_id: Optional[str],
        user_name: Optional[str],
        email: Optional[str],
    ) -> ChatRequestWrapper:
        content: str = (
            f"You are interacting with user_id: {user_id} who is named {user_name} and has email {email}"
            if user_id
            else "You are interacting with an anonymous user"
        )

        new_system_message: ChatMessageWrapper = (
            chat_request_wrapper.create_system_message(content=content)
        )
        chat_request_wrapper.append_message(message=new_system_message)

        return chat_request_wrapper

    @staticmethod
    def add_system_messages_for_json(
        *, chat_request_wrapper: ChatRequestWrapper
    ) -> Tuple[ChatRequestWrapper, bool]:
        """
        If the user is requesting json_object or json_schema output, add system messages to the chat request
        to generate JSON output.


        :param chat_request_wrapper:
        :return:
        """
        json_response_requested: bool = False
        response_format: Literal["text", "json_object", "json_schema"] | None = (
            chat_request_wrapper.response_format
        )
        if not response_format:
            return chat_request_wrapper, json_response_requested

        match response_format:
            case "text":
                return chat_request_wrapper, json_response_requested
            case "json_object":
                json_response_requested = True
                json_object_system_message_text: str = """
                Respond only with a JSON object or array.

                Output follows this example format:
                <json>
                json  here
                </json>"""
                json_object_system_message: ChatMessageWrapper = (
                    chat_request_wrapper.create_system_message(
                        content=json_object_system_message_text
                    )
                )
                chat_request_wrapper.append_message(message=json_object_system_message)
                return chat_request_wrapper, json_response_requested
            case "json_schema":
                json_response_requested = True
                json_schema: str | None = chat_request_wrapper.response_json_schema
                if json_schema is None:
                    raise ValueError(
                        "json_schema should be specified in response_format if type is json_schema"
                    )
                json_schema_system_message_text: str = f"""
                Respond only with a JSON object or array using the provided schema:
                ```{json_schema}```

                Output follows this example format:
                <json>
                json  here
                </json>"""
                json_schema_system_message: ChatMessageWrapper = (
                    chat_request_wrapper.create_system_message(
                        content=json_schema_system_message_text
                    )
                )
                chat_request_wrapper.append_message(message=json_schema_system_message)
                return chat_request_wrapper, json_response_requested
            case _:
                raise ValueError(f"Unexpected response format type: {response_format}")

    async def get_streaming_response_async(
        self,
        *,
        chat_request_wrapper: ChatRequestWrapper,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        system_messages: List[ChatMessageWrapper],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> AsyncGenerator[str, None]:
        """
        Get the streaming response asynchronously.

        Args:
            chat_request_wrapper: The chat request.
            compiled_state_graph: The compiled state graph.
            system_messages: The list of chat completion message parameters.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will be created using the messages and request information.

        Returns:
            The streaming response as an async generator.
        """

        new_messages: List[ChatMessageWrapper] = [
            m for m in chat_request_wrapper.messages
        ]
        messages: List[ChatMessageWrapper] = [s for s in system_messages] + new_messages

        logger.debug("Streaming response %s from agent", request_information.request_id)
        generator: AsyncGenerator[str, None] = self._stream_resp_async_generator(
            chat_request_wrapper=chat_request_wrapper,
            compiled_state_graph=compiled_state_graph,
            messages=messages,
            request_information=request_information,
            config=config,
            state=state,
        )
        return generator

    # noinspection PyMethodMayBeStatic
    async def _run_graph_with_messages_async(
        self,
        *,
        messages: List[AnyMessage],
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> List[AnyMessage]:
        """
        Run the graph with the provided messages asynchronously.

        Args:
            messages: The list of role and incoming message type tuples.
            compiled_state_graph: The compiled state graph.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will be created using the messages and request information.

        Returns:
            The list of any messages.
        """

        input_: MyMessagesState = state or self.create_state(
            messages=messages,
            request_information=request_information,
        )
        config = self._build_runnable_config(
            request_information=request_information,
            config=config,
        )
        runtime_context = {"user_id": request_information.user_id}
        try:
            output: Dict[str, Any] = await compiled_state_graph.ainvoke(
                input=input_,
                config=config,
                context=runtime_context,  # type: ignore[call-overload]
            )
        except AttributeError:
            # Fallback if errorfactory is not available
            logger.exception("AttributeError in throttling handling")
            raise
        except Exception as e:
            # Try to catch ThrottlingException dynamically
            if (
                hasattr(e, "__class__")
                and e.__class__.__name__ == "ThrottlingException"
            ):
                logger.exception("AWS ThrottlingException: %s", e)
                raise HTTPException(
                    status_code=429,
                    detail="AWS request throttled. Please try again later.",
                )
            raise
        out_messages: List[AnyMessage] = output["messages"]
        return out_messages

    # noinspection PyMethodMayBeStatic
    async def _stream_graph_with_messages_async(
        self,
        *,
        messages: List[AnyMessage],
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> AsyncGenerator[StandardStreamEvent | CustomStreamEvent, None]:
        """
        Stream the graph with the provided messages asynchronously.

        Args:
            messages: The list of role and incoming message type tuples.
            compiled_state_graph: The compiled state graph.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will

        Yields:
            The standard or custom stream event.
        """

        config = self._build_runnable_config(
            request_information=request_information,
            config=config,
        )
        runtime_context = {"user_id": request_information.user_id}
        try:
            event: StandardStreamEvent | CustomStreamEvent
            async for event in compiled_state_graph.astream_events(
                input=state
                or self.create_state(
                    messages=messages,
                    request_information=request_information,
                ),
                version="v2",
                config=config,
                context=runtime_context,
            ):
                yield event
        except ToolException as e:
            logger.exception(
                "ToolException occurred while streaming graph. request_id=%s message_count=%d error=%s",
                request_information.request_id,
                len(messages),
                e,
            )
            raise BaileyException(
                f"Tool Error streaming graph with messages: {e}"
            ) from e
        except AuthorizationNeededException:
            raise
        except TokenRetrievalError:
            raise
        except Exception as e:
            if e.__class__.__name__ == "GraphRecursionError":
                logger.warning(
                    "Graph recursion limit reached while streaming. request_id=%s message_count=%d recursion_limit=%s error=%s",
                    request_information.request_id,
                    len(messages),
                    config.get("recursion_limit"),
                    e,
                )
                raise BaileyException(
                    "The graph reached its recursion limit before completing. "
                    "Please try again with a more focused request."
                ) from e
            if self._is_timeout_exception(e):
                logger.warning(
                    "Timeout while streaming graph. request_id=%s message_count=%d error=%s",
                    request_information.request_id,
                    len(messages),
                    e,
                )
                raise BaileyException(
                    "Upstream model timed out while streaming. Please try again."
                ) from e
            if "toolUse.name" in str(e) or "tool_use" in str(e).lower():
                tool_names_in_messages = []
                for msg in messages:
                    if hasattr(msg, "tool_calls"):
                        for tc in msg.tool_calls or []:
                            tool_names_in_messages.append(
                                tc.get("name", "unknown")
                                if isinstance(tc, dict)
                                else getattr(tc, "name", "unknown")
                            )
                    if hasattr(msg, "name") and msg.name:
                        tool_names_in_messages.append(f"msg.name={msg.name}")
                    if hasattr(msg, "content") and isinstance(msg.content, list):
                        for block in msg.content:
                            if (
                                isinstance(block, dict)
                                and block.get("type") == "tool_use"
                            ):
                                tool_names_in_messages.append(
                                    f"content.tool_use.name={block.get('name')}"
                                )
                logger.error(
                    "Tool name validation failed. Tool names in messages: %s",
                    tool_names_in_messages,
                )
            logger.exception(
                "Exception occurred while streaming graph. request_id=%s message_count=%d error=%s",
                request_information.request_id,
                len(messages),
                e,
            )
            raise BaileyException(f"Error streaming graph with messages: {e}") from e

    def _build_runnable_config(
        self,
        *,
        request_information: RequestInformation,
        config: RunnableConfig | None,
    ) -> RunnableConfig:
        """Build a runnable config with stable defaults and caller overrides."""
        default_recursion_limit = self.environment_variables.langgraph_recursion_limit
        base_configurable: Dict[str, Any] = {
            "thread_id": request_information.conversation_thread_id,
            "user_id": request_information.user_id,
        }
        if config is None:
            return {
                "configurable": base_configurable,
                "recursion_limit": default_recursion_limit,
            }

        merged_config: Dict[str, Any] = dict(config)
        configurable = merged_config.get("configurable")
        merged_configurable: Dict[str, Any] = (
            dict(configurable) if isinstance(configurable, dict) else {}
        )
        if "thread_id" not in merged_configurable:
            merged_configurable["thread_id"] = (
                request_information.conversation_thread_id
            )
        if "user_id" not in merged_configurable:
            merged_configurable["user_id"] = request_information.user_id
        merged_config["configurable"] = merged_configurable

        if "recursion_limit" not in merged_config:
            merged_config["recursion_limit"] = default_recursion_limit

        return cast(RunnableConfig, merged_config)

    # noinspection SpellCheckingInspection
    async def ainvoke(
        self,
        *,
        chat_request_wrapper: ChatRequestWrapper,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        system_messages: Iterable[ChatMessageWrapper],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> List[AnyMessage]:
        """
        Run the agent asynchronously.

        Args:
            chat_request_wrapper: The chat request.
            compiled_state_graph: The compiled state graph.
            system_messages: The iterable of chat completion message parameters.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will be created using the messages and request information.

        Returns:
            The list of any messages.
        """
        if chat_request_wrapper is None:
            raise ValueError("request must not be None")

        new_messages: List[ChatMessageWrapper] = [
            m for m in chat_request_wrapper.messages
        ]
        messages: List[ChatMessageWrapper] = [s for s in system_messages] + new_messages

        return await self._run_graph_with_messages_async(
            compiled_state_graph=compiled_state_graph,
            messages=self.create_messages_for_graph(messages=messages),
            request_information=request_information,
            config=config,
            state=state,
        )

    async def astream_events(
        self,
        *,
        request_information: RequestInformation,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        messages: Iterable[ChatMessageWrapper],
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> AsyncGenerator[StandardStreamEvent | CustomStreamEvent, None]:
        """
        Stream events asynchronously.

        Args:
            compiled_state_graph: The compiled state graph.
            messages: The iterable of chat completion message parameters.
            request_information: The request information.
            config: Optional configuration for the runnable execution.
            state: Optional state to run the graph with. If not provided, a new state will

        Yields:
            The standard or custom stream event.
        """
        event: StandardStreamEvent | CustomStreamEvent

        async for event in self._stream_graph_with_messages_async(
            compiled_state_graph=compiled_state_graph,
            messages=self.create_messages_for_graph(messages=messages),
            request_information=request_information,
            config=config,
            state=state,
        ):
            yield event

    # noinspection PyMethodMayBeStatic
    def create_messages_for_graph(
        self, *, messages: Iterable[ChatMessageWrapper]
    ) -> List[AnyMessage]:
        """
        Create messages for the graph.

        Args:
            messages: The iterable of chat completion message parameters.

        Returns:
            The list of role and incoming message type tuples.
        """

        messages_: List[AnyMessage] = [m.to_langchain_message() for m in messages]
        return messages_

    async def run_graph_async(
        self,
        *,
        chat_request_wrapper: ChatRequestWrapper,
        compiled_state_graph: CompiledStateGraph[MyMessagesState],
        request_information: RequestInformation,
        config: RunnableConfig | None,
        state: Optional[MyMessagesState],
    ) -> List[AnyMessage]:
        """
        Run the graph asynchronously.

        Args:
            chat_request_wrapper: The chat request.
            compiled_state_graph: The compiled state graph.
            request_information: The request information.
            config: RunnableConfig | None
            state: Optional state to run the graph with. If not provided, a new state will be created.

        Returns:
            The list of any messages.
        """
        messages: List[AnyMessage] = self.create_messages_for_graph(
            messages=chat_request_wrapper.messages
        )

        output_messages: List[AnyMessage] = await self._run_graph_with_messages_async(
            compiled_state_graph=compiled_state_graph,
            messages=messages,
            request_information=request_information,
            config=config,
            state=state,
        )
        return output_messages

    # noinspection PyMethodMayBeStatic
    async def create_graph_for_llm_async(
        self,
        *,
        llm: BaseChatModel,
        tools: Sequence[BaseTool],
        store: BaseStore | None,
        checkpointer: BaseCheckpointSaver[str] | None,
        system_prompts: List[str] | None = None,
        tool_catalog: ToolCatalog | None = None,
    ) -> CompiledStateGraph[MyMessagesState]:
        """
        Create a graph for the language model asynchronously.

        Optionally includes a health safety evaluation node that can evaluate
        and refine AI responses before they are returned to the user.

        Args:
            llm: The language model to use
            tools: List of tools available to the agent
            store: Optional store for persistence
            checkpointer: Optional checkpointer for state management
            system_prompts: Optional list of system prompts to prepend to the agent
            tool_catalog: Optional tool catalog for tool discovery middleware
        """
        # Build system prompt from config if provided
        system_prompt: str | None = None
        if system_prompts:
            # Strip and filter empty prompts to avoid accidental separators
            cleaned_prompts = [p.strip() for p in system_prompts if p and p.strip()]
            if cleaned_prompts:
                system_prompt = "\n\n".join(cleaned_prompts)
                logger.debug(
                    "[GRAPH] %s Using system prompt from config (%s chars): %s )",
                    uuid.uuid4(),
                    len(system_prompt),
                    system_prompt,
                )

        logger.debug(
            "Creating LLM graph with tools: tools=%s, store=%s, checkpointer=%s, "
            "system_prompt=%s",
            tools,
            "provided" if store else "none",
            "provided" if checkpointer else "none",
            "provided" if system_prompt else "none",
        )
        # Create the react agent with optional system prompt
        middleware: list[AgentMiddleware] = []
        if tool_catalog is not None:
            middleware.append(ToolDiscoveryMiddleware(catalog=tool_catalog))

        react_agent_runnable = create_agent(
            model=llm,
            tools=tools,
            state_schema=MyMessagesState,
            context_schema=dict,  # type: ignore[misc]
            store=store,
            checkpointer=checkpointer,
            system_prompt=system_prompt,
            middleware=middleware,
        )

        # Build the workflow
        workflow: StateGraph[MyMessagesState] = StateGraph(
            MyMessagesState,
            context_schema=dict,  # type: ignore[arg-type]
        )
        workflow.add_node("react_agent", react_agent_runnable)
        workflow.set_entry_point("react_agent")

        compiled_state_graph = workflow.compile()

        return compiled_state_graph

    @staticmethod
    def create_state(
        *,
        messages: List[AnyMessage],
        request_information: RequestInformation,
    ) -> MyMessagesState:
        """
        Create the state.
        """

        input1: MyMessagesState = MyMessagesState(
            messages=messages,
            auth_token=LangGraphToOpenAIConverter.get_auth_token_from_headers(
                headers=request_information.headers
            ),
            usage_metadata=None,
            user_id=request_information.user_id,
            conversation_thread_id=request_information.conversation_thread_id,
            passed_evaluation=None,
            evaluation_notes=None,
        )
        return input1

    @staticmethod
    def get_auth_token_from_headers(headers: Dict[str, str]) -> Optional[str]:
        """
        Get the auth token from the headers.

        Args:
            headers: The headers.

        Returns:
            The auth token.
        """
        # Normalize headers to handle case-insensitive matching
        normalized_headers = {k.lower(): v for k, v in headers.items()}

        # Check for authorization header variations
        auth_headers = ["authorization"]

        for header_key in auth_headers:
            header_value = normalized_headers.get(header_key.lower())

            if header_value:
                # Use regex to extract bearer token
                match = re.search(r"Bearer\s+(\S+)", str(header_value), re.IGNORECASE)
                if match:
                    return match.group(1)

        return None

    # noinspection PyMethodMayBeStatic
    def convert_usage_meta_data_to_openai(
        self, *, usages: List[UsageMetadata]
    ) -> CompletionUsage:
        total_usage_metadata: CompletionUsage = CompletionUsage(
            prompt_tokens=0, completion_tokens=0, total_tokens=0
        )
        usage_metadata: UsageMetadata
        for usage_metadata in usages:
            total_usage_metadata.prompt_tokens += usage_metadata["input_tokens"]
            total_usage_metadata.completion_tokens += usage_metadata["output_tokens"]
            total_usage_metadata.total_tokens += usage_metadata["total_tokens"]
        return total_usage_metadata
