import pathlib
from collections.abc import Iterable, Mapping

import pytest

import lazynwb.file_io


@pytest.fixture(autouse=True)
def reset_file_io_config():
    """Keep file I/O config isolated between tests."""
    original_anon = lazynwb.file_io.config.anon
    original_storage_options = dict(lazynwb.file_io.config.fsspec_storage_options)
    original_use_obstore = lazynwb.file_io.config.use_obstore
    try:
        yield
    finally:
        lazynwb.file_io.config.anon = original_anon
        lazynwb.file_io.config.fsspec_storage_options = original_storage_options
        lazynwb.file_io.config.use_obstore = original_use_obstore


@pytest.mark.parametrize(
    "nwb_fixture_name",
    [
        "local_hdf5_path",
        "local_zarr_path",
    ],
)
def test_file_accessor(nwb_fixture_name, request):
    """Test FileAccessor with various NWB file/store inputs."""
    path = request.getfixturevalue(nwb_fixture_name)
    accessor = lazynwb.file_io._get_accessor(path)
    assert isinstance(accessor, lazynwb.file_io.FileAccessor)
    assert "units" in accessor, "__contains__() failing, or NWB fixture has changed"
    assert "/units" in accessor, "__contains__() failling to normalize path"
    assert accessor.get("units") is not None, "get() should return an object"
    assert next(iter(accessor), None) is not None, "Accessor should be iterable and yield at least one item"

def test_file_accessor_caching(local_hdf5_path: pathlib.Path) -> None:
    """Test that FileAccessor instances are cached and reused."""
    file_path = local_hdf5_path

    # Initial access
    accessor1 = lazynwb.file_io.FileAccessor(file_path)
    accessor1_id = id(accessor1)

    # Access again, should return the same instance
    accessor2 = lazynwb.file_io.FileAccessor(file_path)
    accessor2_id = id(accessor2)

    assert accessor1_id == accessor2_id


def test_file_accessor_reinstantiation_after_close(
    local_hdf5_path: pathlib.Path,
) -> None:
    """Test that FileAccessor can be reinstantiated after the underlying HDF5 file is closed."""
    file_path = local_hdf5_path

    # Initial access
    accessor1 = lazynwb.file_io.FileAccessor(file_path)
    accessor1_id = id(accessor1)

    # Verify it's working initially
    assert "units" in accessor1
    assert accessor1._hdmf_backend == lazynwb.file_io.FileAccessor.HDMFBackend.HDF5

    # Close the underlying HDF5 file
    accessor1._accessor.close()

    # Verify the file is closed
    assert not bool(accessor1._accessor)

    # Access again - should detect stale cache and return same instance with new accessor
    accessor2 = lazynwb.file_io.FileAccessor(file_path)
    accessor2_id = id(accessor2)

    # Should be the same cached instance
    assert accessor1_id == accessor2_id

    # But should have a fresh, working accessor
    assert bool(accessor2._accessor)
    assert "units" in accessor2
    assert accessor2._hdmf_backend == lazynwb.file_io.FileAccessor.HDMFBackend.HDF5


def test_file_accessor_clearing(local_hdf5_path: pathlib.Path) -> None:
    """Test that FileAccessor cache can be cleared."""
    file_path = local_hdf5_path

    # Initial access
    accessor1 = lazynwb.file_io.FileAccessor(file_path)
    accessor1_id = id(accessor1)

    # Clear the cache
    lazynwb.file_io.clear_cache()

    # Access again, should return a new instance
    accessor2 = lazynwb.file_io.FileAccessor(file_path)
    accessor2_id = id(accessor2)

    assert accessor1_id != accessor2_id


def test_open_single_and_multiple(local_hdf5_paths: list[pathlib.Path]) -> None:
    """Test lazynwb.file_io.open with single and multiple paths.

    Ensures correct return type and access for both single and iterable input.
    """

    # Single path
    accessor = lazynwb.file_io._get_accessor(local_hdf5_paths[0])
    assert isinstance(accessor, lazynwb.file_io.FileAccessor)
    assert "units" in accessor

    # Multiple paths
    accessors = lazynwb.file_io._get_accessors(local_hdf5_paths)
    assert isinstance(accessors, Iterable)
    assert all(isinstance(a, lazynwb.file_io.FileAccessor) for a in accessors)
    assert "units" in accessors[0]
    assert "units" in accessors[1]


def test_fsspec_storage_options_use_top_level_anon() -> None:
    lazynwb.file_io.config.anon = True
    lazynwb.file_io.config.fsspec_storage_options = {"anon": False, "custom": "value"}

    assert lazynwb.file_io._get_fsspec_storage_options() == {
        "anon": True,
        "custom": "value",
    }


def test_obstore_storage_options_translate_anon_to_skip_signature() -> None:
    lazynwb.file_io.config.anon = True
    lazynwb.file_io.config.fsspec_storage_options = {"anon": False, "region": "us-west-2"}

    assert lazynwb.file_io._get_obstore_storage_options() == {
        "region": "us-west-2",
        "skip_signature": True,
    }


def test_storage_options_fall_back_to_legacy_anon_setting() -> None:
    lazynwb.file_io.config.anon = None
    lazynwb.file_io.config.fsspec_storage_options = {"anon": True}

    assert lazynwb.file_io._get_fsspec_storage_options()["anon"] is True
    assert lazynwb.file_io._get_obstore_storage_options()["skip_signature"] is True


def test_open_file_preserves_anonymous_s3_options_for_zarr(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    lazynwb.file_io.config.anon = True
    lazynwb.file_io.config.fsspec_storage_options = {"anon": False}

    opened: dict[str, object] = {}

    def fake_zarr_open(store: object, mode: str, **kwargs: object) -> object:
        opened["store"] = store
        opened["mode"] = mode
        opened["kwargs"] = kwargs
        return object()

    monkeypatch.setattr(lazynwb.file_io.zarr, "open", fake_zarr_open)

    lazynwb.file_io._open_file("s3://example-bucket/session.zarr")

    opened_store = opened["store"]
    if isinstance(opened_store, str):
        opened_kwargs = opened["kwargs"]
        assert isinstance(opened_kwargs, Mapping)
        storage_options = opened_kwargs["storage_options"]
        assert isinstance(storage_options, Mapping)
        assert storage_options["anon"] is True
    else:
        assert opened_store.fs.anon is True  # type: ignore[attr-defined]
    assert opened["mode"] == "r"


def test_open_file_preserves_anonymous_s3_options_for_obstore_zarr(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    lazynwb.file_io.config.use_obstore = True
    lazynwb.file_io.config.anon = True
    lazynwb.file_io.config.fsspec_storage_options = {"anon": False}

    opened: dict[str, object] = {}

    def fake_zarr_open(store: object, mode: str, **kwargs: object) -> object:
        opened["store"] = store
        opened["mode"] = mode
        opened["kwargs"] = kwargs
        return object()

    monkeypatch.setattr(lazynwb.file_io.zarr, "open", fake_zarr_open)

    lazynwb.file_io._open_file("s3://example-bucket/session.zarr")

    opened_store = opened["store"]
    assert opened_store.fs._config_kwargs["skip_signature"] is True  # type: ignore[attr-defined]
    assert opened["mode"] == "r"


if __name__ == "__main__":
    pytest.main([__file__])
