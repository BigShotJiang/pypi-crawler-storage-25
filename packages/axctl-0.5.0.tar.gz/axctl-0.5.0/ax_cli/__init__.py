"""aX Platform CLI."""

__version__ = "0.3.0"
