from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic


def capillary_1(p1, S1, S1max, S2, dt):
    # Flux function
    # ------------------
    # Description:  Capillary rise: based on deficit in higher reservoir
    # Constraints:  f <= S2/dt
    # @(Inputs):    p1   - maximum capillary rise rate  [mm/d]
    #               S1   - current storage in receiving store [mm]
    #               S1max- maximum storage in receiving store [mm]
    #               S2   - current storage in providing store [mm]
    #               dt   - time step size [d]

    out = min(p1 * (1 - S1 / S1max), S2 / dt)
    return out


def capillary_2(p1, S, dt):
    # Capillary rise at constant rate
    # Constraints: f <= S/dt
    # Inputs: p1 - base capillary rise rate [mm/d]
    #         S - current storage [mm]
    #         dt - time step size [d]

    return min(p1, S/dt)


def capillary_3(p1, p2, S1, S2, dt):
    # Flux function
    # Description: Capillary rise scaled by receiving store's deficit up to a storage threshold
    # Constraints: f <= S2
    # Inputs: p1   - base capillary rise rate [mm/d]
    #         p2   - threshold above which no capillary flow occurs [mm]
    #         S1   - current storage in receiving store [mm]
    #         S2   - current storage in supplying store [mm]
    #         dt   - time step size [d]
    return min(S2/dt, p1*(1-S1/p2)*smooth_threshold_storage_logistic(S1, p2))
