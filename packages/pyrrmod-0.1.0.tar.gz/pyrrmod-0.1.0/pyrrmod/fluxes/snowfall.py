import numpy as np
from pyrrmod.auxiliary.smooth import smooth_threshold_temperature_logistic as sttl


def snowfall_1(In: float, T: float, p1: float, *args: float) -> float:
    """
    Calculates snowfall based on a temperature threshold.

    Parameters
    ----------
    In : float
        Incoming precipitation flux [mm/d].
    T : float
        Current temperature [°C].
    p1 : float
        Temperature threshold below which snowfall occurs [°C].
    args : float, optional
        Smoothing variable r (default is 0.01).

    Returns
    -------
    float
        Outgoing snowfall flux [mm/d].
    """
    if len(args) == 0:
        r = 0.01
    elif len(args) == 1:
        r = args[0]
    else:
        raise ValueError("Too many input arguments for smoothing variable.")

    sttl_result = sttl(T, p1, r)
    out = In * sttl_result
    return out


def snowfall_2(In: float, T: float, p1: float, p2: float) -> float:
    """
    Calculates snowfall based on a temperature threshold interval.

    Parameters
    ----------
    In : float
        Incoming precipitation flux [mm/d].
    T : float
        Current temperature [°C].
    p1 : float
        Midpoint of the combined rain/snow interval [°C].
    p2 : float
        Length of the mixed snow/rain interval [°C].

    Returns
    -------
    float
        Snowfall amount [mm/d].
    """
    out = min(In, max(0, In * (p1 + 0.5 * p2 - T) / p2))
    return out
