import numpy as np
from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic as stsl


def interception_1(In: np.ndarray, S: np.ndarray, Smax: float, *args: float) -> np.ndarray:
    """
    Interception excess when maximum capacity is reached.

    Parameters
    ----------
    In : np.ndarray
        Incoming flux [mm/d].
    S : np.ndarray
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    *args : float, optional
        Additional smoothing variables r and e.

    Returns
    -------
    np.ndarray
        Outgoing flux after interception [mm/d].
    """
    if len(args) == 0:
        out = In * (1 - stsl(S, Smax))
    elif len(args) == 1:
        out = In * (1 - stsl(S, Smax, args[0]))
    elif len(args) == 2:
        out = In * (1 - stsl(S, Smax, args[0], args[1]))
    else:
        raise ValueError("Too many arguments provided for smoothing variables.")

    return out


def interception_2(In, p1):
    # Flux function
    # Description: Interception excess after a constant amount is intercepted
    # Constraints: - f >= 0
    # Inputs: In - incoming flux [mm/d]
    #            p1   - interception and evaporation capacity [mm/d]
    # Outputs: f - interception excess [mm/d]

    out = max(In - p1, 0)
    return out


def interception_3(p1, In):
    """
    Interception excess after a fraction is intercepted

    Parameters:
    p1 : float
        Fraction throughfall [-]
    In : float
        Incoming flux [mm/day]

    Returns:
    out : float
        Interception excess
    """
    out = p1 * In
    return out


def interception_4(p1, p2, t, tmax, In, dt):
    """
    Creates function for effective rainfall through interception.

    Parameters:
    p1 (float): mean throughfall fraction [-]
    p2 (float): timing of maximum throughfall fraction [d]
    t (float): current time step [-]
    tmax (float): duration of the seasonal cycle [d]
    In (float): incoming flux [mm/d]
    dt (float): time step size [d]

    Returns:
    float: the effective rainfall through interception
    """
    import math
    angle = 2*math.pi*(t*dt - p2) / tmax
    out = max(0, p1 + (1-p1)*math.cos(angle)) * In
    return out


def interception_5(p1, p2, In):
    # Flux function
    # ------------------
    # Description: Interception excess after a combined absolute amount and fraction are intercepted
    # Constraints: f >= 0
    # @(Inputs): p1 - fraction that is not throughfall [-]
    #            p2 - constant interception and evaporation [mm/d]
    #            In - incoming flux [mm/d]

    out = max(p1 * In - p2, 0)

    return out
