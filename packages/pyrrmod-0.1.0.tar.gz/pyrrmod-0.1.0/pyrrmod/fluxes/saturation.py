from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic
import numpy as np
from scipy.stats import norm


def saturation_1(In, S, Smax, *varargin):
    """
    SATURATION_1: Flux function for saturation excess from a store that has reached maximum capacity

    Inputs:
    - In: incoming flux [mm/d]
    - S: current storage [mm]
    - Smax: maximum storage [mm]
    - varargin(1): smoothing variable r (default 0.01)
    - varargin(2): smoothing variable e (default 5.00)

    Output:
    - out: calculated output
    """
    if len(varargin) == 0:
        out = In * (1 - smooth_threshold_storage_logistic(S, Smax))
    elif len(varargin) == 1:
        out = In * (1 - smooth_threshold_storage_logistic(S, Smax, varargin[0]))
    elif len(varargin) == 2:
        out = In * (1 - smooth_threshold_storage_logistic(S, Smax, varargin[0], varargin[1]))

    return out


def saturation_10(p1: float, p2: float, p3: float, S: float, In: float) -> float:
    """
    Calculate the saturation excess flow from a store with different degrees of saturation (min-max exponential variant).

    Parameters
    ----------
    p1 : float
        Maximum contributing fraction area [-].
    p2 : float
        Minimum contributing fraction area [-].
    p3 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    In : float
        Incoming flux [mm/d].

    Returns
    -------
    float
        The saturation excess flow [mm/d].
    """
    # added if statement to prevent overflow error
    if (p3 * S) > 700:
        out = p1 * In
    else:
        out = min(p1, p2 + p2 * np.exp(p3 * S)) * In
    return out


def saturation_11(p1, p2, S, Smin, Smax, In, *args):
    '''
    saturation_11

    Description:
    Saturation excess flow from a store with different degrees of saturation (min exponential variant)

    Constraints:
    f <= In

    Inputs:
    p1   - linear scaling parameter [-]
    p2   - exponential scaling parameter [-]
    S    - current storage [mm]
    Smin - minimum contributing storage [mm]
    Smax - maximum contributing storage [mm]
    In   - incoming flux [mm/d]
    args:
        smoothing variable r (default 0.01)
        smoothing variable e (default 5.00)
    '''

    if len(args) == 0:
        return In * min(1, p1 * (max(0, S - Smin) / (Smax - Smin)) ** p2) * (1 - smooth_threshold_storage_logistic(S, Smin))
    elif len(args) == 1:
        return In * min(1, p1 * (max(0, S - Smin) / (Smax - Smin)) ** p2) * (1 - smooth_threshold_storage_logistic(S, Smin, args[0]))
    elif len(args) == 2:
        return In * min(1, p1 * (max(0, S - Smin) / (Smax - Smin)) ** p2) * (1 - smooth_threshold_storage_logistic(S, Smin, args[0], args[1]))


def saturation_12(p1, p2, In):
    # Flux function
    # Description: Saturation excess flow from a store with different degrees
    # of saturation (min-max linear variant)
    # Constraints: f >= 0
    # Inputs: p1 - maximum contributing fraction area [-]
    #         p2 - minimum contributing fraction area [-]
    #         In - incoming flux [mm/d]

    out = max(0, (p1 - p2) / (1 - p2)) * In

    return out


def saturation_13(p1: float, p2: float, S: float, In: float) -> float:
    """
    Calculate the saturation excess flow from a store with different degrees of saturation (normal distribution variant).

    Parameters
    ----------
    p1 : float
        Soil depth where 50% of the catchment contributes to overland flow [mm].
    p2 : float
        Soil depth where 16% of the catchment contributes to overland flow [mm].
    S : float
        Current storage [mm].
    In : float
        Incoming flux [mm/d].

    Returns
    -------
    float
        The saturation excess flow [mm/d].
    """
    S = max(0, S)  # Ensure storage is non-negative
    if S == 0:
        out = 0
    else:
        out = In * norm.cdf(np.log10(S / p1) / np.log10(p1 / p2))
    return out


def saturation_14(p1, p2, S, Smax, In):
    """
    saturation_14

    WARRANTY. See <https://www.gnu.org/licenses/> for details.

    Flux function
    ------------------
    Description:  Saturation excess flow from a store with different degrees
                  of saturation (two-part exponential variant)
    Constraints:  -
    @(Inputs):    p1   - fraction of area where inflection point is [-]
                  p2   - exponential scaling parameter [-]
                  S    - current storage [mm]
                  Smax - maximum contributing storage [mm]
                  In   - incoming flux [mm/d]
    """
    out = ((  (0.5-p1)**(1-p2) * np.maximum(0,  S/Smax)**p2)*(S/Smax <= 0.5-p1) +
         (1-(0.5+p1)**(1-p2) * np.maximum(0,1-S/Smax)**p2)*(S/Smax >  0.5-p1))*In
    return out


def saturation_2(S, Smax, p1, In):
    # Flux function
    # Description: Saturation excess from a store with different degrees of saturation
    # Constraints: 1-S/Smax >= 0 prevents numerical issues with complex numbers

    # Inputs:
    #   S - current storage [mm]
    #   Smax - maximum contributing storage [mm]
    #   p1 - non-linear scaling parameter [-]
    #   In - incoming flux [mm/d]

    # NOTE: When stores are very slightly below or over their maximum, the exponent can push this function into regions where no feasible solutions exist.
    # The min(max()) combination prevents this from happening.
    # Matlab: out = (1- min(1,max(0,(1-S./Smax))).^p1) .*In

    out = (1 - min(1, max(0, (1 - S / Smax))) ** p1) * In

    return out


def saturation_3(S, Smax, p1, In):
    """
    Flux function: Saturation excess from a store with different degrees of saturation (exponential variant)

    Inputs:
    - S: current storage [mm]
    - Smax: maximum contributing storage [mm]
    - p1: linear scaling parameter [-]
    - In: incoming flux [mm/d]

    Returns:
    - out: calculated flux
    """
    import numpy as np  # Import numpy for exponential function
    out = (1 - (1 / (1 + np.exp((S / Smax + 0.5) / p1)))) * In
    return out


def saturation_4(S: float, Smax: float, In: float) -> float:
    ##S: np.ndarray, Smax: np.ndarray, In: np.ndarray) -> np.ndarray:
    """
    Calculates saturation excess from a store with different degrees of saturation (quadratic variant).

    Parameters
    ----------
    S : float
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    In : float
        Incoming flux [mm/d].

    Returns
    -------
    float
        The saturation excess flux, constrained to be non-negative.
    """
    out = np.maximum(0, (1 - (S / Smax) ** 2) * In)
    return out

# Example usage:
# S = np.array([50, 100])
# Smax = np.array([100, 200])
# In = np.array([10, 20])
# out = saturation_excess_flux(S, Smax, In)
# print(out)


def saturation_5(S, p1, p2, In):
    # Flux function
    # Description: Deficit store: exponential saturation excess based on current storage and a threshold parameter
    # Constraints: S >= 0 prevents numerical issues with complex numbers
    # Inputs: p1 - deficit threshold above which no flow occurs [mm]
    #         p2 - exponential scaling parameter [-]
    #         S - current deficit [mm]
    #         In - incoming flux [mm/d]

    return (1 - min(1, (max(S, 0) / p1) ** p2)) * In


def saturation_6(p1, S, Smax, In):
    # Flux function
    # Description: Saturation excess from a store with different degrees of saturation (linear variant)
    # Constraints: -
    # @(Inputs): p1 - linear scaling parameter [-]
    #            S - current storage [mm]
    #            Smax - maximum contributing storage [mm]
    #            In - incoming flux [mm/d]

    out = p1 * S / Smax * In
    return out


# Python translation of the MATLAB function saturation_7
# Function definition
def saturation_7(p1, p2, p3, p4, p5, S, In):
    from scipy.integrate import quad
    import numpy as np

    # Define the integrand function
    integrand = lambda x: 1 / (p1 * np.math.gamma(p2)) * (np.maximum(x - p3, 0) / p1) ** (p2 - 1) * np.exp(-1 * np.maximum(x - p3, 0) / p1)

    # Perform the integration
    out, _ = quad(integrand, p5 * max(S, 0) + p4, np.inf)

    return out * In


def saturation_8(p1, p2, S, Smax, In):
    '''
    saturation_8

    Flux function
    Description: Saturation excess flow from a store with different degrees of saturation (min-max linear variant)
    Constraints: -
    Inputs: p1 - minimum fraction contributing area [-]
            p2 - maximum fraction contributing area [-]
            S - current storage [mm]
            Smax - maximum contributing storage [mm]
            In - incoming flux [mm/d]
    '''
    out = (p1 + (p2 - p1) * S / Smax) * In
    return out


def saturation_9(In, S, St, *varargin):
    """
    Flux function.

    Description: Deficit store: Saturation excess from a store that has reached maximum capacity.

    Constraints: -

    Parameters:
    -----------
    In : float
        Incoming flux [mm/d].
    S : float
        Current storage [mm].
    St : float
        Threshold for flow generation [mm], 0 for deficit store.
    varargin : tuple
        Smoothing variables r (default 0.01) and e (default 5.00).

    Returns:
    --------
    out : float
        Resulting flux.
    """
    if len(varargin) == 0:
        out = In * smooth_threshold_storage_logistic(S, St)
    elif len(varargin) == 1:
        out = In * smooth_threshold_storage_logistic(S, St, varargin[0])
    elif len(varargin) == 2:
        out = In * smooth_threshold_storage_logistic(S, St, varargin[0], varargin[1])

    return out
