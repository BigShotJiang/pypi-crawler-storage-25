import numpy as np


def phenology_1(T: float, p1: float, p2: float, Ep: float) -> float:
    """
    Corrects potential evapotranspiration (Ep) for phenology effects.

    Parameters
    ----------
    T : float
        Current temperature [°C].
    p1 : float
        Temperature threshold where evaporation stops [°C].
    p2 : float
        Temperature threshold above which corrected Ep equals Ep.
    Ep : float
        Current potential evapotranspiration [mm/d].

    Returns
    -------
    float
        Corrected potential evapotranspiration [mm/d].
    """
    correction_factor = np.clip((T - p1) / (p2 - p1), 0, 1)
    out = correction_factor * Ep
    return out


def phenology_2(p1, p2, p3, t, tmax, dt):
    '''
    phenology_2

    WARRANTY. See <https://www.gnu.org/licenses/> for details.
    '''

    # Flux function
    # Description: Phenology-based maximum interception capacity (returns store size [mm])
    # Constraints: Implicit assumption: 0 <= p2 <= 1
    # Inputs: p1 - mean interception capacity [mm]
    #         p2 - seasonal change as fraction of the mean [-]
    #         p3 - time of maximum store size [d]
    #         t  - current time step [-]
    #         tmax - seasonal length [d]
    #         dt  - time step size [d]

    out = p1 * (1 + p2 * np.sin(2 * np.pi * (t * dt - p3) / tmax))
    return out
