from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    capillary_2,
    evap_1,
    interception_2,
    saturation_2,
    split_1,
)
from pyrrmod.auxiliary.unit_hydro import (
    SingleUHState,
    half_hydrograph,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _make_hillslope_uh(th: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(th, delta_t, power=1.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _hillslope_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _hillslope_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _hillslope_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh_weights: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weights in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    dw = float(theta[0])
    betaw = float(theta[1])
    swmax = float(theta[2])
    a = float(theta[3])
    c = float(theta[5])
    kh = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pe = interception_2(P, dw)
    flux_ei = P - flux_pe
    flux_ea = evap_1(S1, Ep, delta_t)
    flux_qse = saturation_2(S1, swmax, betaw, flux_pe)
    flux_qses = split_1(a, flux_qse)
    flux_qseg = split_1(1.0 - a, flux_qse)
    flux_c = capillary_2(c, S2, delta_t)
    flux_qhgw = baseflow_1(kh, S2)
    flux_qhsrf = _hillslope_route_current(uh_pending)
    flux_qt = flux_qhsrf + flux_qhgw

    out_dS[0] = flux_pe + flux_c - flux_ea - flux_qse
    out_dS[1] = flux_qseg - flux_c - flux_qhgw

    out_fluxes[0] = flux_pe
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_ea
    out_fluxes[3] = flux_qse
    out_fluxes[4] = flux_qses
    out_fluxes[5] = flux_qseg
    out_fluxes[6] = flux_c
    out_fluxes[7] = flux_qhgw
    out_fluxes[8] = flux_qhsrf
    out_fluxes[9] = flux_qt


class hillslope(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 10
        self.num_params = 7
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[0, 5], [0, 10], [1, 2000], [0, 1], [1, 120], [0, 4], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = [
            "pe",
            "ei",
            "ea",
            "qse",
            "qses",
            "qseg",
            "c",
            "qhgw",
            "qhsrf",
            "qt",
        ]
        self.flux_groups = {"Ea": [2, 3], "Q": [10]}

    def init(self) -> None:
        weights = _make_hillslope_uh(float(self.theta[4]), float(self.delta_t))
        routing_state = SingleUHState(
            uh_weights=weights,
            uh_pending=np.zeros_like(weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("hillslope requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = runtime.routing_state
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("hillslope routing state is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        uh_weights = routing.uh_weights
        uh_pending = routing.uh_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_weights,
                uh_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = runtime.routing_state if runtime is not None else self.routing_state
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("hillslope routing state is not initialised")

        _hillslope_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh_weights,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_hillslope_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_hillslope_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "hillslope does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "hillslope does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = (
            self.runtime_context.routing_state
            if self.runtime_context is not None
            else self.routing_state
        )
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("hillslope routing state is not initialised")

        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        flux_qses = float(self.fluxes[self.t, 4])
        _hillslope_update_uh_inplace(routing.uh_weights, routing.uh_pending, flux_qses)
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
