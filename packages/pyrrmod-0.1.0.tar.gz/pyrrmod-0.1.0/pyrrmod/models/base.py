from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from numbers import Real
from typing import Any, Callable, Literal, Self

import numpy as np
from numpy.typing import NDArray
from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)
from scipy.optimize import fsolve, least_squares

from pyrrmod.auxiliary.solver import newton_raphson


FloatArray = NDArray[np.float64]
CompilerTarget = Literal["auto", "python", "numba"]


def _coerce_float_vector(value: Any, field_name: str) -> FloatArray:
    try:
        vector = np.asarray(value, dtype=np.float64).reshape(-1)
    except Exception as exc:
        raise ValueError(f"{field_name} must be an array-like of real numbers") from exc
    if vector.size == 0:
        raise ValueError(f"{field_name} must contain at least one value")
    return np.ascontiguousarray(vector)


def _coerce_vector(value: Any, field_name: str) -> NDArray[Any]:
    try:
        vector = np.asarray(value).reshape(-1)
    except Exception as exc:
        raise ValueError(f"{field_name} must be an array-like value") from exc
    if vector.size == 0:
        raise ValueError(f"{field_name} must contain at least one value")
    return np.array(vector, copy=True)


@dataclass(slots=True, kw_only=True, frozen=True)
class ClimateArrays:
    """Validated runtime climate arrays normalized to per-step flux rates."""

    precip: FloatArray
    pet: FloatArray
    temp: FloatArray
    dates: NDArray[Any] | None = None

    @property
    def time_steps(self) -> int:
        return int(self.precip.shape[0])


@dataclass(slots=True, kw_only=True)
class RuntimeContext:
    """Mutable simulation state shared by Python and compiled kernels.

    This object is intentionally restricted to ndarrays, scalars, and simple
    Python containers so the runtime layer stays compatible with Numba-backed
    kernels. Pydantic models are converted before this context is constructed.
    """

    theta: FloatArray
    delta_t: float
    S0: FloatArray
    climate: ClimateArrays
    time_steps: int
    store_min: FloatArray
    store_max: FloatArray
    stores: FloatArray
    fluxes: FloatArray
    solver_data: dict[str, NDArray[Any]]
    routing_state: Any = None
    active_step: int = 0
    delta_states_scratch: FloatArray | None = None
    fluxes_scratch: FloatArray | None = None

    @property
    def precip(self) -> FloatArray:
        return self.climate.precip

    @property
    def pet(self) -> FloatArray:
        return self.climate.pet

    @property
    def temp(self) -> FloatArray:
        return self.climate.temp


class ClimateInput(BaseModel):
    """Validation-only climate forcing payload.

    This model exists only at the input boundary. Before simulation starts, the
    payload is converted to contiguous ndarrays inside :meth:`to_climate_arrays`.
    """

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )

    precip: Sequence[float] | NDArray[Any] = Field(
        validation_alias=AliasChoices("precip", "P", "rain", "rainfall")
    )
    pet: Sequence[float] | NDArray[Any] = Field(
        validation_alias=AliasChoices("pet", "PET", "etp")
    )
    temp: Sequence[float] | NDArray[Any] = Field(
        validation_alias=AliasChoices("temp", "temperature", "T")
    )
    dates: Sequence[Any] | NDArray[Any] | None = None

    @field_validator("precip", mode="before")
    @classmethod
    def _validate_precip(cls, value: Any) -> FloatArray:
        return _coerce_float_vector(value, "precip")

    @field_validator("pet", mode="before")
    @classmethod
    def _validate_pet(cls, value: Any) -> FloatArray:
        return _coerce_float_vector(value, "pet")

    @field_validator("temp", mode="before")
    @classmethod
    def _validate_temp(cls, value: Any) -> FloatArray:
        return _coerce_float_vector(value, "temp")

    @field_validator("dates", mode="before")
    @classmethod
    def _validate_dates(cls, value: Any) -> NDArray[Any] | None:
        if value is None:
            return None
        return _coerce_vector(value, "dates")

    @model_validator(mode="after")
    def _validate_lengths(self) -> ClimateInput:
        time_steps = int(np.asarray(self.precip).shape[0])
        if int(np.asarray(self.pet).shape[0]) != time_steps:
            raise ValueError("pet must have the same length as precip")
        if int(np.asarray(self.temp).shape[0]) != time_steps:
            raise ValueError("temp must have the same length as precip")
        if (
            self.dates is not None
            and int(np.asarray(self.dates).shape[0]) != time_steps
        ):
            raise ValueError("dates must have the same length as precip")
        return self

    def to_climate_arrays(self, delta_t: float) -> ClimateArrays:
        if not np.isfinite(delta_t) or delta_t <= 0.0:
            raise ValueError("delta_t must be a finite positive scalar")

        precip = np.ascontiguousarray(
            np.asarray(self.precip, dtype=np.float64) / delta_t
        )
        pet = np.ascontiguousarray(np.asarray(self.pet, dtype=np.float64) / delta_t)
        temp = np.ascontiguousarray(np.asarray(self.temp, dtype=np.float64))
        dates: NDArray[Any] | None = None
        if self.dates is not None:
            dates = np.array(np.asarray(self.dates).reshape(-1), copy=True)

        return ClimateArrays(precip=precip, pet=pet, temp=temp, dates=dates)


class SolverOptionsInput(BaseModel):
    """Validation-only overrides for nonlinear solver options."""

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )

    resnorm_tolerance: float | None = Field(default=None, gt=0.0)
    resnorm_maxiter: int | None = Field(default=None, ge=1)
    NewtonRaphson: Mapping[str, Any] | None = None
    fsolve: Mapping[str, Any] | None = None
    lsqnonlin: Mapping[str, Any] | None = None

    @field_validator("NewtonRaphson", "fsolve", "lsqnonlin", mode="before")
    @classmethod
    def _validate_mapping_fields(cls, value: Any) -> Mapping[str, Any] | None:
        if value is None:
            return None
        if not isinstance(value, Mapping):
            raise ValueError("solver section must be a mapping")
        return dict(value)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump(exclude_none=True)


class ModelConfigInput(BaseModel):
    """Validation-only partial configuration update for the object layer."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )

    theta: Sequence[float] | NDArray[Any] | None = None
    delta_t: float | None = Field(default=None, gt=0.0)
    S0: Sequence[float] | NDArray[Any] | None = Field(
        default=None,
        validation_alias=AliasChoices("S0", "s0", "initial_stores"),
    )
    input_climate: ClimateInput | None = Field(
        default=None,
        validation_alias=AliasChoices("input_climate", "climate"),
    )
    solver_opts: SolverOptionsInput | None = Field(
        default=None,
        validation_alias=AliasChoices("solver_opts", "solver_options"),
    )
    compile_target: CompilerTarget | None = None

    @field_validator("theta", mode="before")
    @classmethod
    def _validate_theta(cls, value: Any) -> FloatArray | None:
        if value is None:
            return None
        return _coerce_float_vector(value, "theta")

    @field_validator("S0", mode="before")
    @classmethod
    def _validate_s0(cls, value: Any) -> FloatArray | None:
        if value is None:
            return None
        return _coerce_float_vector(value, "S0")

    @field_validator("input_climate", mode="before")
    @classmethod
    def _validate_input_climate(cls, value: Any) -> ClimateInput | None:
        if value is None:
            return None
        if isinstance(value, ClimateInput):
            return value
        return ClimateInput.model_validate(value)

    @field_validator("solver_opts", mode="before")
    @classmethod
    def _validate_solver_opts(cls, value: Any) -> SolverOptionsInput | None:
        if value is None:
            return None
        if isinstance(value, SolverOptionsInput):
            return value
        if isinstance(value, Mapping):
            return SolverOptionsInput.model_validate(dict(value))
        raise ValueError("solver_opts must be a mapping or SolverOptionsInput")


class ModelRunInput(ModelConfigInput):
    """Validation-only complete simulation request.

    This is the payload shape expected by the MCP-facing run path. It must
    contain all inputs required to execute a simulation immediately.
    """

    theta: Sequence[float] | NDArray[Any]
    delta_t: float = Field(gt=0.0)
    S0: Sequence[float] | NDArray[Any] = Field(
        validation_alias=AliasChoices("S0", "s0", "initial_stores")
    )
    input_climate: ClimateInput = Field(
        validation_alias=AliasChoices("input_climate", "climate")
    )


@dataclass(slots=True, kw_only=True)
class CompilerState:
    """Lazy compiler configuration and resolved runtime state."""

    requested_target: CompilerTarget = "python"
    target: str = "python"
    compiled_model_fun: (
        Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
    ) = None
    detail: str = "python model_fun"
    attempted: bool = False

    @property
    def enabled(self) -> bool:
        return self.compiled_model_fun is not None

    @property
    def wants_numba(self) -> bool:
        return self.requested_target in {"auto", "numba"}


class HydrologyModel(ABC):
    """Simulation-only base class with explicit validation/runtime separation.

    Pydantic models are used only at the API boundary to validate input payloads.
    Before a simulation starts, validated data is converted to ndarrays and
    scalars and stored inside :class:`RuntimeContext`, so compiled kernels never
    interact with BaseModel instances. Numeric kernels are built lazily and may
    be accelerated with Numba without import-time compilation.
    """

    def __init__(self) -> None:
        self.num_stores: int | None = None
        self.num_fluxes: int | None = None
        self.num_params: int | None = None
        self.par_ranges: FloatArray | None = None
        self.jacob_pattern: Any = None
        self.store_names: list[str] | None = None
        self.flux_names: list[str] | None = None
        self.flux_groups: dict[str, Any] | None = None
        self.StoreSigns: Any = None

        self._theta: FloatArray | None = None
        self._delta_t: float | None = None
        self._S0: FloatArray | None = None
        self._input_climate: dict[str, NDArray[Any]] | None = None
        self._climate_arrays: ClimateArrays | None = None
        self._solver_opts: dict[str, Any] | None = None
        self._runtime_context: RuntimeContext | None = None
        self._python_model_fun: (
            Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
        ) = None
        self._suspend_reset: int = 0

        self.store_min: FloatArray | None = None
        self.store_max: FloatArray | None = None
        self.t: int | None = None
        self.fluxes: FloatArray | None = None
        self.stores: FloatArray | None = None
        self.uhs: Any = None
        self.routing_state: Any = None
        self.solver_data: dict[str, NDArray[Any]] | None = None
        self.status: int = 0
        self.compiler: CompilerState = CompilerState()

    @property
    def theta(self) -> FloatArray | None:
        return self._theta

    @theta.setter
    def theta(self, value: Any) -> None:
        if value is None:
            self._theta = None
            self._reset_if_allowed()
            return
        self._theta = self._normalize_vector(value, self.num_params, "theta")
        self._reset_if_allowed()

    @property
    def delta_t(self) -> float | None:
        return self._delta_t

    @delta_t.setter
    def delta_t(self, value: Any) -> None:
        if value is None:
            self._delta_t = None
            self._reset_if_allowed()
            return
        if not isinstance(value, Real):
            raise ValueError("delta_t must be a scalar")
        self._delta_t = float(value)
        self._reset_if_allowed()

    @property
    def S0(self) -> FloatArray | None:
        return self._S0

    @S0.setter
    def S0(self, value: Any) -> None:
        if value is None:
            self._S0 = None
            self._reset_if_allowed()
            return
        self._S0 = self._normalize_vector(value, self.num_stores, "S0")
        self._reset_if_allowed()

    @property
    def input_climate(self) -> dict[str, NDArray[Any]] | None:
        return self._input_climate

    @input_climate.setter
    def input_climate(self, value: Any) -> None:
        if value is None:
            self._input_climate = None
            self._climate_arrays = None
            self._reset_if_allowed()
            return

        climate_arrays, climate_mapping = self._normalize_climate_inputs(value)
        self._climate_arrays = climate_arrays
        self._input_climate = climate_mapping
        self._reset_if_allowed()

    @property
    def climate_arrays(self) -> ClimateArrays | None:
        return self._climate_arrays

    @property
    def runtime_context(self) -> RuntimeContext | None:
        return self._runtime_context

    @property
    def solver_opts(self) -> dict[str, Any] | None:
        return self._solver_opts

    @solver_opts.setter
    def solver_opts(self, value: Any) -> None:
        if value is None:
            self._solver_opts = None
            self._reset_if_allowed()
            return

        normalized: dict[str, Any]
        if isinstance(value, SolverOptionsInput):
            normalized = value.to_dict()
        elif isinstance(value, Mapping):
            normalized = dict(value)
        else:
            raise ValueError("solver_opts must be a mapping or SolverOptionsInput")

        self._solver_opts = self.merge_solver_options(normalized)
        self._reset_if_allowed()

    @property
    def model_name(self) -> str:
        return getattr(self, "legacy_name", self.__class__.__name__)

    @property
    def model_meta(self) -> dict[str, Any]:
        par_ranges = None
        if self.par_ranges is not None:
            par_ranges = np.asarray(self.par_ranges, dtype=np.float64)

        return {
            "name": self.model_name,
            "num_stores": int(self.num_stores or 0),
            "num_fluxes": int(self.num_fluxes or 0),
            "num_params": int(self.num_params or 0),
            "par_ranges": par_ranges,
            "jacob_pattern": self.jacob_pattern,
            "store_names": tuple(self.store_names or ()),
            "flux_names": tuple(self.flux_names or ()),
            "flux_groups": self.flux_groups,
        }

    @staticmethod
    def _coerce_config_input(
        payload: ModelConfigInput | Mapping[str, Any],
    ) -> ModelConfigInput:
        if isinstance(payload, ModelConfigInput):
            return payload
        if not isinstance(payload, Mapping):
            raise ValueError("config payload must be a mapping or ModelConfigInput")
        return ModelConfigInput.model_validate(dict(payload))

    @staticmethod
    def _coerce_run_input(
        payload: ModelRunInput | Mapping[str, Any],
    ) -> ModelRunInput:
        if isinstance(payload, ModelRunInput):
            return payload
        if not isinstance(payload, Mapping):
            raise ValueError("run payload must be a mapping or ModelRunInput")
        return ModelRunInput.model_validate(dict(payload))

    def validate_run_payload(
        self,
        payload: ModelRunInput | Mapping[str, Any],
    ) -> ModelRunInput:
        """Validate an MCP run payload without executing the simulation."""

        return self._coerce_run_input(payload)

    def run_from_payload(
        self,
        payload: ModelRunInput | Mapping[str, Any],
        *,
        include_internal: bool = False,
        include_solver: bool = False,
        include_water_balance: bool = True,
        include_execution: bool = False,
    ) -> dict[str, Any]:
        """Recommended MCP entrypoint for executing a complete simulation request.

        This method validates a :class:`ModelRunInput` payload, runs the model,
        and returns a compact JSON-safe response. MCP callers that need
        structured error payloads should catch exceptions and pass them to
        :meth:`_format_mcp_error`.
        """

        self.run(config=self.validate_run_payload(payload))
        return self.to_mcp_payload(
            include_internal=include_internal,
            include_solver=include_solver,
            include_water_balance=include_water_balance,
            include_execution=include_execution,
        )

    def configure(
        self,
        *,
        config: ModelConfigInput | Mapping[str, Any] | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: ClimateInput | Mapping[str, Any] | None = None,
        solver_opts: SolverOptionsInput | Mapping[str, Any] | None = None,
        compile_target: CompilerTarget | None = None,
    ) -> Self:
        """Apply partial object-level configuration outside the MCP run path."""

        if config is not None:
            parsed = self._coerce_config_input(config)
            if parsed.delta_t is not None:
                self.delta_t = parsed.delta_t
            if parsed.theta is not None:
                self.theta = parsed.theta
            if parsed.S0 is not None:
                self.S0 = parsed.S0
            if parsed.solver_opts is not None:
                self.solver_opts = parsed.solver_opts
            if parsed.input_climate is not None:
                self.input_climate = parsed.input_climate
            if parsed.compile_target is not None:
                self.compile_model_fun(parsed.compile_target)

        if delta_t is not None:
            self.delta_t = delta_t
        if theta is not None:
            self.theta = theta
        if S0 is not None:
            self.S0 = S0
        if solver_opts is not None:
            self.solver_opts = solver_opts
        if input_climate is not None:
            self.input_climate = input_climate
        if compile_target is not None:
            self.compile_model_fun(compile_target)
        return self

    def reset(self) -> None:
        requested_target = self.compiler.requested_target
        self._runtime_context = None
        self._python_model_fun = None
        self.t = None
        self.fluxes = None
        self.stores = None
        self.uhs = None
        self.routing_state = None
        self.solver_data = None
        self.status = 0

        if requested_target == "python":
            detail = "python model_fun"
            target = "python"
        else:
            detail = "numba pending (lazy compile)"
            target = "pending"

        self.compiler = CompilerState(
            requested_target=requested_target,
            target=target,
            detail=detail,
            attempted=False,
        )

    def compile_model_fun(self, target: CompilerTarget = "auto") -> CompilerState:
        """Select the preferred execution target without compiling eagerly."""

        if target not in {"auto", "python", "numba"}:
            raise ValueError("target must be one of: auto, python, numba")

        if target == "python":
            detail = "python model_fun"
            resolved_target = "python"
        else:
            detail = "numba pending (lazy compile)"
            resolved_target = "pending"

        self.compiler = CompilerState(
            requested_target=target,
            target=resolved_target,
            detail=detail,
            attempted=False,
        )
        return self.compiler

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        return None

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        return None

    def init_runtime(self) -> None:
        """Materialize validated inputs into ndarray-only runtime state."""

        self._ensure_ready_to_run()
        climate = self._climate_arrays
        assert climate is not None
        time_steps = climate.time_steps

        self._suspend_reset += 1
        try:
            self.store_min = np.zeros(self.num_stores, dtype=np.float64)
            self.store_max = np.full(self.num_stores, np.inf, dtype=np.float64)
            self.stores = np.zeros((time_steps, self.num_stores), dtype=np.float64)
            self.fluxes = np.zeros((time_steps, self.num_fluxes), dtype=np.float64)
            self.solver_data = self._build_solver_data(time_steps)
            self.uhs = None
            self.routing_state = None
            self.init()
        finally:
            self._suspend_reset -= 1

        self.store_min = self._normalize_store_bounds(self.store_min, 0.0, "store_min")
        self.store_max = self._normalize_store_bounds(
            self.store_max, np.inf, "store_max"
        )

        runtime = RuntimeContext(
            theta=np.asarray(self.theta, dtype=np.float64),
            delta_t=float(self.delta_t),
            S0=np.asarray(self.S0, dtype=np.float64),
            climate=climate,
            time_steps=time_steps,
            store_min=np.asarray(self.store_min, dtype=np.float64),
            store_max=np.asarray(self.store_max, dtype=np.float64),
            stores=np.asarray(self.stores, dtype=np.float64),
            fluxes=np.asarray(self.fluxes, dtype=np.float64),
            solver_data=self.solver_data,
            routing_state=self.routing_state,
            delta_states_scratch=np.empty(self.num_stores, dtype=np.float64),
            fluxes_scratch=np.empty(self.num_fluxes, dtype=np.float64),
        )
        self._runtime_context = runtime
        self._python_model_fun = self.build_python_kernel(runtime)
        self._ensure_compiler_ready(runtime)
        self.t = None

    def ode_approx_implicit_euler(self, states: Any) -> FloatArray:
        runtime = self._require_runtime_context()
        current_states = np.asarray(states, dtype=np.float64).reshape(-1)
        delta_states = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        self._evaluate_step_into(
            current_states, runtime.active_step, delta_states, fluxes
        )

        previous_states = (
            runtime.S0
            if runtime.active_step == 0
            else runtime.stores[runtime.active_step - 1, :]
        )
        return (current_states - previous_states) / runtime.delta_t - delta_states

    def solve_stores(self, previous_states: Any) -> tuple[FloatArray, float, str, int]:
        previous_states = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        solver_opts = self._solver_opts or self.default_solver_options()
        scale = float(np.min(np.abs(previous_states))) if previous_states.size else 0.0
        tolerance = solver_opts["resnorm_tolerance"] * scale + 1e-5

        trial_states = np.zeros((3, self.num_stores), dtype=np.float64)
        trial_resnorms = np.full(3, np.inf, dtype=np.float64)
        trial_iters = np.ones(3, dtype=int)

        current_states, residuals, _ = newton_raphson(
            self.ode_approx_implicit_euler,
            previous_states,
            solver_opts["NewtonRaphson"],
        )
        current_states = self._clamp_states(current_states)
        residuals = self.ode_approx_implicit_euler(current_states)
        trial_states[0, :] = current_states
        trial_resnorms[0] = float(np.sum(residuals**2))

        if trial_resnorms[0] > tolerance:
            current_states, residuals, _, iterations = self.rerun_solver(
                "fsolve", current_states, previous_states
            )
            trial_states[1, :] = current_states
            trial_resnorms[1] = float(np.sum(residuals**2))
            trial_iters[1] = iterations

            if trial_resnorms[1] > tolerance:
                current_states, residuals, _, iterations = self.rerun_solver(
                    "lsqnonlin", current_states, previous_states
                )
                trial_states[2, :] = current_states
                trial_resnorms[2] = float(np.sum(residuals**2))
                trial_iters[2] = iterations

        best_index = int(np.argmin(trial_resnorms))
        solver_name = ["NewtonRaphson", "fsolve", "lsqnonlin"][best_index]
        return (
            trial_states[best_index],
            float(trial_resnorms[best_index]),
            solver_name,
            int(trial_iters[best_index]),
        )

    def rerun_solver(
        self,
        solver_name: str,
        initial_guess: Any,
        previous_states: Any,
    ) -> tuple[FloatArray, FloatArray, int, int]:
        solver_name = solver_name.lower()
        solver_opts = (self._solver_opts or self.default_solver_options())[solver_name]
        previous_states = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        initial_guess = np.asarray(initial_guess, dtype=np.float64).reshape(-1)
        max_iter = int(
            (self._solver_opts or self.default_solver_options())["resnorm_maxiter"]
        )
        tolerance = (self._solver_opts or self.default_solver_options())[
            "resnorm_tolerance"
        ]
        tolerance = tolerance * float(np.min(np.abs(previous_states))) + 1e-5

        best_states = initial_guess.copy()
        best_residuals = self.ode_approx_implicit_euler(best_states)
        best_resnorm = float(np.sum(best_residuals**2))
        stop_flag = 1

        for iteration in range(1, max_iter + 1):
            trial_guess = self._solver_guess(iteration, initial_guess, previous_states)

            if solver_name == "fsolve":
                current_states, info_dict, _, _ = fsolve(
                    self.ode_approx_implicit_euler,
                    trial_guess,
                    full_output=True,
                )
                current_residuals = np.asarray(info_dict["fvec"], dtype=np.float64)
            elif solver_name == "lsqnonlin":
                result = least_squares(
                    self.ode_approx_implicit_euler,
                    self._clamp_states(trial_guess),
                    bounds=(self.store_min, self.store_max),
                    method="trf",
                    max_nfev=solver_opts["MaxFunEvals"],
                )
                current_states = np.asarray(result.x, dtype=np.float64)
                current_residuals = np.asarray(result.fun, dtype=np.float64)
                stop_flag = int(result.status)
            else:
                raise ValueError("Only fsolve and lsqnonlin are supported.")

            current_states = self._clamp_states(current_states)
            current_residuals = self.ode_approx_implicit_euler(current_states)
            current_resnorm = float(np.sum(current_residuals**2))

            if current_resnorm < best_resnorm:
                best_states = current_states
                best_residuals = current_residuals
                best_resnorm = current_resnorm

            if best_resnorm <= tolerance:
                return best_states, best_residuals, stop_flag, iteration

        return best_states, best_residuals, 5, max_iter

    def run(
        self,
        input_climate: ClimateInput | Mapping[str, Any] | None = None,
        S0: Any | None = None,
        theta: Any | None = None,
        solver_opts: SolverOptionsInput | Mapping[str, Any] | None = None,
        *,
        config: ModelRunInput | Mapping[str, Any] | None = None,
        compile_target: CompilerTarget | None = None,
    ) -> None:
        """Run a full simulation after validating any provided payload inputs."""

        if config is not None:
            self.configure(config=self._coerce_run_input(config))

        if theta is not None:
            self.theta = theta
        if S0 is not None:
            self.S0 = S0
        if solver_opts is not None:
            self.solver_opts = solver_opts
        if input_climate is not None:
            self.input_climate = input_climate
        if compile_target is not None:
            self.compile_model_fun(compile_target)

        self.init_runtime()
        runtime = self._require_runtime_context()

        if self._uses_discrete_step_solver():
            self._run_discrete(runtime)
        else:
            self._run_implicit(runtime)

        self.status = 1

    def get_output(self, nargout: int, *args: Any):
        """Legacy compatibility output.

        Prefer :meth:`get_output_dict` for structured consumers and
        :meth:`to_mcp_payload` for MCP/JSON-facing callers.
        """

        if args or self.status == 0:
            self.run(*args)

        flux_output: dict[str, FloatArray] = {}
        for group_name, raw_indices in self.flux_groups.items():
            indices = np.atleast_1d(raw_indices).astype(int)
            signs = np.sign(indices)
            zero_based = np.abs(indices) - 1
            values = self.fluxes[:, zero_based]
            flux_output[group_name] = (
                signs[0] * values[:, 0]
                if zero_based.size == 1
                else np.sum(signs * values, axis=1)
            )

        flux_internal = {
            self.flux_names[index]: self.fluxes[:, index]
            for index in range(self.num_fluxes)
        }
        store_internal = {
            self.store_names[index]: self.stores[:, index]
            for index in range(self.num_stores)
        }

        if nargout == 4:
            water_balance = self.check_water_balance()
            return flux_output, flux_internal, store_internal, water_balance
        if nargout == 5:
            water_balance = self.check_water_balance()
            return (
                flux_output,
                flux_internal,
                store_internal,
                water_balance,
                self.solver_data,
            )
        return flux_output, flux_internal, store_internal

    def get_output_dict(
        self,
        *,
        include_internal: bool = False,
        include_solver: bool = False,
        include_water_balance: bool = True,
        include_execution: bool = False,
    ) -> dict[str, Any]:
        """Return the single structured output representation for a simulation.

        This is the canonical structured output source. Higher-level MCP output
        methods should build on this method instead of reconstructing response
        payloads independently.
        """

        if self.status == 0:
            self.run()

        flux_output, flux_internal, store_internal = self.get_output(3)
        output: dict[str, Any] = {
            "model": self.model_name,
            "status": int(self.status),
            "flux_groups": flux_output,
            "streamflow": self.get_streamflow(),
        }

        if include_internal:
            output["flux_internal"] = flux_internal
            output["store_internal"] = store_internal
        if include_solver:
            output["solver_data"] = self.solver_data
        if include_water_balance:
            output["water_balance_error"] = self.check_water_balance()
        if include_execution:
            output["execution"] = self._execution_metadata()
        return output

    def to_mcp_payload(
        self,
        *,
        include_internal: bool = False,
        include_solver: bool = False,
        include_water_balance: bool = True,
        include_execution: bool = False,
    ) -> dict[str, Any]:
        """Convert :meth:`get_output_dict` output to JSON-safe Python types."""

        raw = self.get_output_dict(
            include_internal=include_internal,
            include_solver=include_solver,
            include_water_balance=include_water_balance,
            include_execution=include_execution,
        )
        return self._to_builtin_types(raw)

    def check_water_balance(self, *args: Any) -> float:
        """Compute the simulation water balance residual for the current run."""

        if args or self.status == 0:
            self.run(*args)

        if self._climate_arrays is None or self.delta_t is None:
            raise RuntimeError(
                "Climate arrays are not initialised. Run the model first."
            )

        precipitation = np.asarray(
            self._climate_arrays.precip, dtype=np.float64
        ) * float(self.delta_t)
        total_outflow = 0.0
        for raw_indices in self.flux_groups.values():
            indices = np.atleast_1d(raw_indices).astype(int)
            signs = np.sign(indices)
            zero_based = np.abs(indices) - 1
            total_outflow += float(np.sum(signs * self.fluxes[:, zero_based]))

        store_signs = (
            np.ones(self.num_stores, dtype=np.float64)
            if self.StoreSigns is None
            else np.atleast_1d(self.StoreSigns).astype(np.float64)
        )
        delta_storage = store_signs * (self.stores[-1] - self.S0)

        return float(
            np.sum(precipitation)
            - total_outflow
            - np.sum(delta_storage)
            - self.get_routed_storage_amount()
        )

    def get_routed_storage_amount(self) -> float:
        runtime = self._runtime_context
        if runtime is not None and runtime.routing_state is not None:
            return self._sum_routing_storage(runtime.routing_state)
        return self._sum_routing_storage(self.uhs)

    def get_streamflow(self, pars: Any | None = None) -> FloatArray:
        """Return simulated streamflow derived from the configured Q flux group."""

        if pars is not None:
            parameter_vector = np.asarray(pars, dtype=np.float64).reshape(-1)
            if (
                self.status == 0
                or self.theta is None
                or not np.array_equal(parameter_vector, self.theta)
            ):
                self.run(theta=parameter_vector)
        elif self.status == 0:
            self.run()

        indices = np.atleast_1d(self.flux_groups["Q"]).astype(int)
        signs = np.sign(indices)
        zero_based = np.abs(indices) - 1
        return np.sum(signs * self.fluxes[:, zero_based], axis=1)

    def default_solver_options(self) -> dict[str, Any]:
        return {
            "resnorm_tolerance": 0.1,
            "resnorm_maxiter": 6,
            "NewtonRaphson": {"MaxIter": self.num_stores * 10},
            "fsolve": {"jacob_pattern": self.jacob_pattern},
            "lsqnonlin": {"jacob_pattern": self.jacob_pattern, "MaxFunEvals": 1000},
        }

    def merge_solver_options(
        self, opts: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        defaults = self.default_solver_options()
        if opts is None:
            return defaults

        merged: dict[str, Any] = {}
        for field, default_value in defaults.items():
            if field not in opts or opts[field] is None:
                merged[field] = default_value
            elif isinstance(default_value, dict):
                merged[field] = {**default_value, **opts[field]}
            else:
                merged[field] = opts[field]
        return merged

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            f"{self.model_name} does not expose a SciPy-compatible RHS yet."
        )

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        raise NotImplementedError(
            f"{self.model_name} does not expose a SciPy-compatible RHS yet."
        )

    def _evaluate_model_fun(self, states: Any) -> tuple[FloatArray, FloatArray]:
        runtime = self._require_runtime_context()
        vector = np.asarray(states, dtype=np.float64).reshape(-1)
        delta_states = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        self._evaluate_step_into(vector, runtime.active_step, delta_states, fluxes)
        return delta_states, fluxes

    def _evaluate_step_into(
        self,
        states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        """Evaluate one model step into preallocated ndarray outputs.

        This method is the hot-path bridge between the object layer and the
        Python/Numba kernel layer. Only ndarrays, integers, and floats cross
        this boundary.
        """

        vector = np.asarray(states, dtype=np.float64).reshape(-1)
        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if kernel is not None:
            kernel(vector, step_index, out_states, out_fluxes)
            return

        self.t = step_index
        delta_states, fluxes = self.model_fun(vector)
        out_states[:] = np.asarray(delta_states, dtype=np.float64).reshape(-1)
        out_fluxes[:] = np.asarray(fluxes, dtype=np.float64).reshape(-1)

    def _uses_discrete_step_solver(self) -> bool:
        return False

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        raise NotImplementedError(
            f"{self.model_name} does not implement a discrete step kernel."
        )

    def _run_implicit(self, runtime: RuntimeContext) -> None:
        assert runtime.delta_states_scratch is not None
        assert runtime.fluxes_scratch is not None

        for time_index in range(runtime.time_steps):
            self._set_active_step(runtime, time_index)
            previous_states = (
                runtime.S0 if time_index == 0 else runtime.stores[time_index - 1, :]
            )
            current_states, resnorm, solver_name, iterations = self.solve_stores(
                previous_states
            )
            self._evaluate_step_into(
                current_states,
                time_index,
                runtime.delta_states_scratch,
                runtime.fluxes_scratch,
            )

            runtime.fluxes[time_index, :] = runtime.fluxes_scratch * runtime.delta_t
            runtime.stores[time_index, :] = (
                previous_states + runtime.delta_states_scratch * runtime.delta_t
            )
            runtime.solver_data["resnorm"][time_index] = resnorm
            runtime.solver_data["solver"][time_index] = solver_name
            runtime.solver_data["iter"][time_index] = iterations
            self.step()

    def _run_discrete(self, runtime: RuntimeContext) -> None:
        next_states = np.empty(self.num_stores, dtype=np.float64)
        assert runtime.fluxes_scratch is not None

        for time_index in range(runtime.time_steps):
            self._set_active_step(runtime, time_index)
            previous_states = (
                runtime.S0 if time_index == 0 else runtime.stores[time_index - 1, :]
            )
            self._advance_discrete_step(
                previous_states,
                time_index,
                next_states,
                runtime.fluxes_scratch,
            )

            runtime.stores[time_index, :] = next_states
            runtime.fluxes[time_index, :] = runtime.fluxes_scratch * runtime.delta_t
            runtime.solver_data["resnorm"][time_index] = 0.0
            runtime.solver_data["solver"][time_index] = "discrete"
            runtime.solver_data["iter"][time_index] = 1
            self.step()

    def _ensure_compiler_ready(self, runtime: RuntimeContext) -> None:
        """Attempt lazy kernel compilation once the ndarray runtime is available."""

        if self.compiler.attempted or not self.compiler.wants_numba:
            return

        detail = "compiled model unavailable"
        compiled_model_fun: (
            Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
        ) = None
        builder = getattr(self, "build_numba_model_fun", None)
        if callable(builder):
            try:
                compiled_model_fun = builder(runtime)
            except Exception as exc:  # pragma: no cover - optional acceleration path
                detail = f"compiled model unavailable: {exc}"
            else:
                if compiled_model_fun is not None:
                    self.compiler = CompilerState(
                        requested_target=self.compiler.requested_target,
                        target="numba",
                        compiled_model_fun=compiled_model_fun,
                        detail="model-specific compiled kernel",
                        attempted=True,
                    )
                    return

        self.compiler = CompilerState(
            requested_target=self.compiler.requested_target,
            target="python",
            detail=detail,
            attempted=True,
        )

    def _build_solver_data(self, time_steps: int) -> dict[str, NDArray[Any]]:
        return {
            "resnorm": np.zeros(time_steps, dtype=np.float64),
            "solver": np.full(time_steps, "None", dtype="U32"),
            "iter": np.zeros(time_steps, dtype=int),
        }

    def _normalize_vector(
        self, value: Any, expected_size: int | None, field_name: str
    ) -> FloatArray:
        vector = np.array(value, dtype=np.float64, copy=True).reshape(-1)
        if expected_size is not None and vector.size != expected_size:
            raise ValueError(f"{field_name} must have {expected_size} elements")
        return np.ascontiguousarray(vector)

    def _normalize_climate_inputs(
        self, value: Any
    ) -> tuple[ClimateArrays, dict[str, NDArray[Any]]]:
        """Validate climate payloads and convert them to runtime ndarray form."""

        if self.delta_t is None:
            raise ValueError("delta_t must be set before input_climate")
        if isinstance(value, ClimateInput):
            climate_input = value
        elif isinstance(value, Mapping):
            climate_input = ClimateInput.model_validate(dict(value))
        else:
            raise ValueError("input_climate must be a mapping or ClimateInput")

        climate_arrays = climate_input.to_climate_arrays(float(self.delta_t))
        climate_mapping = {
            "precip": climate_arrays.precip,
            "pet": climate_arrays.pet,
            "temp": climate_arrays.temp,
        }
        if climate_arrays.dates is not None:
            climate_mapping["dates"] = climate_arrays.dates
        return climate_arrays, climate_mapping

    def _ensure_ready_to_run(self) -> None:
        missing: list[str] = []
        for name in ("theta", "delta_t", "S0", "input_climate"):
            if getattr(self, name) is None:
                missing.append(name)
        if self.solver_opts is None:
            self.solver_opts = {}
        if missing:
            raise ValueError(
                f"Model is not ready to run. Missing: {', '.join(missing)}"
            )

    def _to_builtin_types(self, value: Any) -> Any:
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, dict):
            return {str(k): self._to_builtin_types(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._to_builtin_types(item) for item in value]
        return value

    def _execution_metadata(self) -> dict[str, str]:
        return {
            "requested_target": str(self.compiler.requested_target),
            "resolved_target": str(self.compiler.target),
            "compiler_detail": str(self.compiler.detail),
        }

    def _format_mcp_error(
        self,
        exc: Exception,
        category: str | None = None,
    ) -> dict[str, Any]:
        """Return a small structured error payload for MCP-facing adapters."""

        resolved_category = category or self._infer_mcp_error_category(exc)
        payload: dict[str, Any] = {
            "ok": False,
            "error": {
                "category": resolved_category,
                "type": exc.__class__.__name__,
                "message": str(exc),
                "model": self.model_name,
            },
        }

        if isinstance(exc, ValidationError):
            payload["error"]["details"] = exc.errors()
        return payload

    @staticmethod
    def _infer_mcp_error_category(exc: Exception) -> str:
        if isinstance(exc, ValidationError):
            return "payload_error"

        message = str(exc).lower()
        if "numba" in message or "compile" in message or "compiled model" in message:
            return "compile_error"
        if isinstance(exc, ValueError):
            return "configuration_error"
        return "simulation_error"

    def _clamp_states(self, states: Any) -> FloatArray:
        vector = np.asarray(states, dtype=np.float64).reshape(-1)
        lower = np.asarray(self.store_min, dtype=np.float64).reshape(-1)
        upper = np.asarray(self.store_max, dtype=np.float64).reshape(-1)
        return np.clip(vector, lower, upper)

    def _normalize_store_bounds(
        self,
        value: Any,
        fill_value: float,
        field_name: str,
    ) -> FloatArray:
        if value is None:
            return np.full(self.num_stores, fill_value, dtype=np.float64)

        vector = np.asarray(value, dtype=np.float64).reshape(-1)
        if vector.size != self.num_stores:
            raise ValueError(f"{field_name} must have {self.num_stores} elements")
        return np.ascontiguousarray(vector)

    def _solver_guess(
        self, iteration: int, initial_guess: FloatArray, previous_states: FloatArray
    ) -> FloatArray:
        if iteration == 1:
            return initial_guess
        if iteration == 2:
            return previous_states
        if iteration == 3:
            return np.maximum(-2e4, self.store_min)
        if iteration == 4:
            return np.minimum(2e4, self.store_max)
        noise = np.random.randn(self.num_stores) * previous_states / 10
        return np.maximum(0.0, previous_states + noise)

    def _set_active_step(self, runtime: RuntimeContext, step_index: int) -> None:
        runtime.active_step = int(step_index)
        self.t = int(step_index)

    def _sum_routing_storage(self, routing_state: Any) -> float:
        if routing_state is None:
            return 0.0

        pending_total = getattr(routing_state, "pending_total", None)
        if callable(pending_total):
            return float(pending_total())

        if isinstance(routing_state, tuple) and len(routing_state) == 2:
            return float(np.sum(np.asarray(routing_state[1], dtype=np.float64)))

        if isinstance(routing_state, (list, tuple)):
            return float(sum(self._sum_routing_storage(item) for item in routing_state))

        return 0.0

    def _require_runtime_context(self) -> RuntimeContext:
        if self._runtime_context is None:
            raise RuntimeError("Runtime context is not initialised. Call run() first.")
        return self._runtime_context

    def _reset_if_allowed(self) -> None:
        if self._suspend_reset == 0:
            self.reset()

    @abstractmethod
    def init(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        raise NotImplementedError

    def step(self) -> None:
        pass
