from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.auxiliary.unit_hydro import (
    DoubleUHState,
    half_hydrograph,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.fluxes import baseflow_1, evap_3, percolation_2, saturation_3, split_1
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _make_flexb_uh(duration: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(duration, delta_t, power=1.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _flexb_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _flexb_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _flexb_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh1_weights: FloatArray,
    uh1_pending: FloatArray,
    _uh2_weights: FloatArray,
    uh2_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    s1max = float(theta[0])
    beta = float(theta[1])
    d = float(theta[2])
    percmax = float(theta[3])
    lp = float(theta[4])
    kf = float(theta[7])
    ks = float(theta[8])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ru = saturation_3(S1, s1max, beta, P)
    flux_eur = evap_3(lp, S1, s1max, Ep, delta_t)
    flux_ps = percolation_2(percmax, S1, s1max, delta_t)
    flux_rf = split_1(1.0 - d, P - flux_ru)
    flux_rs = split_1(d, P - flux_ru)
    flux_rfl = _flexb_route_current(uh1_pending)
    flux_rsl = _flexb_route_current(uh2_pending)
    flux_qf = baseflow_1(kf, S2)
    flux_qs = baseflow_1(ks, S3)

    out_dS[0] = flux_ru - flux_eur - flux_ps
    out_dS[1] = flux_rfl - flux_qf
    out_dS[2] = flux_rsl - flux_qs

    out_fluxes[0] = flux_ru
    out_fluxes[1] = flux_eur
    out_fluxes[2] = flux_ps
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_rs
    out_fluxes[5] = flux_rfl
    out_fluxes[6] = flux_rsl
    out_fluxes[7] = flux_qf
    out_fluxes[8] = flux_qs


class flexb(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 9
        self.num_params = 9
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 0, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0, 10],
                [0, 1],
                [0, 20],
                [0.05, 0.95],
                [1, 5],
                [1, 15],
                [0, 1],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ru", "eur", "ps", "rf", "rs", "rfl", "rsl", "qf", "qs"]
        self.flux_groups = {"Ea": 2, "Q": [8, 9]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        uh1 = _make_flexb_uh(float(theta[5]), float(self.delta_t))
        uh2 = _make_flexb_uh(float(theta[6]), float(self.delta_t))
        routing_state = DoubleUHState(
            uh1_weights=uh1,
            uh1_pending=np.zeros_like(uh1),
            uh2_weights=uh2,
            uh2_pending=np.zeros_like(uh2),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("flexb requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = runtime.routing_state
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexb routing state is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                routing.uh1_weights,
                routing.uh1_pending,
                routing.uh2_weights,
                routing.uh2_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = runtime.routing_state if runtime is not None else self.routing_state
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexb routing state is not initialised")

        _flexb_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh1_weights,
            routing.uh1_pending,
            routing.uh2_weights,
            routing.uh2_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_flexb_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_flexb_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "flexb does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "flexb does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = (
            self.runtime_context.routing_state
            if self.runtime_context is not None
            else self.routing_state
        )
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexb routing state is not initialised")

        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        fluxes = self.fluxes[self.t]
        _flexb_update_uh_inplace(
            routing.uh1_weights, routing.uh1_pending, float(fluxes[3])
        )
        _flexb_update_uh_inplace(
            routing.uh2_weights, routing.uh2_pending, float(fluxes[2] + fluxes[4])
        )
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
