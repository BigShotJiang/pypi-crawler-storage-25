from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _penman_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    smax = float(theta[0])
    phi = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_1(S1, Ep, delta_t)
    flux_qex = saturation_1(P, S1, smax)
    flux_u1 = split_1(phi, flux_qex)
    flux_q12 = split_1(1.0 - phi, flux_qex)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_u2 = saturation_9(flux_q12, S2, 0.01)
    flux_q = baseflow_1(k1, S3)

    out_dS[0] = P - flux_ea - flux_qex
    out_dS[1] = flux_et + flux_u2 - flux_q12
    out_dS[2] = flux_u1 + flux_u2 - flux_q

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qex
    out_fluxes[2] = flux_u1
    out_fluxes[3] = flux_q12
    out_fluxes[4] = flux_et
    out_fluxes[5] = flux_u2
    out_fluxes[6] = flux_q


class penman(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 7
        self.num_params = 4
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qex", "u1", "q12", "et", "u2", "q"]
        self.flux_groups = {"Ea": [1, 5], "Q": [7]}
        self.StoreSigns = np.array([1.0, -1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("penman requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _penman_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_penman_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_penman_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
