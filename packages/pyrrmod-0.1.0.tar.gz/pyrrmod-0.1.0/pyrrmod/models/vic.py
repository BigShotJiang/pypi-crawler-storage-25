from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_5,
    effective_1,
    evap_7,
    excess_1,
    interception_1,
    percolation_5,
    phenology_2,
    saturation_1,
    saturation_2,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _vic_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    ibar = float(theta[0])
    idelta = float(theta[1])
    ishift = float(theta[2])
    stot = float(theta[3])
    fsm = float(theta[4])
    b = float(theta[5])
    k1 = float(theta[6])
    c1 = float(theta[7])
    k2 = float(theta[8])
    c2 = float(theta[9])

    smmax = fsm * stot
    gwmax = (1.0 - fsm) * stot
    tmax = 365.25

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    aux_imax = phenology_2(ibar, idelta, ishift, step_index + 1, tmax, delta_t)
    flux_ei = evap_7(S1, aux_imax, Ep, delta_t)
    flux_peff = interception_1(P, S1, aux_imax)
    flux_iex = excess_1(S1, aux_imax, delta_t)
    flux_qie = saturation_2(S2, smmax, b, flux_peff + flux_iex)
    flux_inf = effective_1(flux_peff + flux_iex, flux_qie)
    flux_et1 = evap_7(S2, smmax, max(0.0, Ep - flux_ei), delta_t)
    flux_qex1 = saturation_1(flux_inf, S2, smmax)
    flux_pc = percolation_5(k1, c1, S2, smmax, delta_t)
    flux_et2 = evap_7(S3, gwmax, max(0.0, Ep - flux_ei - flux_et1), delta_t)
    flux_qex2 = saturation_1(flux_pc, S3, gwmax)
    flux_qb = baseflow_5(k2, c2, S3, gwmax, delta_t)

    out_dS[0] = P - flux_ei - flux_peff - flux_iex
    out_dS[1] = flux_inf - flux_et1 - flux_qex1 - flux_pc
    out_dS[2] = flux_pc - flux_et2 - flux_qex2 - flux_qb

    out_fluxes[0] = flux_ei
    out_fluxes[1] = flux_peff
    out_fluxes[2] = flux_iex
    out_fluxes[3] = flux_qie
    out_fluxes[4] = flux_inf
    out_fluxes[5] = flux_et1
    out_fluxes[6] = flux_qex1
    out_fluxes[7] = flux_pc
    out_fluxes[8] = flux_et2
    out_fluxes[9] = flux_qex2
    out_fluxes[10] = flux_qb


class vic(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 11
        self.num_params = 10
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0.1, 5],
                [0, 1],
                [1, 365],
                [1, 2000],
                [0.01, 0.99],
                [0, 10],
                [0, 1],
                [0, 10],
                [0, 1],
                [1, 5],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = [
            "ei",
            "peff",
            "iex",
            "qie",
            "inf",
            "et1",
            "qex1",
            "pc",
            "et2",
            "qex2",
            "qb",
        ]
        self.flux_groups = {"Ea": [1, 6, 9], "Q": [4, 7, 10, 11]}

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("vic requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _vic_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_vic_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_vic_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
