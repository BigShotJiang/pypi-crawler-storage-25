from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    depression_1,
    evap_1,
    evap_2,
    exchange_1,
    exchange_3,
    infiltration_1,
    infiltration_2,
    interception_1,
    interflow_1,
    recharge_1,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _modhydrolog_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    insc = float(theta[0])
    coeff = float(theta[1])
    sq = float(theta[2])
    smsc = float(theta[3])
    sub = float(theta[4])
    crak = float(theta[5])
    em = float(theta[6])
    dsc = float(theta[7])
    ads = float(theta[8])
    md = float(theta[9])
    vcond = float(theta[10])
    dlev = float(theta[11])
    k1 = float(theta[12])
    k2 = float(theta[13])
    k3 = float(theta[14])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_Ei = evap_1(S1, Ep, delta_t)
    flux_EXC = interception_1(P, S1, insc)
    flux_INF = infiltration_1(coeff, sq, S2, smsc, flux_EXC)
    flux_INT = interflow_1(sub, S2, smsc, flux_INF)
    flux_REC = recharge_1(crak, S2, smsc, flux_INF - flux_INT)
    flux_SMF = flux_INF - flux_INT - flux_REC
    flux_Et = evap_2(em, S2, smsc, Ep, delta_t)
    flux_GWF = saturation_1(flux_SMF, S2, smsc)
    flux_RUN = flux_EXC - flux_INF
    flux_TRAP = depression_1(ads, md, S3, dsc, flux_RUN, delta_t)
    flux_Ed = evap_1(S3, ads * Ep, delta_t)
    flux_DINF = ads * infiltration_2(coeff, sq, S2, smsc, flux_SMF, S3, delta_t)
    flux_SEEP = exchange_3(vcond, S4, dlev)
    flux_SRUN = flux_RUN - flux_TRAP
    flux_FLOW = exchange_1(k1, k2, k3, S4, flux_SRUN, delta_t)
    flux_Q = baseflow_1(1, S5)

    out_dS[0] = P - flux_Ei - flux_EXC
    out_dS[1] = flux_SMF + flux_DINF - flux_Et - flux_GWF
    out_dS[2] = flux_TRAP - flux_Ed - flux_DINF
    out_dS[3] = flux_REC + flux_GWF - flux_SEEP - flux_FLOW
    out_dS[4] = flux_SRUN + flux_INT + flux_FLOW - flux_Q

    out_fluxes[0] = flux_Ei
    out_fluxes[1] = flux_EXC
    out_fluxes[2] = flux_INF
    out_fluxes[3] = flux_INT
    out_fluxes[4] = flux_REC
    out_fluxes[5] = flux_SMF
    out_fluxes[6] = flux_Et
    out_fluxes[7] = flux_GWF
    out_fluxes[8] = flux_TRAP
    out_fluxes[9] = flux_Ed
    out_fluxes[10] = flux_DINF
    out_fluxes[11] = flux_SEEP
    out_fluxes[12] = flux_FLOW
    out_fluxes[13] = flux_Q
    out_fluxes[14] = flux_RUN
    out_fluxes[15] = flux_SRUN


class modhydrolog(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 16
        self.num_params = 15
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [1, 1, 1, 0, 0],
                [1, 1, 1, 1, 0],
                [1, 1, 1, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [0, 5],
                [0, 600],
                [0, 15],
                [1, 2000],
                [0, 1],
                [0, 1],
                [0, 20],
                [0, 50],
                [0, 1],
                [0.99, 1],
                [0, 0.5],
                [-10, 10],
                [0, 1],
                [0, 1],
                [0, 100],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "Ei",
            "EXC",
            "INF",
            "INT",
            "REC",
            "SMF",
            "Et",
            "GWF",
            "TRAP",
            "Ed",
            "DINF",
            "SEEP",
            "FLOW",
            "Q",
            "RUN",
            "SRUN",
        ]
        self.flux_groups = {"Ea": [1, 7, 10], "Q": [14], "GWseepage": 12}

    def init(self) -> None:
        self.store_min[3] = -np.inf

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("modhydrolog requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _modhydrolog_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_modhydrolog_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_modhydrolog_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
