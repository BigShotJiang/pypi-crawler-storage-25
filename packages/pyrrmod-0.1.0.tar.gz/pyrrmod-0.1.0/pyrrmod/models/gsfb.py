from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    baseflow_9,
    evap_20,
    interflow_11,
    recharge_5,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _gsfb_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    c = float(theta[0])
    ndc = float(theta[1])
    smax = float(theta[2])
    emax = float(theta[3])
    frate = float(theta[4])
    b = float(theta[5])
    dpf = float(theta[6])
    sdrmax = float(theta[7])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    threshold = ndc * smax
    flux_ea = evap_20(emax, ndc, S1, smax, Ep, delta_t)
    flux_qs = saturation_1(P, S1, smax)
    flux_f = interflow_11(frate, threshold, S1, delta_t)
    flux_qb = baseflow_9(b * dpf, sdrmax, S2)
    flux_dp = baseflow_1((1.0 - b) * dpf, S2)
    flux_qdr = recharge_5(c, threshold, S3, S1)

    out_dS[0] = P + flux_qdr - flux_ea - flux_qs - flux_f
    out_dS[1] = flux_f - flux_qb - flux_dp
    out_dS[2] = flux_dp - flux_qdr

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qs
    out_fluxes[2] = flux_f
    out_fluxes[3] = flux_qb
    out_fluxes[4] = flux_dp
    out_fluxes[5] = flux_qdr


class gsfb(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 6
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 0, 1], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 1],
                [0.05, 0.95],
                [1, 2000],
                [0, 20],
                [0, 200],
                [0, 1],
                [0, 1],
                [1, 300],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qs", "f", "qb", "dp", "qdr"]
        self.flux_groups = {"Ea": 1, "Q": [2, 4]}

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("gsfb requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _gsfb_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_gsfb_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_gsfb_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
