from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.auxiliary.unit_hydro import (
    delay_hydrograph,
    half_hydrograph,
    TripleUHState,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.fluxes import evap_12, saturation_5, split_1
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _make_ihacres_half_uh(duration: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(duration, delta_t, power=1.0)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _make_ihacres_delay_uh(delay: float, delta_t: float) -> FloatArray:
    weights, _ = delay_hydrograph(delay, delta_t)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _ihacres_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _ihacres_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _ihacres_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh1_weights: FloatArray,
    uh1_pending: FloatArray,
    _uh2_weights: FloatArray,
    uh2_pending: FloatArray,
    _uh3_weights: FloatArray,
    uh3_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    lp = float(theta[0])
    d = float(theta[1])
    p = float(theta[2])
    alpha = float(theta[3])

    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_12(S1, lp, Ep)
    flux_u = saturation_5(S1, d, p, P)
    flux_uq = split_1(alpha, flux_u)
    flux_us = split_1(1.0 - alpha, flux_u)
    flux_xq = _ihacres_route_current(uh1_pending)
    flux_xs = _ihacres_route_current(uh2_pending)
    flux_xt = _ihacres_route_current(uh3_pending)

    out_dS[0] = -P + flux_ea + flux_u

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_u
    out_fluxes[2] = flux_uq
    out_fluxes[3] = flux_us
    out_fluxes[4] = flux_xq
    out_fluxes[5] = flux_xs
    out_fluxes[6] = flux_xt


class ihacres(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 7
        self.num_params = 7
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [1, 2000], [0, 10], [0, 1], [1, 700], [1, 700], [0, 119]],
            dtype=np.float64,
        )
        self.store_names = ["S1"]
        self.flux_names = ["Ea", "u", "uq", "us", "xq", "xs", "Qt"]
        self.flux_groups = {"Ea": 1, "Q": 7}
        self.StoreSigns = np.array([-1.0], dtype=np.float64)

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        delta_t = float(self.delta_t)
        uh1 = _make_ihacres_half_uh(float(theta[4]), delta_t)
        uh2 = _make_ihacres_half_uh(float(theta[5]), delta_t)
        uh3 = _make_ihacres_delay_uh(float(theta[6]), delta_t)
        routing_state = TripleUHState(
            uh1_weights=uh1,
            uh1_pending=np.zeros_like(uh1),
            uh2_weights=uh2,
            uh2_pending=np.zeros_like(uh2),
            uh3_weights=uh3,
            uh3_pending=np.zeros_like(uh3),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("ihacres requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = runtime.routing_state
        if not isinstance(routing, TripleUHState):
            raise RuntimeError("ihacres routing state is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                routing.uh1_weights,
                routing.uh1_pending,
                routing.uh2_weights,
                routing.uh2_pending,
                routing.uh3_weights,
                routing.uh3_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = runtime.routing_state if runtime is not None else self.routing_state
        if not isinstance(routing, TripleUHState):
            raise RuntimeError("ihacres routing state is not initialised")

        _ihacres_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh1_weights,
            routing.uh1_pending,
            routing.uh2_weights,
            routing.uh2_pending,
            routing.uh3_weights,
            routing.uh3_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_ihacres_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_ihacres_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "ihacres does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "ihacres does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = (
            self.runtime_context.routing_state
            if self.runtime_context is not None
            else self.routing_state
        )
        if not isinstance(routing, TripleUHState):
            raise RuntimeError("ihacres routing state is not initialised")

        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        fluxes = self.fluxes[self.t]
        _ihacres_update_uh_inplace(
            routing.uh1_weights, routing.uh1_pending, float(fluxes[2])
        )
        _ihacres_update_uh_inplace(
            routing.uh2_weights, routing.uh2_pending, float(fluxes[3])
        )
        _ihacres_update_uh_inplace(
            routing.uh3_weights, routing.uh3_pending, float(fluxes[4] + fluxes[5])
        )
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
