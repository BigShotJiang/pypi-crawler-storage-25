from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_1, interflow_8, recharge_3
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _tank_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    a0 = float(theta[0])
    b0 = float(theta[1])
    c0 = float(theta[2])
    a1 = float(theta[3])
    fa = float(theta[4])
    fb = float(theta[5])
    fc = float(theta[6])
    fd = float(theta[7])
    st = float(theta[8])
    f2 = float(theta[9])
    f1 = float(theta[10])
    f3 = float(theta[11])

    t2 = f2 * st
    t1 = t2 + f1 * (st - t2)
    t3 = f3 * (st - t1)
    t4 = st - t1 - t3
    a2 = fa * a1
    b1 = fb * a2
    c1 = fc * b1
    d1 = fd * c1

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_y1 = interflow_8(S1, a1, t1)
    flux_y2 = interflow_8(S1, a2, t2)
    flux_y3 = interflow_8(S2, b1, t3)
    flux_y4 = interflow_8(S3, c1, t4)
    flux_y5 = baseflow_1(d1, S4)
    flux_e1 = evap_1(S1, Ep, delta_t)
    flux_e2 = evap_1(S2, max(0.0, Ep - flux_e1), delta_t)
    flux_e3 = evap_1(S3, max(0.0, Ep - flux_e1 - flux_e2), delta_t)
    flux_e4 = evap_1(S4, max(0.0, Ep - flux_e1 - flux_e2 - flux_e3), delta_t)
    flux_f12 = recharge_3(a0, S1)
    flux_f23 = recharge_3(b0, S2)
    flux_f34 = recharge_3(c0, S3)

    out_dS[0] = P - flux_e1 - flux_f12 - flux_y1 - flux_y2
    out_dS[1] = flux_f12 - flux_e2 - flux_f23 - flux_y3
    out_dS[2] = flux_f23 - flux_e3 - flux_f34 - flux_y4
    out_dS[3] = flux_f34 - flux_e4 - flux_y5

    out_fluxes[0] = flux_y1
    out_fluxes[1] = flux_y2
    out_fluxes[2] = flux_y3
    out_fluxes[3] = flux_y4
    out_fluxes[4] = flux_y5
    out_fluxes[5] = flux_e1
    out_fluxes[6] = flux_e2
    out_fluxes[7] = flux_e3
    out_fluxes[8] = flux_e4
    out_fluxes[9] = flux_f12
    out_fluxes[10] = flux_f23
    out_fluxes[11] = flux_f34


class tank(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 12
        self.num_params = 12
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [1, 1, 1, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [1, 2000],
                [0.01, 0.99],
                [0.01, 0.99],
                [0.01, 0.99],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "y1",
            "y2",
            "y3",
            "y4",
            "y5",
            "e1",
            "e2",
            "e3",
            "e4",
            "f12",
            "f23",
            "f34",
        ]
        self.flux_groups = {"Ea": [6, 7, 8, 9], "Q": [1, 2, 3, 4, 5]}

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("tank requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _tank_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_tank_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_tank_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
