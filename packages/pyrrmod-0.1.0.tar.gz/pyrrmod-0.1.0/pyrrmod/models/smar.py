from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    effective_1,
    evap_13,
    evap_14,
    infiltration_4,
    saturation_1,
    saturation_6,
    split_1,
)
from pyrrmod.auxiliary.unit_hydro import (
    gamma_hydrograph,
    SingleUHState,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _make_smar_uh(n: float, k: float, delta_t: float) -> FloatArray:
    weights, _ = gamma_hydrograph(n, k, delta_t)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _smar_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _smar_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _smar_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh_weights: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weights in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    h = float(theta[0])
    y = float(theta[1])
    smax = float(theta[2])
    c = float(theta[3])
    g = float(theta[4])
    kg = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])
    S6 = float(states[5])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pstar = effective_1(P, Ep)
    flux_estar = effective_1(Ep, P)
    flux_evap = min(Ep, P)
    flux_r1 = saturation_6(h, S1 + S2 + S3 + S4 + S5, smax, flux_pstar)
    flux_i = infiltration_4(flux_pstar - flux_r1, y)
    flux_r2 = effective_1(flux_pstar - flux_r1, flux_i)
    flux_e1 = evap_13(c, 0, flux_estar, S1, delta_t)
    flux_e2 = evap_14(c, 1, flux_estar, S2, S1, 0.1, delta_t)
    flux_e3 = evap_14(c, 2, flux_estar, S3, S2, 0.1, delta_t)
    flux_e4 = evap_14(c, 3, flux_estar, S4, S3, 0.1, delta_t)
    flux_e5 = evap_14(c, 4, flux_estar, S5, S4, 0.1, delta_t)
    flux_q1 = saturation_1(flux_i, S1, smax / 5.0)
    flux_q2 = saturation_1(flux_q1, S2, smax / 5.0)
    flux_q3 = saturation_1(flux_q2, S3, smax / 5.0)
    flux_q4 = saturation_1(flux_q3, S4, smax / 5.0)
    flux_r3 = saturation_1(flux_q4, S5, smax / 5.0)
    flux_rg = split_1(g, flux_r3)
    flux_r3star = split_1(1.0 - g, flux_r3)
    flux_qr = _smar_route_current(uh_pending)
    flux_qg = baseflow_1(kg, S6)

    out_dS[0] = flux_i - flux_e1 - flux_q1
    out_dS[1] = flux_q1 - flux_e2 - flux_q2
    out_dS[2] = flux_q2 - flux_e3 - flux_q3
    out_dS[3] = flux_q3 - flux_e4 - flux_q4
    out_dS[4] = flux_q4 - flux_e5 - flux_r3
    out_dS[5] = flux_rg - flux_qg

    out_fluxes[0] = flux_pstar
    out_fluxes[1] = flux_estar
    out_fluxes[2] = flux_evap
    out_fluxes[3] = flux_r1
    out_fluxes[4] = flux_i
    out_fluxes[5] = flux_r2
    out_fluxes[6] = flux_e1
    out_fluxes[7] = flux_e2
    out_fluxes[8] = flux_e3
    out_fluxes[9] = flux_e4
    out_fluxes[10] = flux_e5
    out_fluxes[11] = flux_q1
    out_fluxes[12] = flux_q2
    out_fluxes[13] = flux_q3
    out_fluxes[14] = flux_q4
    out_fluxes[15] = flux_r3
    out_fluxes[16] = flux_rg
    out_fluxes[17] = flux_r3star
    out_fluxes[18] = flux_qr
    out_fluxes[19] = flux_qg


class smar(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 6
        self.num_fluxes = 20
        self.num_params = 8
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0, 0],
                [1, 1, 0, 0, 0, 0],
                [1, 1, 1, 0, 0, 0],
                [1, 1, 1, 1, 0, 0],
                [1, 1, 1, 1, 1, 0],
                [1, 1, 1, 1, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [[0, 1], [0, 200], [1, 2000], [0, 1], [0, 1], [0, 1], [1, 10], [1, 120]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5", "S6"]
        self.flux_names = [
            "pstar",
            "estar",
            "evap",
            "r1",
            "i",
            "r2",
            "e1",
            "e2",
            "e3",
            "e4",
            "e5",
            "q1",
            "q2",
            "q3",
            "q4",
            "r3",
            "rg",
            "r3star",
            "qr",
            "qg",
        ]
        self.flux_groups = {"Ea": [3, 7, 8, 9, 10, 11], "Q": [19, 20]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        n = float(theta[6])
        nk = float(theta[7])
        weights = _make_smar_uh(n, nk / n, float(self.delta_t))
        routing_state = SingleUHState(
            uh_weights=weights,
            uh_pending=np.zeros_like(weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("smar requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = runtime.routing_state
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("smar routing state is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        uh_weights = routing.uh_weights
        uh_pending = routing.uh_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_weights,
                uh_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = runtime.routing_state if runtime is not None else self.routing_state
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("smar routing state is not initialised")

        _smar_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh_weights,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_smar_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_smar_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "smar does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "smar does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = (
            self.runtime_context.routing_state
            if self.runtime_context is not None
            else self.routing_state
        )
        if not isinstance(routing, SingleUHState):
            raise RuntimeError("smar routing state is not initialised")

        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        inflow = float(
            self.fluxes[self.t, 3] + self.fluxes[self.t, 5] + self.fluxes[self.t, 17]
        )
        _smar_update_uh_inplace(routing.uh_weights, routing.uh_pending, inflow)
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
