from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_3,
    interception_1,
    percolation_2,
    saturation_3,
    split_1,
)
from pyrrmod.auxiliary.unit_hydro import (
    DoubleUHState,
    half_hydrograph,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _make_flexi_uh(duration: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(duration, delta_t, power=1.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _flexi_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _flexi_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _flexi_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh1_weights: FloatArray,
    uh1_pending: FloatArray,
    _uh2_weights: FloatArray,
    uh2_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    smax = float(theta[0])
    beta = float(theta[1])
    d = float(theta[2])
    percmax = float(theta[3])
    lp = float(theta[4])
    kf = float(theta[7])
    ks = float(theta[8])
    imax = float(theta[9])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_peff = interception_1(P, S1, imax)
    flux_ei = evap_1(S1, Ep, delta_t)
    flux_ru = saturation_3(S2, smax, beta, flux_peff)
    flux_eur = evap_3(lp, S2, smax, Ep, delta_t)
    flux_ps = percolation_2(percmax, S2, smax, delta_t)
    flux_rf = split_1(1.0 - d, flux_peff - flux_ru)
    flux_rs = split_1(d, flux_peff - flux_ru)
    flux_rfl = _flexi_route_current(uh1_pending)
    flux_rsl = _flexi_route_current(uh2_pending)
    flux_qf = baseflow_1(kf, S3)
    flux_qs = baseflow_1(ks, S4)

    out_dS[0] = P - flux_peff - flux_ei
    out_dS[1] = flux_ru - flux_eur - flux_ps
    out_dS[2] = flux_rfl - flux_qf
    out_dS[3] = flux_rsl - flux_qs

    out_fluxes[0] = flux_peff
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_ru
    out_fluxes[3] = flux_eur
    out_fluxes[4] = flux_ps
    out_fluxes[5] = flux_rf
    out_fluxes[6] = flux_rs
    out_fluxes[7] = flux_rfl
    out_fluxes[8] = flux_rsl
    out_fluxes[9] = flux_qf
    out_fluxes[10] = flux_qs


class flexi(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 11
        self.num_params = 10
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [1, 1, 0, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0, 10],
                [0, 1],
                [0, 20],
                [0.05, 0.95],
                [1, 5],
                [1, 15],
                [0, 1],
                [0, 1],
                [0, 5],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "peff",
            "ei",
            "ru",
            "eur",
            "ps",
            "rf",
            "rs",
            "rfl",
            "rsl",
            "qf",
            "qs",
        ]
        self.flux_groups = {"Ea": [2, 4], "Q": [10, 11]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        uh1 = _make_flexi_uh(float(theta[5]), float(self.delta_t))
        uh2 = _make_flexi_uh(float(theta[6]), float(self.delta_t))
        routing_state = DoubleUHState(
            uh1_weights=uh1,
            uh1_pending=np.zeros_like(uh1),
            uh2_weights=uh2,
            uh2_pending=np.zeros_like(uh2),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("flexi requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = runtime.routing_state
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexi routing state is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                routing.uh1_weights,
                routing.uh1_pending,
                routing.uh2_weights,
                routing.uh2_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = runtime.routing_state if runtime is not None else self.routing_state
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexi routing state is not initialised")

        _flexi_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh1_weights,
            routing.uh1_pending,
            routing.uh2_weights,
            routing.uh2_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_flexi_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_flexi_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "flexi does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "flexi does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = (
            self.runtime_context.routing_state
            if self.runtime_context is not None
            else self.routing_state
        )
        if not isinstance(routing, DoubleUHState):
            raise RuntimeError("flexi routing state is not initialised")

        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        fluxes = self.fluxes[self.t]
        _flexi_update_uh_inplace(
            routing.uh1_weights, routing.uh1_pending, float(fluxes[5])
        )
        _flexi_update_uh_inplace(
            routing.uh2_weights, routing.uh2_pending, float(fluxes[4] + fluxes[6])
        )
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
