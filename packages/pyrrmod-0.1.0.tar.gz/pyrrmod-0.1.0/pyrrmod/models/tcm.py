from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    abstraction_1,
    baseflow_1,
    baseflow_6,
    effective_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _tcm_prepare_theta(theta: FloatArray, precip: FloatArray) -> FloatArray:
    prepared = np.empty(theta.size + 1, dtype=np.float64)
    prepared[: theta.size] = theta
    prepared[theta.size] = float(theta[4]) * float(np.mean(precip))
    return prepared


def _tcm_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    phi = float(theta[0])
    rc = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])
    k2 = float(theta[5])
    ca = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = effective_1(P, Ep)
    flux_en = P - flux_pn
    flux_pby = split_1(phi, flux_pn)
    flux_pin = split_1(1.0 - phi, flux_pn)
    flux_ea = evap_1(S1, Ep, delta_t)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_qex1 = saturation_1(flux_pin, S1, rc)
    flux_qex2 = saturation_9(flux_qex1, S2, 0.01)
    flux_quz = baseflow_1(k1, S3)
    flux_a = abstraction_1(ca)
    flux_q = baseflow_6(k2, 0, S4, delta_t)

    out_dS[0] = flux_pin - flux_ea - flux_qex1
    out_dS[1] = flux_et + flux_qex2 - flux_qex1
    out_dS[2] = flux_qex2 + flux_pby - flux_quz
    out_dS[3] = flux_quz - flux_a - flux_q

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_pby
    out_fluxes[3] = flux_pin
    out_fluxes[4] = flux_ea
    out_fluxes[5] = flux_et
    out_fluxes[6] = flux_qex1
    out_fluxes[7] = flux_qex2
    out_fluxes[8] = flux_quz
    out_fluxes[9] = flux_a
    out_fluxes[10] = flux_q


class tcm(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 11
        self.num_params = 6
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [0, 0, 1, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [[0, 1], [1, 2000], [0, 1], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "pn",
            "en",
            "pby",
            "pin",
            "ea",
            "et",
            "qex1",
            "qex2",
            "quz",
            "a",
            "q",
        ]
        self.flux_groups = {"Ea": [2, 5, 6], "Q": 11, "Abstraction": 10}
        self.StoreSigns = np.array([1.0, -1.0, 1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                _tcm_prepare_theta(
                    np.asarray(runtime.theta, dtype=np.float64), runtime.precip
                ),
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("tcm requires theta, delta_t, and input_climate")

        theta = np.asarray(self.theta, dtype=np.float64)
        return (
            None,
            _tcm_prepare_theta(theta, climate.precip),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = _tcm_prepare_theta(
            np.asarray(runtime.theta, dtype=np.float64), runtime.precip
        )
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _tcm_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_tcm_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_tcm_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
