from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

from pyrrmod.auxiliary.unit_hydro import (
    full_hydrograph,
    half_hydrograph,
    route_uh_current,
    update_uh_inplace,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


@dataclass(slots=True, kw_only=True)
class GR4JRoutingState:
    q9_weights: FloatArray
    q9_pending: FloatArray
    q1_weights: FloatArray
    q1_pending: FloatArray

    def pending_total(self) -> float:
        return float(np.sum(self.q9_pending) + np.sum(self.q1_pending))

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [
            (self.q9_weights, self.q9_pending),
            (self.q1_weights, self.q1_pending),
        ]


def _make_gr4j_uh1(x4: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(x4, delta_t, power=2.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _make_gr4j_uh2(x4: float, delta_t: float) -> FloatArray:
    weights, _ = full_hydrograph(2.0 * x4, delta_t, power=2.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _gr4j_route_current(uh_pending: FloatArray) -> float:
    return route_uh_current(uh_pending)


def _gr4j_update_uh_inplace(
    uh_weights: FloatArray,
    uh_pending: FloatArray,
    inflow: float,
) -> None:
    update_uh_inplace(uh_weights, uh_pending, inflow)


def _gr4j_saturation_quadratic(
    storage: float,
    storage_max: float,
    inflow: float,
) -> float:
    return max(0.0, (1.0 - (storage / storage_max) ** 2) * inflow)


def _gr4j_evap_quadratic(
    storage: float,
    storage_max: float,
    evap_pot: float,
) -> float:
    scaled = storage / storage_max
    return max(0.0, (2.0 * scaled - scaled**2) * evap_pot)


def _gr4j_percolation(storage: float, storage_max: float) -> float:
    return storage_max ** (-4.0) / 4.0 * (4.0 / 9.0) ** 4 * storage**5


def _gr4j_exchange(storage: float, storage_max: float, x2: float) -> float:
    return x2 * ((max(storage, 0.0) / storage_max) ** 3.5)


def _gr4j_baseflow(storage: float, storage_max: float) -> float:
    return storage_max ** (-4.0) / 4.0 * storage**5


def _gr4j_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _q9_weights: FloatArray,
    q9_pending: FloatArray,
    _q1_weights: FloatArray,
    q1_pending: FloatArray,
    out_states: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    x1 = float(theta[0])
    x2 = float(theta[1])
    x3 = float(theta[2])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = max(P - Ep, 0.0)
    flux_en = max(Ep - P, 0.0)
    flux_ef = P - flux_pn
    flux_ps = _gr4j_saturation_quadratic(S1, x1, flux_pn)
    flux_es = _gr4j_evap_quadratic(S1, x1, flux_en)
    flux_perc = _gr4j_percolation(S1, x1)
    flux_q9 = _gr4j_route_current(q9_pending) / delta_t
    flux_q1 = _gr4j_route_current(q1_pending) / delta_t
    flux_fr = _gr4j_exchange(S2, x3, x2)
    flux_fq = flux_fr
    flux_qr = _gr4j_baseflow(S2, x3)
    quick_component = flux_q1 + flux_fq
    quick_positive = quick_component if quick_component > 0.0 else 0.0
    flux_qt = flux_qr + quick_positive
    flux_ex = flux_fr + quick_positive - flux_q1

    dS1 = flux_ps - flux_es - flux_perc
    dS2 = flux_q9 + flux_fr - flux_qr
    out_states[0] = min(x1, max(0.0, S1 + dS1 * delta_t))
    out_states[1] = min(x3, max(0.0, S2 + dS2 * delta_t))

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_ef
    out_fluxes[3] = flux_ps
    out_fluxes[4] = flux_es
    out_fluxes[5] = flux_perc
    out_fluxes[6] = flux_q9
    out_fluxes[7] = flux_q1
    out_fluxes[8] = flux_fr
    out_fluxes[9] = flux_fq
    out_fluxes[10] = flux_qr
    out_fluxes[11] = flux_qt
    out_fluxes[12] = flux_ex


class gr4j(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 13
        self.num_params = 4
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [-20, 20], [1, 300], [0.5, 15]], dtype=np.float64
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = [
            "pn",
            "en",
            "ef",
            "ps",
            "es",
            "perc",
            "q9",
            "q1",
            "fr",
            "fq",
            "qr",
            "qt",
            "ex",
        ]
        self.flux_groups = {"Ea": [3, 5], "Q": [12], "Exchange": -13}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        x1 = float(theta[0])
        x3 = float(theta[2])
        x4 = float(theta[3])
        self.store_max = np.array([x1, x3], dtype=np.float64)

        q9_weights = _make_gr4j_uh1(x4, float(self.delta_t))
        q1_weights = _make_gr4j_uh2(x4, float(self.delta_t))
        routing_state = GR4JRoutingState(
            q9_weights=q9_weights,
            q9_pending=np.zeros_like(q9_weights),
            q1_weights=q1_weights,
            q1_pending=np.zeros_like(q1_weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("gr4j requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                routing.q9_weights,
                routing.q9_pending,
                routing.q1_weights,
                routing.q1_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_states: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_states is None:
            out_states = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if runtime is self.runtime_context and kernel is not None:
            kernel(state_vector, resolved_step, out_states, out_fluxes)
            return out_states, out_fluxes

        routing = self._require_routing_state(runtime)
        _gr4j_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.q9_weights,
            routing.q9_pending,
            routing.q1_weights,
            routing.q1_pending,
            out_states,
            out_fluxes,
        )
        return out_states, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_gr4j_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_gr4j_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_states = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_states, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        _, fluxes = self._compute_into(state_vector, step_index=self.t)
        dS = np.empty(self.num_stores, dtype=np.float64)
        dS[0] = fluxes[3] - fluxes[4] - fluxes[5]
        dS[1] = fluxes[6] + fluxes[8] - fluxes[10]
        return dS, fluxes

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "gr4j does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "gr4j does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = self._require_routing_state(self.runtime_context)
        fluxes = self.fluxes[self.t, :]
        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        inflow_volume = float(fluxes[0] - fluxes[3] + fluxes[5])
        _gr4j_update_uh_inplace(
            routing.q9_weights, routing.q9_pending, 0.9 * inflow_volume
        )
        _gr4j_update_uh_inplace(
            routing.q1_weights, routing.q1_pending, 0.1 * inflow_volume
        )
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()

    def _uses_discrete_step_solver(self) -> bool:
        return True

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if kernel is None:
            raise RuntimeError("gr4j routing kernel is not initialised")
        kernel(
            np.asarray(previous_states, dtype=np.float64),
            step_index,
            out_states,
            out_fluxes,
        )

    def _require_routing_state(
        self,
        runtime: RuntimeContext | None,
    ) -> GR4JRoutingState:
        routing = runtime.routing_state if runtime is not None else self.routing_state
        if isinstance(routing, GR4JRoutingState):
            return routing

        self.init()
        if isinstance(self.routing_state, GR4JRoutingState):
            return self.routing_state
        raise RuntimeError("gr4j routing state is not initialised")
