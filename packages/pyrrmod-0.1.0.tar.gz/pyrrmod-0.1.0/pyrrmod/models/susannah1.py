from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    baseflow_2,
    evap_5,
    evap_6,
    interflow_7,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


def _susannah1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    sb = float(theta[0])
    sfc = float(theta[1])
    m = float(theta[2])
    a = float(theta[3])
    b = float(theta[4])
    r = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ebs = evap_5(m, S1, sb, Ep, delta_t)
    flux_eveg = evap_6(m, sfc, S1, sb, Ep, delta_t)
    flux_qse = saturation_1(P, S1, sb)
    flux_qss = interflow_7(S1, sb, sfc, a, b, delta_t)
    flux_qr = baseflow_1(r, flux_qss)
    flux_qb = baseflow_2(S2, a, b, delta_t)
    flux_qt = flux_qse + (flux_qss - flux_qr) + flux_qb

    out_dS[0] = P - flux_ebs - flux_eveg - flux_qse - flux_qss
    out_dS[1] = flux_qr - flux_qb

    out_fluxes[0] = flux_ebs
    out_fluxes[1] = flux_eveg
    out_fluxes[2] = flux_qse
    out_fluxes[3] = flux_qss
    out_fluxes[4] = flux_qr
    out_fluxes[5] = flux_qb
    out_fluxes[6] = flux_qt


class susannah1(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 7
        self.num_params = 6
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0.05, 0.95], [1, 50], [0.2, 1], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = ["Ebs", "Evg", "Qse", "Qss", "qr", "Qb", "qt"]
        self.flux_groups = {"Ea": [1, 2], "Q": 7}

    def init(self) -> None:
        pass

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("susannah1 requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _susannah1_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_susannah1_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_susannah1_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        pass
