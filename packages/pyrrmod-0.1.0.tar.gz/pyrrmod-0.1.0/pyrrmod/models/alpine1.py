from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.models.base import (
    FloatArray,
    HydrologyModel,
    RuntimeContext,
)


def _temperature_logistic(
    temperature: float,
    threshold: float,
    r: float = 0.01,
) -> float:
    if (temperature - threshold) / r >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp((temperature - threshold) / r))


def _storage_logistic(
    storage: float,
    storage_max: float,
    r: float = 0.01,
    e: float = 5.0,
) -> float:
    storage_max = max(0.0, storage_max)
    if r * storage_max == 0.0:
        exponent = (storage - storage_max + r * e * storage_max) / r
    else:
        exponent = (storage - storage_max + r * e * storage_max) / (r * storage_max)

    if exponent >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp(exponent))


def _alpine1_flux_values(
    S1: float,
    S2: float,
    tt: float,
    ddf: float,
    Smax: float,
    tc: float,
    delta_t: float,
    precip_t: float,
    pet_t: float,
    temp_t: float,
) -> tuple[float, float, float, float, float, float]:
    snow_fraction = _temperature_logistic(temp_t, tt)
    flux_ps = precip_t * snow_fraction
    flux_pr = precip_t * (1.0 - snow_fraction)
    flux_qn = max(min(ddf * (temp_t - tt), S1 / delta_t), 0.0)
    flux_ea = min(S2 / delta_t, pet_t)
    flux_qse = (precip_t + flux_qn) * (1.0 - _storage_logistic(S2, Smax))
    flux_qss = tc * S2
    return flux_ps, flux_pr, flux_qn, flux_ea, flux_qse, flux_qss


def _alpine1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    ddf = float(theta[1])
    Smax = float(theta[2])
    tc = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    precip_t = float(precip[step_index])
    pet_t = float(pet[step_index])
    temp_t = float(temp[step_index])

    flux_ps, flux_pr, flux_qn, flux_ea, flux_qse, flux_qss = _alpine1_flux_values(
        S1,
        S2,
        tt,
        ddf,
        Smax,
        tc,
        delta_t,
        precip_t,
        pet_t,
        temp_t,
    )

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_ea - flux_qse - flux_qss
    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pr
    out_fluxes[2] = flux_qn
    out_fluxes[3] = flux_ea
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss


def _forcing_step_index(t: float, delta_t: float, time_steps: int) -> int:
    if time_steps <= 0:
        raise ValueError("time_steps must be positive")
    if t <= 0.0:
        return 0

    step_index = int(t / delta_t)
    if step_index >= time_steps:
        return time_steps - 1
    return step_index


class alpine1(HydrologyModel):
    """Alpine model v1 with a single shared numeric step kernel."""

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 6
        self.num_params = 4

        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [-3, 5],
                [0, 20],
                [1, 2000],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = ["ps", "pr", "qn", "ea", "qse", "qss"]
        self.flux_groups = {
            "Ea": 4,
            "Q": [5, 6],
        }

    def init(self) -> None:
        """No model-specific runtime initialization is required."""

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None, FloatArray, float, FloatArray, FloatArray, FloatArray
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError("alpine1 requires theta, delta_t, and input_climate")

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = _forcing_step_index(float(t), delta_t, time_steps)
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )

        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
        else:
            _alpine1_compute_step(
                state_vector,
                resolved_step,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )

        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_alpine1_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        try:
            from numba import njit
        except Exception as exc:
            raise RuntimeError("numba is not installed") from exc

        compiled_step = njit(cache=True)(_alpine1_compute_step)
        kernel = self._bind_kernel(compiled_step, runtime)

        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)
        return kernel

    def model_fun(self, S: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(S, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        dS, _ = self._compute_into(y, t=t, ctx=ctx)
        return dS

    def make_scipy_rhs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> Callable[[float, FloatArray], FloatArray]:
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def step(self) -> None:
        """No post-step routing update is required for alpine1."""
