import numpy as np


def smooth_threshold_storage_logistic(s, smax, r=0.01, e=5.0):
    """
    Logisitic smoother for storage threshold functions.

    Converted from MatLab to Python, 2024, RTI International
    WARRANTY. See <https://www.gnu.org/licenses/> for details.

    Smooths the transition of threshold functions of the form:
    Q = { P, if S = Smax
        { 0, if S < Smax

    By transforming the equation above to Q = f(P,S,Smax,e,r):
    Q = P * 1/ (1+exp((S-Smax+r*e*Smax)/(r*Smax)))

    Inputs:
    S       : current storage
    Smax    : maximum storage
    r       : smoothing parameter rho, default = 0.01
    e       : smoothing parameter e, default 5

    NOTE: this function only outputs the multiplier. This needs to be
    applied to the proper flux outside of this function.

    NOTE: can be applied for temperature thresholds as well (i.e. snow
    modules). This simply means that S becomes T, and Smax T0.
    """

    smax = max(0, smax)

    # Configure NumPy to raise an error on overflow
    old_settings = np.seterr(over='raise')

    # Calculate multiplier
    #bug fix: 11July2024 - SAS - nested if else statement added to prevent overflow in np.exp term
    #bug fix: 01Dec2025 - SAS - more robust handling of overflow
    if r * smax == 0:
        # if (s - smax + r * e * smax) / r >= 700:
        #     out = 0
        # else:
        #     out = 1 / (1 + np.exp((s - smax + r * e * smax) / r))
        try:
            out = 1 / (1 + np.exp((s - smax + r * e * smax) / r))
        except:
            out = 0
        finally:
            np.seterr(**old_settings) # Restore original error settings
    else:
        # if (s - smax + r * e * smax) / (r * smax) >= 700:
        #     out = 0
        # else:
        #     out = 1 / (1 + np.exp((s - smax + r * e * smax) / (r * smax)))
        try:
            out = 1 / (1 + np.exp((s - smax + r * e * smax) / (r * smax)))
        except:
            out = 0
        finally:
            np.seterr(**old_settings) # Restore original error settings
    return out


def smooth_threshold_temperature_logistic(T, Tt, r=0.01):
    """
    Logistic smoother for temperature threshold functions.

    Smooths the transition of threshold functions of the form:
    Snowfall = { P, if T <  Tt
                { 0, if T >= Tt

    By transforming the equation above to Sf = f(P, T, Tt, r):
    Sf = P * 1 / (1 + exp((T - Tt) / r))

    Inputs:

    T       : current temperature
    Tt      : threshold temperature below which snowfall occurs
    r       : smoothing parameter rho, default = 0.01

    NOTE: this function only outputs the multiplier. This needs to be
    applied to the proper flux (P in Sf equation) outside of this function.
    """
    # Calculate multiplier
    #bug fix: 11July2024 - SAS - if else statement added to prevent overflow in np.exp term

    if (T - Tt) / r >= 700:
        out = 0
    else:
        out = 1 / (1 + np.exp((T - Tt) / r))

    return out
