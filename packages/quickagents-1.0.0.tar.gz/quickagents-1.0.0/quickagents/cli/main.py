"""
QuickAgents CLI - 命令行工具

命令:
    qa read <file>           # 智能读取文件（哈希检测）
    qa write <file> <content> # 写入文件
    qa edit <file> <old> <new> # 编辑文件
    qa hash <file>           # 获取文件哈希
    qa cache stats           # 查看缓存统计
    qa cache clear           # 清空缓存
    qa memory get <key>      # 获取记忆
    qa memory set <key> <val> # 设置记忆
    qa memory search <keyword> # 搜索记忆
    qa loop check            # 检查循环模式
    qa loop reset            # 重置循环检测
    qa stats                 # 查看整体统计
    
    # 新增：Skills本地化命令
    qa feedback bug <desc>   # 记录Bug
    qa feedback improve <desc> # 记录改进建议
    qa feedback best <desc>  # 记录最佳实践
    qa feedback view [type]  # 查看收集的经验
    
    qa tdd red [test_file]   # RED阶段：运行测试（应失败）
    qa tdd green [test_file] # GREEN阶段：运行测试（应通过）
    qa tdd refactor [test_file] # REFACTOR阶段
    qa tdd stats             # TDD统计
    qa tdd coverage          # 检查覆盖率
    
    qa git status            # Git状态
    qa git check             # Pre-commit检查
    qa git commit <type> <scope> <subject> # 执行提交
    qa git push              # 推送到远程
"""

import sys
import os
import argparse
from pathlib import Path

# 添加父目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.file_manager import FileManager
from core.memory import MemoryManager
from core.loop_detector import LoopDetector
from core.reminder import Reminder
from core.cache_db import CacheDB
from skills.feedback_collector import FeedbackCollector
from skills.tdd_workflow import TDDWorkflow, TDDPhase
from skills.git_commit import GitCommit


def cmd_read(args):
    """读取文件命令"""
    fm = FileManager()
    content, changed = fm.read_if_changed(args.file)
    
    print(f"文件: {args.file}")
    print(f"状态: {'已变化/新读取' if changed else '使用缓存（节省Token）'}")
    print("-" * 50)
    print(content)


def cmd_write(args):
    """写入文件命令"""
    fm = FileManager()
    fm.write(args.file, args.content)
    print(f"✅ 已写入: {args.file}")


def cmd_edit(args):
    """编辑文件命令"""
    fm = FileManager()
    result = fm.edit(args.file, args.old, args.new)
    
    if result['success']:
        print(f"✅ 编辑成功: {args.file}")
        if result['token_saved'] > 0:
            print(f"💰 节省Token: ~{result['token_saved']}")
    else:
        print(f"❌ 编辑失败: {result['message']}")


def cmd_hash(args):
    """获取文件哈希"""
    fm = FileManager()
    hash_val = fm.get_file_hash(args.file)
    print(f"文件: {args.file}")
    print(f"哈希: {hash_val}")


def cmd_cache(args):
    """缓存管理命令"""
    db = CacheDB()
    
    if args.action == 'stats':
        stats = db.get_stats()['file_cache']
        print("📊 缓存统计")
        print(f"  缓存文件数: {stats['count']}")
        print(f"  总大小: {stats['total_kb']} KB")
    
    elif args.action == 'clear':
        count = db.clear_file_cache()
        print(f"✅ 已清空 {count} 个文件缓存")
    
    elif args.action == 'list':
        with db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT path, content_hash, size, access_count FROM file_cache')
            rows = cursor.fetchall()
            
            print("📁 缓存文件列表")
            print("-" * 80)
            for row in rows:
                print(f"  {row['path']}")
                print(f"    哈希: {row['content_hash']}, 大小: {row['size']}B, 访问: {row['access_count']}次")


def cmd_memory(args):
    """记忆管理命令"""
    memory = MemoryManager()
    
    if args.action == 'get':
        value = memory.get(args.key)
        if value is not None:
            print(f"{args.key}: {value}")
        else:
            print(f"❌ 未找到: {args.key}")
    
    elif args.action == 'set':
        memory.set_factual(args.key, args.value)
        memory.save()
        print(f"✅ 已设置: {args.key} = {args.value}")
    
    elif args.action == 'search':
        results = memory.search(args.keyword)
        print(f"🔍 搜索结果 ({len(results)} 条)")
        print("-" * 50)
        for r in results:
            print(f"  [{r['type']}] {r.get('key', r.get('category', ''))}: {r.get('value', r.get('content', ''))}")


def cmd_loop(args):
    """循环检测命令"""
    detector = LoopDetector()
    
    if args.action == 'check':
        patterns = detector.get_loop_patterns()
        if patterns:
            print("⚠️ 检测到循环模式")
            print("-" * 50)
            for p in patterns:
                print(f"  {p['tool_name']}: {p['count']}次")
                print(f"    首次: {p['first_seen']}")
                print(f"    最后: {p['last_seen']}")
        else:
            print("✅ 未检测到循环模式")
    
    elif args.action == 'reset':
        detector.reset()
        print("✅ 已重置循环检测")
    
    elif args.action == 'stats':
        stats = detector.get_stats()
        print("📊 循环检测统计")
        print(f"  检测阈值: {stats['threshold']}")
        print(f"  窗口大小: {stats['window_size']}")
        print(f"  循环模式: {stats['total_patterns']}")


def cmd_stats(args):
    """查看整体统计"""
    db = CacheDB()
    stats = db.get_stats()
    
    print("📊 QuickAgents 统计")
    print("=" * 50)
    
    print("\n📁 文件缓存")
    print(f"  缓存文件: {stats['file_cache']['count']}")
    print(f"  总大小: {stats['file_cache']['total_kb']} KB")
    
    print("\n🧠 记忆系统")
    print(f"  记忆条目: {stats['memory']['count']}")
    
    print("\n💰 Token节省")
    print(f"  估算节省: {stats['tokens']['total_saved']} tokens")


def cmd_reminder(args):
    """提醒系统命令"""
    reminder = Reminder()
    
    if args.action == 'check':
        alerts = reminder.check_alerts()
        if alerts:
            print("⚠️ 活跃提醒")
            print("-" * 50)
            for a in alerts:
                print(f"  [{a['level']}] {a['message']}")
        else:
            print("✅ 无活跃提醒")
    
    elif args.action == 'stats':
        stats = reminder.get_stats()
        print("📊 提醒系统统计")
        print(f"  工具调用: {stats['tool_calls']}")
        print(f"  错误次数: {stats['errors']}")
        print(f"  运行时间: {int(stats['elapsed_minutes'])} 分钟")
        print(f"  上下文使用: {stats['context_usage']}%")


# ==================== 新增：Skills本地化命令 ====================

def cmd_feedback(args):
    """经验收集命令"""
    collector = FeedbackCollector()
    
    if args.action == 'bug':
        success = collector.record('bug', args.description, scenario=args.scenario)
        if success:
            print(f"✅ 已记录Bug: {args.description}")
        else:
            print("ℹ️ 重复记录已忽略")
    
    elif args.action == 'improve':
        success = collector.record('improve', args.description, scenario=args.scenario)
        if success:
            print(f"✅ 已记录改进建议: {args.description}")
        else:
            print("ℹ️ 重复记录已忽略")
    
    elif args.action == 'best':
        success = collector.record('best', args.description, scenario=args.scenario)
        if success:
            print(f"✅ 已记录最佳实践: {args.description}")
        else:
            print("ℹ️ 重复记录已忽略")
    
    elif args.action == 'view':
        feedback_type = args.type if hasattr(args, 'type') and args.type else None
        feedbacks = collector.get_feedback(feedback_type, limit=20)
        
        print(f"📋 经验收集 ({len(feedbacks)} 条)")
        print("-" * 50)
        for fb in feedbacks:
            print(f"  [{fb['type']}] {fb['timestamp']}")
            print(f"    {fb['description'][:50]}...")
    
    elif args.action == 'stats':
        stats = collector.get_stats()
        print("📊 经验收集统计")
        print(f"  总计: {stats['total']} 条")
        for ftype, count in stats['by_type'].items():
            print(f"  {ftype}: {count} 条")


def cmd_tdd(args):
    """TDD工作流命令"""
    tdd = TDDWorkflow()
    
    if args.action == 'red':
        result = tdd.run_red(args.test_file)
        print(f"🔴 RED阶段: {'测试失败 ✓' if not result['passed'] else '测试通过 ⚠️'}")
        print(f"  耗时: {result['duration_ms']}ms")
        if result['passed']:
            print("  ⚠️ 测试已通过，需要先写失败的测试！")
    
    elif args.action == 'green':
        result = tdd.run_green(args.test_file)
        print(f"🟢 GREEN阶段: {'测试通过 ✓' if result['passed'] else '测试失败 ❌'}")
        print(f"  耗时: {result['duration_ms']}ms")
        if result['passed']:
            print("  ✅ 可以进入Refactor阶段")
    
    elif args.action == 'refactor':
        result = tdd.run_refactor(args.test_file)
        print(f"🔄 REFACTOR阶段: {'测试通过 ✓' if result['passed'] else '测试失败 ❌'}")
        print(f"  耗时: {result['duration_ms']}ms")
    
    elif args.action == 'stats':
        stats = tdd.get_stats()
        print("📊 TDD统计")
        print(f"  RED次数: {stats['red_count']}")
        print(f"  GREEN次数: {stats['green_count']}")
        print(f"  REFACTOR次数: {stats['refactor_count']}")
        print(f"  测试命令: {stats['test_command']}")
    
    elif args.action == 'coverage':
        result = tdd.check_coverage(threshold=80)
        print(f"📈 测试覆盖率: {result['coverage']}%")
        print(f"  达标: {'✅' if result['meets_threshold'] else '❌'}")


def cmd_git(args):
    """Git提交命令"""
    git = GitCommit()
    
    if args.action == 'status':
        status = git.get_status()
        print(f"🌿 分支: {status['branch']}")
        print(f"  领先: {status['ahead']}, 落后: {status['behind']}")
        
        if status['staged']:
            print(f"\n✅ 已暂存 ({len(status['staged'])})")
            for f in status['staged'][:5]:
                print(f"  {f}")
        
        if status['unstaged']:
            print(f"\n📝 未暂存 ({len(status['unstaged'])})")
            for f in status['unstaged'][:5]:
                print(f"  {f}")
        
        if status['untracked']:
            print(f"\n❓ 未跟踪 ({len(status['untracked'])})")
            for f in status['untracked'][:5]:
                print(f"  {f}")
    
    elif args.action == 'check':
        print("🔍 执行Pre-commit检查...")
        checks = git.run_pre_commit_checks()
        
        print(f"\n{'✅' if checks['all_passed'] else '❌'} 检查结果")
        for check_name, result in checks['checks'].items():
            status = '✅' if result['passed'] else ('⏭️' if result.get('skipped') else '❌')
            print(f"  {status} {check_name}")
    
    elif args.action == 'commit':
        print("🔍 执行Pre-commit检查...")
        result = git.commit(
            args.type, args.scope, args.subject,
            run_checks=True
        )
        
        if result['success']:
            print(f"✅ 提交成功: {result['commit_hash']}")
            print(f"   {result['message'].split(chr(10))[0]}")
        else:
            print(f"❌ 提交失败: {result['message']}")
    
    elif args.action == 'push':
        result = git.push()
        if result['success']:
            print("✅ 推送成功")
        else:
            print(f"❌ 推送失败: {result['message']}")


def main():
    parser = argparse.ArgumentParser(description='QuickAgents CLI')
    subparsers = parser.add_subparsers(dest='command', help='命令')
    
    # read 命令
    p_read = subparsers.add_parser('read', help='读取文件')
    p_read.add_argument('file', help='文件路径')
    p_read.set_defaults(func=cmd_read)
    
    # write 命令
    p_write = subparsers.add_parser('write', help='写入文件')
    p_write.add_argument('file', help='文件路径')
    p_write.add_argument('content', help='写入内容')
    p_write.set_defaults(func=cmd_write)
    
    # edit 命令
    p_edit = subparsers.add_parser('edit', help='编辑文件')
    p_edit.add_argument('file', help='文件路径')
    p_edit.add_argument('old', help='要替换的内容')
    p_edit.add_argument('new', help='替换后的内容')
    p_edit.set_defaults(func=cmd_edit)
    
    # hash 命令
    p_hash = subparsers.add_parser('hash', help='获取文件哈希')
    p_hash.add_argument('file', help='文件路径')
    p_hash.set_defaults(func=cmd_hash)
    
    # cache 命令
    p_cache = subparsers.add_parser('cache', help='缓存管理')
    p_cache.add_argument('action', choices=['stats', 'clear', 'list'], help='操作')
    p_cache.set_defaults(func=cmd_cache)
    
    # memory 命令
    p_memory = subparsers.add_parser('memory', help='记忆管理')
    p_memory.add_argument('action', choices=['get', 'set', 'search'], help='操作')
    p_memory.add_argument('key', nargs='?', help='键名')
    p_memory.add_argument('value', nargs='?', help='值')
    p_memory.add_argument('--keyword', '-k', help='搜索关键词')
    p_memory.set_defaults(func=cmd_memory)
    
    # loop 命令
    p_loop = subparsers.add_parser('loop', help='循环检测')
    p_loop.add_argument('action', choices=['check', 'reset', 'stats'], help='操作')
    p_loop.set_defaults(func=cmd_loop)
    
    # stats 命令
    p_stats = subparsers.add_parser('stats', help='查看统计')
    p_stats.set_defaults(func=cmd_stats)
    
    # reminder 命令
    p_reminder = subparsers.add_parser('reminder', help='提醒系统')
    p_reminder.add_argument('action', choices=['check', 'stats'], help='操作')
    p_reminder.set_defaults(func=cmd_reminder)
    
    # ==================== 新增命令 ====================
    
    # feedback 命令
    p_feedback = subparsers.add_parser('feedback', help='经验收集')
    p_feedback.add_argument('action', choices=['bug', 'improve', 'best', 'view', 'stats'], help='操作')
    p_feedback.add_argument('description', nargs='?', help='描述')
    p_feedback.add_argument('--scenario', '-s', help='场景上下文')
    p_feedback.add_argument('--type', '-t', help='反馈类型（view时使用）')
    p_feedback.set_defaults(func=cmd_feedback)
    
    # tdd 命令
    p_tdd = subparsers.add_parser('tdd', help='TDD工作流')
    p_tdd.add_argument('action', choices=['red', 'green', 'refactor', 'stats', 'coverage'], help='操作')
    p_tdd.add_argument('test_file', nargs='?', help='测试文件')
    p_tdd.set_defaults(func=cmd_tdd)
    
    # git 命令
    p_git = subparsers.add_parser('git', help='Git提交管理')
    p_git.add_argument('action', choices=['status', 'check', 'commit', 'push'], help='操作')
    p_git.add_argument('type', nargs='?', help='提交类型')
    p_git.add_argument('scope', nargs='?', help='范围')
    p_git.add_argument('subject', nargs='?', help='主题')
    p_git.set_defaults(func=cmd_git)
    
    args = parser.parse_args()
    
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
