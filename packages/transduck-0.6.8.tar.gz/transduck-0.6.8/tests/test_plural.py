from transduck.plural import get_plural_category, get_plural_categories, interpolate_vars


def test_get_plural_category_english():
    assert get_plural_category("EN", 1) == "one"
    assert get_plural_category("EN", 0) == "other"
    assert get_plural_category("EN", 5) == "other"
    assert get_plural_category("EN", 2) == "other"


def test_get_plural_category_russian():
    assert get_plural_category("RU", 1) == "one"
    assert get_plural_category("RU", 2) == "few"
    assert get_plural_category("RU", 5) == "many"
    assert get_plural_category("RU", 21) == "one"


def test_get_plural_category_german():
    assert get_plural_category("DE", 1) == "one"
    assert get_plural_category("DE", 2) == "other"


def test_get_plural_categories_english():
    cats = get_plural_categories("EN")
    assert "one" in cats
    assert "other" in cats
    assert len(cats) == 2


def test_get_plural_categories_russian():
    cats = get_plural_categories("RU")
    assert "one" in cats
    assert "few" in cats
    assert "many" in cats
    assert "other" in cats


def test_interpolate_vars_basic():
    assert interpolate_vars("Hello {name}", {"name": "Tim"}) == "Hello Tim"


def test_interpolate_vars_multiple():
    result = interpolate_vars("{count} items for {name}", {"count": 5, "name": "Tim"})
    assert result == "5 items for Tim"


def test_interpolate_vars_none():
    assert interpolate_vars("Hello world", None) == "Hello world"


def test_interpolate_vars_extra_keys_ignored():
    assert interpolate_vars("Hello {name}", {"name": "Tim", "extra": "ignored"}) == "Hello Tim"


def test_interpolate_vars_missing_key_left_alone():
    assert interpolate_vars("Hello {name}", {"other": "val"}) == "Hello {name}"
