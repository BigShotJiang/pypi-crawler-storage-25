import os
import pytest
from transduck.scanner import extract_strings, scan_directory


def test_extract_ait_double_quotes():
    code = 'ait("Our Events")'
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "Our Events"
    assert result[0].get("plural") is None


def test_extract_ait_single_quotes():
    code = "ait('Our Events')"
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "Our Events"


def test_extract_ait_with_context_keyword():
    code = 'ait("Book Now", context="Hotel booking")'
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "Book Now"
    assert result[0]["context"] == "Hotel booking"


def test_extract_ait_with_context_positional():
    """JS-style positional context."""
    code = 'ait("Book Now", "Hotel booking")'
    result = extract_strings(code, "test.js")
    assert len(result) == 1
    assert result[0]["text"] == "Book Now"
    assert result[0]["context"] == "Hotel booking"


def test_extract_ait_no_context():
    code = 'ait("Hello")'
    result = extract_strings(code, "test.py")
    assert result[0].get("context") is None


def test_extract_ait_with_vars_no_context():
    code = 'ait("Welcome {name}", vars={"name": user})'
    result = extract_strings(code, "test.py")
    assert result[0]["text"] == "Welcome {name}"
    assert result[0].get("context") is None


def test_extract_ait_plural_python():
    code = 'ait_plural("{count} message", "{count} messages", count=n)'
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} message"
    assert result[0]["other"] == "{count} messages"


def test_extract_ait_plural_js():
    code = "aitPlural('{count} night', '{count} nights', 5)"
    result = extract_strings(code, "test.ts")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} night"
    assert result[0]["other"] == "{count} nights"


def test_extract_django_template_tag():
    code = '{% ait "Our Events" %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["text"] == "Our Events"


def test_extract_django_template_tag_with_context():
    code = '{% ait "Book Now" context="Hotel booking" %}'
    result = extract_strings(code, "test.html")
    assert result[0]["text"] == "Book Now"
    assert result[0]["context"] == "Hotel booking"


def test_extract_jinja_expression():
    code = '{{ ait("Our Events") }}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["text"] == "Our Events"


def test_extract_multiple_strings():
    code = '''
ait("Hello")
ait("World", context="greeting")
ait_plural("{count} item", "{count} items", count=n)
'''
    result = extract_strings(code, "test.py")
    assert len(result) == 3


def test_extract_no_matches():
    code = 'print("Hello")'
    result = extract_strings(code, "test.py")
    assert len(result) == 0


def test_extract_includes_line_numbers():
    code = 'line1\nait("Hello")\nline3'
    result = extract_strings(code, "test.py")
    assert result[0]["line"] == 2


def test_scan_directory(tmp_path):
    (tmp_path / "app.py").write_text('ait("Hello")\nait("World")')
    (tmp_path / "views.py").write_text('ait("Hello")')  # duplicate
    (tmp_path / "template.html").write_text('{% ait "Events" %}')
    result = scan_directory([tmp_path])
    # Hello should be deduped, so 3 unique strings
    texts = [e.get("text") for e in result if not e.get("plural")]
    assert "Hello" in texts
    assert "World" in texts
    assert "Events" in texts
    assert len(result) == 3


def test_scan_directory_dedup_with_files(tmp_path):
    (tmp_path / "a.py").write_text('ait("Hello")')
    (tmp_path / "b.py").write_text('ait("Hello")')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert len(result[0]["files"]) == 2


def test_scan_directory_skips_node_modules(tmp_path):
    nm = tmp_path / "node_modules"
    nm.mkdir()
    (nm / "dep.js").write_text('ait("Hidden")')
    (tmp_path / "app.py").write_text('ait("Visible")')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert result[0]["text"] == "Visible"


def test_scan_directory_skips_venv(tmp_path):
    venv = tmp_path / ".venv"
    venv.mkdir()
    (venv / "lib.py").write_text('ait("Hidden")')
    (tmp_path / "app.py").write_text('ait("Visible")')
    result = scan_directory([tmp_path])
    assert len(result) == 1


def test_scan_directory_skips_venv_with_suffix(tmp_path):
    """venv312, venv3, .venv3 etc. should be skipped."""
    venv = tmp_path / "venv312"
    venv.mkdir()
    sp = venv / "lib" / "python3.12" / "site-packages" / "pkg"
    sp.mkdir(parents=True)
    (sp / "mod.py").write_text('ait("Hidden")')
    (tmp_path / "app.py").write_text('ait("Visible")')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert result[0]["text"] == "Visible"


def test_scan_directory_skips_env(tmp_path):
    """env and .env directories should be skipped."""
    for name in ["env", ".env"]:
        d = tmp_path / name
        d.mkdir(exist_ok=True)
        (d / "lib.py").write_text('ait("Hidden")')
    (tmp_path / "app.py").write_text('ait("Visible")')
    result = scan_directory([tmp_path])
    assert len(result) == 1


def test_scan_directory_filters_extensions(tmp_path):
    (tmp_path / "readme.md").write_text('ait("Not a code file")')
    (tmp_path / "app.py").write_text('ait("Code file")')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert result[0]["text"] == "Code file"


def test_scan_directory_plural_dedup(tmp_path):
    (tmp_path / "a.py").write_text('ait_plural("{count} msg", "{count} msgs", count=n)')
    (tmp_path / "b.py").write_text('ait_plural("{count} msg", "{count} msgs", count=n)')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert len(result[0]["files"]) == 2


def test_extract_t_from_transduck_react_import():
    code = "import { t } from 'transduck/react';\nt(\"Hello\")\nt(\"Book\", \"Hotel booking\")"
    result = extract_strings(code, "test.tsx")
    assert len(result) == 2
    assert result[0]["text"] == "Hello"
    assert result[1]["text"] == "Book"
    assert result[1]["context"] == "Hotel booking"


def test_no_extract_t_without_transduck_import():
    code = "import { t } from 'i18next';\nt(\"Hello\")"
    result = extract_strings(code, "test.tsx")
    assert len(result) == 0


def test_extract_tPlural_from_transduck_react_import():
    code = "import { tPlural } from 'transduck/react';\ntPlural(\"{count} item\", \"{count} items\", 5)"
    result = extract_strings(code, "test.tsx")
    assert len(result) == 1
    assert result[0]["plural"] is True


def test_extract_t_from_server_component_with_ait():
    """Issue #2: t() should be detected in files that use ait (not just transduck/react)."""
    code = '''import { ait } from "@/lib/transduck";
const t = async (str, ctx) => String(await ait(str, ctx));
const headline = await t("Your property visits, organized.", "Landing page headline");
'''
    result = extract_strings(code, "test.tsx")
    texts = [e["text"] for e in result if not e.get("plural")]
    assert "Your property visits, organized." in texts


def test_extract_t_from_direct_transduck_import():
    """t() detected when file imports from 'transduck' (not /react)."""
    code = "import { ait } from 'transduck';\nconst t = ait;\nt(\"Hello\")"
    result = extract_strings(code, "test.ts")
    texts = [e["text"] for e in result]
    assert "Hello" in texts


def test_no_false_positive_t_in_py_without_ait():
    """t() in a .py file without ait should not be matched."""
    code = "from gettext import gettext as t\nt('Hello')"
    result = extract_strings(code, "test.py")
    assert len(result) == 0


def test_no_false_positive_wait():
    """'await' contains 'ait' substring but should not trigger t() scanning in non-JS."""
    code = "result = await something()\nt('Hello')"
    result = extract_strings(code, "test.py")
    assert len(result) == 0


def test_extract_multiline_python_implicit_concat():
    code = '''ait(
    "This is a long "
    "paragraph that spans "
    "multiple lines"
)'''
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "This is a long paragraph that spans multiple lines"


def test_extract_multiline_with_context():
    code = '''ait(
    "This is a long "
    "paragraph",
    context="Some context"
)'''
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "This is a long paragraph"
    assert result[0]["context"] == "Some context"


def test_extract_multiline_js_plus_concat():
    code = """ait(
    "This is a long " +
    "paragraph that spans " +
    "multiple lines"
)"""
    result = extract_strings(code, "test.js")
    assert len(result) == 1
    assert result[0]["text"] == "This is a long paragraph that spans multiple lines"


def test_extract_multiline_plural():
    code = '''ait_plural(
    "{count} long item "
    "description here",
    "{count} long items "
    "description here",
    count=n
)'''
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} long item description here"
    assert result[0]["other"] == "{count} long items description here"


def test_extract_django_tag_with_as():
    code = '{% ait "Welcome" as headline %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["text"] == "Welcome"


def test_extract_django_tag_with_context_and_as():
    code = '{% ait "Book" context="Hotel booking" as btn %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["text"] == "Book"
    assert result[0]["context"] == "Hotel booking"


def test_extract_django_plural_tag_with_as():
    code = '{% ait_plural "{count} night" "{count} nights" as stay %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} night"


def test_extract_django_plural_tag():
    code = '{% ait_plural "{count} night" "{count} nights" %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} night"
    assert result[0]["other"] == "{count} nights"
    assert result[0].get("context") is None


def test_extract_django_plural_tag_with_context():
    code = '{% ait_plural "{count} night" "{count} nights" context="Hotel stay duration" %}'
    result = extract_strings(code, "test.html")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} night"
    assert result[0]["other"] == "{count} nights"
    assert result[0]["context"] == "Hotel stay duration"


def test_extract_django_plural_tag_single_quotes():
    code = "{% ait_plural '{count} item' '{count} items' %}"
    result = extract_strings(code, "test.jinja2")
    assert len(result) == 1
    assert result[0]["plural"] is True
    assert result[0]["one"] == "{count} item"
    assert result[0]["other"] == "{count} items"


def test_extract_django_plural_not_in_py():
    """Django template tags should only match in template files."""
    code = '{% ait_plural "{count} night" "{count} nights" %}'
    result = extract_strings(code, "test.py")
    assert len(result) == 0


def test_extract_from_vue_sfc():
    code = '''<template>
  <h1>{% ait "Welcome" %}</h1>
</template>
<script setup>
import { ait } from 'transduck';
const msg = ait("Hello", "greeting");
</script>'''
    result = extract_strings(code, "test.vue")
    texts = [e["text"] for e in result if not e.get("plural")]
    assert "Welcome" in texts
    assert "Hello" in texts


def test_extract_from_svelte():
    code = '''<script>
import { ait } from 'transduck';
</script>
<h1>{ait("Welcome")}</h1>'''
    result = extract_strings(code, "test.svelte")
    assert any(e["text"] == "Welcome" for e in result)


def test_extract_from_mjs():
    code = 'import { ait } from "transduck";\nait("Hello");'
    result = extract_strings(code, "test.mjs")
    assert len(result) == 1
    assert result[0]["text"] == "Hello"


def test_extract_from_cjs():
    code = 'const { ait } = require("transduck");\nait("Hello");'
    result = extract_strings(code, "test.cjs")
    assert len(result) == 1
    assert result[0]["text"] == "Hello"


def test_extract_from_mdx():
    code = 'import { ait } from "transduck";\n\n# Title\n\n{ait("Welcome")}'
    result = extract_strings(code, "test.mdx")
    assert any(e["text"] == "Welcome" for e in result)


def test_extract_from_njk():
    code = '{% ait "Welcome" %}\n{% ait "Book" context="hotel" %}'
    result = extract_strings(code, "test.njk")
    assert len(result) == 2
    assert result[0]["text"] == "Welcome"
    assert result[1]["text"] == "Book"
    assert result[1]["context"] == "hotel"


def test_scan_directory_finds_vue_files(tmp_path):
    (tmp_path / "app.vue").write_text('<script>\nait("Hello")\n</script>')
    result = scan_directory([tmp_path])
    assert len(result) == 1
    assert result[0]["text"] == "Hello"


def test_extract_multiline_single_quotes():
    code = """ait(
    'This is a long '
    'paragraph'
)"""
    result = extract_strings(code, "test.py")
    assert len(result) == 1
    assert result[0]["text"] == "This is a long paragraph"
