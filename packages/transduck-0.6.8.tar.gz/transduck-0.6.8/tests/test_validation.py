from transduck.validation import extract_placeholders, validate_translation


def test_extract_curly_placeholders():
    assert extract_placeholders("Hello {name}") == {"{name}"}


def test_extract_double_curly_placeholders():
    assert extract_placeholders("You have {{ count }} items") == {"{{ count }}"}


def test_extract_percent_placeholders():
    assert extract_placeholders("Hello %s, you have %d items") == {"%s", "%d"}


def test_extract_dollar_placeholders():
    assert extract_placeholders("Hello ${name}") == {"${name}"}


def test_extract_mixed_placeholders():
    result = extract_placeholders("{greeting} %s ${name}")
    assert result == {"{greeting}", "%s", "${name}"}


def test_extract_no_placeholders():
    assert extract_placeholders("Hello world") == set()


def test_validate_translation_passes():
    assert validate_translation("Hello {name}", "Hallo {name}") is True


def test_validate_translation_fails_empty():
    assert validate_translation("Hello", "") is False


def test_validate_translation_fails_missing_placeholder():
    assert validate_translation("Hello {name}", "Hallo") is False


def test_validate_translation_passes_no_placeholders():
    assert validate_translation("Hello", "Hallo") is True
