from transduck.result import TranslationResult


def _make(text="Hallo", pending=False, source_lang="EN", lang="DE"):
    return TranslationResult(text, pending=pending, source_lang=source_lang, lang=lang)


# --- metadata attributes ---

def test_attributes():
    r = _make()
    assert r.pending is False
    assert r.source_lang == "EN"
    assert r.lang == "DE"


def test_pending_true():
    r = _make(pending=True)
    assert r.pending is True


# --- str identity ---

def test_str_equality():
    r = _make("Hallo")
    assert r == "Hallo"
    assert "Hallo" == r


def test_str_type():
    r = _make()
    assert isinstance(r, str)


def test_concatenation():
    r = _make("Hallo")
    assert r + " Welt" == "Hallo Welt"
    assert "Sag " + r == "Sag Hallo"


def test_fstring():
    r = _make("Hallo")
    assert f"Greeting: {r}" == "Greeting: Hallo"


def test_format_method():
    r = _make("Hallo")
    assert "Greeting: {}".format(r) == "Greeting: Hallo"


def test_template_string():
    from string import Template
    r = _make("Hallo")
    t = Template("Greeting: $word")
    assert t.substitute(word=r) == "Greeting: Hallo"


def test_repr():
    r = _make("Hallo")
    assert repr(r) == repr("Hallo")


def test_hash_matches_str():
    r = _make("Hallo")
    assert hash(r) == hash("Hallo")


def test_in_dict_key():
    r = _make("key")
    d = {r: 1}
    assert d["key"] == 1


def test_len():
    r = _make("Hallo")
    assert len(r) == 5


def test_slicing():
    r = _make("Hallo")
    assert r[:3] == "Hal"


def test_upper_lower():
    r = _make("Hallo")
    assert r.upper() == "HALLO"
    assert r.lower() == "hallo"
