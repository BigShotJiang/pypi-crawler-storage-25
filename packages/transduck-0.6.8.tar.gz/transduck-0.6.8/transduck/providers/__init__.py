"""Translation provider abstraction."""


def get_provider(config):
    """Return the provider module for the configured provider."""
    if config.provider == "openai":
        from transduck.providers import openai_provider
        return openai_provider
    elif config.provider == "claude_api":
        from transduck.providers import claude_api
        return claude_api
    elif config.provider == "claude_code":
        from transduck.providers import claude_code
        return claude_code
    else:
        raise ValueError(f"Unknown provider: {config.provider}. Valid: openai, claude_api, claude_code")
