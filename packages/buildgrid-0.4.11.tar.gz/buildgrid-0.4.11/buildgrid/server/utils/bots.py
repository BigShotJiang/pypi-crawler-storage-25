# Copyright (C) 2025 Bloomberg LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  <http://www.apache.org/licenses/LICENSE-2.0>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass
from typing import Any

from buildgrid._protos.google.devtools.remoteworkers.v1test2.bots_pb2 import BotSession
from buildgrid.server.context import current_instance

BOT_CAPACITY_KEY = "capacity"
BOT_PRIORITY_KEY = "priority"


@dataclass(frozen=True)
class BotConfig:
    """Configuration extracted from a BotSession's worker configs."""

    capacity: int = 1
    priority: int = 0

    @staticmethod
    def from_bot_session(bot_session: BotSession) -> "BotConfig":
        """Extract bot configuration from a BotSession.

        Iterates over worker configs once to extract both capacity and priority.
        Defaults to capacity=1 and priority=0 if not specified.
        """
        capacity = 1
        priority = 0
        for config in bot_session.worker.configs:
            if config.key == BOT_CAPACITY_KEY:
                capacity = int(config.value)
            elif config.key == BOT_PRIORITY_KEY:
                priority = int(config.value)
        return BotConfig(capacity=capacity, priority=priority)


def bot_log_tags(bot_session: BotSession) -> dict[str, Any]:
    """Return the dictionary of common log tags for a BotSession."""
    config = BotConfig.from_bot_session(bot_session)
    return {
        "instance_name": current_instance(),
        "request.bot_name": bot_session.name,
        "request.bot_id": bot_session.bot_id,
        "request.bot_status": bot_session.status,
        "request.leases.size": len(bot_session.leases),
        "request.capacity": config.capacity,
        "request.priority": config.priority,
    }
