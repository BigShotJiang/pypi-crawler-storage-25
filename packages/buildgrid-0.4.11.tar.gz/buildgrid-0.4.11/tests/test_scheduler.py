# Copyright (C) 2019 Bloomberg LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  <http://www.apache.org/licenses/LICENSE-2.0>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import datetime
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Sequence, Any
from collections.abc import Iterator

from unittest import mock
from unittest.mock import Mock

import grpc
import pytest
from pytest import FixtureRequest
from psycopg import Connection

from buildgrid_metering.client.exceptions import MeteringServiceHTTPError

# Ignore typing bellow as there are not type stubs for flaky
from flaky import flaky  # type: ignore [import-untyped]
from google.protobuf.any_pb2 import Any as ProtoAny
from google.protobuf.duration_pb2 import Duration
from google.protobuf.message import Message
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from buildgrid._protos.build.bazel.remote.execution.v2.remote_execution_pb2 import (
    ExecutedActionMetadata,
    RequestMetadata,
)
from buildgrid._protos.build.bazel.remote.asset.v1.remote_asset_pb2_grpc import (
    add_PushServicer_to_server,
)
from buildgrid._protos.build.bazel.remote.execution.v2 import remote_execution_pb2
from buildgrid._protos.build.bazel.remote.execution.v2.remote_execution_pb2 import (
    Action,
    Digest,
    ExecuteOperationMetadata,
    ExecuteResponse,
    Platform,
)
from buildgrid._protos.build.buildbox.execution_stats_pb2 import ExecutionStatistics
from buildgrid._protos.build.buildgrid.scheduling_pb2 import SchedulingMetadata
from buildgrid._protos.google.devtools.remoteworkers.v1test2.bots_pb2 import Lease
from buildgrid._protos.google.rpc import code_pb2
from buildgrid._protos.google.rpc.status_pb2 import Status
from buildgrid.server.actioncache.caches.action_cache_abc import ActionCacheABC
from buildgrid.server.actioncache.caches.lru_cache import LruActionCache
from buildgrid.server.actioncache.caches.remote_cache import RemoteActionCache
from buildgrid.server.cas.storage import lru_memory_cache
from buildgrid.server.cas.storage.remote import RemoteStorage
from buildgrid.server.cas.storage.storage_abc import StorageABC, create_write_session
from buildgrid.server.client.asset import AssetClient
from buildgrid.server.context import instance_context
from buildgrid.server.controller import ExecutionController
from buildgrid.server.enums import (
    BotStatus,
    JobHistoryEvent,
    LeaseState,
    OperationStage,
)
from buildgrid.server.exceptions import (
    BotSessionMismatchError,
    InstanceQuotaOutdatedError,
    InvalidArgumentError,
    NotFoundError,
    ResourceExhaustedError,
    StorageFullError,
)
from buildgrid.server.scheduler import PropertyLabel, PropertySet, Scheduler, StaticPropertySet
from buildgrid.server.scheduler.impl import BotRequirementsFilter
from buildgrid.server.scheduler.properties import hash_from_dict
from buildgrid.server.scheduler.assigner import (
    AssignByCapacity,
    AssignByLocality,
    SamplingConfig,
    SamplingWeights,
    create_bot_assignment_fn,
)
from buildgrid.server.scheduler.cohorts import Cohort, CohortSet
from buildgrid.server.sql import models
from buildgrid.server.sql.models import (
    Base,
    BotEntry,
    BotLocalityHintEntry,
    ClientIdentityEntry,
    EvictionLog,
    JobEntry,
    OperationEntry,
    digest_to_string,
    string_to_digest,
)
from buildgrid.server.sql.provider import SqlProvider
from buildgrid.server.utils.cancellation import CancellationContext
from buildgrid.server.utils.digests import create_digest
from tests.utils.action_cache import serve_cache
from tests.utils.cas import serve_cas
from tests.utils.fixtures import (  # noqa: F401 allow fixture inclusion
    connection_string_from_connection,
    mock_logstream_client,
    new_postgres_fixture,
    pg_schema_provider,
)
from tests.utils.metrics import mock_create_timer_record
from tests.utils.mocks import mock_context
from tests.utils.server import MockAssetPushServicer
from tests.utils.utils import find_free_port, generate_bot_name

server = mock.create_autospec(grpc.Server)

command = remote_execution_pb2.Command()
command_digest = create_digest(command.SerializeToString())

action = remote_execution_pb2.Action(command_digest=command_digest, do_not_cache=False)
action_digest = create_digest(action.SerializeToString())

uncacheable_action = remote_execution_pb2.Action(command_digest=command_digest, do_not_cache=True)
uncacheable_action_digest = create_digest(uncacheable_action.SerializeToString())


@pytest.fixture
def asset_service_remote() -> str:
    return f"localhost:{find_free_port()}"


@pytest.fixture
def push_service(asset_service_remote: str) -> Iterator[MockAssetPushServicer]:
    server = grpc.server(thread_pool=ThreadPoolExecutor())
    push = MockAssetPushServicer()
    add_PushServicer_to_server(push, server)
    server.add_insecure_port(asset_service_remote)
    server.start()

    try:
        yield push
    finally:
        server.stop(grace=None)


@pytest.fixture
def asset_service_channel(asset_service_remote: str) -> Iterator[grpc.Channel]:
    with grpc.insecure_channel(asset_service_remote) as channel:
        yield channel


@pytest.fixture
def asset_client(
    push_service: Iterator[MockAssetPushServicer], asset_service_channel: grpc.Channel
) -> Iterator[AssetClient]:
    yield AssetClient(asset_service_channel)


@pytest.fixture
def cohort_set() -> CohortSet:
    return CohortSet(
        [
            Cohort(name="linux", property_labels=frozenset({"linux", "unknown"})),
            Cohort(
                name="os-foo-1",
                property_labels=frozenset({"os-foo-1.0", "os-foo-1.1", "os-foo-1.2"}),
            ),
        ]
    )


USE_ACTION_CACHE = ["action-cache", "remote-action-cache", "no-action-cache"]
USE_REMOTE_STORAGE = ["lru-storage", "remote-storage"]


@pytest.fixture(params=USE_REMOTE_STORAGE)
def storage(request: FixtureRequest) -> Iterator[StorageABC]:
    if request.param == "lru-storage":
        yield lru_memory_cache.LRUMemoryCache(1024 * 1024)
    elif request.param == "remote-storage":
        with serve_cas(["sql", "linux"]) as server:
            yield RemoteStorage(server.remote, max_backoff=0)


@pytest.fixture(params=USE_ACTION_CACHE)
def scheduler(
    new_postgres: Connection,
    request: FixtureRequest,
    asset_client: AssetClient,
    common_props: PropertySet,
    cohort_set: CohortSet,
    storage: StorageABC,
) -> Iterator[Scheduler]:
    connection = connection_string_from_connection(new_postgres)
    sql_provider = SqlProvider(connection_string=connection)

    if request.param == "no-action-cache":
        yield Scheduler(
            sql_provider,
            storage,
            poll_interval=0.01,
            property_set=common_props,
            cohort_set=cohort_set,
            asset_client=asset_client,
            queued_action_retention_hours=12,
            completed_action_retention_hours=1,
            action_result_retention_hours=3,
        )
    elif request.param == "action-cache":
        cache: ActionCacheABC = LruActionCache(storage, 50)
        yield Scheduler(
            sql_provider,
            storage,
            poll_interval=0.01,
            action_cache=cache,
            property_set=common_props,
            cohort_set=cohort_set,
            asset_client=asset_client,
            queued_action_retention_hours=12,
            completed_action_retention_hours=1,
            action_result_retention_hours=3,
        )
    elif request.param == "remote-action-cache":
        with serve_cache(["sql", "linux"]) as cache_server:
            cache = RemoteActionCache(cache_server.remote)
            yield Scheduler(
                sql_provider,
                storage,
                poll_interval=0.01,
                action_cache=cache,
                property_set=common_props,
                cohort_set=cohort_set,
                asset_client=asset_client,
                queued_action_retention_hours=12,
                completed_action_retention_hours=1,
                action_result_retention_hours=3,
            )


@pytest.fixture
def controller(
    storage: StorageABC,
    scheduler: Scheduler,
) -> Iterator[ExecutionController]:
    # Create database tables
    with scheduler._sql._engine.begin() as conn:
        Base.metadata.create_all(conn)

    with scheduler, instance_context("sql"):
        with create_write_session(command_digest) as write_session:
            write_session.write(command.SerializeToString())
            storage.commit_write(command_digest, write_session)

        with create_write_session(action_digest) as write_session:
            write_session.write(action.SerializeToString())
            storage.commit_write(action_digest, write_session)

        yield ExecutionController(scheduler)


PARAMS_MAX_EXECUTION = [None, 0.1, 2]


@pytest.fixture(params=PARAMS_MAX_EXECUTION)
def controller_max_execution_timeout(
    new_postgres: Connection, request: FixtureRequest, common_props: PropertySet
) -> Iterator[ExecutionController]:
    max_execution_timeout = request.param
    storage = lru_memory_cache.LRUMemoryCache(1024 * 1024)
    connection = connection_string_from_connection(new_postgres)
    sql_provider = SqlProvider(connection_string=connection)

    # Create database tables
    with sql_provider._engine.begin() as conn:
        Base.metadata.create_all(conn)

    with create_write_session(command_digest) as write_session:
        write_session.write(command.SerializeToString())
        storage.commit_write(command_digest, write_session)

    with create_write_session(action_digest) as write_session:
        write_session.write(action.SerializeToString())
        storage.commit_write(action_digest, write_session)

    scheduler = Scheduler(
        sql_provider,
        storage,
        poll_interval=0.1,
        execution_timer_interval=0.1,
        property_set=common_props,
        max_execution_timeout=max_execution_timeout,
    )
    controller = ExecutionController(scheduler)
    assert controller.execution_instance is not None
    with controller.execution_instance, instance_context("sql"):
        yield controller


PARAMS_MAX_QUEUE_SIZE = [None, 1, 5]


@pytest.fixture(params=PARAMS_MAX_QUEUE_SIZE)
def controller_max_queue_size(
    new_postgres: Connection, request: FixtureRequest, common_props: PropertySet
) -> Iterator[ExecutionController]:
    max_queue_size = request.param
    storage = lru_memory_cache.LRUMemoryCache(1024 * 1024)
    connection = connection_string_from_connection(new_postgres)
    sql_provider = SqlProvider(connection_string=connection)

    # Create database tables
    with sql_provider._engine.begin() as conn:
        Base.metadata.create_all(conn)

    with create_write_session(command_digest) as write_session:
        write_session.write(command.SerializeToString())
        storage.commit_write(command_digest, write_session)

    with create_write_session(action_digest) as write_session:
        write_session.write(action.SerializeToString())
        storage.commit_write(action_digest, write_session)

    scheduler = Scheduler(
        sql_provider,
        storage,
        poll_interval=0.1,
        property_set=common_props,
        max_queue_size=max_queue_size,
    )
    controller = ExecutionController(scheduler)
    assert controller.execution_instance is not None
    with controller.execution_instance, instance_context("sql"):
        yield controller


@pytest.fixture
def isolated_controllers(
    new_postgres: Connection, request: FixtureRequest, common_props: PropertySet
) -> Iterator[tuple[ExecutionController, ExecutionController]]:
    storage = lru_memory_cache.LRUMemoryCache(1024 * 1024)
    connection = connection_string_from_connection(new_postgres)
    sql_provider = SqlProvider(connection_string=connection)

    # Create database tables
    with sql_provider._engine.begin() as conn:
        Base.metadata.create_all(conn)

    with create_write_session(command_digest) as write_session:
        write_session.write(command.SerializeToString())
        storage.commit_write(command_digest, write_session)

    with create_write_session(action_digest) as write_session:
        write_session.write(action.SerializeToString())
        storage.commit_write(action_digest, write_session)

    cache = LruActionCache(storage, 50)
    scheduler_a = Scheduler(sql_provider, storage, action_cache=cache, property_set=common_props)
    scheduler_b = Scheduler(sql_provider, storage, action_cache=cache, property_set=common_props)
    with scheduler_b, scheduler_a:
        yield ExecutionController(scheduler_a), ExecutionController(scheduler_b)


@pytest.fixture
def controller_postgres(
    asset_client: AssetClient,
    common_props: PropertySet,
    postgres: Connection,
    cohort_set: CohortSet,
) -> Iterator[ExecutionController]:
    storage = lru_memory_cache.LRUMemoryCache(1024 * 1024)
    cache = LruActionCache(storage, 50)

    with pg_schema_provider(postgres) as sql_provider:
        with create_write_session(command_digest) as write_session:
            write_session.write(command.SerializeToString())
            storage.commit_write(command_digest, write_session)

        with create_write_session(action_digest) as write_session:
            write_session.write(action.SerializeToString())
            storage.commit_write(action_digest, write_session)

        scheduler = Scheduler(
            sql_provider,
            storage,
            poll_interval=0.01,
            action_cache=cache,
            property_set=common_props,
            cohort_set=cohort_set,
            asset_client=asset_client,
            queued_action_retention_hours=12,
            completed_action_retention_hours=1,
            action_result_retention_hours=3,
        )

        with scheduler, instance_context("sql"):
            yield ExecutionController(scheduler)


def add_bot(
    scheduler: Scheduler,
    bot_instance_name: str,
    bot_capacity: int = 1,
    bot_session_id: str = "test-worker",
    bot_capability_hashes: list[str] | None = None,
    bot_property_labels: list[str] | None = None,
    bot_priority: int = 0,
) -> tuple[str, str]:
    bot_id = bot_session_id
    # Avoid re-adding the same bot entry
    with instance_context(bot_instance_name):
        with scheduler._sql.session() as session:
            bot = session.execute(select(BotEntry).where(BotEntry.bot_id == bot_id)).scalar_one_or_none()
            if bot is None:
                bot_name = scheduler.add_bot_entry(
                    bot_name=generate_bot_name(),
                    bot_session_id=bot_id,
                    bot_session_status=BotStatus.OK.value,
                    bot_capacity=bot_capacity,
                    bot_priority=bot_priority,
                    instance_name=bot_instance_name,
                    bot_capability_hashes=bot_capability_hashes,
                    bot_property_labels=bot_property_labels,
                )
            else:
                bot_name = bot.name
    return bot_name, bot_id


def mock_queue_job_action(
    scheduler: Scheduler,
    skip_cache_lookup: bool = True,
    request_metadata: RequestMetadata | None = None,
    do_not_cache: bool = False,
    assign: bool = True,
    create_bot: bool = True,
    locality_hint: str | None = None,
    job_priority: int = 0,
    bot_capacity: int = 1,
    bot_instance_name: str = "*",
    platform_requirements: dict[str, list[str]] | None = None,
) -> tuple[str, str, str, str]:
    bot_id = "test-worker"
    bot_name = ""
    if create_bot:
        bot_name, bot_id = add_bot(scheduler, bot_instance_name, bot_capacity=bot_capacity)

    scheduling_metadata = SchedulingMetadata()
    if locality_hint is not None:
        scheduling_metadata.locality_hint = locality_hint

    if platform_requirements is None:
        platform_requirements = {}

    operation_name = scheduler.queue_job_action(
        action=uncacheable_action if do_not_cache else action,
        action_digest=uncacheable_action_digest if do_not_cache else action_digest,
        command=command,
        platform_requirements=platform_requirements,
        property_label="unknown",
        priority=job_priority,
        skip_cache_lookup=skip_cache_lookup,
        request_metadata=request_metadata,
        scheduling_metadata=scheduling_metadata,
    )
    job_name = scheduler.get_operation_job_name(operation_name)
    assert job_name is not None

    if assign:
        scheduler.assign_job_by_priority_age()
    return bot_name, bot_id, operation_name, job_name


def test_assign_job_by_age(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with two jobs in the queue, lowest priority oldest
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, _, job_name = mock_queue_job_action(scheduler, assign=False, job_priority=10)
    mock_queue_job_action(scheduler, create_bot=False, assign=False)
    assert job_name is not None

    # WHEN: An attempt to assign based on age occurs
    scheduler.assign_job_by_priority_age(order_by_priority=False)

    # THEN: The older job is assigned
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.EXECUTING.value
        assert job.assigned


def test_assign_job_to_lower_priority_bot(controller: ExecutionController) -> None:
    # GIVEN: Two bots with different priorities and one queued job
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    add_bot(scheduler, "*", bot_session_id="bot-high", bot_priority=1)
    _, low_priority_bot_id = add_bot(scheduler, "*", bot_session_id="bot-low", bot_priority=-1)

    _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False, assign=False)
    assert job_name is not None

    # WHEN: Assignment uses sampling-based bot matching (exercises _match_bot_by_sampling priority ordering)
    sampling = SamplingConfig(sample_size=100, max_attempts=1)

    def bot_assignment_fn(
        session: Session, job: JobEntry, bot_requirements_filter: BotRequirementsFilter
    ) -> tuple[BotEntry, str] | None:
        return scheduler.match_bot_by_capacity(session, job, bot_requirements_filter, sampling=sampling)

    scheduler.assign_job_by_priority_age(bot_assignment_fn=bot_assignment_fn)

    # THEN: The job is assigned to the bot with the lower priority value
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.EXECUTING.value
        assert job.assigned
        assert job.worker_name == low_priority_bot_id


def test_assign_job_to_higher_capacity_bot(controller: ExecutionController) -> None:
    # GIVEN: Two bots with different priorities and capacities, and one queued job
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    add_bot(scheduler, "*", bot_session_id="bot-high-priority", bot_priority=-1, bot_capacity=1)
    _, high_capacity_bot_id = add_bot(
        scheduler, "*", bot_session_id="bot-high-capacity", bot_priority=0, bot_capacity=10
    )

    _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False, assign=False)
    assert job_name is not None

    sampling = SamplingConfig(
        sample_size=100,
        max_attempts=1,
        weights=SamplingWeights(priority=-1.0, capacity=1.0),
    )

    def bot_assignment_fn(
        session: Session, job: JobEntry, bot_requirements_filter: BotRequirementsFilter
    ) -> tuple[BotEntry, str] | None:
        return scheduler.match_bot_by_capacity(session, job, bot_requirements_filter, sampling=sampling)

    scheduler.assign_job_by_priority_age(bot_assignment_fn=bot_assignment_fn)

    # THEN: The job is assigned to the bot with higher capacity despite worse priority
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.EXECUTING.value
        assert job.assigned
        assert job.worker_name == high_capacity_bot_id


def test_assign_job_to_bot_with_locality_hint(controller: ExecutionController) -> None:
    # GIVEN: Two bots with same priority but different capacities, and one queued job with a locality hint
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    bot_local_name, _ = add_bot(scheduler, "*", bot_session_id="bot-local", bot_capacity=1)
    add_bot(scheduler, "*", bot_session_id="bot-capacity", bot_capacity=2)

    _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False, assign=False, locality_hint="region-a")
    assert job_name is not None

    # Insert a locality hint for bot-local matching the job's locality hint
    with scheduler._sql.session() as session:
        session.add(BotLocalityHintEntry(bot_name=bot_local_name, locality_hint="region-a"))

    # WHEN: Assignment uses sampling with default weights
    sampling = SamplingConfig(sample_size=100, max_attempts=1)

    def bot_assignment_fn(
        session: Session, job: JobEntry, bot_requirements_filter: BotRequirementsFilter
    ) -> tuple[BotEntry, str] | None:
        return scheduler.match_bot_by_capacity(session, job, bot_requirements_filter, sampling=sampling)

    scheduler.assign_job_by_priority_age(bot_assignment_fn=bot_assignment_fn)

    # THEN: The job is assigned to the bot with matching locality hint despite lower capacity
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.EXECUTING.value
        assert job.assigned
        assert job.worker_name == "bot-local"


def test_assign_job_with_unmet_requirements(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot and a job with unmatchable requirements
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, _, job_name = mock_queue_job_action(
        scheduler, assign=False, platform_requirements={"OSFamily": ["impossible"]}
    )
    assert job_name is not None

    # WHEN: Assignment is attempted
    scheduler.assign_job_by_priority_age()

    # THEN: The job remains unassigned
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.QUEUED.value
        assert not job.assigned
        assert job.schedule_after > datetime.datetime.utcnow()


def test_fail_to_assign_job_to_unhealthy_bot(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id = add_bot(scheduler, "*")

    # WHEN: The bot synchronizes an unhealthy state
    leases, _ = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.UNHEALTHY.value, 0, [], CancellationContext(mock_context())
    )
    assert len(leases) == 0

    # WHEN: A job is submitted and assignment attempted
    _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False)
    assert job_name is not None

    # THEN: The job is not assigned
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.stage == OperationStage.QUEUED.value
        assert not job.assigned
        assert job.schedule_after > datetime.datetime.utcnow()


def test_synchronize_dead_bot(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id = add_bot(scheduler, "*")

    # WHEN: A bot with the same ID (client-provided) but a different name (server-generated) attempts to synchronize
    # THEN: A BotSessionMismatchError is raised
    with pytest.raises(BotSessionMismatchError):
        scheduler.synchronize_bot_leases(
            str(reversed(bot_name)), bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
        )


def test_synchronize_closed_bot(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler)

    # WHEN: The bot session is closed (simulating expiry for example)
    with instance_context("*"):
        scheduler.close_bot_sessions(bot_name)

    # THEN: Attempting to synchronize the bot session raises an InvalidArgumentError
    with pytest.raises(InvalidArgumentError):
        scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
        )


def test_synchronize_missing_lease(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)

    # WHEN: The bot synchronizes without including the active lease
    leases, _ = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
    )

    # THEN: The lease is included in the list returned by synchronization
    assert len(leases) == 1
    assert leases[0].id == job_name


def test_synchronize_complete_completed_job(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler)

    # WHEN: The bot completes the job
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    leases[0].state = LeaseState.COMPLETED.value
    old_lease = leases[0]
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )

    # THEN: The synchronization returns no leases
    assert len(leases) == 0

    # WHEN: Attempting to synchronize the completed lease again
    leases, _ = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [old_lease], CancellationContext(mock_context())
    )

    # THEN: The synchronization again returns no leases
    assert len(leases) == 0


def test_synchronize_update_completed_job(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler)

    # WHEN: The bot completes the job
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    old_lease = Lease()
    old_lease.CopyFrom(leases[0])
    leases[0].state = LeaseState.COMPLETED.value
    leases, _ = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )

    # THEN: The synchronization returns no leases
    assert len(leases) == 0

    # WHEN: Attempting to synchronize the old lease in an incomplete state
    scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [old_lease], CancellationContext(mock_context())
    )

    # THEN: The synchronization again returns no leases
    assert len(leases) == 0


def test_complete_job(controller: ExecutionController, push_service: MockAssetPushServicer) -> None:
    # GIVEN: A scheduler
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # WHEN: A job is submitted and assigned to a bot
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        # check retention for queued action
        assert job is not None
        assert job.action_digest in push_service.blobs
        asset = push_service.blobs[job.action_digest]
        assert asset.instance_name == "sql"
        assert asset.uris == [f"nih:sha-256;{string_to_digest(job.action_digest).hash}"]
        action = Action.FromString(job.action)
        assert action.command_digest in asset.references_blobs
        assert action.input_root_digest in asset.references_directories
        assert asset.expire_at.ToDatetime() > datetime.datetime.now() + datetime.timedelta(hours=10)

    # THEN: A lease to execute the job is added when synchronizing leases for the bot
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    assert lease.state == LeaseState.ACTIVE.value

    # WHEN: The bot sets the lease to COMPLETED and synchronizes again
    mock_stderr_digest = Digest(hash="stderr", size_bytes=42)
    test_action_result = remote_execution_pb2.ActionResult(
        exit_code=0, stdout_raw=b"test", stderr_digest=mock_stderr_digest
    )
    lease.result.Pack(test_action_result)
    lease.state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )

    # THEN: The lease is removed during synchronizing
    assert len(leases) == 0

    # THEN: The asset retention is as expected
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        # check retention for completed action and result
        asset = push_service.blobs[job.action_digest]
        assert asset.expire_at.ToDatetime() > datetime.datetime.now() + datetime.timedelta(hours=0.5)
        assert job.result is not None
        message = scheduler.storage.get_message(string_to_digest(job.result), ExecuteResponse)
        assert message is not None
        action_result = message.result
        result_digest = create_digest(action_result.SerializeToString())
        result_asset = push_service.blobs[digest_to_string(result_digest)]
        assert result_asset.instance_name == "sql"
        assert result_asset.uris == [f"nih:sha-256;{result_digest.hash}"]
        assert mock_stderr_digest in result_asset.references_blobs
        assert result_asset.expire_at.ToDatetime() > datetime.datetime.now() + datetime.timedelta(hours=2)


def test_retried_job_can_be_assigned(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # WHEN: The bot's session is closed
    scheduler.close_bot_sessions(bot_name)

    # WHEN: A new bot connects
    bot_name, bot_id = add_bot(scheduler, "*")

    # WHEN: A job assignment attempt occurs
    scheduler.assign_job_by_priority_age()

    # THEN: The job is successfully assigned
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.EXECUTING.value
        assert job.assigned
        assert job.worker_name == bot_id


def test_retry_job_on_bot_session_close(controller: ExecutionController) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # WHEN: The bot's session is closed for some reason
    scheduler.close_bot_sessions(bot_name)

    # THEN: The job is retried
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.QUEUED.value


def test_retry_job_with_retryable_not_ok_status(
    controller: ExecutionController,
) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # WHEN: The bot reports the job COMPLETED with a retryable non-OK status
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    leases[0].state = LeaseState.COMPLETED.value
    leases[0].status.CopyFrom(Status(code=code_pb2.UNAVAILABLE))
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )

    # THEN: The bot has no work assigned
    assert len(leases) == 0

    # THEN: The database reflects that the job has been requeued
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.QUEUED.value


def test_no_retry_job_with_non_retryable_not_ok_status(
    controller: ExecutionController,
) -> None:
    # GIVEN: A scheduler with an active bot with a job assigned
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # WHEN: The bot reports the job COMPLETED with a non-retryable non-OK status
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    leases[0].state = LeaseState.COMPLETED.value
    leases[0].status.CopyFrom(Status(code=code_pb2.FAILED_PRECONDITION))
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )

    # THEN: The bot has no work assigned
    assert len(leases) == 0

    # THEN: The database reflects that the job has been completed unsuccessfully
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 1
        assert job.stage == OperationStage.COMPLETED.value
        assert job.status_code == code_pb2.FAILED_PRECONDITION


def test_retry_exhaustion(controller: ExecutionController) -> None:
    # GIVEN: A Scheduler which attempts job execution twice
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.max_job_attempts = 2

    # WHEN: A job is submitted and assigned to a bot
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # THEN: The database reflects that the job is assigned for its first attempt
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 1
        assert job.stage == OperationStage.EXECUTING.value

    # WHEN: The bot goes away
    scheduler.close_bot_sessions(bot_name)

    # THEN: The job is requeued for its second execution attempt
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.QUEUED.value

    # WHEN: A new bot connects and the job is assigned
    bot_name = scheduler.add_bot_entry(bot_name=bot_name, bot_session_id=bot_id, bot_session_status=BotStatus.OK.value)
    scheduler.assign_job_by_priority_age()

    # THEN: The database reflects that the job is assigned for its second attempt
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.EXECUTING.value

    # WHEN: The bot goes away
    scheduler.close_bot_sessions(bot_name)

    # THEN: The job is marked as aborted in the database
    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.n_tries == 2
        assert job.stage == OperationStage.COMPLETED.value
        assert job.status_code == code_pb2.ABORTED

        stmt = select(models.JobHistoryEntry).where(models.JobHistoryEntry.job_name == job_name)
        history: Sequence[models.JobHistoryEntry] = list(session.execute(stmt).scalars())
        assert any(event.event_type == JobHistoryEvent.RETRY.value for event in history)


def test_requeue_queued_job(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler: Scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.worker_name is not None
        assert job.stage == OperationStage.EXECUTING.value

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    lease.state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    assert lease.state == LeaseState.ACTIVE.value

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.worker_name is not None
        assert job.stage == OperationStage.EXECUTING.value

    # Make sure that retrying a job that was assigned but
    # not marked as in progress properly re-queues
    scheduler.close_bot_sessions(bot_name)
    bot_name = scheduler.add_bot_entry(bot_name=bot_name, bot_session_id=bot_id, bot_session_status=BotStatus.OK.value)

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.worker_name is None
        assert job.stage == OperationStage.QUEUED.value

    scheduler.assign_job_by_priority_age()

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.worker_name is not None
        assert job.stage == OperationStage.EXECUTING.value


# Test that jobs can be created/completed with no action-cache, a working action cache,
# and an action-cache that throws exceptions when used
@pytest.mark.parametrize("cache_errors", [True, False])
def test_complete_lease_action_cache_error(controller: ExecutionController, cache_errors: bool) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    if scheduler.action_cache and cache_errors:
        with mock.patch.object(scheduler.action_cache, "get_action_result", autospec=True) as ac_mock:
            ac_mock.side_effect = ConnectionError("Fake Connection Error")
            bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, skip_cache_lookup=False)
            assert ac_mock.call_count == 1
    else:
        bot_name, bot_id, _, _ = mock_queue_job_action(scheduler)

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    assert lease.state == LeaseState.ACTIVE.value

    lease.state = LeaseState.COMPLETED.value
    if scheduler.action_cache and cache_errors:
        with mock.patch.object(scheduler.action_cache, "update_action_result", autospec=True) as ac_mock:
            ac_mock.side_effect = StorageFullError("TestActionCache is full")
            leases, bot_version = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
            )
            assert ac_mock.call_count == 1
    else:
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
        )

    assert len(leases) == 0


def test_uncacheable_action(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, do_not_cache=True)

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    assert lease.state == LeaseState.ACTIVE.value

    lease.state = LeaseState.COMPLETED.value
    if scheduler.action_cache:
        # update_action_result should not be called for do_not_cache actions
        with mock.patch.object(scheduler.action_cache, "update_action_result", autospec=True) as ac_mock:
            leases, bot_version = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
            )
            assert ac_mock.call_count == 0
    else:
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
        )

    assert len(leases) == 0


def test_action_deduplication(controller: ExecutionController) -> None:
    # Verify two identical actions are deduplicated
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, operation_name, job_name = mock_queue_job_action(scheduler)
    _, _, operation_name2, job_name2 = mock_queue_job_action(scheduler)
    # Operation names should be different, but job names identical
    assert operation_name != operation_name2
    assert job_name == job_name2

    # Actions with do_not_cache=True must not be deduplicated
    _, _, uncacheable_operation_name, uncacheable_job_name = mock_queue_job_action(scheduler, do_not_cache=True)
    _, _, uncacheable_operation_name2, uncacheable_job_name2 = mock_queue_job_action(scheduler, do_not_cache=True)
    assert uncacheable_operation_name != uncacheable_operation_name2
    assert uncacheable_job_name != uncacheable_job_name2


def test_job_assignment_resets_worker_timestamps(
    controller: ExecutionController,
) -> None:
    # GIVEN: A scheduler with a job queued
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False, assign=False)
    assert job_name is not None

    # GIVEN: The job already has worker timestamps (perhaps from a previous execution attempt)
    old_start_time = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
    with instance_context("sql"):
        with scheduler._sql.session() as session:
            job = scheduler._get_job(job_name, session)
            assert job is not None
            assert not job.assigned
            job.worker_start_timestamp = old_start_time
            job.worker_completed_timestamp = datetime.datetime.utcnow()

    # WHEN: A worker connects and job assignment is attempted
    _, _ = add_bot(scheduler, "*")
    scheduler.assign_job_by_priority_age()

    # THEN: The job is successfully assigned, and its timestamps are reset
    with instance_context("sql"):
        with scheduler._sql.session() as session:
            job = scheduler._get_job(job_name, session)
            assert job is not None
            assert job.assigned
            assert job.worker_start_timestamp != old_start_time
            assert job.worker_completed_timestamp is None


@pytest.mark.parametrize(["job_instance_name", "bot_instance_name"], [["sql", "sql"], ["sql", "*"]])
def test_job_assignment_creates_logstream(
    controller: ExecutionController,
    job_instance_name: str,
    bot_instance_name: str,
) -> None:
    # GIVEN: A Scheduler with LogStream configured to use a mocked client
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.logstream_channel = mock.MagicMock()

    # WHEN: A bot connects, a job is assigned, and the bot synchronizes state with the Scheduler
    with mock.patch("buildgrid.server.scheduler.impl.logstream_client", new=mock_logstream_client()):
        bot_name, bot_id, operation_name, _ = mock_queue_job_action(scheduler, bot_instance_name=bot_instance_name)
        with instance_context(bot_instance_name):
            leases, _ = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
            )

    # THEN: A single lease was added to the BotSession
    assert len(leases) == 1

    # THEN: The metadata for this lease includes writable LogStream stream names
    with instance_context(bot_instance_name):
        [[_, lease_metadata]] = scheduler.get_metadata_for_leases(leases)
    metadata = ExecuteOperationMetadata()
    metadata.ParseFromString(lease_metadata)
    assert metadata.stdout_stream_name
    assert metadata.stdout_stream_name.endswith("stdout/mock-logstream/write")
    assert metadata.stderr_stream_name
    assert metadata.stderr_stream_name.endswith("stderr/mock-logstream/write")

    # THEN: Retrieving the relevant operation also retrieves the stream names
    with instance_context(job_instance_name):
        op = scheduler.load_operation(operation_name)
    metadata = ExecuteOperationMetadata()
    op.metadata.Unpack(metadata)
    assert metadata.stdout_stream_name
    assert metadata.stdout_stream_name.endswith("stdout/mock-logstream")
    assert metadata.stderr_stream_name
    assert metadata.stderr_stream_name.endswith("stderr/mock-logstream")


@pytest.mark.parametrize(["job_instance_name", "bot_instance_name"], [["sql", "sql"], ["sql", "*"]])
def test_job_retry_creates_new_logstream(
    controller: ExecutionController,
    job_instance_name: str,
    bot_instance_name: str,
) -> None:
    # GIVEN: A Scheduler with LogStream configured to use a mocked client
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.logstream_channel = mock.MagicMock()

    # WHEN: A bot connects, a job is assigned, and the bot synchronizes state with the Scheduler
    with mock.patch("buildgrid.server.scheduler.impl.logstream_client", new=mock_logstream_client()):
        bot_name, bot_id, operation_name, _ = mock_queue_job_action(scheduler, bot_instance_name=bot_instance_name)
        with instance_context(bot_instance_name):
            leases, _ = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
            )

    # THEN: A single lease was added to the BotSession
    assert len(leases) == 1

    # THEN: The metadata for this lease includes writable LogStream stream names
    with instance_context(bot_instance_name):
        [[_, lease_metadata]] = scheduler.get_metadata_for_leases(leases)
    metadata = ExecuteOperationMetadata()
    metadata.ParseFromString(lease_metadata)
    assert metadata.stdout_stream_name
    assert metadata.stdout_stream_name.endswith("stdout/mock-logstream/write")
    assert metadata.stderr_stream_name
    assert metadata.stderr_stream_name.endswith("stderr/mock-logstream/write")

    # WHEN: The bot disconnects, causing the job to be requeued
    with instance_context(bot_instance_name):
        scheduler.close_bot_sessions(bot_name)

    # WHEN: A new bot connects, and the job is reassigned
    with mock.patch(
        "buildgrid.server.scheduler.impl.logstream_client",
        new=mock_logstream_client(suffix="-second"),
    ):
        bot_name, bot_id = add_bot(scheduler, bot_instance_name)
        with instance_context(bot_instance_name):
            scheduler.assign_job_by_priority_age()
            leases, _ = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
            )

    # THEN: A single lease is added to the BotSession
    assert len(leases) == 1

    # THEN: The metadata for this lease includes stream names from a call to the second mocked LogStream client
    with instance_context(bot_instance_name):
        [[_, lease_metadata]] = scheduler.get_metadata_for_leases(leases)
    metadata = ExecuteOperationMetadata()
    metadata.ParseFromString(lease_metadata)
    assert metadata.stdout_stream_name
    assert metadata.stdout_stream_name.endswith("stdout/mock-logstream-second/write")
    assert metadata.stderr_stream_name
    assert metadata.stderr_stream_name.endswith("stderr/mock-logstream-second/write")


def test_get_metadata_for_leases(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.logstream_channel = mock.MagicMock()

    with mock.patch("buildgrid.server.scheduler.impl.logstream_client", new=mock_logstream_client()):
        bot_name, bot_id, operation_name, _ = mock_queue_job_action(scheduler)

        bot_version = 0
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 1
        lease = leases[0]
        lease.state = LeaseState.ACTIVE.value

        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
        )
        assert len(leases) == 1
        lease = leases[0]

    lease_metadata = scheduler.get_metadata_for_leases([lease])
    op = scheduler.load_operation(operation_name)
    op_metadata = ExecuteOperationMetadata()
    op.metadata.Unpack(op_metadata)

    assert op_metadata.partial_execution_metadata.worker == bot_id
    assert op_metadata.partial_execution_metadata.queued_timestamp.ToDatetime() != datetime.datetime(1970, 1, 1, 0, 0)
    assert op_metadata.partial_execution_metadata.worker_start_timestamp.ToDatetime() != datetime.datetime(
        1970, 1, 1, 0, 0
    )
    assert op_metadata.partial_execution_metadata.worker_completed_timestamp.ToDatetime() == datetime.datetime(
        1970, 1, 1, 0, 0
    )

    assert op_metadata.stdout_stream_name
    assert op_metadata.stdout_stream_name.endswith("stdout/mock-logstream")
    assert op_metadata.stderr_stream_name
    assert op_metadata.stderr_stream_name.endswith("stderr/mock-logstream")

    # Lease metadata should be the same, just with the write streams instead
    op_metadata.stdout_stream_name = op_metadata.stdout_stream_name + "/write"
    op_metadata.stderr_stream_name = op_metadata.stderr_stream_name + "/write"
    assert lease_metadata[0][0] == "executeoperationmetadata-bin"
    assert lease_metadata[0][1] == op_metadata.SerializeToString()


def test_list_operations(controller: ExecutionController) -> None:
    """Test that the scheduler reports the correct
    number of operations when calling list_operations()"""
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    operations, _ = scheduler.list_operations()
    assert len(operations) == 0

    mock_queue_job_action(scheduler)

    operations, _ = scheduler.list_operations()
    assert len(operations) == 1

    mock_queue_job_action(scheduler)
    mock_queue_job_action(scheduler)

    operations, _ = scheduler.list_operations()
    assert len(operations) == 3


def test_query_operation_metadata(controller: ExecutionController) -> None:
    """Test that the scheduler returns the expected `RequestMetadata`
    information for an operation.
    """
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    request_metadata = remote_execution_pb2.RequestMetadata()
    request_metadata.tool_details.tool_name = "my-tool"
    request_metadata.tool_details.tool_version = "1.0"
    request_metadata.tool_invocation_id = "invId123"
    request_metadata.correlated_invocations_id = "corId456"

    _, _, operation_name, _ = mock_queue_job_action(scheduler, request_metadata=request_metadata)
    metadata = scheduler.get_operation_request_metadata_by_name(operation_name)

    assert metadata is not None
    assert metadata.tool_details.tool_name == request_metadata.tool_details.tool_name
    assert metadata.tool_details.tool_version == request_metadata.tool_details.tool_version
    assert metadata.tool_invocation_id == request_metadata.tool_invocation_id
    assert metadata.correlated_invocations_id == request_metadata.correlated_invocations_id


# Validate that an ongoing job has an operation which is not marked done
def test_get_job_operation_ongoing(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, operation_name, _ = mock_queue_job_action(scheduler)

    operation = scheduler.load_operation(operation_name)
    assert operation.name == operation_name
    assert not operation.done


# Validate that a finished job has an operation with an ExecuteResponse
# containing an OK status code
def test_get_job_operation_finished(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    bot_name, bot_id, operation_name, _ = mock_queue_job_action(scheduler)

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    lease.state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    lease.state = LeaseState.COMPLETED.value
    test_action_result = remote_execution_pb2.ActionResult(exit_code=1, stdout_raw=b"test")
    lease.result.Pack(test_action_result)
    scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )

    operation = scheduler.load_operation(operation_name)
    assert operation.name == operation_name
    assert operation.done
    assert operation.WhichOneof("result") == "response"

    execute_response = remote_execution_pb2.ExecuteResponse()
    assert operation.response.Unpack(execute_response)

    assert execute_response.status.code == code_pb2.OK
    assert execute_response.result.stdout_raw == b"test"
    assert execute_response.result.exit_code == 1


# Validate that a failed job has an operation with an ExecuteResponse
# containing a non-OK status code
def test_get_job_operation_failed(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.max_job_attempts = 0
    bot_name, bot_id, operation_name, _ = mock_queue_job_action(scheduler)

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    lease.state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    lease.state = LeaseState.COMPLETED.value
    failed_status = Status(code=code_pb2.ABORTED, message="Failed Status")
    lease.status.CopyFrom(failed_status)
    scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )

    operation = scheduler.load_operation(operation_name)
    assert operation.name == operation_name
    assert operation.done
    assert operation.WhichOneof("result") == "response"

    execute_response = remote_execution_pb2.ExecuteResponse()
    assert operation.response.Unpack(execute_response)
    assert execute_response.status == failed_status


@flaky(max_runs=3)  # type: ignore [untyped-decorator, misc, unused-ignore]
@pytest.mark.parametrize("n_operations", [1, 2])
@pytest.mark.parametrize("sleep_time", [0.2])
def test_max_execution_timeout(
    controller_max_execution_timeout: ExecutionController,
    sleep_time: int,
    n_operations: int,
) -> None:
    assert controller_max_execution_timeout.execution_instance is not None
    scheduler: Scheduler = controller_max_execution_timeout.execution_instance.scheduler

    max_execution_timeout = scheduler.max_execution_timeout

    # Queue Job
    bot_name, bot_id, operation_name, job_name = mock_queue_job_action(scheduler)
    assert job_name is not None

    # Create n operations
    operation_names = [operation_name]
    with scheduler._sql.session() as session:
        for i in range(n_operations - 1):
            operation_names.append(
                scheduler._create_operation(
                    session,
                    job_name=job_name,
                    client_identity=None,
                    request_metadata=None,
                    operation_count=n_operations,
                )
            )

    for i in range(n_operations):
        operation_initially = scheduler.load_operation(operation_names[i])
        assert operation_initially.done is False

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    lease.state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    # Make sure it was marked as "Executing"
    op_after_assignment = scheduler.load_operation(operation_name)
    assert not op_after_assignment.done

    # Wait and see it marked as cancelled when exceeding execution timeout...
    time.sleep(sleep_time)

    if max_execution_timeout and sleep_time >= max_execution_timeout:
        for operation_name in operation_names:
            operation = scheduler.load_operation(operation_name)
            assert operation.done is True
            # Verify the response in the operation has the correct
            # status code
            assert operation.WhichOneof("result") == "response"
            execute_response = remote_execution_pb2.ExecuteResponse()
            assert operation.response.Unpack(execute_response)
            assert execute_response.status.code == code_pb2.DEADLINE_EXCEEDED

        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
        )
        # lease is dropped
        assert len(leases) == 0

    else:
        for operation_name in operation_names:
            operation = scheduler.load_operation(operation_name)
            assert operation.done is False
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
        )
        assert len(leases) == 1
        lease = leases[0]
        assert lease.state == LeaseState.ACTIVE.value


def test_max_execution_timeout_rejection(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.max_execution_timeout = 1

    action = remote_execution_pb2.Action(command_digest=command_digest, do_not_cache=False, timeout=Duration(seconds=2))
    action_digest = create_digest(action.SerializeToString())

    with create_write_session(action_digest) as write_session:
        write_session.write(action.SerializeToString())
        scheduler.storage.commit_write(action_digest, write_session)

    with pytest.raises(InvalidArgumentError):
        scheduler.queue_job_action(
            action=action,
            action_digest=action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=False,
            request_metadata=None,
        )


def test_job_deduplication_in_scheduling(controller: ExecutionController) -> None:
    # GIVEN: a scheduler
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # WHEN: two identical Actions are queued for execution
    _, _, operation_name1, job_name1 = mock_queue_job_action(
        scheduler, do_not_cache=False, create_bot=False, assign=False
    )
    _, _, operation_name2, job_name2 = mock_queue_job_action(
        scheduler, do_not_cache=False, create_bot=False, assign=False
    )

    # THEN: the jobs are be deduplicated, but separate operations are created
    assert job_name1 == job_name2
    assert operation_name1 != operation_name2
    with scheduler._sql.session() as session:
        job_count = session.scalar(select(func.count(models.JobEntry.name)).filter_by(name=job_name1))
        assert job_count == 1
        operation_count = session.scalar(select(func.count(models.OperationEntry.name)).filter_by(job_name=job_name1))
        assert operation_count == 2


def test_job_reprioritisation(controller: ExecutionController) -> None:
    # GIVEN: a scheduler
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # WHEN: an Action with a low priority is queued
    _, _, _, job_name_1 = mock_queue_job_action(scheduler, job_priority=10, create_bot=False, assign=False)
    assert job_name_1 is not None

    # THEN: the priority is correctly recorded
    with scheduler._sql.session() as session, instance_context("sql"):
        job = scheduler._get_job(job_name_1, session)
        assert job is not None
        assert job.priority == 10

    # WHEN: a second, identical Action with a higher priority is queued
    _, _, _, job_name_2 = mock_queue_job_action(scheduler, job_priority=1, create_bot=False, assign=False)
    assert job_name_2 is not None

    # THEN: the jobs are deduplicated
    assert job_name_1 == job_name_2

    # THEN: the internal priority of the job is updated to match the higher priority request
    with scheduler._sql.session() as session, instance_context(""):
        job = scheduler._get_job(job_name_1, session)
        assert job is not None
        assert job.priority == 1


def test_do_not_cache_no_deduplication(controller: ExecutionController) -> None:
    # GIVEN: a scheduler with an uncacheable Action queued
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    _, _, operation_name_1, job_name_1 = mock_queue_job_action(
        scheduler, do_not_cache=True, create_bot=False, assign=False
    )

    # WHEN: a cacheable version of the same Action is queued
    _, _, operation_name_2, job_name_2 = mock_queue_job_action(
        scheduler, do_not_cache=False, create_bot=False, assign=False
    )

    # THEN: The jobs are not deduplicated because of do_not_cache, and two operations are created
    assert job_name_1 != job_name_2
    assert operation_name_1 != operation_name_2
    with scheduler._sql.session() as session:
        job_count = session.scalar(select(func.count(models.JobEntry.name)))
        assert job_count == 2
        operation_count = session.scalar(select(func.count(models.OperationEntry.name)))
        assert operation_count == 2


@mock.patch("buildgrid.server.metrics_utils.create_timer_record", new=mock_create_timer_record)
def test_cancel_operation(controller: ExecutionController) -> None:
    # GIVEN: a scheduler
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # WHEN: a job is queued and assigned to a bot
    _, bot_id, operation_name, job_name = mock_queue_job_action(scheduler)

    # WHEN: all operations for the job are subsequently cancelled
    with instance_context("sql"):
        scheduler.cancel_operation(operation_name)

    # THEN: the job is marked as completed, with a completion timestamp set
    with scheduler._sql.session() as session:
        job = session.scalars(select(models.JobEntry).filter_by(name=job_name)).first()
        assert job is not None
        assert job.stage == OperationStage.COMPLETED.value
        assert len(job.operations) > 0
        assert all(op.cancelled for op in job.operations)
        assert job.worker_completed_timestamp is not None

        # THEN: the job's history log is as expected
        stmt = select(models.JobHistoryEntry).where(models.JobHistoryEntry.job_name == job_name)
        history: Sequence[models.JobHistoryEntry] = list(session.execute(stmt).scalars())
        assert len(history) == 5

        # Creation event, no payload
        assert history[0].event_type == JobHistoryEvent.CREATION.value

        # Operation creation
        assert history[1].event_type == JobHistoryEvent.NEW_OPERATION.value
        assert history[1].payload is not None

        # Assignment event
        assert history[2].event_type == JobHistoryEvent.ASSIGNMENT.value
        assert history[2].payload is not None
        assert history[2].payload["worker_name"] == bot_id  # type: ignore [index]

        # Operation cancellation
        assert history[3].event_type == JobHistoryEvent.OPERATION_CANCELLATION.value
        assert history[3].payload is not None

        # Overall cancellation
        assert history[4].event_type == JobHistoryEvent.CANCELLATION.value
        assert history[4].payload is not None


@pytest.fixture
def mock_metering_client() -> Iterator[Mock]:
    usage_sink = []

    def mock_put_usage(identity: Any, operation_name: str, usage: Any) -> None:
        usage_sink.append((identity, operation_name, usage))

    mocked = mock.Mock()
    mocked.put_usage.side_effect = mock_put_usage
    mocked.sink = usage_sink
    yield mocked


def store_message(scheduler: Scheduler, message: Message) -> Digest:
    binary = message.SerializeToString()
    digest = create_digest(binary)
    scheduler.storage.bulk_update_blobs([(digest, binary)])
    return digest


@pytest.fixture
def mock_execution_metadata(controller: ExecutionController) -> ExecutedActionMetadata:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    action_digest = store_message(scheduler, Action())

    execution_stats = ExecutionStatistics()
    execution_stats.command_rusage.maxrss = 100
    execution_stats_any = ProtoAny()
    execution_stats_any.Pack(execution_stats)
    execution_stats_digest = store_message(scheduler, execution_stats_any)

    digest_any = ProtoAny()
    digest_any.Pack(execution_stats_digest)
    execution_metadata = remote_execution_pb2.ExecutedActionMetadata()
    execution_metadata.auxiliary_metadata.append(digest_any)

    now = datetime.datetime.now()
    with scheduler._sql.session(exceptions_to_not_raise_on=[Exception]) as session:
        session.add(
            JobEntry(
                name="job",
                instance_name="sql",
                action_digest=digest_to_string(action_digest),
                action=b"",
                create_timestamp=now,
                queued_timestamp=now,
                schedule_after=now,
                assigned=False,
                n_tries=1,
                platform_requirements="",
                property_label="unknown",
                command="foo",
            )
        )
        session.add(ClientIdentityEntry(id=1, instance="sql", workflow="build", actor="tool", subject="user1"))
        session.add(ClientIdentityEntry(id=2, instance="sql", workflow="build", actor="tool", subject="user2"))
        session.add(OperationEntry(name="op1", job_name="job", client_identity_id=1))
        session.add(OperationEntry(name="op2", job_name="job", client_identity_id=2))

    return execution_metadata


def test_publish_execution_stats(
    controller: ExecutionController,
    mock_metering_client: Mock,
    mock_execution_metadata: Mock,
) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.metering_client = mock_metering_client

    with instance_context("sql"):
        scheduler.publish_execution_stats("job", "sql", mock_execution_metadata, "linux")
    assert len(mock_metering_client.sink) == 2


def test_publish_execution_stats_fetch_fails_no_throw(
    controller: ExecutionController,
    mock_metering_client: Mock,
    mock_execution_metadata: Mock,
) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.metering_client = mock_metering_client
    mock_metering_client.put_usage.side_effect = MeteringServiceHTTPError(503, "big bang")

    with instance_context("sql"):
        scheduler.publish_execution_stats("job", "sql", mock_execution_metadata)
    assert len(mock_metering_client.sink) == 0


def test_publish_execution_stats_invalid_execution_stats(
    controller: ExecutionController,
    mock_metering_client: Mock,
    mock_execution_metadata: Mock,
) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    scheduler.metering_client = mock_metering_client

    some_digest = Digest()
    some_digest_any = ProtoAny()
    some_digest_any.Pack(some_digest)
    mock_execution_metadata.auxiliary_metadata.pop()
    mock_execution_metadata.auxiliary_metadata.append(some_digest_any)

    with instance_context("sql"):
        scheduler.publish_execution_stats("job", "sql", mock_execution_metadata, "linux")
    assert len(mock_metering_client.sink) == 0


def test_publish_execution_stats_no_client(
    controller: ExecutionController,
    mock_metering_client: Mock,
    mock_execution_metadata: Mock,
) -> None:
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler
    # Just dont assign a client?? Weird test

    with instance_context("sql"):
        scheduler.publish_execution_stats("job", "sql", mock_execution_metadata, "linux")
    assert len(mock_metering_client.sink) == 0


def test_instance_isolation_load_operation(
    isolated_controllers: tuple[ExecutionController, ExecutionController],
) -> None:
    controller_a, controller_b = isolated_controllers
    assert controller_a.execution_instance is not None
    assert controller_b.execution_instance is not None
    scheduler_a = controller_a.execution_instance.scheduler
    scheduler_b = controller_b.execution_instance.scheduler

    with instance_context("instance-a"):
        _, _, operation_name, _ = mock_queue_job_action(scheduler_a)
        # Check that fetching the operation respects instances
        scheduler_a.load_operation(operation_name)

    with instance_context("instance-b"):
        with pytest.raises(NotFoundError):
            scheduler_b.load_operation(operation_name)


def test_instance_isolation_lease_assignment(
    isolated_controllers: tuple[ExecutionController, ExecutionController],
) -> None:
    controller_a, controller_b = isolated_controllers
    assert controller_a.execution_instance is not None
    assert controller_b.execution_instance is not None
    scheduler_a: Scheduler = controller_a.execution_instance.scheduler
    scheduler_b: Scheduler = controller_b.execution_instance.scheduler
    bot_id = "test-worker"

    # Queue a job into instance-a
    with instance_context("instance-a"):
        mock_queue_job_action(scheduler_a, create_bot=False, assign=False)

    # Connect a bot to instance-b
    with instance_context("instance-b"):
        bot_name = scheduler_b.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
        )

    # Attempt to assign work in the scheduler that got the job
    scheduler_a.assign_job_by_priority_age(failure_backoff=0)

    # The bot should have no lease created
    with instance_context("instance-b"):
        bot_version = 0
        leases, bot_version = scheduler_b.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 0

    # Attempt to assign work in the scheduler that has the bot
    scheduler_b.assign_job_by_priority_age(failure_backoff=0)

    # There should still be no lease for the job, since it's instance name doesn't match the bot
    with instance_context("instance-b"):
        leases, bot_version = scheduler_b.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 0

    # Synchronize the bot with the wrong instance
    with instance_context("instance-a"):
        with pytest.raises(InvalidArgumentError):
            scheduler_a.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, 0, [], CancellationContext(mock_context())
            )

    with instance_context("instance-b"):
        scheduler_b.close_bot_sessions(bot_name)

    # Add the bot to the instance which has a job queued
    with instance_context("instance-a"):
        bot_name = scheduler_a.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
        )

    # Attempt to assign work again
    scheduler_a.assign_job_by_priority_age(failure_backoff=0)

    # This time the job should have a lease
    with instance_context("instance-a"):
        bot_version = 0
        leases, bot_version = scheduler_a.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 1
        lease = leases[0]
        assert lease.state == LeaseState.ACTIVE.value


def test_isolated_instances_list_operations(
    isolated_controllers: tuple[ExecutionController, ExecutionController],
) -> None:
    controller_a, controller_b = isolated_controllers
    assert controller_a.execution_instance is not None
    assert controller_b.execution_instance is not None
    scheduler_a = controller_a.execution_instance.scheduler
    scheduler_b = controller_b.execution_instance.scheduler

    with instance_context("instance-a"):
        mock_queue_job_action(scheduler_a)

    # Check that ListOperations respects instances
    with instance_context("instance-a"):
        operations_a, _ = scheduler_a.list_operations()
    with instance_context("instance-b"):
        operations_b, _ = scheduler_b.list_operations()

    assert len(operations_a) == 1
    assert len(operations_b) == 0


def test_wildcard_bot_lease_assignment(
    isolated_controllers: tuple[ExecutionController, ExecutionController],
) -> None:
    controller_a, controller_b = isolated_controllers
    assert controller_a.execution_instance is not None
    assert controller_b.execution_instance is not None
    scheduler_a: Scheduler = controller_a.execution_instance.scheduler
    scheduler_b: Scheduler = controller_b.execution_instance.scheduler
    bot_id = "test-worker"

    # Queue a job into instance-a
    with instance_context("instance-a"):
        mock_queue_job_action(scheduler_a, create_bot=False, assign=False)

    # Connect a wildcard bot in the context of instance-b
    # This instance context should be unused, but is set to validate that a wildcard bot can
    # definitely work cross-instance
    with instance_context("instance-b"):
        bot_name = scheduler_b.add_bot_entry(
            bot_name=f"*/{uuid.uuid4()}",
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            instance_name="*",
        )

    # Attempt to assign work in the scheduler that got the job
    scheduler_a.assign_job_by_priority_age(failure_backoff=0)

    # The bot should have a job assigned to it, and its metadata should be attainable from instance-b
    with instance_context("instance-b"):
        bot_version = 0
        leases, bot_version = scheduler_b.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 1

        metadata = scheduler_b.get_metadata_for_leases(leases)
        assert len(metadata) == 1

        # Complete the lease
        leases[0].state = LeaseState.COMPLETED.value
        leases, bot_version = scheduler_b.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        assert len(leases) == 0

        with scheduler_a._sql.session() as session:
            job = session.execute(
                select(JobEntry).where(JobEntry.stage < OperationStage.COMPLETED.value)
            ).scalar_one_or_none()
            assert job is None


def test_wildcard_bot_retries_jobs(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler: Scheduler = controller.execution_instance.scheduler
    bot_id = "test-worker"

    # Queue a job into instance-a
    with instance_context("instance-a"):
        _, _, _, job_name = mock_queue_job_action(scheduler, create_bot=False, assign=False)
        assert job_name is not None

    # Connect a wildcard bot
    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=f"*/{uuid.uuid4()}",
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            instance_name="*",
        )

    # Attempt to assign work in the scheduler that got the job
    scheduler.assign_job_by_priority_age(failure_backoff=0)

    # The job should be assigned
    with instance_context("instance-a"):
        with scheduler._sql.session() as session:
            job = scheduler._get_job(job_name, session)
            assert job is not None
            assert job.assigned

    # Reconnect a bot with the same session ID
    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=f"*/{uuid.uuid4()}",
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            instance_name="*",
        )

    # The job should have been re-queued
    with instance_context("instance-a"):
        with scheduler._sql.session() as session:
            job = scheduler._get_job(job_name, session)
            assert job is not None
            assert not job.assigned


def test_wildcard_bot_deletes_old_sessions(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler: Scheduler = controller.execution_instance.scheduler
    bot_id = "test-worker"

    # Connect a bot
    with instance_context("instance-a"):
        scheduler.add_bot_entry(
            bot_name=f"*/{uuid.uuid4()}",
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            instance_name="instance-a",
        )

    # Reconnect a bot with the same session ID
    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=f"*/{uuid.uuid4()}",
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            instance_name="*",
        )

    # There should only be a single bot with the given ID, and it should be the one using the
    # wildcard instance name.
    with scheduler._sql.session() as session:
        stmt = select(BotEntry).where(BotEntry.bot_id == bot_id)
        bots = session.execute(stmt).scalars().all()
        assert len(bots) == 1

        bot = bots[0]
        assert bot.instance_name == "*"


def test_max_queue_size(controller_max_queue_size: ExecutionController) -> None:
    assert controller_max_queue_size.execution_instance is not None
    scheduler = controller_max_queue_size.execution_instance.scheduler

    max_queue_size = scheduler.max_queue_size

    # Queue jobs up to the maximum queue size
    for _ in range(max_queue_size or 10):
        mock_queue_job_action(scheduler, do_not_cache=True, assign=False)

    if max_queue_size is not None:
        # Attempt to queue an additional job, expecting an error
        with pytest.raises(ResourceExhaustedError):
            mock_queue_job_action(scheduler, do_not_cache=True, assign=False)


def test_queue_job_action_with_scheduling_metadata_locality_hint(
    controller: ExecutionController,
) -> None:
    """Test that jobs are created with locality_hint when scheduling metadata is provided."""
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # Create scheduling metadata with locality hint
    _, _, _, job_name = mock_queue_job_action(scheduler, locality_hint="a")

    # Check that the job has the correct locality_hint stored
    with scheduler._sql.session() as session:
        job = session.execute(select(JobEntry).where(JobEntry.name == job_name)).scalar_one()
        assert job.locality_hint == "a"


def test_queue_job_action_with_scheduling_metadata_empty_locality_hint(
    controller: ExecutionController,
) -> None:
    """Test that jobs are created with NULL locality_hint when scheduling metadata has empty string."""
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # Queue job with scheduling metadata but empty locality hint
    _, _, _, job_name = mock_queue_job_action(scheduler, locality_hint="")

    # Check that the job has NULL locality_hint (empty string converts to None)
    with scheduler._sql.session() as session:
        job = session.execute(select(JobEntry).where(JobEntry.name == job_name)).scalar_one()
        assert job.locality_hint is None


def test_queue_job_action_without_scheduling_metadata(
    controller: ExecutionController,
) -> None:
    """Test that jobs are created with NULL locality_hint when no scheduling metadata is provided."""
    assert controller.execution_instance is not None
    scheduler = controller.execution_instance.scheduler

    # Queue job without scheduling metadata (backward compatibility)
    _, _, _, job_name = mock_queue_job_action(scheduler, locality_hint=None)

    # Check that the job has NULL locality_hint
    with scheduler._sql.session() as session:
        job = session.execute(select(JobEntry).where(JobEntry.name == job_name)).scalar_one()
        assert job.locality_hint is None


@pytest.mark.parametrize("controller", ["action-cache"], indirect=True)
def test_complete_job_with_locality_hint(
    controller: ExecutionController, controller_postgres: ExecutionController
) -> None:
    """Test that jobs with locality hint can be competed."""

    for c in [controller, controller_postgres]:
        assert c.execution_instance is not None
        scheduler: Scheduler = c.execution_instance.scheduler

        # Create scheduling metadata with locality hint
        scheduling_metadata = SchedulingMetadata()
        locality_hint = "a"
        scheduling_metadata.locality_hint = locality_hint

        # Queue job with scheduling metadata
        bot_name = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id="test-worker",
            bot_session_status=BotStatus.OK.value,
        )
        bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler, locality_hint=locality_hint)
        assert job_name is not None

        # Complete the job
        bot_version = 0
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 1
        leases[0].state = LeaseState.ACTIVE.value
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        assert len(leases) == 1
        leases[0].state = LeaseState.COMPLETED.value
        scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        with scheduler._sql.session() as session:
            job = scheduler._get_job(job_name, session)
            assert job is not None
            assert job.locality_hint == locality_hint

            # bot is associated with the locality hint
            locality_hints = (
                session.execute(select(BotLocalityHintEntry).where(BotLocalityHintEntry.bot_name == bot_name))
                .scalars()
                .all()
            )
            assert len(locality_hints) == 1
            assert locality_hints[0].locality_hint == locality_hint


@pytest.mark.parametrize("controller", ["action-cache"], indirect=True)
def test_complete_job_with_locality_hints_limit_size(
    controller: ExecutionController, controller_postgres: ExecutionController
) -> None:
    """Test that jobs with locality hint can be competed."""

    for c in [controller, controller_postgres]:
        assert c.execution_instance is not None
        scheduler: Scheduler = c.execution_instance.scheduler

        # Create scheduling metadata with locality hint
        scheduling_metadata = SchedulingMetadata()
        locality_hint = "a"
        scheduling_metadata.locality_hint = locality_hint

        # Queue and complete jobs with scheduling metadata
        bot_name = ""  # placeholder, all jobs will use the same bot name
        for _ in range(20):
            bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, locality_hint=locality_hint)
            bot_version = 0
            leases, bot_version = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
            )

            assert len(leases) == 1
            leases[0].state = LeaseState.COMPLETED.value
            scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
            )

        with scheduler._sql.session() as session:
            locality_hints = (
                session.execute(select(BotLocalityHintEntry).where(BotLocalityHintEntry.bot_name == bot_name))
                .scalars()
                .all()
            )
            # size is limited
            assert len(locality_hints) == scheduler.bot_locality_hint_limit


def test_locality_hint_not_recorded_on_non_zero_exit_code(
    controller_postgres: ExecutionController,
) -> None:
    """Test that locality hint is not recorded when action result has non-zero exit code."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    locality_hint = "test-locality"

    # Queue job with locality hint
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler, locality_hint=locality_hint)

    # Complete the job with exit_code=1 (failure)
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]
    lease.state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    lease = leases[0]

    # Complete with failed exit code
    test_action_result = remote_execution_pb2.ActionResult(exit_code=1, stdout_raw=b"failed")
    lease.result.Pack(test_action_result)
    lease.state = LeaseState.COMPLETED.value
    scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [lease], CancellationContext(mock_context())
    )

    # Verify locality hint was NOT recorded due to non-zero exit code
    with scheduler._sql.session() as session:
        locality_hints = (
            session.execute(select(BotLocalityHintEntry).where(BotLocalityHintEntry.bot_name == bot_name))
            .scalars()
            .all()
        )
        assert len(locality_hints) == 0


def test_proactive_fetch_to_capacity_enabled(
    controller_postgres: ExecutionController,
) -> None:
    """Test that with proactive_fetch_to_capacity=True, bot capacity is used for proactive fetching."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.proactive_fetch_to_capacity = True

    # Create a bot with capacity 3
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, bot_capacity=3, do_not_cache=True, assign=False)
    # Add another 3 jobs
    for _ in range(3):
        mock_queue_job_action(scheduler, create_bot=False, do_not_cache=True, assign=False)

    # Bot should have 3 active leases (full capacity)
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 3

    # Complete only 1 job
    completed_leases = [leases[0]]
    completed_leases[0].state = LeaseState.COMPLETED.value

    # With proactive_fetch_to_capacity=True, should fetch up to full capacity (3 jobs total)
    remaining_leases = leases[1:]  # The 2 jobs still active
    new_leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name,
        bot_id,
        BotStatus.OK.value,
        bot_version,
        completed_leases + remaining_leases,
        CancellationContext(mock_context()),
    )

    # Should have 3 total leases: 2 remaining + 1 newly fetched to reach full capacity
    assert len(new_leases) == 3


def test_bot_proactively_fetch(controller_postgres: ExecutionController) -> None:
    """Test that bots can proactively fetch jobs when bot_proactively_fetch is enabled."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    # Enqueue 2 jobs
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)
    _ = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)
    scheduler.assign_job_by_priority_age()  # successful
    scheduler.assign_job_by_priority_age(failure_backoff=60)  # failure, adding `schedule_after`

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    leases[0].state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases)

    with scheduler._sql.session() as session:
        jobs = session.execute(select(JobEntry)).scalars().all()
        assert len(jobs) == 2
        assert jobs[0].stage == OperationStage.COMPLETED.value
        # Assert that the second job is scheduled
        assert jobs[1].assigned
        assert jobs[1].worker_name == bot_id


def test_bot_proactively_fetch_near_max_quota(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    # Create quota configs for two instances, allowing only 1 concurrent job each
    scheduler.put_instance_quota("sql", "linux", 1, 1)
    scheduler.put_instance_quota("other", "linux", 1, 1)

    # Enqueue 2 jobs
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)
    _ = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)
    scheduler.assign_job_by_priority_age()  # successful
    scheduler.assign_job_by_priority_age(failure_backoff=60)  # failure, adding `schedule_after`

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    leases[0].state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases)

    with scheduler._sql.session() as session:
        jobs = session.execute(select(JobEntry)).scalars().all()
        assert len(jobs) == 2
        assert jobs[0].stage == OperationStage.COMPLETED.value
        # Assert that the second job is scheduled
        assert jobs[1].assigned
        assert jobs[1].worker_name == bot_id

        # Assert that the bot has no more capacity to fetch more jobs
        bot_entry = session.execute(select(BotEntry).where(BotEntry.name == bot_name)).scalar_one()
        assert bot_entry.capacity == 0

    # Check usage is recorded correctly
    usage = scheduler.get_instance_quota("sql", "linux")
    assert usage is not None
    assert usage.current_usage == 1


def test_bot_proactive_fetch_prefers_min_quota_over_max_quota(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    # Configure quotas for two instances in the "linux" cohort
    # Instance "a": min=2, max=3 — usage=0, well below min_quota
    # Instance "b": min=0, max=3 — usage=0, at min_quota, only below max_quota
    scheduler.put_instance_quota("a", "linux", 2, 3)
    scheduler.put_instance_quota("b", "linux", 0, 3)

    # Create a wildcard bot with capacity 1
    with instance_context("*"):
        bot_name = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id="test-worker",
            bot_session_status=BotStatus.OK.value,
            bot_capacity=1,
        )
    bot_id = "test-worker"

    # Queue a job in "sql" (no quota configured) and assign it — bot capacity drops to 0
    scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements={},
        property_label="unknown",
        priority=0,
        skip_cache_lookup=True,
    )
    scheduler.assign_job_by_priority_age()

    # Queue a job in "b" first, then one in "a"
    # "b" is queued first so it has an earlier timestamp — without quota-aware
    # prioritization it would be picked first by ORDER BY priority, queued_timestamp
    with instance_context("b"):
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
        )
    with instance_context("a"):
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
        )

    # Both jobs fail assignment (bot has 0 capacity), setting schedule_after 60s in future
    # (required by the proactive fetch schedule_after >= now filter)
    scheduler.assign_job_by_priority_age(failure_backoff=60)
    scheduler.assign_job_by_priority_age(failure_backoff=60)

    # Sync bot to retrieve the active lease for the "sql" job
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1

    # Complete the "sql" job — bot now has capacity for proactive fetch
    leases[0].state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )

    # Proactive fetch should pick exactly 1 new job
    assert len(leases) == 1

    # The fetched job should be from instance "a" (tier 1: below min_quota),
    # not from instance "b" (only tier 2: below max_quota)
    usage_a = scheduler.get_instance_quota("a", "linux")
    assert usage_a is not None
    assert usage_a.current_usage == 1

    usage_b = scheduler.get_instance_quota("b", "linux")
    assert usage_b is not None
    assert usage_b.current_usage == 0


def test_schedule_by_instances(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    # Enqueue a job without assigning
    bot_name, bot_id, _, _ = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)

    # Assign by instance names
    num_updated = scheduler.assign_job_by_priority_age(failure_backoff=0.1, instance_names=frozenset(["sql", "foo"]))
    assert num_updated == 1

    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) != 0
    # Complete the  job
    leases[0].state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases) != 0
    leases[0].state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases) == 0


def test_schedule_by_instances_isolation(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    # Enqueue a job without assigning
    _, _, _, job_name = mock_queue_job_action(scheduler, do_not_cache=True, skip_cache_lookup=True, assign=False)
    assert job_name is not None

    # Assign by unrelated instance names
    num_updated = scheduler.assign_job_by_priority_age(failure_backoff=0.1, instance_names=frozenset(["foo", "bar"]))
    assert num_updated == 0


def test_scheduling_match_by_locality(controller_postgres: ExecutionController) -> None:
    """Test that a job is scheduled based on locality hints."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    locality_hint = "a"
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler, locality_hint=locality_hint, assign=False)
    assert job_name is not None
    # Add another bot with locality hint
    bot_id2 = "test-worker2"
    bot_name2 = scheduler.add_bot_entry(
        bot_name=generate_bot_name(),
        bot_session_id=bot_id2,
        bot_session_status=BotStatus.OK.value,
    )
    with scheduler._sql.session() as session:
        bot_locality_hint = BotLocalityHintEntry(bot_name=bot_name2, locality_hint=locality_hint)
        session.add(bot_locality_hint)

    # Run assignment
    strategy = AssignByLocality(sampling=SamplingConfig(sample_size=2))
    bot_fn = create_bot_assignment_fn(strategy, scheduler, "locality")
    scheduler.assign_job_by_priority_age(bot_assignment_fn=bot_fn)

    # Job is assigned to the bot with matching locality hint
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 0
    bot_version2 = 0
    leases, bot_version2 = scheduler.synchronize_bot_leases(
        bot_name2, bot_id2, BotStatus.OK.value, bot_version2, [], CancellationContext(mock_context())
    )
    assert len(leases) > 0


def test_scheduling_match_by_locality_fallback(
    controller_postgres: ExecutionController,
) -> None:
    """Test that a job is scheduled by the fallback mechanism."""

    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    locality_hint = "a"
    bot_name, bot_id, _, job_name = mock_queue_job_action(scheduler, locality_hint=locality_hint, assign=False)
    assert job_name is not None

    # Run assignment
    scheduler.assign_job_by_priority_age(
        bot_assignment_fn=lambda session, job, brf: scheduler.match_bot_by_locality(
            session, job, bot_requirements_filter=brf
        )
    )

    # Even though the bot has no locality hint, it should still be able to fetch the job
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) > 0


def test_queue_position(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler

    # Helper function to add a mock job to queue
    def add_mock_job(priority: int) -> str:
        scheduling_metadata = SchedulingMetadata()
        operation_name = scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=priority,
            skip_cache_lookup=True,
            request_metadata=None,
            scheduling_metadata=scheduling_metadata,
        )
        return operation_name

    # Add 5 jobs of varying priority and timestamp to queue
    first = add_mock_job(0)
    low = add_mock_job(1)
    second = add_mock_job(0)
    high = add_mock_job(-1)
    third = add_mock_job(0)

    assert first != second

    # Check queue positions
    instance_name = "sql"

    assert "~1" == scheduler.get_queue_position(high, instance_name)
    assert "~2" == scheduler.get_queue_position(first, instance_name)
    assert "~3" == scheduler.get_queue_position(second, instance_name)
    assert "~4" == scheduler.get_queue_position(third, instance_name)
    assert "~5" == scheduler.get_queue_position(low, instance_name)

    assert "3+" == scheduler.get_queue_position(third, instance_name, job_search_limit=3)
    assert "3+" == scheduler.get_queue_position(low, instance_name, job_search_limit=3)

    # Create a bot
    scheduler.add_bot_entry(
        bot_name=generate_bot_name(),
        bot_session_id="test-worker",
        bot_session_status=BotStatus.OK.value,
    )

    # Assign the next job
    scheduler.assign_job_by_priority_age()

    # Check queue positions have moved up
    assert "~0" == scheduler.get_queue_position(high, instance_name)
    assert "~1" == scheduler.get_queue_position(first, instance_name)
    assert "~2" == scheduler.get_queue_position(second, instance_name)
    assert "~3" == scheduler.get_queue_position(third, instance_name)
    assert "~4" == scheduler.get_queue_position(low, instance_name)


def test_scheduling_match_by_sampled_capacity(
    controller_postgres: ExecutionController,
) -> None:
    """Test that a job is scheduled based on load-balancing via sampling."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    # Add a bot and assign a job to it
    # The remaining capacity of the bot is 1
    mock_queue_job_action(scheduler, bot_capacity=2)

    # Add another bot (capacity == 2) & job pair
    bot_id2 = "test-worker2"
    _ = scheduler.add_bot_entry(
        bot_name=generate_bot_name(),
        bot_session_id=bot_id2,
        bot_session_status=BotStatus.OK.value,
        bot_capacity=2,
    )
    _, _, _, job_name = mock_queue_job_action(
        scheduler,
        create_bot=False,
        assign=False,
        bot_capacity=2,
        skip_cache_lookup=True,
        do_not_cache=True,
    )
    assert job_name is not None

    # Run assignment
    strategy = AssignByCapacity(sampling=SamplingConfig(sample_size=2))
    bot_fn = create_bot_assignment_fn(strategy, scheduler, "sampled")
    scheduler.assign_job_by_priority_age(bot_assignment_fn=bot_fn)

    # Job is assigned to the idle bot that has the higher capacity
    with scheduler._sql.session() as session:
        job = session.execute(select(JobEntry).where(JobEntry.name == job_name)).scalar_one()
        assert job.assigned is True
        assert job.worker_name == bot_id2


def test_add_bot_with_cohorts(controller: ExecutionController) -> None:
    assert controller.execution_instance is not None
    scheduler: Scheduler = controller.execution_instance.scheduler

    # unknown label is mapped to linux cohort
    bot_name = generate_bot_name()
    scheduler.add_bot_entry(
        bot_name=bot_name,
        bot_session_id="unknown-bot",
        bot_property_labels=None,
        bot_session_status=BotStatus.OK.value,
    )
    with scheduler._sql.session() as session:
        bot = session.execute(select(BotEntry).where(BotEntry.name == bot_name)).scalar_one()
        assert bot.cohort == "linux"

    # bot with both labels "os-foo-1.0" and "os-foo-1.1"
    bot_name = generate_bot_name()
    scheduler.add_bot_entry(
        bot_name=bot_name,
        bot_session_id="foo-bot",
        bot_property_labels=["os-foo-1.0", "os-foo-1.1"],
        bot_session_status=BotStatus.OK.value,
    )
    with scheduler._sql.session() as session:
        bot = session.execute(select(BotEntry).where(BotEntry.name == bot_name)).scalar_one()
        assert bot.cohort == "os-foo-1"


def test_usage_tracking(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("sql", "linux", 10, 10)

    bot_name, bot_id, op_name, job_name = mock_queue_job_action(
        scheduler, bot_capacity=5, assign=False, do_not_cache=True
    )
    scheduler.assign_job_by_priority_age()

    with scheduler._sql.session() as session:
        job = session.execute(select(JobEntry).where(JobEntry.name == job_name)).scalar_one_or_none()
        assert job is not None
        assert job.assigned is True
        assert job.worker_name == bot_id

        bot = session.execute(select(BotEntry).where(BotEntry.name == bot_name)).scalar_one_or_none()
        assert bot is not None
        assert bot.cohort == "linux"
        assert bot.capacity == 4

    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 1

    mock_queue_job_action(scheduler, bot_capacity=5, assign=False, do_not_cache=True)
    scheduler.assign_job_by_priority_age()

    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 2

    # Cancel the first job
    scheduler.cancel_operation(op_name)
    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 1

    # Complete the second job
    bot_version = 0
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
    )
    assert len(leases) == 1
    leases[0].state = LeaseState.ACTIVE.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases) == 1
    leases[0].state = LeaseState.COMPLETED.value
    leases, bot_version = scheduler.synchronize_bot_leases(
        bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
    )
    assert len(leases) == 0

    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 0


def test_usage_reset_after_closing_bot(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("sql", "linux", 10, 10)

    bot_name, _, _, _ = mock_queue_job_action(scheduler, bot_capacity=5, assign=False, do_not_cache=True)
    scheduler.assign_job_by_priority_age()

    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 1

    scheduler.close_bot_sessions(bot_name)
    quota = scheduler.get_instance_quota("sql", "linux")
    assert quota is not None
    assert quota.current_usage == 0


def test_get_cohort_quota_metics(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("sql", "linux", 2, 3)
    scheduler.put_instance_quota("foo", "linux", 4, 5)

    with instance_context("*"):
        bot_id = "wildcard-bot"
        scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            bot_capacity=6,
        )
        scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id + "_unhealthy",
            bot_session_status=BotStatus.UNHEALTHY.value,
            bot_capacity=6,
        )
    with instance_context("sql"):
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
            request_metadata=None,
        )
    with instance_context("foo"):
        for _ in range(2):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )
    with instance_context("*"):
        for _ in range(3):
            scheduler.assign_job_by_cohort("linux", 0)

    metrics = scheduler.get_cohort_quota_metrics("sql")
    assert len(metrics) == 1
    assert metrics[0].bot_cohort == "linux"
    assert metrics[0].current_usage == 1
    assert metrics[0].min_quota == 2
    assert metrics[0].max_quota == 3
    assert metrics[0].available_max_capacity == 6
    assert metrics[0].available_capacity == 3
    assert metrics[0].capacity_gap == 0
    assert metrics[0].opportunistic_utilization == 0

    metrics = scheduler.get_cohort_quota_metrics("foo")
    assert len(metrics) == 1
    assert metrics[0].bot_cohort == "linux"
    assert metrics[0].current_usage == 2
    assert metrics[0].min_quota == 4
    assert metrics[0].max_quota == 5
    assert metrics[0].available_max_capacity == 6
    assert metrics[0].available_capacity == 3
    assert metrics[0].capacity_gap == 0
    assert metrics[0].opportunistic_utilization == 0


def test_get_cohort_quota_metics_capacity_gap(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("a", "linux", 1, 2)
    scheduler.put_instance_quota("b", "linux", 2, 2)

    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id="gap-bot",
            bot_session_status=BotStatus.OK.value,
            bot_capacity=2,
        )
    with instance_context("a"):
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
            request_metadata=None,
        )
    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)

    metrics = scheduler.get_cohort_quota_metrics("a")
    assert len(metrics) == 1
    assert metrics[0].current_usage == 1
    assert metrics[0].min_quota == 1
    assert metrics[0].available_capacity == 1
    assert metrics[0].capacity_gap == 0

    metrics = scheduler.get_cohort_quota_metrics("b")
    assert len(metrics) == 1
    assert metrics[0].current_usage == 0
    assert metrics[0].min_quota == 2
    assert metrics[0].available_capacity == 1
    assert metrics[0].capacity_gap == 1


def test_get_cohort_quota_metics_opportunistic_utilization(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("a", "linux", 1, 3)

    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id="opp-bot",
            bot_session_status=BotStatus.OK.value,
            bot_capacity=3,
        )
    for _ in range(2):
        with instance_context("a"):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )
        with instance_context("*"):
            scheduler.assign_job_by_cohort("linux", 0)

    metrics = scheduler.get_cohort_quota_metrics("a")
    assert len(metrics) == 1
    assert metrics[0].current_usage == 2
    assert metrics[0].min_quota == 1
    assert metrics[0].opportunistic_utilization == 1


def test_get_cohort_quota_metrics_gap_reduced_by_other_opportunistic_usage(
    controller_postgres: ExecutionController,
) -> None:
    """Two instances share cohort 'linux'. Instance 'a' has min_quota=1, max_quota=4 and uses 3 slots
    (2 opportunistic). Instance 'b' has min_quota=3, max_quota=5 and uses 0 slots. Bot has capacity 4,
    so available_capacity=1 after 3 assigned. For instance 'b': without the fix gap=max(0,3-0-1)=2;
    with the fix gap=max(0,3-0-1-2)=0 because instance 'a' holds 2 reclaimable opportunistic slots."""
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("a", "linux", 1, 4)
    scheduler.put_instance_quota("b", "linux", 3, 5)

    with instance_context("*"):
        scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id="opp-gap-bot",
            bot_session_status=BotStatus.OK.value,
            bot_capacity=4,
        )
    # Queue and assign 3 jobs for instance "a"
    for _ in range(3):
        with instance_context("a"):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )
        with instance_context("*"):
            scheduler.assign_job_by_cohort("linux", 0)

    # Instance "a": usage=3, min_quota=1 => opportunistic_utilization=2, capacity_gap=0
    metrics_a = scheduler.get_cohort_quota_metrics("a")
    assert len(metrics_a) == 1
    assert metrics_a[0].current_usage == 3
    assert metrics_a[0].min_quota == 1
    assert metrics_a[0].available_capacity == 1
    assert metrics_a[0].opportunistic_utilization == 2
    assert metrics_a[0].capacity_gap == 0

    # Instance "b": usage=0, min_quota=3, available_capacity=1
    # other_opportunistic=max(0, 3-1)=2 (from instance "a")
    # capacity_gap=max(0, 3-0-1-2)=0
    metrics_b = scheduler.get_cohort_quota_metrics("b")
    assert len(metrics_b) == 1
    assert metrics_b[0].current_usage == 0
    assert metrics_b[0].min_quota == 3
    assert metrics_b[0].available_capacity == 1
    assert metrics_b[0].capacity_gap == 0
    assert metrics_b[0].opportunistic_utilization == 0


def test_assign_job_by_cohort(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("a", "linux", 1, 2)
    scheduler.put_instance_quota("b", "linux", 1, 1)

    with instance_context("a"):
        bot_id1 = "bot-1"
        bot_name1 = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id1,
            bot_session_status=BotStatus.OK.value,
            bot_capacity=2,
        )
        # Enqueue 2 `a` jobs
        for _ in range(2):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )
    with instance_context("b"):
        bot_id2 = "bot-2"
        bot_name2 = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id2,
            bot_session_status=BotStatus.OK.value,
            bot_capacity=2,
        )
        # Enqueue 1 `b` jobs
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
            request_metadata=None,
        )

    # Job is assigned to bot in `a` instance
    scheduler.assign_job_by_cohort("linux", 0)
    with instance_context("a"):
        bot_version1 = 0
        a_leases, bot_version1 = scheduler.synchronize_bot_leases(
            bot_name1, bot_id1, BotStatus.OK.value, bot_version1, [], CancellationContext(mock_context())
        )
        assert len(a_leases) == 1

    # Job is assigned to bot in `b` instance, even though `a` has more jobs queued
    scheduler.assign_job_by_cohort("linux", 0)
    with instance_context("b"):
        bot_version2 = 0
        b_leases, bot_version2 = scheduler.synchronize_bot_leases(
            bot_name2, bot_id2, BotStatus.OK.value, bot_version2, [], CancellationContext(mock_context())
        )
        assert len(b_leases) == 1

    # Another job is assigned to bot in `a` instance, since it has remaining max_quota
    scheduler.assign_job_by_cohort("linux", 0)
    with instance_context("a"):
        a_leases, bot_version1 = scheduler.synchronize_bot_leases(
            bot_name1, bot_id1, BotStatus.OK.value, bot_version1, a_leases, CancellationContext(mock_context())
        )
        assert len(a_leases) == 2

    # The second job is not assigned to bot in `b` instance, since it has reached max_quota
    scheduler.assign_job_by_cohort("linux", 0)
    with instance_context("b"):
        leases, bot_version2 = scheduler.synchronize_bot_leases(
            bot_name2, bot_id2, BotStatus.OK.value, bot_version2, b_leases, CancellationContext(mock_context())
        )
        assert len(leases) == 1


def test_max_quota_enformcement(controller_postgres: ExecutionController) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("sql", "linux", 0, 3)

    for _ in range(10):
        mock_queue_job_action(scheduler, assign=True, do_not_cache=True, bot_capacity=10)

    with scheduler._sql.session() as session:
        jobs = session.execute(select(JobEntry)).scalars().all()
        assert len(jobs) == 10
        assigned_jobs = [job for job in jobs if job.assigned]
        assert len(assigned_jobs) == 3


def test_assign_job_by_cohort_guard_failure(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("sql", "linux", 1, 1)

    def _quota_usage_side_effect(
        session: Session, _bot_cohort: str, _instance_name: str, _delta: Any, guard: Any
    ) -> None:
        session.rollback()
        raise InstanceQuotaOutdatedError("Simulated outdated instance quota during test")

    with mock.patch.object(
        scheduler,
        "_update_instance_quota_usage",
        side_effect=_quota_usage_side_effect,
    ):
        _, _, _, job_name = mock_queue_job_action(scheduler, assign=False)
        assert job_name is not None
        # no throw and no job assigned
        assert scheduler.assign_job_by_cohort("linux", 0) == 0

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert not job.assigned
        assert job.worker_name is None


def test_assign_job_by_cohort_preemption(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.put_instance_quota("a", "linux", 1, 2)
    scheduler.put_instance_quota("b", "linux", 1, 2)

    with instance_context("*"):
        bot_id = "wildcard-bot"
        bot_name = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            bot_capacity=2,
        )
    with instance_context("a"):
        for priority in [1, -1]:
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=priority,
                skip_cache_lookup=True,
                request_metadata=None,
            )

    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)
        scheduler.assign_job_by_cohort("linux", 0)
        # Both `a` jobs are assigned to bot
        bot_version = 0
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 2

    with instance_context("b"):
        for _ in range(2):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )

    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)
        scheduler.assign_job_by_cohort("linux", 0)
        # One `b` job is assigned to bot by preempting an `a` job
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        assert len(leases) == 2

        with scheduler._sql.session() as session:
            a_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "a")).scalars().all()
            assert len(a_jobs) == 2
            active_a_jobs = [job for job in a_jobs if job.assigned]
            assert len(active_a_jobs) == 1
            # Preemption respects priority
            assert active_a_jobs[0].priority == -1

            b_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "b")).scalars().all()
            assert len([job for job in b_jobs if job.assigned]) == 1

            capacity = session.execute(select(BotEntry.capacity)).scalar_one_or_none()
            assert capacity is not None
            assert capacity == 0

    # Check the usages are right
    a_usage = scheduler.get_instance_quota("a", "linux")
    b_usage = scheduler.get_instance_quota("b", "linux")
    assert a_usage
    assert b_usage
    assert a_usage.current_usage == 1
    assert b_usage.current_usage == 1


def test_assign_job_by_cohort_preemption_cooldown(
    controller_postgres: ExecutionController,
) -> None:
    assert controller_postgres.execution_instance is not None
    scheduler: Scheduler = controller_postgres.execution_instance.scheduler
    scheduler.eviction_cooldown_seconds = datetime.timedelta(seconds=999)
    # Cooldown applies to both proactive fetching and normal assignment
    scheduler.proactive_fetch_to_capacity = True

    scheduler.put_instance_quota("a", "linux", 1, 2)
    scheduler.put_instance_quota("b", "linux", 1, 2)

    with instance_context("*"):
        bot_id = "wildcard-bot"
        bot_name = scheduler.add_bot_entry(
            bot_name=generate_bot_name(),
            bot_session_id=bot_id,
            bot_session_status=BotStatus.OK.value,
            bot_capacity=2,
        )
    with instance_context("a"):
        for _ in range(2):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )

    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)
        scheduler.assign_job_by_cohort("linux", 0)
        # Both `a` jobs are assigned to bot
        bot_version = 0
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, [], CancellationContext(mock_context())
        )
        assert len(leases) == 2

    with instance_context("b"):
        scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements={},
            property_label="unknown",
            priority=0,
            skip_cache_lookup=True,
            request_metadata=None,
        )

    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)
        # One `b` job is assigned to bot by preempting an `a` job
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        assert len(leases) == 2

        with scheduler._sql.session() as session:
            a_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "a")).scalars().all()
            assert len(a_jobs) == 2
            assert len([job for job in a_jobs if job.assigned]) == 1
            b_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "b")).scalars().all()
            assert len([job for job in b_jobs if job.assigned]) == 1
            b_job_name = b_jobs[0].name
            capacity = session.execute(select(BotEntry.capacity)).scalar_one_or_none()
            assert capacity is not None
            assert capacity == 0

        # Finish the assigned `b` job
        for lease in leases:
            if lease.id == b_job_name:
                lease.state = LeaseState.COMPLETED.value
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )

        # After finishing the `b` job, the preempted `a` job should not be re-assigned immediately due to cooldown
        scheduler.assign_job_by_cohort("linux", 0)
        with scheduler._sql.session() as session:
            a_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "a")).scalars().all()
            assert len(a_jobs) == 2
            assert len([job for job in a_jobs if job.assigned]) == 1

            capacity = session.execute(select(BotEntry.capacity)).scalar_one_or_none()
            assert capacity is not None
            assert capacity == 1

    # Check the usages are right
    a_usage = scheduler.get_instance_quota("a", "linux")
    b_usage = scheduler.get_instance_quota("b", "linux")
    assert a_usage
    assert b_usage
    assert a_usage.current_usage == 1
    assert b_usage.current_usage == 0

    # Complete existing `a` job
    with instance_context("*"):
        for _ in range(2):
            for lease in leases:
                lease.state = LeaseState.COMPLETED.value
            leases, bot_version = scheduler.synchronize_bot_leases(
                bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
            )
        assert len(leases) == 0

    # Manually expire the cooldown by updating eviction logs with old timestamp
    with scheduler._sql.session() as session:
        session.execute(
            update(EvictionLog).values(
                timestamp=EvictionLog.timestamp - scheduler.eviction_cooldown_seconds - datetime.timedelta(seconds=1)
            )
        )

    with instance_context("a"):
        for _ in range(2):
            scheduler.queue_job_action(
                action=uncacheable_action,
                action_digest=uncacheable_action_digest,
                command=command,
                platform_requirements={},
                property_label="unknown",
                priority=0,
                skip_cache_lookup=True,
                request_metadata=None,
            )

    with instance_context("*"):
        scheduler.assign_job_by_cohort("linux", 0)
        scheduler.assign_job_by_cohort("linux", 0)

        # Both new `a` jobs should be assigned since cooldown has expired
        # and adjusted_max_quota is back to 2
        leases, bot_version = scheduler.synchronize_bot_leases(
            bot_name, bot_id, BotStatus.OK.value, bot_version, leases, CancellationContext(mock_context())
        )
        assert len(leases) == 2
        a_jobs = session.execute(select(JobEntry).where(JobEntry.instance_name == "a")).scalars().all()
        assert len(a_jobs) == 4
        assert len([job for job in a_jobs if job.assigned and job.stage == OperationStage.EXECUTING.value]) == 2

    a_usage = scheduler.get_instance_quota("a", "linux")
    assert a_usage
    assert a_usage.current_usage == 2


SMALL_HASH = hash_from_dict({"foo": ["bar"]})
LARGE_HASH = hash_from_dict({"foo": ["bar"], "size": ["large"]})


@pytest.fixture
def controller_preferred_props(
    postgres: Connection,
) -> Iterator[ExecutionController]:
    storage = lru_memory_cache.LRUMemoryCache(1024 * 1024)
    cache = LruActionCache(storage, 50)

    preferred_props = StaticPropertySet(
        property_labels=[
            PropertyLabel(label="small", properties={("foo", "bar")}),
            PropertyLabel(label="large", properties={("foo", "bar"), ("size", "large")}),
        ],
        wildcard_property_keys=set(),
        exclusive_property_keys=frozenset({"size"}),
        preferred_property_keys=frozenset({"size"}),
    )

    with pg_schema_provider(postgres) as sql_provider:
        with create_write_session(command_digest) as write_session:
            write_session.write(command.SerializeToString())
            storage.commit_write(command_digest, write_session)

        with create_write_session(action_digest) as write_session:
            write_session.write(action.SerializeToString())
            storage.commit_write(action_digest, write_session)

        scheduler = Scheduler(
            sql_provider,
            storage,
            poll_interval=0.01,
            action_cache=cache,
            property_set=preferred_props,
            cohort_set=CohortSet(
                [
                    Cohort(name="large", property_labels=frozenset({"large"})),
                    Cohort(name="small", property_labels=frozenset({"small"})),
                ]
            ),
        )

        with scheduler, instance_context("sql"):
            yield ExecutionController(scheduler)


def test_preferred_match_assigns_to_preferred_bot(
    controller_preferred_props: ExecutionController,
) -> None:
    """When a preferred bot is available, the job should be assigned to it."""
    assert controller_preferred_props.execution_instance is not None
    scheduler: Scheduler = controller_preferred_props.execution_instance.scheduler

    # Set up instance quotas for both cohorts
    scheduler.put_instance_quota("sql", "large", 1, 1)
    scheduler.put_instance_quota("sql", "small", 1, 1)

    # Register a "small" bot and a "large" bot
    add_bot(
        scheduler, "*", bot_session_id="small-bot", bot_capability_hashes=[SMALL_HASH], bot_property_labels=["small"]
    )
    add_bot(
        scheduler, "*", bot_session_id="large-bot", bot_capability_hashes=[LARGE_HASH], bot_property_labels=["large"]
    )

    platform = Platform(
        properties=[
            Platform.Property(name="foo", value="bar"),
            Platform.Property(name="size", value="large"),
        ]
    )
    property_label, platform_requirements = scheduler.property_set.execution_properties(platform)
    preferred_label, preferred_requirements = scheduler.property_set.preferred_execution_properties(platform) or (
        None,
        None,
    )

    # Queue a job with preferred requirements
    operation_name = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    job_name = scheduler.get_operation_job_name(operation_name)
    assert job_name is not None

    scheduler.assign_job_by_priority_age()

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.assigned
        assert job.worker_name == "large-bot"


def test_preferred_match_falls_back_to_satisfying_bot(
    controller_preferred_props: ExecutionController,
) -> None:
    """When no preferred bot exists, the job should fall back to a satisfying bot."""
    assert controller_preferred_props.execution_instance is not None
    scheduler: Scheduler = controller_preferred_props.execution_instance.scheduler

    # Set up instance quotas for both cohorts
    scheduler.put_instance_quota("sql", "large", 1, 1)
    scheduler.put_instance_quota("sql", "small", 1, 1)

    # Register only a "small" bot
    add_bot(
        scheduler, "*", bot_session_id="small-bot", bot_capability_hashes=[SMALL_HASH], bot_property_labels=["small"]
    )

    platform = Platform(
        properties=[
            Platform.Property(name="foo", value="bar"),
            Platform.Property(name="size", value="large"),
        ]
    )
    property_label, platform_requirements = scheduler.property_set.execution_properties(platform)
    preferred_label, preferred_requirements = scheduler.property_set.preferred_execution_properties(platform) or (
        None,
        None,
    )

    # Queue a job with preferred requirements that no bot matches
    operation_name = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    job_name = scheduler.get_operation_job_name(operation_name)
    assert job_name is not None

    scheduler.assign_job_by_priority_age()

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.assigned
        assert job.worker_name == "small-bot"


def test_no_preferred_requirements_uses_base_match(
    controller_preferred_props: ExecutionController,
) -> None:
    """Without preferred requirements, the job matches on base requirements only."""
    assert controller_preferred_props.execution_instance is not None
    scheduler: Scheduler = controller_preferred_props.execution_instance.scheduler

    # Set up instance quotas for both cohorts
    scheduler.put_instance_quota("sql", "large", 1, 1)
    scheduler.put_instance_quota("sql", "small", 1, 1)

    # Register a "small" bot and a "large" bot
    add_bot(
        scheduler, "*", bot_session_id="small-bot", bot_capability_hashes=[SMALL_HASH], bot_property_labels=["small"]
    )
    add_bot(
        scheduler, "*", bot_session_id="large-bot", bot_capability_hashes=[LARGE_HASH], bot_property_labels=["large"]
    )

    # no preferred keys in this platform
    platform = Platform(
        properties=[
            Platform.Property(name="foo", value="bar"),
        ]
    )
    property_label, platform_requirements = scheduler.property_set.execution_properties(platform)
    preferred_label, preferred_requirements = scheduler.property_set.preferred_execution_properties(platform) or (
        None,
        None,
    )

    # Queue a job with no preferred requirements
    operation_name = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    job_name = scheduler.get_operation_job_name(operation_name)
    assert job_name is not None

    scheduler.assign_job_by_priority_age()

    with scheduler._sql.session() as session:
        job = scheduler._get_job(job_name, session)
        assert job is not None
        assert job.assigned
        assert job.worker_name == "small-bot"


def test_preferred_bot_at_capacity_falls_back(
    controller_preferred_props: ExecutionController,
) -> None:
    """When the preferred bot is at capacity, the job falls back to a satisfying bot in another cohort."""
    assert controller_preferred_props.execution_instance is not None
    scheduler: Scheduler = controller_preferred_props.execution_instance.scheduler

    # Set up instance quotas for both cohorts
    scheduler.put_instance_quota("sql", "large", 1, 1)
    scheduler.put_instance_quota("sql", "small", 1, 1)

    # Register a "large" bot (cohort="large") with capacity 1, and a "small" bot (cohort="small")
    add_bot(
        scheduler,
        "*",
        bot_session_id="large-bot",
        bot_capacity=2,
        bot_capability_hashes=[LARGE_HASH],
        bot_property_labels=["large"],
    )
    add_bot(
        scheduler,
        "*",
        bot_session_id="small-bot",
        bot_capacity=1,
        bot_capability_hashes=[SMALL_HASH],
        bot_property_labels=["small"],
    )

    platform = Platform(
        properties=[
            Platform.Property(name="foo", value="bar"),
            Platform.Property(name="size", value="large"),
        ]
    )
    property_label, platform_requirements = scheduler.property_set.execution_properties(platform)
    preferred_label, preferred_requirements = scheduler.property_set.preferred_execution_properties(platform) or (
        None,
        None,
    )

    # Queue first job with preferred requirements
    op1 = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    job_name1 = scheduler.get_operation_job_name(op1)
    assert job_name1 is not None

    # Queue second job with same preferred requirements
    op2 = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    job_name2 = scheduler.get_operation_job_name(op2)
    assert job_name2 is not None

    # Assign first job
    scheduler.assign_job_by_priority_age(0)

    with scheduler._sql.session() as session:
        job1 = scheduler._get_job(job_name1, session)
        assert job1 is not None
        assert job1.assigned
        assert job1.worker_name == "large-bot"

    # Assign second job
    scheduler.assign_job_by_priority_age(0)

    with scheduler._sql.session() as session:
        job2 = scheduler._get_job(job_name2, session)
        assert job2 is not None
        assert job2.assigned
        assert job2.worker_name == "small-bot"


def test_preferred_bot_at_capacity_preempts_small_bot(
    controller_preferred_props: ExecutionController,
) -> None:
    """When both bots are at capacity and instance is below min_quota, preemption kicks in for the fallback cohort."""
    assert controller_preferred_props.execution_instance is not None
    scheduler: Scheduler = controller_preferred_props.execution_instance.scheduler

    # Set up instance quotas:
    scheduler.put_instance_quota("sql", "small", 1, 1)
    scheduler.put_instance_quota("sql", "large", 1, 1)
    scheduler.put_instance_quota("other", "small", 0, 1)
    scheduler.put_instance_quota("other", "large", 0, 1)

    # Register bots with capacity 1
    add_bot(
        scheduler,
        "*",
        bot_session_id="large-bot",
        bot_capacity=1,
        bot_capability_hashes=[LARGE_HASH],
        bot_property_labels=["large"],
    )
    add_bot(
        scheduler,
        "*",
        bot_session_id="small-bot",
        bot_capacity=1,
        bot_capability_hashes=[SMALL_HASH],
        bot_property_labels=["small"],
    )

    # Queue and assign jobs from "other" instance to fill both bots
    # A small job for the small bot
    with instance_context("other"):
        small_op = scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements=scheduler.property_set.execution_properties(
                Platform(properties=[Platform.Property(name="foo", value="bar")])
            )[1],
            property_label="small",
            priority=0,
            skip_cache_lookup=True,
        )
        small_job_name = scheduler.get_operation_job_name(small_op)
        assert small_job_name is not None
        scheduler.assign_job_by_priority_age(0)

    with scheduler._sql.session() as session:
        small_job = scheduler._get_job(small_job_name, session)
        assert small_job is not None
        assert small_job.assigned
        assert small_job.worker_name == "small-bot"

    # A large job for the large bot (using preferred properties platform)
    with instance_context("other"):
        platform = Platform(
            properties=[
                Platform.Property(name="foo", value="bar"),
                Platform.Property(name="size", value="large"),
            ]
        )
        large_prop_label, large_plat_req = scheduler.property_set.execution_properties(platform)
        large_pref_label, large_pref_req = scheduler.property_set.preferred_execution_properties(platform) or (
            None,
            None,
        )
        large_op = scheduler.queue_job_action(
            action=uncacheable_action,
            action_digest=uncacheable_action_digest,
            command=command,
            platform_requirements=large_plat_req,
            preferred_requirements=large_pref_req,
            property_label=large_prop_label,
            preferred_label=large_pref_label,
            priority=0,
            skip_cache_lookup=True,
        )
        large_job_name = scheduler.get_operation_job_name(large_op)
        assert large_job_name is not None
        scheduler.assign_job_by_priority_age(0)

    with scheduler._sql.session() as session:
        large_job = scheduler._get_job(large_job_name, session)
        assert large_job is not None
        assert large_job.assigned
        assert large_job.worker_name == "large-bot"

    # Now queue the target job from instance "sql" with preferred=large requirements
    platform = Platform(
        properties=[
            Platform.Property(name="foo", value="bar"),
            Platform.Property(name="size", value="large"),
        ]
    )
    property_label, platform_requirements = scheduler.property_set.execution_properties(platform)
    preferred_label, preferred_requirements = scheduler.property_set.preferred_execution_properties(platform) or (
        None,
        None,
    )

    target_op = scheduler.queue_job_action(
        action=uncacheable_action,
        action_digest=uncacheable_action_digest,
        command=command,
        platform_requirements=platform_requirements,
        preferred_requirements=preferred_requirements,
        property_label=property_label,
        preferred_label=preferred_label,
        priority=0,
        skip_cache_lookup=True,
    )
    target_job_name = scheduler.get_operation_job_name(target_op)
    assert target_job_name is not None

    # Assign with preemption enabled
    scheduler.assign_job_by_priority_age(0, preemption_delay=0)

    with scheduler._sql.session() as session:
        target_job = scheduler._get_job(target_job_name, session)
        assert target_job is not None
        assert target_job.assigned
        assert target_job.worker_name == "small-bot"

        # The evicted job should be re-queued
        evicted_job = scheduler._get_job(small_job_name, session)
        assert evicted_job is not None
        assert not evicted_job.assigned
        assert evicted_job.instance_name == "other"
