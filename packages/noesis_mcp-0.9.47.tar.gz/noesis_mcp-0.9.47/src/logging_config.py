import logging
import sys


def configure_logging(level=logging.INFO):
    """Configure logging with a StreamHandler."""
    root = logging.getLogger()
    # Remove existing StreamHandlers to avoid duplicate logs
    root.handlers = [h for h in root.handlers if not isinstance(h, logging.StreamHandler)]
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    handler.setFormatter(formatter)
    root.addHandler(handler)
    root.setLevel(level)
