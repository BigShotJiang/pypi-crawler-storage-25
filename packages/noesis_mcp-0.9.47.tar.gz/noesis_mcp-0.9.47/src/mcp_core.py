"""
MiniMax API MCP (Model Context Protocol) Core Module
Handles API interactions with error handling for response key access.
"""

import json
import logging
from typing import Optional, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MiniMaxAPIError(Exception):
    """Custom exception for MiniMax API errors."""
    pass


class MiniMaxClient:
    """Client for interacting with MiniMax API with robust error handling."""
    
    def __init__(self, api_key: str, base_url: str = "https://api.minimax.chat"):
        """
        Initialize the MiniMax API client.
        
        Args:
            api_key: The API key for authentication.
            base_url: Base URL for the API endpoint.
        """
        self.api_key = api_key
        self.base_url = base_url
    
    def _validate_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate that the API response contains required keys.
        
        Args:
            response: The API response dictionary.
            
        Returns:
            The validated response dictionary.
            
        Raises:
            MiniMaxAPIError: If required keys are missing.
        """
        # Check for 'choices' key
        if 'choices' not in response:
            error_msg = "Invalid API response: 'choices' key not found in response"
            logger.error(error_msg)
            logger.debug(f"Response keys: {list(response.keys())}")
            raise MiniMaxAPIError(error_msg)
        
        # Check that choices is not empty
        if not response['choices'] or len(response['choices']) == 0:
            error_msg = "Invalid API response: 'choices' list is empty"
            logger.error(error_msg)
            raise MiniMaxAPIError(error_msg)
        
        # Check for 'message' key in the first choice
        first_choice = response['choices'][0]
        if 'message' not in first_choice:
            error_msg = "Invalid API response: 'message' key not found in first choice"
            logger.error(error_msg)
            logger.debug(f"Choice keys: {list(first_choice.keys())}")
            raise MiniMaxAPIError(error_msg)
        
        return response
    
    def get_completion(self, prompt: str, model: str = "abab5.5-chat") -> Optional[str]:
        """
        Get a completion from the MiniMax API.
        
        Args:
            prompt: The input prompt for the model.
            model: The model identifier to use.
            
        Returns:
            The completion text or None if an error occurs.
        """
        # Simulated API call structure (replace with actual API call logic)
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model,
            "messages": [
                {"role": "user", "content": prompt}
            ]
        }
        
        # In a real implementation, this would use requests or httpx
        # response = requests.post(f"{self.base_url}/v1/chat/completions", 
        #                          headers=headers, json=payload)
        
        # Simulated response for demonstration
        # In production, replace with actual API call
        logger.info(f"Sending request to MiniMax API with model: {model}")
        
        # This is where the actual response would be processed
        # simulated_response = response.json()
        
        return None
    
    def process_response(self, response: Dict[str, Any]) -> Optional[str]:
        """
        Process an API response and extract the message content safely.
        
        Args:
            response: The raw API response dictionary.
            
        Returns:
            The message content or None if extraction fails.
        """
        try:
            validated_response = self._validate_response(response)
            
            # Safely extract the message content
            message = validated_response['choices'][0].get('message', {})
            content = message.get('content', '')
            
            return content if content else None
            
        except KeyError as e:
            logger.error(f"KeyError occurred while processing response: {e}")
            return None
        except MiniMaxAPIError as e:
            logger.error(f"MiniMax API error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error processing response: {e}")
            return None


def create_client(api_key: str) -> MiniMaxClient:
    """
    Factory function to create a MiniMaxClient instance.
    
    Args:
        api_key: The API key for authentication.
        
    Returns:
        A configured MiniMaxClient instance.
    """
    return MiniMaxClient(api_key=api_key)


# Example usage function
def example_usage():
    """Demonstrate how to use the MiniMaxClient with error handling."""
    client = create_client(api_key="your-api-key-here")
    
    # Example valid response structure
    valid_response = {
        "id": "chatcmpl-123",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": "Hello! How can I help you today?"
                },
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 20
        }
    }
    
    content = client.process_response(valid_response)
    print(f"Extracted content: {content}")
    
    # Example invalid response (missing keys)
    invalid_response = {
        "id": "chatcmpl-456",
        "usage": {}
    }
    
    content = client.process_response(invalid_response)
    print(f"Invalid response result: {content}")  # Will be None due to error


if __name__ == "__main__":
    example_usage()
