"""LLM API client wrappers: MiniMax, mimo, DeepSeek R1."""

import os, json, subprocess, re
from pathlib import Path
from checkpoint import log, MCP_SOURCE_DIR, API_TIMEOUT, track_metric

def call_mcp_http(task: str, messages: list[dict], max_tokens: int = 800,
                   system: str = None, passthrough: bool = False,
                   timeout: int = None) -> tuple[str, list[dict]]:
    """Single HTTP call to MCP-brain via curl subprocess. Returns (content, updated_messages).
    
    Each call is stateless — only the current task+system is sent.
    History is NOT accumulated between calls since the model has no memory.
    
    Args:
        passthrough: if True, sends "tools":[] to bypass cognitive pipeline (fast, no reasoning).
                     if False, sends no tools field → cognitive pipeline runs.
    """
    # Build the call with only system + current task (stateless design)
    call_messages = []
    if system:
        call_messages.append({"role": "system", "content": system})
    call_messages.append({"role": "user", "content": task})

    payload = {
        "model": "mcp-brain",
        "messages": call_messages,
        "max_tokens": max_tokens,
        "stream": False,
        "temperature": 0.2,
    }
    if passthrough:
        payload["tools"] = []  # Empty list → bypass cognitive pipeline, use passthrough mode

    api_key = os.environ.get("MINIMAX_API_KEY", "")
    cmd = [
        "curl", "-s", "--max-time", str(API_TIMEOUT),
        "-X", "POST", "http://127.0.0.1:8080/v1/chat/completions",
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {api_key}",
        "-d", json.dumps(payload),
    ]
    curl_timeout = timeout if timeout is not None else API_TIMEOUT
    result = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=curl_timeout + 5)
    if result.returncode != 0:
        raise RuntimeError(f"curl failed (exit {result.returncode}): {result.stderr[:500]}")

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"JSON parse failed on {len(result.stdout)} byte response: {e}\nFirst 300: {result.stdout[:300]}")

    choices = data.get("choices", [])
    if not choices:
        return f"[ERROR: empty choices: {str(data)[:300]}]", []

    msg = choices[0].get("message", {})
    content = msg.get("content", "") or ""
    return content, []


# ── DeepSeek API (for Critic/Auditor) ───────────────────────────────────────────────────
def _get_deepseek_key() -> str:
    return os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_REASONER_MODEL = "deepseek-reasoner"  # reasoning (Critic, Auditor)
DEEPSEEK_TIMEOUT = 180

MIMO_URL = "https://token-plan-sgp.xiaomimimo.com/v1/chat/completions"
MIMO_MODEL = "mimo-v2.5-pro"
def _get_mimo_key() -> str:
    return os.environ.get("MIMO_API_KEY", "")
MIMO_TIMEOUT = 120


def call_mimo(task: str, system: str = None, max_tokens: int = 2048) -> str:
    """Call Xiaomi mimo-v2.5-pro for Scout and Architect-Scout.

    mimo puts the actual answer in 'content' -- NOT 'thinking' or 'reasoning_content'.
    mimo sometimes generates invalid JSON (literal newlines inside string values).
    """
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": task})

    payload = {
        "model": MIMO_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.1,
    }

    cmd = [
        "curl", "-s", "--max-time", str(MIMO_TIMEOUT),
        "-X", "POST", MIMO_URL,
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {_get_mimo_key()}",
        "-d", json.dumps(payload),
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=MIMO_TIMEOUT + 10)
    if result.returncode != 0:
        raise RuntimeError(f"mimo curl failed (exit {result.returncode}): {result.stderr[:300]}")

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        text = result.stdout.strip()
        m = re.search(r'"content"\s*:\s*"([^"]{0,5000})"', text)
        if m:
            log(f"[MIMO] model={MIMO_MODEL} recovered via regex")
            return m.group(1).replace("\\n", "\n").replace('\\"', '"')
        raise RuntimeError(f"mimo JSON parse failed on {len(result.stdout)} byte response")

    choices = data.get("choices", [])
    if not choices:
        return f"[ERROR: empty choices: {str(data)[:300]}]"

    msg = choices[0].get("message", {})
    content = msg.get("content", "") or ""
    if content.strip():
        total = data.get('usage', {}).get('total_tokens', 0)
        log(f"[MIMO] model={MIMO_MODEL} tokens={total}")
        track_metric(f"tokens_mimo")
        track_metric(f"tokens_total")
        return content.strip()

    return f"[ERROR: no content in mimo response: {str(data)[:300]}]"


def call_deepseek_r1(task: str, system: str = None, max_tokens: int = 4096) -> str:
    """Call DeepSeek Reasoner (R1) for Critic and Auditor.

    DeepSeek R1 returns reasoning in 'reasoning_content' and answer in 'content'.
    We want the answer (content), not the chain-of-thought.
    """
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": task})

    payload = {
        "model": DEEPSEEK_REASONER_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
    }

    cmd = [
        "curl", "-s", "--max-time", str(DEEPSEEK_TIMEOUT),
        "-X", "POST", DEEPSEEK_URL,
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {_get_deepseek_key()}",
        "-d", json.dumps(payload),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=DEEPSEEK_TIMEOUT + 10)
    if result.returncode != 0:
        raise RuntimeError(f"DeepSeek R1 curl failed (exit {result.returncode}): {result.stderr[:300]}")

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"DeepSeek R1 JSON parse failed on {len(result.stdout)} byte response: {e}")

    choices = data.get("choices", [])
    if not choices:
        return f"[ERROR: empty choices: {str(data)[:300]}]"

    msg = choices[0].get("message", {})
    # R1 puts the answer in content, reasoning in reasoning_content
    content = msg.get("content", "") or ""
    if not content.strip():
        # Fallback: some responses only have reasoning_content
        content = msg.get("reasoning_content", "") or ""
    reasoning_tokens = data.get("usage", {}).get("completion_tokens_details", {}).get("reasoning_tokens", "?")
    total = data.get('usage', {}).get('total_tokens', 0)
    log(f"[DEEPSEEK-R1] model={DEEPSEEK_REASONER_MODEL} tokens={total} reasoning={reasoning_tokens}")
    track_metric("tokens_deepseek")
    track_metric("tokens_total")
    return content



# ── MiniMax API (for Proposer/Defender/Synthesizer) ───────────────────────────
MINIMAX_API_KEY = None  # loaded lazily from ~/.mcp/config.json
MINIMAX_URL = "https://api.minimax.io/v1/chat/completions"
MINIMAX_MODEL = "MiniMax-M2.7"
MINIMAX_TIMEOUT = 300

def _get_minimax_key() -> str:
    """Load MiniMax API key from ~/.mcp/config.json (same source as mcp-brain)."""
    global MINIMAX_API_KEY
    if MINIMAX_API_KEY:
        return MINIMAX_API_KEY
    try:
        config_path = Path.home() / ".mcp" / "config.json"
        if config_path.exists():
            import json
            config = json.loads(config_path.read_text())
            MINIMAX_API_KEY = config.get("api_key", "") or os.environ.get("MINIMAX_API_KEY", "")
    except Exception:
        MINIMAX_API_KEY = os.environ.get("MINIMAX_API_KEY", "")
    if not MINIMAX_API_KEY:
        raise RuntimeError("MiniMax API key not found in ~/.mcp/config.json or MINIMAX_API_KEY env")
    return MINIMAX_API_KEY

def call_minimax(task: str, system: str = None, max_tokens: int = 8000) -> str:
    """Call MiniMax API directly for Proposer/Defender/Synthesizer.
    
    Bypasses MCP-brain cognitive pipeline — these agents need raw LLM output
    for code generation, not the pipeline's analysis wrapping.
    Returns just the content string (stateless).
    """
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": task})
    
    payload = {
        "model": MINIMAX_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.1,
    }
    
    cmd = [
        "curl", "-s", "--max-time", str(MINIMAX_TIMEOUT),
        "-X", "POST", MINIMAX_URL,
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {_get_minimax_key()}",
        "-d", json.dumps(payload),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=MINIMAX_TIMEOUT + 10)
    if result.returncode != 0:
        raise RuntimeError(f"MiniMax curl failed (exit {result.returncode}): {result.stderr[:500]}")
    
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"MiniMax JSON parse failed on {len(result.stdout)} byte response: {e}\nFirst 300: {result.stdout[:300]}")
    
    choices = data.get("choices", [])
    if not choices:
        return f"[ERROR: empty choices: {str(data)[:300]}]"
    
    msg = choices[0].get("message", {})
    content = msg.get("content", "") or ""
    tokens = data.get('usage', {}).get('completion_tokens', 0)
    log(f"[MINIMAX] tokens={tokens}")
    track_metric("tokens_minimax")
    track_metric("tokens_total")
    return content




__all__ = ['call_mcp_http', 'call_mimo', 'call_deepseek_r1', 'call_minimax']
