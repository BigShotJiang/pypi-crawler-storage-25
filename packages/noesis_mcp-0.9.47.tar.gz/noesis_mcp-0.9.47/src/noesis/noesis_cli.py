"""Noesis CLI — self-improving AI agent framework.

Unified command-line interface for managing the Noesis self-improvement daemon.
Handles installation, configuration, lifecycle, and monitoring.

Usage:
    noesis install              Install as systemd service
    noesis start                Start daemon
    noesis stop                 Stop daemon
    noesis restart              Restart daemon
    noesis status               Show daemon status, checkpoint, metrics
    noesis run                  Run daemon in foreground
    noesis run --dry-run        Test pipeline without writing files
    noesis config show          Display all settings
    noesis config set KEY=VAL   Set API key or config value
    noesis config init          Create config template
    noesis wish "Add X"         Submit a single wish
    noesis architect            Force Architect-Scout run
    noesis pause                Pause daemon
    noesis resume               Resume daemon
    noesis metrics              Show pipeline metrics
    noesis logs                 Tail daemon logs
    noesis version              Show version
"""

import os
import sys
import json
import time
import subprocess
from pathlib import Path
from typing import Optional

import click

__version__ = "0.9.47"

# ── Paths ───────────────────────────────────────────────────────────────────
HERMES_DIR = Path.home() / ".hermes"
SCRIPTS_DIR = HERMES_DIR / "scripts"
ENV_FILE = HERMES_DIR / ".env"
CHECKPOINT_FILE = SCRIPTS_DIR / "mcp_self_improve_checkpoint.json"
METRICS_FILE = SCRIPTS_DIR / "mcp_self_improve_metrics.json"
PAUSE_FILE = SCRIPTS_DIR / "mcp_self_improve.pause"
PID_FILE = SCRIPTS_DIR / "mcp_self_improve.pid"
LOG_FILE = SCRIPTS_DIR / "mcp_self_improve.log"
SERVICE_FILE = Path.home() / ".config" / "systemd" / "user" / "mcp-self-improve.service"
HTTP_SERVICE_FILE = Path.home() / ".config" / "systemd" / "user" / "noesis-http.service"
WISHES_FILE = Path.home() / "mcp-work" / "wishes.txt"
META_WISHES_FILE = SCRIPTS_DIR / "meta_wish_approved.json"
REJECTIONS_FILE = SCRIPTS_DIR / "noesis_rejections.json"

# ── Env file management ────────────────────────────────────────────────────
ENV_KEYS = {
    "DEEPSEEK_API_KEY": "DeepSeek API key (api.deepseek.com)",
    "MIMO_API_KEY": "Xiaomi mimo API key (token-plan-sgp.xiaomimimo.com)",
    "MINIMAX_API_KEY": "MiniMax API key (api.minimax.io)",
    "MINIMAX_BASE_URL": "MiniMax base URL (default: https://api.minimax.io/v1)",
    "MINIMAX_MODEL": "MiniMax model name (default: MiniMax-M2.7)",
}


def load_env() -> dict:
    """Load key=value pairs from ~/.hermes/.env."""
    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env


def save_env(env: dict):
    """Write key=value pairs to ~/.hermes/.env, preserving comments."""
    lines = []
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            stripped = line.strip()
            if "=" in stripped and not stripped.startswith("#"):
                k = stripped.split("=", 1)[0].strip()
                if k in env:
                    lines.append(f"{k}={env[k]}")
                    del env[k]
                else:
                    lines.append(line)
            else:
                lines.append(line)
    # Add remaining new keys
    for k, v in env.items():
        lines.append(f"{k}={v}")
    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    ENV_FILE.write_text("\n".join(lines) + "\n")


def get_env_value(key: str) -> Optional[str]:
    """Get a single value from env file."""
    env = load_env()
    return env.get(key)


def set_env_value(key: str, value: str):
    """Set a single value in env file."""
    env = load_env()
    env[key] = value
    save_env(env)


# ── Service management ─────────────────────────────────────────────────────
def is_daemon_running() -> bool:
    """Check if the daemon systemd service is active."""
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", "mcp-self-improve"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() == "active"
    except Exception:
        return False


def is_http_running() -> bool:
    """Check if noesis-http is active."""
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", "noesis-http"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() == "active"
    except Exception:
        return False


def run_systemctl(action: str, service: str) -> bool:
    """Run systemctl --user action on a service."""
    r = subprocess.run(
        ["systemctl", "--user", action, service],
        capture_output=True, text=True, timeout=30,
    )
    return r.returncode == 0


# ── CLI ─────────────────────────────────────────────────────────────────────
@click.group()
@click.version_option(version=__version__, prog_name="noesis")
def cli():
    """Noesis — self-improving AI agent framework.

    Autonomous code refinement via wish-driven adversarial debate pipeline.
    Multi-agent system with Scout, Proposer, Critic, Defender, Synthesizer,
    Judge, and Auditor agents.
    """
    pass


# ── Lifecycle commands ──────────────────────────────────────────────────────
@cli.command()
def install():
    """Install Noesis as systemd user services."""
    click.echo("Installing Noesis systemd services...")

    # Create systemd user directory
    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)

    # mcp-self-improve.service
    daemon_service = f"""[Unit]
Description=Noesis Self-Improvement Daemon
After=network.target noesis-http.service
Wants=noesis-http.service

[Service]
ExecStart=/usr/bin/python3 {SCRIPTS_DIR / 'mcp_self_improve.py'} --watch
Restart=always
RestartSec=10
StandardOutput=append:{LOG_FILE}
StandardError=append:{LOG_FILE}
WorkingDirectory={Path.home()}

[Install]
WantedBy=default.target
"""
    SERVICE_FILE.write_text(daemon_service)
    click.echo(f"  ✓ {SERVICE_FILE}")

    # noesis-http.service (if http_server.py exists)
    http_script = SCRIPTS_DIR / "http_server.py"
    if not http_script.exists():
        # Try installed package
        try:
            import noesis.http_server
            http_script = Path(noesis.http_server.__file__)
        except ImportError:
            http_script = None

    if http_script:
        http_service = f"""[Unit]
Description=Noesis HTTP Server
After=network.target

[Service]
ExecStart=/usr/bin/python3 -m noesis.http_server --host 127.0.0.1 --port 8080
Restart=always
RestartSec=5
Environment="PYTHONPATH={Path.home() / 'mcp-work' / 'src'}"

[Install]
WantedBy=default.target
"""
        HTTP_SERVICE_FILE.write_text(http_service)
        click.echo(f"  ✓ {HTTP_SERVICE_FILE}")

    # Reload systemd
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
    click.echo("  ✓ systemd daemon reloaded")

    # Enable services
    run_systemctl("enable", "mcp-self-improve")
    click.echo("  ✓ mcp-self-improve enabled")

    if HTTP_SERVICE_FILE.exists():
        run_systemctl("enable", "noesis-http")
        click.echo("  ✓ noesis-http enabled")

    # Create env template if not exists
    if not ENV_FILE.exists():
        env_content = "# Noesis API Keys\n"
        for key, desc in ENV_KEYS.items():
            env_content += f"# {desc}\n{key}=\n"
        ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
        ENV_FILE.write_text(env_content)
        click.echo(f"  ✓ Created config template: {ENV_FILE}")
        click.echo("\n  ⚠ Edit ~/.hermes/.env with your API keys, then run:")
        click.echo("    noesis config set DEEPSEEK_API_KEY=sk-...")
        click.echo("    noesis config set MIMO_API_KEY=tp-...")
        click.echo("    noesis config set MINIMAX_API_KEY=eyJ...")
    else:
        click.echo(f"  ✓ Config already exists: {ENV_FILE}")

    click.echo("\n✓ Installation complete! Run 'noesis start' to begin.")


@cli.command()
def start():
    """Start the Noesis daemon."""
    if is_daemon_running():
        click.echo("Daemon is already running.")
        return
    click.echo("Starting Noesis daemon...")
    if run_systemctl("start", "mcp-self-improve"):
        time.sleep(2)
        if is_daemon_running():
            click.echo("✓ Daemon started.")
        else:
            click.echo("✗ Daemon failed to start. Check: noesis logs", err=True)
    else:
        click.echo("✗ Failed to start daemon.", err=True)


@cli.command()
def stop():
    """Stop the Noesis daemon."""
    if not is_daemon_running():
        click.echo("Daemon is not running.")
        return
    click.echo("Stopping Noesis daemon...")
    if run_systemctl("stop", "mcp-self-improve"):
        click.echo("✓ Daemon stopped.")
    else:
        click.echo("✗ Failed to stop daemon.", err=True)


@cli.command()
def restart():
    """Restart the Noesis daemon."""
    click.echo("Restarting Noesis daemon...")
    run_systemctl("restart", "mcp-self-improve")
    time.sleep(2)
    if is_daemon_running():
        click.echo("✓ Daemon restarted.")
    else:
        click.echo("✗ Daemon failed to restart. Check: noesis logs", err=True)


@cli.command()
def run():
    """Run the Noesis daemon in foreground (Ctrl+C to stop).

    Useful for debugging or running without systemd.
    """
    script = SCRIPTS_DIR / "mcp_self_improve.py"
    if not script.exists():
        click.echo(f"Error: {script} not found. Run 'noesis install' first.", err=True)
        sys.exit(1)

    args = [sys.executable, str(script), "--watch"]
    # Pass through --dry-run if set
    if "--dry-run" in sys.argv:
        args.append("--dry-run")
    if "--resume" in sys.argv:
        args.append("--resume")

    try:
        os.execvp(sys.executable, args)
    except KeyboardInterrupt:
        click.echo("\nStopped.")


# ── Status and monitoring ──────────────────────────────────────────────────
@cli.command()
def status():
    """Show Noesis daemon status, checkpoint, and metrics."""
    # Service status
    daemon_active = is_daemon_running()
    http_active = is_http_running()
    click.echo(f"Daemon:      {'● running' if daemon_active else '○ stopped'}")
    click.echo(f"HTTP server: {'● running' if http_active else '○ stopped'}")

    # PID
    if PID_FILE.exists():
        pid = PID_FILE.read_text().strip()
        click.echo(f"PID:         {pid}")

    # Checkpoint
    if CHECKPOINT_FILE.exists():
        try:
            cp = json.loads(CHECKPOINT_FILE.read_text())
            click.echo(f"\nCheckpoint:")
            click.echo(f"  Iterations:    {cp.get('iterations', 0)}")
            click.echo(f"  Wish index:    {cp.get('wish_index', 0)}")
            click.echo(f"  Applied:       {len(cp.get('applied_patches', []))}")
            click.echo(f"  Debate round:  {cp.get('debate_round', 0)}")
            click.echo(f"  Done:          {cp.get('done', False)}")
            last_updated = cp.get("last_updated", "?")
            click.echo(f"  Last updated:  {last_updated}")
            architect_last = cp.get("architect_last_run")
            if architect_last:
                elapsed = int(time.time() - architect_last)
                remaining = max(0, 3600 - elapsed)
                click.echo(f"  Architect:     {elapsed}s ago (~{remaining // 60}m cooldown)")
        except json.JSONDecodeError:
            click.echo("\nCheckpoint: CORRUPT", err=True)
    else:
        click.echo("\nCheckpoint: not found")

    # Metrics
    if METRICS_FILE.exists():
        try:
            metrics = json.loads(METRICS_FILE.read_text())
            click.echo(f"\nMetrics:")
            for k, v in sorted(metrics.items()):
                if k != "last_updated":
                    click.echo(f"  {k}: {v}")
        except json.JSONDecodeError:
            pass

    # Config check
    env = load_env()
    click.echo(f"\nAPI Keys:")
    for key in ENV_KEYS:
        val = env.get(key, "")
        masked = val[:8] + "..." if len(val) > 8 else ("(not set)" if not val else val)
        click.echo(f"  {key}: {masked}")


@cli.command()
@click.option("--lines", "-n", default=50, help="Number of lines to show")
def logs(lines: int):
    """Tail daemon logs."""
    if not LOG_FILE.exists():
        click.echo("No log file found.")
        return
    try:
        subprocess.run(["tail", "-n", str(lines), str(LOG_FILE)])
    except KeyboardInterrupt:
        pass


@cli.command()
def metrics():
    """Show pipeline metrics."""
    if not METRICS_FILE.exists():
        click.echo("No metrics recorded yet.")
        return
    try:
        data = json.loads(METRICS_FILE.read_text())
        click.echo("Pipeline Metrics:")
        click.echo("-" * 40)
        for k, v in sorted(data.items()):
            if k == "last_updated":
                click.echo(f"  {k}: {v}")
            else:
                click.echo(f"  {k}: {v}")
    except json.JSONDecodeError:
        click.echo("Metrics file corrupt.", err=True)


# ── Control commands ────────────────────────────────────────────────────────
@cli.command()
def pause():
    """Pause the daemon (stops processing wishes)."""
    if PAUSE_FILE.exists():
        click.echo("Daemon is already paused.")
        return
    PAUSE_FILE.parent.mkdir(parents=True, exist_ok=True)
    PAUSE_FILE.write_text(f"paused at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    click.echo(f"✓ Daemon paused. Remove {PAUSE_FILE} to resume, or run: noesis resume")


@cli.command()
def resume():
    """Resume a paused daemon."""
    if not PAUSE_FILE.exists():
        click.echo("Daemon is not paused.")
        return
    PAUSE_FILE.unlink()
    click.echo("✓ Daemon resumed.")


@cli.command()
@click.argument("wish")
def wish(wish: str):
    """Submit a single wish to the pipeline."""
    if not wish.strip():
        click.echo("Error: empty wish", err=True)
        sys.exit(1)

    script = SCRIPTS_DIR / "mcp_self_improve.py"
    if not script.exists():
        click.echo(f"Error: {script} not found. Run 'noesis install' first.", err=True)
        sys.exit(1)

    click.echo(f"Submitting wish: {wish[:80]}...")
    r = subprocess.run(
        [sys.executable, str(script), wish],
        capture_output=True, text=True, timeout=600,
        cwd=str(Path.home()),
    )
    click.echo(r.stdout)
    if r.stderr:
        click.echo(r.stderr, err=True)
    sys.exit(r.returncode)


@cli.command()
def architect():
    """Force an Architect-Scout run (ignores cooldown)."""
    script = SCRIPTS_DIR / "mcp_self_improve.py"
    if not script.exists():
        click.echo(f"Error: {script} not found.", err=True)
        sys.exit(1)

    # Reset cooldown
    if CHECKPOINT_FILE.exists():
        try:
            cp = json.loads(CHECKPOINT_FILE.read_text())
            cp["architect_last_run"] = 0
            CHECKPOINT_FILE.write_text(json.dumps(cp, indent=2))
        except Exception:
            pass

    click.echo("Running Architect-Scout...")
    r = subprocess.run(
        [sys.executable, str(script), "--architect"],
        capture_output=True, text=True, timeout=300,
        cwd=str(Path.home()),
    )
    click.echo(r.stdout)
    if r.stderr:
        click.echo(r.stderr, err=True)
    sys.exit(r.returncode)


# ── Config commands ─────────────────────────────────────────────────────────
@cli.group()
def config():
    """Manage Noesis configuration."""
    pass


@config.command(name="show")
def config_show():
    """Display all configuration settings."""
    env = load_env()
    click.echo(f"Config file: {ENV_FILE}\n")
    click.echo(f"{'Key':<25} {'Value':<30} Description")
    click.echo("-" * 80)
    for key, desc in ENV_KEYS.items():
        val = env.get(key, "")
        masked = val[:12] + "..." if len(val) > 12 else ("(not set)" if not val else val)
        click.echo(f"{key:<25} {masked:<30} {desc}")

    # Show derived paths
    click.echo(f"\nPaths:")
    click.echo(f"  Scripts:     {SCRIPTS_DIR}")
    click.echo(f"  Checkpoint:  {CHECKPOINT_FILE}")
    click.echo(f"  Log:         {LOG_FILE}")
    click.echo(f"  Metrics:     {METRICS_FILE}")
    click.echo(f"  Pause file:  {PAUSE_FILE}")
    click.echo(f"  Wishes:      {WISHES_FILE}")


# Short aliases for config keys
KEY_ALIASES = {
    "deepseek": "DEEPSEEK_API_KEY",
    "deepseek_key": "DEEPSEEK_API_KEY",
    "mimo": "MIMO_API_KEY",
    "mimo_key": "MIMO_API_KEY",
    "minimax": "MINIMAX_API_KEY",
    "minimax_key": "MINIMAX_API_KEY",
    "model": "MINIMAX_MODEL",
    "base_url": "MINIMAX_BASE_URL",
}

# Key validation patterns
KEY_VALIDATORS = {
    "DEEPSEEK_API_KEY": (lambda v: v.startswith("sk-"), 'should start with "sk-"'),
    "MIMO_API_KEY": (lambda v: v.startswith("tp-"), 'should start with "tp-"'),
    "MINIMAX_API_KEY": (lambda v: len(v) > 20, "should be a long token"),
}


@config.command(name="set")
@click.argument("pair")
def config_set(pair: str):
    """Set a config value. Format: KEY=value or alias=value.

    Short aliases:
      deepseek=sk-...      → DEEPSEEK_API_KEY
      mimo=tp-...          → MIMO_API_KEY
      minimax=eyJ...       → MINIMAX_API_KEY
      model=MiniMax-M2.7   → MINIMAX_MODEL

    Full form also works:
      DEEPSEEK_API_KEY=sk-...
    """
    if "=" not in pair:
        click.echo("Error: format must be KEY=value", err=True)
        click.echo("Short aliases: deepseek, mimo, minimax, model, base_url")
        sys.exit(1)

    key, value = pair.split("=", 1)
    key = key.strip().lower()
    value = value.strip()

    if not value:
        click.echo("Error: value cannot be empty", err=True)
        sys.exit(1)

    # Resolve alias
    if key in KEY_ALIASES:
        resolved = KEY_ALIASES[key]
        click.echo(f"  ({key} → {resolved})")
        key = resolved
    else:
        key = key.upper()
        if not key.endswith("_KEY") and not key.endswith("_URL") and not key.endswith("_MODEL"):
            key = key + "_API_KEY"

    # Validate key format
    if key in KEY_VALIDATORS:
        validator, hint = KEY_VALIDATORS[key]
        if not validator(value):
            click.echo(f"Warning: {key} {hint}", err=True)
            if not click.confirm("Continue anyway?"):
                sys.exit(1)

    set_env_value(key, value)

    # Mask the value for display
    masked = value[:8] + "..." if len(value) > 8 else value
    click.echo(f"✓ Set {key}={masked}")

    if key in ENV_KEYS:
        click.echo(f"  ({ENV_KEYS[key]})")


@config.command(name="init")
def config_init():
    """Create a config template at ~/.hermes/.env."""
    if ENV_FILE.exists():
        click.echo(f"Config already exists: {ENV_FILE}")
        click.echo("Use 'noesis config set KEY=value' to update values.")
        return

    env_content = "# Noesis Configuration\n"
    env_content += "# Edit this file with your API keys\n\n"
    for key, desc in ENV_KEYS.items():
        env_content += f"# {desc}\n{key}=\n\n"

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    ENV_FILE.write_text(env_content)
    click.echo(f"✓ Created config template: {ENV_FILE}")
    click.echo("\nEdit with your API keys:")
    click.echo("  noesis config set DEEPSEEK_API_KEY=sk-...")
    click.echo("  noesis config set MIMO_API_KEY=tp-...")
    click.echo("  noesis config set MINIMAX_API_KEY=eyJ...")


@config.command(name="validate")
def config_validate():
    """Validate that all required config values are set."""
    env = load_env()
    issues = []
    for key, desc in ENV_KEYS.items():
        val = env.get(key, "")
        if not val:
            issues.append(f"  ✗ {key}: not set ({desc})")
        else:
            masked = val[:8] + "..."
            click.echo(f"  ✓ {key}: {masked}")

    if issues:
        click.echo("\nMissing keys:")
        for issue in issues:
            click.echo(issue)
        click.echo("\nSet with: noesis config set KEY=value")
        sys.exit(1)
    else:
        click.echo("\n✓ All required keys are set.")


# ── Wishes management ──────────────────────────────────────────────────────
@cli.command(name="wishes")
def list_wishes():
    """List current wishes and approved meta-wishes."""
    click.echo("Current wishes:")
    if WISHES_FILE.exists():
        wishes = [w.strip() for w in WISHES_FILE.read_text().splitlines() if w.strip() and not w.startswith("#")]
        if wishes:
            for i, w in enumerate(wishes):
                click.echo(f"  [{i}] {w[:80]}")
        else:
            click.echo("  (empty)")
    else:
        click.echo("  (file not found)")

    click.echo("\nApproved meta-wishes:")
    if META_WISHES_FILE.exists():
        try:
            meta = json.loads(META_WISHES_FILE.read_text())
            if meta:
                for m in meta:
                    click.echo(f"  - {m.get('wish', '?')[:70]}")
            else:
                click.echo("  (none)")
        except json.JSONDecodeError:
            click.echo("  (corrupt file)")
    else:
        click.echo("  (file not found)")


@cli.command()
@click.argument("wish_hash", required=False)
@click.option("--list", "-l", "list_debates", is_flag=True, help="List all saved debates")
def debate(wish_hash: str, list_debates: bool):
    """View debate transcript for a wish, or list all debates.

    Use 'noesis debate --list' to see all saved debates.
    Use 'noesis debate <hash>' to view a specific debate.
    """
    debates_dir = SCRIPTS_DIR / "debates"

    if list_debates or not wish_hash:
        if not debates_dir.exists():
            click.echo("No debates recorded yet.")
            return
        files = sorted(debates_dir.glob("*.json"), reverse=True)
        if not files:
            click.echo("No debates recorded yet.")
            return
        click.echo(f"{'Hash':<14} {'Wish':<60}")
        click.echo("-" * 76)
        for f in files[:20]:
            try:
                data = json.loads(f.read_text())
                wish = data.get("wish", "?")[:57]
                click.echo(f"{f.stem:<14} {wish}")
            except Exception:
                continue
        return

    # Show specific debate
    debate_file = debates_dir / f"{wish_hash}.json"
    if not debate_file.exists():
        click.echo(f"Debate '{wish_hash}' not found.", err=True)
        sys.exit(1)

    data = json.loads(debate_file.read_text())
    wish = data.get("wish", "?")
    transcript = data.get("transcript", [])

    click.echo(f"\n{'='*70}")
    click.echo(f"DEBATE: {wish[:65]}")
    click.echo(f"{'='*70}\n")

    if not transcript:
        click.echo("  (empty transcript)")
        return

    for entry in transcript:
        agent = entry.get("agent", "?")
        content = entry.get("content", "")
        click.echo(f"  [{agent}]")
        for line in content.split("\n")[:10]:
            click.echo(f"    {line[:65]}")
        if len(content) > 650:
            click.echo(f"    ... ({len(content)} chars total)")
        click.echo()


@cli.command()
def rejections():
    """Show rejection history (what the Architect learned from)."""
    if not REJECTIONS_FILE.exists():
        click.echo("No rejections recorded.")
        return
    try:
        data = json.loads(REJECTIONS_FILE.read_text())
        reasons = data.get("rejection_reasons", {})
        click.echo(f"Rejection history ({len(reasons)} entries):")
        click.echo("-" * 60)
        for wish, info in list(reasons.items())[-10:]:
            reason = info.get("reason", "?")[:60] if isinstance(info, dict) else str(info)[:60]
            click.echo(f"  {wish[:50]}")
            click.echo(f"    → {reason}")
    except json.JSONDecodeError:
        click.echo("Rejections file corrupt.", err=True)


# ── Project management ────────────────────────────────────────────────────
@cli.command()
@click.option("--name", "-n", prompt="Project name", help="Project name")
@click.option("--source", "-s", default="src", help="Source directory (relative to project root)")
@click.option("--wishes", "-w", default="wishes.txt", help="Wishes file (relative to project root)")
@click.option("--desc", "-d", default="", help="Project description")
def init(name: str, source: str, wishes: str, desc: str):
    """Initialize a Noesis project in the current directory.

    Creates .noesis.yaml config and registers the project.
    Run this from the project root directory.
    """
    project_dir = Path.cwd()
    config_path = project_dir / ".noesis.yaml"

    if config_path.exists():
        click.echo(f"Project already initialized: {config_path}")
        if not click.confirm("Overwrite?"):
            return

    # Create .noesis.yaml
    config_content = f"""# Noesis project configuration
name: {name}
source_dir: {source}
wishes_file: {wishes}
description: "{desc}"
"""
    config_path.write_text(config_content)
    click.echo(f"  ✓ Created {config_path}")

    # Create wishes file if not exists
    wishes_path = project_dir / wishes
    if not wishes_path.exists():
        wishes_path.write_text("# Add one wish per line\n")
        click.echo(f"  ✓ Created {wishes_path}")

    # Register in ~/.hermes/projects/
    from checkpoint import register_project, set_active_project
    register_project(name, project_dir, source, wishes, desc)
    set_active_project(name)
    click.echo(f"  ✓ Registered project: {name}")
    click.echo(f"  ✓ Set as active project")

    # Create .gitignore entry for noesis state
    gitignore = project_dir / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        if ".noesis" not in content:
            content += "\n# Noesis state\n.noesis/\n"
            gitignore.write_text(content)
            click.echo(f"  ✓ Updated .gitignore")

    click.echo(f"\n✓ Project '{name}' initialized!")
    click.echo(f"  Edit wishes: {wishes_path}")
    click.echo(f"  Start daemon: noesis start")
    click.echo(f"  Watch live: noesis watch")


@cli.command(name="list")
def list_projects_cmd():
    """List all registered Noesis projects."""
    from checkpoint import list_projects
    projects = list_projects()
    if not projects:
        click.echo("No projects registered. Run 'noesis init' in a project directory.")
        return

    active = None
    click.echo(f"{'Name':<20} {'Active':<8} {'Path':<40} Description")
    click.echo("-" * 90)
    for p in projects:
        marker = "●" if p["active"] else " "
        if p["active"]:
            active = p["name"]
        click.echo(f"{p['name']:<20} {marker:<8} {p['path']:<40} {p.get('description', '')[:30]}")

    if active:
        click.echo(f"\nActive project: {active}")


@cli.command()
@click.argument("name")
def switch(name: str):
    """Switch to a different Noesis project."""
    from checkpoint import set_active_project, load_project_state_config
    config = load_project_state_config(name)
    if not config:
        click.echo(f"Project '{name}' not found. Run 'noesis list' to see projects.", err=True)
        sys.exit(1)

    set_active_project(name)
    click.echo(f"✓ Switched to: {name}")
    click.echo(f"  Source: {config.get('project_dir', '?')}/{config.get('source_dir', 'src')}")
    click.echo(f"  Restart daemon: noesis restart")


@cli.command()
@click.option("--all", "-a", "show_all", is_flag=True, help="Show all projects status")
def status(show_all: bool):
    """Show Noesis daemon status and project info."""
    from checkpoint import get_active_project, load_project_state_config, list_projects

    if show_all:
        projects = list_projects()
        for p in projects:
            marker = "●" if p["active"] else " "
            click.echo(f"{marker} {p['name']}: {p.get('description', '')}")
        return

    # Show active project
    active = get_active_project()
    if active:
        config = load_project_state_config(active)
        click.echo(f"Project: {active}")
        click.echo(f"  Source: {config.get('project_dir', '?')}/{config.get('source_dir', 'src')}")

    # Existing status logic (daemon, checkpoint, metrics, etc.)
    daemon_active = is_daemon_running()
    click.echo(f"\nDaemon:      {'● running' if daemon_active else '○ stopped'}")

    if CHECKPOINT_FILE.exists():
        try:
            cp = json.loads(CHECKPOINT_FILE.read_text())
            click.echo(f"  Iterations:    {cp.get('iterations', 0)}")
            click.echo(f"  Applied:       {len(cp.get('applied_patches', []))}")
        except Exception:
            pass

    if METRICS_FILE.exists():
        try:
            metrics = json.loads(METRICS_FILE.read_text())
            total = metrics.get("tokens_total", 0)
            click.echo(f"  Tokens used:   {total:,}")
        except Exception:
            pass


# ── Dashboard ──────────────────────────────────────────────────────────────
@cli.command()
@click.option("--refresh", "-r", default=3.0, help="Refresh rate in seconds")
def watch(refresh: float):
    """Live terminal dashboard — watch the pipeline in real-time."""
    try:
        from noesis.dashboard import run_dashboard
    except ImportError:
        # Try relative import for script-mode execution
        import sys as _sys
        _sys.path.insert(0, str(Path(__file__).parent))
        from dashboard import run_dashboard
    run_dashboard(refresh_rate=refresh)


# ── Version ────────────────────────────────────────────────────────────────
@cli.command()
def version():
    """Show Noesis version and component info."""
    click.echo(f"Noesis CLI:   {__version__}")

    # Check package version
    try:
        from noesis import __version__ as pkg_version
        click.echo(f"Package:      {pkg_version}")
    except ImportError:
        click.echo(f"Package:      (not installed)")

    # Check daemon
    if is_daemon_running():
        click.echo(f"Daemon:       running")
    else:
        click.echo(f"Daemon:       stopped")

    # Check Python
    click.echo(f"Python:       {sys.version.split()[0]}")
    click.echo(f"Platform:     {sys.platform}")


def main():
    cli()


if __name__ == "__main__":
    main()
