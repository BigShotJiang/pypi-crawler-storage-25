"""Checkpoint, PID, metrics, rejection tracking, file locking, and validation."""

import os, sys, json, time, fcntl
from typing import Optional
from pathlib import Path
from datetime import datetime, timezone

# ── Config ────────────────────────────────────────────────────────────────
SCRIPTS_DIR = Path.home() / ".hermes" / "scripts"
PROJECTS_DIR = Path.home() / ".hermes" / "projects"
ACTIVE_PROJECT_FILE = Path.home() / ".hermes" / "active_project"
LOG_FILE = SCRIPTS_DIR / "mcp_self_improve.log"
PID_FILE = SCRIPTS_DIR / "mcp_self_improve.pid"
PAUSE_FILE = SCRIPTS_DIR / "mcp_self_improve.pause"


def get_active_project() -> Optional[str]:
    """Get the name of the currently active project."""
    if ACTIVE_PROJECT_FILE.exists():
        return ACTIVE_PROJECT_FILE.read_text().strip()
    return None


def set_active_project(name: str):
    """Set the active project."""
    ACTIVE_PROJECT_FILE.parent.mkdir(parents=True, exist_ok=True)
    ACTIVE_PROJECT_FILE.write_text(name)


def load_project_state_config(project_name: str = None) -> dict:
    """Load the registered project config from state dir."""
    name = project_name or get_active_project() or "default"
    state_dir = PROJECTS_DIR / name
    config_file = state_dir / "config.yaml"
    if not config_file.exists():
        return {}
    config = {}
    try:
        for line in config_file.read_text().splitlines():
            line = line.strip()
            if ":" in line and not line.startswith("#"):
                k, v = line.split(":", 1)
                config[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    return config


def get_source_files() -> list[Path]:
    """Get all Python files in the project source directory."""
    if not MCP_SOURCE_DIR.exists():
        return []
    return sorted([p for p in MCP_SOURCE_DIR.glob("*.py")])



def read_file_content(path: Path) -> str:
    """Read a file, truncated to 8000 lines to avoid huge payloads."""
    try:
        lines = path.read_text().splitlines()[:8000]
        return "\n".join(lines)
    except Exception as e:
        return f"[READ ERROR: {e}]"


def get_file_map() -> str:
    """Return a compact map of files: name + function/class signatures."""
    lines = []
    for fp in get_source_files():
        content = read_file_content(fp)
        # Extract top-level def/class signatures (cheap AST-free heuristic)
        signatures = []
        for ln in content.splitlines():
            stripped = ln.strip()
            if stripped.startswith(("def ", "async def ", "class ")):
                # grab the def/class line only (no body)
                signatures.append(stripped)
        line_count = len(content.splitlines())
        sig_block = ""
        if signatures:
            sig_block = "  Exports: " + "; ".join(signatures[:10])
        lines.append(f"  {fp.name} ({line_count} lines){sig_block}")
    return "\n".join(lines)


def read_target_files(filenames: list[str], codebase_root: Path) -> dict[str, str]:
    """Read specific files from a codebase root. Returns {relpath: content}."""
    results = {}
    for fn in filenames:
        fn = fn.strip()
        if not fn:
            continue
        # Try relative to codebase_root, then absolute
        fp = codebase_root / fn
        if not fp.exists():
            fp = Path(fn)
        if fp.exists() and fp.is_file():
            results[str(fp)] = read_file_content(fp)
        else:
            results[fn] = "[NOT FOUND]"
    return results


def format_codebase_snapshot(files: dict[str, str], max_chars: int = 6000) -> str:
    """Format a dict of {filename: content} into a compact string for LLM context."""
    parts = []
    total = 0
    for name, content in sorted(files.items()):
        snippet = f"### {name}\n{content}"
        if total + len(snippet) > max_chars:
            remaining = max_chars - total
            if remaining > 100:
                parts.append(f"### {name} (truncated)\n{content[:remaining]}...")
            break
        parts.append(snippet)
        total += len(snippet)
    return "\n\n".join(parts)


# ── AST validation ────────────────────────────────────────────────────────────


# ── Syntax and import checks ──────────────────────────────────────────────

def _source_dir() -> Path:
    """Get source directory for active project."""
    active = get_active_project()
    if active:
        config = load_project_state_config(active)
        project_dir = config.get("project_dir", "")
        source_dir = config.get("source_dir", "src")
        if project_dir:
            return Path(project_dir) / source_dir
    return Path.home() / "mcp-work" / "src" / "noesis"


def _project_state_dir() -> Path:
    """Get state directory for active project, or global fallback."""
    active = get_active_project()
    if active:
        d = PROJECTS_DIR / active
        d.mkdir(parents=True, exist_ok=True)
        return d
    return SCRIPTS_DIR


def _checkpoint():
    return _project_state_dir() / "checkpoint.json"
def _metrics():
    return _project_state_dir() / "mcp_self_improve_metrics.json"
def _recent_wishes():
    return _project_state_dir() / "mcp_self_improve_recent_wishes.json"
def _debates():
    return _project_state_dir() / "debates"
def _rejections():
    return _project_state_dir() / "noesis_rejections.json"
def _meta_wishes():
    return _project_state_dir() / "meta_wish_approved.json"
def _wishes_file():
    """Get wishes file for active project."""
    active = get_active_project()
    if active:
        config = load_project_state_config(active)
        project_dir = config.get("project_dir", "")
        wishes = config.get("wishes_file", "wishes.txt")
        if project_dir:
            return Path(project_dir) / wishes
    return Path.home() / "mcp-work" / "wishes.txt"


MCP_SOURCE_DIR = _source_dir()
SAFE_WRITE_ROOT = MCP_SOURCE_DIR.parent
CHECKPOINT_FILE = _checkpoint()
METRICS_FILE = _metrics()
RECENT_WISHES_FILE = _recent_wishes()
DEBATE_DIR = _debates()
REJECTIONS_FILE = _rejections()
META_WISHES_FILE = _meta_wishes()
WISHES_FILE = _wishes_file()
PID_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve.pid"
PAUSE_FILE = Path.home() / ".hermes" / "scripts" / "mcp_self_improve.pause"
METRICS_FILE = _metrics()  # uses project-aware path, synced with dashboard
MAX_ITERATIONS = 200
DRY_RUN = False  # Set by --dry-run flag



def validate_write_path(filename: str, root: Path = SAFE_WRITE_ROOT) -> Path | None:
    """Validate that a file path stays within the allowed project directory.

    Prevents path traversal attacks (e.g. '../../etc/passwd').
    Returns the resolved Path if valid, None if the path escapes the root.

    Works for any project — root defaults to MCP_SOURCE_DIR.parent (repo root)
    but can be overridden per-deployment.
    """
    # Resolve the target path
    target = (root / filename).resolve()
    root_resolved = root.resolve()

    # Check if target is within root
    try:
        target.relative_to(root_resolved)
        return target
    except ValueError:
        log(f"[SECURITY] Path traversal blocked: {filename} escapes {root_resolved}")
        return None

API_TIMEOUT = 360
DEBATE_ROUNDS = 3          # max judge-reject → retry cycles per wish
MAX_CONTEXT_FILES = 8      # max files to read per debate turn
WATCH_INTERVAL = 60        # seconds to sleep when Scout finds nothing
ARCHITECT_COOLDOWN = 3600  # seconds between architect-scout runs (1h)


# ── Logging ───────────────────────────────────────────────────────────────────
def log(msg: str, print_it: bool = True) -> None:
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    line = f"[{ts}] {msg}"
    if print_it:
        print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOG_FILE.open("a").write(line + "\n")


# ── Checkpoint ────────────────────────────────────────────────────────────────
def load_checkpoint() -> dict:
    """Load checkpoint with shared lock to prevent reading during a write."""
    if CHECKPOINT_FILE.exists():
        try:
            with open(CHECKPOINT_FILE, "r") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                data = json.loads(f.read())
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                return data
        except Exception:
            pass
    return {
        "iterations": 0,
        "applied_patches": [],
        "done": False,
        "wish_index": 0,
        "debate_round": 0,
        "last_wish": None,
    }


def save_checkpoint(cp: dict) -> None:
    """Save checkpoint with exclusive lock, atomic write, and backup rotation."""
    cp["last_updated"] = datetime.now(timezone.utc).isoformat()
    CHECKPOINT_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(cp, indent=2, default=str)

    # Rotate backups: keep last 3
    MAX_BACKUPS = 3
    for i in range(MAX_BACKUPS - 1, 0, -1):
        older = CHECKPOINT_FILE.with_suffix(f".bak{i}")
        newer = CHECKPOINT_FILE.with_suffix(f".bak{i+1}") if i < MAX_BACKUPS else None
        if i == MAX_BACKUPS - 1:
            older_backup = CHECKPOINT_FILE.with_suffix(f".bak{MAX_BACKUPS}")
            if older_backup.exists():
                older_backup.unlink()
        if older.exists():
            older.rename(CHECKPOINT_FILE.with_suffix(f".bak{i+1}"))
    if CHECKPOINT_FILE.exists():
        CHECKPOINT_FILE.rename(CHECKPOINT_FILE.with_suffix(".bak1"))

    # Atomic write: write to temp file, then rename
    tmp = CHECKPOINT_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    tmp.rename(CHECKPOINT_FILE)


def is_duplicate_wish(wish: str) -> bool:
    """Check if this wish was recently proposed (text similarity)."""
    try:
        recent = [] if not RECENT_WISHES_FILE.exists() else json.loads(RECENT_WISHES_FILE.read_text())
    except Exception:
        recent = []
    wish_lower = wish.lower().strip()
    for entry in recent:
        prev = entry.get("wish", "").lower().strip()
        # Exact match or high overlap
        if wish_lower == prev:
            return True
        # Check if >70% of words overlap
        wish_words = set(wish_lower.split())
        prev_words = set(prev.split())
        if wish_words and prev_words:
            overlap = len(wish_words & prev_words) / max(len(wish_words), len(prev_words))
            if overlap > 0.7:
                return True
    return False


def record_wish(wish: str, status: str = "proposed"):
    """Record a wish in the recent wishes list (keeps last 50)."""
    try:
        recent = [] if not RECENT_WISHES_FILE.exists() else json.loads(RECENT_WISHES_FILE.read_text())
    except Exception:
        recent = []
    recent.append({
        "wish": wish[:200],
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })
    # Keep last 50
    recent = recent[-50:]
    RECENT_WISHES_FILE.parent.mkdir(parents=True, exist_ok=True)
    RECENT_WISHES_FILE.write_text(json.dumps(recent, indent=2))


def save_debate(wish: str, transcript: list[dict]):
    """Save a debate transcript for later review.

    Each entry: {"agent": "Critic", "content": "...", "timestamp": "..."}
    """
    import hashlib
    DEBATE_DIR.mkdir(parents=True, exist_ok=True)
    # Use wish hash as filename
    wish_hash = hashlib.md5(wish.encode()).hexdigest()[:12]
    filename = f"{wish_hash}.json"
    debate_file = DEBATE_DIR / filename
    debate_file.write_text(json.dumps({
        "wish": wish,
        "transcript": transcript,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }, indent=2))
    return wish_hash


def load_debate(wish_hash: str) -> Optional[dict]:
    """Load a debate transcript by wish hash."""
    debate_file = DEBATE_DIR / f"{wish_hash}.json"
    if not debate_file.exists():
        return None
    try:
        return json.loads(debate_file.read_text())
    except Exception:
        return None


def list_debates() -> list[dict]:
    """List all saved debate transcripts."""
    if not DEBATE_DIR.exists():
        return []
    debates = []
    for f in sorted(DEBATE_DIR.glob("*.json"), reverse=True):
        try:
            data = json.loads(f.read_text())
            data["hash"] = f.stem
            debates.append(data)
        except Exception:
            continue
    return debates


def load_project_config(project_dir: Path = None) -> Optional[dict]:
    """Load .noesis.yaml from project directory."""
    import yaml  # optional dep, falls back to manual parse
    config_file = (project_dir or Path.cwd()) / ".noesis.yaml"
    if not config_file.exists():
        return None
    try:
        # Try yaml first, fall back to manual parse
        try:
            return yaml.safe_load(config_file.read_text())
        except ImportError:
            # Manual YAML-ish parse for simple key: value format
            config = {}
            for line in config_file.read_text().splitlines():
                line = line.strip()
                if ":" in line and not line.startswith("#"):
                    k, v = line.split(":", 1)
                    config[k.strip()] = v.strip().strip('"').strip("'")
            return config
    except Exception:
        return None


def get_project_state_dir(project_name: str = None) -> Path:
    """Get the state directory for a project."""
    name = project_name or get_active_project() or "default"
    state_dir = PROJECTS_DIR / name
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


def list_projects() -> list[dict]:
    """List all registered projects."""
    if not PROJECTS_DIR.exists():
        return []
    projects = []
    for d in sorted(PROJECTS_DIR.iterdir()):
        if d.is_dir():
            config_file = d / "config.yaml"
            config = {}
            if config_file.exists():
                try:
                    for line in config_file.read_text().splitlines():
                        line = line.strip()
                        if ":" in line and not line.startswith("#"):
                            k, v = line.split(":", 1)
                            config[k.strip()] = v.strip().strip('"')
                except Exception:
                    pass
            projects.append({
                "name": d.name,
                "path": config.get("project_dir", "?"),
                "description": config.get("description", ""),
                "active": d.name == get_active_project(),
            })
    return projects


def register_project(name: str, project_dir: Path, source_dir: str = "src",
                     wishes_file: str = "wishes.txt", description: str = ""):
    """Register a new project."""
    state_dir = PROJECTS_DIR / name
    state_dir.mkdir(parents=True, exist_ok=True)
    config = {
        "name": name,
        "project_dir": str(project_dir),
        "source_dir": source_dir,
        "wishes_file": wishes_file,
        "description": description,
    }
    config_file = state_dir / "config.yaml"
    lines = [f"{k}: {v}" for k, v in config.items()]
    config_file.write_text("\n".join(lines) + "\n")


def track_metric(event: str):
    """Track pipeline events: wish_proposed, wish_approved, wish_rejected, audit_rejected, layer1_failed."""
    try:
        metrics = {} if not METRICS_FILE.exists() else json.loads(METRICS_FILE.read_text())
    except Exception:
        metrics = {}
    metrics[event] = metrics.get(event, 0) + 1
    metrics["last_updated"] = datetime.now(timezone.utc).isoformat()
    METRICS_FILE.parent.mkdir(parents=True, exist_ok=True)
    METRICS_FILE.write_text(json.dumps(metrics, indent=2))


def acquire_pid_file() -> bool:
    """Check if another instance is running. If not, write our PID. Returns True if acquired."""
    if PID_FILE.exists():
        try:
            old_pid = int(PID_FILE.read_text().strip())
            # Check if process is still alive
            os.kill(old_pid, 0)
            log(f"[PID] Another instance running (PID {old_pid}). Exiting.")
            return False
        except (ProcessLookupError, ValueError):
            # Process dead or PID file corrupt — safe to proceed
            pass
        except PermissionError:
            # Process exists but owned by different user — assume it's running
            log(f"[PID] Another instance may be running (permission denied checking PID). Exiting.")
            return False

    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    log(f"[PID] Acquired PID file (PID {os.getpid()})")
    return True


def release_pid_file() -> None:
    """Remove PID file on clean shutdown."""
    try:
        if PID_FILE.exists() and PID_FILE.read_text().strip() == str(os.getpid()):
            PID_FILE.unlink()
    except Exception:
        pass


# ── Persistent rejection store ─────────────────────────────────────────────────
REJECTIONS_FILE = Path.home() / ".hermes" / "scripts" / "noesis_rejections.json"


def save_rejection_reason(wish: str, reason: str) -> None:
    """Persist a wish→reason mapping so Architect can read it next run."""
    try:
        rejections = {} if not REJECTIONS_FILE.exists() else json.loads(REJECTIONS_FILE.read_text())
    except Exception:
        rejections = {}
    # Normalize wish to a comparable key
    normalized = wish.strip()
    rejections[normalized] = {"reason": reason, "timestamp": datetime.now(timezone.utc).isoformat()}
    REJECTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    REJECTIONS_FILE.write_text(json.dumps(rejections, indent=2))


def load_rejection_reasons() -> dict:
    """Load all rejection reasons from persistent store.

    The file format is {"rejection_reasons": {...}, ...}. Returns only the
    rejection_reasons sub-dict so callers can iterate wish→reason pairs.
    """
    try:
        if not REJECTIONS_FILE.exists():
            return {}
        raw = json.loads(REJECTIONS_FILE.read_text())
        # Support both flat format and {"rejection_reasons": {...}} wrapper
        if isinstance(raw, dict) and "rejection_reasons" in raw:
            return raw["rejection_reasons"]
        elif isinstance(raw, dict):
            # Filter out non-reason top-level keys
            return {k: v for k, v in raw.items()
                    if k not in ("rejections", "timestamp", "version")}
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def save_meta_wish(wish: str, proposal: str) -> None:
    """Persist an approved meta-wish proposal to the approved list."""
    try:
        approved = [] if not META_WISHES_FILE.exists() else json.loads(META_WISHES_FILE.read_text())
    except Exception:
        approved = []
    approved.append({
        "wish": wish,
        "proposal": proposal,
        "timestamp": datetime.now(timezone.utc).isoformat()
    })
    META_WISHES_FILE.parent.mkdir(parents=True, exist_ok=True)
    META_WISHES_FILE.write_text(json.dumps(approved, indent=2))
    log(f"[META-WISH] Saved to {META_WISHES_FILE}")


# ── File locks: prevent concurrent-wish conflicts ─────────────────────────────
LOCKS_FILE = Path.home() / ".hermes" / "scripts" / "noesis_file_locks.json"


def load_locks() -> dict:
    try:
        return {} if not LOCKS_FILE.exists() else json.loads(LOCKS_FILE.read_text())
    except Exception:
        return {}


def save_locks(lock_map: dict) -> None:
    LOCKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOCKS_FILE.write_text(json.dumps(lock_map, indent=2))


def claim_files(file_list: list[str]) -> tuple[bool, list[str]]:
    """Claim files for the current wish. Returns (claimed_ok, already_locked_by_us).
    Call this after Proposer produces code_blocks (we now know which files it targets)."""
    locks = load_locks()
    my_claims = [f for f, w in locks.items() if w == "current"]
    locked_by_others = [f for f in file_list if f in locks and locks[f] != "current"]
    if locked_by_others:
        return False, []
    for f in file_list:
        locks[f] = "current"
    save_locks(locks)
    return True, my_claims


def release_files(file_list: list[str]) -> None:
    """Release file locks held by the current wish."""
    locks = load_locks()
    for f in file_list:
        if locks.get(f) == "current":
            del locks[f]
    save_locks(locks)


# ── Adaptive debate rounds ─────────────────────────────────────────────────────
def adaptive_debate_rounds(severity: str) -> int:
    """Return effective debate rounds based on Critic severity.
    Blockers/high need fewer retries — either the Defender can fix it or it can't."""
    return {  # (severity → rounds, reason)
        "blocker": (1, "Defender can't resolve fundamental flaws in one round"),
        "high":    (1, "High-severity issues are either fixable immediately or not worth iterating"),
        "medium":  (2, "Standard debate rounds for addressable concerns"),
        "low":     (3, "Style/nitpicks may need multiple rounds of refinement"),
    }.get(severity, (3, "Default"))[0]




# Re-export constants for other modules
__all__ = [
    'MCP_SOURCE_DIR', 'SAFE_WRITE_ROOT', 'CHECKPOINT_FILE', 'LOG_FILE',
    'WISHES_FILE', 'META_WISHES_FILE', 'PID_FILE', 'PAUSE_FILE', 'METRICS_FILE',
    'MAX_ITERATIONS', 'DRY_RUN', 'API_TIMEOUT', 'DEBATE_ROUNDS', 'MAX_CONTEXT_FILES',
    'WATCH_INTERVAL', 'ARCHITECT_COOLDOWN',
    'validate_write_path', 'log', 'load_checkpoint', 'save_checkpoint',
    'track_metric', 'acquire_pid_file', 'release_pid_file',
    'save_rejection_reason', 'load_rejection_reasons', 'save_meta_wish',
    'load_locks', 'save_locks', 'claim_files', 'release_files',
    'adaptive_debate_rounds',
]
