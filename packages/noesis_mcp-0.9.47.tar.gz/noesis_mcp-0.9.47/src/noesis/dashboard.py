"""Noesis Terminal Dashboard — live pipeline visualization.

Features:
- Live debate transcript (agent outputs as they stream)
- Pipeline flow animation (arrows light up as stages progress)
- Win rate chart (ASCII bar chart)
- Project banner (big colored project name)
- Git diff summary (files changed per wish)
"""

import json
import time
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich import box

try:
    from noesis import __version__
except ImportError:
    __version__ = "dev"

# ── Paths ─────────────────────────────────────────────────────────────────
SCRIPTS_DIR = Path.home() / ".hermes" / "scripts"
PROJECTS_DIR = Path.home() / ".hermes" / "projects"
ACTIVE_PROJECT_FILE = Path.home() / ".hermes" / "active_project"


def _project_state_dir() -> Path:
    active = None
    if ACTIVE_PROJECT_FILE.exists():
        active = ACTIVE_PROJECT_FILE.read_text().strip()
    if active:
        d = PROJECTS_DIR / active
        if d.exists():
            return d
    return SCRIPTS_DIR


def _get_active_project() -> str:
    if ACTIVE_PROJECT_FILE.exists():
        return ACTIVE_PROJECT_FILE.read_text().strip()
    return "default"


def _project_config() -> dict:
    state_dir = _project_state_dir()
    config_file = state_dir / "config.yaml"
    if not config_file.exists():
        return {}
    config = {}
    try:
        for line in config_file.read_text().splitlines():
            line = line.strip()
            if ":" in line and not line.startswith("#"):
                k, v = line.split(":", 1)
                config[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    return config


def _checkpoint_file() -> Path:
    return _project_state_dir() / "checkpoint.json"


def _metrics_file() -> Path:
    return _project_state_dir() / "mcp_self_improve_metrics.json"


def _debates_dir() -> Path:
    return _project_state_dir() / "debates"


def _rejections_file() -> Path:
    return _project_state_dir() / "noesis_rejections.json"


LOG_FILE = SCRIPTS_DIR / "mcp_self_improve.log"
PAUSE_FILE = SCRIPTS_DIR / "mcp_self_improve.pause"
PID_FILE = SCRIPTS_DIR / "mcp_self_improve.pid"

console = Console()


# ── Data readers ──────────────────────────────────────────────────────────
def read_checkpoint() -> dict:
    try:
        f = _checkpoint_file()
        return json.loads(f.read_text()) if f.exists() else {}
    except Exception:
        return {}


def read_metrics() -> dict:
    try:
        f = _metrics_file()
        return json.loads(f.read_text()) if f.exists() else {}
    except Exception:
        return {}


def read_last_log_lines(n: int = 30) -> list[str]:
    if not LOG_FILE.exists():
        return []
    try:
        result = subprocess.run(
            ["tail", "-n", str(n), str(LOG_FILE)],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip().split("\n") if result.stdout.strip() else []
    except Exception:
        return []


def is_daemon_running() -> bool:
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", "mcp-self-improve"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() == "active"
    except Exception:
        return False


def get_daemon_pid() -> Optional[str]:
    if PID_FILE.exists():
        try:
            return PID_FILE.read_text().strip()
        except Exception:
            pass
    return None


def get_uptime() -> str:
    pid = get_daemon_pid()
    if not pid:
        return "unknown"
    try:
        result = subprocess.run(
            ["ps", "-o", "etime=", "-p", pid],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.stdout.strip() else "unknown"
    except Exception:
        return "unknown"


def get_memory() -> str:
    pid = get_daemon_pid()
    if not pid:
        return "unknown"
    try:
        result = subprocess.run(
            ["ps", "-o", "rss=", "-p", pid],
            capture_output=True, text=True, timeout=5,
        )
        if result.stdout.strip():
            rss_kb = int(result.stdout.strip())
            return f"{rss_kb // 1024}MB"
    except Exception:
        pass
    return "unknown"


def get_git_diff_summary(project_dir: str) -> list[dict]:
    """Get recent git changes in the project."""
    if not project_dir:
        return []
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", "--name-status", "-5"],
            capture_output=True, text=True, timeout=5,
            cwd=project_dir,
        )
        changes = []
        current_commit = None
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            if line and not line[0].isspace() and line[0] in "0123456789abcdef":
                current_commit = line[:7]
            elif line.startswith(("A\t", "M\t", "D\t")):
                status = line[0]
                filename = line[2:]
                changes.append({"commit": current_commit, "status": status, "file": filename})
        return changes[:10]
    except Exception:
        return []


def get_recent_debates() -> list[dict]:
    """Get recent debate transcripts."""
    debates_dir = _debates_dir()
    if not debates_dir.exists():
        return []
    debates = []
    for f in sorted(debates_dir.glob("*.json"), reverse=True)[:3]:
        try:
            data = json.loads(f.read_text())
            debates.append(data)
        except Exception:
            continue
    return debates


# ── Pipeline stage detection ──────────────────────────────────────────────
def detect_pipeline_stage(lines: list[str]) -> dict:
    stage = {
        "scout": "idle", "proposer": "idle", "critic": "idle",
        "defender": "idle", "judge": "idle", "auditor": "idle",
        "current_wish": "", "critic_text": "", "judge_text": "",
        "proposer_text": "", "last_agent": "", "last_output": "",
        "wish_num": "", "round_num": "",
    }
    for line in reversed(lines):
        if "Analyzing" in line and "Scout" in line:
            stage["scout"] = "active"
        elif "PROPOSER" in line and "drafting" in line:
            stage["proposer"] = "active"
            stage["scout"] = "done"
            if "]" in line:
                stage["last_agent"] = "Proposer"
        elif "MINIMAX" in line and "tokens=" in line:
            stage["proposer"] = "done"
        elif "CRITIC" in line and "analyzing" in line:
            stage["critic"] = "active"
            stage["proposer"] = "done"
        elif "DEEPSEEK-R1" in line and "tokens=" in line:
            stage["critic"] = "done"
        elif "CRITIC" in line and "verdict:" in line:
            stage["critic"] = "done"
            if "APPROVED" in line:
                stage["critic_verdict"] = "approved"
            else:
                stage["critic_verdict"] = "rejected"
        elif "DEFENDER" in line:
            stage["defender"] = "active"
        elif "SYNTHESIZER" in line:
            stage["synthesizer"] = "active"
        elif "JUDGE" in line and ("Meta-wish" in line or "passing verdict" in line):
            stage["judge"] = "active"
        elif "MIMO" in line and "tokens=" in line:
            # Could be Judge or Scout
            pass
        elif "JUDGE" in line and "VERDICT:" in line:
            stage["judge"] = "done"
            stage["judge_text"] = line[line.index("VERDICT:"):][:100]
        elif "AUDITOR" in line:
            stage["auditor"] = "active"
        elif "WISH" in line and "round" in line:
            if "]" in line:
                wish_part = line[line.index("]")+1:].strip()
                if ":" in wish_part:
                    wish_part = wish_part[wish_part.index(":")+1:].strip()
                stage["current_wish"] = wish_part[:80]
            # Extract wish number
            import re
            m = re.search(r'WISH \[(\d+)\]', line)
            if m:
                stage["wish_num"] = m.group(1)
            m = re.search(r'round (\d+)/(\d+)', line)
            if m:
                stage["round_num"] = f"{m.group(1)}/{m.group(2)}"
    return stage


# ── Layout builders ───────────────────────────────────────────────────────
def build_project_banner() -> Panel:
    """Big colored project name at the top."""
    project = _get_active_project()
    config = _project_config()
    desc = config.get("description", "")
    running = is_daemon_running()
    uptime = get_uptime()
    memory = get_memory()
    pid = get_daemon_pid()
    pause = "PAUSED" if PAUSE_FILE.exists() else ""

    # Project name in big style
    title = Text()
    title.append(f"  {project.upper()}", style="bold cyan")
    if desc:
        title.append(f"  —  {desc}", style="dim")

    # Status line
    status = Text()
    if running:
        status.append("  ● Running", style="bold green")
    else:
        status.append("  ○ Stopped", style="bold red")
    if pause:
        status.append(f"  ⏸ {pause}", style="bold yellow")
    status.append(f"  │  Uptime: {uptime}", style="dim")
    status.append(f"  │  Memory: {memory}", style="dim")
    if pid:
        status.append(f"  │  PID: {pid}", style="dim")
    status.append(f"  │  v{__version__}", style="dim")

    content = Text.assemble(title, "\n", status)
    return Panel(
        Align.center(content),
        border_style="cyan",
        box=box.DOUBLE,
    )


def build_pipeline(stage: dict) -> Panel:
    """Pipeline flow with animated arrows."""
    agents = [
        ("SCOUT", "mimo", stage.get("scout", "idle")),
        ("PROPOSER", "MiniMax", stage.get("proposer", "idle")),
        ("CRITIC", "DeepSeek", stage.get("critic", "idle")),
        ("DEFENDER", "MiniMax", stage.get("defender", "idle")),
        ("JUDGE", "mimo", stage.get("judge", "idle")),
    ]

    # Build horizontal flow with arrows
    parts = []
    for i, (name, model, status) in enumerate(agents):
        if status == "active":
            style = "bold yellow"
            icon = "⟳"
        elif status == "done":
            style = "green"
            icon = "✓"
        else:
            style = "dim"
            icon = "·"

        parts.append(Text(f" {icon} {name} ", style=style))
        if i < len(agents) - 1:
            if status == "done":
                parts.append(Text("→", style="green"))
            elif status == "active":
                parts.append(Text("→", style="yellow"))
            else:
                parts.append(Text("→", style="dim"))

    # Add model names below
    model_line = Text()
    model_line.append("  ", style="dim")
    for i, (name, model, _) in enumerate(agents):
        model_line.append(f"{model:^10}", style="dim")
        if i < len(agents) - 1:
            model_line.append("  ", style="dim")

    content = Text.assemble(*parts)
    return Panel(
        Text.assemble(content, "\n", model_line),
        title="[bold]Pipeline[/bold]",
        border_style="cyan",
        box=box.ROUNDED,
    )


def build_wish_panel(stage: dict) -> Panel:
    """Current wish with debate transcript."""
    content = Text()

    # Wish info
    wish = stage.get("current_wish", "")
    wish_num = stage.get("wish_num", "")
    round_num = stage.get("round_num", "")

    if wish:
        if wish_num:
            content.append(f"WISH #{wish_num}", style="bold cyan")
            if round_num:
                content.append(f"  (round {round_num})", style="dim")
            content.append("\n")
        content.append(wish, style="white")
    else:
        content.append("No active wish", style="dim")

    # Show latest agent output
    content.append("\n\n")
    if stage.get("critic") == "active":
        content.append("CRITIC (DeepSeek R1) — analyzing...\n", style="bold yellow")
        content.append("Searching for flaws in the proposal...\n", style="dim")
    elif stage.get("critic_verdict"):
        verdict = stage["critic_verdict"]
        if verdict == "approved":
            content.append("CRITIC: ", style="bold")
            content.append("APPROVED\n", style="bold green")
        else:
            content.append("CRITIC: ", style="bold")
            content.append("REJECTED\n", style="bold red")
    elif stage.get("judge") == "active":
        content.append("JUDGE (mimo) — evaluating...\n", style="bold magenta")
    elif stage.get("judge_text"):
        content.append(stage["judge_text"] + "\n", style="magenta")

    return Panel(content, title="[bold]Current Wish[/bold]", border_style="yellow", box=box.ROUNDED)


def build_debate_transcript() -> Panel:
    """Show recent debate transcripts."""
    debates = get_recent_debates()
    content = Text()

    if not debates:
        content.append("No debates recorded yet.", style="dim")
    else:
        for debate in debates[:2]:
            wish = debate.get("wish", "?")[:60]
            transcript = debate.get("transcript", [])
            content.append(f"▸ {wish}\n", style="bold cyan")

            agent_colors = {
                "Proposer": "cyan", "Critic": "red", "Defender": "green",
                "Synthesizer": "yellow", "Judge": "magenta",
            }
            for entry in transcript[:4]:
                agent = entry.get("agent", "?")
                text = entry.get("content", "")[:80]
                color = agent_colors.get(agent, "white")
                content.append(f"  [{agent}] ", style=f"bold {color}")
                content.append(f"{text}\n", style="dim")
            content.append("\n")

    return Panel(content, title="[bold]Debate Transcript[/bold]", border_style="blue", box=box.ROUNDED)


def build_win_rate_chart(metrics: dict) -> Panel:
    """ASCII bar chart of approval vs rejection."""
    proposed = metrics.get("wish_proposed", 0)
    approved = metrics.get("wish_approved", 0)
    rejected = proposed - approved
    rate = (approved / proposed * 100) if proposed > 0 else 0

    # Build bar chart
    bar_width = 20
    if proposed > 0:
        approve_bar = int(approved / proposed * bar_width)
        reject_bar = bar_width - approve_bar
    else:
        approve_bar = 0
        reject_bar = bar_width

    content = Text()
    content.append(f"  Win Rate: ", style="bold")
    if rate >= 70:
        content.append(f"{rate:.0f}%", style="bold green")
    elif rate >= 40:
        content.append(f"{rate:.0f}%", style="bold yellow")
    else:
        content.append(f"{rate:.0f}%", style="bold red")
    content.append(f"  ({approved}/{proposed})\n\n")

    content.append("  ", style="dim")
    content.append("█" * approve_bar, style="green")
    content.append("█" * reject_bar, style="red")
    content.append("\n")

    content.append("  ", style="dim")
    content.append(f"✓ {approved} approved", style="green")
    content.append("  │  ", style="dim")
    content.append(f"✗ {rejected} rejected", style="red")
    content.append("\n\n")

    # Token cost
    tokens_total = metrics.get("tokens_total", 0)
    tokens_mimo = metrics.get("tokens_mimo", 0)
    tokens_deepseek = metrics.get("tokens_deepseek", 0)
    tokens_minimax = metrics.get("tokens_minimax", 0)

    content.append("  Token Usage\n", style="bold")
    content.append(f"  mimo      {tokens_mimo:>8,}\n", style="cyan")
    content.append(f"  DeepSeek  {tokens_deepseek:>8,}\n", style="blue")
    content.append(f"  MiniMax   {tokens_minimax:>8,}\n", style="green")
    content.append(f"  ─────────────────\n", style="dim")
    content.append(f"  TOTAL     {tokens_total:>8,}", style="bold")

    return Panel(content, title="[bold]Stats[/bold]", border_style="green", box=box.ROUNDED)


def build_git_diff(project_dir: str) -> Panel:
    """Show recent file changes from git."""
    changes = get_git_diff_summary(project_dir)
    content = Text()

    if not changes:
        content.append("No recent changes.", style="dim")
    else:
        status_icons = {"A": ("+", "green"), "M": ("~", "yellow"), "D": ("-", "red")}
        for change in changes[:8]:
            icon, color = status_icons.get(change["status"], ("?", "white"))
            content.append(f"  {icon} ", style=f"bold {color}")
            content.append(f"{change['file']}", style="white")
            if change.get("commit"):
                content.append(f"  ({change['commit']})", style="dim")
            content.append("\n")

    return Panel(content, title="[bold]Recent Changes[/bold]", border_style="magenta", box=box.ROUNDED)


def build_architect(checkpoint: dict) -> Panel:
    """Architect status."""
    content = Text()
    architect_last = checkpoint.get("architect_last_run")
    if architect_last:
        elapsed = int(time.time() - architect_last)
        remaining = max(0, 3600 - elapsed)
        if remaining > 0:
            mins = remaining // 60
            content.append(f"Cooldown: {mins}m remaining\n", style="yellow")
        else:
            content.append("Cooldown: expired — ready\n", style="green")
        content.append(f"Last run: {elapsed // 60}m ago\n", style="dim")
    else:
        content.append("Never run\n", style="dim")

    # Rejection count
    try:
        f = _rejections_file()
        if f.exists():
            data = json.loads(f.read_text())
            reasons = data.get("rejection_reasons", {})
            content.append(f"Rejections: {len(reasons)}\n", style="dim")
    except Exception:
        pass

    # Meta-wishes
    meta_file = _project_state_dir() / "meta_wish_approved.json"
    try:
        if meta_file.exists():
            meta = json.loads(meta_file.read_text())
            content.append(f"Meta-wishes: {len(meta)}\n", style="dim")
    except Exception:
        pass

    return Panel(content, title="[bold]Architect[/bold]", border_style="blue", box=box.ROUNDED)


def build_footer() -> Panel:
    """Footer with keyboard shortcuts."""
    footer = Text()
    footer.append("  [q]uit  [p]ause  [r]esume  [s]tatus  ", style="dim")
    footer.append("│  ", style="dim")
    footer.append("Ctrl+C to exit", style="dim")
    return Panel(footer, border_style="dim")


def build_dashboard() -> Layout:
    """Build the full dashboard layout."""
    layout = Layout()

    checkpoint = read_checkpoint()
    metrics = read_metrics()
    log_lines = read_last_log_lines(30)
    stage = detect_pipeline_stage(log_lines)
    config = _project_config()
    project_dir = config.get("project_dir", "")

    layout.split(
        Layout(name="banner", size=4),
        Layout(name="body"),
        Layout(name="footer", size=3),
    )

    layout["banner"].update(build_project_banner())

    layout["body"].split_row(
        Layout(name="left", ratio=2),
        Layout(name="right", ratio=1),
    )

    layout["left"].split(
        Layout(name="pipeline", size=5),
        Layout(name="wish", size=10),
        Layout(name="debate"),
    )

    layout["right"].split(
        Layout(name="stats"),
        Layout(name="git"),
        Layout(name="architect"),
    )

    layout["pipeline"].update(build_pipeline(stage))
    layout["wish"].update(build_wish_panel(stage))
    layout["debate"].update(build_debate_transcript())
    layout["stats"].update(build_win_rate_chart(metrics))
    layout["git"].update(build_git_diff(project_dir))
    layout["architect"].update(build_architect(checkpoint))
    layout["footer"].update(build_footer())

    return layout


def run_dashboard(refresh_rate: float = 3.0):
    """Run the live dashboard."""
    console.clear()
    try:
        with Live(
            build_dashboard(),
            console=console,
            refresh_per_second=1 / refresh_rate,
            screen=True,
        ) as live:
            while True:
                time.sleep(refresh_rate)
                live.update(build_dashboard())
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard closed.[/dim]")


if __name__ == "__main__":
    run_dashboard()
