#!/usr/bin/env python3
"""
MCP-Brain Self-Improvement Loop v3.2 - Wish-Driven Adversarial Debate
======================================================================
Autonomous loop via HTTP API. Replaces regex pattern hunting with
a 6-agent debate system. Each wish goes through:
  Proposer -> Critic -> Defender -> Synthesizer -> Judge -> Auditor -> Implementer

Usage:
    python3 mcp_self_improve.py --watch          # run wishes from wishes.txt
    python3 mcp_self_improve.py --wish "Add X"   # single wish
    python3 mcp_self_improve.py --resume        # resume from checkpoint
    python3 mcp_self_improve.py --dry-run       # full pipeline, no writes
    python3 mcp_self_improve.py --meta-scout    # experimental meta-wish mode
    python3 mcp_self_improve.py --status         # show checkpoint
    python3 mcp_self_improve.py --architect      # run Architect-Scout

Modules:
    checkpoint.py   - Config, logging, checkpoint, PID, metrics, validation
    api_clients.py  - LLM API wrappers (MiniMax, mimo, DeepSeek R1)
    prompts.py      - System prompts for all agents
    agents.py       - Agent definitions (Proposer, Critic, etc.)
    scout.py        - Scout and Architect-Scout logic
    pipeline.py     - Pipeline orchestration (process_wish, run_loop)
"""

import os, sys, time, signal

# Load env from ~/.hermes/.env
_env_file = os.path.expanduser("~/.hermes/.env")
if os.path.exists(_env_file):
    for line in open(_env_file):
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

# Ensure sibling modules are importable when running as script
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

from pathlib import Path
from checkpoint import (
    log, PAUSE_FILE, PID_FILE,
    acquire_pid_file, release_pid_file, DRY_RUN,
)
from pipeline import process_wish, run_loop, load_wishes
from scout import scout_generate_wish, architect_scout_generate_wish


def show_status():
    """Display current checkpoint status."""
    from checkpoint import load_checkpoint, CHECKPOINT_FILE
    import json
    if not CHECKPOINT_FILE.exists():
        print("No checkpoint found.")
        return
    cp = json.loads(CHECKPOINT_FILE.read_text())
    print(f"Checkpoint: {CHECKPOINT_FILE}")
    print(f"  Iterations: {cp.get('iterations', 0)}")
    print(f"  Wish index: {cp.get('wish_index', 0)}")
    print(f"  Applied patches: {len(cp.get('applied_patches', []))}")
    for p in cp.get('applied_patches', [])[-5:]:
        print(f"    - {p}")
    print(f"  Debate round: {cp.get('debate_round', 0)}")
    print(f"  Done: {cp.get('done', False)}")


if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_: (print("\nInterrupted."), sys.exit(0)))

    if "--status" in sys.argv:
        show_status()
        sys.exit(0)

    resume = "--resume" in sys.argv
    watch = "--watch" in sys.argv
    meta_scout = "--meta-scout" in sys.argv
    DRY_RUN = "--dry-run" in sys.argv
    if DRY_RUN:
        log("[DRY-RUN] Mode enabled - no file writes, no restart")

    # Meta-Scout mode
    if meta_scout:
        from checkpoint import MCP_SOURCE_DIR, load_checkpoint, save_checkpoint
        log("Running Meta-Scout mode...")
        wish = scout_generate_wish()
        if wish:
            log(f"Meta-wish generated: {wish}")
            made_progress, _, _ = process_wish(wish, 0, 0)
        else:
            log("Meta-Scout failed to generate a wish")
        sys.exit(0)

    # Architect-Scout mode
    if "--architect" in sys.argv:
        from checkpoint import load_checkpoint, save_checkpoint, ARCHITECT_COOLDOWN
        cp = load_checkpoint()
        last_run = cp.get("architect_last_run")
        now = time.time()
        if last_run and (now - last_run) < ARCHITECT_COOLDOWN:
            elapsed = int(now - last_run)
            remaining = ARCHITECT_COOLDOWN - elapsed
            hrs = remaining // 3600
            mins = (remaining % 3600) // 60
            log(f"[Architect-Scout] Cooldown active ({elapsed}s elapsed, ~{hrs}h {mins}m remaining). Exiting.")
            sys.exit(0)
        log("[Architect-Scout] Running architectural analysis...")
        wish = architect_scout_generate_wish()
        if wish:
            log(f"[Architect-Scout] Wish generated: {wish}")
            made_progress, _, _ = process_wish(wish, 0, 0)
        else:
            log("[Architect-Scout] No wish generated - system may not need new capabilities right now")
        cp = load_checkpoint()
        cp["architect_last_run"] = now
        save_checkpoint(cp)
        sys.exit(0)

    # Single wish mode
    single_wish = None
    for a in sys.argv[1:]:
        if not a.startswith("--"):
            single_wish = a
            break

    if single_wish:
        log(f"Processing single wish: {single_wish}")
        process_wish(single_wish, 0, 0)
    elif watch:
        if not acquire_pid_file():
            sys.exit(1)
        import atexit
        atexit.register(release_pid_file)
        signal.signal(signal.SIGTERM, lambda *_: (release_pid_file(), sys.exit(0)))
        from checkpoint import WATCH_INTERVAL
        log("[WATCH] Entering autonomous self-improvement loop...")
        while True:
            # Pause mechanism
            if PAUSE_FILE.exists():
                log(f"[PAUSE] Paused (remove {PAUSE_FILE} to resume)")
                while PAUSE_FILE.exists():
                    time.sleep(30)
                log("[PAUSE] Resumed")
            run_loop(watch=True, resume=resume)
            log(f"[WATCH] Cycle complete. Restarting in {WATCH_INTERVAL}s...")
            time.sleep(WATCH_INTERVAL)
    else:
        run_loop(watch=False, resume=resume)
