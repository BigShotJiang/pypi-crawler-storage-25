import random
"""Scout and Architect-Scout: proactive improvement hunting."""

import os, json, time, subprocess, re
from collections import deque
from pathlib import Path
from checkpoint import (
    log, MCP_SOURCE_DIR, ARCHITECT_COOLDOWN,
    load_checkpoint, save_checkpoint, load_rejection_reasons,
    is_duplicate_wish, record_wish, META_WISHES_FILE, WISHES_FILE,
)
from api_clients import call_mimo
from prompts import SCOUT_SYSTEM, SCOUT_ARCHITECT_SYSTEM

SCOUT_HISTORY = deque(maxlen=15)

def scout_generate_wish() -> str:
    """
    Proactively hunts for code improvements when the daemon is idle.
    Returns a single-sentence wish, or "" if it fails/nothing found.
    Scoped strictly to ~/mcp-work/src/noesis/ to avoid random disk scanning.

    Uses DeepSeek R1 via Straico — fast, cheap, strong code analysis.
    """
    app_dir = Path.home() / "mcp-work" / "src" / "noesis"

    if not app_dir.exists():
        log(f"[Scout] Directory not found: {app_dir}")
        return ""

    all_py_files = list(app_dir.rglob("*.py"))
    available_files = [f for f in all_py_files if str(f) not in SCOUT_HISTORY]

    if not available_files:
        SCOUT_HISTORY.clear()
        available_files = all_py_files

    if not available_files:
        return ""

    target_file = random.choice(available_files)
    SCOUT_HISTORY.append(str(target_file))

    log(f"  [Scout] Idle... Analyzing {target_file.name}...")

    # Truncate to 400 lines for speed — Scout just needs a taste
    file_lines = target_file.read_text(errors="ignore").splitlines()
    file_content = "\n".join(file_lines[:400])
    if len(file_lines) > 400:
        file_content += f"\n# ... ({len(file_lines) - 400} more lines)"

    task = (
        f"FILE: {target_file.name}\n\n"
        f"Read this Python file. Find exactly ONE concrete improvement: "
        f"a bug fix, security patch, optimization, or readability refactor. "
        f"Respond ONLY with a single actionable sentence starting with a verb "
        f"(e.g. 'Refactor the data parser to handle edge cases.'). "
        f"Do NOT output markdown or explanations.\n\n{file_content}"
    )

    try:
        response = call_mimo(task, system=SCOUT_SYSTEM, max_tokens=1024)

        wish = response.strip().replace("\n", " ").strip('"\'')
        # Remove [SCOUT: ...] prefix if R1 echoed it back
        wish = re.sub(r'^\[SCOUT:\s*\S+\.py\]\s*', '', wish)
        # R1 reasoning leak: sentence fragments, too long, starts with thinking words
        reasoning_leak_phrases = [
            "looking for", "so maybe", "it shows", "the key is",
            "the code uses", "if that failed", "maybe that's",
            "## ", "**", "---", "for example",
            "okay ", "let me", "i think", "i need to", "first ",
            # API error text — these appear in source when error messages are hardcoded
            "error:", "'error'", '"error"', "token is not valid",
            "empty choices", "success: false", "success': false",
        ]
        is_reasoning_leak = (
            any(p in wish.lower() for p in reasoning_leak_phrases)
            or len(wish) > 250  # real actionable sentences are concise
            or wish.count('.') > 5  # multiple sentences = reasoning chain
            or wish.startswith("o. ")  # R1 enumeration artifact
        )
        if wish and 10 < len(wish) <= 250 and not is_reasoning_leak:
            # Duplicate detection — skip if recently proposed
            if is_duplicate_wish(wish):
                log(f"  [Scout] Skipping duplicate wish: {wish[:60]}...")
                return ""
            record_wish(wish, "proposed")
            return f"[SCOUT: {target_file.name}] {wish}"

    except Exception as e:
        log(f"  [Scout] Error generating wish: {e}")


def _find_git_root(start: Path) -> Path:
    """Walk up from start until we find a .git directory."""
    cur = start.resolve()
    for _ in range(10):
        if (cur / ".git").exists():
            return cur
        parent = cur.parent
        if parent == cur:
            break
        cur = parent
    return start  # fallback

def git_log_summary(limit: int = 60) -> str:
    """Get git log summary: commits per file (churn) + repeated patterns."""
    repo_root = _find_git_root(MCP_SOURCE_DIR)
    if not (repo_root / ".git").exists():
        return "[git: repo root not found]"
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_root), "log", "--oneline", f"-n{limit}"],
            capture_output=True, text=True, timeout=10
        )
        commits = r.stdout.strip().splitlines()
    except Exception as e:
        return f"[git log error: {e}]"

    # Count how many times each file was touched
    from collections import Counter
    file_hits: Counter[str] = Counter()
    repeated_wishes: list[str] = []
    seen_wish_roots: dict[str, int] = {}

    for line in commits:
        # Extract filename from commit messages like "Auto-backup before implementing wish: [SCOUT: filename.py] Wish text"
        if "Auto-backup before implementing wish:" in line:
            match = re.search(r'\[SCOUT:\s*(\S+\.py)\]', line)
            if match:
                fn = match.group(1)
                file_hits[fn] += 1
                # Track repeated wish patterns (same file touched many times)
                root = fn.replace(".py", "")
                seen_wish_roots[root] = seen_wish_roots.get(root, 0) + 1
                if seen_wish_roots[root] == 3:
                    repeated_wishes.append(f"{fn} (touched 3+ times — possible pattern problem)")

    churn_lines = [f"  {count}x {fn}" for fn, count in file_hits.most_common(10)]
    churn_block = "\n".join(churn_lines) if churn_lines else "  (no commit history)"
    repeat_block = "\n".join(f"  ⚠ {r}" for r in repeated_wishes) if repeated_wishes else "  (no repeat patterns detected)"

    return f"""Git churn (last {limit} commits):
{churn_block}

Repeat-pattern warnings:
{repeat_block}"""


def architect_scout_generate_wish() -> str:
    """
    Real meta-scout: analyzes git history + file structure to find capability gaps.
    NOT a code defect scanner — asks "what should this system DO that it doesn't?"
    Run manually via: python3 mcp_self_improve.py --architect
    """
    log(f"[Architect-Scout] Analyzing system for capability gaps...")
    app_dir = MCP_SOURCE_DIR

    # 1. Git churn analysis
    git_summary = git_log_summary(limit=60)

    # 2. File structure map (what modules exist, what doesn't)
    existing_files = []
    for fp in sorted(app_dir.glob("*.py")):
        lines = fp.read_text(errors="ignore").splitlines()
        existing_files.append(f"  {fp.name} ({len(lines)} lines)")

    file_inventory = "\n".join(existing_files) if existing_files else "  (no files found)"

    # Load rejection history so Architect avoids repeated failures
    rejections = load_rejection_reasons()
    if rejections:
        reason_lines = []
        for wish_key, data in list(rejections.items())[-5:]:  # last 5
            reason_lines.append(f"  - Wish: {wish_key[:80]}")
            reason_lines.append(f"    Rejected because: {data['reason'][:200]}")
        rejection_block = "\n".join(reason_lines)
    else:
        rejection_block = "  (no prior rejections)"

    log(f"[Architect-Scout] Loaded {len(rejections)} prior rejections")

    # 3. Ask what capability is missing
    task = (
        "You are an elite Staff Engineer doing architectural analysis. "
        "You are NOT looking for bugs or code defects. "
        "You are asking: 'What should this system BE ABLE TO DO that it currently cannot?'\n\n"
        "Look at the git history (which shows recent activity patterns), "
        "the file inventory (which shows what exists), and "
        "the prior rejections (which show what was tried and failed). "
        "Identify ONE new capability this system is missing that would be high-value.\n\n"
        "IMPORTANT: Avoid wishes similar to any previously rejected ones. "
        "If a prior wish was rejected, the new wish must be genuinely different in approach.\n\n"
        "Examples of good NEW capability wishes:\n"
        "- 'Add a Prometheus metrics endpoint to expose token usage and API latency'\n"
        "- 'Add a config file system so API keys are read from a config.yaml instead of environment variables'\n"
        "- 'Add a webhook system to notify external services when a wish is applied'\n"
        "- 'Add a health check endpoint that verifies API credentials are valid'\n\n"
        "Output exactly ONE sentence starting with a verb. No code, no markdown, no lists.\n\n"
        f"=== GIT HISTORY (recent activity patterns) ===\n{git_summary}\n\n"
        f"=== FILE INVENTORY (what currently exists) ===\n{file_inventory}\n\n"
        f"=== PRIOR REJECTIONS (learn from past failures) ===\n{rejection_block}\n\n"
        "What ONE new capability should this system have?"
    )

    try:
        response = call_mimo(task, system=SCOUT_ARCHITECT_SYSTEM, max_tokens=2048)

        # Handle thinking dumps: response is <think>\nTHINKING\n</think>\nANSWER\n</think>
        # The answer we want is between the last </think> and final </think>
        stripped = response.strip()
        if stripped.startswith("<think>") or "<think>" in stripped:
            chunks = stripped.split("</think>")
            if len(chunks) >= 2:
                extracted = chunks[-2].strip()
                log(f"  [Architect-Scout] Extracted from thinking: {extracted[:80]}")
                stripped = extracted
            else:
                log(f"  [Architect-Scout] Rejected: thinking dump with no answer")
                return ""

        wish = stripped.replace("\n", " ").strip('"\'')

        # Validate wish
        if not wish or len(wish) < 15 or len(wish) > 300:
            log(f"  [Architect-Scout] Rejected: wish length out of range ({len(wish)})")
            return ""
        if wish[0].islower() or wish[0] in "'\"" or wish[0] in "oqu":
            log(f"  [Architect-Scout] Rejected: wish starts with '{wish[0]}'")
            return ""

        if not any(p in wish.lower() for p in [
            "looking for", "so maybe", "it shows", "the key is",
            "the code uses", "if that failed", "maybe that's",
            "## ", "**", "---", "for example",
            "okay ", "let me", "i think", "i need to", "first ",
            "i'd suggest", "i would suggest", "perhaps",
            "here's", "here is", "certainly",
            "the goal", "my goal",
        ]):
            if is_duplicate_wish(wish):
                log(f"  [Architect] Skipping duplicate wish: {wish[:60]}...")
                return ""
            record_wish(wish, "proposed")
            return f"[META] {wish}"

        log(f"  [Architect-Scout] Wish rejected as reasoning leak: '{wish[:80]}'")
    except Exception as e:
        log(f"  [Architect-Scout] Error: {e}")
    return ""


# Alias for backward compatibility with --meta-scout flag
meta_scout_generate_wish = architect_scout_generate_wish


# ── Meta-wish to concrete wish conversion ──────────────────────────────────
def convert_meta_wishes() -> list[str]:
    """Convert approved meta-wishes into concrete code wishes.

    Reads meta_wish_approved.json, finds unconverted entries,
    asks mimo to generate specific code wishes from each proposal,
    and appends them to wishes.txt.

    Returns list of generated concrete wishes.
    """
    if not META_WISHES_FILE.exists():
        return []

    try:
        approved = json.loads(META_WISHES_FILE.read_text())
    except Exception:
        return []

    # Find unconverted meta-wishes
    unconverted = [w for w in approved if not w.get("converted")]
    if not unconverted:
        return []

    generated = []
    for entry in unconverted:
        wish = entry.get("wish", "")
        proposal = entry.get("proposal", "")

        # Skip if proposal is too short or empty
        if len(proposal) < 50:
            entry["converted"] = True
            continue

        log(f"  [Convert] Converting meta-wish: {wish[:60]}...")

        # Ask mimo to generate concrete code wishes
        task = f"""You have an approved architectural proposal. Convert it into 1-3 CONCRETE, 
ACTIONABLE code wishes that can be implemented in specific files.

ARCHITECTURAL PROPOSAL:
{proposal[:2000]}

RULES:
- Each wish must target a SPECIFIC file (e.g., "Add X to bot.py")
- Each wish must be a single actionable sentence starting with a verb
- Each wish must be under 200 characters
- Output ONLY the wishes, one per line, no numbering, no explanation
- If the proposal is too vague to convert, output: SKIP

EXAMPLE OUTPUT:
Add a SQLite connection manager class to database.py
Create a trade_history table schema in models.py
Add query methods for recent trades to database.py"""

        try:
            response = call_mimo(task, max_tokens=500)
        except Exception as e:
            log(f"  [Convert] Error: {e}")
            continue

        # Parse wishes from response — filter errors
        wishes = []
        error_indicators = ["error", "invalid", "failed", "traceback", "exception"]
        for line in response.strip().split("\n"):
            line = line.strip()
            if not line or line.upper() == "SKIP":
                continue
            # Skip error responses
            if any(ind in line.lower() for ind in error_indicators):
                continue
            # Clean up numbering, bullets, etc.
            import re as _re
            line = _re.sub(r'^\d+[\.\)]\s*', '', line)
            line = _re.sub(r'^[-*]\s*', '', line)
            if 10 < len(line) < 200:
                wishes.append(line)

        if wishes:
            # Append to wishes file
            wishes_path = WISHES_FILE
            existing = ""
            if wishes_path.exists():
                existing = wishes_path.read_text()
            new_wishes = "\n".join(wishes) + "\n"
            wishes_path.parent.mkdir(parents=True, exist_ok=True)
            with open(wishes_path, "a") as f:
                f.write(new_wishes)
            log(f"  [Convert] Generated {len(wishes)} concrete wishes")
            for w in wishes:
                log(f"    → {w[:70]}")
            generated.extend(wishes)
        else:
            log(f"  [Convert] No actionable wishes generated")

        # Mark as converted
        entry["converted"] = True

    # Save updated meta_wish_approved.json
    META_WISHES_FILE.write_text(json.dumps(approved, indent=2))
    return generated


# ── Architect-Scout auto-trigger ────────────────────────────────────────────────
def _try_architect_scout() -> str | None:
    """Fire Architect-Scout if cooldown has expired.

    Called from run_loop when wish queue is empty. Updates architect_last_run
    in checkpoint on successful execution. Architect fires at most once per
    ARCHITECT_COOLDOWN (1h).

    Returns a wish string if Architect generated one, else None.
    """
    cp = load_checkpoint()
    last_run = cp.get("architect_last_run", 0)
    now = time.time()

    if last_run and (now - last_run) < ARCHITECT_COOLDOWN:
        elapsed = int(now - last_run)
        remaining = ARCHITECT_COOLDOWN - elapsed
        log(f"[Architect] Cooldown active ({elapsed}s elapsed, ~{remaining // 60}m remaining).")
        return None

    log("[Architect] Cooldown expired — running architectural analysis...")
    try:
        wish = architect_scout_generate_wish()
    except Exception as e:
        log(f"[Architect] Error: {e}")
        return None

    if wish:
        log(f"[Architect] Wish generated: {wish}")
        # Record successful run
        cp = load_checkpoint()
        cp["architect_last_run"] = now
        save_checkpoint(cp)
        return wish

    # Record the attempt even if no wish was produced (prevents hammering)
    cp = load_checkpoint()
    cp["architect_last_run"] = now
    save_checkpoint(cp)
    log("[Architect] No wish generated.")
    return None




__all__ = [
    'scout_generate_wish', 'architect_scout_generate_wish',
    '_try_architect_scout',
]
