import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs


class CORSRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler with CORS middleware support."""

    # CORS configuration
    CORS_ORIGINS = ['*']
    CORS_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
    CORS_HEADERS = ['Content-Type', 'Authorization', 'X-Requested-With']

    def send_cors_headers(self):
        """Send CORS headers for cross-origin requests."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', ', '.join(self.CORS_METHODS))
        self.send_header('Access-Control-Allow-Headers', ', '.join(self.CORS_HEADERS))
        self.send_header('Access-Control-Max-Age', '86400')

    def options_preflight(self):
        """Handle OPTIONS preflight requests for CORS."""
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()
        return True

    def dispatch(self, method):
        """Dispatch request to appropriate handler method."""
        # Handle OPTIONS preflight
        if self.command == 'OPTIONS':
            return self.options_preflight()

        # Dispatch to registered handlers
        handler_name = f'do_{method.upper()}'
        if hasattr(self, handler_name):
            handler = getattr(self, handler_name)
            return handler()
        else:
            self.send_error(405, 'Method Not Allowed')
            return True

    def do_GET(self):
        """Handle GET requests."""
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        
        response = {
            'status': 'ok',
            'path': parsed.path,
            'params': params
        }
        self.wfile.write(json.dumps(response).encode())

    def do_POST(self):
        """Handle POST requests."""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        
        response = {
            'status': 'ok',
            'method': 'POST',
            'body': body
        }
        self.wfile.write(json.dumps(response).encode())

    def do_PUT(self):
        """Handle PUT requests."""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        
        response = {
            'status': 'ok',
            'method': 'PUT',
            'body': body
        }
        self.wfile.write(json.dumps(response).encode())

    def do_DELETE(self):
        """Handle DELETE requests."""
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        
        response = {
            'status': 'ok',
            'method': 'DELETE'
        }
        self.wfile.write(json.dumps(response).encode())

    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS preflight."""
        self.options_preflight()

    def log_message(self, format, *args):
        """Log HTTP requests."""
        print(f"[HTTP] {args[0]}")


def run_server(host='localhost', port=8080):
    """Start the HTTP server."""
    server = HTTPServer((host, port), CORSRequestHandler)
    print(f"Server running on http://{host}:{port}")
    print("Press Ctrl+C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped")
        server.server_close()


if __name__ == '__main__':
    run_server()
