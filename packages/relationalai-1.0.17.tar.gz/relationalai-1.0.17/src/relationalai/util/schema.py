from collections import defaultdict
import json
import textwrap

from relationalai.util.error import source, warn, SourcePos
from relationalai.util.fs import get_build_dir
from relationalai.util.identifiers import IdentityParser, normalize_qualified_name, quote_identifier_if_needed, split_qualified_name, unquote_identifier

#------------------------------------------------------
# General
#------------------------------------------------------

CACHE_PATH = get_build_dir() / "cache" / "schemas.json"
CACHE = {}

# One ``SHOW COLUMNS IN SCHEMA`` is cheaper than N per-table scans once N
# crosses this threshold (the schema scan is O(schema size) regardless of how
# many tables we filter to, whereas per-table scans are O(table size) × N).
# Below the threshold we stick to the per-table fast path.
BATCH_PRELOAD_THRESHOLD = 4

def _convert_types(result: dict[str, type | str]) -> dict[str, str]:
    """Convert Python types to string representations for the cache."""
    type_map = {str: "String", int: "Int64", float: "Float", bool: "Bool", bytes: "Binary"}
    return {
        col: type_map.get(t, "String") if isinstance(t, type) else t
        for col, t in result.items()
    }

def fetch(fqn: str, model=None) -> tuple[bool, dict[str, str]]:
    """
    Fetch column metadata for a fully-qualified table name.

    Args:
        fqn: Fully-qualified table name (database.schema.table)
        model: Optional Model instance. Uses the model's executor for schema
               fetching when in install_mode, otherwise falls back to Snowflake.
    """
    global CACHE
    fqn = normalize_qualified_name(fqn)
    parts = split_qualified_name(fqn)
    if len(parts) != 3:
        raise ValueError(f"Expected a fully-qualified table name with 3 parts, got: {fqn!r}")
    database, schema, table = parts
    table_name = unquote_identifier(table)

    # Load or initialize cache
    if not CACHE and CACHE_PATH.exists():
        with CACHE_PATH.open("r", encoding="utf-8") as f:
            CACHE = json.load(f)

    # If already cached, return it
    if fqn in CACHE:
        return True, CACHE[fqn]

    config = model.config if model else None

    # In install_mode, use the model's Executor (supports DuckDB and Snowflake)
    if model is not None:
        from ..semantics.backends.executor import ModelManagerExecutor
        from ..semantics.backends.multi_reasoner_executor import MultiReasonerExecutor
        from ..semantics.backends.sql_executor import SQLExecutor
        executor = model._get_executor()
        if isinstance(executor, ModelManagerExecutor):
            executor = executor.inner_executor
        if isinstance(executor, MultiReasonerExecutor):
            executor = executor._sql_executor
        if isinstance(executor, SQLExecutor):
            result = executor._sql_backend.fetch_schema(database, schema, table_name)
            if result:
                CACHE[fqn] = _convert_types(result)
                _save_cache()
                return False, CACHE[fqn]

        # On the Snowflake path, if the model has enough uncached sibling tables
        # in the same schema, fetch them all at once instead of running the
        # per-table query N times. Populates CACHE as a side effect.
        _preload_schema_batch(model, database, schema, config=config)
        if fqn in CACHE:
            # Fetched from Snowflake during this call, not a real cache hit:
            # return False so callers logging "Cache Hit/Miss" report a miss.
            return False, CACHE[fqn]

    # Per-table Snowflake fast path. Used when there aren't enough siblings
    # to justify a schema-wide batch (or when no model is supplied).
    columns = fetch_snowflake_table(database, schema, table, config=config)
    if not columns:
        return False, {}

    CACHE[fqn] = columns
    _save_cache()

    return False, CACHE[fqn]


def _save_cache():
    """Save the cache to disk."""
    global CACHE
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with CACHE_PATH.open("w", encoding="utf-8") as f:
            json.dump(CACHE, f, indent=2)
    except OSError as e:
        if e.errno == 30:  # 30 = EROFS: read-only file system (e.g. Snowflake container)
            return  # silently use in-memory cache
        try:
            warn("Schema Cache",
                 f"Could not persist schema cache to {CACHE_PATH}. Using in-memory cache",
                 [source(SourcePos.new()), f"[red]{e}"]
            )
        except Exception:
            pass  # prevent warning machinery failures from escaping _save_cache

#------------------------------------------------------
# Snowflake
#------------------------------------------------------

SUPPORTED_SNOWFLAKE_TYPES = [
    'CHAR', 'STRING', 'VARCHAR', 'BINARY', 'NUMBER', 'FLOAT', 'REAL',
    'BOOLEAN', 'DATE', 'FIXED', 'TEXT', 'TIME', 'TIMESTAMP_LTZ',
    'TIMESTAMP_NTZ', 'TIMESTAMP_TZ'
]

SFTypes = {
    "TEXT": "String",
    "FIXED": "Decimal",
    "DATE": "Date",
    "TIME": "DateTime",
    "TIMESTAMP": "DateTime",
    "TIMESTAMP_LTZ": "DateTime",
    "TIMESTAMP_TZ": "DateTime",
    "TIMESTAMP_NTZ": "DateTime",
    "FLOAT": "Float",
    "REAL": "Float",
    "BOOLEAN": "Bool",
}

def quoted(ident: str) -> str:
    return quote_identifier_if_needed(ident)

def get_provider(config=None):
    from ..shims.executor import get_provider as _get_provider
    return _get_provider(config)

def _parse_snowflake_columns(
    database: str,
    schema: str,
    table_name: str,
    rows: list,
) -> dict[str, str]:
    """Parse rows returned by SHOW COLUMNS for a single table.

    Returns a ``{column_name: concept_type}`` dict. Columns whose Snowflake type is
    not in :data:`SUPPORTED_SNOWFLAKE_TYPES` are collected and a single warning is
    emitted per table rather than per column.
    """
    resolved: dict[str, str] = {}
    unsupported: dict[str, str] = {}

    for row in rows:
        _, column_name, data_type = row
        sf_type_info = json.loads(data_type)
        typ = sf_type_info.get("type")

        if typ not in SUPPORTED_SNOWFLAKE_TYPES:
            unsupported[column_name] = typ
            continue

        if typ == "FIXED":
            resolved[column_name] = sf_numeric_to_type_str(column_name, sf_type_info)
        else:
            resolved[column_name] = SFTypes[typ]

    if unsupported:
        col_str = ", ".join(f"{col}({typ})" for col, typ in unsupported.items())
        warn("Unsupported Column",
            f"The following columns in '{database}.{schema}.{table_name}' have unsupported types: {col_str}",
            [
                "These columns will not be accessible in your model.",
                "For the list of supported column types see: https://docs.relational.ai/api/cli/imports/stream/#supported-column-types"
            ])

    return resolved


def fetch_snowflake_table(database: str, schema: str, table_identifier: str, config=None) -> dict[str, str]:
    """Fetch column metadata for a single table via ``SHOW COLUMNS IN TABLE``.

    ``SHOW COLUMNS IN SCHEMA`` scans every table's metadata in the schema, which is
    O(schema size) per call and dominates cold-start time on large schemas. Using
    ``SHOW COLUMNS IN TABLE`` keeps each fetch O(table size) instead, so N per-table
    fetches scale linearly with the number of requested tables rather than with the
    total schema size.
    """
    fq_table = f"{quoted(database)}.{quoted(schema)}.{quoted(table_identifier)}"
    query = textwrap.dedent(f"""
        begin
            SHOW COLUMNS IN TABLE {fq_table};
            let r resultset := (
                select "table_name", "column_name", "data_type"
                from table(result_scan(-1)) as t
            );
            return table(r);
        end;
    """)

    # Allow exceptions to propagate; caller handles "Unknown Table".
    rows = get_provider(config).sql(query)
    assert isinstance(rows, list)

    return _parse_snowflake_columns(database, schema, unquote_identifier(table_identifier), rows)


def _snowflake_stored_name(table_identifier: str) -> str:
    """Return the string Snowflake stores in ``"table_name"`` for an identifier.

    Snowflake preserves quoted identifiers verbatim (minus the surrounding
    double quotes) and uppercases unquoted ones. Mirroring this lets us build
    an ``IN (...)`` filter whose literals actually match.

    Identifiers in this module are often passed around without surrounding
    quotes even when they contain characters that require quoting (e.g.
    ``t#st!-TAble`` or ``O'Neil`` — ``split_qualified_name`` strips quotes).
    Only uppercase tokens that are valid unquoted Snowflake IDs; otherwise
    return the token verbatim so the IN-list literal matches what Snowflake
    actually stores.
    """
    token = table_identifier.strip()
    if len(token) >= 2 and token.startswith('"') and token.endswith('"'):
        return unquote_identifier(token)
    if IdentityParser.SF_ID_REGEX.fullmatch(token):
        return token.upper()
    return token


def fetch_snowflake_batch(
    database: str,
    schema: str,
    table_identifiers: list[str],
    config=None,
) -> dict[str, dict[str, str]]:
    """Fetch column metadata for many tables in one ``SHOW COLUMNS IN SCHEMA`` call.

    A single schema-wide scan is cheaper than N per-table scans when N is
    large enough: :func:`fetch` routes through this path when
    :data:`BATCH_PRELOAD_THRESHOLD` or more siblings are uncached in the same
    schema.

    Returns a dict keyed by the caller's original ``table_identifier`` spelling,
    mapping to ``{column_name: concept_type}``. Tables with no supported columns
    (or absent from the schema) are omitted from the returned dict.
    """
    if not table_identifiers:
        return {}

    stored_to_identifier: dict[str, str] = {
        _snowflake_stored_name(t): t for t in table_identifiers
    }
    literals = ", ".join(
        IdentityParser.to_sql_value(stored_name) for stored_name in stored_to_identifier
    )
    query = textwrap.dedent(f"""
        begin
            SHOW COLUMNS IN SCHEMA {quoted(database)}.{quoted(schema)};
            let r resultset := (
                select "table_name", "column_name", "data_type"
                from table(result_scan(-1)) as t
                where "table_name" in ({literals})
            );
            return table(r);
        end;
    """)

    rows = get_provider(config).sql(query)
    assert isinstance(rows, list)

    rows_by_table: dict[str, list] = defaultdict(list)
    for row in rows:
        rows_by_table[row[0]].append(row)

    result: dict[str, dict[str, str]] = {}
    for stored_name, table_rows in rows_by_table.items():
        caller_identifier = stored_to_identifier.get(stored_name)
        if caller_identifier is None:
            continue
        classified = _parse_snowflake_columns(
            database, schema, unquote_identifier(caller_identifier), table_rows
        )
        if classified:
            result[caller_identifier] = classified
    return result


def _preload_schema_batch(model, database: str, schema: str, config=None) -> None:
    """Populate CACHE for uncached siblings of the requested table in one call.

    Walks ``model.tables``, keeps only tables that share ``(database, schema)``,
    aren't already cached, aren't export destinations, and have no explicit
    ``schema=`` yet. If enough such siblings exist, fetches them all in a
    single :func:`fetch_snowflake_batch` call. Below the threshold, returns
    without touching the cache so the per-table path can handle the miss.

    Best-effort: any exception from the batch call is swallowed so the caller
    can still fall back to the per-table path.
    """
    siblings: list[tuple[str, str]] = []  # (fqn, original_identifier)
    for t in getattr(model, "tables", ()):
        if getattr(t, "_is_export_destination", False):
            continue
        if getattr(t, "_known_columns", None):
            continue
        raw_name = getattr(t, "_name", None)
        if not isinstance(raw_name, str):
            continue
        try:
            t_fqn = normalize_qualified_name(raw_name)
            parts = split_qualified_name(t_fqn)
        except Exception:
            continue
        if len(parts) != 3:
            continue
        t_db, t_schema, t_table = parts
        if t_db != database or t_schema != schema:
            continue
        if t_fqn in CACHE:
            continue
        siblings.append((t_fqn, t_table))

    if len(siblings) < BATCH_PRELOAD_THRESHOLD:
        return

    table_identifiers = [ident for _, ident in siblings]
    try:
        batch_result = fetch_snowflake_batch(
            database, schema, table_identifiers, config=config
        )
    except Exception:
        return

    changed = False
    for fqn, ident in siblings:
        columns = batch_result.get(ident)
        if columns:
            CACHE[fqn] = columns
            changed = True

    if changed:
        _save_cache()


def digits_to_bits(precision)-> int:
    """
    Transform from a number of base 10 digits to the number of bits necessary to represent
    that. If the precision is larger than 38, return None as that is not supported.

    For example, a number with 38 digits requires 128 bits.
    """
    if precision <= 2:
        return 8
    elif precision <= 4:
        return 16
    elif precision <= 9:
        return 32
    elif precision <= 18:
        return 64
    elif precision <= 38:
        return 128
    raise ValueError(f"Invalid numeric precision '{precision}'")

def sf_numeric_to_type_str(column_name: str, sf_type_info: dict) -> str:
    """
    Computes the appropriate type to use for this column. This code reflects exactly
    the logic currently used by RAI's CDC implementation to ensure we map to the exact
    same number types.
    """
    if "scale" not in sf_type_info or "precision" not in sf_type_info:
        raise ValueError(
            f"Invalid definition for column '{column_name}': "
            "'scale' or 'precision' missing"
        )

    precision = sf_type_info["precision"]
    scale = sf_type_info["scale"]

    if scale > precision or scale < 0 or scale > 37:
        raise ValueError(
            f"Invalid numeric scale '{scale}' for column '{column_name}'"
        )

    if scale == 0:
        # Integers (load_csv only supports these two (and not 8/16/32 bit ints)
        bits = digits_to_bits(precision)
        # return Int128 if bits == 128 else Int64
        return "Decimal(38,0)" if bits == 128 else "Decimal(18,0)"

    return f"Decimal({precision},{scale})"
