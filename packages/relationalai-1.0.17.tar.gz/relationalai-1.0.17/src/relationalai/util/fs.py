"""
Filesystem utilities for PyRel.

Provides a writable build directory that automatically falls back to /tmp
when the default location is on a read-only filesystem (e.g. Snowflake
container environments).
"""
import contextlib
import logging
import os
import warnings
from functools import lru_cache
from pathlib import Path

from relationalai.config.constants import RAI_BUILD_DIR_ENV_VAR

_FALLBACK_BUILD_DIR = Path("/tmp/rai_build")


@lru_cache(maxsize=1)
def get_build_dir() -> Path:
    """Return a writable build directory.

    Resolution order:
    1. ``RAI_BUILD_DIR`` env var if set.
    2. ``build/`` relative to the working directory.
    3. ``/tmp/rai_build/`` if the above is on a read-only filesystem
       (errno 30 = EROFS, expected in Snowflake container environments).

    The result is cached after the first call.
    """
    configured = Path(os.environ.get(RAI_BUILD_DIR_ENV_VAR, "build"))
    try:
        configured.mkdir(parents=True, exist_ok=True)
        return configured
    except OSError as e:
        if e.errno != 30:  # 30 = EROFS: read-only file system
            raise
    # Read-only filesystem — fall back to /tmp
    try:
        _FALLBACK_BUILD_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass  # best-effort; callers handle individual write failures
    return _FALLBACK_BUILD_DIR


@lru_cache(maxsize=1)
def is_readonly_fs() -> bool:
    """Return True if the working directory is on a read-only filesystem.

    The result is cached after the first call.
    """
    return get_build_dir() == _FALLBACK_BUILD_DIR


@contextlib.contextmanager
def suppress_erofs(operation: str = "filesystem write"):
    """Context manager that silently suppresses EROFS (errno 30) errors and
    emits a warning showing what operation was skipped and why.

    Any other OSError is re-raised unchanged.

    Usage::

        with suppress_erofs("write schema cache"):
            CACHE_PATH.write_text(...)
    """
    try:
        yield
    except OSError as e:
        if e.errno != 30:
            raise
        warnings.warn(
            f"Skipped {operation} — read-only filesystem (EROFS): {e}",
            stacklevel=2,
        )


class _SuppressOnReadOnlyFS(logging.Filter):
    """Logging filter that drops records when the filesystem is read-only.

    Attached to the pyrellogger at startup so all FileHandlers — including
    ones registered later by v0 — are silenced before they can raise EROFS.
    """
    def filter(self, record: logging.LogRecord) -> bool:
        return not is_readonly_fs()


def configure_for_environment() -> None:
    """Detect the runtime environment once at startup and configure PyRel
    to handle read-only filesystems (EROFS) gracefully.

    - Probes the build directory so ``get_build_dir()`` is cached early.
    - On EROFS: emits a single warning and installs ``_SuppressOnReadOnlyFS``
      on the ``pyrellogger`` logger so that any FileHandler — including ones
      registered later by v0 — never attempts a disk write.

    Called automatically from ``relationalai/__init__.py``.
    """
    if not is_readonly_fs():
        return

    warnings.warn(
        f"Read-only filesystem detected (EROFS) — file logging suppressed, "
        f"build directory redirected to {get_build_dir()}."
    )

    logger = logging.getLogger("pyrellogger")
    # Guard against duplicate filters if called more than once.
    if not any(isinstance(f, _SuppressOnReadOnlyFS) for f in logger.filters):
        logger.addFilter(_SuppressOnReadOnlyFS())
