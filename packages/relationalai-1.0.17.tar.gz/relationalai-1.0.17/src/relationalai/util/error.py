from dataclasses import dataclass
from io import StringIO
from typing import Any, NoReturn, Optional
import html
import os

from .source import SourcePos

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table as RichTable
from rich.text import Text

#------------------------------------------------------
# Parts
#------------------------------------------------------

@dataclass
class Source:
    pos: SourcePos
    orig_line: int

    def __init__(self, pos: SourcePos):
        self.orig_line = pos.line or 0
        self.pos = pos.block


@dataclass
class Table:
    headers: list[str]
    rows: list[list[str]]

Part = str|Source|Table

#------------------------------------------------------
# Diagnostic
#------------------------------------------------------

class Diagnostic():
    def __init__(self, name: str, message:str, parts: list[Part] = [], severity: str = "error"):
        self.name = name
        self.message = message
        self.parts = parts
        self.severity = severity  # "error", "warning", "info"

    def to_dict(self) -> dict:
        parts_json: list[dict] = []
        for p in self.parts:
            if isinstance(p, str):
                parts_json.append({"kind": "text", "text": p})
            elif isinstance(p, Source):
                parts_json.append({"kind": "source", "file": p.pos.file, "line": p.pos.line, "source": p.pos.source, "orig_line": p.orig_line})
            elif isinstance(p, Table):
                parts_json.append({"kind": "table", "headers": p.headers, "rows": p.rows})
        return {"name": self.name, "message": self.message, "severity": self.severity, "parts": parts_json}


def _is_notebook_generated_path(path: str) -> bool:
    basename = os.path.basename(path)
    return (
        path.startswith("<ipython-input-")
        or ("ipykernel_" in path and basename.endswith(".py"))
        or path.startswith("<colab-input-")
    )


def _display_source_label(part: Source) -> str:
    file_str = str(part.pos.file)
    try:
        from .runtime import ENV, NotebookBase  # avoid circular import
    except Exception:
        return file_str

    if isinstance(ENV, NotebookBase) and _is_notebook_generated_path(file_str):
        return f"cell:{part.orig_line}"
    return file_str


def _source_lines(part: Source) -> list[tuple[int, str]]:
    source_lines = part.pos.source.rstrip("\n").splitlines()
    start_line = part.pos.line or part.orig_line or 1
    return [(start_line + idx, source_line) for idx, source_line in enumerate(source_lines)]


def diagnostic_to_plain_text(diag: "Diagnostic") -> str:
    lines = [f"[{diag.name}] {diag.message}"]
    for part in diag.parts:
        if isinstance(part, str):
            lines.append(part)
        elif isinstance(part, Source) and part.pos.source:
            source_label = _display_source_label(part)
            if source_label.startswith("cell:"):
                lines.append(f">> {source_label}")
            else:
                lines.append(f">> {source_label}:{part.orig_line}")
            for line_no, source_line in _source_lines(part):
                lines.append(f"{line_no:>4} {source_line}")
        elif isinstance(part, Table):
            if part.headers:
                lines.append(" | ".join(part.headers))
            for row in part.rows:
                lines.append(" | ".join(str(c) for c in row))
    return "\n".join(lines)

#------------------------------------------------------
# Emitters
#------------------------------------------------------

class RichEmitter:
    """
    Returns a pretty terminal string (no side effects).
    """
    def emit(self, diag: Diagnostic) -> str:
        buf = StringIO()
        # write to our buffer, not the real terminal
        console = Console(file=buf, record=False, color_system="auto", soft_wrap=False, force_terminal=True)
        sev_style = {"error": "bold red", "warning": "bold yellow", "info": "bold cyan"}.get(diag.severity, "bold")

        # Title
        title_text = Text(f"[{diag.name}] ", style=sev_style)
        title_text.append(diag.message, style="bold")

        # Collect all parts into a group
        parts_renderables:list[Any] = [title_text]
        loc = None
            # parts_renderables.append(Rule(style=sev_style))

        for i, part in enumerate(diag.parts):
            parts_renderables.append(Text(""))  # spacer
            if isinstance(part, str):
                parts_renderables.append(Text.from_markup(part))
            elif isinstance(part, Source) and part.pos.source:
                if not loc:
                    source_label = _display_source_label(part)
                    loc_text = f">> {source_label}" if source_label.startswith("cell:") else f">> {source_label}:{part.orig_line}"
                    loc = Text(loc_text, style="dim")
                lexer = "python" if str(part.pos.file).endswith(".py") else "text"
                num_lines = part.pos.source.count("\n") + 1
                highlight_lines = set([part.orig_line]) if num_lines > 1 else set()
                start_line = part.pos.line or 0
                parts_renderables.append(
                    Syntax(part.pos.source.rstrip("\n"), lexer, line_numbers=True, background_color="default", word_wrap=True, start_line=start_line, highlight_lines=highlight_lines)
                )
            elif isinstance(part, Table):
                t = RichTable(show_header=True, expand=False, show_lines=False, padding=(0,1), box=box.SIMPLE_HEAD, border_style=None)
                for h in part.headers:
                    t.add_column(h)
                for row in part.rows:
                    t.add_row(*[str(c) for c in row])
                parts_renderables.append(t)

        # One big group, inside one Panel
        if loc:
            parts_renderables.insert(1, loc)
        group = Group(*parts_renderables)
        console.print(Panel(group, border_style=sev_style))

        return buf.getvalue()

class HTMLEmitter:
    """
    Returns inline-CSS HTML string (no side effects).
    """
    def emit(self, diag: Diagnostic) -> str:
        sev_color_dark = {"error": "#ff6b6b", "warning": "#f4b942", "info": "#5cc8ff"}.get(diag.severity, "#c7d2fe")
        sev_color_light = {"error": "#c93c37", "warning": "#9a6700", "info": "#0b6bcb"}.get(diag.severity, "#4f46e5")
        css = """
<style>
.diag {
  color-scheme: light dark;
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, Apple Color Emoji, Segoe UI Emoji;
  margin: 10px 0 14px 0;
  --diag-accent: var(--diag-accent-light);
  --diag-bg: #fff7f7;
  --diag-fg: #201a1a;
  --diag-muted: #5f636d;
  --diag-code-bg: #ffffff;
  --diag-code-border: #ead9d8;
  --diag-line-no: #8f6b68;
  --diag-hi-bg: rgba(201, 60, 55, 0.08);
  --diag-shadow: inset 0 1px 0 rgba(255,255,255,0.8);
}
@media (prefers-color-scheme: dark) {
  .diag {
    --diag-accent: var(--diag-accent-dark);
    --diag-bg: #0b0d10;
    --diag-fg: #e5e7eb;
    --diag-muted: #9aa4b2;
    --diag-code-bg: #05070a;
    --diag-code-border: #20242c;
    --diag-line-no: #6b7280;
    --diag-hi-bg: rgba(255, 107, 107, 0.08);
    --diag-shadow: inset 0 1px 0 rgba(255,255,255,0.03);
  }
}
.diag-card {
  background: var(--diag-bg);
  color: var(--diag-fg);
  border: 1px solid var(--diag-accent);
  border-radius: 10px;
  padding: 12px 14px;
  box-shadow: var(--diag-shadow);
}
.hdr {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 14px;
  line-height: 1.35;
  font-weight: 600;
  margin: 0;
  color: var(--diag-accent);
}
.hdr .name { font-weight: 700; }
.hdr .msg { color: inherit; }
.loc {
  margin: 8px 0 0 0;
  color: var(--diag-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  line-height: 1.3;
}
.block { margin: 8px 0 0 0; color: var(--diag-fg); }
.codewrap {
  margin-top: 6px;
  background: var(--diag-code-bg);
  border: 1px solid var(--diag-code-border);
  border-radius: 8px;
  overflow: auto;
}
.code-table {
  width: 100%;
  border-collapse: collapse;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  line-height: 1.6;
}
.code-table td {
  padding: 0;
  vertical-align: top;
}
.code-line.hl { background: var(--diag-hi-bg); }
.line-no {
  width: 1%;
  min-width: 34px;
  padding: 0 8px 0 8px !important;
  text-align: right;
  user-select: none;
  color: var(--diag-line-no);
  border-right: 1px solid var(--diag-code-border);
}
.code-line.hl .line-no { color: var(--diag-accent); }
.line-src {
  padding: 0 10px !important;
  white-space: pre;
  text-align: left;
  color: var(--diag-fg);
}
.table {
  border-collapse: collapse;
  margin: 10px 0 0 0;
  font-size: 0.95rem;
}
.table th, .table td {
  border: 1px solid var(--diag-code-border);
  padding: 6px 8px;
}
.table th {
  background: color-mix(in srgb, var(--diag-code-bg) 84%, var(--diag-accent) 16%);
  text-align: left;
}
</style>
"""
        hdr = (
            '<div class="hdr">'
            f'<span class="name">[{html.escape(diag.name)}]</span> '
            f'<span class="msg">{html.escape(diag.message)}</span>'
            "</div>"
        )

        parts_html: list[str] = []
        for part in diag.parts:
            if isinstance(part, str):
                parts_html.append(f'<div class="block">{html.escape(part)}</div>')
            elif isinstance(part, Source) and part.pos.source:
                source_label = _display_source_label(part)
                file_line = html.escape(source_label if source_label.startswith("cell:") else f"{source_label}:{part.orig_line}")
                rows = []
                for line_no, source_line in _source_lines(part):
                    row_cls = "code-line hl" if line_no == part.orig_line else "code-line"
                    rows.append(
                        f'<tr class="{row_cls}">'
                        f'<td class="line-no">{line_no}</td>'
                        f'<td class="line-src">{html.escape(source_line)}</td>'
                        "</tr>"
                    )
                code_table = '<div class="codewrap"><table class="code-table"><tbody>' + "".join(rows) + "</tbody></table></div>"
                parts_html.append(f'<div class="loc">&gt;&gt; {file_line}</div>{code_table}')
            elif isinstance(part, Table):
                head = "".join(f"<th>{html.escape(h)}</th>" for h in part.headers)
                body = "".join("<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in row) + "</tr>" for row in part.rows)
                parts_html.append(f'<div class="block"><table class="table"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>')

        return (
            f'<div class="diag" style="--diag-accent-light: {sev_color_light}; --diag-accent-dark: {sev_color_dark};">'
            f"{css}<div class=\"diag-card\">{hdr}{''.join(parts_html)}</div></div>"
        )

#------------------------------------------------------
# Custom Exception classes
#------------------------------------------------------

class RAIWarning(UserWarning):
    """Warnings emitted by RAI."""

class RAIException(Exception):
    """Exception raised to signal a diagnostic error."""
    def __init__(self, diag: Diagnostic):
        self.diagnostic = diag
        super().__init__(diagnostic_to_plain_text(diag))

#------------------------------------------------------
# Funcs
#------------------------------------------------------

def info(name: str, message: str, parts: Optional[list[Part]] = None) -> Diagnostic:
    from .runtime import ENV  # avoid circular import
    diag = Diagnostic(name, message, parts or [], severity="info")
    ENV.info(diag)
    return diag

def warn(name: str, message: str, parts: Optional[list[Part]] = None) -> Diagnostic:
    from .runtime import ENV  # avoid circular import
    diag = Diagnostic(name, message, parts or [], severity="warning")
    ENV.warn(diag)
    return diag

def err(name: str, message: str, parts: Optional[list[Part]] = None) -> Diagnostic:
    from .runtime import ENV  # avoid circular import
    diag = Diagnostic(name, message, parts or [], severity="error")
    # Do not raise here; caller may choose to continue. Just route it.
    ENV.err(diag)  # default raises; override ENV to change behavior
    return diag  # (unreached in default env)

def exc(name: str, message: str, parts: Optional[list[Part]] = None) -> NoReturn:
    from .runtime import ENV  # avoid circular import
    """Always raise after routing (handy for short-circuiting)."""
    diag = Diagnostic(name, message, parts or [], severity="error")
    ENV.err(diag, exception=True)  # raises DiagnosticException by default
    raise RuntimeError("Unreachable")  # for type checkers

def source(obj:Any) -> Source:
    if isinstance(obj, SourcePos):
        return Source(pos=obj)

    source = getattr(obj, "_source", None) or getattr(obj, "source", None)
    if source is None:
        raise ValueError("Object has no source information")

    return Source(source)

def table(headers: list[str] = [], rows: list[list[str]] = []) -> Table:
    return Table(headers=headers, rows=rows)
