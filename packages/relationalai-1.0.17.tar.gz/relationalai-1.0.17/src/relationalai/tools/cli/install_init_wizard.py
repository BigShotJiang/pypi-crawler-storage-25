"""Wizard for the `rai init --install-mode` command.

Scaffolds a full install-mode starter project in a named subfolder.

Entry paths:
  1. <name>/raiconfig.yaml found → validate it (same as rai init path 1)
  2. Nothing found               → create <name>/ with all starter files
"""

from __future__ import annotations

from pathlib import Path

import click
import rich

# ── Constants ────────────────────────────────────────────────────────────────
RAICONFIG_YAML = "raiconfig.yaml"
RAICONFIG_YML = "raiconfig.yml"

_DIVIDER = "[dim]" + "─" * 52 + "[/dim]"


# ── Public entry point ───────────────────────────────────────────────────────

def run_install_wizard() -> None:
    """Entry point called from cli.py for `rai init --install-mode`."""
    rich.print(f"\n{_DIVIDER}")
    rich.print("[bold]Welcome to [green]RelationalAI[/green]![/bold]")
    rich.print("[dim]Setting up your install-mode starter project.[/dim]")
    rich.print(_DIVIDER)

    _create_install_mode_project()


# ── Project scaffolding ───────────────────────────────────────────────────────

def _create_install_mode_project() -> None:
    """Scaffold a new install-mode project in a named subfolder (Next.js-style)."""
    from .template_config import (
        INSTALL_MODE_CONFIG_TEMPLATE,
        INSTALL_MODE_LOAD_DATA_TEMPLATE,
        INSTALL_MODE_MODEL_PY_TEMPLATE,
        INSTALL_MODE_PYPROJECT_TOML_TEMPLATE,
        INSTALL_MODE_QUERIES_PY_TEMPLATE,
        INSTALL_MODE_README_TEMPLATE,
    )

    name = click.prompt("Project name", default="starter")
    project_dir = Path(name)
    yaml_path = project_dir / RAICONFIG_YAML

    if yaml_path.exists():
        _existing_yaml_path(yaml_path)
        return

    project_dir.mkdir(exist_ok=True)

    yaml_path.write_text(INSTALL_MODE_CONFIG_TEMPLATE, encoding="utf-8")
    (project_dir / "model.py").write_text(INSTALL_MODE_MODEL_PY_TEMPLATE.format(name=name), encoding="utf-8")
    (project_dir / "load_data.py").write_text(INSTALL_MODE_LOAD_DATA_TEMPLATE, encoding="utf-8")
    (project_dir / "queries.py").write_text(INSTALL_MODE_QUERIES_PY_TEMPLATE, encoding="utf-8")
    (project_dir / "pyproject.toml").write_text(INSTALL_MODE_PYPROJECT_TOML_TEMPLATE.format(name=name), encoding="utf-8")
    (project_dir / "README.md").write_text(INSTALL_MODE_README_TEMPLATE.format(name=name), encoding="utf-8")

    rich.print(f"\n{_DIVIDER}")
    rich.print(f"[green]✓ Created project [bold]{name}/[/bold][/green]")
    rich.print(f"  [cyan]{name}/raiconfig.yaml[/cyan]    — connection + install mode config")
    rich.print(f"  [cyan]{name}/model.py[/cyan]           — starter model")
    rich.print(f"  [cyan]{name}/load_data.py[/cyan]       — data loading script")
    rich.print(f"  [cyan]{name}/queries.py[/cyan]         — example queries")
    rich.print(f"  [cyan]{name}/pyproject.toml[/cyan]     — project metadata")
    rich.print(f"  [cyan]{name}/README.md[/cyan]           — getting started guide")
    rich.print("\n[dim]Next steps:[/dim]")
    rich.print(f"[dim]  cd {name}[/dim]")
    rich.print("[dim]  pip install -e .[/dim]")
    rich.print("[dim]  python load_data.py[/dim]")
    rich.print("[dim]  rai model:install[/dim]")
    rich.print("[dim]  python queries.py[/dim]")
    rich.print(f"{_DIVIDER}\n")


# ── Validation (reused from init_wizard logic) ────────────────────────────────

_TEMPLATE_PLACEHOLDERS = {"myorg-myaccount", "you@example.com", "your_password"}


def _has_template_values(yaml_path: Path) -> bool:
    """Return True if the file still contains any known template placeholder values."""
    content = yaml_path.read_text(encoding="utf-8")
    return any(placeholder in content for placeholder in _TEMPLATE_PLACEHOLDERS)


def _existing_yaml_path(yaml_path: Path) -> None:
    """Validate existing raiconfig.yaml and report status."""
    try:
        from relationalai.config import create_config
        from relationalai.tools.cli.init_wizard import run_explain
        run_explain(create_config())
        rich.print(f"\n{_DIVIDER}")
        if _has_template_values(yaml_path):
            rich.print("[yellow]⚠ Your config still contains template placeholder values.[/yellow]")
            rich.print(f"[dim]Edit [bold]{yaml_path}[/bold] and replace the example values with your own, then run [bold]rai init --install-mode[/bold] again.[/dim]")
        else:
            rich.print("[green]✓ You're all set![/green] Your config is valid and ready to use.")
        rich.print(f"{_DIVIDER}\n")
    except Exception as e:
        rich.print(f"\n[yellow]⚠ Config has issues:[/yellow]\n{e}")
        rich.print("\n[dim]Edit your raiconfig.yaml to fix the issues above.[/dim]")
