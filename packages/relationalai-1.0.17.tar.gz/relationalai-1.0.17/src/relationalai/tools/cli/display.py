from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Iterable, Mapping

from rich import box as rich_box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from relationalai.tools.cli.cli_helpers import console as cli_console

if TYPE_CHECKING:
    from relationalai.config.config import Config
    from relationalai.config.connections import ConnectionConfig

from relationalai.services.reasoners.models import ReasonerType


def format_state_with_color(state: str) -> str:
    """Format state with colors (mirrors upstream CLI `format_state_with_color`)."""
    if not state:
        return ""
    state_upper = state.upper()
    # Success / terminal-ok states (jobs + operations).
    if state_upper in ("COMPLETED", "SUCCEEDED"):
        return f"[green]{state_upper}[/green]"
    if state_upper == "READY":
        return f"[green]{state_upper}[/green]"
    if state_upper == "SUSPENDED":
        return f"[yellow]{state_upper}[/yellow]"
    if state_upper in ("CANCELED", "CANCELLED"):
        return f"[yellow]{state_upper}[/yellow]"
    if state_upper in ("PENDING", "SYNCING", "PROCESSING", "RUNNING", "CANCELLING"):
        return f"[bold yellow]{state_upper}[/bold yellow]"
    if state_upper in ("ABORTED", "QUARANTINED", "GONE", "FAILED", "ERROR", "DELETED"):
        return f"[red]{state_upper}[/red]"
    return state_upper


def format_value(value: Any) -> str:
    """Format values for table display (mirrors upstream CLI `format_value`)."""
    if value is None:
        return "N/A"
    if isinstance(value, str) and not value.strip():
        return "N/A"
    if isinstance(value, (int, float, bool)):
        return f"{value}"
    if isinstance(value, list):
        return ", ".join(map(str, value))
    if isinstance(value, datetime):
        dt = value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value
        return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, timedelta):
        # Keep it simple here; reasoners tables typically don't show timedeltas.
        return str(value)
    return str(value)


def _format_duration_ms(duration_ms: int | float | None) -> str:
    """Format a duration in milliseconds into a compact human form."""
    if duration_ms is None:
        return "N/A"
    try:
        ms = float(duration_ms)
    except Exception:
        return str(duration_ms)
    if ms < 1000:
        return f"{int(ms)}ms" if ms.is_integer() else f"{ms}ms"
    s = ms / 1000.0
    # Keep one decimal only when needed (e.g. 1.5s), otherwise show integer seconds.
    if abs(s - round(s)) < 1e-9:
        return f"{int(round(s))}s"
    out = f"{s:.1f}".rstrip("0").rstrip(".")
    return f"{out}s"


_KNOWN_REASONER_TYPES = {ReasonerType.LOGIC, ReasonerType.PRESCRIPTIVE, ReasonerType.PREDICTIVE}


def _get(obj: Any, key: str, default: Any = "") -> Any:
    if isinstance(obj, Mapping):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _job_model(job: Any) -> Any:
    """Target model/database name on a `Job` or mapping (details use key ``model``)."""
    m = _get(job, "model", None)
    if m is not None:
        return m
    details = _get(job, "details", None)
    if isinstance(details, Mapping):
        if details.get("model") is not None:
            return details.get("model")
        return details.get("database_name")
    return None


def _format_reasoner_type(reasoner_type: str) -> str:
    t = (reasoner_type or "").upper()
    from relationalai.tools.cli.job_types import JOB_TYPE_LABELS

    if t in JOB_TYPE_LABELS:
        return JOB_TYPE_LABELS[t]
    if t in _KNOWN_REASONER_TYPES:
        return ReasonerType.get_label(t)
    return reasoner_type or ""


def show_reasoners(reasoners: Iterable[Any]) -> None:
    """Show reasoners in a table matching upstream reasoners table layout."""
    items = list(reasoners)
    if not len(items):
        return

    table = Table(show_header=True, border_style="dim", header_style="bold", box=rich_box.SIMPLE_HEAD)
    table.add_column("#")
    table.add_column("Name")
    table.add_column("Type")
    table.add_column("Size")
    table.add_column("State")
    table.add_column("Created By")
    table.add_column("Created On")

    for index, r in enumerate(items):
        r_type = _get(r, "type", "") or ""
        type_display = _format_reasoner_type(str(r_type))
        created_on = format_value(_get(r, "created_on", None))
        state_display = format_state_with_color(str(_get(r, "state", "") or ""))
        table.add_row(
            f"{index+1}",
            str(_get(r, "name", "")),
            type_display,
            str(_get(r, "size", "") or ""),
            state_display,
            str(_get(r, "created_by", "") or ""),
            created_on,
        )

    cli_console.print(table)


def show_reasoner(reasoner: Any) -> None:
    """Convenience wrapper for printing a single reasoner."""
    show_reasoners([reasoner])


def _format_reasoner_detail_blob(value: Any) -> str:
    """Format SETTINGS/RUNTIME-style JSON for vertical reasoner detail output."""
    if value is None:
        return "N/A"
    if isinstance(value, Mapping):
        return json.dumps(dict(value), indent=2, sort_keys=True, default=str)
    return format_value(value)


def _format_job_payload_cell(value: Any) -> str:
    """Format job ``details['payload']`` (often a JSON string) for vertical job detail output."""
    if value is None or value == "":
        return "N/A"
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, (dict, list)):
                return json.dumps(parsed, indent=2, sort_keys=True, default=str)
        except Exception:
            return value
        return value
    if isinstance(value, Mapping):
        return json.dumps(dict(value), indent=2, sort_keys=True, default=str)
    return format_value(value)


def show_reasoner_detail(reasoner: Any) -> None:
    """Print one reasoner as a Field/Value table (all known metadata, including JSON blobs)."""
    r = reasoner
    r_type = str(_get(r, "type", "") or "")
    type_display = _format_reasoner_type(r_type)
    state_display = format_state_with_color(str(_get(r, "state", "") or ""))

    rows: list[tuple[str, str]] = [
        ("Name", format_value(_get(r, "name", None))),
        ("Type", type_display),
        ("ID", format_value(_get(r, "id", None))),
        ("Size", format_value(_get(r, "size", None))),
        ("State", state_display),
        ("Created By", format_value(_get(r, "created_by", None))),
        ("Created On", format_value(_get(r, "created_on", None))),
        ("Updated On", format_value(_get(r, "updated_on", None))),
        ("Version", format_value(_get(r, "version", None))),
        ("Auto Suspend (mins)", format_value(_get(r, "auto_suspend_mins", None))),
        ("Suspends At", format_value(_get(r, "suspends_at", None))),
        ("Settings", _format_reasoner_detail_blob(_get(r, "settings", None))),
        ("Runtime", _format_reasoner_detail_blob(_get(r, "runtime", None))),
    ]

    table = Table(show_header=True, border_style="dim", header_style="bold", box=rich_box.SIMPLE_HEAD)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    for label, cell in rows:
        table.add_row(label, cell)

    cli_console.print(table)


def show_jobs(jobs: Iterable[Any], *, include_details: bool = False) -> None:
    """Show jobs in a stable, readable table.

    ``Model`` is always shown when known. When `include_details=True`, adds columns
    from `job.details` for read_only/timeout_ms.
    """
    items = list(jobs)
    if not len(items):
        return

    table = Table(show_header=True, border_style="dim", header_style="bold", box=rich_box.SIMPLE_HEAD)
    table.add_column("#")
    table.add_column("ID", no_wrap=True)
    table.add_column("Type")
    table.add_column("State")
    table.add_column("Reasoner")
    table.add_column("Model")
    table.add_column("Created By")
    table.add_column("Created On")
    table.add_column("Finished At")
    table.add_column("Duration")
    table.add_column("Abort Reason")
    if include_details:
        table.add_column("Read Only")
        table.add_column("Timeout (ms)")

    for index, j in enumerate(items):
        t_display = _format_reasoner_type(str(_get(j, "reasoner_type", "") or ""))
        state_display = format_state_with_color(str(_get(j, "state", "") or ""))
        details = _get(j, "details", None)
        details_d: dict[str, Any] = dict(details) if isinstance(details, Mapping) else {}
        dur_any = _get(j, "duration", None)
        duration_display = (
            _format_duration_ms(dur_any)
            if (dur_any is None or isinstance(dur_any, (int, float)))
            else format_value(dur_any)
        )
        table.add_row(
            f"{index+1}",
            str(_get(j, "id", "")),
            t_display,
            state_display,
            format_value(_get(j, "name", None)),
            format_value(_job_model(j)),
            format_value(_get(j, "created_by", None)),
            format_value(_get(j, "created_on", None)),
            format_value(_get(j, "finished_at", None)),
            duration_display,
            format_value(_get(j, "abort_reason", None)),
            *(
                [
                    format_value(details_d.get("read_only")),
                    format_value(details_d.get("timeout_ms")),
                ]
                if include_details
                else []
            ),
        )

    cli_console.print(table)


def show_job(job: Any) -> None:
    """Convenience wrapper for printing a single job."""
    show_jobs([job])


def show_job_detail(job: Any) -> None:
    """Print one job as a Field/Value table (mirrors ``show_reasoner_detail`` for ``jobs:get``)."""
    j = job
    t_display = _format_reasoner_type(str(_get(j, "reasoner_type", "") or ""))
    state_display = format_state_with_color(str(_get(j, "state", "") or ""))
    details = _get(j, "details", None)
    details_d: dict[str, Any] = dict(details) if isinstance(details, Mapping) else {}
    dur_any = _get(j, "duration", None)
    duration_display = (
        _format_duration_ms(dur_any)
        if (dur_any is None or isinstance(dur_any, (int, float)))
        else format_value(dur_any)
    )

    rows: list[tuple[str, str]] = [
        ("ID", format_value(_get(j, "id", None))),
        ("Type", t_display),
        ("State", state_display),
        ("Reasoner", format_value(_get(j, "name", None))),
        ("Model", format_value(_job_model(j))),
        ("Created By", format_value(_get(j, "created_by", None))),
        ("Created On", format_value(_get(j, "created_on", None))),
        ("Finished At", format_value(_get(j, "finished_at", None))),
        ("Duration", duration_display),
        ("Abort Reason", format_value(_get(j, "abort_reason", None))),
        ("Read Only", format_value(details_d.get("read_only"))),
        ("Timeout (ms)", format_value(details_d.get("timeout_ms"))),
        ("Payload", _format_job_payload_cell(details_d.get("payload"))),
    ]

    table = Table(show_header=True, border_style="dim", header_style="bold", box=rich_box.SIMPLE_HEAD)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    for label, cell in rows:
        table.add_row(label, cell)

    cli_console.print(table)


def show_connect_panel(config: Config, console: Console) -> ConnectionConfig:
    """Print the rai connect info panel and return the resolved default connection."""
    from relationalai.tools.cli.error_handlers import format_connection_info

    connection = config.get_default_connection()

    info_table = Table(show_header=False, box=None, padding=(0, 2, 0, 0), expand=True)
    info_table.add_column(style="dim cyan", no_wrap=True)
    info_table.add_column(style="white")

    source_field = type(config).model_fields.get("source")
    config_source = source_field.default if source_field is not None else None
    if config_source:
        info_table.add_row("Config", config_source)
    if config.active_profile:
        info_table.add_row("Profile", config.active_profile)

    if config_source or config.active_profile:
        info_table.add_row("", "")  # spacer

    for label, value in format_connection_info(connection):
        info_table.add_row(label, value)

    if "direct_access" in config.model_fields_set and config.direct_access:
        info_table.add_row("", "")  # spacer
        info_table.add_row("Direct Access", "true")

    console.print(Panel(info_table, title="[bold cyan]rai connect[/bold cyan]", border_style="cyan", padding=(1, 2)))
    return connection


def print_job_expansions(job: Any, *, skip_details: bool = False) -> None:
    """Print expanded job sections when present (mirrors scripts/jobs.py UX).

    When ``skip_details=True``, omit the DETAILS block (e.g. after ``show_job_detail`` inlines it).
    """
    if not skip_details and getattr(job, "details", None) is not None:
        cli_console.print("\n[bold]DETAILS[/bold]")
        cli_console.print(json.dumps(getattr(job, "details"), indent=2, default=str))
    if getattr(job, "artifacts", None) is not None:
        cli_console.print("\n[bold]ARTIFACTS[/bold]")
        cli_console.print(json.dumps(getattr(job, "artifacts"), indent=2, default=str))
    if getattr(job, "problems", None) is not None:
        cli_console.print("\n[bold]PROBLEMS[/bold]")
        cli_console.print(json.dumps(getattr(job, "problems"), indent=2, default=str))
    if getattr(job, "events", None) is not None:
        ev = getattr(job, "events")
        cli_console.print("\n[bold]EVENTS[/bold]")
        cli_console.print(
            json.dumps(
                {"events": getattr(ev, "events", []), "continuation_token": getattr(ev, "continuation_token", None)},
                indent=2,
                default=str,
            )
        )
    if getattr(job, "raw", None) is not None:
        cli_console.print("\n[bold]RAW[/bold]")
        cli_console.print(json.dumps(getattr(job, "raw"), indent=2, default=str))


def show_models(items: list) -> None:
    """Display model schemas in a Rich table."""
    table = Table(box=rich_box.SIMPLE)
    table.add_column("Schema", style="bold")
    table.add_column("Parent")
    table.add_column("Type")
    table.add_column("Version")

    for m in items:
        table.add_row(
            str(m.name),
            format_value(getattr(m, "parent_schema", None)),
            "live" if getattr(m, "is_live", True) else "static",
            format_value(getattr(m, "version", None)),
        )

    cli_console.print(table)

