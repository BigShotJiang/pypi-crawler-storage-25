from __future__ import annotations

import json
from dataclasses import asdict
from typing import TYPE_CHECKING

from relationalai.config.config import Config
from relationalai.semantics.backends.sql.normalizer import StorageVersionNormalizer
from relationalai.semantics.metamodel import metamodel as mm

from .sql.logic_block_builder import LogicBlockBuilder
from .sql.artifacts import Catalog, LogicExecutionStep
from .legacy_executor import LegacyExecutor


if TYPE_CHECKING:
    from .sql.artifacts import BlockVersionState
    from .sql.coalescer import CoalescedBlock

def _sql_string_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"

def _sql_nullable_int_literal(value: int | None) -> str:
    return "NULL" if value is None else str(value)

def _sql_bool_literal(value: bool) -> str:
    return "TRUE" if value else "FALSE"

class LogicExecutor:
    """Submits LQP blobs to the Snowflake-hosted logic reasoner.

    This executor is only instantiated on Snowflake connections. Any
    :class:`~sql.artifacts.LogicExecutionStep` in the execution plan is routed
    here rather than to the SQL executor.
    """

    def __init__(self, config: Config, sf_database: str) -> None:
        self._config = config
        self._sf_database = sf_database
        self._legacy_executor = LegacyExecutor(config = self._config, database = self._sf_database)

    def plan_block(
        self,
        block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        storage_normalizer: StorageVersionNormalizer,
    ) -> LogicExecutionStep | None:
        """Compile a logic block into the execution payload the LR backend needs.

        Called during model install (inside the Lowerer) to produce the plan
        that is stored in the plan table and passed to :meth:`execute`.
        """
        block_builder = LogicBlockBuilder(storage_normalizer)
        logic_block = block_builder.build(
            block,
            model,
            catalog,
            version_state,
        )
        if logic_block is None:
            return None

        return LogicExecutionStep(lqp_plan=logic_block)


    def execute_block(self, step: LogicExecutionStep, mm_model: mm.Model) -> None:
        """Execute a single LQP step against the logic reasoner."""

        execution_model = mm_model.mut(root=step.lqp_plan.install_root)
        self._legacy_executor.execute_mm(
            dsl_query_string="LQP block",
            mm_query=step.lqp_plan.export_query,
            mm_model=execution_model,
        )


    def plan_lqp_sql(self, meta_schema: str, block_index: int, step: LogicExecutionStep, mm_model: mm.Model) -> str:
        """Return the SQL/call that the refresh procedure uses to re-run this step."""

        execution_model = mm_model.mut(root=step.lqp_plan.install_root)
        compiled = self._legacy_executor.build_lqp_refresh_spec(
            mm_query=step.lqp_plan.export_query,
            mm_model=execution_model,
        )

        source_tables_json = json.dumps([asdict(t) for t in compiled.source_tables])
        export_specs_json = json.dumps([asdict(e) for e in compiled.export_specs])

        model_database = compiled.model_database
        engine_name = compiled.engine_name
        engine_size = compiled.engine_size
        query_timeout_mins = compiled.query_timeout_mins
        wait_for_stream_sync = compiled.wait_for_stream_sync
        lqp_payload_b64 = compiled.lqp_payload_b64

        run_sql = (
            f"CALL {meta_schema}.RUN_LQP_BLOCK("
            f"{_sql_nullable_int_literal(block_index)}, "
            f"{_sql_string_literal(model_database)}, "
            f"{_sql_string_literal(engine_name)}, "
            f"{_sql_string_literal(engine_size)}, "
            f"{_sql_nullable_int_literal(query_timeout_mins)}, "
            f"{_sql_bool_literal(wait_for_stream_sync)}, "
            f"{_sql_string_literal(source_tables_json)}, "
            f"{_sql_string_literal(lqp_payload_b64)}, "
            f"{_sql_string_literal(export_specs_json)})"
        )
        return run_sql
