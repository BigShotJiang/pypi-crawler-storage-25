from relationalai.semantics.backends.legacy_lqp.rewrite.cast_to_union_type import CastToUnionType

from .lqp_pass import Pass

from .transform_require import TransformRequire
from .deduplicate_vars import DeduplicateVars
from .constants_to_vars import ConstantsToVars
from .function_annotations import FunctionAnnotations
from .pass_sequence import PassSequence
from .recursion_config import RecursionConfig
from .annotate_constraints import AnnotateConstraints
from .handle_annotated_requires import HandleAnnotatedRequires
from .match2union import Match2Union

from v0.relationalai.semantics.metamodel.compiler import Pass as v0Pass
from v0.relationalai.semantics.metamodel import rewrite as v0_rewrite, typer as v0_typer
from v0.relationalai.semantics.lqp import rewrite as v0_lqp_rewrite

def lqp_passes() -> list[Pass]:
    return [
        RecursionConfig(),
        PassSequence(
            TransformRequire(),
            FunctionAnnotations(),
            AnnotateConstraints(),
            HandleAnnotatedRequires(),
        ),
        Match2Union(),
        DeduplicateVars(),
        ConstantsToVars(),
        CastToUnionType(),
    ]

def v0_lqp_passes() -> list[v0Pass]:
    return [
        v0_typer.InferTypes(),

        v0_rewrite.DNFUnionSplitter(),
        v0_lqp_rewrite.ExtractKeys(),
        v0_lqp_rewrite.FormatOutputs(),

        v0_lqp_rewrite.ExtractCommon(),
        v0_lqp_rewrite.Flatten(),
        v0_lqp_rewrite.FlattenScript(), # - Partially migrated in #783
        # (Match2Union handles everything that FlattenScript used to except for flattening logicals)
        v0_rewrite.HandleAggregationsAndRanks(),

        v0_lqp_rewrite.LiftData(),
        v0_lqp_rewrite.PeriodMath(),
        v0_lqp_rewrite.Splinter(),
        v0_lqp_rewrite.DeduplicateVars(),
        v0_lqp_rewrite.QuantifyVars(),

        v0_lqp_rewrite.AlgorithmPass(),
        v0_lqp_rewrite.UnifyDefinitions(),
    ]
