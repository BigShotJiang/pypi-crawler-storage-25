from ....metamodel.rewriter import Rewriter
from ....metamodel.metamodel import Task, Update, Logical
from .....config import Config
from ..annotations import require_seminaive
from .lqp_pass import Pass
from ....experimental.loopy.structural_recursion import STRUCTURAL_RECURSION_ANNOTATIONS

class RecursionConfig(Pass):
    """
    A rewrite pass that adds the `@recursion_config(:require_seminaive)` annotation to all
    `Update` nodes. 
    
    Also moves any structural recursion annotations (`@iter`, `@inner_loop`, `@inner_loop2`)
    to the `Update` node and not the `Logical`.
    """
    def _rewrite_task(self, node: Task, config:Config) -> Task:
        if not config.compiler.safe_recursion:
            return node

        recursion_rewriter = RecursionConfigRewriter()
        structural_rewriter = StructuralRecursionRewriter()

        node_with_recursion = recursion_rewriter.add_recursion_config(node)
        node_with_structural = structural_rewriter.propagate_annotations(node_with_recursion)

        return node_with_structural

class RecursionConfigRewriter(Rewriter):
    """
    Rewriter that adds the `@recursion_config(:require_seminaive)` annotation to all
    `Update` nodes.
    """
    def add_recursion_config(self, node: Task):
        return self(node)

    def update(self, node: Update):
        if require_seminaive in node.annotations:
            return node

        new_annotations = list(node.annotations) + [require_seminaive]
        return node.mut(annotations=tuple(new_annotations))

class StructuralRecursionRewriter(Rewriter):
    """
    Rewriter that takes any structural recursion annotations from the parent Logical
    and propagates them downwards to any updates.
    """

    def __init__(self):
        super().__init__()
        self.structural_annos = set()
        self._annos_stack = []

    def propagate_annotations(self, node: Task):
        return self(node)

    def enter_logical(self, node: Logical):
        self._annos_stack.append(self.structural_annos)
        own_annos = {
            anno for anno in node.annotations
            if anno.relation.name in STRUCTURAL_RECURSION_ANNOTATIONS
        }
        self.structural_annos = self.structural_annos | own_annos

    def logical(self, node: Logical):
        self.structural_annos = self._annos_stack.pop()
        remaining = tuple(
            a for a in node.annotations
            if a.relation.name not in STRUCTURAL_RECURSION_ANNOTATIONS
        )
        if len(remaining) != len(node.annotations):
            return node.mut(annotations=remaining)

    def update(self, node: Update):
        if self.structural_annos:
            return node.mut(annotations=node.annotations + tuple(self.structural_annos))

