"""Base Executor class for all PyRel backends."""

from __future__ import annotations

import json
import os

from typing import Iterable, TypeVar, Callable
from pandas import DataFrame

from ...config.config import Config
from ...util.error import exc, source

from ..metamodel import metamodel as mm
from ..metamodel.metamodel_analyzer import Normalize, RelationAnalyzer, Lowering, Groundness
from ..metamodel.typer import Typer
from ..frontend import base as dsl

from v0.relationalai import debugging

#------------------------------------------------------
# Executor and MetamodelExecutor (base)
#------------------------------------------------------

class Executor:
    """Backend-agnostic executor."""

    def execute_query(self, model: "dsl.Model", fragment: "dsl.Fragment", **kwargs) -> DataFrame:
        """ Execute a query fragment against the model, returning a DataFrame.

        Executors may keep track of whether the model is already installed, and install it
        if necessary. """
        raise NotImplementedError(f"execute_query: {self}")

    def install(self, model: "dsl.Model", **kwargs) -> None:
        """ Install the model. """
        raise NotImplementedError(f"install: {self}")

class MetamodelExecutor:
    """Executor that operates directly on the metamodel. This is the interface that all
    executors must implement, and it is used by the ModelManagerExecutor to execute
    queries against the installed model.
    """

    def execute_query(self, model: mm.Model, query: mm.Task, **kwargs) -> DataFrame:
        raise NotImplementedError(f"execute_query: {self}")

    def install(self, model: mm.Model, **kwargs) -> None:
        raise NotImplementedError(f"install: {self}")

#------------------------------------------------------
# Model Manager Executor
#------------------------------------------------------

class ModelManagerExecutor(Executor):
    """Executor that manages the state of the installed model.

    This class wraps a MetamodelExecutor to actually perform installation and query
    execution. The current implementation keeps track of the model in memory, but in the
    future it may use persistence.

    Handles DSL -> metamodel translation with caching: the model is only retranslated
    (and reinstalled) when its version token changes. The fragment is always retranslated.

    Also handles the common metamodel passes that need to be executed prior to installation
    and query execution.
    """

    def __init__(self, executor: MetamodelExecutor, config: Config):
        # wrapped executor and config
        self._executor = executor
        self._config = config
        # cache of model state
        self._installed_model_token: tuple[int, int] | None = None
        self._cached_mm_model: mm.Model | None = None
        # stateful typer is created when a model is installed, and reused for queries
        self._typer: Typer | None = None
        # common passes
        self._normalizer = Normalize()
        self.analyzer = RelationAnalyzer()
        self._lowering = Lowering()
        self._groundness = Groundness()

    @property
    def inner_executor(self) -> MetamodelExecutor:
        return self._executor

    def execute_query(self, model: "dsl.Model", fragment: "dsl.Fragment", **kwargs) -> DataFrame:
        token = self._model_token(model)
        if self._cached_mm_model is None or self._installed_model_token != token:
            self.install(model, **kwargs)
        assert self._cached_mm_model is not None

        # translate dsl to metamodel
        mm_query = fragment.to_metamodel()
        assert isinstance(mm_query, mm.Task) # TODO: raise if false?

        # unpack kwargs for debugging span
        meta=kwargs.get("meta")
        dsl_query_string = format(fragment)

        source_attrs = with_source(mm_query)
        # If there's no source file, use the query_string as the source so it shows up in the debugger
        if not source_attrs.get("source"):
            source_attrs["source"] = dsl_query_string

        with debugging.span("query", tag=None, dsl=dsl_query_string, meta=meta, **source_attrs) as query_span:
            with debugging.span("compile", metamodel=mm_query) as span:
                span["compile_type"] = "query"
                with debugging.span("v1") as span:
                    with debugging.span("Original") as span:
                        add_to_span(span, mm_query)

                    # execute the common passes
                    mm_query = self._common_metamodel_passes(mm_query)

                    # finally execute the query and add the results to the original query span
                    try:
                        results = self._executor.execute_query(self._cached_mm_model, mm_query, **kwargs)
                        query_span["results"] = results
                        return results
                    except Exception as e:
                        query_span["results"] = str(e)
                        exc("Query execution failed", "Internal error executing query", [str(e), source(fragment)])


    def install(self, model: "dsl.Model", **kwargs) -> None:
        # always reset the typer when installing a model
        self._typer = Typer(enforce=not self._config.compiler.soft_type_errors)
        with debugging.span("install") as span:
            # translate dsl to metamodel
            mm_model = model.to_metamodel()
            with debugging.span("compile", metamodel=mm_model) as span:
                span["compile_type"] = "model"
                with debugging.span("v1") as span:
                    with debugging.span("Original") as span:
                        add_to_span(span, mm_model.root)
                    # execute the common passes
                    mm_model = self._common_metamodel_passes(mm_model)

                    # finally install the model and cache the result if successful
                    self._executor.install(mm_model, **kwargs)
                    self._cached_mm_model = mm_model
                    self._installed_model_token = self._model_token(model)


    #------------------------------------------------------
    # Common metamodel passes and helpers
    #------------------------------------------------------

    T = TypeVar("T", bound=mm.Model | mm.Task)
    def _common_metamodel_passes(self, node: T) -> T:
        assert(self._typer is not None)

        with debugging.span("Typer") as span:
            # execute the appropriate typer method and capture which node to process in the
            # other passes (either the node itself for a query, or the root for a model)
            if isinstance(node, mm.Model):
                typed_model = self._typer.infer_model(node)
                task = typed_model.root
            else:
                typed_model = None # to appease the type checker
                task = self._typer.infer_query(node)
            add_to_span(span, task)
            if debugging.DEBUG:
                assert self._typer.model_net is not None
                add_to_span(span, json.dumps(
                    {
                        "id": "model_net",
                        "content": str(self._typer.model_net.to_mermaid()),
                    }
                ), "typer_network")

        with debugging.span("Normalizer") as span:
            task = self._normalizer.normalize(task)
            add_to_span(span, task)

        with debugging.span("Lowering") as span:
            task = Lowering().normalize(task)
            add_to_span(span, task)

        with debugging.span("Groundness") as span:
            self._groundness.enforce(task)

        if isinstance(node, mm.Model):
            # mutate the typed model with the new root
            assert typed_model is not None
            return typed_model.mut(root=task)
        else:
            # just return the lowered task
            return task # type: ignore


    def _model_token(self, model: "dsl.Model") -> tuple[int, int]:
        """ Generate a token for the model based on its identity and version. """
        return (id(model), model._version)


#------------------------------------------------------
# Factory
#------------------------------------------------------

def create_executor(config: Config, model: "dsl.Model") -> Executor:
    # TODO: model should not be a parameter here, but older executors still require it
    if config.install_mode:
        pipeline = os.getenv("PYREL_SQL_PIPELINE", "").strip().lower()
        if pipeline in {"new_sql"}:
            from relationalai.semantics.backends.multi_reasoner_executor import MultiReasonerExecutor
            return ModelManagerExecutor(MultiReasonerExecutor(config, model.config), config)
        else:
            from relationalai.semantics.backends.sql_poc_executor import SQLExecutor
            return SQLExecutor(config)

    elif config.reasoners.logic.use_lqp:
        from relationalai.semantics.backends.legacy_lqp.legacy_executor import LegacyLQPExecutor
        return LegacyLQPExecutor(model)
    else:
        from relationalai.semantics.backends.legacy_executor import LegacyExecutor
        return LegacyExecutor(model)

#------------------------------------------------------
# Helpers
#------------------------------------------------------

def add_to_span(span, item, key="metamodel", transform: Callable = str):
    """ Add this item to the span in this key, but only transforming into a string if
    debugging.DEBUG is True. This is to avoid the string transformation overhead."""
    if debugging.DEBUG and item:
        if isinstance(item, Iterable) and not isinstance(item, (str, bytes)):
            span[key] = "[\n" + "\n".join(transform(i) for i in item) + "]"
        else:
            span[key] = transform(item)

def with_source(item: mm.Node):
    """
    Extract source location information from a metamodel node.

    Used for debugging to provide file, line number, and source code context.

    Parameters
    ----------
    item : mm.Node
        The metamodel node to extract source information from.

    Returns
    -------
    dict
        Dictionary with source information keys: "file", "line", optionally "source".
        Empty dict if source is None.

    Raises
    ------
    ValueError
        If the item has no source attribute.
    """
    if not hasattr(item, "source"):
        raise ValueError(f"Item {item} has no source")
    elif item.source is None:
        return {}
    elif debugging.DEBUG:
        source = item.source.block
        if source:
            return {"file": source.file, "line": source.line, "source": source.source}
        else:
            return {"file": item.source.file, "line": item.source.line}
    else:
        return {"file": item.source.file, "line": item.source.line}
