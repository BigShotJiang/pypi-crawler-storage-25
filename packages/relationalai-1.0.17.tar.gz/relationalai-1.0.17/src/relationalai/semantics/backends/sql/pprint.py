"""Pretty printer for SQL backend intermediate data structures."""
from __future__ import annotations

import io
from math import floor
from typing import Any

from ...metamodel import metamodel as mm
from ...metamodel.metamodel_analyzer import RelationAnalysis
from .sql_ir import (
    SQLBinaryOp, SQLCast, SQLColumnRef, SQLConcat, SQLCreateView, SQLExists,
    SQLExpr, SQLFromItem, SQLFunctionCall, SQLIsNotNull, SQLJoin, SQLLiteral,
    SQLNot, SQLOrderItem, SQLPlaceholder, SQLQuery, SQLSelectItem, SQLSelectQuery,
    SQLSingletonSource, SQLSource, SQLStar, SQLSubquerySource, SQLTableFunctionSource,
    SQLTableSource, SQLTryCast, SQLUnboundVar, SQLUnionQuery, SQLValuesSource,
    SQLWindowCall,
)
from .catalog_builder import Catalog, DataStore, EntityStore, RelationStore, StoreColumn
from .stratifier import DependencyEdge
from .artifacts import (
    Contribution, ExecutionPlan, ModelPlan, NormalizedSQLBlock, PlannedTarget,
    RecursiveComponentPlan, RecursiveTargetPlan, SCCGraph, SemiNaiveLoop, SemiNaiveTable,
    SQLExecutionStep, Target, TargetPlan, CoalescedBlock, View,
)

_INDENT = "  "


def pprint(obj: Any, *, indent: int = 0) -> str:
    """Return a pretty-printed string for an SQL backend intermediate data structure."""
    buf = io.StringIO()
    _write(buf, obj, indent)
    return buf.getvalue()


def _ind(n: int) -> str:
    return _INDENT * n


def _sql_to_pretty(obj: Any, dialect: str = "duckdb") -> str:
    """Emit a SQL IR object to a SQL string, pretty-printed via sqlglot for complete statements."""
    from sqlglot import parse_one
    from .emitter import SQLEmitter
    from .sql_backend import SQLBackend
    emitter = SQLEmitter(SQLBackend())

    # Complete statements: emit then reformat via sqlglot
    if isinstance(obj, (SQLCreateView, SQLQuery)):
        sql = emitter.emit(obj)
        try:
            return parse_one(sql, read=dialect).sql(dialect=dialect, pretty=True)
        except Exception:
            return sql

    # Expressions: emit inline
    if isinstance(obj, SQLExpr):
        return emitter.emit_expr(obj)

    # Select / order items
    if isinstance(obj, SQLSelectItem):
        return emitter._emit_select_item(obj)
    if isinstance(obj, SQLOrderItem):
        return emitter._emit_order_item(obj)

    # Sources
    if isinstance(obj, SQLSource):
        return emitter._emit_source(obj)

    # From / join fragments
    if isinstance(obj, SQLFromItem):
        src = emitter._emit_source(obj.source)
        return f"{src} AS {obj.alias}"
    if isinstance(obj, SQLJoin):
        src = emitter._emit_source(obj.source)
        on = " AND ".join(emitter._emit_condition(c) for c in obj.conditions) if obj.conditions else "TRUE"
        return f"{obj.kind} {src} AS {obj.alias} ON {on}"

    return object.__repr__(obj)


def _write(buf: io.StringIO, obj: Any, indent: int) -> None:  # noqa: C901
    pad = _ind(indent)
    child = _ind(indent + 1)
    grandchild = _ind(indent + 2)

    # ---- mm types: skip Tasks, show others briefly ----

    if isinstance(obj, mm.Task):
        from ...metamodel.pprint import format as mm_format
        buf.write(mm_format(obj, indent=floor(indent/2)))
        buf.write("\n")
        return

    if isinstance(obj, mm.Table):
        buf.write(f"{pad}Table({obj.name!r})\n")
        return

    if isinstance(obj, mm.Relation):
        buf.write(f"{pad}Relation({obj.name!r}, id={obj.id})\n")
        return

    if isinstance(obj, mm.Field):
        buf.write(f"{pad}Field({obj.name!r})\n")
        return

    # ---- primitives ----

    if isinstance(obj, (str, int, float, bool, type(None))):
        buf.write(f"{pad}{obj!r}\n")
        return

    # ---- collections ----

    if isinstance(obj, (tuple, list)):
        if not obj:
            buf.write(f"{pad}[]\n")
            return
        buf.write(f"{pad}[\n")
        for item in obj:
            _write(buf, item, indent + 1)
        buf.write(f"{pad}]\n")
        return

    if isinstance(obj, dict):
        if not obj:
            buf.write(f"{pad}{{}}\n")
            return
        buf.write(f"{pad}{{\n")
        for k, v in obj.items():
            buf.write(f"{child}{k!r}:\n")
            _write(buf, v, indent + 2)
        buf.write(f"{pad}}}\n")
        return

    if isinstance(obj, set):
        if not obj:
            buf.write(f"{pad}set()\n")
            return
        buf.write(f"{pad}{{\n")
        for item in sorted(repr(x) for x in obj):
            buf.write(f"{child}{item}\n")
        buf.write(f"{pad}}}\n")
        return

    # ---- SQL IR: expressions ----

    if isinstance(obj, SQLStar):
        buf.write(f"{pad}*\n")
        return

    if isinstance(obj, SQLLiteral):
        buf.write(f"{pad}SQLLiteral({obj.value!r})\n")
        return

    if isinstance(obj, SQLColumnRef):
        ref = f"{obj.table_alias}.{obj.column_name}" if obj.table_alias else obj.column_name
        buf.write(f"{pad}SQLColumnRef({ref!r})\n")
        return

    if isinstance(obj, SQLBinaryOp):
        buf.write(f"{pad}SQLBinaryOp({obj.operator!r})\n")
        buf.write(f"{child}left:\n")
        _write(buf, obj.left, indent + 2)
        buf.write(f"{child}right:\n")
        _write(buf, obj.right, indent + 2)
        return

    if isinstance(obj, SQLFunctionCall):
        type_part = f", type={obj.sql_type!r}" if obj.sql_type else ""
        buf.write(f"{pad}SQLFunctionCall({obj.name!r}{type_part})\n")
        if obj.args:
            buf.write(f"{child}args:\n")
            for arg in obj.args:
                _write(buf, arg, indent + 2)
        return

    if isinstance(obj, SQLCast):
        buf.write(f"{pad}SQLCast(as {obj.type_name!r})\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    if isinstance(obj, SQLTryCast):
        buf.write(f"{pad}SQLTryCast(as {obj.type_name!r})\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    if isinstance(obj, SQLIsNotNull):
        buf.write(f"{pad}SQLIsNotNull\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    if isinstance(obj, SQLNot):
        buf.write(f"{pad}SQLNot\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    if isinstance(obj, SQLExists):
        buf.write(f"{pad}SQLExists\n")
        buf.write(f"{child}query:\n")
        _write(buf, obj.query, indent + 2)
        return

    if isinstance(obj, SQLConcat):
        buf.write(f"{pad}SQLConcat\n")
        if obj.args:
            buf.write(f"{child}args:\n")
            for arg in obj.args:
                _write(buf, arg, indent + 2)
        return

    if isinstance(obj, SQLPlaceholder):
        buf.write(f"{pad}SQLPlaceholder({obj.name!r})\n")
        return

    if isinstance(obj, SQLUnboundVar):
        buf.write(f"{pad}SQLUnboundVar({obj.name!r})\n")
        return

    if isinstance(obj, SQLWindowCall):
        buf.write(f"{pad}SQLWindowCall({obj.function_name!r})\n")
        if obj.partition_by:
            buf.write(f"{child}partition_by:\n")
            for expr in obj.partition_by:
                _write(buf, expr, indent + 2)
        if obj.order_by:
            buf.write(f"{child}order_by:\n")
            for item in obj.order_by:
                _write(buf, item, indent + 2)
        return

    if isinstance(obj, SQLSelectItem):
        alias_part = f" AS {obj.alias!r}" if obj.alias else ""
        buf.write(f"{pad}SQLSelectItem{alias_part}\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    if isinstance(obj, SQLOrderItem):
        direction = "DESC" if obj.descending else "ASC"
        buf.write(f"{pad}SQLOrderItem({direction})\n")
        buf.write(f"{child}expr:\n")
        _write(buf, obj.expr, indent + 2)
        return

    # ---- SQL IR: sources ----

    if isinstance(obj, SQLTableSource):
        buf.write(f"{pad}SQLTableSource({obj.name!r})\n")
        return

    if isinstance(obj, SQLSubquerySource):
        buf.write(f"{pad}SQLSubquerySource\n")
        buf.write(f"{child}query:\n")
        _write(buf, obj.query, indent + 2)
        return

    if isinstance(obj, SQLValuesSource):
        buf.write(f"{pad}SQLValuesSource(columns={list(obj.column_names)!r})\n")
        for row in obj.rows:
            buf.write(f"{child}row:\n")
            for expr in row:
                _write(buf, expr, indent + 2)
        return

    if isinstance(obj, SQLSingletonSource):
        buf.write(f"{pad}SQLSingletonSource\n")
        return

    if isinstance(obj, SQLTableFunctionSource):
        buf.write(f"{pad}SQLTableFunctionSource({obj.function_name!r})\n")
        if obj.args:
            buf.write(f"{child}args:\n")
            for arg in obj.args:
                _write(buf, arg, indent + 2)
        return

    if isinstance(obj, SQLFromItem):
        buf.write(f"{pad}SQLFromItem(alias={obj.alias!r})\n")
        buf.write(f"{child}source:\n")
        _write(buf, obj.source, indent + 2)
        return

    if isinstance(obj, SQLJoin):
        buf.write(f"{pad}SQLJoin({obj.kind!r}, alias={obj.alias!r})\n")
        buf.write(f"{child}source:\n")
        _write(buf, obj.source, indent + 2)
        if obj.conditions:
            buf.write(f"{child}conditions:\n")
            for cond in obj.conditions:
                _write(buf, cond, indent + 2)
        return

    # ---- SQL IR: queries and views — emit as formatted SQL via sqlglot ----
    # Note: check View before SQLCreateView (subclass), and SQLSelectQuery/SQLUnionQuery before SQLQuery

    if isinstance(obj, (View, SQLCreateView, SQLSelectQuery, SQLUnionQuery)):
        buf.write(f"{pad}{_sql_to_pretty(obj)}\n")
        return

    # ---- Catalog ----

    if isinstance(obj, StoreColumn):
        sem = f", sem={obj.semantic_name!r}" if obj.semantic_name else ""
        buf.write(f"{pad}⬦ StoreColumn(name={obj.name!r}, sql_type={obj.sql_type!r}{sem})\n")
        return

    if isinstance(obj, EntityStore):
        buf.write(f"{pad}⬦ EntityStore(type_name={obj.type_name!r}, type_id={obj.type_id}, object_name={obj.object_name!r})\n")
        if obj.columns:
            buf.write(f"{child}columns:\n")
            for col in obj.columns:
                _write(buf, col, indent + 2)
        return

    if isinstance(obj, RelationStore):
        buf.write(f"{pad}⬦ RelationStore(relation_name={obj.relation_name!r}, relation_id={obj.relation_id}, object_name={obj.object_name!r})\n")
        if obj.columns:
            buf.write(f"{child}columns:\n")
            for col in obj.columns:
                _write(buf, col, indent + 2)
        return

    if isinstance(obj, DataStore):
        src = f", source={obj.source_name!r}" if obj.source_name else ""
        buf.write(f"{pad}⬦ DataStore(type_name={obj.type_name!r}, type_id={obj.type_id}, object_name={obj.object_name!r}{src})\n")
        if obj.columns:
            buf.write(f"{child}columns:\n")
            for col in obj.columns:
                _write(buf, col, indent + 2)
        return

    if isinstance(obj, Catalog):
        buf.write(f"{pad}Catalog\n")
        buf.write(f"{child}entity_stores ({len(obj.entity_stores)}):\n")
        for store in obj.entity_stores:
            _write(buf, store, indent + 2)
        buf.write(f"{child}relation_stores ({len(obj.relation_stores)}):\n")
        for store in obj.relation_stores:
            _write(buf, store, indent + 2)
        buf.write(f"{child}data_stores ({len(obj.data_stores)}):\n")
        for store in obj.data_stores:
            _write(buf, store, indent + 2)
        if obj.folded_property_owner_type_ids:
            buf.write(f"{child}folded_property_owner_type_ids:\n")
            for rel_id, type_id in obj.folded_property_owner_type_ids.items():
                buf.write(f"{grandchild}relation {rel_id} -> entity store type_id {type_id}\n")
        if obj.data_column_store_type_ids:
            buf.write(f"{child}data_column_store_type_ids:\n")
            for rel_id, type_id in obj.data_column_store_type_ids.items():
                buf.write(f"{grandchild}relation {rel_id} -> data store type_id {type_id}\n")
        return

    # ---- Stratifier ----

    if isinstance(obj, DependencyEdge):
        neg = " [negated]" if obj.negated else ""
        buf.write(f"{pad}DependencyEdge(writer={obj.writer_relation_id}, reader={obj.reader_relation_id}{neg})\n")
        return

    if isinstance(obj, SCCGraph):
        buf.write(f"{pad}SCCGraph ({len(obj.sccs)} SCCs)\n")
        for i, scc in enumerate(obj.sccs):
            loop = " [self-loop]" if obj.has_self_loop[i] else ""
            stratum = obj.stratum_index_by_scc[i]
            deps = sorted(obj.dependencies[i])
            buf.write(f"{child}SCC[{i}]{loop} stratum={stratum}, relations={list(scc)!r}, deps={deps!r}\n")
        return

    # ---- Coalescer ----

    if isinstance(obj, Target):
        buf.write(f"{pad}Target({obj.kind!r}, {obj.object_name!r}, anchor={obj.anchor_id})\n")
        return

    if isinstance(obj, Contribution):
        buf.write(f"{pad}Contribution\n")
        buf.write(f"{child}target:\n")
        _write(buf, obj.target, indent + 2)
        buf.write(f"{child}task:\n")
        _write(buf, obj.task, indent + 2)
        return

    if isinstance(obj, PlannedTarget):
        rec = " [recursive]" if obj.recursive else ""
        buf.write(f"{pad}PlannedTarget{rec}\n")
        buf.write(f"{child}target:\n")
        _write(buf, obj.target, indent + 2)
        if obj.recursive_component_relation_ids:
            buf.write(f"{child}recursive_component_ids: {list(obj.recursive_component_relation_ids)!r}\n")
        buf.write(f"{child}contributions ({len(obj.contributions)}):\n")
        for c in obj.contributions:
            _write(buf, c, indent + 2)
        return

    if isinstance(obj, CoalescedBlock):
        rec = " [recursive]" if obj.recursive else ""
        buf.write(f"{pad}CoalescedBlock(index={obj.index}, reasoner_type={obj.reasoner_type}{rec})\n")
        if obj.targets:
            buf.write(f"{child}targets:\n")
            for t in obj.targets:
                _write(buf, t, indent + 2)
        return

    # ---- Artifacts ----

    if isinstance(obj, TargetPlan):
        coalesce = " [requires_coalesce]" if obj.requires_coalesce else ""
        buf.write(f"{pad}TargetPlan{coalesce}\n")
        buf.write(f"{child}target:\n")
        _write(buf, obj.target, indent + 2)
        buf.write(f"{child}output_table: {obj.output_table.name!r}\n")
        if obj.prior_table:
            buf.write(f"{child}prior_table: {obj.prior_table.name!r}\n")
        buf.write(f"{child}tasks ({len(obj.tasks)}):\n")
        for t in obj.tasks:
            _write(buf, t, indent + 2)
        return

    if isinstance(obj, RecursiveTargetPlan):
        coalesce = " [requires_coalesce]" if obj.requires_coalesce else ""
        buf.write(f"{pad}RecursiveTargetPlan{coalesce}\n")
        buf.write(f"{child}target:\n")
        _write(buf, obj.target, indent + 2)
        buf.write(f"{child}output_table: {obj.output_table.name!r}\n")
        buf.write(f"{child}marker_table: {obj.marker_table.name!r}\n")
        if obj.prior_table:
            buf.write(f"{child}prior_table: {obj.prior_table.name!r}\n")
        buf.write(f"{child}seed_tasks ({len(obj.seed_tasks)}):\n")
        for t in obj.seed_tasks:
            _write(buf, t, indent + 2)
        buf.write(f"{child}recursive_tasks ({len(obj.recursive_tasks)}):\n")
        for t in obj.recursive_tasks:
            _write(buf, t, indent + 2)
        return

    if isinstance(obj, RecursiveComponentPlan):
        buf.write(f"{pad}RecursiveComponentPlan(relations={list(obj.relation_ids)!r})\n")
        if obj.targets:
            buf.write(f"{child}targets:\n")
            for t in obj.targets:
                _write(buf, t, indent + 2)
        return

    if isinstance(obj, NormalizedSQLBlock):
        rec = " [recursive]" if obj.recursive else ""
        buf.write(f"{pad}NormalizedSQLBlock(index={obj.index}{rec})\n")
        if obj.items:
            buf.write(f"{child}items:\n")
            for item in obj.items:
                _write(buf, item, indent + 2)
        return

    if isinstance(obj, SemiNaiveTable):
        buf.write(f"{pad}SemiNaiveTable({obj.table_name!r}, columns={list(obj.columns)!r})\n")
        buf.write(f"{child}accum_view: {obj.accum_view_name!r}\n")
        buf.write(f"{child}delta_view: {obj.delta_view_name!r}\n")
        buf.write(f"{child}next_delta_view: {obj.next_delta_view_name!r}\n")
        buf.write(f"{child}base_query:\n")
        _write(buf, obj.base_query, indent + 2)
        buf.write(f"{child}delta_query:\n")
        _write(buf, obj.delta_query, indent + 2)
        buf.write(f"{child}merge_query:\n")
        _write(buf, obj.merge_query, indent + 2)
        buf.write(f"{child}final_query:\n")
        _write(buf, obj.final_query, indent + 2)
        return

    if isinstance(obj, SemiNaiveLoop):
        buf.write(f"{pad}SemiNaiveLoop ({len(obj.tables)} tables)\n")
        if obj.tables:
            buf.write(f"{child}tables:\n")
            for table in obj.tables:
                _write(buf, table, indent + 2)
        return

    if isinstance(obj, SQLExecutionStep):
        buf.write(f"{pad}SQLExecutionStep\n")
        if obj.views:
            buf.write(f"{child}views ({len(obj.views)}):\n")
            for view in obj.views:
                _write(buf, view, indent + 2)
        if obj.semi_naive_loops:
            buf.write(f"{child}semi_naive_loops ({len(obj.semi_naive_loops)}):\n")
            for loop in obj.semi_naive_loops:
                _write(buf, loop, indent + 2)
        return

    if isinstance(obj, ExecutionPlan):
        buf.write(f"{pad}ExecutionPlan ({len(obj.steps)} steps)\n")
        if obj.steps:
            buf.write(f"{child}steps:\n")
            for step in obj.steps:
                _write(buf, step, indent + 2)
        return

    if isinstance(obj, ModelPlan):
        buf.write(f"{pad}ModelPlan\n")
        if obj.seed_object_names:
            buf.write(f"{child}seed_object_names: {list(obj.seed_object_names)!r}\n")
        _write(buf, obj.catalog, indent + 1)
        tables = obj.version_state.latest_tables_by_relation_id
        buf.write(f"{child}tables ({len(tables)}):\n")
        for rel_id, table in tables.items():
            buf.write(f"{grandchild}{rel_id} -> {table.name!r}\n")
        buf.write(f"{child}blocks ({len(obj.blocks)}):\n")
        for block in obj.blocks:
            _write(buf, block, indent + 2)
        return

    # ---- RelationAnalysis ----

    if isinstance(obj, RelationAnalysis):
        buf.write(f"{pad}RelationAnalysis\n")
        mandatory_names = ", ".join(sorted(r.name for r in obj.mandatory))
        buf.write(f"{child}mandatory ({len(obj.mandatory)}): {mandatory_names}\n")
        buf.write(f"{child}fds ({len(obj.fds)}):\n")
        for f, deps in obj.fds.items():
            dep_names = ", ".join(d.name for d in deps)
            buf.write(f"{grandchild}{f.name!r} <- [{dep_names}]\n")
        return

    # ---- fallback ----

    buf.write(f"{pad}{obj!r}\n")


__all__ = ["pprint"]
