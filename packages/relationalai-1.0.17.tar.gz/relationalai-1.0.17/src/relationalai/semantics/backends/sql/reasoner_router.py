"""Reasoner-aware execution block routing for the SQL/Logic mixed pipeline."""
from __future__ import annotations

from bisect import insort
from dataclasses import dataclass

from ...metamodel import metamodel as mm
from .stratifier import SCCGraph

# Reasoner types that must not cross negation-stratum boundaries during block grouping.
_STRATUM_BOUNDED = {"sql"}


@dataclass(frozen=True, slots=True)
class ExecutionBlock:
    """A maximal run of same-reasoner SCCs with no forced boundary between them.

    SQL blocks never cross a stratum boundary (negation requires sequential
    SQL execution).  Logic blocks may span multiple strata.

    ``input_relation_ids``  — relation_ids produced by a *different*-reasoner
    block that this block reads.  Populated for future parallel dispatch; unused
    during sequential execution.

    ``output_relation_ids`` — relation_ids produced by this block that a
    *different*-reasoner block reads.
    """

    index: int
    reasoner_type: str  # lowercased reasoner type, e.g. "sql", "logic"
    relation_ids: tuple[int, ...]
    recursive: bool
    recursive_component_relation_ids: tuple[tuple[int, ...], ...]
    input_relation_ids: tuple[int, ...]
    output_relation_ids: tuple[int, ...]


class ReasonerRouter:
    """Partitions the SCC dependency graph into maximal same-reasoner blocks.

    Uses a reasoner-aware Kahn's topological sort: when choosing the next SCC
    from the ready queue, SCCs of the current reasoner (and, for SQL, the
    current stratum) are preferred over switching to a different reasoner.
    This maximizes logic block size while preserving all dependency constraints.
    """

    def route(
        self,
        scc_graph: SCCGraph,
        model: mm.Model,
    ) -> tuple[ExecutionBlock, ...]:
        scc_reasoner_types = self._label_reasoner_types(scc_graph, model)
        order = self._reasoner_aware_kahn(scc_graph, scc_reasoner_types)
        return self._build_blocks(order, scc_graph, scc_reasoner_types)

    def _label_reasoner_types(
        self,
        scc_graph: SCCGraph,
        model: mm.Model,
    ) -> tuple[str, ...]:
        """Return a reasoner type label for every SCC in scc_graph."""
        relation_to_type: dict[int, str] = {
            relation.id: reasoner.type.lower()
            for reasoner in model.reasoners
            for relation in reasoner.relations
        }

        result: list[str] = []
        for scc in scc_graph.sccs:
            reasoner_types = {relation_to_type.get(rid, "sql") for rid in scc}
            if len(reasoner_types) > 1:
                raise ValueError(
                    f"SCC contains relation_ids with mixed reasoner types {scc}. "
                    "All relations in a strongly-connected component must target "
                    "the same reasoner."
                )
            result.append(reasoner_types.pop())
        return tuple(result)

    def _reasoner_aware_kahn(
        self,
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
    ) -> list[int]:
        """Return a topological ordering of SCC indices that minimizes reasoner switches.

        Identical to standard Kahn's algorithm except that _pick_next replaces
        the usual "pop any ready node" step with a reasoner- and stratum-aware
        selection.  The ready list is kept sorted so that tie-breaking is
        deterministic.
        """
        n = len(scc_graph.sccs)
        indegree = [len(deps) for deps in scc_graph.dependencies]

        # adjacency[j] = SCCs that depend on j (successors)
        adjacency: dict[int, list[int]] = {i: [] for i in range(n)}
        for i, deps in enumerate(scc_graph.dependencies):
            for j in deps:
                adjacency[j].append(i)

        ready: list[int] = sorted(i for i in range(n) if indegree[i] == 0)
        order: list[int] = []

        while ready:
            chosen = self._pick_next(ready, order, scc_graph, scc_reasoner_types)
            ready.remove(chosen)
            order.append(chosen)
            for succ in adjacency[chosen]:
                indegree[succ] -= 1
                if indegree[succ] == 0:
                    insort(ready, succ)

        return order

    def _pick_next(
        self,
        ready: list[int],
        order: list[int],
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
    ) -> int:
        """Choose the next SCC to emit from the ready list.

        Prefers a candidate that continues the current reasoner run:
        - Must match the reasoner type of the last emitted SCC.
        - For SQL, must also stay within the same stratum (negation stratification
          requires all SCCs in a stratum to be fully computed before the next stratum
          begins; The logic reasoner handles stratification internally so this constraint is
          not applied there).

        Falls back to ready[0] (lowest index) when no compatible candidate exists,
        which forces a block boundary and starts a new run deterministically.
        """
        if not order:
            return ready[0]

        current_reasoner_type = scc_reasoner_types[order[-1]]
        current_stratum = scc_graph.stratum_index_by_scc[order[-1]]

        # Prefer same reasoner; for stratum-bounded reasoners also require same stratum.
        for candidate in ready:
            if scc_reasoner_types[candidate] != current_reasoner_type:
                continue
            if current_reasoner_type in _STRATUM_BOUNDED and scc_graph.stratum_index_by_scc[candidate] != current_stratum:
                continue
            return candidate

        # No compatible candidate — must start a new block; pick lowest index.
        return ready[0]

    def _build_blocks(
        self,
        order: list[int],
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
    ) -> tuple[ExecutionBlock, ...]:
        """Convert the ordered SCC list into maximal same-reasoner ExecutionBlocks.

        Consecutive SCCs that share a reasoner type (and, for SQL, a stratum) are
        merged into a single block.  For each block the method also computes:
        - relation_ids: flat list of all relation IDs owned by the block.
        - recursive / recursive_component_relation_ids: whether the block
          contains any recursive SCC and which relation groups participate.
        - input_relation_ids / output_relation_ids: relations that cross a
          reasoner boundary, used for future parallel dispatch between engines.
        """
        if not order:
            return ()

        # Group consecutive compatible SCCs into blocks.
        raw_blocks: list[list[int]] = [[order[0]]]
        for scc_idx in order[1:]:
            last_block = raw_blocks[-1]
            last_scc = last_block[-1]
            last_reasoner_type = scc_reasoner_types[last_scc]
            last_stratum = scc_graph.stratum_index_by_scc[last_scc]

            reasoner_type = scc_reasoner_types[scc_idx]
            stratum = scc_graph.stratum_index_by_scc[scc_idx]

            same_reasoner = reasoner_type == last_reasoner_type
            # Stratum-bounded reasoners (e.g. SQL) must not cross stratum boundaries.
            same_stratum_or_unbounded = reasoner_type not in _STRATUM_BOUNDED or stratum == last_stratum

            if same_reasoner and same_stratum_or_unbounded:
                last_block.append(scc_idx)
            else:
                raw_blocks.append([scc_idx])

        # Map SCC index → block index for cross-block wiring.
        scc_to_block: dict[int, int] = {
            scc_idx: block_idx
            for block_idx, scc_indexes in enumerate(raw_blocks)
            for scc_idx in scc_indexes
        }

        # Compute cross-reasoner input/output relation sets.
        block_inputs: list[set[int]] = [set() for _ in raw_blocks]
        block_outputs: list[set[int]] = [set() for _ in raw_blocks]

        for i, deps in enumerate(scc_graph.dependencies):
            block_i = scc_to_block[i]
            for j in deps:
                block_j = scc_to_block[j]
                if block_i != block_j and scc_reasoner_types[i] != scc_reasoner_types[j]:
                    # SCC j is in a different-reasoner block that block_i reads.
                    block_j_relation_ids = set(scc_graph.sccs[j])
                    block_inputs[block_i].update(block_j_relation_ids)
                    block_outputs[block_j].update(block_j_relation_ids)

        blocks: list[ExecutionBlock] = []
        for block_idx, scc_indexes in enumerate(raw_blocks):
            reasoner_type = scc_reasoner_types[scc_indexes[0]]
            all_relation_ids: list[int] = [
                rid
                for scc_idx in scc_indexes
                for rid in scc_graph.sccs[scc_idx]
            ]

            # Each recursive SCC's component is exactly the SCC itself
            # (already sorted by Tarjan's algorithm).
            seen_components: set[tuple[int, ...]] = set()
            recursive_components: list[tuple[int, ...]] = []
            is_recursive = False
            for scc_idx in scc_indexes:
                if not (scc_graph.has_self_loop[scc_idx] or len(scc_graph.sccs[scc_idx]) > 1):
                    continue
                is_recursive = True
                component_t = scc_graph.sccs[scc_idx]
                if component_t not in seen_components:
                    recursive_components.append(component_t)
                    seen_components.add(component_t)

            blocks.append(ExecutionBlock(
                index=block_idx,
                reasoner_type=reasoner_type,
                relation_ids=tuple(sorted(all_relation_ids)),
                recursive=is_recursive,
                recursive_component_relation_ids=tuple(recursive_components),
                input_relation_ids=tuple(sorted(block_inputs[block_idx])),
                output_relation_ids=tuple(sorted(block_outputs[block_idx])),
            ))

        return tuple(blocks)


__all__ = ["ReasonerRouter", "ExecutionBlock"]
