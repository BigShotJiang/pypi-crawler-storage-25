"""Build the LR (logic-reasoner) payload for a single coalesced block.

Pipeline context
----------------
The compiler splits a model into ``CoalescedBlock``s. Blocks whose reasoner
type is ``"logic"`` are handed to this builder; the SQL-typed blocks go through
the storage normalizer + lowerer instead. For each logic block we must produce
a :class:`LogicBlock` that the LR executor understands, which has three pieces:

* ``install_root``      — the program to compile and install into the LR backend.
                          It *writes* the block's results into the physical
                          output relations owned by this block.
* ``export_query``      — a small read-back program we hand to the v0
                          ``LegacyExecutor``. It reads from the physical
                          output relations and writes into an output binding
                          shaped the way v0's executor expects, which is how
                          results actually land in the Snowflake tables
                          downstream (SQL-typed) blocks consume.
* ``output_table_names``— the catalog names the LR backend materializes, so
                          the orchestrator can stitch LR outputs back into the
                          shared ``BlockVersionState`` and let later blocks
                          find them.

Terminology
-----------
Throughout this file "legacy" means **v0-shaped**: the output-binding
convention the v0 ``LegacyExecutor`` understands (one ``Table`` plus one
``Relation`` per column, keyed on a row ``Var``). It is not "deprecated" —
it is the interop shape for the still-active v0 execution path.
"""

from __future__ import annotations

from relationalai.semantics import metamodel as mm
from relationalai.semantics.backends.sql.normalizer import _RelationVersionRewriter, StorageVersionNormalizer
from relationalai.semantics.metamodel.builtins import builtins as bt
from relationalai.semantics.backends.sql.artifacts import BlockVersionState, Catalog, CoalescedBlock, LogicBlock, PlannedTarget, Target

class LogicBlockBuilder:
    """Translate one ``CoalescedBlock`` into a ``LogicBlock`` for the LR backend.

    The builder borrows heavily from :class:`StorageVersionNormalizer`: the two
    backends share how they resolve physical output tables, how they split
    entity targets across constructs, and how they assemble the "row" update
    used by downstream consumers. Rather than duplicate that logic, this class
    delegates to normalizer helpers and focuses on what is LR-specific:

    * rewriting input lookups to the *latest* materialized table for each
      relation (inputs may have been produced by earlier SQL blocks),
    * producing a separate read-back/export program, since LR and SQL live
      in different engines and results must be bridged back via SQL tables.
    """

    def __init__(self, normalizer: StorageVersionNormalizer) -> None:
        self._normalizer = normalizer


    def build(
        self,
        planned_block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
    ) -> LogicBlock | None:
        """Assemble the full ``LogicBlock`` payload for one logic-reasoner block.

        High-level flow, per target in the block:

        1. Resolve the *physical* output table (the concrete table the LR
           backend will write into).
        2. Build the install tasks that populate that physical table — these
           are the block's contributions, with their relation lookups rewritten
           to point at the latest materialized input tables so the LR program
           reads the right upstream snapshot.
        3. Build the export tasks that read from the physical output and
           write into a v0-shaped output binding, which the v0
           ``LegacyExecutor`` then runs to materialize the Snowflake table
           later blocks can consume.
        4. Register the target's output relations in ``version_state`` so
           downstream blocks can find them by relation id.

        Returns ``None`` when there is nothing to install or export (empty
        block, or all contributions dropped during rewrite)."""
        if not planned_block.targets:
            return None

        # Snapshot the input tables this block should read from. We freeze the
        # versions *before* we start emitting install tasks so that all targets
        # in this block see a consistent upstream view, even as we later bind
        # this block's own outputs back into the shared version_state.
        input_relation_tables = {
            rid: table
            for rid in planned_block.input_relation_ids
            if (table := version_state.latest_table_for(rid)) is not None
        }
        input_version_state = BlockVersionState(
            latest_tables_by_relation_id=dict(input_relation_tables),
            entry_tables_by_relation_id=dict(input_relation_tables),
        )

        install_tasks: list[mm.Logical] = []
        export_tasks: list[mm.Logical] = []
        bound_object_names: set[str] = set()
        for planned_target in planned_block.targets:
            target = planned_target.target
            object_name = target.object_name
            # The "physical" output table is what the LR backend materializes.
            # Multiple targets can share an object_name (e.g. several entity
            # properties living in one table), which is why we de-duplicate
            # the bind step below on object_name.
            physical_output_table = self._normalizer._output_table_for_target(
                target,
                object_name,
                model,
                catalog,
            )
            install_tasks.extend(
                self._prepare_logic_target_install_tasks(
                    planned_target,
                    physical_output_table,
                    input_version_state,
                )
            )
            export_tasks.extend(
                self._build_lqp_export_tasks(target, physical_output_table)
            )
            if object_name not in bound_object_names:
                # Publish this target's outputs into the shared version_state
                # so later blocks can resolve these relation ids to tables.
                self._normalizer._bind_target_relations(
                    target,
                    model,
                    catalog,
                    version_state,
                    object_name,
                )
                bound_object_names.add(object_name)

        if not install_tasks or not export_tasks:
            return None

        return LogicBlock(
            install_root=mm.Logical(body=tuple(install_tasks), scope=True),
            export_query=mm.Logical(body=tuple(export_tasks), scope=True),
            output_table_names=tuple(sorted(bound_object_names)),
        )

    def _prepare_logic_target_install_tasks(
        self,
        planned_target: PlannedTarget,
        physical_output_table: mm.Table,
        input_version_state: BlockVersionState,
    ) -> tuple[mm.Logical, ...]:
        """Turn each contribution into an install task the LR backend can run.

        A "contribution" is one rule-like task from the source model that
        writes into this target. Two things happen per contribution:

        * **Version rewrite.** Every ``Lookup`` inside the task is retargeted
          from the logical relation to the concrete input table we froze at
          the start of :meth:`build`. Without this the LR program would refer
          to abstract relations with no backing storage.
        * **Entity splitting.** For entity targets a single contribution may
          construct and populate one entity; the shared normalizer helper
          splits it into one install task per constructed owner so each
          installed task is focused on a single entity key. Relation targets
          pass through as-is.
        """
        install_tasks: list[mm.Logical] = []
        for contribution in planned_target.contributions:
            rewritten_task = _RelationVersionRewriter(
                input_version_state,
                target=None,
                recursive_relation_tables=None,
            ).rewrite_task(contribution.task)
            rewritten_task = rewritten_task if isinstance(rewritten_task, mm.Logical) else None
            if rewritten_task is None:
                continue
            split_tasks = (
                self._normalizer._split_entity_task(rewritten_task, physical_output_table)
                if planned_target.target.kind == "entity"
                else (rewritten_task,)
            )
            install_tasks.extend(split_tasks)
        return tuple(install_tasks)

    def _build_lqp_export_tasks(
        self,
        target: Target,
        physical_output_table: mm.Table,
    ) -> tuple[mm.Logical, ...]:
        """Produce the read-back task that bridges LR outputs into a v0 binding.

        The LR backend materializes results in its own physical tables, but
        the export step is executed by the v0 ``LegacyExecutor``, which
        expects output bindings in its own shape. Export is a two-step
        construction:

        1. :meth:`_build_lqp_export_lookups` emits the pure-read program over
           the physical output relations *and* returns the per-column row
           values those lookups bind.
        2. :meth:`_bind_legacy_output_task` wraps those lookups with the
           row-key/construct bookkeeping that reshapes the row values into
           the v0 output binding.
        """
        lookups, row_values = self._build_lqp_export_lookups(target, physical_output_table)
        return (
            self._bind_legacy_output_task(
                lookups,
                row_values,
                target,
                physical_output_table,
            ),
        )

    def _build_lqp_export_lookups(
        self,
        target: Target,
        physical_output_table: mm.Table,
    ) -> tuple[tuple[mm.Task, ...], tuple[mm.Value, ...]]:
        """Emit read-only lookups over the physical outputs and return row values.

        Returns ``(lookups, row_values)`` where

        * ``lookups`` is the body of ``Lookup`` nodes that read every cell
          the LR backend wrote, and
        * ``row_values`` is the tuple of vars those lookups bind, in
          ``target.column_names`` order — exactly what the v0-shaped output
          binding needs to write a row.

        Contract with ``_output_table_for_target`` / ``_relations_for_target``
        ------------------------------------------------------------------
        The ``physical_output_table.columns`` tuple read here is populated
        upstream by :meth:`StorageVersionNormalizer._relations_for_target`,
        whose shape depends on ``target.kind``:

        * ``target.kind == "relation"`` → exactly one relation, with every
          output column represented as a *field* on that single relation.
        * ``target.kind == "entity"`` → the first relation is the owner
          (entity-id) relation, and the remaining relations are one-per-
          folded-property, each with shape ``(owner, value)``.
        """
        relations = tuple(physical_output_table.columns)
        if not relations:
            raise ValueError("relations cannot be None.")

        if target.kind == "relation":
            # Single relation; its fields carry the column types. The args
            # we bind via Lookup are the row values, in field order which
            # matches target.column_names by construction.
            relation = relations[0]
            args = tuple(
                mm.Var(type=field.type, name=field.name or f"arg_{index}")
                for index, field in enumerate(relation.fields, start=1)
            )
            return (mm.Lookup(relation=relation, args=args),), args

        elif target.kind == "entity":
            # Owner relation first (binds the entity-id var that keys every
            # following attribute lookup), then one (owner, value) relation
            # per folded property. We collect row values by column name so
            # that the final tuple can be reordered to target.column_names
            # (which starts with "_id" and may list properties in any order).
            owner_relation = relations[0]
            owner_field = owner_relation.fields[-1]
            owner_var = mm.Var(type=owner_field.type, name=owner_field.name or owner_relation.name.lower())
            lookups: list[mm.Task] = [mm.Lookup(relation=owner_relation, args=(owner_var,))]
            values_by_column: dict[str, mm.Value] = {"_id": owner_var}
            for relation in relations[1:]:
                value_field = relation.fields[-1]
                value_var = mm.Var(type=value_field.type, name=value_field.name or relation.name.lower())
                lookups.append(mm.Lookup(relation=relation, args=(owner_var, value_var)))
                values_by_column[relation.name] = value_var

            row_values = tuple(
                values_by_column.get(column_name, mm.Literal(None))  # type: ignore[arg-type]
                for column_name in target.column_names
            )
            return tuple(lookups), row_values

        else:
            raise ValueError(f"Unknown target kind {target.kind!r} for {target.object_name!r}.")

    def _bind_legacy_output_task(
        self,
        lookups: tuple[mm.Task, ...],
        row_values: tuple[mm.Value, ...],
        target: Target,
        physical_output_table: mm.Table,
    ) -> mm.Logical:
        """Wrap ``lookups`` with the bookkeeping that writes into the v0 binding.

        The v0 executor represents a row as: one table-typed row var, plus
        one per-column relation of shape ``(row_var, value)``. Getting from
        ``row_values`` to that representation requires:

        * Turning any non-``Var`` value into a ``Var`` bound by an ``eq``
          lookup, because ``Construct`` needs ``Var`` inputs as its
          id-generator keys.
        * Emitting a ``Construct`` to mint the row var deterministically
          from those keys, an ``Update`` to insert the row, and per-column
          ``Update``s to populate each attribute.
        """
        output_table = self._legacy_output_table(target, physical_output_table)
        table_var = mm.Var(
            type=output_table,
            name=f"{output_table.name.rsplit('.', 1)[-1].lower()}__row",
        )
        key_bindings, key_values = self._bind_output_key_values(row_values, table_var.name)
        body: list[mm.Task] = [
            *lookups,
            *key_bindings,
            mm.Construct(values=key_values, id_var=table_var),
            mm.Update(relation=output_table, args=(table_var,)),
        ]
        for column_relation, value in zip(output_table.columns, row_values):
            body.append(mm.Update(relation=column_relation, args=(table_var, value)))
        return mm.Logical(body=tuple(body))

    def _bind_output_key_values(
        self,
        row_values: tuple[mm.Value, ...],
        table_var_name: str,
    ) -> tuple[tuple[mm.Lookup, ...], tuple[mm.Value, ...]]:
        """Coerce row values into ``Var``s suitable for ``Construct`` keys.

        ``Construct`` deterministically derives an id from a tuple of ``Var``
        inputs, so any literal or expression we want to use as a key must
        first be bound to a fresh ``Var`` via an ``eq`` lookup. Values that
        are already ``Var``s pass through untouched.

        Returns ``(eq_lookups_to_prepend, key_vars_in_original_order)``.
        """
        bindings: list[mm.Lookup] = []
        key_values: list[mm.Value] = []
        for index, value in enumerate(row_values, start=1):
            if isinstance(value, mm.Var):
                key_values.append(value)
                continue
            bound_var = mm.Var(
                type=getattr(value, "type", mm.TypeNode()),
                name=f"{table_var_name}__key_{index}",
            )
            bindings.append(mm.Lookup(relation=bt.core.eq, args=(bound_var, value)))
            key_values.append(bound_var)
        return tuple(bindings), tuple(key_values)

    def _legacy_output_table(self, target: Target, physical_output_table: mm.Table) -> mm.Table:
        """Construct the v0-shaped output table that mirrors the physical output.

        This is the shape the v0 ``LegacyExecutor`` expects when it runs the
        export query: one ``Table`` plus one ``Relation`` per column, each
        keyed on a row-typed ``Var`` with the value field typed from the
        corresponding physical column. Mirroring the physical table 1:1 (same
        column names and types) is what lets an LR-produced output slot into
        the same downstream plumbing a SQL-produced output would use.
        """
        output_name = target.object_name
        table = mm.Table(name=output_name, uri=f"table://{output_name}")
        columns: list[mm.Relation] = []
        for column_name, column_relation in zip(target.column_names, physical_output_table.columns):
            value_type = column_relation.fields[-1].type
            columns.append(mm.Relation(
                name=column_name,
                fields=(
                    mm.Field(name="table", type=table),
                    mm.Field(name=column_name, type=value_type),
                ),
            ))
        table._force_columns(tuple(columns))
        return table
    