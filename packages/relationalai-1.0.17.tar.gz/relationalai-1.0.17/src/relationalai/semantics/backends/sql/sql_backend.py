from __future__ import annotations

from typing import TYPE_CHECKING
from pandas import DataFrame

from relationalai.config.config import Config
from relationalai.config.connections.snowflake import SnowflakeConnection

if TYPE_CHECKING:
    from .artifacts import SemiNaiveLoop
    from .emitter import SQLEmitter

class SQLBackend:

    #------------------------------------------------------
    # Dialect handling
    #------------------------------------------------------
    def dialect_name(self) -> str:
        raise NotImplementedError

    def normalize_schema_name(self, name) -> str:
        return name

    def normalize_column_name(self, name: str) -> str:
        if name.startswith('"') and name.endswith('"'):
            return name[1:-1]
        return name

    def format_table_name(self, name: str) -> str:
        return name

    def quote_table_name(self, name: str) -> str:
        return name

    def quote_identifier(self, name: str) -> str:
        escaped = name.replace('"', '""')
        return f'"{escaped}"'

    def quote_path(self, path: str) -> str:
        return ".".join(self.quote_identifier(part) for part in path.split("."))

    def materialize_install_views_as_tables(self) -> bool:
        """Return True to emit install-time views as CREATE TABLE instead of CREATE VIEW."""
        return False

    def emit_create_statement(self, name: str, query_sql: str) -> str:
        """Return the full DDL string to create (or replace) the given view/table."""
        ddl = "TABLE" if self.materialize_install_views_as_tables() else "VIEW"
        return f"CREATE OR REPLACE {ddl} {self.quote_table_name(name)} AS\n{query_sql}"

    #------------------------------------------------------
    # Metadata fetching
    #------------------------------------------------------

    def fetch_schema(self, database: str, schema: str, table: str) -> dict[str, type | str]:
        raise NotImplementedError
    
    def resolve_model_schema(self, config: Config | None) -> str | None:
        if config is None:
            return None
        schema_name = config.model.schema_
        if schema_name is None or not schema_name.strip():
            return None
        conn = config.get_default_connection()
        if isinstance(conn, SnowflakeConnection):
            database_name = conn.database
            if database_name:
                schema_name = f"{database_name}.{schema_name}"
        schema_name = self.normalize_schema_name(schema_name.strip())
        return schema_name
        

    #------------------------------------------------------
    # SQL execution
    #------------------------------------------------------

    def execute_sql(self, sql: str) -> DataFrame:
        raise NotImplementedError

    def execute_sql_batch(self, statements: list[str]) -> None:
        raise NotImplementedError

    #------------------------------------------------------
    # Semi-naive execution
    #------------------------------------------------------

    def build_semi_naive_plan(self, loop: "SemiNaiveLoop", emitter: "SQLEmitter") -> object:
        """Emit a dialect-specific plan object which specifies how to execute a semi-naive
        loop."""
        raise NotImplementedError(
            f"build_semi_naive_plan is not supported for dialect '{self.dialect_name()}'."
        )

    def execute_semi_naive(self, plan: object) -> None:
        """Execute a pre-built semi-naive plan."""
        raise NotImplementedError(
            f"execute_semi_naive is not supported for dialect '{self.dialect_name()}'."
        )
