from __future__ import annotations

from pandas import DataFrame

from relationalai.semantics.metamodel.metamodel_analyzer import RelationAnalyzer

from .executor import MetamodelExecutor, add_to_span
from ...config.config import Config
from ..metamodel import metamodel as mm
from v0.relationalai import debugging

from .sql.artifacts import ModelPlan
from .sql.orchestrator import Orchestrator, SnowflakeOrchestrator
from ...config.connections.snowflake import SnowflakeConnection
from .logic_executor import LogicExecutor

from .sql.catalog_builder import CatalogBuilder
from .sql.stratifier import Stratifier
from .sql.reasoner_router import ReasonerRouter
from .sql.coalescer import Coalescer
from .sql.normalizer import StorageVersionNormalizer


class MultiReasonerExecutor(MetamodelExecutor):
    """Executor that owns the compilation pipeline, install loop, and query execution."""

    def __init__(self, config: Config, model_config: Config) -> None:
        from .sql_executor import SQLExecutor
        self._config = config
        self._model_config = model_config
        self._install_result: ModelPlan | None = None
        self._show_debug_logs = bool(getattr(config.debug, "show_debug_logs", False))
        self._dry_run = bool(getattr(getattr(self._config, "compiler", None), "dry_run", False))
        self._sf_database_name = self._resolve_model_database()
        if not self._sf_database_name:
            self._sf_database_name = "default"
        self._sql_executor = SQLExecutor(config, model_config)
        self._logic_executor: LogicExecutor = LogicExecutor(self._config, self._sf_database_name)

        self._relation_analyzer = RelationAnalyzer()
        self._catalog_builder = CatalogBuilder()
        self._stratifier = Stratifier()
        self._reasoner_router = ReasonerRouter()
        self._coalescer = Coalescer()
        self._storage_normalizer = StorageVersionNormalizer()

    def create_model_plan(self, model: mm.Model) -> ModelPlan:
        with debugging.span("Relation Analyzer"):
            relation_analysis = self._relation_analyzer.analyze(model)
        with debugging.span("Catalog Builder") as span:
            catalog = self._catalog_builder.build(
                model, relation_analysis, schema_name=self._sql_executor.schema_name
            )
            add_to_span(span, catalog, "result")
        with debugging.span("Stratifier") as span:
            scc_graph = self._stratifier.build_scc_graph(model, catalog)
            add_to_span(span, scc_graph, "result")
        with debugging.span("Reasoner Router") as span:
            blocks = self._reasoner_router.route(scc_graph, model)
            add_to_span(span, blocks, "result")
        with debugging.span("Coalescer") as span:
            coalesced_blocks = self._coalescer.plan(model, catalog, blocks)
            add_to_span(span, coalesced_blocks, "result")

        version_state = self._storage_normalizer.initial_version_state(model, catalog)
        seed_object_names = self._storage_normalizer.compute_seed_object_names(
            model, catalog, coalesced_blocks
        )
        return ModelPlan(
            catalog=catalog,
            blocks=tuple(coalesced_blocks),
            version_state=version_state,
            seed_object_names=seed_object_names,
        )

    def install(self, model: mm.Model, **kwargs) -> None:
        model_plan = self.create_model_plan(model)
        orch: Orchestrator | None = None
        if not self._dry_run:
            self._sql_executor.ensure_schema_exists()
            orch = self._create_orchestrator()

        # Seed views (always SQL)
        seed_plan = self._sql_executor.plan_seed_views(
            model_plan.seed_object_names, model_plan.catalog
        )
        if seed_plan and not self._dry_run:
            assert orch is not None
            orch.register_sql_block(-1, seed_plan)
            self._sql_executor.execute_block(seed_plan)

        for block in model_plan.blocks:
            if block.reasoner_type == "sql":
                sql_plan = self._sql_executor.plan_block(
                    block, model, model_plan.catalog, model_plan.version_state,
                    self._storage_normalizer, self._show_debug_logs,
                )
                if not self._dry_run:
                    assert orch is not None
                    orch.register_sql_block(block.index, sql_plan)
                    self._sql_executor.execute_block(sql_plan)
            elif block.reasoner_type == "logic":
                logic_block = self._logic_executor.plan_block(
                    block, 
                    model,
                    model_plan.catalog,
                    model_plan.version_state,
                    self._storage_normalizer
                )
                if logic_block is not None and not self._dry_run:
                    assert orch is not None
                    run_sql = self._logic_executor.plan_lqp_sql(
                        (self._sql_executor.schema_name or "default") + "_meta", 
                        block.index, 
                        logic_block, 
                        model
                    )
                    orch.register_logic_block(block.index, logic_block.lqp_plan.output_table_names, run_sql)
                    self._logic_executor.execute_block(logic_block, mm_model=model )
            else:
                raise RuntimeError(
                    f"Unsupported reasoner '{block.reasoner_type}'. "
                    "Supported reasoners are 'sql' and 'logic'."
                )

        if not self._dry_run and orch is not None:
            orch.finalize()
        self._install_result = model_plan

    def _create_orchestrator(self) -> Orchestrator:
        conn = self._config.get_default_connection()
        if isinstance(conn, SnowflakeConnection):
            return SnowflakeOrchestrator(
                session=conn.get_session(),
                app_name=conn.rai_app_name,
                execute_sql=self._sql_executor.execute_sql,
                meta_schema=(self._sql_executor.schema_name or "default") + "_meta",
                schedule_cfg=getattr(self._config, "schedule", None),
            )
        return Orchestrator()

    def execute_query(self, model: mm.Model, query: mm.Task, **kwargs) -> DataFrame:
        assert self._install_result is not None, "Model must be installed before executing queries."
        return self._sql_executor.execute_query(
            query,
            self._install_result,
            self._storage_normalizer,
            dry_run=self._dry_run,
            show_debug_logs=self._show_debug_logs,
        )

    def _resolve_model_database(self) -> str | None:
        connection = self._config.get_default_connection()
        if not isinstance(connection, SnowflakeConnection):
            return None
        return connection.database
    