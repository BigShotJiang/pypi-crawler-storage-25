"""Coalescing pass for sql9 model contributions."""
from __future__ import annotations

from dataclasses import dataclass

from ...metamodel import metamodel as mm
from .catalog import Catalog
from .dependency import Stratum


@dataclass(frozen=True, slots=True)
class Target:
    kind: str
    object_name: str
    column_names: tuple[str, ...]
    key_columns: tuple[str, ...]
    anchor_id: int
    relation_ids: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class Contribution:
    target: Target
    task: mm.Logical


@dataclass(frozen=True, slots=True)
class PlannedTarget:
    target: Target
    contributions: tuple[Contribution, ...]
    recursive: bool
    recursive_component_relation_ids: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class PlannedStratum:
    index: int
    targets: tuple[PlannedTarget, ...]


class Coalescer:
    def plan(self, model: mm.Model, catalog: Catalog, strata: tuple[Stratum, ...]) -> tuple[PlannedStratum, ...]:
        rule_blocks = tuple(self._rule_blocks(model.root))
        stratum_by_relation_id = {
            relation_id: stratum.index
            for stratum in strata
            for relation_id in stratum.relation_ids
        }

        grouped: dict[int, dict[Target, list[Contribution]]] = {}
        for block in rule_blocks:
            for target in self._targets_for_block(block, catalog, model):
                projected = self._project_block(block, target, catalog)
                if projected is None:
                    continue
                stratum_index = stratum_by_relation_id.get(target.anchor_id, 0)
                grouped.setdefault(stratum_index, {}).setdefault(target, []).append(
                    Contribution(target=target, task=projected)
                )

        planned: list[PlannedStratum] = []
        strata_by_index = {stratum.index: stratum for stratum in strata}
        for stratum_index in sorted(grouped):
            targets = []
            stratum = strata_by_index.get(stratum_index, Stratum(stratum_index, (), False, ()))
            for target, contributions in grouped[stratum_index].items():
                recursive_component_relation_ids = next(
                    (
                        component
                        for component in stratum.recursive_component_relation_ids
                        if set(component) & set(target.relation_ids)
                    ),
                    (),
                )
                targets.append(
                    PlannedTarget(
                        target=target,
                        contributions=tuple(contributions),
                        recursive=bool(recursive_component_relation_ids),
                        recursive_component_relation_ids=recursive_component_relation_ids,
                    )
                )
            planned.append(PlannedStratum(index=stratum_index, targets=tuple(targets)))
        return tuple(planned)

    def _rule_blocks(self, task: mm.Task, inherited_context: tuple[mm.Task, ...] = ()):
        if not isinstance(task, mm.Logical):
            return
        if self._has_direct_model_write(task):
            yield mm.Logical(body=(*inherited_context, *task.body), optional=task.optional, scope=task.scope)
            return

        local_context = tuple(child for child in task.body if not isinstance(child, mm.Logical))
        for child in task.body:
            if isinstance(child, mm.Logical):
                yield from self._rule_blocks(child, inherited_context=(*inherited_context, *local_context))

    def _has_direct_model_write(self, task: mm.Logical) -> bool:
        return any(isinstance(child, (mm.Update, mm.Construct)) for child in task.body)

    def _targets_for_block(self, block: mm.Logical, catalog: Catalog, model: mm.Model) -> tuple[Target, ...]:
        targets: dict[tuple[str, int], Target] = {}
        constructs = self._constructs(block)
        updates = self._updates(block)
        ignored_update_keys = self._ignored_entity_update_keys(block, constructs)

        for construct in constructs:
            if not self._is_primary_construct(
                construct,
                constructs,
                updates,
                ignored_update_keys,
            ):
                continue
            entity_type = construct.id_var.type
            if isinstance(entity_type, mm.ScalarType):
                try:
                    store = catalog.entity_store(entity_type)
                except KeyError:
                    continue
                targets[("entity", store.type_id)] = Target(
                    kind="entity",
                    object_name=store.object_name,
                    column_names=tuple(column.name for column in store.columns),
                    key_columns=store.key_columns,
                    anchor_id=store.type_id,
                    relation_ids=self._entity_target_relation_ids(entity_type, model, catalog),
                )

        for update in updates:
            if catalog.is_folded_property(update.relation):
                if self._is_ignored_entity_update(update, ignored_update_keys):
                    continue
                store = catalog.owner_store_for_property(update.relation)
                targets[("entity", store.type_id)] = Target(
                    kind="entity",
                    object_name=store.object_name,
                    column_names=tuple(column.name for column in store.columns),
                    key_columns=store.key_columns,
                    anchor_id=store.type_id,
                    relation_ids=self._entity_target_relation_ids(store.type_id, model, catalog),
                )
                continue
            try:
                store = catalog.entity_store(update.relation)
            except KeyError:
                store = None
            if store is not None:
                if self._is_ignored_entity_update(update, ignored_update_keys):
                    continue
                targets[("entity", store.type_id)] = Target(
                    kind="entity",
                    object_name=store.object_name,
                    column_names=tuple(column.name for column in store.columns),
                    key_columns=store.key_columns,
                    anchor_id=store.type_id,
                    relation_ids=self._entity_target_relation_ids(store.type_id, model, catalog),
                )
                continue
            try:
                store = catalog.relation_store(update.relation)
            except KeyError:
                continue
            targets[("relation", store.relation_id)] = Target(
                kind="relation",
                object_name=store.object_name,
                column_names=tuple(column.name for column in store.columns),
                key_columns=store.key_columns,
                anchor_id=store.relation_id,
                relation_ids=(store.relation_id,),
            )

        return tuple(targets.values())

    def _entity_target_relation_ids(
        self,
        entity_ref: mm.ScalarType | int,
        model: mm.Model,
        catalog: Catalog,
    ) -> tuple[int, ...]:
        entity_type_id = entity_ref if isinstance(entity_ref, int) else getattr(entity_ref, "id", None)
        if not isinstance(entity_type_id, int):
            return ()
        relation_ids = [entity_type_id]
        for relation in model.relations:
            if not catalog.is_folded_property(relation):
                continue
            if catalog.owner_store_for_property(relation).type_id == entity_type_id:
                relation_ids.append(relation.id)
        return tuple(relation_ids)

    def _is_primary_construct(
        self,
        construct: mm.Construct,
        constructs: tuple[mm.Construct, ...],
        updates: tuple[mm.Update, ...],
        ignored_update_keys: set[tuple[int, int]],
    ) -> bool:
        construct_var_id = construct.id_var.id
        construct_type_id = getattr(construct.id_var.type, "id", None)
        if isinstance(construct_type_id, int) and (construct_type_id, construct_var_id) in ignored_update_keys:
            return False
        if any(
            update.args
            and isinstance(update.args[0], mm.Var)
            and update.args[0].id == construct_var_id
            and not self._is_ignored_entity_update(update, ignored_update_keys)
            for update in updates
        ):
            return True
        return not any(
            other is not construct
            and any(isinstance(value, mm.Var) and value.id == construct_var_id for value in other.values)
            for other in constructs
        )

    def _binding_lookup_keys(self, task: mm.Task) -> set[tuple[int, int]]:
        binding_keys: set[tuple[int, int]] = set()

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Lookup):
                relation_id = getattr(node.relation, "id", None)
                if (
                    isinstance(relation_id, int)
                    and node.args
                    and isinstance(node.args[0], mm.Var)
                ):
                    binding_keys.add((relation_id, node.args[0].id))
                return
            if isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)
                return
            if isinstance(node, (mm.Union, mm.Match)):
                for child in node.tasks:
                    walk(child)
                return
            if isinstance(node, mm.Not):
                walk(node.task)
                return
            if isinstance(node, mm.Aggregate):
                walk(node.body)

        walk(task)
        return binding_keys

    def _ignored_entity_update_keys(
        self,
        task: mm.Task,
        constructs: tuple[mm.Construct, ...],
    ) -> set[tuple[int, int]]:
        binding_lookup_keys = self._binding_lookup_keys(task)
        ignored_update_keys: set[tuple[int, int]] = set(binding_lookup_keys)
        for construct in constructs:
            relation_id = getattr(construct.id_var.type, "id", None)
            if not isinstance(relation_id, int) or (relation_id, construct.id_var.id) not in binding_lookup_keys:
                continue
            owner_type = construct.id_var.type
            identify_by = tuple(getattr(owner_type, "identify_by", ()))
            ignored_update_keys.update(
                (identify_relation.id, construct.id_var.id)
                for identify_relation in identify_by
            )
        return ignored_update_keys

    def _is_ignored_entity_update(
        self,
        update: mm.Update,
        ignored_update_keys: set[tuple[int, int]],
    ) -> bool:
        relation_id = getattr(update.relation, "id", None)
        if not isinstance(relation_id, int) or not update.args:
            return False
        owner = update.args[0]
        if not isinstance(owner, mm.Var):
            return False
        return (relation_id, owner.id) in ignored_update_keys

    def _project_block(self, block: mm.Logical, target: Target, catalog: Catalog) -> mm.Logical | None:
        all_constructs = tuple(self._constructs(block))
        ignored_update_keys = self._ignored_entity_update_keys(block, all_constructs)
        kept_updates = []
        for update in self._updates(block):
            if target.kind == "entity":
                if catalog.is_folded_property(update.relation):
                    if self._is_ignored_entity_update(update, ignored_update_keys):
                        continue
                    owner_store = catalog.owner_store_for_property(update.relation)
                    if owner_store.object_name == target.object_name:
                        kept_updates.append(update)
                    continue
                if self._is_ignored_entity_update(update, ignored_update_keys):
                    continue
                try:
                    entity_store = catalog.entity_store(update.relation)
                except KeyError:
                    entity_store = None
                if entity_store is not None and entity_store.object_name == target.object_name:
                    kept_updates.append(update)
            elif target.kind == "relation":
                try:
                    store = catalog.relation_store(update.relation)
                except KeyError:
                    continue
                if store.object_name == target.object_name:
                    kept_updates.append(update)

        kept_constructs = self._constructs_for_target(all_constructs, tuple(kept_updates), target, catalog)
        if not kept_constructs and not kept_updates:
            return None

        other_tasks = [
            pruned
            for child in block.body
            if not isinstance(child, mm.Update)
            and not isinstance(child, mm.Construct)
            and (pruned := self._strip_writes(child)) is not None
        ]
        return mm.Logical(body=(*kept_constructs, *other_tasks, *kept_updates))

    def _constructs_for_target(
        self,
        all_constructs: tuple[mm.Construct, ...],
        kept_updates: tuple[mm.Update, ...],
        target: Target,
        catalog: Catalog,
    ) -> tuple[mm.Construct, ...]:
        if target.kind != "entity":
            return all_constructs

        construct_by_var_id = {construct.id_var.id: construct for construct in all_constructs}
        required_ids = {
            construct.id_var.id
            for construct in all_constructs
            if self._construct_targets_match(construct, target, catalog)
        }
        pending = list(required_ids)

        while pending:
            construct = construct_by_var_id[pending.pop()]
            for value in construct.values:
                if isinstance(value, mm.Var) and value.id in construct_by_var_id and value.id not in required_ids:
                    required_ids.add(value.id)
                    pending.append(value.id)

        for update in kept_updates:
            for arg in update.args:
                if isinstance(arg, mm.Var) and arg.id in construct_by_var_id and arg.id not in required_ids:
                    required_ids.add(arg.id)
                    pending.append(arg.id)
                    while pending:
                        construct = construct_by_var_id[pending.pop()]
                        for value in construct.values:
                            if isinstance(value, mm.Var) and value.id in construct_by_var_id and value.id not in required_ids:
                                required_ids.add(value.id)
                                pending.append(value.id)

        return tuple(construct for construct in all_constructs if construct.id_var.id in required_ids)

    def _construct_targets_match(self, construct: mm.Construct, target: Target, catalog: Catalog) -> bool:
        if target.kind != "entity":
            return True
        construct_type = construct.id_var.type
        if not isinstance(construct_type, mm.ScalarType):
            return False
        try:
            store = catalog.entity_store(construct_type)
        except KeyError:
            return False
        return store.object_name == target.object_name

    def _strip_writes(self, task: mm.Task) -> mm.Task | None:
        if isinstance(task, (mm.Update, mm.Construct)):
            return None
        if isinstance(task, mm.Logical):
            body = tuple(
                pruned
                for child in task.body
                if (pruned := self._strip_writes(child)) is not None
            )
            return task.mut(body=body)
        if isinstance(task, (mm.Union, mm.Match)):
            tasks = tuple(
                pruned
                for child in task.tasks
                if (pruned := self._strip_writes(child)) is not None
            )
            return task.mut(tasks=tasks)
        if isinstance(task, mm.Not):
            inner = self._strip_writes(task.task)
            return task.mut(task=inner) if inner is not None else None
        if isinstance(task, mm.Aggregate):
            body = self._strip_writes(task.body)
            return task.mut(body=body) if body is not None else None
        return task

    def _constructs(self, task: mm.Task) -> tuple[mm.Construct, ...]:
        found: list[mm.Construct] = []

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Construct):
                found.append(node)
            elif isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)

        walk(task)
        return tuple(found)

    def _updates(self, task: mm.Task) -> tuple[mm.Update, ...]:
        found: list[mm.Update] = []

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Update):
                found.append(node)
            elif isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)

        walk(task)
        return tuple(found)


__all__ = ["Coalescer", "Contribution", "PlannedStratum", "PlannedTarget", "Target"]
