from __future__ import annotations

from ...metamodel import metamodel as mm
from ...metamodel.rewriter import Walker


class _VarIdCollector(Walker):
    def __init__(self) -> None:
        super().__init__()
        self.var_ids: set[int] = set()

    def enter_var(self, node: mm.Var):
        self.var_ids.add(node.id)


def task_var_ids(value) -> set[int]:
    collector = _VarIdCollector()
    collector(value)
    return collector.var_ids
