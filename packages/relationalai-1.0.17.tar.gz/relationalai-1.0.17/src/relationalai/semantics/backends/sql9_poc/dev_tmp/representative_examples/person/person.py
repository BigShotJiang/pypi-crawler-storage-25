from relationalai.semantics import Model, select, where, define, Integer, String
from relationalai.semantics.metamodel import typer

m = Model("Person")

Person = m.Concept("Person")

define(
    Person.new(name="Alice", age=10),
    Person.new(name="Bob", age=30),
    Person.new(name="David", age=50),
)

# me is a different Alice, without age
me = Person.new(name="Alice")
define(
    me,
    me.score(me.age)
)

# two ways of computing "age days"
define(Person.age_days(Person.age * 365))
where(c := Person.age).define(Person.age_days_too(c * 365))
# includes "me", which has no age
select(Person.name, Person.age_days, Person.age_days_too).to_df()
# # exclude persons without age
where(Person.age).select(Person.name, Person.age_days, Person.age_days_too).to_df()

# # computing values in the select
(select(Person.name, Person.age + 1)
 .where(Person.age > 18, Person.name == "David")
 .to_df())

# # computing values in the where
(where(Person.age > 18, coolness := Person.age + 2 * 100)
 .select(Person.name, Person.age + 1, coolness)
 .where(Person.name == "David")
 .to_df())

# extending the concept and then querying
Adult = m.Concept("Adult", extends=[Person])

define(Adult(Person)).where(Person.age >= 18)

select(Adult.name, Adult.age).to_df()


# disallow comparison between different nominal types
PersonId = m.Concept("PersonId", extends=[String])
PersonDogId = m.Concept("PersonDogId", extends=[String])
define(
    p3 := Person.new(name="john", pid=PersonId("aaa"), did=PersonDogId("aaa")),
)
with typer.errors(typer.TypeMismatch):
    select(Person.name).where(Person.pid == Person.did).to_df()


other = Person.ref()
select(Person.name, other.name).where(Person.age > 40).to_df()
select(Person.name, other.name).where(other.age > 40).to_df()

# various ways to access a relationship field
Person.info = m.Property(f"{Person} has {Integer:age} and {String:id}")
define(p3.info(38, "123a"))
select(
    Person.name,
    Person.info["age"],
    Person.info[String],
    Person.info[2],
    Person.info["agE"],
    Person.info["AGE"]
).where(Person.pid(PersonId("aaa"))).to_df()

