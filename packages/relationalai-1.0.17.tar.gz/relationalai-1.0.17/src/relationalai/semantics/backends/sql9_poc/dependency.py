"""Dependency graph and stratification for sql9."""
from __future__ import annotations

from dataclasses import dataclass

from ...metamodel import metamodel as mm


@dataclass(frozen=True, slots=True)
class DependencyEdge:
    writer_relation_id: int
    reader_relation_id: int
    negated: bool


@dataclass(frozen=True, slots=True)
class Stratum:
    index: int
    relation_ids: tuple[int, ...]
    recursive: bool
    recursive_component_relation_ids: tuple[tuple[int, ...], ...] = ()


class DependencyCollector:
    def collect(self, root: mm.Task) -> tuple[DependencyEdge, ...]:
        edges: list[DependencyEdge] = []
        for block in self._rule_blocks(root):
            writer_relation_ids = tuple(
                update.relation.id
                for update in block.body
                if isinstance(update, mm.Update)
            )
            if not writer_relation_ids:
                continue
            for reader_relation_id, negated in self._block_read_edges(block):
                for writer_relation_id in writer_relation_ids:
                    edges.append(
                        DependencyEdge(
                            writer_relation_id=writer_relation_id,
                            reader_relation_id=reader_relation_id,
                            negated=negated,
                        )
                    )
        return tuple(edges)

    def _rule_blocks(self, task: mm.Task, inherited_context: tuple[mm.Task, ...] = ()):
        if not isinstance(task, mm.Logical):
            return
        if self._has_direct_model_write(task):
            yield mm.Logical(body=(*inherited_context, *task.body), optional=task.optional, scope=task.scope)
            return

        local_context = tuple(child for child in task.body if not isinstance(child, mm.Logical))
        for child in task.body:
            if isinstance(child, mm.Logical):
                yield from self._rule_blocks(child, inherited_context=(*inherited_context, *local_context))

    def _has_direct_model_write(self, task: mm.Logical) -> bool:
        return any(isinstance(child, mm.Update) for child in task.body)

    def _block_read_edges(self, task: mm.Task, *, negated: bool = False):
        if isinstance(task, mm.Lookup):
            relation_id = getattr(task.relation, "id", None)
            if isinstance(relation_id, int):
                yield relation_id, negated
            return
        if isinstance(task, mm.Logical):
            for child in task.body:
                if isinstance(child, mm.Update):
                    continue
                yield from self._block_read_edges(child, negated=negated)
            return
        if isinstance(task, (mm.Union, mm.Match)):
            for child in task.tasks:
                yield from self._block_read_edges(child, negated=negated)
            return
        if isinstance(task, mm.Not):
            yield from self._block_read_edges(task.task, negated=True)
            return
        if isinstance(task, mm.Aggregate):
            yield from self._block_read_edges(task.body if isinstance(task.body, mm.Task) else mm.Logical(body=tuple(task.body)), negated=negated)


class Stratifier:
    def build(self, model: mm.Model) -> tuple[Stratum, ...]:
        collector = DependencyCollector()
        edges = collector.collect(model.root)

        relation_ids = {
            relation.id
            for relation in model.relations
        }
        for edge in edges:
            relation_ids.add(edge.writer_relation_id)
            relation_ids.add(edge.reader_relation_id)

        sccs = self._tarjan(tuple(relation_ids), list(edges))
        scc_index = {
            relation_id: index
            for index, component in enumerate(sccs)
            for relation_id in component
        }

        component_edges: dict[int, set[int]] = {index: set() for index in range(len(sccs))}
        component_has_self_loop: dict[int, bool] = {index: False for index in range(len(sccs))}
        indegree: dict[int, int] = {index: 0 for index in range(len(sccs))}
        level: dict[int, int] = {index: 0 for index in range(len(sccs))}

        for edge in edges:
            writer_scc = scc_index[edge.writer_relation_id]
            reader_scc = scc_index[edge.reader_relation_id]
            if writer_scc == reader_scc:
                if edge.negated:
                    raise NotImplementedError("sql9 does not yet support recursive negation.")
                component_has_self_loop[writer_scc] = True
                continue
            if writer_scc not in component_edges[reader_scc]:
                component_edges[reader_scc].add(writer_scc)
                indegree[writer_scc] += 1

        queue = sorted(index for index, degree in indegree.items() if degree == 0)
        topo: list[int] = []
        while queue:
            current = queue.pop(0)
            topo.append(current)
            for nxt in sorted(component_edges[current]):
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    queue.append(nxt)

        for edge in edges:
            writer_scc = scc_index[edge.writer_relation_id]
            reader_scc = scc_index[edge.reader_relation_id]
            if writer_scc == reader_scc:
                continue
            increment = 1 if edge.negated else 0
            level[writer_scc] = max(level[writer_scc], level[reader_scc] + increment)

        by_level: dict[int, list[int]] = {}
        for component_index in topo:
            by_level.setdefault(level[component_index], []).append(component_index)

        strata: list[Stratum] = []
        for index, stratum_level in enumerate(sorted(by_level)):
            component_indexes = by_level[stratum_level]
            relation_ids_in_stratum = tuple(
                relation_id
                for component_index in component_indexes
                for relation_id in sorted(sccs[component_index])
            )
            recursive_components = tuple(
                tuple(sorted(sccs[component_index]))
                for component_index in component_indexes
                if len(sccs[component_index]) > 1 or component_has_self_loop[component_index]
            )
            strata.append(
                Stratum(
                    index=index,
                    relation_ids=relation_ids_in_stratum,
                    recursive=bool(recursive_components),
                    recursive_component_relation_ids=recursive_components,
                )
            )
        return tuple(strata)

    def _tarjan(self, relation_ids: tuple[int, ...], edges: list[DependencyEdge]) -> tuple[tuple[int, ...], ...]:
        adjacency: dict[int, list[int]] = {relation_id: [] for relation_id in relation_ids}
        for edge in edges:
            adjacency.setdefault(edge.writer_relation_id, []).append(edge.reader_relation_id)

        index_counter = 0
        index_by_node: dict[int, int] = {}
        lowlink_by_node: dict[int, int] = {}
        stack: list[int] = []
        on_stack: set[int] = set()
        components: list[tuple[int, ...]] = []

        def strongconnect(node: int) -> None:
            nonlocal index_counter
            index_by_node[node] = index_counter
            lowlink_by_node[node] = index_counter
            index_counter += 1
            stack.append(node)
            on_stack.add(node)

            for neighbor in adjacency.get(node, ()):
                if neighbor not in index_by_node:
                    strongconnect(neighbor)
                    lowlink_by_node[node] = min(lowlink_by_node[node], lowlink_by_node[neighbor])
                elif neighbor in on_stack:
                    lowlink_by_node[node] = min(lowlink_by_node[node], index_by_node[neighbor])

            if lowlink_by_node[node] == index_by_node[node]:
                component: list[int] = []
                while stack:
                    candidate = stack.pop()
                    on_stack.remove(candidate)
                    component.append(candidate)
                    if candidate == node:
                        break
                components.append(tuple(sorted(component)))

        for relation_id in relation_ids:
            if relation_id not in index_by_node:
                strongconnect(relation_id)

        return tuple(components)


__all__ = ["DependencyEdge", "Stratifier", "Stratum"]
