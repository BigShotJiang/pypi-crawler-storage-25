"""SQL IR-level optimizations for the sql9_poc backend.

Optimizations applied after lowering, before emitting:

  O1 — Empty init view elimination
  O2 — Singleton UNION ALL → VALUES lift
  O3 — Carry-compute fold
  O4 — Single-consumer view inlining
  O5 — Aggregate-subquery flatten (push MAX through a pure-projection subquery)
  O6 — Project-over-aggregate fold (inline a pure projection into an aggregating subquery)
  O7 — Redundant CAST elimination (type-aware: CAST(expr AS T) dropped when type(expr) == T)
  O8 — Double-negation elimination + trivially-true IS NOT NULL guard removal
  M2 — Inline redundant pass-through SELECT DISTINCT wrapper over a subquery
  M4 — Drop IS NOT NULL WHERE guards made redundant by JOIN equi-conditions
  Q2 — Drop outer DISTINCT when inner GROUP BY constant guarantees uniqueness
  Q3 — Drop WHERE/JOIN TRUE conditions (SQLLiteral(True))
"""
from __future__ import annotations

from .artifacts import SQL9ExecutionPlan, SQL9ExecutionStep, SQL9View
from .sql_ir import (
    SQLBinaryOp,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLExpr,
    SQLFromItem,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLJoin,
    SQLLiteral,
    SQLNot,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSingletonSource,
    SQLSource,
    SQLSubquerySource,
    SQLTableSource,
    SQLTryCast,
    SQLUnionQuery,
    SQLValuesSource,
)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


class SQLOptimizer:
    """SQL IR-level optimization pass; runs after lowering, before emitting.

    Set ``enabled = False`` (or the env var ``PYREL_SQL9_OPTIMIZER=0``) to
    bypass all optimizations and emit raw lowered SQL.
    """

    enabled: bool = True

    def __init__(self) -> None:
        import os
        env = os.environ.get("PYREL_SQL9_OPTIMIZER", "").strip()
        if env == "0":
            self.enabled = False

    def optimize_query(self, query: SQLQuery) -> SQLQuery:
        """Apply query-level optimizations to a fragment query."""
        if not self.enabled:
            return query
        return _apply_query_opts(query)

    def optimize_plan(self, plan: SQL9ExecutionPlan) -> SQL9ExecutionPlan:
        if not self.enabled:
            return plan
        # For each step, collect view names that are referenced from outside it.
        external_refs_per_step = _compute_external_refs(plan)
        return SQL9ExecutionPlan(
            steps=tuple(
                _optimize_step(step, external_refs)
                for step, external_refs in zip(plan.steps, external_refs_per_step)
            )
        )


# ---------------------------------------------------------------------------
# Step-level driver
# ---------------------------------------------------------------------------


def _optimize_step(
    step: SQL9ExecutionStep, external_refs: set[str]
) -> SQL9ExecutionStep:
    """Apply O1–O6 to a single execution step until no further changes."""
    views = list(step.views)
    while True:
        prev = views

        # O1: drop empty init views that nothing references
        views = _drop_empty_init_views(views, external_refs)

        # O2, O3, O5, O6: applied bottom-up inside each view's query
        views = [SQL9View(name=v.name, query=_apply_query_opts(v.query)) for v in views]

        # O4: inline single-consumer views
        views = _inline_single_consumer_views(views, external_refs)

        if views == prev:
            break

    return SQL9ExecutionStep(views=tuple(views), semi_naive_loops=step.semi_naive_loops)


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _is_staging_view(name: str) -> bool:
    """Return True for internal staging views (e.g. Person_t781__stage_2)."""
    local = name.split(".")[-1].strip('"')
    return "__" in local


# ---------------------------------------------------------------------------
# O1 — Empty init view elimination
# ---------------------------------------------------------------------------


def _drop_empty_init_views(
    views: list[SQL9View], external_refs: set[str]
) -> list[SQL9View]:
    """Drop seed views (empty VALUES, no rows) that nothing else references.
    Only staging views (name contains '__') are eligible — public views may be
    referenced by separately-compiled queries and must always be emitted."""
    return [v for v in views if not (
        _is_staging_view(v.name) and _is_empty_store_view(v) and v.name not in external_refs
    )]


def _is_empty_store_view(view: SQL9View) -> bool:
    """Return True for views of the form SELECT cols FROM (empty VALUES) AS alias."""
    q = view.query
    if not isinstance(q, SQLSelectQuery):
        return False
    if q.where or q.joins or q.group_by or q.distinct:
        return False
    if q.from_item is None or not isinstance(q.from_item.source, SQLValuesSource):
        return False
    return len(q.from_item.source.rows) == 0


# ---------------------------------------------------------------------------
# Q2 — Drop redundant DISTINCT when inner subquery GROUP BY guarantees uniqueness
# ---------------------------------------------------------------------------


def _drop_redundant_distinct(query: SQLQuery) -> SQLQuery:
    """Q2: Remove outer DISTINCT when the single FROM subquery already guarantees
    unique rows via GROUP BY on constant expressions (e.g. GROUP BY 1).

    GROUP BY on a constant collapses all rows into a single group, so the output
    has at most one row — DISTINCT on one row is always a no-op.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.distinct or query.joins or query.where or query.group_by:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if not inner.group_by:
        return query
    # GROUP BY all-constant → at most one output row → DISTINCT is no-op
    if not all(isinstance(g, SQLLiteral) for g in inner.group_by):
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=False,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# M4 — Drop IS NOT NULL guards made redundant by JOIN equi-conditions
# ---------------------------------------------------------------------------


def _drop_join_constrained_null_guards(query: SQLQuery) -> SQLQuery:
    """M4: Remove WHERE `col IS NOT NULL` conditions that are already implied
    by a JOIN equi-condition on the same column.

    A JOIN ON (a.x = b.y) guarantees both sides are non-NULL (NULL fails =),
    so any `IS NOT NULL(a.x)` or `IS NOT NULL(b.y)` in WHERE is redundant.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.where or not query.joins:
        return query

    # Collect (table_alias, column_name) pairs from JOIN equi-conditions
    join_eq_cols: set[tuple[str | None, str]] = set()
    for j in query.joins:
        for cond in j.conditions:
            if isinstance(cond, SQLBinaryOp) and cond.operator == "=":
                for side in (cond.left, cond.right):
                    if isinstance(side, SQLColumnRef):
                        join_eq_cols.add((side.table_alias, side.column_name))

    if not join_eq_cols:
        return query

    def _redundant(expr: SQLExpr) -> bool:
        if isinstance(expr, SQLIsNotNull) and isinstance(expr.expr, SQLColumnRef):
            col = expr.expr
            return (col.table_alias, col.column_name) in join_eq_cols
        return False

    new_where = tuple(c for c in query.where if not _redundant(c))
    if new_where == query.where:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=query.joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# M2 — Inline redundant pass-through SELECT DISTINCT wrapper
# ---------------------------------------------------------------------------


def _inline_passthrough_wrapper(query: SQLQuery) -> SQLQuery:
    """M2: Remove an outer SELECT DISTINCT that is a pure pass-through over an
    inner SQLSelectQuery subquery.

    Pattern:
        SELECT DISTINCT merged."c1" AS "c1", merged."c2" AS "c2", ...
        FROM (inner_select) AS merged

    When:
      - No JOINs, WHERE, GROUP BY, ORDER BY, LIMIT on the outer query
      - All SELECT items are SQLColumnRef(name) AS name  (identity projections)
      - The inner query is a SQLSelectQuery

    Action: return inner_select with distinct=True, discarding the wrapper.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if (
        query.joins
        or query.where
        or query.group_by
        or query.order_by
        or query.limit is not None
        or not query.distinct
        or query.from_item is None
    ):
        return query
    if not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query

    # Verify every outer SELECT item is an identity column ref
    outer_alias = query.from_item.alias
    for item in query.select:
        if not isinstance(item.expr, SQLColumnRef):
            return query
        col = item.expr
        # Must reference the subquery alias (or no alias) and match output alias
        if col.table_alias is not None and col.table_alias != outer_alias:
            return query
        expected_alias = item.alias if item.alias is not None else col.column_name
        if col.column_name != expected_alias:
            return query

    # Safe to inline: return inner with distinct forced on
    if inner.distinct:
        return inner
    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=inner.select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=True,
        limit=inner.limit,
    )


# ---------------------------------------------------------------------------
# O2, O3, O5, O6 — applied together via recursive bottom-up query walk
# ---------------------------------------------------------------------------


def _apply_query_opts(query: SQLQuery) -> SQLQuery:
    """Bottom-up: recurse into sub-queries, then apply all optimizations."""
    query = _map_subqueries(query, _apply_query_opts)
    query = _singleton_union_to_values(query)          # O2
    query = _carry_compute_fold(query)                 # O3
    query = _aggregate_subquery_flatten(query)         # O5
    query = _project_over_aggregate_fold(query)        # O6
    query = _simplify_casts_in_query(query)            # O7
    query = _simplify_negations_in_query(query)        # O8
    query = _drop_redundant_distinct(query)             # Q2
    query = _drop_join_constrained_null_guards(query)  # M4
    query = _inline_passthrough_wrapper(query)         # M2
    return query


# ---------------------------------------------------------------------------
# O2 — Singleton UNION ALL → VALUES lift
# ---------------------------------------------------------------------------


def _singleton_union_to_values(query: SQLQuery) -> SQLQuery:
    """
    O2: Replace a UNION ALL of same-structure singleton-source branches with a
    single SELECT over a VALUES source.

    The outer SELECT wrapper (including any GROUP BY / MAX) is preserved; only
    the inner union is replaced.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    fi = query.from_item
    if fi is None or not isinstance(fi.source, SQLSubquerySource):
        return query

    union = fi.source.query
    if not isinstance(union, SQLUnionQuery) or union.operator != "UNION ALL":
        return query
    if len(union.queries) < 2:
        return query

    branches = union.queries

    # Every branch must be a singleton-source SELECT with no JOIN / GROUP BY.
    # A WHERE clause is allowed only if every condition is a provably-always-true
    # NOT <non-null-expr> IS NULL guard (emitted by the lowerer for MD5 outputs).
    for b in branches:
        if not isinstance(b, SQLSelectQuery):
            return query
        if b.joins or b.group_by or b.distinct:
            return query
        if b.from_item is None or not isinstance(b.from_item.source, SQLSingletonSource):
            return query
        if b.where and not _all_trivially_true(b.where):
            return query

    # All branches must expose the same column aliases (same output schema)
    aliases = tuple(item.alias for item in branches[0].select)
    for b in branches[1:]:
        if tuple(item.alias for item in b.select) != aliases:
            return query

    # Anti-unify each column across branches: extract varying literals as holes
    holes: list[list[object]] = []
    template_items: list[SQLSelectItem] = []
    for col_idx, alias in enumerate(aliases):
        col_exprs = [b.select[col_idx].expr for b in branches]
        template_expr = _anti_unify_literals(col_exprs, holes)
        if template_expr is None:
            return query  # structurally incompatible — skip
        template_items.append(SQLSelectItem(template_expr, alias=alias))

    if not holes:
        # All branches identical — degenerate, nothing to lift
        return query

    # Deduplicate holes: merge holes that carry identical value sequences.
    # canonical_idx[i] = earliest j such that holes[j] == holes[i].
    canonical_idx = list(range(len(holes)))
    for i in range(1, len(holes)):
        for j in range(i):
            if holes[j] == holes[i]:
                canonical_idx[i] = j
                break
    # Determine final compacted index for each canonical hole
    seen_canonical: set[int] = set()
    kept_order: list[int] = []
    for i in range(len(holes)):
        ci = canonical_idx[i]
        if ci not in seen_canonical:
            seen_canonical.add(ci)
            kept_order.append(ci)
    final_idx = {orig: new for new, orig in enumerate(kept_order)}
    # Build a single batch rename map: __p{i} → __p{final}
    rename_map = {
        f"__p{i}": f"__p{final_idx[canonical_idx[i]]}"
        for i in range(len(holes))
    }
    if any(v != k for k, v in rename_map.items()):
        template_items = [
            SQLSelectItem(_rename_col_refs_batch(item.expr, rename_map), alias=item.alias)
            for item in template_items
        ]
    holes = [holes[i] for i in kept_order]

    # Semantic hole naming: name a hole after the single output column that
    # exclusively references it (no other holes in the same template expression).
    item_hole_sets = [_holes_in_expr(item.expr) for item in template_items]
    used_names: set[str] = set()
    hole_names_list: list[str] = []
    for i in range(len(holes)):
        candidates = [
            template_items[j].alias
            for j in range(len(template_items))
            if i in item_hole_sets[j]
            and len(item_hole_sets[j]) == 1
            and template_items[j].alias is not None
        ]
        if len(candidates) == 1 and candidates[0] not in used_names:
            name = candidates[0]
        else:
            name = f"__p{i}"
        hole_names_list.append(name)
        used_names.add(name)
    # Rename __p{i} → semantic name in template expressions where the name changed
    for i, new_name in enumerate(hole_names_list):
        old_name = f"__p{i}"
        if new_name != old_name:
            template_items = [
                SQLSelectItem(
                    _rename_col_ref_in_expr(item.expr, old_name, new_name),
                    alias=item.alias,
                )
                for item in template_items
            ]
    hole_names = tuple(hole_names_list)
    rows = tuple(
        tuple(SQLLiteral(holes[i][branch_idx]) for i in range(len(holes)))
        for branch_idx in range(len(branches))
    )
    values_source = SQLValuesSource(column_names=hole_names, rows=rows)

    inner_query = SQLSelectQuery(
        from_item=SQLFromItem(source=values_source, alias="t"),
        select=tuple(template_items),
    )

    new_fi = SQLFromItem(source=SQLSubquerySource(inner_query), alias=fi.alias)
    return SQLSelectQuery(
        from_item=new_fi,
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _anti_unify_literals(
    exprs: list[SQLExpr], holes: list[list[object]]
) -> SQLExpr | None:
    """
    Anti-unify a list of expressions (one per branch) by extracting varying
    SQLLiteral nodes as holes.

    Returns a template expression where each hole is represented by
    SQLColumnRef("__p{i}"), or None if the expressions differ at a non-literal
    node (structurally incompatible).

    New holes are appended to `holes`; holes[i] is the list of per-branch
    literal values for placeholder __p{i}.
    """
    # Identical everywhere — no hole needed
    if all(e == exprs[0] for e in exprs):
        return exprs[0]

    first = exprs[0]

    # If first is SQLCast, normalize any SQLLiteral(None) entries (produced by R4)
    # to SQLCast(NULL, T) so they are structurally compatible.
    if isinstance(first, SQLCast):
        normalized: list[SQLCast] = []
        for e in exprs:
            if isinstance(e, SQLLiteral) and e.value is None:
                normalized.append(SQLCast(e, first.type_name))
            elif isinstance(e, SQLCast):
                normalized.append(e)
            else:
                return None
        if not all(e.type_name == first.type_name for e in normalized):
            return None
        inner = _anti_unify_literals([e.expr for e in normalized], holes)
        return None if inner is None else SQLCast(inner, first.type_name)

    # All must share the same concrete type to unify structurally
    if not all(type(e) is type(first) for e in exprs):
        return None

    if isinstance(first, SQLLiteral):
        idx = len(holes)
        holes.append([e.value for e in exprs])  # type: ignore[union-attr]
        return SQLColumnRef(f"__p{idx}")

    if isinstance(first, SQLTryCast):
        casts2: list[SQLTryCast] = exprs  # type: ignore[assignment]
        if not all(e.type_name == first.type_name for e in casts2):
            return None
        inner = _anti_unify_literals([e.expr for e in casts2], holes)
        return None if inner is None else SQLTryCast(inner, first.type_name)

    if isinstance(first, SQLFunctionCall):
        fns: list[SQLFunctionCall] = exprs  # type: ignore[assignment]
        if not all(
            e.name == first.name
            and len(e.args) == len(first.args)
            and e.sql_type == first.sql_type
            for e in fns
        ):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in fns], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLFunctionCall(first.name, tuple(new_args), first.sql_type)

    if isinstance(first, SQLConcat):
        concats: list[SQLConcat] = exprs  # type: ignore[assignment]
        if not all(len(e.args) == len(first.args) for e in concats):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in concats], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLConcat(tuple(new_args))

    if isinstance(first, SQLBinaryOp):
        ops: list[SQLBinaryOp] = exprs  # type: ignore[assignment]
        if not all(e.operator == first.operator for e in ops):
            return None
        left = _anti_unify_literals([e.left for e in ops], holes)
        if left is None:
            return None
        right = _anti_unify_literals([e.right for e in ops], holes)
        return None if right is None else SQLBinaryOp(left, first.operator, right)

    if isinstance(first, SQLIsNotNull):
        nodes: list[SQLIsNotNull] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nodes], holes)
        return None if inner is None else SQLIsNotNull(inner)

    if isinstance(first, SQLNot):
        nots: list[SQLNot] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nots], holes)
        return None if inner is None else SQLNot(inner)

    # Any other node type that isn't a literal and isn't handled above:
    # if all are equal we already returned above, so they must differ — can't unify
    return None


# ---------------------------------------------------------------------------
# O2 helpers — hole introspection and renaming
# ---------------------------------------------------------------------------


def _holes_in_expr(expr: SQLExpr) -> frozenset[int]:
    """Return the set of hole indices (__p{i}) referenced in expr."""
    if isinstance(expr, SQLColumnRef):
        n = expr.column_name
        if n.startswith("__p") and n[3:].isdigit():
            return frozenset([int(n[3:])])
        return frozenset()
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _holes_in_expr(expr.expr)
    if isinstance(expr, SQLFunctionCall):
        result: frozenset[int] = frozenset()
        for a in expr.args:
            result = result | _holes_in_expr(a)
        return result
    if isinstance(expr, SQLConcat):
        result = frozenset()
        for a in expr.args:
            result = result | _holes_in_expr(a)
        return result
    if isinstance(expr, SQLBinaryOp):
        return _holes_in_expr(expr.left) | _holes_in_expr(expr.right)
    if isinstance(expr, (SQLIsNotNull, SQLNot)):
        return _holes_in_expr(expr.expr)
    return frozenset()


def _rename_col_refs_batch(expr: SQLExpr, rename_map: dict[str, str]) -> SQLExpr:
    """Rename multiple column refs in one pass using a name→name map."""
    if isinstance(expr, SQLColumnRef):
        new_name = rename_map.get(expr.column_name)
        return SQLColumnRef(new_name, expr.table_alias) if new_name is not None else expr
    if isinstance(expr, SQLCast):
        inner = _rename_col_refs_batch(expr.expr, rename_map)
        return SQLCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLTryCast):
        inner = _rename_col_refs_batch(expr.expr, rename_map)
        return SQLTryCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLFunctionCall):
        new_args = tuple(_rename_col_refs_batch(a, rename_map) for a in expr.args)
        return SQLFunctionCall(expr.name, new_args, expr.sql_type) if new_args != expr.args else expr
    if isinstance(expr, SQLConcat):
        new_args_c = tuple(_rename_col_refs_batch(a, rename_map) for a in expr.args)
        return SQLConcat(new_args_c) if new_args_c != expr.args else expr
    if isinstance(expr, SQLBinaryOp):
        left = _rename_col_refs_batch(expr.left, rename_map)
        right = _rename_col_refs_batch(expr.right, rename_map)
        if left is expr.left and right is expr.right:
            return expr
        return SQLBinaryOp(left, expr.operator, right)
    if isinstance(expr, SQLIsNotNull):
        inner = _rename_col_refs_batch(expr.expr, rename_map)
        return SQLIsNotNull(inner) if inner is not expr.expr else expr
    if isinstance(expr, SQLNot):
        inner = _rename_col_refs_batch(expr.expr, rename_map)
        return SQLNot(inner) if inner is not expr.expr else expr
    return expr


def _rename_col_ref_in_expr(expr: SQLExpr, old: str, new: str) -> SQLExpr:
    """Rename every SQLColumnRef(column_name=old) to SQLColumnRef(new) in expr."""
    if isinstance(expr, SQLColumnRef):
        return SQLColumnRef(new, expr.table_alias) if expr.column_name == old else expr
    if isinstance(expr, SQLCast):
        inner = _rename_col_ref_in_expr(expr.expr, old, new)
        return SQLCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLTryCast):
        inner = _rename_col_ref_in_expr(expr.expr, old, new)
        return SQLTryCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLFunctionCall):
        new_args = tuple(_rename_col_ref_in_expr(a, old, new) for a in expr.args)
        return SQLFunctionCall(expr.name, new_args, expr.sql_type) if new_args != expr.args else expr
    if isinstance(expr, SQLConcat):
        new_args_c = tuple(_rename_col_ref_in_expr(a, old, new) for a in expr.args)
        return SQLConcat(new_args_c) if new_args_c != expr.args else expr
    if isinstance(expr, SQLBinaryOp):
        left = _rename_col_ref_in_expr(expr.left, old, new)
        right = _rename_col_ref_in_expr(expr.right, old, new)
        if left is expr.left and right is expr.right:
            return expr
        return SQLBinaryOp(left, expr.operator, right)
    if isinstance(expr, SQLIsNotNull):
        inner = _rename_col_ref_in_expr(expr.expr, old, new)
        return SQLIsNotNull(inner) if inner is not expr.expr else expr
    if isinstance(expr, SQLNot):
        inner = _rename_col_ref_in_expr(expr.expr, old, new)
        return SQLNot(inner) if inner is not expr.expr else expr
    return expr


# ---------------------------------------------------------------------------
# O2 helpers — trivially-true guard detection
# ---------------------------------------------------------------------------


def _is_always_nonnull(expr: SQLExpr) -> bool:
    """Return True if expr can never evaluate to NULL at runtime.

    Covers MD5 (always returns VARCHAR), literal constants, and CASTs of
    always-non-null expressions (CAST propagates non-nullability).
    """
    if isinstance(expr, SQLLiteral):
        return expr.value is not None
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _is_always_nonnull(expr.expr)
    if isinstance(expr, SQLFunctionCall) and expr.name == "MD5":
        return True
    if isinstance(expr, SQLConcat):
        return all(_is_always_nonnull(a) for a in expr.args)
    return False


def _is_trivially_true_condition(expr: SQLExpr) -> bool:
    """Return True if a single WHERE/JOIN condition is always true and can be dropped.

    The lowerer emits `NOT x IS NULL` as SQLIsNotNull(x) in the IR — i.e.
    "x IS NOT NULL". This is trivially true whenever x is always non-null.
    SQLLiteral(True) (emitted as TRUE) is trivially true by definition.
    """
    if isinstance(expr, SQLLiteral) and expr.value is True:
        return True
    if isinstance(expr, SQLIsNotNull):
        return _is_always_nonnull(expr.expr)
    return False


def _all_trivially_true(conditions: tuple) -> bool:
    """Return True if every condition in a WHERE tuple is trivially always true."""
    return all(_is_trivially_true_condition(c) for c in conditions)


# ---------------------------------------------------------------------------
# O8 — Double-negation elimination
# ---------------------------------------------------------------------------


def _simplify_negation_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively eliminate NOT(NOT(x)) → x throughout an expression."""
    if isinstance(expr, SQLNot):
        inner = _simplify_negation_expr(expr.expr)
        if isinstance(inner, SQLNot):
            # NOT(NOT(x)) → x  (already simplified)
            return inner.expr
        return SQLNot(inner) if inner is not expr.expr else expr
    if isinstance(expr, SQLBinaryOp):
        left = _simplify_negation_expr(expr.left)
        right = _simplify_negation_expr(expr.right)
        if left is expr.left and right is expr.right:
            return expr
        return SQLBinaryOp(left, expr.operator, right)
    if isinstance(expr, SQLIsNotNull):
        inner = _simplify_negation_expr(expr.expr)
        return SQLIsNotNull(inner) if inner is not expr.expr else expr
    if isinstance(expr, (SQLCast, SQLTryCast)):
        inner = _simplify_negation_expr(expr.expr)
        if inner is expr.expr:
            return expr
        return type(expr)(inner, expr.type_name)
    if isinstance(expr, SQLFunctionCall):
        new_args = tuple(_simplify_negation_expr(a) for a in expr.args)
        if new_args == expr.args:
            return expr
        return SQLFunctionCall(expr.name, new_args, expr.sql_type)
    return expr


def _simplify_negations_in_query(query: SQLQuery) -> SQLQuery:
    """O8: Eliminate NOT(NOT(x)) and drop trivially-true IS NOT NULL guards
    throughout all WHERE / JOIN conditions."""
    if not isinstance(query, SQLSelectQuery):
        return query
    new_where = tuple(
        _simplify_negation_expr(c)
        for c in query.where
        if not _is_trivially_true_condition(c)
    )
    new_joins = tuple(
        SQLJoin(
            kind=j.kind,
            source=j.source,
            alias=j.alias,
            conditions=tuple(
                _simplify_negation_expr(c)
                for c in j.conditions
                if not _is_trivially_true_condition(c)
            ),
        )
        for j in query.joins
    )
    if new_where == query.where and new_joins == query.joins:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=new_joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# O3 — Carry-compute fold
# ---------------------------------------------------------------------------


def _carry_compute_fold(query: SQLQuery) -> SQLQuery:
    """
    O3: Fold carry(S) ∪ compute(S) with MAX+GROUP BY into a single SELECT from S
    with the computed column inlined.

    Preconditions (all checked):
    - Outer query: GROUP BY on exactly one key column; SELECT is key + MAX(col) per
      non-key column.
    - Inner union: exactly two UNION ALL branches reading from the same SQLTableSource S.
    - One branch is an unrestricted pass-through (carry branch).
    - The other branch computes exactly one non-key column, NULLing all others (compute
      branch).
    - The compute expression only references S (dependency check).

    The WHERE condition from the compute branch is dropped on the assumption that the
    compute expression naturally propagates NULL when the condition is false (the typical
    pattern: condition = "col IS NOT NULL", expression = f(col)).
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if len(query.group_by) != 1 or not isinstance(query.group_by[0], SQLColumnRef):
        return query

    key_col = query.group_by[0].column_name

    # Outer SELECT must be: key col-ref + MAX(col-ref) for every non-key column
    for item in query.select:
        if item.alias == key_col:
            if not (isinstance(item.expr, SQLColumnRef) and item.expr.column_name == key_col):
                return query
        else:
            expr = item.expr
            if not (
                isinstance(expr, SQLFunctionCall)
                and expr.name == "MAX"
                and len(expr.args) == 1
                and isinstance(expr.args[0], SQLColumnRef)
            ):
                return query

    # FROM must be a subquery containing a two-branch UNION ALL
    fi = query.from_item
    if fi is None or not isinstance(fi.source, SQLSubquerySource):
        return query
    union = fi.source.query
    if (
        not isinstance(union, SQLUnionQuery)
        or union.operator != "UNION ALL"
        or len(union.queries) != 2
    ):
        return query

    b1, b2 = union.queries
    if not isinstance(b1, SQLSelectQuery) or not isinstance(b2, SQLSelectQuery):
        return query

    # Both branches must read from the same SQLTableSource
    src1 = _single_table_source_name(b1)
    src2 = _single_table_source_name(b2)
    if src1 is None or src1 != src2:
        return query
    source_name = src1

    # Identify carry and compute branches (try both orderings)
    carry_alias = _detect_carry_branch(b1, source_name, key_col)
    compute_info = _detect_compute_branch(b2, source_name, key_col) if carry_alias else None

    if carry_alias is None or compute_info is None:
        carry_alias = _detect_carry_branch(b2, source_name, key_col)
        compute_info = _detect_compute_branch(b1, source_name, key_col) if carry_alias else None

    if carry_alias is None or compute_info is None:
        return query

    compute_alias, computed_col, compute_expr = compute_info

    # Dependency check: compute_expr must only reference columns from source S
    if not _expr_only_refs_alias(compute_expr, compute_alias):
        return query

    # Rewrite the compute expression to use the carry alias
    folded_expr = _replace_alias_in_expr(compute_expr, compute_alias, carry_alias)

    # Build folded SELECT: inline computed col, direct col-refs for all others
    new_select = tuple(
        SQLSelectItem(
            folded_expr if item.alias == computed_col else SQLColumnRef(item.alias, carry_alias),
            alias=item.alias,
        )
        for item in query.select
    )

    return SQLSelectQuery(
        from_item=SQLFromItem(SQLTableSource(source_name), carry_alias),
        select=new_select,
        order_by=query.order_by,
    )


def _single_table_source_name(q: SQLSelectQuery) -> str | None:
    """Return the SQLTableSource name if q reads from exactly one table (no joins)."""
    if q.joins or q.from_item is None:
        return None
    if not isinstance(q.from_item.source, SQLTableSource):
        return None
    return q.from_item.source.name


def _detect_carry_branch(
    q: SQLSelectQuery, source_name: str, key_col: str
) -> str | None:
    """
    Return the table alias if q is a carry branch:
      SELECT col, col, ... FROM source_name AS alias  (no WHERE, no transforms).
    """
    if q.where or q.group_by or q.joins or q.distinct:
        return None
    if q.from_item is None or not isinstance(q.from_item.source, SQLTableSource):
        return None
    if q.from_item.source.name != source_name:
        return None
    carry_alias = q.from_item.alias
    for item in q.select:
        if not isinstance(item.expr, SQLColumnRef):
            return None
        # alias=None means the column name serves as the implicit alias
        if item.alias is not None and item.expr.column_name != item.alias:
            return None
        if item.expr.table_alias not in (None, carry_alias):
            return None
    return carry_alias


def _detect_compute_branch(
    q: SQLSelectQuery, source_name: str, key_col: str
) -> tuple[str, str, SQLExpr] | None:
    """
    Return (compute_alias, computed_col, compute_expr) if q is a compute branch:
    - reads from source_name
    - exactly one non-key, non-NULL select item (the computed column)
    - all other non-key items are NULL expressions
    - optional WHERE clause (caller is responsible for handling it)
    """
    if q.group_by or q.joins or q.distinct:
        return None
    if q.from_item is None or not isinstance(q.from_item.source, SQLTableSource):
        return None
    if q.from_item.source.name != source_name:
        return None
    compute_alias = q.from_item.alias

    computed: list[tuple[str, SQLExpr]] = []
    for item in q.select:
        if item.alias == key_col:
            if not isinstance(item.expr, SQLColumnRef):
                return None
            continue
        if _is_null_expr(item.expr):
            continue
        computed.append((item.alias, item.expr))

    if len(computed) != 1:
        return None

    return (compute_alias, computed[0][0], computed[0][1])


def _is_null_expr(expr: SQLExpr) -> bool:
    if isinstance(expr, SQLLiteral) and expr.value is None:
        return True
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return isinstance(expr.expr, SQLLiteral) and expr.expr.value is None
    return False


def _expr_only_refs_alias(expr: SQLExpr, alias: str | None) -> bool:
    """Return True if every SQLColumnRef table_alias in expr is `alias` or None."""
    if isinstance(expr, SQLColumnRef):
        return expr.table_alias in (None, alias)
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _expr_only_refs_alias(expr.expr, alias)
    if isinstance(expr, SQLFunctionCall):
        return all(_expr_only_refs_alias(a, alias) for a in expr.args)
    if isinstance(expr, SQLConcat):
        return all(_expr_only_refs_alias(a, alias) for a in expr.args)
    if isinstance(expr, SQLBinaryOp):
        return _expr_only_refs_alias(expr.left, alias) and _expr_only_refs_alias(
            expr.right, alias
        )
    if isinstance(expr, (SQLIsNotNull, SQLNot)):
        return _expr_only_refs_alias(expr.expr, alias)
    return True  # literals, SQLStar, etc. have no column refs


def _replace_alias_in_expr(expr: SQLExpr, old: str, new: str) -> SQLExpr:
    """Replace every SQLColumnRef with table_alias == old with new."""
    if isinstance(expr, SQLColumnRef):
        return SQLColumnRef(expr.column_name, new) if expr.table_alias == old else expr
    if isinstance(expr, SQLCast):
        return SQLCast(_replace_alias_in_expr(expr.expr, old, new), expr.type_name)
    if isinstance(expr, SQLTryCast):
        return SQLTryCast(_replace_alias_in_expr(expr.expr, old, new), expr.type_name)
    if isinstance(expr, SQLFunctionCall):
        return SQLFunctionCall(
            expr.name,
            tuple(_replace_alias_in_expr(a, old, new) for a in expr.args),
            expr.sql_type,
        )
    if isinstance(expr, SQLConcat):
        return SQLConcat(tuple(_replace_alias_in_expr(a, old, new) for a in expr.args))
    if isinstance(expr, SQLBinaryOp):
        return SQLBinaryOp(
            _replace_alias_in_expr(expr.left, old, new),
            expr.operator,
            _replace_alias_in_expr(expr.right, old, new),
        )
    if isinstance(expr, SQLIsNotNull):
        return SQLIsNotNull(_replace_alias_in_expr(expr.expr, old, new))
    if isinstance(expr, SQLNot):
        return SQLNot(_replace_alias_in_expr(expr.expr, old, new))
    return expr


# ---------------------------------------------------------------------------
# O4 — Single-consumer view inlining
# ---------------------------------------------------------------------------


def _inline_single_consumer_views(
    views: list[SQL9View], external_refs: set[str]
) -> list[SQL9View]:
    """
    O4: Inline a view into its one consumer when it has no external consumers.

    A view V is inlinable when:
    - Exactly one other view in this step references V by name.
    - V's name is not in external_refs (not referenced from outside this step).
    - V is an internal staging view (base name contains "__"), not a public final view.
      Public views (entity tables, relation tables) may be referenced by queries compiled
      separately and must therefore remain as named views.
    """
    step_names = {v.name for v in views}

    # Count how many views within this step reference each step-local name
    ref_counts: dict[str, int] = {name: 0 for name in step_names}
    for v in views:
        for name in _collect_table_refs_in_query(v.query):
            if name in ref_counts:
                ref_counts[name] += 1


    inlinable = {
        name
        for name, count in ref_counts.items()
        if count == 1 and name not in external_refs and _is_staging_view(name)
    }
    if not inlinable:
        return views

    inline_map = {v.name: v.query for v in views if v.name in inlinable}
    return [
        SQL9View(name=v.name, query=_substitute_table_sources(v.query, inline_map))
        for v in views
        if v.name not in inlinable
    ]


# ---------------------------------------------------------------------------
# O5 — Aggregate-subquery flatten
# ---------------------------------------------------------------------------


def _aggregate_subquery_flatten(query: SQLQuery) -> SQLQuery:
    """
    O5: Push MAX aggregates through a pure-projection subquery.

    Pattern:
      SELECT key_col, MAX(col1), MAX(col2), ...
      FROM (SELECT expr_k AS key_col, expr1 AS col1, expr2 AS col2, ... FROM src) AS t
      GROUP BY key_col
    →
      SELECT expr_k AS key_col, MAX(expr1) AS col1, MAX(expr2) AS col2, ...
      FROM src
      GROUP BY expr_k

    Preconditions:
    - Outer has GROUP BY and no WHERE, no DISTINCT, no extra joins.
    - Outer SELECT contains only the key column (direct col-ref) and MAX(col-ref) items.
    - Inner is a pure projection: no GROUP BY, no DISTINCT, no extra joins.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.group_by or query.where or query.joins or query.distinct:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if inner.group_by or inner.distinct or inner.joins or inner.from_item is None:
        return query

    # outer_alias = query.from_item.alias

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Rewrite GROUP BY: each col-ref must resolve through inner_map
    new_group_by: list[SQLExpr] = []
    for gb_expr in query.group_by:
        if not isinstance(gb_expr, SQLColumnRef):
            return query
        if gb_expr.column_name not in inner_map:
            return query
        new_group_by.append(inner_map[gb_expr.column_name])

    # Rewrite SELECT: key col-ref or MAX(col-ref), both resolved through inner_map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        expr = item.expr
        if isinstance(expr, SQLColumnRef):
            col_name = expr.column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(inner_map[col_name], alias=item.alias))
        elif (
            isinstance(expr, SQLFunctionCall)
            and expr.name == "MAX"
            and len(expr.args) == 1
            and isinstance(expr.args[0], SQLColumnRef)
        ):
            col_name = expr.args[0].column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(
                SQLFunctionCall("MAX", (inner_map[col_name],)),
                alias=item.alias,
            ))
        else:
            return query  # non-MAX, non-key expression in outer — can't flatten

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# O6 — Project-over-aggregate fold
# ---------------------------------------------------------------------------


def _project_over_aggregate_fold(query: SQLQuery) -> SQLQuery:
    """
    O6: Fold a pure projection over an aggregating subquery directly into it.

    Pattern:
      SELECT f(carry.col1), carry.col2, ...
      FROM (SELECT expr1 AS col1, MAX(col2) AS col2, ... FROM src GROUP BY key) AS carry
    →
      SELECT f(expr1) AS ..., MAX(col2) AS col2, ...
      FROM src
      GROUP BY key

    Preconditions:
    - Outer is a pure projection: no GROUP BY, no WHERE, no extra joins.
      DISTINCT is allowed and is propagated into the folded result.
    - Outer SELECT contains no aggregate functions.
    - Inner is an aggregating query with GROUP BY.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if query.group_by or query.where or query.joins:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if not inner.group_by or inner.from_item is None:
        return query
    # Skip if inner uses positional GROUP BY (integer literals like GROUP BY 1):
    # after rewriting the SELECT list the positions would refer to different columns.
    if any(isinstance(g, SQLLiteral) and isinstance(g.value, int) for g in inner.group_by):
        return query

    outer_alias = query.from_item.alias

    # Outer SELECT must not contain aggregates (would create illegal nested aggs)
    for item in query.select:
        if _contains_aggregate(item.expr):
            return query

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Substitute col-refs in each outer SELECT item using the inner map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        new_expr = _substitute_col_refs(item.expr, inner_map, outer_alias)
        if new_expr is None:
            return query
        # If the outer item had no explicit alias but was a bare column ref, keep
        # that name as the alias so the folded result still names its columns
        # correctly when embedded in a UNION ALL / wrapped by GROUP BY.
        alias = item.alias
        if alias is None and isinstance(item.expr, SQLColumnRef):
            alias = item.expr.column_name
        new_select.append(SQLSelectItem(new_expr, alias=alias))

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=inner.group_by,
        order_by=query.order_by or inner.order_by,
        distinct=query.distinct or inner.distinct,
        limit=query.limit if query.limit is not None else inner.limit,
    )


def _contains_aggregate(expr: SQLExpr) -> bool:
    """Return True if expr contains any aggregate function call (MAX, MIN, etc.)."""
    if isinstance(expr, SQLFunctionCall):
        if expr.name in ("MAX", "MIN", "SUM", "COUNT", "AVG"):
            return True
        return any(_contains_aggregate(a) for a in expr.args)
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _contains_aggregate(expr.expr)
    if isinstance(expr, SQLConcat):
        return any(_contains_aggregate(a) for a in expr.args)
    if isinstance(expr, SQLBinaryOp):
        return _contains_aggregate(expr.left) or _contains_aggregate(expr.right)
    if isinstance(expr, (SQLIsNotNull, SQLNot)):
        return _contains_aggregate(expr.expr)
    return False


# ---------------------------------------------------------------------------
# O7 — Redundant CAST elimination (type-aware)
# ---------------------------------------------------------------------------


def _infer_sql_type(expr: SQLExpr) -> str | None:
    """
    Infer the SQL type of expr where determinable.

    Rules:
    - CAST(_, T) / TryCast(_, T)  → T
    - MAX(e) / MIN(e)             → type of e  (aggregate preserves element type)
    - MD5(...)                    → VARCHAR
    - Otherwise                   → None (unknown)
    """
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return expr.type_name
    if isinstance(expr, SQLFunctionCall):
        if expr.name in ("MAX", "MIN") and len(expr.args) == 1:
            return _infer_sql_type(expr.args[0])
        if expr.name == "MD5":
            return "VARCHAR"
    if isinstance(expr, SQLBinaryOp) and expr.operator in ("*", "+", "-", "/"):
        return _infer_sql_type(expr.left)
    return None


def _simplify_casts_in_query(query: SQLQuery) -> SQLQuery:
    """O7: Remove CAST(expr AS T) when type(expr) is already T throughout a query."""
    if not isinstance(query, SQLSelectQuery):
        return query
    changed = False

    new_select = []
    for item in query.select:
        s = _simplify_cast_expr(item.expr)
        new_select.append(SQLSelectItem(s, alias=item.alias))
        if s is not item.expr:
            changed = True

    new_where = []
    for w in query.where:
        s = _simplify_cast_expr(w)
        new_where.append(s)
        if s is not w:
            changed = True

    new_group_by = []
    for g in query.group_by:
        s = _simplify_cast_expr(g)
        new_group_by.append(s)
        if s is not g:
            changed = True

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=query.joins,
        where=tuple(new_where),
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _simplify_cast_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively remove CAST(expr AS T) when the type of expr is already T,
    and simplify CAST(NULL AS T) → NULL."""
    if isinstance(expr, SQLCast):
        inner = _simplify_cast_expr(expr.expr)
        if isinstance(inner, SQLLiteral) and inner.value is None:
            return inner  # CAST(NULL AS T) → NULL
        if _infer_sql_type(inner) == expr.type_name:
            return inner  # redundant — type already matches
        return SQLCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLTryCast):
        inner = _simplify_cast_expr(expr.expr)
        if isinstance(inner, SQLLiteral) and inner.value is None:
            return inner  # TRY_CAST(NULL AS T) → NULL
        if _infer_sql_type(inner) == expr.type_name:
            return inner
        return SQLTryCast(inner, expr.type_name) if inner is not expr.expr else expr
    if isinstance(expr, SQLFunctionCall):
        new_args = tuple(_simplify_cast_expr(a) for a in expr.args)
        if new_args == expr.args:
            return expr
        return SQLFunctionCall(expr.name, new_args, expr.sql_type)
    if isinstance(expr, SQLConcat):
        new_args = tuple(_simplify_cast_expr(a) for a in expr.args)
        return SQLConcat(new_args) if new_args != expr.args else expr
    if isinstance(expr, SQLBinaryOp):
        left = _simplify_cast_expr(expr.left)
        right = _simplify_cast_expr(expr.right)
        if left is expr.left and right is expr.right:
            return expr
        return SQLBinaryOp(left, expr.operator, right)
    if isinstance(expr, SQLIsNotNull):
        inner = _simplify_cast_expr(expr.expr)
        return SQLIsNotNull(inner) if inner is not expr.expr else expr
    if isinstance(expr, SQLNot):
        inner = _simplify_cast_expr(expr.expr)
        return SQLNot(inner) if inner is not expr.expr else expr
    return expr


def _substitute_col_refs(
    expr: SQLExpr,
    sub_map: dict[str, SQLExpr],
    outer_alias: str | None,
) -> SQLExpr | None:
    """
    Replace SQLColumnRef(col, outer_alias) with sub_map[col] throughout expr.
    Returns None if a col-ref targeting outer_alias is missing from sub_map.
    Col-refs targeting other aliases are left unchanged.
    """
    if isinstance(expr, SQLColumnRef):
        if expr.table_alias in (None, outer_alias):
            if expr.column_name in sub_map:
                return sub_map[expr.column_name]
            return None  # col not found in inner
        return expr  # different table — leave as-is
    if isinstance(expr, SQLCast):
        inner = _substitute_col_refs(expr.expr, sub_map, outer_alias)
        return None if inner is None else SQLCast(inner, expr.type_name)
    if isinstance(expr, SQLTryCast):
        inner = _substitute_col_refs(expr.expr, sub_map, outer_alias)
        return None if inner is None else SQLTryCast(inner, expr.type_name)
    if isinstance(expr, SQLFunctionCall):
        new_args: list[SQLExpr] = []
        for a in expr.args:
            na = _substitute_col_refs(a, sub_map, outer_alias)
            if na is None:
                return None
            new_args.append(na)
        return SQLFunctionCall(expr.name, tuple(new_args), expr.sql_type)
    if isinstance(expr, SQLConcat):
        new_args_c: list[SQLExpr] = []
        for a in expr.args:
            na = _substitute_col_refs(a, sub_map, outer_alias)
            if na is None:
                return None
            new_args_c.append(na)
        return SQLConcat(tuple(new_args_c))
    if isinstance(expr, SQLBinaryOp):
        left = _substitute_col_refs(expr.left, sub_map, outer_alias)
        right = _substitute_col_refs(expr.right, sub_map, outer_alias)
        if left is None or right is None:
            return None
        return SQLBinaryOp(left, expr.operator, right)
    if isinstance(expr, SQLIsNotNull):
        inner = _substitute_col_refs(expr.expr, sub_map, outer_alias)
        return None if inner is None else SQLIsNotNull(inner)
    if isinstance(expr, SQLNot):
        inner = _substitute_col_refs(expr.expr, sub_map, outer_alias)
        return None if inner is None else SQLNot(inner)
    return expr  # SQLLiteral, SQLStar, SQLUnboundVar, etc. — no col-refs


# ---------------------------------------------------------------------------
# Query traversal helpers
# ---------------------------------------------------------------------------


def _map_subqueries(query: SQLQuery, fn) -> SQLQuery:
    """Apply fn bottom-up to all sub-queries nested inside query."""
    if isinstance(query, SQLSelectQuery):
        new_fi = None
        if query.from_item is not None:
            new_fi = SQLFromItem(
                _map_source(query.from_item.source, fn), query.from_item.alias
            )
        new_joins = tuple(
            SQLJoin(j.kind, _map_source(j.source, fn), j.alias, j.conditions)
            for j in query.joins
        )
        return SQLSelectQuery(
            from_item=new_fi,
            joins=new_joins,
            where=query.where,
            select=query.select,
            group_by=query.group_by,
            order_by=query.order_by,
            distinct=query.distinct,
            limit=query.limit,
        )
    if isinstance(query, SQLUnionQuery):
        return SQLUnionQuery(
            queries=tuple(fn(q) for q in query.queries),
            operator=query.operator,
        )
    return query


def _map_source(source: SQLSource, fn) -> SQLSource:
    if isinstance(source, SQLSubquerySource):
        return SQLSubquerySource(fn(source.query))
    return source


def _collect_table_refs_in_query(query: SQLQuery) -> set[str]:
    """Collect all SQLTableSource names referenced anywhere in query."""
    names: set[str] = set()

    def visit(q: SQLQuery) -> None:
        if isinstance(q, SQLSelectQuery):
            if q.from_item is not None:
                visit_source(q.from_item.source)
            for j in q.joins:
                visit_source(j.source)
        elif isinstance(q, SQLUnionQuery):
            for sub in q.queries:
                visit(sub)

    def visit_source(s: SQLSource) -> None:
        if isinstance(s, SQLTableSource):
            names.add(s.name)
        elif isinstance(s, SQLSubquerySource):
            visit(s.query)

    visit(query)
    return names


def _substitute_table_sources(
    query: SQLQuery, subs: dict[str, SQLQuery]
) -> SQLQuery:
    """Replace every SQLTableSource(name) where name is in subs with a subquery."""
    if not subs:
        return query

    def sub_source(s: SQLSource) -> SQLSource:
        if isinstance(s, SQLTableSource) and s.name in subs:
            # Recursively substitute inside the inlined query too (transitive inlining)
            return SQLSubquerySource(_substitute_table_sources(subs[s.name], subs))
        if isinstance(s, SQLSubquerySource):
            return SQLSubquerySource(_substitute_table_sources(s.query, subs))
        return s

    if isinstance(query, SQLSelectQuery):
        new_fi = None
        if query.from_item is not None:
            new_fi = SQLFromItem(sub_source(query.from_item.source), query.from_item.alias)
        new_joins = tuple(
            SQLJoin(j.kind, sub_source(j.source), j.alias, j.conditions) for j in query.joins
        )
        return SQLSelectQuery(
            from_item=new_fi,
            joins=new_joins,
            where=query.where,
            select=query.select,
            group_by=query.group_by,
            order_by=query.order_by,
            distinct=query.distinct,
            limit=query.limit,
        )
    if isinstance(query, SQLUnionQuery):
        return SQLUnionQuery(
            queries=tuple(_substitute_table_sources(q, subs) for q in query.queries),
            operator=query.operator,
        )
    return query


# ---------------------------------------------------------------------------
# Plan-level reference analysis
# ---------------------------------------------------------------------------


def _compute_external_refs(plan: SQL9ExecutionPlan) -> list[set[str]]:
    """
    For each step, return the set of view names that are referenced from
    *outside* that step (other steps' views, any semi-naive loop queries).
    """
    # Collect all refs per step (views + loops within the step itself)
    step_all_refs: list[set[str]] = []
    for step in plan.steps:
        refs: set[str] = set()
        for v in step.views:
            refs |= _collect_table_refs_in_query(v.query)
        for loop in step.semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.final_query):
                    refs |= _collect_table_refs_in_query(q)
        step_all_refs.append(refs)

    total = len(plan.steps)
    external: list[set[str]] = []
    for i in range(total):
        ext: set[str] = set()
        for j in range(total):
            if j != i:
                ext |= step_all_refs[j]
        # Also include semi-naive loop refs from the current step (they are not
        # rewritten by the optimizer so they count as external consumers)
        for loop in plan.steps[i].semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.final_query):
                    ext |= _collect_table_refs_in_query(q)
        external.append(ext)

    return external


__all__ = ["SQLOptimizer"]
