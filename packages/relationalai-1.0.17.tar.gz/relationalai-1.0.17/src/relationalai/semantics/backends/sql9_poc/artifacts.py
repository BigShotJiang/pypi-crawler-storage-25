from __future__ import annotations

from dataclasses import dataclass, field

from ...metamodel import metamodel as mm
from .coalesce import Target
from .sql_ir import SQLCreateView, SQLQuery


@dataclass(frozen=True, slots=True)
class SQL9TargetPlan:
    target: Target
    tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True


@dataclass(frozen=True, slots=True)
class SQL9RecursiveTargetPlan:
    target: Target
    seed_tasks: tuple[mm.Logical, ...]
    recursive_tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    marker_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True


@dataclass(frozen=True, slots=True)
class SQL9RecursiveComponentPlan:
    relation_ids: tuple[int, ...]
    targets: tuple[SQL9RecursiveTargetPlan, ...]


@dataclass(slots=True)
class SQL9StratumVersionState:
    latest_tables_by_relation_id: dict[int, mm.Table]
    entry_tables_by_relation_id: dict[int, mm.Table]
    materialized_tables_by_object_name: dict[str, mm.Table] = field(default_factory=dict)
    stage_numbers_by_object_name: dict[str, int] = field(default_factory=dict)

    def latest_table_for(self, relation_id: int) -> mm.Table | None:
        return self.latest_tables_by_relation_id.get(relation_id)

    def entry_table_for(self, relation_id: int) -> mm.Table | None:
        return self.entry_tables_by_relation_id.get(relation_id)

    def prior_table_for(self, object_name: str) -> mm.Table | None:
        return self.materialized_tables_by_object_name.get(object_name)

    def note_output_name(self, object_name: str) -> int:
        next_stage = self.stage_numbers_by_object_name.get(object_name, 0) + 1
        self.stage_numbers_by_object_name[object_name] = next_stage
        return next_stage

    def materialize_object(self, object_name: str, output_table: mm.Table) -> None:
        self.materialized_tables_by_object_name[object_name] = output_table

    def bind_relation_table(self, relation_id: int, table: mm.Table) -> None:
        self.latest_tables_by_relation_id[relation_id] = table


@dataclass(frozen=True, slots=True)
class SQL9PlanStratum:
    index: int
    items: tuple[SQL9TargetPlan | SQL9RecursiveComponentPlan, ...]
    recursive: bool = False


@dataclass(frozen=True, slots=True)
class SQL9View(SQLCreateView):
    pass


@dataclass(frozen=True, slots=True)
class SQL9SemiNaiveTable:
    table_name: str
    columns: tuple[str, ...]
    base_query: SQLQuery
    delta_query: SQLQuery
    merge_query: SQLQuery
    final_query: SQLQuery
    accum_view_name: str
    delta_view_name: str
    next_delta_view_name: str


@dataclass(frozen=True, slots=True)
class SQL9SemiNaiveLoop:
    tables: tuple[SQL9SemiNaiveTable, ...] = ()


@dataclass(frozen=True, slots=True)
class SQL9ExecutionStep:
    views: tuple[SQL9View, ...] = ()
    semi_naive_loops: tuple[SQL9SemiNaiveLoop, ...] = ()


@dataclass(frozen=True, slots=True)
class SQL9ExecutionPlan:
    steps: tuple[SQL9ExecutionStep, ...] = ()


@dataclass(frozen=True, slots=True)
class SQL9ModelPlan:
    strata: tuple[SQL9PlanStratum, ...]
    final_tables_by_relation_id: dict[int, mm.Table]
    seed_object_names: tuple[str, ...] = ()
