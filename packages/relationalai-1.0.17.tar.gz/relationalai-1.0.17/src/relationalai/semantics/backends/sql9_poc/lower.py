"""Mechanical SQL lowering for the isolated sql9 backend."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Literal

from ...metamodel import metamodel as mm
from ...metamodel.builtins import builtins as builtin_registry, is_function
from .artifacts import (
    SQL9ExecutionPlan,
    SQL9ExecutionStep,
    SQL9ModelPlan,
    SQL9PlanStratum,
    SQL9RecursiveComponentPlan,
    SQL9RecursiveTargetPlan,
    SQL9SemiNaiveLoop,
    SQL9SemiNaiveTable,
    SQL9TargetPlan,
    SQL9View,
)
from .catalog import Catalog, DataStore
from .coalesce import Target
from .mm_utils import task_var_ids
from .sql_ir import (
    SQLBinaryOp,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLExists,
    SQLExpr,
    SQLFromItem,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLJoin,
    SQLLiteral,
    SQLNot,
    SQLOrderItem,
    SQLPlaceholder,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSingletonSource,
    SQLSource,
    SQLStar,
    SQLSubquerySource,
    SQLTableSource,
    SQLTableFunctionSource,
    SQLTryCast,
    SQLUnboundVar,
    SQLUnionQuery,
    SQLValuesSource,
    SQLWindowCall,
)


BindingOrigin = Literal["store", "derived"]


@dataclass(frozen=True, slots=True)
class Binding:
    expr: SQLExpr
    alias: str | None = None
    source_object: str | None = None
    origin: BindingOrigin = "derived"


@dataclass(frozen=True, slots=True)
class FromItem:
    source: SQLSource
    alias: str


@dataclass(frozen=True, slots=True)
class JoinItem:
    kind: str
    source: SQLSource
    alias: str
    conditions: tuple[SQLExpr, ...]


@dataclass
class SelectQuery:
    from_item: FromItem | None = None
    joins: list[JoinItem] = field(default_factory=list)
    where: list[SQLExpr] = field(default_factory=list)
    select: list[SQLSelectItem] = field(default_factory=list)
    group_by: list[SQLExpr] = field(default_factory=list)
    order_by: list[SQLOrderItem] = field(default_factory=list)
    distinct: bool = False

    def to_ir(self) -> SQLSelectQuery:
        from_item = None
        if self.from_item is not None:
            from_item = SQLFromItem(source=self.from_item.source, alias=self.from_item.alias)
        return SQLSelectQuery(
            from_item=from_item,
            joins=tuple(
                SQLJoin(kind=join.kind, source=join.source, alias=join.alias, conditions=join.conditions)
                for join in self.joins
            ),
            where=tuple(self.where),
            select=tuple(self.select),
            group_by=tuple(self.group_by),
            order_by=tuple(self.order_by),
            distinct=self.distinct,
        )

    def clone(self) -> SelectQuery:
        from_item = None
        if self.from_item is not None:
            from_item = FromItem(source=self.from_item.source, alias=self.from_item.alias)
        return SelectQuery(
            from_item=from_item,
            joins=list(self.joins),
            where=list(self.where),
            select=list(self.select),
            group_by=list(self.group_by),
            order_by=list(self.order_by),
            distinct=self.distinct,
        )


class Lowerer:
    _COMPARATORS = {"=", "!=", "<", "<=", ">", ">="}
    _ARITHMETIC = {"+", "-", "*", "/", "//", "%", "^"}
    _BUILTIN_ALIASES = {"len": "length", "maximum": "greatest", "minimum": "least"}
    _BUILTIN_PREDICATES = {"starts_with", "ends_with", "contains", "like", "regex_match", "isinf", "isnan"}

    def __init__(self, catalog: Catalog) -> None:
        self.catalog = catalog
        self._alias_counter = 0

    def lower_model(self, model_plan: SQL9ModelPlan) -> SQL9ExecutionPlan:
        steps: list[SQL9ExecutionStep] = []
        seed_views = self._seed_views(model_plan.seed_object_names)
        if seed_views:
            steps.append(SQL9ExecutionStep(views=seed_views))
        for stratum in model_plan.strata:
            steps.extend(self._lower_stratum(stratum))
        return SQL9ExecutionPlan(steps=tuple(steps))

    def _lower_stratum(self, stratum: SQL9PlanStratum) -> list[SQL9ExecutionStep]:
        steps: list[SQL9ExecutionStep] = []
        pending_views: list[SQL9View] = []
        for item in stratum.items:
            if isinstance(item, SQL9TargetPlan):
                view = self._lower_target_view(item)
                if view is not None:
                    pending_views.append(view)
                continue

            loop = self._lower_recursive_component(item)
            if pending_views:
                steps.append(SQL9ExecutionStep(views=tuple(pending_views)))
                pending_views = []
            if loop is not None and loop.tables:
                steps.append(SQL9ExecutionStep(semi_naive_loops=(loop,)))
        if pending_views:
            steps.append(SQL9ExecutionStep(views=tuple(pending_views)))
        return steps

    def _seed_views(self, seed_object_names: tuple[str, ...]) -> tuple[SQL9View, ...]:
        if not seed_object_names:
            return ()
        entity_stores = {store.object_name: store for store in self.catalog.entity_stores}
        relation_stores = {store.object_name: store for store in self.catalog.relation_stores}
        views: list[SQL9View] = []
        for object_name in seed_object_names:
            store = entity_stores.get(object_name) or relation_stores.get(object_name)
            if store is None:
                continue
            views.append(self._empty_store_view(store.object_name, tuple(column.name for column in store.columns)))
        return tuple(views)

    def _empty_store_view(self, name: str, column_names: tuple[str, ...]) -> SQL9View:
        alias = "empty_rows"
        query = SQLSelectQuery(
            from_item=SQLFromItem(source=SQLValuesSource(column_names=column_names), alias=alias),
            select=tuple(SQLSelectItem(SQLColumnRef(column_name, alias), alias=column_name) for column_name in column_names),
        )
        return SQL9View(name=name, query=query)

    def lower_fragment(self, task: mm.Task) -> SQLQuery | None:
        if not isinstance(task, mm.Logical):
            return None
        bindings: dict[int, Binding] = {}
        query = SelectQuery()
        updates = [child for child in task.body if isinstance(child, mm.Update)]

        self._lower_logical(task, bindings, query, include_updates=False, nullable_aggregates=False)
        self._ensure_from(query)
        query.select = self._select_list_from_fragment(task, updates, bindings) if updates else [SQLSelectItem(SQLLiteral(1))]
        query.distinct = self._contains_aggregate(task)
        query.order_by = self._default_order_by(query.select)
        return query.to_ir()

    def lower_target_select(self, task: mm.Logical, target: Target) -> SQLQuery | None:
        bindings: dict[int, Binding] = {}
        query = SelectQuery()
        self._lower_logical(task, bindings, query, include_updates=False, nullable_aggregates=False)
        self._ensure_from(query)
        projections = self._project_target(task, target, bindings)
        if projections is None:
            return None
        query.select = projections
        if target.kind == "relation":
            query.where.extend(SQLIsNotNull(item.expr) for item in projections)
        return query.to_ir()

    def _lower_target_view(self, target_plan: SQL9TargetPlan) -> SQL9View | None:
        selects: list[SQLQuery] = []
        has_prior = target_plan.prior_table is not None
        if target_plan.prior_table is not None:
            prior_name = target_plan.prior_table.uri or target_plan.prior_table.name
            selects.append(self._select_all_from_source(target_plan.target, prior_name))
        for task in target_plan.tasks:
            sql = self.lower_target_select(task, target_plan.target)
            if sql is not None:
                selects.append(sql)
        if not selects:
            return None
        query_sql = self._coalesce_target_query(
            target_plan.target,
            selects,
            has_prior=has_prior,
            requires_coalesce=target_plan.requires_coalesce,
        )
        return SQL9View(
            name=target_plan.output_table.uri or target_plan.output_table.name,
            query=query_sql,
        )

    def _lower_recursive_component(self, component_plan: SQL9RecursiveComponentPlan) -> SQL9SemiNaiveLoop | None:
        accum_name_by_marker: dict[str, str] = {}
        delta_name_by_marker: dict[str, str] = {}
        next_delta_name_by_marker: dict[str, str] = {}
        table_names_by_marker: dict[str, str] = {}
        empty_query_by_marker: dict[str, SQLQuery] = {}
        # Each recursive SCC is evaluated as one synchronized loop, with one
        # logical marker table per target rewritten to accum/delta views later.
        for target_plan in component_plan.targets:
            marker_name = target_plan.marker_table.uri or target_plan.marker_table.name
            table_name = target_plan.output_table.uri or target_plan.output_table.name
            temp_prefix = self._semi_naive_temp_prefix(table_name)
            accum_name_by_marker[marker_name] = f"{temp_prefix}__accum"
            delta_name_by_marker[marker_name] = f"{temp_prefix}__delta"
            next_delta_name_by_marker[marker_name] = f"{temp_prefix}__next_delta"
            table_names_by_marker[marker_name] = table_name
            empty_query_by_marker[marker_name] = self._empty_target_query(target_plan.target)

        loop_tables: list[SQL9SemiNaiveTable] = []
        for target_plan in component_plan.targets:
            marker_name = target_plan.marker_table.uri or target_plan.marker_table.name
            table_name = table_names_by_marker[marker_name]
            accum_name = accum_name_by_marker[marker_name]
            delta_name = delta_name_by_marker[marker_name]
            next_delta_name = next_delta_name_by_marker[marker_name]

            base_query = self._lower_recursive_base_query(
                target_plan,
                empty_query_by_marker=empty_query_by_marker,
            )
            delta_query = self._lower_recursive_delta_query(
                target_plan,
                accum_name_by_marker=accum_name_by_marker,
                delta_name_by_marker=delta_name_by_marker,
            )
            merge_query = self._coalesce_target_query(
                target_plan.target,
                [
                    self._select_all_from_source(target_plan.target, accum_name),
                    self._select_all_from_source(target_plan.target, next_delta_name),
                ],
                has_prior=False,
                requires_coalesce=True,
            )
            final_query = self._select_all_from_source(target_plan.target, accum_name)
            loop_tables.append(
                SQL9SemiNaiveTable(
                    table_name=table_name,
                    columns=target_plan.target.column_names,
                    base_query=base_query,
                    delta_query=delta_query,
                    merge_query=merge_query,
                    final_query=final_query,
                    accum_view_name=accum_name,
                    delta_view_name=delta_name,
                    next_delta_view_name=next_delta_name,
                )
            )

        return SQL9SemiNaiveLoop(tables=tuple(loop_tables)) if loop_tables else None

    def _lower_recursive_base_query(
        self,
        target_plan: SQL9RecursiveTargetPlan,
        *,
        empty_query_by_marker: dict[str, SQLQuery],
    ) -> SQLQuery:
        selects: list[SQLQuery] = []
        has_prior = target_plan.prior_table is not None
        if target_plan.prior_table is not None:
            prior_name = target_plan.prior_table.uri or target_plan.prior_table.name
            selects.append(self._select_all_from_source(target_plan.target, prior_name))
        for task in target_plan.seed_tasks:
            sql = self.lower_target_select(task, target_plan.target)
            if sql is not None:
                selects.append(sql)
        # Recursive rules can embed their own base case via `union(...)`; seed
        # the loop by evaluating those branches against empty recursive inputs.
        for task in target_plan.recursive_tasks:
            sql = self.lower_target_select(task, target_plan.target)
            if sql is not None:
                selects.append(
                    self._rewrite_recursive_marker_refs_to_empty(
                        query=sql,
                        empty_query_by_marker=empty_query_by_marker,
                    )
                )
        if not selects:
            return self._empty_target_query(target_plan.target)
        return self._coalesce_target_query(
            target_plan.target,
            selects,
            has_prior=has_prior,
            requires_coalesce=target_plan.requires_coalesce,
        )

    def _lower_recursive_delta_query(
        self,
        target_plan: SQL9RecursiveTargetPlan,
        *,
        accum_name_by_marker: dict[str, str],
        delta_name_by_marker: dict[str, str],
    ) -> SQLQuery:
        delta_variants: list[SQLQuery] = []
        for task in target_plan.recursive_tasks:
            lowered = self.lower_target_select(task, target_plan.target)
            if lowered is None:
                continue
            delta_variants.extend(
                self._build_semi_naive_delta_variants(
                    lowered,
                    accum_name_by_marker=accum_name_by_marker,
                    delta_name_by_marker=delta_name_by_marker,
                )
            )
        if not delta_variants:
            return self._empty_target_query(target_plan.target)
        return self._coalesce_target_query(
            target_plan.target,
            delta_variants,
            has_prior=False,
            requires_coalesce=target_plan.requires_coalesce,
        )

    def _semi_naive_temp_prefix(self, table_name: str) -> str:
        return table_name.replace(".", "__")

    def _select_all_from_source(self, target: Target, source_name: str) -> SQLQuery:
        return SQLSelectQuery(
            select=tuple(SQLSelectItem(SQLColumnRef(column_name)) for column_name in target.column_names),
            from_item=SQLFromItem(source=SQLTableSource(source_name), alias="carry"),
        )

    def _empty_target_query(self, target: Target) -> SQLQuery:
        alias = "empty_rows"
        return SQLSelectQuery(
            from_item=SQLFromItem(source=SQLValuesSource(column_names=target.column_names), alias=alias),
            select=tuple(SQLSelectItem(SQLColumnRef(column_name, alias), alias=column_name) for column_name in target.column_names),
        )

    def _coalesce_target_query(
        self,
        target: Target,
        selects: list[SQLQuery],
        *,
        has_prior: bool,
        requires_coalesce: bool,
    ) -> SQLQuery:
        if target.kind == "entity" and not has_prior and len(selects) == 1 and not requires_coalesce:
            return selects[0]
        if target.kind != "entity":
            return SQLSelectQuery(
                distinct=True,
                select=tuple(SQLSelectItem(SQLColumnRef(column_name, "merged"), alias=column_name) for column_name in target.column_names),
                from_item=SQLFromItem(
                    source=SQLSubquerySource(SQLUnionQuery(queries=tuple(selects), operator="UNION ALL")),
                    alias="merged",
                ),
            )
        key_columns = target.key_columns or ("_id",)
        non_key_columns = [column for column in target.column_names if column not in key_columns]
        return SQLSelectQuery(
            select=tuple(
                [
                    *(SQLSelectItem(SQLColumnRef(column_name), alias=column_name) for column_name in key_columns),
                    *(
                        SQLSelectItem(
                            SQLFunctionCall("MAX", (SQLColumnRef(column_name),)),
                            alias=column_name,
                        )
                        for column_name in non_key_columns
                    ),
                ]
            ),
            from_item=SQLFromItem(
                source=SQLSubquerySource(SQLUnionQuery(queries=tuple(selects), operator="UNION ALL")),
                alias="merged",
            ),
            group_by=tuple(SQLColumnRef(column_name) for column_name in key_columns),
        )

    def _build_semi_naive_delta_variants(
        self,
        query: SQLQuery,
        *,
        accum_name_by_marker: dict[str, str],
        delta_name_by_marker: dict[str, str],
    ) -> list[SQLQuery]:
        marker_names = set(accum_name_by_marker)
        marker_ref_count = self._count_recursive_marker_refs(query, marker_names=marker_names)
        if marker_ref_count == 0:
            return [query]
        # Standard semi-naive expansion: one variant per recursive read
        # position, with exactly one read bound to delta and the rest to accum.
        variants: list[SQLQuery] = []
        for delta_ref_ix in range(marker_ref_count):
            variants.append(
                self._rewrite_recursive_marker_refs(
                    query=query,
                    marker_names=marker_names,
                    accum_name_by_marker=accum_name_by_marker,
                    delta_name_by_marker=delta_name_by_marker,
                    delta_ref_ix=delta_ref_ix,
                )
            )
        return variants

    def _rewrite_recursive_marker_refs_to_empty(
        self,
        *,
        query: SQLQuery,
        empty_query_by_marker: dict[str, SQLQuery],
    ) -> SQLQuery:
        def rewrite_source(source: SQLSource) -> SQLSource:
            if isinstance(source, SQLTableSource) and source.name in empty_query_by_marker:
                return SQLSubquerySource(empty_query_by_marker[source.name])
            return source
        return self._map_sql_query(query, source_fn=rewrite_source)

    def _count_recursive_marker_refs(self, query: SQLQuery, *, marker_names: set[str]) -> int:
        count = 0

        def count_source(source: SQLSource) -> SQLSource:
            nonlocal count
            if isinstance(source, SQLTableSource):
                count += int(source.name in marker_names)
            return source

        self._map_sql_query(query, source_fn=count_source)
        return count

    def _rewrite_recursive_marker_refs(
        self,
        *,
        query: SQLQuery,
        marker_names: set[str],
        accum_name_by_marker: dict[str, str],
        delta_name_by_marker: dict[str, str],
        delta_ref_ix: int,
    ) -> SQLQuery:
        seen_ref_ix = 0

        def rewrite_source(source: SQLSource) -> SQLSource:
            nonlocal seen_ref_ix
            if isinstance(source, SQLTableSource) and source.name in marker_names:
                replacement = (
                    delta_name_by_marker[source.name]
                    if seen_ref_ix == delta_ref_ix
                    else accum_name_by_marker[source.name]
                )
                seen_ref_ix += 1
                return SQLTableSource(replacement)
            return source
        return self._map_sql_query(query, source_fn=rewrite_source)

    def _map_sql_query(
        self,
        query: SQLQuery,
        *,
        source_fn: Callable[[SQLSource], SQLSource] | None = None,
        expr_fn: Callable[[SQLExpr], SQLExpr] | None = None,
    ) -> SQLQuery:
        source_fn = source_fn or (lambda source: source)
        expr_fn = expr_fn or (lambda expr: expr)

        def rewrite_query(inner: SQLQuery) -> SQLQuery:
            if isinstance(inner, SQLUnionQuery):
                return SQLUnionQuery(
                    queries=tuple(rewrite_query(part) for part in inner.queries),
                    operator=inner.operator,
                )
            assert isinstance(inner, SQLSelectQuery)
            return SQLSelectQuery(
                from_item=rewrite_from_item(inner.from_item),
                joins=tuple(rewrite_join(join) for join in inner.joins),
                where=tuple(rewrite_expr(expr) for expr in inner.where),
                select=tuple(SQLSelectItem(rewrite_expr(item.expr), alias=item.alias) for item in inner.select),
                group_by=tuple(rewrite_expr(expr) for expr in inner.group_by),
                order_by=tuple(SQLOrderItem(rewrite_expr(item.expr), descending=item.descending) for item in inner.order_by),
                distinct=inner.distinct,
                limit=inner.limit,
            )

        def rewrite_from_item(from_item: SQLFromItem | None) -> SQLFromItem | None:
            if from_item is None:
                return None
            return SQLFromItem(source=rewrite_source(from_item.source), alias=from_item.alias)

        def rewrite_join(join: SQLJoin) -> SQLJoin:
            return SQLJoin(
                kind=join.kind,
                source=rewrite_source(join.source),
                alias=join.alias,
                conditions=tuple(rewrite_expr(expr) for expr in join.conditions),
            )

        def rewrite_source(source: SQLSource) -> SQLSource:
            if isinstance(source, SQLSubquerySource):
                source = SQLSubquerySource(rewrite_query(source.query))
            return source_fn(source)

        def rewrite_expr(expr: SQLExpr) -> SQLExpr:
            if isinstance(expr, SQLBinaryOp):
                expr = SQLBinaryOp(rewrite_expr(expr.left), expr.operator, rewrite_expr(expr.right))
            elif isinstance(expr, SQLFunctionCall):
                expr = SQLFunctionCall(expr.name, tuple(rewrite_expr(arg) for arg in expr.args), sql_type=expr.sql_type)
            elif isinstance(expr, SQLWindowCall):
                expr = SQLWindowCall(
                    function_name=expr.function_name,
                    partition_by=tuple(rewrite_expr(arg) for arg in expr.partition_by),
                    order_by=tuple(SQLOrderItem(rewrite_expr(item.expr), descending=item.descending) for item in expr.order_by),
                )
            elif isinstance(expr, SQLCast):
                expr = SQLCast(rewrite_expr(expr.expr), expr.type_name)
            elif isinstance(expr, SQLTryCast):
                expr = SQLTryCast(rewrite_expr(expr.expr), expr.type_name)
            elif isinstance(expr, SQLIsNotNull):
                expr = SQLIsNotNull(rewrite_expr(expr.expr))
            elif isinstance(expr, SQLNot):
                expr = SQLNot(rewrite_expr(expr.expr))
            elif isinstance(expr, SQLConcat):
                expr = SQLConcat(tuple(rewrite_expr(arg) for arg in expr.args))
            elif isinstance(expr, SQLExists):
                expr = SQLExists(rewrite_query(expr.query))
            return expr_fn(expr)

        return rewrite_query(query)

    def _lower_logical(
        self,
        task: mm.Logical,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        include_updates: bool,
        nullable_aggregates: bool,
        optional_context: bool = False,
    ) -> None:
        deferred_constructs: list[mm.Construct] = []
        deferred_lookups: list[mm.Lookup] = []
        deferred_nots: list[mm.Not] = []
        rowset_query = query.clone()
        body = tuple(task.body)
        for index, child in enumerate(body):
            if isinstance(child, mm.Construct):
                if self._can_bind_construct_now(child, bindings):
                    bindings[child.id_var.id] = Binding(expr=self._construct_identity(child, bindings))
                else:
                    deferred_constructs.append(child)
                continue
            if isinstance(child, mm.Lookup):
                if self._should_defer_lookup(child, bindings, optional_context=optional_context):
                    deferred_lookups.append(child)
                    continue
                self._lower_lookup(child, bindings, query, optional_context=optional_context)
                rowset_query = query.clone()
                continue
            if isinstance(child, mm.Union):
                demanded_var_ids = self._later_demanded_var_ids(body[index + 1 :], bindings)
                self._lower_union(
                    child,
                    bindings,
                    query,
                    optional_context=optional_context,
                    demanded_var_ids=demanded_var_ids,
                )
                rowset_query = query.clone()
                continue
            if isinstance(child, mm.Match):
                self._lower_match(child, bindings, query)
                rowset_query = query.clone()
                continue
            if isinstance(child, mm.Not):
                if self._should_defer_not(child, bindings, body[index + 1:]):
                    deferred_nots.append(child)
                    continue
                self._lower_not(child, bindings, query)
                rowset_query = query.clone()
                continue
            if isinstance(child, mm.Aggregate):
                aggregate_base_query = query.clone() if self._task_depends_on_synthetic_binding(child, bindings) else rowset_query
                self._lower_aggregate(
                    child,
                    bindings,
                    query,
                    base_query=aggregate_base_query,
                    nullable=nullable_aggregates,
                )
                continue
            if isinstance(child, mm.Logical):
                if child.optional and self._lower_aggregate_scope(
                    child,
                    bindings,
                    query,
                    base_query=rowset_query,
                ):
                    continue
                if child.optional:
                    self._lower_optional(child, bindings, query)
                else:
                    self._lower_logical(
                        child,
                        bindings,
                        query,
                        include_updates=include_updates,
                        nullable_aggregates=nullable_aggregates,
                        optional_context=optional_context,
                    )
                rowset_query = query.clone()
                continue
            if isinstance(child, mm.Update) and include_updates:
                continue

        for lookup in deferred_lookups:
            self._lower_lookup(lookup, bindings, query, optional_context=optional_context)
            rowset_query = query.clone()

        for construct in deferred_constructs:
            bindings[construct.id_var.id] = Binding(expr=self._construct_identity(construct, bindings))

        for not_task in deferred_nots:
            self._lower_not(not_task, bindings, query)

    def _lower_aggregate_scope(
        self,
        task: mm.Logical,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        base_query: SelectQuery,
    ) -> bool:
        support_tasks, aggregates = self._aggregate_scope_parts(task)
        if not aggregates or (not support_tasks and len(aggregates) < 2):
            return False
        first = aggregates[0]
        group_vars = tuple(var for var in first.group if isinstance(var, mm.Var))
        projection_vars = tuple(var for var in first.projection if isinstance(var, mm.Var))
        if any(
            tuple(var for var in aggregate.group if isinstance(var, mm.Var)) != group_vars
            or tuple(var for var in aggregate.projection if isinstance(var, mm.Var)) != projection_vars
            for aggregate in aggregates[1:]
        ):
            return False

        scope_bindings = dict(bindings)
        scope_query = base_query.clone()
        if support_tasks:
            self._lower_logical(
                mm.Logical(body=support_tasks, scope=True),
                scope_bindings,
                scope_query,
                include_updates=False,
                nullable_aggregates=False,
                optional_context=True,
            )
        if len(aggregates) == 1:
            self._lower_aggregate(
                aggregates[0],
                bindings,
                query,
                base_query=scope_query,
                nullable=True,
                outer_bindings=scope_bindings,
            )
            return True

        base_query = scope_query.clone()
        self._ensure_from(base_query)
        base_signature = self._query_signature(base_query)
        lowered_aggregates: list[tuple[mm.Aggregate, dict[int, Binding], SelectQuery]] = []
        for aggregate in aggregates:
            inner_task = aggregate.body if isinstance(aggregate.body, mm.Logical) else mm.Logical(body=(aggregate.body,))
            inner_bindings = dict(scope_bindings)
            inner_query = scope_query.clone()
            self._lower_logical(
                inner_task,
                inner_bindings,
                inner_query,
                include_updates=False,
                nullable_aggregates=False,
                optional_context=True,
            )
            self._ensure_from(inner_query)
            if self._query_signature(inner_query) != base_signature:
                return False
            lowered_aggregates.append((aggregate, inner_bindings, inner_query))

        aggregate_query = self._packed_aggregate_query(
            lowered_aggregates,
            base_query,
            group_vars=group_vars,
            projection_vars=projection_vars,
        )
        outer_alias = self._next_alias()
        join_conditions = self._join_conditions_for_columns(bindings, group_vars, outer_alias, bind_missing=True)
        for index, aggregate in enumerate(aggregates):
            output_arg = aggregate.args[-1] if aggregate.args else None
            if isinstance(output_arg, mm.Var):
                bindings[output_arg.id] = Binding(expr=SQLColumnRef(f"a{index}", outer_alias), alias=outer_alias)

        aggregate_source = SQLSubquerySource(aggregate_query.to_ir())
        if query.from_item is None and not query.joins and not query.where:
            query.from_item = FromItem(source=aggregate_source, alias=outer_alias)
            return True

        self._ensure_from(query)
        query.joins.append(
            JoinItem(
                kind="LEFT JOIN",
                source=aggregate_source,
                alias=outer_alias,
                conditions=tuple(join_conditions or [SQLLiteral(True)]),
            )
        )
        return True

    def _lower_lookup(
        self,
        lookup: mm.Lookup,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> None:
        relation = lookup.relation
        args = lookup.args

        if self._lower_named_lookup(relation, args, bindings, query, optional_context=optional_context):
            return
        self._lower_storage_lookup(relation, args, bindings, query, optional_context=optional_context)

    def _lower_named_lookup(
        self,
        relation: mm.Relation,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> bool:
        name = relation.name
        if name in self._COMPARATORS:
            self._lower_comparator_lookup(name, args, bindings, query)
            return True
        if name == "cast" and len(args) >= 3:
            self._lower_cast_lookup(args, bindings)
            return True
        if name in self._ARITHMETIC and len(args) >= 3:
            self._lower_arithmetic_lookup(name, args, bindings)
            return True
        if name == "range" and len(args) >= 4:
            self._lower_range(args, bindings, query, optional_context=optional_context)
            return True
        if name == "split" and len(args) >= 4:
            self._lower_split(args, bindings, query, optional_context=optional_context)
            return True
        if self._is_builtin_function_relation(relation):
            self._lower_builtin_lookup(name, args, bindings, query)
            return True
        return False

    def _lower_storage_lookup(
        self,
        relation: mm.Relation,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> None:
        if isinstance(relation, mm.Table):
            self._lower_table_lookup(relation, args, bindings, query, optional_context=optional_context)
            return
        if isinstance(relation, mm.Data):
            store = self.catalog.data_store(relation)
            self._lower_store_row_lookup(
                self._data_store_source(store),
                ("__rowid",),
                args[:1],
                bindings,
                query,
                source_object=store.source_name or store.object_name,
            )
            return
        if (store := self._catalog_store(self.catalog.data_store, relation)) is not None:
            self._lower_store_row_lookup(
                self._data_store_source(store),
                ("__rowid",),
                args[:1],
                bindings,
                query,
                source_object=store.source_name or store.object_name,
            )
            return
        if self.catalog.is_data_column(relation):
            store = self.catalog.data_store_for_column(relation)
            self._lower_store_value_lookup(
                self._data_store_source(store),
                "__rowid",
                relation.name,
                args,
                bindings,
                query,
                source_object=store.source_name or store.object_name,
            )
            return
        if (store := self._catalog_store(self.catalog.entity_store, relation)) is not None:
            self._lower_store_row_lookup(
                SQLTableSource(store.object_name),
                ("_id",),
                args[:1],
                bindings,
                query,
                source_object=store.object_name,
                optional_mode="unbound" if optional_context else "never",
            )
            return
        if self.catalog.is_folded_property(relation):
            store = self.catalog.owner_store_for_property(relation)
            self._lower_store_value_lookup(
                SQLTableSource(store.object_name),
                "_id",
                relation.name,
                args,
                bindings,
                query,
                source_object=store.object_name,
                allow_optional_attach=optional_context,
                emit_not_null=not optional_context,
            )
            return
        if (store := self._catalog_store(self.catalog.relation_store, relation)) is not None:
            self._lower_store_row_lookup(
                SQLTableSource(store.object_name),
                tuple(column.name for column in store.columns),
                args,
                bindings,
                query,
                source_object=store.object_name,
                optional_mode="non_synthetic" if optional_context else "never",
            )

    def _lower_comparator_lookup(
        self,
        name: str,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
    ) -> None:
        if name == "=" and len(args) >= 2:
            left_arg, right_arg = args[0], args[1]
            left_unbound = isinstance(left_arg, mm.Var) and left_arg.id not in bindings
            right_unbound = isinstance(right_arg, mm.Var) and right_arg.id not in bindings
            if left_unbound and not right_unbound:
                bindings[left_arg.id] = Binding(expr=self._coerce_expr_for_var(left_arg, right_arg, bindings))
                return
            if right_unbound and not left_unbound:
                bindings[right_arg.id] = Binding(expr=self._coerce_expr_for_var(right_arg, left_arg, bindings))
                return
            left_expr = self._resolve(left_arg, bindings)
            right_expr = self._resolve(right_arg, bindings)
            if self._is_placeholder_expr(left_expr) and not self._is_placeholder_expr(right_expr):
                self._rebind_placeholder(bindings, left_expr, right_expr)
                return
            if self._is_placeholder_expr(right_expr) and not self._is_placeholder_expr(left_expr):
                self._rebind_placeholder(bindings, right_expr, left_expr)
                return
            if self._is_placeholder_expr(left_expr) and self._is_placeholder_expr(right_expr):
                self._rebind_placeholder(bindings, right_expr, left_expr)
                return
        query.where.append(SQLBinaryOp(self._resolve(args[0], bindings), name, self._resolve(args[1], bindings)))

    def _lower_cast_lookup(self, args: tuple, bindings: dict[int, Binding]) -> None:
        target_type, source_arg, target_arg = args[0], args[1], args[2]
        if isinstance(target_arg, mm.Var):
            source_expr = self._cast_source_expr(source_arg, self._resolve(source_arg, bindings), target_type)
            if isinstance(source_arg, mm.Var) and source_arg.id not in bindings and isinstance(source_expr, SQLUnboundVar):
                placeholder = self._placeholder(source_arg.id)
                bindings[source_arg.id] = Binding(expr=placeholder)
                bindings[target_arg.id] = Binding(expr=placeholder)
                return
            bindings[target_arg.id] = Binding(expr=source_expr)
            if isinstance(source_arg, mm.Var) and source_arg.id not in bindings and self._is_placeholder_expr(source_expr):
                bindings[source_arg.id] = Binding(expr=source_expr)
            return
        if isinstance(source_arg, mm.Var) and isinstance(target_arg, mm.Var):
            target_expr = self._resolve(target_arg, bindings)
            if self._is_placeholder_expr(target_expr):
                bindings[source_arg.id] = Binding(expr=target_expr)

    def _lower_arithmetic_lookup(self, name: str, args: tuple, bindings: dict[int, Binding]) -> None:
        result = args[-1]
        if not isinstance(result, mm.Var):
            return
        operator = "/" if name == "//" else name
        expr = SQLBinaryOp(self._resolve(args[0], bindings), operator, self._resolve(args[1], bindings))
        bindings[result.id] = Binding(expr=self._cast_expr_to_type(expr, result.type))

    def _lower_builtin_lookup(
        self,
        name: str,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
    ) -> None:
        result = args[-1] if args and name not in self._BUILTIN_PREDICATES else None
        expr = self._builtin_expr(name, args, bindings, result.type if isinstance(result, mm.Var) else None)
        if name in self._BUILTIN_PREDICATES:
            query.where.append(expr)
            return
        if isinstance(result, mm.Var):
            bindings[result.id] = Binding(expr=self._cast_expr_to_type(expr, result.type))

    def _builtin_expr(
        self,
        name: str,
        args: tuple,
        bindings: dict[int, Binding],
        result_type,
    ) -> SQLExpr:
        if name == "concat":
            return SQLConcat(tuple(self._resolve(arg, bindings) for arg in args[:-1]))
        if name == "join" and len(args) >= 3 and isinstance(args[0], tuple):
            separator_expr = self._resolve(args[1], bindings)
            pieces: list[SQLExpr] = []
            for index, part in enumerate(args[0]):
                if index > 0:
                    pieces.append(separator_expr)
                pieces.append(self._resolve(part, bindings))
            return SQLConcat(tuple(pieces)) if pieces else SQLLiteral("")
        if name == "hash" and len(args) >= 2 and isinstance(args[0], tuple):
            return SQLFunctionCall(name, tuple(self._resolve(part, bindings) for part in args[0]))
        input_args = args[:-1] if name not in self._BUILTIN_PREDICATES else args
        return SQLFunctionCall(
            self._builtin_sql_name(name),
            tuple(self._resolve(arg, bindings) for arg in input_args),
            sql_type=self._sql_type_for_type(result_type),
        )

    def _builtin_sql_name(self, name: str) -> str:
        return self._BUILTIN_ALIASES.get(name, name)

    def _is_builtin_function_relation(self, relation: mm.Relation) -> bool:
        if relation.name in self._BUILTIN_PREDICATES:
            return any(relation.name in library.data for library in builtin_registry._libraries.values())
        if not is_function(relation):
            return False
        return any(relation.name in library.data for library in builtin_registry._libraries.values())

    def _lower_table_lookup(
        self,
        table: mm.Table,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> None:
        if (data_store := self._catalog_store(self.catalog.data_store, table)) is not None:
            self._lower_store_row_lookup(
                self._data_store_source(data_store),
                ("__rowid",),
                args[:1],
                bindings,
                query,
                source_object=data_store.source_name or data_store.object_name,
            )
            return

        primary_relation = self._table_primary_relation(table)
        if primary_relation is None:
            return
        source_name = table.uri or table.name

        if self.catalog.is_data_column(primary_relation):
            store = self.catalog.data_store_for_column(primary_relation)
            self._lower_store_value_lookup(
                self._data_store_source(store, source_name=source_name),
                "__rowid",
                primary_relation.name,
                args,
                bindings,
                query,
                source_object=source_name or store.source_name or store.object_name,
            )
            return

        if (self._catalog_store(self.catalog.entity_store, primary_relation)) is not None:
            self._lower_store_row_lookup(
                SQLTableSource(source_name),
                ("_id",),
                args[:1],
                bindings,
                query,
                source_object=source_name,
                optional_mode="unbound" if optional_context else "never",
            )
            return

        if self.catalog.is_folded_property(primary_relation):
            self._lower_store_value_lookup(
                SQLTableSource(source_name),
                "_id",
                primary_relation.name,
                args,
                bindings,
                query,
                source_object=source_name,
                allow_optional_attach=optional_context,
                emit_not_null=not optional_context,
            )
            return

        if (relation_store := self._catalog_store(self.catalog.relation_store, primary_relation)) is not None:
            self._lower_store_row_lookup(
                SQLTableSource(source_name),
                tuple(column.name for column in relation_store.columns),
                args,
                bindings,
                query,
                source_object=source_name,
                optional_mode="non_synthetic" if optional_context else "never",
            )

    def _lower_split(
        self,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> None:
        self._lower_table_function_lookup(
            SQLTableFunctionSource(
                function_name="STRING_SPLIT",
                args=(self._resolve(args[0], bindings), self._resolve(args[1], bindings)),
                column_names=("result", "index"),
                with_ordinality=True,
                zero_based_ordinality=True,
                unnest=True,
            ),
            bound_columns=((args[2], "index"), (args[3], "result")),
            bindings=bindings,
            query=query,
            optional_context=optional_context,
        )

    def _lower_range(
        self,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool,
    ) -> None:
        self._lower_table_function_lookup(
            SQLTableFunctionSource(
                function_name="RANGE",
                args=(
                    SQLCast(self._resolve(args[0], bindings), "BIGINT"),
                    SQLCast(self._resolve(args[1], bindings), "BIGINT"),
                    SQLCast(self._resolve(args[2], bindings), "BIGINT"),
                ),
                column_names=("value",),
            ),
            bound_columns=((args[3], "value"),),
            bindings=bindings,
            query=query,
            optional_context=optional_context,
        )

    def _lower_table_function_lookup(
        self,
        source: SQLTableFunctionSource,
        *,
        bound_columns: tuple[tuple[object, str], ...],
        bindings: dict[int, Binding],
        query: SelectQuery,
        optional_context: bool,
    ) -> None:
        alias = self._next_alias()
        conditions: list[SQLExpr] = []
        for arg, column_name in bound_columns:
            if isinstance(arg, mm.Var):
                binding = bindings.get(arg.id)
                if binding is not None:
                    conditions.append(SQLBinaryOp(SQLColumnRef(column_name, alias), "=", binding.expr))
            elif isinstance(arg, mm.Literal):
                conditions.append(SQLBinaryOp(SQLColumnRef(column_name, alias), "=", self._literal(arg.value)))

        if optional_context and query.from_item is not None:
            self._attach_optional_source(query, source, alias, conditions=tuple(conditions))
        else:
            self._attach_source(query, source, alias, conditions=tuple(conditions))

        for arg, column_name in bound_columns:
            if isinstance(arg, mm.Var) and arg.id not in bindings:
                bindings[arg.id] = Binding(expr=SQLColumnRef(column_name, alias), alias=alias)

    def _data_store_source(self, store: DataStore, *, source_name: str | None = None) -> SQLSource:
        external_name = source_name or store.source_name
        if external_name is not None:
            alias = "source_rows"
            return SQLSubquerySource(
                SQLSelectQuery(
                    from_item=SQLFromItem(source=SQLTableSource(external_name), alias=alias),
                    select=tuple(
                        [
                            SQLSelectItem(
                                SQLBinaryOp(SQLWindowCall("ROW_NUMBER"), "-", SQLLiteral(1)),
                                alias="__rowid",
                            ),
                            *(
                                SQLSelectItem(SQLColumnRef(column.name, alias), alias=column.name)
                                for column in store.columns
                                if column.name != "__rowid"
                            ),
                        ]
                    ),
                )
            )
        return SQLValuesSource(
            column_names=tuple(column.name for column in store.columns),
            rows=tuple(tuple(self._literal(value) for value in row) for row in store.rows),
        )

    def _store_binding(
        self,
        expr: SQLExpr,
        *,
        alias: str,
        source_object: str,
    ) -> Binding:
        return Binding(expr=expr, alias=alias, source_object=source_object, origin="store")

    def _bind_or_constrain_store_arg(
        self,
        arg,
        column_sql: SQLExpr,
        bindings: dict[int, Binding],
        conditions: list[SQLExpr],
        *,
        alias: str,
        source_object: str,
    ) -> None:
        if isinstance(arg, mm.Var):
            binding = bindings.get(arg.id)
            if binding is None:
                bindings[arg.id] = self._store_binding(column_sql, alias=alias, source_object=source_object)
            else:
                conditions.append(SQLBinaryOp(column_sql, "=", binding.expr))
            return
        if isinstance(arg, mm.Literal):
            conditions.append(SQLBinaryOp(column_sql, "=", self._literal(arg.value)))

    def _lower_store_row_lookup(
        self,
        source: SQLSource,
        column_names: tuple[str, ...],
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        source_object: str,
        optional_mode: str = "never",
    ) -> None:
        alias = self._next_alias()
        owner_was_bound = bool(args and isinstance(args[0], mm.Var) and args[0].id in bindings)
        conditions: list[SQLExpr] = []
        for column_name, arg in zip(column_names, args):
            self._bind_or_constrain_store_arg(
                arg,
                SQLColumnRef(column_name, alias),
                bindings,
                conditions,
                alias=alias,
                source_object=source_object,
            )
        if query.from_item is not None and optional_mode == "unbound":
            if not owner_was_bound:
                self._attach_optional_source(query, source, alias, conditions=tuple(conditions))
                return
        if query.from_item is not None and optional_mode == "non_synthetic" and not self._args_depend_on_synthetic_binding(args, bindings):
            self._attach_optional_source(query, source, alias, conditions=tuple(conditions))
            return
        self._attach_source(query, source, alias, conditions=tuple(conditions))

    def _lower_store_value_lookup(
        self,
        source: SQLSource,
        id_column_name: str,
        column_name: str,
        args: tuple,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        source_object: str,
        allow_optional_attach: bool = False,
        emit_not_null: bool = False,
    ) -> None:
        owner_arg = args[0]
        value_arg = args[-1]
        owner_binding = bindings.get(owner_arg.id) if isinstance(owner_arg, mm.Var) else None
        alias = self._ensure_owner_store_alias(
            owner_arg,
            owner_binding,
            query,
            source,
            id_column_name=id_column_name,
            source_object=source_object,
            bindings=bindings,
            allow_optional_attach=(
                allow_optional_attach
                and query.from_item is not None
                and owner_binding is not None
                and owner_binding.source_object is not None
            ),
        )
        value_sql = SQLColumnRef(column_name, alias)
        if emit_not_null:
            query.where.append(SQLIsNotNull(value_sql))
        self._bind_or_constrain_store_arg(
            value_arg,
            value_sql,
            bindings,
            query.where,
            alias=alias,
            source_object=source_object,
        )

    def _catalog_store(self, getter, relation):
        try:
            return getter(relation)
        except KeyError:
            return None

    def _ensure_owner_store_alias(
        self,
        owner_arg,
        owner_binding: Binding | None,
        query: SelectQuery,
        source: SQLSource,
        *,
        id_column_name: str,
        source_object: str,
        bindings: dict[int, Binding],
        allow_optional_attach: bool = False,
    ) -> str:
        if (
            owner_binding is not None
            and owner_binding.alias is not None
            and owner_binding.source_object == source_object
        ):
            return owner_binding.alias

        alias = self._next_alias()
        join_conditions: tuple[SQLExpr, ...] = ()
        if owner_binding is not None:
            join_conditions = (SQLBinaryOp(SQLColumnRef(id_column_name, alias), "=", owner_binding.expr),)
        if allow_optional_attach:
            self._attach_optional_source(query, source, alias, conditions=join_conditions)
        else:
            self._attach_source(query, source, alias, conditions=join_conditions)
        if isinstance(owner_arg, mm.Var):
            bindings[owner_arg.id] = self._store_binding(
                SQLColumnRef(id_column_name, alias),
                alias=alias,
                source_object=source_object,
            )
        return alias

    def _lower_not(self, task: mm.Not, bindings: dict[int, Binding], query: SelectQuery) -> None:
        inner = SelectQuery(select=[SQLSelectItem(SQLLiteral(1))])
        local_bindings = dict(bindings)
        inner_task = task.task if isinstance(task.task, mm.Logical) else mm.Logical(body=(task.task,))
        self._lower_logical(inner_task, local_bindings, inner, include_updates=False, nullable_aggregates=False)
        if inner.from_item is None:
            folded = self._fold_exprs(inner.where, "AND")
            if folded is not None:
                query.where.append(SQLNot(folded))
            return
        query.where.append(SQLNot(SQLExists(inner.to_ir())))

    def _lower_optional(
        self,
        task: mm.Logical,
        bindings: dict[int, Binding],
        query: SelectQuery,
    ) -> None:
        if (query.from_item is None and not query.joins and not query.where) or self._optional_can_inline(task, bindings):
            self._lower_logical(
                task,
                bindings,
                query,
                include_updates=False,
                nullable_aggregates=True,
                optional_context=True,
            )
            return

        inner = SelectQuery()
        local_bindings = dict(bindings)
        self._lower_logical(
            task,
            local_bindings,
            inner,
            include_updates=False,
            nullable_aggregates=False,
            optional_context=True,
        )
        new_bindings = [(var_id, binding) for var_id, binding in local_bindings.items() if var_id not in bindings]
        if inner.from_item is None and not inner.where and not new_bindings:
            return
        for var_id, binding in new_bindings:
            inner.select.append(SQLSelectItem(binding.expr, alias=f"v{var_id}"))
        if not inner.select:
            inner.select.append(SQLSelectItem(SQLLiteral(1), alias="__keep"))
        alias = self._next_alias()
        query.joins.append(
            JoinItem(
                kind="LEFT JOIN LATERAL",
                source=SQLSubquerySource(inner.to_ir()),
                alias=alias,
                conditions=(SQLLiteral(True),),
            )
        )
        for var_id, _binding in new_bindings:
            bindings[var_id] = Binding(expr=SQLColumnRef(f"v{var_id}", alias), alias=alias)

    def _lower_union(
        self,
        task: mm.Union,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        optional_context: bool = False,
        demanded_var_ids: set[int] | None = None,
    ) -> None:
        output_vars = tuple(var for var in task.outputs if isinstance(var, mm.Var))
        if not output_vars:
            branch_plans: list[tuple[SelectQuery, dict[int, Binding]]] = []
            shared_var_ids: set[int] | None = None
            for branch in task.tasks:
                branch_query, branch_bindings, _ = self._branch_query(branch, bindings, ())
                branch_plans.append((branch_query, branch_bindings))
                new_var_ids = {var_id for var_id in branch_bindings if var_id not in bindings}
                if shared_var_ids is None:
                    shared_var_ids = set(new_var_ids)
                else:
                    shared_var_ids &= new_var_ids

            visible_var_ids = tuple(sorted(set(shared_var_ids or set()) & (demanded_var_ids or set())))
            if visible_var_ids:
                branch_sql: list[SQLQuery] = []
                for branch_query, branch_bindings in branch_plans:
                    branch_query.select = [
                        SQLSelectItem(branch_bindings[var_id].expr, alias=f"o{index}")
                        for index, var_id in enumerate(visible_var_ids)
                    ]
                    branch_sql.append(branch_query.to_ir())

                alias = self._next_alias()
                union_source = SQLSubquerySource(SQLUnionQuery(queries=tuple(branch_sql), operator="UNION"))
                if query.from_item is None:
                    query.from_item = FromItem(source=union_source, alias=alias)
                else:
                    query.joins.append(JoinItem(kind="JOIN LATERAL", source=union_source, alias=alias, conditions=(SQLLiteral(True),)))
                for index, var_id in enumerate(visible_var_ids):
                    bindings[var_id] = Binding(expr=SQLColumnRef(f"o{index}", alias), alias=alias)
                return

            folded = self._fold_exprs([self._branch_predicate_sql(branch_query) for branch_query, _ in branch_plans], "OR")
            if folded is not None:
                query.where.append(folded)
            return

        branch_sql, shared_output_bindings = self._branch_outputs(task.tasks, bindings, output_vars)
        alias = self._next_alias()
        union_source = SQLSubquerySource(SQLUnionQuery(queries=tuple(branch_sql), operator="UNION"))
        join_kind = (
            "LEFT JOIN LATERAL" if optional_context and not self._task_depends_on_synthetic_binding(task, bindings) else "JOIN LATERAL"
        )
        self._attach_source(query, union_source, alias, conditions=(SQLLiteral(True),), join_kind=join_kind)
        self._bind_output_equivalents(bindings, output_vars, shared_output_bindings, alias)

    def _lower_match(self, task: mm.Match, bindings: dict[int, Binding], query: SelectQuery) -> None:
        output_vars = tuple(var for var in task.outputs if isinstance(var, mm.Var))
        if not output_vars:
            folded = self._fold_exprs([self._branch_predicate_sql(self._branch_query(branch, bindings, ())[0]) for branch in task.tasks], "OR")
            if folded is not None:
                query.where.append(folded)
            return

        branch_sql, shared_output_bindings = self._branch_outputs(task.tasks, bindings, output_vars, prioritized=True)
        alias = self._next_alias()
        table_query = SQLSelectQuery(
            select=(SQLSelectItem(SQLStar()),),
            from_item=SQLFromItem(
                source=SQLSubquerySource(SQLUnionQuery(queries=tuple(branch_sql), operator="UNION ALL")),
                alias="matched",
            ),
            order_by=(SQLOrderItem(SQLColumnRef("__prio")),),
            limit=1,
        )
        self._attach_source(query, SQLSubquerySource(table_query), alias, conditions=(SQLLiteral(True),), join_kind="JOIN LATERAL")
        self._bind_output_equivalents(bindings, output_vars, shared_output_bindings, alias)

    def _branch_query(
        self,
        task: mm.Task,
        bindings: dict[int, Binding],
        output_vars: tuple[mm.Var, ...],
        *,
        priority: int | None = None,
    ) -> tuple[SelectQuery, dict[int, Binding], tuple[set[int], ...]]:
        local_bindings = dict(bindings)
        branch_query = SelectQuery()
        if isinstance(task, mm.Logical):
            self._lower_logical(task, local_bindings, branch_query, include_updates=False, nullable_aggregates=False)
        else:
            self._lower_logical(
                mm.Logical(body=(task,)),
                local_bindings,
                branch_query,
                include_updates=False,
                nullable_aggregates=False,
            )
        branch_query.select = [
            SQLSelectItem(self._resolve(output_var, local_bindings), alias=f"o{index}")
            for index, output_var in enumerate(output_vars)
        ] or [SQLSelectItem(SQLLiteral(1), alias="__one")]
        if priority is not None:
            branch_query.select.append(SQLSelectItem(SQLLiteral(priority), alias="__prio"))
        equivalent_bindings: list[set[int]] = []
        for output_var in output_vars:
            output_binding = local_bindings.get(output_var.id)
            if output_binding is None:
                equivalent_bindings.append(set())
                continue
            selected_expr = self._resolve(output_var, local_bindings)
            equivalent_bindings.append(
                {
                    var_id
                    for var_id, binding in local_bindings.items()
                    if var_id not in bindings
                    and (
                        binding.expr == selected_expr
                        or self._cast_expr_to_type(binding.expr, output_var.type) == selected_expr
                    )
                }
            )
        return branch_query, local_bindings, tuple(equivalent_bindings)

    def _branch_predicate_sql(self, query: SelectQuery) -> SQLExpr:
        if query.from_item is None:
            return self._fold_exprs(query.where, "AND", empty=SQLLiteral(True))
        return SQLExists(query.to_ir())

    def _branch_outputs(
        self,
        tasks: tuple[mm.Task, ...],
        bindings: dict[int, Binding],
        output_vars: tuple[mm.Var, ...],
        *,
        prioritized: bool = False,
    ) -> tuple[tuple[SQLQuery, ...], list[set[int] | None]]:
        branch_sql: list[SQLQuery] = []
        shared_output_bindings: list[set[int] | None] = [None] * len(output_vars)
        for index, branch in enumerate(tasks):
            branch_query, _, equivalent_bindings = self._branch_query(
                branch,
                bindings,
                output_vars,
                priority=index if prioritized else None,
            )
            branch_sql.append(branch_query.to_ir())
            self._merge_equivalent_bindings(shared_output_bindings, equivalent_bindings)
        return tuple(branch_sql), shared_output_bindings

    def _lower_aggregate(
        self,
        task: mm.Aggregate,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        base_query: SelectQuery,
        nullable: bool,
        outer_bindings: dict[int, Binding] | None = None,
    ) -> None:
        if task.aggregation.name == "rank":
            self._lower_rank_aggregate(
                task,
                bindings,
                query,
                base_query=base_query,
                outer_bindings=outer_bindings,
            )
            return
        inner_task = task.body if isinstance(task.body, mm.Logical) else mm.Logical(body=(task.body,))
        seed_bindings = outer_bindings or bindings
        inner_bindings: dict[int, Binding] = dict(seed_bindings)
        inner_query = base_query.clone()
        self._lower_logical(inner_task, inner_bindings, inner_query, include_updates=False, nullable_aggregates=False)
        self._ensure_from(inner_query)

        group_vars = tuple(var for var in task.group if isinstance(var, mm.Var))
        projection_vars = tuple(var for var in task.projection if isinstance(var, mm.Var))
        value_args = tuple(arg for arg in task.args[:-1])
        output_arg = task.args[-1] if task.args else None
        aggregate_query = inner_query
        aggregate_bindings = inner_bindings

        if projection_vars:
            projection_query = self._projection_query(inner_query, distinct=True)
            aggregate_bindings = {}
            aggregate_alias = self._next_alias()
            for index, group_var in enumerate(group_vars):
                binding = inner_bindings.get(group_var.id)
                if binding is None:
                    continue
                alias_name = f"g{index}"
                projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
                aggregate_bindings[group_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

            projection_index = 0
            for projection_var in projection_vars:
                if projection_var.id in aggregate_bindings:
                    continue
                binding = inner_bindings.get(projection_var.id)
                if binding is None:
                    continue
                alias_name = f"p{projection_index}"
                projection_index += 1
                projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
                aggregate_bindings[projection_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

            for value_arg in value_args:
                if not isinstance(value_arg, mm.Var) or value_arg.id in aggregate_bindings:
                    continue
                binding = inner_bindings.get(value_arg.id)
                if binding is None:
                    continue
                alias_name = f"p{projection_index}"
                projection_index += 1
                projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
                aggregate_bindings[value_arg.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

            aggregate_query = SelectQuery(
                from_item=FromItem(source=SQLSubquerySource(projection_query.to_ir()), alias=aggregate_alias)
            )
        self._emit_group_keys(aggregate_query, group_vars, aggregate_bindings)
        if not group_vars and projection_vars:
            aggregate_query.select.append(SQLSelectItem(SQLLiteral(1), alias="__present"))
            aggregate_query.group_by.append(SQLLiteral(1))
        aggregate_expr = self._aggregate_expression_from_values(
            task,
            tuple(self._resolve(value_arg, aggregate_bindings) for value_arg in value_args),
        )
        if isinstance(output_arg, mm.Var):
            aggregate_expr = self._cast_aggregate_expr(task, aggregate_expr, value_args, output_arg)
        aggregate_query.select.append(SQLSelectItem(aggregate_expr, alias="agg_value"))
        outer_alias = self._next_alias()
        join_conditions = self._join_conditions_for_columns(bindings, group_vars, outer_alias, bind_missing=True)
        if isinstance(output_arg, mm.Var):
            bindings[output_arg.id] = Binding(expr=SQLColumnRef("agg_value", outer_alias), alias=outer_alias)
        aggregate_source = SQLSubquerySource(aggregate_query.to_ir())
        if nullable and query.from_item is None and not query.joins and not query.where:
            query.from_item = FromItem(source=aggregate_source, alias=outer_alias)
            return

        self._ensure_from(query)
        query.joins.append(
            JoinItem(
                kind="LEFT JOIN" if nullable else "JOIN",
                source=aggregate_source,
                alias=outer_alias,
                conditions=tuple(join_conditions or [SQLLiteral(True)]),
            )
        )

    def _lower_rank_aggregate(
        self,
        task: mm.Aggregate,
        bindings: dict[int, Binding],
        query: SelectQuery,
        *,
        base_query: SelectQuery,
        outer_bindings: dict[int, Binding] | None = None,
    ) -> None:
        inner_task = task.body if isinstance(task.body, mm.Logical) else mm.Logical(body=(task.body,))
        seed_bindings = outer_bindings or bindings
        inner_bindings: dict[int, Binding] = dict(seed_bindings)
        inner_query = base_query.clone()
        self._lower_logical(inner_task, inner_bindings, inner_query, include_updates=False, nullable_aggregates=False)
        self._ensure_from(inner_query)

        group_vars = tuple(var for var in task.group if isinstance(var, mm.Var))
        projection_vars = tuple(var for var in task.projection if isinstance(var, mm.Var))
        group_var_ids = {group_var.id for group_var in group_vars}
        projection_join_vars = tuple(var for var in projection_vars if var.id not in group_var_ids)
        if len(task.args) < 3:
            order_values, ascending_flags = (), ()
        else:
            order_values = task.args[0] if isinstance(task.args[0], tuple) else (task.args[0],)
            flags = task.args[1] if isinstance(task.args[1], tuple) else (task.args[1],)
            ascending_flags = tuple(bool(flag.value) if isinstance(flag, mm.Literal) else True for flag in flags)
        if not isinstance(task.args[-1], mm.Var):
            raise NotImplementedError("sql9 aggregate output must bind to a variable.")
        result_var = task.args[-1]

        projection_query = self._projection_query(inner_query, distinct=True)
        aggregate_alias = self._next_alias()
        aggregate_bindings: dict[int, Binding] = {}

        for index, group_var in enumerate(group_vars):
            binding = inner_bindings.get(group_var.id)
            if binding is None:
                continue
            alias_name = f"g{index}"
            projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
            aggregate_bindings[group_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

        for index, projection_var in enumerate(projection_join_vars):
            binding = inner_bindings.get(projection_var.id)
            if binding is None:
                continue
            alias_name = f"p{index}"
            projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
            aggregate_bindings[projection_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

        order_items: list[SQLOrderItem] = []
        for index, (value, ascending) in enumerate(zip(order_values, ascending_flags, strict=False)):
            expr = self._resolve(value, inner_bindings)
            alias_name = f"o{index}"
            projection_query.select.append(SQLSelectItem(expr, alias=alias_name))
            order_items.append(SQLOrderItem(SQLColumnRef(alias_name, aggregate_alias), descending=not ascending))

        ranked_alias = self._next_alias()
        rank_query = SelectQuery(
            from_item=FromItem(source=SQLSubquerySource(projection_query.to_ir()), alias=aggregate_alias),
            select=[
                *[
                    SQLSelectItem(SQLColumnRef(f"g{index}", aggregate_alias), alias=f"g{index}")
                    for index, _ in enumerate(group_vars)
                ],
                *[
                    SQLSelectItem(
                        SQLColumnRef(f"p{index}", aggregate_alias),
                        alias=f"p{index}",
                    )
                    for index, projection_var in enumerate(projection_join_vars)
                    if projection_var.id in aggregate_bindings
                ],
            ],
        )
        rank_query.select.append(
            SQLSelectItem(
                self._cast_expr_to_type(
                    SQLWindowCall(
                        function_name="ROW_NUMBER",
                        partition_by=tuple(SQLColumnRef(f"g{index}", aggregate_alias) for index, _ in enumerate(group_vars)),
                        order_by=tuple(order_items),
                    ),
                    result_var.type,
                ),
                alias="agg_value",
            )
        )

        join_conditions = self._join_conditions_for_columns(bindings, group_vars, ranked_alias)
        join_conditions.extend(self._join_conditions_for_columns(bindings, projection_join_vars, ranked_alias, prefix="p"))

        aggregate_source = SQLSubquerySource(rank_query.to_ir())
        self._ensure_from(query)
        query.joins.append(
            JoinItem(
                kind="JOIN",
                source=aggregate_source,
                alias=ranked_alias,
                conditions=tuple(join_conditions or [SQLLiteral(True)]),
            )
        )
        bindings[result_var.id] = Binding(expr=SQLColumnRef("agg_value", ranked_alias), alias=ranked_alias)

    def _packed_aggregate_query(
        self,
        lowered_aggregates: list[tuple[mm.Aggregate, dict[int, Binding], SelectQuery]],
        reference_query: SelectQuery,
        *,
        group_vars: tuple[mm.Var, ...],
        projection_vars: tuple[mm.Var, ...],
    ) -> SelectQuery:
        projection_query = self._projection_query(reference_query, distinct=bool(projection_vars))
        projected_bindings: dict[int, Binding] = {}
        aggregate_alias = self._next_alias()

        for index, group_var in enumerate(group_vars):
            binding = lowered_aggregates[0][1].get(group_var.id)
            if binding is None:
                continue
            alias_name = f"g{index}"
            projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
            projected_bindings[group_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)

        projection_index = 0
        for projection_var in projection_vars:
            if projection_var.id in projected_bindings:
                continue
            binding = lowered_aggregates[0][1].get(projection_var.id)
            if binding is None:
                continue
            alias_name = f"p{projection_index}"
            projection_query.select.append(SQLSelectItem(binding.expr, alias=alias_name))
            projected_bindings[projection_var.id] = Binding(expr=SQLColumnRef(alias_name, aggregate_alias), alias=aggregate_alias)
            projection_index += 1

        value_aliases: list[str | None] = []
        value_index = 0
        for aggregate, aggregate_bindings, _ in lowered_aggregates:
            value_args = tuple(arg for arg in aggregate.args[:-1])
            if not value_args:
                value_aliases.append(None)
                continue
            value_expr = self._resolve(value_args[0], aggregate_bindings)
            alias_name = f"v{value_index}"
            value_index += 1
            projection_query.select.append(SQLSelectItem(value_expr, alias=alias_name))
            value_aliases.append(alias_name)

        aggregate_query = SelectQuery(
            from_item=FromItem(source=SQLSubquerySource(projection_query.to_ir()), alias=aggregate_alias)
        )
        self._emit_group_keys(aggregate_query, group_vars, projected_bindings)

        if not group_vars and projection_vars:
            aggregate_query.select.append(SQLSelectItem(SQLLiteral(1), alias="__present"))
            aggregate_query.group_by.append(SQLLiteral(1))

        for index, ((aggregate, _, _), value_alias) in enumerate(zip(lowered_aggregates, value_aliases, strict=False)):
            value_exprs = () if value_alias is None else (SQLColumnRef(value_alias, aggregate_alias),)
            aggregate_expr = self._aggregate_expression_from_values(aggregate, value_exprs)
            output_arg = aggregate.args[-1] if aggregate.args else None
            if isinstance(output_arg, mm.Var):
                value_args = tuple(arg for arg in aggregate.args[:-1])
                aggregate_expr = self._cast_aggregate_expr(aggregate, aggregate_expr, value_args, output_arg)
            aggregate_query.select.append(SQLSelectItem(aggregate_expr, alias=f"a{index}"))

        return aggregate_query

    def _projection_query(self, query: SelectQuery, *, distinct: bool) -> SelectQuery:
        return SelectQuery(
            from_item=query.from_item,
            joins=list(query.joins),
            where=list(query.where),
            distinct=distinct,
        )

    def _emit_group_keys(
        self,
        query: SelectQuery,
        group_vars: tuple[mm.Var, ...],
        bindings: dict[int, Binding],
    ) -> None:
        for index, group_var in enumerate(group_vars):
            binding = bindings.get(group_var.id)
            if binding is None:
                continue
            query.select.append(SQLSelectItem(binding.expr, alias=f"g{index}"))
            query.group_by.append(binding.expr)

    def _join_conditions_for_columns(
        self,
        bindings: dict[int, Binding],
        vars: tuple[mm.Var, ...],
        alias: str,
        *,
        prefix: str = "g",
        bind_missing: bool = False,
    ) -> list[SQLExpr]:
        conditions: list[SQLExpr] = []
        for index, var in enumerate(vars):
            existing = bindings.get(var.id)
            if existing is None:
                if bind_missing:
                    bindings[var.id] = Binding(expr=SQLColumnRef(f"{prefix}{index}", alias), alias=alias)
                continue
            conditions.append(SQLBinaryOp(SQLColumnRef(f"{prefix}{index}", alias), "=", existing.expr))
        return conditions

    def _aggregate_expression_from_values(self, task: mm.Aggregate, value_exprs: tuple[SQLExpr, ...]) -> SQLExpr:
        fn = task.aggregation.name.strip().lower()
        sql_fn = {
            "count": "COUNT",
            "sum": "SUM",
            "min": "MIN",
            "max": "MAX",
            "avg": "AVG",
        }.get(fn, task.aggregation.name.upper())
        if fn == "count" and not value_exprs:
            return SQLFunctionCall("COUNT", (SQLStar(),))
        if fn == "count":
            return SQLFunctionCall("COUNT", (value_exprs[0],))
        if not value_exprs:
            raise NotImplementedError(f"sql9 aggregate {task.aggregation.name!r} is not yet supported.")
        return SQLFunctionCall(sql_fn, (value_exprs[0],))

    def _cast_aggregate_expr(
        self,
        task: mm.Aggregate,
        expr: SQLExpr,
        value_args: tuple,
        output_arg: mm.Var,
    ) -> SQLExpr:
        sql_type = self._aggregate_sql_type(task, value_args, output_arg.type)
        if sql_type is None:
            return expr
        return SQLCast(expr, sql_type)

    def _aggregate_sql_type(self, task: mm.Aggregate, value_args: tuple, output_type) -> str | None:
        fn = task.aggregation.name.strip().lower()
        if fn == "sum":
            value_type = self._aggregate_value_type(value_args)
            if isinstance(value_type, mm.NumberType):
                return f"DECIMAL(38,{value_type.scale})"
        return self._sql_type_for_type(output_type)

    def _aggregate_value_type(self, value_args: tuple):
        for value_arg in value_args:
            if isinstance(value_arg, mm.Var):
                return value_arg.type
        return None

    def _project_target(self, task: mm.Logical, target: Target, bindings: dict[int, Binding]) -> list[SQLSelectItem] | None:
        updates = [child for child in task.body if isinstance(child, mm.Update)]
        table_update = next((update for update in updates if isinstance(update.relation, mm.Table)), None)
        if table_update is not None:
            return [
                SQLSelectItem(
                    self._cast_expr_to_type(
                        self._resolve(arg, bindings),
                        self._output_column_type_for_table(table_update.relation, index, len(table_update.args)),
                    ),
                    alias=column_name,
                )
                for index, (column_name, arg) in enumerate(zip(target.column_names, table_update.args))
            ]
        constructs = [child for child in task.body if isinstance(child, mm.Construct)]
        if target.kind == "relation":
            update = updates[0] if updates else None
            if update is None:
                return None
            return [
                SQLSelectItem(self._resolve(arg, bindings), alias=column_name)
                for column_name, arg in zip(target.column_names, update.args)
            ]

        entity_id_expr = None
        if constructs:
            entity_id_expr = self._construct_identity(constructs[0], bindings)
        elif updates and updates[0].args and isinstance(updates[0].args[0], mm.Var):
            owner_binding = bindings.get(updates[0].args[0].id)
            entity_id_expr = owner_binding.expr if owner_binding is not None else None
        if entity_id_expr is None:
            return None

        values_by_column: dict[str, SQLExpr] = {column_name: SQLLiteral(None) for column_name in target.column_names}
        values_by_column["_id"] = entity_id_expr
        for update in updates:
            if not update.args:
                continue
            values_by_column[update.relation.name] = self._resolve(update.args[-1], bindings)
        return [
            SQLSelectItem(values_by_column[column_name], alias=column_name)
            for column_name in target.column_names
        ]

    def _select_list_from_fragment(
        self,
        task: mm.Logical,
        updates: list[mm.Update],
        bindings: dict[int, Binding],
    ) -> list[SQLSelectItem]:
        output_table = next((update.relation for update in updates if isinstance(update.relation, mm.Table)), None)
        if isinstance(output_table, mm.Table) and output_table.columns:
            update_by_relation_id = {
                update.relation.id: update
                for update in updates
                if isinstance(update.relation, mm.Relation) and not isinstance(update.relation, mm.Table)
            }
            select_sql: list[SQLSelectItem] = []
            for column in output_table.columns:
                update = update_by_relation_id.get(column.id)
                if update is None or not update.args:
                    continue
                select_sql.append(SQLSelectItem(self._resolve(update.args[-1], bindings), alias=column.name))
            if select_sql:
                return select_sql

        return self._select_list_from_updates(updates, bindings)

    def _select_list_from_updates(
        self,
        updates: list[mm.Update],
        bindings: dict[int, Binding],
    ) -> list[SQLSelectItem]:
        select_sql: list[SQLSelectItem] = []
        seen: dict[str, int] = {}
        for update in updates:
            if isinstance(update.relation, mm.Table):
                continue
            alias = update.relation.name
            seen[alias] = seen.get(alias, 0) + 1
            if seen[alias] > 1:
                alias = f"{alias}_{seen[alias]}"
            select_sql.append(SQLSelectItem(self._resolve(update.args[-1], bindings), alias=alias))
        return select_sql

    def _attach_source(
        self,
        query: SelectQuery,
        table_sql: SQLSource,
        alias: str,
        *,
        conditions: tuple[SQLExpr, ...] = (),
        join_kind: str = "JOIN",
    ) -> None:
        if query.from_item is None:
            query.from_item = FromItem(source=table_sql, alias=alias)
            if conditions:
                query.where.extend(conditions)
            return
        query.joins.append(JoinItem(kind=join_kind, source=table_sql, alias=alias, conditions=conditions))

    def _attach_optional_source(
        self,
        query: SelectQuery,
        table_sql: SQLSource,
        alias: str,
        *,
        conditions: tuple[SQLExpr, ...] = (),
    ) -> None:
        inner = SQLSelectQuery(
            select=(SQLSelectItem(SQLStar()),),
            from_item=SQLFromItem(source=table_sql, alias=alias),
            where=conditions,
        )
        query.joins.append(
            JoinItem(
                kind="LEFT JOIN LATERAL",
                source=SQLSubquerySource(inner),
                alias=alias,
                conditions=(SQLLiteral(True),),
            )
        )

    def _ensure_from(self, query: SelectQuery) -> None:
        if query.from_item is None:
            query.from_item = FromItem(source=SQLSingletonSource(), alias=self._next_alias())

    def _construct_identity(self, construct: mm.Construct, bindings: dict[int, Binding]) -> SQLExpr:
        pieces: list[SQLExpr] = []
        if construct.values and isinstance(construct.values[0], mm.Literal) and isinstance(construct.values[0].value, str):
            pieces.append(self._literal(construct.values[0].value))
        elif isinstance(construct.id_var.type, mm.ScalarType):
            pieces.append(self._literal(construct.id_var.type.name))
        else:
            pieces.append(self._literal(construct.id_var.name or "Entity"))
        pieces.extend(self._resolve(value, bindings) for value in construct.values)
        return SQLFunctionCall("MD5", (SQLConcat(tuple(pieces)),))

    def _can_bind_construct_now(self, construct: mm.Construct, bindings: dict[int, Binding]) -> bool:
        for value in construct.values:
            if isinstance(value, mm.Literal):
                continue
            if isinstance(value, mm.Var) and value.id in bindings:
                continue
            return False
        return True

    def _should_defer_lookup(
        self,
        lookup: mm.Lookup,
        bindings: dict[int, Binding],
        *,
        optional_context: bool,
    ) -> bool:
        if not optional_context or not lookup.args:
            return False
        relation = lookup.relation
        if isinstance(relation, mm.Table):
            relation = self._table_primary_relation(relation) or relation
        if not isinstance(relation, mm.Relation):
            return False
        try:
            self.catalog.entity_store(relation)
        except KeyError:
            return False
        first_arg = lookup.args[0]
        return isinstance(first_arg, mm.Var) and first_arg.id not in bindings

    def _should_defer_not(self, task: mm.Not, bindings: dict[int, Binding], remaining_body: tuple[mm.Task, ...]) -> bool:
        not_var_ids = task_var_ids(task.task)
        remaining_var_ids: set[int] = set()
        for child in remaining_body:
            remaining_var_ids |= task_var_ids(child)
        return any(var_id not in bindings and var_id in remaining_var_ids for var_id in not_var_ids)

    def _later_demanded_var_ids(self, remaining_body: tuple[mm.Task, ...], bindings: dict[int, Binding]) -> set[int]:
        demanded: set[int] = set()
        for child in remaining_body:
            demanded |= task_var_ids(child)
        return {var_id for var_id in demanded if var_id not in bindings}

    def _resolve(self, value, bindings: dict[int, Binding]) -> SQLExpr:
        if isinstance(value, mm.Var):
            binding = bindings.get(value.id)
            return binding.expr if binding is not None else SQLUnboundVar(value.name)
        if isinstance(value, mm.Literal):
            return self._literal(value.value)
        return SQLLiteral(None)

    def _literal(self, value) -> SQLExpr:
        return SQLLiteral(value)

    def _next_alias(self) -> str:
        self._alias_counter += 1
        return f"s{self._alias_counter}"

    def _placeholder(self, var_id: int) -> SQLExpr:
        return SQLPlaceholder(f"__var_{var_id}")

    def _is_placeholder_expr(self, expr: SQLExpr) -> bool:
        return isinstance(expr, SQLPlaceholder)

    def _rebind_placeholder(self, bindings: dict[int, Binding], placeholder: SQLExpr, expr: SQLExpr) -> None:
        for var_id, binding in tuple(bindings.items()):
            if binding.expr == placeholder:
                bindings[var_id] = Binding(expr=expr, alias=binding.alias, source_object=binding.source_object, origin=binding.origin)

    def _cast_source_expr(self, source_arg, source_expr: SQLExpr, target_type) -> SQLExpr:
        import datetime as dt

        if isinstance(source_arg, mm.Literal):
            if self._type_is_date(target_type) and isinstance(source_arg.value, dt.datetime):
                return self._literal(source_arg.value.date())
            if self._type_is_date(target_type) and isinstance(source_arg.value, dt.date):
                return self._literal(source_arg.value)
        return self._cast_expr_to_type(source_expr, target_type)

    def _table_primary_relation(self, table: mm.Table) -> mm.Relation | None:
        if len(table.columns) != 1:
            return None
        relation = table.columns[0]
        return relation if isinstance(relation, mm.Relation) else None

    def _output_column_type_for_table(self, table: mm.Table, index: int, arity: int):
        if len(table.columns) == 1 and isinstance(table.columns[0], mm.Relation):
            relation = table.columns[0]
            if len(relation.fields) == arity:
                return relation.fields[index].type
        if index >= len(table.columns):
            return None
        column = table.columns[index]
        if isinstance(column, mm.Relation) and column.fields:
            return column.fields[-1].type
        return None

    def _coerce_expr_for_var(self, target_var: mm.Var, source_arg, bindings: dict[int, Binding]) -> SQLExpr:
        source_expr = self._resolve(source_arg, bindings)
        return self._cast_source_expr(source_arg, source_expr, target_var.type)

    def _type_is_date(self, type_ref) -> bool:
        current = type_ref
        seen: set[int] = set()
        while isinstance(current, mm.ScalarType) and current.id not in seen:
            seen.add(current.id)
            if current.name.strip().lower() == "date":
                return True
            super_types = tuple(super_type for super_type in getattr(current, "super_types", ()) if isinstance(super_type, mm.ScalarType))
            current = super_types[0] if super_types else None
        return False

    def _cast_expr_to_type(self, expr: SQLExpr, type_ref) -> SQLExpr:
        if self._is_placeholder_expr(expr) or isinstance(expr, SQLUnboundVar):
            return expr
        sql_type = self._sql_type_for_type(type_ref)
        if sql_type is None:
            return expr
        return SQLCast(expr, sql_type)

    def _sql_type_for_type(self, type_ref) -> str | None:
        if isinstance(type_ref, mm.NumberType):
            return f"DECIMAL({type_ref.precision},{type_ref.scale})"
        numeric_sql_type = self._numeric_sql_type(type_ref)
        if numeric_sql_type is not None:
            return numeric_sql_type
        current = type_ref
        seen: set[int] = set()
        while isinstance(current, mm.ScalarType) and current.id not in seen:
            seen.add(current.id)
            name = current.name.strip().lower()
            if name in {"string", "symbol", "uuid"}:
                return "VARCHAR"
            if name in {"bool", "boolean"}:
                return "BOOLEAN"
            if name in {"float", "double"}:
                return "DOUBLE"
            if name == "date":
                return "DATE"
            if name in {"datetime", "timestamp"}:
                return "TIMESTAMP"
            super_types = tuple(
                super_type for super_type in getattr(current, "super_types", ()) if isinstance(super_type, mm.ScalarType)
            )
            current = super_types[0] if super_types else None
        return None

    def _numeric_sql_type(self, type_ref) -> str | None:
        seen: set[int] = set()
        stack = [type_ref]
        while stack:
            candidate = stack.pop()
            if isinstance(candidate, mm.NumberType):
                return f"DECIMAL({candidate.precision},{candidate.scale})"
            candidate_id = getattr(candidate, "id", None)
            if isinstance(candidate_id, int):
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
            stack.extend(getattr(candidate, "super_types", ()))
        return None

    def _optional_can_inline(self, task: mm.Logical, bindings: dict[int, Binding]) -> bool:
        if self._contains_aggregate(task):
            return True
        alias_counter = self._alias_counter
        try:
            probe_query = SelectQuery()
            probe_bindings = dict(bindings)
            self._lower_logical(
                task,
                probe_bindings,
                probe_query,
                include_updates=False,
                nullable_aggregates=False,
                optional_context=True,
            )
            return probe_query.from_item is None and not probe_query.joins and not probe_query.where
        finally:
            self._alias_counter = alias_counter

    def _default_order_by(self, select_items: list[SQLSelectItem]) -> list[SQLOrderItem]:
        order_by: list[SQLOrderItem] = []
        for item in select_items:
            if item.alias is None:
                continue
            order_by.append(SQLOrderItem(SQLColumnRef(item.alias)))
        return order_by

    def _aggregate_scope_parts(self, task: mm.Logical) -> tuple[tuple[mm.Task, ...], tuple[mm.Aggregate, ...]]:
        if not task.optional:
            return (), ()
        first_aggregate_index = None
        for index, child in enumerate(task.body):
            if isinstance(child, mm.Aggregate):
                first_aggregate_index = index
                break
        if first_aggregate_index is None:
            return (), ()
        if any(not isinstance(child, mm.Aggregate) for child in task.body[first_aggregate_index:]):
            return (), ()
        support_tasks = tuple(task.body[:first_aggregate_index])
        aggregates = tuple(child for child in task.body[first_aggregate_index:] if isinstance(child, mm.Aggregate))
        return support_tasks, aggregates

    def _query_signature(self, query: SelectQuery) -> tuple[FromItem | None, tuple[JoinItem, ...], tuple[SQLExpr, ...]]:
        return query.from_item, tuple(query.joins), tuple(query.where)

    def _fold_exprs(
        self,
        exprs: list[SQLExpr] | tuple[SQLExpr, ...],
        op: str,
        *,
        empty: SQLExpr | None = None,
    ) -> SQLExpr | None:
        if not exprs:
            return empty
        folded = exprs[0]
        for expr in exprs[1:]:
            folded = SQLBinaryOp(folded, op, expr)
        return folded

    def _merge_equivalent_bindings(
        self,
        shared: list[set[int] | None],
        equivalent: tuple[set[int], ...],
    ) -> None:
        for index, equivalent_var_ids in enumerate(equivalent):
            shared[index] = set(equivalent_var_ids) if shared[index] is None else shared[index] & equivalent_var_ids

    def _bind_output_equivalents(
        self,
        bindings: dict[int, Binding],
        output_vars: tuple[mm.Var, ...],
        shared_output_bindings: list[set[int] | None],
        alias: str,
    ) -> None:
        for index, var in enumerate(output_vars):
            output_binding = Binding(expr=SQLColumnRef(f"o{index}", alias), alias=alias)
            bindings[var.id] = output_binding
            for equivalent_var_id in shared_output_bindings[index] or ():
                if equivalent_var_id not in bindings:
                    bindings[equivalent_var_id] = output_binding

    def _args_depend_on_synthetic_binding(self, args: tuple, bindings: dict[int, Binding]) -> bool:
        for arg in args:
            if not isinstance(arg, mm.Var):
                continue
            binding = bindings.get(arg.id)
            if binding is not None and binding.origin != "store":
                return True
        return False

    def _task_depends_on_synthetic_binding(self, task: mm.Task, bindings: dict[int, Binding]) -> bool:
        return any(
            (binding := bindings.get(var_id)) is not None and binding.origin != "store"
            for var_id in task_var_ids(task)
        )

    def _contains_aggregate(self, task: mm.Task) -> bool:
        if isinstance(task, mm.Aggregate):
            return True
        if isinstance(task, mm.Logical):
            return any(self._contains_aggregate(child) for child in task.body)
        if isinstance(task, (mm.Union, mm.Match)):
            return any(self._contains_aggregate(child) for child in task.tasks)
        if isinstance(task, mm.Not):
            return self._contains_aggregate(task.task)
        return False


__all__ = ["Binding", "Lowerer", "SelectQuery"]
