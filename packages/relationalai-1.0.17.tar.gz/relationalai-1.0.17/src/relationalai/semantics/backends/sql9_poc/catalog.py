"""Catalog pass for the isolated sql9 backend."""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
import re

from relationalai.semantics.metamodel.metamodel_analyzer import RelationAnalysis

from ...metamodel.builtins import builtins as builtin_registry, is_entity_type, is_primitive, is_value_type
from ...metamodel import metamodel as mm


@dataclass(frozen=True, slots=True)
class StoreColumn:
    name: str
    sql_type: str | None
    semantic_name: str | None = None


@dataclass(frozen=True, slots=True)
class EntityStore:
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ("_id",)


@dataclass(frozen=True, slots=True)
class RelationStore:
    relation_id: int
    relation_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DataStore:
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    source_name: str | None = None
    rows: tuple[tuple[object | None, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class Catalog:
    entity_stores: tuple[EntityStore, ...]
    relation_stores: tuple[RelationStore, ...]
    data_stores: tuple[DataStore, ...]
    folded_property_owner_type_ids: dict[int, int]
    data_column_store_type_ids: dict[int, int]

    def entity_store(self, ref: mm.ScalarType | str) -> EntityStore:
        if isinstance(ref, mm.ScalarType):
            type_id = getattr(ref, "id", None)
        else:
            type_id = None
        if isinstance(type_id, int):
            for store in self.entity_stores:
                if store.type_id == type_id:
                    return store
        type_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.entity_stores:
            if store.type_name == type_name:
                return store
        raise KeyError(f"Unknown sql9 entity store for {type_name!r}.")

    def relation_store(self, ref: mm.Relation | str) -> RelationStore:
        if isinstance(ref, mm.Relation) and self.is_data_column(ref):
            raise KeyError(f"Data column relation {ref.name!r} does not have a sql9 relation store.")
        relation_id = getattr(ref, "id", None)
        if isinstance(relation_id, int):
            for store in self.relation_stores:
                if store.relation_id == relation_id:
                    return store
        relation_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.relation_stores:
            if store.relation_name == relation_name:
                return store
        raise KeyError(f"Unknown sql9 relation store for {relation_name!r}.")

    def data_store(self, ref: mm.Data | mm.Table | str) -> DataStore:
        type_id = getattr(ref, "id", None)
        if isinstance(type_id, int):
            for store in self.data_stores:
                if store.type_id == type_id:
                    return store
        type_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.data_stores:
            if store.type_name == type_name:
                return store
        raise KeyError(f"Unknown sql9 data store for {type_name!r}.")

    def is_folded_property(self, relation: mm.Relation) -> bool:
        return relation.id in self.folded_property_owner_type_ids

    def owner_store_for_property(self, relation: mm.Relation) -> EntityStore:
        owner_type_id = self.folded_property_owner_type_ids[relation.id]
        for store in self.entity_stores:
            if store.type_id == owner_type_id:
                return store
        raise KeyError(f"Missing owner store for folded property {relation.name!r}.")

    def is_data_column(self, relation: mm.Relation) -> bool:
        return relation.id in self.data_column_store_type_ids

    def data_store_for_column(self, relation: mm.Relation) -> DataStore:
        store_type_id = self.data_column_store_type_ids[relation.id]
        for store in self.data_stores:
            if store.type_id == store_type_id:
                return store
        raise KeyError(f"Missing data store for column relation {relation.name!r}.")


class CatalogBuilder:
    def __init__(self) -> None:
        self._builtin_relation_names = {
            relation.name
            for library in builtin_registry._libraries.values()
            for relation in library.data.values()
        }

    def build(self, model: mm.Model, relation_analysis: RelationAnalysis, *, schema_name: str | None = None) -> Catalog:
        folded_owner_type_ids: dict[int, int] = {}
        data_column_store_type_ids: dict[int, int] = {}

        entity_stores: list[EntityStore] = []
        for entity_type in self._user_entity_types(model):
            property_relations = tuple(
                relation
                for relation in model.relations
                if self._is_folded_property_relation(model, relation_analysis, relation)
                and getattr(relation.fields[0].type, "id", None) == entity_type.id
            )
            for relation in property_relations:
                folded_owner_type_ids[relation.id] = entity_type.id
            columns = [
                StoreColumn(name="_id", sql_type="VARCHAR", semantic_name=entity_type.name),
                *(
                    StoreColumn(
                        name=relation.name,
                        sql_type=self._sql_type_name(relation.fields[1].type),
                        semantic_name=getattr(relation.fields[1].type, "name", None),
                    )
                    for relation in property_relations
                ),
            ]
            entity_stores.append(
                EntityStore(
                    type_id=entity_type.id,
                    type_name=entity_type.name,
                    object_name=self._qualified_name(schema_name, f"{entity_type.name}__t{entity_type.id}"),
                    columns=tuple(columns),
                )
            )

        relation_stores: list[RelationStore] = []
        for relation in model.relations:
            if relation.name in self._builtin_relation_names:
                continue
            if isinstance(relation, (mm.Table, mm.Data)):
                continue
            if self._is_folded_property_relation(model, relation_analysis, relation):
                continue
            columns = tuple(
                StoreColumn(
                    name=field.name,
                    sql_type=self._sql_type_name(field.type),
                    semantic_name=getattr(field.type, "name", None),
                )
                for field in relation.fields
            )
            relation_stores.append(
                RelationStore(
                    relation_id=relation.id,
                    relation_name=relation.name,
                    object_name=self._qualified_name(schema_name, self._relation_table_name(relation)),
                    columns=columns,
                    key_columns=(),
                )
            )

        data_stores: list[DataStore] = []
        for data_type in (type_ for type_ in model.types if isinstance(type_, (mm.Data, mm.Table))):
            columns = [StoreColumn(name="__rowid", sql_type="BIGINT")]
            for column_relation in data_type.columns:
                relation = column_relation
                data_column_store_type_ids[relation.id] = data_type.id
                columns.append(
                    StoreColumn(
                        name=relation.name,
                        sql_type=self._sql_type_name(relation.fields[1].type),
                        semantic_name=getattr(relation.fields[1].type, "name", None),
                    )
                )
            rows = []
            source_name: str | None = None
            if isinstance(data_type, mm.Data):
                frame = data_type.data
                for index, row in frame.reset_index(drop=True).iterrows():
                    rows.append((index, *(row.iloc[position] for position in range(len(frame.columns)))))
            else:
                uri = getattr(data_type, "uri", "")
                source_name = uri[len("table://"):] if uri.startswith("table://") else data_type.name
            data_stores.append(
                DataStore(
                    type_id=data_type.id,
                    type_name=data_type.name,
                    object_name=self._qualified_name(
                        schema_name,
                        f"{self._safe_identifier(data_type.name)}__source__t{data_type.id}",
                    ),
                    columns=tuple(columns),
                    source_name=source_name,
                    rows=tuple(rows),
                )
            )

        return Catalog(
            entity_stores=tuple(entity_stores),
            relation_stores=tuple(relation_stores),
            data_stores=tuple(data_stores),
            folded_property_owner_type_ids=folded_owner_type_ids,
            data_column_store_type_ids=data_column_store_type_ids,
        )

    def _user_entity_types(self, model: mm.Model) -> tuple[mm.ScalarType, ...]:
        return tuple(
            type_
            for type_ in model.types
            if isinstance(type_, mm.ScalarType)
            and is_entity_type(type_)
            and not is_primitive(type_)
            and not is_value_type(type_)
            and not isinstance(type_, (mm.Table, mm.Data))
        )

    def _is_folded_property_relation(self, model: mm.Model, relation_analysis: RelationAnalysis, relation: mm.Relation) -> bool:
        if len(relation.fields) != 2:
            return False
        if relation_analysis is None or not relation_analysis.is_property(relation):
            return False
        owner_type = relation.fields[0].type
        value_type = relation.fields[1].type
        if not isinstance(owner_type, mm.ScalarType) or not is_entity_type(owner_type):
            return False
        if isinstance(value_type, mm.ScalarType) and is_entity_type(value_type):
            return False
        if isinstance(value_type, mm.UnionType):
            return False
        return True

    def _relation_table_name(self, relation: mm.Relation) -> str:
        field_signature = "_".join(self._safe_identifier(getattr(field.type, "name", "Any")) for field in relation.fields)
        return self._safe_identifier(f"rel__{relation.name}__{field_signature}")

    def _qualified_name(self, schema_name: str | None, base_name: str) -> str:
        safe_base_name = self._safe_identifier(base_name)
        if schema_name:
            return f"{schema_name}.{safe_base_name}"
        return f"SANDBOX_MODEL.{safe_base_name}"

    def _sql_type_name(self, type_ref) -> str | None:
        if isinstance(type_ref, mm.NumberType):
            return f"DECIMAL({type_ref.precision},{type_ref.scale})"
        numeric_sql_type = self._numeric_sql_type(type_ref)
        if numeric_sql_type is not None:
            return numeric_sql_type
        if isinstance(type_ref, mm.ScalarType):
            for candidate in self._type_lineage(type_ref):
                name = candidate.name.lower()
                if name in {"string", "symbol", "uuid"}:
                    return "VARCHAR"
                if name in {"bool", "boolean"}:
                    return "BOOLEAN"
                if name in {"float", "double"}:
                    return "DOUBLE"
                if name == "date":
                    return "DATE"
                if name in {"datetime", "timestamp"}:
                    return "TIMESTAMP"
        return None

    def _numeric_sql_type(self, type_ref) -> str | None:
        seen: set[int] = set()
        stack = [type_ref]
        while stack:
            candidate = stack.pop()
            if isinstance(candidate, mm.NumberType):
                return f"DECIMAL({candidate.precision},{candidate.scale})"
            candidate_id = getattr(candidate, "id", None)
            if isinstance(candidate_id, int):
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
            stack.extend(getattr(candidate, "super_types", ()))
        return None

    def _type_lineage(self, type_ref: mm.ScalarType) -> Iterable[mm.ScalarType]:
        seen: set[int] = set()
        stack = [type_ref]
        while stack:
            candidate = stack.pop()
            if candidate.id in seen:
                continue
            seen.add(candidate.id)
            yield candidate
            stack.extend(
                super_type
                for super_type in getattr(candidate, "super_types", ())
                if isinstance(super_type, mm.ScalarType)
            )

    def _safe_identifier(self, token: str) -> str:
        normalized = re.sub(r"[^0-9A-Za-z_]+", "_", token)
        normalized = re.sub(r"_+", "_", normalized).strip("_")
        return normalized or "obj"


__all__ = [
    "Catalog",
    "CatalogBuilder",
    "DataStore",
    "EntityStore",
    "RelationStore",
    "StoreColumn",
]
