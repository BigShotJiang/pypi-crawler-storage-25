from relationalai.semantics import AnyEntity, Integer, Model, where, define, not_

m = Model("Quantifier")

Person = m.Concept("Person")
Cat = m.Concept("Cat")
Person.age = m.Property(f"{Person} has {Integer:age}")

define(
    p1 := Person.new(id=1, name="Alice"),
    p2 := Person.new(id=2, name="Bob"),
    p3 := Person.new(id=3, name="John"),
    p4 := Person.new(id=4, name="Jane"),
    p5 := Person.new(id=5, name="Jim"),
    p1.age(10),
    p2.age(30),
    p5.age(40),
    c1 := Cat.new(name="Fluffy", color="white"),
    c2 := Cat.new(name="Boots", color="black"),
    p1.pets(c1),
    p2.pets(c2),
)

Path = m.Concept("Path")
Path.nodes = m.Relationship(f"{Path} has {AnyEntity:node}", short_name="nodes")
Dog = m.Concept("Dog")
define(
    fluffy := Dog.new(id=100, name="Fluffy"),
    path := Path.new(id=1),
    path.nodes(p1),
    path.nodes(p2),
    path.nodes(fluffy),
)

# persons older than 18 in a cross product with cat colors
where(not_(a := Person.age, a > 18)).select(Person.name, Cat.color).to_df()
# persons older than 18 and the color of their pets
where(not_(a := Person.age, a > 18), Person.pets == Cat).select(Person.name, Cat.color).to_df()
# all persons except persons with id 3 and not an age set (poor John)
where(not_(not_(Person.age), Person.id == 3)).select(Person.name).to_df()
# all persons except persons with id 3 and with some age (John is back!)
where(not_(Person.age, Person.id == 3)).select(Person.name).to_df()
# excluding john again, also exclude people with no pets
where(not_(Person.pets), not_(not_(Person.age), Person.id == 3)).select(Person.name).to_df()
# persons without pets and whose age is > 18
where(name := Person.name, not_(Person.pets), not_(not_(Person.age > 18))).select(name).to_df()
# persons without pets and whose age is not > 18 (includes persons whose age we don't know)
where(name := Person.name, not_(Person.pets), not_(Person.age > 18)).select(name).to_df()
# persons without pets and whose age is not > 18
where(name := Person.name, not_(Person.pets), not_(not_(not_(Person.age > 18)))).select(name).to_df()
# persons without pets, excluding Jim if he is older then 18
where(name := Person.name, not_(Person.pets), not_(Person.id == 5, not_(not_(Person.age > 18)))).select(name).to_df()
# persons without pets, keep only Jim if he is older then 18
where(name := Person.name, not_(Person.pets), not_(not_(Person.id == 5, not_(not_(Person.age > 18))))).select(name).to_df()
# persons without pets, excluding Jane if he is younger than 35
where(name := Person.name, not_(Person.pets), not_(Person.id == 4, not_(not_(not_(Person.age > 35))))).select(name).to_df()

where(not_(Dog(Path.nodes))).select(Path.nodes.id).to_df()
