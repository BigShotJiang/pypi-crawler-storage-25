"""
Regenerate all _after.sql files by running each representative example script
in an isolated subprocess, capturing the compiled SQL via the debugging span logger,
and prettifying with sqlglot.
"""
import subprocess
import sys
import json
from pathlib import Path

EXAMPLES_DIR = Path(__file__).parent / "representative_examples"
SCRIPTS = [
    EXAMPLES_DIR / "aggregate" / "aggregate.py",
    EXAMPLES_DIR / "negation" / "negation.py",
    EXAMPLES_DIR / "person" / "person.py",
    EXAMPLES_DIR / "recursion" / "recursion.py",
    EXAMPLES_DIR / "relationship3_dsl" / "relationship3_dsl.py",
]

RUNNER = r"""
import sys, json, os
sys.path.insert(0, "{pyrel_root}")
os.environ["PYREL_SQL_PIPELINE"] = "sql9"

from relationalai.config import shims
shims.DRY_RUN = True
from relationalai.util import runtime
runtime.ENV = runtime.File()

# Patch SQL9Compiler before anything instantiates it
from relationalai.semantics.backends.sql9_poc.compiler import SQL9Compiler as _C

model_batches = []
query_sqls = []

_orig_cm = _C.compile_model
_orig_cf = _C.compile_fragment

def _patched_cm(self, model):
    result = _orig_cm(self, model)
    if result:
        model_batches.append(list(result))
    return result

def _patched_cf(self, fragment, mm_fragment):
    result = _orig_cf(self, fragment, mm_fragment)
    if result is not None:
        query_sqls.append(result)
    return result

_C.compile_model = _patched_cm
_C.compile_fragment = _patched_cf

from relationalai import semantics as dsl
dsl.Model.all_models.clear()

exec(open("{script}").read())

print(json.dumps({{"model_batches": model_batches, "query_sqls": query_sqls}}))
"""

PYREL_ROOT = str(Path(__file__).parents[6])  # root of monorepo


def try_prettify(sql: str) -> str:
    try:
        import sqlglot
        return sqlglot.transpile(sql, read="duckdb", write="duckdb", pretty=True)[0]
    except Exception:
        return sql


def run_script(script: Path) -> tuple[list[list[str]], list[str]]:
    code = RUNNER.format(pyrel_root=PYREL_ROOT, script=str(script))
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True, text=True, cwd=PYREL_ROOT
    )
    if result.returncode != 0:
        print(f"ERROR running {script.name}:\n{result.stderr[-3000:]}", file=sys.stderr)
        return [], []
    lines = result.stdout.strip().splitlines()
    for line in reversed(lines):
        try:
            data = json.loads(line)
            return data["model_batches"], data["query_sqls"]
        except Exception:
            continue
    print(f"No JSON output from {script.name}.\nSTDOUT:\n{result.stdout[-1000:]}\nSTDERR:\n{result.stderr[-500:]}", file=sys.stderr)
    return [], []


def write_model_file(out_path: Path, sqls: list[str]):
    # Deduplicate: keep last SQL per view name
    seen: dict[str, str] = {}
    for sql in sqls:
        first_line = sql.strip().splitlines()[0] if sql.strip() else ""
        seen[first_line] = sql
    combined = "\n\n".join(try_prettify(s) for s in seen.values())
    out_path.write_text(combined + "\n")


def write_query_file(out_path: Path, sql: str):
    out_path.write_text(try_prettify(sql) + "\n")


def main():
    for script in SCRIPTS:
        if not script.exists():
            print(f"SKIP (not found): {script}")
            continue
        print(f"Running {script.name} ...", end=" ", flush=True)
        model_batches, query_sqls = run_script(script)
        print(f"{len(model_batches)} model batches, {len(query_sqls)} queries")

        base = script.parent
        name = script.stem

        for i, batch in enumerate(model_batches, start=1):
            out = base / f"{name}_model_{i}_after.sql"
            write_model_file(out, batch)
            print(f"  wrote {out.name}")

        for i, sql in enumerate(query_sqls, start=1):
            out = base / f"{name}_query_{i}_after.sql"
            write_query_file(out, sql)
            print(f"  wrote {out.name}")


if __name__ == "__main__":
    main()
