from relationalai.semantics import Integer, String, Model, select, where, define

m = Model("Relationship3")
Concept, Relationship = m.Concept, m.Relationship

Cat = Concept("Cat")
Cat.age = Relationship(f"{Cat} has {Integer:age}")
Cat.name = Relationship(f"{Cat} has {String:name}")
Cat.color = Relationship(f"{Cat} has {String:color}")

c1 = Cat.new(name="Whiskers")
c2 = Cat.new(name="Mittens")
define(c1, c2)
define(Cat.color(c1, "white"))
define(Cat.color(c2, "black"))
where(Cat.name == "Whiskers").define(Cat.age(1))
where(Cat.name == "Mittens").define(Cat.age(3))

select(Cat.name, Cat.age, Cat.color).to_df()
