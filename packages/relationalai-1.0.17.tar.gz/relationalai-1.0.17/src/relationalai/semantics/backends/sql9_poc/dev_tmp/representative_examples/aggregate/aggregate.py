from relationalai.semantics import Float, String, Model, avg, count, define, distinct, min, select, where, sum, Number, Integer
from relationalai.semantics.std import strings

m = Model("Aggregate")
Concept, Relationship, Property = m.Concept, m.Relationship, m.Property

Department = Concept("Department")
Contractor = Concept("Contractor")
Department.employees = Relationship(f"{Department} has employees {Contractor:employees}")
employees = Department.employees

define(
    d1 := Department.new(name="Sales"),
    d2 := Department.new(name="Marketing"),
    d3 := Department.new(name="Engineering"),
    c1 := Contractor.new(name="Joe", age=20),
    c2 := Contractor.new(name="Bob", age=54),
    c3 := Contractor.new(name="Mary", age=30),
    c4 := Contractor.new(name="John", age=50),
    c5 := Contractor.new(name="Jane", age=60),
    d1.employees(c1),
    d1.employees(c2),
    d2.employees(c3),
    d2.employees(c4),
    d2.employees(c5),
)

# Count how many departments there are
select(count(Department)).to_df()

# Grouping is explicit with aggregates
select(Department.name, count(employees).per(Department)).to_df()

# You can place constraints on just the aggregate by using where.
# So to count how many employees and contractors are in each department
where(
    all_employees := count(employees).per(Department),
    middle_aged := count(employees).per(Department).where(employees.age > 30)
).select(
    Department.name,
    all_employees.alias("employees"),
    middle_aged.alias("middle_aged")
).to_df()

Person = Concept("Person")
Person.id = Property(f"{Person} has {Integer:id}", short_name="id")
p1 = Person.new(name="Chris", id=1)
p2 = Person.new(name="Chris", id=2)
p3 = Person.new(name="Joe", id=3)
define(p1, p2, p3)

# By default, aggregates will behave bag-like, meaning
# they will include their keys. So this counts names
# even if they are duplicated:
select(count(Person.name).alias("bag-count")).to_df() # Chris, Chris, Joe = 3

# If you want to count distinct names, you can use
# the `distinct` function:
select(count(distinct(Person.name)).alias("set-count")).to_df() # Chris, Chris, Joe = 2

# This must hold even for complex relationships:
# needs to uniqify on both person and car
Car = Concept("Car")
Car.make = Property(f"{Car} has make {String:make}")
Person.cars = Relationship(f"{Person} has cars {Car:cars}")
define(
    c1 := Car.new(make="Toyota", id=1),
    c2 := Car.new(make="Ford", id=2),
    p1.cars(c1), # Chris, Toyota
    p1.cars(c2), # Chris, Ford
    p2.cars(c1), # Chris, Toyota
)

# all 3
where(key := strings.concat(Person.name, Person.cars.make)).select(count(key)).to_df()
# only 2 as ChrisToyota gets merged
where(key := strings.concat(Person.name, Person.cars.make)).select(count(distinct(key))).to_df()

select(min(Person.id)).to_df()

#------------------------------------------------------
# Projection unifies across branches
#------------------------------------------------------

Edge = m.Concept("Edge")
Edge.src = m.Property(f"{Edge} src {String}")
Edge.dst = m.Property(f"{Edge} dst {String}")
Edge.weight = m.Property(f"{Edge} weight {Float}")

edge1 = Edge.new(src='a', dst='b', weight=1.0, id=1)
edge2 = Edge.new(src='a', dst='b', weight=1.0, id=2)
edge3 = Edge.new(src='b', dst='a', weight=0.1, id=3)
define(edge1, edge2, edge3)

e, eSrc, eDst, eWeight = m.union(
    m.where(Edge, Edge.src <= Edge.dst).select(Edge, Edge.src, Edge.dst, Edge.weight),
    m.where(Edge, Edge.src > Edge.dst).select(Edge, Edge.dst, Edge.src, Edge.weight),
)

m.where(
    summed_weight := sum(e, eWeight).per(eSrc, eDst)
).select(eSrc, eDst, summed_weight).to_df()


#
# Averages, including across value types that extend numbers
#
Salary = Concept("Salary", extends=[Number.size(38,14)])
Person.salary = Property(f"{Person} has {Salary:val}", short_name="salary")

define(
    p1.salary(Salary(50000)),
    p2.salary(Salary(60000)),
    p3.salary(Salary(70000))
)

select(avg(Contractor.age)).to_df()

select(avg(Person.id).alias("avg_id"), avg(Person.salary).alias("avg_salary")).to_df()

#----------------------------------------------------------------------
# Union aggregate result with 0: triggers Decimal-to-literal conversion
#----------------------------------------------------------------------
select(min(Person.salary) | 0).to_df()
