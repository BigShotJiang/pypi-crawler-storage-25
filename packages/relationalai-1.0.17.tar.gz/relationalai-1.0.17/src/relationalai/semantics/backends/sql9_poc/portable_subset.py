from __future__ import annotations

from .sql_ir import (
    SQLBinaryOp,
    SQLCase,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLExists,
    SQLExpr,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLJoin,
    SQLNot,
    SQLOrderItem,
    SQLQuery,
    SQLScalarSubquery,
    SQLScopedSource,
    SQLSelectQuery,
    SQLSeriesSource,
    SQLSource,
    SQLSubquerySource,
    SQLTableFunctionSource,
    SQLTryCast,
    SQLUnionQuery,
    SQLValuesSource,
    SQLWindowCall,
)

_SCOPED_SOURCE_ALIAS = "__scope"
_SCOPE_ROWID = "__scope_rowid"


def portable_subset_violations(query: SQLQuery) -> list[str]:
    violations: list[str] = []
    _check_query(query, violations, path="root")
    return violations


def assert_portable_subset(query: SQLQuery) -> None:
    violations = portable_subset_violations(query)
    if violations:
        raise ValueError("SQL query violates portable subset:\n- " + "\n- ".join(violations))


def _check_query(
    query: SQLQuery,
    violations: list[str],
    *,
    path: str,
    allowed_external_aliases: set[str] | None = None,
) -> None:
    allowed_external_aliases = allowed_external_aliases or set()
    if isinstance(query, SQLUnionQuery):
        for index, child in enumerate(query.queries):
            _check_query(
                child,
                violations,
                path=f"{path}.union[{index}]",
                allowed_external_aliases=allowed_external_aliases,
            )
        if query.queries and _query_external_aliases(query, allowed_external_aliases=allowed_external_aliases):
            violations.append(f"{path} uses correlated UNION branches")
        return

    assert isinstance(query, SQLSelectQuery)
    local_aliases = _local_aliases(query)
    external = _query_external_aliases(query, allowed_external_aliases=allowed_external_aliases)
    if query.limit is not None and external:
        violations.append(f"{path} uses correlated LIMIT")

    if query.from_item is not None:
        _check_source(
            query.from_item.source,
            violations,
            path=f"{path}.from",
            local_aliases=local_aliases,
            allowed_external_aliases=allowed_external_aliases,
        )

    for index, join in enumerate(query.joins):
        _check_join(
            join,
            violations,
            path=f"{path}.join[{index}]",
            local_aliases=local_aliases,
            allowed_external_aliases=allowed_external_aliases,
        )

    for index, expr in enumerate(query.where):
        _check_expr(
            expr,
            violations,
            path=f"{path}.where[{index}]",
            local_aliases=local_aliases,
            expr_context="where",
            allowed_external_aliases=allowed_external_aliases,
        )

    for index, item in enumerate(query.select):
        _check_expr(
            item.expr,
            violations,
            path=f"{path}.select[{index}]",
            local_aliases=local_aliases,
            expr_context="select",
            allowed_external_aliases=allowed_external_aliases,
        )

    for index, expr in enumerate(query.group_by):
        _check_expr(
            expr,
            violations,
            path=f"{path}.group_by[{index}]",
            local_aliases=local_aliases,
            expr_context="group_by",
            allowed_external_aliases=allowed_external_aliases,
        )

    for index, item in enumerate(query.order_by):
        _check_expr(
            item.expr,
            violations,
            path=f"{path}.order_by[{index}]",
            local_aliases=local_aliases,
            expr_context="order_by",
            allowed_external_aliases=allowed_external_aliases,
        )


def _check_join(
    join: SQLJoin,
    violations: list[str],
    *,
    path: str,
    local_aliases: set[str],
    allowed_external_aliases: set[str],
) -> None:
    if "LATERAL" in join.kind.upper():
        violations.append(f"{path} uses LATERAL")
    _check_source(
        join.source,
        violations,
        path=path,
        local_aliases=local_aliases,
        allowed_external_aliases=allowed_external_aliases,
    )
    for index, condition in enumerate(join.conditions):
        _check_expr(
            condition,
            violations,
            path=f"{path}.on[{index}]",
            local_aliases=local_aliases,
            expr_context="join",
            allowed_external_aliases=allowed_external_aliases,
        )


def _check_source(
    source: SQLSource,
    violations: list[str],
    *,
    path: str,
    local_aliases: set[str],
    allowed_external_aliases: set[str],
) -> None:
    if isinstance(source, SQLSubquerySource):
        external = _query_external_aliases(source.query, allowed_external_aliases=allowed_external_aliases)
        if external:
            violations.append(f"{path}.subquery references outer aliases {sorted(external)}")
        _check_query(
            source.query,
            violations,
            path=f"{path}.subquery",
            allowed_external_aliases=allowed_external_aliases,
        )
        return
    if isinstance(source, SQLScopedSource):
        _check_query(
            source.scope_query,
            violations,
            path=f"{path}.scope",
            allowed_external_aliases=allowed_external_aliases,
        )
        scope_external = _query_external_aliases(
            source.scope_query,
            allowed_external_aliases=allowed_external_aliases,
        )
        if scope_external:
            violations.append(f"{path}.scope_query references outer aliases {sorted(scope_external)}")
        if _SCOPE_ROWID not in source.scope_columns:
            violations.append(f"{path} does not expose {_SCOPE_ROWID}")
        inner_external = _query_external_aliases(source.inner_query, allowed_external_aliases={_SCOPED_SOURCE_ALIAS})
        if inner_external:
            violations.append(f"{path}.inner_query references outer aliases {sorted(inner_external)}")
        _check_query(
            source.inner_query,
            violations,
            path=f"{path}.inner",
            allowed_external_aliases={_SCOPED_SOURCE_ALIAS},
        )
        _check_scoped_inner_nesting(
            source.inner_query,
            violations,
            path=f"{path}.inner",
        )
        if not any(left == _SCOPE_ROWID or right == _SCOPE_ROWID for left, right in source.reattach_on):
            violations.append(f"{path} does not reattach using {_SCOPE_ROWID}")
        return
    if isinstance(source, SQLSeriesSource):
        series_allowed_aliases = allowed_external_aliases | local_aliases
        scope_external = _query_external_aliases(
            source.scope_query,
            allowed_external_aliases=series_allowed_aliases,
        )
        if scope_external:
            violations.append(f"{path}.series_scope references outer aliases {sorted(scope_external)}")
        _check_query(
            source.scope_query,
            violations,
            path=f"{path}.series_scope",
            allowed_external_aliases=series_allowed_aliases,
        )
        return
    if isinstance(source, SQLTableFunctionSource):
        aliases = set()
        for arg in source.args:
            aliases |= _expr_table_aliases(arg, allowed_external_aliases=allowed_external_aliases)
        if aliases - allowed_external_aliases:
            violations.append(
                f"{path}.table_function {source.function_name} references outer aliases {sorted(aliases - allowed_external_aliases)}"
            )
        return
    if isinstance(source, SQLValuesSource):
        for row_index, row in enumerate(source.rows):
            for expr_index, expr in enumerate(row):
                _check_expr(
                    expr,
                    violations,
                    path=f"{path}.values[{row_index}][{expr_index}]",
                    local_aliases=local_aliases,
                    expr_context="values",
                    allowed_external_aliases=allowed_external_aliases,
                )


def _check_expr(
    expr: SQLExpr,
    violations: list[str],
    *,
    path: str,
    local_aliases: set[str],
    expr_context: str,
    allowed_external_aliases: set[str],
) -> None:
    if isinstance(expr, SQLBinaryOp):
        _check_expr(
            expr.left,
            violations,
            path=f"{path}.left",
            local_aliases=local_aliases,
            expr_context=expr_context,
            allowed_external_aliases=allowed_external_aliases,
        )
        _check_expr(
            expr.right,
            violations,
            path=f"{path}.right",
            local_aliases=local_aliases,
            expr_context=expr_context,
            allowed_external_aliases=allowed_external_aliases,
        )
        return
    if isinstance(expr, SQLExists):
        exists_allowed_aliases = allowed_external_aliases | local_aliases
        correlated = bool(_query_external_aliases(expr.query, allowed_external_aliases=exists_allowed_aliases))
        if expr_context != "where":
            violations.append(f"{path} uses EXISTS outside WHERE")
        if correlated and isinstance(expr.query, SQLUnionQuery):
            violations.append(f"{path} uses correlated EXISTS over UNION")
        _check_query(
            expr.query,
            violations,
            path=f"{path}.exists",
            allowed_external_aliases=exists_allowed_aliases,
        )
        return
    if isinstance(expr, SQLScalarSubquery):
        subquery_allowed_aliases = allowed_external_aliases | local_aliases
        correlated = bool(_query_external_aliases(expr.query, allowed_external_aliases=subquery_allowed_aliases))
        if correlated and expr_context != "where":
            violations.append(f"{path} uses correlated scalar subquery outside WHERE")
        if correlated and isinstance(expr.query, SQLUnionQuery):
            violations.append(f"{path} uses correlated scalar subquery over UNION")
        _check_query(
            expr.query,
            violations,
            path=f"{path}.scalar",
            allowed_external_aliases=subquery_allowed_aliases,
        )
        return
    if isinstance(expr, (SQLCast, SQLTryCast, SQLIsNotNull, SQLNot)):
        _check_expr(
            expr.expr,
            violations,
            path=f"{path}.expr",
            local_aliases=local_aliases,
            expr_context=expr_context,
            allowed_external_aliases=allowed_external_aliases,
        )
        return
    if isinstance(expr, SQLFunctionCall):
        for index, arg in enumerate(expr.args):
            _check_expr(
                arg,
                violations,
                path=f"{path}.arg[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        return
    if isinstance(expr, SQLConcat):
        for index, arg in enumerate(expr.args):
            _check_expr(
                arg,
                violations,
                path=f"{path}.arg[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        return
    if isinstance(expr, SQLWindowCall):
        for index, part in enumerate(expr.partition_by):
            _check_expr(
                part,
                violations,
                path=f"{path}.partition[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        for index, item in enumerate(expr.order_by):
            assert isinstance(item, SQLOrderItem)
            _check_expr(
                item.expr,
                violations,
                path=f"{path}.order[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        return
    if isinstance(expr, SQLCase):
        for index, (condition, result) in enumerate(expr.when_then):
            _check_expr(
                condition,
                violations,
                path=f"{path}.when[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
            _check_expr(
                result,
                violations,
                path=f"{path}.then[{index}]",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        if expr.else_expr is not None:
            _check_expr(
                expr.else_expr,
                violations,
                path=f"{path}.else",
                local_aliases=local_aliases,
                expr_context=expr_context,
                allowed_external_aliases=allowed_external_aliases,
            )
        return
    if isinstance(expr, SQLColumnRef):
        if expr.table_alias is None:
            return
        if expr.table_alias in local_aliases:
            return
        if expr.table_alias in allowed_external_aliases:
            return
        violations.append(f"{path} references outer alias {expr.table_alias!r}")


def _local_aliases(query: SQLSelectQuery) -> set[str]:
    aliases: set[str] = set()
    if query.from_item is not None:
        aliases.add(query.from_item.alias)
    aliases.update(join.alias for join in query.joins)
    return aliases


def _query_external_aliases(
    query: SQLQuery,
    allowed_external_aliases: set[str] | None = None,
) -> set[str]:
    allowed_external_aliases = allowed_external_aliases or set()
    if isinstance(query, SQLUnionQuery):
        external: set[str] = set()
        for child in query.queries:
            external |= _query_external_aliases(child, allowed_external_aliases=allowed_external_aliases)
        return external

    assert isinstance(query, SQLSelectQuery)
    local_aliases = _local_aliases(query)
    external: set[str] = set()

    if query.from_item is not None:
        external |= _source_external_aliases(
            query.from_item.source,
            local_aliases,
            allowed_external_aliases=allowed_external_aliases,
        )
    for join in query.joins:
        external |= _source_external_aliases(
            join.source,
            local_aliases,
            allowed_external_aliases=allowed_external_aliases,
        )
        for condition in join.conditions:
            external |= _expr_table_aliases(condition, allowed_external_aliases=allowed_external_aliases)
    for expr in query.where:
        external |= _expr_table_aliases(expr, allowed_external_aliases=allowed_external_aliases)
    for item in query.select:
        external |= _expr_table_aliases(item.expr, allowed_external_aliases=allowed_external_aliases)
    for expr in query.group_by:
        external |= _expr_table_aliases(expr, allowed_external_aliases=allowed_external_aliases)
    for item in query.order_by:
        external |= _expr_table_aliases(item.expr, allowed_external_aliases=allowed_external_aliases)
    return (external - local_aliases) - allowed_external_aliases


def _source_external_aliases(
    source: SQLSource,
    local_aliases: set[str],
    *,
    allowed_external_aliases: set[str],
) -> set[str]:
    if isinstance(source, SQLSubquerySource):
        return _query_external_aliases(source.query, allowed_external_aliases=allowed_external_aliases) - local_aliases
    if isinstance(source, SQLScopedSource):
        return set()
    if isinstance(source, SQLSeriesSource):
        return _query_external_aliases(
            source.scope_query,
            allowed_external_aliases=allowed_external_aliases,
        ) - local_aliases
    if isinstance(source, SQLTableFunctionSource):
        aliases: set[str] = set()
        for arg in source.args:
            aliases |= _expr_table_aliases(arg, allowed_external_aliases=allowed_external_aliases)
        return (aliases - local_aliases) - allowed_external_aliases
    if isinstance(source, SQLValuesSource):
        aliases: set[str] = set()
        for row in source.rows:
            for expr in row:
                aliases |= _expr_table_aliases(expr, allowed_external_aliases=allowed_external_aliases)
        return (aliases - local_aliases) - allowed_external_aliases
    return set()


def _check_scoped_inner_nesting(
    query: SQLQuery,
    violations: list[str],
    *,
    path: str,
) -> None:
    if isinstance(query, SQLUnionQuery):
        if _SCOPED_SOURCE_ALIAS in _query_external_aliases(query):
            violations.append(f"{path} contains nested UNION referencing scoped alias {_SCOPED_SOURCE_ALIAS!r}")
        for index, child in enumerate(query.queries):
            _check_scoped_inner_nesting(child, violations, path=f"{path}.union[{index}]")
        return

    assert isinstance(query, SQLSelectQuery)
    if query.from_item is not None:
        _check_scoped_inner_source(query.from_item.source, violations, path=f"{path}.from")
    for index, join in enumerate(query.joins):
        _check_scoped_inner_source(join.source, violations, path=f"{path}.join[{index}]")


def _check_scoped_inner_source(
    source: SQLSource,
    violations: list[str],
    *,
    path: str,
) -> None:
    if isinstance(source, SQLSubquerySource):
        if _SCOPED_SOURCE_ALIAS in _query_external_aliases(source.query):
            violations.append(f"{path}.subquery references scoped alias {_SCOPED_SOURCE_ALIAS!r}")
        _check_scoped_inner_nesting(source.query, violations, path=f"{path}.subquery")
        return
    if isinstance(source, SQLScopedSource):
        if _SCOPED_SOURCE_ALIAS in _query_external_aliases(source.scope_query):
            violations.append(f"{path}.scope references scoped alias {_SCOPED_SOURCE_ALIAS!r}")
        if _SCOPED_SOURCE_ALIAS in _query_external_aliases(source.inner_query):
            violations.append(f"{path}.inner_query references scoped alias {_SCOPED_SOURCE_ALIAS!r}")
        _check_scoped_inner_nesting(source.scope_query, violations, path=f"{path}.scope")
        _check_scoped_inner_nesting(source.inner_query, violations, path=f"{path}.inner")
        return
    if isinstance(source, SQLSeriesSource):
        return
    if isinstance(source, SQLTableFunctionSource):
        aliases: set[str] = set()
        for arg in source.args:
            aliases |= _expr_table_aliases(arg, allowed_external_aliases=set())
        if _SCOPED_SOURCE_ALIAS in aliases:
            violations.append(f"{path}.table_function references scoped alias {_SCOPED_SOURCE_ALIAS!r}")


def _expr_table_aliases(
    expr: SQLExpr,
    *,
    allowed_external_aliases: set[str],
) -> set[str]:
    if isinstance(expr, SQLColumnRef):
        return {expr.table_alias} if expr.table_alias is not None else set()
    if isinstance(expr, SQLBinaryOp):
        return _expr_table_aliases(expr.left, allowed_external_aliases=allowed_external_aliases) | _expr_table_aliases(
            expr.right,
            allowed_external_aliases=allowed_external_aliases,
        )
    if isinstance(expr, SQLExists):
        return _query_external_aliases(expr.query, allowed_external_aliases=allowed_external_aliases)
    if isinstance(expr, SQLScalarSubquery):
        return _query_external_aliases(expr.query, allowed_external_aliases=allowed_external_aliases)
    if isinstance(expr, (SQLCast, SQLTryCast, SQLIsNotNull, SQLNot)):
        return _expr_table_aliases(expr.expr, allowed_external_aliases=allowed_external_aliases)
    if isinstance(expr, SQLFunctionCall):
        aliases: set[str] = set()
        for arg in expr.args:
            aliases |= _expr_table_aliases(arg, allowed_external_aliases=allowed_external_aliases)
        return aliases
    if isinstance(expr, SQLConcat):
        aliases: set[str] = set()
        for arg in expr.args:
            aliases |= _expr_table_aliases(arg, allowed_external_aliases=allowed_external_aliases)
        return aliases
    if isinstance(expr, SQLWindowCall):
        aliases: set[str] = set()
        for part in expr.partition_by:
            aliases |= _expr_table_aliases(part, allowed_external_aliases=allowed_external_aliases)
        for item in expr.order_by:
            aliases |= _expr_table_aliases(item.expr, allowed_external_aliases=allowed_external_aliases)
        return aliases
    if isinstance(expr, SQLCase):
        aliases: set[str] = set()
        for condition, result in expr.when_then:
            aliases |= _expr_table_aliases(condition, allowed_external_aliases=allowed_external_aliases)
            aliases |= _expr_table_aliases(result, allowed_external_aliases=allowed_external_aliases)
        if expr.else_expr is not None:
            aliases |= _expr_table_aliases(expr.else_expr, allowed_external_aliases=allowed_external_aliases)
        return aliases
    return set()


__all__ = ["assert_portable_subset", "portable_subset_violations"]
