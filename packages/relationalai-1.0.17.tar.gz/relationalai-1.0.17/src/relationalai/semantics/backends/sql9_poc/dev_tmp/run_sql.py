#!/usr/bin/env python3
"""Run a SQL file against an in-memory DuckDB instance."""

import re
import sys
import time
import duckdb

if len(sys.argv) < 2:
    print(f"Usage: {sys.argv[0]} <sql_file>")
    sys.exit(1)

sql = open(sys.argv[1]).read()

# Fix missing AS in "CREATE OR REPLACE VIEW name\nSELECT" (no AS before SELECT)
sql = re.sub(r'(CREATE\s+OR\s+REPLACE\s+VIEW\s+\S+)\s*\n(\s*SELECT)', r'\1 AS\n\2', sql)

statements = [s.strip() for s in sql.split("\n\n") if s.strip()]
setup_stmts = statements[:-1]
query_stmt = statements[-1]

RUNS = 5
timings = []
result = None

for i in range(RUNS):
    conn = duckdb.connect(":memory:")
    for stmt in setup_stmts:
        conn.execute(stmt)
    t0 = time.perf_counter()
    result = conn.execute(query_stmt).fetchdf()
    timings.append(time.perf_counter() - t0)

BOLD  = "\033[1m"
CYAN  = "\033[36m"
GREEN = "\033[32m"
YELLOW= "\033[33m"
RED   = "\033[31m"
RESET = "\033[0m"

assert result is not None
print(result.to_string(index=False))
print()

avg_ms = sum(timings) / RUNS * 1000
min_ms = min(timings) * 1000
max_ms = max(timings) * 1000

print(
    f"{BOLD}Query time{RESET} ({RUNS} runs):  "
    f"{CYAN}avg {avg_ms:.1f} ms{RESET}  "
    f"{GREEN}min {min_ms:.1f} ms{RESET}  "
    f"{RED}max {max_ms:.1f} ms{RESET}"
)
