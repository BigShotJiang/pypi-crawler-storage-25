"""Public sql9 compiler entrypoint."""
from __future__ import annotations

from relationalai.semantics.metamodel.metamodel_analyzer import Groundness

from ...frontend.base import Fragment, Model
from ...metamodel.metamodel import Task
from relationalai.config.config import Config
from .artifacts import SQL9ExecutionPlan
from .catalog import Catalog
from .emitter import SQL9Emitter
from .lower import Lowerer
from .model_compiler import ModelCompiler, PreparedModel
from .normalize import SQLNormalizer
from .sql_optimizer import SQLOptimizer
from v0.relationalai import debugging

class SQL9Compiler:
    def __init__(self, dialect: str = "duckdb", config: Config | None = None):
        self.config = config
        self.dialect = dialect
        self.pipeline = "sql9"
        self.catalog = Catalog(
            entity_stores=(),
            relation_stores=(),
            data_stores=(),
            folded_property_owner_type_ids={},
            data_column_store_type_ids={},
        )
        self._groundness = Groundness()
        self._model_compiler = ModelCompiler()
        self._sql_normalizer = SQLNormalizer()
        self._lowerer = Lowerer(self.catalog)
        self._optimizer = SQLOptimizer()
        self.emitter = SQL9Emitter()
        self.execution_plan = SQL9ExecutionPlan()
        self._last_model_ref: Model | None = None
        self._last_model_version: int | None = None

    @property
    def model_artifacts(self) -> PreparedModel | None:
        return self._model_compiler.last_prepared_model

    def compile_model(self, model: Model) -> list[str]:
        if self._last_model_ref is model and self._last_model_version == model._version:
            return []
        mm_model = model.to_metamodel()
        with debugging.span("compile", metamodel=mm_model) as span:
            span["compile_type"] = "model_v1"
            with debugging.span("v1") as span:
                with debugging.span("Original") as span:
                    span["metamodel"] = str(mm_model.root)
                schema_name = self._resolve_model_schema(model)
                prepared = self._model_compiler.compile_model(mm_model, schema_name=schema_name)
                prepared = self._model_compiler.last_prepared_model
                if prepared is not None:
                    self.catalog = prepared.catalog
                    self._lowerer = Lowerer(self.catalog)
                    self.execution_plan = self._lowerer.lower_model(prepared.model_plan)
                    self.execution_plan = self._optimizer.optimize_plan(self.execution_plan)
                self._last_model_ref = model
                self._last_model_version = model._version
                with debugging.span("Emitter") as span:
                    result = [self.emitter.emit(view) for step in self.execution_plan.steps for view in step.views]
                    span["metamodel"] = "\n".join(result)
                return result

    def compile_fragment(self, fragment: Fragment, mm_fragment: Task) -> str | None:
        from ...metamodel.metamodel_analyzer import Normalize
        from ...metamodel.typer import Typer

        with debugging.span("compile", metamodel=mm_fragment) as span:
            span["compile_type"] = "query_v1"
            with debugging.span("v1") as span:
                typed_fragment = mm_fragment
                with debugging.span("Original") as span:
                    span["metamodel"] = str(typed_fragment)
                prepared = self._model_compiler.last_prepared_model
                typer = Typer(enforce=True)
                if prepared is not None:
                    typer.model_net = prepared.model_net
                with debugging.span("Typer") as span:
                    typed_fragment = typer.infer_query(mm_fragment)
                    span["metamodel"] = str(typed_fragment)
                with debugging.span("Normalizer") as span:
                    normalized = Normalize().normalize(typed_fragment)
                    span["metamodel"] = str(normalized)
                with debugging.span("Groundness") as span:
                    self._groundness.enforce(normalized)

                with debugging.span("SQL Normalizer") as span:
                    canonical = self._sql_normalizer.normalize(normalized)
                    span["metamodel"] = str(canonical)
                if prepared is not None:
                    with debugging.span("Storage Normalizer") as span:
                        canonical = self._model_compiler.storage_normalizer.bind_fragment(
                            canonical,
                            prepared.model_plan.final_tables_by_relation_id,
                        )
                        span["metamodel"] = str(canonical)
                if not isinstance(canonical, Task):
                    return None
                with debugging.span("Lowerer") as span:
                    lowered = self._lowerer.lower_fragment(canonical)
                    span["metamodel"] = str(lowered)
                if lowered is not None:
                    lowered = self._optimizer.optimize_query(lowered)
                with debugging.span("Emitter") as span:
                    result = None if lowered is None else self.emitter.emit(lowered)
                    span["metamodel"] = str(result)
                return result

    def _resolve_model_schema(self, model: Model) -> str | None:
        config_source = self.config if self.config is not None else model.config
        if config_source is None:
            return None
        model_cfg = getattr(config_source, "model", None)
        schema_name = getattr(model_cfg, "schema_", None)
        if not isinstance(schema_name, str) or not schema_name.strip():
            return None
        schema_name = schema_name.strip()
        if self.dialect == "duckdb":
            parts = schema_name.split(".")
            if len(parts) == 2:
                return f"{parts[0]}_{parts[1]}"
        return schema_name

__all__ = ["SQL9Compiler"]
