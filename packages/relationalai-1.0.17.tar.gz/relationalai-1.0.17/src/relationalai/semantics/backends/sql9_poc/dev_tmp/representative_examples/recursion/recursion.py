from relationalai.semantics import Integer, Model, define, per, select, union, where

m = Model("Graph Recursion")

Node = m.Concept("Node")
edge = m.Relationship(f"{Node:src} has an edge to {Node:dst}")
distance = m.Relationship(f"Distance from {Node:src} to {Node:dst} is {Integer:d}")

python_edge_list = [(1, 2), (2, 3)]
for src, dst in python_edge_list:
    u = Node.new(id=src)
    v = Node.new(id=dst)
    define(u, v, edge(u, v))

# Recursive definitions
u, v, n = Node.ref(), Node.ref(), Node.ref()
d = Integer.ref()

define(
    distance(u, v, per(u, v).min(union(
        select(0).where(u == v),
        select(distance(u, n) + 1).where(edge(n, v)),
    ))),
)

where(distance(u, v, d)).select(u.id, v.id, d).to_df()
