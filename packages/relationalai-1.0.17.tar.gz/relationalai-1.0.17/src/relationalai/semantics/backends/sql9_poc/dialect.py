from __future__ import annotations

import re


class SQL9Dialect:
    dialect_name = "generic"

    def quote_identifier(self, name: str) -> str:
        escaped = name.replace('"', '""')
        return f'"{escaped}"'

    def quote_path(self, path: str) -> str:
        return ".".join(self.quote_identifier(part) for part in path.split("."))

    def format_table_name(self, name: str) -> str:
        return name


class DuckDBDialect(SQL9Dialect):
    dialect_name = "duckdb"

    def format_table_name(self, name: str) -> str:
        parts = name.split(".")
        if len(parts) == 3:
            db, schema, table = parts
            return f"{db}_{schema}.{table}"
        return name


class SnowflakeDialect(SQL9Dialect):
    dialect_name = "snowflake"
    _UNQUOTED_IDENTIFIER_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*$")
    _RESERVED_IDENTIFIERS = frozenset(
        {
            "ALL",
            "ALTER",
            "AND",
            "ANY",
            "AS",
            "BETWEEN",
            "BY",
            "CASE",
            "CAST",
            "CHECK",
            "COLUMN",
            "CONNECT",
            "CONSTRAINT",
            "CREATE",
            "CROSS",
            "CURRENT",
            "CURRENT_DATE",
            "CURRENT_TIME",
            "CURRENT_TIMESTAMP",
            "CURRENT_USER",
            "DATABASE",
            "DELETE",
            "DISTINCT",
            "DROP",
            "ELSE",
            "EXISTS",
            "FALSE",
            "FOLLOWING",
            "FOR",
            "FROM",
            "FULL",
            "GRANT",
            "GROUP",
            "HAVING",
            "ILIKE",
            "IN",
            "INCREMENT",
            "INNER",
            "INSERT",
            "INTERSECT",
            "INTO",
            "IS",
            "ISSUE",
            "JOIN",
            "LATERAL",
            "LEFT",
            "LIKE",
            "LOCALTIME",
            "LOCALTIMESTAMP",
            "MINUS",
            "NATURAL",
            "NOT",
            "NULL",
            "OF",
            "ON",
            "OR",
            "ORDER",
            "QUALIFY",
            "REGEXP",
            "REVOKE",
            "RIGHT",
            "RLIKE",
            "ROW",
            "ROWS",
            "SAMPLE",
            "SCHEMA",
            "SELECT",
            "SET",
            "SOME",
            "START",
            "TABLE",
            "TABLESAMPLE",
            "THEN",
            "TO",
            "TRIGGER",
            "TRUE",
            "TRY_CAST",
            "UNION",
            "UNIQUE",
            "UPDATE",
            "USING",
            "VALUES",
            "VIEW",
            "WHEN",
            "WHENEVER",
            "WHERE",
            "WITH",
        }
    )

    def quote_identifier(self, name: str) -> str:
        token = name.strip()
        if token == "*":
            return token
        if token.startswith('"') and token.endswith('"'):
            return token
        upper = token.upper()
        if self._UNQUOTED_IDENTIFIER_RE.fullmatch(token) and upper not in self._RESERVED_IDENTIFIERS:
            return upper
        escaped = token.replace('"', '""')
        return f'"{escaped}"'


__all__ = ["DuckDBDialect", "SnowflakeDialect", "SQL9Dialect"]
