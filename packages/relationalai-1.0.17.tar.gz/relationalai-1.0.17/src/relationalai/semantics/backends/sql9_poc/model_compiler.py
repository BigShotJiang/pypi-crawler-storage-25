"""Model-side sql9 pipeline orchestration."""
from __future__ import annotations

from dataclasses import dataclass

from ...metamodel.metamodel import Model as MMModel
from ...metamodel.metamodel_analyzer import RelationAnalyzer, Groundness, Normalize
from ...metamodel.typer import Typer
from .artifacts import SQL9ModelPlan
from .catalog import Catalog, CatalogBuilder
from .coalesce import Coalescer, PlannedStratum
from .dependency import Stratifier, Stratum
from .normalize import StorageVersionNormalizer

from v0.relationalai import debugging


@dataclass(frozen=True, slots=True)
class PreparedModel:
    typed_model: MMModel
    normalized_model: MMModel
    analyzed_model: MMModel
    catalog: Catalog
    strata: tuple[Stratum, ...]
    coalesced_strata: tuple[PlannedStratum, ...]
    model_plan: SQL9ModelPlan
    model_net: object | None


class ModelCompiler:
    def __init__(self) -> None:
        self.typer = Typer(enforce=True)
        self.normalizer = Normalize()
        self._groundness = Groundness()
        self.analyzer = RelationAnalyzer()
        self.catalog_builder = CatalogBuilder()
        self.stratifier = Stratifier()
        self.coalescer = Coalescer()
        self.storage_normalizer = StorageVersionNormalizer()
        self.last_prepared_model: PreparedModel | None = None

    def compile_model(self, model: MMModel, *, schema_name: str | None = None) -> PreparedModel:
        with debugging.span("Typer") as span:
            typed_model = self.typer.infer_model(model)
            span["metamodel"] = str(typed_model.root)
        with debugging.span("Normalizer") as span:
            normalized_root = self.normalizer.normalize(typed_model.root)
            normalized_model = typed_model.mut(root=normalized_root)
            span["metamodel"] = str(normalized_model.root)
        with debugging.span("Groundness") as span:
            self._groundness.enforce(normalized_model.root)
        with debugging.span("Relation Analyzer") as span:
            relation_analysis = self.analyzer.analyze(normalized_model)
        with debugging.span("Catalog Builder") as span:
            catalog = self.catalog_builder.build(normalized_model, relation_analysis, schema_name=schema_name)
            span["metamodel"] = str(catalog)
        with debugging.span("Stratifier") as span:
            strata = self.stratifier.build(normalized_model)
            span["metamodel"] = str(strata)
        with debugging.span("Coalescer") as span:
            coalesced = self.coalescer.plan(normalized_model, catalog, strata)
            span["metamodel"] = str(coalesced)
        with debugging.span("Storage Normalizer") as span:
            model_plan = self.storage_normalizer.normalize_model_plan(normalized_model, catalog, coalesced)
            span["metamodel"] = str(model_plan)

        self.last_prepared_model = PreparedModel(
            typed_model=typed_model,
            normalized_model=normalized_model,
            analyzed_model=normalized_model,
            catalog=catalog,
            strata=strata,
            coalesced_strata=coalesced,
            model_plan=model_plan,
            model_net=self.typer.model_net,
        )
        return self.last_prepared_model


__all__ = ["ModelCompiler", "PreparedModel"]
