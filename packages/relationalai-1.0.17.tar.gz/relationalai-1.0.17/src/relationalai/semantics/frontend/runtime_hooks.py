from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING
import weakref

from ...util.runtime import ExecutionOrigin, current_execution_origin, register_cell_start_observer

if TYPE_CHECKING:
    from .base import Fragment, Model


_models_by_origin: dict[ExecutionOrigin, dict[int, weakref.ReferenceType["Model"]]] = defaultdict(dict)
_rules_by_origin: dict[ExecutionOrigin, dict[int, weakref.ReferenceType["Fragment"]]] = defaultdict(dict)
_rule_owner: dict[int, weakref.ReferenceType["Model"]] = {}
_rule_origin: dict[int, ExecutionOrigin] = {}
_model_rules: dict[int, dict[int, weakref.ReferenceType["Fragment"]]] = defaultdict(dict)
_model_origin: dict[int, ExecutionOrigin] = {}
_observer_registered = False


def register_model(model: "Model") -> None:
    origin = current_execution_origin()
    if origin is None:
        return
    _retire_untracked_active_models(exclude=model)
    model_id = id(model)
    _models_by_origin[origin][model_id] = weakref.ref(model)
    _model_origin[model_id] = origin


def register_rule(model: "Model", fragment: "Fragment") -> None:
    origin = current_execution_origin()
    if origin is None:
        return

    rule_id = id(fragment)
    _forget_rule(rule_id)
    _rules_by_origin[origin][rule_id] = weakref.ref(fragment)
    _rule_owner[rule_id] = weakref.ref(model)
    _rule_origin[rule_id] = origin
    _model_rules[id(model)][rule_id] = weakref.ref(fragment)


def unregister_rule(model: "Model", fragment: "Fragment") -> None:
    _forget_rule(id(fragment), owner_id=id(model))


def _forget_rule(rule_id: int, *, owner_id: int | None = None) -> None:
    origin = _rule_origin.pop(rule_id, None)
    if origin is not None:
        refs = _rules_by_origin.get(origin)
        if refs is not None:
            refs.pop(rule_id, None)
            if not refs:
                _rules_by_origin.pop(origin, None)

    if owner_id is None:
        owner_ref = _rule_owner.pop(rule_id, None)
        owner = owner_ref() if owner_ref is not None else None
        owner_id = id(owner) if owner is not None else None
    else:
        _rule_owner.pop(rule_id, None)

    if owner_id is not None:
        refs = _model_rules.get(owner_id)
        if refs is not None:
            refs.pop(rule_id, None)
            if not refs:
                _model_rules.pop(owner_id, None)


def _unregister_model(model: "Model") -> None:
    model_id = id(model)
    origin = _model_origin.pop(model_id, None)
    if origin is not None:
        refs = _models_by_origin.get(origin)
        if refs is not None:
            refs.pop(model_id, None)
            if not refs:
                _models_by_origin.pop(origin, None)

    for rule_id in list(_model_rules.pop(model_id, {}).keys()):
        _forget_rule(rule_id, owner_id=model_id)


def _retire_models_for_origin(origin: ExecutionOrigin) -> None:
    for model_id, model_ref in list(_models_by_origin.get(origin, {}).items()):
        model = model_ref()
        if model is None:
            _unregister_model_by_id(model_id, origin)
            continue
        active_models = getattr(type(model), "all_models", None)
        if isinstance(active_models, list):
            while model in active_models:
                active_models.remove(model)
        _unregister_model(model)


def _retire_untracked_active_models(*, exclude: "Model | None" = None) -> None:
    active_models = getattr(exclude.__class__ if exclude is not None else None, "all_models", None)
    if not isinstance(active_models, list):
        from .base import Model
        active_models = Model.all_models

    for model in list(active_models):
        if exclude is not None and model is exclude:
            continue
        if id(model) in _model_origin:
            continue
        while model in active_models:
            active_models.remove(model)


def _remove_rules_for_origin(origin: ExecutionOrigin) -> None:
    for rule_id, fragment_ref in list(_rules_by_origin.get(origin, {}).items()):
        fragment = fragment_ref()
        if fragment is None:
            _forget_rule(rule_id)
            continue
        owner_ref = _rule_owner.get(rule_id)
        owner = owner_ref() if owner_ref is not None else None
        if owner is None:
            _forget_rule(rule_id)
            continue
        try:
            owner._remove_rule(fragment)
        except ValueError:
            _forget_rule(rule_id, owner_id=id(owner))


def _unregister_model_by_id(model_id: int, origin: ExecutionOrigin) -> None:
    refs = _models_by_origin.get(origin)
    if refs is not None:
        refs.pop(model_id, None)
        if not refs:
            _models_by_origin.pop(origin, None)
    _model_origin.pop(model_id, None)
    for rule_id in list(_model_rules.pop(model_id, {}).keys()):
        _forget_rule(rule_id, owner_id=model_id)


def _on_cell_start(origin: ExecutionOrigin) -> None:
    _retire_models_for_origin(origin)
    _remove_rules_for_origin(origin)


def _ensure_observer_registered() -> None:
    global _observer_registered
    if _observer_registered:
        return
    register_cell_start_observer(_on_cell_start)
    _observer_registered = True


def _reset_runtime_hooks_state_for_tests() -> None:
    global _observer_registered
    _models_by_origin.clear()
    _rules_by_origin.clear()
    _rule_owner.clear()
    _rule_origin.clear()
    _model_rules.clear()
    _model_origin.clear()
    _observer_registered = False
    _ensure_observer_registered()


_ensure_observer_registered()
