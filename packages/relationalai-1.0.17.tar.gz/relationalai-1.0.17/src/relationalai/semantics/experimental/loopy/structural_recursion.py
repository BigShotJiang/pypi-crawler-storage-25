from relationalai.semantics.frontend.base import Library, Field
from relationalai.semantics import metamodel as mm
from relationalai.semantics.frontend.core import String, Number

library = Library("Structural Recursion")

iter = library.Relation("iter", [])
inner_loop = library.Relation("inner_loop", [])
inner_loop_2 = library.Relation("inner_loop2", [])
inspect = library.Relation("inspect", [Field.input("value", String), Field("result", Number)])

_iter_relation = mm.Relation("iter")
iter_annotation = mm.Annotation(relation=_iter_relation,)

_inner_loop_relation = mm.Relation("inner_loop")
inner_loop_annotation = mm.Annotation(relation=_inner_loop_relation,)

_inner_loop_2_relation = mm.Relation("inner_loop2")
inner_loop_2_annotation = mm.Annotation(relation=_inner_loop_2_relation,)

_inspect_relation=inspect
def inspect(type: str, verbosity: int):
    return _inspect_relation(type, verbosity)

STRUCTURAL_RECURSION_ANNOTATIONS = ["iter", "inner_loop", "inner_loop2", "inspect"]
