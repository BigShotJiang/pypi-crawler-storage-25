"""Inspect a PyRel model's schema and rules without an engine connection.

A PyRel :class:`~relationalai.semantics.frontend.base.Model` declares:

- **Concepts** — entity types (e.g. ``Person``, ``Order``). Each concept can
  have identity properties (from ``identify_by=``) and other properties
  (attributes).
  In the DSL, :class:`~relationalai.semantics.frontend.base.Property` is a
  subclass of :class:`~relationalai.semantics.frontend.base.Relationship`;
  both are represented as :class:`RelationshipInfo` with ``is_property``.
- **Relationships** — multi-valued associations between concepts
  (``Customer placed Order``).
- **Tables** — external table references (for example Snowflake tables) or
  temporary table-like objects backed by in-memory data
  (``model.data([...])``). ``TableInfo.loads`` shows which concepts a table
  populates; ``ConceptInfo.data_sources`` shows the reverse.
- **Enums** — enumeration types (``Priority: LOW, MEDIUM, HIGH``).
- **Rules** — ``define()`` and ``require()`` fragments registered on the
  model, exposed as :class:`RuleInfo` with rendered text.

Standalone declarations (not owned by any concept) appear in
``bare_relationships`` on :class:`ModelSchema`.

Usage::

    from relationalai.semantics import inspect

    ms = inspect.schema(model)
    print(ms)                      # human-readable summary
    ms["Person"].identify_by       # identity properties
    ms["Person"].has_data           # True if loaded from a table or model.data()
    ms.defines                     # all define() rules as RuleInfo
    ms.to_dict()                   # JSON-safe dictionary

    concept = inspect.to_concept(Person.name)  # resolve Chain -> Concept
    refs = inspect.fields(Person.friends)      # FieldRefs for select()

This module is read-only and frontend-level only — nothing is mutated and no
compiler or engine connection is required.

.. note::

   For table-backed concepts (``define(Concept.new(table.to_schema()))``),
   identity properties only appear when ``identify_by=`` is passed to the
   ``Concept`` constructor::

       Customer = m.Concept("Customer", identify_by={"C_CUSTKEY": Integer})
       define(Customer.new(customer_tbl.to_schema()))

   Without ``identify_by``, all properties are reported as non-identity
   properties.

Example output of ``print(ms)``::

    Model: scheduling
    =================

      Task
        Identity:
          id: Integer
        Properties:
          name: String
          priority: Priority
        Relationships:
          Worker is assigned to Task

      Data Sources:
        db.tasks -> Task [ID: Integer, NAME: String, PRIORITY: String]

      Standalone Declarations:
        Task costs Float:cost

      Enums:
        Priority: LOW, MEDIUM, HIGH

      Defines: (2 rules)
        ...

      Requires: (1 rules)
        ...
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any, Iterator, TypeVar, overload, TYPE_CHECKING

__all__ = [
    "ConceptInfo",
    "EnumInfo",
    "FieldInfo",
    "RuleInfo",
    "ModelSchema",
    "RelationshipInfo",
    "TableInfo",
    "fields",
    "schema",
    "to_concept",
]

from relationalai.semantics.frontend.base import (
    Chain,
    CoreConcepts,
    Expression,
    Field,
    FieldRef,
    Fragment,
    Model,
    New,
    Property,
    Reading,
    Relationship,
    Variable,
)
from relationalai.semantics.frontend.pprint import format as _pprint_format

if TYPE_CHECKING:
    from relationalai.semantics.frontend.base import Concept


# ── Inheritance helpers ────────────────────────────────────────────────────


def _is_subtype(concept: Concept, base: Concept) -> bool:
    """True if *base* is *concept* itself or an ancestor of *concept*."""
    if concept._id == base._id:
        return True
    return any(_is_subtype(ext, base) for ext in concept._extends)


def _infer_owner_concept(relationship: Relationship) -> Concept | None:
    """Find the unique concept that owns *relationship*, if any.

    Used by :func:`fields` when called with a direct Relationship/Reading
    handle (no chain context) so owned properties exclude the owner field
    by default, matching the documented API.

    A concept "owns" a relationship if the relationship appears in its
    ``_relationships`` or ``_identify_by`` collection.  Returns None when
    zero concepts own it (standalone/bare relationship) or when more than
    one does (ambiguous — e.g. a property attached to two concepts).
    """
    model = relationship._model
    if model is None:
        return None
    rel_id = relationship._id
    owners: list[Concept] = []
    for c in model.concepts:
        owned = False
        if any(r._id == rel_id for r in c._relationships.values()):
            owned = True
        else:
            for ident in c._identify_by:
                actual = ident._relationship if isinstance(ident, Reading) else ident
                if actual._id == rel_id:
                    owned = True
                    break
        if owned:
            owners.append(c)
            if len(owners) > 1:
                return None
    if len(owners) == 1:
        return owners[0]
    return None


# ── Preferred alias resolution ──────────────────────────────────────────────

# Ordered by priority — first match wins when reverse-mapping a concept _id
# to a friendly name.
_PREFERRED_ALIASES = (
    "Integer",
    "Int64",
    "Int128",
    "Float",
    "Decimal",
    "Bool",
    "String",
    "Date",
    "DateTime",
    "Number",
    "Any",
    "AnyEntity",
)


def _friendly_type_name(concept: Concept) -> str:
    """Return the most human-friendly name for *concept*.

    Checks ``_PREFERRED_ALIASES`` first, then falls back to any
    ``CoreConcepts`` alias that doesn't contain parentheses.  Sized
    numeric types like ``Decimal.size(12, 2)`` — stored internally as
    ``"Number(12,2)"`` — are mapped to ``"Decimal(12,2)"`` since
    ``Decimal`` is the preferred user-facing name.  User-defined
    concepts return ``concept._name`` as-is.
    """
    cid = concept._id
    # Fast path: check preferred aliases in priority order
    for alias in _PREFERRED_ALIASES:
        if alias in CoreConcepts and CoreConcepts[alias]._id == cid:
            return alias
    # Fallback: any core alias without parentheses (e.g. avoids "Number(12,2)")
    for alias, c in CoreConcepts.items():
        if c._id == cid and "(" not in alias:
            return alias
    # Sized Number types → prefer "Decimal" label.  Decimal.size(12,2) creates
    # a concept with _name "Number(12,2)" which is technically correct but
    # confusing — "Decimal(12,2)" is the name users expect.
    name = concept._name
    if name.startswith("Number("):
        return "Decimal" + name[6:]
    return name


# ── Structured reading reconstruction ───────────────────────────────────────


def _structured_reading(reading: Reading) -> str:
    """Reconstruct a human-readable string from a Reading's _parts template.

    Alt readings (from ``.alt()``) store field indices that reference the
    *parent* relationship's field ordering, not the reading's reordered
    ``_fields``.  Use ``_relationship._fields`` when available so that
    indices resolve correctly regardless of field reordering.
    """
    parts: list[str] = []
    # Reading._parts indices reference the parent Relationship's field ordering,
    # not the Reading's own (potentially reordered) _fields.  All Reading
    # instances set _relationship in __init__; the getattr fallback is purely
    # defensive.  (RelationshipRef also has _relationship but is never passed
    # here — only _readings items are, which are always Reading instances.)
    source_fields = reading._fields
    parent = getattr(reading, "_relationship", None)
    if parent is not None:
        source_fields = parent._fields
    for p in reading._parts:
        if isinstance(p, int):
            field = source_fields[p]
            type_name = _friendly_type_name(field.type)
            # Append ":fieldname" when the field name differs from the type
            # (disambiguates "String:name" vs "String:breed")
            if field.name.lower() != type_name.lower():
                parts.append(f"{type_name}:{field.name}")
            else:
                parts.append(type_name)
        else:
            parts.append(p)
    return "".join(parts).strip()


# ── Dataclasses ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class FieldInfo:
    """A typed field in a property or relationship.

    Attributes
    ----------
    name : str
        Field name (e.g. ``"age"``, ``"freight_group"``).
    type_name : str
        Human-friendly type name.  Core types use preferred aliases
        (``"Integer"`` not ``"Number(38,0)"``).  User-defined concept names
        are returned as-is (``"FreightGroup"``).  These names correspond to
        importable types from ``relationalai.semantics`` — e.g. ``Integer``,
        ``String``, ``Float``, ``Date``, ``Decimal``.  Sized decimals like
        ``"Decimal(12,2)"`` correspond to ``Decimal.size(12, 2)``.
    """

    name: str
    type_name: str


@dataclass(frozen=True)
class RelationshipInfo:
    """Read-only view of a :class:`~relationalai.semantics.frontend.base.Relationship`.

    In the DSL, :class:`~relationalai.semantics.frontend.base.Property` is a
    subclass of :class:`~relationalai.semantics.frontend.base.Relationship` —
    a property is a single-valued (functional) relationship.  This dataclass
    represents both: use ``is_property`` to distinguish them.

    The owning concept's field is excluded from ``fields`` — only value and
    key fields are included.

    Attributes
    ----------
    name : str
        Relationship or property name (e.g. ``"age"``, ``"customer"``).
        Empty string for unnamed relationships.
    type_name : str
        Type of the last field — the value type for properties
        (``"Integer"``), or the target concept for relationships
        (``"Order"``).
    fields : tuple[FieldInfo, ...]
        Value/key fields, excluding the owning concept.
    reading : str
        Natural-language description (e.g. ``"Person has Integer:age"``
        or ``"Customer placed Order"``).  Empty string if none declared.
    is_property : bool
        True if this is a single-valued property (DSL ``Property``),
        False if multi-valued (DSL ``Relationship``).
    is_identity : bool
        True if this property is part of the concept's unique key
        (from ``identify_by=``).  Always False for non-properties.
    is_list : bool
        True if the value field accepts a list of values.
    is_input : bool
        True if the value field is a solver input (prescriptive models).
    alt_readings : tuple[str, ...]
        Alternative phrasings from ``.alt()`` declarations.
    """

    name: str
    type_name: str
    fields: tuple[FieldInfo, ...]
    reading: str
    is_property: bool
    is_identity: bool
    is_list: bool
    is_input: bool
    alt_readings: tuple[str, ...] = ()

    def __str__(self) -> str:
        if self.is_property:
            if len(self.fields) <= 1:
                return f"{self.name}: {self.type_name}"
            inner = ", ".join(f.type_name for f in self.fields[:-1])
            return f"{self.name}({inner}) -> {self.type_name}"
        if self.reading:
            return self.reading
        return f"{self.name} -> {self.type_name}"


@dataclass(frozen=True)
class ConceptInfo:
    """Read-only view of a :class:`~relationalai.semantics.frontend.base.Concept`.

    Inherited properties from base concepts are included automatically.
    Use ``all_properties`` to get identity + non-identity properties together.

    Attributes
    ----------
    name : str
        Concept name (e.g. ``"Person"``, ``"Order"``).
    extends : tuple[str, ...]
        Names of base concepts (empty if no bases).
    identify_by : tuple[RelationshipInfo, ...]
        Properties that form the concept's unique key (from ``identify_by=``).
    properties : tuple[RelationshipInfo, ...]
        Non-identity properties (regular attributes).
        Includes inherited properties from base concepts.
    relationships : tuple[RelationshipInfo, ...]
        Multi-valued relationships declared on this concept or inherited from
        base concepts.
    """

    name: str
    extends: tuple[str, ...]
    identify_by: tuple[RelationshipInfo, ...]
    properties: tuple[RelationshipInfo, ...]
    relationships: tuple[RelationshipInfo, ...]
    data_sources: tuple[str, ...] = ()
    """Table names that populate this concept via ``define(Concept.new(table.to_schema()))``.

    Reverse of ``TableInfo.loads``.  Empty for concepts without data.
    """

    @property
    def has_data(self) -> bool:
        """True if this concept is populated from at least one data source."""
        return len(self.data_sources) > 0

    @property
    def all_properties(self) -> tuple[RelationshipInfo, ...]:
        return self.identify_by + self.properties

    def __str__(self) -> str:
        lines = [f"  {self.name}"]
        if self.extends:
            lines[0] += f" (extends {', '.join(self.extends)})"
        if self.identify_by:
            lines.append("    Identity:")
            for p in self.identify_by:
                lines.append(f"      {p}")
                for alt in p.alt_readings:
                    lines.append(f"        alt: {alt}")
        if self.properties:
            lines.append("    Properties:")
            for p in self.properties:
                lines.append(f"      {p}")
                for alt in p.alt_readings:
                    lines.append(f"        alt: {alt}")
        if self.relationships:
            lines.append("    Relationships:")
            for r in self.relationships:
                lines.append(f"      {r}")
                for alt in r.alt_readings:
                    lines.append(f"        alt: {alt}")
        return "\n".join(lines)


@dataclass(frozen=True)
class TableInfo:
    """An external table reference or a temporary table-like object backed by
    in-memory data.

    Attributes
    ----------
    name : str
        Table path (e.g. ``"db.schema.customers"``) or ``"Data"`` for a
        temporary table created by ``model.data()``.
    columns : tuple[FieldInfo, ...]
        Known columns with their types.  Empty tuple if the table was declared
        without a local schema (columns discovered lazily at query time).
    """

    name: str
    columns: tuple[FieldInfo, ...]
    loads: tuple[str, ...] = ()
    """Concept names this table populates via ``define(Concept.new(table.to_schema()))``.

    Derived from ``model.defines`` by finding ``New`` expressions whose
    ``_row_ids`` reference this table.  Empty if no define links this table
    to a concept.
    """

    def __str__(self) -> str:
        suffix = f" -> {', '.join(self.loads)}" if self.loads else ""
        if self.columns:
            cols = ", ".join(f"{c.name}: {c.type_name}" for c in self.columns)
            return f"    {self.name}{suffix} [{cols}]"
        return f"    {self.name}{suffix}"


@dataclass(frozen=True)
class EnumInfo:
    """An enumeration type with its members.

    Attributes
    ----------
    name : str
        Enum type name (e.g. ``"Priority"``).
    values : tuple[str, ...]
        Member names in declaration order (e.g. ``("LOW", "MEDIUM", "HIGH")``).
    """

    name: str
    values: tuple[str, ...]

    def __str__(self) -> str:
        return f"    {self.name}: {', '.join(self.values)}"


@dataclass(frozen=True)
class RuleInfo:
    """A registered ``define()`` or ``require()`` rule.

    Each ``RuleInfo`` corresponds to one rule registered on the model
    via ``model.defines`` or ``model.requires``.  In the DSL, rules are
    the subset of :class:`~relationalai.semantics.frontend.base.Fragment`
    objects that have an effect (define or require clauses).

    Attributes
    ----------
    text : str
        Rendered representation of the full fragment (via the internal
        pretty-printer).
    """

    text: str

    def __str__(self) -> str:
        return self.text


@dataclass(frozen=True)
class ModelSchema:
    """Complete schema of a :class:`~relationalai.semantics.frontend.base.Model`.

    One object, full picture.  Access concepts by name with ``ms["Person"]``
    or ``"Person" in ms``.  Serialize with ``ms.to_dict()`` (JSON-safe) or
    ``str(ms)`` (human-readable summary grouped by section).

    Attributes
    ----------
    name : str
        Model name.
    concepts : tuple[ConceptInfo, ...]
        All non-enum concepts, in model declaration order. Enum concepts
        appear in ``enums`` instead.
    enums : tuple[EnumInfo, ...]
        Enumeration types with their member values, in declaration order.
    tables : tuple[TableInfo, ...]
        External table references and temporary tables created by
        ``model.Table()`` and ``model.data()``, in overall creation order.
    bare_relationships : tuple[RelationshipInfo, ...]
        Relationships (including properties) not owned by any concept.
        These come from ``model.relationships`` and are shown as
        "Standalone Declarations" in ``str()`` output.  Use
        ``is_property`` to distinguish properties from multi-valued
        relationships. Order matches ``model.relationships``.

    Notes
    -----
    Within each :class:`ConceptInfo`, properties and relationships preserve
    effective lookup order: members declared on the concept appear before
    inherited members, and subtype redeclarations shadow inherited same-name
    members.

    ``to_dict()`` uses ``dataclasses.asdict`` which preserves tuples (not
    lists).  ``json.dumps(ms.to_dict())`` works correctly — JSON arrays
    for both.
    """

    name: str
    concepts: tuple[ConceptInfo, ...]
    enums: tuple[EnumInfo, ...]
    tables: tuple[TableInfo, ...]
    bare_relationships: tuple[RelationshipInfo, ...]
    defines: tuple[RuleInfo, ...] = ()
    """All ``define()`` rules registered on the model, in declaration order.

    Mirrors ``model.defines``.  Each :class:`RuleInfo` contains a rendered
    text representation of the fragment.
    """
    requires: tuple[RuleInfo, ...] = ()
    """All ``require()`` rules registered on the model, in declaration order.

    Mirrors ``model.requires``.  Each :class:`RuleInfo` contains a rendered
    text representation of the fragment.
    """

    @property
    def value_types(self) -> tuple[ConceptInfo, ...]:
        """Concepts that extend a base type without adding properties or relationships.

        These are lightweight typed wrappers like ``ContractId(extends String)``
        or ``Price(extends Float)``.  The ``str()`` output groups them under
        "Value Types:" separately from entity concepts.
        """
        return tuple(c for c in self.concepts if c.extends and not c.all_properties and not c.relationships)

    @property
    def bare_properties(self) -> tuple[RelationshipInfo, ...]:
        """Standalone properties (``is_property=True``) not owned by any concept."""
        return tuple(r for r in self.bare_relationships if r.is_property)

    def __getitem__(self, name: str) -> ConceptInfo:
        for c in self.concepts:
            if c.name == name:
                return c
        if any(e.name == name for e in self.enums):
            raise KeyError(f"{name!r} is an enum, not a concept. Access enums via .enums.")
        available = [c.name for c in self.concepts]
        raise KeyError(f"{name!r} not found. Available concepts: {available}")

    def __contains__(self, name: object) -> bool:
        return any(c.name == name for c in self.concepts)

    def get(self, name: str, default: ConceptInfo | None = None) -> ConceptInfo | None:
        """Look up a concept by name, returning *default* if not found."""
        for c in self.concepts:
            if c.name == name:
                return c
        return default

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dictionary representation.

        Returns
        -------
        dict[str, Any]
            Nested dictionary mirroring the dataclass structure.
            Collections remain as tuples; ``json.dumps`` handles them as arrays.
            A ``json.loads`` round-trip converts tuples to lists.
        """
        return dataclasses.asdict(self)

    def __repr__(self) -> str:
        return (
            f"ModelSchema(name={self.name!r}, concepts={len(self.concepts)}, "
            f"enums={len(self.enums)}, tables={len(self.tables)}, "
            f"bare_relationships={len(self.bare_relationships)}, "
            f"defines={len(self.defines)}, requires={len(self.requires)})"
        )

    def __str__(self) -> str:
        lines: list[str] = []
        lines.append(f"Model: {self.name}")
        lines.append("=" * (len(lines[0])))

        # Value types: concepts with extends but no properties or relationships
        value_types = self.value_types
        if value_types:
            lines.append("")
            lines.append("  Value Types:")
            for c in value_types:
                lines.append(f"    {c.name} (extends {', '.join(c.extends)})")

        # Entity types: concepts with properties or relationships (or no extends)
        value_type_names = {c.name for c in value_types}
        entity_types = [c for c in self.concepts if c.name not in value_type_names]
        for c in entity_types:
            lines.append("")
            lines.append(str(c))

        # Data sources
        if self.tables:
            lines.append("")
            lines.append("  Data Sources:")
            for t in self.tables:
                lines.append(str(t))

        # Standalone declarations
        bare = list(self.bare_relationships)
        if bare:
            lines.append("")
            lines.append("  Standalone Declarations:")
            for item in bare:
                if item.reading:
                    lines.append(f"    {item.reading}")
                else:
                    lines.append(f"    {item}")
                for alt in item.alt_readings:
                    lines.append(f"      alt: {alt}")

        # Enums
        if self.enums:
            lines.append("")
            lines.append("  Enums:")
            for e in self.enums:
                lines.append(str(e))

        # Rules
        if self.defines:
            lines.append("")
            lines.append(f"  Defines: ({len(self.defines)} rules)")
            for r in self.defines:
                # Show first line of pprint, indented
                first_line = r.text.split("\n")[0]
                lines.append(f"    {first_line}")

        if self.requires:
            lines.append("")
            lines.append(f"  Requires: ({len(self.requires)} rules)")
            for r in self.requires:
                first_line = r.text.split("\n")[0]
                lines.append(f"    {first_line}")

        return "\n".join(lines)


# ── Property collection with inheritance ────────────────────────────────────


def _make_field_info(field: Field) -> FieldInfo:
    return FieldInfo(name=field.name, type_name=_friendly_type_name(field.type))


def _make_relationship_info(
    rel: Relationship,
    *,
    is_identity: bool = False,
    owner_concept: Concept | None = None,
) -> RelationshipInfo:
    """Build a RelationshipInfo from a DSL Relationship or Property."""
    # Exclude the owning concept field.  Callers (_collect_properties,
    # _collect_relationships) always pass the declaring concept, so an
    # exact _id match is correct here.
    if owner_concept is not None and rel._fields and rel._fields[0].type._id == owner_concept._id:
        fields = tuple(_make_field_info(f) for f in rel._fields[1:])
    else:
        fields = tuple(_make_field_info(f) for f in rel._fields)

    type_name = _friendly_type_name(rel._fields[-1].type) if rel._fields else "Any"

    reading = ""
    alt_readings: tuple[str, ...] = ()
    if rel._readings:
        reading = _structured_reading(rel._readings[0])
        if len(rel._readings) > 1:
            alt_readings = tuple(_structured_reading(r) for r in rel._readings[1:])

    return RelationshipInfo(
        name=rel._short_name,
        type_name=type_name,
        fields=fields,
        reading=reading,
        is_property=isinstance(rel, Property),
        is_identity=is_identity,
        is_list=rel._fields[-1].is_list if rel._fields else False,
        is_input=rel._fields[-1].is_input if rel._fields else False,
        alt_readings=alt_readings,
    )


def _replace_relationship_type(info: RelationshipInfo, type_name: str) -> RelationshipInfo:
    """Return *info* with an updated output type, preserving other metadata."""
    if info.type_name == type_name:
        return info
    fields = info.fields
    if fields:
        fields = (*fields[:-1], dataclasses.replace(fields[-1], type_name=type_name))
    return dataclasses.replace(info, type_name=type_name, fields=fields)


def _infer_schema_value_type(
    name: str,
    value: Any,
    row_source_ids: set[int],
) -> Concept | None:
    """Return the table-column type for an auto-populated ``New`` kwarg.

    ``Concept.new(table.to_schema())`` expands each included table column into a
    kwarg shaped like ``COLUMN=table.COLUMN``. On ``main`` those implicit
    properties remain typed as ``Any`` in the frontend model; inspect infers the
    richer table-backed type here without mutating core semantics.
    """
    if not isinstance(value, Expression):
        return None
    op = getattr(value, "_op", None)
    if not isinstance(op, Property) or not op._short_name or op._short_name.lower() != name.lower():
        return None
    args = getattr(value, "_args", ())
    if not args or getattr(args[0], "_id", None) not in row_source_ids or not op._fields:
        return None
    return op._fields[-1].type


def _apply_inferred_property_types(
    concept: ConceptInfo,
    inferred_types: dict[str, Concept],
) -> ConceptInfo:
    """Patch inspect-only property types recovered from table-backed loads."""
    if not inferred_types:
        return concept

    def patch(props: tuple[RelationshipInfo, ...]) -> tuple[RelationshipInfo, ...]:
        patched: list[RelationshipInfo] = []
        changed = False
        for prop in props:
            inferred = inferred_types.get(prop.name.lower())
            if inferred is not None and prop.type_name in {"Any", "AnyEntity"}:
                patched.append(_replace_relationship_type(prop, _friendly_type_name(inferred)))
                changed = True
            else:
                patched.append(prop)
        return tuple(patched) if changed else props

    identify_by = patch(concept.identify_by)
    properties = patch(concept.properties)
    if identify_by is concept.identify_by and properties is concept.properties:
        return concept
    return dataclasses.replace(concept, identify_by=identify_by, properties=properties)


def _collect_properties(
    concept: Concept,
) -> tuple[list[RelationshipInfo], list[RelationshipInfo]]:
    """Collect identity and non-identity properties including inherited ones.

    Returns (identity_props, data_props).
    """
    identity: list[RelationshipInfo] = []
    data: list[RelationshipInfo] = []
    seen_ids: set[int] = set()
    # Short names declared on subtypes; inherited same-name members are shadowed
    # to match DSL lookup order.
    seen_names: set[str] = set()
    visited: set[int] = set()

    def _collect(c: Concept) -> None:
        if c._id in visited:
            return
        visited.add(c._id)

        # Items declared at this level should not be blocked by their own names.
        blocked = frozenset(seen_names)

        # Identity properties from _identify_by.  A Reading (alt reading)
        # may appear in _identify_by — resolve to the underlying Property.
        identity_rel_ids: set[int] = set()
        for rel in c._identify_by:
            actual = getattr(rel, "_relationship", rel) if isinstance(rel, Reading) else rel
            identity_rel_ids.add(actual._id)
            if actual._id in seen_ids or not isinstance(actual, Property):
                continue
            name_key = (actual._short_name or "").lower()
            if name_key and name_key in blocked:
                continue
            seen_ids.add(actual._id)
            identity.append(_make_relationship_info(actual, is_identity=True, owner_concept=c))

        # Data properties: _relationships minus identity, filtered to Property
        for _, rel in c._relationships.items():
            if rel._id in seen_ids or rel._id in identity_rel_ids or not isinstance(rel, Property):
                continue
            name_key = (rel._short_name or "").lower()
            if name_key and name_key in blocked:
                continue
            seen_ids.add(rel._id)
            data.append(_make_relationship_info(rel, is_identity=False, owner_concept=c))

        # Record all declared names so inherited same-name members are shadowed
        # regardless of kind.
        for _, rel in c._relationships.items():
            if rel._short_name:
                seen_names.add(rel._short_name.lower())
        for rel in c._identify_by:
            actual = getattr(rel, "_relationship", rel) if isinstance(rel, Reading) else rel
            if actual._short_name:
                seen_names.add(actual._short_name.lower())

        # Walk inheritance chain
        for base in c._extends:
            _collect(base)

    _collect(concept)
    return identity, data


def _collect_relationships(
    concept: Concept,
    seen_ids: set[int],
    visited: set[int] | None = None,
    seen_names: set[str] | None = None,
) -> list[RelationshipInfo]:
    """Collect multi-valued relationships (non-Property) from a concept.

    ``seen_names`` tracks names declared on subtypes so inherited same-name
    relationships are shadowed, matching DSL lookup semantics. Property names
    also contribute so cross-kind shadowing works.
    """
    if visited is None:
        visited = set()
    if seen_names is None:
        seen_names = set()
    if concept._id in visited:
        return []
    visited.add(concept._id)

    # Items declared here should not be blocked by their own names.
    blocked = frozenset(seen_names)

    rels: list[RelationshipInfo] = []
    for _, rel in concept._relationships.items():
        if rel._id in seen_ids or isinstance(rel, Property) or isinstance(rel, Reading):
            continue
        name_key = (rel._short_name or "").lower()
        if name_key and name_key in blocked:
            continue
        seen_ids.add(rel._id)
        rels.append(_make_relationship_info(rel, owner_concept=concept))

    # Record all declared names so inherited same-name members are shadowed
    # regardless of kind.
    for _, rel in concept._relationships.items():
        if rel._short_name:
            seen_names.add(rel._short_name.lower())
    for rel in concept._identify_by:
        actual = getattr(rel, "_relationship", rel) if isinstance(rel, Reading) else rel
        if actual._short_name:
            seen_names.add(actual._short_name.lower())

    # Also check inherited
    for base in concept._extends:
        rels.extend(_collect_relationships(base, seen_ids, visited, seen_names))
    return rels


# ── Rule rendering ──────────────────────────────────────────────────────────


def _make_rule_info(fragment: Fragment) -> RuleInfo:
    """Build a RuleInfo from a registered Fragment."""
    return RuleInfo(text=_pprint_format(fragment))


def _iter_nested_news(root: Any) -> Iterator[New]:
    """Yield ``New`` nodes reachable through expression-bearing child slots.

    This walks the frontend DSL tree without traversing operator/model metadata
    such as ``_op`` or ``_next``. That keeps the search focused on user-written
    expressions while still finding nested ``New(...)`` inside wrappers like
    equality expressions, aliases, tuple-valued expressions, and aggregates.
    """
    stack: list[Any] = [root]
    visited: set[int] = set()
    while stack:
        node = stack.pop()
        node_id = id(node)
        if node_id in visited:
            continue
        visited.add(node_id)

        if isinstance(node, New):
            yield node

        if isinstance(node, Fragment):
            stack.extend(node._define)
            stack.extend(node._where)
            stack.extend(node._select)
            stack.extend(node._require)
            continue

        if isinstance(node, Expression):
            stack.extend(node._args)
            stack.extend(node._kwargs.values())

        if isinstance(node, Chain):
            stack.append(node._start)

        if isinstance(node, FieldRef):
            stack.append(node._root)

        source_item = getattr(node, "_source_item", None)
        if source_item is not None:
            stack.append(source_item)

        items = getattr(node, "_items", None)
        if items is not None:
            stack.extend(items)

        projection_args = getattr(node, "_projection_args", None)
        if projection_args is not None:
            stack.extend(projection_args)

        group = getattr(node, "_group", None)
        if group is not None:
            stack.append(group)

        where = getattr(node, "_where", None)
        if isinstance(where, Fragment):
            stack.append(where)


# ── Main entry point ────────────────────────────────────────────────────────


def schema(model: Model) -> ModelSchema:
    """Return the complete schema of *model* as frozen dataclasses.

    One call gives you every concept, property, relationship, table, and enum
    in the model — including inherited properties and relationships. No
    engine connection needed.

    Output order is deterministic: top-level model collections follow
    declaration order, while per-concept members follow effective lookup
    order after inheritance and shadowing.

    Parameters
    ----------
    model : Model
        The PyRel model to inspect.

    Returns
    -------
    ModelSchema
        A frozen, structured description of the entire model schema.

    Examples
    --------
    >>> from relationalai.semantics import Model, Integer, String, inspect
    >>> m = Model("example")
    >>> Person = m.Concept("Person", identify_by={"id": Integer})
    >>> Person.name = m.Property(f"{Person} has {String:name}")
    >>> ms = inspect.schema(m)
    >>> ms["Person"].identify_by[0].type_name
    'Integer'
    >>> ms["Person"].properties[0].name
    'name'
    """
    if not isinstance(model, Model):
        raise TypeError(f"schema() expects a Model, got {type(model).__name__}. Usage: inspect.schema(model)")
    # 1. Build set of relationship IDs owned by concepts
    owned_rel_ids: set[int] = set()
    for concept in model.concepts:
        for rel in concept._identify_by:
            owned_rel_ids.add(rel._id)
        for _, rel in concept._relationships.items():
            owned_rel_ids.add(rel._id)

    # 2. Collect tables and temporary tables created from in-memory data
    tables: list[TableInfo] = []
    all_tables = sorted([*model.tables, *model.data_items], key=lambda t: t._id)
    for table in all_tables:
        cols: list[FieldInfo] = []
        for _, rel in table._relationships.items():
            if rel._short_name:
                col_type = _friendly_type_name(rel._fields[-1].type) if rel._fields else "Any"
                cols.append(FieldInfo(name=rel._short_name, type_name=col_type))
            owned_rel_ids.add(rel._id)
        tables.append(TableInfo(name=table._name, columns=tuple(cols)))

    # 3. Identify enum concept IDs
    enum_concept_ids: set[int] = set()
    for enum_cls in model.enums:
        enum_concept_ids.add(enum_cls._concept._id)

    # 4. Build concept infos (skip enum concepts)
    concepts: list[ConceptInfo] = []
    for concept in model.concepts:
        if concept._id in enum_concept_ids:
            continue

        identity_props, data_props = _collect_properties(concept)

        # Collect relationship IDs we've already seen as properties
        prop_ids = {r._id for r in concept._identify_by}
        for _, rel in concept._relationships.items():
            if isinstance(rel, Property):
                prop_ids.add(rel._id)

        rels = _collect_relationships(concept, prop_ids)

        extends = tuple(_friendly_type_name(base) for base in concept._extends)

        concepts.append(
            ConceptInfo(
                name=concept._name,
                extends=extends,
                identify_by=tuple(identity_props),
                properties=tuple(data_props),
                relationships=tuple(rels),
            )
        )

    # 5. Bare relationships (not owned by any concept)
    bare_relationships: list[RelationshipInfo] = []
    for rel in model.relationships:
        if rel._id in owned_rel_ids:
            continue
        if isinstance(rel, Reading):
            continue
        bare_relationships.append(_make_relationship_info(rel))

    # 6. Enums
    enums: list[EnumInfo] = []
    for enum_cls in model.enums:
        values = tuple(member.name for member in enum_cls)
        enums.append(EnumInfo(name=enum_cls.__name__, values=values))

    # 7. Rules (defines and requires) + data source mapping
    # Walk every New in each define fragment — including News nested inside
    # _args/_kwargs — so constructs like
    #   Order.new(customer=Customer.new(source.to_schema()))
    # attribute the table to the inner Customer concept as well.
    table_to_concepts: dict[int, list[str]] = {}
    concept_to_source_ids: dict[str, list[int]] = {}
    concept_to_inferred_types: dict[str, dict[str, Concept]] = {}
    source_name_by_id = {source._id: str(source._name) for source in all_tables}
    defines_list: list[RuleInfo] = []
    for frag in model.defines:
        defines_list.append(_make_rule_info(frag))
        for item in frag._define:
            for node in _iter_nested_news(item):
                if node._row_ids:
                    cname = str(node._op._name)
                    row_source_ids = {source._id for source in node._row_ids}
                    for source in node._row_ids:
                        table_to_concepts.setdefault(source._id, []).append(cname)
                        concept_to_source_ids.setdefault(cname, []).append(source._id)
                    for name, value in node._kwargs.items():
                        inferred = _infer_schema_value_type(name, value, row_source_ids)
                        if inferred is not None:
                            concept_to_inferred_types.setdefault(cname, {}).setdefault(name.lower(), inferred)
    requires = tuple(_make_rule_info(f) for f in model.requires)

    # Apply table-to-concept mapping
    for i, dsl_table in enumerate(all_tables):
        loads = tuple(dict.fromkeys(table_to_concepts.get(dsl_table._id, [])))
        if loads:
            tables[i] = dataclasses.replace(tables[i], loads=loads)

    # Apply concept-to-table mapping
    patched_concepts: list[ConceptInfo] = []
    for ci in concepts:
        source_ids = tuple(dict.fromkeys(concept_to_source_ids.get(ci.name, [])))
        sources = tuple(source_name_by_id[source_id] for source_id in source_ids)
        patched = dataclasses.replace(ci, data_sources=sources) if sources else ci
        patched = _apply_inferred_property_types(patched, concept_to_inferred_types.get(ci.name, {}))
        patched_concepts.append(patched)

    return ModelSchema(
        name=model.name,
        concepts=tuple(patched_concepts),
        enums=tuple(enums),
        tables=tuple(tables),
        bare_relationships=tuple(bare_relationships),
        defines=tuple(defines_list),
        requires=requires,
    )


# ── DSL object utilities ───────────────────────────────────────────────────

_MISSING = object()
_T = TypeVar("_T")


@overload
def to_concept(obj: Variable) -> Concept: ...
@overload
def to_concept(obj: Variable, default: _T) -> Concept | _T: ...


def to_concept(obj: Variable, default: object = _MISSING) -> Concept | Any:
    """Return the :class:`Concept` that *obj* resolves to.

    Works on any DSL :class:`Variable` — :class:`Concept`, :class:`Chain`,
    :class:`Expression`, :class:`Ref`, :class:`FieldRef`, etc.

    Parameters
    ----------
    obj : Variable
        Any DSL variable or expression.
    default
        Value to return if the concept cannot be determined.  If omitted,
        a :class:`TypeError` is raised instead.

    Returns
    -------
    Concept
        The resolved concept, or *default* if the concept cannot be
        determined and a default was provided.

    Raises
    ------
    TypeError
        If the concept cannot be determined and no *default* was given.

    Examples
    --------
    >>> from relationalai.semantics import Model, String, inspect
    >>> m = Model("example")
    >>> Person = m.Concept("Person")
    >>> Person.name = m.Property(f"{Person} has {String:name}")
    >>> inspect.to_concept(Person) is Person
    True
    >>> inspect.to_concept(Person.name, default=None)  # returns Concept or None
    """
    if not isinstance(obj, Variable):
        raise TypeError(f"to_concept() expects a Variable, got {type(obj).__name__}")
    result = obj._to_concept()
    if result is not None:
        return result
    if default is not _MISSING:
        return default  # type: ignore[return-value]
    raise TypeError(
        f"Cannot determine concept for {type(obj).__name__}. Pass default=None to return None instead of raising."
    )


def fields(
    rel: Relationship | Chain,
    *,
    include_owner: bool = False,
) -> tuple[FieldRef, ...]:
    """Return selectable :class:`FieldRef` objects for *rel*'s fields.

    This bridges introspection and live DSL usage: the returned
    ``FieldRef`` objects can be passed directly to :func:`select`.

    By default the owner concept's field is excluded — specifically, the
    first field, when its type matches the owning concept.  For chain
    access (``Person.name``), the owner is the chain's root.  For a direct
    :class:`Relationship` or :class:`Reading` handle, the owner is inferred
    from the model: if exactly one concept in ``model.concepts`` owns the
    relationship (via ``_relationships`` or ``_identify_by``), that concept
    is the owner.  If ownership is ambiguous (the same relationship is
    attached to multiple concepts) or standalone (bare relationship), all
    fields are returned.  Pass ``include_owner=True`` to always return all
    fields.

    Parameters
    ----------
    rel : Relationship | Chain
        A relationship or chain to inspect.
    include_owner : bool
        If True, include the owner concept's field in the result.

    Returns
    -------
    tuple[FieldRef, ...]
        Field references, usable in :func:`select`.

    Examples
    --------
    >>> from relationalai.semantics import Model, String, Any, inspect
    >>> m = Model("example")
    >>> Item = m.Concept("Item")
    >>> Item.successors = m.Relationship(
    ...     f"{Item:i} has successor {Item:s} with {Any:data}"
    ... )
    >>> refs = inspect.fields(Item.successors)
    >>> len(refs)  # excludes the owner 'i' field
    2
    """
    # Resolve the underlying Relationship and the accessor object.
    if isinstance(rel, Chain):
        relationship = rel._next
        # Normalize alt readings to the parent Relationship for consistent
        # field ordering, matching _make_relationship_info().
        if isinstance(relationship, Reading):
            relationship = relationship._relationship
        accessor = rel
        owner_concept = rel._start._to_concept()
    elif isinstance(rel, Relationship):
        relationship = rel._relationship if isinstance(rel, Reading) else rel
        accessor = rel
        # For direct Relationship/Reading inputs, infer the owning concept
        # from the model so owned properties behave like chain access.
        # Ambiguous or standalone relationships get no owner (all fields kept).
        owner_concept = _infer_owner_concept(relationship)
    else:
        raise TypeError(f"fields() expects a Relationship or Chain, got {type(rel).__name__}")

    all_fields = relationship._fields
    # Skip the owner field: the first field whose type is the chain's root
    # concept or one of its ancestors.  The subtype check handles inherited
    # properties — e.g. fields(Adult.name) where name is declared on Person.
    if (
        not include_owner
        and owner_concept is not None
        and all_fields
        and _is_subtype(owner_concept, all_fields[0].type)
    ):
        all_fields = all_fields[1:]

    return tuple(accessor[f.name] for f in all_fields)
