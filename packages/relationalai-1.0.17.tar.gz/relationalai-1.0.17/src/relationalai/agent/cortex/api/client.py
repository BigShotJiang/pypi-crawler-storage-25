import httpx
from snowflake.connector import SnowflakeConnection

from relationalai.util.docutils import include_in_docs
from relationalai.util.error import exc


@include_in_docs
def http_client(
    conn: SnowflakeConnection,
    timeout: int = 300,
    host: str | None = None,
) -> httpx.Client:
    """Create an authenticated HTTP client for Snowflake Cortex API requests.

    Parameters
    ----------
    conn : SnowflakeConnection
        An active Snowflake connection used to extract the session token.
    timeout : int
        Request timeout in seconds. Default: 300.
    host : str, optional
        Override for the base URL host. Accepts a bare hostname
        (e.g. ``amd01.east-us-2.azure.snowflakecomputing.com``) or a full
        URL with scheme. When omitted, ``conn.host`` is used if it is a
        regional Snowflake hostname; otherwise the URL is built from
        ``CURRENT_ACCOUNT()`` so it matches Snowflake's default REST TLS
        certificate.

    Returns
    -------
    httpx.Client
        A configured HTTP client with authentication headers and the
        correct Snowflake base URL.

    Examples
    --------

    >>> from relationalai.config import Config
    >>> conn = create_config().get_session().connection
    >>> client = http_client(conn)
    """
    base_url = _hostname(conn, host)

    if conn._rest is None:
        exc("SnowflakeConnection", "Connection has no REST client (_rest is None).")
    token_data = conn._rest._token_request('ISSUE')
    if token_data is None:
        exc("SnowflakeConnection", "Token request returned None.")
    token_extract = token_data['data']['sessionToken']
    token = f'\"{token_extract}\"'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f"Snowflake Token={token}"
    }
    return httpx.Client(
        headers=headers,
        timeout=timeout,
        base_url=base_url
    )


def _hostname(conn: SnowflakeConnection, override: str | None = None) -> str:
    if override:
        return _with_scheme(override)

    # Prefer conn.host when it's a regional Snowflake hostname — required
    # on Azure/GCP and non-default AWS regions where the account-locator
    # URL won't resolve. Reject org-qualified forms because Snowflake's
    # REST TLS cert doesn't cover them.
    host = getattr(conn, "host", None)
    if host and _is_regional_snowflake_host(host):
        return _with_scheme(host)

    # Fallback: build the classic account-locator URL. Works for AWS
    # deployments whose connections were configured with the
    # org-qualified name.
    cursor = conn.cursor()
    if cursor is None:
        exc("SnowflakeConnection", "Could not get cursor from connection.")
    result = cursor.execute("select CURRENT_ACCOUNT()")
    if result is None:
        exc("SnowflakeConnection", "CURRENT_ACCOUNT() query returned None.")
    row = result.fetchone()
    if not row or len(row) != 1:
        exc("SnowflakeConnection", "Could not select CURRENT_ACCOUNT().")
    return f"https://{row[0]}.snowflakecomputing.com"


def _is_regional_snowflake_host(host: str) -> bool:
    # Regional locator hosts carry a cloud segment (`.aws.`/`.azure.`/`.gcp.`).
    # PrivateLink hosts replace that segment with `.privatelink.`. Both must
    # be used verbatim — the generic `{locator}.snowflakecomputing.com` form
    # won't route PrivateLink traffic and doesn't work for non-default regions.
    if not host.endswith(".snowflakecomputing.com"):
        return False
    markers = ("aws", "azure", "gcp", "privatelink")
    return any(f".{marker}." in host for marker in markers)


def _with_scheme(host: str) -> str:
    if host.startswith("http://") or host.startswith("https://"):
        return host
    return f"https://{host}"
