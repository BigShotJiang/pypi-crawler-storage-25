from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from relationalai.client.transports.http import AsyncHttpClient, HttpClient
from relationalai.services._shared.artifact_info import coerce_da_artifact_results, uppercase_keys
from relationalai.services._shared.da_headers import mk_da_headers
from relationalai.services._shared.da_request import BaseUrlProvider

from .constants import JOB_ACTIVE_STATES, TRANSACTIONS_DA_BASE_PATH
from .da_http import request_json_async, request_json_sync
from .errors import JobInvalidRequestError, JobServerError
from .models import JobEvents, JobRecord, job_events_from_value, logic_txn_job_from_row

if TYPE_CHECKING:
    from relationalai.config.config import Config

_TXN_ID_KEYS: tuple[str, ...] = ("id", "txn_id", "ID", "TXN_ID")
_TXN_WRAPPER_KEYS: tuple[str, ...] = ("transaction", "txn", "job", "data", "result", "value", "payload")


def _txn_query_params(cfg: "Config", *, payload: dict[str, Any]) -> dict[str, Any]:
    _ = cfg, payload
    return {"use_graph_index": "false"}


def _txn_create_body(*, reasoner_name: str, payload: dict[str, Any], timeout_mins: int | None) -> dict[str, Any]:
    body = dict(payload)
    body["engine_name"] = reasoner_name
    body["abort_detached"] = bool(payload.get("abort_detached") or False)
    if timeout_mins is not None and "timeout_mins" not in body:
        body["timeout_mins"] = int(timeout_mins)
    return body


def _as_str(v: Any) -> str:
    if isinstance(v, str):
        return v.strip()
    if v is None:
        return ""
    try:
        return str(v).strip()
    except Exception:
        return ""


def _unwrap_txn_payload(out: Any) -> Any:
    if not isinstance(out, dict):
        return out
    for key in _TXN_WRAPPER_KEYS:
        val = out.get(key)
        if isinstance(val, dict) and val:
            return val
    return out


def _extract_txn_id(out: Any) -> str:
    if isinstance(out, str):
        return out.strip()
    if isinstance(out, dict):
        for key in _TXN_ID_KEYS:
            value = _as_str(out.get(key))
            if value:
                return value
        inner = _unwrap_txn_payload(out)
        if isinstance(inner, dict) and inner is not out:
            for key in _TXN_ID_KEYS:
                value = _as_str(inner.get(key))
                if value:
                    return value
        for key in _TXN_WRAPPER_KEYS:
            raw_value = out.get(key)
            if isinstance(raw_value, (dict, list, tuple, set)):
                continue
            value = _as_str(raw_value)
            if value:
                return value
    return ""


def _require_txn_id(out: Any) -> str:
    txn_id = _extract_txn_id(out)
    if not txn_id:
        if isinstance(out, dict):
            msg = _as_str(out.get("message") or out.get("error"))
            if msg:
                raise RuntimeError(f"Transaction creation failed (no id in response). {msg}")
        raise RuntimeError(f"Transaction creation did not return an ID. response={out!r}")
    return txn_id


def _txn_events_query_params(continuation_token: str) -> dict[str, Any]:
    token = "" if str(continuation_token) == "0" else str(continuation_token or "")
    return {"continuation_token": token}


def _txn_headers(cfg: "Config", *, gi_setup_skipped: bool) -> dict[str, str]:
    return mk_da_headers(cfg, gi_setup_skipped=gi_setup_skipped)


def _txn_job_record(out: Any) -> JobRecord | None:
    payload = _unwrap_txn_payload(out)
    if not isinstance(payload, dict) or not payload:
        return None
    return logic_txn_job_from_row(payload)


def _txn_events(out: Any, *, txn_id: str, continuation_token: str, stream_name: str) -> JobEvents:
    _ = txn_id, continuation_token, stream_name
    return job_events_from_value(out)


def _txn_artifacts(out: Any) -> dict[str, dict[str, Any]]:
    out2 = uppercase_keys(out) if isinstance(out, dict) else {}
    return coerce_da_artifact_results(out2)


def _txn_problems(out: Any) -> dict[str, Any]:
    return out if isinstance(out, dict) else {}


def _txn_default_headers(headers: dict[str, str] | None) -> dict[str, str]:
    return headers or {"Content-Type": "application/json"}


def _txn_create_request_kwargs(
    cfg: "Config",
    *,
    reasoner_name: str,
    payload: dict[str, Any],
    timeout_mins: int | None,
) -> dict[str, Any]:
    return {
        "operation": "create",
        "method": "POST",
        "endpoint": TRANSACTIONS_DA_BASE_PATH,
        "query_params": _txn_query_params(cfg, payload=payload),
        "json_body": _txn_create_body(reasoner_name=reasoner_name, payload=payload, timeout_mins=timeout_mins),
        "headers": _txn_headers(cfg, gi_setup_skipped=bool(payload.get("gi_setup_skipped") or False)),
    }


def _txn_get_request_kwargs(cfg: "Config", txn_id: str) -> dict[str, Any]:
    return {
        "operation": "get",
        "method": "GET",
        "endpoint": f"{TRANSACTIONS_DA_BASE_PATH}/{{txn_id}}",
        "path_params": {"txn_id": txn_id},
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
        "allow_404": True,
    }


def _txn_events_request_kwargs(cfg: "Config", txn_id: str, continuation_token: str, stream_name: str) -> dict[str, Any]:
    return {
        "operation": "events",
        "method": "GET",
        "endpoint": f"{TRANSACTIONS_DA_BASE_PATH}/{{txn_id}}/events/{{stream_name}}",
        "path_params": {"txn_id": txn_id, "stream_name": stream_name},
        "query_params": _txn_events_query_params(continuation_token),
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
    }


def _txn_artifacts_request_kwargs(cfg: "Config", txn_id: str) -> dict[str, Any]:
    return {
        "operation": "artifacts",
        "method": "GET",
        "endpoint": f"{TRANSACTIONS_DA_BASE_PATH}/{{txn_id}}/artifacts",
        "path_params": {"txn_id": txn_id},
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
    }


def _txn_problems_request_kwargs(cfg: "Config", txn_id: str) -> dict[str, Any]:
    return {
        "operation": "problems",
        "method": "GET",
        "endpoint": f"{TRANSACTIONS_DA_BASE_PATH}/{{txn_id}}/problems",
        "path_params": {"txn_id": txn_id},
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
    }


def _txn_cancel_async_request_kwargs(cfg: "Config", txn_id: str) -> dict[str, Any]:
    return {
        "operation": "cancel",
        "method": "POST",
        "endpoint": f"{TRANSACTIONS_DA_BASE_PATH}/{{txn_id}}/cancel_async",
        "path_params": {"txn_id": txn_id},
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
    }


def _txn_list_request_kwargs(cfg: "Config") -> dict[str, Any]:
    return {
        "operation": "list",
        "method": "GET",
        "endpoint": TRANSACTIONS_DA_BASE_PATH,
        "headers": _txn_headers(cfg, gi_setup_skipped=False),
    }


def _txn_extract_transaction_dicts(out: Any) -> list[dict[str, Any]]:
    if isinstance(out, list):
        return [x for x in out if isinstance(x, dict)]
    if not isinstance(out, dict):
        return []
    for key in ("transactions", "Transactions", "txns", "items", "data"):
        val = out.get(key)
        if isinstance(val, list):
            return [x for x in val if isinstance(x, dict)]
    return []


def _txn_filter_list_records(
    records: list[JobRecord],
    *,
    state: str | None,
    name: str | None,
    created_by: str | None,
    only_active: bool,
    all_users: bool,
    limit: int | None,
    offset: int | None,
) -> list[JobRecord]:
    desired_state = state.upper() if isinstance(state, str) and state else None
    desired_rn = str(name).lower() if name is not None else None
    desired_cb = str(created_by).lower() if created_by is not None else None

    out: list[JobRecord] = []
    for rec in records:
        st = str(rec.state or "").upper()
        if desired_state is not None and st != desired_state:
            continue
        if desired_state is None and only_active and st not in JOB_ACTIVE_STATES:
            continue

        if desired_rn is not None:
            rn = rec.reasoner_name or ""
            if str(rn).lower() != desired_rn:
                continue

        if not all_users and desired_cb is not None:
            cb = rec.created_by or ""
            if str(cb).lower() != desired_cb:
                continue

        out.append(rec)

    offset_int = int(offset or 0)
    if offset_int < 0:
        raise JobInvalidRequestError("Job `offset` must be >= 0.")
    if offset_int:
        out = out[offset_int:]
    if limit is not None and int(limit) > 0:
        return out[: int(limit)]
    return out


def _txn_list_matches_single_job(
    job: JobRecord | None,
    *,
    state: str | None,
    name: str | None,
    created_by: str | None,
    only_active: bool,
    all_users: bool,
) -> list[JobRecord]:
    if job is None:
        return []
    desired_state = state.upper() if isinstance(state, str) and state else None
    job_state = str(job.state or "").upper()
    if desired_state is not None and job_state != desired_state:
        return []
    if desired_state is None and only_active and job_state not in JOB_ACTIVE_STATES:
        return []
    if name is not None and str(getattr(job, "reasoner_name", "") or "").lower() != str(name).lower():
        return []
    if not all_users and created_by is not None and str(getattr(job, "created_by", "") or "").lower() != str(created_by).lower():
        return []
    return [job]


def _txn_list_from_bulk_response(
    out: Any,
    *,
    state: str | None,
    name: str | None,
    created_by: str | None,
    only_active: bool,
    all_users: bool,
    limit: int | None,
    offset: int | None,
) -> list[JobRecord]:
    raw = _txn_extract_transaction_dicts(out)
    records = [logic_txn_job_from_row(x) for x in raw]
    return _txn_filter_list_records(
        records,
        state=state,
        name=name,
        created_by=created_by,
        only_active=only_active,
        all_users=all_users,
        limit=limit,
        offset=offset,
    )


@dataclass
class TxnHttpGateway:
    """Transactions gateway backed by Direct Access HTTP endpoints (sync)."""

    config: "Config"
    base_url_provider: BaseUrlProvider
    http: HttpClient

    def _request(
        self,
        *,
        operation: str,
        method: str,
        endpoint: str,
        path_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        allow_404: bool = False,
    ) -> Any:
        _status, content = request_json_sync(
            http=self.http,
            operation=operation,
            method=method,
            base_url_provider=self.base_url_provider,
            endpoint=endpoint,
            path_params=path_params,
            query_params=query_params,
            payload=json_body,
            headers=_txn_default_headers(headers),
            allow_404=allow_404,
            invalid_exc=JobInvalidRequestError,
            server_exc=JobServerError,
            prefix="Transactions",
        )
        return content

    def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        out = self._request(**_txn_create_request_kwargs(self.config, reasoner_name=reasoner_name, payload=payload, timeout_mins=timeout_mins))
        return _require_txn_id(out)

    def get(self, id: str) -> JobRecord | None:
        out = self._request(**_txn_get_request_kwargs(self.config, id))
        return _txn_job_record(out)

    def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[JobRecord]:
        if limit is not None and int(limit) <= 0:
            return []

        if job_id:
            return _txn_filter_list_records(
                _txn_list_matches_single_job(
                    self.get(job_id),
                    state=state,
                    name=name,
                    created_by=created_by,
                    only_active=only_active,
                    all_users=all_users,
                ),
                state=None,
                name=None,
                created_by=None,
                only_active=False,
                all_users=True,
                limit=limit,
                offset=offset,
            )

        out = self._request(**_txn_list_request_kwargs(self.config))
        return _txn_list_from_bulk_response(
            out,
            state=state,
            name=name,
            created_by=created_by,
            only_active=only_active,
            all_users=all_users,
            limit=limit,
            offset=offset,
        )

    def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents:
        out = self._request(**_txn_events_request_kwargs(self.config, id, continuation_token, stream_name))
        return _txn_events(out, txn_id=id, continuation_token=continuation_token, stream_name=stream_name)

    def artifacts(self, id: str) -> dict[str, dict[str, Any]]:
        out = self._request(**_txn_artifacts_request_kwargs(self.config, id))
        return _txn_artifacts(out)

    def problems(self, id: str) -> dict[str, Any]:
        out = self._request(**_txn_problems_request_kwargs(self.config, id))
        return _txn_problems(out)

    def cancel(self, id: str, *, all_users: bool = False) -> None:
        if all_users:
            raise JobInvalidRequestError("Transactions Direct Access cancel does not support all_users=True.")
        self._request(**_txn_cancel_async_request_kwargs(self.config, id))


@dataclass
class TxnHttpGatewayAsync:
    """Transactions gateway backed by Direct Access HTTP endpoints (async)."""

    config: "Config"
    base_url_provider: BaseUrlProvider
    http: AsyncHttpClient

    async def _request(
        self,
        *,
        operation: str,
        method: str,
        endpoint: str,
        path_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        allow_404: bool = False,
    ) -> Any:
        _status, content = await request_json_async(
            http=self.http,
            operation=operation,
            method=method,
            base_url_provider=self.base_url_provider,
            endpoint=endpoint,
            path_params=path_params,
            query_params=query_params,
            payload=json_body,
            headers=_txn_default_headers(headers),
            allow_404=allow_404,
            invalid_exc=JobInvalidRequestError,
            server_exc=JobServerError,
            prefix="Transactions",
        )
        return content

    async def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        out = await self._request(
            **_txn_create_request_kwargs(self.config, reasoner_name=reasoner_name, payload=payload, timeout_mins=timeout_mins)
        )
        return _require_txn_id(out)

    async def get(self, id: str) -> JobRecord | None:
        out = await self._request(**_txn_get_request_kwargs(self.config, id))
        return _txn_job_record(out)

    async def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[JobRecord]:
        if limit is not None and int(limit) <= 0:
            return []

        if job_id:
            return _txn_filter_list_records(
                _txn_list_matches_single_job(
                    await self.get(job_id),
                    state=state,
                    name=name,
                    created_by=created_by,
                    only_active=only_active,
                    all_users=all_users,
                ),
                state=None,
                name=None,
                created_by=None,
                only_active=False,
                all_users=True,
                limit=limit,
                offset=offset,
            )

        out = await self._request(**_txn_list_request_kwargs(self.config))
        return _txn_list_from_bulk_response(
            out,
            state=state,
            name=name,
            created_by=created_by,
            only_active=only_active,
            all_users=all_users,
            limit=limit,
            offset=offset,
        )

    async def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents:
        out = await self._request(**_txn_events_request_kwargs(self.config, id, continuation_token, stream_name))
        return _txn_events(out, txn_id=id, continuation_token=continuation_token, stream_name=stream_name)

    async def artifacts(self, id: str) -> dict[str, dict[str, Any]]:
        out = await self._request(**_txn_artifacts_request_kwargs(self.config, id))
        return _txn_artifacts(out)

    async def problems(self, id: str) -> dict[str, Any]:
        out = await self._request(**_txn_problems_request_kwargs(self.config, id))
        return _txn_problems(out)

    async def cancel(self, id: str, *, all_users: bool = False) -> None:
        if all_users:
            raise JobInvalidRequestError("Transactions Direct Access cancel does not support all_users=True.")
        await self._request(**_txn_cancel_async_request_kwargs(self.config, id))


# Backward-compatible alias for callers still importing the previous name.
TxnAsyncHttpGateway = TxnHttpGatewayAsync


__all__ = [
    "TxnAsyncHttpGateway",
    "TxnHttpGatewayAsync",
    "TxnHttpGateway",
    "_extract_txn_id",
    "_require_txn_id",
    "_txn_extract_transaction_dicts",
    "_txn_filter_list_records",
    "_txn_list_from_bulk_response",
    "_txn_list_matches_single_job",
    "_txn_cancel_async_request_kwargs",
    "_txn_list_request_kwargs",
    "_txn_query_params",
]
