from __future__ import annotations

import asyncio
import functools
from dataclasses import dataclass
from typing import Any, Protocol

from relationalai.services._shared.direct_access_capability import Transport
from relationalai.services._shared.transport_logging import log_transport_decision
from relationalai.services.constants import REASONER_TYPE_LOGIC

from .capabilities import da_capability
from .errors import JobInvalidRequestError
from .gateways import JobsGateway, JobsGatewaySync
from .models import JobEvents, JobRecord


def _is_logic(reasoner_type: str) -> bool:
    return str(reasoner_type).strip().upper() == REASONER_TYPE_LOGIC


def _logic_resolved_transport(operation: str, *, txn_http: Any | None) -> Transport:
    capability = da_capability(operation=operation, reasoner_type=REASONER_TYPE_LOGIC)
    if capability.transport == "http" and txn_http is None:
        return "sql"
    return capability.transport


def _logic_emit_transport_log(
    operation: str,
    *,
    txn_http: Any | None,
    resolved_transport: Transport | None = None,
) -> None:
    capability = da_capability(operation=operation, reasoner_type=REASONER_TYPE_LOGIC)
    transport: Transport = (
        resolved_transport
        if resolved_transport is not None
        else _logic_resolved_transport(operation, txn_http=txn_http)
    )
    details = {"sql_dependency": str(capability.sql_dependency).lower()}
    if capability.note:
        details["note"] = capability.note.replace(" ", "_")
    log_transport_decision(
        service="jobs",
        operation=operation,
        transport=transport,
        policy="direct_access_logic_hybrid" if txn_http is not None else "sql_only_logic",
        reasoner_type=REASONER_TYPE_LOGIC,
        details=details,
    )


class _TxnSqlGateway(Protocol):
    def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str: ...
    def get(self, id: str) -> JobRecord | None: ...
    def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[JobRecord]: ...
    def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents: ...
    def cancel(self, id: str, *, all_users: bool = False) -> None: ...
    def artifacts(self, id: str) -> dict[str, Any]: ...
    def problems(self, id: str) -> dict[str, Any]: ...


class _TxnDaGatewaySync(Protocol):
    def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str: ...
    def get(self, id: str) -> JobRecord | None: ...
    def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[JobRecord]: ...
    def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents: ...
    def cancel(self, id: str, *, all_users: bool = False) -> None: ...
    def artifacts(self, id: str) -> dict[str, Any]: ...
    def problems(self, id: str) -> dict[str, Any]: ...


class TxnDaGatewayAsync(Protocol):
    async def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str: ...
    async def get(self, id: str) -> JobRecord | None: ...
    async def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[JobRecord]: ...
    async def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents: ...
    async def cancel(self, id: str, *, all_users: bool = False) -> None: ...
    async def artifacts(self, id: str) -> dict[str, Any]: ...
    async def problems(self, id: str) -> dict[str, Any]: ...


@dataclass
class LogicTransactionsGatewaySync:
    txn_sql: _TxnSqlGateway
    txn_http: _TxnDaGatewaySync | None = None

    def _require_logic(self, reasoner_type: str) -> None:
        if not _is_logic(reasoner_type):
            raise JobInvalidRequestError("Only supported for reasoner_type='LOGIC'.")

    def _log(self, operation: str, *, resolved_transport: Transport | None = None) -> None:
        _logic_emit_transport_log(operation, txn_http=self.txn_http, resolved_transport=resolved_transport)

    def _resolved_transport(self, operation: str) -> Transport:
        return _logic_resolved_transport(operation, txn_http=self.txn_http)

    def _dispatch(self, operation: str, *, sql_call: Any, http_call: Any | None = None) -> Any:
        transport = self._resolved_transport(operation)
        self._log(operation)
        if transport == "http":
            if http_call is None:
                raise RuntimeError(f"Jobs LOGIC operation {operation!r} resolved to HTTP without an HTTP handler.")
            return http_call()
        if transport == "sql":
            return sql_call()
        if transport is None:
            raise RuntimeError(f"Jobs LOGIC operation {operation!r} has no transport configured.")
        raise RuntimeError(f"Unknown Jobs LOGIC transport: {transport!r}")

    def get(self, reasoner_type: str, job_id: str) -> JobRecord | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "get",
            sql_call=lambda: self.txn_sql.get(job_id),
            http_call=(lambda: http.get(job_id)) if http is not None else None,
        )

    def create(self, reasoner_type: str, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "create",
            sql_call=lambda: self.txn_sql.create(reasoner_name, payload, timeout_mins=timeout_mins),
            http_call=(lambda: http.create(reasoner_name, payload, timeout_mins=timeout_mins))
            if http is not None
            else None,
        )

    def list(self, reasoner_type: str, **kwargs: Any) -> list[JobRecord]:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "list",
            sql_call=lambda: self.txn_sql.list(**kwargs),
            http_call=(lambda: http.list(**kwargs)) if http is not None else None,
        )

    def events(
        self, reasoner_type: str, job_id: str, continuation_token: str = "", *, stream_name: str = "progress"
    ) -> JobEvents:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "events",
            sql_call=lambda: self.txn_sql.events(job_id, continuation_token=continuation_token, stream_name=stream_name),
            http_call=(lambda: http.events(job_id, continuation_token=continuation_token, stream_name=stream_name))
            if http is not None
            else None,
        )

    def cancel(self, reasoner_type: str, job_id: str, *, all_users: bool = False) -> None:
        self._require_logic(reasoner_type)
        if all_users:
            self._log("cancel", resolved_transport="sql")
            self.txn_sql.cancel(job_id, all_users=True)
            return None
        http = self.txn_http
        return self._dispatch(
            "cancel",
            sql_call=lambda: self.txn_sql.cancel(job_id, all_users=False),
            http_call=(lambda: http.cancel(job_id, all_users=False)) if http is not None else None,
        )

    def artifacts(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "artifacts",
            sql_call=lambda: self.txn_sql.artifacts(job_id),
            http_call=(lambda: http.artifacts(job_id)) if http is not None else None,
        )

    def problems(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return self._dispatch(
            "problems",
            sql_call=lambda: self.txn_sql.problems(job_id),
            http_call=(lambda: http.problems(job_id)) if http is not None else None,
        )

    def close(self) -> None:
        return None


@dataclass
class LogicTransactionsGateway:
    txn_sql: _TxnSqlGateway
    txn_http: TxnDaGatewayAsync | None = None

    def _require_logic(self, reasoner_type: str) -> None:
        if not _is_logic(reasoner_type):
            raise JobInvalidRequestError("Only supported for reasoner_type='LOGIC'.")

    def _log(self, operation: str, *, resolved_transport: Transport | None = None) -> None:
        _logic_emit_transport_log(operation, txn_http=self.txn_http, resolved_transport=resolved_transport)

    def _resolved_transport(self, operation: str) -> Transport:
        return _logic_resolved_transport(operation, txn_http=self.txn_http)

    async def _dispatch(self, operation: str, *, sql_call: Any, http_call: Any | None = None) -> Any:
        transport = self._resolved_transport(operation)
        self._log(operation)
        if transport == "http":
            if http_call is None:
                raise RuntimeError(f"Jobs LOGIC operation {operation!r} resolved to HTTP without an HTTP handler.")
            return await http_call()
        if transport == "sql":
            return await sql_call()
        if transport is None:
            raise RuntimeError(f"Jobs LOGIC operation {operation!r} has no transport configured.")
        raise RuntimeError(f"Unknown Jobs LOGIC transport: {transport!r}")

    async def get(self, reasoner_type: str, job_id: str) -> JobRecord | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "get",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.get, job_id),
            http_call=(lambda: http.get(job_id)) if http is not None else None,
        )

    async def create(self, reasoner_type: str, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "create",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.create, reasoner_name, payload, timeout_mins=timeout_mins),
            http_call=(lambda: http.create(reasoner_name, payload, timeout_mins=timeout_mins))
            if http is not None
            else None,
        )

    async def list(self, reasoner_type: str, **kwargs: Any) -> list[JobRecord]:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "list",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.list, **kwargs),
            http_call=(lambda: http.list(**kwargs)) if http is not None else None,
        )

    async def events(
        self, reasoner_type: str, job_id: str, continuation_token: str = "", *, stream_name: str = "progress"
    ) -> JobEvents:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "events",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.events, job_id, continuation_token, stream_name=stream_name),
            http_call=(lambda: http.events(job_id, continuation_token=continuation_token, stream_name=stream_name))
            if http is not None
            else None,
        )

    async def cancel(self, reasoner_type: str, job_id: str, *, all_users: bool = False) -> None:
        self._require_logic(reasoner_type)
        if all_users:
            self._log("cancel", resolved_transport="sql")
            await asyncio.to_thread(functools.partial(self.txn_sql.cancel, job_id, all_users=True))
            return None
        http = self.txn_http
        return await self._dispatch(
            "cancel",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.cancel, job_id),
            http_call=(lambda: http.cancel(job_id, all_users=False)) if http is not None else None,
        )

    async def artifacts(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "artifacts",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.artifacts, job_id),
            http_call=(lambda: http.artifacts(job_id)) if http is not None else None,
        )

    async def problems(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        self._require_logic(reasoner_type)
        http = self.txn_http
        return await self._dispatch(
            "problems",
            sql_call=lambda: asyncio.to_thread(self.txn_sql.problems, job_id),
            http_call=(lambda: http.problems(job_id)) if http is not None else None,
        )

    async def aclose(self) -> None:
        return None


@dataclass
class RouterGatewaySync:
    jobs: JobsGatewaySync
    logic: JobsGatewaySync

    def _gw(self, reasoner_type: str) -> JobsGatewaySync:
        return self.logic if _is_logic(reasoner_type) else self.jobs

    def get(self, reasoner_type: str, job_id: str) -> JobRecord | None:
        return self._gw(reasoner_type).get(reasoner_type, job_id)

    def create(self, reasoner_type: str, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        return self._gw(reasoner_type).create(reasoner_type, reasoner_name, payload, timeout_mins=timeout_mins)

    def list(self, reasoner_type: str, **kwargs: Any) -> list[JobRecord]:
        return self._gw(reasoner_type).list(reasoner_type, **kwargs)

    def events(
        self, reasoner_type: str, job_id: str, continuation_token: str = "", *, stream_name: str = "progress"
    ) -> JobEvents:
        return self._gw(reasoner_type).events(reasoner_type, job_id, continuation_token=continuation_token, stream_name=stream_name)

    def cancel(self, reasoner_type: str, job_id: str, *, all_users: bool = False) -> None:
        return self._gw(reasoner_type).cancel(reasoner_type, job_id, all_users=all_users)

    def artifacts(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        return self._gw(reasoner_type).artifacts(reasoner_type, job_id)

    def problems(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        return self._gw(reasoner_type).problems(reasoner_type, job_id)

    def close(self) -> None:
        return None


@dataclass
class RouterGateway:
    jobs: JobsGateway
    logic: JobsGateway

    def _gw(self, reasoner_type: str) -> JobsGateway:
        return self.logic if _is_logic(reasoner_type) else self.jobs

    async def get(self, reasoner_type: str, job_id: str) -> JobRecord | None:
        return await self._gw(reasoner_type).get(reasoner_type, job_id)

    async def create(self, reasoner_type: str, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        return await self._gw(reasoner_type).create(reasoner_type, reasoner_name, payload, timeout_mins=timeout_mins)

    async def list(self, reasoner_type: str, **kwargs: Any) -> list[JobRecord]:
        return await self._gw(reasoner_type).list(reasoner_type, **kwargs)

    async def events(
        self, reasoner_type: str, job_id: str, continuation_token: str = "", *, stream_name: str = "progress"
    ) -> JobEvents:
        return await self._gw(reasoner_type).events(reasoner_type, job_id, continuation_token=continuation_token, stream_name=stream_name)

    async def cancel(self, reasoner_type: str, job_id: str, *, all_users: bool = False) -> None:
        return await self._gw(reasoner_type).cancel(reasoner_type, job_id, all_users=all_users)

    async def artifacts(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        return await self._gw(reasoner_type).artifacts(reasoner_type, job_id)

    async def problems(self, reasoner_type: str, job_id: str) -> dict[str, Any] | None:
        return await self._gw(reasoner_type).problems(reasoner_type, job_id)

    async def aclose(self) -> None:
        return None


__all__ = [
    "LogicTransactionsGateway",
    "LogicTransactionsGatewaySync",
    "RouterGateway",
    "RouterGatewaySync",
    "TxnDaGatewayAsync",
]
