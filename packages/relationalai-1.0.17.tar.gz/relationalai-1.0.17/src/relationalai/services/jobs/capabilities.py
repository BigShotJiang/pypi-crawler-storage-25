from __future__ import annotations

from typing import Final

from relationalai.services._shared.direct_access_capability import DirectAccessCapability


NON_LOGIC_DA_CAPABILITIES: Final[dict[str, DirectAccessCapability]] = {
    "get": DirectAccessCapability("get", "http"),
    "create": DirectAccessCapability("create", "http"),
    "list": DirectAccessCapability("list", "http"),
    "events": DirectAccessCapability("events", "http"),
    "cancel": DirectAccessCapability("cancel", "http"),
    "artifacts": DirectAccessCapability("artifacts", None, note="Non-LOGIC jobs do not expose artifacts."),
    "problems": DirectAccessCapability("problems", None, note="Non-LOGIC jobs do not expose problems."),
}

LOGIC_DA_CAPABILITIES: Final[dict[str, DirectAccessCapability]] = {
    "get": DirectAccessCapability("get", "http"),
    "create": DirectAccessCapability("create", "http"),
    "list": DirectAccessCapability(
        "list",
        "http",
        note="LOGIC list uses GET /v1alpha1/transactions when transactions HTTP is available; otherwise SQL.",
        sql_dependency=True,
    ),
    "events": DirectAccessCapability("events", "http"),
    "cancel": DirectAccessCapability(
        "cancel",
        "http",
        note="LOGIC cancel uses POST .../transactions/{id}/cancel_async when transactions HTTP is available; "
        "SQL for all_users=True or without txn HTTP.",
        sql_dependency=True,
    ),
    "artifacts": DirectAccessCapability("artifacts", "http"),
    "problems": DirectAccessCapability("problems", "http"),
}


def da_capability(*, operation: str, reasoner_type: str) -> DirectAccessCapability:
    rt = str(reasoner_type or "").strip().upper()
    matrix = LOGIC_DA_CAPABILITIES if rt == "LOGIC" else NON_LOGIC_DA_CAPABILITIES
    try:
        return matrix[operation]
    except KeyError as e:
        raise KeyError(f"Unknown jobs DA capability: reasoner_type={rt!r} operation={operation!r}") from e


def describe_direct_access_policy() -> str:
    return (
        "Jobs: non-LOGIC uses HTTP. LOGIC prefers HTTP with SQL fallback when transactions HTTP "
        "is unavailable; cancel(all_users=True) stays on SQL."
    )


__all__ = [
    "DirectAccessCapability",
    "LOGIC_DA_CAPABILITIES",
    "NON_LOGIC_DA_CAPABILITIES",
    "da_capability",
    "describe_direct_access_policy",
]
