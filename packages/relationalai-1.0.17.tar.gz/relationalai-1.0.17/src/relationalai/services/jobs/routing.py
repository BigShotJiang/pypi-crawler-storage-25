"""Compatibility re-exports for Jobs routing internals.

The concrete LOGIC routing implementation now lives in smaller modules:
- `txn_sql.py`
- `txn_http.py`
- `router.py`

This file keeps the existing import surface stable for callers and tests.
"""

from __future__ import annotations

from .router import (
    LogicTransactionsGateway,
    LogicTransactionsGatewaySync,
    RouterGateway,
    RouterGatewaySync,
    TxnDaGatewayAsync,
)
from .txn_http import TxnAsyncHttpGateway, TxnHttpGateway, TxnHttpGatewayAsync, _extract_txn_id, _require_txn_id, _txn_query_params
from .txn_sql import TxnSqlGateway

__all__ = [
    "LogicTransactionsGateway",
    "LogicTransactionsGatewaySync",
    "RouterGateway",
    "RouterGatewaySync",
    "TxnDaGatewayAsync",
    "TxnAsyncHttpGateway",
    "TxnHttpGatewayAsync",
    "TxnHttpGateway",
    "TxnSqlGateway",
    "_extract_txn_id",
    "_require_txn_id",
    "_txn_query_params",
]

