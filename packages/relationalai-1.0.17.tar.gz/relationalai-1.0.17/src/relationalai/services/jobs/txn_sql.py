from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from relationalai.client.transports.sql import SqlClient
from relationalai.services._shared.sql_rows import row_first_value, row_get, row_to_mapping

from .errors import JobInvalidRequestError
from .models import JobEvents, JobRecord, job_events_from_value, logic_txn_job_from_row

if TYPE_CHECKING:
    from relationalai.config.config import Config


@dataclass
class TxnSqlGateway:
    """Transactions gateway implemented via SQL (table + stored procs/functions)."""

    executor: SqlClient
    app: str
    config: "Config"

    def _collect(self, statement: str, params: list[Any] | None, *, operation: str) -> list[Any]:
        return self.executor.collect(
            statement,
            params if params else None,
            operation=operation,
            meta={
                "app": self.app,
                "schema": "api",
                "object": "transactions",
                "params": 0 if not params else len(params),
            },
        )

    def get(self, id: str) -> JobRecord | None:
        stmt = f"""
            SELECT
                id, database_name, engine_name, state, abort_reason, read_only,
                created_by, created_on, finished_at, duration
            FROM {self.app}.api.transactions
            WHERE id = ?
            LIMIT 1;
        """
        rows = self._collect(stmt, [id], operation="get")
        if not rows:
            return None
        return logic_txn_job_from_row(rows[0])

    def list(
        self,
        *,
        job_id: str | None = None,
        state: str | None = None,
        name: str | None = None,
        created_by: str | None = None,
        only_active: bool = False,
        all_users: bool = False,
        limit: int | None = 100,
        offset: int | None = None,
    ) -> list[JobRecord]:
        where: list[str] = []
        params: list[Any] = []

        if job_id:
            where.append("id = ?")
            params.append(job_id)

        if state:
            where.append("state = ?")
            params.append(state)
        elif only_active:
            where.append("state in ('CREATED', 'RUNNING', 'PENDING')")

        if name:
            where.append("LOWER(engine_name) = ?")
            params.append(str(name).lower())
        if not all_users and created_by is not None:
            where.append("LOWER(created_by) = ?")
            params.append(str(created_by).lower())

        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        offset_int = int(offset or 0)
        if offset_int < 0:
            raise JobInvalidRequestError("Job `offset` must be >= 0.")
        limit_clause = ""
        if limit is not None:
            limit_int = int(limit)
            if limit_int <= 0:
                return []
            limit_clause = " LIMIT ?"
            params.append(limit_int)
            if offset_int:
                limit_clause += " OFFSET ?"
                params.append(offset_int)

        stmt = f"""
            SELECT
                id, database_name, engine_name, state, abort_reason, read_only,
                created_by, created_on, finished_at, duration
            FROM {self.app}.api.transactions
            {where_clause}
            ORDER BY created_on DESC{limit_clause};
        """
        rows = self._collect(stmt, params, operation="list")
        if limit is None and offset_int:
            rows = rows[offset_int:]
        return [logic_txn_job_from_row(r) for r in rows]

    def create(self, reasoner_name: str, payload: dict[str, Any], *, timeout_mins: int | None = None) -> str:
        reasoner = str(reasoner_name).strip()
        if not reasoner:
            raise JobInvalidRequestError("Transaction create requires a non-empty reasoner name.")

        db_any = payload.get("dbname") or payload.get("database") or payload.get("database_name")
        dbname = str(db_any).strip() if isinstance(db_any, str) else ""
        if not dbname:
            raise JobInvalidRequestError("Transaction create requires payload['dbname'] (database name).")

        q_any = payload.get("query") or payload.get("raw_code") or payload.get("code")
        query = str(q_any).strip() if isinstance(q_any, str) else ""
        if not query:
            raise JobInvalidRequestError("Transaction create requires payload['query'] (raw code).")

        inputs_any = payload.get("v1_inputs")
        if inputs_any is None:
            inputs_any = payload.get("inputs")
        inputs = inputs_any if isinstance(inputs_any, dict) else {}

        ro_any = payload.get("readonly")
        if ro_any is None:
            ro_any = payload.get("read_only")
        readonly = True if ro_any is None else bool(ro_any)

        nowait_durable = bool(payload.get("nowait_durable") or False)
        lang_any = payload.get("language")
        language = str(lang_any) if isinstance(lang_any, str) and lang_any else "rel"

        hdrs = payload.get("headers")
        headers = hdrs if isinstance(hdrs, dict) else {}

        to_mins_any = payload.get("timeout_mins")
        payload_timeout = int(to_mins_any) if isinstance(to_mins_any, int) else None
        tm = timeout_mins if timeout_mins is not None else payload_timeout

        inputs_json = json.dumps(inputs)
        headers_json = json.dumps(headers)
        abort_detached = bool(payload.get("abort_detached") or False)
        if tm is not None:
            stmt = f"call {self.app}.api.exec_async_v2(?, ?, ?, PARSE_JSON(?), ?, ?, ?, ?, PARSE_JSON(?), ?);"
            params = [
                dbname,
                reasoner,
                query,
                inputs_json,
                readonly,
                nowait_durable,
                language,
                int(tm),
                headers_json,
                abort_detached,
            ]
        else:
            stmt = f"call {self.app}.api.exec_async_v2(?, ?, ?, PARSE_JSON(?), ?, ?, ?, PARSE_JSON(?), ?);"
            params = [dbname, reasoner, query, inputs_json, readonly, nowait_durable, language, headers_json, abort_detached]

        try:
            rows = self._collect(stmt, params, operation="create")
        except Exception as e:
            msg = str(e).lower()
            if "exec_async_v2" not in msg or (
                "wrong number of arguments" not in msg and "too many arguments" not in msg and "argument" not in msg
            ):
                raise
            if tm is not None:
                stmt = f"call {self.app}.api.exec_async_v2(?, ?, ?, PARSE_JSON(?), ?, ?, ?, ?, PARSE_JSON(?));"
                params = [dbname, reasoner, query, inputs_json, readonly, nowait_durable, language, int(tm), headers_json]
            else:
                stmt = f"call {self.app}.api.exec_async_v2(?, ?, ?, PARSE_JSON(?), ?, ?, ?, PARSE_JSON(?));"
                params = [dbname, reasoner, query, inputs_json, readonly, nowait_durable, language, headers_json]
            rows = self._collect(stmt, params, operation="create")
        if not rows:
            raise RuntimeError("Transaction creation returned no results (expected an ID row).")
        txn_id = row_get(rows[0], "ID", "id", "TXN_ID", "txn_id")
        if not isinstance(txn_id, str):
            txn_id = str(txn_id) if txn_id is not None else ""
        if not txn_id:
            raise RuntimeError("Transaction creation did not return an ID.")
        return txn_id

    def events(self, id: str, continuation_token: str = "", *, stream_name: str = "progress") -> JobEvents:
        if stream_name and stream_name != "progress":
            raise JobInvalidRequestError("SQL backend for transactions only supports stream_name='progress'.")
        stmt = f"select {self.app}.api.get_own_transaction_events(?, ?);"
        tok_in = str(continuation_token or "")
        tok = "" if tok_in == "0" else tok_in
        rows = self._collect(stmt, [id, tok], operation="events")
        if not rows:
            return JobEvents(events=[], continuation_token=None)
        val = row_first_value(rows[0])
        return job_events_from_value(val)

    def cancel(self, id: str, *, all_users: bool = False) -> None:
        proc = "CANCEL_TRANSACTION" if all_users else "CANCEL_OWN_TRANSACTION"
        stmt = f"call {self.app}.api.{proc}(?);"
        self._collect(stmt, [id], operation="cancel")
        return None

    def artifacts(self, id: str) -> dict[str, Any]:
        stmt = f"call {self.app}.api.get_own_transaction_artifacts(?);"
        rows = self._collect(stmt, [id], operation="artifacts")
        if not rows:
            return {}
        d = row_to_mapping(rows[0])
        return d if isinstance(d, dict) else {}

    def problems(self, id: str) -> dict[str, Any]:
        stmt = f"select * from table({self.app}.api.get_own_transaction_problems(?));"
        rows = self._collect(stmt, [id], operation="problems")
        if not rows:
            return {}
        items: list[dict[str, Any]] = []
        for r in rows:
            m = row_to_mapping(r)
            if m:
                items.append(m)
        return {"problems": items}


__all__ = ["TxnSqlGateway"]
