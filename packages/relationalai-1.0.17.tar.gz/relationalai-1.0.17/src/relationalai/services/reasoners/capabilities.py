from __future__ import annotations

from typing import Final

from relationalai.services._shared.direct_access_capability import DirectAccessCapability

from . import constants as c


DA_CAPABILITIES: Final[dict[str, DirectAccessCapability]] = {
    "list": DirectAccessCapability("list", method="GET", endpoint=c.REASONERS_DA_BASE_PATH),
    "get": DirectAccessCapability(
        "get",
        method="GET",
        endpoint=f"{c.REASONERS_DA_BASE_PATH}/{{engine_type}}/{{engine_name}}",
        allow_404=True,
    ),
    "create": DirectAccessCapability("create", method="POST", endpoint=f"{c.REASONERS_DA_BASE_PATH}/{{engine_type}}"),
    "delete": DirectAccessCapability(
        "delete",
        method="DELETE",
        endpoint=f"{c.REASONERS_DA_BASE_PATH}/{{engine_type}}/{{engine_name}}",
    ),
    "suspend": DirectAccessCapability(
        "suspend",
        method="POST",
        endpoint=f"{c.REASONERS_DA_BASE_PATH}/{{engine_type}}/{{engine_name}}/suspend",
    ),
    "resume": DirectAccessCapability(
        "resume",
        method="POST",
        endpoint=f"{c.REASONERS_DA_BASE_PATH}/{{engine_type}}/{{engine_name}}/resume_async",
    ),
    "alter_auto_suspend_mins": DirectAccessCapability("alter_auto_suspend_mins", sql_fallback=True),
}


def da_capability(operation: str) -> DirectAccessCapability:
    try:
        return DA_CAPABILITIES[operation]
    except KeyError as e:
        raise KeyError(f"Unknown reasoners DA capability: {operation!r}") from e


def describe_direct_access_policy() -> str:
    return "Reasoners: HTTP for list/get/create/delete/suspend/resume with SQL fallback for alter_auto_suspend_mins."


__all__ = ["DA_CAPABILITIES", "DirectAccessCapability", "da_capability", "describe_direct_access_policy"]
