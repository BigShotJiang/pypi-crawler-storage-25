from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Transport = Literal["http", "sql"] | None


@dataclass(frozen=True)
class DirectAccessCapability:
    """Shared description of how a Direct Access operation is served."""

    operation: str
    transport: Transport = "http"
    method: str | None = None
    endpoint: str | None = None
    allow_404: bool = False
    sql_fallback: bool = False
    sql_dependency: bool = False
    note: str = ""


__all__ = ["DirectAccessCapability", "Transport"]
