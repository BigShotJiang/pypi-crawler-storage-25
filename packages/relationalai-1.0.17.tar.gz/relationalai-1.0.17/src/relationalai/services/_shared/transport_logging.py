from __future__ import annotations

import logging
from typing import Any

_EXEC_LOG = logging.getLogger("relationalai.client.execution")


def log_transport_decision(
    *,
    service: str,
    operation: str,
    transport: str | None,
    policy: str,
    reasoner_type: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    """Emit a structured transport-selection log for CLI diagnostics."""
    normalized_transport = str(transport or "unknown")
    kind = normalized_transport.upper()
    parts = [
        f"service={service}",
        f"transport={normalized_transport}",
        f"policy={policy}",
    ]
    if reasoner_type:
        parts.append(f"reasoner_type={reasoner_type}")
    if details:
        for key in sorted(details):
            value = details[key]
            if value is None or value == "":
                continue
            parts.append(f"{key}={value}")
    _EXEC_LOG.info("transport_selected kind=%s op=%s %s", kind, operation, " ".join(parts))


__all__ = ["log_transport_decision"]
