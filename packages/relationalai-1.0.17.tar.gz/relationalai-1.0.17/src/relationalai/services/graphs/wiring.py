"""Graphs service wiring (composition root).

The graphs service is **Direct-Access-only**. When `cfg.direct_access` is true,
this module wires up the HTTP gateways against the DA base URL provider. When
it is false (SQL-only deployment, for example), we return client instances
backed by a small "unsupported" gateway that raises
:class:`~relationalai.services.graphs.errors.GraphsUnsupportedError` on every
method.

This mirrors the pattern used by `services/reasoners/wiring.py` and
`services/jobs/wiring.py` for transport selection, but without any SQL fallback.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import NoReturn, Protocol, TYPE_CHECKING, cast

from relationalai.services._shared.da_wiring import build_da_base_url_provider
from relationalai.services._shared.lazy_async_gateway import LazyAsyncGateway
from relationalai.util.adapters import SyncToAsyncGatewayAdapter
from relationalai.util.noclose import NoClose

from .client import GraphsClient
from .client_sync import GraphsClientSync
from .errors import GraphsUnsupportedError
from .gateways import AsyncHttpGateway, HttpGateway
from .models import Graph
from .protocol import GraphsGateway, GraphsGatewaySync

if TYPE_CHECKING:
    from relationalai.client.core import ClientCore


class _AsyncPlatform(Protocol):
    core: "ClientCore"


class _SyncPlatform(Protocol):
    core: "ClientCore"


# ---------------------------------------------------------------------------
# Unsupported-gateway stubs (raised when `cfg.direct_access` is False).
# ---------------------------------------------------------------------------


_UNSUPPORTED_MSG = (
    "`client.graphs` is only available on Direct Access deployments. "
    "Graph databases are a DA-only primitive consumed by the Logic reasoner; "
    "your current backend does not expose the graph endpoints. "
    "Enable Direct Access (`cfg.direct_access = True`) to use this API."
)


@dataclass
class _UnsupportedGraphsGatewaySync:
    """Sync graphs gateway that raises `GraphsUnsupportedError` on every call."""

    def _raise(self) -> NoReturn:
        raise GraphsUnsupportedError(_UNSUPPORTED_MSG)

    def list(self) -> list[Graph]:
        self._raise()

    def get(self, name: str) -> Graph | None:  # noqa: ARG002
        self._raise()

    def create(self, name: str) -> None:  # noqa: ARG002
        self._raise()

    def clone(self, source: str, target: str, *, force: bool = False) -> None:  # noqa: ARG002
        self._raise()

    def delete(
        self,
        name: str,  # noqa: ARG002
        *,
        force: bool = False,  # noqa: ARG002
        language: str = "rel",  # noqa: ARG002
    ) -> None:
        self._raise()


@dataclass
class _UnsupportedGraphsGatewayAsync:
    """Async graphs gateway that raises `GraphsUnsupportedError` on every call."""

    def _raise(self) -> NoReturn:
        raise GraphsUnsupportedError(_UNSUPPORTED_MSG)

    async def list(self) -> list[Graph]:
        self._raise()

    async def get(self, name: str) -> Graph | None:  # noqa: ARG002
        self._raise()

    async def create(self, name: str) -> None:  # noqa: ARG002
        self._raise()

    async def clone(self, source: str, target: str, *, force: bool = False) -> None:  # noqa: ARG002
        self._raise()

    async def delete(
        self,
        name: str,  # noqa: ARG002
        *,
        force: bool = False,  # noqa: ARG002
        language: str = "rel",  # noqa: ARG002
    ) -> None:
        self._raise()

    async def aclose(self) -> None:
        return None


# ---------------------------------------------------------------------------
# Builders.
# ---------------------------------------------------------------------------


def build_graphs_client(platform: _AsyncPlatform) -> GraphsClient:
    """Build an async-first `GraphsClient` bound to a root platform client."""
    cfg = platform.core.config

    if not cfg.direct_access:
        # Preserve the stable shape of `client.graphs` but fail loudly on use.
        return GraphsClient(cast(GraphsGateway, _UnsupportedGraphsGatewayAsync()), config=cfg)

    base_url_provider = build_da_base_url_provider(platform.core)

    async def _build_gateway() -> GraphsGateway:
        http_async = await platform.core.ensure_http_async()
        if http_async is not None:
            return cast(
                GraphsGateway,
                AsyncHttpGateway(config=cfg, base_url_provider=base_url_provider, http=http_async),
            )

        http = platform.core.http_executor
        if http is None:
            raise RuntimeError("Direct Access backend requires an HTTP executor on Client.")
        gw_sync = HttpGateway(config=cfg, base_url_provider=base_url_provider, http=http)
        return cast(GraphsGateway, SyncToAsyncGatewayAdapter(gw_sync))

    gw_lazy = LazyAsyncGateway(_build_gateway)
    return GraphsClient(cast(GraphsGateway, NoClose(gw_lazy)), config=cfg)


def build_graphs_client_sync(platform: _SyncPlatform) -> GraphsClientSync:
    """Build a synchronous `GraphsClientSync` bound to a root platform client."""
    cfg = platform.core.config

    if not cfg.direct_access:
        return GraphsClientSync(cast(GraphsGatewaySync, _UnsupportedGraphsGatewaySync()), config=cfg)

    base_url_provider = build_da_base_url_provider(platform.core)
    http = platform.core.http_executor
    if http is None:
        raise RuntimeError("Direct Access backend requires an HTTP executor on ClientSync.")

    gw = HttpGateway(config=cfg, base_url_provider=base_url_provider, http=http)
    return GraphsClientSync(gw, config=cfg)


__all__ = [
    "build_graphs_client",
    "build_graphs_client_sync",
]
