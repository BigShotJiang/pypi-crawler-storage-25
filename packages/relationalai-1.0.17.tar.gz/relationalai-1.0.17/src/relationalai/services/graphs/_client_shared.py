"""Small shared helpers used by both `GraphsClient` and `GraphsClientSync`."""

from __future__ import annotations

import re

from .errors import GraphInvalidRequestError


# Accept the union of shapes seen in RAI graph names across v0: letters/digits with
# optional '_' or '-' separators. Kept permissive to avoid rejecting server-accepted
# names; server remains the authoritative validator.
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-]*$")


def normalize_name(name: str, *, field: str = "name") -> str:
    """Validate and normalize a graph name, raising a clear error on bad input."""
    if not isinstance(name, str):
        raise GraphInvalidRequestError(f"Graph `{field}` must be a string.")
    value = name.strip()
    if not value:
        raise GraphInvalidRequestError(f"Graph `{field}` is required and cannot be empty.")
    if not _NAME_RE.match(value):
        raise GraphInvalidRequestError(
            f"Invalid graph `{field}`={value!r}. "
            "Use letters/digits plus '_' or '-', starting with a letter or digit."
        )
    return value


__all__ = ["normalize_name"]
