"""Backends (gateways) for the Graphs service.

The Graphs service is **Direct-Access-only**: graph databases live behind the RAI
DA HTTP API (`/v1alpha1/databases` and `/v1alpha1/index/release`) and there is no
Snowflake SQL surface for them. This module ships two thin gateways that speak
those endpoints, mirroring the style of `services/reasoners/gateways.py`:

- :class:`HttpGateway` for sync HTTP (`requests`)
- :class:`AsyncHttpGateway` for async HTTP (aiohttp)

Status/response mapping uses the same `_raise_for_*` pattern as reasoners so
callers get stable domain exceptions (`GraphNotFoundError`, `GraphConflictError`,
`GraphHttpError`, ...).
"""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Any, Protocol, TYPE_CHECKING, TypeAlias, cast

from relationalai.client.transports.http import AsyncHttpClient, HttpClient
from relationalai.services._shared.da_headers import mk_da_headers
from relationalai.services._shared.da_request import BaseUrlProvider, request_async, request_sync
from relationalai.services._shared.transport_logging import log_transport_decision

from relationalai.services._shared.direct_access_capability import DirectAccessCapability

from .capabilities import da_capability
from .errors import (
    GraphAuthError,
    GraphConflictError,
    GraphHttpError,
    GraphInvalidRequestError,
    GraphNotFoundError,
    GraphServerError,
)
from .models import Graph, graph_from_da


def _method_endpoint(spec: DirectAccessCapability) -> tuple[str, str]:
    """Return ``(method, endpoint)`` for a DA capability or raise a real error.

    The capability dataclass types `method`/`endpoint` as `Optional[str]` because
    it is reused across services that have SQL-only operations. Graph operations
    are all HTTP-only, so this helper lets the gateways read `spec.method` /
    `spec.endpoint` without littering call-sites with `assert` statements.
    """
    method = spec.method
    endpoint = spec.endpoint
    if method is None or endpoint is None:
        raise GraphServerError(
            f"Graphs DA capability {spec.operation!r} is missing method/endpoint."
        )
    return method, endpoint


if TYPE_CHECKING:
    import requests

    HttpResponse: TypeAlias = requests.Response
else:
    HttpResponse: TypeAlias = Any


class _ModelCfgLike(Protocol):
    @property
    def reuse_model(self) -> bool: ...


class _ConfigLike(Protocol):
    @property
    def use_graph_index(self) -> bool: ...

    @property
    def model(self) -> _ModelCfgLike: ...


# ---------------------------------------------------------------------------
# HTTP response -> domain error mapping (shared by sync/async paths).
# ---------------------------------------------------------------------------


def _http_error_message(status: int, payload: object) -> str:
    if isinstance(payload, dict):
        return str(payload.get("message") or payload.get("error") or json.dumps(payload))
    return str(payload) or f"HTTP {status}"


def _payload_says_not_found(payload: object) -> bool:
    """Detect DA 'database not found' payloads.

    v0 `delete_graph` / `release_index` treated `404 + "database not found"` as a
    benign no-op. We preserve that behavior at the gateway level so callers don't
    need to know the wire message.

    TODO(graphs): switch to a structured error code once DA exposes one; matching
    on a substring of the human-readable message is fragile across server versions.
    """
    if not isinstance(payload, dict):
        return False
    msg = str(payload.get("message", "")).lower()
    return "database not found" in msg


def _raise_for_status_content(op: str, status: int, payload: object) -> None:
    """Map non-200 status/payload pairs to stable Graphs exceptions."""
    if int(status) == 200:
        return

    msg = _http_error_message(int(status), payload)
    if int(status) in (401, 403):
        raise GraphAuthError(f"Direct Access request unauthorized (status={status}). {msg}")
    if int(status) == 404:
        raise GraphNotFoundError(msg)
    if int(status) == 409:
        raise GraphConflictError(msg)
    if int(status) == 400:
        raise GraphInvalidRequestError(msg)
    if int(status) == 429 or 500 <= int(status) <= 599:
        raise GraphHttpError(status=int(status), message=msg, operation=op)
    raise GraphServerError(f"Direct Access request failed (status={status}). {msg}")


def _raise_for_http(op: str, resp: HttpResponse) -> None:
    """Map non-200 responses to stable Graphs exceptions."""
    if resp.status_code == 200:
        return
    try:
        payload = resp.json()
    except (ValueError, json.JSONDecodeError, TypeError):
        payload = resp.text or f"HTTP {resp.status_code}"
    _raise_for_status_content(op, int(resp.status_code), payload)


# ---------------------------------------------------------------------------
# Payload parsing.
# ---------------------------------------------------------------------------


def _parse_da_list_graphs(content: dict[str, Any]) -> list[Graph]:
    """Parse a DA ``/v1alpha1/databases`` list response into `Graph` objects.

    Ordering is intentionally left to the caller (``GraphsClient.list``) so that
    all gateways produce the same ordering regardless of server response order.
    """
    items = content.get("databases")
    if items is None:
        items = []
    elif not isinstance(items, list):
        raise GraphServerError(
            "Direct Access list returned malformed payload: 'databases' must be a list."
        )
    out: list[Graph] = []
    for entry in items:
        if not isinstance(entry, dict):
            continue
        out.append(graph_from_da(entry))
    return out


def _parse_da_get_graph(content: dict[str, Any], name: str) -> Graph | None:
    """Parse the shape returned by `GET /v1alpha1/databases?name=<name>`.

    v0's `get_database` expects `{"databases": [<entry>]}` with a single match.
    We require an exact name match and return `None` otherwise; returning an
    unrelated first entry when the server's filter is lax would be a source of
    hard-to-debug "wrong graph" bugs.
    """
    dbs = content.get("databases")
    if not dbs or not isinstance(dbs, list):
        return None
    for entry in dbs:
        if isinstance(entry, dict) and str(entry.get("name", "")) == name:
            return graph_from_da(entry)
    return None


# ---------------------------------------------------------------------------
# Sync HTTP gateway.
# ---------------------------------------------------------------------------


@dataclass
class HttpGateway:
    """Graphs gateway backed by Direct Access HTTP endpoints (sync requests)."""

    config: _ConfigLike
    base_url_provider: BaseUrlProvider
    http: HttpClient

    # -- shared helpers --

    def _headers(self) -> dict[str, str] | None:
        return mk_da_headers(cast(Any, self.config), gi_setup_skipped=False)

    def _log(self, operation: str) -> None:
        log_transport_decision(
            service="graphs",
            operation=operation,
            transport="http",
            policy="direct_access_http",
        )

    def _request(
        self,
        *,
        operation: str,
        method: str,
        endpoint: str,
        payload: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        query_params: dict[str, str] | None = None,
    ) -> HttpResponse:
        self._log(operation)
        return request_sync(
            http=self.http,
            operation=operation,
            method=method,
            base_url_provider=self.base_url_provider,
            endpoint=endpoint,
            path_params=path_params,
            query_params=query_params,
            payload=payload,
            headers=self._headers(),
        )

    # -- gateway methods --

    def list(self) -> list[Graph]:
        """List graphs via the DA `/v1alpha1/databases` endpoint."""
        method, endpoint = _method_endpoint(da_capability("list"))
        resp = self._request(operation="list", method=method, endpoint=endpoint)
        _raise_for_http("list", resp)
        return _parse_da_list_graphs(resp.json() or {})

    def get(self, name: str) -> Graph | None:
        """Fetch a single graph by name (returns `None` if not found)."""
        spec = da_capability("get")
        method, endpoint = _method_endpoint(spec)
        resp = self._request(
            operation="get",
            method=method,
            endpoint=endpoint,
            query_params={"name": name},
        )
        if spec.allow_404 and resp.status_code == 404:
            return None
        _raise_for_http("get", resp)
        content = resp.json() or {}
        return _parse_da_get_graph(content, name)

    def create(self, name: str) -> None:
        """Create a graph (mirrors v0 `create_graph` / `_create_database(name, "")`)."""
        self._post_create(name=name, source="")

    def clone(self, source: str, target: str, *, force: bool = False) -> None:
        """Clone a graph from `source` to `target`.

        When ``force=True`` and the target exists, it is **fully deleted** first
        (a release_index with ``keep_database=False`` when index-reuse is on, or
        a raw database delete otherwise) so the subsequent create does not hit a
        name conflict. This is stricter than v0 ``clone_graph(..., force=True)``,
        which only called ``delete_graph`` without forwarding ``force`` — with
        the default ``reuse_model=True`` that left the database in place and the
        clone could still fail.
        """
        if force:
            existing = self.get(target)
            if existing is not None:
                self.delete(target, force=True)
        self._post_create(name=target, source=source)

    def _post_create(self, *, name: str, source: str) -> None:
        method, endpoint = _method_endpoint(da_capability("create"))
        operation = "create" if not source else "clone"
        resp = self._request(
            operation=operation,
            method=method,
            endpoint=endpoint,
            payload={"name": name, "source_name": source},
        )
        _raise_for_http(operation, resp)

    def delete(self, name: str, *, force: bool = False, language: str = "rel") -> None:
        """Delete a graph, honoring v0 ``use_graph_index`` / ``reuse_model`` semantics.

        When ``use_graph_index`` is enabled we call `release_index` (which may retain
        the database for reuse); otherwise we call the raw DB-delete endpoint. In
        both cases a 404 with "database not found" is treated as a no-op.
        """
        if self.config.use_graph_index:
            self._release_index(name=name, force=force, language=language)
            return
        self._delete_db(name=name)

    def _release_index(self, *, name: str, force: bool, language: str) -> None:
        keep_database = (not force) and self.config.model.reuse_model
        method, endpoint = _method_endpoint(da_capability("release_index"))
        resp = self._request(
            operation="release_index",
            method=method,
            endpoint=endpoint,
            payload={
                "model_name": name,
                "keep_database": keep_database,
                "language": language,
            },
        )
        if resp.status_code == 200:
            return
        try:
            payload = resp.json()
        except (ValueError, json.JSONDecodeError, TypeError):
            payload = None
        if resp.status_code == 404 and _payload_says_not_found(payload):
            return
        _raise_for_http("release_index", resp)

    def _delete_db(self, *, name: str) -> None:
        method, endpoint = _method_endpoint(da_capability("delete"))
        resp = self._request(
            operation="delete",
            method=method,
            endpoint=endpoint,
            path_params={"db_name": name},
        )
        if resp.status_code == 404:
            try:
                payload = resp.json()
            except (ValueError, json.JSONDecodeError, TypeError):
                payload = None
            if _payload_says_not_found(payload):
                return
        _raise_for_http("delete", resp)


# ---------------------------------------------------------------------------
# Async HTTP gateway.
# ---------------------------------------------------------------------------


@dataclass
class AsyncHttpGateway:
    """Async-native Direct Access gateway for graphs (aiohttp)."""

    config: _ConfigLike
    base_url_provider: BaseUrlProvider
    http: AsyncHttpClient

    def _headers(self) -> dict[str, str] | None:
        return mk_da_headers(cast(Any, self.config), gi_setup_skipped=False)

    def _log(self, operation: str) -> None:
        log_transport_decision(
            service="graphs",
            operation=operation,
            transport="http",
            policy="direct_access_http",
        )

    async def _request(
        self,
        *,
        operation: str,
        method: str,
        endpoint: str,
        payload: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        query_params: dict[str, str] | None = None,
        allow_404: bool = False,
    ) -> tuple[int, Any]:
        self._log(operation)
        return await request_async(
            http=self.http,
            operation=operation,
            method=method,
            base_url_provider=self.base_url_provider,
            endpoint=endpoint,
            path_params=path_params,
            query_params=query_params,
            payload=payload,
            headers=self._headers(),
            allow_404=allow_404,
        )

    async def aclose(self) -> None:
        """Close the underlying aiohttp session (if present)."""
        session = getattr(self.http, "session", None)
        close = getattr(session, "close", None)
        if callable(close):
            out = close()
            if inspect.isawaitable(out):
                await cast(Any, out)

    async def list(self) -> list[Graph]:
        method, endpoint = _method_endpoint(da_capability("list"))
        status, content = await self._request(
            operation="list", method=method, endpoint=endpoint,
        )
        _raise_for_status_content("list", int(status), content)
        return _parse_da_list_graphs(content or {})

    async def get(self, name: str) -> Graph | None:
        spec = da_capability("get")
        method, endpoint = _method_endpoint(spec)
        status, content = await self._request(
            operation="get",
            method=method,
            endpoint=endpoint,
            query_params={"name": name},
            allow_404=spec.allow_404,
        )
        if spec.allow_404 and int(status) == 404:
            return None
        _raise_for_status_content("get", int(status), content)
        if not isinstance(content, dict):
            return None
        return _parse_da_get_graph(content, name)

    async def create(self, name: str) -> None:
        await self._post_create(name=name, source="")

    async def clone(self, source: str, target: str, *, force: bool = False) -> None:
        if force:
            existing = await self.get(target)
            if existing is not None:
                await self.delete(target, force=True)
        await self._post_create(name=target, source=source)

    async def _post_create(self, *, name: str, source: str) -> None:
        method, endpoint = _method_endpoint(da_capability("create"))
        operation = "create" if not source else "clone"
        status, content = await self._request(
            operation=operation,
            method=method,
            endpoint=endpoint,
            payload={"name": name, "source_name": source},
        )
        _raise_for_status_content(operation, int(status), content)

    async def delete(self, name: str, *, force: bool = False, language: str = "rel") -> None:
        if self.config.use_graph_index:
            await self._release_index(name=name, force=force, language=language)
            return
        await self._delete_db(name=name)

    async def _release_index(self, *, name: str, force: bool, language: str) -> None:
        keep_database = (not force) and self.config.model.reuse_model
        method, endpoint = _method_endpoint(da_capability("release_index"))
        status, content = await self._request(
            operation="release_index",
            method=method,
            endpoint=endpoint,
            payload={
                "model_name": name,
                "keep_database": keep_database,
                "language": language,
            },
            allow_404=True,
        )
        if int(status) == 200:
            return
        if int(status) == 404 and _payload_says_not_found(content):
            return
        _raise_for_status_content("release_index", int(status), content)

    async def _delete_db(self, *, name: str) -> None:
        method, endpoint = _method_endpoint(da_capability("delete"))
        status, content = await self._request(
            operation="delete",
            method=method,
            endpoint=endpoint,
            path_params={"db_name": name},
            allow_404=True,
        )
        if int(status) == 404 and _payload_says_not_found(content):
            return
        _raise_for_status_content("delete", int(status), content)


__all__ = ["HttpGateway", "AsyncHttpGateway"]
