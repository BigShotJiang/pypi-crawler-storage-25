"""Graphs gateway protocols.

These protocols define the backend adapter surface used by `GraphsClient` /
`GraphsClientSync`. Implementations live in `graphs/gateways.py`.
"""

from __future__ import annotations

from typing import Protocol

from .models import Graph


class GraphsGateway(Protocol):
    """Async Graphs gateway protocol.

    Sync gateways should be adapted via `SyncToAsyncGatewayAdapter`.
    """

    async def list(self) -> list[Graph]: ...

    async def get(self, name: str) -> Graph | None: ...

    async def create(self, name: str) -> None: ...

    async def clone(self, source: str, target: str, *, force: bool = False) -> None: ...

    async def delete(
        self,
        name: str,
        *,
        force: bool = False,
        language: str = "rel",
    ) -> None: ...

    async def aclose(self) -> None: ...


class GraphsGatewaySync(Protocol):
    """Synchronous gateway protocol for the graphs service."""

    def list(self) -> list[Graph]: ...

    def get(self, name: str) -> Graph | None: ...

    def create(self, name: str) -> None: ...

    def clone(self, source: str, target: str, *, force: bool = False) -> None: ...

    def delete(
        self,
        name: str,
        *,
        force: bool = False,
        language: str = "rel",
    ) -> None: ...


__all__ = ["GraphsGateway", "GraphsGatewaySync"]
