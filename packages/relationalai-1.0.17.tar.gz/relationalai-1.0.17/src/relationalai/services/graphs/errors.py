"""Graphs error types.

The graphs service is a thin Direct Access wrapper, so its error hierarchy reuses
the shared client error base classes. Callers can catch `GraphError` for any
graphs-specific failure, or the base classes (e.g. `ClientNotFoundError`) for
cross-service handling.

`GraphsUnsupportedError` is raised at call time when `client.graphs` is used on a
deployment that does not expose the Direct Access graph endpoints (e.g. SQL-only).
"""

from __future__ import annotations

from relationalai.client.errors.exceptions import (
    ClientAuthError,
    ClientConflictError,
    ClientError,
    ClientInvalidRequestError,
    ClientNotFoundError,
    ClientServerError,
    ClientUnknownError,
)
from relationalai.util.docutils import include_in_docs


__include_in_docs__ = True


@include_in_docs
class GraphError(ClientError):
    """Base error for graph database operations."""


@include_in_docs
class GraphAuthError(ClientAuthError, GraphError):
    """Raised when a graph request fails authentication or authorization."""


@include_in_docs
class GraphNotFoundError(ClientNotFoundError, GraphError):
    """Raised when the requested graph database does not exist."""


@include_in_docs
class GraphConflictError(ClientConflictError, GraphError):
    """Raised when a graph operation conflicts with current state (e.g. already exists)."""


@include_in_docs
class GraphInvalidRequestError(ClientInvalidRequestError, GraphError):
    """Raised when the graph request is invalid (bad name, missing source, etc.)."""


@include_in_docs
class GraphServerError(ClientServerError, GraphError):
    """Raised when the backend fails while processing a graph request."""


@include_in_docs
class GraphHttpError(GraphServerError):
    """Direct Access HTTP error with status code (useful for retries/classification)."""

    def __init__(self, *, status: int, message: str, operation: str | None = None):
        self.status = int(status)
        self.operation = operation
        self.message = message
        op = f" op={operation}" if operation else ""
        super().__init__(f"Direct Access request failed (status={self.status}).{op} {message}")


@include_in_docs
class GraphUnknownError(ClientUnknownError, GraphError):
    """Raised when a graph failure cannot be classified more precisely."""


@include_in_docs
class GraphsUnsupportedError(GraphError):
    """Raised when `client.graphs` is used on a deployment that does not expose graph CRUD.

    Graph databases are a Direct Access primitive consumed by the Logic reasoner.
    On SQL-only deployments (or any deployment where Direct Access is disabled)
    the graph endpoints are not reachable and this error is raised on first use.
    """


__all__ = [
    "GraphError",
    "GraphAuthError",
    "GraphNotFoundError",
    "GraphConflictError",
    "GraphInvalidRequestError",
    "GraphServerError",
    "GraphHttpError",
    "GraphUnknownError",
    "GraphsUnsupportedError",
]
