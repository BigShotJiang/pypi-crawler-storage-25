"""Graphs service package.

This package contains the public service clients (`GraphsClient`, `GraphsClientSync`),
their domain models, and the wiring/gateway adapters used to talk to the RAI Direct
Access HTTP API that manages **RAI graph databases**.

Graph databases are the persistence primitive consumed by the Logic reasoner. They
are not exposed over Snowflake SQL — they live exclusively on the Direct Access
service endpoint — and so this service is **DA-only** by design. On non-DA
deployments `client.graphs` still resolves but raises `GraphsUnsupportedError` on
first use.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import GraphsClient as GraphsClient
    from .client_sync import GraphsClientSync as GraphsClientSync

__include_in_docs__ = True


def __getattr__(name: str) -> object:
    # Keep package import lightweight and avoid import cycles when callers import
    # submodules (e.g. `from relationalai.services.graphs.models import ...`).
    if name == "GraphsClient":
        from .client import GraphsClient as _GraphsClient

        return _GraphsClient
    if name == "GraphsClientSync":
        from .client_sync import GraphsClientSync as _GraphsClientSync

        return _GraphsClientSync
    raise AttributeError(name)


__all__ = ["GraphsClient", "GraphsClientSync"]
