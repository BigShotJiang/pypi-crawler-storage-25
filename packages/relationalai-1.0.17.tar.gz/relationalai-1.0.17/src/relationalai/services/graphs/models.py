"""Graphs domain models.

`Graph` is the stable public shape returned by the Graphs service. It corresponds
to an RAI graph database as exposed by the Direct Access API
(`GET /v1alpha1/databases`).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from relationalai.services._shared.datetime import coerce_datetime


@dataclass(frozen=True)
class Graph:
    """Metadata for a single RAI graph database."""

    name: str
    id: str | None = None
    state: str | None = None
    created_by: str | None = None
    created_on: datetime | None = None
    deleted_by: str | None = None
    deleted_on: datetime | None = None

    def __repr__(self) -> str:
        return f"Graph(name={self.name!r}, state={self.state!r})"


def _coerce_epoch_ms(val: Any) -> datetime | None:
    """Parse a DA timestamp which may be epoch-millis or an ISO string.

    Some RAI DA responses (notably the `/databases` endpoint) return `created_on` /
    `deleted_on` as epoch-millisecond integers, while others return ISO strings.
    `coerce_datetime` handles strings and datetimes; we handle integers here.
    """
    if val is None:
        return None
    if isinstance(val, (int, float)):
        try:
            from datetime import timezone

            return datetime.fromtimestamp(float(val) / 1000.0, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    return coerce_datetime(val)


def graph_from_da(payload: dict[str, Any]) -> Graph:
    """Build a `Graph` from the DA `/v1alpha1/databases` entry shape."""
    name = payload.get("name")
    if name is None:
        raise ValueError(f"Invalid graph payload (missing 'name'): {payload!r}")
    return Graph(
        name=str(name),
        id=payload.get("id"),
        state=payload.get("state"),
        created_by=payload.get("created_by"),
        created_on=_coerce_epoch_ms(payload.get("created_on")),
        deleted_by=payload.get("deleted_by"),
        deleted_on=_coerce_epoch_ms(payload.get("deleted_on")),
    )


__all__ = ["Graph", "graph_from_da"]
