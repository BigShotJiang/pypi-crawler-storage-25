"""Graphs package constants.

Graph databases are a Direct-Access-only primitive in v1. These constants cover
the DA URL surface and stable graph-state strings; there is no SQL schema because
the SQL backend does not expose graph CRUD.
"""

from __future__ import annotations

from typing import Final


GRAPHS_DA_BASE_PATH: Final[str] = "/v1alpha1/databases"
"""Base path of the RAI Direct Access databases API (a.k.a. graph databases)."""

RELEASE_INDEX_DA_PATH: Final[str] = "/v1alpha1/index/release"
"""DA endpoint used when deleting a graph while index-reuse is enabled."""


GRAPH_STATE_CREATED: Final[str] = "CREATED"
GRAPH_STATE_DELETED: Final[str] = "DELETED"
