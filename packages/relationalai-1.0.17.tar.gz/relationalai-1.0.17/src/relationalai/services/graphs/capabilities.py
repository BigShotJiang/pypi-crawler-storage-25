"""Direct Access capability registry for the Graphs service.

Mirrors `services/reasoners/capabilities.py`. Because graphs are DA-only in v1,
every capability here has `transport="http"` and none declare a SQL fallback.

The endpoint map intentionally matches v0's `DirectAccessClient.endpoints` entries
for `create_db`, `get_db`, `delete_db`, and `release_index`, so the server-side
contract is unchanged between v0 and v1.
"""

from __future__ import annotations

from typing import Final

from relationalai.services._shared.direct_access_capability import DirectAccessCapability

from . import constants as c


DA_CAPABILITIES: Final[dict[str, DirectAccessCapability]] = {
    # List & get use the same endpoint shape (/v1alpha1/databases) but with different
    # semantics: `list` returns all databases, `get` filters by `?name=<name>`.
    "list": DirectAccessCapability(
        "list",
        method="GET",
        endpoint=c.GRAPHS_DA_BASE_PATH,
    ),
    "get": DirectAccessCapability(
        "get",
        method="GET",
        endpoint=c.GRAPHS_DA_BASE_PATH,
        allow_404=True,
    ),
    # v0 uses POST /v1alpha1/databases with a JSON body of `{name, source_name}`.
    # `source_name` is empty for create-from-scratch and non-empty for clone.
    "create": DirectAccessCapability(
        "create",
        method="POST",
        endpoint=c.GRAPHS_DA_BASE_PATH,
    ),
    "clone": DirectAccessCapability(
        "clone",
        method="POST",
        endpoint=c.GRAPHS_DA_BASE_PATH,
    ),
    "delete": DirectAccessCapability(
        "delete",
        method="DELETE",
        endpoint=f"{c.GRAPHS_DA_BASE_PATH}/{{db_name}}",
    ),
    # `release_index` is used when index-reuse is enabled: the server keeps the DB
    # around and only releases the graph index. It lives on a different path.
    "release_index": DirectAccessCapability(
        "release_index",
        method="POST",
        endpoint=c.RELEASE_INDEX_DA_PATH,
    ),
}


def da_capability(operation: str) -> DirectAccessCapability:
    try:
        return DA_CAPABILITIES[operation]
    except KeyError as e:
        raise KeyError(f"Unknown graphs DA capability: {operation!r}") from e


def describe_direct_access_policy() -> str:
    return "Graphs: HTTP-only (list/get/create/clone/delete/release_index); no SQL fallback."


__all__ = ["DA_CAPABILITIES", "DirectAccessCapability", "da_capability", "describe_direct_access_policy"]
