"""
Direct access authentication validation for v1 config.

This module owns the canonical set of v1 authenticators that support direct
access and provides a reusable validation helper.

DA_SUPPORTED_AUTHENTICATORS is the single source of truth — both the
translator (v1_to_v0_translator.py) and the v1 wiring layer
(client/wiring/wiring.py) import from here.

When v0 executors are fully migrated, import validate_direct_access_auth
from here instead of from v1_to_v0_translator (which will be deleted).
"""

from typing import Any

from .config import Config

# v1 authenticator names (as written in raiconfig.yaml) that support direct access.
# Imported by client/wiring/wiring.py — do not duplicate.
DA_SUPPORTED_AUTHENTICATORS = frozenset({
    "jwt",
    "oauth_authorization_code",
    "programmatic_access_token",
})


def direct_access_auth_error_message(authenticator: Any) -> str:
    supported = ", ".join(sorted(DA_SUPPORTED_AUTHENTICATORS))
    return (
        "Direct Access backend requires a Snowflake connection with one of these authenticators: "
        f"{supported}. Got authenticator={authenticator!r}. "
        "Use `token=...` to bypass connection-based Direct Access auth middleware."
    )


def validate_direct_access_auth(config: Config) -> None:
    """
    Raise when `direct_access=True` uses an unsupported default authenticator.

    Args:
        config: V1 Config instance.
    """
    if not config.direct_access:
        return

    from .connections.snowflake import SnowflakeConnectionBase

    try:
        conn = config.get_default_connection()
    except Exception:
        return

    if not isinstance(conn, SnowflakeConnectionBase):
        return

    authenticator = getattr(conn, "authenticator", None)
    if authenticator in DA_SUPPORTED_AUTHENTICATORS:
        return

    from relationalai.auth import DirectAccessConfigError

    raise DirectAccessConfigError(direct_access_auth_error_message(authenticator))
