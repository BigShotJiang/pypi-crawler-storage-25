#include <pybind11/pybind11.h>
#include <pybind11/stl.h> // REQUIRED for std::vector conversion
#include "tensor.h"

namespace py = pybind11;

// 👑 THE SOVEREIGN MODULE MANIFESTATION
PYBIND11_MODULE(tensorkite_cpps, m) {
    m.doc() = "Tensorkite C++ Core: The Silicon Spirit of the Polarflow District";

    py::class_<Tensor>(m, "Tensor")
        .def(py::init<std::vector<int>, std::string>())
        .def("memory_tensor", &Tensor::memory_tensor)
        .def("print", &Tensor::print);
}