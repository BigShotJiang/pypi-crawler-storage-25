from setuptools import setup, Extension, find_packages
import pybind11
import os

cpp_extension = Extension(
    'tensorkite_cpps',
    sources=['main.cpp', 'tensor.cpp', 'tensorkite_core.cpp'],
    include_dirs=[
        pybind11.get_include(),
        '.', # 👑 LOOK IN THE CURRENT FOLDER
    ],
    language='c++'
)

setup(
    name="tensorkite-king",          
    version="1.1.0",                 # BUMP VERSION
    author="Sundaram Gupta",
    packages=find_packages(),        
    ext_modules=[cpp_extension],   
    licence="MIT",
    install_requires=["pybind11>=2.10.0"],
    # ... keep the rest the same
)