#include <iostream>
#include <vector>
#include <string>
#include <algorithm> // For std::fill
#include <cstring>   // For std::memset

// 🛡️ The Placeholder Class (Internal Logic)
class Placeholder {
public:
    std::string name;
    std::vector<int> shape;
    Placeholder(std::string n, std::vector<int> s) : name(n), shape(s) {}
};

extern "C" {
    // ☀️ THE SOLAR INITIALIZER: Fills memory with 1.0f
    // This is the Spirit Bomb of Tensorkite.
    void ones_initializer(float* buffer, size_t size) {
        std::fill(buffer, buffer + size, 1.0f);
    }

    // 🌑 THE VOID INITIALIZER: Fills memory with 0.0f
    // Total Eradication of the buffer.
    void zeros_initializer(float* buffer, size_t size) {
        std::memset(buffer, 0, size * sizeof(float));
    }
}