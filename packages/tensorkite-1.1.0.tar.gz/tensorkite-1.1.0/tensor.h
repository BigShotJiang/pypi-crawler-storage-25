#ifndef TENSOR_H
#define TENSOR_H

#include <windows.h>
#include <vector>
#include <string>

class Tensor {
public:
    std::vector<int> shape;
    std::string name;
    
    // THE ORIGINAL MEMORY TENSOR ENGINES
    float* m_ptr;
    HANDLE hFile;
    HANDLE hMapping;
    size_t vault_size;

    Tensor(std::vector<int> s, std::string n);
    ~Tensor(); // The Destroyer: Cleans the Vault

    void memory_tensor(const std::string& filepath);
    void print();
};

#endif