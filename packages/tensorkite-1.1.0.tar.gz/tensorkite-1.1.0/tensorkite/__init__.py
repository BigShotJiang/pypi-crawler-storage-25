import os
import mmap
import array
import os
import sys
import subprocess
import importlib.util

# THE VARIABLES (The Class)
class Tensor:
    def __init__(self, buffer, shape, name):
        # High-Level: Points to binary bits
        self.data = memoryview(buffer).cast('f') 
        self.shape = shape
        self.name = name

    def __repr__(self):
        return f"Tensor(name={self.name}, shape={self.shape}, engine=tensorkite_mmap)"

# This line pulls the function and variables from memory.py to the front
from .memory import Engine,Tensor

# tensorkite/__init__.py
try:
    # Import the compiled binary from the local folder
    from . import tensorkite_core
except ImportError:
    print("❌ ERROR: Run 'pip install -e .' to compile the C++ core!")
    raise

# Expose it at the top level
Placeholder = tensorkite_core.Placeholder

def placeholder(name="", shape=None):
    """
    Allocates a named entry point for the Tensorkite Graph.
    Build your jawline, not your failine! 💀
    """
    if shape is None:
        shape = []
    return Placeholder(name=name, shape=shape)



# 1. PATH DISCOVERY: Find where the Tensorkite folder actually lives
_pkg_dir = os.path.dirname(os.path.abspath(__file__))
_cpp_src = os.path.join(_pkg_dir, "core.cpp")
_binary_name = "tensorkite_core"
_ext = ".pyd" if os.name == "nt" else ".so"
_binary_path = os.path.join(_pkg_dir, f"{_binary_name}{_ext}")

# 2. AUTO-COMPILER: Build the jawline if the binary is missing or old
def _build_metal():
    if not os.path.exists(_binary_path) or os.path.getmtime(_cpp_src) > os.path.getmtime(_binary_path):
        print(f"💀 [Tensorkite] Forging C++ Core at {_binary_path}...")
        
        import pybind11
        # Detect Python and Pybind11 includes
        inc_py = sys.prefix + "/include"
        inc_pb = pybind11.get_include()
        
        # Command for G++ (Works on Windows with MinGW/MSYS2 or Linux/Mac)
        cmd = [
            "g++", "-O3", "-shared", "-std=c++11", "-fPIC",
            f"-I{inc_py}", f"-I{inc_pb}",
            _cpp_src, "-o", _binary_path
        ]
        
        try:
            subprocess.check_call(cmd)
            print("📈 [Tensorkite] Core Compiled. Aura: INFINITE.")
        except Exception as e:
            print(f"📉 [Failine] Compilation Error. Ensure g++ is in your PATH. \n{e}")
            raise

# Execute build
_build_metal()

# 3. GLOBAL LINK: Load the binary into the namespace
spec = importlib.util.spec_from_file_location(_binary_name, _binary_path)
_core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_core)

# 4. EXPOSE: Make it available to any .py file
Placeholder = _core.Placeholder

def placeholder(name="", shape=None):
    if shape is None: shape = []
    return Placeholder(name=name, shape=shape)