#include "tensor.h"
#include <iostream>

Tensor::Tensor(std::vector<int> s, std::string n) 
    : shape(s), name(n), m_ptr(nullptr), hFile(INVALID_HANDLE_VALUE), hMapping(NULL) {
    
    size_t elements = 1;
    for(int dim : s) elements *= dim;
    this->vault_size = elements * sizeof(float);
}

void Tensor::memory_tensor(const std::string& filepath) {
    hFile = CreateFileA(filepath.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    hMapping = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, (DWORD)vault_size, NULL);
    m_ptr = (float*)MapViewOfFile(hMapping, FILE_MAP_ALL_ACCESS, 0, 0, vault_size);
    
    if (m_ptr) std::cout << "--- 🛰️ VAULT MAPPED: " << filepath << " ---" << std::endl;
}

void Tensor::print() {
    std::cout << "--- 🏆 THE KING'S MEMORY: " << name << " ---" << std::endl;
}

Tensor::~Tensor() {
    if (m_ptr) UnmapViewOfFile(m_ptr);
    if (hMapping) CloseHandle(hMapping);
    if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);
}