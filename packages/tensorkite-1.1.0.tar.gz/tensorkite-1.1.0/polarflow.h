#ifndef POLARFLOW_H
#define POLARFLOW_H

#include <windows.h>
#include <iostream>
#include <string>
#include <vector>

class Tensor {
public:
    float* data;      // Pointer to binary bits on disk
    size_t size;      // Number of elements
    HANDLE hFile;     // Windows File Handle
    HANDLE hMap;      // Mapping Handle

    // Constructor: Sets up the memory link
    Tensor(float* d, size_t s, HANDLE hf, HANDLE hm) 
        : data(d), size(s), hFile(hf), hMap(hm) {}

    // Destructor: Automatically closes the file when the program stops
    ~Tensor() {
        if (data) UnmapViewOfFile(data);
        if (hMap) CloseHandle(hMap);
        if (hFile) CloseHandle(hFile);
    }

    void info() {
        std::cout << "--- PolarFlow METM Active ---" << std::endl;
        std::cout << "Elements: " << size << " | Memory Address: " << data << std::endl;
    }
};

// The C++ MemoryTensor Function
Tensor* memorytensor(std::string word, std::vector<float> data = {}) {
    std::string filename = word + ".tk";
    
    // 1. Open the file (Read/Write mode)
    HANDLE hFile = CreateFileA(filename.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, 
                               OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE) {
        std::cerr << "Error: Could not open " << filename << std::endl;
        return nullptr;
    }

    // 2. If it's a new file, write the initial data
    if (GetLastError() != ERROR_ALREADY_EXISTS && !data.empty()) {
        DWORD bytesWritten;
        WriteFile(hFile, data.data(), (DWORD)(data.size() * sizeof(float)), &bytesWritten, NULL);
    }

    // 3. Get current file size
    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == 0) { CloseHandle(hFile); return nullptr; }

    // 4. Create the "Mapping Tunnel"
    HANDLE hMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
    if (!hMap) { CloseHandle(hFile); return nullptr; }

    // 5. Point the 'data' pointer to the file bits
    float* mappedData = (float*)MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);
    
    return new Tensor(mappedData, fileSize / sizeof(float), hFile, hMap);
}

#endif