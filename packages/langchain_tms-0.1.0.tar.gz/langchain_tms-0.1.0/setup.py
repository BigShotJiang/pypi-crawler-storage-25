from setuptools import setup, find_packages

setup(
    name="langchain-TMS",
    version="0.1.0",
    author="Tumus Garuru",
    author_email="114514@google.com",
    description="A security checker for LangChain variables",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)