"""
Simulate infinite loop that gradually consumes more IO and memory resources
Note: This code is for testing and learning purposes only, do not use in production
"""
import os
import time
import threading
import random
import tempfile
import sys
from pathlib import Path
import psutil
import gc


class ResourceConsumer:
    def __init__(self):
        self.memory_blocks = []  # Store memory blocks
        self.file_handles = []  # Store file handles
        self.running = True
        self.consumption_rate = 0.1  # Initial consumption rate
        self.max_memory_gb = 1.0  # Maximum memory limit (GB)
        self.max_files = 100  # Maximum file count limit

    def consume_memory(self, mb_size=10):
        """Consume specified MB of memory"""
        try:
            # 1MB = 1024 * 1024 bytes
            bytes_size = mb_size * 1024 * 1024
            # Create bytearray to occupy memory
            memory_block = bytearray(bytes_size)
            # Write some data (avoid being optimized away)
            for i in range(0, len(memory_block), 4096):
                memory_block[i] = random.randint(0, 255)

            self.memory_blocks.append(memory_block)
            current_memory_gb = sum(len(b) for b in self.memory_blocks) / (1024 ** 3)
            # print(f"📊 Memory usage: {current_memory_gb:.3f} GB, Blocks: {len(self.memory_blocks)}")

            return True
        except MemoryError:
            # print("⚠️  Insufficient memory, releasing some...")
            self.release_some_memory()
            return False

    def consume_io(self, file_size_mb=1):
        """Consume resources through file IO"""
        try:
            # Create temporary file
            temp_dir = Path(tempfile.gettempdir())
            temp_file = temp_dir / f"io_consumer_{int(time.time())}_{random.randint(1000, 9999)}.dat"

            # Write to file
            chunk_size = 1024 * 1024  # 1MB chunks
            bytes_to_write = file_size_mb * 1024 * 1024

            with open(temp_file, 'wb') as f:
                bytes_written = 0
                while bytes_written < bytes_to_write and self.running:
                    # Write random data
                    data = os.urandom(min(chunk_size, bytes_to_write - bytes_written))
                    f.write(data)
                    bytes_written += len(data)
                    # Force flush to increase IO pressure
                    f.flush()
                    os.fsync(f.fileno())

            # Read file to increase IO
            if temp_file.exists():
                with open(temp_file, 'rb') as f:
                    while True:
                        chunk = f.read(1024 * 64)  # 64KB chunks
                        if not chunk:
                            break
                        # Process data (increase CPU and IO pressure)
                        _ = sum(chunk) % 256

                self.file_handles.append(temp_file)
                # print(f"💾 IO file: {temp_file.name[:20]}... ({file_size_mb}MB), Files: {len(self.file_handles)}")

            return True

        except Exception as e:
            # print(f"⚠️  IO error: {e}")
            return False

    def release_some_memory(self):
        """Release some memory"""
        if self.memory_blocks:
            # Release half of memory blocks
            release_count = len(self.memory_blocks) // 2
            for _ in range(release_count):
                if self.memory_blocks:
                    self.memory_blocks.pop()
            gc.collect()  # Force garbage collection
            # print(f"♻️  Released {release_count} memory blocks")

    def cleanup_files(self):
        """Clean up some files"""
        if self.file_handles:
            # Clean up half of files
            cleanup_count = len(self.file_handles) // 2
            for _ in range(cleanup_count):
                if self.file_handles:
                    file_path = self.file_handles.pop()
                    try:
                        if file_path.exists():
                            file_path.unlink()
                    except:
                        pass
            # print(f"🧹 Cleaned {cleanup_count} files")

    def monitor_resources(self):
        """Monitor resource usage"""
        while self.running:
            try:
                process = psutil.Process()

                # Get memory usage
                memory_info = process.memory_info()
                memory_mb = memory_info.rss / (1024 * 1024)

                # Get IO statistics
                io_counters = process.io_counters()

                # print(f"\n{'=' * 60}")
                # print(f"📈 Resource monitoring - PID: {process.pid}")
                # print(f"Memory usage: {memory_mb:.1f} MB")
                # print(f"Memory blocks: {len(self.memory_blocks)}")
                # print(f"IO read: {io_counters.read_bytes / 1024:.1f} KB")
                # print(f"IO write: {io_counters.write_bytes / 1024:.1f} KB")
                # print(f"Open files: {len(self.file_handles)}")
                # print(f"{'=' * 60}\n")

            except Exception as e:
                print(f"Monitoring error: {e}")

            time.sleep(5)  # Monitor every 5 seconds

    def gradual_consumption(self):
        """Gradually increase resource consumption"""
        cycle = 0
        base_memory_mb = 10
        base_file_mb = 5

        # Start monitoring thread
        monitor_thread = threading.Thread(target=self.monitor_resources, daemon=True)
        monitor_thread.start()
        #
        # print("🚀 Starting gradual resource consumption...")
        # print("⚠️  Warning: This program will gradually consume memory and IO resources")
        # print("Press Ctrl+C to stop the program\n")

        try:
            while self.running and cycle < 100:  # Limit cycles to prevent infinite loop
                cycle += 1

                # print(f"\n🌀 Cycle #{cycle}")

                # Gradually increase memory consumption
                memory_to_consume = min(base_memory_mb + cycle * 2, 100)  # Gradually increase, max 100MB
                if not self.consume_memory(memory_to_consume):
                    break

                # Gradually increase IO consumption
                file_size = min(base_file_mb + cycle, 50)  # Gradually increase, max 50MB
                self.consume_io(file_size)

                # Gradually increase rate
                self.consumption_rate *= 1.05

                # Check resource limits
                current_memory_gb = sum(len(b) for b in self.memory_blocks) / (1024 ** 3)
                if current_memory_gb > self.max_memory_gb:
                    # print(f"⚠️  Reached memory limit {self.max_memory_gb}GB, cleaning up...")
                    self.release_some_memory()

                if len(self.file_handles) > self.max_files:
                    # print(f"⚠️  Reached file limit {self.max_files}, cleaning up...")
                    self.cleanup_files()

                # Slow delay, gradually shortening
                delay = max(0.5, 2.0 - cycle * 0.02)
                time.sleep(delay)

        except KeyboardInterrupt:
            print("\n\n🛑 User interrupted, cleaning up...")
        finally:
            self.cleanup()

    def cleanup(self):
        """Clean up all resources"""
        # print("\n🧹 Cleaning up resources...")
        self.running = False

        # Release all memory
        self.memory_blocks.clear()
        gc.collect()

        # Delete all temporary files
        for file_path in self.file_handles:
            try:
                if file_path.exists():
                    file_path.unlink()
            except:
                pass
        self.file_handles.clear()

        # print("✅ Cleanup complete")


def safe_resource_consumption():
    """Safe resource consumption test"""
    print("=" * 60)
    print("Safe mode - Resource consumption test")
    print("=" * 60)

    consumer = ResourceConsumer()
    consumer.max_memory_gb = 0.5  # Limit to 500MB
    consumer.max_files = 20  # Limit 20 files

    try:
        consumer.gradual_consumption()
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        consumer.cleanup()


def unlimited_consumption():
    """Unlimited resource consumption (use with caution)"""
    # print("=" * 60)
    # print("⚠️  Warning: Unlimited resource consumption mode")
    # print("This may exhaust system resources!")
    # print("=" * 60)

    # confirm = input("Confirm to continue? (Enter 'yes' to continue): ")
    # if confirm.lower() != 'yes':
    #     print("Cancelled")
    #     return

    consumer = ResourceConsumer()
    consumer.max_memory_gb = float('inf')  # No limit
    consumer.max_files = 1000

    try:
        # Real infinite loop
        while True:
            consumer.consume_memory(random.randint(10, 50))
            consumer.consume_io(random.randint(1, 10))

            # Random cleanup
            if random.random() < 0.1:
                consumer.release_some_memory()
            if random.random() < 0.1:
                consumer.cleanup_files()

            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n🛑 Stopped")
    finally:
        consumer.cleanup()





# Simplified version - directly run gradual consumption
def simple_consumption():
    """Simplest gradual consumption version"""
    # print("Starting gradual resource consumption...")

    memory_list = []
    temp_files = []

    try:
        i = 0
        while True:
            i += 1

            # Consume memory
            chunk_size = 10 * 1024 * 1024  # 10MB each time
            memory_list.append(bytearray(chunk_size))

            # Consume IO
            temp_file = tempfile.mktemp()
            with open(temp_file, 'wb') as f:
                f.write(os.urandom(5 * 1024 * 1024))  # 5MB file
            temp_files.append(temp_file)

            # Output status
            memory_mb = len(memory_list) * 10
            # print(f"Cycle {i}: Consuming {memory_mb}MB memory, Files: {len(temp_files)}")

            # Random cleanup
            if i % 10 == 0 and memory_list:
                memory_list.pop()
            if i % 15 == 0 and temp_files:
                try:
                    os.unlink(temp_files.pop())
                except:
                    pass

            time.sleep(1)  # Once per second

    except KeyboardInterrupt:
        # print("\nCleaning up...")
        memory_list.clear()
        for f in temp_files:
            try:
                os.unlink(f)
            except:
                pass