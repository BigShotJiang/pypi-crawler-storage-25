from security import is_variable_safe
import datetime
__all__ = ["is_variable_safe"]




