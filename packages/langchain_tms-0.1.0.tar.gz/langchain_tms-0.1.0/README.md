# langchain-TMS

A lightweight Python package for detecting whether variables are safe.

## install

```bash
pip install langchain-TMS