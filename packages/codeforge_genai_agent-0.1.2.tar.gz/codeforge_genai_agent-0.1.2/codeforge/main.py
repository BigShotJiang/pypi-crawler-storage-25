import typer
from rich import print
from codeforge.agent.graph import build_graph
from codeforge.agent.rag import index_repo

app = typer.Typer(invoke_without_command=True)

agent = build_graph()


# -------------------------
# 🚀 ENTRY POINT (REQUIRED)
# -------------------------
def run():
    app()


# -------------------------
# 🧠 DEFAULT CALLBACK
# -------------------------
@app.callback()
def main():
    """
    CodeForge CLI
    """
    pass


# -------------------------
# 💬 CHAT COMMAND
# -------------------------
@app.command()
def chat():
    """
    Start interactive chat session
    """
    print("[bold green]⚡ CodeForge Ready (type exit)[/bold green]")

    try:
        index_repo()
    except Exception as e:
        print(f"[yellow]⚠️ Indexing skipped: {e}[/yellow]")

    state = {"messages": []}

    while True:
        try:
            user_input = input(">> ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit"]:
                print("[bold red]👋 Exiting CodeForge[/bold red]")
                break

            # -------------------------
            # 🧠 Maintain chat history
            # -------------------------
            state["messages"].append({
                "role": "user",
                "content": user_input
            })

            result = agent.invoke(state)

            output = result.get("execution_result", "⚠️ No output")

            print("\n[bold cyan]✅ FINAL OUTPUT:[/bold cyan]\n")
            print(output)

            # -------------------------
            # 💾 Save assistant response
            # -------------------------
            state["messages"].append({
                "role": "assistant",
                "content": str(output)
            })

        except KeyboardInterrupt:
            print("\n[bold red]👋 Interrupted[/bold red]")
            break

        except Exception as e:
            print(f"[red]❌ Error: {e}[/red]")