from __future__ import annotations
from core.types import Phase


class Scheduler:
    EVAL_ROLES = [
        {"name": "code_reviewer", "agent_type": "kanban-code-reviewer"},
        {"name": "qa", "agent_type": "kanban-qa"},
        {"name": "pm", "agent_type": "kanban-pm"},
        {"name": "designer", "agent_type": "kanban-designer"},
    ]

    PLAN_REVIEW_DIMENSIONS = [
        {"name": "requirement_clarity", "agent_type": "kanban-plan-reviewer"},
        {"name": "technical_feasibility", "agent_type": "kanban-plan-reviewer"},
        {"name": "task_decomposition", "agent_type": "kanban-plan-reviewer"},
        {"name": "acceptance_criteria", "agent_type": "kanban-plan-reviewer"},
        {"name": "research_completeness", "agent_type": "kanban-plan-reviewer"},
        {"name": "parallel_safety", "agent_type": "kanban-plan-reviewer"},
    ]

    RETROSPECTIVE_ROLES = [
        {"name": "retrospective_writer", "agent_type": "kanban-knowledge-manager"},
        {"name": "acceptance_writer", "agent_type": "kanban-knowledge-manager"},
        {"name": "knowledge_extractor", "agent_type": "kanban-knowledge-manager"},
    ]

    @staticmethod
    def scan_agents(fs) -> list[dict]:
        """Scan .claude/agents/ directory for agent definitions."""
        agents_dir = fs.kanban_dir.parent / ".claude" / "agents"
        if not agents_dir.exists() or not agents_dir.is_dir():
            return []
        agents = []
        for f in sorted(agents_dir.glob("*.md")):
            name = f.stem
            agents.append({"name": name, "file": str(f)})
        return agents

    PHASE_ORDER = [
        Phase.PLAN,
        Phase.PLAN_REVIEW,
        Phase.QA_SPEC,
        Phase.SPEC_REVIEW,
        Phase.EXECUTE,
        Phase.EVALUATE,
        Phase.RETROSPECTIVE,
        Phase.USER_DECISION,
        Phase.ARCHIVE,
    ]

    LIGHTWEIGHT_PHASE_ORDER = [
        Phase.PLAN,
        Phase.EXECUTE,
        Phase.EVALUATE,
        Phase.USER_DECISION,
        Phase.ARCHIVE,
    ]

    LIGHTWEIGHT_EVAL_ROLES = [
        {"name": "qa", "agent_type": "kanban-qa"},
    ]

    @classmethod
    def eval_roles(cls, lightweight: bool = False) -> list[dict]:
        if lightweight:
            return list(cls.LIGHTWEIGHT_EVAL_ROLES)
        return list(cls.EVAL_ROLES)

    @classmethod
    def plan_review_dimensions(cls) -> list[dict]:
        return list(cls.PLAN_REVIEW_DIMENSIONS)

    @classmethod
    def retrospective_roles(cls, lightweight: bool = False) -> list[dict]:
        if lightweight:
            return [{"name": "acceptance_writer", "agent_type": "kanban-knowledge-manager"}]
        return list(cls.RETROSPECTIVE_ROLES)

    @classmethod
    def dispatch_order(cls, lightweight: bool = False) -> list[Phase]:
        if lightweight:
            return list(cls.LIGHTWEIGHT_PHASE_ORDER)
        return list(cls.PHASE_ORDER)

    @classmethod
    def next_phase(cls, current: Phase, lightweight: bool = False) -> Phase | None:
        order = cls.LIGHTWEIGHT_PHASE_ORDER if lightweight else cls.PHASE_ORDER
        try:
            idx = order.index(current)
            return order[idx + 1]
        except (ValueError, IndexError):
            return None

    @classmethod
    def previous_phase(cls, current: Phase, lightweight: bool = False) -> Phase | None:
        order = cls.LIGHTWEIGHT_PHASE_ORDER if lightweight else cls.PHASE_ORDER
        try:
            idx = order.index(current)
            if idx > 0:
                return order[idx - 1]
        except ValueError:
            pass
        return None

    @staticmethod
    def compute_parallel_batches(subtasks: list[dict]) -> list[list[dict]]:
        """Group subtasks into parallel batches by dependency topology.

        Two subtasks can run in parallel ONLY if:
        - Neither depends on the other
        - Their file_ownership sets have zero overlap
        - Both have parallelizable=true (or are forced into parallel)

        Returns list of batches, each batch is a list of subtask dicts.
        """
        remaining = {s["id"]: s for s in subtasks}
        completed: set[str] = set()
        batches: list[list[dict]] = []

        while remaining:
            batch = []
            for sid, st in list(remaining.items()):
                deps = set(st.get("dependencies", []))
                # All dependencies must be in completed
                if not deps.issubset(completed):
                    continue
                # Check file ownership conflicts with current batch
                my_files = set(st.get("file_ownership", []))
                conflict = any(
                    my_files & set(b.get("file_ownership", []))
                    for b in batch
                )
                if conflict:
                    continue
                batch.append(st)
                del remaining[sid]

            if not batch:
                # Deadlock: circular dependency or conflict. Force sequential.
                first = min(remaining.values(),
                           key=lambda s: len(s.get("dependencies", [])))
                batch = [first]
                del remaining[first["id"]]

            batches.append(batch)
            completed.update(s["id"] for s in batch)

        return batches
