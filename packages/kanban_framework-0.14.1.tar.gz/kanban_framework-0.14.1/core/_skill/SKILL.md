---
name: kanban
description: "使用 /kanban 命令管理看板任务的全生命周期：初始化看板、创建 TASK-NNN 任务、执行阶段（plan/execute/evaluate）、归档完成、查看状态/进度、恢复中断任务、多迭代工作流。当用户提到 kanban、看板、TASK-NNN、/kanban 命令、任务创建/归档/恢复、或任何看板任务管理意图时使用此技能。"
---

# Kanban 多 Agent 编排系统

基于 FSM 的任务编排框架。

## 命令约定

优先检测 `kanban` CLI（pip 安装），不可用时回退 `python3 -m core`（需 PYTHONPATH）。

## 命令路由

**精确命令** 直接匹配，**自然语言** 通过 `kanban nlp` 解析后路由。路由规则：

| 意图 | 条件 | 路由 |
|------|------|------|
| `work` | 无 task_id | 先 `create` 再 `run` |
| `work` | 有 task_id | `run` |
| `query` | 含查询动词 | `status` / `show` |

**硬性约束：** `intent == "work"` 时禁止直接执行，必须先创建任务。

### 常用命令

```
/kanban init                        # 初始化
/kanban create "<title>"            # 创建任务（自动推荐模式）
/kanban task edit <id> --mode full  # 切换模式
/kanban run <id>                    # 执行当前阶段
/kanban status                      # 看板状态
/kanban show <id>                   # 任务详情
/kanban decide <id> --action <act>  # 用户决策（approve_and_archive/abort/restart_from_plan/restart_from_execute）
/kanban time <id>                   # 耗时追踪
/kanban tokens <id>                 # Token 追踪
/kanban knowledge search <kw>       # 搜索知识库
/kanban knowledge semantic <query>  # 语义搜索
/kanban knowledge hybrid <query>    # 混合搜索
/kanban clean <id>|--all            # 清理归档任务
/kanban recover [<id>]              # 崩溃恢复
```

---

## FSM 阶段流转

```
Plan A (brainstorming) → Plan B (writing-plans) → Plan Review → QA Spec → Spec Review → 测试确认 → Execute → Evaluate → 自迭代 → Retrospective → User Decision → Archive
```

| 阶段 | 动作 | 产出 | 人 |
|------|------|------|-----|
| **Plan A** | brainstorming 需求澄清 | spec.md | — |
| **Plan B** | writing-plans 任务拆解 | plan/index.md + plan/ST-NNN_{slug}.md + task_breakdown.json | **确认 spec.md** |
| **Plan Review** | 6 维评审（多轮用 _r1/_r2 保留历史） | reviews/plan_review_report.json | — |
| **QA Spec** | kanban-qa subagent | test_spec.md（任务级） | — |
| **Spec Review** | kanban-test-spec-reviewer 评审 | reviews/spec_review_report.json | — |
| **测试确认** | — | — | **approve / revise** |
| **Execute** | 多 executor 按依赖拓扑并行 TDD | execute/execution_summary/pitfalls/decisions | — |
| **Evaluate** | 4 角色并行评审（轻量模式 QA only） | reviews/{role}_report.json | — |
| **自迭代** | score >= 8.0 → 继续；< 8.0 → Hot(回Execute) 或 Full(回Plan) | — | **达上限时介入** |
| **Retrospective** | 复盘 + 知识提取 + 时间/Token 追加 | retrospective.md, acceptance.md | — |
| **User Decision** | — | — | **approve_and_archive / abort / restart** |
| **Archive** | merge worktree + 清理 | archive/TASK-NNN/ | — |

**轻量模式：** Plan → Execute → Evaluate(QA only) → Archive。跳过系统评审但不跳过人工决策。

---

## 编排器清单

编排器在每个阶段转换前逐项核对。

> **上下文压缩后先恢复状态：** `kanban show "$task_id" --json` 读取 `phase` + `history`，从磁盘判断当前进度，不凭记忆。

### Plan 阶段关键步骤

Plan 阶段包含两个子步骤（A+B），**每个子步骤必须独立追踪状态并记录耗时**。

```
# ── Plan A: 需求澄清 ──
kanban knowledge hybrid "<title> <desc>"     # Step 0: 知识库检索（强制）
kanban time start "$task_id" plan_A          # 记录 Plan A 开始
spawn brainstorming agent → 产出 spec.md     # Skill("superpowers:brainstorming")
kanban time end "$task_id" plan_A            # 记录 Plan A 结束
→ 展示 spec.md 给用户确认

# ── Plan B: 任务拆解 ──
kanban time start "$task_id" plan_B          # 记录 Plan B 开始
spawn writing-plans agent → 产出 plan/index.md + plan/ST-NNN_*.md + task_breakdown.json
kanban time end "$task_id" plan_B            # 记录 Plan B 结束

# ── Plan 完成 ──
kanban time end "$task_id" plan              # 结束整个 Plan 阶段
→ 用户确认 spec.md 后进入 Plan Review
```

**禁止行为：**
- 禁止将 Plan A 和 Plan B 合并为一个 agent 调用
- 禁止跳过 Plan A 直接执行 Plan B（IR-16）
- 禁止在 Plan A 未产出 spec.md 时启动 Plan B

### 通用步骤

```
1. kanban show "$task_id" --json             # 解析路径变量
2. kanban workflow transition "$task_id" <phase>
3. kanban time start "$task_id" <phase>      # 自动计时
4. kanban workflow get-phase-agents "<phase>"
5. spawn agents（注入 $KANBAN_DIR, $task_dir, $report_dir, $iteration, $task_id）
6. kanban time end "$task_id" <phase>
7. kanban guard check-artifacts "$task_id" <phase>
8. kanban workflow complete-phase "$task_id"
```

### Execute 阶段特殊处理

**每个 subtask 必须使用独立 agent 执行**（即使是串行任务）。避免单个 agent 上下文膨胀。

按依赖拓扑分批，同批内 `run_in_background=true` 并行调度：

```
kanban -c "from core.infra.scheduler import Scheduler; ..."
# → 每批 spawn N 个 executor(subtask_id=ST-NNN, plan_file=plan/ST-NNN_slug.md)
#   串行 batch 也每个 subtask 独立 spawn，不合并为一个 agent
```

`file_ownership` 有交集或 `dependencies` 未满足 → 不能同批。

### Plan → Plan Review

- [ ] **Plan A 已完成**: brainstorming agent 产出 spec.md，耗时已记录
- [ ] **知识库已检索**: `kanban knowledge hybrid` 已执行
- [ ] **Plan B 已完成**: writing-plans agent 产出 plan/index.md + plan/ST-NNN_*.md + task_breakdown.json
- [ ] `kanban time end plan` 已调用，Plan 阶段耗时已闭合
- [ ] 用户已确认 spec.md 内容

### Plan Review → QA Spec

- [ ] reviews/plan_review_report.json（或多轮 _r1/_r2）已产出
- [ ] 总分 >= pass_threshold，不达标修订重试（最多 max_rounds 轮）

### QA Spec → Spec Review

- [ ] test_spec.md 由 kanban-qa subagent 产出（禁止编排器自行生成）
- [ ] reviews/spec_review_report.json 由 kanban-test-spec-reviewer subagent 产出

### Spec Review → Execute

- [ ] 总分 >= pass_threshold
- [ ] **用户确认测试用例**：展示 review 摘要 + test_spec.md 关键内容，approve / revise

### Execute → Evaluate

- [ ] 所有 subtask 已完成 + git commit
- [ ] execute/execution_summary.md 含 TDD 证据表格（每行 RED=Fail）
- [ ] guard check-artifacts execute 返回 pass

### Evaluate → 自迭代（禁止询问用户）

- [ ] reviews/ 下 4 角色报告全部产出
- [ ] self-improve-check 已执行
  - all_pass → Retrospective
  - max_reached → Retrospective → User Decision
  - hot（>= 7.0）→ 自动回 Execute
  - full（< 7.0）→ 自动回 Plan

### Retrospective → Archive

- [ ] retrospective.md + acceptance.md 已产出
- [ ] 知识条目 >= 1 条
- [ ] inbox.md 待处理为空
- [ ] 用户显式 approve_and_archive（禁止自动归档）

---

## 编排红线

| 想法 | 为什么错 |
|------|---------|
| "小改动，不用看板" | IR-12：所有代码修改走 Plan → Execute → Evaluate |
| "代码写完了，直接评估" | Execute 产物不全，Guard 阻止 |
| "评分低但让用户看看" | IR-17：禁止询问，必须自动 hot/full |
| "我自己写 test_spec 更快" | 必须调度 kanban-qa subagent |
| "不确当前状态，先继续" | 先读 task.json → progress.json → status |
| "阈值我记得是 7.0" | 从 workflow.json 读取，禁止硬编码 |

---

## 路径变量

编排器 spawn agent 时注入：

| 变量 | 规则 | 示例 |
|------|------|------|
| `$KANBAN_DIR` | `.kanban/` | `.kanban/` |
| `$task_dir` | `$KANBAN_DIR/tasks/{task_id}/` | `.kanban/tasks/TASK-042/` |
| `$report_dir` | `$task_dir/iteration-{N}/` | `.kanban/tasks/TASK-042/iteration-1/` |
| `$iteration` | task.json iteration 字段 | `1` |
| `$task_id` | 任务 ID | `TASK-042` |

## 产物目录

```
.kanban/
  config.json / workflow.json / next_id.txt
  tasks/TASK-NNN/
    task.json                    # 含 assessment, test_config, mode
    inbox.md
    spec.md                     # 任务级
    plan/
      index.md                  # 总览
      ST-NNN_{slug}.md          # 每 subtask 独立 plan
    task_breakdown.json
    test_spec.md                # 任务级，不随迭代变化
    retrospective.md            # 含时间/Token 消耗
    iteration-1/
      reviews/                  # 评审报告
        plan_review_report.json （多轮: _r1, _r2 ...）
        spec_review_report.json
        code_reviewer_report.json / qa_report.json / pm_report.json / designer_report.json
      execute/                  # 执行产物
        execution_summary.md / execution_pitfalls.md / execution_decisions.md
  archive/TASK-NNN/
```

- Plan: `{task_dir}/spec.md`, `{task_dir}/plan/index.md`, `{task_dir}/task_breakdown.json`
- QA Spec: `{task_dir}/test_spec.md`
- Execute: `{iteration_dir}/execute/execution_*.md`
- Evaluate: `{iteration_dir}/reviews/{role}_report.json`
- Guard `_check_file` 兼容旧格式（平铺在 iteration-N/ 下）

---

## Agent 调度

每阶段 agent 从 `kanban workflow get-phase-agents "<phase>"` 获取。Evaluate 4 角色 `run_in_background=true` 并行。自定义 agent 通过 workflow.json 的 `agent_file` 字段配置。

## 上下文压缩恢复

kanban skill 只在 `/kanban` 调用时加载，非 kanban 会话不受影响。压缩后恢复：

```
kanban show "$task_id" --json | jq '{phase, history, iteration, lightweight}'
```

从此输出推断当前步骤：
- `phase=plan` 且无 plan_A 完成 → 从 Plan A 开始
- `phase=plan` 且 plan_A 完成无 plan_B → 从 Plan B 开始
- `phase=execute` → 继续 Execute

**关键原则：** 磁盘是真相源，不凭记忆。
