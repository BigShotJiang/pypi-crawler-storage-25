"""State machine driver for kanban workflow orchestration.

Instead of the orchestrator remembering the full FSM, it calls
`next_step(task_id)` and receives precise instructions for what to do next.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.types import Task, Phase
from core.infra.filesystem import Filesystem
from core.infra.config import Config
from core.infra.scheduler import Scheduler


@dataclass
class StepDef:
    id: str
    description: str
    actions: list[str] = field(default_factory=list)
    agent_type: Optional[str] = None
    parallel: bool = False
    user_action: bool = False  # requires human interaction


# ── Step definitions per phase ──────────────────────────────────────────

FULL_STEPS: dict[str, list[StepDef]] = {
    "plan": [
        StepDef("plan.knowledge_search", "知识库检索",
                actions=["kanban knowledge hybrid \"<title> <desc>\""]),
        StepDef("plan.plan_A", "Plan A: 需求澄清（brainstorming）",
                actions=["kanban time start $task_id plan_A",
                         "spawn brainstorming agent (superpowers:brainstorming)",
                         "kanban time end $task_id plan_A"],
                agent_type="kanban-planner"),
        StepDef("plan.user_confirm_spec", "用户确认 spec.md",
                actions=["展示 spec.md 内容给用户确认"],
                user_action=True),
        StepDef("plan.plan_B", "Plan B: 任务拆解（writing-plans）",
                actions=["kanban time start $task_id plan_B",
                         "spawn writing-plans agent (superpowers:writing-plans)",
                         "kanban time end $task_id plan_B"],
                agent_type="kanban-planner"),
        StepDef("plan.complete", "Plan 阶段完成",
                actions=["kanban time end $task_id plan",
                         "kanban guard check-artifacts $task_id plan",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "plan_review": [
        StepDef("plan_review.spawn", "并行启动 6 维度 Plan Review agents",
                actions=["kanban workflow get-phase-agents plan_review",
                         "spawn 6 plan-reviewer agents (run_in_background=true)"],
                agent_type="kanban-plan-reviewer", parallel=True),
        StepDef("plan_review.collect", "收集评审报告",
                actions=["kanban workflow collect-plan-review $task_id"]),
        StepDef("plan_review.check", "评分检查（不达标则重试）",
                actions=["检查 plan_review_report.json 总分 >= pass_threshold"]),
        StepDef("plan_review.complete", "Plan Review 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "qa_spec": [
        StepDef("qa_spec.spawn", "QA Agent 生成 test_spec.md",
                actions=["kanban workflow get-phase-agents qa_spec",
                         "spawn kanban-qa agent (mode=spec)"],
                agent_type="kanban-qa"),
        StepDef("qa_spec.complete", "QA Spec 完成",
                actions=["kanban guard check-artifacts $task_id qa_spec",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "spec_review": [
        StepDef("spec_review.spawn", "Test Spec Reviewer 审核",
                actions=["kanban workflow get-phase-agents spec_review",
                         "spawn kanban-test-spec-reviewer agent"],
                agent_type="kanban-test-spec-reviewer"),
        StepDef("spec_review.check", "评分检查",
                actions=["检查 spec_review_report.json 总分 >= pass_threshold"]),
        StepDef("spec_review.user_confirm", "用户确认测试用例",
                actions=["展示 review 摘要 + test_spec.md，approve / revise"],
                user_action=True),
        StepDef("spec_review.complete", "Spec Review 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "execute": [
        StepDef("execute.spawn", "按拓扑批次 spawn executor agents",
                actions=["计算并行批次（依赖拓扑 + file_ownership）",
                         "每批 spawn kanban-executor agents (run_in_background=true)",
                         "每 subtask 独立 agent，不合并"],
                agent_type="kanban-executor", parallel=True),
        StepDef("execute.verify", "验证执行产物",
                actions=["kanban guard check-artifacts $task_id execute"]),
        StepDef("execute.complete", "Execute 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "evaluate": [
        StepDef("evaluate.spawn", "并行启动评估 agents",
                actions=["kanban workflow get-phase-agents evaluate",
                         "spawn 4 角色 agents (run_in_background=true)"],
                agent_type="kanban-code-reviewer", parallel=True),
        StepDef("evaluate.collect_scores", "收集评分（自动同步）",
                actions=["评分已由 complete-phase 自动同步"]),
        StepDef("evaluate.check_score", "自迭代决策（禁止询问用户）",
                actions=["kanban workflow self-improve-check $task_id",
                         "all_pass → Retrospective",
                         "hot(>=7.0) → 自动回 Execute",
                         "full(<7.0) → 自动回 Plan"]),
        StepDef("evaluate.complete", "Evaluate 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "retrospective": [
        StepDef("retrospective.spawn", "并行启动复盘 agents",
                actions=["kanban workflow get-phase-agents retrospective",
                         "spawn 3 agents: retrospective/acceptance/knowledge (parallel)"],
                parallel=True),
        StepDef("retrospective.knowledge_import", "导入提取的知识",
                actions=["complete-phase 自动导入 knowledge_extracted.json"]),
        StepDef("retrospective.complete", "Retrospective 完成",
                actions=["kanban guard check-artifacts $task_id retrospective",
                         "kanban workflow complete-phase $task_id"]),
    ],
    "user_decision": [
        StepDef("user_decision.present", "展示变更摘要",
                actions=["展示 retrospective + acceptance + 变更全景"],
                user_action=True),
        StepDef("user_decision.wait", "等待用户决策",
                actions=["kanban decide $task_id --action <approve_and_archive|abort|restart>"],
                user_action=True),
    ],
    "archive": [
        StepDef("archive.merge", "合并 worktree 代码",
                actions=["kanban worktree merge $task_id"]),
        StepDef("archive.cleanup", "清理 worktree + 归档",
                actions=["kanban worktree cleanup $task_id",
                         "kanban clean $task_id"]),
    ],
}

LIGHTWEIGHT_STEPS: dict[str, list[StepDef]] = {
    "plan": FULL_STEPS["plan"],
    "execute": FULL_STEPS["execute"],
    "evaluate": [
        StepDef("evaluate.spawn_qa", "QA 单角色评估",
                actions=["spawn kanban-qa agent (eval mode)"],
                agent_type="kanban-qa"),
        StepDef("evaluate.collect_score", "收集评分",
                actions=["评分已由 complete-phase 自动同步"]),
        StepDef("evaluate.check_score", "评分检查",
                actions=["kanban workflow self-improve-check $task_id"]),
        StepDef("evaluate.complete", "Evaluate 完成",
                actions=["kanban workflow complete-phase $task_id"]),
    ],
    "user_decision": FULL_STEPS["user_decision"],
    "archive": FULL_STEPS["archive"],
}


def _get_steps(mode: str) -> dict[str, list[StepDef]]:
    if mode == "lightweight":
        return LIGHTWEIGHT_STEPS
    return FULL_STEPS


def _get_phase_order(lightweight: bool) -> list[Phase]:
    if lightweight:
        return Scheduler.LIGHTWEIGHT_PHASE_ORDER
    return Scheduler.PHASE_ORDER


# ── Progress tracking ───────────────────────────────────────────────────

def _progress_path(fs: Filesystem, task_id: str) -> Path:
    return fs.task_dir(task_id) / "progress.json"


def load_progress(fs: Filesystem, task_id: str) -> dict:
    pp = _progress_path(fs, task_id)
    if pp.is_file():
        return json.loads(pp.read_text(encoding="utf-8"))
    return {"task_id": task_id, "steps": {}}


def save_progress(fs: Filesystem, task_id: str, progress: dict) -> None:
    pp = _progress_path(fs, task_id)
    pp.parent.mkdir(parents=True, exist_ok=True)
    pp.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")


def mark_step(fs: Filesystem, task_id: str, step_id: str, status: str = "completed") -> dict:
    progress = load_progress(fs, task_id)
    progress["steps"][step_id] = {
        "status": status,
        "updated_at": time.time(),
    }
    save_progress(fs, task_id, progress)
    return progress


# ── Core: determine next step ───────────────────────────────────────────

@dataclass
class NextStepResult:
    task_id: str
    phase: str
    step_id: str
    step_index: int
    total_steps: int
    description: str
    actions: list[str]
    agent_type: Optional[str] = None
    parallel: bool = False
    user_action: bool = False
    phase_complete: bool = False
    all_complete: bool = False
    context_files: list[str] = field(default_factory=list)
    message: str = ""


def next_step(fs: Filesystem, config: Config, task: Task) -> NextStepResult:
    """Determine the exact next action for a task."""
    steps_map = _get_steps("lightweight" if task.lightweight else "full")
    progress = load_progress(fs, task.id)
    completed_steps = {k for k, v in progress.get("steps", {}).items() if v.get("status") == "completed"}

    phase_value = task.phase.value

    # Check if task is in draft status
    if task.status.value == "draft":
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="draft.promote",
            step_index=0, total_steps=1,
            description="任务处于 draft 状态，需要 promote 到正式流程",
            actions=["kanban task promote " + task.id],
            message="draft 任务需要先 promote",
        )

    # Check if archived
    if task.status.value in ("archived", "cancelled"):
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="done",
            step_index=0, total_steps=0,
            description="任务已归档/取消",
            actions=[], all_complete=True,
            message="任务已结束",
        )

    # Get steps for current phase
    phase_steps = steps_map.get(phase_value, [])
    if not phase_steps:
        return NextStepResult(
            task_id=task.id, phase=phase_value, step_id="unknown",
            step_index=0, total_steps=0,
            description=f"阶段 {phase_value} 无定义步骤",
            actions=["kanban workflow transition " + task.id],
            message="未知阶段，尝试 transition 推进",
        )

    # Find first incomplete step
    for i, step in enumerate(phase_steps):
        if step.id not in completed_steps:
            context_files = _get_context_files(fs, task, phase_value)
            return NextStepResult(
                task_id=task.id,
                phase=phase_value,
                step_id=step.id,
                step_index=i,
                total_steps=len(phase_steps),
                description=step.description,
                actions=[a.replace("$task_id", task.id) for a in step.actions],
                agent_type=step.agent_type,
                parallel=step.parallel,
                user_action=step.user_action,
                context_files=context_files,
                message=f"当前阶段: {phase_value}, 步骤 {i+1}/{len(phase_steps)}: {step.description}",
            )

    # All steps in current phase are complete — transition to next phase
    phase_order = _get_phase_order(task.lightweight)
    current_idx = None
    for idx, p in enumerate(phase_order):
        if p == task.phase:
            current_idx = idx
            break

    if current_idx is not None and current_idx < len(phase_order) - 1:
        next_phase = phase_order[current_idx + 1]
        return NextStepResult(
            task_id=task.id,
            phase=phase_value,
            step_id=f"transition_to_{next_phase.value}",
            step_index=len(phase_steps),
            total_steps=len(phase_steps),
            description=f"阶段 {phase_value} 全部完成，准备进入 {next_phase.value}",
            actions=[
                f"kanban workflow transition {task.id} {next_phase.value}",
                f"kanban workflow next-step {task.id}",
            ],
            phase_complete=True,
            message=f"阶段 {phase_value} 完成 → {next_phase.value}",
        )

    return NextStepResult(
        task_id=task.id, phase=phase_value, step_id="all_done",
        step_index=len(phase_steps), total_steps=len(phase_steps),
        description="所有阶段已完成",
        actions=[], all_complete=True,
        message="任务流程全部完成",
    )


def _get_context_files(fs: Filesystem, task: Task, phase: str) -> list[str]:
    td = fs.task_dir(task.id)
    files = []
    candidates = [
        td / "task.json",
        td / "spec.md",
        td / "task_breakdown.json",
        td / "test_spec.md",
    ]
    for c in candidates:
        if c.is_file():
            files.append(str(c.relative_to(fs.kanban_dir)))
    return files


def next_step_to_dict(result: NextStepResult) -> dict:
    return {
        "task_id": result.task_id,
        "phase": result.phase,
        "step_id": result.step_id,
        "step_index": result.step_index,
        "total_steps": result.total_steps,
        "description": result.description,
        "actions": result.actions,
        "agent_type": result.agent_type,
        "parallel": result.parallel,
        "user_action": result.user_action,
        "phase_complete": result.phase_complete,
        "all_complete": result.all_complete,
        "context_files": result.context_files,
        "message": result.message,
    }
