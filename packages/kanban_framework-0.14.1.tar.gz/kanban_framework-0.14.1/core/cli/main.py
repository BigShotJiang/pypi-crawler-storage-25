from __future__ import annotations
import importlib
import json
import sys

_CMD_MAP: dict[str, tuple[str, str]] = {
    "check-env":  ("core.cli.main", "_cmd_check_env"),
    "init":       ("core.cli.task", "cmd_init"),
    "scan":       ("core.cli.task", "cmd_scan"),
    "create":     ("core.cli.task", "cmd_create"),
    "task":       ("core.cli.task", "cmd_task"),
    "status":     ("core.cli.task", "cmd_status"),
    "show":       ("core.cli.task", "cmd_show"),
    "clean":      ("core.cli.task", "cmd_clean"),
    "promote":    ("core.cli.task", "cmd_promote"),
    "run":        ("core.cli.run", "cmd_run"),
    "decide":     ("core.cli.run", "cmd_decide"),
    "guard":      ("core.cli.run", "cmd_guard"),
    "workflow":   ("core.cli.run", "cmd_workflow"),
    "worktree":   ("core.cli.run", "cmd_worktree"),
    "nlp":        ("core.cli.run", "cmd_nlp"),
    "recover":    ("core.cli.run", "cmd_recover"),
    "rollback":   ("core.cli.run", "cmd_rollback"),
    "resume":     ("core.cli.run", "cmd_resume"),
    "subtask":    ("core.cli.subtask", "dispatch"),
    "score":      ("core.cli.query", "cmd_score"),
    "summary":    ("core.cli.query", "cmd_summary"),
    "progress":   ("core.cli.query", "cmd_progress"),
    "time":       ("core.cli.query", "cmd_time"),
    "tokens":     ("core.cli.query", "cmd_tokens"),
    "dashboard":  ("core.cli.query", "cmd_dashboard"),
    "inbox":      ("core.cli.inbox", "dispatch"),
    "knowledge":  ("core.cli.knowledge", "dispatch"),
    "feedback":   ("core.cli.inbox", "cmd_feedback"),
    "version":    ("core.cli.version", "dispatch"),
    "plan":           ("core.cli.plan", "dispatch"),
    "evolve-skills":  ("core.cli.skills", "dispatch"),
    "framework":      ("core.cli.framework", "dispatch"),
    "evaluator":      ("core.cli.evaluator", "dispatch"),
    "help":           ("core.cli.main", "_cmd_help"),
    "sync-agents":    ("core.cli.main", "_cmd_sync_agents"),
}

_USE_JSON = False


def main() -> None:
    global _USE_JSON
    args = sys.argv[1:]

    # Extract --json / -o json before command dispatch
    if "--json" in args or "-o" in args:
        _USE_JSON = True
        args = [a for a in args if a not in ("--json", "-o")]

    if not args or args[0] in ("--help", "-h", "help"):
        if _USE_JSON:
            _output({"success": True, "data": _cmd_help(args[1:] if len(args) > 1 else [])})
        else:
            _render_help()
        return

    if args[0] in ("--version", "-V"):
        _output_version()
        return

    cmd = args[0]
    entry = _CMD_MAP.get(cmd)
    if entry is None:
        _output({"success": False, "error": f"unknown command: {cmd}", "code": "UNKNOWN_COMMAND"})
        sys.exit(1)

    mod_name, fn_name = entry
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, fn_name)
    try:
        result = fn(args[1:])
        if _USE_JSON:
            _output({"success": True, "data": result})
        else:
            _render(cmd, result)
    except Exception as e:
        _output({"success": False, "error": str(e), "code": type(e).__name__})


def _render(cmd: str, data: dict) -> None:
    """Human-readable renderer dispatcher."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    renderers = {
        "status": _render_status,
        "show": _render_show,
        "create": _render_create,
        "init": _render_init,
        "score": _render_score,
        "summary": _render_summary,
        "time": _render_time,
        "tokens": _render_tokens,
        "nlp": _render_nlp,
    }
    renderer = renderers.get(cmd)
    if renderer:
        renderer(data)
    else:
        # Fallback: pretty-print JSON-like summary
        _render_json_fallback(cmd, data)


def _output(data: dict) -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(json.dumps(data, ensure_ascii=False))


def _format_table(rows: list[list[str]], headers: list[str]) -> str:
    """Format aligned table."""
    cols = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            cols[i] = max(cols[i], len(str(cell)))
    lines = ["  ".join(h.ljust(cols[i]) for i, h in enumerate(headers))]
    lines.append("  ".join("─" * cols[i] for i in range(len(headers))))
    for row in rows:
        lines.append("  ".join(str(row[i]).ljust(cols[i]) for i in range(len(row))))
    return "\n".join(lines)


# ── Renderers ──

def _render_help():
    print("Usage: kanban <command> [options]\n")
    groups = [
        ("Tasks", [
            ("create   <title>", "Create a new task"),
            ("task edit <id>", "Edit task mode/priority/auto-mode"),
            ("status", "Show kanban board summary"),
            ("show     <id>", "Show task details"),
            ("promote  <id>", "Advance draft to active"),
            ("clean    <id>", "Clean up archived task"),
        ]),
        ("Execution", [
            ("run      <id>", "Execute current phase"),
            ("decide   <id>", "Make a decision"),
            ("subtask  <action>", "Manage subtasks"),
        ]),
        ("Knowledge", [
            ("knowledge search  <kw>", "Search knowledge base"),
            ("knowledge learn   <path>", "Learn from code"),
            ("knowledge list", "List knowledge entries"),
            ("knowledge review", "Review draft entries"),
        ]),
        ("Query", [
            ("score    <id>", "Evaluation scores"),
            ("summary  <id>", "Task summary"),
            ("progress <id>", "Subtask progress"),
            ("time     <id>", "Time tracking"),
            ("tokens   <id>", "Token usage"),
        ]),
        ("Inbox", [
            ("inbox add    <id> <text>", "Add feedback"),
            ("inbox analyze <id>", "Analyze inbox items"),
        ]),
    ]
    for group, cmds in groups:
        print(f"[{group}]")
        for cmd, desc in cmds:
            print(f"  {cmd.ljust(26)}{desc}")
        print()
    print("[Options]")
    print("  --json, -o json         Output raw JSON")
    print("  --help, -h              Show this help")


def _render_status(data: dict):
    tasks = data.get("tasks", [])
    by_status = data.get("by_status", {})
    total = data.get("total", 0)

    print(f"\n  Kanban Board — {total} tasks\n")
    print(f"  In Progress: {by_status.get('in_progress', 0)}")
    print(f"  Completed:   {by_status.get('completed', 0)}")

    if not tasks:
        print("\n  No active tasks.")
        return

    print()
    print(_format_table(
        [[t.get("id",""), t.get("title","")[:30], t.get("phase",""),
          f"v{t.get('iteration',1)}", t.get("status","")]
         for t in tasks if t.get("status") != "archived"],
        ["ID", "TITLE", "PHASE", "ITER", "STATUS"]
    ))


def _render_show(data: dict):
    print(f"\n  Task: {data.get('id', '?')} — {data.get('title', '?')}")
    print(f"  Phase: {data.get('phase', '?')} | Iteration: {data.get('iteration', 1)}")
    print(f"  Status: {data.get('status', '?')}")
    if data.get("description"):
        print(f"\n  {data['description']}")


def _render_create(data: dict):
    print(f"  Created {data.get('id', '?')}: {data.get('title', '?')}")
    print(f"  Phase: {data.get('phase', '?')} | Status: {data.get('status', '?')}")

    assessment = data.get("assessment", {})
    if assessment:
        mode = assessment.get("recommended_mode", "?")
        reason = assessment.get("reason", "")
        risks = assessment.get("risk_factors", [])
        mode_label = "lightweight" if mode == "lightweight" else "full"
        print(f"  Mode: {mode_label}")
        print(f"  Reason: {reason}")
        if risks:
            print(f"  Risks: {', '.join(risks)}")

    tc = data.get("test_config")
    if tc:
        level = tc.get("level", "full")
        level_labels = {"full": "完整测试", "quick": "快速验证", "manual": "手动检查"}
        parts = [level_labels.get(level, "full")]
        if tc.get("framework"): parts.append(tc["framework"])
        if tc.get("command"): parts.append(tc["command"])
        if tc.get("coverage"): parts.append(f"coverage {tc['coverage']}")
        print(f"  Test: {' | '.join(parts)}")

    task_id = data.get("id", "")
    desc = data.get("description", "") or "(无)"
    print(f"\n  ── 确认检查点 ──")
    print(f"  标题: {data.get('title', '?')}")
    if desc and desc != "(无)":
        print(f"  描述: {desc[:80]}{'...' if len(desc) > 80 else ''}")
    print(f"  模式: {data.get('mode', 'full')}")
    tc = data.get("test_config")
    if tc:
        print(f"  测试: {tc.get('level', 'full')}")
    print(f"\n  → 确认无误？ kanban run {task_id}")
    if not data.get("user_specified_mode", False):
        override = f"kanban task edit {task_id} --mode full" if data.get("mode") == "lightweight" else f"kanban task edit {task_id} --mode lightweight"
        print(f"  → 修改模式: {override}")
    print(f"  → 修改需求: 编辑 .kanban/tasks/{task_id}/spec.md 后运行")


def _render_init(data: dict):
    sync = data.get("sync", {})
    added = sync.get("added", [])
    updated = sync.get("updated", [])
    stale = sync.get("stale", [])
    created = data.get("created", []) or added + updated

    parts = []
    if added:
        parts.append(f"{len(added)} added")
    if updated:
        parts.append(f"{len(updated)} updated")
    if stale:
        parts.append(f"{len(stale)} stale")

    status = ", ".join(parts) if parts else f"{len(created)} items created"
    print(f"  kanban env ready — {status}")

    lang = data.get("language", "unknown")
    if lang and lang != "unknown":
        lang_labels = {"python": "Python", "javascript": "JavaScript", "typescript": "TypeScript", "go": "Go", "rust": "Rust"}
        print(f"  Language: {lang_labels.get(lang, lang)} (auto-detected)")

    if updated:
        for f in updated[:5]:
            print(f"    ~ {f}")
    pending = sync.get("pending_updates", [])
    if pending:
        print(f"\n  ⚠  {len(pending)} files have updates available (not applied)")
        for f in pending[:5]:
            print(f"    → {f}")
        if len(pending) > 5:
            print(f"    ... and {len(pending) - 5} more")
        print(f"  Review changes and run: kanban init --apply")
    if stale:
        print(f"  ⚠  {len(stale)} stale files (not in framework source)")
        for f in stale[:3]:
            print(f"    ? {f}")

    orphaned = data.get("orphaned_links", [])
    if orphaned:
        print(f"\n  ⚠  {len(orphaned)} orphaned agent/rule symlinks from older version")
        print(f"     These waste context in non-kanban sessions.")
        print(f"     Remove with: kanban init --clean-orphaned")

    if data.get("pip_warning"):
        print(f"  ⚠️  {data['pip_warning']}")


def _render_score(data: dict):
    scores = data.get("scores", [])
    avg = data.get("average")
    print(f"\n  Average: {avg}/10" if avg else "\n  No scores yet")
    if scores:
        print(_format_table(
            [[s["role"], f"{s['total']}/10", f"iter {s['iteration']}"] for s in scores],
            ["ROLE", "SCORE", "ITER"]
        ))


def _render_summary(data: dict):
    print(f"\n  Task: {data.get('title', data.get('task_id', '?'))}")
    print(f"  Phase: {data.get('phase', '?')} | Status: {data.get('status', '?')}")
    print(f"  Progress: {data.get('progress', {})}")


def _render_nlp(data: dict):
    print(f"\n  Input: {data.get('input', '')}")
    print(f"  Task ID: {data.get('task_id', '-')}")
    guidance = data.get("routing_guidance", {})
    print(f"  Intent: {guidance.get('intent', '?')}")
    print(f"  Suggested: {guidance.get('suggested_command', '?')}")
    print(f"  Rule: {guidance.get('rule', '')[:120]}")
    cmds = data.get("available_commands", [])
    print(f"\n  Commands ({len(cmds)} total):")
    for c in cmds:
        print(f"    {c.get('command', ''):<24} {c.get('example', '')}")


def _render_time(data: dict):
    t = data.get("time", data)
    print(f"\n  Total: {t.get('total_seconds', 0):.0f}s")
    for phase, info in t.get("phases", {}).items():
        print(f"  {phase}: {info.get('elapsed_seconds', 0):.0f}s")


def _render_tokens(data: dict):
    t = data.get("tokens", data)
    total = t.get("total_tokens", 0)
    budget = "within budget" if t.get("within_budget", True) else "over budget"
    print(f"\n  Total: {total} tokens ({budget})")
    for phase, tokens in t.get("by_phase", {}).items():
        print(f"  {phase}: {tokens}")


def _render_json_fallback(cmd: str, data: dict):
    """Fallback: show key fields in readable format."""
    if isinstance(data, dict):
        for k, v in data.items():
            if k in ("success", "code"):
                continue
            if isinstance(v, (str, int, float, bool)):
                print(f"  {k}: {v}")
            elif isinstance(v, list):
                print(f"  {k}: [{len(v)} items]")
            elif isinstance(v, dict):
                print(f"  {k}: {{{len(v)} keys}}")
    else:
        print(f"  {data}")


# ── Legacy commands ──

def _cmd_help(args: list[str]) -> dict:
    return {"commands": sorted(_CMD_MAP.keys())}


def _cmd_check_env(args: list[str]) -> dict:
    import os
    from pathlib import Path
    from core.infra.filesystem import Filesystem
    root = Filesystem.find_project_root()
    kanban_dir = root / ".kanban"

    # Check agent file sync between agents/ and core/_skill/agents/
    agent_sync_issues = _check_agent_sync()

    return {
        "project_root": str(root),
        "has_kanban": kanban_dir.is_dir(),
        "kanban_dir": str(kanban_dir),
        "ok": kanban_dir.is_dir(),
        "python": sys.executable,
        "agent_sync": {"in_sync": len(agent_sync_issues) == 0, "issues": agent_sync_issues},
    }


def _check_agent_sync() -> list[str]:
    from pathlib import Path
    # core/cli/main.py → core/cli/ → core/ → kanban root
    kanban_root = Path(__file__).resolve().parent.parent.parent
    agents_dir = kanban_root / "agents"
    skill_dir = kanban_root / "core" / "_skill" / "agents"
    issues = []
    if not agents_dir.is_dir() or not skill_dir.is_dir():
        return issues
    for f in agents_dir.glob("*.md"):
        other = skill_dir / f.name
        if not other.is_file():
            issues.append(f"{f.name}: missing in _skill/agents/")
        elif not _files_equal(f, other):
            issues.append(f"{f.name}: out of sync")
    return issues


def _files_equal(a: 'Path', b: 'Path') -> bool:
    import hashlib
    return hashlib.md5(a.read_bytes()).hexdigest() == hashlib.md5(b.read_bytes()).hexdigest()


def _cmd_sync_agents(args: list[str]) -> dict:
    from pathlib import Path
    kanban_root = Path(__file__).resolve().parent.parent.parent
    agents_dir = kanban_root / "agents"
    skill_dir = kanban_root / "core" / "_skill" / "agents"
    if not agents_dir.is_dir():
        return {"error": "agents/ directory not found"}

    skill_dir.mkdir(parents=True, exist_ok=True)
    synced = []
    for f in agents_dir.glob("*.md"):
        target = skill_dir / f.name
        target.write_bytes(f.read_bytes())
        synced.append(f.name)
    return {"synced": synced, "count": len(synced)}


def _output_version() -> None:
    ver = _get_version()
    if _USE_JSON:
        _output({"success": True, "data": {"version": ver}})
    else:
        print(f"kanban {ver}")


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("kanban-framework")
    except Exception:
        pass
    try:
        from pathlib import Path
        cfg = Path(__file__).resolve().parent.parent / "pyproject.toml"
        if cfg.is_file():
            import re
            text = cfg.read_text(encoding="utf-8")
            m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
            if m:
                return m.group(1)
    except Exception:
        pass
    return "unknown"


if __name__ == "__main__":
    main()
