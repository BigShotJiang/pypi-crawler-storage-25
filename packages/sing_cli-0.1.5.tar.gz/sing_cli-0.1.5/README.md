# sing-cli

Windows CLI for installing and controlling the `sing-box` Windows service.

## Requirements

`sing-box.exe` and `nssm.exe` must be available in `PATH`. `sing install --bin <path>` can use a custom `sing-box.exe` path.

On Windows, install the runtime executables with Scoop:

```powershell
scoop install sing-box nssm
```

## Installation

Install `sing-cli`:

```powershell
uv tool install sing-cli
```

Update `sing-cli`:

```powershell
uv tool upgrade sing-cli
```

Uninstall `sing-cli`:

```powershell
uv tool uninstall sing-cli
```

## Commands

| Command | Description |
|---|---|
| `sing install [--bin <path>]` | Register the `sing-box` Windows service through NSSM and enable autostart. |
| `sing uninstall` | Delete the `sing-box` Windows service. |
| `sing start <name>` | Start the service with a saved profile. |
| `sing stop` | Stop the service. |
| `sing restart` | Stop, reconfigure, and start the service with the active profile. |
| `sing status` | Show the NSSM service status, active profile, profile path, and installed `sing-box.exe` path. |
| `sing add <name> <url>` | Download a complete `sing-box` JSON profile and save it under a name. |
| `sing remove <name>` | Remove a saved non-active profile. |
| `sing update <name>` | Redownload a saved profile from its URL. |
| `sing list` | List saved profiles and mark the active profile. |

`sing install` uses `sing-box.exe` from `PATH` unless `--bin` is provided. The CLI does not download or upgrade `sing-box.exe` or `nssm.exe`.
