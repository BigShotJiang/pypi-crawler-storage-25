from __future__ import annotations

from collections.abc import Callable
from datetime import datetime
from functools import wraps
from pathlib import Path

import typer

from .errors import SingCliError
from .profile import download_profile
from .service import (
    configure_service,
    install_service,
    resolve_bin,
    service_is_running,
    service_status,
    start_service,
    stop_service,
    uninstall_service,
)
from .state import (
    ProfileEntry,
    State,
    load_state,
    now_utc,
    require_profile,
    save_state,
    validate_profile_name,
)

APP_NAME = "sing-cli"

app = typer.Typer(no_args_is_help=True)


def app_dir() -> Path:
    return Path(typer.get_app_dir(APP_NAME))


def state_path() -> Path:
    return app_dir() / "state.json"


def profile_path(name: str) -> Path:
    return app_dir() / "profiles" / name


def load_cli_state() -> State:
    return load_state(state_path())


def save_cli_state(state: State) -> None:
    save_state(state_path(), state)


def require_installed_bin(state: State) -> str:
    if state.bin is None:
        raise SingCliError("sing-box.exe path is not installed. Run 'sing install' first.")
    return state.bin


def fail(error: SingCliError) -> None:
    typer.echo(f"Error: {error}", err=True)
    raise typer.Exit(1)


def report_cli_errors[**P](command: Callable[P, None]) -> Callable[P, None]:
    @wraps(command)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> None:
        try:
            command(*args, **kwargs)
        except SingCliError as error:
            fail(error)

    return wrapper


def to_local_timezone(value: datetime) -> datetime:
    return value.astimezone()


def format_local_updated_at(profile_name: str, updated_at: str) -> str:
    if not updated_at.endswith("Z"):
        raise SingCliError(f"Profile '{profile_name}' has invalid updated_at timestamp: {updated_at}")

    try:
        updated_at_utc = datetime.fromisoformat(updated_at.removesuffix("Z") + "+00:00")
    except ValueError as error:
        raise SingCliError(f"Profile '{profile_name}' has invalid updated_at timestamp: {updated_at}") from error

    return to_local_timezone(updated_at_utc).isoformat()


@app.command()
@report_cli_errors
def install(bin: Path | None = typer.Option(None, "--bin", help="Path to sing-box.exe.")) -> None:
    resolved_bin = resolve_bin(bin)
    install_service(resolved_bin)
    state = load_cli_state()
    state.bin = str(resolved_bin)
    save_cli_state(state)
    typer.echo(f"Installed {resolved_bin}")


@app.command()
@report_cli_errors
def uninstall() -> None:
    uninstall_service()
    typer.echo("Uninstalled sing-box service")


@app.command()
@report_cli_errors
def start(name: str) -> None:
    state = load_cli_state()
    entry = require_profile(state, name)
    bin_path = require_installed_bin(state)
    if service_is_running():
        raise SingCliError("sing-box service is already running. Use 'sing restart'.")
    configure_service(bin_path, entry.path)
    start_service()
    state.active = name
    save_cli_state(state)
    typer.echo(f"Started {name}")


@app.command()
@report_cli_errors
def stop() -> None:
    stop_service()
    typer.echo("Stopped sing-box service")


@app.command()
@report_cli_errors
def restart() -> None:
    state = load_cli_state()
    if state.active is None:
        raise SingCliError("No active profile. Run 'sing start <name>' first.")
    entry = require_profile(state, state.active)
    bin_path = require_installed_bin(state)
    stop_service()
    configure_service(bin_path, entry.path)
    start_service()
    typer.echo(f"Restarted {state.active}")


@app.command()
@report_cli_errors
def status() -> None:
    state = load_cli_state()
    active_profile = state.active or "(none)"
    bin_path = state.bin or "(not installed)"
    profile = state.profiles.get(state.active) if state.active is not None else None
    profile_file = profile.path if profile is not None else ("(missing)" if state.active is not None else "(none)")

    typer.echo(f"Service status: {service_status()}")
    typer.echo(f"Active profile: {active_profile}")
    typer.echo(f"Profile path: {profile_file}")
    typer.echo(f"sing-box.exe: {bin_path}")


@app.command()
@report_cli_errors
def add(name: str, url: str) -> None:
    validate_profile_name(name)
    state = load_cli_state()
    if name in state.profiles:
        raise SingCliError(f"Profile already exists: {name}")
    destination = profile_path(name)
    download_profile(url, destination)
    state.profiles[name] = ProfileEntry(url=url, path=str(destination), updated_at=now_utc())
    save_cli_state(state)
    typer.echo(f"Added {name}")


@app.command()
@report_cli_errors
def remove(name: str) -> None:
    state = load_cli_state()
    entry = require_profile(state, name)
    if state.active == name:
        raise SingCliError(f"Cannot remove active profile: {name}")
    Path(entry.path).unlink()
    del state.profiles[name]
    save_cli_state(state)
    typer.echo(f"Removed {name}")


@app.command()
@report_cli_errors
def update(name: str) -> None:
    state = load_cli_state()
    entry = require_profile(state, name)
    download_profile(entry.url, Path(entry.path))
    state.profiles[name] = ProfileEntry(url=entry.url, path=entry.path, updated_at=now_utc())
    save_cli_state(state)
    typer.echo(f"Updated {name}")


@app.command(name="list")
@report_cli_errors
def list_profiles() -> None:
    state = load_cli_state()

    if not state.profiles:
        typer.echo("No profiles")
        return

    for name, entry in sorted(state.profiles.items()):
        marker = "*" if state.active == name else " "
        typer.echo(f"{marker} {name}\t{entry.url}\t{format_local_updated_at(name, entry.updated_at)}")
