# Add sing status command

## Goal

Add a `sing status` command so users can inspect the current `sing-box` service state from the CLI without starting, stopping, or reconfiguring the service.

## What I already know

* The user requested a new `sing status` command.
* The project is a Python Typer CLI for controlling the `sing-box` Windows service through NSSM.
* Existing service commands are implemented in `src/sing_cli/cli.py`.
* Existing NSSM service helpers are implemented in `src/sing_cli/service.py`.
* `service_is_running()` already calls `nssm.exe status sing-box` and returns a boolean for `SERVICE_RUNNING`.
* Local CLI state stores the installed `sing-box.exe` path, active profile name, and saved profiles in `state.json`.
* README command documentation lists every supported command in a table.

## Assumptions

* `sing status` should be read-only and must not mutate service configuration or local state.
* The command should follow existing CLI error handling: user-facing failures go to stderr as `Error: ...` and exit with code 1.
* The command should be documented in README once behavior is final.

## Open Questions

* None.

## Requirements

* Add a `sing status` Typer command.
* Query the Windows service through NSSM instead of inferring service state only from local CLI state.
* Keep the command read-only.
* Print detailed status:
  * NSSM service status.
  * Active profile name from local state.
  * Installed `sing-box.exe` path from local state.
  * Active profile file path when an active profile is set and still exists in local state.
* Add or update tests for the new command behavior.
* Update README command documentation.

## Acceptance Criteria

* [x] `sing status` is available in the CLI.
* [x] `sing status` reports the service state based on NSSM status output.
* [x] `sing status` reports local active profile details.
* [x] `sing status` reports the installed `sing-box.exe` path.
* [x] `sing status` does not write `state.json` or change service configuration.
* [x] Tests cover running and stopped service states.
* [x] README includes the new command.

## Definition of Done

* Tests added or updated where appropriate.
* Lint, type-check, and tests pass.
* Documentation reflects the final behavior.
* Rollout and rollback risk is considered.

## Out of Scope

* Managing multiple Windows services.
* Downloading or upgrading `sing-box.exe` or `nssm.exe`.
* Adding non-Windows service backends.
* Adding continuous monitoring or watch mode.

## Technical Notes

* Likely impacted files: `src/sing_cli/cli.py`, `src/sing_cli/service.py`, `tests/test_cli.py`, `tests/test_service.py`, `README.md`.
* Relevant specs: `.trellis/spec/backend/index.md`, `.trellis/spec/backend/error-handling.md`, `.trellis/spec/backend/quality-guidelines.md`, `.trellis/spec/backend/logging-guidelines.md`.
* Existing command docs are in the README `Commands` table; keep the table consistent without adding extra commentary lines.

## Decision

Use detailed status output. `sing status` should combine live NSSM service status with local CLI state, while keeping the command read-only and making clear through field names which values are local configuration.
