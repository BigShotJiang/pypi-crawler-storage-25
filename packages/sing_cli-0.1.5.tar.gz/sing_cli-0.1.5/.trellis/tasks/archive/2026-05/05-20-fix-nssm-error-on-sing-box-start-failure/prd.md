# Fix nssm error when sing-box startup fails

## Goal

When `sing-box` fails during `sing start <name>` or `sing restart`, the CLI should report a `sing-box` service startup failure instead of exposing the raw `nssm.exe failed` framing as the primary error. The failure must remain explicit and non-zero.

## What I already know

- The user reported that when `sing-box` startup fails, an NSSM error appears.
- Windows service control is implemented in `src/sing_cli/service.py`.
- `start_service()` currently calls `run_nssm(["start", SERVICE_NAME], runner)`.
- `run_nssm()` raises `ExternalCommandError` with the executable name when `nssm.exe` returns a non-zero exit code.
- `sing start <name>` configures the service, starts it, then saves `state.active`; existing tests already assert failed service start does not save `active`.
- `sing restart` stops the service, reconfigures it, then starts it.

## Assumptions

- The desired behavior is to keep the low-level NSSM output available as a diagnostic detail, but make the user-facing primary error describe the failed `sing-box` service startup.
- This task should only adjust startup failure reporting. It should not replace NSSM, add retries, or add profile validation with `sing-box check`.

## Requirements

- `sing start <name>` must still fail with a non-zero exit code when the service cannot start.
- `sing restart` must still fail with a non-zero exit code when the service cannot start after reconfiguration.
- Startup failures from `nssm.exe start sing-box` must be reported as a `sing-box` service startup failure, not as a raw `nssm.exe failed` headline.
- The original NSSM stdout/stderr summary must remain visible in the error message so the user can diagnose the underlying failure.
- Other NSSM failures, such as install, uninstall, stop, status, or configure failures, must keep the existing external command error behavior.
- Failed `sing start <name>` must not save `state.active`.

## Acceptance Criteria

- [x] A unit test covers `start_service()` translating an NSSM start failure into a startup-specific CLI error.
- [x] CLI tests cover `sing start <name>` and `sing restart` startup failures using the new message.
- [x] Existing NSSM non-start failure tests continue to pass unchanged.
- [x] `uv run pytest` passes.
- [x] `uv run ruff check src` passes.
- [x] `uv run ty check src` passes.

## Definition of Done

- Tests added or updated for the changed behavior.
- Lint, type check, and tests pass.
- Documentation/spec updates are considered if the CLI error contract changes.

## Out of Scope

- Replacing NSSM with another Windows service manager.
- Adding automatic retry, rollback, or service repair logic.
- Running `sing-box check` before service start.
- Changing install, uninstall, stop, status, or configure failure behavior.

## Technical Notes

- Relevant files inspected:
  - `src/sing_cli/service.py`
  - `src/sing_cli/cli.py`
  - `src/sing_cli/errors.py`
  - `tests/test_service.py`
  - `tests/test_cli.py`
  - `.trellis/spec/backend/error-handling.md`
  - `.trellis/spec/backend/quality-guidelines.md`
  - `.trellis/spec/backend/logging-guidelines.md`
- Backend spec requires CLI failures to surface clearly and forbids silent fallback behavior.
- Backend spec says `sing add` and `sing update` do not proactively call `sing-box check`; profile validity is exposed during `sing start <name>`.
