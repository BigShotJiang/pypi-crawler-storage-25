# Workspace Index - pixelcola

> Journal tracking for AI development sessions.

---

## Current Status

<!-- @@@auto:current-status -->
- **Active File**: `journal-1.md`
- **Total Sessions**: 11
- **Last Active**: 2026-05-20
<!-- @@@/auto:current-status -->

---

## Active Documents

<!-- @@@auto:active-documents -->
| File | Lines | Status |
|------|-------|--------|
| `journal-1.md` | ~376 | Active |
<!-- @@@/auto:active-documents -->

---

## Session History

<!-- @@@auto:session-history -->
| # | Date | Title | Commits | Branch |
|---|------|-------|---------|--------|
| 11 | 2026-05-20 | Add sing status command | `548a9ee` | `feature/add-sing-status-command` |
| 10 | 2026-05-20 | Clarify sing-box service start failures | `a4c0c5d` | `fix/nssm-start-error` |
| 9 | 2026-05-13 | Optimize Python code | `8c0ae39` | `refactor/optimize-python-code` |
| 8 | 2026-05-13 | Use local timezone in sing list | `c6a44bf` | `fix/list-local-timezone` |
| 7 | 2026-05-12 | Expand test coverage | `764205a` | `test/improve-coverage` |
| 6 | 2026-05-12 | Update README installation instructions | `49680f6` | `docs/readme-install-uv-tool` |
| 5 | 2026-05-12 | Fix restart active profile | `010e59e` | `fix/restart-active-config` |
| 4 | 2026-05-12 | Fix Windows subprocess output decoding | `e90a676` | `fix/windows-subprocess-output-decoding` |
| 3 | 2026-05-12 | Use NSSM for Windows service | `72c1b0d` | `fix/use-nssm-service` |
| 2 | 2026-05-12 | Windows sing-box CLI | `2f18462` | `feature/windows-sing-box-cli` |
| 1 | 2026-05-12 | Bootstrap Guidelines | `ced349d` | `main` |
<!-- @@@/auto:session-history -->

---

## Notes

- Sessions are appended to journal files
- New journal file created when current exceeds 2000 lines
- Use `add_session.py` to record sessions