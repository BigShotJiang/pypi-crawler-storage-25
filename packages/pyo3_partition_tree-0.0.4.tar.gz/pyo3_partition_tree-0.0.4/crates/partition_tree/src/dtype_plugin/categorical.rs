//! Categorical dtype plugin.
//!
//! Handles `Enum` and `Categorical` Polars columns. Scans all observed
//! category codes and creates a [`BelongsTo`](crate::rules::BelongsTo) rule
//! with a sorted domain for deterministic behaviour.
use std::collections::HashSet;
use std::sync::Arc;

use crate::rules::BelongsTo;

use super::DTypePlugin;
use crate::column_split::{CategoricalColumnSplitSearcher, ColumnSplitSearcher};
use crate::dataset_view::{ColumnView, LogicalDTypeKind};
use crate::rule::DynRule;

// ---------------------------------------------------------------------------
// CategoricalPlugin
// ---------------------------------------------------------------------------

/// Plugin for categorical (`Enum`, `Categorical`) columns.
///
/// Scans for all observed category codes and creates a `BelongsTo` rule
/// with a sorted domain for deterministic behaviour.
pub struct CategoricalPlugin {
    searcher: CategoricalColumnSplitSearcher,
}

impl CategoricalPlugin {
    /// Create a new `CategoricalPlugin`.
    pub fn new() -> Self {
        Self {
            searcher: CategoricalColumnSplitSearcher,
        }
    }
}

impl Default for CategoricalPlugin {
    fn default() -> Self {
        Self::new()
    }
}

impl DTypePlugin for CategoricalPlugin {
    fn logical_dtype_kind(&self) -> LogicalDTypeKind {
        LogicalDTypeKind::Categorical
    }

    fn default_rule(
        &self,
        col: &dyn ColumnView,
        _boundaries_expansion_factor: f64,
    ) -> Box<dyn DynRule> {
        // Scan for all observed category codes
        let mut seen = HashSet::new();
        let mut domain_order = Vec::new();
        for i in 0..col.len() {
            if let Some(cat) = col.get_cat(i) {
                if seen.insert(cat) {
                    domain_order.push(cat);
                }
            }
        }

        // Sort domain for determinism
        domain_order.sort();

        // Use real string labels from the column if available;
        // fall back to synthetic "cat_N" names.
        let domain_names: Vec<String> = if let Some(labels) = col.cat_labels() {
            domain_order
                .iter()
                .map(|&c| labels.get(c).cloned().unwrap_or_else(|| format!("cat_{c}")))
                .collect()
        } else {
            domain_order.iter().map(|c| format!("cat_{c}")).collect()
        };
        let values: HashSet<usize> = domain_order.iter().copied().collect();

        Box::new(BelongsTo::new(
            values,
            Arc::new(domain_order),
            Arc::new(domain_names),
            true,
        ))
    }

    fn split_searcher(&self) -> &dyn ColumnSplitSearcher {
        &self.searcher
    }
}
