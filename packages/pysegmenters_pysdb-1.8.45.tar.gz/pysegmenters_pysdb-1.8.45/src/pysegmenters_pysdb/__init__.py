"""Rule-based segmenter"""

__version__ = "1.8.45"
