<h1 align="center">GitWizard</h1>

<p align="center">
  <strong>Universal Git Commit & Push Automation CLI</strong><br>
  Smart Diff-Based Commits &bull; One-Command Setup &bull; GitHub Auth &bull; v1.0.0
</p>

<p align="center">
  <a href="https://gitwizard.fahim.website">
    <img src="https://img.shields.io/badge/Docs-gitwizard.fahim.website-blue?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Ik0yIDNoOWE0IDQgMCAwIDEgNCA0djhhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJWNVoiPjwvcGF0aD48cGF0aCBkPSJNOCAzaDlhNCA0IDAgMCAxIDQgNHY4YTIgMiAwIDAgMS0yIDJoLTlhMiAyIDAgMCAxLTItMlY1eiI+PC9wYXRoPjwvc3ZnPg==">
  </a>
  <a href="https://pypi.org/project/gitwizard-pro/">
    <img src="https://img.shields.io/pypi/v/gitwizard-pro?color=blue&label=v1.0.0">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/gitwizard-pro?color=brightgreen&label=Python">
  <img src="https://img.shields.io/pypi/l/gitwizard-pro?color=orange">
  <img src="https://img.shields.io/pypi/dm/gitwizard-pro?color=purple&label=Downloads">
  <img src="https://img.shields.io/badge/CLI-Global-black">
  <img src="https://img.shields.io/badge/Supports-240%2B%20Languages-success">
</p>

---

## Official Documentation

Full Documentation: [gitwizard.fahim.website](https://gitwizard.fahim.website)

---

## What is GitWizard?

**GitWizard** is a professional-grade Python CLI tool that fully automates Git commit generation, pushing, and repository management. It is designed for developers who want to save time by automating repetitive git operations while maintaining a clean and meaningful commit history.

Whether you are starting a brand new project or managing an existing repository, GitWizard provides powerful commands to handle everything from initial GitHub setup to smart diff-based commit message generation. The tool analyzes your actual code changes and creates descriptive commit messages automatically, detects word-level replacements like variable renames, and supports both automated and manual commit workflows.

The tool supports over **240+ programming and scripting languages** across every major category, making it truly universal for modern development environments. It works entirely locally without sending any code to external servers, requires no API tokens, and is compatible with Windows, macOS, and Linux.

---

## Key Features

- **GitHub Authentication Integration** — Automatic VS Code and GitHub CLI authorization check with interactive setup guidance for first-time users
- **One-Command Project Setup** — `gitwizard setup` handles everything: git init, file staging, commit creation, remote connection, and push to GitHub in a single interactive flow
- **Smart Diff-Based Commit Messages** — Automatically analyzes `git diff` output to generate meaningful, descriptive commit messages based on what actually changed in your code
- **Word Replacement Detection** — Detects when text has been renamed or replaced (e.g., renaming a variable from `Fahim` to `Hasib`) and includes it in the commit message
- **Atomic Per-File Commits** — The `--atomic` flag creates a separate, individual commit for each file change, keeping your git history clean and granular
- **Bulk Auto-Commit Generator** — Generate multiple automated commits with customizable delay, message templates, and optional auto-push for repository activity
- **Both Automation and Manual Modes** — Use fully automatic commit message generation or provide your own custom messages at any time
- **240+ Language Support** — Intelligently detects programming languages and applies the correct comment syntax for auto-commit operations across 240+ file types
- **Dry-Run Simulation** — Preview what would happen without making any actual changes to your repository
- **Real-Time Progress Bar** — Beautiful ASCII progress bar showing commit generation progress in real time
- **Safe Interrupt Handling** — Gracefully handles Ctrl+C interrupts at any point without leaving your repository in a broken state
- **Fully Local Execution** — All operations run locally on your machine. No code is sent to any external server
- **No API Tokens Required** — Uses your existing Git and GitHub CLI configuration. No extra setup needed
- **Cross-Platform Compatible** — Works seamlessly on Windows, macOS, and Linux with automatic color detection

---

## Installation

Install from PyPI:

```bash
pip install gitwizard-pro
```

**Requirements:**
- Python 3.7 or higher
- Git installed and available in your system PATH
- GitHub CLI (`gh`) recommended for authentication features (install from [cli.github.com](https://cli.github.com/))

**Upgrade from a previous version:**

```bash
pip install gitwizard-pro --upgrade
```

---

## Quick Start

### 1. First-Time Setup (New Project)

If you have a project that is not yet connected to GitHub, the setup command handles everything:

```bash
gitwizard setup
```

This interactive command guides you through:

| Step | Action |
|------|--------|
| 1 | **Check GitHub Authentication** — Verifies if you are logged into GitHub CLI. If not, it guides you through the authentication process step by step |
| 2 | **Initialize Git Repository** — Runs `git init` if the project is not already a git repository |
| 3 | **Stage All Files** — Runs `git add .` automatically to stage every file in your project directory |
| 4 | **Create Commit** — Prompts you for a commit message (provides a timestamp-based default) and creates the initial commit |
| 5 | **Connect Remote** — Prompts you for your GitHub repository URL and configures it as the origin remote |
| 6 | **Push to GitHub** — Pushes the commit to GitHub automatically. If the regular push fails (common for new empty repos), it tries a force push as a fallback |

You do not need to type a single `git` command. The entire process is fully automated and interactive.

### 2. Smart Push (Day-to-Day Usage)

After the initial setup, just make changes to your code and run:

```bash
gitwizard push
```

The tool will:
- Automatically run `git add .` to stage all changes
- Parse the `git diff` output to understand exactly what changed
- Generate a meaningful, descriptive commit message based on the actual changes
- Create the commit and push it to the remote repository

**With a custom commit message:**

```bash
gitwizard push -m "fix: resolve login bug"
```

**Atomic commits (one per file):**

```bash
gitwizard push --atomic
```

**Commit locally without pushing:**

```bash
gitwizard push --no-push
```

### 3. Bulk Auto-Commit (Generate Repository Activity)

Generate multiple automated commits for repository activity:

```bash
gitwizard auto --count 10
gitwizard auto --count 5 --push
gitwizard auto --count 3 --dry-run
```

---

## Command Reference

### `gitwizard setup`

Interactive project setup. Connects your local project to GitHub in one command.

```bash
gitwizard setup
```

| Step | Action | Details |
|------|--------|---------|
| 1 | Check GitHub authentication | Prompts login if not authenticated |
| 2 | Initialize git repository | Runs `git init` (skips if already a repo) |
| 3 | Stage all files | Runs `git add .` |
| 4 | Create commit | Asks for commit message |
| 5 | Connect remote | Asks for GitHub repo URL |
| 6 | Push to GitHub | Commits and pushes automatically |

---

### `gitwizard push`

Smart commit and push based on detected code changes.

```bash
gitwizard push                   # Auto-generate commit message
gitwizard push -m "message"      # Custom commit message
gitwizard push --atomic          # Separate commit per file
gitwizard push --no-push         # Commit only, don't push
```

| Flag | Description |
|------|-------------|
| `-m, --message` | Provide a custom commit message instead of auto-generation |
| `--atomic` | Create a separate commit for each changed file |
| `--no-push` | Commit locally without pushing to the remote |

**How auto-generated commit messages work:**

The tool runs a comprehensive analysis of your `git diff` output. It parses every changed line, categorizes the type of change, and generates a descriptive commit message using conventional commit format. Here are examples of what it generates:

| Change Type | Generated Message Example |
|-------------|--------------------------|
| Word replaced in code | `update: replace 'Fahim' with 'Hasib' in main.py` |
| New file added | `feat: add config.py` |
| File deleted | `remove: delete old_script.js` |
| Import statements changed | `refactor: update imports in utils.py` |
| Function or class modified | `update: modify login in auth.py` |
| Function or class removed | `update: remove calculate from math_utils.py` |
| Configuration file changed | `config: modify settings.yaml (+3/-1)` |
| Test file changed | `test: modify test_auth.py (+5/-2)` |
| Documentation file changed | `docs: modify README.md (+12/-3)` |
| Dependency file changed | `deps: modify requirements.txt (+1/-1)` |
| Multiple files changed | `update: modify 3 file(s) [main.py, app.py, utils.py] (+12/-3)` |
| All new files | `feat: add 5 new file(s) (config.py, utils.py, ...)` |
| All deleted files | `remove: delete 3 file(s) (old.py, backup.py, ...)` |

---

### `gitwizard auto --count N`

Bulk auto-commit generator. Creates multiple commits by appending safe comment lines to tracked source files. This is useful for generating repository activity with realistic-looking commit history.

```bash
gitwizard auto --count 5                           # Generate 5 auto commits
gitwizard auto --count 10 --push                   # With auto-push after each commit
gitwizard auto --count 3 --dry-run                 # Preview mode (no actual commits)
gitwizard auto --count 5 --min-delay 1 --max-delay 3  # Custom delay range
gitwizard auto --count 5 -m "update {file}"        # Custom message template
```

| Flag | Default | Description |
|------|---------|-------------|
| `--count, -c` | (required) | Number of commits to generate |
| `--min-delay` | 2 | Minimum delay between commits in seconds |
| `--max-delay` | 4 | Maximum delay between commits in seconds |
| `--message, -m` | `auto commit at {time}` | Commit message template |
| `--push, -p` | false | Push to remote after each commit |
| `--dry-run` | false | Simulate without making actual commits |

**Available template variables:**

| Variable | Output Example |
|----------|---------------|
| `{time}` | `2025-01-15 14:30:00` |
| `{iteration}` | `3` |
| `{file}` | `src/main.py` |

---

### `gitwizard auth`

Check or set up GitHub / VS Code authentication.

```bash
gitwizard auth            # Full interactive setup guide
gitwizard auth --check    # Quick auth status check
```

This command checks if the GitHub CLI (`gh`) is authenticated. The GitHub CLI is the same authentication system used by VS Code's built-in Git integration. If authentication is not configured, the tool provides a step-by-step interactive guide to help you log in, including installation instructions for macOS, Ubuntu, and Windows.

---

### `gitwizard help`

Show the full command reference with colored output, along with documentation and report issue links.

```bash
gitwizard help
```

Displays all available commands with colored formatting and provides links to the full documentation website.

---

## How Smart Diff Analysis Works

### Overview

When you run `gitwizard push`, the tool performs a multi-step analysis pipeline to generate the best possible commit message:

### Step 1: Change Detection
The tool runs `git add .` to stage all changes, then captures the `git diff --cached` output. This gives the tool a complete picture of exactly what lines were added, removed, or modified across all files.

### Step 2: File Categorization
Each changed file is automatically categorized based on its name and path. Configuration files, test files, documentation files, dependency files, and data files are each recognized and assigned an appropriate commit prefix (config, test, docs, deps, etc.).

### Step 3: Word-Level Replacement Detection
The tool compares removed and added lines pair-by-pair to detect specific word or phrase replacements. For example, if you rename a variable from `Fahim` to `Hasib` across your codebase, the tool detects this at the word level and generates a message like:

```
update: replace 'Fahim' with 'Hasib' in main.py
update: replace 'Fahim' with 'Hasib' in config.py
```

### Step 4: Content Analysis
The tool scans the changed content for common patterns like import statements, function definitions, class definitions, and other structural elements. This allows it to generate messages like:

```
refactor: update imports in utils.py
update: modify calculate_total in invoice.py
```

### Step 5: Commit Message Generation
All the analysis results are combined into a single, descriptive commit message using the conventional commit format (type: description). For multi-file changes, the message includes a summary of how many files changed, which files, and the total addition/deletion count.

### Atomic Commit Mode

When you use the `--atomic` flag, each file's changes become a separate commit with its own auto-generated message. This is useful for creating a clean, granular commit history where each commit represents exactly one logical change. The process is:

1. Unstage all files
2. Stage only the first file
3. Analyze the diff for that file
4. Generate a commit message specific to that file's changes
5. Commit with the generated message
6. Repeat for each changed file
7. Push all commits at once

---

## Supported Languages

The auto-commit generator supports **240+ programming and scripting languages** with intelligent comment style detection:

| Category | Languages |
|----------|-----------|
| **Web Frontend** | JavaScript, TypeScript, JSX, TSX, HTML, CSS, SCSS, SASS, LESS, PHP |
| **Systems Programming** | C, C++, C#, Rust, Go, Zig, Assembly |
| **Scripting Languages** | Python, Ruby, Bash, Zsh, PowerShell, Perl, Lua, Tcl |
| **Mobile Development** | Swift, Kotlin, Dart |
| **Functional Programming** | Haskell, Erlang, Elixir, Clojure, Scala |
| **Data & Analysis** | SQL, R, MATLAB, CSV, TSV, JSON |
| **Configuration** | YAML, TOML, INI, XML, JSON |
| **IaC / DevOps** | Dockerfile, Terraform, Nix, Kubernetes, CI/CD configs |
| **Blockchain / Web3** | Solidity, Move, Vyper |
| **Low-Level / Hardware** | Assembly, VHDL, Verilog, Fortran, Ada, COBOL |
| **Niche / Academic** | Lean, Coq, Agda, Idris, Mercury, Joy, Forth |
| **And 200+ more** | Covering every major programming language in existence |

Each language is mapped to its appropriate comment style (hash, slash, dash, html, css, etc.) so that auto-generated comment lines use the correct syntax for the file type.

---

## Security & Safety

- **Fully Local Execution** — No code is ever sent to any external server. All git operations run directly on your machine using the standard git command-line tool
- **No API Tokens Required** — The tool uses your existing Git and GitHub CLI configuration. There is no need to create or manage any additional API tokens
- **Safe Comment Lines** — Auto-generated comment lines are clearly marked with timestamps and are non-intrusive. They do not affect code functionality
- **Dry-Run Mode** — Preview exactly what would happen without making any actual commits using the `--dry-run` flag
- **Ctrl+C Safety** — All long-running operations handle keyboard interrupts gracefully. You can press Ctrl+C at any point and the tool will stop cleanly without leaving your repository in a broken state
- **MIT Licensed** — Open source and free to use, modify, and distribute

---

## Platform Compatibility

| Platform | Supported | Notes |
|----------|-----------|-------|
| **Windows** | Yes | Requires Git for Windows. Colors auto-disabled in non-terminal environments |
| **macOS** | Yes | Works with both Intel and Apple Silicon Macs |
| **Linux** | Yes | Works with all major distributions |

The tool automatically detects whether your terminal supports ANSI color codes and disables colors when running in environments that do not support them (such as CI/CD pipelines or redirected output). You can also manually disable colors by setting the `NO_COLOR` environment variable.

---

## Requirements

| Requirement | Version | Details |
|-------------|---------|---------|
| **Python** | 3.7+ | Python 3.7, 3.8, 3.9, 3.10, 3.11, 3.12, 3.13 |
| **Git** | Any recent version | Must be installed and available in your system PATH |
| **GitHub CLI** | Latest recommended | Required for authentication features. Install from [cli.github.com](https://cli.github.com/) |

---

## Links

| Resource | Link |
|----------|------|
| **Official Documentation** | [gitwizard.fahim.website](https://gitwizard.fahim.website) |
| **PyPI Package** | [pypi.org/project/gitwizard-pro](https://pypi.org/project/gitwizard-pro/) |
| **GitHub** | [github.com/devfahimbd](https://github.com/devfahimbd) |

---

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

<p align="center">
  <strong>Powered By Programmer Fahim</strong>
</p>
