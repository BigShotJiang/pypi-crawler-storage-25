"""
GitWizard v1.0.0
========================
Universal Git Commit & Push Automation CLI Tool
Powered By Programmer Fahim
"""

__version__ = "1.0.0"
__author__ = "Programmer Fahim"
__license__ = "MIT"
__docs_url__ = "https://gitwizard.fahim.website"
