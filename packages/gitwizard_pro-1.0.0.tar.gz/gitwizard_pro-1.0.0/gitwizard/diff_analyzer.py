"""
Smart diff analyzer for GitWizard.
Parses git diff output to generate meaningful automatic commit messages.
Detects word-level replacements, file additions, deletions, and modifications.
"""

import os
import re
from difflib import SequenceMatcher


# Conventional commit prefixes based on change type
CHANGE_CATEGORIES = {
    "new_file":      "feat",
    "deleted_file":  "remove",
    "config_change": "config",
    "test_change":   "test",
    "doc_change":    "docs",
    "refactor":      "refactor",
    "fix":           "fix",
    "style_change":  "style",
    "dependency":    "deps",
    "data_change":   "data",
    "general":       "update",
}

# File patterns for auto-categorization
FILE_PATTERNS = {
    "test":      [r"test_", r"_test\.", r"tests?/", r"spec_", r"_spec\."],
    "docs":      [r"README", r"CHANGELOG", r"LICENSE", r"docs/", r"\.md$"],
    "config":    [r"config", r"settings", r"\.env", r"\.toml", r"\.yaml", r"\.yml", r"\.ini", r"\.cfg"],
    "style":     [r"\.css", r"\.scss", r"\.sass", r"\.less", r"\.html"],
    "dependency":[r"requirements", r"Pipfile", r"pyproject\.toml", r"package\.json", r"yarn\.lock", r"Cargo\.toml", r"go\.mod"],
    "data":      [r"\.json", r"\.csv", r"\.xml", r"\.sql", r"\.db"],
}


def categorize_file(filepath):
    """Categorize a file based on its name/path pattern."""
    fname = filepath.lower()
    for category, patterns in FILE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, fname):
                return {
                    "test": "test_change", "docs": "doc_change",
                    "config": "config_change", "style": "style_change",
                    "dependency": "dependency", "data": "data_change",
                }.get(category, "general")
    return "general"


def parse_diff(diff_output):
    """
    Parse raw git diff output into structured change data.

    Returns:
        List of dicts: file, status, additions, deletions, added_lines, removed_lines
    """
    if not diff_output or not diff_output.strip():
        return []

    changes = []
    current = None

    for line in diff_output.split("\n"):
        if line.startswith("diff --git"):
            if current:
                changes.append(current)
            match = re.search(r"b/(.+)$", line)
            filepath = match.group(1) if match else "unknown"
            current = {
                "file": filepath,
                "status": "modified",
                "additions": 0,
                "deletions": 0,
                "added_lines": [],
                "removed_lines": [],
            }
        elif current:
            if line.startswith("new file"):
                current["status"] = "added"
            elif line.startswith("deleted file"):
                current["status"] = "deleted"
            elif line.startswith("rename"):
                current["status"] = "renamed"
                match = re.search(r"rename to (.+)$", line)
                if match:
                    current["file"] = match.group(1)
            elif line.startswith("Binary files"):
                pass
            elif line.startswith("+") and not line.startswith("+++"):
                current["additions"] += 1
                content = line[1:].strip()
                if content:
                    current["added_lines"].append(content)
            elif line.startswith("-") and not line.startswith("---"):
                current["deletions"] += 1
                content = line[1:].strip()
                if content:
                    current["removed_lines"].append(content)

    if current:
        changes.append(current)
    return changes


def detect_replacements(added_lines, removed_lines):
    """
    Detect word-level replacements between added and removed lines.
    Returns list of (old_text, new_text, context_line).
    """
    replacements = []
    paired = zip(removed_lines, added_lines)
    for old, new in paired:
        if old != new:
            old_words = old.split()
            new_words = new.split()
            if len(old_words) == len(new_words):
                for ow, nw in zip(old_words, new_words):
                    if ow != nw:
                        replacements.append((ow, nw, old))
            else:
                matcher = SequenceMatcher(None, old_words, new_words)
                for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                    if tag == "replace":
                        old_part = " ".join(old_words[i1:i2])
                        new_part = " ".join(new_words[j1:j2])
                        replacements.append((old_part, new_part, old))
    return replacements


def generate_commit_message(diff_output, custom_message=None):
    """
    Generate a smart commit message from git diff output.
    If custom_message is provided, it is used instead.
    """
    if custom_message:
        return custom_message.strip()

    changes = parse_diff(diff_output)
    if not changes:
        return "chore: no changes detected"

    if len(changes) == 1:
        return _single_file_message(changes[0])
    else:
        return _multi_file_message(changes)


def generate_atomic_messages(diff_output):
    """
    Generate individual commit messages for each file change.
    Used in --atomic mode.
    Returns list of dicts: file, message, status
    """
    changes = parse_diff(diff_output)
    messages = []
    for change in changes:
        msg = _single_file_message(change)
        messages.append({
            "file": change["file"],
            "message": msg,
            "status": change["status"],
        })
    return messages


def get_change_summary(diff_output):
    """Get a human-readable summary of all changes."""
    changes = parse_diff(diff_output)
    if not changes:
        return "No changes detected"

    total_add = sum(c["additions"] for c in changes)
    total_del = sum(c["deletions"] for c in changes)
    n_files = len(changes)

    parts = []
    for ch in changes:
        status_icon = {"added": "+", "deleted": "-", "modified": "~", "renamed": ">"}
        icon = status_icon.get(ch["status"], "?")
        basename = os.path.basename(ch["file"])
        parts.append(f"  {icon} {basename} ({ch['additions']}+/{ch['deletions']}-)")

    summary = f"{n_files} file(s) changed, {total_add} addition(s), {total_del} deletion(s)"
    return summary + "\n" + "\n".join(parts)


def _single_file_message(change):
    """Generate a commit message for a single file change."""
    filepath = change["file"]
    basename = os.path.basename(filepath)
    status = change["status"]
    additions = change["additions"]
    deletions = change["deletions"]

    replacements = detect_replacements(change["added_lines"], change["removed_lines"])
    category = categorize_file(filepath)
    prefix = CHANGE_CATEGORIES.get(category, "update")

    if status == "added":
        return f"feat: add {basename}"
    elif status == "deleted":
        return f"remove: delete {basename}"

    if replacements:
        old_text, new_text, _ = replacements[0]
        old_clean = _clean_text(old_text)
        new_clean = _clean_text(new_text)
        if old_clean and new_clean:
            return f"update: replace '{old_clean}' with '{new_clean}' in {basename}"

    parts = []
    if additions > 0:
        parts.append(f"+{additions}")
    if deletions > 0:
        parts.append(f"-{deletions}")
    change_summary = ", ".join(parts)

    added_content = " ".join(change["added_lines"][:5])
    removed_content = " ".join(change["removed_lines"][:5])

    if _contains_import(added_content) or _contains_import(removed_content):
        return f"{prefix}: update imports in {basename}"

    if _contains_function_def(added_content) or _contains_function_def(removed_content):
        func_name = _extract_function_name(added_content) or _extract_function_name(removed_content)
        if func_name:
            if deletions > additions:
                return f"{prefix}: remove {func_name} from {basename}"
            elif additions > deletions:
                return f"{prefix}: update {func_name} in {basename}"
            return f"{prefix}: modify {func_name} in {basename}"

    return f"{prefix}: modify {basename} ({change_summary})"


def _multi_file_message(changes):
    """Generate a commit message for multiple file changes."""
    categories = set()
    filenames = []
    total_additions = 0
    total_deletions = 0
    new_files = []
    deleted_files = []

    for change in changes:
        categories.add(categorize_file(change["file"]))
        filenames.append(os.path.basename(change["file"]))
        total_additions += change["additions"]
        total_deletions += change["deletions"]
        if change["status"] == "added":
            new_files.append(os.path.basename(change["file"]))
        elif change["status"] == "deleted":
            deleted_files.append(os.path.basename(change["file"]))

    if len(new_files) == len(changes):
        names = ", ".join(new_files[:3])
        if len(new_files) > 3:
            names += f" (+{len(new_files) - 3} more)"
        return f"feat: add {len(changes)} new file(s) ({names})"

    if len(deleted_files) == len(changes):
        names = ", ".join(deleted_files[:3])
        if len(deleted_files) > 3:
            names += f" (+{len(deleted_files) - 3} more)"
        return f"remove: delete {len(changes)} file(s) ({names})"

    if "config_change" in categories and len(categories) == 1:
        prefix = "config"
    elif "test_change" in categories and len(categories) == 1:
        prefix = "test"
    elif "doc_change" in categories and len(categories) == 1:
        prefix = "docs"
    elif "dependency" in categories:
        prefix = "deps"
    else:
        prefix = "update"

    stat_parts = []
    if total_additions:
        stat_parts.append(f"+{total_additions}")
    if total_deletions:
        stat_parts.append(f"-{total_deletions}")
    change_summary = ", ".join(stat_parts) if stat_parts else "0 changes"

    file_summary = ", ".join(filenames[:3])
    if len(filenames) > 3:
        file_summary += f" (+{len(filenames) - 3} more)"

    return f"{prefix}: modify {len(changes)} file(s) [{file_summary}] ({change_summary})"


def _clean_text(text):
    """Clean text for use in a commit message."""
    text = text.strip()
    if len(text) > 50:
        text = text[:47] + "..."
    return text


def _contains_import(content):
    """Check if content contains import statements."""
    patterns = [r"import\s+", r"from\s+\S+\s+import", r"#include", r"require\("]
    return any(re.search(p, content) for p in patterns)


def _contains_function_def(content):
    """Check if content contains function/class definitions."""
    patterns = [r"def\s+\w+", r"function\s+\w+", r"class\s+\w+",
                r"fn\s+\w+", r"func\s+\w+", r"public\s+(static\s+)?void"]
    return any(re.search(p, content) for p in patterns)


def _extract_function_name(content):
    """Try to extract a function or class name from content."""
    match = re.search(r"(?:def|function|class|fn|func)\s+(\w+)", content)
    return match.group(1) if match else None
