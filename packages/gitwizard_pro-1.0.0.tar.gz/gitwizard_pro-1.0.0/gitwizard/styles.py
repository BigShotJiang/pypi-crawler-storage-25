"""
Terminal styles, colors, and UI utilities for GitWizard.
"""

import os
import sys
import shutil


class Colors:
    """ANSI color codes for terminal output."""

    RESET     = "\033[0m"
    BOLD      = "\033[1m"
    DIM       = "\033[2m"
    UNDERLINE = "\033[4m"

    BLACK   = "\033[30m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"

    BG_BLACK   = "\033[40m"
    BG_RED     = "\033[41m"
    BG_GREEN   = "\033[42m"
    BG_YELLOW  = "\033[43m"
    BG_BLUE    = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN    = "\033[46m"
    BG_WHITE   = "\033[47m"

    _enabled = None

    @classmethod
    def enabled(cls):
        """Check if terminal supports ANSI colors."""
        if cls._enabled is not None:
            return cls._enabled
        if os.environ.get("NO_COLOR"):
            cls._enabled = False
            return False
        if not hasattr(sys.stdout, "isatty"):
            cls._enabled = False
            return False
        if not sys.stdout.isatty():
            cls._enabled = False
            return False
        if os.name == "nt":
            cls._enabled = bool(
                os.environ.get("ANSICON") or os.environ.get("WT_SESSION")
            )
        else:
            cls._enabled = True
        return cls._enabled

    @classmethod
    def disable(cls):
        cls._enabled = False

    @classmethod
    def enable(cls):
        cls._enabled = True


def c(text, color_code):
    """Apply a color code to text, respecting color support."""
    if Colors.enabled():
        return f"{color_code}{text}{Colors.RESET}"
    return text


def red(text):      return c(text, Colors.RED)
def green(text):    return c(text, Colors.GREEN)
def yellow(text):   return c(text, Colors.YELLOW)
def blue(text):     return c(text, Colors.BLUE)
def magenta(text):  return c(text, Colors.MAGENTA)
def cyan(text):     return c(text, Colors.CYAN)
def bold(text):     return c(text, Colors.BOLD)
def dim(text):      return c(text, Colors.DIM)


def banner(title, subtitle=None, width=60):
    """Print a styled banner header."""
    line = "=" * width
    print()
    if subtitle:
        print(cyan(line))
        print(cyan(f"  {bold(title)}"))
        print(cyan(f"  {subtitle}"))
        print(cyan(line))
    else:
        print(cyan(f"{bold(line)}"))
        print(cyan(f"  {bold(title)}"))
        print(cyan(f"{bold(line)}"))
    print()


def success(text):
    print(f"  {green('  [OK]')} {text}")


def error(text):
    print(f"  {red('  [ERROR]')} {text}")


def warning(text):
    print(f"  {yellow('  [!]')} {text}")


def info(text):
    print(f"  {blue('  [i]')} {text}")


def step(number, total, text):
    print(f"  {cyan(f'  [{number}/{total}]')} {text}")


def progress_bar(current, total, width=30):
    """Print an ASCII progress bar on the same line."""
    if total == 0:
        percent = 100
    else:
        percent = int((current / total) * 100)
    filled = int(width * current // max(total, 1))
    bar = green(chr(9608) * filled) + dim(chr(9617) * (width - filled))
    print(f"\r  [{bar}] {percent}% ({current}/{total})", end="", flush=True)


def separator(char="-", width=60):
    """Print a separator line."""
    print(dim(char * width))


def prompt_input(message, default=None):
    """Prompt user for input with optional default value."""
    if default:
        result = input(f"  {cyan('?')} {message} {dim(f'[{default}]:')}")
        return result.strip() if result.strip() else default
    else:
        return input(f"  {cyan('?')} {message}: ").strip()


def prompt_confirm(message, default=True):
    """Prompt user for yes/no confirmation."""
    hint = "Y/n" if default else "y/N"
    result = input(f"  {cyan('?')} {message} {dim(f'({hint}):')} ").strip().lower()
    if not result:
        return default
    return result in ("y", "yes")


def terminal_width():
    """Get the terminal width, defaulting to 80."""
    return shutil.get_terminal_size(fallback=(80, 24)).columns
