"""
GitHub authentication module for GitWizard.
Handles GitHub CLI (gh) authentication checks and VS Code authorization.
Provides interactive setup guidance for first-time users.
"""

import subprocess

from .styles import (
    success, error, warning, info, cyan, bold, dim,
    green, banner, separator, prompt_confirm
)
from .git_ops import is_gh_installed, run


def check_gh_auth():
    """
    Check if the GitHub CLI is authenticated.

    Returns:
        dict: authenticated, username, scopes, message, fix
    """
    if not is_gh_installed():
        return {
            "authenticated": False,
            "username": None,
            "scopes": [],
            "message": "GitHub CLI (gh) is not installed.",
            "fix": "Install from: https://cli.github.com/",
        }

    code, stdout, stderr = run(["gh", "auth", "status"], check=False)
    output = stdout + stderr

    if code != 0:
        return {
            "authenticated": False,
            "username": None,
            "scopes": [],
            "message": "GitHub CLI is installed but not authenticated.",
            "fix": "Run: gh auth login",
        }

    username = None
    scopes = []
    for line in output.splitlines():
        line = line.strip()
        if "Logged in to" in line:
            parts = line.split()
            for i, part in enumerate(parts):
                if part == "as" and i + 1 < len(parts):
                    username = parts[i + 1].rstrip(",")
                    break
        if "Token scopes:" in line or "scopes:" in line:
            scope_str = line.split(":", 1)[-1].strip()
            scopes = [s.strip() for s in scope_str.split(",") if s.strip()]

    return {
        "authenticated": True,
        "username": username,
        "scopes": scopes,
        "message": f"Authenticated as {username}" if username else "Authenticated",
        "fix": None,
    }


def guide_auth():
    """
    Interactive guide to help the user set up GitHub authentication.
    Returns True if authenticated, False otherwise.
    """
    banner("GitHub Authentication Setup", "VS Code + GitHub CLI")

    if not is_gh_installed():
        error("GitHub CLI (gh) is not installed on your system.")
        print()
        info("GitHub CLI is required for authentication.")
        print()
        print(f"  {cyan('Install methods:')}")
        print(f"    {dim('macOS:')}   brew install gh")
        print(f"    {dim('Ubuntu:')}  sudo apt install gh")
        print(f"    {dim('Windows:')} winget install GitHub.cli")
        print(f"    {dim('Download:')} https://cli.github.com/")
        print()
        info("After installing, run 'gitwizard auth' again.")
        return False

    auth = check_gh_auth()
    if auth["authenticated"]:
        success(f"You are already authenticated as {bold(auth['username'])}!")
        print()
        info("Your GitHub integration with VS Code is working.")
        if auth["scopes"]:
            print(f"  {dim('Token scopes:')} {', '.join(auth['scopes'])}")
        print()
        print(f"  {cyan('To re-authenticate:')}")
        print(f"    {dim('1.')} gh auth logout")
        print(f"    {dim('2.')} gitwizard auth")
        return True

    warning("GitHub CLI is not authenticated.")
    print()
    info("Follow these steps to authenticate:")
    print()
    print(f"  {cyan('Step 1:')} Run this command in your terminal:")
    print(f"           {bold(green('gh auth login'))}")
    print()
    print(f"  {cyan('Step 2:')} Choose your preferences:")
    print(f"           {dim('- GitHub.com or GitHub Enterprise')}")
    print(f"           {dim('- HTTPS or SSH')}")
    print(f"           {dim('- Login with web browser (recommended)')}")
    print()
    print(f"  {cyan('Step 3:')} Grant these scopes when prompted:")
    print(f"           {dim('- repo (full control of private repositories)')}")
    print(f"           {dim('- read:org (read organization membership)')}")
    print(f"           {dim('- workflow (update GitHub Actions workflows)')}")
    print()
    separator()

    if prompt_confirm("Do you want to start GitHub login now?", default=True):
        print()
        info("Launching GitHub CLI login...")
        print()
        try:
            subprocess.run(["gh", "auth", "login"])
            print()
            auth = check_gh_auth()
            if auth["authenticated"]:
                success(f"Authentication successful! Logged in as {bold(auth['username'])}")
                return True
            else:
                error("Authentication did not complete successfully.")
                info("Please try again or check your network connection.")
                return False
        except KeyboardInterrupt:
            print()
            warning("Authentication was cancelled.")
            return False
    else:
        print()
        info("No problem! You can authenticate later:")
        print(f"         {bold('gh auth login')}")
        print()
        info("Then verify with:")
        print(f"         {bold('gitwizard auth')}")
        return False


def require_auth():
    """
    Ensure the user is authenticated. If not, guide them through setup.
    Returns True if authenticated, False otherwise.
    """
    auth = check_gh_auth()
    if auth["authenticated"]:
        return True
    warning("GitHub is not authenticated. Required for this operation.")
    print()
    return guide_auth()
