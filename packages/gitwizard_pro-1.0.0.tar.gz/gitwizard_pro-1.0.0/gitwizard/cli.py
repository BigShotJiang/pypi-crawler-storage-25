"""
GitWizard v1.0.0 - Main CLI Entry Point
================================================
Universal Git Commit & Push Automation CLI Tool
Powered By Programmer Fahim

Commands:
  setup   - Interactive repo setup (init, add, commit, push)
  push    - Smart diff-based commit & push (auto or manual message)
  auto    - Bulk auto-commit generator (200+ language support)
  auth    - GitHub / VS Code authentication check & setup
  help    - Documentation link & report issue link
"""

import os
import sys
import random
import time
import argparse
from datetime import datetime

from . import __version__, __docs_url__
from .styles import (
    Colors, banner, success, error, warning, info,
    step, progress_bar, separator, prompt_input,
    prompt_confirm, cyan, bold, dim, green, red, yellow
)
from .git_ops import (
    GitError, git, is_git_repo, has_remote, has_any_changes,
    has_staged_changes, init_repo, add,
    commit, push, push_force, add_remote, set_branch_name,
    get_current_branch, get_diff, get_changed_files, get_staged_files,
    stage_file, unstage_all, get_diff_for_file
)
from .auth import check_gh_auth, guide_auth, require_auth
from .diff_analyzer import (
    generate_commit_message, generate_atomic_messages,
    get_change_summary
)


# =============================================================================
# Command: setup
# =============================================================================

def cmd_setup(args):
    """
    Interactive setup: auth -> git init -> add -> commit -> push.
    One command to connect your project to GitHub.
    """
    banner("GitWizard - Setup", "Initialize and push your project to GitHub")

    # Step 1: GitHub Authentication
    print(f"  {cyan('Step 1: GitHub Authentication')}")
    separator()
    auth = check_gh_auth()
    if not auth["authenticated"]:
        warning("GitHub is not authenticated.")
        print()
        if not prompt_confirm("Set up GitHub authentication now?", default=True):
            error("GitHub authentication is required for setup. Aborting.")
            print()
            info("Run 'gitwizard auth' to authenticate first.")
            return
        print()
        if not require_auth():
            error("Authentication failed. Aborting setup.")
            return
        print()
    else:
        success(f"GitHub authenticated as '{auth['username']}'")
    print()

    # Step 2: Git Init
    print(f"  {cyan('Step 2: Git Repository')}")
    separator()
    if is_git_repo():
        success("Git repository already exists.")
        branch = get_current_branch()
        info(f"Current branch: {branch}")
    else:
        info("Initializing new git repository...")
        try:
            init_repo()
            success("Git repository initialized.")
        except GitError as e:
            error(f"Failed to initialize git repository: {e}")
            return
    print()

    # Step 3: Stage Files
    print(f"  {cyan('Step 3: Stage Files')}")
    separator()
    try:
        add(".")
        files = get_staged_files()
        if files:
            success(f"Staged {len(files)} file(s) for commit.")
            for f in files[:10]:
                print(f"    {dim('>')} {f}")
            if len(files) > 10:
                print(f"    {dim(f'... and {len(files) - 10} more')}")
        else:
            info("No new files to stage (existing repo).")
    except GitError as e:
        error(f"Failed to stage files: {e}")
        return
    print()

    # Step 4: Commit
    print(f"  {cyan('Step 4: Commit')}")
    separator()
    default_msg = f"Initial commit - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    commit_msg = prompt_input("Enter commit message", default=default_msg)
    if not commit_msg:
        error("Commit message cannot be empty.")
        return
    try:
        if has_staged_changes():
            commit(commit_msg)
            success(f"Committed: \"{commit_msg}\"")
        else:
            info("Nothing new to commit.")
    except GitError as e:
        error(f"Failed to commit: {e}")
        return
    print()

    # Step 5: GitHub Repository URL
    print(f"  {cyan('Step 5: Connect to GitHub')}")
    separator()
    repo_url = prompt_input("Enter your GitHub repository URL (e.g., https://github.com/user/repo.git)")
    if not repo_url:
        error("Repository URL is required.")
        return
    print()
    try:
        add_remote("origin", repo_url)
        success(f"Remote 'origin' set to: {repo_url}")
    except GitError as e:
        error(f"Failed to set remote: {e}")
        return
    print()

    # Step 6: Push
    print(f"  {cyan('Step 6: Push to GitHub')}")
    separator()
    branch = get_current_branch() or "main"
    if branch != "main":
        info(f"Current branch is '{branch}'. Renaming to 'main'...")
        set_branch_name("main")
        branch = "main"
        success("Branch renamed to 'main'.")

    info(f"Pushing to {repo_url} (branch: {branch})...")
    print()
    try:
        push("origin", branch)
        success("Code pushed to GitHub successfully!")
    except GitError:
        warning("Regular push failed. Trying force push (safe for new repos)...")
        try:
            push_force("origin", branch)
            success("Code force-pushed to GitHub successfully!")
        except GitError as e:
            error(f"Push failed: {e}")
            info("Make sure the repository exists on GitHub and you have push access.")
            return
    print()
    banner("Setup Complete!", "Your project is now on GitHub")
    success("Your code has been committed and pushed to GitHub.")
    info(f"Repository: {repo_url}")
    info(f"Branch: {branch}")
    print()
    info("From now on, just make changes and run:")
    print(f"         {bold('gitwizard push')}")
    print()


# =============================================================================
# Command: push
# =============================================================================

def cmd_push(args):
    """
    Smart push: detect changes, generate (or use custom) commit message, commit & push.
    """
    banner("GitWizard - Push", "Smart commit & push based on code changes")

    if not is_git_repo():
        error("Not inside a git repository!")
        info("Run 'gitwizard setup' to initialize a new project.")
        return

    try:
        add(".")
    except GitError as e:
        error(f"Failed to stage files: {e}")
        return

    diff_output = get_diff(staged=True)
    if not diff_output.strip() and not has_staged_changes():
        info("No changes detected. Everything is up to date.")
        return

    print(f"  {cyan('Detected Changes:')}")
    separator()
    summary = get_change_summary(diff_output)
    print(f"  {summary}")
    print()

    do_push = not args.no_push

    if args.atomic:
        _push_atomic(diff_output, args.message, do_push)
    else:
        _push_single(diff_output, args.message, do_push)


def _push_single(diff_output, custom_message=None, do_push=True):
    """Handle single-commit push."""
    if custom_message:
        commit_msg = custom_message
        info(f"Using custom commit message: \"{commit_msg}\"")
    else:
        commit_msg = generate_commit_message(diff_output)
        info(f"Auto-generated commit message: \"{commit_msg}\"")
    print()

    try:
        commit(commit_msg)
        success(f"Committed: \"{commit_msg}\"")
    except GitError as e:
        error(f"Failed to commit: {e}")
        return

    if do_push and has_remote():
        branch = get_current_branch()
        info(f"Pushing to remote ({branch})...")
        try:
            push("origin", branch)
            success("Pushed to GitHub successfully!")
        except GitError as e:
            warning(f"Push failed: {e}")
            info("Your changes are committed locally. Push manually: git push")
    elif do_push and not has_remote():
        warning("No remote repository configured.")
        info("Your changes are committed locally.")
        info("Run 'gitwizard setup' to connect to a GitHub repository.")
    else:
        info("Committed locally (push skipped by --no-push flag).")

    print()
    success("Done!")
    print()


def _push_atomic(diff_output, custom_message=None, do_push=True):
    """Handle atomic per-file push."""
    messages = generate_atomic_messages(diff_output)
    if not messages:
        info("No individual changes to commit.")
        return

    info(f"Creating {len(messages)} atomic commit(s)...")
    print()

    try:
        unstage_all()
    except GitError:
        pass

    success_count = 0
    for i, item in enumerate(messages):
        filepath = item["file"]
        msg = custom_message or item["message"]

        try:
            stage_file(filepath)
        except GitError:
            continue

        file_diff = get_diff_for_file(filepath, staged=True)
        if not file_diff.strip():
            continue

        if custom_message:
            per_file_msg = f"{custom_message} [{os.path.basename(filepath)}]"
        else:
            per_file_msg = msg

        try:
            commit(per_file_msg)
            success(f"  [{i+1}/{len(messages)}] {per_file_msg}")
            success_count += 1
        except GitError as e:
            warning(f"  [{i+1}/{len(messages)}] Skipped {filepath}: {e}")

    if success_count > 0:
        print()
        success(f"Created {success_count} atomic commit(s).")
        if do_push and has_remote():
            branch = get_current_branch()
            info(f"Pushing {success_count} commit(s) to remote ({branch})...")
            try:
                push("origin", branch)
                success("All atomic commits pushed to GitHub!")
            except GitError as e:
                warning(f"Push failed: {e}")
                info("Commits are saved locally. Push manually: git push")
        elif do_push and not has_remote():
            warning("No remote repository configured.")
            info("Commits are saved locally.")
    else:
        warning("No commits were created.")
    print()


# =============================================================================
# Command: auto (200+ language support, human-like commits)
# =============================================================================

# Human-like commit messages — indistinguishable from real developer commits
HUMAN_COMMIT_MESSAGES = [
    "fix minor issue",
    "update comments",
    "refactor code",
    "clean up code",
    "improve readability",
    "add documentation",
    "optimize logic",
    "fix typo",
    "update type hints",
    "improve error handling",
    "clean up imports",
    "add inline comments",
    "improve code structure",
    "fix formatting",
    "update docstring",
    "minor cleanup",
    "improve variable naming",
    "simplify logic",
    "refactor helper function",
    "update module docstring",
    "fix edge case",
    "improve validation",
    "add TODO note",
    "clean up whitespace",
    "improve function signature",
    "refactor constants",
    "update README",
    "fix lint warnings",
    "improve code clarity",
    "reorganize imports",
    "remove unused reference",
    "update default values",
    "improve exception handling",
    "add type annotation",
    "simplify condition",
    "improve naming convention",
    "fix off-by-one error",
    "update configuration",
    "improve string formatting",
    "refactor utility function",
    "add safety check",
    "improve test coverage",
    "clean up dead code",
    "optimize query logic",
    "fix race condition",
    "update dependency version",
    "improve logging",
    "refactor error messages",
    "simplify data flow",
    "fix memory leak",
    "improve cache strategy",
    "update environment config",
    "normalize data format",
    "fix boundary condition",
    "improve request handler",
    "update response format",
    "refactor middleware",
    "clean up test fixtures",
    "improve retry logic",
    "fix async handler",
    "update validation rules",
    "simplify callback chain",
    "improve buffer handling",
    "fix null pointer check",
    "update schema definition",
    "refactor parser logic",
    "improve file handling",
    "add boundary test",
    "clean up console logs",
    "fix timezone handling",
    "improve search logic",
    "update regex pattern",
    "refactor state management",
    "improve access control",
    "fix pagination logic",
    "update email template",
    "improve token validation",
    "clean up debug code",
    "fix character encoding",
    "improve path handling",
    "refactor event handler",
    "update serialization",
    "improve input sanitization",
    "fix content-type header",
    "update rate limiter",
    "improve CORS handling",
    "refactor database query",
    "fix index out of bounds",
    "update migration script",
    "improve webhook handler",
    "simplify auth flow",
    "fix session expiry",
    "update template engine",
    "improve file upload",
    "refactor notification",
    "fix redirect loop",
    "update cache headers",
    "improve queue processing",
    "fix concurrent access",
    "update health check",
    "improve graceful shutdown",
    "refactor worker pool",
    "fix connection timeout",
    "update retry policy",
    "improve stream handling",
    "fix parsing error",
    "update build config",
    "improve bundle size",
    "refactor component tree",
    "fix hydration mismatch",
    "update render logic",
    "improve layout system",
    "fix style leak",
    "update theme config",
    "improve accessibility",
    "refactor hook logic",
    "fix scroll behavior",
    "update form validation",
    "improve focus management",
]

# Natural developer-style comments added to files (not timestamps)
NATURAL_COMMENTS = [
    "optimized for better readability",
    "refactored for clarity",
    "performance improvement",
    "cleanup and minor fixes",
    "updated logic for edge cases",
    "improved error handling here",
    "added validation check",
    "simplified the flow",
    "better approach for this section",
    "minor refactor",
    "clean up pass",
    "removed redundancy",
    "more robust implementation",
    "updated for consistency",
    "fixed potential issue",
    "streamlined logic",
    "added safety check",
    "improved efficiency",
    "better variable naming",
    "restructured for maintainability",
    "addressed code review feedback",
    "simplified conditional logic",
    "improved documentation clarity",
    "reduced complexity",
    "better abstraction",
    "optimized data flow",
    "clean implementation",
    "straightforward approach",
    "defensive coding applied",
    "improved type safety",
    "reduced duplication",
    "clearer intent",
    "more explicit handling",
    "consistent style applied",
    "self-documenting code",
    "followed best practice",
    "reduced coupling",
    "improved cohesion",
    "simpler interface",
    "better separation of concerns",
]

# 200+ supported file extensions
SUPPORTED_EXTENSIONS = (
    # --- Python ---
    ".py", ".pyw", ".pyi", ".pyx", ".pxd", ".py3",
    # --- JavaScript / TypeScript ---
    ".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx", ".mts", ".cts",
    # --- Web ---
    ".html", ".htm", ".css", ".scss", ".sass", ".less", ".vue", ".svelte", ".astro",
    ".pug", ".haml", ".slim", ".ejs", ".hbs", ".mustache", ".jade",
    # --- C / C++ / Obj-C ---
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cxx", ".c++", ".h++", ".hh", ".ino",
    # --- C# / .NET ---
    ".cs", ".csx", ".vb", ".vbs", ".bas", ".fs", ".fsi", ".fsx",
    # --- Java / JVM ---
    ".java", ".jar", ".class", ".kt", ".kts", ".scala", ".sc", ".groovy", ".gradle",
    ".clj", ".cljs", ".clojure",
    # --- Go ---
    ".go",
    # --- Rust ---
    ".rs",
    # --- Swift ---
    ".swift",
    # --- Dart / Flutter ---
    ".dart",
    # --- Ruby ---
    ".rb", ".erb", ".rake", ".gemspec", ".ru", ".rmd",
    # --- PHP ---
    ".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".pht",
    # --- Perl ---
    ".pl", ".pm", ".t", ".psgi",
    # --- Lua ---
    ".lua",
    # --- R ---
    ".r", ".R", ".rmd", ".rmarkdown", ".rprofile",
    # --- MATLAB / Octave ---
    ".m", ".matlab",
    # --- Shell / Scripting ---
    ".sh", ".bash", ".zsh", ".fish", ".ps1", ".psm1", ".psd1", ".bat", ".cmd",
    ".ksh", ".csh", ".tcsh", ".dash",
    # --- SQL ---
    ".sql", ".mysql", ".pgsql", ".sqlite", ".plsql", ".mdb",
    # --- Config / Data ---
    ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".env", ".properties",
    ".json", ".json5", ".jsonc", ".xml", ".xhtml", ".xsl", ".xslt", ".svg",
    ".csv", ".tsv", ".bson",
    # --- Haskell ---
    ".hs", ".lhs",
    # --- Erlang ---
    ".erl", ".hrl",
    # --- Elixir ---
    ".ex", ".exs",
    # --- Lisp / Scheme ---
    ".lisp", ".cl", ".el", ".emacs", ".scm", ".rkt", ".hy",
    # --- Julia ---
    ".jl",
    # --- Nim ---
    ".nim", ".nims",
    # --- Zig ---
    ".zig",
    # --- D ---
    ".d",
    # --- Ada / SPARK ---
    ".ada", ".adb", ".ads",
    # --- Fortran ---
    ".f", ".f90", ".f95", ".f03", ".f08", ".for",
    # --- Pascal / Delphi ---
    ".pas", ".pp", ".dpk", ".dpr", ".lfm",
    # --- COBOL ---
    ".cob", ".cbl", ".cpy",
    # --- Assembly ---
    ".asm", ".s", ".S", ".nasm", ".masm",
    # --- Tcl ---
    ".tcl",
    # --- Make / Build ---
    ".mk", ".mak",
    # --- Docker / Containers ---
    ".dockerfile", ".containerfile",
    # --- Nix ---
    ".nix",
    # --- Terraform / IaC ---
    ".tf", ".tfvars", ".hcl",
    # --- Protobuf / GraphQL ---
    ".proto", ".graphql", ".gql",
    # --- WASM ---
    ".wat", ".wast",
    # --- Solidity / Web3 ---
    ".sol",
    # --- Apex / Salesforce ---
    ".cls", ".apex", ".trigger",
    # --- ColdFusion ---
    ".cfm", ".cfc",
    # --- VHDL / Verilog ---
    ".vhd", ".vhdl", ".v", ".sv", ".svh",
    # --- ABAP (SAP) ---
    ".abap",
    # --- M4 / Autoconf ---
    ".m4",
    # --- Roff / Man pages ---
    ".roff", ".man", ".mdoc",
    # --- TeX / LaTeX ---
    ".tex", ".latex", ".bib", ".bbl", ".sty", ".cls",
    # --- Markdown / Docs ---
    ".md", ".rst", ".adoc", ".asciidoc", ".org", ".txt", ".log",
    # --- ReStructuredText ---
    ".rest", ".restx",
    # --- Robot Framework ---
    ".robot",
    # --- Twig ---
    ".twig",
    # --- Jinja ---
    ".j2", ".jinja", ".jinja2",
    # --- Blade (Laravel) ---
    ".blade.php",
    # --- Smarty ---
    ".tpl",
    # --- CoffeeScript ---
    ".coffee",
    # --- LiveScript ---
    ".ls",
    # --- Idris ---
    ".idr", ".lidr",
    # --- Agda ---
    ".agda",
    # --- Coq ---
    ".v",
    # --- Lean ---
    ".lean",
    # --- Mercury ---
    ".m",
    # --- Crystal ---
    ".cr",
    # --- Wren ---
    ".wren",
    # --- Io ---
    ".io",
    # --- Factor ---
    ".factor",
    # --- Joy ---
    ".joy",
    # --- Forth ---
    ".fs", ".fth",
    # --- AWK ---
    ".awk", ".gawk",
    # --- Sed ---
    ".sed",
    # --- Vimscript ---
    ".vim",
    # --- PowerShell ---
    ".ps1",
)

# Comment styles for different languages
COMMENT_STYLES = {
    "hash":      ("#", ""),
    "slash":     ("//", ""),
    "dash":      ("--", ""),
    "semicolon": (";", ""),
    "percent":   ("%", ""),
    "html":      ("<!--", "-->"),
    "css":       ("/*", "*/"),
}

# Map every extension to its comment style
EXTENSION_MAP = {
    # Hash style: # comment
    ".py": "hash", ".pyw": "hash", ".pyi": "hash", ".pyx": "hash", ".pxd": "hash", ".py3": "hash",
    ".rb": "hash", ".erb": "hash", ".rake": "hash", ".gemspec": "hash", ".ru": "hash", ".rmd": "hash",
    ".sh": "hash", ".bash": "hash", ".zsh": "hash", ".fish": "hash", ".ksh": "hash", ".csh": "hash",
    ".tcsh": "hash", ".dash": "hash",
    ".r": "hash", ".R": "hash", ".rmarkdown": "hash", ".rprofile": "hash",
    ".yaml": "hash", ".yml": "hash", ".toml": "hash", ".ini": "hash", ".cfg": "hash",
    ".conf": "hash", ".env": "hash", ".properties": "hash",
    ".pl": "hash", ".pm": "hash", ".t": "hash", ".psgi": "hash",
    ".awk": "hash", ".gawk": "hash",
    ".vim": "hash",
    ".dockerfile": "hash", ".containerfile": "hash",
    ".nix": "hash",
    ".tf": "hash", ".tfvars": "hash", ".hcl": "hash",
    ".m4": "hash", ".mak": "hash", ".mk": "hash",
    ".robot": "hash",
    ".j2": "hash", ".jinja": "hash", ".jinja2": "hash",
    ".cr": "hash", ".wren": "hash", ".io": "hash", ".joy": "hash", ".factor": "hash",
    ".fs": "hash",
    # Slash style: // comment
    ".js": "slash", ".jsx": "slash", ".mjs": "slash", ".cjs": "slash",
    ".ts": "slash", ".tsx": "slash", ".mts": "slash", ".cts": "slash",
    ".java": "slash", ".jar": "slash", ".class": "slash",
    ".c": "slash", ".h": "slash", ".cpp": "slash", ".hpp": "slash",
    ".cc": "slash", ".cxx": "slash", ".c++": "slash", ".h++": "slash",
    ".hh": "slash", ".ino": "slash",
    ".cs": "slash", ".csx": "slash",
    ".go": "slash",
    ".rs": "slash",
    ".kt": "slash", ".kts": "slash",
    ".swift": "slash",
    ".scala": "slash", ".sc": "slash",
    ".groovy": "slash", ".gradle": "slash",
    ".dart": "slash",
    ".zig": "slash",
    ".php": "slash", ".phtml": "slash", ".php3": "slash", ".php4": "slash",
    ".php5": "slash", ".php7": "slash", ".phps": "slash", ".pht": "slash",
    ".clj": "slash", ".cljs": "slash", ".clojure": "slash",
    ".lua": "slash",
    ".glsl": "slash", ".hlsl": "slash",
    ".d": "slash",
    ".fsi": "slash", ".fsx": "slash",
    ".sol": "slash",
    ".cls": "slash", ".apex": "slash", ".trigger": "slash",
    ".cfm": "slash", ".cfc": "slash",
    ".abap": "slash",
    ".sv": "slash", ".svh": "slash",
    ".proto": "slash", ".graphql": "slash", ".gql": "slash",
    ".wat": "slash", ".wast": "slash",
    ".nim": "slash", ".nims": "slash",
    ".coffee": "slash",
    ".ls": "slash",
    ".idr": "slash", ".lidr": "slash",
    ".agda": "slash",
    ".lean": "slash",
    ".vhd": "slash", ".vhdl": "slash",
    ".mercury": "slash",
    ".fth": "slash",
    ".ps1": "slash", ".psm1": "slash", ".psd1": "slash",
    # Dash style: -- comment
    ".sql": "dash", ".mysql": "dash", ".pgsql": "dash", ".sqlite": "dash",
    ".plsql": "dash", ".mdb": "dash",
    ".hs": "dash", ".lhs": "dash",
    ".erl": "dash", ".hrl": "dash",
    ".ex": "dash", ".exs": "dash",
    ".lua": "dash",
    ".tcl": "dash",
    ".hql": "dash",
    # Semicolon style: ; comment
    ".asm": "semicolon", ".s": "semicolon", ".S": "semicolon",
    ".nasm": "semicolon", ".masm": "semicolon",
    ".f": "semicolon", ".f90": "semicolon", ".f95": "semicolon",
    ".f03": "semicolon", ".f08": "semicolon", ".for": "semicolon",
    ".v": "semicolon",
    ".lisp": "semicolon", ".cl": "semicolon", ".el": "semicolon",
    ".emacs": "semicolon", ".scm": "semicolon", ".rkt": "semicolon", ".hy": "semicolon",
    ".coq": "semicolon",
    # Percent style: % comment
    ".tex": "percent", ".latex": "percent", ".bib": "percent", ".bbl": "percent",
    ".sty": "percent", ".cls": "percent",
    ".matlab": "percent",
    ".erlang": "percent",
    ".m": "percent",
    # HTML style: <!-- comment -->
    ".html": "html", ".htm": "html",
    ".xml": "html", ".xhtml": "html", ".svg": "html",
    ".xsl": "html", ".xslt": "html",
    ".pug": "html", ".haml": "html", ".slim": "html",
    ".ejs": "html", ".hbs": "html", ".mustache": "html", ".jade": "html",
    ".vue": "html", ".svelte": "html", ".astro": "html",
    ".tpl": "html", ".twig": "html",
    ".adoc": "html", ".asciidoc": "html",
    ".rest": "html", ".restx": "html",
    ".roff": "html", ".man": "html", ".mdoc": "html",
    # CSS style: /* comment */
    ".css": "css", ".scss": "css", ".sass": "css", ".less": "css",
    ".json": "css", ".json5": "css", ".jsonc": "css",
    ".csv": "css", ".tsv": "css",
    ".md": "css", ".rst": "css", ".org": "css", ".txt": "css", ".log": "css",
    ".vb": "css", ".vbs": "css", ".bas": "css",
    ".bat": "css", ".cmd": "css",
    ".cob": "css", ".cbl": "css", ".cpy": "css",
    ".ada": "css", ".adb": "css", ".ads": "css",
    ".pas": "css", ".pp": "css", ".dpk": "css", ".dpr": "css", ".lfm": "css",
    ".bson": "css",
    ".sed": "css",
    ".blade.php": "css",
}


def cmd_auto(args):
    """
    Bulk auto-commit: appends natural developer-style comments to tracked files.
    Commit messages look human-written. 200+ language support.
    """
    repeat = args.count
    min_delay = args.min_delay
    max_delay = args.max_delay
    dry_run = args.dry_run
    message_template = args.message
    auto_push = args.push

    banner("GitWizard - Bulk Generator", f"Creating {repeat} commit(s)")

    if not is_git_repo():
        error("Not inside a git repository!")
        info("Run 'gitwizard setup' first to initialize a project.")
        return

    tracked_output = git("ls-files")
    tracked_files = tracked_output.splitlines() if tracked_output else []

    valid_files = [
        f for f in tracked_files
        if f.lower().endswith(SUPPORTED_EXTENSIONS)
    ]

    if not valid_files:
        error("No supported tracked files found in this repository.")
        info(f"Supported extensions: {len(SUPPORTED_EXTENSIONS)}+ types")
        return

    info(f"Found {len(valid_files)} supported file(s) for auto-commit.")
    info(f"Delay: {min_delay}s - {max_delay}s | Push: {'Yes' if auto_push else 'No'} | Dry-run: {'Yes' if dry_run else 'No'}")
    print()

    try:
        print(f"  {cyan('Generating commits...')}")
        print()
        separator()

        for i in range(1, repeat + 1):
            file_to_edit = random.choice(valid_files)
            ext = os.path.splitext(file_to_edit)[1].lower()

            # Pick comment style based on file type
            style_key = EXTENSION_MAP.get(ext, "slash")
            start_symbol, end_symbol = COMMENT_STYLES[style_key]

            # Pick a natural developer-style comment (not timestamp)
            natural_comment = random.choice(NATURAL_COMMENTS)

            # Build the comment line
            if end_symbol:
                comment_line = f"{start_symbol} {natural_comment} {end_symbol}"
            else:
                comment_line = f"{start_symbol} {natural_comment}"

            # Pick a human-like commit message
            if auto_push:
                # When pushing to remote: use human-like message (indistinguishable)
                commit_message = random.choice(HUMAN_COMMIT_MESSAGES)
            else:
                # Local only: use template or human-like
                commit_message = random.choice(HUMAN_COMMIT_MESSAGES)

            # Allow user custom template override
            if message_template and message_template != "auto commit at {time}":
                commit_message = message_template.format(
                    time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    iteration=i,
                    file=file_to_edit
                )

            if dry_run:
                print(f"  {yellow('[DRY RUN]')} Would modify: {file_to_edit}")
                print(f"  {yellow('[DRY RUN]')} Comment: \"{natural_comment}\"")
                print(f"  {yellow('[DRY RUN]')} Commit: \"{commit_message}\"")
            else:
                with open(file_to_edit, "a", encoding="utf-8", errors="ignore") as f:
                    f.write(f"\n{comment_line}\n")
                try:
                    add(".")
                    commit(commit_message)
                    if auto_push and has_remote():
                        branch = get_current_branch()
                        push("origin", branch)
                except GitError as e:
                    warning(f"Commit {i} failed: {e}")

            progress_bar(i, repeat)
            time.sleep(random.uniform(min_delay, max_delay))

        print()
        print()
        if dry_run:
            success(f"Dry run complete! Would create {repeat} commit(s).")
        else:
            success(f"All {repeat} commit(s) completed successfully!")
            if auto_push:
                info("All commits were pushed to remote.")

    except KeyboardInterrupt:
        print()
        print()
        warning("Interrupted safely (Ctrl+C).")
        info(f"Completed {i if 'i' in dir() else 0} of {repeat} commit(s).")

    print()


# =============================================================================
# Command: auth
# =============================================================================

def cmd_auth(args):
    """Check or set up GitHub / VS Code authentication."""
    banner("GitWizard - Authentication", "GitHub / VS Code Authorization")

    if args.check:
        auth = check_gh_auth()
        if auth["authenticated"]:
            success(f"Authenticated as '{auth['username']}'")
            if auth["scopes"]:
                print(f"  {dim('Scopes:')} {', '.join(auth['scopes'])}")
        else:
            warning("Not authenticated.")
            print(f"  {dim(auth['message'])}")
            if auth.get("fix"):
                print(f"  {dim('Fix:')} {auth['fix']}")
        print()
        return

    guide_auth()


# =============================================================================
# Command: help
# =============================================================================

def cmd_help(args):
    """
    Help command: shows command listing with colors, and links section
    with documentation link + report issue link (both point to docs site).
    """
    banner("GitWizard v1.0.0", "Command Reference & Links")

    print(f"  {bold('COMMANDS')}")
    print()
    print(f"    {green('gitwizard setup')}             {dim('Interactive project setup (init, add, commit, push)')}")
    print(f"    {green('gitwizard push')}              {dim('Smart commit & push based on code changes')}")
    print(f"    {green('gitwizard push -m \"msg\"')}     {dim('Push with custom commit message')}")
    print(f"    {green('gitwizard push --atomic')}      {dim('Separate commit per file change')}")
    print(f"    {green('gitwizard push --no-push')}     {dim('Commit locally without pushing')}")
    print(f"    {green('gitwizard auto --count N')}     {dim('Bulk auto-commit generator')}")
    print(f"    {green('gitwizard auto --count N --push')}{dim('  Bulk auto-commit with auto push')}")
    print(f"    {green('gitwizard auto --count N --dry-run')}{dim(' Preview mode (no actual commits)')}")
    print(f"    {green('gitwizard auth')}              {dim('GitHub / VS Code authentication setup')}")
    print(f"    {green('gitwizard auth --check')}       {dim('Quick auth status check')}")
    print(f"    {green('gitwizard help')}               {dim('Show this help message')}")
    print(f"    {green('gitwizard --version')}         {dim('Show version number')}")
    print()

    print(f"  {bold('LINKS')}")
    print()
    print(f"    {cyan('Documentation:')}  {bold(__docs_url__)}")
    print(f"    {cyan('Report Issues:')}  {bold(__docs_url__)}")
    print()

    separator()
    print(f"  {dim('Powered By Programmer Fahim')}")
    print()


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main CLI entry point."""

    parser = argparse.ArgumentParser(
        prog="gitwizard",
        description="GitWizard v1.0.0 - Universal Git Commit & Push Automation CLI Tool",
        add_help=True,
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s v{__version__}"
    )

    subparsers = parser.add_subparsers(dest="command")

    # ----- setup -----
    subparsers.add_parser("setup", help="Interactive project setup (init, add, commit, push to GitHub)")

    # ----- push -----
    p_push = subparsers.add_parser("push", help="Smart commit & push based on code changes")
    p_push.add_argument("-m", "--message", type=str, default=None, help="Custom commit message")
    p_push.add_argument("--atomic", action="store_true", help="Separate commit per file change")
    p_push.add_argument("--no-push", action="store_true", help="Commit locally without pushing")

    # ----- auto -----
    p_auto = subparsers.add_parser("auto", help="Bulk auto-commit generator")
    p_auto.add_argument("--count", "-c", type=int, required=True, help="Number of commits to generate")
    p_auto.add_argument("--min-delay", type=float, default=2, help="Minimum delay between commits (default: 2)")
    p_auto.add_argument("--max-delay", type=float, default=4, help="Maximum delay between commits (default: 4)")
    p_auto.add_argument("--message", "-m", type=str, default="auto commit at {time}", help='Commit message template')
    p_auto.add_argument("--push", "-p", action="store_true", help="Push to remote after each commit")
    p_auto.add_argument("--dry-run", action="store_true", help="Simulate without making actual commits")

    # ----- auth -----
    p_auth = subparsers.add_parser("auth", help="Check or set up GitHub / VS Code authentication")
    p_auth.add_argument("--check", action="store_true", help="Quick auth status check")

    # ----- help -----
    subparsers.add_parser("help", help="Show command reference and documentation link")

    args = parser.parse_args()

    if args.command == "setup":
        cmd_setup(args)
    elif args.command == "push":
        cmd_push(args)
    elif args.command == "auto":
        cmd_auto(args)
    elif args.command == "auth":
        cmd_auth(args)
    elif args.command == "help":
        cmd_help(args)
    else:
        parser.print_help()
        print()
        info(f"For documentation visit: {__docs_url__}")
        print()


if __name__ == "__main__":
    main()
