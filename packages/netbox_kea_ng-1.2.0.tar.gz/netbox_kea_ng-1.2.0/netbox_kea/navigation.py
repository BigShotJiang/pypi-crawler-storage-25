from netbox.plugins import PluginMenuButton, PluginMenuItem

menu_items = (
    PluginMenuItem(
        link="plugins:netbox_kea:combined",
        link_text="Combined View",
        permissions=["netbox_kea.view_server"],
    ),
    PluginMenuItem(
        link="plugins:netbox_kea:server_list",
        link_text="Servers",
        permissions=["netbox_kea.view_server"],
        buttons=(
            PluginMenuButton(
                link="plugins:netbox_kea:server_add",
                title="Add",
                icon_class="mdi mdi-plus-thick",
                permissions=["netbox_kea.add_server"],
            ),
        ),
    ),
    PluginMenuItem(
        link="plugins:netbox_kea:sync_jobs",
        link_text="Sync Jobs",
        permissions=["netbox_kea.view_server"],
    ),
)
