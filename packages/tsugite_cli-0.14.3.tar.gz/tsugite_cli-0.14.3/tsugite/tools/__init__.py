"""Tool registry for Tsugite agents."""

import inspect
from dataclasses import dataclass
from typing import Any, Callable, Dict, List


@dataclass
class ToolInfo:
    """Information about a registered tool."""

    name: str
    func: Callable
    description: str
    parameters: Dict[str, Any]
    parent_only: bool = False
    interactive_only: bool = False
    category: str | None = None


# Global tool registry
_tools: Dict[str, ToolInfo] = {}

# Daemon-only tools: registered only when daemon mode is active
_daemon_tools: Dict[str, Callable] = {}
_daemon_mode = False


def _register_tool(func: Callable) -> None:
    """Register a function into the tool registry.

    Reads flags (parent_only, interactive_only) from function attributes
    set by the @tool decorator.
    """
    sig = inspect.signature(func)
    doc = func.__doc__ or "No description available"

    parameters = {}
    for param_name, param in sig.parameters.items():
        parameters[param_name] = {
            "type": (param.annotation if param.annotation != inspect.Parameter.empty else str),
            "default": (param.default if param.default != inspect.Parameter.empty else None),
            "required": param.default == inspect.Parameter.empty,
        }

    _tools[func.__name__] = ToolInfo(
        name=func.__name__,
        func=func,
        description=doc.split("\n")[0].strip(),
        parameters=parameters,
        parent_only=getattr(func, "_parent_only", False),
        interactive_only=getattr(func, "_interactive_only", False),
        category=getattr(func, "_category", None),
    )


def tool(func=None, *, require_daemon=False, parent_only=False, interactive_only=False, category: str | None = None):
    """Register a function as a tool.

    Args:
        require_daemon: Only register when running in daemon mode.
        parent_only: If True, tool must run in parent process (not in sandbox).
            Used for tools that need direct user interaction or spawn subprocesses.
        interactive_only: If True, tool is only available when a UI handler is present.
            Hidden in scheduled tasks where there's no way to display output.
        category: Override the category used by @<category> tool specs and
            get_tools_by_category(). Defaults to the function's module basename.
            Plugins should set this when their package name doesn't match the
            user-facing category.
    """

    def decorator(fn):
        fn._parent_only = parent_only
        fn._interactive_only = interactive_only
        fn._category = category
        if require_daemon:
            _daemon_tools[fn.__name__] = fn
            if _daemon_mode:
                _register_tool(fn)
        else:
            _register_tool(fn)
        return fn

    if func is not None:
        return decorator(func)
    return decorator


def set_daemon_mode(enabled: bool):
    """Enable/disable daemon mode. Registers/unregisters daemon-only tools."""
    global _daemon_mode
    # Load tool modules first (before changing mode) so decorators
    # don't double-register when they see _daemon_mode=True during import.
    _ensure_tools_loaded()
    _daemon_mode = enabled
    if enabled:
        for fn in _daemon_tools.values():
            _register_tool(fn)
    else:
        for name in _daemon_tools:
            _tools.pop(name, None)


def get_interactive_only_names() -> set:
    """Return names of tools marked interactive_only."""
    _ensure_tools_loaded()
    return {name for name, info in _tools.items() if info.interactive_only}


def get_tool(name: str) -> ToolInfo:
    """Get a registered tool by name."""
    _ensure_tools_loaded()
    if name not in _tools:
        # Provide helpful error message
        from ..shell_tool_config import get_custom_tools_config_path

        error_parts = ["not found"]

        # Check if it might be a custom tool
        config_path = get_custom_tools_config_path()
        if config_path.exists():
            error_parts.append(f"Check if '{name}' is defined in {config_path}")
        else:
            error_parts.append(f"Custom tools config not found at {config_path}")

        # Suggest similar tool names
        all_tools = list(_tools.keys())
        similar = [t for t in all_tools if name.lower() in t.lower() or t.lower() in name.lower()]
        if similar:
            error_parts.append(f"Did you mean: {', '.join(similar[:3])}?")

        error_parts.append("Run 'tsugite tools list' to see all available tools")

        raise ValueError(f"Invalid tool '{name}': {'. '.join(error_parts)}")
    return _tools[name]


def call_tool(tool_name: str, **kwargs) -> Any:
    """Call a tool with the given arguments."""
    tool_info = get_tool(tool_name)

    # Validate required parameters
    for param_name, param_info in tool_info.parameters.items():
        if param_info["required"] and param_name not in kwargs:
            raise ValueError(f"Invalid parameter '{param_name}': missing for tool '{tool_name}'")

    try:
        return tool_info.func(**kwargs)
    except Exception as e:
        raise RuntimeError(f"Tool '{tool_name}' failed to execute: {e}")


def list_tools() -> List[str]:
    """List all registered tool names."""
    _ensure_tools_loaded()
    return list(_tools.keys())


def get_tools_by_category(category: str) -> List[str]:
    """Get all tool names in a specific category.

    A tool's category is its explicit ToolInfo.category if set (via
    @tool(category=...)), otherwise the basename of its defining module.

    Args:
        category: Category name (e.g., 'fs', 'http', 'shell')

    Returns:
        List of tool names in the category
    """
    _ensure_tools_loaded()
    category_tools = []
    for tool_name, tool_info in _tools.items():
        effective = tool_info.category or tool_info.func.__module__.split(".")[-1]
        if effective == category:
            category_tools.append(tool_name)

    return sorted(category_tools)


_OPTIONAL_CATEGORIES = {"schedule", "notify", "scratchpad", "sessions", "secrets", "tmux"}


def _expand_single_spec(spec: str, strict: bool = True) -> List[str]:
    """Expand a single tool specification to tool names.

    Args:
        spec: Tool specification (name, @category, or glob pattern)
        strict: If True, raise error when spec matches nothing. If False, return empty list.

    Returns:
        List of matching tool names
    """
    import fnmatch

    if spec.startswith("@"):
        # Category reference: @fs, @http, etc.
        category = spec[1:]
        category_tools = get_tools_by_category(category)
        if not category_tools and strict and category not in _OPTIONAL_CATEGORIES:
            raise ValueError(f"Invalid tool category '{category}': not found or empty")
        return category_tools
    elif "*" in spec or "?" in spec or "[" in spec:
        # Glob pattern
        all_tool_names = list_tools()
        matches = fnmatch.filter(all_tool_names, spec)
        if not matches and strict:
            raise ValueError(f"Invalid tool pattern '{spec}': matched no tools")
        return matches
    else:
        # Regular tool name
        _ensure_tools_loaded()
        if spec not in _tools:
            if strict:
                available = ", ".join(list(_tools.keys())) if _tools else "none"
                raise ValueError(f"Invalid tool '{spec}': not found. Available: {available}")
            return []
        return [spec]


def expand_tool_specs(tool_specs: List[str]) -> List[str]:
    """Expand tool specifications to actual tool names.

    Supports:
    - Regular tool names: 'read_file' -> ['read_file']
    - Category references: '@fs' -> all tools in fs category
    - Glob patterns: '*_file' -> all tools matching pattern
    - Exclusions: '-tool_name', '-@category', '-pattern*' -> remove matching tools

    Args:
        tool_specs: List of tool specifications (names, @category, globs, or exclusions with -)

    Returns:
        Expanded list of unique tool names

    Examples:
        >>> expand_tool_specs(['read_file', 'write_file'])
        ['read_file', 'write_file']
        >>> expand_tool_specs(['@fs'])
        ['create_directory', 'file_exists', 'list_files', 'read_file', 'write_file']
        >>> expand_tool_specs(['*_file'])
        ['read_file', 'write_file']
        >>> expand_tool_specs(['@fs', '-*_directory'])
        ['file_exists', 'list_files', 'read_file', 'write_file']
        >>> expand_tool_specs(['@http', '-web_search'])
        ['check_url', 'download_file', 'fetch_json', 'fetch_text', 'http_request']
    """
    # Separate inclusions and exclusions
    inclusions = []
    exclusions = []

    for spec in tool_specs:
        if spec.startswith("-"):
            exclusions.append(spec[1:])  # Strip the - prefix
        else:
            inclusions.append(spec)

    # Expand inclusions (strict - must match something)
    expanded = []
    for spec in inclusions:
        expanded.extend(_expand_single_spec(spec, strict=True))

    # Expand exclusions (non-strict - silently ignore if nothing matches)
    excluded_tools = set()
    for spec in exclusions:
        excluded_tools.update(_expand_single_spec(spec, strict=False))

    # Apply exclusions
    result_with_exclusions = [tool for tool in expanded if tool not in excluded_tools]

    # Return unique tools while preserving order
    seen = set()
    result = []
    for tool in result_with_exclusions:
        if tool not in seen:
            seen.add(tool)
            result.append(tool)

    return result


def load_custom_shell_tools() -> None:
    """Load custom shell tools from config file.

    This is called automatically at module import time to register
    user-defined shell tools from custom_tools.yaml.
    """
    import os
    import sys

    try:
        from ..shell_tool_config import get_custom_tools_config_path, load_custom_tools_config
        from .shell_tools import register_shell_tools

        config_path = get_custom_tools_config_path()

        # Only try to load if config file exists
        if not config_path.exists():
            # Silently skip if no custom tools configured
            return

        definitions = load_custom_tools_config()
        if definitions:
            register_shell_tools(definitions)

            # Show helpful message if verbose mode enabled
            if os.environ.get("TSUGITE_VERBOSE") or os.environ.get("TSUGITE_DEBUG"):
                tool_names = [d.name for d in definitions]
                print(
                    f"✓ Loaded {len(definitions)} custom tool(s): {', '.join(tool_names)}",
                    file=sys.stderr,
                )
        else:
            # Config exists but no tools defined
            if os.environ.get("TSUGITE_VERBOSE") or os.environ.get("TSUGITE_DEBUG"):
                print(f"⚠ Custom tools config exists but no tools defined: {config_path}", file=sys.stderr)

    except Exception as e:
        # Don't fail startup if custom tools can't be loaded, but show clear error
        print(f"⚠ Failed to load custom tools: {e}", file=sys.stderr)
        print(f"  Config file: {get_custom_tools_config_path()}", file=sys.stderr)
        print("  Use 'tsugite tools validate' to check your config", file=sys.stderr)


# Lazy loading flag to defer tool module imports until first use
_tools_loaded = False


def _ensure_tools_loaded():
    """Lazy load tool modules on first use to speed up CLI startup."""
    global _tools_loaded
    if _tools_loaded:
        return

    # Import tool modules (they need to import 'tool' decorator from this module)
    from . import agents as agents  # noqa: E402, F401
    from . import fs as fs  # noqa: E402, F401
    from . import history as history  # noqa: E402, F401
    from . import http as http  # noqa: E402, F401
    from . import interactive as interactive  # noqa: E402, F401
    from . import notify as notify  # noqa: E402, F401
    from . import schedule as schedule  # noqa: E402, F401
    from . import scratchpad as scratchpad  # noqa: E402, F401
    from . import secrets as secrets  # noqa: E402, F401
    from . import sessions as sessions  # noqa: E402, F401
    from . import shell as shell  # noqa: E402, F401
    from . import skills as skills  # noqa: E402, F401
    from . import time as time  # noqa: E402, F401

    # Load custom shell tools after built-in tools
    load_custom_shell_tools()

    # Load plugin tools after custom shell tools
    from tsugite.plugins import (
        load_decorator_plugins,
        load_event_subscriber_plugins,
        load_hook_plugins,
        load_tool_plugins,
    )

    load_decorator_plugins()
    load_tool_plugins()
    load_hook_plugins()
    load_event_subscriber_plugins()

    _tools_loaded = True
