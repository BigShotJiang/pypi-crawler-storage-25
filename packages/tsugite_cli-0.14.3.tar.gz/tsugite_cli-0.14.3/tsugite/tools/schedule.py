"""Schedule tools for agents to manage daemon schedules directly.

Tools use @tool(require_daemon=True) so they only appear in daemon mode.
"""

import asyncio
from dataclasses import asdict
from typing import Optional
from uuid import uuid4

from . import tool

_scheduler = None
_loop = None
_channel_names: set[str] = set()
_agent_names: set[str] = set()


def set_scheduler(scheduler, loop=None, channel_names=None, agent_names=None):
    """Called by the daemon to set/clear the scheduler reference."""
    global _scheduler, _loop, _channel_names, _agent_names
    _scheduler = scheduler
    _loop = loop
    _channel_names = channel_names or set()
    _agent_names = agent_names or set()


def _call(fn, *args, **kwargs):
    """Call a scheduler method on the event loop thread (thread-safe)."""

    async def _wrapper():
        return fn(*args, **kwargs)

    future = asyncio.run_coroutine_threadsafe(_wrapper(), _loop)
    return future.result(timeout=10)


def _validate_notify(notify: Optional[list[str]], notify_tool: bool) -> None:
    """Validate notification channels and notify_tool requirement."""
    if notify_tool and not notify:
        raise ValueError("notify_tool=True requires a non-empty 'notify' list")
    if notify:
        unknown = set(notify) - _channel_names
        if unknown:
            raise ValueError(f"Unknown notification channel(s): {', '.join(sorted(unknown))}")


def _validate_agent(agent: str) -> None:
    """Validate agent name against registered daemon adapters."""
    if _agent_names and agent not in _agent_names:
        raise ValueError(f"Unknown agent '{agent}'. Available: {', '.join(sorted(_agent_names))}")


def _resolve_agent(agent: Optional[str]) -> str:
    """Resolve agent name, falling back to the current agent or 'default'."""
    from tsugite.agent_runner.helpers import resolve_current_agent

    return resolve_current_agent(agent)


@tool(require_daemon=True)
def schedule_create(
    id: str,
    prompt: str = "",
    agent: Optional[str] = None,
    cron: Optional[str] = None,
    run_at: Optional[str] = None,
    timezone: str = "UTC",
    notify: Optional[list[str]] = None,
    notify_tool: bool = False,
    inject_history: bool = True,
    model: Optional[str] = None,
    agent_file: Optional[str] = None,
    execution_type: str = "agent",
    command: Optional[str] = None,
    script_timeout: int = 60,
    expires_at: Optional[str] = None,
    max_runs: Optional[int] = None,
    session_id: Optional[str] = None,
    target_session: Optional[str] = None,
) -> dict:
    """Create a recurring (cron) or one-off schedule to run an agent or script.

    IMPORTANT: Always confirm with the user before calling this tool. Show them the exact
    prompt, schedule, and timezone you plan to use and wait for approval. Never schedule
    destructive or dangerous actions (file deletion, force-push, infrastructure changes, etc.).

    Args:
        id: Unique schedule name (e.g., "daily-backup")
        prompt: Clear, direct instruction for the agent. Do NOT copy the user's words verbatim — interpret their intent and write a self-contained instruction the agent can execute autonomously. Can be empty when agent_file is set or execution_type is "script".
        agent: Agent name configured in daemon. Defaults to the current agent if omitted.
        cron: Cron expression for recurring (e.g., "0 9 * * *" = daily at 9am). Mutually exclusive with run_at.
        run_at: ISO datetime for one-off execution (e.g., "2026-02-13T14:00:00-06:00"). Mutually exclusive with cron.
        timezone: IANA timezone (default: UTC)
        notify: List of notification channel names to deliver results to on completion.
        notify_tool: If true, gives the agent the notify_user tool so it can send messages during execution. Requires notify to be set.
        inject_history: If true (default), injects the task result into notified users' chat sessions so the agent has context when they reply.
        model: Optional model override (e.g., "openai:gpt-4o-mini"). When set, this schedule uses this model instead of the agent's default.
        agent_file: Agent name (e.g., "+reporter") or path to a tsugite agent .md file. Hot-loaded on each run — edit the file and the next execution picks up changes.
        execution_type: "agent" (default) runs an LLM agent, "script" runs a shell command directly without LLM.
        command: Shell command to execute when execution_type is "script". Required for script type.
        script_timeout: Max seconds for script execution (default: 60). Only used when execution_type is "script".
        expires_at: ISO datetime after which the schedule auto-disables (e.g., "2026-04-01T00:00:00Z").
        max_runs: Auto-disable after this many successful executions.
        session_id: If set, all runs of this schedule share the same session (persistent LLM context across runs). If omitted, each run gets its own isolated session.
        target_session: Where the inject_history synthetic turn lands. Distinct from session_id (which controls the agent's run session). Legal forms:
            None (default) - fallback chain: primary -> originating -> none
            "primary" - primary lookup only (no fallback)
            "originating" - originating_session_id only
            "none" - skip injection
            "name:<n>" - lookup by metadata.session_name
            "<sid>" - bare session id

    Returns:
        Created schedule details including computed next_run
    """
    if not cron and not run_at:
        raise ValueError("Provide either 'cron' or 'run_at'")
    if cron and run_at:
        raise ValueError("Provide 'cron' or 'run_at', not both")

    if execution_type == "script":
        if not command:
            raise ValueError("'command' is required when execution_type is 'script'")
    else:
        if not prompt and not agent_file:
            raise ValueError("Provide at least one of 'prompt' or 'agent_file'")

    _validate_notify(notify, notify_tool)
    agent = _resolve_agent(agent)
    _validate_agent(agent)

    from tsugite.daemon.scheduler import ScheduleEntry

    entry = ScheduleEntry(
        id=id,
        agent=agent,
        prompt=prompt,
        schedule_type="once" if run_at else "cron",
        cron_expr=cron,
        run_at=run_at,
        notify=notify or [],
        notify_tool=notify_tool,
        inject_history=inject_history,
        model=model,
        timezone=timezone,
        agent_file=agent_file,
        execution_type=execution_type,
        command=command,
        script_timeout=script_timeout,
        expires_at=expires_at,
        max_runs=max_runs,
        session_id=session_id,
        target_session=target_session,
    )
    result = _call(_scheduler.add, entry)
    return asdict(result)


@tool(require_daemon=True)
def schedule_list() -> list:
    """List all configured schedules with their status.

    Returns:
        List of schedules with id, agent, type, enabled, next_run, last_status
    """
    entries = _call(_scheduler.list)
    return [asdict(e) for e in entries]


@tool(require_daemon=True)
def schedule_remove(id: str) -> dict:
    """Remove a schedule.

    Args:
        id: Schedule ID to remove

    Returns:
        Confirmation of removal
    """
    _call(_scheduler.remove, id)
    return {"status": "removed", "id": id}


@tool(require_daemon=True)
def schedule_enable(id: str) -> dict:
    """Enable a disabled schedule.

    Args:
        id: Schedule ID to enable

    Returns:
        Confirmation with updated schedule details
    """
    _call(_scheduler.enable, id)
    return asdict(_call(_scheduler.get, id))


@tool(require_daemon=True)
def schedule_disable(id: str) -> dict:
    """Disable a schedule without removing it.

    Args:
        id: Schedule ID to disable

    Returns:
        Confirmation with updated schedule details
    """
    _call(_scheduler.disable, id)
    return asdict(_call(_scheduler.get, id))


@tool(require_daemon=True)
def schedule_update(
    id: str,
    prompt: Optional[str] = None,
    cron: Optional[str] = None,
    run_at: Optional[str] = None,
    timezone: Optional[str] = None,
    notify: Optional[list[str]] = None,
    notify_tool: Optional[bool] = None,
    inject_history: Optional[bool] = None,
    model: Optional[str] = None,
    agent_file: Optional[str] = None,
    execution_type: Optional[str] = None,
    command: Optional[str] = None,
    script_timeout: Optional[int] = None,
    expires_at: Optional[str] = None,
    max_runs: Optional[int] = None,
    session_id: Optional[str] = None,
    target_session: Optional[str] = None,
) -> dict:
    """Update fields on an existing schedule.

    Args:
        id: Schedule ID to update
        prompt: New prompt text (optional)
        cron: New cron expression (optional)
        run_at: New run_at ISO datetime (optional)
        timezone: New IANA timezone (optional)
        notify: New notification channel list (optional)
        notify_tool: Enable/disable notify_user tool (optional)
        inject_history: Enable/disable result injection into user chat sessions (optional)
        model: Model override for this schedule (optional). Set to empty string to clear.
        agent_file: Agent name (e.g., "+reporter") or path to agent .md file (optional). Set to empty string to clear.
        execution_type: Change to "agent" or "script" (optional).
        command: Shell command for script execution (optional). Set to empty string to clear.
        script_timeout: Max seconds for script execution (optional).
        expires_at: ISO datetime for auto-disable (optional). Set to empty string to clear.
        max_runs: Auto-disable after N successful runs (optional).
        session_id: Persistent session ID for this schedule (optional). Set to empty string to clear (reverts to per-run sessions).
        target_session: Routing target for inject_history synthetic turn (optional). See schedule_create for legal forms. Set to empty string to clear (reverts to fallback chain).

    Returns:
        Updated schedule details
    """
    # Build fields dict from provided params (rename cron → cron_expr)
    simple = {
        "prompt": prompt,
        "cron_expr": cron,
        "run_at": run_at,
        "timezone": timezone,
        "inject_history": inject_history,
        "execution_type": execution_type,
        "script_timeout": script_timeout,
        "max_runs": max_runs,
    }
    fields = {k: v for k, v in simple.items() if v is not None}

    if notify is not None:
        _validate_notify(notify, False)
        fields["notify"] = notify
    if notify_tool is not None:
        if notify_tool:
            effective_notify = notify if notify is not None else _call(_scheduler.get, id).notify
            if not effective_notify:
                raise ValueError("notify_tool=True requires a non-empty 'notify' list")
        fields["notify_tool"] = notify_tool

    # Clearable fields: empty/falsy value → None (clears the field)
    for param_name, value in [
        ("model", model),
        ("agent_file", agent_file),
        ("command", command),
        ("expires_at", expires_at),
        ("session_id", session_id),
        ("target_session", target_session),
    ]:
        if value is not None:
            fields[param_name] = value or None

    if not fields:
        raise ValueError("No fields to update")

    result = _call(_scheduler.update, id, **fields)
    return asdict(result)


@tool(require_daemon=True)
def schedule_cleanup() -> dict:
    """Remove all orphaned one-off schedules (disabled, already fired).

    Returns:
        Dict with removed schedule IDs and count
    """
    removed = _call(_scheduler.cleanup)
    return {"removed": removed, "count": len(removed)}


@tool(require_daemon=True)
def schedule_run(id: str) -> dict:
    """Fire an existing schedule immediately in the background.

    The schedule runs asynchronously — this tool returns immediately.
    Results are delivered via the schedule's configured notification channels.

    Args:
        id: Schedule ID to fire

    Returns:
        Confirmation that the schedule was triggered
    """
    _call(_scheduler.fire_now, id)
    return {"status": "triggered", "id": id}


@tool(require_daemon=True)
def schedule_status(id: str, history_limit: int = 10) -> dict:
    """Get the current status of a schedule, including whether it's running and recent run history.

    Args:
        id: Schedule ID to check
        history_limit: Max number of recent runs to return (default: 10)

    Returns:
        Dict with schedule state including is_running flag and run_history
    """
    entry = _call(_scheduler.get, id)
    running_ids = _call(_scheduler.get_running_ids)
    return {
        "id": entry.id,
        "agent": entry.agent,
        "is_running": entry.id in running_ids,
        "last_status": entry.last_status,
        "last_run": entry.last_run,
        "last_error": entry.last_error,
        "next_run": entry.next_run,
        "enabled": entry.enabled,
        "run_count": entry.run_count,
        "session_id": entry.session_id,
        "run_history": entry.run_history[-history_limit:],
    }


def _get_running_tasks_snapshot():
    """Collect running task details in a single scheduler-thread call."""
    running_ids = _scheduler.get_running_ids()
    return [
        {"id": e.id, "agent": e.agent, "prompt": e.prompt[:200]} for rid in running_ids if (e := _scheduler.get(rid))
    ]


@tool(require_daemon=True)
def list_running_tasks() -> list:
    """List all currently running schedule tasks.

    Returns:
        List of dicts with id, agent, and prompt (truncated) for each running task
    """
    return _call(_get_running_tasks_snapshot)


@tool(require_daemon=True)
def background_task(
    prompt: str = "",
    agent: Optional[str] = None,
    notify: Optional[list[str]] = None,
    notify_tool: bool = False,
    inject_history: bool = False,
    model: Optional[str] = None,
    max_turns: Optional[int] = None,
    execution_type: str = "agent",
    command: Optional[str] = None,
    script_timeout: int = 60,
    on_complete: Optional[dict] = None,
    target_session: Optional[str] = None,
) -> dict:
    """Launch a background task that auto-replies with results when complete.

    Creates a one-off schedule and fires it immediately. When the task finishes,
    results are automatically processed on the user's conversation session and
    delivered as a human-friendly response via notification channels.

    Use this for tasks that may take a while (research, long-running commands, etc.)
    so the user doesn't have to wait. For deterministic commands (curl, ping, df, etc.),
    use execution_type="script" to skip the LLM entirely.

    IMPORTANT: Always confirm with the user before launching background tasks.

    Args:
        prompt: Clear, self-contained instruction for the background agent. Optional when execution_type is "script".
        agent: Agent name to run. Defaults to the current agent.
        notify: Notification channels for result delivery. Required for auto-reply.
        notify_tool: If true, gives the background agent the notify_user tool.
        inject_history: If true, inject raw result into user session (in addition to auto-reply).
        model: Optional model override (e.g., "openai:gpt-4o-mini").
        max_turns: Optional max reasoning turns for the agent. Limits how many LLM iterations the task can use.
        execution_type: "agent" (default) runs an LLM agent, "script" runs a shell command directly.
        command: Shell command to execute when execution_type is "script".
        script_timeout: Max seconds for script execution (default: 60).
        on_complete: Completion callback. Currently supports {"action": "reply"} to auto-reply
            to the originating session when the task finishes, allowing the agent to chain work.
        target_session: Routing target for the inject_history synthetic turn. See schedule_create for
            legal forms. Defaults to "originating" when on_complete is set so completion replies still
            land in the spawning session; otherwise defaults to None (fallback chain).

    Returns:
        Dict with status and generated task ID
    """
    if execution_type == "script":
        if not command:
            raise ValueError("'command' is required when execution_type is 'script'")
    else:
        if not prompt:
            raise ValueError("'prompt' is required when execution_type is 'agent'")

    if on_complete and (not isinstance(on_complete, dict) or on_complete.get("action") != "reply"):
        raise ValueError("on_complete must be {'action': 'reply'}")

    _validate_notify(notify, notify_tool)
    agent = _resolve_agent(agent)
    _validate_agent(agent)

    from tsugite.daemon.scheduler import ScheduleEntry
    from tsugite.daemon.session_runner import get_current_chain_depth, get_current_session_id

    originating_session_id = get_current_session_id() if on_complete else None
    if on_complete and not originating_session_id:
        raise ValueError("on_complete requires a session context (daemon mode)")
    chain_depth = get_current_chain_depth() if on_complete else 0

    if target_session is None and on_complete:
        from tsugite.daemon.scheduler import TARGET_SESSION_ORIGINATING

        target_session = TARGET_SESSION_ORIGINATING

    task_id = f"bg-{uuid4().hex[:8]}"
    # run_at in the past so it's immediately eligible
    run_at = "2000-01-01T00:00:00Z"

    entry = ScheduleEntry(
        id=task_id,
        agent=agent,
        prompt=prompt,
        schedule_type="once",
        run_at=run_at,
        notify=notify or [],
        notify_tool=notify_tool,
        inject_history=inject_history,
        auto_reply=bool(notify),
        model=model,
        max_turns=max_turns,
        execution_type=execution_type,
        command=command,
        script_timeout=script_timeout,
        originating_session_id=originating_session_id,
        on_complete=on_complete,
        chain_depth=chain_depth,
        target_session=target_session,
    )
    _call(_scheduler.add, entry)
    _call(_scheduler.fire_now, task_id)
    return {"status": "started", "id": task_id}
