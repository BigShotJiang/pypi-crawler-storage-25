"""Agent markdown parser and template renderer."""

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Union

logger = logging.getLogger(__name__)

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator  # noqa: E402

from .utils import has_glob_chars, parse_yaml_frontmatter  # noqa: E402


def _parse_directive_attribute(
    args: str,
    attr_name: str,
    value_pattern: str = r"([^\"']+)",
    converter: Optional[Callable[[str], Any]] = None,
    default: Any = None,
) -> Any:
    """Parse an attribute from directive arguments using regex.

    The leading `\\b` prevents attr names from matching as suffixes of longer ones
    (e.g. `assign=` would otherwise match inside `stdout_assign=`).
    """
    pattern = rf'\b{attr_name}=(["\']?)({value_pattern})\1'
    match = re.search(pattern, args)
    if not match:
        return default

    value = match.group(2)
    if converter:
        return converter(value)
    return value


class AttachmentSpec(BaseModel):
    """Dict-form attachment specification.

    Used in agent frontmatter as an alternative to plain string paths. Supports
    binding attachment content to a Jinja variable (`assign:`) and rendering as
    an on-demand index instead of full content (`mode: index`).
    """

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    path: str
    mode: Literal["full", "index"] = "full"
    name: Optional[str] = None
    assign: Optional[str] = None
    attach: bool = True
    index_format: Literal["path_only", "first_line", "first_heading", "frontmatter"] = "first_heading"
    max_entries: int = 50

    @field_validator("assign", mode="after")
    @classmethod
    def _valid_identifier(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and not v.isidentifier():
            raise ValueError(f"assign must be a valid Python identifier, got: {v!r}")
        return v

    @field_validator("path", mode="after")
    @classmethod
    def _no_leading_dash(cls, v: str) -> str:
        if v.startswith("-"):
            raise ValueError("AttachmentSpec.path cannot start with '-' (use string form for removals)")
        return v

    @model_validator(mode="after")
    def _attach_or_assign(self) -> "AttachmentSpec":
        if not self.attach and not self.assign:
            raise ValueError("attach: false requires assign: to be useful")
        return self


class AgentConfig(BaseModel):
    """Agent configuration from YAML frontmatter."""

    model_config = ConfigDict(
        extra="forbid",  # Reject unknown fields to catch typos in YAML
        str_strip_whitespace=True,  # Auto-strip whitespace from strings
    )

    name: str
    description: str = ""
    model: Optional[str] = None
    max_turns: int = 5
    tools: List[str] = Field(default_factory=list)
    prefetch: List[Dict[str, Any]] = Field(default_factory=list)
    attachments: List[Union[str, AttachmentSpec]] = Field(default_factory=list)
    auto_load_skills: List[str] = Field(default_factory=list)
    auto_load_agent_list: bool = False
    auto_load_agents: List[str] = Field(default_factory=list)
    skill_paths: List[str] = Field(default_factory=list)
    instructions: str = ""
    extends: Optional[str] = None
    reasoning_effort: Optional[str] = None  # For reasoning models (low, medium, high)
    custom_tools: List[Dict[str, Any]] = Field(default_factory=list)  # Per-agent shell tools
    disable_history: bool = False  # Disable conversation history persistence for this agent
    auto_context: Optional[bool] = None  # Auto-load context files (None = use config default)
    visibility: str = "public"  # Agent visibility: public, private, internal
    spawnable: bool = True  # Whether this agent can be spawned by other agents
    network: Optional[Dict[str, Any]] = None  # Network hints for sandbox proxy allowlist
    allowed_secrets: List[str] = Field(default_factory=list)  # Per-agent secret allowlist (empty = all allowed)
    run_if: Optional[str] = Field(
        default=None,
        description="Jinja expression guard evaluated after prefetch. Agent is skipped if the expression evaluates to a falsy value. Has access to prefetch variables and built-in helpers (file_exists, read_text, env, now, etc.).",
        json_schema_extra={
            "examples": [
                "inbox_count | int > 0",
                "file_exists('/tmp/trigger.flag')",
                "env.get('ENABLE_AGENT') == 'true'",
            ]
        },
    )

    @field_validator("visibility", mode="after")
    @classmethod
    def validate_visibility(cls, v: str) -> str:
        """Validate visibility is one of the allowed values."""
        allowed = ["public", "private", "internal"]
        if v not in allowed:
            raise ValueError(f"visibility must be one of {allowed}, got: {v}")
        return v

    @field_validator("attachments", mode="after")
    @classmethod
    def _no_duplicate_assigns(cls, v: List[Union[str, "AttachmentSpec"]]) -> List[Union[str, "AttachmentSpec"]]:
        seen: set[str] = set()
        for item in v:
            if isinstance(item, AttachmentSpec) and item.assign:
                if item.assign in seen:
                    raise ValueError(f"duplicate attachment assign: {item.assign!r}")
                seen.add(item.assign)
        return v


@dataclass
class Agent:
    """Parsed agent with config and content."""

    config: AgentConfig
    content: str
    file_path: Path

    @property
    def name(self) -> str:
        return self.config.name


def parse_agent(text: str, file_path: Optional[Path] = None) -> Agent:
    """Parse agent markdown text with YAML frontmatter."""
    # Parse YAML frontmatter
    frontmatter, markdown_content = parse_yaml_frontmatter(text, "Agent text")

    # Create config
    config = AgentConfig(**frontmatter)

    return Agent(config=config, content=markdown_content, file_path=file_path or Path(""))


def parse_agent_file(file_path: Path) -> Agent:
    """Parse an agent markdown file with YAML frontmatter.

    This function also resolves agent inheritance if configured.

    Args:
        file_path: Path to agent markdown file

    Returns:
        Parsed Agent with resolved inheritance

    Raises:
        FileNotFoundError: If agent file doesn't exist
        ValueError: If circular inheritance or missing parent agent
    """
    if not file_path.exists():
        raise FileNotFoundError(f"Agent file not found: {file_path}")

    content = file_path.read_text(encoding="utf-8")
    agent = parse_agent(content, file_path)

    # Resolve inheritance if needed
    if agent.config.extends != "none":
        from .agent_inheritance import resolve_agent_inheritance

        agent = resolve_agent_inheritance(agent, file_path)

    return agent


def extract_directives(content: str) -> List[Dict[str, Any]]:
    """Extract tsugite directives from markdown content."""
    directives = []

    # Pattern to match <!-- tsu:directive ... -->
    pattern = r"<!--\s*tsu:(\w+)\s+([^>]+)\s*-->"

    for match in re.finditer(pattern, content):
        directive_type = match.group(1)
        directive_args = match.group(2).strip()

        # Parse directive arguments (simplified for now)
        directive = {
            "type": directive_type,
            "raw_args": directive_args,
            "position": match.span(),
        }

        # Basic parsing for common patterns
        if "name=" in directive_args and "args=" in directive_args:
            # Extract tool name and args
            name_match = re.search(r'name=(["\']?)(\w+)\1', directive_args)
            if name_match:
                directive["name"] = name_match.group(2)

            # Extract assign parameter
            assign_match = re.search(r'assign=(["\']?)(\w+)\1', directive_args)
            if assign_match:
                directive["assign"] = assign_match.group(2)

        directives.append(directive)

    return directives


@dataclass
class ToolDirective:
    """Represents a tool directive in agent content."""

    name: str
    args: Dict[str, Any]
    assign_var: str
    start_pos: int
    end_pos: int
    raw_match: str


def extract_tool_directives(content: str) -> List[ToolDirective]:
    """Extract <!-- tsu:tool --> directives from content.

    Args:
        content: Raw markdown content

    Returns:
        List of ToolDirective objects with parsed name, args, and assignment

    Example:
        >>> content = '''
        ... <!-- tsu:tool name="fetch_json" args={"url": "http://example.com"} assign="data" -->
        ... '''
        >>> directives = extract_tool_directives(content)
        >>> directives[0].name
        'fetch_json'
        >>> directives[0].args
        {'url': 'http://example.com'}
    """
    directives = []
    pattern = r"<!--\s*tsu:tool\s+([^>]+?)\s*-->"

    for match in re.finditer(pattern, content):
        raw_args = match.group(1).strip()
        start_pos = match.start()
        end_pos = match.end()
        raw_match = match.group(0)

        # Extract name (required)
        name_match = re.search(r'name=(["\']?)(\w+)\1', raw_args)
        if not name_match:
            raise ValueError(f"Tool directive missing required 'name' attribute: {raw_args}")
        tool_name = name_match.group(2)

        # Extract and parse JSON args (required)
        args_dict = extract_and_parse_json_args(raw_args, tool_name)

        # Extract assign (required)
        assign_match = re.search(r'assign=(["\']?)(\w+)\1', raw_args)
        if not assign_match:
            raise ValueError(f"Tool directive missing required 'assign' attribute: {raw_args}")
        assign_var = assign_match.group(2)

        directives.append(
            ToolDirective(
                name=tool_name,
                args=args_dict,
                assign_var=assign_var,
                start_pos=start_pos,
                end_pos=end_pos,
                raw_match=raw_match,
            )
        )

    return directives


@dataclass
class ExecDirective:
    """Represents a `<!-- tsu:exec -->` directive in agent content.

    Attributes:
        name: Label for logs/errors (required).
        code: Python source code in the block body.
        assign_var: Optional Jinja var to receive return_value / last-expr value.
        stdout_assign: Optional Jinja var to receive captured stdout.
        timeout: Wall-clock timeout in seconds (default 30).
        continue_on_error: If true, exceptions become None instead of aborting.
        start_pos / end_pos: Source byte offsets of the full open-to-close span.
        raw_match: The exact substring matched (for content replacement).
    """

    name: str
    code: str
    assign_var: Optional[str] = None
    stdout_assign: Optional[str] = None
    timeout: int = 30
    continue_on_error: bool = False
    start_pos: int = 0
    end_pos: int = 0
    raw_match: str = ""


_EXEC_OPEN_RE = re.compile(r"<!--\s*tsu:exec\s+([^>]+?)\s*-->", re.DOTALL)
_EXEC_PAIR_RE = re.compile(
    r"<!--\s*tsu:exec\s+([^>]+?)\s*-->(.*?)<!--\s*/tsu:exec\s*-->",
    re.DOTALL,
)


def extract_exec_directives(content: str) -> List[ExecDirective]:
    """Extract `<!-- tsu:exec ... -->...<!-- /tsu:exec -->` directives.

    Open/close pair grammar mirrors `tsu:ignore` (renderer.py).
    Body is opaque (not Jinja-rendered) and surfaces verbatim as the directive's `code`.
    The non-greedy match means a literal `<!-- /tsu:exec -->` inside a Python string
    will truncate the block at that point - documented limitation.
    """
    directives: List[ExecDirective] = []
    pair_matches = list(_EXEC_PAIR_RE.finditer(content))

    paired_starts = {m.start() for m in pair_matches}
    for open_match in _EXEC_OPEN_RE.finditer(content):
        if open_match.start() not in paired_starts:
            args_preview = open_match.group(1).strip().split()[0] if open_match.group(1).strip() else "?"
            raise ValueError(
                f"tsu:exec directive has unmatched open tag (no <!-- /tsu:exec --> follows): {args_preview}"
            )

    for match in pair_matches:
        args = match.group(1).strip()
        body = match.group(2)

        name = _parse_directive_attribute(args, "name", r"\w+")
        if not name:
            raise ValueError(f"tsu:exec directive missing required 'name' attribute: {args}")

        assign_var = _parse_directive_attribute(args, "assign", r"\w+")
        stdout_assign = _parse_directive_attribute(args, "stdout_assign", r"\w+")
        timeout = _parse_directive_attribute(args, "timeout", r"[0-9]+", int, default=30)
        continue_on_error_str = _parse_directive_attribute(args, "continue_on_error", r"true|false", default="false")
        continue_on_error = continue_on_error_str.lower() == "true"

        directives.append(
            ExecDirective(
                name=name,
                code=body.strip("\r\n"),
                assign_var=assign_var,
                stdout_assign=stdout_assign,
                timeout=timeout,
                continue_on_error=continue_on_error,
                start_pos=match.start(),
                end_pos=match.end(),
                raw_match=match.group(0),
            )
        )

    return directives


@dataclass
class StepDirective:
    """Represents a step in multi-step agent execution."""

    name: str
    content: str
    assign_var: Optional[str] = None
    model_kwargs: Dict[str, Any] = field(default_factory=dict)
    max_retries: int = 0
    retry_delay: float = 0.0
    continue_on_error: bool = False
    timeout: Optional[int] = None  # Timeout in seconds, None = no timeout
    start_pos: int = 0
    end_pos: int = 0

    # Loop control
    repeat_while: Optional[str] = None  # Jinja2 expression or helper name to continue repeating
    repeat_until: Optional[str] = None  # Jinja2 expression or helper name to stop repeating
    max_iterations: int = 10  # Maximum loop iterations (safety valve)

    # If set, run via spawn_agent (isolated context); rendered step content is the prompt.
    spawn_agent_path: Optional[str] = None


def extract_step_directives(content: str, include_preamble: bool = True) -> tuple[str, List[StepDirective]]:
    """Extract step directives and preamble from markdown content.

    Steps are marked with <!-- tsu:step name="..." assign="..." --> comments.
    Each step's content runs from the directive to the next step (or EOF).
    Content before the first step is the preamble and can be prepended to all steps.

    Args:
        content: Raw markdown content
        include_preamble: If True, prepend preamble to each step's content

    Returns:
        Tuple of (preamble, list of StepDirective objects with parsed attributes and content)

    Example:
        >>> content = '''
        ... Header content
        ... <!-- tsu:step name="research" assign="data" -->
        ... Do research here
        ... <!-- tsu:step name="write" -->
        ... Write content
        ... '''
        >>> preamble, steps = extract_step_directives(content)
        >>> len(steps)
        2
        >>> 'Header content' in preamble
        True
    """
    steps = []
    pattern = r"<!--\s*tsu:step\s+([^>]+?)\s*-->"
    matches = list(re.finditer(pattern, content))

    # Extract preamble (content before first step)
    preamble = ""
    if matches:
        preamble = content[: matches[0].start()].strip()

    for i, match in enumerate(matches):
        args = match.group(1).strip()
        start_pos = match.end()

        # Determine end position (next step or EOF)
        end_pos = matches[i + 1].start() if i + 1 < len(matches) else len(content)

        # Extract step content
        step_content = content[start_pos:end_pos].strip()

        # Prepend preamble if requested
        if include_preamble and preamble:
            step_content = f"{preamble}\n\n{step_content}"

        # Parse name attribute (required)
        name_match = re.search(r'name=(["\']?)(\w+)\1', args)
        if not name_match:
            raise ValueError(f"Step directive missing required 'name' attribute: {args}")
        step_name = name_match.group(2)

        # Parse optional attributes
        assign_var = _parse_directive_attribute(args, "assign", r"\w+")
        timeout = _parse_directive_attribute(args, "timeout", r"[0-9]+", int)
        spawn_agent_path = _parse_directive_attribute(args, "agent", r"[^\"'\s]+")

        # Use helpers for complex parsing
        model_kwargs = parse_model_kwargs_from_args(args, step_name)
        max_retries, retry_delay, continue_on_error = parse_retry_params_from_args(args)
        repeat_while, repeat_until, max_iterations = parse_loop_params_from_args(args, step_name)

        steps.append(
            StepDirective(
                name=step_name,
                content=step_content,
                assign_var=assign_var,
                model_kwargs=model_kwargs,
                max_retries=max_retries,
                retry_delay=retry_delay,
                continue_on_error=continue_on_error,
                timeout=timeout,
                repeat_while=repeat_while,
                repeat_until=repeat_until,
                max_iterations=max_iterations,
                start_pos=start_pos,
                end_pos=end_pos,
                spawn_agent_path=spawn_agent_path,
            )
        )

    return preamble, steps


def has_step_directives(content: str) -> bool:
    """Check if markdown content contains step directives."""
    pattern = r"<!--\s*tsu:step\s+"
    return bool(re.search(pattern, content))


def validate_agent(agent: Agent) -> List[str]:
    """Validate agent configuration and content."""
    errors = []

    # Validate required fields
    if not agent.config.name:
        errors.append("Agent name is required")

    # Model is now optional - it will be loaded from config if not specified

    # Validate model format if specified
    if agent.config.model and not _is_valid_model_format(agent.config.model):
        errors.append(f"Invalid model format: {agent.config.model}")

    # Validate tools exist
    for tool in agent.config.tools:
        if not isinstance(tool, str):
            errors.append(f"Tool name must be string: {tool}")

    # Validate max_turns is positive
    if agent.config.max_turns <= 0:
        errors.append("max_turns must be positive")

    # Validate directives in content
    directives = extract_directives(agent.content)
    for directive in directives:
        if directive["type"] == "tool" and "name" not in directive:
            errors.append(f"Tool directive missing name: {directive['raw_args']}")

    return errors


def _is_valid_model_format(model: str) -> bool:
    """Check if model string follows expected format."""
    if ":" not in model:
        return False

    provider, model_name = model.split(":", 1)
    return bool(provider.strip() and model_name.strip())


def validate_agent_execution(agent: Agent | Path) -> tuple[bool, str]:
    """Validate that an agent can be executed.

    Args:
        agent: Parsed agent or path to agent file

    Returns:
        Tuple of (is_valid, error_message)
    """
    # Handle both Path objects and Agent objects
    if isinstance(agent, Path):
        try:
            agent_text = agent.read_text()
            agent = parse_agent(agent_text, agent)
        except Exception as e:
            return False, f"Failed to parse agent file: {e}"

    # Basic validation
    errors = validate_agent(agent)
    if errors:
        return False, "; ".join(errors)

    # Validate model if specified
    if agent.config.model:
        is_valid, error = validate_model_string(agent.config.model)
        if not is_valid:
            return False, error

    # Validate tool syntax
    if agent.config.tools:
        is_valid, error = validate_tool_specs(agent.config.tools)
        if not is_valid:
            return False, error

    # Check template rendering with minimal context
    from .renderer import AgentRenderer

    renderer = AgentRenderer()
    try:
        test_context = build_validation_test_context(agent)
        add_mock_step_variables(test_context, agent.content)
        add_mock_tool_variables(test_context, agent.content)
        renderer.render(agent.content, test_context)
    except Exception as e:
        return False, f"Template validation failed: {e}"

    return True, "Agent is valid"


def parse_model_kwargs_from_args(args: str, step_name: str) -> dict[str, Any]:
    """Parse model kwargs from step directive arguments.

    Extracts temperature, max_tokens, top_p, penalties, response_format,
    and reasoning_effort from directive args.

    Args:
        args: Raw directive arguments string
        step_name: Name of step (for error messages)

    Returns:
        Dict of model kwargs to pass to LLM

    Raises:
        ValueError: If JSON parsing fails for response_format
    """
    import json

    model_kwargs = {}

    # Check for json shorthand
    json_match = re.search(r'json=(["\']?)(true|false)\1', args)
    if json_match and json_match.group(2) == "true":
        model_kwargs["response_format"] = {"type": "json_object"}

    # Check for response_format (overrides json shorthand)
    rf_match = re.search(r'response_format=(["\'])(.+?)\1', args)
    if rf_match:
        try:
            rf_value = rf_match.group(2)
            model_kwargs["response_format"] = json.loads(rf_value)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in response_format for step '{step_name}': {e}") from e

    # Parse numeric parameters
    temperature = _parse_directive_attribute(args, "temperature", r"[0-9.]+", float)
    if temperature is not None:
        model_kwargs["temperature"] = temperature

    max_tokens = _parse_directive_attribute(args, "max_tokens", r"[0-9]+", int)
    if max_tokens is not None:
        model_kwargs["max_tokens"] = max_tokens

    top_p = _parse_directive_attribute(args, "top_p", r"[0-9.]+", float)
    if top_p is not None:
        model_kwargs["top_p"] = top_p

    freq_penalty = _parse_directive_attribute(args, "frequency_penalty", r"[0-9.]+", float)
    if freq_penalty is not None:
        model_kwargs["frequency_penalty"] = freq_penalty

    pres_penalty = _parse_directive_attribute(args, "presence_penalty", r"[0-9.]+", float)
    if pres_penalty is not None:
        model_kwargs["presence_penalty"] = pres_penalty

    # Parse reasoning_effort. Values validated at runtime against the resolved
    # model's supported_effort_levels (see tsugite.models.resolve_reasoning_effort).
    reasoning_effort = _parse_directive_attribute(args, "reasoning_effort", r"[a-z]+")
    if reasoning_effort:
        model_kwargs["reasoning_effort"] = reasoning_effort

    return model_kwargs


def parse_retry_params_from_args(args: str) -> tuple[int, float, bool]:
    """Parse retry parameters from step directive arguments.

    Args:
        args: Raw directive arguments string

    Returns:
        Tuple of (max_retries, retry_delay, continue_on_error)
    """
    max_retries = _parse_directive_attribute(args, "max_retries", r"[0-9]+", int, default=0)
    retry_delay = _parse_directive_attribute(args, "retry_delay", r"[0-9.]+", float, default=0.0)
    continue_str = _parse_directive_attribute(args, "continue_on_error", r"true|false", default="false")
    continue_on_error = continue_str.lower() == "true"

    return max_retries, retry_delay, continue_on_error


def parse_loop_params_from_args(args: str, step_name: str) -> tuple[Optional[str], Optional[str], int]:
    """Parse loop control parameters from step directive arguments.

    Args:
        args: Raw directive arguments string
        step_name: Name of step (for error messages)

    Returns:
        Tuple of (repeat_while, repeat_until, max_iterations)

    Raises:
        ValueError: If both repeat_while and repeat_until are specified
    """
    repeat_while = _parse_directive_attribute(args, "repeat_while", r".+?")
    repeat_until = _parse_directive_attribute(args, "repeat_until", r".+?")
    max_iterations = _parse_directive_attribute(args, "max_iterations", r"[0-9]+", int, default=10)

    # Validate: cannot specify both
    if repeat_while and repeat_until:
        raise ValueError(f"Step '{step_name}' cannot specify both repeat_while and repeat_until. Use one or the other.")

    return repeat_while, repeat_until, max_iterations


_JSON_DECODER = json.JSONDecoder()


def find_json_object_in_string(text: str, start_keyword: str) -> tuple[int, int]:
    """Find a JSON object in a string starting after a keyword.

    Uses the stdlib JSON decoder so braces inside string values (e.g.
    `{"tmpl": "{{ name }}"}`) are handled correctly.

    Raises:
        ValueError: if the keyword is missing, no opening brace follows it, or
        the JSON is malformed.
    """
    keyword_pos = text.find(start_keyword)
    if keyword_pos == -1:
        raise ValueError(f"Keyword '{start_keyword}' not found in text")

    json_start = text.find("{", keyword_pos)
    if json_start == -1:
        raise ValueError(f"No JSON object found after '{start_keyword}'")

    try:
        _, rel_end = _JSON_DECODER.raw_decode(text[json_start:])
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON object after '{start_keyword}': {e}") from e

    return json_start, json_start + rel_end


def extract_and_parse_json_args(raw_args: str, tool_name: str) -> dict[str, Any]:
    """Extract and parse JSON args from tool directive arguments.

    Raises:
        ValueError: if `args=` is missing, no JSON object follows it, or the
        JSON is invalid.
    """
    if "args=" not in raw_args:
        raise ValueError(f"Tool directive missing required 'args' attribute: {raw_args}")

    try:
        json_start, json_end = find_json_object_in_string(raw_args, "args=")
    except ValueError as e:
        if "No JSON object" in str(e):
            raise ValueError(f"Tool directive args must be a JSON object: {raw_args}") from e
        raise ValueError(f"Invalid JSON in tool directive args for '{tool_name}': {e}") from e

    return json.loads(raw_args[json_start:json_end])


def build_validation_test_context(agent, include_prefetch: bool = True) -> dict[str, Any]:
    """Build minimal test context for agent validation.

    Args:
        agent: Agent object to build context for
        include_prefetch: Whether to include mock prefetch variables

    Returns:
        Dict of context variables for template rendering
    """
    test_context = {
        "user_prompt": "test",
        "agent_name": agent.config.name or "test",
        "is_interactive": False,
        "is_daemon": False,
        "is_scheduled": False,
        "schedule_id": "",
        "has_notify_tool": False,
        "tools": agent.config.tools or [],
        "is_subagent": False,
        "parent_agent": None,
        "chat_history": [],
    }

    # Add mock prefetch variables with appropriate shapes
    if include_prefetch and agent.config.prefetch:
        for item in agent.config.prefetch:
            assign_name = item.get("assign")
            if assign_name:
                # Provide mock data with correct shape for known prefetch variables
                if assign_name == "available_skills":
                    # Skills are rendered as {{ skill.name }} and {{ skill.description }}
                    test_context[assign_name] = [{"name": "mock_skill", "description": "Mock skill for validation"}]
                elif assign_name == "failed_skills":
                    test_context[assign_name] = [
                        {
                            "name": "mock_failed",
                            "source": "scan",
                            "path": "/tmp/SKILL.md",
                            "severity": "warning",
                            "message": "Mock failure for validation",
                        }
                    ]
                elif assign_name == "available_agents":
                    # Agents are rendered as a formatted string
                    test_context[assign_name] = "- **mock_agent**: Mock agent for validation"
                else:
                    # Default: use string placeholder
                    test_context[assign_name] = "mock_prefetch_data"

    # Mock attachment `assign:` bindings so templates that reference them validate.
    # Shape mirrors what resolve_agent_config_attachments would produce at runtime.
    for item in agent.config.attachments or []:
        if not isinstance(item, AttachmentSpec) or not item.assign:
            continue
        if item.mode == "index":
            test_context[item.assign] = [{"path": "mock/path.md", "heading": "Mock", "size_bytes": 0, "mtime": 0}]
        elif has_glob_chars(item.path):
            test_context[item.assign] = [{"path": "mock/path.md", "content": "mock content"}]
        else:
            test_context[item.assign] = "mock attachment content"

    return test_context


def add_mock_step_variables(test_context: dict[str, Any], agent_content: str) -> None:
    """Add mock variables for step assignments to test context. Modifies test_context in place."""
    if has_step_directives(agent_content):
        try:
            preamble, steps = extract_step_directives(agent_content)
            for step in steps:
                if step.assign_var:
                    test_context[step.assign_var] = "mock_step_result"
        except Exception:
            logger.debug("Failed to parse step directives for mock variables", exc_info=True)


def add_mock_tool_variables(test_context: dict[str, Any], agent_content: str) -> None:
    """Add mock variables for tool directive assignments to test context. Modifies test_context in place."""
    try:
        directives = extract_tool_directives(agent_content)
        for directive in directives:
            if directive.assign_var:
                test_context[directive.assign_var] = "mock_tool_result"
    except Exception:
        logger.debug("Failed to parse tool directives for mock variables", exc_info=True)


def validate_model_string(model: str) -> tuple[bool, Optional[str]]:
    """Validate model string format.

    Args:
        model: Model string to validate (e.g., "openai:gpt-4")

    Returns:
        Tuple of (is_valid, error_message). Error is None if valid.
    """
    try:
        from .models import parse_model_string

        parse_model_string(model)
        return True, None
    except Exception as e:
        return False, f"Model validation failed: {e}"


def validate_tool_specs(tool_specs: list[str]) -> tuple[bool, Optional[str]]:
    """Validate tool specifications are syntactically correct.

    Args:
        tool_specs: List of tool specification strings

    Returns:
        Tuple of (is_valid, error_message). Error is None if valid.
    """
    try:
        # Import to ensure module can be loaded
        from .tools import expand_tool_specs  # noqa: F401

        # Check syntax is valid
        for tool_spec in tool_specs:
            if not isinstance(tool_spec, str):
                return False, f"Tool specification must be string: {tool_spec}"

        return True, None
    except Exception as e:
        return False, f"Tool import error: {e}"
