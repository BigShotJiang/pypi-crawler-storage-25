"""Helper functions for creating and managing UI loggers."""

from contextlib import contextmanager
from typing import Generator

from rich.console import Console

from tsugite.ui.base import CustomUIHandler, CustomUILogger
from tsugite.ui.plain import PlainUIHandler
from tsugite.ui_context import clear_ui_context, set_ui_context


@contextmanager
def custom_agent_ui(
    console: Console,
    show_code: bool = True,
    show_observations: bool = True,
    show_progress: bool = True,
    show_llm_messages: bool = False,
    show_panels: bool = True,
    show_debug_messages: bool = False,
) -> Generator[CustomUILogger, None, None]:
    """Context manager for custom agent UI.

    Args:
        console: Rich console instance
        show_code: Whether to display executed code
        show_observations: Whether to display tool observations
        show_progress: Whether to show progress spinner
        show_llm_messages: Whether to show LLM reasoning messages
        show_panels: Whether to show Rich panels (borders and decorations)
        show_debug_messages: Whether to show debug messages (requires --verbose)

    Yields:
        CustomUILogger: Logger instance with ui_handler and console
    """
    ui_handler = CustomUIHandler(
        console,
        show_code=show_code,
        show_observations=show_observations,
        show_llm_messages=show_llm_messages,
        show_panels=show_panels,
        show_debug_messages=show_debug_messages,
    )
    logger = CustomUILogger(ui_handler, console)

    try:
        if show_progress:
            # progress_context() will call set_ui_context() with the progress instance
            with ui_handler.progress_context():
                yield logger
        else:
            # No progress, so set ui_context here without progress
            set_ui_context(console=console, progress=None, ui_handler=ui_handler)
            yield logger
    finally:
        clear_ui_context()


def create_plain_logger(show_reasoning: bool = False) -> CustomUILogger:
    """Create a plain text logger for copy-paste friendly output.

    Returns a logger using PlainUIHandler with no colors, panels, or emojis.
    Ideal for:
    - Piped output
    - Copy-paste workflows
    - Screen readers
    - Logs and automation

    Args:
        show_reasoning: When True, render LLM reasoning blocks (mirrors --show-reasoning).

    Returns:
        CustomUILogger with PlainUIHandler
    """
    plain_handler = PlainUIHandler(show_reasoning=show_reasoning)
    return CustomUILogger(plain_handler, plain_handler.console)


def create_live_logger(show_reasoning: bool = False) -> CustomUILogger:
    """Create a three-region live logger: scrollback above, persistent status footer.

    Wraps :class:`LiveUIHandler`, which inherits PlainUIHandler's scrollback formatting
    and adds a 1-3 line status panel pinned at the bottom showing turn, current tool,
    cumulative tokens/cost, and elapsed time.

    Args:
        show_reasoning: When True, render LLM reasoning blocks in the scrollback.

    Returns:
        CustomUILogger with LiveUIHandler; caller is expected to enter
        ``custom_logger.ui_handler.live_context()``.
    """
    from tsugite.ui.live import LiveUIHandler

    live_handler = LiveUIHandler(show_reasoning=show_reasoning)
    return CustomUILogger(live_handler, live_handler.console)
