"""Agent preparation pipeline - unified logic for render and execution."""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

from tsugite.attachments.base import Attachment, AttachmentContentType  # noqa: E402
from tsugite.core.tools import Tool  # noqa: E402
from tsugite.md_agents import Agent, AgentConfig, AttachmentSpec  # noqa: E402
from tsugite.renderer import humanize_mtime  # noqa: E402
from tsugite.skill_discovery import Skill  # noqa: E402
from tsugite.utils import has_glob_chars  # noqa: E402

if TYPE_CHECKING:
    from tsugite.workspace import Workspace


def _render_path(template: str) -> Optional[str]:
    """Render a Jinja path template; return None on render failure."""
    from tsugite.renderer import AgentRenderer

    try:
        return AgentRenderer().render_string(template)
    except Exception as e:
        logger.debug("Failed to render attachment path %r: %s", template, e)
        return None


def split_attachment_removals(
    items: List[Union[str, AttachmentSpec]],
) -> Tuple[set, List[Union[str, AttachmentSpec]]]:
    """Split `-filename` removal markers out of an attachments list.

    The leading-dash convention is string-only legacy syntax; AttachmentSpec items
    always pass through unchanged.
    """
    removals = {t.lstrip("-") for t in items if isinstance(t, str) and t.startswith("-")}
    keep = [t for t in items if not (isinstance(t, str) and t.startswith("-"))]
    return removals, keep


def _resolve_path(rendered: str, workspace_path: Optional[Path]) -> Path:
    p = Path(rendered)
    if not p.is_absolute() and workspace_path:
        p = workspace_path / p
    return p


def _expand_glob(pattern: str, workspace_path: Optional[Path]) -> List[Path]:
    """Expand a glob pattern relative to workspace, alphabetically sorted."""
    p = Path(pattern)
    if p.is_absolute():
        base = Path(p.anchor)
        rel = str(p.relative_to(p.anchor))
    elif workspace_path:
        base = workspace_path
        rel = pattern
    else:
        base = Path.cwd()
        rel = pattern
    matches = sorted(base.glob(rel))
    return [m for m in matches if m.is_file()]


def resolve_agent_config_attachments(
    items: List[Union[str, AttachmentSpec]],
    workspace_path: Optional[Path] = None,
) -> Tuple[List[Attachment], Dict[str, Any]]:
    """Resolve agent config attachment items to Attachment objects and Jinja bindings.

    String items keep legacy semantics (Jinja-render the path, fetch the single file).
    AttachmentSpec items support globs, `assign:` bindings, and `attach: false`.

    Args:
        items: List of strings or AttachmentSpec objects from agent_config.attachments
        workspace_path: Optional workspace path for resolving relative paths

    Returns:
        Tuple of (attachments to inject, dict of {assign_name: bound_value}).
        Bound value is `str` for single concrete files, `list[dict]` for globs,
        and `None` for a missing single file.
    """
    if not items:
        return [], {}

    from tsugite.attachments.file import FileHandler

    file_handler = FileHandler()
    attachments: List[Attachment] = []
    bindings: Dict[str, Any] = {}

    for item in items:
        if isinstance(item, str):
            _resolve_string_item(item, workspace_path, file_handler, attachments)
        else:
            _resolve_spec(item, workspace_path, file_handler, attachments, bindings)

    return attachments, bindings


def _resolve_string_item(
    template: str,
    workspace_path: Optional[Path],
    file_handler: "FileHandler",
    attachments: List[Attachment],
) -> None:
    """Legacy string handling: render Jinja, resolve path, fetch single file."""
    rendered = _render_path(template)
    if rendered is None:
        return
    resolved = _resolve_path(rendered, workspace_path)
    if not resolved.exists():
        logger.debug("Agent attachment not found (skipped): %s", resolved)
        return
    att = file_handler.fetch(str(resolved))
    if att:
        attachments.append(att)
        logger.debug("Loaded agent attachment: %s", resolved)


def _resolve_spec(
    spec: AttachmentSpec,
    workspace_path: Optional[Path],
    file_handler: "FileHandler",
    attachments: List[Attachment],
    bindings: Dict[str, Any],
) -> None:
    """Resolve a single AttachmentSpec, populating attachments and bindings."""
    rendered = _render_path(spec.path)
    if rendered is None:
        if spec.assign:
            bindings[spec.assign] = None
        return

    if spec.mode == "index":
        _resolve_index_spec(spec, rendered, workspace_path, attachments, bindings)
        return

    if has_glob_chars(rendered):
        matched = _expand_glob(rendered, workspace_path)
        if spec.assign:
            bindings[spec.assign] = []
        for path in matched:
            # When attach=False, we only need text content for the binding; skip
            # FileHandler.fetch so binaries aren't base64-encoded just to be discarded.
            if not spec.attach and spec.assign:
                try:
                    content = path.read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    continue
                bindings[spec.assign].append({"path": str(path), "content": content})
                continue
            att = file_handler.fetch(str(path))
            if not att:
                continue
            if spec.attach:
                attachments.append(att)
            if spec.assign and att.content_type == AttachmentContentType.TEXT:
                bindings[spec.assign].append({"path": str(path), "content": att.content})
        return

    resolved = _resolve_path(rendered, workspace_path)
    if not resolved.exists():
        if spec.assign:
            bindings[spec.assign] = None
        logger.debug("Agent attachment not found (skipped): %s", resolved)
        return

    att = file_handler.fetch(str(resolved))
    if not att:
        if spec.assign:
            bindings[spec.assign] = None
        return
    if spec.attach:
        attachments.append(att)
    if spec.assign:
        bindings[spec.assign] = att.content if att.content_type == AttachmentContentType.TEXT else None


def _resolve_index_spec(
    spec: AttachmentSpec,
    rendered_path: str,
    workspace_path: Optional[Path],
    attachments: List[Attachment],
    bindings: Dict[str, Any],
) -> None:
    """Resolve a mode: index spec into a single index Attachment and/or assign binding."""
    if has_glob_chars(rendered_path):
        paths = _expand_glob(rendered_path, workspace_path)
    else:
        single = _resolve_path(rendered_path, workspace_path)
        paths = [single] if single.exists() and single.is_file() else []

    if len(paths) > spec.max_entries:
        logger.warning(
            "Attachment index for %r exceeds max_entries=%d, truncating from %d",
            spec.path,
            spec.max_entries,
            len(paths),
        )
        paths = paths[: spec.max_entries]

    entries = [_extract_index_entry(p, spec.index_format) for p in paths]

    if spec.assign:
        bindings[spec.assign] = entries

    if not entries:
        return

    if spec.attach:
        att_name = spec.name or _derive_index_name(rendered_path)
        att_content = _format_index_block(spec.path, entries, spec.index_format)
        attachments.append(
            Attachment(
                name=att_name,
                content=att_content,
                content_type=AttachmentContentType.TEXT,
                mime_type="text/plain",
                mode="index",
            )
        )


def _extract_index_entry(path: Path, fmt: str) -> Dict[str, Any]:
    """Build an index entry dict for a single file. Falls back gracefully on errors."""
    entry: Dict[str, Any] = {"path": str(path)}

    if fmt == "path_only":
        # Cheapest format: skip stat + read entirely. Only `path` is used downstream.
        entry["heading"] = ""
        return entry

    try:
        stat = path.stat()
        entry["size_bytes"] = stat.st_size
        entry["mtime"] = stat.st_mtime
    except OSError:
        entry["size_bytes"] = 0
        entry["mtime"] = 0

    try:
        with path.open("rb") as f:
            head = f.read(2048)
        text = head.decode("utf-8", errors="replace")
    except OSError:
        text = ""

    if fmt == "first_line":
        entry["heading"] = _first_nonempty_line(text)
    elif fmt == "frontmatter":
        entry.update(_parse_frontmatter_for_index(text, path))
    else:  # first_heading (default)
        entry["heading"] = _first_markdown_heading(text)

    return entry


def _first_nonempty_line(text: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return ""


def _first_markdown_heading(text: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("#").strip()
    return ""


def _parse_frontmatter_for_index(text: str, path: Path) -> Dict[str, Any]:
    """Extract title/description/tags from YAML frontmatter; fall back to path_only on error."""
    if not text.startswith("---"):
        return {"heading": ""}
    try:
        from tsugite.utils import parse_yaml_frontmatter

        meta, _body = parse_yaml_frontmatter(text, str(path))
    except Exception:
        return {"heading": ""}
    out: Dict[str, Any] = {
        "heading": meta.get("title", "") or meta.get("description", ""),
    }
    if "title" in meta:
        out["title"] = meta["title"]
    if "description" in meta:
        out["description"] = meta["description"]
    if "tags" in meta:
        out["tags"] = meta["tags"]
    return out


def _format_index_block(pattern: str, entries: List[Dict[str, Any]], fmt: str) -> str:
    """Render the index Attachment content with a one-line prelude + bullets."""
    prelude = (
        f'File index for "{pattern}" ({len(entries)} files). Use read_file(path=...) to read any of them when relevant.'
    )
    lines = [prelude, ""]
    for entry in entries:
        path = entry.get("path", "")
        if fmt == "path_only":
            lines.append(path)
            continue

        if fmt == "frontmatter":
            title = entry.get("title") or entry.get("heading") or ""
            desc = entry.get("description", "")
            if title and desc:
                bullet = f"{path} - {title}: {desc}"
            elif title:
                bullet = f"{path} - {title}"
            else:
                bullet = path
        else:
            heading = entry.get("heading", "")
            bullet = f"{path} - {heading}" if heading else path

        relative = humanize_mtime(entry.get("mtime"))
        if relative:
            bullet = f"{bullet} ({relative})"
        lines.append(bullet)
    return "\n".join(lines)


def _derive_index_name(pattern: str) -> str:
    """Derive a default index attachment name from a glob pattern.

    Uses the deepest non-glob path segment, suffixed with `_index`. Falls back to
    `attachment_index` if the pattern is purely glob characters.
    """
    parts = Path(pattern).parts
    for segment in reversed(parts):
        if segment and not has_glob_chars(segment) and segment not in ("/", "."):
            return f"{segment}_index"
    return "attachment_index"


@dataclass
class PreparedAgent:
    """Fully prepared agent ready for execution or display.

    This dataclass contains everything needed to either:
    1. Display what will be sent to the LLM (render command)
    2. Execute the agent (run command)

    Attributes:
        agent: Parsed agent object with content and config
        agent_config: Agent configuration (model, tools, etc.)
        system_message: Complete system message sent to LLM
        user_message: Complete user message sent to LLM
        rendered_prompt: Rendered template (before building system message)
        original_prompt: The user's prompt as typed (pre-template-rendering)
        tools: List of Tool objects ready for agent execution
        context: Full template rendering context
        combined_instructions: Combined default + agent instructions
        prefetch_results: Results from prefetch tool execution
        attachments: List of Attachment objects for multi-modal inputs
        skills: List of Skill objects for loaded skills
    """

    agent: Agent
    agent_config: AgentConfig
    system_message: str
    user_message: str
    rendered_prompt: str
    tools: List[Tool]
    context: Dict[str, Any]
    combined_instructions: str
    prefetch_results: Dict[str, Any]
    attachments: List[Attachment]
    original_prompt: str = ""
    skills: List[Skill] = field(default_factory=list)
    # Map of sticky skill name -> turns remaining before auto-unload. Only
    # populated on the turn a skill is about to expire (turns_remaining <= 0).
    # The agent surfaces these as <skill_expiring> blocks in the context turn.
    expiring_skills: Dict[str, int] = field(default_factory=dict)
    skipped: bool = False
    skip_reason: str | None = None


class AgentPreparer:
    """Prepares agents for execution or rendering.

    This class consolidates all agent preparation logic that was previously
    duplicated across render command, run_agent, and _execute_agent_with_prompt.

    The preparation pipeline:
    1. Parse agent file (with inheritance resolution)
    2. Execute prefetch tools
    3. Execute tool directives (optional)
    4. Build template context
    5. Render template
    6. Build instructions
    7. Expand and create tools
    8. Build system prompt

    This ensures that render shows EXACTLY what run executes.
    """

    def _build_directive_placeholders(
        self,
        content: str,
        extractor: Callable[[str], List[Any]],
        kind: str,
        rewrite_to: Optional[Callable[[Any], str]] = None,
    ) -> Tuple[str, Dict[str, str]]:
        """Build {assign_var: placeholder} for directives that won't actually run.

        Used by render-mode shortcuts so the template still has all its variables
        defined. When `rewrite_to` is given, the directive substring is also
        replaced in `content` with the callable's per-directive output.
        """
        try:
            directives = extractor(content)
        except Exception:
            return content, {}

        placeholders: Dict[str, str] = {}
        modified = content
        for d in directives:
            if d.assign_var:
                placeholders[d.assign_var] = f"[{kind} directive: {d.name}(...) - not executed in render mode]"
            if rewrite_to is not None:
                modified = modified.replace(d.raw_match, rewrite_to(d))
        return modified, placeholders

    def _extract_tool_directive_placeholders(self, content: str) -> Dict[str, str]:
        from tsugite.md_agents import extract_tool_directives

        _, placeholders = self._build_directive_placeholders(content, extract_tool_directives, "Tool")
        return placeholders

    def _extract_exec_directive_placeholders(self, content: str) -> Tuple[str, Dict[str, str]]:
        from tsugite.md_agents import extract_exec_directives

        return self._build_directive_placeholders(
            content,
            extract_exec_directives,
            "Exec",
            rewrite_to=lambda d: f"<!-- Exec '{d.name}' skipped (--no-exec) -->",
        )

    def prepare(
        self,
        agent: Agent,
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        workspace: Optional["Workspace"] = None,
        skip_tool_directives: bool = False,
        skip_exec_directives: bool = False,
        attachments: Optional[List[Attachment]] = None,
        event_bus: Optional[Any] = None,
        path_context: Optional[Any] = None,
    ) -> PreparedAgent:
        """Prepare agent with all context, tools, and instructions.

        Args:
            agent: Parsed agent object
            prompt: User prompt/task
            context: Additional context variables
            workspace: Optional workspace for context files and persistent sessions
            skip_tool_directives: Skip executing tool directives (for render)
            skip_exec_directives: Skip executing exec directives (for render --no-exec)
            attachments: List of Attachment objects for multi-modal inputs
            event_bus: Optional event bus for emitting skill load events
            path_context: Optional PathContext with invoked_from, workspace_dir, effective_cwd

        Returns:
            PreparedAgent ready for execution or display

        Raises:
            RuntimeError: If preparation fails
        """
        from tsugite.agent_runner import (
            _combine_instructions,
            execute_exec_directives,
            execute_prefetch,
            execute_tool_directives,
            get_default_instructions,
        )
        from tsugite.core.agent import build_system_prompt
        from tsugite.core.tools import create_tool_from_tsugite
        from tsugite.renderer import AgentRenderer
        from tsugite.tools import expand_tool_specs
        from tsugite.utils import is_interactive

        if context is None:
            context = {}

        agent_config = agent.config

        # Step 0: Resolve workspace files using convention-based discovery
        workspace_attachments: List[Attachment] = []
        if workspace:
            from tsugite.workspace.context import build_workspace_attachments

            workspace_attachments = build_workspace_attachments(workspace)

        # Merge workspace attachments with explicit attachments (explicit first)
        all_attachments = (attachments or []) + workspace_attachments

        # Step 0b: Load agent-config attachments (Jinja-rendered paths). Legacy
        # `-filename` string entries remove a workspace default with that name.
        workspace_path = workspace.path if workspace else None
        removals, keep_items = split_attachment_removals(agent_config.attachments or [])
        if removals:
            all_attachments = [a for a in all_attachments if a.name not in removals]
        loaded, attachment_bindings = resolve_agent_config_attachments(keep_items, workspace_path)
        all_attachments.extend(loaded)

        # Deduplicate by name (keep first occurrence)
        seen_names: set[str] = set()
        deduped: List[Attachment] = []
        for att in all_attachments:
            if att.name not in seen_names:
                seen_names.add(att.name)
                deduped.append(att)
        all_attachments = deduped

        # Step 0c: Set up workspace-aware skill manager. Fall back to
        # path_context.workspace_dir when no Workspace was passed so daemon/chat
        # callers still get workspace skills.
        from tsugite.config import load_config as _load_config
        from tsugite.tools.skills import SkillManager, set_skill_manager
        from tsugite.workspace.models import Workspace

        effective_workspace = workspace or Workspace.try_load(path_context.workspace_dir if path_context else None)

        _config = _load_config()
        extra_skill_paths = (agent_config.skill_paths or []) + (_config.skill_paths or [])
        _skill_manager = SkillManager(workspace=effective_workspace, extra_paths=extra_skill_paths or None)
        set_skill_manager(_skill_manager)

        # Step 1: Execute prefetch tools
        prefetch_context = {}
        if agent_config.prefetch:
            try:
                prefetch_context = execute_prefetch(agent_config.prefetch)
            except Exception:
                # Silently continue if prefetch fails
                prefetch_context = {}

        # Step 1b: Opt-in <available_agents> injection. Default agents call
        # list_available_agents() on demand instead of carrying the full list.
        if "available_agents" not in prefetch_context and (
            agent_config.auto_load_agent_list or agent_config.auto_load_agents
        ):
            from tsugite.tools.agents import discover_agents, format_agents_markdown

            agents = discover_agents()
            if agent_config.auto_load_agents:
                wanted = set(agent_config.auto_load_agents)
                agents = [a for a in agents if a["name"] in wanted]
            prefetch_context["available_agents"] = format_agents_markdown(agents)

        # Step 2: Execute tool directives (unless skip_tool_directives=True for render)
        if skip_tool_directives:
            modified_content = agent.content
            # Extract tool directive variable names and provide placeholders
            tool_context = self._extract_tool_directive_placeholders(agent.content)
        else:
            modified_content, tool_context = execute_tool_directives(agent.content, prefetch_context)

        # Step 2.5: Execute exec directives. Default-on for `tsu render` so the preview
        # reflects what the LLM would see; `--no-exec` opts out for side-effecty blocks.
        if skip_exec_directives:
            modified_content, exec_context = self._extract_exec_directive_placeholders(modified_content)
        else:
            exec_locals: Dict[str, Any] = {**context, **prefetch_context, **tool_context}
            modified_content, exec_context = execute_exec_directives(
                modified_content,
                existing_context=exec_locals,
                event_bus=event_bus,
            )

        # Step 3: Build template context
        interactive_mode = is_interactive()

        # Extract path context values if available
        # Use effective_cwd from path_context (for daemon) or fall back to actual cwd
        if path_context and path_context.effective_cwd:
            cwd = str(path_context.effective_cwd)
        else:
            cwd = str(Path.cwd())
        invoked_from = str(path_context.invoked_from) if path_context else None
        workspace_dir = str(path_context.workspace_dir) if path_context and path_context.workspace_dir else None

        full_context = {
            **context,
            **prefetch_context,
            **tool_context,
            **exec_context,
            "user_prompt": prompt,
            "agent_name": agent_config.name,
            "is_interactive": interactive_mode,
            "is_daemon": context.get("is_daemon", False),
            "is_scheduled": context.get("is_scheduled", False),
            "schedule_id": context.get("schedule_id", ""),
            "has_notify_tool": context.get("has_notify_tool", False),
            "running_tasks": context.get("running_tasks", []),
            "tsugite_url": context.get("tsugite_url", ""),
            "tsugite_token": context.get("tsugite_token", ""),
            "tools": agent_config.tools,
            # Subagent context
            "is_subagent": context.get("is_subagent", False),
            "parent_agent": context.get("parent_agent", None),
            # Chat history (for chat agents)
            "chat_history": context.get("chat_history", []),
            # Path context for workspace-aware agents
            "CWD": cwd,
            "INVOKED_FROM": invoked_from,
            "WORKSPACE_DIR": workspace_dir,
        }

        # Apply attachment `assign:` bindings on top of full_context. User-specified
        # bindings override built-in or prefetch values; warn so collisions surface.
        for name, value in attachment_bindings.items():
            if name in full_context:
                logger.warning("Attachment binding %r overrides existing context variable", name)
            full_context[name] = value

        renderer = AgentRenderer()

        # Step 3b: Evaluate run_if guard (skip agent if expression is falsy)
        if agent_config.run_if:
            skip_reason = None
            try:
                guard_result = renderer.render("{{ " + agent_config.run_if + " }}", full_context)
                if guard_result.strip().lower() in ("", "false", "none", "0"):
                    skip_reason = f"run_if guard '{agent_config.run_if}' evaluated to false"
            except Exception as e:
                skip_reason = f"run_if guard error: {e}"
            if skip_reason:
                return PreparedAgent(
                    agent=agent,
                    agent_config=agent_config,
                    system_message="",
                    user_message="",
                    rendered_prompt="",
                    tools=[],
                    context=full_context,
                    combined_instructions="",
                    prefetch_results=prefetch_context,
                    attachments=all_attachments,
                    skipped=True,
                    skip_reason=skip_reason,
                )

        # Step 4: Render template
        try:
            rendered_prompt = renderer.render(modified_content, full_context)
        except Exception as e:
            raise RuntimeError(f"Template rendering failed: {e}") from e

        # Step 5: Build instructions
        base_instructions = get_default_instructions()
        agent_instructions = getattr(agent_config, "instructions", "")

        # Render agent instructions as Jinja2 template
        if agent_instructions:
            try:
                agent_instructions = renderer.render(agent_instructions, full_context)
            except Exception as e:
                raise RuntimeError(f"Failed to render agent instructions: {e}") from e

        combined_instructions = _combine_instructions(base_instructions, agent_instructions)

        # Step 6: Expand and create tools
        try:
            # Expand tool specifications (categories, globs, regular names)
            expanded_tools = expand_tool_specs(agent_config.tools) if agent_config.tools else []

            # Auto-inject or filter interactive tools based on interaction capability.
            from tsugite.interaction import get_interaction_backend
            from tsugite.tools import _tools

            interactive_tool_names = ["ask_user", "ask_user_batch"]
            has_interaction = (
                interactive_mode or get_interaction_backend() is not None or full_context.get("is_daemon", False)
            )
            if has_interaction:
                for name in interactive_tool_names:
                    if name not in expanded_tools and name in _tools:
                        expanded_tools.append(name)
            else:
                expanded_tools = [t for t in expanded_tools if t not in interactive_tool_names]

            # Auto-inject notify_user when has_notify_tool is set (scheduled tasks)
            if full_context.get("has_notify_tool", False):
                if "notify_user" not in expanded_tools and "notify_user" in _tools:
                    expanded_tools.append("notify_user")

            # Convert to Tool objects
            tools = [create_tool_from_tsugite(name) for name in expanded_tools]
        except Exception as e:
            raise RuntimeError(f"Failed to create tools: {e}") from e

        # Step 7: Load auto_load_skills, sticky skills, and trigger-matched skills
        from tsugite.events.events import SkillLoadFailedEvent

        # Skills the user explicitly removed this session (populated by the daemon).
        suppressed_skills = set(full_context.get("suppressed_skills") or [])

        # Sticky skills carried over from prior turns on this session (daemon-only).
        # Shape: {skill_name: turns_unused_counter}
        sticky_counters: Dict[str, int] = dict(full_context.get("sticky_skills") or {})
        ttl_default = int(full_context.get("skill_ttl_default") or 10)

        # Step 7a: auto_load_skills (exempt from TTL, re-loaded every turn from frontmatter)
        auto_load_skills = [s for s in (agent_config.auto_load_skills or []) if s not in suppressed_skills]

        for skill_name in auto_load_skills:
            result = _skill_manager.load_skill(skill_name)
            if result.startswith("Failed") or result.startswith("Skill '"):
                if event_bus:
                    event_bus.emit(SkillLoadFailedEvent(skill_name=skill_name, error_message=result))

        # Step 7b: sticky skills — re-load whatever carried over from prior turns,
        # unless the counter already exceeded the skill's effective TTL (expired).
        _skill_manager._ensure_registry_initialized()
        registry = _skill_manager._skill_registry
        expiring_skills: Dict[str, int] = {}
        expired_sticky: List[str] = []
        for name, counter in sticky_counters.items():
            if name in suppressed_skills:
                expired_sticky.append(name)
                continue
            meta = registry.get(name)
            if meta is None:
                # Skill vanished (renamed/removed) between turns — drop it.
                expired_sticky.append(name)
                continue
            effective_ttl = meta.ttl if meta.ttl is not None else ttl_default
            if effective_ttl > 0 and counter > effective_ttl:
                expired_sticky.append(name)
                continue
            if name in auto_load_skills:
                # Already loaded above; no need to double-load but it's still sticky.
                continue
            result = _skill_manager.load_skill(name)
            if result.startswith("Failed") or result.startswith("Skill '"):
                if event_bus:
                    event_bus.emit(SkillLoadFailedEvent(skill_name=name, error_message=result))
                continue
            if effective_ttl > 0:
                remaining = effective_ttl - counter
                if remaining <= 1:
                    expiring_skills[name] = max(remaining, 0)

        # Step 7c: trigger-matched skills (new stickies start here when daemon adds them).
        triggered_skill_names = [
            name for name in _skill_manager.get_triggered_skills(prompt) if name not in suppressed_skills
        ]
        for skill_name in triggered_skill_names:
            logger.info(f"Trigger-loading skill '{skill_name}' based on user prompt")
            result = _skill_manager.load_skill(skill_name)
            if result.startswith("Failed") or result.startswith("Skill '"):
                if event_bus:
                    event_bus.emit(SkillLoadFailedEvent(skill_name=skill_name, error_message=result))

        # Stash expired/triggered names so the daemon can update its sticky state post-turn.
        full_context["_expired_sticky_skills"] = expired_sticky
        full_context["_triggered_skill_names"] = list(triggered_skill_names)
        full_context["_auto_loaded_skill_names"] = list(auto_load_skills)

        # Get all successfully loaded skills as Skill objects
        loaded_skills_dict = _skill_manager.get_loaded_skills()
        skills = [Skill(name=name, content=content) for name, content in loaded_skills_dict.items()]

        # Step 8: Build system message (what LLM actually sees)
        system_message = build_system_prompt(tools, combined_instructions)

        # Add environment context when invoked_from differs from CWD
        if invoked_from and invoked_from != cwd:
            env_block = f"""
## Environment

Working directory: {cwd}
Invoked from: {invoked_from}

When the user refers to "this folder", "current directory", or "here",
they typically mean the invoked location ({invoked_from}).
"""
            system_message = system_message + env_block

        # User message is the rendered prompt
        user_message = rendered_prompt

        return PreparedAgent(
            agent=agent,
            agent_config=agent_config,
            system_message=system_message,
            user_message=user_message,
            rendered_prompt=rendered_prompt,
            original_prompt=prompt,
            tools=tools,
            context=full_context,
            combined_instructions=combined_instructions,
            prefetch_results=prefetch_context,
            attachments=all_attachments,
            skills=skills,
            expiring_skills=expiring_skills,
        )
