"""Discord bot adapter."""

import asyncio
import inspect
import logging
import re
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import NamedTuple, Optional

import discord
from discord.ext import commands

from tsugite.daemon.adapters.base import BaseAdapter, ChannelContext, CompositeUIHandler, SSEBroadcastHandler
from tsugite.daemon.config import AgentConfig, DiscordBotConfig
from tsugite.daemon.session_store import Session, SessionSource, SessionStore
from tsugite.events import (
    CodeExecutionEvent,
    ErrorEvent,
    FinalAnswerEvent,
    InfoEvent,
    LLMMessageEvent,
    LLMWaitProgressEvent,
    ObservationEvent,
    ReactionEvent,
    ReasoningContentEvent,
    StepStartEvent,
    ToolCallEvent,
    ToolResultEvent,
    WarningEvent,
)
from tsugite.events.base import BaseEvent

logger = logging.getLogger(__name__)


class ProgressStep(NamedTuple):
    """Progress update step."""

    label: str
    completed: bool
    emoji: str


def _handle_async_exception(future_or_task, context: str = "") -> None:
    """Handle exceptions from Tasks or Futures to prevent silent crashes."""
    try:
        future_or_task.result()
    except asyncio.CancelledError:
        pass
    except Exception as e:
        prefix = f"[{context}] " if context else ""
        logger.error("%sAsync error: %s", prefix, e, exc_info=True)


class DiscordProgressHandler:
    """Lightweight handler for Discord progress updates."""

    MAX_DISPLAY_STEPS = 10  # Show last N steps if too many

    def __init__(
        self,
        channel: discord.abc.Messageable,
        loop: asyncio.AbstractEventLoop,
        trigger_message: Optional[discord.Message] = None,
        header_text: Optional[str] = None,
    ):
        """Initialize progress handler.

        Args:
            channel: Discord channel to send progress updates to
            loop: Discord bot's event loop (for thread-safe scheduling)
            trigger_message: The user message that triggered this interaction (for reactions)
            header_text: First line of the progress tree, used to surface the active session
        """
        self.channel = channel
        self.loop = loop
        self.trigger_message = trigger_message
        self.header_text = header_text or "🤔 Working..."
        self.progress_msg: Optional[discord.Message] = None
        self.updates: list[ProgressStep] = []
        self.update_lock = asyncio.Lock()
        self.typing_task: Optional[asyncio.Task] = None
        self.done = False
        self._reasoning_shown = False
        self._waiting_step_idx: Optional[int] = None
        self._last_rendered: Optional[str] = None
        self._thought_buffer: Optional[str] = None
        self._current_turn = 0
        self._max_turns = 10

    def _complete_prev_and_append(self, label: str, emoji: str) -> None:
        if self.updates:
            prev = self.updates[-1]
            self.updates[-1] = ProgressStep(prev.label, True, prev.emoji)
        self.updates.append(ProgressStep(label, False, emoji))

    def _mark_last_complete(self) -> bool:
        if self.updates and not self.updates[-1].completed:
            last = self.updates[-1]
            self.updates[-1] = ProgressStep(last.label, True, last.emoji)
            return True
        return False

    async def _flush_thought(self) -> None:
        """Send the buffered LLM thought prose as a standalone Discord message."""
        if not self._thought_buffer:
            return
        text = self._thought_buffer
        self._thought_buffer = None

        msg = f"💭 {text}"
        limit = 2000
        if len(msg) > limit:
            suffix = "\n... (truncated)"
            msg = msg[: limit - len(suffix)] + suffix

        try:
            await self.channel.send(msg)
        except discord.errors.HTTPException as e:
            logger.debug("Failed to send thought: %s", e)

    def handle_event(self, event: BaseEvent) -> None:
        """Handle EventBus events and update Discord message.

        This is called from a different thread (executor), so we use
        run_coroutine_threadsafe to schedule work on the Discord event loop.
        """
        future = asyncio.run_coroutine_threadsafe(self._handle_event_async(event), self.loop)
        future.add_done_callback(lambda f: _handle_async_exception(f, "progress"))

    def _emit(self, event_type: str, data: dict) -> None:
        """Handle progress events from the base adapter (e.g. compacting/compacted)."""
        if event_type == "compacting":
            self.updates.append(ProgressStep("Compacting history", False, "📦"))
        elif event_type == "compacting_waiting":
            self.updates.append(ProgressStep("Waiting for compaction", False, "⌛"))
        elif event_type == "compacted":
            if self.updates and self.updates[-1].emoji in {"📦", "⌛"} and not self.updates[-1].completed:
                last = self.updates[-1]
                self.updates[-1] = ProgressStep(last.label, True, last.emoji)
        else:
            return
        future = asyncio.run_coroutine_threadsafe(self._update_progress(), self.loop)
        future.add_done_callback(lambda f: _handle_async_exception(f, "emit"))

    async def _handle_event_async(self, event: BaseEvent) -> None:
        """Async implementation of event handling.

        Labels mirror _progress_status_text in tsugite/daemon/session_store.py so the
        Discord progress message shows the same status text the web UI sidebar shows.
        """
        async with self.update_lock:
            if not isinstance(event, LLMWaitProgressEvent):
                self._waiting_step_idx = None

            if isinstance(event, StepStartEvent):
                self._current_turn = event.step
                self._max_turns = event.max_turns
                self._complete_prev_and_append(f"Turn {event.step}/{event.max_turns}", "🤔")
                await self._update_progress()

            elif isinstance(event, CodeExecutionEvent):
                await self._flush_thought()
                self._complete_prev_and_append("Running code", "⚙️")
                await self._update_progress()

            elif isinstance(event, ToolCallEvent):
                await self._flush_thought()
                self._complete_prev_and_append(f"Tool: {event.tool_name}", "🔧")
                await self._update_progress()

            elif isinstance(event, (ObservationEvent, ToolResultEvent)):
                if self._mark_last_complete():
                    await self._update_progress()

            elif isinstance(event, LLMMessageEvent):
                if event.content:
                    self._thought_buffer = event.content

            elif isinstance(event, ReasoningContentEvent):
                if not self._reasoning_shown:
                    self._reasoning_shown = True
                    self.updates.append(ProgressStep("Reasoning", False, "💭"))
                    await self._update_progress()

            elif isinstance(event, LLMWaitProgressEvent):
                label = f"Waiting on LLM ({event.elapsed_seconds}s)"
                if self._waiting_step_idx is not None:
                    self.updates[self._waiting_step_idx] = ProgressStep(label, False, "⏳")
                else:
                    self.updates.append(ProgressStep(label, False, "⏳"))
                    self._waiting_step_idx = len(self.updates) - 1
                await self._update_progress()

            elif isinstance(event, WarningEvent):
                self.updates.append(ProgressStep("Retrying", False, "⚠️"))
                await self._update_progress()

            elif isinstance(event, ErrorEvent):
                self.updates.append(ProgressStep("Error", False, "❌"))
                await self._update_progress()

            elif isinstance(event, InfoEvent):
                if event.message:
                    try:
                        await self.channel.send(event.message)
                    except discord.errors.HTTPException as e:
                        logger.debug("Failed to send info message: %s", e)

            elif isinstance(event, ReactionEvent):
                target = self.trigger_message
                if target and event.emoji:
                    try:
                        await target.add_reaction(event.emoji)
                    except discord.errors.HTTPException as e:
                        logger.debug("Failed to add reaction %s: %s", event.emoji, e)

            elif isinstance(event, FinalAnswerEvent):
                self._thought_buffer = None
                self._mark_last_complete()
                await self._collapse_to_summary()

    async def _update_progress(self):
        """Update or create progress message."""
        if self.done:
            return

        lines = [self.header_text]

        display_updates = self.updates
        if len(self.updates) > self.MAX_DISPLAY_STEPS:
            skipped = len(self.updates) - self.MAX_DISPLAY_STEPS
            lines.append(f"├─ ... ({skipped} earlier steps)")
            display_updates = self.updates[-self.MAX_DISPLAY_STEPS :]

        for i, step in enumerate(display_updates):
            is_last = i == len(display_updates) - 1
            prefix = "└─" if is_last else "├─"
            suffix = " ✓" if step.completed else ""
            lines.append(f"{prefix} {step.emoji} {step.label}{suffix}")

        text = "\n".join(lines)

        if len(text) > 2000:
            text = text[:1950] + "\n... (truncated)"

        if text == self._last_rendered:
            return

        try:
            if self.progress_msg is None:
                self.progress_msg = await self.channel.send(text)
            else:
                await self.progress_msg.edit(content=text)
            self._last_rendered = text
        except discord.errors.HTTPException:
            pass  # Ignore errors (rate limit, deleted message, etc.)

    async def _collapse_to_summary(self):
        """Collapse progress to a summary on completion."""
        self.done = True

        if not self.progress_msg or not self.updates:
            return

        turn_count = sum(1 for u in self.updates if u.label.startswith("Turn "))
        if turn_count == 0:
            turn_count = self._current_turn or 1

        summary = f"✅ Done ({turn_count} turn{'s' if turn_count != 1 else ''})"

        try:
            await self.progress_msg.edit(content=summary)
        except discord.errors.HTTPException:
            pass

    async def start_typing_loop(self):
        """Keep typing indicator active for long operations."""

        async def typing_loop():
            try:
                while not self.done:
                    try:
                        await self.channel.typing()
                    except (AttributeError, discord.errors.HTTPException):
                        pass  # Some channel types may not support typing
                    await asyncio.sleep(8)  # Re-trigger before 10s expiry
            except asyncio.CancelledError:
                pass
            except Exception as e:
                logger.debug("Typing loop error: %s", e)

        self.typing_task = asyncio.create_task(typing_loop())

    async def cleanup(self, success: bool = True):
        """Clean up and finalize status message."""
        self.done = True

        if self.typing_task:
            self.typing_task.cancel()
            try:
                await self.typing_task
            except asyncio.CancelledError:
                pass

        if self.progress_msg and not success:
            try:
                turn_count = sum(1 for u in self.updates if u.label.startswith("Turn "))
                if turn_count == 0:
                    turn_count = self._current_turn or 1
                await self.progress_msg.edit(
                    content=f"❌ Error after {turn_count} turn{'s' if turn_count != 1 else ''}"
                )
            except discord.errors.HTTPException:
                pass
        elif success and self.updates and self.progress_msg:
            await self._collapse_to_summary()


class _YesNoView(discord.ui.View):
    """Discord button view for yes/no questions."""

    def __init__(self, question: str, user_id: str, timeout: float = 300):
        super().__init__(timeout=timeout)
        self.value: Optional[str] = None
        self.question = question
        self._user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self._user_id:
            await interaction.response.send_message("This question isn't for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Yes", style=discord.ButtonStyle.green)
    async def yes_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = "yes"
        await interaction.response.edit_message(content=f"**Q:** {self.question}\n**A:** Yes", view=None)
        self.stop()

    @discord.ui.button(label="No", style=discord.ButtonStyle.red)
    async def no_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = "no"
        await interaction.response.edit_message(content=f"**Q:** {self.question}\n**A:** No", view=None)
        self.stop()


class _ChoiceView(discord.ui.View):
    """Discord button/select view for choice questions."""

    def __init__(self, question: str, options: list[str], user_id: str, timeout: float = 300):
        super().__init__(timeout=timeout)
        self.value: Optional[str] = None
        self.question = question
        self._user_id = user_id

        if len(options) <= 5:
            for opt in options:
                self.add_item(_ChoiceButton(opt, self))
        else:
            self.add_item(_ChoiceSelect(options, self))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self._user_id:
            await interaction.response.send_message("This question isn't for you.", ephemeral=True)
            return False
        return True


class _ChoiceButton(discord.ui.Button):
    def __init__(self, label: str, parent_view: _ChoiceView):
        super().__init__(label=label, style=discord.ButtonStyle.primary)
        self._parent_view = parent_view

    async def callback(self, interaction: discord.Interaction):
        self._parent_view.value = self.label
        await interaction.response.edit_message(
            content=f"**Q:** {self._parent_view.question}\n**A:** {self.label}", view=None
        )
        self._parent_view.stop()


class _ChoiceSelect(discord.ui.Select):
    def __init__(self, options: list[str], parent_view: _ChoiceView):
        super().__init__(
            placeholder="Select an option...",
            options=[discord.SelectOption(label=opt) for opt in options[:25]],
        )
        self._parent_view = parent_view

    async def callback(self, interaction: discord.Interaction):
        self._parent_view.value = self.values[0]
        await interaction.response.edit_message(
            content=f"**Q:** {self._parent_view.question}\n**A:** {self.values[0]}", view=None
        )
        self._parent_view.stop()


class _TextInputModal(discord.ui.Modal):
    """Discord modal for freeform text input."""

    def __init__(self, question: str, timeout: float = 300):
        super().__init__(title="Question", timeout=timeout)
        self.value: Optional[str] = None
        self._question = question
        self.answer = discord.ui.TextInput(
            label=question[:45],  # Discord label limit is 45 chars
            placeholder="Type your answer...",
            style=discord.TextStyle.paragraph,
            required=True,
        )
        self.add_item(self.answer)

    async def on_submit(self, interaction: discord.Interaction):
        self.value = self.answer.value
        await interaction.response.defer()
        self.stop()


class _TextInputView(discord.ui.View):
    """View with a Reply button that opens a text input modal."""

    def __init__(self, question: str, user_id: str, timeout: float = 300):
        super().__init__(timeout=timeout)
        self.question = question
        self._user_id = user_id
        self._timeout = timeout
        self.modal: Optional[_TextInputModal] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self._user_id:
            await interaction.response.send_message("This question isn't for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Reply", style=discord.ButtonStyle.primary, emoji="\u270f\ufe0f")
    async def reply_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.modal = _TextInputModal(self.question, timeout=self._timeout)
        await interaction.response.send_modal(self.modal)
        # Wait for the modal to complete
        timed_out = await self.modal.wait()
        if not timed_out and self.modal.value is not None:
            self.stop()


class DiscordInteractionBackend:
    """Interaction backend for Discord — uses views/modals for questions."""

    TIMEOUT = 300

    def __init__(
        self, bot: commands.Bot, channel: discord.abc.Messageable, user_id: str, loop: asyncio.AbstractEventLoop
    ):
        self._bot = bot
        self._channel = channel
        self._user_id = user_id
        self._loop = loop

    def ask_user(self, question: str, question_type: str = "text", options: Optional[list[str]] = None) -> str:
        future = asyncio.run_coroutine_threadsafe(self._ask_async(question, question_type, options), self._loop)
        try:
            return future.result(timeout=self.TIMEOUT)
        except asyncio.CancelledError:
            raise RuntimeError("Interaction cancelled (Discord bot shutting down)")
        except TimeoutError:
            raise RuntimeError("Timed out waiting for user response (Discord)")

    async def _ask_async(self, question: str, question_type: str, options: Optional[list[str]]) -> str:
        if question_type == "yes_no":
            view = _YesNoView(question, user_id=self._user_id, timeout=self.TIMEOUT)
            await self._channel.send(f"**Question:** {question}", view=view)
            timed_out = await view.wait()
            if timed_out or view.value is None:
                raise RuntimeError("Timed out waiting for user response (Discord)")
            return view.value

        elif question_type == "choice" and options:
            view = _ChoiceView(question, options, user_id=self._user_id, timeout=self.TIMEOUT)
            await self._channel.send(f"**Question:** {question}", view=view)
            timed_out = await view.wait()
            if timed_out or view.value is None:
                raise RuntimeError("Timed out waiting for user response (Discord)")
            return view.value

        else:  # text — use modal via button
            view = _TextInputView(question, user_id=self._user_id, timeout=self.TIMEOUT)
            msg = await self._channel.send(f"**Question:** {question}", view=view)
            timed_out = await view.wait()
            value = view.modal.value if view.modal else None
            if timed_out or value is None:
                raise RuntimeError("Timed out waiting for user response (Discord)")
            await msg.edit(content=f"**Q:** {question}\n**A:** {value}", view=None)
            return value


class DiscordAdapter(BaseAdapter):
    """Discord bot adapter tied to a specific agent."""

    def __init__(
        self,
        bot_config: DiscordBotConfig,
        agent_name: str,
        agent_config: AgentConfig,
        session_store: "SessionStore",
        identity_map: dict[str, str] | None = None,
    ):
        super().__init__(agent_name, agent_config, session_store, identity_map=identity_map)
        self.bot_config = bot_config
        self.active_progress_handlers: list[DiscordProgressHandler] = []

        intents = discord.Intents.default()
        intents.message_content = True

        self.bot = commands.Bot(command_prefix=bot_config.command_prefix, intents=intents)
        self._register_commands()

        @self.bot.event
        async def on_ready():
            try:
                if bot_config.guild_id:
                    guild = discord.Object(id=int(bot_config.guild_id))
                    self.bot.tree.copy_global_to(guild=guild)
                    await self.bot.tree.sync(guild=guild)
                else:
                    await self.bot.tree.sync()
                synced = len(self.bot.tree.get_commands())
                logger.info(
                    "Discord bot '%s' logged in as %s (agent: %s, %d app commands synced)",
                    bot_config.name,
                    self.bot.user,
                    agent_name,
                    synced,
                )
            except Exception as e:
                logger.error("Failed to sync app commands for '%s': %s", bot_config.name, e)
                logger.info("Discord bot '%s' logged in as %s (agent: %s)", bot_config.name, self.bot.user, agent_name)

        @self.bot.event
        async def on_error(event_method, *args, **kwargs):
            logger.error("[%s] Discord event error in %s", bot_config.name, event_method, exc_info=True)

        @self.bot.event
        async def on_message(message):
            if message.author == self.bot.user:
                return

            is_dm = isinstance(message.channel, discord.DMChannel)
            is_thread = isinstance(message.channel, discord.Thread)

            # Check allowlist for both DMs and server channels
            if bot_config.dm_policy == "allowlist":
                if str(message.author.id) not in bot_config.allow_from:
                    if is_dm:
                        await message.channel.send("You are not authorized.")
                    return

            def strip_mention(text: str) -> str:
                return text.replace(f"<@{self.bot.user.id}>", "").replace(f"<@!{self.bot.user.id}>", "").strip()

            if is_dm:
                user_msg = message.content.strip()
            elif is_thread:
                bot_owns_thread = message.channel.owner_id == self.bot.user.id
                if bot_owns_thread:
                    user_msg = message.content.strip()
                elif self.bot.user.mentioned_in(message):
                    user_msg = strip_mention(message.content)
                else:
                    return
            else:
                if not self.bot.user.mentioned_in(message):
                    return
                user_msg = strip_mention(message.content)

            if not user_msg:
                return

            channel_type = "thread" if is_thread else ("DM" if is_dm else "channel")
            logger.info("[%s] <- %s (%s): %s", bot_config.name, message.author, channel_type, user_msg[:100])

            task = asyncio.create_task(self._process_message(message, user_msg, bot_config.name))
            task.add_done_callback(lambda t: _handle_async_exception(t, bot_config.name))

    def _register_commands(self):
        """Auto-register adapter commands from the shared registry as Discord app commands."""
        from tsugite.daemon.commands import get_commands

        for cmd in get_commands().values():
            self._add_app_command(cmd)

    def _add_app_command(self, cmd: "AdapterCommand"):
        """Convert an AdapterCommand to a discord app_commands.Command and add to the bot tree."""
        adapter = self

        # user_id is auto-injected from the interaction, so hide it from the Discord UI
        visible_params = [p for p in cmd.params if p.name != "user_id"]
        auto_inject_user_id = len(visible_params) < len(cmd.params)

        sig_params = [
            inspect.Parameter("interaction", inspect.Parameter.POSITIONAL_OR_KEYWORD, annotation=discord.Interaction)
        ]
        for p in visible_params:
            ann = Optional[p.type] if not p.required else p.type
            default = inspect.Parameter.empty if p.required else None
            sig_params.append(
                inspect.Parameter(p.name, inspect.Parameter.POSITIONAL_OR_KEYWORD, annotation=ann, default=default)
            )

        async def callback(interaction: discord.Interaction, **kwargs):
            await interaction.response.defer()
            if auto_inject_user_id:
                kwargs.setdefault("user_id", str(interaction.user.id))
            try:
                result = await cmd.handler(adapter, **kwargs)
            except Exception as e:
                logger.error("App command '%s' failed: %s", cmd.name, e)
                result = f"Command failed: {e}"
            await interaction.followup.send(str(result)[:2000])

        callback.__signature__ = inspect.Signature(sig_params)
        callback.__annotations__ = {p.name: p.annotation for p in sig_params}

        descriptions = {p.name: p.description for p in visible_params}
        if descriptions:
            callback = discord.app_commands.describe(**descriptions)(callback)

        app_cmd = discord.app_commands.Command(name=cmd.name, description=cmd.description, callback=callback)
        self.bot.tree.add_command(app_cmd)

    def _resolve_target_session(
        self, message, channel_context: ChannelContext, is_thread: bool, is_dm: bool, thread_id: Optional[str]
    ) -> Session:
        """Pick which session this message routes to.

        Channels and threads stay shared across users (team-agent context). DMs are
        per-user, and when bot_config.session_name is set DMs route to the named session
        for that user instead of their default-interactive.
        """
        user_id = self.resolve_user(str(message.author.id), channel_context)

        if is_thread and thread_id:
            existing = self.session_store.find_by_thread(thread_id)
            if existing:
                return existing
            parent_session = self.session_store.get_or_create_interactive(user_id, self.agent_name)
            parent_channel_id = getattr(message.channel, "parent_id", None)
            thread_session = Session(
                id="",
                agent=self.agent_name,
                source=SessionSource.INTERACTIVE.value,
                user_id=user_id,
                parent_id=parent_session.id,
                metadata={
                    "thread_name": getattr(message.channel, "name", ""),
                    "channel_id": str(parent_channel_id) if parent_channel_id else None,
                    "thread_id": thread_id,
                },
            )
            self.session_store.create_session(thread_session)
            return thread_session

        if not is_dm and message.guild:
            return self.session_store.get_or_create_channel_session(
                channel_id=str(message.channel.id),
                agent=self.agent_name,
                user_id=user_id,
            )

        if self.bot_config.session_name:
            return self.session_store.get_or_create_named_session(
                user_id, self.agent_name, self.bot_config.session_name
            )

        return self.session_store.get_or_create_interactive(user_id, self.agent_name)

    @staticmethod
    def _channel_display_name(channel) -> str:
        return getattr(channel, "name", "?")

    def _build_progress_header(self, message, session: Session, is_thread: bool, is_dm: bool) -> str:
        if is_thread:
            route = f"thread {self._channel_display_name(message.channel)}"
        elif not is_dm and message.guild:
            route = f"#{self._channel_display_name(message.channel)}"
        elif self.bot_config.session_name:
            route = f"DM · named: {self.bot_config.session_name}"
        else:
            route = "DM"

        identifier = session.metadata.get("topic") or session.id[:6]
        return f"🤔 {route} · {identifier}"

    async def _process_message(self, message, user_msg: str, bot_name: str):
        """Process a message in an isolated task."""
        is_thread = isinstance(message.channel, discord.Thread)
        is_dm = isinstance(message.channel, discord.DMChannel)
        thread_id = str(message.channel.id) if is_thread else None

        channel_context = ChannelContext(
            source="discord",
            channel_id=str(message.channel.id),
            user_id=str(message.author.id),
            reply_to=f"discord:{message.channel.id}",
            thread_id=thread_id,
            metadata={
                "author_name": str(message.author),
                "guild_id": str(message.guild.id) if message.guild else None,
            },
        )

        target_session = self._resolve_target_session(message, channel_context, is_thread, is_dm, thread_id)
        channel_context.metadata["conv_id_override"] = target_session.id

        header_text = self._build_progress_header(message, target_session, is_thread, is_dm)

        loop = asyncio.get_running_loop()
        progress = DiscordProgressHandler(message.channel, loop, trigger_message=message, header_text=header_text)
        sse_handler = SSEBroadcastHandler(
            broadcaster=self.event_bus,
            session_id=target_session.id,
            persist_event=lambda payload: self.session_store.append_event(
                target_session.id,
                {**payload, "timestamp": datetime.now(timezone.utc).isoformat()},
            ),
        )
        custom_logger = SimpleNamespace(ui_handler=CompositeUIHandler(progress, sse_handler))

        from tsugite.interaction import set_interaction_backend

        interaction_backend = DiscordInteractionBackend(
            bot=self.bot,
            channel=message.channel,
            user_id=str(message.author.id),
            loop=loop,
        )
        set_interaction_backend(interaction_backend)

        await progress.start_typing_loop()
        self.active_progress_handlers.append(progress)

        try:
            response = await self.handle_message(
                user_id=str(message.author.id),
                message=user_msg,
                channel_context=channel_context,
                custom_logger=custom_logger,
            )
            await progress.cleanup(success=True)
            if not sse_handler.has_final:
                sse_handler._emit("final_result", {"result": response})

        except Exception as e:
            await progress.cleanup(success=False)
            response = f"Error processing message: {e}"
            logger.error("[%s] %s", bot_name, e, exc_info=True)
            if not sse_handler.has_final:
                sse_handler._emit("error", {"error": str(e)})
        finally:
            # Remove from active handlers after cleanup
            if progress in self.active_progress_handlers:
                self.active_progress_handlers.remove(progress)

        logger.info("[%s] -> %s: %s", bot_name, message.author, response[:100])
        await self._send_chunked(message.channel, response)

    def _split_respecting_code_blocks(self, text: str, limit: int) -> list[str]:
        """Split text into chunks respecting code block boundaries.

        Args:
            text: Text to split
            limit: Maximum chunk size

        Returns:
            List of chunks
        """
        code_block_pattern = re.compile(r"```(\w*)\n([\s\S]*?)```")
        closing_fence_len = 4  # "\n```"

        chunks: list[str] = []
        current = ""

        def flush_current() -> None:
            nonlocal current
            if current.strip():
                chunks.append(current.rstrip("\n"))
            current = ""

        def add_text_lines(text_content: str) -> None:
            nonlocal current
            for line in text_content.split("\n"):
                if len(current) + len(line) + 1 <= limit:
                    current += line + "\n"
                else:
                    flush_current()
                    current = line + "\n"

        def add_code_block(full_block: str, lang: str, inner: str) -> None:
            nonlocal current

            if len(current) + len(full_block) <= limit:
                current += full_block
                return

            if len(full_block) <= limit:
                flush_current()
                current = full_block
                return

            flush_current()
            header = f"```{lang}\n"
            code_chunk = header

            for line in inner.split("\n"):
                line_with_newline = line + "\n"
                if len(code_chunk) + len(line_with_newline) + closing_fence_len <= limit:
                    code_chunk += line_with_newline
                else:
                    chunks.append(code_chunk.rstrip("\n") + "\n```")
                    code_chunk = header + line_with_newline

            if code_chunk != header:
                current = code_chunk.rstrip("\n") + "\n```"

        last_end = 0
        for match in code_block_pattern.finditer(text):
            if match.start() > last_end:
                add_text_lines(text[last_end : match.start()])

            lang = match.group(1)
            inner = match.group(2).strip("\n")
            full_block = f"```{lang}\n{inner}\n```"
            add_code_block(full_block, lang, inner)
            last_end = match.end()

        if last_end < len(text):
            add_text_lines(text[last_end:])

        flush_current()
        return chunks

    async def _send_chunked(self, channel, text: str):
        """Send message, splitting if longer than 2000 chars while respecting code blocks.

        Args:
            channel: Discord channel to send to
            text: Message text to send
        """
        limit = 2000

        if len(text) <= limit:
            await channel.send(text)
            return

        chunks = self._split_respecting_code_blocks(text, limit)
        for chunk in chunks:
            if chunk.strip():
                await channel.send(chunk)

    # ── ThreadCapability implementation ──

    async def _get_thread(self, platform_thread_id: str) -> discord.Thread:
        """Fetch a Discord thread by ID, raising if not found or not a thread."""
        channel = self.bot.get_channel(int(platform_thread_id))
        if not channel:
            channel = await self.bot.fetch_channel(int(platform_thread_id))
        if not isinstance(channel, discord.Thread):
            raise RuntimeError(f"Channel {platform_thread_id} is not a thread")
        return channel

    async def create_thread(self, channel_id: str, title: str) -> str:
        """Create a Discord thread in the specified channel."""
        channel = self.bot.get_channel(int(channel_id))
        if not channel:
            channel = await self.bot.fetch_channel(int(channel_id))
        thread = await channel.create_thread(name=title[:100], type=discord.ChannelType.public_thread)
        return str(thread.id)

    async def send_to_thread(self, platform_thread_id: str, message: str) -> None:
        thread = await self._get_thread(platform_thread_id)
        if thread.archived:
            await thread.edit(archived=False)
        await self._send_chunked(thread, message)

    async def close_thread(self, platform_thread_id: str) -> None:
        thread = await self._get_thread(platform_thread_id)
        await thread.edit(archived=True)

    async def start(self):
        """Start Discord bot with retry on transient errors."""
        max_retries = 5
        backoff = 5
        for attempt in range(max_retries):
            try:
                await self.bot.start(self.bot_config.resolve_token())
                break
            except (discord.errors.DiscordServerError, OSError) as e:
                if attempt < max_retries - 1:
                    delay = backoff * (2**attempt)
                    logger.warning(
                        "Discord connection failed (attempt %d/%d): %s — retrying in %ds",
                        attempt + 1,
                        max_retries,
                        e,
                        delay,
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error("Discord adapter failed after %d retries", max_retries)
                    raise

    async def stop(self):
        """Stop Discord bot and clean up resources."""
        # Clean up any active progress handlers (orphaned typing tasks)
        for progress in self.active_progress_handlers[:]:  # Copy list to avoid modification during iteration
            await progress.cleanup(success=False)
        self.active_progress_handlers.clear()

        await self.bot.close()
