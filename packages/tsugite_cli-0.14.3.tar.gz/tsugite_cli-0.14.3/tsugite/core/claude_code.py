"""Claude Code CLI subprocess provider.

Routes LLM calls through `claude --print` instead of a direct HTTP provider,
enabling Claude Max subscription auth. Text-only, no multimodal support.
"""

import asyncio
import json
import logging
import os
import shutil
import tempfile
import uuid
from collections.abc import AsyncIterator

from tsugite.cli.helpers import get_workspace_dir

logger = logging.getLogger(__name__)

# Env vars that must be unset to avoid "nested session" detection
_CLAUDE_ENV_VARS = {"CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "ANTHROPIC_API_KEY"}


async def claude_code_complete(system_prompt: str, user_content: str, model: str) -> str:
    """One-shot completion via Claude Code CLI.

    Creates a subprocess, sends a single message, and returns the result text.
    Used for compaction/summarization when the agent uses the claude_code provider.
    """
    proc = ClaudeCodeProcess()
    try:
        await proc.start(model, system_prompt)
        async for event in proc.send_message(user_content):
            if event["type"] == "result":
                return event.get("text", "")
        return ""
    finally:
        await proc.stop()


class ClaudeCodeProcess:
    """Manages a persistent claude CLI subprocess for LLM completions.

    Uses stream-json I/O format to send user turns via stdin and parse
    streaming responses from stdout. The subprocess holds conversation
    state in memory between turns.
    """

    def __init__(self):
        self._process: asyncio.subprocess.Process | None = None  # pylint: disable=no-member
        self._session_id: str | None = None
        self._system_prompt_file: str | None = None
        self._stderr_lines: list[str] = []
        self._stderr_task: asyncio.Task | None = None
        self._compacted: bool = False
        self._last_usage: dict = {}

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @property
    def compacted(self) -> bool:
        """Whether Claude Code auto-compacted during this session."""
        return self._compacted

    async def _drain_stderr(self) -> None:
        """Background task: read stderr lines so the pipe never fills up."""
        try:
            while True:
                line = await self._process.stderr.readline()
                if not line:
                    break
                self._stderr_lines.append(line.decode().rstrip())
        except (asyncio.CancelledError, Exception):
            pass

    def _get_stderr(self) -> str:
        return "\n".join(self._stderr_lines[-20:])  # last 20 lines

    async def start(
        self,
        model: str,
        system_prompt: str,
        resume_session: str | None = None,
        effort: str | None = None,
    ) -> None:
        """Launch persistent claude subprocess.

        Args:
            model: Model name (sonnet, opus, haiku, or full model ID)
            system_prompt: System prompt text
            resume_session: Optional session ID to resume instead of starting fresh
            effort: Optional reasoning effort level passed via ``--effort``
                (low, medium, high, xhigh, max).

        Raises:
            RuntimeError: If claude CLI is not found or fails to start
        """
        if not shutil.which("claude"):
            raise RuntimeError("Claude Code CLI not found. Install it with: npm install -g @anthropic-ai/claude-code")

        # Write system prompt to temp file
        fd, self._system_prompt_file = tempfile.mkstemp(suffix=".txt", prefix="tsugite_sysprompt_")
        with os.fdopen(fd, "w") as f:
            f.write(system_prompt)

        cmd = [
            "claude",
            "--print",
            "--input-format",
            "stream-json",
            "--output-format",
            "stream-json",
            "--verbose",
            "--max-turns",
            "1",
            "--model",
            model,
            "--tools",
            "",
            "--strict-mcp-config",
            "--system-prompt-file",
            self._system_prompt_file,
        ]

        if resume_session:
            cmd.extend(["--resume", resume_session])
        else:
            cmd.extend(["--session-id", str(uuid.uuid4())])

        if effort:
            cmd.extend(["--effort", effort])

        # Copy env but unset keys that trigger nested-session guard or API key usage
        env = {k: v for k, v in os.environ.items() if k not in _CLAUDE_ENV_VARS}

        workspace = get_workspace_dir()
        self._process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            cwd=str(workspace) if workspace is not None else None,
        )

        # Start draining stderr in background to prevent pipe buffer deadlock
        self._stderr_task = asyncio.create_task(self._drain_stderr())
        mode = f"resume={resume_session}" if resume_session else "new session"
        logger.info(
            "Claude Code subprocess started (pid=%d, model=%s, effort=%s, %s)",
            self._process.pid,
            model,
            effort or "default",
            mode,
        )

    async def send_message(self, content: str) -> AsyncIterator[dict]:
        """Write user message to stdin and yield streaming events from stdout.

        Args:
            content: User message text

        Yields:
            Dicts with type "text_delta" (streaming chunk) or "result" (final)

        Raises:
            RuntimeError: If subprocess has crashed
        """
        msg = {
            "type": "user",
            "message": {"role": "user", "content": content},
            "session_id": self._session_id or "default",
        }
        content_len = len(content)
        self._process.stdin.write((json.dumps(msg) + "\n").encode())
        await self._process.stdin.drain()
        logger.debug("Sent message (%d chars, ~%d est tokens): %.200s", content_len, content_len // 4, content)

        while True:
            line = await self._process.stdout.readline()
            if not line:
                stderr = self._get_stderr()
                raise RuntimeError(
                    f"Claude Code process ended unexpectedly (sent ~{content_len} chars). stderr: {stderr}"
                )

            raw = line.decode().strip()
            if not raw:
                continue

            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue

            event_type = event.get("type", "")

            # Init event — capture session_id (arrives after first user message)
            if event_type == "system" and event.get("subtype") == "init":
                self._session_id = event.get("session_id")
                logger.debug("Init event received (session=%s)", self._session_id)
                continue

            # Compact boundary — Claude Code auto-compacted the conversation
            if event_type == "system" and event.get("subtype") == "compact_boundary":
                self._compacted = True
                logger.info(
                    "Claude Code auto-compacted (preTokens=%s)",
                    event.get("compactMetadata", {}).get("preTokens"),
                )
                continue

            # Content block delta (streaming with --include-partial-messages)
            if event_type == "content_block_delta":
                delta = event.get("delta", {})
                if delta.get("type") == "text_delta":
                    yield {"type": "text_delta", "text": delta["text"]}

            # Full assistant message — extract text and usage from content blocks
            elif event_type == "assistant":
                message = event.get("message", {})
                usage = message.get("usage", {})
                if usage:
                    self._last_usage = usage
                content_blocks = message.get("content", [])
                # Claude CLI redacts thinking text, leaving an empty payload, so drop it
                # entirely rather than surfacing a content-free placeholder block.
                text = "".join(block.get("text", "") for block in content_blocks if block.get("type") == "text")
                if text:
                    yield {"type": "text_delta", "text": text}

            # Final result
            elif event_type == "result":
                result_text = event.get("result", "")
                cost = event.get("total_cost_usd")
                duration = event.get("duration_ms")
                logger.debug("Result received (cost=$%s, %sms): %.200s", cost, duration, result_text)

                # Prefer usage from result event, fall back to last assistant event
                result_usage = event.get("usage")
                if not result_usage:
                    logger.debug(
                        "Result event missing usage; falling back to assistant event usage (cache tokens may be lost)"
                    )
                    result_usage = self._last_usage

                # modelUsage is keyed by model name, e.g. {"claude-sonnet-4-6": {"contextWindow": 200000}}
                context_window = None
                for model_data in (event.get("modelUsage") or {}).values():
                    context_window = model_data.get("contextWindow")
                    if context_window:
                        break

                yield {
                    "type": "result",
                    "text": result_text,
                    "cost_usd": cost,
                    "duration_ms": duration,
                    "session_id": event.get("session_id", self._session_id),
                    "input_tokens": result_usage.get("input_tokens") or 0,
                    "cache_creation_input_tokens": result_usage.get("cache_creation_input_tokens") or 0,
                    "cache_read_input_tokens": result_usage.get("cache_read_input_tokens") or 0,
                    "output_tokens": result_usage.get("output_tokens") or 0,
                    "context_window": context_window,
                    "is_error": bool(event.get("is_error")),
                    "subtype": event.get("subtype"),
                }
                return

            # Skip: rate_limit_event, system, etc.

    async def stop(self) -> None:
        """Terminate subprocess and clean up temp files."""
        if self._stderr_task:
            self._stderr_task.cancel()
            self._stderr_task = None

        if self._process:
            try:
                self._process.terminate()
                await self._process.wait()
            except ProcessLookupError:
                pass
            self._process = None

        if self._system_prompt_file and os.path.exists(self._system_prompt_file):
            os.unlink(self._system_prompt_file)
            self._system_prompt_file = None
