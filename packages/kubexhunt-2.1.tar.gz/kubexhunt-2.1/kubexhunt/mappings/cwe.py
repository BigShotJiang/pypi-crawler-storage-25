"""CWE mappings."""
