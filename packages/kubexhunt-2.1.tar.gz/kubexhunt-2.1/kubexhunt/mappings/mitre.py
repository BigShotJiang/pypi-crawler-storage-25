"""MITRE mappings."""
