"""Caching helpers."""
