"""Cloud API helpers."""
