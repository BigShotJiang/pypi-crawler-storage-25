"""KubeXHunt package entrypoint."""

__all__ = [
    "__version__",
]

__version__ = "2.1"
