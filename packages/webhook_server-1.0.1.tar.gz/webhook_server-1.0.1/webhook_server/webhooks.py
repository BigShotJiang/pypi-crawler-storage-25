from http import HTTPStatus
from flask.typing import ResponseReturnValue
import requests

from flask import request, jsonify
import logger
from . import app, basic_auth
from .datadog import DatadogAlert, DatadogAlertContent

webhookLogger = logger.get_json_logger(__name__)


@app.route("/")
def ping() -> ResponseReturnValue:
    return jsonify({"status": "ok"}), HTTPStatus.OK


@app.route("/telegram/<chat_id>", methods=["POST"])
@basic_auth.required
def webhookHandler(chat_id) -> ResponseReturnValue:
    try:
        content = request.get_json()
    except requests.exceptions.RequestException:
        webhookLogger.exception("failed to parse request payload")
        return jsonify({"message": "Bad request"}), HTTPStatus.BAD_REQUEST

    try:
        alert = DatadogAlert(DatadogAlertContent(**content))
    except TypeError:
        webhookLogger.exception("failed to build DatadogAlert")
        return jsonify({"message": "Bad request"}), HTTPStatus.BAD_REQUEST

    url = (
        "https://api.telegram.org/bot"
        + app.config.get("TELEGRAM_BOT_API_TOKEN", "")
        + "/sendMessage"
    )

    try:
        payload = {
            "chat_id": chat_id,
            "text": alert.get_message(),
            "parse_mode": "HTML",
        }
        req = requests.post(url=url, data=payload, timeout=5)
        telegram_response = req.json()
        return jsonify(telegram_response)
    except requests.exceptions.RequestException:
        webhookLogger.exception("failed to post to Telegram")
        return jsonify({"message": "Bad request"}), HTTPStatus.BAD_REQUEST
