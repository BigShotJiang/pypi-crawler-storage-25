# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in crawlix, please report it privately by emailing keylordelrey (at) users.noreply.github.com.

Please do not disclose the vulnerability publicly until it has been addressed.

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.x     | Yes       |

## Security Best Practices

- Always validate and sanitize user input when constructing selectors
- Be cautious when using `page.evaluate()` with untrusted JavaScript
- Use `stealth=True` (default) to avoid bot detection
- Use proxies when scraping at scale to avoid IP blocking
