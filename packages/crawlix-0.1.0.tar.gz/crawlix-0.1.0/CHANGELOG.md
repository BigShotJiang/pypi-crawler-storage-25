# Changelog

All notable changes to crawlix will be documented in this file.

## [0.1.0] - 2026-05-17

### Added

- Initial release
- `Browser` class with context manager support and auto-detect backend
- `Page` class with navigation, querying, interaction, and chaining support
- `Element` class with traversal, attributes, and magic methods
- `Backend` ABC with strategy pattern for multiple backends
- `RequestsBackend` — lightweight HTTP scraping via requests + BeautifulSoup4
- `PlaywrightBackend` — full browser automation via Playwright
- `SeleniumBackend` — full browser automation via Selenium
- `HttpxBackend` — async HTTP support via httpx
- `AsyncBrowser` and `AsyncPage` for async workflows
- `aget()` and `afetch()` convenience functions
- Auto-detect backend (playwright > selenium > requests)
- Stealth mode with realistic headers and UA rotation
- BackendError with helpful install hints for browser-only features
- Full type hints (Python 3.10+)
- Comprehensive test suite with mocked responses
