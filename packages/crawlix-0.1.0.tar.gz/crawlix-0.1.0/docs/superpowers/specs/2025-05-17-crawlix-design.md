# Crawlix Design Document

> One API. Any backend. Full browser automation to lightweight scraping.

**Date:** 2025-05-17
**Status:** Approved
**Author:** keylordelrey

---

## 1. Project Overview

Crawlix is a Python browser automation and web scraping library with a unified API across multiple backends. Users write the same code whether they are doing simple HTTP scraping or full Playwright-powered browser automation — switching backends never requires rewriting user code.

### Target Python Version

Python 3.10+ (uses modern union syntax like `str | None`)

### Core Design Principles

1. Same API across all backends — switching backend never requires rewriting user code
2. Auto-detect best available backend — no config needed
3. Zero hard dependencies on optional backends — all optional imports inside functions/methods only
4. Fail with helpful errors — BackendError includes install hints
5. Context manager always — resources always cleaned up properly
6. Stealth on by default — realistic headers, UA rotation, no bot fingerprint
7. All documentation in English

---

## 2. Project Structure

```
crawlix/
├── src/
│   └── crawlix/
│       ├── __init__.py              # Public API re-export
│       ├── _version.py              # Single source of truth — __version__
│       ├── browser.py               # Class Browser (context manager, auto-detect)
│       ├── page.py                  # Class Page (dispatches to backend)
│       ├── element.py               # Class Element (wraps backend element)
│       ├── exceptions.py            # All custom exceptions
│       ├── backends/
│       │   ├── __init__.py          # Re-export, auto-detect logic
│       │   ├── protocol.py          # Backend Protocol (ABC)
│       │   ├── requests.py          # RequestsBackend (core)
│       │   ├── playwright.py        # PlaywrightBackend
│       │   ├── selenium.py          # SeleniumBackend
│       │   └── httpx.py             # HttpxBackend (async)
│       ├── async_api.py             # AsyncBrowser, aget, afetch
│       └── utils.py                 # Stealth helpers, UA rotation
├── tests/
│   ├── __init__.py
│   ├── conftest.py                  # Fixtures + mock backend
│   ├── test_browser.py
│   ├── test_page.py
│   ├── test_element.py
│   ├── test_backends/
│   │   ├── test_requests.py
│   │   ├── test_playwright.py
│   │   └── test_selenium.py
│   └── test_async_api.py
├── docs/
│   ├── superpowers/specs/
│   └── ... (future documentation)
├── pyproject.toml
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── SECURITY.md
├── CHANGELOG.md
└── .gitignore
```

---

## 3. Backend Architecture (Strategy Pattern)

### 3.1 Protocol / Abstract Base

```python
# src/crawlix/backends/protocol.py
class Backend(ABC):
    @property
    def name(self) -> str: ...
    @property
    def supports_js(self) -> bool: ...

    def open(self, url: str) -> PageData: ...
    def new_page(self) -> PageData: ...
    def close(self) -> None: ...

    # HTTP-level
    def set_headers(self, headers: dict) -> None: ...
    def set_cookies(self, cookies: list[dict]) -> None: ...
    def get_cookies(self) -> list[dict]: ...

    # Navigation
    def goto(self, url: str) -> None: ...
    def reload(self) -> None: ...
    def back(self) -> None: ...
    def forward(self) -> None: ...

    # Querying
    def find(self, selector: str) -> ElementData | None: ...
    def find_all(self, selector: str) -> list[ElementData]: ...

    # Interaction (browser backends only)
    def click(self, selector: str) -> None: ...
    def type(self, selector: str, text: str) -> None: ...
    def submit(self, selector: str) -> None: ...
    # ... etc

    # Waiting (browser backends only)
    def wait_for(self, selector: str, timeout: int) -> None: ...
    def wait_for_load(self, timeout: int) -> None: ...

    # JavaScript (browser backends only)
    def evaluate(self, js_code: str) -> Any: ...

    # Output
    def screenshot(self, path: str | None) -> bytes: ...
```

`PageData` and `ElementData` are lightweight dataclasses returned by the backend — the Page and Element classes in `crawlix/` wrap these into the public API.

### 3.2 Backend Implementations

| Backend | File | Dependencies | supports_js |
|---------|------|-------------|-------------|
| RequestsBackend | `backends/requests.py` | requests, beautifulsoup4 (core) | No |
| PlaywrightBackend | `backends/playwright.py` | playwright (optional) | Yes |
| SeleniumBackend | `backends/selenium.py` | selenium (optional) | Yes |
| HttpxBackend | `backends/httpx.py` | httpx (optional) | No |

### 3.3 Auto-Detect Flow

```
Browser.__init__("auto"):
  1. User passed explicit backend? → Use it
  2. Try playwright → selenium (in order)
  3. If none available → fallback to requests+bs4 (core)
  4. Cache result — detect once, never re-detect
```

### 3.4 Optional Import Rule

All optional dependencies imported inside functions/methods only:

```python
# Correct — inside method, try/except
def screenshot(self, path=None):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise BackendError("screenshot() requires a browser backend...")
```

```python
# WRONG — module level import
from playwright.sync_api import sync_playwright  # NEVER
```

---

## 4. Public API

### 4.1 Browser

```python
class Browser:
    def __init__(
        self,
        backend: str = "auto",
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        locale: str = "en-US",
        user_agent: str | None = None,
    )
    def open(self, url: str) -> Page
    def new_page(self) -> Page
    def close(self) -> None
    @property
    def backend_name(self) -> str
    @property
    def supports_js(self) -> bool
    def __enter__(self) -> Browser
    def __exit__(self, *args) -> None  # Always calls close() even on exception
```

### 4.2 Page

```python
class Page:
    # Navigation (all return self for chaining)
    def goto(self, url: str) -> Page
    def reload(self) -> Page
    def back(self) -> Page
    def forward(self) -> Page

    # Properties
    @property
    def url(self) -> str
    @property
    def title(self) -> str
    @property
    def html(self) -> str
    @property
    def text(self) -> str
    @property
    def status(self) -> int
    @property
    def headers(self) -> dict

    # Querying
    def find(self, selector: str) -> Element | None
    def find_all(self, selector: str) -> list[Element]
    def find_text(self, text: str) -> Element | None
    def xpath(self, expr: str) -> list[Element]

    # Interaction — BackendError on HTTP backends
    def click(self, selector: str) -> Page
    def type(self, selector: str, text: str) -> Page
    def clear(self, selector: str) -> Page
    def submit(self, selector: str = "form") -> Page
    def select(self, selector: str, value: str) -> Page
    def hover(self, selector: str) -> Page
    def focus(self, selector: str) -> Page
    def scroll_to(self, selector: str) -> Page
    def upload(self, selector: str, path: str) -> Page
    def key(self, key: str) -> Page

    # Waiting — BackendError on HTTP backends
    def wait_for(self, selector: str, timeout: int | None = None) -> Page
    def wait_for_text(self, text: str, timeout: int | None = None) -> Page
    def wait_for_load(self, timeout: int | None = None) -> Page
    def sleep(self, seconds: float) -> Page

    # JavaScript — BackendError on HTTP backends
    def evaluate(self, js_code: str) -> Any
    def evaluate_on(self, selector: str, js: str) -> Any

    # Network
    def set_headers(self, headers: dict) -> Page
    def set_cookies(self, cookies: list[dict]) -> Page
    def get_cookies(self) -> list[dict]
    def clear_cookies(self) -> Page

    # Extraction helpers
    def links(self) -> list[str]
    def images(self) -> list[str]
    def tables(self) -> list[list[list[str]]]
    def json(self) -> dict

    # Output — screenshot/pdf require browser backend
    def screenshot(self, path: str | None = None) -> bytes
    def save(self, path: str) -> Page
```

### 4.3 Element

```python
class Element:
    @property
    def text(self) -> str
    @property
    def html(self) -> str
    @property
    def outer_html(self) -> str
    @property
    def tag(self) -> str
    @property
    def classes(self) -> list[str]
    def attr(self, name: str, default: str = "") -> str
    @property
    def attrs(self) -> dict
    def has_attr(self, name: str) -> bool

    # Traversal
    def find(self, selector: str) -> Element | None
    def find_all(self, selector: str) -> list[Element]
    def parent(self) -> Element | None
    def children(self) -> list[Element]
    def siblings(self) -> list[Element]

    # Interaction — BackendError on HTTP backends
    def click(self) -> Element
    def type(self, text: str) -> Element
    def clear(self) -> Element
    def hover(self) -> Element
    def focus(self) -> Element
    def is_visible(self) -> bool
    def screenshot(self, path: str | None = None) -> bytes

    # Magic
    def __bool__(self) -> Literal[True]  # Always True
    def __str__(self) -> str
    def __repr__(self) -> str
```

### 4.4 Convenience Functions

```python
def get(url: str, **kwargs) -> Page      # Auto backend
def fetch(url: str, **kwargs) -> str      # Returns HTML string
def browse(url: str, **kwargs) -> Page    # Forces browser backend
```

### 4.5 Async API

```python
# src/crawlix/async_api.py
class AsyncBrowser:
    async def open(self, url: str) -> AsyncPage: ...
    async def close(self): ...

class AsyncPage:
    async def find(self, selector) -> AsyncElement | None: ...
    async def click(self, selector) -> AsyncPage: ...
    # ... mirror of Page but async

async def aget(url: str) -> AsyncPage: ...
async def afetch(url: str) -> str: ...
```

---

## 5. Exception Hierarchy

```
CrawlixError (Base)
├── BackendError       — Backend unavailable or operation not supported
├── TimeoutError       — Wait exceeded timeout
├── NavigationError    — Page failed to load
├── SelectorError      — Invalid selector or element not found
├── NetworkError       — Connection error
└── JavaScriptError    — JS evaluation failed
```

`BackendError` always includes install hint:
```
BackendError: screenshot() requires a browser backend.
Install one:
  pip install crawlix[playwright]   ← recommended
  pip install crawlix[selenium]
```

---

## 6. Dependencies

### Required (core — `pip install crawlix`)
- `requests>=2.28`
- `beautifulsoup4>=4.12`

### Optional Extras
| Extra | Package |
|-------|---------|
| `[playwright]` | playwright>=1.40 |
| `[selenium]` | selenium>=4.15 |
| `[full]` | playwright, selenium |

### Dev Dependencies
- pytest, pytest-mock, pytest-asyncio
- ruff, mypy
- build, twine
- responses (for mocking HTTP)

---

## 7. Testing Strategy

| Layer | Tools | Scope |
|-------|-------|-------|
| Unit | pytest + pytest-mock | Test Browser/Page/Element logic with mocked backends |
| Backend | pytest + responses | Test RequestsBackend with mocked HTTP responses |
| Integration | pytest | Optional — run with real backends (manual) |
| Async | pytest-asyncio | Test async_api.py with mocked HTTP |

- Never hit real URLs in test suite
- Fixtures in conftest.py: mock_backend, mock_page, mock_element
- Coverage target: >90%

---

## 8. Build & CI/CD

- **Build backend:** hatchling
- **Versioning:** Dynamic from `src/crawlix/_version.py`
- **Linting:** ruff
- **Type checking:** mypy
- **Testing:** pytest
- **CI:** GitHub Actions (ci.yml: lint + test on push)
- **Publishing:** GitHub Actions (publish.yml: Trusted Publishing on `git tag v*`)
- **Changelog:** Keep a Changelog format

---

## 9. Stealth & Anti-Detection

Applied by default when `stealth=True`:

- Realistic browser-like headers (Accept, Accept-Language, Sec-Fetch-*)
- User-Agent rotation from a curated list of real browser UAs
- No default `python-requests`/`httpx` User-Agent
- Consistent header ordering
- Viewport and timeout randomization

---

## 10. File-by-File Implementation Order

1. `pyproject.toml` — project config, dependencies, tooling
2. `src/crawlix/_version.py` — version string
3. `src/crawlix/exceptions.py` — exception hierarchy
4. `src/crawlix/backends/protocol.py` — Backend ABC + PageData/ElementData
5. `src/crawlix/backends/requests.py` — RequestsBackend
6. `src/crawlix/utils.py` — stealth helpers, UA rotation
7. `src/crawlix/element.py` — Element class
8. `src/crawlix/page.py` — Page class
9. `src/crawlix/browser.py` — Browser class + auto-detect
10. `src/crawlix/__init__.py` — public API re-exports
11. `src/crawlix/backends/playwright.py` — PlaywrightBackend
12. `src/crawlix/backends/selenium.py` — SeleniumBackend
13. `src/crawlix/async_api.py` — AsyncBrowser + AsyncPage
14. `src/crawlix/backends/httpx.py` — HttpxBackend
15. Tests — conftest.py, test_browser.py, test_page.py, test_element.py, test_backends/
16. `README.md`, `CONTRIBUTING.md`, `SECURITY.md`, `CHANGELOG.md`, `LICENSE`
