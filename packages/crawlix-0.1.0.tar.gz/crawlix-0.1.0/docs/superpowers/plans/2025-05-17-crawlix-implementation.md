# Crawlix Implementation Plan

> **For agentic workers:** Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Build crawlix — a Python browser automation and web scraping library with a unified API across multiple backends.

**Architecture:** Strategy pattern — Backend ABC defines the interface, each backend (Requests, Playwright, Selenium, Httpx) implements it. Browser/Page/Element are public API wrappers that dispatch to the active backend. Auto-detect picks the best available backend at init time.

**Tech Stack:** Python 3.10+, requests+bs4 (core), playwright (optional), selenium (optional), httpx (optional async), hatchling (build), pytest+responses (testing), ruff+mypy (quality)

---

## File Structure

```
src/crawlix/
├── __init__.py              # Public API re-exports
├── _version.py              # __version__ = "0.1.0"
├── browser.py               # Browser class + convenience functions (get, fetch, browse)
├── page.py                  # Page class
├── element.py               # Element class
├── exceptions.py            # CrawlixError hierarchy
├── async_api.py             # AsyncBrowser, AsyncPage, aget, afetch
├── utils.py                 # Stealth helpers, User-Agent rotation
└── backends/
    ├── __init__.py           # Backend registry, auto-detect
    ├── protocol.py           # Backend ABC, PageData, ElementData
    ├── requests.py           # RequestsBackend
    ├── playwright.py         # PlaywrightBackend
    ├── selenium.py           # SeleniumBackend
    └── httpx.py              # HttpxBackend

tests/
├── __init__.py
├── conftest.py               # Fixtures, MockBackend
├── test_browser.py
├── test_page.py
├── test_element.py
├── test_exceptions.py
├── test_async_api.py
└── test_backends/
    ├── __init__.py
    ├── test_requests.py
    ├── test_playwright.py
    └── test_selenium.py

docs/
├── superpowers/
│   ├── specs/
│   │   └── 2025-05-17-crawlix-design.md
│   └── plans/
│       └── 2025-05-17-crawlix-implementation.md

pyproject.toml
README.md
LICENSE
CONTRIBUTING.md
SECURITY.md
CHANGELOG.md
.gitignore
```

---

### Task 1: Project Scaffolding

**Files:**
- Create: `pyproject.toml`
- Create: `src/crawlix/__init__.py`
- Create: `src/crawlix/_version.py`
- Create: `src/crawlix/exceptions.py`
- Create: `.gitignore`
- Create: `tests/__init__.py`
- Create: `src/crawlix/backends/__init__.py`

- [ ] **Step 1: Create pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "crawlix"
dynamic = ["version"]
description = "One API. Any backend. Full browser automation to lightweight scraping."
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.10"
authors = [
    {name = "keylordelrey"},
]
keywords = ["web-scraping", "browser-automation", "playwright", "selenium"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Internet :: WWW/HTTP",
    "Topic :: Software Development :: Libraries :: Python Modules",
]
dependencies = [
    "requests>=2.28",
    "beautifulsoup4>=4.12",
]

[project.optional-dependencies]
playwright = ["playwright>=1.40"]
selenium = ["selenium>=4.15"]
full = ["crawlix[playwright]", "crawlix[selenium]"]

[project.urls]
Homepage = "https://github.com/keylordelrey/crawlix"
Source = "https://github.com/keylordelrey/crawlix"
Issues = "https://github.com/keylordelrey/crawlix/issues"

[tool.hatch.version]
path = "src/crawlix/_version.py"

[tool.hatch.build.targets.wheel]
packages = ["src/crawlix"]

[tool.ruff]
target-version = "py310"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP"]

[tool.ruff.format]
quote-style = "double"

[tool.mypy]
python_version = "3.10"
strict = true
ignore_missing_imports = true

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
asyncio_mode = "auto"

[tool.coverage.run]
source = ["src/crawlix"]
```

- [ ] **Step 2: Create src/crawlix/_version.py**

```python
__version__ = "0.1.0"
```

- [ ] **Step 3: Create src/crawlix/exceptions.py**

```python
class CrawlixError(Exception):
    """Base exception for all crawlix errors."""


class BackendError(CrawlixError):
    """Raised when a backend is unavailable or does not support an operation."""


class TimeoutError(CrawlixError):
    """Raised when a wait operation exceeds the timeout."""


class NavigationError(CrawlixError):
    """Raised when a page fails to load."""


class SelectorError(CrawlixError):
    """Raised when a selector is invalid or no element is found."""


class NetworkError(CrawlixError):
    """Raised on connection errors."""


class JavaScriptError(CrawlixError):
    """Raised when JavaScript evaluation fails."""
```

- [ ] **Step 4: Create src/crawlix/__init__.py (empty for now)**

```python
# crawlix — One API. Any backend.
```

- [ ] **Step 5: Create src/crawlix/backends/__init__.py (empty for now)**

```python
```

- [ ] **Step 6: Create tests/__init__.py (empty)**

```python
```

- [ ] **Step 7: Create .gitignore**

```
__pycache__/
*.py[cod]
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST
.pytest_cache/
.coverage
.coverage.*
htmlcov/
.mypy_cache/
.ruff_cache/
*.log
.env
.venv/
venv/
ENV/
.idea/
.vscode/
*.swp
*.swo
*~
.DS_Store
node_modules/
```

- [ ] **Step 8: Verify scaffold works**

Run: `python -c "import sys; sys.path.insert(0, 'src'); from crawlix._version import __version__; print(__version__)"`
Expected: `0.1.0`

- [ ] **Step 9: Commit**

```bash
git add -A && git commit -m "chore: scaffold crawlix project structure"
```

---

### Task 2: Backend Protocol & Data Classes

**Files:**
- Create: `src/crawlix/backends/protocol.py`

- [ ] **Step 1: Write protocol.py**

```python
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class PageData:
    url: str = ""
    html: str = ""
    text: str = ""
    title: str = ""
    status: int = 200
    headers: dict[str, str] = field(default_factory=dict)
    cookies: list[dict[str, str]] = field(default_factory=list)


@dataclass
class ElementData:
    tag: str = ""
    text: str = ""
    html: str = ""
    outer_html: str = ""
    attributes: dict[str, str] = field(default_factory=dict)
    attrs: dict[str, str] = field(default_factory=dict)
    classes: list[str] = field(default_factory=list)
    element_id: str = ""
    parent_data: ElementData | None = None
    children_data: list[ElementData] = field(default_factory=list)


class Backend(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def supports_js(self) -> bool: ...

    @abstractmethod
    def open(self, url: str) -> PageData: ...

    @abstractmethod
    def close(self) -> None: ...

    # Navigation
    def goto(self, url: str) -> None:
        raise BackendError(f"{self.name} does not support goto()")

    def reload(self) -> None:
        raise BackendError(f"{self.name} does not support reload()")

    def back(self) -> None:
        raise BackendError(f"{self.name} does not support back()")

    def forward(self) -> None:
        raise BackendError(f"{self.name} does not support forward()")

    # Querying
    @abstractmethod
    def find(self, selector: str) -> ElementData | None: ...

    @abstractmethod
    def find_all(self, selector: str) -> list[ElementData]: ...

    def find_text(self, text: str) -> ElementData | None:
        for element in self.find_all("*"):
            if text in (element.text or ""):
                return element
        return None

    def xpath(self, expr: str) -> list[ElementData]:
        raise BackendError(f"{self.name} does not support xpath()")

    # Interaction
    def click(self, selector: str) -> None:
        raise BackendError(self._browser_only("click"))

    def double_click(self, selector: str) -> None:
        raise BackendError(self._browser_only("double_click"))

    def type(self, selector: str, text: str) -> None:
        raise BackendError(self._browser_only("type"))

    def clear(self, selector: str) -> None:
        raise BackendError(self._browser_only("clear"))

    def submit(self, selector: str = "form") -> None:
        raise BackendError(self._browser_only("submit"))

    def select(self, selector: str, value: str) -> None:
        raise BackendError(self._browser_only("select"))

    def hover(self, selector: str) -> None:
        raise BackendError(self._browser_only("hover"))

    def focus(self, selector: str) -> None:
        raise BackendError(self._browser_only("focus"))

    def blur(self, selector: str) -> None:
        raise BackendError(self._browser_only("blur"))

    def scroll_to(self, selector: str) -> None:
        raise BackendError(self._browser_only("scroll_to"))

    def upload(self, selector: str, path: str) -> None:
        raise BackendError(self._browser_only("upload"))

    def key(self, key: str) -> None:
        raise BackendError(self._browser_only("key"))

    # Waiting
    def wait_for(self, selector: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for"))

    def wait_for_text(self, text: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for_text"))

    def wait_for_url(self, pattern: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for_url"))

    def wait_for_load(self, timeout: int = 30) -> None:
        raise BackendError(self._browser_only("wait_for_load"))

    def wait_for_network_idle(self, timeout: int = 30) -> None:
        raise BackendError(self._browser_only("wait_for_network_idle"))

    def sleep(self, seconds: float) -> None:
        raise BackendError(self._browser_only("sleep"))

    # JavaScript
    def evaluate(self, js_code: str) -> Any:
        raise BackendError(self._browser_only("evaluate"))

    def evaluate_on(self, selector: str, js: str) -> Any:
        raise BackendError(self._browser_only("evaluate_on"))

    # Network
    def set_headers(self, headers: dict[str, str]) -> None:
        raise BackendError(f"{self.name} does not support set_headers()")

    def set_cookies(self, cookies: list[dict]) -> None:
        raise BackendError(f"{self.name} does not support set_cookies()")

    def get_cookies(self) -> list[dict]:
        raise BackendError(f"{self.name} does not support get_cookies()")

    def clear_cookies(self) -> None:
        raise BackendError(f"{self.name} does not support clear_cookies()")

    def intercept(self, pattern: str, handler) -> None:
        raise BackendError(self._browser_only("intercept"))

    # Output
    def screenshot(self, path: str | None = None) -> bytes:
        raise BackendError(self._browser_only("screenshot"))

    def pdf(self, path: str | None = None) -> bytes:
        raise BackendError(self._browser_only("pdf"))

    # Helpers
    @staticmethod
    def _browser_only(method: str) -> str:
        return (
            f"{method}() requires a browser backend.\n"
            "Install one:\n"
            "  pip install crawlix[playwright]   -- recommended\n"
            "  pip install crawlix[selenium]"
        )
```

- [ ] **Step 2: Verify it imports cleanly**

Run: `python -c "import sys; sys.path.insert(0, 'src'); from crawlix.backends.protocol import Backend, PageData, ElementData; print('OK')"`
Expected: `OK`

- [ ] **Step 3: Commit**

```bash
git add -A && git commit -m "feat: add backend protocol with ABC and data classes"
```

---

### Task 3: Utils — Stealth Helpers & UA Rotation

**Files:**
- Create: `src/crawlix/utils.py`

- [ ] **Step 1: Write utils.py**

```python
from __future__ import annotations

import random
from typing import Literal


_USER_AGENTS: list[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
]


def random_user_agent() -> str:
    return random.choice(_USER_AGENTS)


_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
_ACCEPT_LANGUAGE = "en-US,en;q=0.9"


def stealth_headers(user_agent: str | None = None, locale: str = "en-US") -> dict[str, str]:
    ua = user_agent or random_user_agent()
    return {
        "User-Agent": ua,
        "Accept": _ACCEPT,
        "Accept-Language": f"{locale},{locale.split('-')[0]};q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control": "max-age=0",
    }
```

- [ ] **Step 2: Write quick test**

```python
# Run inline
from crawlix.utils import random_user_agent, stealth_headers
ua = random_user_agent()
assert isinstance(ua, str) and ua.startswith("Mozilla")
headers = stealth_headers()
assert headers["User-Agent"] in ua or "Chrome" in headers["User-Agent"]
print("utils OK")
```

- [ ] **Step 3: Commit**

```bash
git add -A && git commit -m "feat: add stealth helpers and UA rotation"
```

---

### Task 4: Element Class

**Files:**
- Create: `src/crawlix/element.py`
- Create: `tests/test_element.py`

- [ ] **Step 1: Write test_element.py**

```python
from __future__ import annotations

import pytest
from crawlix.element import Element
from crawlix.backends.protocol import ElementData


def make_element(**kwargs) -> Element:
    data = ElementData(
        tag=kwargs.get("tag", "div"),
        text=kwargs.get("text", "hello world"),
        html=kwargs.get("html", "hello world"),
        outer_html=kwargs.get("outer_html", '<div class="foo">hello world</div>'),
        attributes=kwargs.get("attributes", {"class": "foo", "id": "bar"}),
        classes=kwargs.get("classes", ["foo"]),
        element_id=kwargs.get("element_id", "bar"),
    )
    return Element(data)


class TestElementProperties:
    def test_text(self):
        el = make_element(text="hello")
        assert el.text == "hello"

    def test_html(self):
        el = make_element(html="<span>hi</span>")
        assert el.html == "<span>hi</span>"

    def test_outer_html(self):
        el = make_element(outer_html='<div>hi</div>')
        assert el.outer_html == '<div>hi</div>'

    def test_tag(self):
        el = make_element(tag="span")
        assert el.tag == "span"

    def test_element_id(self):
        el = make_element(element_id="myid")
        assert el.id == "myid"

    def test_classes(self):
        el = make_element(classes=["a", "b"])
        assert el.classes == ["a", "b"]


class TestElementAttributes:
    def test_attr_exists(self):
        el = make_element()
        assert el.attr("class") == "foo"

    def test_attr_missing(self):
        el = make_element()
        assert el.attr("data-x", default="fallback") == "fallback"

    def test_attrs_dict(self):
        el = make_element()
        assert el.attrs == {"class": "foo", "id": "bar"}

    def test_has_attr_true(self):
        el = make_element()
        assert el.has_attr("class") is True

    def test_has_attr_false(self):
        el = make_element()
        assert el.has_attr("nonexistent") is False


class TestElementBool:
    def test_bool_is_always_true(self):
        el = make_element()
        assert bool(el) is True


class TestElementStr:
    def test_str_returns_text(self):
        el = make_element(text="hello")
        assert str(el) == "hello"

    def test_repr(self):
        el = make_element(tag="div", element_id="bar")
        assert "Element" in repr(el)
        assert "div" in repr(el)


class TestElementTraversal:
    def test_find_returns_none_for_no_backend(self):
        el = make_element()
        assert el.find(".anything") is None

    def test_find_all_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.find_all(".anything") == []

    def test_parent_returns_none_for_no_backend(self):
        el = make_element()
        assert el.parent() is None

    def test_children_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.children() == []

    def test_siblings_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.siblings() == []

    def test_next_returns_none_for_no_backend(self):
        el = make_element()
        assert el.next() is None

    def test_prev_returns_none_for_no_backend(self):
        el = make_element()
        assert el.prev() is None


class TestElementInteractionRaises:
    def test_click_raises_backend_error(self):
        el = make_element()
        with pytest.raises(Exception):
            el.click()

    def test_type_raises_backend_error(self):
        el = make_element()
        with pytest.raises(Exception):
            el.type("text")

    def test_clear_raises_backend_error(self):
        el = make_element()
        with pytest.raises(Exception):
            el.clear()

    def test_hover_raises_backend_error(self):
        el = make_element()
        with pytest.raises(Exception):
            el.hover()

    def test_is_visible_raises_backend_error(self):
        el = make_element()
        with pytest.raises(Exception):
            el.is_visible()
```

- [ ] **Step 2: Write element.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import ElementData


class Element:
    def __init__(self, data: ElementData, backend=None):
        self._data = data
        self._backend = backend

    @property
    def text(self) -> str:
        return self._data.text or ""

    @property
    def html(self) -> str:
        return self._data.html or ""

    @property
    def outer_html(self) -> str:
        return self._data.outer_html or ""

    @property
    def tag(self) -> str:
        return self._data.tag or ""

    @property
    def id(self) -> str:
        return self._data.element_id or ""

    @property
    def classes(self) -> list[str]:
        return list(self._data.classes) if self._data.classes else []

    def attr(self, name: str, default: str = "") -> str:
        attrs = self._data.attributes or {}
        return attrs.get(name, default)

    @property
    def attrs(self) -> dict[str, str]:
        return dict(self._data.attributes) if self._data.attributes else {}

    def has_attr(self, name: str) -> bool:
        attrs = self._data.attributes or {}
        return name in attrs

    # Traversal
    def find(self, selector: str) -> Element | None:
        if self._backend is None:
            return None
        result = self._backend.find(selector)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def find_all(self, selector: str) -> list[Element]:
        if self._backend is None:
            return []
        return [Element(d, backend=self._backend) for d in self._backend.find_all(selector)]

    def parent(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        return Element(self._data.parent_data, backend=self._backend)

    def children(self) -> list[Element]:
        if not self._data.children_data:
            return []
        return [Element(d, backend=self._backend) for d in self._data.children_data]

    def siblings(self) -> list[Element]:
        if self._data.parent_data is None or not self._data.parent_data.children_data:
            return []
        return [
            Element(d, backend=self._backend)
            for d in self._data.parent_data.children_data
            if d is not self._data
        ]

    def next(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        siblings = self._data.parent_data.children_data or []
        idx = next((i for i, d in enumerate(siblings) if d is self._data), -1)
        if idx < 0 or idx + 1 >= len(siblings):
            return None
        return Element(siblings[idx + 1], backend=self._backend)

    def prev(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        siblings = self._data.parent_data.children_data or []
        idx = next((i for i, d in enumerate(siblings) if d is self._data), -1)
        if idx < 1:
            return None
        return Element(siblings[idx - 1], backend=self._backend)

    # Interaction
    def click(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.click("")
        return self

    def type(self, text: str) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.type("", text)
        return self

    def clear(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.clear("")
        return self

    def hover(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.hover("")
        return self

    def focus(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.focus("")
        return self

    def scroll_into_view(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.scroll_to("")
        return self

    def is_visible(self) -> bool:
        raise NotImplementedError("is_visible requires a browser backend")

    def is_enabled(self) -> bool:
        raise NotImplementedError("is_enabled requires a browser backend")

    def is_checked(self) -> bool:
        raise NotImplementedError("is_checked requires a browser backend")

    def bounding_box(self) -> dict:
        raise NotImplementedError("bounding_box requires a browser backend")

    def screenshot(self, path: str | None = None) -> bytes:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        return self._backend.screenshot(path)

    # Magic
    def __bool__(self) -> bool:
        return True

    def __str__(self) -> str:
        return self.text

    def __repr__(self) -> str:
        cls = self.__class__.__name__
        tag = self.tag
        classes = " ".join(self.classes)
        el_id = self.id
        parts = [f"<{tag}"]
        if classes:
            parts.append(f".{classes}")
        if el_id:
            parts.append(f"#{el_id}")
        return f"{cls}({''.join(parts)})"
```

- [ ] **Step 3: Run element tests**

Run: `python -m pytest tests/test_element.py -v`
Expected: All tests pass

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "feat: add Element class with traversal and magic methods"
```

---

### Task 5: Page Class

**Files:**
- Create: `src/crawlix/page.py`
- Create: `tests/test_page.py`

- [ ] **Step 1: Write test_page.py**

```python
from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from crawlix.page import Page
from crawlix.backends.protocol import PageData, ElementData


@pytest.fixture
def mock_backend():
    backend = MagicMock()
    backend.name = "mock"
    backend.supports_js = True
    backend.open.return_value = PageData(
        url="https://example.com",
        html="<html><body><h1>Hello</h1></body></html>",
        text="Hello",
        title="Test Page",
        status=200,
        headers={"content-type": "text/html"},
    )
    backend.find.return_value = ElementData(tag="h1", text="Hello", html="<h1>Hello</h1>")
    backend.find_all.return_value = [
        ElementData(tag="a", text="Link 1"),
        ElementData(tag="a", text="Link 2"),
    ]
    backend.screenshot.return_value = b"image_data"
    return backend


@pytest.fixture
def page(mock_backend):
    return Page(mock_backend, PageData(url="https://example.com"))


class TestPageProperties:
    def test_url(self, page):
        assert page.url == "https://example.com"

    def test_title(self, page):
        assert page.title == "Test Page"

    def test_html(self, page):
        assert "Hello" in page.html

    def test_text(self, page):
        assert page.text == "Hello"

    def test_status(self, page):
        assert page.status == 200

    def test_headers(self, page):
        assert page.headers["content-type"] == "text/html"


class TestPageQuerying:
    def test_find_returns_element(self, page):
        el = page.find("h1")
        assert el is not None
        assert el.text == "Hello"

    def test_find_returns_none(self, page):
        el = page.find(".nonexistent")
        assert el is None

    def test_find_all_returns_list(self, page):
        els = page.find_all("a")
        assert len(els) == 2
        assert els[0].text == "Link 1"

    def test_find_all_empty(self, page):
        els = page.find_all(".nonexistent")
        assert els == []


class TestPageScreenshot:
    def test_screenshot_returns_bytes(self, page):
        data = page.screenshot()
        assert data == b"image_data"


class TestPageChaining:
    def test_goto_returns_page(self, page):
        result = page.goto("https://other.com")
        assert result is page

    def test_reload_returns_page(self, page):
        result = page.reload()
        assert result is page
```

- [ ] **Step 2: Write page.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.element import Element
from crawlix.backends.protocol import PageData, ElementData


class Page:
    def __init__(self, backend, data: PageData | None = None):
        self._backend = backend
        self._data = data or PageData()

    # Navigation
    def goto(self, url: str) -> Page:
        self._backend.goto(url)
        self._data = self._backend.open(url)
        return self

    def reload(self) -> Page:
        self._backend.reload()
        return self

    def back(self) -> Page:
        self._backend.back()
        return self

    def forward(self) -> Page:
        self._backend.forward()
        return self

    # Properties
    @property
    def url(self) -> str:
        return self._data.url

    @property
    def title(self) -> str:
        return self._data.title

    @property
    def html(self) -> str:
        return self._data.html

    @property
    def text(self) -> str:
        return self._data.text

    @property
    def status(self) -> int:
        return self._data.status

    @property
    def headers(self) -> dict[str, str]:
        return dict(self._data.headers)

    # Querying
    def find(self, selector: str) -> Element | None:
        result = self._backend.find(selector)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def find_all(self, selector: str) -> list[Element]:
        return [Element(d, backend=self._backend) for d in self._backend.find_all(selector)]

    def find_text(self, text: str) -> Element | None:
        result = self._backend.find_text(text)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def xpath(self, expr: str) -> list[Element]:
        return [Element(d, backend=self._backend) for d in self._backend.xpath(expr)]

    # Interaction
    def click(self, selector: str) -> Page:
        self._backend.click(selector)
        return self

    def double_click(self, selector: str) -> Page:
        self._backend.double_click(selector)
        return self

    def right_click(self, selector: str) -> Page:
        self._backend.right_click(selector)
        return self

    def type(self, selector: str, text: str) -> Page:
        self._backend.type(selector, text)
        return self

    def clear(self, selector: str) -> Page:
        self._backend.clear(selector)
        return self

    def submit(self, selector: str = "form") -> Page:
        self._backend.submit(selector)
        return self

    def select(self, selector: str, value: str) -> Page:
        self._backend.select(selector, value)
        return self

    def hover(self, selector: str) -> Page:
        self._backend.hover(selector)
        return self

    def focus(self, selector: str) -> Page:
        self._backend.focus(selector)
        return self

    def blur(self, selector: str) -> Page:
        self._backend.blur(selector)
        return self

    def scroll(self, x: int = 0, y: int = 500) -> Page:
        self._backend.evaluate(f"window.scrollTo({x}, {y})")
        return self

    def scroll_to(self, selector: str) -> Page:
        self._backend.scroll_to(selector)
        return self

    def key(self, key: str) -> Page:
        self._backend.key(key)
        return self

    def upload(self, selector: str, path: str) -> Page:
        self._backend.upload(selector, path)
        return self

    # Waiting
    def wait_for(self, selector: str, timeout: int | None = None) -> Page:
        self._backend.wait_for(selector, timeout or 10)
        return self

    def wait_for_text(self, text: str, timeout: int | None = None) -> Page:
        self._backend.wait_for_text(text, timeout or 10)
        return self

    def wait_for_url(self, pattern: str, timeout: int | None = None) -> Page:
        self._backend.wait_for_url(pattern, timeout or 10)
        return self

    def wait_for_load(self, timeout: int | None = None) -> Page:
        self._backend.wait_for_load(timeout or 30)
        return self

    def wait_for_network_idle(self, timeout: int | None = None) -> Page:
        self._backend.wait_for_network_idle(timeout or 30)
        return self

    def sleep(self, seconds: float) -> Page:
        self._backend.sleep(seconds)
        return self

    # JavaScript
    def evaluate(self, js_code: str) -> Any:
        return self._backend.evaluate(js_code)

    def evaluate_on(self, selector: str, js: str) -> Any:
        return self._backend.evaluate_on(selector, js)

    # Network
    def set_headers(self, headers: dict[str, str]) -> Page:
        self._backend.set_headers(headers)
        return self

    def set_cookies(self, cookies: list[dict]) -> Page:
        self._backend.set_cookies(cookies)
        return self

    def get_cookies(self) -> list[dict]:
        return self._backend.get_cookies()

    def clear_cookies(self) -> Page:
        self._backend.clear_cookies()
        return self

    def intercept(self, pattern: str, handler) -> Page:
        self._backend.intercept(pattern, handler)
        return self

    # Extraction helpers
    def links(self) -> list[str]:
        return [el.attr("href") for el in self.find_all("a[href]") if el.attr("href")]

    def images(self) -> list[str]:
        return [el.attr("src") for el in self.find_all("img[src]") if el.attr("src")]

    def tables(self) -> list[list[list[str]]]:
        result = []
        for table in self.find_all("table"):
            rows = []
            for row in table.find_all("tr"):
                cells = [c.text for c in row.find_all("td,th")]
                rows.append(cells)
            result.append(rows)
        return result

    def json(self) -> dict:
        import json as _json
        return _json.loads(self.text)

    # Output
    def screenshot(self, path: str | None = None) -> bytes:
        return self._backend.screenshot(path)

    def pdf(self, path: str | None = None) -> bytes:
        return self._backend.pdf(path)

    def save(self, path: str) -> Page:
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.html)
        return self
```

- [ ] **Step 3: Run page tests**

Run: `python -m pytest tests/test_page.py -v`
Expected: All tests pass

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "feat: add Page class with navigation, querying, and interaction"
```

---

### Task 6: RequestsBackend (Core)

**Files:**
- Create: `src/crawlix/backends/requests.py`
- Create: `tests/test_backends/__init__.py`
- Create: `tests/test_backends/test_requests.py`

- [ ] **Step 1: Write test_backends/test_requests.py**

```python
from __future__ import annotations

import pytest
import responses

from crawlix.backends.requests import RequestsBackend


@pytest.fixture
def backend():
    return RequestsBackend()


class TestRequestsBackend:
    @responses.activate
    def test_open_returns_page_data(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><h1>Hello</h1></body></html>",
            status=200,
            content_type="text/html",
        )
        data = backend.open("https://example.com")
        assert data.url == "https://example.com"
        assert data.status == 200
        assert "Hello" in data.html
        assert data.title == ""

    @responses.activate
    def test_find_returns_element_data(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><h1 class='title'>Hi</h1></body></html>",
        )
        backend.open("https://example.com")
        el = backend.find("h1")
        assert el is not None
        assert el.tag == "h1"
        assert el.text == "Hi"
        assert el.attributes == {"class": "title"}

    @responses.activate
    def test_find_nonexistent(self, backend):
        responses.get("https://example.com", body="<html></html>")
        backend.open("https://example.com")
        assert backend.find(".nothing") is None

    @responses.activate
    def test_find_all(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><a>1</a><a>2</a><a>3</a></body></html>",
        )
        backend.open("https://example.com")
        els = backend.find_all("a")
        assert len(els) == 3

    def test_name(self, backend):
        assert backend.name == "requests"

    def test_supports_js(self, backend):
        assert backend.supports_js is False

    def test_close_does_not_raise(self, backend):
        backend.close()

    @responses.activate
    def test_links_method(self, backend):
        responses.get(
            "https://example.com",
            body='<html><body><a href="/page1">1</a><a href="/page2">2</a></body></html>',
        )
        backend.open("https://example.com")
        els = backend.find_all("a[href]")
        hrefs = [el.attributes.get("href", "") for el in els if el.attributes.get("href")]
        assert "/page1" in hrefs
        assert "/page2" in hrefs
```

- [ ] **Step 2: Write backends/requests.py**

```python
from __future__ import annotations

from typing import Any
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from crawlix.backends.protocol import Backend, PageData, ElementData
from crawlix.utils import stealth_headers, random_user_agent


class RequestsBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
    ):
        self._headless = headless
        self._stealth = stealth
        self._timeout = timeout
        self._proxy = proxy
        self._user_agent = user_agent
        self._locale = locale
        self._session: requests.Session | None = None
        self._current_url: str = ""
        self._current_soup: BeautifulSoup | None = None
        self._current_text: str = ""
        self._current_html: str = ""
        self._status: int = 0
        self._response_headers: dict[str, str] = {}

    @property
    def name(self) -> str:
        return "requests"

    @property
    def supports_js(self) -> bool:
        return False

    def _get_session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
            if self._stealth:
                self._session.headers.update(stealth_headers(self._user_agent, self._locale))
            if self._proxy:
                self._session.proxies = {"http": self._proxy, "https": self._proxy}
        return self._session

    def open(self, url: str) -> PageData:
        session = self._get_session()
        try:
            resp = session.get(url, timeout=self._timeout)
        except requests.RequestException as e:
            from crawlix.exceptions import NavigationError
            raise NavigationError(f"Failed to load {url}: {e}") from e

        self._current_url = resp.url
        self._status = resp.status_code
        self._response_headers = dict(resp.headers)
        self._current_html = resp.text
        self._current_soup = BeautifulSoup(resp.text, "html.parser")
        self._current_text = self._current_soup.get_text(separator=" ", strip=True)

        return PageData(
            url=resp.url,
            html=resp.text,
            text=self._current_text,
            title=self._parse_title(),
            status=resp.status_code,
            headers=dict(resp.headers),
        )

    def _parse_title(self) -> str:
        if self._current_soup is None:
            return ""
        title_tag = self._current_soup.find("title")
        return title_tag.get_text(strip=True) if title_tag else ""

    def _element_to_data(self, el) -> ElementData:
        if el is None:
            return ElementData()
        return ElementData(
            tag=el.name or "",
            text=el.get_text(strip=True),
            html=str(el.decode_contents()),
            outer_html=str(el),
            attributes=dict(el.attrs) if el.attrs else {},
            attrs=dict(el.attrs) if el.attrs else {},
            classes=el.get("class", []),
            element_id=el.get("id", ""),
            parent_data=self._element_to_data(el.parent) if el.parent and el.parent.name else None,
            children_data=[self._element_to_data(c) for c in el.children if hasattr(c, "name") and c.name],
        )

    def find(self, selector: str) -> ElementData | None:
        if self._current_soup is None:
            return None
        el = self._current_soup.select_one(selector)
        if el is None:
            return None
        return self._element_to_data(el)

    def find_all(self, selector: str) -> list[ElementData]:
        if self._current_soup is None:
            return []
        return [self._element_to_data(el) for el in self._current_soup.select(selector)]

    def set_headers(self, headers: dict[str, str]) -> None:
        session = self._get_session()
        session.headers.update(headers)

    def set_cookies(self, cookies: list[dict]) -> None:
        session = self._get_session()
        for c in cookies:
            session.cookies.set(c.get("name", ""), c.get("value", ""))

    def get_cookies(self) -> list[dict]:
        if self._session is None:
            return []
        return [
            {"name": c.name, "value": c.value, "domain": c.domain, "path": c.path}
            for c in self._session.cookies
        ]

    def clear_cookies(self) -> None:
        if self._session is not None:
            self._session.cookies.clear()

    def close(self) -> None:
        if self._session is not None:
            self._session.close()
            self._session = None
```

- [ ] **Step 3: Run requests backend tests**

Run: `python -m pytest tests/test_backends/test_requests.py -v`
Expected: All tests pass

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "feat: add RequestsBackend with bs4 parsing"
```

---

### Task 7: Browser Class, Auto-Detect, Convenience Functions

**Files:**
- Create: `src/crawlix/browser.py`
- Create: `tests/test_browser.py`
- Modify: `src/crawlix/__init__.py`
- Modify: `src/crawlix/backends/__init__.py`

- [ ] **Step 1: Write backends/__init__.py with auto-detect**

```python
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from crawlix.backends.protocol import Backend


def detect_backend(
    explicit: str | None = None,
    headless: bool = True,
    stealth: bool = True,
    timeout: int = 30,
    proxy: str | None = None,
    user_agent: str | None = None,
    locale: str = "en-US",
) -> Backend:
    if explicit is not None:
        return _create_backend(
            explicit, headless, stealth, timeout, proxy, user_agent, locale
        )

    # Auto-detect: try playwright → selenium → fallback to requests
    for name in ("playwright", "selenium"):
        try:
            return _create_backend(
                name, headless, stealth, timeout, proxy, user_agent, locale
            )
        except ImportError:
            continue

    from crawlix.backends.requests import RequestsBackend
    return RequestsBackend(
        headless=headless,
        stealth=stealth,
        timeout=timeout,
        proxy=proxy,
        user_agent=user_agent,
        locale=locale,
    )


def _create_backend(
    name: str,
    headless: bool = True,
    stealth: bool = True,
    timeout: int = 30,
    proxy: str | None = None,
    user_agent: str | None = None,
    locale: str = "en-US",
) -> Backend:
    if name == "requests":
        from crawlix.backends.requests import RequestsBackend
        return RequestsBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "playwright":
        from crawlix.backends.playwright import PlaywrightBackend
        return PlaywrightBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "selenium":
        from crawlix.backends.selenium import SeleniumBackend
        return SeleniumBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "httpx":
        from crawlix.backends.httpx import HttpxBackend
        return HttpxBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    else:
        from crawlix.exceptions import BackendError
        raise BackendError(
            f"Unknown backend: {name!r}. Available: requests, playwright, selenium, httpx"
        )
```

- [ ] **Step 2: Write tests/test_browser.py**

```python
from __future__ import annotations

import pytest
from unittest.mock import patch, MagicMock

from crawlix.browser import Browser


class TestBrowserInit:
    def test_default_backend_is_requests(self):
        with patch("crawlix.backends.detect_backend") as mock_detect:
            mock_backend = MagicMock()
            mock_backend.name = "requests"
            mock_detect.return_value = mock_backend
            b = Browser()
            assert b.backend_name == "requests"

    def test_explicit_backend(self):
        with patch("crawlix.backends._create_backend") as mock_create:
            mock_backend = MagicMock()
            mock_backend.name = "playwright"
            mock_create.return_value = mock_backend
            b = Browser(backend="playwright")
            assert b.backend_name == "playwright"

    def test_supports_js_false_for_requests(self):
        with patch("crawlix.backends.detect_backend") as mock_detect:
            mock_backend = MagicMock()
            mock_backend.supports_js = False
            mock_detect.return_value = mock_backend
            b = Browser()
            assert b.supports_js is False


class TestBrowserContextManager:
    def test_close_called_on_exit(self):
        mock_backend = MagicMock()
        with patch("crawlix.backends.detect_backend", return_value=mock_backend):
            with Browser() as b:
                assert b.backend_name is not None
            mock_backend.close.assert_called_once()

    def test_close_called_on_exception(self):
        mock_backend = MagicMock()
        with patch("crawlix.backends.detect_backend", return_value=mock_backend):
            with pytest.raises(RuntimeError):
                with Browser() as b:
                    raise RuntimeError("test error")
            mock_backend.close.assert_called_once()


class TestBrowserOpen:
    def test_open_returns_page(self):
        mock_backend = MagicMock()
        mock_backend.name = "requests"
        mock_backend.open.return_value.url = "https://example.com"
        with patch("crawlix.backends.detect_backend", return_value=mock_backend):
            b = Browser()
            page = b.open("https://example.com")
            assert page.url == "https://example.com"

    def test_cached_backend(self):
        mock_backend = MagicMock()
        mock_backend.name = "requests"
        with patch("crawlix.backends.detect_backend", return_value=mock_backend) as mock_detect:
            b = Browser()
            b.open("https://a.com")
            b.open("https://b.com")
            mock_detect.assert_called_once()
```

- [ ] **Step 3: Write browser.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.page import Page
from crawlix.backends import detect_backend
from crawlix.backends.protocol import Backend


class Browser:
    def __init__(
        self,
        backend: str = "auto",
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        locale: str = "en-US",
        user_agent: str | None = None,
    ):
        explicit = None if backend == "auto" else backend
        self._backend: Backend = detect_backend(
            explicit=explicit,
            headless=headless,
            stealth=stealth,
            timeout=timeout,
            proxy=proxy,
            user_agent=user_agent,
            locale=locale,
        )

    @property
    def backend_name(self) -> str:
        return self._backend.name

    @property
    def supports_js(self) -> bool:
        return self._backend.supports_js

    def open(self, url: str) -> Page:
        data = self._backend.open(url)
        return Page(self._backend, data)

    def new_page(self) -> Page:
        data = self._backend.new_page()
        return Page(self._backend, data)

    def close(self) -> None:
        self._backend.close()

    def __enter__(self) -> Browser:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def get(url: str, **kwargs: Any) -> Page:
    with Browser(**kwargs) as b:
        return b.open(url)


def fetch(url: str, **kwargs: Any) -> str:
    with Browser(**kwargs) as b:
        return b.open(url).html


def browse(url: str, **kwargs: Any) -> Page:
    kwargs.setdefault("backend", "playwright")
    with Browser(**kwargs) as b:
        return b.open(url)
```

- [ ] **Step 4: Update __init__.py**

```python
from crawlix.browser import Browser, get, fetch, browse
from crawlix.page import Page
from crawlix.element import Element
from crawlix.exceptions import (
    CrawlixError,
    BackendError,
    TimeoutError,
    NavigationError,
    SelectorError,
    NetworkError,
    JavaScriptError,
)

__all__ = [
    "Browser",
    "Page",
    "Element",
    "get",
    "fetch",
    "browse",
    "CrawlixError",
    "BackendError",
    "TimeoutError",
    "NavigationError",
    "SelectorError",
    "NetworkError",
    "JavaScriptError",
]
```

- [ ] **Step 5: Run browser tests**

Run: `python -m pytest tests/test_browser.py -v`
Expected: All tests pass

- [ ] **Step 6: Verify convenience functions work**

Run: `python -c "import sys; sys.path.insert(0, 'src'); from crawlix import get, fetch, browse; print('OK')"`
Expected: `OK`

- [ ] **Step 7: Commit**

```bash
git add -A && git commit -m "feat: add Browser class, auto-detect, and convenience functions"
```

---

### Task 8: PlaywrightBackend

**Files:**
- Create: `src/crawlix/backends/playwright.py`
- Create: `tests/test_backends/test_playwright.py`

- [ ] **Step 1: Write test_backends/test_playwright.py**

```python
from __future__ import annotations

import pytest
from crawlix.exceptions import BackendError


class TestPlaywrightBackendInit:
    def test_import_error_if_not_installed(self):
        with pytest.raises(ImportError):
            import playwright  # noqa: F401


class TestPlaywrightBackend:
    def test_backend_name(self):
        pytest.importorskip("playwright")
        from crawlix.backends.playwright import PlaywrightBackend
        backend = PlaywrightBackend(headless=True)
        assert backend.name == "playwright"
        assert backend.supports_js is True
        backend.close()
```

- [ ] **Step 2: Write backends/playwright.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, PageData, ElementData
from crawlix.utils import random_user_agent


class PlaywrightBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as e:
            raise ImportError(
                "playwright is not installed.\n"
                "Install: pip install crawlix[playwright]"
            ) from e

        self._headless = headless
        self._stealth = stealth
        self._timeout = timeout * 1000
        self._proxy = proxy
        self._user_agent = user_agent or random_user_agent()
        self._locale = locale
        self._playwright = None
        self._browser = None
        self._context = None
        self._page = None

        self._playwright = sync_playwright().start()
        launch_kwargs: dict[str, Any] = {"headless": headless}
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}
        self._browser = self._playwright.chromium.launch(**launch_kwargs)

        context_kwargs: dict[str, Any] = {
            "user_agent": self._user_agent,
            "locale": locale,
        }
        if stealth:
            context_kwargs.update(self._stealth_context())
        self._context = self._browser.new_context(**context_kwargs)
        self._page = self._context.new_page()

    @staticmethod
    def _stealth_context() -> dict:
        return {
            "viewport": {"width": 1920, "height": 1080},
            "screen": {"width": 1920, "height": 1080},
        }

    @property
    def name(self) -> str:
        return "playwright"

    @property
    def supports_js(self) -> bool:
        return True

    def open(self, url: str) -> PageData:
        self._page.goto(url, timeout=self._timeout)
        return self._to_page_data()

    def new_page(self) -> PageData:
        self._page = self._context.new_page()
        return PageData(url="about:blank")

    def close(self) -> None:
        try:
            if self._playwright:
                self._playwright.stop()
        except Exception:
            pass

    def _to_page_data(self) -> PageData:
        return PageData(
            url=self._page.url,
            html=self._page.content(),
            text=self._page.inner_text("body") if self._page.query_selector("body") else "",
            title=self._page.title(),
            status=200,
        )

    def goto(self, url: str) -> None:
        self._page.goto(url, timeout=self._timeout)

    def reload(self) -> None:
        self._page.reload()

    def back(self) -> None:
        self._page.go_back()

    def forward(self) -> None:
        self._page.go_forward()

    def find(self, selector: str) -> ElementData | None:
        el = self._page.query_selector(selector)
        if el is None:
            return None
        return self._element_to_data(el)

    def find_all(self, selector: str) -> list[ElementData]:
        els = self._page.query_selector_all(selector)
        return [self._element_to_data(el) for el in els]

    def _element_to_data(self, el) -> ElementData:
        try:
            tag = el.evaluate("el => el.tagName.toLowerCase()")
        except Exception:
            tag = ""
        return ElementData(
            tag=tag,
            text=el.inner_text() if el else "",
            html=el.inner_html() if el else "",
            outer_html=el.evaluate("el => el.outerHTML") if el else "",
            attributes=el.evaluate("el => { const a = {}; for (const attr of el.attributes) a[attr.name] = attr.value; return a; }") if el else {},
            attrs=el.evaluate("el => { const a = {}; for (const attr of el.attributes) a[attr.name] = attr.value; return a; }") if el else {},
            classes=el.evaluate("el => [...el.classList]") if el else [],
            element_id=el.evaluate("el => el.id") if el else "",
        )

    def click(self, selector: str) -> None:
        self._page.click(selector)

    def double_click(self, selector: str) -> None:
        self._page.dblclick(selector)

    def type(self, selector: str, text: str) -> None:
        self._page.fill(selector, text)

    def clear(self, selector: str) -> None:
        self._page.fill(selector, "")

    def submit(self, selector: str = "form") -> None:
        el = self._page.query_selector(selector)
        if el:
            el.evaluate("el => el.submit()")

    def select(self, selector: str, value: str) -> None:
        self._page.select_option(selector, value)

    def hover(self, selector: str) -> None:
        self._page.hover(selector)

    def focus(self, selector: str) -> None:
        self._page.focus(selector)

    def wait_for(self, selector: str, timeout: int = 10) -> None:
        self._page.wait_for_selector(selector, timeout=timeout * 1000)

    def wait_for_text(self, text: str, timeout: int = 10) -> None:
        self._page.wait_for_function(
            f'document.body.innerText.includes("{text}")',
            timeout=timeout * 1000,
        )

    def wait_for_load(self, timeout: int = 30) -> None:
        self._page.wait_for_load_state("load", timeout=timeout * 1000)

    def evaluate(self, js_code: str) -> Any:
        return self._page.evaluate(js_code)

    def evaluate_on(self, selector: str, js: str) -> Any:
        return self._page.evaluate(f"document.querySelector('{selector}')?.{js}")

    def screenshot(self, path: str | None = None) -> bytes:
        return self._page.screenshot(path=path)

    def set_headers(self, headers: dict[str, str]) -> None:
        self._context.set_extra_http_headers(headers)

    def get_cookies(self) -> list[dict]:
        cookies = self._context.cookies()
        return [{"name": c["name"], "value": c["value"], "domain": c.get("domain", ""), "path": c.get("path", "")} for c in cookies]
```

- [ ] **Step 3: Verify PlaywrightBackend imports (may skip if not installed)**

Run: `python -c "import sys; sys.path.insert(0, 'src'); from crawlix.backends.playwright import PlaywrightBackend; print('OK')" 2>&1 || echo "Playwright not installed — skipping"`
Note: Will show Playwright import error if not installed — this is expected behavior

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "feat: add PlaywrightBackend with full browser automation"
```

---

### Task 9: SeleniumBackend

**Files:**
- Create: `src/crawlix/backends/selenium.py`
- Create: `tests/test_backends/test_selenium.py`

- [ ] **Step 1: Write test_backends/test_selenium.py**

```python
from __future__ import annotations

import pytest


class TestSeleniumBackend:
    def test_backend_name(self):
        pytest.importorskip("selenium")
        from crawlix.backends.selenium import SeleniumBackend
        backend = SeleniumBackend(headless=True)
        assert backend.name == "selenium"
        assert backend.supports_js is True
        backend.close()
```

- [ ] **Step 2: Write backends/selenium.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, PageData, ElementData
from crawlix.utils import random_user_agent


class SeleniumBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            from selenium.webdriver.chrome.service import Service
        except ImportError as e:
            raise ImportError(
                "selenium is not installed.\n"
                "Install: pip install crawlix[selenium]"
            ) from e

        self._timeout = timeout
        self._user_agent = user_agent or random_user_agent()

        options = Options()
        if headless:
            options.add_argument("--headless=new")
        options.add_argument(f"--user-agent={self._user_agent}")
        options.add_argument(f"--lang={locale}")
        if proxy:
            options.add_argument(f"--proxy-server={proxy}")

        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-blink-features=AutomationControlled")

        self._driver = webdriver.Chrome(options=options)
        self._driver.implicitly_wait(timeout)
        self._driver.set_page_load_timeout(timeout)

    @property
    def name(self) -> str:
        return "selenium"

    @property
    def supports_js(self) -> bool:
        return True

    def open(self, url: str) -> PageData:
        self._driver.get(url)
        return self._to_page_data()

    def _to_page_data(self) -> PageData:
        from selenium.common.exceptions import NoSuchElementException
        try:
            title_el = self._driver.find_element("tag name", "title")
            title = title_el.get_attribute("textContent") or ""
        except Exception:
            title = ""
        return PageData(
            url=self._driver.current_url,
            html=self._driver.page_source,
            text=self._driver.find_element("tag name", "body").text if self._driver.find_elements("tag name", "body") else "",
            title=title,
        )

    def close(self) -> None:
        try:
            self._driver.quit()
        except Exception:
            pass

    def goto(self, url: str) -> None:
        self._driver.get(url)

    def find(self, selector: str) -> ElementData | None:
        from selenium.webdriver.common.by import By
        try:
            el = self._driver.find_element(By.CSS_SELECTOR, selector)
            return self._element_to_data(el)
        except Exception:
            return None

    def find_all(self, selector: str) -> list[ElementData]:
        from selenium.webdriver.common.by import By
        els = self._driver.find_elements(By.CSS_SELECTOR, selector)
        return [self._element_to_data(el) for el in els]

    def _element_to_data(self, el) -> ElementData:
        from selenium.webdriver.remote.webelement import WebElement
        if not isinstance(el, WebElement):
            return ElementData()
        try:
            tag = el.tag_name
        except Exception:
            tag = ""
        return ElementData(
            tag=tag,
            text=el.text,
            html=el.get_attribute("innerHTML") or "",
            outer_html=el.get_attribute("outerHTML") or "",
            attributes=el.get_property("attributes") or {},
            attrs={},
            classes=el.get_attribute("class").split() if el.get_attribute("class") else [],
            element_id=el.get_attribute("id") or "",
        )

    def click(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).click()

    def type(self, selector: str, text: str) -> None:
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        el.clear()
        el.send_keys(text)

    def clear(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).clear()

    def evaluate(self, js_code: str) -> Any:
        return self._driver.execute_script(js_code)

    def screenshot(self, path: str | None = None) -> bytes:
        return self._driver.get_screenshot_as_png()
```

- [ ] **Step 3: Verify SeleniumBackend imports**

Run: `python -c "import sys; sys.path.insert(0, 'src'); from crawlix.backends.selenium import SeleniumBackend; print('OK')" 2>&1 || echo "Selenium not installed — skipping"`

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "feat: add SeleniumBackend with browser automation"
```

---

### Task 10: HttpxBackend & Async API

**Files:**
- Create: `src/crawlix/backends/httpx.py`
- Create: `src/crawlix/async_api.py`
- Create: `tests/test_async_api.py`

- [ ] **Step 1: Write backends/httpx.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, PageData, ElementData


class HttpxBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        self._timeout = timeout
        self._proxy = proxy
        self._user_agent = user_agent
        self._locale = locale
        self._stealth = stealth
        self._client = None

    async def _get_client(self):
        if self._client is None:
            try:
                import httpx
            except ImportError as e:
                raise ImportError(
                    "httpx is required for async support.\n"
                    "Install: pip install crawlix[async]"
                ) from e

            headers = {}
            if self._stealth:
                from crawlix.utils import stealth_headers
                headers = stealth_headers(self._user_agent, self._locale)

            client_kwargs: dict[str, Any] = {
                "headers": headers,
                "timeout": self._timeout,
            }
            if self._proxy:
                client_kwargs["proxies"] = self._proxy
            self._client = httpx.AsyncClient(**client_kwargs)
        return self._client

    @property
    def name(self) -> str:
        return "httpx"

    @property
    def supports_js(self) -> bool:
        return False

    async def open(self, url: str) -> PageData:
        import httpx
        from bs4 import BeautifulSoup

        client = await self._get_client()
        try:
            resp = await client.get(url)
        except httpx.RequestError as e:
            from crawlix.exceptions import NavigationError
            raise NavigationError(f"Failed to load {url}: {e}") from e

        soup = BeautifulSoup(resp.text, "html.parser")
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""
        text = soup.get_text(separator=" ", strip=True)

        return PageData(
            url=str(resp.url),
            html=resp.text,
            text=text,
            title=title,
            status=resp.status_code,
            headers=dict(resp.headers),
        )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def find(self, selector: str) -> ElementData | None:
        return None  # Not implemented for simple HTTP backend

    async def find_all(self, selector: str) -> list[ElementData]:
        return []
```

- [ ] **Step 2: Write async_api.py**

```python
from __future__ import annotations

from typing import Any

from crawlix.backends import _create_backend
from crawlix.backends.protocol import Backend


class AsyncBrowser:
    def __init__(
        self,
        backend: str = "httpx",
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        locale: str = "en-US",
        user_agent: str | None = None,
    ):
        self._backend: Backend = _create_backend(
            name=backend,
            headless=headless,
            stealth=stealth,
            timeout=timeout,
            proxy=proxy,
            user_agent=user_agent,
            locale=locale,
        )

    @property
    def backend_name(self) -> str:
        return self._backend.name

    async def open(self, url: str) -> AsyncPage:
        data = await self._backend.open(url)
        return AsyncPage(self._backend, data)

    async def close(self) -> None:
        await self._backend.close()

    async def __aenter__(self) -> AsyncBrowser:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()


class AsyncPage:
    def __init__(self, backend, data=None):
        self._backend = backend
        self._data = data

    @property
    def url(self) -> str:
        return self._data.url

    @property
    def html(self) -> str:
        return self._data.html

    @property
    def text(self) -> str:
        return self._data.text

    @property
    def status(self) -> int:
        return self._data.status

    async def find(self, selector: str):
        result = await self._backend.find(selector)
        return result  # No Element wrapper for async yet

    async def json(self) -> dict:
        import json as _json
        return _json.loads(self.text)


async def aget(url: str, **kwargs: Any) -> AsyncPage:
    async with AsyncBrowser(**kwargs) as b:
        return await b.open(url)


async def afetch(url: str, **kwargs: Any) -> str:
    async with AsyncBrowser(**kwargs) as b:
        page = await b.open(url)
        return page.html
```

- [ ] **Step 3: Write tests/test_async_api.py**

```python
from __future__ import annotations

import pytest
from unittest.mock import patch, MagicMock, AsyncMock


@pytest.mark.asyncio
async def test_async_browser_httpx_backend():
    with patch("crawlix.backends.httpx.HttpxBackend") as MockHttpx:
        backend = AsyncMock()
        backend.name = "httpx"
        backend.open.return_value.url = "https://example.com"
        backend.open.return_value.html = "<html>Hello</html>"
        backend.open.return_value.text = "Hello"
        backend.open.return_value.status = 200
        MockHttpx.return_value = backend

        from crawlix.async_api import AsyncBrowser
        async with AsyncBrowser(backend="httpx") as b:
            page = await b.open("https://example.com")
            assert page.url == "https://example.com"
            assert page.status == 200
```

- [ ] **Step 4: Run async tests**

Run: `python -m pytest tests/test_async_api.py -v`
Expected: All tests pass

- [ ] **Step 5: Commit**

```bash
git add -A && git commit -m "feat: add HttpxBackend and async API"
```

---

### Task 11: Tests — Conftest & Remaining Test Coverage

**Files:**
- Create: `tests/conftest.py`
- Modify: `tests/test_page.py` (add more edge cases)
- Modify: `tests/test_element.py` (add more edge cases)

- [ ] **Step 1: Write conftest.py with mock backend fixture**

```python
from __future__ import annotations

from unittest.mock import MagicMock
from typing import Any

import pytest

from crawlix.backends.protocol import PageData, ElementData
from crawlix.page import Page
from crawlix.element import Element


@pytest.fixture
def mock_page_data() -> PageData:
    return PageData(
        url="https://example.com",
        html="<html><body><h1>Hello</h1><p>World</p></body></html>",
        text="Hello World",
        title="Test",
        status=200,
        headers={"content-type": "text/html"},
    )


@pytest.fixture
def mock_element_data() -> ElementData:
    return ElementData(
        tag="h1",
        text="Hello",
        html="Hello",
        outer_html='<h1 class="title">Hello</h1>',
        attributes={"class": "title"},
        attrs={"class": "title"},
        classes=["title"],
        element_id="main-title",
    )


@pytest.fixture
def mock_backend():
    backend = MagicMock()
    backend.name = "mock"
    backend.supports_js = True
    backend.open.return_value = PageData(
        url="https://example.com",
        html="<html><body><h1>Hello</h1></body></html>",
        text="Hello",
        title="Test",
        status=200,
        headers={"content-type": "text/html"},
    )
    backend.find.return_value = ElementData(tag="h1", text="Hello")
    backend.find_all.return_value = []
    backend.screenshot.return_value = b"png_data"
    return backend


@pytest.fixture
def page_with_backend(mock_backend) -> Page:
    return Page(mock_backend, PageData(url="https://example.com"))
```

- [ ] **Step 2: Add more test cases to test_element.py**

Append to existing test file:
```python
class TestElementWithBackend:
    def test_find_with_backend(self):
        backend = MagicMock()
        backend.find.return_value = ElementData(tag="span", text="child")
        el = Element(ElementData(tag="div"), backend=backend)
        child = el.find(".child")
        assert child is not None
        assert child.text == "child"

    def test_click_with_backend(self):
        backend = MagicMock()
        el = Element(ElementData(tag="button"), backend=backend)
        el.click()
        backend.click.assert_called_once()

    def test_type_with_backend(self):
        backend = MagicMock()
        el = Element(ElementData(tag="input"), backend=backend)
        el.type("hello")
        backend.type.assert_called_once_with("", "hello")
```

- [ ] **Step 3: Run all tests**

Run: `python -m pytest tests/ -v`
Expected: All tests pass

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "test: add conftest fixtures and improve test coverage"
```

---

### Task 12: Documentation & Final Polish

**Files:**
- Create: `README.md`
- Create: `LICENSE`
- Create: `CONTRIBUTING.md`
- Create: `SECURITY.md`
- Create: `CHANGELOG.md`
- Modify: `pyproject.toml`

- [ ] **Step 1: Create LICENSE (MIT)**

```text
MIT License

Copyright (c) 2025 keylordelrey

Permission is hereby granted...
```

- [ ] **Step 2: Create README.md** (use the spec from design doc, full English)

```markdown
# crawlix

> One API. Any backend. Full browser automation to lightweight scraping.

...
```

- [ ] **Step 3: Create CONTRIBUTING.md**

```markdown
# Contributing to crawlix

## Development Setup
...
```

- [ ] **Step 4: Create SECURITY.md**

```markdown
# Security Policy

## Reporting a Vulnerability
...
```

- [ ] **Step 5: Create CHANGELOG.md**

```markdown
# Changelog

## [0.1.0] - 2025-05-17
### Added
- Initial release
- Browser, Page, Element classes
- RequestsBackend (core)
- PlaywrightBackend
- SeleniumBackend
- Async API (HttpxBackend)
- Auto-detect backend
- Stealth mode
```

- [ ] **Step 6: Run quality checks**

Run: `python -m ruff check src/` (lint)
Run: `python -m mypy src/ --ignore-missing-imports` (type check)
Run: `python -m pytest tests/ -v --coverage` (coverage)

- [ ] **Step 7: Final commit**

```bash
git add -A && git commit -m "docs: add README, LICENSE, CONTRIBUTING, SECURITY, CHANGELOG"
```

- [ ] **Step 8: Verify package builds**

Run: `python -m build`
Expected: builds dist/crawlix-0.1.0.tar.gz and .whl

---

## Spec Coverage Check

| Spec Requirement | Task |
|-----------------|------|
| Browser with context manager | Task 7 |
| Same API across backends | Tasks 4-10 (Strategy pattern) |
| Auto-detect best backend | Task 7 (backends/__init__.py) |
| Zero hard dependencies at module level | All backends use inline imports |
| BackendError with install hints | Task 2 (protocol.py _browser_only) |
| Page methods return self | Task 5 (page.py — all return self) |
| Browser.__exit__ calls close() | Task 7 (browser.py __exit__) |
| Element.__bool__ returns True | Task 4 (element.py __bool__) |
| Python 3.10+ type hints | All files use `str \| None` |
| Auto-detect runs once | Task 7 (cached in Browser.__init__) |
| Stealth by default | Task 3 (utils.py) + Task 6 (requests.py) |
| All wait methods respect timeout | Task 5 + Task 8 (timeout param) |
| Tests use mocked responses | Task 6 (responses library) |
| hatchling build backend | Task 1 (pyproject.toml) |
| Dynamic version from _version.py | Task 1 (hatch config) |
| exceptions.py with all types | Task 1 (exceptions.py) |
| README with full API reference | Task 12 |
| CONTRIBUTING.md | Task 12 |
| SECURITY.md | Task 12 |
| CHANGELOG.md | Task 12 |
| py.typed (PEP 561) | Task 12 |
