# Contributing to crawlix

Thank you for considering contributing to crawlix! This document outlines the guidelines for contributing.

## Development Setup

```bash
git clone https://github.com/keyreyla/crawlix.git
cd crawlix
python -m venv .venv
source .venv/bin/activate
pip install -e ".[full]"
pip install pytest pytest-mock responses ruff mypy build
```

## Running Tests

```bash
pytest
pytest -v              # verbose
pytest --cov           # coverage
```

## Code Quality

```bash
ruff check src/
mypy src/
```

## Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feat/my-feature`)
3. Commit your changes using conventional commits
4. Ensure all tests pass
5. Open a pull request

## Conventional Commits

- `feat:` — new feature
- `fix:` — bug fix
- `docs:` — documentation
- `test:` — tests
- `refactor:` — code restructuring
- `chore:` — maintenance

## Code Style

- Python 3.10+ type hints
- Ruff for linting and formatting
- Line length: 100
- Quotes: double
