from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from crawlix.element import Element
from crawlix.backends.protocol import ElementData


def make_element(**kwargs) -> Element:
    data = ElementData(
        tag=kwargs.get("tag", "div"),
        text=kwargs.get("text", "hello world"),
        html=kwargs.get("html", "hello world"),
        outer_html=kwargs.get("outer_html", '<div class="foo">hello world</div>'),
        attributes=kwargs.get("attributes", {"class": "foo", "id": "bar"}),
        classes=kwargs.get("classes", ["foo"]),
        element_id=kwargs.get("element_id", "bar"),
    )
    return Element(data)


class TestElementProperties:
    def test_text(self):
        el = make_element(text="hello")
        assert el.text == "hello"

    def test_html(self):
        el = make_element(html="<span>hi</span>")
        assert el.html == "<span>hi</span>"

    def test_outer_html(self):
        el = make_element(outer_html="<div>hi</div>")
        assert el.outer_html == "<div>hi</div>"

    def test_tag(self):
        el = make_element(tag="span")
        assert el.tag == "span"

    def test_id(self):
        el = make_element(element_id="myid")
        assert el.id == "myid"

    def test_classes(self):
        el = make_element(classes=["a", "b"])
        assert el.classes == ["a", "b"]


class TestElementAttributes:
    def test_attr_exists(self):
        el = make_element()
        assert el.attr("class") == "foo"

    def test_attr_missing(self):
        el = make_element()
        assert el.attr("data-x", default="fallback") == "fallback"

    def test_attrs_dict(self):
        el = make_element()
        assert el.attrs == {"class": "foo", "id": "bar"}

    def test_has_attr_true(self):
        el = make_element()
        assert el.has_attr("class") is True

    def test_has_attr_false(self):
        el = make_element()
        assert el.has_attr("nonexistent") is False


class TestElementBool:
    def test_bool_is_always_true(self):
        el = make_element()
        assert bool(el) is True


class TestElementStr:
    def test_str_returns_text(self):
        el = make_element(text="hello")
        assert str(el) == "hello"

    def test_repr(self):
        el = make_element(tag="div", element_id="bar")
        assert "Element" in repr(el)
        assert "div" in repr(el)


class TestElementTraversal:
    def test_find_returns_none_for_no_backend(self):
        el = make_element()
        assert el.find(".anything") is None

    def test_find_all_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.find_all(".anything") == []

    def test_parent_returns_none_for_no_backend(self):
        el = make_element()
        assert el.parent() is None

    def test_children_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.children() == []

    def test_siblings_returns_empty_for_no_backend(self):
        el = make_element()
        assert el.siblings() == []

    def test_next_returns_none_for_no_backend(self):
        el = make_element()
        assert el.next() is None

    def test_prev_returns_none_for_no_backend(self):
        el = make_element()
        assert el.prev() is None


class TestElementWithBackend:
    def test_find_with_backend(self):
        backend = MagicMock()
        backend.find.return_value = ElementData(tag="span", text="child")
        el = Element(ElementData(tag="div"), backend=backend)
        child = el.find(".child")
        assert child is not None
        assert child.text == "child"

    def test_click_with_backend(self):
        backend = MagicMock()
        el = Element(ElementData(tag="button"), backend=backend)
        el.click()
        backend.click.assert_called_once()

    def test_type_with_backend(self):
        backend = MagicMock()
        el = Element(ElementData(tag="input"), backend=backend)
        el.type("hello")
        backend.type.assert_called_once_with("", "hello")
