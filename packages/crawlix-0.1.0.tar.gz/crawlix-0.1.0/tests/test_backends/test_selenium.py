from __future__ import annotations

import pytest

selenium = pytest.importorskip("selenium", reason="selenium not installed")


class TestSeleniumBackendImport:
    def test_import_succeeds(self):
        from crawlix.backends.selenium import SeleniumBackend
        assert SeleniumBackend.__name__ == "SeleniumBackend"
