from __future__ import annotations

import pytest
import responses

from crawlix.backends.requests import RequestsBackend


@pytest.fixture
def backend():
    return RequestsBackend()


class TestRequestsBackend:
    @responses.activate
    def test_open_returns_page_data(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><h1>Hello</h1></body></html>",
            status=200,
            content_type="text/html",
        )
        data = backend.open("https://example.com")
        assert data.url == "https://example.com/"
        assert data.status == 200
        assert "Hello" in data.html

    @responses.activate
    def test_find_returns_element_data(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><h1 class='title'>Hi</h1></body></html>",
        )
        backend.open("https://example.com")
        el = backend.find("h1")
        assert el is not None
        assert el.tag == "h1"
        assert el.text == "Hi"
        assert el.attributes == {"class": ["title"]}

    @responses.activate
    def test_find_nonexistent(self, backend):
        responses.get("https://example.com", body="<html></html>")
        backend.open("https://example.com")
        assert backend.find(".nothing") is None

    @responses.activate
    def test_find_all(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><a>1</a><a>2</a><a>3</a></body></html>",
        )
        backend.open("https://example.com")
        els = backend.find_all("a")
        assert len(els) == 3

    def test_name(self, backend):
        assert backend.name == "requests"

    def test_supports_js(self, backend):
        assert backend.supports_js is False

    def test_close_does_not_raise(self, backend):
        backend.close()

    @responses.activate
    def test_find_text_works(self, backend):
        responses.get(
            "https://example.com",
            body="<html><body><p>target text</p><div>other</div></body></html>",
        )
        backend.open("https://example.com")
        el = backend.find_text("target text")
        assert el is not None
        assert el.tag == "p"

    @responses.activate
    def test_open_navigation_error(self, backend):
        with pytest.raises(Exception):
            backend.open("https://nonexistent.domain.test")
