from __future__ import annotations

from unittest.mock import patch, MagicMock

import pytest

from crawlix.browser import Browser


@pytest.fixture
def mock_backend():
    backend = MagicMock()
    backend.name = "mock"
    backend.supports_js = False
    backend.open.return_value = MagicMock()
    backend.open.return_value.url = "https://example.com"
    backend.open.return_value.html = "<html>Hello</html>"
    backend.open.return_value.text = "Hello"
    backend.open.return_value.title = "Test"
    backend.open.return_value.status = 200
    backend.open.return_value.headers = {}
    return backend


class TestBrowserInit:
    def test_default_backend_is_requests(self, mock_backend):
        with patch("crawlix.browser.detect_backend") as mock_detect:
            mock_detect.return_value = mock_backend
            b = Browser()
            assert b.backend_name == "mock"

    def test_explicit_backend(self, mock_backend):
        with patch("crawlix.browser.detect_backend") as mock_detect:
            mock_detect.return_value = mock_backend
            b = Browser(backend="playwright")
            assert b.backend_name == "mock"

    def test_supports_js_false_for_requests(self, mock_backend):
        with patch("crawlix.browser.detect_backend") as mock_detect:
            mock_detect.return_value = mock_backend
            b = Browser()
            assert b.supports_js is False


class TestBrowserContextManager:
    def test_close_called_on_exit(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend):
            with Browser() as b:
                assert b.backend_name is not None
            mock_backend.close.assert_called_once()

    def test_close_called_on_exception(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend):
            with pytest.raises(RuntimeError):
                with Browser() as b:
                    raise RuntimeError("test error")
            mock_backend.close.assert_called_once()


class TestBrowserOpen:
    def test_open_returns_page(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend):
            b = Browser()
            page = b.open("https://example.com")
            assert page.url == "https://example.com"

    def test_cached_backend(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend) as mock_detect:
            b = Browser()
            b.open("https://a.com")
            b.open("https://b.com")
            mock_detect.assert_called_once()


class TestConvenienceFunctions:
    def test_get_returns_page(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend):
            from crawlix.browser import get
            page = get("https://example.com")
            assert page.url == "https://example.com"

    def test_fetch_returns_html(self, mock_backend):
        with patch("crawlix.browser.detect_backend", return_value=mock_backend):
            from crawlix.browser import fetch
            html = fetch("https://example.com")
            assert "Hello" in html
