from __future__ import annotations

from typing import Any

from crawlix.backends import detect_backend
from crawlix.backends.protocol import Backend
from crawlix.page import Page


class Browser:
    def __init__(
        self,
        backend: str = "auto",
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        locale: str = "en-US",
        user_agent: str | None = None,
    ):
        explicit = None if backend == "auto" else backend
        self._backend: Backend = detect_backend(
            explicit=explicit,
            headless=headless,
            stealth=stealth,
            timeout=timeout,
            proxy=proxy,
            user_agent=user_agent,
            locale=locale,
        )

    @property
    def backend_name(self) -> str:
        return self._backend.name

    @property
    def supports_js(self) -> bool:
        return self._backend.supports_js

    def open(self, url: str) -> Page:
        data = self._backend.open(url)
        return Page(self._backend, data)

    def new_page(self) -> Page:
        data = self._backend.new_page()
        return Page(self._backend, data)

    def close(self) -> None:
        self._backend.close()

    def __enter__(self) -> Browser:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def get(url: str, **kwargs: Any) -> Page:
    with Browser(**kwargs) as b:
        return b.open(url)


def fetch(url: str, **kwargs: Any) -> str:
    with Browser(**kwargs) as b:
        return b.open(url).html


def browse(url: str, **kwargs: Any) -> Page:
    kwargs.setdefault("backend", "playwright")
    with Browser(**kwargs) as b:
        return b.open(url)
