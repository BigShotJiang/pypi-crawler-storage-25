from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import PageData
from crawlix.element import Element


class Page:
    def __init__(self, backend, data: PageData | None = None):
        self._backend = backend
        self._data = data or PageData()

    def goto(self, url: str) -> Page:
        self._backend.goto(url)
        self._data = self._backend.open(url)
        return self

    def reload(self) -> Page:
        self._backend.reload()
        self._data = self._backend.open(self._data.url)
        return self

    def back(self) -> Page:
        self._backend.back()
        return self

    def forward(self) -> Page:
        self._backend.forward()
        return self

    @property
    def url(self) -> str:
        return self._data.url

    @property
    def title(self) -> str:
        return self._data.title

    @property
    def html(self) -> str:
        return self._data.html

    @property
    def text(self) -> str:
        return self._data.text

    @property
    def status(self) -> int:
        return self._data.status

    @property
    def headers(self) -> dict[str, str]:
        return dict(self._data.headers)

    def find(self, selector: str) -> Element | None:
        result = self._backend.find(selector)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def find_all(self, selector: str) -> list[Element]:
        return [Element(d, backend=self._backend) for d in self._backend.find_all(selector)]

    def find_text(self, text: str) -> Element | None:
        result = self._backend.find_text(text)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def xpath(self, expr: str) -> list[Element]:
        return [Element(d, backend=self._backend) for d in self._backend.xpath(expr)]

    def click(self, selector: str) -> Page:
        self._backend.click(selector)
        return self

    def double_click(self, selector: str) -> Page:
        self._backend.double_click(selector)
        return self

    def right_click(self, selector: str) -> Page:
        self._backend.right_click(selector)
        return self

    def type(self, selector: str, text: str) -> Page:
        self._backend.type(selector, text)
        return self

    def clear(self, selector: str) -> Page:
        self._backend.clear(selector)
        return self

    def submit(self, selector: str = "form") -> Page:
        self._backend.submit(selector)
        return self

    def select(self, selector: str, value: str) -> Page:
        self._backend.select(selector, value)
        return self

    def hover(self, selector: str) -> Page:
        self._backend.hover(selector)
        return self

    def focus(self, selector: str) -> Page:
        self._backend.focus(selector)
        return self

    def blur(self, selector: str) -> Page:
        self._backend.blur(selector)
        return self

    def scroll(self, x: int = 0, y: int = 500) -> Page:
        self._backend.evaluate(f"window.scrollTo({x}, {y})")
        return self

    def scroll_to(self, selector: str) -> Page:
        self._backend.scroll_to(selector)
        return self

    def key(self, key: str) -> Page:
        self._backend.key(key)
        return self

    def upload(self, selector: str, path: str) -> Page:
        self._backend.upload(selector, path)
        return self

    def wait_for(self, selector: str, timeout: int | None = None) -> Page:
        self._backend.wait_for(selector, timeout or 10)
        return self

    def wait_for_text(self, text: str, timeout: int | None = None) -> Page:
        self._backend.wait_for_text(text, timeout or 10)
        return self

    def wait_for_url(self, pattern: str, timeout: int | None = None) -> Page:
        self._backend.wait_for_url(pattern, timeout or 10)
        return self

    def wait_for_load(self, timeout: int | None = None) -> Page:
        self._backend.wait_for_load(timeout or 30)
        return self

    def wait_for_network_idle(self, timeout: int | None = None) -> Page:
        self._backend.wait_for_network_idle(timeout or 30)
        return self

    def sleep(self, seconds: float) -> Page:
        self._backend.sleep(seconds)
        return self

    def evaluate(self, js_code: str) -> Any:
        return self._backend.evaluate(js_code)

    def evaluate_on(self, selector: str, js: str) -> Any:
        return self._backend.evaluate_on(selector, js)

    def set_headers(self, headers: dict[str, str]) -> Page:
        self._backend.set_headers(headers)
        return self

    def set_cookies(self, cookies: list[dict]) -> Page:
        self._backend.set_cookies(cookies)
        return self

    def get_cookies(self) -> list[dict]:
        return self._backend.get_cookies()

    def clear_cookies(self) -> Page:
        self._backend.clear_cookies()
        return self

    def intercept(self, pattern: str, handler) -> Page:
        self._backend.intercept(pattern, handler)
        return self

    def links(self) -> list[str]:
        return [el.attr("href") for el in self.find_all("a[href]") if el.attr("href")]

    def images(self) -> list[str]:
        return [el.attr("src") for el in self.find_all("img[src]") if el.attr("src")]

    def tables(self) -> list[list[list[str]]]:
        results: list[list[list[str]]] = []
        for table in self.find_all("table"):
            rows: list[list[str]] = []
            for row in table.find_all("tr"):
                cells = [c.text for c in row.find_all("td,th")]
                rows.append(cells)
            results.append(rows)
        return results

    def meta(self) -> dict[str, str]:
        metas: dict[str, str] = {}
        for el in self.find_all("meta"):
            name = el.attr("name") or el.attr("property") or ""
            content = el.attr("content") or ""
            if name:
                metas[name] = content
        return metas

    def json(self) -> dict:
        import json as _json
        return _json.loads(self.text)

    def screenshot(self, path: str | None = None) -> bytes:
        return self._backend.screenshot(path)

    def pdf(self, path: str | None = None) -> bytes:
        return self._backend.pdf(path)

    def save(self, path: str) -> Page:
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.html)
        return self

    def show(self) -> Page:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(self.html, "html.parser")
        print(soup.prettify())
        return self
