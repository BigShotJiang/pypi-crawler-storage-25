class CrawlixError(Exception):
    """Base exception for all crawlix errors."""


class BackendError(CrawlixError):
    """Raised when a backend is unavailable or does not support an operation."""


class TimeoutError(CrawlixError):
    """Raised when a wait operation exceeds the timeout."""


class NavigationError(CrawlixError):
    """Raised when a page fails to load."""


class SelectorError(CrawlixError):
    """Raised when a selector is invalid or no element is found."""


class NetworkError(CrawlixError):
    """Raised on connection errors."""


class JavaScriptError(CrawlixError):
    """Raised when JavaScript evaluation fails."""
