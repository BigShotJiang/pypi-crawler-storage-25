from __future__ import annotations

from typing import Any

from crawlix.backends import _create_backend
from crawlix.backends.protocol import Backend, PageData


class AsyncBrowser:
    def __init__(
        self,
        backend: str = "httpx",
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        locale: str = "en-US",
        user_agent: str | None = None,
    ):
        self._backend: Backend = _create_backend(
            name=backend,
            headless=headless,
            stealth=stealth,
            timeout=timeout,
            proxy=proxy,
            user_agent=user_agent,
            locale=locale,
        )

    @property
    def backend_name(self) -> str:
        return self._backend.name

    async def open(self, url: str) -> AsyncPage:
        data = await self._backend.open(url)
        return AsyncPage(self._backend, data)

    async def close(self) -> None:
        await self._backend.close()

    async def __aenter__(self) -> AsyncBrowser:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()


class AsyncPage:
    def __init__(self, backend, data: PageData | None = None):
        self._backend = backend
        self._data = data or PageData()

    @property
    def url(self) -> str:
        return self._data.url

    @property
    def html(self) -> str:
        return self._data.html

    @property
    def text(self) -> str:
        return self._data.text

    @property
    def status(self) -> int:
        return self._data.status

    async def json(self) -> dict:
        import json as _json
        return _json.loads(self.text)


async def aget(url: str, **kwargs: Any) -> AsyncPage:
    async with AsyncBrowser(**kwargs) as b:
        return await b.open(url)


async def afetch(url: str, **kwargs: Any) -> str:
    async with AsyncBrowser(**kwargs) as b:
        page = await b.open(url)
        return page.html
