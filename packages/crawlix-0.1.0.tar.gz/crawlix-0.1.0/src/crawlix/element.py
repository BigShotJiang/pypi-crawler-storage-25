from __future__ import annotations

from crawlix.backends.protocol import ElementData


class Element:
    def __init__(self, data: ElementData, backend=None):
        self._data = data
        self._backend = backend

    @property
    def text(self) -> str:
        return self._data.text or ""

    @property
    def html(self) -> str:
        return self._data.html or ""

    @property
    def outer_html(self) -> str:
        return self._data.outer_html or ""

    @property
    def tag(self) -> str:
        return self._data.tag or ""

    @property
    def id(self) -> str:
        return self._data.element_id or ""

    @property
    def classes(self) -> list[str]:
        return list(self._data.classes) if self._data.classes else []

    def attr(self, name: str, default: str = "") -> str:
        attrs = self._data.attributes or {}
        return attrs.get(name, default)

    @property
    def attrs(self) -> dict[str, str]:
        return dict(self._data.attributes) if self._data.attributes else {}

    def has_attr(self, name: str) -> bool:
        attrs = self._data.attributes or {}
        return name in attrs

    def find(self, selector: str) -> Element | None:
        if self._backend is None:
            return None
        result = self._backend.find(selector)
        if result is None:
            return None
        return Element(result, backend=self._backend)

    def find_all(self, selector: str) -> list[Element]:
        if self._backend is None:
            return []
        return [Element(d, backend=self._backend) for d in self._backend.find_all(selector)]

    def parent(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        return Element(self._data.parent_data, backend=self._backend)

    def children(self) -> list[Element]:
        if not self._data.children_data:
            return []
        return [Element(d, backend=self._backend) for d in self._data.children_data]

    def siblings(self) -> list[Element]:
        if self._data.parent_data is None or not self._data.parent_data.children_data:
            return []
        return [
            Element(d, backend=self._backend)
            for d in self._data.parent_data.children_data
            if d is not self._data
        ]

    def next(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        siblings = self._data.parent_data.children_data or []
        idx = next((i for i, d in enumerate(siblings) if d is self._data), -1)
        if idx < 0 or idx + 1 >= len(siblings):
            return None
        return Element(siblings[idx + 1], backend=self._backend)

    def prev(self) -> Element | None:
        if self._data.parent_data is None:
            return None
        siblings = self._data.parent_data.children_data or []
        idx = next((i for i, d in enumerate(siblings) if d is self._data), -1)
        if idx < 1:
            return None
        return Element(siblings[idx - 1], backend=self._backend)

    def click(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.click("")
        return self

    def double_click(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.double_click("")
        return self

    def type(self, text: str) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.type("", text)
        return self

    def clear(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.clear("")
        return self

    def hover(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.hover("")
        return self

    def focus(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.focus("")
        return self

    def scroll_into_view(self) -> Element:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        self._backend.scroll_to("")
        return self

    def is_visible(self) -> bool:
        raise NotImplementedError("is_visible requires a browser backend")

    def is_enabled(self) -> bool:
        raise NotImplementedError("is_enabled requires a browser backend")

    def is_checked(self) -> bool:
        raise NotImplementedError("is_checked requires a browser backend")

    def bounding_box(self) -> dict:
        raise NotImplementedError("bounding_box requires a browser backend")

    def screenshot(self, path: str | None = None) -> bytes:
        if self._backend is None:
            raise RuntimeError("Element has no backend")
        return self._backend.screenshot(path)

    def __bool__(self) -> bool:
        return True

    def __str__(self) -> str:
        return self.text

    def __repr__(self) -> str:
        tag = self.tag
        classes = " ".join(self.classes)
        el_id = self.id
        parts = [f"<{tag}"]
        if classes:
            parts.append(f".{classes}")
        if el_id:
            parts.append(f"#{el_id}")
        return f"Element({''.join(parts)})"
