from __future__ import annotations

import requests
from bs4 import BeautifulSoup

from crawlix.backends.protocol import Backend, ElementData, PageData
from crawlix.utils import stealth_headers


class RequestsBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
    ):
        self._stealth = stealth
        self._timeout = timeout
        self._proxy = proxy
        self._user_agent = user_agent
        self._locale = locale
        self._session: requests.Session | None = None
        self._current_url: str = ""
        self._current_soup: BeautifulSoup | None = None
        self._current_html: str = ""
        self._status: int = 0
        self._response_headers: dict[str, str] = {}

    @property
    def name(self) -> str:
        return "requests"

    @property
    def supports_js(self) -> bool:
        return False

    def _get_session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
            if self._stealth:
                self._session.headers.update(
                    stealth_headers(self._user_agent, self._locale)
                )
            if self._proxy:
                self._session.proxies.update(
                    {"http": self._proxy, "https": self._proxy}
                )
        return self._session

    def open(self, url: str) -> PageData:
        session = self._get_session()
        try:
            resp = session.get(url, timeout=self._timeout)
        except requests.RequestException as e:
            from crawlix.exceptions import NavigationError
            raise NavigationError(f"Failed to load {url}: {e}") from e

        self._current_url = resp.url
        self._status = resp.status_code
        self._response_headers = dict(resp.headers)
        self._current_html = resp.text
        self._current_soup = BeautifulSoup(resp.text, "html.parser")

        return PageData(
            url=resp.url,
            html=resp.text,
            text=self._current_soup.get_text(separator=" ", strip=True),
            title=self._parse_title(),
            status=resp.status_code,
            headers=dict(resp.headers),
        )

    def new_page(self) -> PageData:
        return PageData()

    def _parse_title(self) -> str:
        if self._current_soup is None:
            return ""
        title_tag = self._current_soup.find("title")
        return title_tag.get_text(strip=True) if title_tag else ""

    def _element_to_data(self, el) -> ElementData:
        if el is None:
            return ElementData()
        attrs = dict(el.attrs) if el.attrs else {}
        classes = el.get("class", [])
        if isinstance(classes, str):
            classes = classes.split()
        return ElementData(
            tag=el.name or "",
            text=el.get_text(strip=True),
            html=str(el.decode_contents()),
            outer_html=str(el),
            attributes=attrs,
            classes=classes,
            element_id=el.get("id", ""),
        )

    def find(self, selector: str) -> ElementData | None:
        if self._current_soup is None:
            return None
        el = self._current_soup.select_one(selector)
        if el is None:
            return None
        return self._element_to_data(el)

    def find_all(self, selector: str) -> list[ElementData]:
        if self._current_soup is None:
            return []
        return [self._element_to_data(el) for el in self._current_soup.select(selector)]

    def set_headers(self, headers: dict[str, str]) -> None:
        session = self._get_session()
        session.headers.update(headers)

    def set_cookies(self, cookies: list[dict]) -> None:
        session = self._get_session()
        for c in cookies:
            session.cookies.set(c.get("name", ""), c.get("value", ""))

    def get_cookies(self) -> list[dict]:
        if self._session is None:
            return []
        return [
            {"name": c.name, "value": c.value, "domain": c.domain, "path": c.path}
            for c in self._session.cookies
        ]

    def clear_cookies(self) -> None:
        if self._session is not None:
            self._session.cookies.clear()

    def close(self) -> None:
        if self._session is not None:
            self._session.close()
            self._session = None
