from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, ElementData, PageData
from crawlix.utils import random_user_agent


class PlaywrightBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as e:
            raise ImportError(
                "playwright is not installed.\n"
                "Install: pip install crawlix[playwright]"
            ) from e

        self._headless = headless
        self._stealth = stealth
        self._timeout = timeout * 1000
        self._proxy = proxy
        self._user_agent = user_agent or random_user_agent()
        self._locale = locale
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None

        self._pw = sync_playwright().start()
        launch_kwargs: dict[str, Any] = {"headless": headless, "timeout": self._timeout}
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}
        self._browser = self._pw.chromium.launch(**launch_kwargs)

        context_kwargs: dict[str, Any] = {
            "user_agent": self._user_agent,
            "locale": locale,
        }
        if stealth:
            context_kwargs.update(self._stealth_context())
        self._context = self._browser.new_context(**context_kwargs)
        self._page = self._context.new_page()

    @staticmethod
    def _stealth_context() -> dict:
        return {
            "viewport": {"width": 1920, "height": 1080},
            "screen": {"width": 1920, "height": 1080},
        }

    @property
    def name(self) -> str:
        return "playwright"

    @property
    def supports_js(self) -> bool:
        return True

    def open(self, url: str) -> PageData:
        self._page.goto(url, timeout=self._timeout)
        return self._to_page_data()

    def new_page(self) -> PageData:
        self._page = self._context.new_page()
        return PageData(url="about:blank")

    def close(self) -> None:
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass

    def _to_page_data(self) -> PageData:
        return PageData(
            url=self._page.url,
            html=self._page.content(),
            text=self._page.inner_text("body") if self._page.query_selector("body") else "",
            title=self._page.title(),
            status=200,
        )

    def goto(self, url: str) -> None:
        self._page.goto(url, timeout=self._timeout)

    def reload(self) -> None:
        self._page.reload()

    def back(self) -> None:
        self._page.go_back()

    def forward(self) -> None:
        self._page.go_forward()

    def find(self, selector: str) -> ElementData | None:
        el = self._page.query_selector(selector)
        if el is None:
            return None
        return self._element_to_data(el)

    def find_all(self, selector: str) -> list[ElementData]:
        els = self._page.query_selector_all(selector)
        return [self._element_to_data(el) for el in els]

    def _element_to_data(self, el) -> ElementData:
        try:
            tag = el.evaluate("el => el.tagName.toLowerCase()")
        except Exception:
            tag = ""
        return ElementData(
            tag=tag,
            text=el.inner_text() if el else "",
            html=el.inner_html() if el else "",
            outer_html=el.evaluate("el => el.outerHTML") if el else "",
            attributes=el.evaluate(
                "el => { const a = {}; for (const attr of el.attributes) a[attr.name] = attr.value; return a; }"
            ) if el else {},
            classes=el.evaluate("el => [...el.classList]") if el else [],
            element_id=el.evaluate("el => el.id") if el else "",
        )

    def click(self, selector: str) -> None:
        self._page.click(selector)

    def double_click(self, selector: str) -> None:
        self._page.dblclick(selector)

    def right_click(self, selector: str) -> None:
        self._page.click(selector, button="right")

    def type(self, selector: str, text: str) -> None:
        self._page.fill(selector, text)

    def clear(self, selector: str) -> None:
        self._page.fill(selector, "")

    def submit(self, selector: str = "form") -> None:
        el = self._page.query_selector(selector)
        if el:
            el.evaluate("el => el.submit()")

    def select(self, selector: str, value: str) -> None:
        self._page.select_option(selector, value)

    def hover(self, selector: str) -> None:
        self._page.hover(selector)

    def focus(self, selector: str) -> None:
        self._page.focus(selector)

    def blur(self, selector: str) -> None:
        self._page.evaluate(f"document.querySelector('{selector}')?.blur()")

    def scroll_to(self, selector: str) -> None:
        self._page.evaluate(f"document.querySelector('{selector}')?.scrollIntoView()")

    def key(self, key: str) -> None:
        self._page.keyboard.press(key)

    def upload(self, selector: str, path: str) -> None:
        self._page.set_input_files(selector, path)

    def wait_for(self, selector: str, timeout: int = 10) -> None:
        self._page.wait_for_selector(selector, timeout=timeout * 1000)

    def wait_for_text(self, text: str, timeout: int = 10) -> None:
        self._page.wait_for_function(
            f'document.body.innerText.includes("{text}")',
            timeout=timeout * 1000,
        )

    def wait_for_url(self, pattern: str, timeout: int = 10) -> None:
        self._page.wait_for_url(pattern, timeout=timeout * 1000)

    def wait_for_load(self, timeout: int = 30) -> None:
        self._page.wait_for_load_state("load", timeout=timeout * 1000)

    def wait_for_network_idle(self, timeout: int = 30) -> None:
        self._page.wait_for_load_state("networkidle", timeout=timeout * 1000)

    def sleep(self, seconds: float) -> None:
        import time
        time.sleep(seconds)

    def evaluate(self, js_code: str) -> Any:
        return self._page.evaluate(js_code)

    def evaluate_on(self, selector: str, js: str) -> Any:
        return self._page.evaluate(f"document.querySelector('{selector}')?.{js}")

    def screenshot(self, path: str | None = None) -> bytes:
        return self._page.screenshot(path=path)

    def pdf(self, path: str | None = None) -> bytes:
        return self._page.pdf(path=path)

    def set_headers(self, headers: dict[str, str]) -> None:
        self._context.set_extra_http_headers(headers)

    def get_cookies(self) -> list[dict]:
        return [
            {"name": c["name"], "value": c["value"], "domain": c.get("domain", ""), "path": c.get("path", "")}
            for c in self._context.cookies()
        ]

    def set_cookies(self, cookies: list[dict]) -> None:
        self._context.add_cookies(cookies)

    def clear_cookies(self) -> None:
        self._context.clear_cookies()

    def intercept(self, pattern: str, handler) -> None:
        self._page.route(pattern, handler)
