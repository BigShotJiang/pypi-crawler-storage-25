from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, ElementData, PageData
from crawlix.utils import random_user_agent


class SeleniumBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
        except ImportError as e:
            raise ImportError(
                "selenium is not installed.\n"
                "Install: pip install crawlix[selenium]"
            ) from e

        self._timeout = timeout
        self._user_agent = user_agent or random_user_agent()

        options = Options()
        if headless:
            options.add_argument("--headless=new")
        options.add_argument(f"--user-agent={self._user_agent}")
        options.add_argument(f"--lang={locale}")
        if proxy:
            options.add_argument(f"--proxy-server={proxy}")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-blink-features=AutomationControlled")

        self._driver = webdriver.Chrome(options=options)
        self._driver.implicitly_wait(timeout)
        self._driver.set_page_load_timeout(timeout)

    @property
    def name(self) -> str:
        return "selenium"

    @property
    def supports_js(self) -> bool:
        return True

    def open(self, url: str) -> PageData:
        self._driver.get(url)
        return self._to_page_data()

    def new_page(self) -> PageData:
        self._driver.execute_script("window.open('about:blank', '_blank');")
        handles = self._driver.window_handles
        self._driver.switch_to.window(handles[-1])
        return PageData(url="about:blank")

    def close(self) -> None:
        try:
            self._driver.quit()
        except Exception:
            pass

    def _to_page_data(self) -> PageData:
        try:
            title = self._driver.title or ""
        except Exception:
            title = ""
        try:
            body = self._driver.find_element("tag name", "body")
            text = body.text
        except Exception:
            text = ""
        return PageData(
            url=self._driver.current_url,
            html=self._driver.page_source,
            text=text,
            title=title,
        )

    def goto(self, url: str) -> None:
        self._driver.get(url)

    def reload(self) -> None:
        self._driver.refresh()

    def back(self) -> None:
        self._driver.back()

    def forward(self) -> None:
        self._driver.forward()

    def find(self, selector: str) -> ElementData | None:
        from selenium.webdriver.common.by import By
        try:
            el = self._driver.find_element(By.CSS_SELECTOR, selector)
            return self._element_to_data(el)
        except Exception:
            return None

    def find_all(self, selector: str) -> list[ElementData]:
        from selenium.webdriver.common.by import By
        els = self._driver.find_elements(By.CSS_SELECTOR, selector)
        return [self._element_to_data(el) for el in els]

    def _element_to_data(self, el) -> ElementData:
        try:
            tag = el.tag_name
        except Exception:
            tag = ""
        return ElementData(
            tag=tag,
            text=el.text,
            html=el.get_attribute("innerHTML") or "",
            outer_html=el.get_attribute("outerHTML") or "",
            attributes=self._get_attrs(el),
            classes=(el.get_attribute("class") or "").split(),
            element_id=el.get_attribute("id") or "",
        )

    @staticmethod
    def _get_attrs(el) -> dict[str, str]:
        attr_names = (
            "class", "id", "href", "src", "alt", "title", "name",
            "value", "type", "placeholder", "disabled", "checked",
            "selected", "data-*",
        )
        try:
            return {attr: el.get_attribute(attr) or "" for attr in attr_names if el.get_attribute(attr)}
        except Exception:
            return {}

    def click(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).click()

    def double_click(self, selector: str) -> None:
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        ActionChains(self._driver).double_click(el).perform()

    def right_click(self, selector: str) -> None:
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        ActionChains(self._driver).context_click(el).perform()

    def type(self, selector: str, text: str) -> None:
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        el.clear()
        el.send_keys(text)

    def clear(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).clear()

    def submit(self, selector: str = "form") -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).submit()

    def select(self, selector: str, value: str) -> None:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import Select
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        Select(el).select_by_value(value)

    def hover(self, selector: str) -> None:
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        ActionChains(self._driver).move_to_element(el).perform()

    def focus(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).click()

    def blur(self, selector: str) -> None:
        self._driver.execute_script(f"document.querySelector('{selector}')?.blur()")

    def scroll_to(self, selector: str) -> None:
        from selenium.webdriver.common.by import By
        el = self._driver.find_element(By.CSS_SELECTOR, selector)
        self._driver.execute_script("arguments[0].scrollIntoView();", el)

    def key(self, key: str) -> None:
        from selenium.webdriver.common.keys import Keys
        key_map = {
            "Enter": Keys.ENTER,
            "Tab": Keys.TAB,
            "Escape": Keys.ESCAPE,
            "ArrowUp": Keys.ARROW_UP,
            "ArrowDown": Keys.ARROW_DOWN,
            "ArrowLeft": Keys.ARROW_LEFT,
            "ArrowRight": Keys.ARROW_RIGHT,
            "Backspace": Keys.BACKSPACE,
            "Delete": Keys.DELETE,
            "Home": Keys.HOME,
            "End": Keys.END,
            "PageUp": Keys.PAGE_UP,
            "PageDown": Keys.PAGE_DOWN,
        }
        from selenium.webdriver.common.action_chains import ActionChains
        ActionChains(self._driver).send_keys(key_map.get(key, key)).perform()

    def upload(self, selector: str, path: str) -> None:
        from selenium.webdriver.common.by import By
        self._driver.find_element(By.CSS_SELECTOR, selector).send_keys(path)

    def wait_for(self, selector: str, timeout: int = 10) -> None:
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait
        WebDriverWait(self._driver, timeout).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, selector))
        )

    def wait_for_text(self, text: str, timeout: int = 10) -> None:
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait
        WebDriverWait(self._driver, timeout).until(
            EC.text_to_be_present_in_element(("tag name", "body"), text)
        )

    def wait_for_load(self, timeout: int = 30) -> None:
        from selenium.webdriver.support.ui import WebDriverWait
        WebDriverWait(self._driver, timeout).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )

    def sleep(self, seconds: float) -> None:
        import time
        time.sleep(seconds)

    def evaluate(self, js_code: str) -> Any:
        return self._driver.execute_script(js_code)

    def evaluate_on(self, selector: str, js: str) -> Any:
        return self._driver.execute_script(
            f"return document.querySelector('{selector}')?.{js}"
        )

    def screenshot(self, path: str | None = None) -> bytes:
        return self._driver.get_screenshot_as_png()

    def set_headers(self, headers: dict[str, str]) -> None:
        self._driver.execute_cdp_cmd(
            "Network.setExtraHTTPHeaders", {"headers": headers}
        )

    def get_cookies(self) -> list[dict]:
        return [
            {"name": c["name"], "value": c["value"], "domain": c.get("domain", ""), "path": c.get("path", "")}
            for c in self._driver.get_cookies()
        ]

    def set_cookies(self, cookies: list[dict]) -> None:
        for c in cookies:
            self._driver.add_cookie(c)

    def clear_cookies(self) -> None:
        self._driver.delete_all_cookies()
