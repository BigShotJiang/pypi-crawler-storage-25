from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from crawlix.exceptions import BackendError


@dataclass
class PageData:
    url: str = ""
    html: str = ""
    text: str = ""
    title: str = ""
    status: int = 200
    headers: dict[str, str] = field(default_factory=dict)
    cookies: list[dict[str, str]] = field(default_factory=list)


@dataclass
class ElementData:
    tag: str = ""
    text: str = ""
    html: str = ""
    outer_html: str = ""
    attributes: dict[str, str] = field(default_factory=dict)
    classes: list[str] = field(default_factory=list)
    element_id: str = ""
    parent_data: ElementData | None = None
    children_data: list[ElementData] = field(default_factory=list)


class Backend(ABC):

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def supports_js(self) -> bool: ...

    @abstractmethod
    def open(self, url: str) -> PageData: ...

    @abstractmethod
    def close(self) -> None: ...

    # Navigation
    def goto(self, url: str) -> None:
        raise BackendError(self._browser_only("goto"))

    def reload(self) -> None:
        raise BackendError(self._browser_only("reload"))

    def back(self) -> None:
        raise BackendError(self._browser_only("back"))

    def forward(self) -> None:
        raise BackendError(self._browser_only("forward"))

    # Querying
    @abstractmethod
    def find(self, selector: str) -> ElementData | None: ...

    @abstractmethod
    def find_all(self, selector: str) -> list[ElementData]: ...

    def find_text(self, text: str) -> ElementData | None:
        matches = [el for el in self.find_all("*") if text in (el.text or "")]
        if not matches:
            return None
        matches.sort(key=lambda el: len(el.text or ""))
        return matches[0]

    def xpath(self, expr: str) -> list[ElementData]:
        raise BackendError(self._browser_only("xpath"))

    # Interaction
    def click(self, selector: str) -> None:
        raise BackendError(self._browser_only("click"))

    def double_click(self, selector: str) -> None:
        raise BackendError(self._browser_only("double_click"))

    def type(self, selector: str, text: str) -> None:
        raise BackendError(self._browser_only("type"))

    def clear(self, selector: str) -> None:
        raise BackendError(self._browser_only("clear"))

    def submit(self, selector: str = "form") -> None:
        raise BackendError(self._browser_only("submit"))

    def select(self, selector: str, value: str) -> None:
        raise BackendError(self._browser_only("select"))

    def hover(self, selector: str) -> None:
        raise BackendError(self._browser_only("hover"))

    def focus(self, selector: str) -> None:
        raise BackendError(self._browser_only("focus"))

    def blur(self, selector: str) -> None:
        raise BackendError(self._browser_only("blur"))

    def right_click(self, selector: str) -> None:
        raise BackendError(self._browser_only("right_click"))

    def scroll_to(self, selector: str) -> None:
        raise BackendError(self._browser_only("scroll_to"))

    def key(self, key: str) -> None:
        raise BackendError(self._browser_only("key"))

    def upload(self, selector: str, path: str) -> None:
        raise BackendError(self._browser_only("upload"))

    # Waiting
    def wait_for(self, selector: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for"))

    def wait_for_text(self, text: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for_text"))

    def wait_for_url(self, pattern: str, timeout: int = 10) -> None:
        raise BackendError(self._browser_only("wait_for_url"))

    def wait_for_load(self, timeout: int = 30) -> None:
        raise BackendError(self._browser_only("wait_for_load"))

    def wait_for_network_idle(self, timeout: int = 30) -> None:
        raise BackendError(self._browser_only("wait_for_network_idle"))

    def sleep(self, seconds: float) -> None:
        raise BackendError(self._browser_only("sleep"))

    # JavaScript
    def evaluate(self, js_code: str) -> Any:
        raise BackendError(self._browser_only("evaluate"))

    def evaluate_on(self, selector: str, js: str) -> Any:
        raise BackendError(self._browser_only("evaluate_on"))

    # Network
    def set_headers(self, headers: dict[str, str]) -> None:
        raise BackendError(self._browser_only("set_headers"))

    def set_cookies(self, cookies: list[dict]) -> None:
        raise BackendError(self._browser_only("set_cookies"))

    def get_cookies(self) -> list[dict]:
        raise BackendError(self._browser_only("get_cookies"))

    def clear_cookies(self) -> None:
        raise BackendError(self._browser_only("clear_cookies"))

    def intercept(self, pattern: str, handler) -> None:
        raise BackendError(self._browser_only("intercept"))

    # Output
    def screenshot(self, path: str | None = None) -> bytes:
        raise BackendError(self._browser_only("screenshot"))

    def pdf(self, path: str | None = None) -> bytes:
        raise BackendError(self._browser_only("pdf"))

    @staticmethod
    def _browser_only(method: str) -> str:
        return (
            f"{method}() requires a browser backend.\n"
            "Install one:\n"
            "  pip install crawlix[playwright]   \u2190 recommended\n"
            "  pip install crawlix[selenium]"
        )
