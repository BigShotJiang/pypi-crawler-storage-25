from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from crawlix.backends.protocol import Backend


def detect_backend(
    explicit: str | None = None,
    headless: bool = True,
    stealth: bool = True,
    timeout: int = 30,
    proxy: str | None = None,
    user_agent: str | None = None,
    locale: str = "en-US",
) -> Backend:
    if explicit is not None:
        return _create_backend(
            explicit, headless, stealth, timeout, proxy, user_agent, locale
        )

    for name in ("playwright", "selenium"):
        try:
            return _create_backend(
                name, headless, stealth, timeout, proxy, user_agent, locale
            )
        except ImportError:
            continue

    from crawlix.backends.requests import RequestsBackend
    return RequestsBackend(
        headless=headless,
        stealth=stealth,
        timeout=timeout,
        proxy=proxy,
        user_agent=user_agent,
        locale=locale,
    )


def _create_backend(
    name: str,
    headless: bool = True,
    stealth: bool = True,
    timeout: int = 30,
    proxy: str | None = None,
    user_agent: str | None = None,
    locale: str = "en-US",
) -> Backend:
    if name == "requests":
        from crawlix.backends.requests import RequestsBackend
        return RequestsBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "playwright":
        from crawlix.backends.playwright import PlaywrightBackend
        return PlaywrightBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "selenium":
        from crawlix.backends.selenium import SeleniumBackend
        return SeleniumBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    elif name == "httpx":
        from crawlix.backends.httpx import HttpxBackend
        return HttpxBackend(
            headless=headless, stealth=stealth, timeout=timeout,
            proxy=proxy, user_agent=user_agent, locale=locale,
        )
    else:
        from crawlix.exceptions import BackendError
        raise BackendError(
            f"Unknown backend: {name!r}. Available: requests, playwright, selenium, httpx"
        )
