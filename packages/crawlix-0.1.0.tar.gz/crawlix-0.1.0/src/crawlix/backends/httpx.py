from __future__ import annotations

from typing import Any

from crawlix.backends.protocol import Backend, ElementData, PageData


class HttpxBackend(Backend):
    def __init__(
        self,
        headless: bool = True,
        stealth: bool = True,
        timeout: int = 30,
        proxy: str | None = None,
        user_agent: str | None = None,
        locale: str = "en-US",
        **kwargs: Any,
    ):
        self._timeout = timeout
        self._proxy = proxy
        self._user_agent = user_agent
        self._locale = locale
        self._stealth = stealth
        self._client = None

    async def _get_client(self):
        if self._client is None:
            try:
                import httpx
            except ImportError as e:
                raise ImportError(
                    "httpx is required for async support.\n"
                    "Install: pip install crawlix[async]"
                ) from e

            headers = {}
            if self._stealth:
                from crawlix.utils import stealth_headers
                headers = stealth_headers(self._user_agent, self._locale)

            client_kwargs: dict[str, Any] = {
                "headers": headers,
                "timeout": self._timeout,
            }
            if self._proxy:
                client_kwargs["proxies"] = self._proxy
            self._client = httpx.AsyncClient(**client_kwargs)
        return self._client

    @property
    def name(self) -> str:
        return "httpx"

    @property
    def supports_js(self) -> bool:
        return False

    async def open(self, url: str) -> PageData:
        import httpx
        from bs4 import BeautifulSoup

        client = await self._get_client()
        try:
            resp = await client.get(url)
        except httpx.RequestError as e:
            from crawlix.exceptions import NavigationError
            raise NavigationError(f"Failed to load {url}: {e}") from e

        soup = BeautifulSoup(resp.text, "html.parser")
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""
        text = soup.get_text(separator=" ", strip=True)

        return PageData(
            url=str(resp.url),
            html=resp.text,
            text=text,
            title=title,
            status=resp.status_code,
            headers=dict(resp.headers),
        )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def find(self, selector: str) -> ElementData | None:
        return None

    async def find_all(self, selector: str) -> list[ElementData]:
        return []
