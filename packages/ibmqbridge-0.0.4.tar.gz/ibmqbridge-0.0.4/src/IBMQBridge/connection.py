import qiskit
from typing import Literal, Optional, cast
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
from qiskit_machine_learning.state_fidelities import ComputeUncompute
import time
import numpy as np

from sklearn.preprocessing import StandardScaler

ChannelType = Literal["ibm_quantum_platform", "ibm_cloud", "local"]

class QuantumConnector:
    def __init__(self, token: str, instance_crm: str, channel: ChannelType = "ibm_cloud"):
        """
        Aqui você recebe os parâmetros básicos para iniciar a conversa.
        :param token: Sua API KEY da IBM Quantum Platform.
        :param instance_crm: A instância de acesso .
        :param channel: O canal de acesso (padrão é 'ibm_cloud').
        """
        self.token = token
        self.instance_crm = instance_crm
        self.channel = channel
        self.service = None

    def conectar(self):
        """Método para autenticar na IBM"""
        try:
            self.service = QiskitRuntimeService(channel=cast(ChannelType, self.channel), token=self.token, instance=self.instance_crm)
            print("Conectada com sucesso à IBM! 🚀")
        except Exception as e:
            print(f"Erro ao conectar à IBM")

    def enviar_circuito(self, circuito, backend: Optional[str] = None, shots: Optional[int] = None ):
        """
        Manda seu circuito para o computador quântico.
        :param circuito: O objeto do circuito criado no Qiskit.
        :param backend: O nome do computador ou simulador(Opcional).
        """
        backend_real = None

        if not self.service:
            raise Exception("Você precisa se conectar a IBM antes de enviar um circuito! Use o método 'conectar()' primeiro.")
        
        if backend is None:
            backend_real = self.service.least_busy(simulator=False, operational=True)
            print(f"📡 Backend encontrado: {backend_real.name}. Espera média: {backend_real.status().pending_jobs} jobs.")
        else:
            print(f"Enviando para o backend: {backend}")
            try:
                backend_real = self.service.backend(backend)  # Verifica se o backend existe
            except Exception as e:
                print("Não foi possível encontrar o backend especificado. Verifique o nome e tente novamente.")

        sampler = Sampler(mode=backend_real)
        if shots:
            sampler.options.default_shots = shots  # type: ignore[attr-defined]
            print(f"Shots definidos para: {shots}")
        job = sampler.run([circuito])
        print(f"Job enviado! ID: {job.job_id()}")
        return job
    
    def transpilar_circuito(self, circuito, backend: Optional[str] = None,optimization_level: Optional[int] = None):
        """Transpila o circuito para o backend escolhido."""
        if not self.service:
            raise Exception("Você precisa se conectar a IBM antes de transpilar um circuito! Use o método 'conectar()' primeiro.")
        
        backend_real = None
        if backend is None:
            backend_real = self.service.least_busy(simulator=False, operational=True)
            print(f"Transpilando para o backend mais disponível: {backend_real.name}")
        else:
            try:
                backend_real = self.service.backend(backend)
                print(f"Transpilando para o backend: {backend}")
            except Exception as e:
                print("Não foi possível encontrar o backend especificado. Verifique o nome e tente novamente.")
                return None
        
        circuito_transpilado = qiskit.transpile(circuito, backend=backend_real, optimization_level=optimization_level)
        print("Circuito transpilado com sucesso!")
        return circuito_transpilado
    

    def treinar_modelo_QSVC(self, modelo, X: np.ndarray, y: np.ndarray, backend: Optional[str] = None, shots: Optional[int] = None , optimization_level: Optional[int] = None):
        """Treina um modelo de machine learning quântico usando o backend escolhido."""
        if not self.service:
            raise Exception("Você precisa se conectar a IBM antes de treinar um modelo! Use o método 'conectar()' primeiro.")
        
        backend_real = None
        if backend is None:
            backend_real = self.service.least_busy(simulator=False, operational=True)
            print(f"Treinando no backend mais disponível: {backend_real.name}")
        else:
            try:
                backend_real = self.service.backend(backend)
                print(f"Treinando no backend: {backend}")
            except Exception as e:
                print("Não foi possível encontrar o backend especificado. Verifique o nome e tente novamente.")
                return None
            
        sampler = Sampler(mode=backend_real)
        if shots:
            sampler.options.default_shots = shots  # type: ignore[attr-defined]
            print(f"Shots definidos para: {shots}")
        
        pm = generate_preset_pass_manager(backend=backend_real, optimization_level=optimization_level or 2)
        fidelidade_real = ComputeUncompute(
            sampler=sampler,
            pass_manager=pm,
        )

        from qiskit_machine_learning.algorithms import QSVC
        from qiskit_machine_learning.kernels import FidelityQuantumKernel

        # 3. Criamos o Kernel passando a 'fidelity' em vez do 'sampler'
        kernel_real = FidelityQuantumKernel(feature_map=modelo, fidelity=fidelidade_real)
    
        mod_real = QSVC(quantum_kernel=kernel_real)

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X) # Normaliza os dados para melhor desempenho
        y_qsvc = 2 * y.astype(int) - 1 # Converter labels para -1 e 1 (padrão QSVC)
        start_time = time.time()
        mod_real.fit(X_scaled, y_qsvc)
        end_time = time.time()

        print("Modelo de QSVC treinado com sucesso! Tempo de treinamento: {:.2f} segundos".format(end_time - start_time))
       
        # Aqui você implementaria a lógica de treinamento do modelo usando o backend_real
        # Isso pode envolver a criação de circuitos específicos para o modelo e a execução deles no backend.
        print("Modelo treinado com sucesso!")
    
