# Aqui você importa as classes principais dos seus outros arquivos
# para que elas fiquem disponíveis na "raiz" da biblioteca.
from .connection import QuantumConnector
from .simulation import QuantumSimulator

# Você também pode definir a versão aqui
__version__ = "0.0.4"
__author__ = "Amanda de Jesus Melo"

# Isso controla o que é exportado quando alguém der 'from sua_lib import *'
__all__ = ["QuantumConnector","QuantumSimulator"]