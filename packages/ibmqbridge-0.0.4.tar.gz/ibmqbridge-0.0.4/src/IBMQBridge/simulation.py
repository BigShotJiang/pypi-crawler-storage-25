import qiskit
from qiskit import QuantumCircuit,transpile
from typing import Optional
from qiskit_aer import Aer

class QuantumSimulator:

    def __init__(self, qubits:int, bits:int):
        """
            Aqui você recebe os parâmetros básicos para iniciar o simulador.
            :param qubits: quantidade de qubits que você deseja no circuito do simulador.
            :param bits: quantidade de bits clássicos para suas medições
        """
        self.qubits = qubits
        self.bits = bits
        self.circuito = QuantumCircuit(qubits,bits)

    def testar_circuito(self, backend:str = "qasm_simulator", shots: Optional[int] = None):
        """
            Quando o circuito estiver pronto, você pode rodar ele por essa função.
            :param backend: Hardware que você deseja simular(padrão: qasm_simulator).
            :param shots: Opcional: Quantidade de vezes que seu circuito rodará
        """ 
        simulador= Aer.get_backend(backend)
        transpilado = transpile(self.circuito,simulador)
        job = simulador.run(transpilado,shots=shots) # pyright: ignore[reportAttributeAccessIssue]
        return job.result()

    def aplicar_hadamard(self,qubit:int):
        self.verificar_operacao(qubit)
        self.circuito.h(qubit)

    def aplicar_not(self, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.x(qubit)

    def aplicar_pauli_x(self, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.x(qubit)

    def aplicar_pauli_y(self, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.y(qubit)

    def aplicar_pauli_z(self, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.z(qubit)

    def aplicar_cnot(self, qubit_controle: int, qubit_alvo: int):
        self.verificar_operacao(qubit_controle)
        self.verificar_operacao(qubit_alvo)
        self.circuito.cx(qubit_controle, qubit_alvo)

    def aplicar_swap(self, qubit1: int, qubit2: int):
        self.verificar_operacao(qubit1)
        self.verificar_operacao(qubit2)
        self.circuito.swap(qubit1, qubit2)

    def aplicar_rx(self, theta: float, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.rx(theta, qubit)
        
    def aplicar_rz(self, theta: float, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.rz(theta, qubit)    

    def aplicar_ry(self, theta: float, qubit: int):
        self.verificar_operacao(qubit)
        self.circuito.ry(theta, qubit)

    def medir_qubit(self,qubit,bit):
        """
            Adiciona uma medição no seu circuito
            :param qubit: qubit que você deseja medir.
            :param bit: bit clássico que armazenará o valor da medição
        """ 
        self.verificar_operacao(qubit, bit)
        self.circuito.measure(qubit,bit)

    def verificar_operacao(self,qubit:int, bit: Optional[int] = None):
        """
            Verifica se o qubit e o bit existem no circuito criado
            :param qubit: qubit que você deseja verificar.
            :param bit: bit clássico que você deseja verificar.
        """
        if qubit >= self.qubits:
            raise Exception("Qubit não existe nesse circuito")

        if bit is not None:
            if bit >= self.bits:
                raise Exception("Bit não existe nesse circuito")

    def mostrar_circuito(self):
        """
            Mostra o circuito criado até o momento.
        """
        print(self.circuito)

    def resetar_circuito(self):
        """
            Reseta o circuito para um estado inicial, apagando todas as operações feitas.
        """
        self.circuito = QuantumCircuit(self.qubits,self.bits)

    def obter_circuito(self):
        return self.circuito

    def obter_qubits(self):
        return self.qubits
    
    def obter_bits(self):
        return self.bits
    
    def contar_portas(self):
        return self.circuito.count_ops()
    
    def obter_diagrama(self):
        return self.circuito.draw(output='text')
    
    def obterContagemResultados(self, resultado):
        return resultado.get_counts(self.circuito)
    
    def obter_estado_final(self, resultado):
        return resultado.get_statevector(self.circuito)
    
    def obter_matriz_unitaria(self):
        return self.circuito.to_matrix() # pyright: ignore[reportAttributeAccessIssue]
    
    def plotar_histograma(self, resultado):
        from qiskit.visualization import plot_histogram
        import matplotlib.pyplot as plt
        counts = self.obterContagemResultados(resultado)
        imagem = plot_histogram(counts)
        plt.show(imagem)
        return imagem

