"""
MultiChat
# Version: 0.1.1
# Author: Caiwei Zhen
"""

from .Model import utilities, model_training
from .Analysis import Intra_strength as tl
from .Analysis import Processing as pp
from .Plot import Visualization as pl

__version__ = "0.1.1"
__author__ = "Caiwei Zhen"
