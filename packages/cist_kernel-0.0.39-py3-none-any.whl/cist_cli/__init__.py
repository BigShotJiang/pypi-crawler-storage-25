"""CIST CLI - Contract Instruction Set Toolkit."""

from __future__ import annotations

import re
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path


def _read_source_version() -> str | None:
    pyproject_path = Path(__file__).resolve().parent.parent / "pyproject.toml"
    if not pyproject_path.exists():
        return None

    match = re.search(
        r'^version = "([^"]+)"',
        pyproject_path.read_text(encoding="utf-8"),
        re.MULTILINE,
    )
    if not match:
        return None
    return match.group(1)


_source_version = _read_source_version()
if _source_version is not None:
    __version__ = _source_version
else:
    try:
        __version__ = version("cist-kernel")
    except PackageNotFoundError:
        __version__ = "0.0.0"


__all__ = ["__version__", "main", "parser", "network"]