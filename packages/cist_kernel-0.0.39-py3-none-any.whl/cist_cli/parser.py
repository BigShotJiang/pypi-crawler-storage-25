from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ValidationError(Exception):
    """Raised when CIST syntax validation fails."""


@dataclass(frozen=True)
class SyntaxIssue:
    line: int
    message: str
    severity: str = "error"


class CISTParser:
    """Perform lightweight, local-only validation for CIST source files."""

    USE_PATTERN = re.compile(r"^use\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*$")
    FROM_DATA_PATTERN = re.compile(r"\bfrom\s+data\b(?=\s*\()")

    def parse(self, content: str) -> dict[str, Any]:
        """Validate CIST syntax and return file metadata."""
        lines = content.split("\n")
        issues: list[SyntaxIssue] = []
        modules: list[str] = []
        data_stream_count = 0

        bracket_stack: list[tuple[str, int]] = []
        open_chars = {"(", "[", "{"}
        close_chars = {")": "(", "]": "[", "}": "{"}
        in_string = False
        string_char: str | None = None
        string_start_line = 0

        for line_num, line in enumerate(lines, start=1):
            leading_whitespace = line[: len(line) - len(line.lstrip(" \t"))]
            if " " in leading_whitespace and "\t" in leading_whitespace:
                issues.append(
                    SyntaxIssue(
                        line=line_num,
                        message="Mixed tabs and spaces in indentation",
                        severity="warning",
                    )
                )

            code_buffer: list[str] = []
            index = 0
            while index < len(line):
                char = line[index]

                if in_string:
                    if char == string_char and not self._is_escaped(line, index):
                        in_string = False
                        string_char = None
                        string_start_line = 0
                    index += 1
                    continue

                if char == "#":
                    break

                if char in {'"', "'"}:
                    in_string = True
                    string_char = char
                    string_start_line = line_num
                    index += 1
                    continue

                code_buffer.append(char)
                if char in open_chars:
                    bracket_stack.append((char, line_num))
                elif char in close_chars:
                    if not bracket_stack:
                        issues.append(
                            SyntaxIssue(
                                line=line_num,
                                message=f"Unmatched closing bracket '{char}'",
                            )
                        )
                    else:
                        last_open, last_line = bracket_stack.pop()
                        if last_open != close_chars[char]:
                            issues.append(
                                SyntaxIssue(
                                    line=line_num,
                                    message=(
                                        f"Mismatched bracket: {last_open} closed with {char} "
                                        f"(opened line {last_line})"
                                    ),
                                )
                            )

                index += 1

            stripped_code = "".join(code_buffer).strip()

            if stripped_code.startswith("use "):
                match = self.USE_PATTERN.fullmatch(stripped_code)
                if match is None:
                    issues.append(
                        SyntaxIssue(line=line_num, message="Invalid use statement")
                    )
                else:
                    modules.append(match.group(1))

            if "from data" in stripped_code and not self.FROM_DATA_PATTERN.search(
                stripped_code
            ):
                issues.append(
                    SyntaxIssue(line=line_num, message="Invalid 'from data' expression")
                )
            else:
                data_stream_count += len(self.FROM_DATA_PATTERN.findall(stripped_code))

        for char, line_num in bracket_stack:
            issues.append(SyntaxIssue(line=line_num, message=f"Unclosed bracket '{char}'"))

        if in_string:
            issues.append(
                SyntaxIssue(
                    line=string_start_line or len(lines),
                    message="Unclosed string at end of file",
                )
            )

        errors = [issue for issue in issues if issue.severity == "error"]
        if errors:
            summary = "\n".join(
                f"Line {issue.line}: {issue.message}" for issue in errors[:5]
            )
            raise ValidationError(f"Syntax validation failed:\n{summary}")

        return {
            "content": content,
            "modules": modules,
            "data_streams": data_stream_count,
            "line_count": len(lines),
            "warnings": [issue for issue in issues if issue.severity == "warning"],
        }

    def validate_file(self, filepath: Path) -> dict[str, Any]:
        """Validate a `.cis` file from disk."""
        try:
            content = filepath.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise ValidationError("File is not valid UTF-8 encoding") from exc
        except OSError as exc:
            raise ValidationError(f"Cannot read file: {exc}") from exc

        return self.parse(content)

    @staticmethod
    def _is_escaped(line: str, index: int) -> bool:
        backslash_count = 0
        cursor = index - 1
        while cursor >= 0 and line[cursor] == "\\":
            backslash_count += 1
            cursor -= 1
        return backslash_count % 2 == 1