# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

data modify storage bs:dump ctx.char set string storage bs:dump ctx.parse -1
data modify storage bs:dump ctx.parse set string storage bs:dump ctx.parse 0 -1
execute store result storage bs:dump ctx.cursor int 1 run scoreboard players remove #dump.cursor bs.data 1
execute if data storage bs:dump ctx{char:" "} run return run function bs.dump:interpret/nbt/expand/parse/terminate with storage bs:dump ctx
function bs.dump:interpret/nbt/expand/parse/next
