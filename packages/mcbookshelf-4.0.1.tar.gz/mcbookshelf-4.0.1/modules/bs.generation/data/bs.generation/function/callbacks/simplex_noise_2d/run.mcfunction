# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

scoreboard players operation $random.simplex_noise_2d.x bs.in = $generation.i bs.lambda
scoreboard players operation $random.simplex_noise_2d.y bs.in = $generation.j bs.lambda
scoreboard players operation $random.simplex_noise_2d.x bs.in *= #generation.s bs.data
scoreboard players operation $random.simplex_noise_2d.y bs.in *= #generation.s bs.data

execute store result score $generation.noise bs.lambda run function #bs.random:simplex_noise_2d
$$(cb)
