"""
:mod:`etlplus.cli._commands.validate` module.

Typer command for validating data against field rules or schemas.
"""

from __future__ import annotations

import typer
from click.core import ParameterSource

from .._handlers.dataops import validate_handler
from ._app import app
from ._helpers import CommandHelperPolicy
from ._options.common import OutputOption
from ._options.common import StructuredEventFormatOption
from ._options.resources import SourceArg
from ._options.resources import SourceFormatOption
from ._options.resources import SourceTypeOption
from ._options.specs import RulesOption
from ._options.specs import SchemaFormatOption
from ._options.specs import SchemaOption
from ._state import ensure_state

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Functions
    'validate_cmd',
]


# SECTION: FUNCTIONS ======================================================== #


@app.command('validate')
def validate_cmd(
    ctx: typer.Context,
    source: SourceArg = '-',
    source_format: SourceFormatOption = None,
    source_type: SourceTypeOption = None,
    rules: RulesOption = '{}',
    schema: SchemaOption = None,
    schema_format: SchemaFormatOption = None,
    output: OutputOption = '-',
    event_format: StructuredEventFormatOption = None,
) -> int:
    """
    Validate data against JSON-described rules or an external schema.

    Parameters
    ----------
    ctx : typer.Context
        Typer context.
    source : SourceArg, optional
        Source path, URI/URL, JSON payload, or ``-`` for STDIN.
    source_format : SourceFormatOption, optional
        Source payload format override.
    source_type : SourceTypeOption, optional
        Source connector type override.
    rules : RulesOption, optional
        JSON string describing the validation rules.
    schema : SchemaOption, optional
        Schema path used for schema-based validation.
    schema_format : SchemaFormatOption, optional
        Schema format override for schema-based validation. Supported values
        are ``xsd`` for XML Schema, ``jsonschema`` for JSON Schema, and
        ``frictionless`` for CSV Table Schema validation.
    output : OutputOption, optional
        Optional output path for validation results.
    event_format : StructuredEventFormatOption, optional
        Structured event output format.

    Returns
    -------
    int
        CLI exit code indicating success (``0``) or failure (non-zero).

    Raises
    ------
    typer.BadParameter
        If the schema option family is incomplete or conflicts with
        ``--rules``.

    Notes
    -----
    Use ``--schema-format jsonschema`` for JSON or YAML source documents,
    ``--schema-format frictionless`` for CSV source documents, and
    ``--schema-format xsd`` for XML documents.
    """
    rules_supplied = ctx.get_parameter_source('rules') is not ParameterSource.DEFAULT
    if schema_format is not None and schema is None:
        raise typer.BadParameter('--schema-format requires --schema')
    if schema is not None and rules_supplied:
        raise typer.BadParameter(
            'Use either --rules or --schema/--schema-format, not both.',
        )

    state = ensure_state(ctx)
    _, resolved_source = CommandHelperPolicy.resolve_command_resource(
        ctx,
        state=state,
        role='source',
        value=source,
        connector_type=source_type,
        format_value=source_format,
        soft_inference=True,
    )

    return CommandHelperPolicy.call_handler(
        validate_handler,
        state=state,
        source=resolved_source.value,
        rules=(
            {}
            if schema is not None
            else CommandHelperPolicy.parse_json_option(rules, '--rules')
        ),
        schema=schema,
        schema_format=schema_format,
        target=output,
        source_format=resolved_source.format_hint,
        event_format=event_format,
        format_explicit=resolved_source.format_explicit,
    )
