# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2020-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import collections
import enum

PageContentContentType = collections.namedtuple(
    'PageContentContentType',
    'page, content',
)

PageContentContentTypes = list[PageContentContentType]


class PageContentType(enum.Enum):
    BLOCKQUOTE = enum.auto()
    LIST = enum.auto()
    TEXT = enum.auto()
    FORMULA = enum.auto()
    CAPTION = enum.auto()
    TABLE = enum.auto()
    FIGURE = enum.auto()
    BOXED = enum.auto()
    UNDEFINED = -1
