# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import contextlib
import dataclasses

import utilo

import iamraw
import iamraw.toc


@dataclasses.dataclass(unsafe_hash=True)
class Headline:
    title: str
    level: int = dataclasses.field(default=0)
    raw: str = dataclasses.field(default=None)
    raw_level: str = dataclasses.field(default=None, compare=False)
    page: int = dataclasses.field(default=-1)
    container: int = dataclasses.field(default=None)
    decoration: int = dataclasses.field(default=None)
    # TODO: RENAME PAGE TO PDFPAGE

    @property
    def start(self):
        with contextlib.suppress(TypeError):
            return self.container[0]  # pylint:disable=E1136
        return self.container

    @property
    def end(self):
        with contextlib.suppress(TypeError):
            return self.container[1]  # pylint:disable=E1136
        return self.container

    @property
    def identifier(self) -> int:
        """\
        >>> Headline('Einleitung', container=5).identifier
        123400090015
        """
        page = str(self.page + 10).zfill(4)
        container = self.container
        if isinstance(container, tuple):
            container = container[0]
        container = 1000 if container is None else container + 10
        container = str(container).zfill(4)
        result = int('1234' + page + container)
        return result


Headlines = list[Headline]
PagesHeadlineList = list[Headlines]  # TODO: REMOVE LATER


@dataclasses.dataclass(unsafe_hash=True)
class HeadlineGroup:
    headlines: Headlines = dataclasses.field(default_factory=list)
    number: int = None

    def __getitem__(self, index):
        return self.headlines[index]

    def __len__(self):
        return len(self.headlines)


HeadlineGroups = list[HeadlineGroup]


@iamraw.extracted
@dataclasses.dataclass(unsafe_hash=True)
class HeadlineResult:
    groups: HeadlineGroups = dataclasses.field(default_factory=list)
    """Value of trust in this extraction result."""
    confidence: float = None

    def __getitem__(self, index):
        return self.groups[index]

    def __len__(self):
        return len(self.groups)


def headlines_totoc(
    headlines: PagesHeadlineList,
    remove_rawinfo: bool = False,
    level_default: int = 1,
) -> 'iamraw.Toc':
    """Convert headlines to toc-structure. Use level_default=None to
    skip setting default level.

    Hint: Converting to toc requires a None-Level for every item.
    """
    try:
        flat = utilo.flat(headlines)
    except TypeError:
        # list is already flat
        flat = headlines
    # disable default level by setting None
    if level_default is not None:
        for item in flat:
            # set default level if level is None
            if item.level is None:
                item.level = level_default
    for item in flat:
        assert item.level is not None, str(item)
    result = iamraw.toc.create_toc(flat, remove_rawinfo=remove_rawinfo)
    return result
