# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

from collections import namedtuple

PageContentTextPosition = namedtuple('PageContentTextPosition', 'content, page')
PageContentTextPositions = list[PageContentTextPosition]

TextPosition = namedtuple('TextPosition', 'bounding, mean')
TextPositions = list[TextPosition]
