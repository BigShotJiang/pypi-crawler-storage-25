# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2020-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import dataclasses


@dataclasses.dataclass
class DocRef:
    page: int
    sentence: int
    marked: list = dataclasses.field(default=list)
    raw: list = None

    def __getitem__(self, index):
        return (self.page, self.sentence, self.marked)[index]


DocRefs = list[DocRef]


@dataclasses.dataclass
class TextAdvice:
    raw: str = None
    typ: str = None
    docref: DocRef = None
    replacement: str = None

    @property
    def page(self) -> int:
        return self.docref.page if self.docref else -1


TextAdvices = list[TextAdvice]


@dataclasses.dataclass
class TextAdviceReplacement(TextAdvice):
    hint: str = None


@dataclasses.dataclass
class TextAdviceDelete(TextAdvice):
    pass
