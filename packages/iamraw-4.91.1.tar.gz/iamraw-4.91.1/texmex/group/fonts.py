# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import collections
import statistics

import utilo

import iamraw
import texmex
import texmex.nav
import texmex.text


def fontdistance(bounds: iamraw.BoundingBoxes) -> utilo.Floats:
    """Describes the difference between two content lines"""
    distance = [
        utilo.roundme(second.y0 - first.y1)
        for (first), (second) in zip(bounds[0:], bounds[1:])
    ]
    return distance


def feeddistance(bounds: iamraw.BoundingBoxes) -> utilo.Floats:
    """The text feed describes the distance from the left content border to
    the first content. The feeddistance describes the difference of two
    items"""
    distance = [
        utilo.roundme(second.x0 - first.x0)
        for (first), (second) in zip(bounds[0:], bounds[1:])
    ]
    return distance


def fontdistance_textbounds(bounds: texmex.text.TextBoundsList) -> utilo.Floats:
    assert isinstance(bounds, list)
    assert all(isinstance(item, texmex.text.TextBounds) for item in bounds)
    distance = [
        utilo.roundme(first.bottomdist - second.bottomdist)
        for (first), (second) in zip(bounds[0:], bounds[1:])
    ]
    if bounds:
        # add distance from first content to page start
        # xdist, ydist(1), width, height, fontsize
        distance.insert(0, 0)
    distance.append(0)  # TODO: CHECK AGAIN
    return distance


NONE_BORDER = iamraw.Border(None, None, None, None)


def bounds_to_textbounds(
    bounds: iamraw.BoundingBox,
    contentborder: iamraw.Border = None,
    digits: int = 1,
) -> texmex.text.TextBounds:
    """Compute distance to page `contentborder` and determine font size

    Args:
        bounds(iamraw.BoundingBox): BoundingBox of item
        contentborder(Border): the border of page content if None (0,0) is used
        digits(int): accuracy of bounding component
    Returns:
        computed `TextBounds`
    """
    assert contentborder, contentborder
    x0, y0, x1, y1 = bounds
    data = utilo.roundme(
        x0 - contentborder.left,
        contentborder.right - x1,
        y0 - contentborder.top,
        contentborder.bottom - y1,
        digits=digits,
    )
    return texmex.text.TextBounds(*data)


def textbounds(
    navigator: texmex.nav.PTN,
    contentborder: iamraw.Border,
) -> texmex.text.TextBoundsInfos:
    assert isinstance(navigator, texmex.NavigatorMixin), type(navigator)

    # ensure that order of items has no effect
    cb = contentborder  # pylint:disable=C0103
    __x0, __y0, __x1, __y1 = cb.left, cb.top, cb.right, cb.bottom
    if not navigator:
        return []

    result = [
        texmex.TextBoundsInfo(
            text=item.text,
            bounds=bounds_to_textbounds(item.bounding, contentborder),
        ) for item in navigator
    ]
    return result


def textsize(occurrences: texmex.text.FontOccurrences) -> int:
    """Compute size of text"""
    mostly = sorted(occurrences, key=lambda item: item[1], reverse=True)
    if not mostly:
        return None
    most_font_item = mostly[0]
    size = most_font_item[0]
    return size


def textsize_frompage(navigator: 'texmex.NavigatorMixin') -> float:
    collected = []
    for line in navigator:
        fontsizes = texmex.TextStyle.textsizes(
            line.style,
            method=lambda x: x,  # do not filter anything
        )
        collected.extend(fontsizes)
    return utilo.mode(collected, minimize=True)


def document_textfeed(
    navigators: texmex.nav.PTNs,
    count: int = 1,
    left: bool = True,
) -> utilo.Ints:
    assert count >= 1, f'require none negative count, got: {count}'
    counter = collections.Counter()
    for navigator in navigators:
        for item in navigator:
            if not item.text.strip():
                continue
            if left:
                distance = item.bounding[0]
            else:
                distance = navigator.width - item.bounding[2]
            distance = utilo.roundme(distance, digits=1)
            counter[distance] += 1
    result = counter.most_common(count)
    result = [item for item, _ in result]
    if not result:
        # no text data
        return None
    if count == 1:
        return result[0]
    return result[0:count]


def document_textsize(navigators) -> float:
    """Determine the most common text size"""
    collected = []
    for navigator in navigators:
        for line in navigator:
            fontsizes = texmex.TextStyle.textsizes(
                line.style,
                method=lambda x: x,  # do not filter anything
            )
            collected.extend(fontsizes)
    if not collected:
        return None
    return statistics.mode(collected)


def document_textdistance(
    navigators,
    borders: iamraw.Borders,
    digits: int = 1,
) -> int:
    """Determine the most common text distance"""
    data = [
        texmex.PTCN(
            ptn=navigator,
            content=contentborder.border,
        ) for navigator, contentborder in utilo.sync_pages(
            (navigators, borders),
            numbers=False,
        ) if navigator
    ]
    result = document_textdist_from_ptcns(data, digits=digits)
    return result


def document_textdist_from_ptcns(
    navigators: 'texmex.PTCNs',
    digits: int = 1,
) -> float:
    """Determine the most common text distance"""
    result = []
    for navigator in navigators:
        if not navigator:
            # empty page
            continue
        bounds = texmex.textbounds(navigator, navigator.content)
        # ignore empty content
        bounds = [item.bounds for item in bounds if item.text.strip()]
        ydist = [item.bottomdist for item in bounds]
        for yfirst, ysecond in zip(ydist[:-1], ydist[1:]):
            distance = yfirst - ysecond
            result.append(distance)
    if not result:
        return None
    result = utilo.roundme(result, digits=digits, convert=False)  # pylint:disable=R0204
    mode = utilo.modes(result)
    return mode
