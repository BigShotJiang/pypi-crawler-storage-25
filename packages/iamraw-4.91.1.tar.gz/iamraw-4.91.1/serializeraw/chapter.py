# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import configos
import utilo


def dump_chapter(chapters: list[dict]) -> str:
    result = []
    for item in chapters:
        level, title, content = item['level'], item['title'], item['content']
        result.append({
            'level': level,
            'title': title,
            'content': content,
        })
    dumped = utilo.yaml_dump(result)
    return dumped


@configos.cache_small
def load_chapter(content: str) -> list[dict]:
    loaded = utilo.yaml_load(content)
    return loaded
