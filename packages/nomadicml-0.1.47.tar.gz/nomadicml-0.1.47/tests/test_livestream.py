"""
Unit tests for the NomadicML LiveStreamClient.

No real network traffic is made — _make_request is stubbed per test.
Run with:  pytest sdk/tests/test_livestream.py -v
"""
import time
import pytest

from nomadicml import NomadicML, LiveStreamClient, LiveSessionStatus


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def client():
    return NomadicML(api_key="test_api_key")


@pytest.fixture
def ls(client):
    return client.livestream


def stub_request(client, monkeypatch, return_value: dict):
    """Patch _make_request to return a fixed response."""
    def fake(*args, **kwargs):
        _ = args, kwargs
        return type("R", (), {"json": lambda _: return_value})()
    monkeypatch.setattr(client, "_make_request", fake)


def stub_request_sequence(client, monkeypatch, responses: list[dict]):
    """Patch _make_request to return each dict in sequence."""
    it = iter(responses)
    def fake(*args, **kwargs):
        _ = args, kwargs
        payload = next(it)
        return type("R", (), {"json": lambda _: payload})()
    monkeypatch.setattr(client, "_make_request", fake)


def _session(status="ACTIVE", chunk_count=3, events=None):
    return {
        "session_id": "sess_abc",
        "stream_id": "stream_123",
        "name": "Test session",
        "source_url": "https://example.com/stream.m3u8",
        "status": status,
        "created_by": "user_xyz",
        "chunk_count": chunk_count,
        "chunks": [],
        "events": events or [],
    }


# ---------------------------------------------------------------------------
# Client wiring
# ---------------------------------------------------------------------------

class TestClientWiring:
    def test_livestream_property_returns_live_stream_client(self, client):
        assert isinstance(client.livestream, LiveStreamClient)

    def test_livestream_property_is_cached(self, client):
        assert client.livestream is client.livestream


# ---------------------------------------------------------------------------
# attach_stream
# ---------------------------------------------------------------------------

# class TestAttachStream:
#     def test_returns_ok(self, client, ls, monkeypatch):
#         calls = []
#         def fake_request(method, endpoint, **kwargs):
#             calls.append({"method": method, "endpoint": endpoint, "kwargs": kwargs})
#             return type("R", (), {"json": lambda _: {"ok": True}})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         result = ls.attach_stream("stream_123", "Highway cam", "https://example.com/s.m3u8")

#         assert result == {"ok": True}
#         assert calls[0]["method"] == "POST"
#         assert calls[0]["endpoint"] == "/api/live/attach-stream"
#         assert calls[0]["kwargs"]["data"]["stream_id"] == "stream_123"


# ---------------------------------------------------------------------------
# start_session
# ---------------------------------------------------------------------------

# class TestStartSession:
#     def test_returns_session_id(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"session_id": "sess_abc"})
#         result = ls.start_session("stream_123", "https://example.com/s.m3u8", "My session")
#         assert result["session_id"] == "sess_abc"

#     def test_includes_rapid_review_query(self, client, ls, monkeypatch):
#         captured = {}
#         def fake_request(method, endpoint, **kwargs):
#             captured.update({"method": method, "endpoint": endpoint, **kwargs})
#             return type("R", (), {"json": lambda _: {"session_id": "s"}})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         ls.start_session("stream_123", "https://example.com/s.m3u8", "name",
#                          rapid_review_query="detect hard braking")

#         assert captured["data"]["rapid_review_query"] == "detect hard braking"

#     def test_omits_rapid_review_query_when_none(self, client, ls, monkeypatch):
#         captured = {}
#         def fake_request(method, endpoint, **kwargs):
#             captured.update({"method": method, "endpoint": endpoint, **kwargs})
#             return type("R", (), {"json": lambda _: {"session_id": "s"}})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         ls.start_session("stream_123", "https://example.com/s.m3u8", "name")

#         assert "rapid_review_query" not in captured.get("data", {})


# ---------------------------------------------------------------------------
# end_session
# ---------------------------------------------------------------------------

# class TestEndSession:
#     def test_returns_ended(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"status": "ended"})
#         assert ls.end_session("stream_123", "sess_abc")["status"] == "ended"

#     def test_returns_already_ended(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"status": "already_ended"})
#         assert ls.end_session("stream_123", "sess_abc")["status"] == "already_ended"


# ---------------------------------------------------------------------------
# get_sessions
# ---------------------------------------------------------------------------

# class TestGetSessions:
#     def test_returns_list(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"sessions": [_session()]})
#         sessions = ls.get_sessions()
#         assert isinstance(sessions, list)
#         assert sessions[0]["session_id"] == "sess_abc"

#     def test_empty(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"sessions": []})
#         assert ls.get_sessions() == []

#     def test_org_scope_passed_as_param(self, client, ls, monkeypatch):
#         captured = {}
#         def fake_request(method, endpoint, **kwargs):
#             captured.update({"method": method, "endpoint": endpoint, **kwargs})
#             return type("R", (), {"json": lambda _: {"sessions": []}})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         ls.get_sessions(scope="org")

#         assert captured.get("params") == {"scope": "org"}


# ---------------------------------------------------------------------------
# get_session
# ---------------------------------------------------------------------------

# class TestGetSession:
#     def test_returns_session(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session())
#         session = ls.get_session("stream_123", "sess_abc")
#         assert session["status"] == "ACTIVE"

#     def test_endpoint_includes_ids(self, client, ls, monkeypatch):
#         captured = {}
#         def fake_request(method, endpoint, **kwargs):
#             captured.update({"method": method, "endpoint": endpoint, **kwargs})
#             return type("R", (), {"json": lambda _: _session()})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         ls.get_session("stream_123", "sess_abc")

#         assert captured["endpoint"] == "/api/live/live-sessions/stream_123/sess_abc"


# ---------------------------------------------------------------------------
# get_signed_manifest
# ---------------------------------------------------------------------------

# class TestGetSignedManifest:
#     def test_returns_manifest_url(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, {"url": "https://storage.example.com/signed", "expires_at": "2099-01-01T00:00:00Z", "method": "GET"})
#         result = ls.get_signed_manifest("sess_abc")
#         assert "url" in result
#         assert "expires_at" in result
#         assert result["method"] == "GET"

#     def test_endpoint_includes_session_id(self, client, ls, monkeypatch):
#         captured = {}
#         def fake_request(method, endpoint, **kwargs):
#             captured.update({"method": method, "endpoint": endpoint, **kwargs})
#             return type("R", (), {"json": lambda _: {"url": "https://...", "expires_at": "2099-01-01T00:00:00Z", "method": "GET"}})()
#         monkeypatch.setattr(client, "_make_request", fake_request)

#         ls.get_signed_manifest("sess_abc")

#         assert captured["endpoint"] == "/api/live/session/sess_abc/signed-manifest"


# ---------------------------------------------------------------------------
# monitor_session
# ---------------------------------------------------------------------------

# class TestMonitorSession:
#     def test_returns_immediately_when_finished(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session(status="FINISHED"))
#         result = ls.monitor_session("stream_123", "sess_abc", poll_interval=0)
#         assert result["status"] == "FINISHED"

#     def test_polls_until_terminal(self, client, ls, monkeypatch):
#         stub_request_sequence(client, monkeypatch, [
#             _session(status="ACTIVE"),
#             _session(status="ACTIVE"),
#             _session(status="FINISHED"),
#         ])
#         monkeypatch.setattr(time, "sleep", lambda _: None)

#         result = ls.monitor_session("stream_123", "sess_abc", poll_interval=1)
#         assert result["status"] == "FINISHED"

#     def test_fires_on_update_callback(self, client, ls, monkeypatch):
#         stub_request_sequence(client, monkeypatch, [
#             _session(status="ACTIVE"),
#             _session(status="FINISHED"),
#         ])
#         monkeypatch.setattr(time, "sleep", lambda _: None)

#         statuses = []
#         ls.monitor_session("stream_123", "sess_abc", poll_interval=0,
#                            on_update=lambda s: statuses.append(s["status"]))

#         assert statuses == ["ACTIVE", "FINISHED"]

#     def test_raises_timeout_error(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session(status="ACTIVE"))
#         monkeypatch.setattr(time, "sleep", lambda _: None)
#         times = iter([0.0, 0.0, 999.0])
#         monkeypatch.setattr(time, "monotonic", lambda: next(times))

#         with pytest.raises(TimeoutError):
#             ls.monitor_session("stream_123", "sess_abc", poll_interval=0, timeout=10)

#     def test_handles_failed_status(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session(status="FAILED"))
#         result = ls.monitor_session("stream_123", "sess_abc", poll_interval=0)
#         assert result["status"] == "FAILED"

#     def test_bad_callback_does_not_abort(self, client, ls, monkeypatch):
#         stub_request_sequence(client, monkeypatch, [
#             _session(status="ACTIVE"),
#             _session(status="FINISHED"),
#         ])
#         monkeypatch.setattr(time, "sleep", lambda _: None)

#         result = ls.monitor_session("stream_123", "sess_abc", poll_interval=0,
#                                     on_update=lambda _: (_ for _ in ()).throw(RuntimeError("boom")))
#         assert result["status"] == "FINISHED"


# ---------------------------------------------------------------------------
# iter_events
# ---------------------------------------------------------------------------

# class TestIterEvents:
#     def test_yields_new_events_across_polls(self, client, ls, monkeypatch):
#         event_a = {"type": "Safety Alert", "description": "Hard braking"}
#         event_b = {"type": "Drive Quality", "description": "Lane departure"}

#         stub_request_sequence(client, monkeypatch, [
#             _session(status="ACTIVE", events=[event_a]),
#             _session(status="ACTIVE", events=[event_a, event_b]),
#             _session(status="FINISHED", events=[event_a, event_b]),
#         ])
#         monkeypatch.setattr(time, "sleep", lambda _: None)

#         collected = list(ls.iter_events("stream_123", "sess_abc", poll_interval=0))

#         assert len(collected) == 2
#         assert collected[0]["description"] == "Hard braking"
#         assert collected[1]["description"] == "Lane departure"

#     def test_stops_when_finished(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session(status="FINISHED"))
#         assert list(ls.iter_events("stream_123", "sess_abc", poll_interval=0)) == []

#     def test_stops_at_timeout(self, client, ls, monkeypatch):
#         stub_request(client, monkeypatch, _session(status="ACTIVE"))
#         monkeypatch.setattr(time, "sleep", lambda _: None)
#         times = iter([0.0, 0.0, 999.0])
#         monkeypatch.setattr(time, "monotonic", lambda: next(times))

#         assert list(ls.iter_events("stream_123", "sess_abc", poll_interval=0, timeout=10)) == []

# ---------------------------------------------------------------------------
# Live example (requires real API key — skipped in CI)
#
# Set your key via env var and run:
#   NOMADICML_API_KEY=sk-... pytest sdk/tests/test_livestream.py::test_live_example -v -s
# ---------------------------------------------------------------------------

import os

STREAM_ID  = "IQGQLpd2SfRCzYlpCuPB"
SOURCE_URL = "https://stream.nomadicml.com/stream.m3u8"

def test_live_example():
    """End-to-end smoke test against the real API. Run manually only."""
    api_key = os.environ.get("NOMADICML_API_KEY")
    if not api_key:
        pytest.skip("Set NOMADICML_API_KEY env var to run this test")

    client = NomadicML(api_key=api_key)

    # Start a session
    result = client.livestream.start_session(
        stream_id=STREAM_ID,
        source_url=SOURCE_URL,
        name="SDK live test",
        rapid_review_query="detect any safety events",
    )
    session_id = result["session_id"]
    print(f"\nStarted session: {session_id}")

    # Stream events for up to 60 seconds then stop
    for event in client.livestream.iter_events(STREAM_ID, session_id,
                                               poll_interval=10, timeout=60):
        print(f"  EVENT: [{event.get('type')}] {event.get('description')}")

    # End the session
    client.livestream.end_session(stream_id=STREAM_ID, session_id=session_id)
    print("Session ended.")

    # Fetch final state
    final = client.livestream.get_session(STREAM_ID, session_id)
    print(f"Final status: {final['status']}  chunks: {final['chunk_count']}")
    assert final["status"] in ("FINISHED", "ENDING")
