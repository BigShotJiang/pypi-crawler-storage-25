"""VaultLayer CLI -- vaultlayer ps
Shows all active and recent jobs with live status.
Queries the API for job history (Supabase-backed).
Falls back to Redis for live agent-managed jobs.
"""
import asyncio
import click
import os
from pathlib import Path


@click.command()
@click.option("--all", "show_all", is_flag=True, default=False, help="Show completed jobs too")
def ps(show_all):
    """Show all active and recent VaultLayer jobs."""
    asyncio.run(_ps(show_all))


async def _ps(show_all: bool):
    try:
        from shared.env_utils import load_vaultlayer_env
        load_vaultlayer_env()

        # Try API first (works for remote CLI jobs)
        from shared.api_utils import get_token as _get_token, get_api_url as _get_api_url
        token = _get_token()
        api_url = _get_api_url()
        api_jobs = []
        if token:
            try:
                import httpx
                resp = httpx.get(
                    f"{api_url}/api/v1/jobs",
                    headers={"Authorization": f"Bearer {token}"},
                    params={"limit": 20, "include_completed": "true" if show_all else "false"},
                    timeout=8,
                )
                if resp.status_code == 200:
                    api_jobs = resp.json().get("jobs", [])
            except Exception:
                pass

        # Also try Redis for live agent-managed jobs
        keys = []
        try:
            from shared.config import load_config
            from shared.queue import AgentQueue
            config = load_config()
            if config.redis:
                queue = AgentQueue(config.redis.url)
                await queue.connect()
                redis = queue._redis
                keys = await redis.keys("vaultlayer:job:*")
                await queue.disconnect()
        except Exception:
            pass

        if not keys and not api_jobs:
            click.echo("  No active jobs found.")
            click.echo("  Start one with:  vaultlayer run python train.py")
            return

        import json
        from datetime import datetime
        G, Y, R, BO = "\033[97m", "\033[97m", "\033[0m", "\033[1m"

        click.echo("")
        click.echo(f"  {BO}{'JOB ID':<38} {'STATUS':<12} {'PROVIDER':<12} {'GPU':<10} {'DURATION':>10} {'COST':>8}{R}")
        click.echo(f"  {Y}{chr(9472)*92}{R}")

        # Display API jobs first
        for job in api_jobs:
            job_id = job.get("job_id", "?")[:36]
            status = job.get("status", "?")[:10]
            provider = job.get("provider", "?")[:10]
            gpu = job.get("gpu_type", "?")[:8]
            billing_s = job.get("billing_seconds", 0) or 0
            duration = f"{billing_s//3600}h{(billing_s%3600)//60}m{billing_s%60}s" if billing_s else "-"
            cost = f"${job.get('estimated_cost_usd', 0) or 0:.3f}"
            col = G if status == "running" else ""
            click.echo(f"  {job_id:<38} {col}{status:<12}{R} {provider:<12} {gpu:<10} {duration:>10} {cost:>8}")

        for key in keys:
            raw = await redis.get(key)
            if not raw: continue
            try:
                job = json.loads(raw)
            except Exception:
                continue
            status = job.get("status", "unknown")
            if not show_all and status in ("completed", "failed"):
                continue
            job_id    = job.get("job_id", "?")[:8]
            name      = job.get("name", "?")[:22]
            provider  = job.get("provider", "?")[:12]
            step      = job.get("current_step", 0)
            started   = job.get("started_at", "")
            elapsed   = ""
            if started:
                try:
                    dt = datetime.fromisoformat(started.replace("Z",""))
                    secs = (datetime.utcnow() - dt).total_seconds()
                    elapsed = f"{int(secs//3600)}h{int((secs%3600)//60)}m"
                except Exception:
                    elapsed = "-"
            col = G if status == "running" else (Y if "migrat" in status else "")
            click.echo(f"  {job_id:<12} {name:<24} {col}{status:<14}{R} {provider:<14} {step:>8,} {elapsed:>10}")

        # Show monthly spend summary if user is identifiable
        try:
            _user_id = os.environ.get("VAULTLAYER_USER_ID", "")
            if _user_id:
                from shared.usage_tracker import get_monthly_usage
                usage = get_monthly_usage(_user_id)
                month = usage["month"]
                gpu_h = usage["gpu_hours"]
                usd   = usage["total_usd"]
                live  = usage["live_spend_usd"]
                jobs  = usage["total_jobs"]
                click.echo(
                    f"  {BO}Monthly usage ({month}):{R}  "
                    f"{gpu_h:.2f} GPU-hrs  |  "
                    f"${usd:.2f} total  |  "
                    f"${live:.2f} running  |  "
                    f"{jobs} jobs"
                )
        except Exception:
            pass

        click.echo("")
        click.echo(f"  Dashboard: https://vaultlayer.pages.dev")
        click.echo("")
    except Exception as e:
        click.echo(f"  Error fetching jobs: {e}")
        click.echo("  Try: vaultlayer init  to configure credentials.")