
__name__ = 'tinybird'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/forward/commands'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '4.4.2'
__revision__ = '026901c'
