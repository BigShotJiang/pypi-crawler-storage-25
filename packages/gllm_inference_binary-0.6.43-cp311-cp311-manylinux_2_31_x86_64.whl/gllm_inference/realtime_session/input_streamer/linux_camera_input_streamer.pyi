from _typeshed import Incomplete
from gllm_inference.realtime_session.constants import InputImageConfig as InputImageConfig
from gllm_inference.realtime_session.input_streamer.input_streamer import BaseInputStreamer as BaseInputStreamer
from gllm_inference.realtime_session.schema import RealtimeEvent as RealtimeEvent

class LinuxCameraInputStreamer(BaseInputStreamer):
    """[BETA] A Linux camera input streamer that emits image events.

    Attributes:
        state (RealtimeState): The state of the input streamer.
        input_queue (asyncio.Queue[RealtimeEvent]): The queue to put the input events.
        device_path (str): Linux camera device path.
        fps (int): Target capture FPS.
    """
    device_path: Incomplete
    fps: Incomplete
    def __init__(self, device_path: str = ..., fps: int = ...) -> None:
        """Initializes the LinuxCameraInputStreamer.

        Args:
            device_path (str, optional): Linux camera device path. Defaults to InputImageConfig.DEVICE_PATH.
            fps (int, optional): Target capture FPS. Defaults to InputImageConfig.FPS.

        Raises:
            ValueError: If the current system is not Linux.
        """
    async def stream_input(self) -> None:
        """Streams camera frames from Linux camera device.

        This method is used to stream the camera frames from the Linux camera device to the input queue.
        It captures the camera frames and emits them as image events.

        Raises:
            RuntimeError: If the Linux camera stream fails.
        """
    async def close(self) -> None:
        """Closes the LinuxCameraInputStreamer.

        This method is used to close the LinuxCameraInputStreamer.
        It is used to clean up the camera stream.
        """
