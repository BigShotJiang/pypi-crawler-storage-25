class InputImageConfig:
    """Defines constants for input image processing."""
    DEVICE_PATH: str
    FPS: int
    MAX_CONSECUTIVE_READ_ERRORS: int
    RETRY_BACKOFF_SECONDS: float
