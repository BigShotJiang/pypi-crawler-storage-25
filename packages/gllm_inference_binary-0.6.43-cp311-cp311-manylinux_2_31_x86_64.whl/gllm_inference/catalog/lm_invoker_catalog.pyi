from _typeshed import Incomplete
from gllm_inference.catalog.catalog import BaseCatalog as BaseCatalog
from gllm_inference.lm_invoker import build_lm_invoker as build_lm_invoker
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.schema import ThinkingConfig as ThinkingConfig

MODEL_ID_ENV_VAR_REGEX_PATTERN: str
LM_INVOKER_REQUIRED_COLUMNS: Incomplete
LM_INVOKER_OPTIONAL_COLUMNS: Incomplete
CONFIG_SCHEMA_MAP: Incomplete
logger: Incomplete

class LMInvokerCatalog(BaseCatalog[BaseLMInvoker]):
    '''Loads multiple LM invokers from certain sources.

    Attributes:
        components (dict[str, BaseLMInvoker]): Dictionary of the loaded LM invokers.

    Initialization:
        # Example 1: Load from Google Sheets using client email and private key
        ```python
        catalog = LMInvokerCatalog.from_gsheets(
            sheet_id="...",
            worksheet_id="...",
            client_email="...",
            private_key="...",
        )

        lm_invoker = catalog.name
        ```

        # Example 2: Load from CSV
        ```python
        catalog = LMInvokerCatalog.from_csv(csv_path="...")
        lm_invoker = catalog.name
        ```

        # Example 3: Load from record/JSON file
        ```python
        import json

        records = [
            {
                "name": "answer_question",
                "model_id": "openai/gpt-5-nano",
                "credentials": "OPENAI_API_KEY",
                "config": "{}",
                "system_template": "You are a helpful assistant.",
                "user_template": "{query}",
                "prompt_builder_kwargs": json.dumps({"use_jinja": True}),
            }
        ]

        catalog = LMInvokerCatalog.from_records(records=records)
        lm_invoker = catalog.answer_question
        ```

    Template Example:
        For template examples compatible with LMInvokerCatalog, refer to:
        1. CSV: https://github.com/GDP-ADMIN/gl-sdk/tree/main/libs/gllm-inference/gllm_inference/resources/catalog/lm_invoker_catalog_template.csv
        2. JSON: https://github.com/GDP-ADMIN/gl-sdk/tree/main/libs/gllm-inference/gllm_inference/resources/catalog/lm_invoker_catalog_template.json

    Template Explanation:
        Required columns:
        1. name (str): The name of the LM invoker.
        2. model_id (str): The model ID of the LM invoker.
        3. credentials (str | json_str): The credentials of the LM invoker.
        4. config (json_str): Additional configuration for the LM invoker.

        Optional prompt-builder columns:
        1. system_template (str): The system template used for `lm_invoker.prompt.build(...)`.
        2. user_template (str): The user template used for `lm_invoker.prompt.build(...)`.
        3. prompt_builder_kwargs (json_str): Additional prompt builder kwargs.

        Important Notes:
        1. If any prompt-builder input has a non-empty value, the invoker will call
            `build_lm_invoker(...).prompt.build(...)`.
        2. If no prompt-builder input has a non-empty value, the invoker is created using only `build_lm_invoker(...)`.
        3. The `model_id` can load environment variables using "${ENV_VAR_KEY}" syntax.
        4. `credentials` and `config` are optional in value; empty values use default invoker behavior.
    '''
