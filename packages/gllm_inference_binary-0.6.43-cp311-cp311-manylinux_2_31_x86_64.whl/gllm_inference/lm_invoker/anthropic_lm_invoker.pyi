from _typeshed import Incomplete
from anthropic.types import Message as Message
from functools import cached_property
from gllm_core.retry import RetryConfig
from gllm_inference.constants import INVOKER_DEFAULT_TIMEOUT as INVOKER_DEFAULT_TIMEOUT, INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.input_transformer import InputTransformer as InputTransformer
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.lm_invoker.operations.batch_operations import AnthropicBatchOperations as AnthropicBatchOperations
from gllm_inference.lm_invoker.operations.file_operations import AnthropicFileOperations as AnthropicFileOperations
from gllm_inference.lm_invoker.operations.skill_operations import AnthropicSkillOperations as AnthropicSkillOperations
from gllm_inference.lm_invoker.schema.anthropic import InputType as InputType, Key as Key, OutputType as OutputType
from gllm_inference.output_transformer import OutputTransformer as OutputTransformer, OutputTransformerChain as OutputTransformerChain
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, CodeEvent as CodeEvent, CodeExecResult as CodeExecResult, ContextWindow as ContextWindow, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMOutputItem as LMOutputItem, LMOutputType as LMOutputType, LMTool as LMTool, ModelId as ModelId, ModelProvider as ModelProvider, NativeTool as NativeTool, NativeToolType as NativeToolType, OutputTransformerType as OutputTransformerType, ResponseEvent as ResponseEvent, ResponseSchema as ResponseSchema, Thinking as Thinking, ThinkingConfig as ThinkingConfig, ThinkingEvent as ThinkingEvent, TokenUsage as TokenUsage, ToolCall as ToolCall, ToolResult as ToolResult, URLAttachment as URLAttachment, UploadedAttachment as UploadedAttachment
from typing import Any

DEFAULT_MAX_TOKENS: int
DEFAULT_THINKING_BUDGET: int
VALID_SKILL_TYPES: Incomplete

class AnthropicLMInvoker(BaseLMInvoker):
    '''A language model invoker to interact with Anthropic language models.

    Examples:
        ```python
        lm_invoker = AnthropicLMInvoker(model_name="claude-sonnet-4-6")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Document
           c. Image
        5. Structured output
        6. Tool calling
        7. Native tools
           a. Code interpreter
           b. Skill
           c. Web search
        8. Thinking
        9. Output analytics
        10. Retry and timeout
        11. Extra capabilities
           a. Input transformer
           b. Output transformer
           c. Batch invocation
           d. File management
           e. Skill management

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        client (AsyncAnthropic): The Anthropic client instance.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): Tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        input_transformers (list[InputTransformerConfig]): The list of input transformer configs to use.
        output_transformers (list[OutputTransformerConfig]): The list of output transformer configs to use.
    '''
    client: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, input_transformers: list[InputTransformer] | None = None, output_transformers: list[OutputTransformer] | None = None, input_transformer: InputTransformerType | None = None, output_transformer: OutputTransformerType | None = None) -> None:
        """Initializes the AnthropicLmInvoker instance.

        Args:
            model_name (str): The name of the Anthropic language model.
            api_key (str | None, optional): The Anthropic API key. Defaults to None, in which case the
                `ANTHROPIC_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the Anthropic client.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None, in which case an empty list is used.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            input_transformers (list[InputTransformer] | None, optional): The list of input transformers to use.
                Defaults to None, in which case no input transformers will be used.
            output_transformers (list[OutputTransformer] | None, optional): The list of output transformers to use.
                Defaults to None, in which case no output transformers will be used.
            input_transformer (InputTransformerType | None, optional): Deprecated param to define input transformer.
                Will be removed in v0.7. Defaults to None.
            output_transformer (OutputTransformerType | None, optional): Deprecated param to define output transformer.
                Will be removed in v0.7. Defaults to None.

        Raises:
            ValueError: if `response_schema` is provided, but `tools` or `thinking` are also provided.
        """
    @cached_property
    def batch(self) -> AnthropicBatchOperations:
        """The batch operations for the language model.

        Returns:
            AnthropicBatchOperations: The batch operations for the language model.
        """
    @cached_property
    def file(self) -> AnthropicFileOperations:
        """The file operations for the language model.

        Returns:
            AnthropicFileOperations: The file operations for the language model.
        """
    @cached_property
    def skill(self) -> AnthropicSkillOperations:
        """The skill operations for the language model.

        Returns:
            AnthropicSkillOperations: The skill operations for the language model.
        """
