from _typeshed import Incomplete
from abc import ABC
from functools import cached_property
from gllm_core.event import EventEmitter
from gllm_core.retry import RetryConfig
from gllm_inference.constants import DOCUMENT_MIME_TYPES as DOCUMENT_MIME_TYPES, INVOKER_DEFAULT_TIMEOUT as INVOKER_DEFAULT_TIMEOUT
from gllm_inference.exceptions import get_error_extractor as get_error_extractor
from gllm_inference.input_transformer import InputTransformer as InputTransformer, InputTransformerChain as InputTransformerChain, InputTransformerConfig as InputTransformerConfig
from gllm_inference.lm_invoker.operations.batch_operations import BatchOperations as BatchOperations
from gllm_inference.lm_invoker.operations.data_store_operations import DataStoreOperations as DataStoreOperations
from gllm_inference.lm_invoker.operations.file_operations import FileOperations as FileOperations
from gllm_inference.lm_invoker.operations.prompt_operations import PromptOperations as PromptOperations
from gllm_inference.lm_invoker.operations.skill_operations import SkillOperations as SkillOperations
from gllm_inference.output_transformer import OutputTransformer as OutputTransformer, OutputTransformerChain as OutputTransformerChain, OutputTransformerConfig as OutputTransformerConfig
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, ContextWindow as ContextWindow, InputTransformerType as InputTransformerType, LMInput as LMInput, LMOutput as LMOutput, LMOutputType as LMOutputType, LMTool as LMTool, Message as Message, MessageContent as MessageContent, MessageRole as MessageRole, ModelId as ModelId, NativeTool as NativeTool, NativeToolType as NativeToolType, OutputTransformerType as OutputTransformerType, ResponseSchema as ResponseSchema, Thinking as Thinking, ThinkingConfig as ThinkingConfig, ToolCall as ToolCall, ToolResult as ToolResult, URLAttachment as URLAttachment, UploadedAttachment as UploadedAttachment
from typing import Any

class Key:
    """Defines valid keys in LM invokers JSON schema."""
    ADDITIONAL_PROPERTIES: str
    ANY_OF: str
    DATA_TYPE: str
    DATA_VALUE: str
    DEFAULT: str
    ID: str
    PROPERTIES: str
    REQUIRED: str
    TITLE: str
    TYPE: str

class InputType:
    """Defines valid input types in LM invokers JSON schema."""
    NULL: str

class BaseLMInvoker(ABC):
    """A base class for language model invokers used in Gen AI applications.

    The `BaseLMInvoker` class provides a framework for invoking language models.
    It handles both standard and streaming invocation.

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        default_config (dict[str, Any]): Default config for invoking the language model.
        tools (list[Tool]): Tools provided to the language model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        input_transformers (list[InputTransformerConfig]): The list of input transformer configs to use.
        output_transformers (list[OutputTransformerConfig]): The list of output transformer configs to use.
    """
    default_config: Incomplete
    response_schema: Incomplete
    thinking: Incomplete
    output_analytics: Incomplete
    retry_config: Incomplete
    input_transformers: Incomplete
    output_transformers: Incomplete
    def __init__(self, model_id: ModelId, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, input_transformers: list[InputTransformer] | None = None, output_transformers: list[OutputTransformer] | None = None, input_transformer: InputTransformerType | None = None, output_transformer: OutputTransformerType | None = None, thinking: bool | ThinkingConfig = False) -> None:
        """Initializes a new instance of the BaseLMInvoker class.

        Args:
            model_id (ModelId): The model ID of the language model.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the
                language model. Defaults to None, in which case an empty dictionary is used.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None, in which case an empty list is used.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            input_transformers (list[InputTransformer] | None, optional): The list of input transformers to use.
                Defaults to None, in which case no input transformers will be used.
            output_transformers (list[OutputTransformer] | None, optional): The list of output transformers to use.
                Defaults to None, in which case no output transformers will be used.
            input_transformer (InputTransformerType | None, optional): Deprecated param to define input transformer.
                Will be removed in v0.7. Defaults to None.
            output_transformer (OutputTransformerType | None, optional): Deprecated param to define output transformer.
                Will be removed in v0.7. Defaults to None.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
        """
    @property
    def model_id(self) -> str:
        """The model ID of the language model.

        Returns:
            str: The model ID of the language model.
        """
    @property
    def model_provider(self) -> str:
        """The provider of the language model.

        Returns:
            str: The provider of the language model.
        """
    @property
    def model_name(self) -> str:
        """The name of the language model.

        Returns:
            str: The name of the language model.
        """
    @cached_property
    def batch(self) -> BatchOperations:
        """The batch operations for the language model.

        Returns:
            BatchOperations: The batch operations for the language model.
        """
    @cached_property
    def data_store(self) -> DataStoreOperations:
        """The data store operations for the language model.

        Returns:
            DataStoreOperations: The data store operations for the language model.
        """
    @cached_property
    def file(self) -> FileOperations:
        """The file operations for the language model.

        Returns:
            FileOperations: The file operations for the language model.
        """
    @cached_property
    def prompt(self) -> PromptOperations:
        """The prompt operations for the language model.

        Returns:
            PromptOperations: The prompt operations for the language model.
        """
    @cached_property
    def skill(self) -> SkillOperations:
        """The skill operations for the language model.

        Returns:
            SkillOperations: The skill operations for the language model.
        """
    def set_tools(self, tools: list[LMTool]) -> None:
        """Sets the tools for the language model.

        This method sets the tools for the language model. Any existing tools will be replaced.

        Args:
            tools (list[LMTool]): The list of tools to be used.
        """
    def clear_tools(self) -> None:
        """Clears the tools for the language model.

        This method clears the tools for the language model by calling the `set_tools` method with an empty list.
        """
    def set_response_schema(self, response_schema: ResponseSchema | None) -> None:
        """Sets the response schema for the language model.

        This method sets the response schema for the language model. Any existing response schema will be replaced.

        Args:
            response_schema (ResponseSchema | None): The response schema to be used.
        """
    def clear_response_schema(self) -> None:
        """Clears the response schema for the language model.

        This method clears the response schema for the language model by calling the `set_response_schema` method with
        None.
        """
    async def get_context_window(self) -> ContextWindow:
        """Gets the context window for the language model.

        Returns:
            ContextWindow: The context window for the language model.

        Raises:
            TimeoutError: If the context window retrieval times out.
        """
    async def count_input_tokens(self, messages: LMInput) -> int:
        """Counts the input tokens for an invocation request inputs.

        This method counts the input tokens for an invocation request inputs. This method is useful for:
        1. Estimating the cost of an invocation request before invoking the language model.
        2. Checking if the invocation request is too large to be processed by the language model.

        Args:
            messages (LMInput): The input messages for the language model.
                1. If a list of Message objects is provided, it is used as is.
                2. If a list of MessageContent or a string is provided, it is converted into a user message.

        Returns:
            int: The number of input tokens for the invocation request.

        Raises:
            TimeoutError: If the token counting times out.
        """
    async def invoke(self, messages: LMInput, hyperparameters: dict[str, Any] | None = None, event_emitter: EventEmitter | None = None, max_calls: int = 1) -> LMOutput:
        """Invokes the language model.

        This method processes the language model invocation request. If tool calls are present in the output,
        the method will invoke the tools and feed the results back to the language model. This process will repeat
        until the tool calls are no longer present in the output or the maximum number of calls is reached.

        Args:
            messages (LMInput): The input messages for the language model.
                1. If a list of Message objects is provided, it is used as is.
                2. If a list of MessageContent or a string is provided, it is converted into a user message.
            hyperparameters (dict[str, Any] | None, optional): A dictionary of hyperparameters for the language model.
                Defaults to None, in which case the default hyperparameters are used.
            event_emitter (EventEmitter | None, optional): The event emitter for streaming tokens. If provided,
                streaming invocation is enabled. Defaults to None.
            max_calls (int, optional): The max number of times the language model can be invoked.
                Multiple invocations enable automatic tool invocation when needed. Defaults to 1.

        Returns:
            LMOutput: The generated response from the language model.

        Raises:
            ValueError: If `max_calls` is lower than 1.
        """
