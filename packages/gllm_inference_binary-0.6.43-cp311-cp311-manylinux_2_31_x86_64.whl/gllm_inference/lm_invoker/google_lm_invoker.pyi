from _typeshed import Incomplete
from functools import cached_property
from gllm_core.retry import RetryConfig
from gllm_inference.constants import GOOGLE_SCOPES as GOOGLE_SCOPES, SECONDS_TO_MILLISECONDS as SECONDS_TO_MILLISECONDS
from gllm_inference.input_transformer import InputTransformer as InputTransformer
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.lm_invoker.operations.batch_operations import GoogleBatchOperations as GoogleBatchOperations
from gllm_inference.lm_invoker.operations.data_store_operations import GoogleDataStoreOperations as GoogleDataStoreOperations
from gllm_inference.lm_invoker.operations.file_operations import GoogleFileOperations as GoogleFileOperations
from gllm_inference.lm_invoker.schema.google import InputType as InputType, Key as Key
from gllm_inference.output_transformer import OutputTransformer as OutputTransformer, OutputTransformerChain as OutputTransformerChain
from gllm_inference.schema import Attachment as Attachment, AttachmentStore as AttachmentStore, AttachmentType as AttachmentType, CodeEvent as CodeEvent, CodeExecResult as CodeExecResult, ContextWindow as ContextWindow, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMOutputType as LMOutputType, LMTool as LMTool, Message as Message, MessageContent as MessageContent, MessageRole as MessageRole, ModelId as ModelId, ModelProvider as ModelProvider, NativeTool as NativeTool, NativeToolType as NativeToolType, OutputTransformerType as OutputTransformerType, ResponseEvent as ResponseEvent, ResponseSchema as ResponseSchema, StreamBuffer as StreamBuffer, Thinking as Thinking, ThinkingConfig as ThinkingConfig, ThinkingEvent as ThinkingEvent, TokenUsage as TokenUsage, ToolCall as ToolCall, ToolResult as ToolResult, URLAttachment as URLAttachment, UploadedAttachment as UploadedAttachment
from gllm_inference.utils import SizeUnit as SizeUnit, get_size as get_size
from typing import Any

REQUIRE_THINKING_MODEL_SUBSTRING: str
IMAGE_GENERATION_MODEL_SUBSTRING: str
MAX_INLINE_ATTACHMENT_SIZE_MB: int

class URLPattern:
    """Defines specific Google related URL patterns."""
    YOUTUBE: Incomplete

class GoogleLMInvoker(BaseLMInvoker):
    '''A language model invoker to interact with Google language models.

    Examples:
        ```python
        lm_invoker = GoogleLMInvoker(model_name="gemini-2.5-flash")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Authentication:
        The `GoogleLMInvoker` can use either Google Gen AI or Google Vertex AI.

        Google Gen AI is recommended for quick prototyping and development.
        It requires a Gemini API key for authentication.

        Usage example:
        ```python
        lm_invoker = GoogleLMInvoker(
            model_name="gemini-2.5-flash",
            api_key="your_api_key"
        )
        ```

        Google Vertex AI is recommended to build production-ready applications.
        It requires a service account JSON file for authentication.

        Usage example:
        ```python
        lm_invoker = GoogleLMInvoker(
            model_name="gemini-2.5-flash",
            credentials_path="path/to/service_account.json"
        )
        ```

        If neither `api_key` nor `credentials_path` is provided, Google Gen AI will be used by default.
        The `GOOGLE_API_KEY` environment variable will be used for authentication.

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Audio
           c. Document
           d. Image
           e. Video
        5. Structured output
        6. Tool calling
        7. Native tools
           a. Code interpreter
           b. Data store
           c. Image generation
           d. Web search
        8. Thinking
        9. Output analytics
        10. Retry and timeout
        11. Extra capabilities
           a. Input transformer
           b. Output transformer
           c. Batch invocation
           d. File management
           e. Data store management

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        client_params (dict[str, Any]): The Google client instance init parameters.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig | None): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        image_generation (bool): Whether to generate image. Only allowed for image generation models.
        data_stores (list[AttachmentStore]): The data stores to retrieve internal knowledge from.
        auto_upload (bool): Whether to automatically upload attachments to files API if the inputs total
            size exceeds the threshold of 20MB.
        input_transformers (list[InputTransformerConfig]): The list of input transformer configs to use.
        output_transformers (list[OutputTransformerConfig]): The list of output transformer configs to use.
    '''
    auto_upload: Incomplete
    image_generation: Incomplete
    data_stores: Incomplete
    client_params: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, credentials_path: str | None = None, project_id: str | None = None, location: str = 'us-central1', model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig | None = None, data_stores: list[AttachmentStore] | None = None, auto_upload: bool = True, input_transformers: list[InputTransformer] | None = None, output_transformers: list[OutputTransformer] | None = None, input_transformer: InputTransformerType | None = None, output_transformer: OutputTransformerType | None = None) -> None:
        '''Initializes a new instance of the GoogleLMInvoker class.

        Args:
            model_name (str): The name of the model to use.
            api_key (str | None, optional): Required for Google Gen AI authentication. Cannot be used together
                with `credentials_path`. Defaults to None.
            credentials_path (str | None, optional): Required for Google Vertex AI authentication. Path to the service
                account credentials JSON file. Cannot be used together with `api_key`. Defaults to None.
            project_id (str | None, optional): The Google Cloud project ID for Vertex AI. Only used when authenticating
                with `credentials_path`. Defaults to None, in which case it will be loaded from the credentials file.
            location (str, optional): The location of the Google Cloud project for Vertex AI. Only used when
                authenticating with `credentials_path`. Defaults to "us-central1".
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the Google Vertex AI
                client.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            thinking (bool | ThinkingConfig | None, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to None.
            data_stores (list[AttachmentStore] | None, optional): The data stores to retrieve internal knowledge from.
                Defaults to None, in which case no data stores will be used.
            auto_upload (bool, optional): Whether to automatically upload attachments to files API if the inputs total
                size exceeds the threshold of 20MB. Defaults to True.
            input_transformers (list[InputTransformer] | None, optional): The list of input transformers to use.
                Defaults to None, in which case no input transformers will be used.
            output_transformers (list[OutputTransformer] | None, optional): The list of output transformers to use.
                Defaults to None, in which case no output transformers will be used.
            input_transformer (InputTransformerType | None, optional): Deprecated param to define input transformer.
                Will be removed in v0.7. Defaults to None.
            output_transformer (OutputTransformerType | None, optional): Deprecated param to define output transformer.
                Will be removed in v0.7. Defaults to None.

        Note:
            If neither `api_key` nor `credentials_path` is provided, Google Gen AI will be used by default.
            The `GOOGLE_API_KEY` environment variable will be used for authentication.
        '''
    @cached_property
    def batch(self) -> GoogleBatchOperations:
        """The batch operations for the language model.

        Returns:
            GoogleBatchOperations: The batch operations for the language model.
        """
    @cached_property
    def data_store(self) -> GoogleDataStoreOperations:
        """The data store operations for the language model.

        Returns:
            GoogleDataStoreOperations: The data store operations for the language model.
        """
    @cached_property
    def file(self) -> GoogleFileOperations:
        """The file operations for the language model.

        Returns:
            GoogleFileOperations: The file operations for the language model.
        """
    native_tools: Incomplete
    def set_data_stores(self, data_stores: list[AttachmentStore]) -> None:
        """Sets the data stores for the Google language model.

        This method sets the data stores for the Google language model. Any existing data stores will be replaced.

        Args:
            data_stores (list[AttachmentStore]): The list of data stores to be used.
        """
