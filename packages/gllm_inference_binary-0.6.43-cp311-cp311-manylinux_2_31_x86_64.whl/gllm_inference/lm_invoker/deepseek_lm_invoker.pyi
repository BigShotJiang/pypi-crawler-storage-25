from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.input_transformer import InputTransformer as InputTransformer
from gllm_inference.lm_invoker.openai_chat_completions_lm_invoker import OpenAIChatCompletionsLMInvoker as OpenAIChatCompletionsLMInvoker
from gllm_inference.lm_invoker.schema.openai_chat_completions import Key as Key
from gllm_inference.output_transformer import OutputTransformer as OutputTransformer
from gllm_inference.schema import AttachmentType as AttachmentType, LMTool as LMTool, ModelId as ModelId, ModelProvider as ModelProvider, ResponseSchema as ResponseSchema
from typing import Any

DEEPSEEK_URL: str

class DeepSeekLMInvoker(OpenAIChatCompletionsLMInvoker):
    '''A language model invoker to interact with DeepSeek API.

    Examples:
        ```python
        lm_invoker = DeepSeekLMInvoker(model_name="deepseek-v4-flash")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Tool calling
        5. Output analytics
        6. Retry and timeout
        7. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker
    '''
    client_kwargs: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, input_transformers: list[InputTransformer] | None = None, output_transformers: list[OutputTransformer] | None = None) -> None:
        """Initializes a new instance of the DeepSeekLMInvoker class.

        Args:
            model_name (str): The name of the DeepSeek language model.
            api_key (str | None, optional): The API key for authenticating with the DeepSeek API.
                Defaults to None, in which case the `DEEPSEEK_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            input_transformers (list[InputTransformer] | None, optional): The list of input transformers to use.
                Defaults to None, in which case no input transformers will be used.
            output_transformers (list[OutputTransformer] | None, optional): The list of output transformers to use.
                Defaults to None, in which case no output transformers will be used.
        """
    def set_response_schema(self, response_schema: ResponseSchema | None) -> None:
        """Sets the response schema for the DeepSeek API.

        This method raises a `NotImplementedError` because the DeepSeek API does not support response schema.

        Args:
            response_schema (ResponseSchema | None): The response schema to be used.

        Raises:
            NotImplementedError: This method is not supported for the DeepSeek API.
        """
