from gllm_inference.exceptions import SkillOperationError as SkillOperationError
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.schema import Attachment as Attachment, Skill as Skill
from typing import Any

class VersionOperations:
    """Handles version operations for skill sub-namespace.

    Examples:
        1. List versions:
        ```python
        versions = await lm_invoker.skill.version.list(skill_id)
        ```

        2. Create a version:
        ```python
        version = await lm_invoker.skill.version.create(skill_id, file)
        ```

        3. Retrieve a version:
        ```python
        version = await lm_invoker.skill.version.retrieve(skill_id, version)
        ```

        4. Delete a version:
        ```python
        await lm_invoker.skill.version.delete(skill_id, version)
        ```
    """
    def __init__(self, invoker: BaseLMInvoker) -> None:
        """Initializes the version operations.

        Args:
            invoker (BaseLMInvoker): The LM invoker to use for the version operations.
        """
    async def list(self, skill_id: str) -> list[Skill]:
        """Lists all versions of a skill.

        Args:
            skill_id (str): The ID of the skill.

        Returns:
            list[Skill]: The list of skill versions.

        Raises:
            NotImplementedError: The version operation is not supported.
        """
    async def create(self, skill_id: str, file: Attachment, **kwargs: Any) -> Skill:
        """Creates a new version of a skill.

        Args:
            skill_id (str): The ID of the skill.
            file (Attachment): File attachment of the skill version.
            **kwargs (Any): Additional keyword arguments to create a skill version.

        Returns:
            Skill: The created skill version.

        Raises:
            NotImplementedError: The version operation is not supported.
        """
    async def retrieve(self, skill_id: str, version: str) -> Skill:
        """Retrieves a specific version of a skill.

        Args:
            skill_id (str): The ID of the skill.
            version (str): The version identifier.

        Returns:
            Skill: The retrieved skill version.

        Raises:
            NotImplementedError: The version operation is not supported.
        """
    async def delete(self, skill_id: str, version: str) -> None:
        """Deletes a specific version of a skill.

        Args:
            skill_id (str): The ID of the skill.
            version (str): The version identifier to delete.

        Raises:
            NotImplementedError: The version operation is not supported.
        """
    def __init_subclass__(cls, **kwargs: Any):
        """Wrap subclass operation methods to normalize errors.

        Args:
            **kwargs (Any): Additional keyword arguments to initialize the subclass.
        """
