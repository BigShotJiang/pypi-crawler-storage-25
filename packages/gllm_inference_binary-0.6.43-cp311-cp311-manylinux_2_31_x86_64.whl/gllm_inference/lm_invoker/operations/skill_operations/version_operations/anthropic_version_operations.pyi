from gllm_inference.lm_invoker.anthropic_lm_invoker import AnthropicLMInvoker as AnthropicLMInvoker
from gllm_inference.lm_invoker.operations.skill_operations.anthropic_skill_operations import AnthropicSkillOperations as AnthropicSkillOperations
from gllm_inference.lm_invoker.operations.skill_operations.version_operations.version_operations import VersionOperations as VersionOperations
from gllm_inference.schema import Attachment as Attachment, Skill as Skill
from typing import Any

class AnthropicVersionOperations(VersionOperations):
    """Handles skill version operations for the AnthropicLMInvoker class."""
    def __init__(self, invoker: AnthropicLMInvoker, skill_ops: AnthropicSkillOperations) -> None:
        """Initializes the version operations.

        Args:
            invoker (AnthropicLMInvoker): The LM invoker to use for the version operations.
            skill_ops (AnthropicSkillOperations): The parent skill operations instance.
        """
    async def list(self, skill_id: str) -> list[Skill]:
        """Lists all versions of a skill.

        Uses the Anthropic Skills Versions beta API with automatic pagination.

        Args:
            skill_id (str): The skill identifier.

        Returns:
            list[Skill]: List of skill versions.
        """
    async def create(self, skill_id: str, file: Attachment, **kwargs: Any) -> Skill:
        """Creates a new version of a skill.

        Args:
            skill_id (str): The skill identifier.
            file (Attachment): The skill file to upload (ZIP archive or markdown file).
            **kwargs (Any): Additional keyword arguments passed to Anthropic's versions.create.

        Returns:
            Skill: The created skill version.
        """
    async def retrieve(self, skill_id: str, version: str) -> Skill:
        """Retrieves a specific version of a skill.

        Args:
            skill_id (str): The skill identifier.
            version (str): The version identifier.

        Returns:
            Skill: The retrieved skill version.
        """
    async def delete(self, skill_id: str, version: str) -> None:
        """Deletes a specific version of a skill.

        Args:
            skill_id (str): The skill identifier.
            version (str): The version identifier to delete.
        """
