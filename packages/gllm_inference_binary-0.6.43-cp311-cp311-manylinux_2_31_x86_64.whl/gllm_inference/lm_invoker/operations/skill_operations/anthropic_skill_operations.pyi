from functools import cached_property
from gllm_inference.exceptions import SkillOperationError as SkillOperationError
from gllm_inference.lm_invoker.anthropic_lm_invoker import AnthropicLMInvoker as AnthropicLMInvoker
from gllm_inference.lm_invoker.operations.skill_operations.skill_operations import SkillOperations as SkillOperations
from gllm_inference.lm_invoker.operations.skill_operations.version_operations import AnthropicVersionOperations as AnthropicVersionOperations
from gllm_inference.lm_invoker.schema.anthropic import Key as Key
from gllm_inference.schema import Attachment as Attachment, ModelProvider as ModelProvider, Skill as Skill
from typing import Any

SKILL_ZIP_MIME_TYPE: str
SKILL_MARKDOWN_EXTENSION: str
DEFAULT_SKILL_NAME: str
INTERNAL_SERVER_ERROR_MSG: str

class AnthropicSkillOperations(SkillOperations):
    '''Handles skill operations for the AnthropicLMInvoker class.

    Examples:
        1. Create a skill:
        ```python
        file = Attachment.from_path("path/to/file.zip")
        skill = await lm_invoker.skill.create(file=file, name="My Skill")
        ```

        2. List skills:
        ```python
        skills = await lm_invoker.skill.list()
        ```

        3. Retrieve a skill:
        ```python
        skill = await lm_invoker.skill.retrieve(skill_id)
        ```

        4. Delete a skill:
        ```python
        await lm_invoker.skill.delete(skill_id)
        ```

        5. Create a new skill version:
        ```python
        file = Attachment.from_path("path/to/file.zip")
        skill = await lm_invoker.skill.version.create(skill_id, file=file)
        ```

        6. List skill versions:
        ```python
        versions = await lm_invoker.skill.version.list(skill_id)
        ```

        7. Retrieve a specific skill version:
        ```python
        version = await lm_invoker.skill.version.retrieve(skill_id, version="v1")
        ```

        8. Delete a specific skill version:
        ```python
        await lm_invoker.skill.version.delete(skill_id, version="v1")
        ```
    '''
    def __init__(self, invoker: AnthropicLMInvoker) -> None:
        """Initializes the skill operations.

        Args:
            invoker (AnthropicLMInvoker): The LM invoker to use for the skill operations.
        """
    @cached_property
    def version(self) -> AnthropicVersionOperations:
        """Lazy-initialized version operations sub-namespace.

        Returns:
            AnthropicVersionOperations: The version operations handler.
        """
    async def create(self, file: Attachment, name: str | None = None, **kwargs: Any) -> Skill:
        """Creates a new skill.

        Creates a skill via the Anthropic Skills beta API. Skill creation requires uploading
        files that include a SKILL.md at the root directory.

        Args:
            file (Attachment): The skill file to upload (ZIP archive or markdown file).
            name (str | None, optional): The name of the skill. Defaults to None.
            version (str | None, optional): The version of the skill. Defaults to None.
            **kwargs (Any): Skill creation parameters passed to Anthropic's skills.create.

        Returns:
            Skill: The created skill.
        """
    async def list(self) -> list[Skill]:
        """Lists the skills.

        Uses the Anthropic Skills beta API with automatic pagination via AsyncPageCursor.
        Includes defensive check to prevent infinite pagination loops.

        Returns:
            list[Skill]: List of skills.
        """
    async def list_skill(self) -> list[Skill]:
        """Lists the skills.

        Returns:
            list[Skill]: List of skills.
        """
    async def retrieve(self, skill_id: str) -> Skill:
        """Retrieves a skill by ID.

        Args:
            skill_id (str): The skill identifier.

        Returns:
            Skill: The retrieved skill.
        """
    async def delete(self, skill_id: str) -> None:
        """Deletes a skill by ID.

        Deletes all versions of the skill first, then deletes the skill itself.
        Attempting to delete a skill with existing versions will return a 400 error.

        Note:
            The Anthropic Skills beta API may return a 500 error when deleting the latest
            version. This method handles that by catching server errors on version deletion
            and still attempting to delete the skill.

        Args:
            skill_id (str): The skill identifier to delete.

        Raises:
            SkillOperationError: If the skill failed to be deleted.
        """
    async def update(self, skill_id: str, file: Attachment, **kwargs: Any) -> Skill:
        """Updates a skill by ID.

        Creates a new version of the skill via the Anthropic Skills Versions beta API.

        Args:
            skill_id (str): The skill identifier.
            file (Attachment): The skill file to upload (ZIP archive or markdown file).
            **kwargs (Any): Additional keyword arguments passed to Anthropic's versions.create.

        Returns:
            Skill: The updated skill with the new version.
        """
    async def list_versions(self, skill_id: str) -> list[Skill]:
        """Lists all versions of a skill by ID.

        Args:
            skill_id (str): The skill identifier.

        Returns:
            list[Skill]: List of skill versions.
        """
