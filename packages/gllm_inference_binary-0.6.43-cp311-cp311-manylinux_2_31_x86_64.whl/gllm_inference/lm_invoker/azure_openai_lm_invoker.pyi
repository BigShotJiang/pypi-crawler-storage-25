from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import AZURE_OPENAI_URL_SUFFIX as AZURE_OPENAI_URL_SUFFIX, INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.exceptions import ProviderInvalidArgsError as ProviderInvalidArgsError
from gllm_inference.input_transformer import InputTransformer as InputTransformer
from gllm_inference.lm_invoker.openai_lm_invoker import OpenAILMInvoker as OpenAILMInvoker
from gllm_inference.lm_invoker.schema.openai import Key as Key
from gllm_inference.output_transformer import OutputTransformer as OutputTransformer
from gllm_inference.schema import InputTransformerType as InputTransformerType, LMTool as LMTool, ModelId as ModelId, ModelProvider as ModelProvider, OutputTransformerType as OutputTransformerType, ResponseSchema as ResponseSchema, ThinkingConfig as ThinkingConfig
from typing import Any

class AzureOpenAILMInvoker(OpenAILMInvoker):
    '''A language model invoker to interact with Azure OpenAI language models.

    Examples:
        ```python
        lm_invoker = AzureOpenAILMInvoker(
            azure_endpoint="https://<your-azure-openai-endpoint>.openai.azure.com/openai/v1",
            azure_deployment="<your-azure-openai-deployment>",
        )
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Document
           c. Image
        5. Structured output
        6. Tool calling
        7. Thinking
        8. Output analytics
        9. Retry and timeout
        10. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the Azure OpenAI language model deployment.
        client_kwargs (dict[str, Any]): The keyword arguments for the Azure OpenAI client.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        data_stores (list[AttachmentStore]): The data stores to retrieve internal knowledge from.
        input_transformers (list[InputTransformerConfig]): The list of input transformer configs to use.
        output_transformers (list[OutputTransformerConfig]): The list of output transformer configs to use.
    '''
    client_kwargs: Incomplete
    def __init__(self, azure_endpoint: str, azure_deployment: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, input_transformers: list[InputTransformer] | None = None, output_transformers: list[OutputTransformer] | None = None, input_transformer: InputTransformerType | None = None, output_transformer: OutputTransformerType | None = None) -> None:
        """Initializes a new instance of the AzureOpenAILMInvoker class.

        Args:
            azure_endpoint (str): The endpoint of the Azure OpenAI service.
            azure_deployment (str): The deployment name of the Azure OpenAI service.
            api_key (str | None, optional): The API key for authenticating with Azure OpenAI. Defaults to None, in
                which case the `AZURE_OPENAI_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None, in which case an empty dictionary is used.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None, in which case an empty list is used.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            input_transformers (list[InputTransformer] | None, optional): The list of input transformers to use.
                Defaults to None, in which case no input transformers will be used.
            output_transformers (list[OutputTransformer] | None, optional): The list of output transformers to use.
                Defaults to None, in which case no output transformers will be used.
            input_transformer (InputTransformerType | None, optional): Deprecated param to define input transformer.
                Will be removed in v0.7. Defaults to None.
            output_transformer (OutputTransformerType | None, optional): Deprecated param to define output transformer.
                Will be removed in v0.7. Defaults to None.
        """
