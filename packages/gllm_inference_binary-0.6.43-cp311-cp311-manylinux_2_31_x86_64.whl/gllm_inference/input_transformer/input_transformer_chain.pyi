from _typeshed import Incomplete
from gllm_inference.input_transformer.input_transformer import BaseInputTransformer as BaseInputTransformer
from gllm_inference.input_transformer.input_transformer_config import InputTransformerConfig as InputTransformerConfig
from gllm_inference.schema import Message as Message

class InputTransformerChain:
    """A wrapper to chain a list of input transformers.

    The `InputTransformerChain` class defines the interface for transforming
    the input of language models using a chain of input transformers.

    Attributes:
        transformers (list[BaseInputTransformer]): The list of input transformers to use.
    """
    transformers: Incomplete
    def __init__(self, transformers: list[BaseInputTransformer]) -> None:
        """Initializes a new instance of the InputTransformerChain class.

        Args:
            transformers (list[BaseInputTransformer]): The list of input transformers to use.
        """
    @classmethod
    def from_configs(cls, configs: list[InputTransformerConfig]) -> InputTransformerChain:
        """Create an input transformer chain from configs.

        Args:
            configs (list[InputTransformerConfig]): The list of input transformer configs to use.

        Returns:
            InputTransformerChain: The input transformer chain.
        """
    def transform(self, messages: list[Message]) -> list[Message]:
        """Transforms the input messages of a language model.

        This method transforms the input messages using the chain of input transformers.

        Args:
            messages (list[Message]): The input messages to transform.

        Returns:
            list[Message]: The transformed input messages of a language model.
        """
