from _typeshed import Incomplete
from gllm_inference.input_transformer.filter_empty_input_transformer import FilterEmptyInputTransformer as FilterEmptyInputTransformer
from gllm_inference.input_transformer.identity_input_transformer import IdentityInputTransformer as IdentityInputTransformer
from gllm_inference.input_transformer.input_transformer import BaseInputTransformer as BaseInputTransformer
from gllm_inference.schema import InputTransformerType as InputTransformerType
from pydantic import BaseModel
from typing import Any

class Key:
    """Defines valid keys in input transformer config."""
    TYPE: str

INPUT_TRANSFORMER_TYPE_MAP: Incomplete

class InputTransformerConfig(BaseModel):
    """Defines the input transformer config schema.

    Attributes:
        type (InputTransformerType): The type of input transformer to use.
        kwargs (dict[str, Any]): The additional keyword arguments for the output transformer.
    """
    type: InputTransformerType
    kwargs: dict[str, Any]
    @classmethod
    def identity(cls) -> InputTransformerConfig:
        """Create an identity input transformer config.

        Returns:
            InputTransformerConfig: The identity input transformer config.
        """
    @classmethod
    def filter_empty(cls) -> InputTransformerConfig:
        """Create a filter-empty input transformer config.

        Returns:
            InputTransformerConfig: The filter-empty input transformer config.
        """
    @classmethod
    def from_config(cls, config: InputTransformer) -> InputTransformerConfig:
        """Create an input transformer config from a string or dictionary.

        Args:
            config (InputTransformer): The input transformer config, can be one of the following:
                1. str: The type of the input transformer
                2. dict[str, Any]: The input transformer config as a dictionary
                3. InputTransformerConfig: The input transformer config itself

        Returns:
            InputTransformerConfig: A new input transformer config.

        Raises:
            ValueError:
            1. If the input transformer config is missing the type key.
            2. If the input transformer type is invalid.
        """
    def build(self) -> BaseInputTransformer:
        """Build an input transformer from the config.

        Returns:
            BaseInputTransformer: The input transformer.

        Raises:
            ValueError: If the input transformer type is invalid.
        """
InputTransformer = str | dict[str, Any] | InputTransformerConfig
