class DeepSeekLM:
    '''Defines DeepSeek language model names constants.

    Usage example:
    ```python
    from gllm_inference.model import DeepSeekLM
    from gllm_inference.lm_invoker import DeepSeekLMInvoker

    lm_invoker = DeepSeekLMInvoker(DeepSeekLM.DEEPSEEK_V4_FLASH)
    response = await lm_invoker.invoke("Hello, world!")
    ```
    '''
    DEEPSEEK_V4_FLASH: str
    DEEPSEEK_V4_PRO: str
