from _typeshed import Incomplete
from gllm_inference.output_transformer.event_filter_output_transformer import EventFilterOutputTransformer as EventFilterOutputTransformer
from gllm_inference.output_transformer.identity_output_transformer import IdentityOutputTransformer as IdentityOutputTransformer
from gllm_inference.output_transformer.json_output_transformer import JSONOutputTransformer as JSONOutputTransformer
from gllm_inference.output_transformer.output_transformer import BaseOutputTransformer as BaseOutputTransformer
from gllm_inference.output_transformer.think_tag_output_transformer import ThinkTagOutputTransformer as ThinkTagOutputTransformer
from gllm_inference.schema import OutputTransformerType as OutputTransformerType
from pydantic import BaseModel
from typing import Any

class Key:
    """Defines valid keys in output transformer config."""
    EVENT_TYPES: str
    TYPE: str

OUTPUT_TRANSFORMER_TYPE_MAP: Incomplete

class OutputTransformerConfig(BaseModel):
    """Defines the output transformer config schema.

    Attributes:
        type (OutputTransformerType): The type of output transformer to use.
        kwargs (dict[str, Any]): The additional keyword arguments for the output transformer.
    """
    type: OutputTransformerType
    kwargs: dict[str, Any]
    @classmethod
    def identity(cls) -> OutputTransformerConfig:
        """Create an identity output transformer config.

        Returns:
            OutputTransformerConfig: The identity output transformer config.
        """
    @classmethod
    def event_filter(cls, event_types: list[str]) -> OutputTransformerConfig:
        """Create an event filter output transformer config.

        Args:
            event_types (list[str]): Base event types to keep.

        Returns:
            OutputTransformerConfig: The event filter output transformer config.
        """
    @classmethod
    def json(cls) -> OutputTransformerConfig:
        """Create a JSON output transformer config.

        Returns:
            OutputTransformerConfig: The JSON output transformer config.
        """
    @classmethod
    def think_tag(cls) -> OutputTransformerConfig:
        """Create a think tag output transformer config.

        Returns:
            OutputTransformerConfig: The think tag output transformer config.
        """
    @classmethod
    def from_config(cls, config: OutputTransformer) -> OutputTransformerConfig:
        """Create an output transformer config from a string or a dictionary.

        Args:
            config (OutputTransformer): The output transformer config, can be one of the following:
                1. str: The type of the output transformer
                2. dict[str, Any]: The output transformer config as a dictionary
                3. OutputTransformerConfig: The output transformer config itself

        Returns:
            OutputTransformerConfig: A new output transformer config.

        Raises:
            ValueError:
            1. If the output transformer config is missing the type key.
            2. If the output transformer type is invalid.
        """
    def build(self) -> BaseOutputTransformer:
        """Build an output transformer from the config.

        Returns:
            BaseOutputTransformer: The output transformer.

        Raises:
            ValueError: If the output transformer type is invalid.
        """
OutputTransformer = str | dict[str, Any] | OutputTransformerConfig
