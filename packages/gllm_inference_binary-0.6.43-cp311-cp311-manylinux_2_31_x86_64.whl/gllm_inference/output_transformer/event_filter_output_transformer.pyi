from _typeshed import Incomplete
from gllm_inference.output_transformer.identity_output_transformer import IdentityOutputTransformer as IdentityOutputTransformer

class EventFilterOutputTransformer(IdentityOutputTransformer):
    """An output transformer that filters stream events by type.

    This transformer lets users define the base event types to keep (e.g. `thinking`).
    At runtime, only events matching the selected types are kept, including their
    corresponding `_start` and `_end` events.

    Attributes:
        allowed_event_types (set[str]): The set of allowed event types.
    """
    allowed_event_types: Incomplete
    def __init__(self, event_types: list[str]) -> None:
        """Initializes a new EventFilterOutputTransformer.

        Args:
            event_types (list[str]): Base event types to keep.

        Raises:
            ValueError: If any event type is empty.
        """
