from _typeshed import Incomplete
from gllm_core.event import EventEmitter
from gllm_core.schema import Event
from gllm_inference.output_transformer.output_transformer import BaseOutputTransformer as BaseOutputTransformer
from gllm_inference.output_transformer.output_transformer_config import OutputTransformerConfig as OutputTransformerConfig
from gllm_inference.schema.lm_output import LMOutput as LMOutput

class OutputTransformerChain:
    """A wrapper to chain a list of output transformers.

    The `OutputTransformerChain` class defines the interface for transforming
    the output of language models using a chain of output transformers.

    Attributes:
        transformers (list[BaseOutputTransformer]): The list of output transformers to use.
        event_emitter (EventEmitter | None): The event emitter to use for streaming events.
    """
    transformers: Incomplete
    event_emitter: Incomplete
    def __init__(self, transformers: list[BaseOutputTransformer], event_emitter: EventEmitter | None = None) -> None:
        """Initializes a new instance of the OutputTransformerChain class.

        Args:
            transformers (list[BaseOutputTransformer]): The list of output transformers to use.
            event_emitter (EventEmitter | None, optional): The event emitter to use for streaming events.
                Defaults to None.
        """
    @classmethod
    def from_configs(cls, configs: list[OutputTransformerConfig], event_emitter: EventEmitter | None = None) -> OutputTransformerChain:
        """Create an output transformer chain from a list of output transformer configs.

        Args:
            configs (list[OutputTransformerConfig]): The list of output transformer configs to use.
            event_emitter (EventEmitter | None, optional): The event emitter to use for streaming events.
                Defaults to None.

        Returns:
            OutputTransformerChain: The output transformer chain.
        """
    def transform(self, output: LMOutput) -> LMOutput:
        """Transforms the output of a language model.

        This method transforms the output using the chain of output transformers.

        Args:
            output (LMOutput): The output to transform.

        Returns:
            LMOutput: The transformed output of a language model.
        """
    async def emit(self, event: Event) -> None:
        """Transforms a stream event of a language model and emits it using the event emitter.

        This method transforms a stream event of a language model using
        the chain of output transformers and emits it using the event emitter.

        Args:
            event (Event): The stream event to transform and emit.

        Raises:
            ValueError: If the event emitter is not set.
        """
