"""kairos.cert — proof certificate authoring + cross-check audit.

Public surface bundles two layers:

1. *Tarball-format proof certificates* (legacy, ATH-854) — JWS-signed verdict
   tarballs with manifest, proof artifact, and JWKS snapshot. Re-exported from
   :mod:`kairos.cert._legacy`.
2. *Cert-authoring-time engine-output cross-check* (ATH-1018, asabi
   2026-05-05 Shape-2 dry-run hole) — parses cert markdown for verdict
   claims, re-runs EBMC, fails-loud on mismatch. Re-exported from
   :mod:`kairos.cert._audit`.
3. *Cert-bundle cross-document staleness audit* (ATH-1058, Aidan
   strategic thesis 2026-05-06) — scans every .md file in a cert
   bundle for numerical claims + bridge labels + outcome distributions
   + run_id references; cross-checks against canonical engine emit;
   fails-loud on any drift. Layer 1 of the three-layer drift-prevention
   plan. Re-exported from :mod:`kairos.cert._bundle_audit`.

Per asabi 2026-05-05 ATH-1016 audit: cert-authoring-time engine-output
cross-check is the structural enforcement of the
``prior-run-carry-over`` instance-1 sub-shape (the
"did you re-run, or did you remember?" rule).

Cross-refs
----------

* :issue:`ATH-854` — original kairos.cert tarball + verify CLI.
* :issue:`ATH-1018` — audit module's primary use.
* :issue:`ATH-1016` — parent epic (Shape-2 dry-run holes plug).
* `feedback_cert_against_actual_lean_source_not_proposal_doc.md` —
  the memory rule the audit module enforces structurally.
"""
from __future__ import annotations

from kairos.cert._audit import (
    CertCrossCheckMismatch,
    CertCrossCheckResult,
    CertVerdictClaim,
    cross_check_against_engine_output,
    extract_verdict_claims,
)
from kairos.cert._bundle_audit import (
    BundleAuditResult,
    BundleClaim,
    BundleStalenessFinding,
    cross_check_build_script_consistency,
    cross_check_bundle_against_engine_emit,
    cross_check_gate_count_assertions,
    extract_bundle_claims,
)
from kairos.cert.gates import (
    CertGateError,
    GateViolation,
    require_gates,
    run_all_gates,
)
from kairos.cert.templates import (
    generic_certificate,
    nki_kernel_certificate,
    sec_block_certificate,
)
from kairos.cert.verdict_tier import (
    CertResult,
    PropertyVerdict,
    VerdictTier,
)
from kairos.cert._legacy import (
    CERT_FORMAT_VERSION,
    JWKS_FILENAME,
    MANIFEST_FILENAME,
    MAX_CERT_BYTES,
    MAX_PROOF_ARTIFACT_BYTES,
    PROOF_ARTIFACT_FILENAME,
    SIGNED_VERDICT_FILENAME,
    VERDICT_FILENAME,
    CertChecksumMismatch,
    CertError,
    CertManifestError,
    CertSignatureInvalid,
    CertVerdictMismatch,
    ProofCertificateVerification,
    make_proof_certificate,
    verify_proof_certificate,
)

__all__ = [
    "CERT_FORMAT_VERSION",
    "JWKS_FILENAME",
    "MANIFEST_FILENAME",
    "MAX_CERT_BYTES",
    "MAX_PROOF_ARTIFACT_BYTES",
    "PROOF_ARTIFACT_FILENAME",
    "SIGNED_VERDICT_FILENAME",
    "VERDICT_FILENAME",
    "CertChecksumMismatch",
    "BundleAuditResult",
    "BundleClaim",
    "BundleStalenessFinding",
    "CertCrossCheckMismatch",
    "CertCrossCheckResult",
    "CertError",
    "CertManifestError",
    "CertSignatureInvalid",
    "CertVerdictClaim",
    "CertVerdictMismatch",
    "ProofCertificateVerification",
    "cross_check_against_engine_output",
    "cross_check_build_script_consistency",
    "cross_check_bundle_against_engine_emit",
    "cross_check_gate_count_assertions",
    "extract_bundle_claims",
    "extract_verdict_claims",
    "make_proof_certificate",
    "verify_proof_certificate",
    "CertGateError",
    "CertResult",
    "GateViolation",
    "PropertyVerdict",
    "VerdictTier",
    "require_gates",
    "run_all_gates",
    "generic_certificate",
    "nki_kernel_certificate",
    "sec_block_certificate",
]
