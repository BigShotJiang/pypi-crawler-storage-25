"""siracli — Sira AI Command Line Interface.

Single source of truth for the version is ``pyproject.toml`` (PEP 621).
We expose ``__version__`` here via ``importlib.metadata`` so the click
``--version`` flag and the ``system info`` / ``system version`` commands
stay in lockstep automatically — bump the version once in pyproject.toml
and everything updates.
"""
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("siracli")
except PackageNotFoundError:
    # Running from a checkout without the package being installed
    # (e.g. ``python -m siracli.cli``). Fall back to a sentinel so the
    # CLI doesn't crash; "+source" makes it obvious in any UI.
    __version__ = "0.0.0+source"
