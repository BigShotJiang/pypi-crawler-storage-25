"""HTTP API Client for siracli"""

import requests
import sseclient
from typing import Optional, Dict, Any, Generator
from .config import get_api_url, get_token


class APIError(Exception):
    """API error with status code.

    For structured 409 conflicts (MODEL_IN_USE / AGENT_IN_USE /
    ORCHESTRATOR_IN_USE), the backend returns ``detail`` as a dict like
    ``{"code": ..., "message": ..., "references": ..., "hint": ...}``.
    The exception message uses ``detail.message`` if available; the
    full dict is preserved on ``self.detail`` so callers can render
    the references list.
    """
    def __init__(self, message: str, status_code: int, response: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
        # Convenience accessor for structured detail (409 conflicts etc.)
        detail = (response or {}).get("detail") if isinstance(response, dict) else None
        self.detail: Optional[Dict] = detail if isinstance(detail, dict) else None


class APIClient:
    """HTTP client with auth support"""

    def __init__(self, api_url: Optional[str] = None, token: Optional[str] = None):
        self.api_url = api_url or get_api_url()
        self.token = token or get_token()
        self.session = requests.Session()
        if self.token:
            self.session.headers.update({"Authorization": f"Bearer {self.token}"})

    def _url(self, path: str) -> str:
        """Build full URL"""
        return f"{self.api_url}{path}"

    def request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request with auth"""
        url = self._url(path)
        headers = kwargs.pop("headers", {})
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        headers["Content-Type"] = "application/json"

        response = self.session.request(
            method,
            url,
            headers=headers,
            **kwargs
        )

        if not response.ok:
            try:
                error_data = response.json()
                detail = error_data.get("detail")
                # Structured 409 (MODEL_IN_USE etc.) — detail is a dict with
                # human-readable .message; fall back to repr only as a last resort.
                if isinstance(detail, dict):
                    message = detail.get("message") or str(detail)
                else:
                    message = detail or error_data.get("message", response.text)
            except (ValueError, AttributeError):
                error_data = None
                message = response.text
            raise APIError(message, response.status_code, error_data)

        if response.content:
            return response.json()
        return {}

    def get(self, path: str, **kwargs) -> Dict[str, Any]:
        """GET request"""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> Dict[str, Any]:
        """POST request"""
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs) -> Dict[str, Any]:
        """PUT request"""
        return self.request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs) -> Dict[str, Any]:
        """DELETE request"""
        return self.request("DELETE", path, **kwargs)

    def patch(self, path: str, **kwargs) -> Dict[str, Any]:
        """PATCH request"""
        return self.request("PATCH", path, **kwargs)

    def stream_post(self, path: str, data: Dict[str, Any], api_key: Optional[str] = None) -> Generator[str, None, None]:
        """POST with SSE streaming response"""
        url = self._url(path)
        headers = {
            "Content-Type": "application/json",
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        elif self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        response = self.session.post(
            url,
            json=data,
            headers=headers,
            stream=True
        )

        if not response.ok:
            try:
                error_data = response.json()
                message = error_data.get("detail", error_data.get("message", response.text))
            except (ValueError, AttributeError):
                message = response.text
            raise APIError(message, response.status_code)

        # Parse SSE stream
        client = sseclient.SSEClient(response)
        for event in client.events():
            if event.data:
                yield event.data


def get_client() -> APIClient:
    """Get a configured API client"""
    return APIClient()
