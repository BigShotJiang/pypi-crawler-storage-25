"""Authentication commands"""

import click
from ..config import get_api_url, save_token, clear_token, get_user, get_token, is_authenticated, set_api_url
from ..client import APIClient, APIError


@click.group(name="auth")
def auth_group():
    """Authentication management"""
    pass


@auth_group.command()
@click.option("--email", "-e", prompt="Email", help="Your email address")
@click.option("--password", "-p", prompt="Password", hide_input=True, help="Your password")
@click.option("--api-url", "-u", default=None, help="API URL (e.g., http://localhost:8000)")
def login(email: str, password: str, api_url: str):
    """Login to Sira AI"""
    api_url = api_url or get_api_url()

    client = APIClient(api_url=api_url)

    try:
        response = client.post("/api/auth/login", json={
            "email": email,
            "password": password
        })

        if response.get("success"):
            token = response["token"]
            user = response["user"]
            expires_at = response.get("expiresAt")
            save_token(token, user, api_url, expires_at)
            click.echo(f"✓ Logged in as {user.get('name', email)}")
            click.echo(f"  API URL: {api_url}")
        else:
            click.echo(f"✗ Login failed: {response.get('detail', 'Unknown error')}", err=True)

    except APIError as e:
        click.echo(f"✗ Login failed: {e}", err=True)
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)


@auth_group.command()
def logout():
    """Logout and clear stored credentials"""
    if is_authenticated():
        clear_token()
        click.echo("✓ Logged out successfully")
    else:
        click.echo("Not logged in")


@auth_group.command()
def status():
    """Show current login status"""
    if is_authenticated():
        user = get_user()
        api_url = get_api_url()
        if user:
            click.echo(f"✓ Logged in as {user.get('name', user.get('email', 'Unknown'))}")
            click.echo(f"  Email: {user.get('email', 'N/A')}")
        click.echo(f"  API URL: {api_url}")
    else:
        click.echo("✗ Not logged in")
        click.echo(f"  API URL: {get_api_url()}")


@auth_group.command()
@click.argument("api_url")
def set_url(api_url: str):
    """Set API URL"""
    set_api_url(api_url)
    click.echo(f"✓ API URL set to {api_url}")
