"""Application management commands"""

import json
import uuid
import click
from ..client import get_client, APIError
from ..utils import require_auth


def _build_interrupt_overrides_dict(
    *,
    enable: tuple[str, ...],
    disable: tuple[str, ...],
    json_blob: str | None,
) -> dict | None:
    """``--interrupt-override`` / ``--interrupt-override-off`` /
    ``--interrupt-overrides-json`` 合并成 application 层期望的
    ``platform_config.interrupt_overrides`` dict。

    优先级：JSON blob 提供 baseline，再被 enable / disable 逐 key 覆盖。
    返回 None 表示用户没传任何 HITL flag（caller 决定保留旧值还是清空）。
    """
    if not enable and not disable and not json_blob:
        return None

    base: dict = {}
    if json_blob:
        try:
            parsed = json.loads(json_blob)
        except json.JSONDecodeError as e:
            raise click.UsageError(f"--interrupt-overrides-json 解析失败: {e}")
        if not isinstance(parsed, dict):
            raise click.UsageError("--interrupt-overrides-json 必须是 JSON 对象")
        base.update(parsed)

    for tool_name in enable:
        base[tool_name] = True
    for tool_name in disable:
        base[tool_name] = False

    return base


@click.group(name="application")
def application_group():
    """Application management"""
    pass


# ==================== API Key Subcommands ====================

@click.group(name="apikey")
def apikey_group():
    """API Key management for applications"""
    pass


@apikey_group.command()
@click.option("--application-id", "-a", required=True, help="Application ID")
def list(application_id: str):
    """List API keys for an application"""
    require_auth()
    client = get_client()

    try:
        response = client.get("/api/agent-system/api-keys", params={"application_id": application_id})
        items = response.get("items", [])

        click.echo(f"\nApplication: {application_id}\n")

        if not items:
            click.echo("No API keys found for this application.")
            return

        click.echo(f"{'ID':<10}{'STATUS':<10}{'NAME':<25}{'KEY PREFIX':<30}{'RATE':<8}{'CREATED'}")
        click.echo("-" * 95)

        for key in items:
            key_id = str(key.get("id", ""))
            status = "●" if key.get("is_active") else "○"
            name = key.get("name", "N/A")[:23]
            key_prefix = key.get("key_prefix", "N/A")[:28]
            rate_limit = str(key.get("rate_limit") or "∞")[:6]
            created = str(key.get("created_at", "N/A"))[:10]
            click.echo(f"{key_id:<10}{status:<10}{name:<25}{key_prefix:<30}{rate_limit:<8}{created}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@apikey_group.command()
@click.argument("api_key_id")
def get(api_key_id: str):
    """Get API key details"""
    require_auth()
    client = get_client()

    try:
        key = client.get(f"/api/agent-system/api-keys/{api_key_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"API Key Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {key.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {key.get('name', 'N/A')}")
        click.echo(f"{'Application ID':<20} {key.get('application_id', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Active' if key.get('is_active') else '○ Inactive'}")
        click.echo(f"{'Key Prefix':<20} {key.get('key_prefix', 'N/A')}")
        click.echo(f"{'Rate Limit':<20} {key.get('rate_limit', 'N/A')} req/min")
        click.echo(f"{'Quota Limit':<20} {key.get('quota_limit', 'N/A')}")
        click.echo(f"{'Allowed IPs':<20} {', '.join(key.get('allowed_ips', []) or ['Any'])}")
        click.echo(f"{'Allowed Origins':<20} {', '.join(key.get('allowed_origins', []) or ['Any'])}")
        click.echo(f"{'Created At':<20} {str(key.get('created_at', 'N/A'))[:19]}")
        click.echo(f"{'Expires At':<20} {str(key.get('expires_at', 'N/A'))[:19] if key.get('expires_at') else 'Never'}")
        click.echo(f"{'Last Used':<20} {str(key.get('last_used_at', 'N/A'))[:19] if key.get('last_used_at') else 'Never'}")
        click.echo(f"{'Total Requests':<20} {key.get('total_requests', 0)}")

        if key.get('description'):
            click.echo(f"\n{'Description':<20} {key.get('description')}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@apikey_group.command()
@click.option("--name", "-n", required=True, help="API key name")
@click.option("--application-id", "-a", required=True, help="Application ID")
@click.option("--description", "-d", default="", help="Description")
@click.option("--rate-limit", "-r", default=None, type=int, help="Rate limit (requests per minute)")
@click.option("--quota-limit", "-q", default=None, type=int, help="Quota limit (total requests)")
@click.option("--allowed-ips", "-i", multiple=True, help="Allowed IP addresses")
@click.option("--allowed-origins", "-o", multiple=True, help="Allowed origins")
@click.option("--expires-days", "-e", default=None, type=int, help="Expiration in days")
def create(name: str, application_id: str, description: str, rate_limit: int, quota_limit: int, allowed_ips: tuple, allowed_origins: tuple, expires_days: int):
    """Create a new API key"""
    require_auth()
    client = get_client()

    data = {
        "name": name,
        "application_id": application_id,
        "description": description,
    }
    if rate_limit is not None:
        data["rate_limit"] = rate_limit
    if quota_limit is not None:
        data["quota_limit"] = quota_limit
    if allowed_ips:
        data["allowed_ips"] = list(allowed_ips)
    if allowed_origins:
        data["allowed_origins"] = list(allowed_origins)
    if expires_days is not None:
        data["expires_days"] = expires_days

    try:
        key = client.post("/api/agent-system/api-keys", json=data)
        click.echo(f"✓ API Key created")
        click.echo(f"\n{'='*60}")
        click.echo(f"IMPORTANT: Save this API key now - it will not be shown again!")
        click.echo(f"{'='*60}")
        click.echo(f"API Key: {key.get('key', 'N/A')}")
        click.echo(f"ID: {key.get('id', 'N/A')}")
        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@apikey_group.command()
@click.argument("api_key_id")
@click.option("--name", "-n", default=None, help="API key name")
@click.option("--description", "-d", default=None, help="Description")
@click.option("--rate-limit", "-r", default=None, type=int, help="Rate limit")
@click.option("--quota-limit", "-q", default=None, type=int, help="Quota limit")
@click.option("--allowed-ips", "-i", multiple=True, help="Allowed IPs")
@click.option("--allowed-origins", "-o", multiple=True, help="Allowed origins")
@click.option("--enable/--disable", default=None, help="Enable or disable")
def update(api_key_id: str, name: str, description: str, rate_limit: int, quota_limit: int, allowed_ips: tuple, allowed_origins: tuple, enable: bool):
    """Update an API key"""
    require_auth()
    client = get_client()

    data = {}
    if name:
        data["name"] = name
    if description is not None:
        data["description"] = description
    if rate_limit is not None:
        data["rate_limit"] = rate_limit
    if quota_limit is not None:
        data["quota_limit"] = quota_limit
    if allowed_ips:
        data["allowed_ips"] = list(allowed_ips)
    if allowed_origins:
        data["allowed_origins"] = list(allowed_origins)
    if enable is not None:
        data["is_active"] = enable

    if not data:
        click.echo("No updates provided.")
        return

    try:
        key = client.put(f"/api/agent-system/api-keys/{api_key_id}", json=data)
        click.echo(f"✓ API Key updated: {key.get('name', api_key_id)}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@apikey_group.command()
@click.argument("api_key_id")
def delete(api_key_id: str):
    """Delete an API key"""
    require_auth()

    if not click.confirm(f"Are you sure you want to delete API key {api_key_id}?"):
        return

    client = get_client()

    try:
        client.delete(f"/api/agent-system/api-keys/{api_key_id}")
        click.echo(f"✓ API Key deleted")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@apikey_group.command()
@click.argument("api_key_id")
@click.option("--test-message", "-m", default="Hello, are you working?", help="Test message")
def test(api_key_id: str, test_message: str):
    """Test API key connection"""
    require_auth()
    client = get_client()

    click.echo("Testing API key connection...")

    try:
        key = client.get(f"/api/agent-system/api-keys/{api_key_id}")
        application_id = key.get("application_id")

        if not application_id:
            click.echo("✗ No application associated with this API key")
            return

        response = client.post(
            f"/api/agent-system/applications/{application_id}/message",
            json={"user_message": test_message, "stream": False}
        )

        if response.get("response"):
            click.echo("✓ API key connection successful")
            click.echo(f"Response: {response.get('response', '')[:200]}...")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


# Register apikey subgroup under application
application_group.add_command(apikey_group)


@application_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
def application_list(page: int, limit: int):
    """List all applications"""
    require_auth()
    client = get_client()

    try:
        response = client.get("/api/agent-system/applications", params={
            "page": page,
            "limit": limit
        })
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No applications found.")
            return

        click.echo(f"\nTotal: {total} applications\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<25}{'DISPLAY NAME':<22}{'PLATFORM':<20}{'ORCHESTRATOR ID'}")
        click.echo("-" * 140)

        for app in items:
            app_id = app.get("id", "")
            status = "●" if app.get("is_active") else "○"
            name = app.get("name", "N/A")[:23]
            display_name = app.get("display_name", "")[:20]
            platform = app.get("platform", "N/A")[:18]
            orch_id = app.get("orchestrator_id", "N/A")
            click.echo(f"{app_id:<40}{status:<10}{name:<25}{display_name:<22}{platform:<20}{orch_id}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.argument("application_id")
def get(application_id: str):
    """Get application details"""
    require_auth()
    client = get_client()

    try:
        app = client.get(f"/api/agent-system/applications/{application_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Application Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {app.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {app.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {app.get('display_name', 'N/A')}")
        click.echo(f"{'Platform':<20} {app.get('platform', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Active' if app.get('is_active') else '○ Inactive'}")
        click.echo(f"{'Orchestrator ID':<20} {app.get('orchestrator_id', 'N/A')}")
        click.echo(f"{'Streaming':<20} {'Enabled' if app.get('enable_streaming') else 'Disabled'}")
        click.echo(f"{'Context Retention':<20} {'Enabled' if app.get('enable_context_retention') else 'Disabled'}")
        click.echo(f"{'Session Timeout':<20} {app.get('session_timeout_minutes', 'N/A')}min")
        click.echo(f"{'Total Messages':<20} {app.get('total_messages', 0)}")
        click.echo(f"{'Total Users':<20} {app.get('total_users', 0)}")
        click.echo(f"{'Created At':<20} {str(app.get('created_at', 'N/A'))[:19]}")

        # Callback URL
        callback_url = app.get("callback_url", "")
        if callback_url:
            click.echo(f"\n{'='*60}")
            click.echo(f"Callback URL")
            click.echo(f"{'='*60}")
            click.echo(f"  {callback_url}")

        # Platform config (show non-sensitive info)
        platform_config = app.get("platform_config", {})
        if platform_config:
            click.echo(f"\n{'='*60}")
            click.echo(f"Platform Config")
            click.echo(f"{'='*60}")
            for key, value in platform_config.items():
                if key in ["corp_id", "open_kfid", "kf_name", "deployment"]:
                    click.echo(f"  {key}: {value}")

        # HITL × Card 字段（layer 3: application — 最高优先级）
        hitl_silent = bool(platform_config.get("hitl_disabled"))
        overrides = platform_config.get("interrupt_overrides") or {}
        if hitl_silent or overrides:
            click.echo(f"\n{'='*60}")
            click.echo(f"HITL (application layer)")
            click.echo(f"{'='*60}")
            if hitl_silent:
                click.echo(f"  🔇 hitl_disabled = true (整应用静默；OR-merge 编排器层)")
            if overrides:
                click.echo(f"  interrupt_overrides ({len(overrides)} rules; 最高优先级):")
                for tool_name, raw in overrides.items():
                    if raw is True:
                        click.echo(f"    - {tool_name}: ✓ (force enable approval)")
                    elif raw is False:
                        click.echo(f"    - {tool_name}: ✗ (force disable approval)")
                    elif isinstance(raw, dict):
                        decisions = raw.get("allowed_decisions") or []
                        desc = raw.get("description")
                        click.echo(f"    - {tool_name}: decisions={decisions}"
                                   + (f" desc={desc!r}" if desc else ""))

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.option("--name", "-n", required=True, help="Application name")
@click.option("--display-name", "-D", required=True, help="Display name")
@click.option("--platform", "-p", required=True,
              type=click.Choice(["api_service", "webclient"]),
              help="Platform type (wework/wework_aibot/weixin_kf/feishu_bot: use web console)")
@click.option("--orchestrator-id", "-o", required=True, help="Orchestrator ID to connect")
@click.option("--description", "-d", default="", help="Description")
# HITL × Card 字段（落到 platform_config）— see HITL_INTERACTIVE_CARD_DESIGN §4
@click.option("--hitl-disabled/--no-hitl-disabled", "hitl_disabled", default=None,
              help="HITL: silence the whole application (OR-merged with orchestrator's "
                   "hitl_disabled — either layer set silences)")
@click.option("--interrupt-override", "interrupt_override", multiple=True,
              help="HITL: tool name with application-level approval enabled "
                   "(highest priority; overrides orch + tool layer). Repeatable.")
@click.option("--interrupt-override-off", "interrupt_override_off", multiple=True,
              help="HITL: tool name with application-level approval disabled "
                   "(overrides orch / tool layer). Repeatable.")
@click.option("--interrupt-overrides-json", "interrupt_overrides_json", default=None,
              help="HITL: full interrupt_overrides dict as JSON, e.g. "
                   '''--interrupt-overrides-json '{"send_email": false, '''
                   '''"delete_db": {"allowed_decisions": ["approve"]}}'.''')
def create(name: str, display_name: str, platform: str, orchestrator_id: str,
           description: str,
           hitl_disabled: bool | None,
           interrupt_override: tuple,
           interrupt_override_off: tuple,
           interrupt_overrides_json: str | None):
    """Create a new application"""
    if platform not in ("api_service", "webclient"):
        click.echo(f"✗ Platform '{platform}' is complex. Please use the web console.", err=True)
        raise click.Abort()

    require_auth()
    client = get_client()

    # platform_config 收 HITL 字段
    platform_config: dict = {}
    if hitl_disabled is not None:
        platform_config["hitl_disabled"] = hitl_disabled
    overrides = _build_interrupt_overrides_dict(
        enable=interrupt_override,
        disable=interrupt_override_off,
        json_blob=interrupt_overrides_json,
    )
    if overrides is not None:
        platform_config["interrupt_overrides"] = overrides

    payload = {
        "name": name,
        "display_name": display_name,
        "platform": platform,
        "orchestrator_id": orchestrator_id,
        "description": description,
        "is_active": True,
    }
    if platform_config:
        payload["platform_config"] = platform_config

    try:
        app = client.post("/api/agent-system/applications", json=payload)
        click.echo(f"✓ Application created: {app['name']} [{app['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.argument("application_id")
@click.option("--name", "-n", default=None, help="Application name")
@click.option("--description", "-d", default=None, help="Description")
@click.option("--orchestrator-id", "-o", default=None, help="Orchestrator ID")
# HITL × Card 字段
@click.option("--hitl-disabled/--no-hitl-disabled", "hitl_disabled", default=None,
              help="HITL: silence/un-silence the whole application")
@click.option("--interrupt-override", "interrupt_override", multiple=True,
              help="HITL: add tool to application-level interrupt_overrides as TOOL: true. "
                   "Repeatable (merged with existing).")
@click.option("--interrupt-override-off", "interrupt_override_off", multiple=True,
              help="HITL: add tool to application-level interrupt_overrides as TOOL: false. "
                   "Repeatable (merged with existing).")
@click.option("--interrupt-overrides-json", "interrupt_overrides_json", default=None,
              help="HITL: full interrupt_overrides dict as JSON; merged with "
                   "--interrupt-override / --interrupt-override-off (those win on key collision)")
@click.option("--clear-interrupt-overrides", "clear_interrupt_overrides", is_flag=True,
              default=False,
              help="HITL: clear application-level interrupt_overrides (delete the field)")
def update(application_id: str, name: str, description: str, orchestrator_id: str,
           hitl_disabled: bool | None,
           interrupt_override: tuple,
           interrupt_override_off: tuple,
           interrupt_overrides_json: str | None,
           clear_interrupt_overrides: bool):
    """Update an application"""
    require_auth()
    client = get_client()

    data = {}
    if name:
        data["display_name"] = name
    if description is not None:
        data["description"] = description
    if orchestrator_id:
        data["orchestrator_id"] = orchestrator_id

    # HITL × Card：先拉 existing.platform_config 做 partial merge，避免覆盖
    # 其它字段（corp_id / channel / deployment 等）
    needs_platform_cfg_update = (
        hitl_disabled is not None
        or interrupt_override
        or interrupt_override_off
        or interrupt_overrides_json
        or clear_interrupt_overrides
    )
    if needs_platform_cfg_update:
        try:
            existing = client.get(f"/api/agent-system/applications/{application_id}")
        except APIError as e:
            click.echo(f"✗ Error: {e}", err=True)
            return
        platform_config = dict(existing.get("platform_config") or {})

        if hitl_disabled is not None:
            platform_config["hitl_disabled"] = hitl_disabled

        if clear_interrupt_overrides:
            platform_config.pop("interrupt_overrides", None)
        else:
            merged = _build_interrupt_overrides_dict(
                enable=interrupt_override,
                disable=interrupt_override_off,
                json_blob=interrupt_overrides_json,
            )
            if merged is not None:
                if interrupt_overrides_json:
                    platform_config["interrupt_overrides"] = merged
                else:
                    existing_io = dict(platform_config.get("interrupt_overrides") or {})
                    existing_io.update(merged)
                    platform_config["interrupt_overrides"] = existing_io

        data["platform_config"] = platform_config

    if not data:
        click.echo("No updates provided.")
        return

    try:
        app = client.put(f"/api/agent-system/applications/{application_id}", json=data)
        click.echo(f"✓ Application updated: {app['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.argument("application_id")
def delete(application_id: str):
    """Delete an application.

    Soft-deletes the Application AND cascade-invalidates its child
    resources: all api_keys (set is_active=false) and cron_jobs
    (soft-deleted). Issued API keys stop working immediately.
    """
    require_auth()

    click.echo(
        click.style(
            "⚠️  This will also invalidate all API keys and cancel all "
            "scheduled cron jobs for this application. Issued keys stop "
            "working immediately.",
            fg="yellow",
        )
    )
    if not click.confirm(f"Are you sure you want to delete application {application_id}?"):
        return

    client = get_client()

    try:
        client.delete(f"/api/agent-system/applications/{application_id}")
        click.echo(f"✓ Application deleted (api_keys & cron_jobs cascaded)")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.argument("application_id")
def info(application_id: str):
    """Get application connection info (callback URLs, etc.)"""
    require_auth()
    client = get_client()

    try:
        app = client.get(f"/api/agent-system/applications/{application_id}")
        platform = app.get("platform_type", "N/A")

        click.echo(f"\nApplication: {app['name']}")
        click.echo(f"Platform: {platform}\n")

        if platform == "WECHAT_WORK":
            click.echo("Callback URLs:")
            click.echo(f"  Traditional: /api/agent-system/callback/wework/{application_id}")
            click.echo(f"  AI Bot: /api/agent-system/callback/wework-aibot/{application_id}")
        elif platform == "WEB":
            click.echo("Web Chat URL:")
            click.echo(f"  /app-chat/{application_id}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@application_group.command()
@click.argument("application_id")
@click.option("--message", "-m", required=True, help="Message to send")
@click.option("--session-id", "-s", default=None, help="Session ID (optional, for web-type)")
@click.option("--api-key", "-k", default=None, help="API key for API-type applications")
def chat(application_id: str, message: str, session_id: str, api_key: str):
    """Chat with an application (streaming)

    For web-type applications: uses session auth (login required)
    For API-type applications: uses API key auth (-k/--api-key)
    """
    client = get_client()

    # Generate session ID if not provided
    session_id = session_id or f"cli_{uuid.uuid4().hex[:8]}"

    click.echo(f"\n[Session: {session_id}]")
    click.echo(f"You: {message}\n")

    try:
        full_response = []

        if api_key:
            # API-type application: OpenAI compatible endpoint
            for chunk in client.stream_post(
                "/v1/chat/completions",
                {
                    "model": application_id,
                    "messages": [{"role": "user", "content": message}],
                    "stream": True,
                },
                api_key=api_key
            ):
                if chunk.startswith("{"):
                    import json
                    try:
                        data = json.loads(chunk)
                        # OpenAI streaming format: choices[0].delta.content
                        if data.get("choices") and data["choices"][0].get("delta", {}).get("content"):
                            content = data["choices"][0]["delta"]["content"]
                            click.echo(content, nl=False)
                            full_response.append(content)
                        elif data.get("error"):
                            click.echo(f"\n✗ Error: {data['error']}", err=True)
                            return
                    except json.JSONDecodeError:
                        pass
                else:
                    click.echo(chunk, nl=False)
                    full_response.append(chunk)
        else:
            # Web-type application: session auth
            require_auth()
            for chunk in client.stream_post(
                f"/api/agent-system/applications/{application_id}/message",
                {
                    "user_message": message,
                    "session_id": session_id,
                    "stream": True,
                }
            ):
                if chunk.startswith("{"):
                    import json
                    try:
                        data = json.loads(chunk)
                        if data.get("type") == "content":
                            content = data.get("content", "")
                            if content:
                                click.echo(content, nl=False)
                                full_response.append(content)
                        elif data.get("type") == "error":
                            error_msg = data.get("error") or data.get("data", {}).get("error", "Unknown error")
                            click.echo(f"\n✗ Error: {error_msg}", err=True)
                            return
                        elif data.get("type") == "done":
                            break
                    except json.JSONDecodeError:
                        pass
                else:
                    # Plain text content
                    click.echo(chunk, nl=False)
                    full_response.append(chunk)

        click.echo("\n")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)
