"""MCP (Model Context Protocol) commands"""

import click
from ..client import get_client, APIError
from ..utils import require_auth


@click.group(name="mcp")
def mcp_group():
    """MCP tools and services management"""
    pass


@mcp_group.command(name="list-tools")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--enabled/--all", default=None, help="Show only enabled tools")
def list_tools(page: int, limit: int, enabled: bool):
    """List all MCP tools"""
    require_auth()
    client = get_client()

    params = {"page": page, "limit": limit}
    if enabled is not None:
        params["is_enabled"] = enabled

    try:
        response = client.get("/api/mcp-tools", params=params)
        tools = response.get("tools", response.get("items", []))
        total = response.get("pagination", {}).get("total", len(tools))

        if not tools:
            click.echo("No MCP tools found.")
            return

        click.echo(f"\nTotal: {total} tools\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<25}{'DISPLAY NAME':<20}{'TYPE'}")
        click.echo("-" * 110)

        for tool in tools:
            tool_id = tool.get("id", "")
            status = "●" if tool.get("isEnabled") else "○"
            name = tool.get("name", "N/A")[:23]
            display_name = tool.get("display_name", "")[:18]
            tool_type = tool.get("tool_type", "N/A")
            click.echo(f"{tool_id:<40}{status:<10}{name:<25}{display_name:<20}{tool_type}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command(name="list-services")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--enabled/--all", default=None, help="Show only enabled services")
def list_services(page: int, limit: int, enabled: bool):
    """List all MCP services"""
    require_auth()
    client = get_client()

    params = {"page": page, "limit": limit}
    if enabled is not None:
        params["is_enabled"] = enabled

    try:
        response = client.get("/api/mcp-services", params=params)
        services = response.get("tools", response.get("items", []))
        total = response.get("pagination", {}).get("total", len(services))

        if not services:
            click.echo("No MCP services found.")
            return

        click.echo(f"\nTotal: {total} services\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<25}{'DISPLAY NAME':<20}{'PROTOCOL':<15}{'CONNECTION'}")
        click.echo("-" * 130)

        for svc in services:
            svc_id = svc.get("id", "")
            status = "●" if svc.get("isEnabled") else "○"
            name = svc.get("name", "N/A")[:23]
            display_name = svc.get("display_name", "")[:18]
            protocol_val = svc.get("protocolType") or svc.get("protocol_type") or "N/A"
            protocol = protocol_val[:13] if protocol_val else "N/A"
            connection = svc.get("connectionStatus", "unknown")
            click.echo(f"{svc_id:<40}{status:<10}{name:<25}{display_name:<20}{protocol:<15}{connection}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command()
@click.argument("tool_id")
def info(tool_id: str):
    """Get MCP tool details"""
    require_auth()
    client = get_client()

    try:
        tool = client.get(f"/api/mcp-tools/{tool_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"MCP Tool Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {tool.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {tool.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {tool.get('display_name', 'N/A')}")
        click.echo(f"{'Type':<20} {tool.get('tool_type', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Enabled' if tool.get('isEnabled') else '○ Disabled'}")
        click.echo(f"{'Version':<20} {tool.get('version', 'N/A')}")
        click.echo(f"{'Connection':<20} {tool.get('connectionStatus', 'N/A')}")
        click.echo(f"{'Description':<20} {tool.get('description', 'N/A')}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Statistics")
        click.echo(f"{'='*60}")
        click.echo(f"{'Total Calls':<20} {tool.get('totalCalls', 0)}")
        click.echo(f"{'Success Calls':<20} {tool.get('successCalls', 0)}")
        avg_time = tool.get('avgResponseTime')
        click.echo(f"{'Avg Response Time':<20} {avg_time if avg_time else 'N/A'}ms")
        click.echo(f"{'Error Rate':<20} {tool.get('errorRate', 0)}")
        last_used = tool.get('last_used_at')
        click.echo(f"{'Last Used':<20} {str(last_used)[:19] if last_used else 'N/A'}")

        source_config = tool.get("source_config", {})
        if source_config:
            click.echo(f"\n{'='*60}")
            click.echo(f"Source Config")
            click.echo(f"{'='*60}")
            service_url = source_config.get("service_url", "")
            if service_url:
                click.echo(f"  Service URL: {service_url}")
            protocol = source_config.get("protocol_type", "")
            if protocol:
                click.echo(f"  Protocol: {protocol}")
            timeout = source_config.get("timeout", "")
            if timeout:
                click.echo(f"  Timeout: {timeout}s")

        # HITL × Card 字段（API 响应里 camelCase）
        requires_approval = bool(tool.get("requiresApproval"))
        approval_decisions = tool.get("approvalDecisions") or []
        approval_template = tool.get("approvalDescriptionTemplate")
        # service 类型的 per-tool 白/黑名单（存在 configMetadata.hitl_per_tool）
        cfg_meta = tool.get("configMetadata") or {}
        per_tool = cfg_meta.get("hitl_per_tool") if isinstance(cfg_meta, dict) else None
        if requires_approval or approval_decisions or approval_template or per_tool:
            click.echo(f"\n{'='*60}")
            click.echo(f"HITL Approval (layer 1: tool default)")
            click.echo(f"{'='*60}")
            click.echo(f"  Requires Approval: {'yes' if requires_approval else 'no'}")
            if approval_decisions:
                click.echo(f"  Allowed Decisions: {', '.join(approval_decisions)}")
            if approval_template:
                click.echo(f"  Description Template: {approval_template}")
            if isinstance(per_tool, dict) and per_tool:
                mode = per_tool.get("mode") or "all"
                tools_list = per_tool.get("tools") or []
                click.echo(f"  Per-tool Mode: {mode}")
                if mode in ("whitelist", "blacklist") and tools_list:
                    label = "Whitelist" if mode == "whitelist" else "Blacklist"
                    click.echo(f"    {label} ({len(tools_list)}):")
                    for t in tools_list:
                        click.echo(f"      - {t}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command()
@click.argument("tool_id")
def test(tool_id: str):
    """Test MCP tool connection"""
    require_auth()
    client = get_client()

    click.echo(f"Testing MCP tool {tool_id}...")

    try:
        # Try mcp-services first (for service type), then mcp-tools (for registry type)
        try:
            response = client.post(f"/api/mcp-services/{tool_id}/test")
        except APIError:
            response = client.post(f"/api/mcp-tools/{tool_id}/test")

        if response.get("success"):
            click.echo("✓ Connection successful")
            if response.get("tools"):
                click.echo(f"Available tools: {', '.join(response['tools'])}")
        else:
            click.echo(f"✗ Test failed: {response.get('error', 'Unknown error')}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command()
@click.option("--name", "-n", required=True, help="Tool name")
@click.option("--type", "-t", "tool_type", required=True,
              type=click.Choice(["registry", "manual", "builtin", "service"]),
              help="Tool type")
@click.option("--display-name", "-d", default=None, help="Display name")
@click.option("--description", default=None, help="Tool description")
@click.option("--version", "-v", default=None, help="Tool version")
@click.option("--author", "-a", default=None, help="Tool author")
@click.option("--homepage", default=None, help="Tool homepage URL")
@click.option("--registry-url", default=None, help="Registry URL (for registry type)")
@click.option("--tool-name", default=None, help="Tool name in registry (for registry type)")
@click.option("--builtin-name", default=None, help="Builtin name (for builtin type)")
@click.option("--command", default=None, help="Command (for manual type)")
@click.option("--protocol", "-p", default=None,
              type=click.Choice(["sse", "streamable-http", "stdio"]),
              help="Protocol type (for service type)")
@click.option("--service-url", "-u", default=None, help="Service URL (for service type)")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds (1-300)")
@click.option("--max-retries", default=None, type=int, help="Max retries (0-10)")
@click.option("--concurrent-limit", default=None, type=int, help="Concurrent limit (1-100)")
@click.option("--enabled/--disabled", default=True, help="Enable tool after creation")
# HITL × Card：tool 自身（layer 1）的人工审批默认值
@click.option("--requires-approval/--no-requires-approval", default=None,
              help="HITL: this tool requires human approval before each call")
@click.option("--approval-decisions", default=None,
              help="HITL: comma-separated allowed decisions (approve,reject,edit). "
                   "Default approve,reject. Only meaningful when --requires-approval.")
@click.option("--approval-description", default=None,
              help="HITL: card description template, supports {tool_name}/{tool_args}/"
                   "{<arg_key>} placeholders.")
# HITL service-level whitelist/blacklist (only meaningful for service type with multiple tools)
@click.option("--hitl-mode", "hitl_mode", default=None,
              type=click.Choice(["all", "whitelist", "blacklist"]),
              help="HITL: per-tool mode for service-type MCPs. 'all' (default) = every tool "
                   "follows --requires-approval; 'whitelist' = only --hitl-tool ones require approval; "
                   "'blacklist' = --hitl-tool ones bypass, others require approval.")
@click.option("--hitl-tool", "hitl_tools", multiple=True,
              help="HITL: tool name to include in --hitl-mode whitelist/blacklist. Repeatable.")
def create(name: str, tool_type: str, display_name: str, description: str, version: str,
           author: str, homepage: str, registry_url: str, tool_name: str, builtin_name: str,
           command: str, protocol: str, service_url: str, timeout: int, max_retries: int,
           concurrent_limit: int, enabled: bool,
           requires_approval: bool | None, approval_decisions: str | None,
           approval_description: str | None,
           hitl_mode: str | None, hitl_tools: tuple):
    """Create a new MCP tool"""
    require_auth()
    client = get_client()

    # Build sourceConfig based on tool type
    source_config = {}
    if tool_type == "registry":
        if not registry_url or not tool_name:
            click.echo("✗ Registry type requires --registry-url and --tool-name", err=True)
            return
        source_config = {"registry_url": registry_url, "tool_name": tool_name}
    elif tool_type == "manual":
        if command:
            source_config = {"command": command}
    elif tool_type == "builtin":
        if not builtin_name:
            click.echo("✗ Builtin type requires --builtin-name", err=True)
            return
        source_config = {"builtin_name": builtin_name}

    data = {
        "name": name,
        "toolType": tool_type,
        "sourceConfig": source_config,
        "isEnabled": enabled,
    }
    if display_name:
        data["displayName"] = display_name
    if description:
        data["description"] = description
    if version:
        data["version"] = version
    if author:
        data["author"] = author
    if homepage:
        data["homepage"] = homepage
    if protocol:
        data["protocolType"] = protocol
    if service_url:
        data["serviceUrl"] = service_url
    if timeout is not None:
        data["timeout"] = timeout
    if max_retries is not None:
        data["maxRetries"] = max_retries
    if concurrent_limit is not None:
        data["concurrentLimit"] = concurrent_limit

    # HITL fields (layer 1 default; orchestrator/application can still override)
    if requires_approval is not None:
        data["requiresApproval"] = requires_approval
    if approval_decisions is not None:
        decisions = [d.strip() for d in approval_decisions.split(",") if d.strip()]
        invalid = [d for d in decisions if d not in {"approve", "reject", "edit"}]
        if invalid:
            click.echo(f"✗ Invalid decisions: {invalid}. Allowed: approve / reject / edit", err=True)
            return
        data["approvalDecisions"] = decisions
    if approval_description is not None:
        data["approvalDescriptionTemplate"] = approval_description

    # service-level HITL per-tool whitelist/blacklist → configMetadata.hitl_per_tool
    if hitl_mode is not None or hitl_tools:
        per_tool = {"mode": hitl_mode or "all"}
        if per_tool["mode"] in ("whitelist", "blacklist"):
            per_tool["tools"] = list(hitl_tools)
        elif hitl_tools:
            click.echo("⚠️ --hitl-tool ignored (only meaningful with --hitl-mode whitelist/blacklist)")
        data["configMetadata"] = {"hitl_per_tool": per_tool}

    try:
        tool = client.post("/api/mcp-tools", json=data)
        click.echo(f"✓ MCP tool created: {tool['name']} [{tool['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command()
@click.argument("tool_id")
@click.option("--name", "-n", default=None, help="Tool name")
@click.option("--display-name", "-d", default=None, help="Display name")
@click.option("--description", default=None, help="Tool description")
@click.option("--enabled/--disabled", default=None, help="Enable/disable tool")
# HITL × Card
@click.option("--requires-approval/--no-requires-approval", default=None,
              help="HITL: toggle whether this tool requires human approval")
@click.option("--approval-decisions", default=None,
              help="HITL: comma-separated allowed decisions (approve,reject,edit)")
@click.option("--approval-description", default=None,
              help="HITL: card description template (supports {tool_name}/{tool_args}/{arg_key})")
# HITL service-level whitelist/blacklist
@click.option("--hitl-mode", "hitl_mode", default=None,
              type=click.Choice(["all", "whitelist", "blacklist"]),
              help="HITL: per-tool mode for service-type MCPs (all/whitelist/blacklist).")
@click.option("--hitl-tool", "hitl_tools", multiple=True,
              help="HITL: tool name list for whitelist/blacklist mode. Repeatable.")
@click.option("--clear-hitl-per-tool", "clear_hitl_per_tool", is_flag=True, default=False,
              help="HITL: remove the per-tool whitelist/blacklist (revert to mode=all).")
def update(tool_id: str, name: str, display_name: str, description: str, enabled: bool,
           requires_approval: bool | None, approval_decisions: str | None,
           approval_description: str | None,
           hitl_mode: str | None, hitl_tools: tuple, clear_hitl_per_tool: bool):
    """Update an MCP tool"""
    require_auth()
    client = get_client()

    data = {}
    if name:
        data["name"] = name
    if display_name:
        data["displayName"] = display_name
    if description is not None:
        data["description"] = description
    if enabled is not None:
        data["isEnabled"] = enabled

    if requires_approval is not None:
        data["requiresApproval"] = requires_approval
    if approval_decisions is not None:
        decisions = [d.strip() for d in approval_decisions.split(",") if d.strip()]
        invalid = [d for d in decisions if d not in {"approve", "reject", "edit"}]
        if invalid:
            click.echo(f"✗ Invalid decisions: {invalid}. Allowed: approve / reject / edit", err=True)
            return
        data["approvalDecisions"] = decisions
    if approval_description is not None:
        data["approvalDescriptionTemplate"] = approval_description

    # configMetadata 在后端是直接赋值（不合并），需要先 GET 再 merge 防止
    # 把其它字段（tags / 自定义元数据）一起覆盖掉。
    if hitl_mode is not None or hitl_tools or clear_hitl_per_tool:
        try:
            existing = client.get(f"/api/mcp-tools/{tool_id}")
        except APIError as e:
            click.echo(f"✗ Error fetching tool for HITL merge: {e}", err=True)
            return
        existing_meta = dict(existing.get("configMetadata") or {})
        if clear_hitl_per_tool:
            existing_meta.pop("hitl_per_tool", None)
        else:
            per_tool = {"mode": hitl_mode or existing_meta.get("hitl_per_tool", {}).get("mode", "all")}
            if per_tool["mode"] in ("whitelist", "blacklist"):
                # 如果只调 mode 不传 tools，保留既有 list
                if hitl_tools:
                    per_tool["tools"] = list(hitl_tools)
                else:
                    prev = existing_meta.get("hitl_per_tool", {}).get("tools") or []
                    per_tool["tools"] = list(prev)
            elif hitl_tools:
                click.echo("⚠️ --hitl-tool ignored (only meaningful with --hitl-mode whitelist/blacklist)")
            existing_meta["hitl_per_tool"] = per_tool
        data["configMetadata"] = existing_meta

    if not data:
        click.echo("✗ No updates provided", err=True)
        return

    try:
        tool = client.put(f"/api/mcp-tools/{tool_id}", json=data)
        click.echo(f"✓ MCP tool updated: {tool['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@mcp_group.command()
@click.argument("tool_id")
def delete(tool_id: str):
    """Delete an MCP tool"""
    require_auth()

    if not click.confirm(f"Are you sure you want to delete MCP tool {tool_id}?"):
        return

    client = get_client()

    try:
        client.delete(f"/api/mcp-tools/{tool_id}")
        click.echo(f"✓ MCP tool deleted")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
