"""Sandbox (sandrpod) management commands.

Covers the operational surface admins / ops teams hit most often via CLI:

  siracli sandbox config    sandrpod backend (api_url / agent_facing_url / token)
  siracli sandbox list      list sandboxes (user / dedicated / all)
  siracli sandbox enroll    generate enrollment ticket → install command
  siracli sandbox dedicated create / delete    admin-managed corp-shared sandboxes
  siracli sandbox revoke    revoke a sandbox by id
  siracli sandbox audit     query AI decision audit (allow/deny per path/exec/pty)

For features not exposed here (PTY interactive shell, file browsing, exec) use
the admin web UI — those are heavily UI-driven and have no good CLI ergonomic.
"""

import click
from ..client import get_client, APIError
from ..config import is_authenticated


def require_auth():
    """Check if user is authenticated."""
    if not is_authenticated():
        click.echo("✗ Not logged in. Run 'siracli auth login' first.", err=True)
        raise click.Abort()


def _format_dt(dt: str | None) -> str:
    """Truncate ISO timestamps to YYYY-MM-DD HH:MM."""
    if not dt:
        return "—"
    return dt[:16].replace("T", " ")


def _structured_detail(exc: APIError) -> dict | None:
    """Return the structured ``detail`` payload of an APIError, or None.

    Sandbox API uses ``HTTPException(detail={"code": ..., "message": ..., ...})``
    for business errors so the CLI can render them prettier than the raw repr.
    """
    if exc.response is None:
        return None
    detail = exc.response.get("detail") if isinstance(exc.response, dict) else None
    if isinstance(detail, dict):
        return detail
    return None


def _abort_pretty_409(exc: APIError) -> None:
    """Pretty-print known sandbox conflict errors. Always aborts."""
    detail = _structured_detail(exc)
    code = (detail or {}).get("code") or ""

    if code == "USER_SANDBOX_ALREADY_EXISTS":
        existing = (detail or {}).get("existing_sandbox") or {}
        click.echo(
            click.style(
                "✗ You already have an active sandbox.",
                fg="red",
                bold=True,
            ),
            err=True,
        )
        click.echo("", err=True)
        click.echo(f"  id:          {existing.get('id') or '—'}", err=True)
        click.echo(f"  name:        {existing.get('display_name') or existing.get('sandbox_name') or '—'}", err=True)
        click.echo(f"  type:        {existing.get('type') or '—'}", err=True)
        click.echo(f"  status:      {existing.get('status') or '—'}", err=True)
        click.echo(f"  os/arch:     {existing.get('os') or '—'} / {existing.get('arch') or '—'}", err=True)
        click.echo(f"  last seen:   {_format_dt(existing.get('last_seen_at'))}", err=True)
        click.echo("", err=True)
        click.echo(
            "  Each user can have at most one sandbox at a time. To re-enroll, first revoke:",
            err=True,
        )
        click.echo(
            click.style(
                f"    siracli sandbox revoke {existing.get('id')}",
                fg="cyan",
            ),
            err=True,
        )
        raise click.Abort()

    if code == "CORP_SANDRPOD_NOT_CONFIGURED":
        click.echo(
            click.style("✗ Corp sandrpod backend not configured.", fg="red", bold=True),
            err=True,
        )
        click.echo(
            "  An admin must configure the sandrpod URL + token first:",
            err=True,
        )
        click.echo(
            click.style(
                "    siracli sandbox config set --api-url ... --agent-facing-url ... --token ...",
                fg="cyan",
            ),
            err=True,
        )
        raise click.Abort()

    if code == "ENROLLMENT_INVALID":
        msg = (detail or {}).get("message") or "enrollment ticket invalid"
        click.echo(click.style(f"✗ {msg}", fg="red"), err=True)
        click.echo(
            "  The ticket may have been consumed, expired, or revoked. "
            "Generate a new one with 'siracli sandbox enroll'.",
            err=True,
        )
        raise click.Abort()

    # Unknown structured error — fall back to the generic message
    msg = (detail or {}).get("message") if detail else None
    click.echo(f"✗ {msg or exc}", err=True)
    raise click.Abort()


# ---------------------------------------------------------------------------
# Group root
# ---------------------------------------------------------------------------


@click.group(name="sandbox")
def sandbox_group():
    """Sandbox (sandrpod) management"""
    pass


# ---------------------------------------------------------------------------
# Corp config (sandrpod backend)
# ---------------------------------------------------------------------------


@sandbox_group.group(name="config")
def config_group():
    """Sandrpod backend configuration"""
    pass


@config_group.command(name="get")
def config_get():
    """Show current sandrpod backend config (api_url / agent_facing_url)."""
    require_auth()
    try:
        cfg = get_client().get("/api/agent-system/sandboxes/config")
    except APIError as exc:
        if exc.status_code == 404:
            click.echo("(not configured) — run 'siracli sandbox config set ...' first")
            return
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    click.echo(f"  api_url:           {cfg.get('api_url') or '—'}")
    click.echo(f"  agent_facing_url:  {cfg.get('agent_facing_url') or '—'}")
    click.echo(f"  token:             {'(set)' if cfg.get('has_token') else '(unset)'}")
    click.echo(f"  updated_at:        {_format_dt(cfg.get('updated_at'))}")


@config_group.command(name="set")
@click.option("--api-url", required=True, help="Sandrpod admin API URL (used by backend)")
@click.option(
    "--agent-facing-url",
    required=True,
    help="Sandrpod URL the employee's agent connects to (often same network or DMZ)",
)
@click.option("--token", required=True, help="Sandrpod corp token (encrypted at rest via Fernet)")
def config_set(api_url: str, agent_facing_url: str, token: str):
    """Set sandrpod backend config for this organization."""
    require_auth()
    try:
        cfg = get_client().put(
            "/api/agent-system/sandboxes/config",
            json={
                "api_url": api_url,
                "agent_facing_url": agent_facing_url,
                "token": token,
            },
        )
        click.echo("✓ Config updated")
        click.echo(f"  api_url:          {cfg.get('api_url')}")
        click.echo(f"  agent_facing_url: {cfg.get('agent_facing_url')}")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


@config_group.command(name="test")
def config_test():
    """Try connecting to the configured sandrpod backend."""
    require_auth()
    try:
        result = get_client().post("/api/agent-system/sandboxes/config/test")
        ok = result.get("ok") or result.get("success")
        if ok:
            click.echo(f"✓ {result.get('message') or 'reachable'}")
        else:
            click.echo(f"✗ {result.get('message') or 'unreachable'}", err=True)
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


# ---------------------------------------------------------------------------
# List / get / revoke
# ---------------------------------------------------------------------------


@sandbox_group.command(name="list")
@click.option(
    "--scope",
    type=click.Choice(["mine", "dedicated", "all"]),
    default="mine",
    help=(
        "mine (default) = current user's PC sandbox (0/1); "
        "dedicated = corp-shared sandboxes; "
        "all = full corp view (admin only)"
    ),
)
def sandbox_list(scope: str):
    """List sandboxes (scope-filtered).

    Backend's ``GET /sandboxes`` supports three scopes; this command exposes
    them directly. There's no per-status filter at the API layer — pipe the
    output through ``grep`` for ad-hoc filtering.
    """
    require_auth()
    try:
        response = get_client().get(
            "/api/agent-system/sandboxes", params={"scope": scope}
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    items = response.get("items", []) if isinstance(response, dict) else response
    if not items:
        click.echo("No sandboxes found.")
        return

    click.echo(f"\nTotal: {len(items)} sandboxes\n")
    click.echo(
        f"{'ID':<38}{'OWNER':<8}{'STATUS':<10}{'NAME':<24}{'LAST SEEN':<18}"
    )
    click.echo("-" * 100)
    for sb in items:
        sid = (sb.get("id") or "")[:36]
        owner_t = sb.get("owner_type") or "—"
        st = sb.get("status") or "—"
        name = (sb.get("display_name") or sb.get("name") or "—")[:22]
        last = _format_dt(sb.get("last_seen_at") or sb.get("last_heartbeat_at"))
        click.echo(f"{sid:<38}{owner_t:<8}{st:<10}{name:<24}{last:<18}")
    click.echo()


@sandbox_group.command(name="get")
@click.argument("sandbox_id")
def sandbox_get(sandbox_id: str):
    """Show full sandbox detail."""
    require_auth()
    try:
        sb = get_client().get(f"/api/agent-system/sandboxes/by-id/{sandbox_id}")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    for k, v in sb.items():
        if isinstance(v, (dict, list)):
            import json as _json
            v = _json.dumps(v, ensure_ascii=False, indent=2)
        click.echo(f"{k:<22} {v}")


@sandbox_group.command(name="revoke")
@click.argument("sandbox_id")
@click.confirmation_option(prompt="Revoke this sandbox? Agent will lose access immediately.")
def sandbox_revoke(sandbox_id: str):
    """Revoke a sandbox (own user_sandbox or any if admin)."""
    require_auth()
    try:
        get_client().delete(f"/api/agent-system/sandboxes/by-id/{sandbox_id}")
        click.echo(f"✓ Sandbox {sandbox_id} revoked")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


# ---------------------------------------------------------------------------
# Enrollment (employee PC sandbox provisioning)
# ---------------------------------------------------------------------------


@sandbox_group.command(name="enroll")
@click.option(
    "--user",
    "user_id",
    default=None,
    help="Generate for this user (admin only). Omit to generate for self.",
)
@click.option(
    "--ttl-min",
    "ttl_minutes",
    default=10,
    type=click.IntRange(1, 120),
    help="Ticket TTL in minutes (1–120)",
)
def sandbox_enroll(user_id: str | None, ttl_minutes: int):
    """Generate an enrollment ticket → install command for a user PC.

    Output:
      - enrollment_id (poll status with siracli sandbox enroll-status)
      - JWT (10-min default TTL)
      - one-line install command — paste into the user's terminal
    """
    require_auth()
    payload: dict = {"ttl_seconds": ttl_minutes * 60}
    if user_id:
        payload["user_id"] = user_id
    try:
        ticket = get_client().post(
            "/api/agent-system/sandboxes/enrollment", json=payload
        )
    except APIError as exc:
        # 409 conflict with structured detail → pretty render it.
        # Also handles 424 (corp not configured) which has the same shape.
        if exc.status_code in (409, 424, 400):
            _abort_pretty_409(exc)
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    click.echo(f"✓ Enrollment ticket generated")
    click.echo(f"  id:          {ticket.get('id')}")
    click.echo(f"  expires_at:  {ticket.get('expires_at')}")
    click.echo()
    click.echo("Install command (run on the employee's PC):")
    click.echo(f"  {ticket.get('install_command')}")


@sandbox_group.command(name="enroll-status")
@click.argument("enrollment_id")
def sandbox_enroll_status(enrollment_id: str):
    """Poll enrollment ticket status (pending / consumed / expired)."""
    require_auth()
    try:
        row = get_client().get(
            f"/api/agent-system/sandboxes/enrollment/{enrollment_id}"
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    click.echo(f"  status:              {row.get('status')}")
    click.echo(f"  consumed_at:         {_format_dt(row.get('consumed_at'))}")
    click.echo(f"  consumed_sandbox_id: {row.get('consumed_sandbox_id') or '—'}")
    click.echo(f"  expires_at:          {row.get('expires_at')}")


@sandbox_group.command(name="enroll-revoke")
@click.argument("enrollment_id")
def sandbox_enroll_revoke(enrollment_id: str):
    """Revoke a not-yet-consumed enrollment ticket."""
    require_auth()
    try:
        get_client().delete(
            f"/api/agent-system/sandboxes/enrollment/{enrollment_id}"
        )
        click.echo(f"✓ Enrollment {enrollment_id} revoked")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


# ---------------------------------------------------------------------------
# Dedicated sandbox (admin)
# ---------------------------------------------------------------------------


@sandbox_group.group(name="dedicated")
def dedicated_group():
    """Corp-shared dedicated sandboxes (ENTERPRISE feature)."""
    pass


@dedicated_group.command(name="create")
@click.option("--name", "display_name", required=True, help="Display name for the sandbox")
@click.option(
    "--type",
    "type_",
    default="podman",
    type=click.Choice(["podman", "docker", "vm"]),
    help="Sandbox runtime type",
)
@click.option("--image", required=True, help="Container image ref")
def dedicated_create(display_name: str, type_: str, image: str):
    """Create a dedicated (corp-shared) sandbox. Admin only.

    Requires license feature ``sandbox.dedicated`` (ENTERPRISE).
    """
    require_auth()
    try:
        sb = get_client().post(
            "/api/agent-system/sandboxes/dedicated",
            json={"display_name": display_name, "type": type_, "image": image},
        )
        click.echo(f"✓ Dedicated sandbox created")
        click.echo(f"  id:    {sb.get('id')}")
        click.echo(f"  type:  {sb.get('type')}")
        click.echo(f"  image: {sb.get('image')}")
    except APIError as exc:
        if exc.status_code == 402:
            click.echo("✗ License denies sandbox.dedicated (requires ENTERPRISE)", err=True)
        else:
            click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


@dedicated_group.command(name="list")
def dedicated_list():
    """List dedicated (corp-shared) sandboxes for this org."""
    require_auth()
    try:
        response = get_client().get(
            "/api/agent-system/sandboxes", params={"scope": "dedicated"}
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    items = response.get("items", []) if isinstance(response, dict) else response
    if not items:
        click.echo("No dedicated sandboxes.")
        return
    for sb in items:
        click.echo(f"  {sb.get('id')}  {(sb.get('display_name') or sb.get('name') or '—'):<24} {sb.get('status')}")


# ---------------------------------------------------------------------------
# Decision audit (Sprint 4 — sandbox.decision_audit, ENTERPRISE)
# ---------------------------------------------------------------------------


@sandbox_group.command(name="audit")
@click.option("--sandbox-id", default=None, help="Filter by sandbox id (required for non-admins)")
@click.option(
    "--source",
    type=click.Choice(["path", "exec", "pty"]),
    default=None,
    help="Filter by audit source",
)
@click.option(
    "--decision",
    type=click.Choice(["allow", "deny", "warn"]),
    default=None,
    help="Filter by decision outcome",
)
@click.option("--limit", "-l", default=50, type=click.IntRange(1, 500), help="Max rows")
def sandbox_audit(
    sandbox_id: str | None, source: str | None, decision: str | None, limit: int
):
    """Query AI decision audit log (path/exec/PTY consent records).

    Requires license feature ``sandbox.decision_audit`` (ENTERPRISE).
    """
    require_auth()
    params: dict = {"limit": limit}
    if sandbox_id:
        params["sandbox_id"] = sandbox_id
    if source:
        params["source"] = source
    if decision:
        params["decision"] = decision

    try:
        rows = get_client().get(
            "/api/agent-system/sandboxes/audit/decisions", params=params
        )
    except APIError as exc:
        if exc.status_code == 402:
            click.echo("✗ License denies sandbox.decision_audit (requires ENTERPRISE)", err=True)
        else:
            click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    items = rows.get("items", []) if isinstance(rows, dict) else rows
    total = rows.get("total", len(items)) if isinstance(rows, dict) else len(items)
    if not items:
        click.echo("No audit events.")
        return
    click.echo(f"\nTotal: {total} decision events\n")
    click.echo(f"{'TIME':<18}{'SOURCE':<8}{'DECISION':<10}{'TARGET':<60}")
    click.echo("-" * 100)
    for row in items:
        ts = _format_dt(row.get("occurred_at"))
        src = row.get("source") or "—"
        dec = row.get("decision") or "—"
        target = (row.get("target") or row.get("path") or row.get("command") or "—")[:58]
        # Color the deny rows; click prints ANSI when stdout is a tty
        if dec == "deny":
            line = click.style(f"{ts:<18}{src:<8}{dec:<10}{target:<60}", fg="red")
        else:
            line = f"{ts:<18}{src:<8}{dec:<10}{target:<60}"
        click.echo(line)
    click.echo()
