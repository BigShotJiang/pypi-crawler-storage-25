"""GenAI Toolbox management commands"""

import click
from ..client import get_client, APIError
from ..utils import require_auth


@click.group(name="toolbox")
def toolbox_group():
    """GenAI Toolbox management"""
    pass


@toolbox_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--name", "-n", default=None, help="Filter by name")
@click.option("--use-case", "-u", default=None, help="Filter by use case")
@click.option("--active/--all", default=None, help="Show only active toolsets")
def toolbox_list(page: int, limit: int, name: str, use_case: str, active: bool):
    """List all toolbox toolsets"""
    require_auth()
    client = get_client()

    offset = (page - 1) * limit
    params = {"limit": limit, "offset": offset}
    if name:
        params["name"] = name
    if use_case:
        params["use_case"] = use_case
    if active is not None:
        params["is_active"] = active

    try:
        response = client.get("/api/genai-toolbox/toolsets", params=params)
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No toolsets found.")
            return

        click.echo(f"\nTotal: {total} toolsets\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<25}{'DISPLAY NAME':<25}{'USE CASE':<15}")
        click.echo("-" * 120)

        for ts in items:
            ts_id = ts.get("id", "")
            status = "●" if ts.get("is_active") else "○"
            ts_name = ts.get("name", "N/A")[:23]
            display_name = ts.get("display_name", "")[:23]
            use_case_val = (ts.get("use_case") or "N/A")[:13]
            click.echo(f"{ts_id:<40}{status:<10}{ts_name:<25}{display_name:<25}{use_case_val:<15}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@toolbox_group.command()
@click.argument("toolset_id")
def info(toolset_id: str):
    """Get toolbox toolset details"""
    require_auth()
    client = get_client()

    try:
        ts = client.get(f"/api/genai-toolbox/toolsets/{toolset_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Toolset Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {ts.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {ts.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {ts.get('display_name', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Active' if ts.get('is_active') else '○ Inactive'}")
        click.echo(f"{'Use Case':<20} {ts.get('use_case', 'N/A')}")
        click.echo(f"{'Tags':<20} {', '.join(ts.get('tags', []) or ['N/A'])}")
        click.echo(f"{'Tool Count':<20} {len(ts.get('tool_ids', []))}")
        click.echo(f"{'Created At':<20} {str(ts.get('created_at', 'N/A'))[:19]}")

        description = ts.get("description")
        if description:
            click.echo(f"\n{'='*60}")
            click.echo(f"Description")
            click.echo(f"{'='*60}")
            click.echo(f"{description}")

        tool_ids = ts.get("tool_ids", [])
        if tool_ids:
            click.echo(f"\n{'='*60}")
            click.echo(f"Tool IDs ({len(tool_ids)})")
            click.echo(f"{'='*60}")
            for tid in tool_ids:
                click.echo(f"  - {tid}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
