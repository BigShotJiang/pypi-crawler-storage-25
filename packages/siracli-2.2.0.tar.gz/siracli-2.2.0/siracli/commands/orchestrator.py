"""Orchestrator management commands"""

import click
import json
import uuid
from ..client import get_client, APIError
from ..config import get_api_url
from ..utils import require_auth, render_delete_conflict


def _build_interrupt_on_dict(
    *,
    enable: tuple[str, ...],
    disable: tuple[str, ...],
    json_blob: str | None,
) -> dict | None:
    """合并 ``--interrupt-on`` / ``--interrupt-off`` / ``--interrupt-on-json`` 为
    后端期望的 ``interrupt_on`` dict。

    优先级：JSON blob 提供完整 baseline，再被 enable / disable 逐 key 覆盖。
    返回 None 表示用户没传任何 HITL flag（caller 决定是保留旧值还是清空）。
    """
    if not enable and not disable and not json_blob:
        return None

    base: dict = {}
    if json_blob:
        try:
            parsed = json.loads(json_blob)
        except json.JSONDecodeError as e:
            raise click.UsageError(f"--interrupt-on-json 解析失败: {e}")
        if not isinstance(parsed, dict):
            raise click.UsageError("--interrupt-on-json 必须是 JSON 对象")
        base.update(parsed)

    for tool_name in enable:
        base[tool_name] = True
    for tool_name in disable:
        base[tool_name] = False

    return base


@click.group(name="orchestrator")
def orchestrator_group():
    """Orchestrator management"""
    pass


@orchestrator_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
def orchestrator_list(page: int, limit: int):
    """List all orchestrators"""
    require_auth()
    client = get_client()

    try:
        response = client.get("/api/agent-system/orchestrators", params={
            "page": page,
            "limit": limit
        })
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No orchestrators found.")
            return

        click.echo(f"\nTotal: {total} orchestrators\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'DISPLAY NAME':<22}{'NAME':<25}{'TYPE'}")
        click.echo("-" * 110)

        for orch in items:
            orch_id = orch["id"]
            status = "●" if orch.get("is_active") else "○"
            display_name = (orch.get("display_name") or orch["name"])[:20]
            name = orch["name"][:23]
            orch_type = orch.get("orchestration_type", "N/A")
            click.echo(f"{orch_id:<40}{status:<10}{display_name:<22}{name:<25}{orch_type}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@orchestrator_group.command()
@click.argument("orchestrator_id")
def get(orchestrator_id: str):
    """Get orchestrator details"""
    require_auth()
    client = get_client()

    try:
        orch = client.get(f"/api/agent-system/orchestrators/{orchestrator_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Orchestrator Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {orch['id']}")
        click.echo(f"{'Name':<20} {orch.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {orch.get('display_name', 'N/A')}")
        click.echo(f"{'Type':<20} {orch.get('orchestration_type', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Active' if orch.get('is_active') else '○ Inactive'}")
        click.echo(f"{'Created At':<20} {orch.get('created_at', 'N/A')[:19]}")

        # Show agent ID based on orchestration type
        orch_type = orch.get("orchestration_type", "").upper()
        if orch_type == "SINGLE":
            agent_id = orch.get("agent_id", "")
            if agent_id:
                click.echo(f"{'Agent ID':<20} {agent_id}")
        elif orch_type == "SUPERVISOR":
            supervisor = orch.get("supervisor_config", {})
            sub_agents = supervisor.get("sub_agent_ids", [])
            if sub_agents:
                click.echo(f"\nSupervisor Config:")
                click.echo(f"  Sub Agents: {', '.join(sub_agents)}")
        elif orch_type == "COLLABORATION":
            collab = orch.get("collaboration_config", {})
            agent_ids = collab.get("agent_ids", [])
            if agent_ids:
                click.echo(f"\nCollaboration Config:")
                click.echo(f"  Strategy: {collab.get('collaboration_strategy', 'N/A')}")
                click.echo(f"  Agents ({len(agent_ids)}):")
                for aid in agent_ids:
                    click.echo(f"    - {aid}")
        elif orch_type == "DEEP_AGENTS":
            deep = orch.get("deep_agents_config", {})
            click.echo(f"\nDeep Agents Config:")
            click.echo(f"  AI Model ID: {deep.get('ai_model_id', 'N/A')}")
            if deep.get('subagent_default_model_id'):
                click.echo(f"  SubAgent Default Model: {deep.get('subagent_default_model_id')}")
            if deep.get('system_prompt'):
                prompt = deep.get('system_prompt', '')
                display = prompt[:100] + '...' if len(prompt) > 100 else prompt
                click.echo(f"  System Prompt: {display}")

            # Show subagents
            subagents = deep.get("subagents", [])
            if subagents:
                click.echo(f"  SubAgents ({len(subagents)}):")
                for sa in subagents:
                    sa_type = sa.get("type", "unknown")
                    if sa_type == "agent_ref":
                        click.echo(f"    - agent_ref: {sa.get('agent_id', 'N/A')}")
                    elif sa_type == "predefined":
                        click.echo(f"    - predefined: {sa.get('name', 'N/A')}")

            # Show tools
            tool_ids = deep.get("tool_ids", [])
            if tool_ids:
                click.echo(f"  Tool IDs ({len(tool_ids)}):")
                for tid in tool_ids:
                    click.echo(f"    - {tid}")

            # Show skills
            skill_ids = deep.get("skill_ids", [])
            if skill_ids:
                click.echo(f"  Skill IDs ({len(skill_ids)}):")
                for sid in skill_ids:
                    click.echo(f"    - {sid}")

            click.echo(f"  Backend Type: {deep.get('backend_type', 'N/A')}")

            # Show long-term memory config
            mem = deep.get("memory_config") or {}
            mem_enabled = mem.get("enabled", True)
            click.echo(f"  Memory: {'Enabled' if mem_enabled else 'Disabled'}")
            if mem_enabled:
                mem_dir = mem.get("memory_dir") or "(auto: backend work_dir/memories)"
                click.echo(f"    Dir: {mem_dir}")
                click.echo(f"    Main File: {mem.get('main_file') or 'AGENTS.md'}")
                click.echo(f"    Recent Days: {mem.get('recent_days') or 7}")

            langgraph = orch.get("langgraph_config", {})
            if langgraph:
                click.echo(f"  Recursion Limit: {langgraph.get('recursion_limit', 'N/A')}")
                click.echo(f"  Checkpoint: {'Enabled' if langgraph.get('checkpoint_enabled') else 'Disabled'}")

        # HITL × Card 字段（layer 2: orchestrator）—— 任意编排器类型都可能有
        # （后端读 ``deep_agents_config.hitl_disabled / interrupt_on`` 不区分 type）。
        deep_for_hitl = orch.get("deep_agents_config") or {}
        hitl_silent = bool(deep_for_hitl.get("hitl_disabled"))
        interrupt_on = deep_for_hitl.get("interrupt_on") or {}
        if hitl_silent or interrupt_on:
            click.echo(f"\nHITL (orchestrator layer):")
            if hitl_silent:
                click.echo(f"  🔇 hitl_disabled = true (整编排器静默)")
            if interrupt_on:
                click.echo(f"  interrupt_on ({len(interrupt_on)} rules):")
                for tool_name, raw in interrupt_on.items():
                    if raw is True:
                        click.echo(f"    - {tool_name}: ✓ (use tool default)")
                    elif raw is False:
                        click.echo(f"    - {tool_name}: ✗ (explicitly disabled)")
                    elif isinstance(raw, dict):
                        decisions = raw.get("allowed_decisions") or []
                        desc = raw.get("description")
                        click.echo(f"    - {tool_name}: decisions={decisions}"
                                   + (f" desc={desc!r}" if desc else ""))

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@orchestrator_group.command()
@click.option("--name", "-n", required=True, help="Orchestrator name")
@click.option("--display-name", "-D", required=True, help="Display name")
@click.option("--type", "-t", "orchestration_type", required=True,
              type=click.Choice(["single", "supervisor", "collaboration", "deep_agents"]),
              help="Orchestration type (workflow/conditional/external/knowledge_base: use web console)")
@click.option("--description", "-d", default="", help="Description")
@click.option("--agent-id", "-a", default=None, help="Agent ID (for single type)")
@click.option("--agents", multiple=True, help="Agent IDs (for supervisor/collaboration)")
@click.option("--supervisor-agent-id", default=None, help="Supervisor agent ID (for supervisor type)")
@click.option("--collaboration-strategy", default=None,
              type=click.Choice(["sequential", "parallel"]),
              help="Collaboration strategy (for collaboration type)")
# DeepAgents specific options
@click.option("--ai-model-id", default=None, help="AI model ID (for deep_agents type)")
@click.option("--subagent-model-id", default=None, help="Default SubAgent model ID (for deep_agents type)")
@click.option("--subagent", multiple=True, help="SubAgent ID (for deep_agents type, format: agent_id or type:name)")
@click.option("--skill", multiple=True, help="Skill ID (for deep_agents type)")
@click.option("--tool", multiple=True, help="Tool ID (for deep_agents type)")
@click.option("--system-prompt", default=None, help="System prompt (for deep_agents type)")
@click.option("--backend-type", default="state",
              type=click.Choice(["state", "store", "filesystem", "local_shell", "sandrpod"]),
              help="Backend type (for deep_agents type)")
@click.option("--backend-path", default=None, help="Backend base path (for deep_agents filesystem type)")
@click.option("--sandrpod-api-url", default=None, help="SandrPod Server API URL (for sandrpod type)")
@click.option("--sandrpod-sandbox", default=None, help="SandrPod sandbox name (for sandrpod type)")
@click.option("--sandrpod-api-key", default=None, help="SandrPod API key (for sandrpod type)")
@click.option("--sandrpod-use-session/--sandrpod-no-use-session", default=True, help="Use session mode for SandrPod (for sandrpod type)")
# DeepAgents long-term memory (memory_config; Layer 3 — AGENTS.md + YYYY-MM-DD.md)
@click.option("--memory-enabled/--no-memory-enabled", "memory_enabled", default=None,
              help="Enable long-term memory (default: on; ignored when backend-type=state)")
@click.option("--memory-dir", default=None,
              help="Memory directory absolute path (default: empty = derived from backend's work_dir)")
@click.option("--memory-main-file", default=None,
              help="Main index filename (default: AGENTS.md)")
@click.option("--memory-recent-days", default=None, type=int,
              help="Load last N days of dated memory files (default: 7)")
@click.option("--recursion-limit", default=25, type=int, help="LangGraph recursion limit")
@click.option("--enable-checkpoint/--disable-checkpoint", default=True, help="Enable checkpointing")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds (1-600)")
@click.option("--max-concurrent-agents", default=None, type=int, help="Max concurrent agents (1-20)")
@click.option("--enabled/--disabled", default=True, help="Enable orchestrator after creation")
# HITL × Card — see devdocs/HITL_INTERACTIVE_CARD_DESIGN.md §4
# 任意 ReAct 类型（single / supervisor / collaboration / deep_agents）都生效——
# 后端从 ``deep_agents_config`` 这个 JSONB 列读取，不区分 orchestration_type。
@click.option("--hitl-disabled/--no-hitl-disabled", "hitl_disabled", default=None,
              help="HITL: silence the whole orchestrator (overrides any tool/app HITL)")
@click.option("--interrupt-on", "interrupt_on", multiple=True,
              help="HITL: tool name to enable approval for (use tool's default decisions). "
                   "Repeatable. Equivalent to {TOOL: true} in interrupt_on dict.")
@click.option("--interrupt-off", "interrupt_off", multiple=True,
              help="HITL: tool name to explicitly disable approval (override tool layer's "
                   "requires_approval=true). Repeatable.")
@click.option("--interrupt-on-json", "interrupt_on_json", default=None,
              help="HITL: full interrupt_on dict as JSON. "
                   '''Example: --interrupt-on-json '{"delete_db": true, '''
                   '''"execute": {"allowed_decisions": ["approve","reject"]}}'. '''
                   "Merged with --interrupt-on / --interrupt-off (those win on key collision).")
def create(name: str, display_name: str, orchestration_type: str, description: str,
           agent_id: str, agents: tuple, supervisor_agent_id: str, collaboration_strategy: str,
           ai_model_id: str, subagent_model_id: str, subagent: tuple, skill: tuple,
           tool: tuple, system_prompt: str, backend_type: str, backend_path: str,
           sandrpod_api_url: str, sandrpod_sandbox: str, sandrpod_api_key: str,
           sandrpod_use_session: bool,
           memory_enabled: bool | None, memory_dir: str | None,
           memory_main_file: str | None, memory_recent_days: int | None,
           recursion_limit: int, enable_checkpoint: bool,
           timeout: int, max_concurrent_agents: int, enabled: bool,
           hitl_disabled: bool | None,
           interrupt_on: tuple, interrupt_off: tuple,
           interrupt_on_json: str | None):
    """Create a new orchestrator"""
    if orchestration_type in ("workflow", "conditional", "external", "knowledge_base"):
        click.echo(f"✗ {orchestration_type} type is complex. Please use the web console to create.", err=True)
        # 用 caller 自己配的 api_url（``siracli auth set-url``）做提示，而不是写死某个 SaaS 域名
        click.echo(f"  URL: {get_api_url().rstrip('/')}/agent-system/orchestrators", err=True)
        raise click.Abort()

    require_auth()
    client = get_client()

    data = {
        "name": name,
        "display_name": display_name,
        "orchestration_type": orchestration_type,
        "description": description,
        "is_active": enabled,
    }

    if agent_id:
        data["agent_id"] = agent_id
    if agents:
        if orchestration_type == "supervisor":
            data["supervisor_config"] = {
                "supervisor_agent_id": supervisor_agent_id,
                "sub_agent_ids": list(agents),
            }
        elif orchestration_type == "collaboration":
            data["collaboration_config"] = {
                "agent_ids": list(agents),
                "collaboration_strategy": collaboration_strategy or "sequential",
            }

    # DeepAgents configuration
    if orchestration_type == "deep_agents":
        if not ai_model_id:
            click.echo("✗ --ai-model-id is required for deep_agents type", err=True)
            raise click.Abort()
        if not system_prompt:
            click.echo("✗ --system-prompt is required for deep_agents type", err=True)
            raise click.Abort()

        # Build subagents list
        subagents_list = []
        for sa in subagent:
            if ":" in sa:
                # Format: type:name (e.g., predefined:research-agent)
                sa_type, sa_name = sa.split(":", 1)
                subagents_list.append({"type": sa_type, "name": sa_name})
            else:
                # Assume it's an agent_id reference
                subagents_list.append({"type": "agent_ref", "agent_id": sa})

        # Build backend_config
        backend_config = {}
        if backend_type in ("filesystem", "local_shell") and backend_path:
            backend_config["base_path"] = backend_path
        if backend_type == "store":
            backend_config["namespace"] = "deep_agents"
        if backend_type == "sandrpod":
            if sandrpod_api_url:
                backend_config["api_url"] = sandrpod_api_url
            if sandrpod_sandbox:
                backend_config["sandbox_name"] = sandrpod_sandbox
            if sandrpod_api_key:
                backend_config["api_key"] = sandrpod_api_key
            backend_config["use_session"] = sandrpod_use_session

        # Build middleware_config
        middleware_config = {
            "enable_todo_list": True,
            "enable_filesystem": True,
            "enable_subagents": True,
            "enable_summarization": False,
        }

        # Build langgraph_config
        langgraph_config = {
            "recursion_limit": recursion_limit,
            "checkpoint_enabled": enable_checkpoint,
        }

        # Build memory_config from any explicitly-set memory flags.
        # Omit unset keys so backend defaults (enabled=True, recent_days=7,
        # main_file=AGENTS.md, memory_dir derived from work_dir) apply.
        memory_config: dict = {}
        if memory_enabled is not None:
            memory_config["enabled"] = memory_enabled
        if memory_dir is not None:
            memory_config["memory_dir"] = memory_dir
        if memory_main_file is not None:
            memory_config["main_file"] = memory_main_file
        if memory_recent_days is not None:
            memory_config["recent_days"] = memory_recent_days

        deep_payload = {
            "ai_model_id": ai_model_id,
            "subagent_default_model_id": subagent_model_id,
            "subagents": subagents_list,
            "tool_ids": list(tool),
            "skill_ids": list(skill),
            "system_prompt": system_prompt,
            "backend_type": backend_type,
            "backend_config": backend_config,
            "middleware_config": middleware_config,
        }
        if memory_config:
            deep_payload["memory_config"] = memory_config

        data["deep_agents_config"] = deep_payload
        data["langgraph_config"] = langgraph_config

    # HITL × Card 字段（任意编排器类型都生效——Single / Supervisor /
    # Collaboration / DeepAgents 都从 ``deep_agents_config`` 这个 JSONB
    # 列里读 hitl_disabled / interrupt_on，后端 agent_executor 三层合并
    # 时不区分 orchestration_type）。
    hitl_payload: dict = {}
    if hitl_disabled is not None:
        hitl_payload["hitl_disabled"] = hitl_disabled
    merged = _build_interrupt_on_dict(
        enable=interrupt_on,
        disable=interrupt_off,
        json_blob=interrupt_on_json,
    )
    if merged is not None:
        hitl_payload["interrupt_on"] = merged
    if hitl_payload:
        # 合并到既有 deep_agents_config（DeepAgents 创建时已写其它字段），
        # 或为 Single / Supervisor / Collaboration 单独建。
        existing_da_cfg = data.get("deep_agents_config") or {}
        existing_da_cfg.update(hitl_payload)
        data["deep_agents_config"] = existing_da_cfg

    if timeout is not None:
        data["timeout_seconds"] = timeout
    if max_concurrent_agents is not None:
        data["max_concurrent_agents"] = max_concurrent_agents

    try:
        orch = client.post("/api/agent-system/orchestrators", json=data)
        click.echo(f"✓ Orchestrator created: {orch['name']} [{orch['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@orchestrator_group.command()
@click.argument("orchestrator_id")
@click.option(
    "--force",
    is_flag=True,
    help="Bypass application-reference check (apps lose their orchestrator).",
)
def delete(orchestrator_id: str, force: bool):
    """Delete an orchestrator.

    By default the backend rejects with 409 ORCHESTRATOR_IN_USE if any
    Application points to this orchestrator. Use --force to skip the
    check (those applications will fail at chat time).
    """
    require_auth()

    if not click.confirm(f"Are you sure you want to delete orchestrator {orchestrator_id}?"):
        return

    client = get_client()
    path = f"/api/agent-system/orchestrators/{orchestrator_id}"
    if force:
        path += "?force=true"

    try:
        client.delete(path)
        click.echo(f"✓ Orchestrator deleted")

    except APIError as e:
        if render_delete_conflict(e):
            return
        click.echo(f"✗ Error: {e}", err=True)


@orchestrator_group.command()
@click.argument("orchestrator_id")
@click.option("--name", "-n", default=None, help="Orchestrator name")
@click.option("--display-name", "-D", default=None, help="Display name")
@click.option("--description", "-d", default=None, help="Description")
@click.option("--agent-id", "-a", default=None, help="Agent ID")
# DeepAgents specific options for update
@click.option("--ai-model-id", default=None, help="AI model ID (for deep_agents type)")
@click.option("--subagent-model-id", default=None, help="Default SubAgent model ID (for deep_agents type)")
@click.option("--subagent", multiple=True, help="SubAgent ID (for deep_agents type)")
@click.option("--skill", multiple=True, help="Skill ID (for deep_agents type)")
@click.option("--tool", multiple=True, help="Tool ID (for deep_agents type)")
@click.option("--backend-type", default=None,
              type=click.Choice(["state", "store", "filesystem", "local_shell"]),
              help="Backend type (for deep_agents type)")
# DeepAgents long-term memory (memory_config)
@click.option("--memory-enabled/--no-memory-enabled", "memory_enabled", default=None,
              help="Enable/disable long-term memory")
@click.option("--memory-dir", default=None,
              help="Memory directory absolute path (empty string = re-derive from backend work_dir)")
@click.option("--memory-main-file", default=None, help="Main index filename")
@click.option("--memory-recent-days", default=None, type=int, help="Load last N days of dated files")
@click.option("--recursion-limit", default=None, type=int, help="LangGraph recursion limit")
@click.option("--enable-checkpoint/--disable-checkpoint", default=None, help="Enable checkpointing")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds (1-600)")
@click.option("--max-concurrent-agents", default=None, type=int, help="Max concurrent agents (1-20)")
@click.option("--enabled/--disabled", default=None, help="Enable/disable orchestrator")
# HITL × Card flags（同 create；merge 进 existing.deep_agents_config 而非覆盖整 dict）
@click.option("--hitl-disabled/--no-hitl-disabled", "hitl_disabled", default=None,
              help="HITL: silence the whole orchestrator")
@click.option("--interrupt-on", "interrupt_on", multiple=True,
              help="HITL: add a tool name to interrupt_on (TOOL: true). Repeatable.")
@click.option("--interrupt-off", "interrupt_off", multiple=True,
              help="HITL: add a tool name as explicitly disabled (TOOL: false). Repeatable.")
@click.option("--interrupt-on-json", "interrupt_on_json", default=None,
              help="HITL: full interrupt_on dict as JSON; replaces existing interrupt_on if "
                   "no --interrupt-on/--interrupt-off given alongside, or serves as baseline if "
                   "they are.")
@click.option("--clear-interrupt-on", "clear_interrupt_on", is_flag=True, default=False,
              help="HITL: clear orchestrator-level interrupt_on (delete the field)")
def update(orchestrator_id: str, name: str, display_name: str, description: str,
           agent_id: str, ai_model_id: str, subagent_model_id: str, subagent: tuple,
           skill: tuple, tool: tuple, backend_type: str,
           memory_enabled: bool | None, memory_dir: str | None,
           memory_main_file: str | None, memory_recent_days: int | None,
           recursion_limit: int, enable_checkpoint: bool,
           timeout: int, max_concurrent_agents: int, enabled: bool,
           hitl_disabled: bool | None,
           interrupt_on: tuple, interrupt_off: tuple,
           interrupt_on_json: str | None, clear_interrupt_on: bool):
    """Update an orchestrator"""
    require_auth()
    client = get_client()

    # Get existing orchestrator to know its type
    try:
        existing = client.get(f"/api/agent-system/orchestrators/{orchestrator_id}")
    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
        return

    data = {}
    if name:
        data["name"] = name
    if display_name:
        data["display_name"] = display_name
    if description is not None:
        data["description"] = description
    if agent_id:
        data["agent_id"] = agent_id

    # Handle deep_agents config updates
    orch_type = existing.get("orchestration_type", "")
    if orch_type == "deep_agents":
        deep_agents_config = existing.get("deep_agents_config", {})
        langgraph_config = existing.get("langgraph_config", {})

        if ai_model_id:
            deep_agents_config["ai_model_id"] = ai_model_id
        if subagent_model_id:
            deep_agents_config["subagent_default_model_id"] = subagent_model_id
        if subagent:
            # Build subagents list from agent IDs
            deep_agents_config["subagents"] = [
                {"type": "agent_ref", "agent_id": sa} for sa in subagent
            ]
        if skill:
            deep_agents_config["skill_ids"] = list(skill)
        if tool:
            deep_agents_config["tool_ids"] = list(tool)
        if backend_type:
            deep_agents_config["backend_type"] = backend_type

        # Merge memory_config: only touch keys the user supplied so other
        # settings keep their stored value.
        if any(v is not None for v in (
            memory_enabled, memory_dir, memory_main_file, memory_recent_days,
        )):
            existing_memory = dict(deep_agents_config.get("memory_config") or {})
            if memory_enabled is not None:
                existing_memory["enabled"] = memory_enabled
            if memory_dir is not None:
                existing_memory["memory_dir"] = memory_dir
            if memory_main_file is not None:
                existing_memory["main_file"] = memory_main_file
            if memory_recent_days is not None:
                existing_memory["recent_days"] = memory_recent_days
            deep_agents_config["memory_config"] = existing_memory

        if recursion_limit is not None:
            langgraph_config["recursion_limit"] = recursion_limit
        if enable_checkpoint is not None:
            langgraph_config["checkpoint_enabled"] = enable_checkpoint

        data["deep_agents_config"] = deep_agents_config
        if langgraph_config:
            data["langgraph_config"] = langgraph_config

    # HITL × Card 字段（任意编排器类型都生效——后端从 ``deep_agents_config``
    # 这个 JSONB 列读 hitl_disabled / interrupt_on，三层合并对 Single /
    # Supervisor / Collaboration / DeepAgents 一视同仁）。
    hitl_touched = (
        hitl_disabled is not None
        or clear_interrupt_on
        or interrupt_on
        or interrupt_off
        or interrupt_on_json
    )
    if hitl_touched:
        # 拿 deep_agents_config 作 baseline——DeepAgents 上面已经写过则用，
        # 其它类型直接拷 existing.deep_agents_config 起步（无则空 dict）。
        da_cfg = data.get("deep_agents_config")
        if da_cfg is None:
            da_cfg = dict(existing.get("deep_agents_config") or {})

        if hitl_disabled is not None:
            da_cfg["hitl_disabled"] = hitl_disabled
        if clear_interrupt_on:
            da_cfg.pop("interrupt_on", None)
        else:
            merged = _build_interrupt_on_dict(
                enable=interrupt_on,
                disable=interrupt_off,
                json_blob=interrupt_on_json,
            )
            if merged is not None:
                # JSON blob = baseline；on/off = patch。caller 只传 on/off
                # 时当 patch 加到 existing.interrupt_on 上不清空既有字段。
                if interrupt_on_json:
                    da_cfg["interrupt_on"] = merged
                else:
                    existing_io = dict(da_cfg.get("interrupt_on") or {})
                    existing_io.update(merged)
                    da_cfg["interrupt_on"] = existing_io
        data["deep_agents_config"] = da_cfg

    if timeout is not None:
        data["timeout_seconds"] = timeout
    if max_concurrent_agents is not None:
        data["max_concurrent_agents"] = max_concurrent_agents
    if enabled is not None:
        data["is_active"] = enabled

    if not data:
        click.echo("✗ No updates provided", err=True)
        return

    try:
        orch = client.put(f"/api/agent-system/orchestrators/{orchestrator_id}", json=data)
        click.echo(f"✓ Orchestrator updated: {orch['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@orchestrator_group.command()
@click.argument("orchestrator_id")
@click.option("--message", "-m", required=True, help="Message to send")
@click.option("--session-id", "-s", default=None, help="Session ID (optional)")
def chat(orchestrator_id: str, message: str, session_id: str):
    """Chat with an orchestrator (streaming)

    Note: This command requires a WEB type application.
    Use 'siracli application list' to find an application, then use:
    'siracli application chat <application_id> -m <message>'
    """
    click.echo("Error: orchestrator chat is deprecated.", err=True)
    click.echo("Please use 'siracli application chat <application_id> -m <message>' instead.", err=True)
    click.echo("\n1. First find a WEB type application: siracli application list", err=True)
    click.echo("2. Then chat with it: siracli application chat <app_id> -m 'hello'", err=True)
    raise click.Abort()
