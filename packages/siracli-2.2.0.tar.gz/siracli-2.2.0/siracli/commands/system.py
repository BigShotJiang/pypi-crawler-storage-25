"""System commands"""

import click
import json
from ..client import get_client, APIError
from ..config import get_api_url


@click.group(name="system")
def system_group():
    """System information and health checks"""
    pass


@system_group.command()
def health():
    """Check system health"""
    client = get_client()

    try:
        response = client.get("/api/system/health")
        status = response.get("overall_status", "unknown")
        services = response.get("services", {})

        if status == "healthy":
            click.echo("✓ System healthy\n")
        else:
            click.echo(f"⚠ System status: {status}\n")

        click.echo("Services:")
        for name, info in services.items():
            svc_status = info.get("status", "unknown")
            if svc_status == "online" or svc_status == "healthy":
                click.echo(f"  ● {name}: {svc_status}")
            else:
                click.echo(f"  ○ {name}: {svc_status}")
            if info.get("response_time"):
                click.echo(f"    Response time: {info['response_time']}ms")

    except APIError as e:
        click.echo(f"✗ Health check failed: {e}", err=True)
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)


@system_group.command()
def stats():
    """Get system statistics"""
    client = get_client()

    try:
        response = client.get("/api/system/stats")
        click.echo(f"\nAPI URL: {get_api_url()}\n")

        if "statistics" in response:
            stats = response["statistics"]
            click.echo("Statistics:")
            for key, value in stats.items():
                if isinstance(value, dict):
                    click.echo(f"  {key}:")
                    for k, v in value.items():
                        click.echo(f"    {k}: {v}")
                else:
                    click.echo(f"  {key}: {value}")
        else:
            # Fallback to direct display
            click.echo("System Stats:")
            for key, value in response.items():
                if not key.startswith("_"):
                    click.echo(f"  {key}: {value}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@system_group.command()
def info():
    """Show CLI and API info"""
    from .. import __version__
    from ..config import get_token, is_authenticated

    click.echo(f"SiraCLI version: {__version__}")
    click.echo(f"API URL: {get_api_url()}")

    if is_authenticated():
        user = get_client().get("/api/auth/me")
        click.echo(f"Logged in as: {user.get('name', user.get('email', 'Unknown'))}")
    else:
        click.echo("Not logged in")


@system_group.command()
def version():
    """Show version information"""
    from .. import __version__

    client = get_client()
    try:
        # Try to get backend version from health or root endpoint
        try:
            root = client.session.get(f"{get_api_url()}/")
            backend_version = root.json().get("version", "unknown")
        except:
            backend_version = "unknown"

        click.echo(f"SiraCLI: {__version__}")
        click.echo(f"Backend: {backend_version}")
    except Exception:
        click.echo(f"SiraCLI: {__version__}")
        click.echo("Backend: (unreachable)")
