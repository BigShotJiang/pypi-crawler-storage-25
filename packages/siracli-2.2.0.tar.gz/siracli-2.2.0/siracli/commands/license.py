"""License v2 management commands.

Admin-scoped wrappers around ``/api/admin/license/v2/*``. Lets ops + customer
success do without the web UI:

  siracli license status                    Tier / mode / grace / 22 features
  siracli license import <file.lic>         Upload signed .lic
  siracli license current                   Quick summary of active grant
  siracli license usage [--window-days N]   Per-feature allow/deny counts
  siracli license events [--feature K]      Recent raw audit events (paginated)
  siracli license hardware-id               Machine fingerprint (for hw-bound licenses)
  siracli license metrics                   Prometheus exposition format dump
"""

import click
from ..client import get_client, APIError, get_token
from ..config import get_api_url, is_authenticated


def require_auth():
    if not is_authenticated():
        click.echo("✗ Not logged in. Run 'siracli auth login' first.", err=True)
        raise click.Abort()


def _format_dt(dt: str | None) -> str:
    if not dt:
        return "—"
    return dt[:16].replace("T", " ")


# ---------------------------------------------------------------------------
# Group root
# ---------------------------------------------------------------------------


@click.group(name="license")
def license_group():
    """License (v2) administration"""
    pass


# ---------------------------------------------------------------------------
# Status / current
# ---------------------------------------------------------------------------


@license_group.command(name="status")
@click.option(
    "--show-features/--hide-features",
    default=True,
    help="Print the 22-feature granted/denied table (default on)",
)
def license_status(show_features: bool):
    """Full v2 status — mode, grace, current grant, all features."""
    require_auth()
    try:
        s = get_client().get("/api/admin/license/v2/status")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    mode = s.get("mode") or "—"
    grace = s.get("grace") or {}
    grant = s.get("grant")

    click.echo(f"Mode:           {mode}")
    if grace:
        in_g = grace.get("in_grace")
        days = grace.get("days_remaining")
        click.echo(
            f"Grace period:   {'in_grace' if in_g else 'expired'} "
            f"({days} days remaining of {grace.get('total_days', '?')})"
        )
    if grant:
        click.echo(f"Grant tier:     {grant.get('license_type')}")
        click.echo(f"Grant valid_until: {_format_dt(grant.get('valid_until'))}")
        org_id = grant.get("organization_id") or "(global)"
        click.echo(f"Grant scope:    {org_id}")
    else:
        click.echo("Grant:          (none) — uploading a .lic via 'license import' creates one")

    if show_features:
        features = s.get("features") or []
        granted = sum(1 for f in features if f.get("granted"))
        click.echo(f"\nFeatures: {granted}/{len(features)} granted")
        click.echo(f"  {'KEY':<35}{'TIER':<14}{'GRANTED':<10}{'DISPLAY NAME'}")
        click.echo("  " + "-" * 90)
        for f in features:
            mark = "✓" if f.get("granted") else "✗"
            colour = "green" if f.get("granted") else "yellow"
            line = (
                f"  {f.get('key', ''):<35}"
                f"{f.get('minimum_tier', ''):<14}"
                f"{mark:<10}"
                f"{f.get('display_name') or ''}"
            )
            click.echo(click.style(line, fg=colour))


@license_group.command(name="current")
def license_current():
    """Compact view of the active grant."""
    require_auth()
    try:
        result = get_client().get("/api/admin/license/v2/current")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    if not result.get("licensed"):
        click.echo("(no license)")
        return
    lic = result.get("license") or {}
    for k in (
        "id",
        "type",
        "customer",
        "validity",
        "limits",
    ):
        v = lic.get(k)
        if v is None:
            continue
        if isinstance(v, dict):
            import json as _json
            v = _json.dumps(v, ensure_ascii=False, indent=2)
        click.echo(f"{k:<10} {v}")


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------


@license_group.command(name="import")
@click.argument("file_path", type=click.Path(exists=True, dir_okay=False))
def license_import(file_path: str):
    """Upload a signed .lic file → bridge → grant table."""
    require_auth()

    # multipart upload — bypass the JSON client helper
    import requests

    api_url = get_api_url()
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"} if token else {}

    with open(file_path, "rb") as fh:
        try:
            r = requests.post(
                f"{api_url}/api/admin/license/v2/import",
                headers=headers,
                files={"file": (file_path, fh)},
                timeout=30,
            )
        except requests.RequestException as exc:
            click.echo(f"✗ Network error: {exc}", err=True)
            raise click.Abort()

    if not r.ok:
        try:
            click.echo(f"✗ {r.status_code}: {r.json().get('detail') or r.text}", err=True)
        except ValueError:
            click.echo(f"✗ {r.status_code}: {r.text}", err=True)
        raise click.Abort()

    data = r.json()
    if data.get("success"):
        click.echo(f"✓ Imported")
        click.echo(f"  grant_id:      {data.get('grant_id')}")
        click.echo(f"  license_id:    {data.get('license_id')}")
        click.echo(f"  license_type:  {data.get('license_type')}")
        click.echo(f"  valid_until:   {_format_dt(data.get('valid_until'))}")
        click.echo(f"  feature_count: {data.get('feature_count')}")
    else:
        click.echo(f"✗ Import failed: {data}", err=True)
        raise click.Abort()


# ---------------------------------------------------------------------------
# Usage / events / metrics
# ---------------------------------------------------------------------------


@license_group.command(name="usage")
@click.option("--window-days", "-w", default=7, type=click.IntRange(1, 90), help="Window")
def license_usage(window_days: int):
    """Per-feature allow/deny aggregate over a window."""
    require_auth()
    try:
        s = get_client().get(
            "/api/admin/license/v2/usage/summary",
            params={"window_days": window_days},
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    total = s.get("total_events", 0)
    allow = s.get("total_allow", 0)
    deny = s.get("total_deny", 0)
    deny_rate = (deny * 100 // total) if total else 0
    click.echo(
        f"\nWindow: last {window_days} days | "
        f"events {total} | "
        + click.style(f"allow {allow}", fg="green")
        + " | "
        + click.style(f"deny {deny} ({deny_rate}%)", fg="red")
    )

    by_feature = s.get("by_feature") or []
    if not by_feature:
        click.echo("(no usage events recorded)")
        return
    click.echo(f"\n  {'FEATURE':<35}{'ALLOW':>10}{'DENY':>10}  LAST USED")
    click.echo("  " + "-" * 80)
    for f in by_feature[:25]:  # cap at top 25
        feat = f.get("feature", "")
        a = f.get("allow_count", 0)
        d = f.get("deny_count", 0)
        last = _format_dt(f.get("last_used_at"))
        line = f"  {feat:<35}{a:>10}{d:>10}  {last}"
        click.echo(click.style(line, fg="red") if d > 0 else line)


@license_group.command(name="events")
@click.option("--feature", "-f", default=None, help="Filter by feature key")
@click.option(
    "--outcome",
    type=click.Choice(["allow", "deny"]),
    default=None,
    help="Filter by outcome",
)
@click.option("--limit", "-l", default=50, type=click.IntRange(1, 500), help="Max rows")
@click.option("--offset", default=0, type=click.IntRange(0), help="Pagination offset")
def license_events(feature: str | None, outcome: str | None, limit: int, offset: int):
    """List raw license usage events (per-call audit)."""
    require_auth()
    params = {"limit": limit, "offset": offset}
    if feature:
        params["feature"] = feature
    if outcome:
        params["outcome"] = outcome

    try:
        result = get_client().get("/api/admin/license/v2/usage", params=params)
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    items = result.get("items", [])
    total = result.get("total", 0)
    if not items:
        click.echo("(no events)")
        return
    click.echo(f"\nTotal: {total}  showing offset {offset}–{offset + len(items)}\n")
    click.echo(f"{'OCCURRED':<18}{'FEATURE':<35}{'OUTCOME':<10}{'ORG':<14}")
    click.echo("-" * 100)
    for ev in items:
        meta = ev.get("metadata") or {}
        out = meta.get("outcome") or "allow"
        line = (
            f"{_format_dt(ev.get('occurred_at')):<18}"
            f"{(ev.get('feature') or '')[:33]:<35}"
            f"{out:<10}"
            f"{(ev.get('organization_id') or '—')[:12]:<14}"
        )
        click.echo(click.style(line, fg="red") if out == "deny" else line)


@license_group.command(name="hardware-id")
def license_hardware_id():
    """Print the machine fingerprint (used for hardware-bound licenses)."""
    require_auth()
    try:
        result = get_client().get("/api/admin/license/v2/hardware-id")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()
    click.echo(result.get("hardware_id") or "(unavailable)")


@license_group.command(name="metrics")
def license_metrics():
    """Dump Prometheus exposition format (text/plain).

    Used directly by Prometheus / VictoriaMetrics scrapers, but also
    convenient for quick spot checks via grep:

        siracli license metrics | grep deny
    """
    require_auth()
    # The endpoint returns text/plain — bypass JSON client
    import requests

    api_url = get_api_url()
    token = get_token()
    try:
        r = requests.get(
            f"{api_url}/api/admin/license/v2/metrics",
            headers={"Authorization": f"Bearer {token}"} if token else {},
            timeout=15,
        )
    except requests.RequestException as exc:
        click.echo(f"✗ Network error: {exc}", err=True)
        raise click.Abort()
    if not r.ok:
        click.echo(f"✗ {r.status_code}: {r.text}", err=True)
        raise click.Abort()
    click.echo(r.text)
