"""Agent memory management commands.

Two layers of memory exist; this CLI manages **layer 1** (session-level
LangGraph checkpointer state):

  Layer 1: per-session AI conversation context, lives in Redis with 24h TTL.
           thread_id = session_id = ``{application_id}_{user_id}``.
           Cleared by ``/clear`` slash command (user self-serve) or this CLI.

  Layer 3: file-based long-term memory (AGENTS.md / YYYY-MM-DD.md), lives
           in sandbox / filesystem. Not managed via this CLI — edit the
           files directly, or via the sandbox file tools.

Commands:

  siracli memory stats [--session ID]      Aggregate session stats
  siracli memory list                      Active sessions
  siracli memory messages SESSION          Last N messages of a session
  siracli memory clear SESSION             Wipe one session
  siracli memory cleanup --inactive-hours  Bulk GC inactive sessions
  siracli memory clear-all --confirm CONFIRM_CLEAR_ALL  Nuclear option
"""

import click
from ..client import get_client, APIError
from ..config import is_authenticated


def require_auth():
    if not is_authenticated():
        click.echo("✗ Not logged in. Run 'siracli auth login' first.", err=True)
        raise click.Abort()


def _format_dt(dt: str | None) -> str:
    if not dt:
        return "—"
    return dt[:16].replace("T", " ")


@click.group(name="memory")
def memory_group():
    """Agent session memory management"""
    pass


@memory_group.command(name="stats")
@click.option(
    "--session",
    "session_id",
    default=None,
    help="Stats for one session (omit for all-org aggregate)",
)
def memory_stats(session_id: str | None):
    """Show memory usage statistics."""
    require_auth()
    params = {"session_id": session_id} if session_id else {}
    try:
        s = get_client().get(
            "/api/agent-system/memory/stats", params=params
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    # Print whatever fields the backend sends (intentionally generic)
    if isinstance(s, dict):
        for k, v in s.items():
            if isinstance(v, dict):
                click.echo(f"{k}:")
                for kk, vv in v.items():
                    click.echo(f"  {kk}: {vv}")
            else:
                click.echo(f"{k}: {v}")
    else:
        click.echo(s)


@memory_group.command(name="list")
@click.option("--limit", "-l", default=20, type=click.IntRange(1, 200), help="Max rows")
def memory_list(limit: int):
    """List active sessions (most recent first)."""
    require_auth()
    try:
        result = get_client().get(
            "/api/agent-system/memory/sessions", params={"limit": limit}
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    # Backend uses "sessions" key (see api/memory.py::list_memory_sessions);
    # fall back to "items" for forward-compat in case of response refactor.
    items = (
        result.get("sessions")
        or result.get("items")
        or (result if isinstance(result, list) else [])
    )
    total = result.get("total", len(items)) if isinstance(result, dict) else len(items)
    if not items:
        click.echo("No active sessions.")
        return
    click.echo(f"\nActive sessions: {total}\n")
    click.echo(
        f"{'SESSION ID':<60}{'MSGS':<8}{'TITLE':<30}{'LAST ACCESSED':<18}"
    )
    click.echo("-" * 116)
    for s in items:
        sid = (s.get("thread_id") or s.get("session_id") or "")[:58]
        msgs = s.get("message_count") or s.get("messages") or "—"
        title = (s.get("title") or "—")[:28]
        last = _format_dt(s.get("last_accessed") or s.get("last_activity_at") or s.get("updated_at"))
        click.echo(f"{sid:<60}{str(msgs):<8}{title:<30}{last:<18}")
    click.echo()


@memory_group.command(name="messages")
@click.argument("session_id")
@click.option("--limit", "-l", default=20, type=click.IntRange(1, 200))
def memory_messages(session_id: str, limit: int):
    """Print recent messages of a session (chronological)."""
    require_auth()
    try:
        result = get_client().get(
            f"/api/agent-system/memory/sessions/{session_id}/messages",
            params={"limit": limit},
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()

    items = result.get("messages") or result.get("items") or []
    if not items:
        click.echo("(no messages)")
        return
    for m in items:
        role = (m.get("type") or m.get("role") or "?")[:9]
        content = m.get("content") or ""
        if isinstance(content, list):  # multimodal payload
            content = " ".join(
                part.get("text", "") if isinstance(part, dict) else str(part)
                for part in content
            )
        snippet = content[:200].replace("\n", " ")
        click.echo(f"[{role:<9}] {snippet}")


@memory_group.command(name="clear")
@click.argument("session_id")
@click.confirmation_option(
    prompt="Wipe this session's AI memory? Cannot be undone.",
)
def memory_clear(session_id: str):
    """Clear one session's memory (admin / owner)."""
    require_auth()
    try:
        get_client().delete(f"/api/agent-system/memory/{session_id}")
        click.echo(f"✓ Session {session_id} memory cleared")
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()


@memory_group.command(name="cleanup")
@click.option(
    "--inactive-hours",
    "inactive_hours",
    default=72,
    type=click.IntRange(1, 8760),  # 1h .. 1y
    help="Sessions idle longer than this are cleared",
)
@click.confirmation_option(
    prompt="Bulk-clear inactive sessions? This affects multiple users.",
)
def memory_cleanup(inactive_hours: int):
    """Bulk GC sessions inactive for ``--inactive-hours`` hours."""
    require_auth()
    try:
        result = get_client().post(
            "/api/agent-system/memory/cleanup",
            params={"inactive_threshold_hours": inactive_hours},
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()
    click.echo(f"✓ {result.get('message') or 'Cleanup completed'}")


@memory_group.command(name="clear-all")
@click.option(
    "--confirm",
    required=True,
    help="Must equal CONFIRM_CLEAR_ALL — guards against muscle-memory disasters",
)
def memory_clear_all(confirm: str):
    """Nuclear option: wipe ALL sessions for this org. **Cannot be undone.**"""
    require_auth()
    if confirm != "CONFIRM_CLEAR_ALL":
        click.echo("✗ --confirm must equal CONFIRM_CLEAR_ALL", err=True)
        raise click.Abort()
    try:
        result = get_client().delete(
            "/api/agent-system/memory/all",
            params={"confirm": "CONFIRM_CLEAR_ALL"},
        )
    except APIError as exc:
        click.echo(f"✗ {exc}", err=True)
        raise click.Abort()
    click.echo(f"✓ {result.get('message') or 'All sessions cleared'}")
