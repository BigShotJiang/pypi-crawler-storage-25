"""Skill management commands"""

import click
import json
from ..client import get_client, APIError
from ..config import is_authenticated


def require_auth():
    """Check if user is authenticated"""
    if not is_authenticated():
        click.echo("✗ Not logged in. Run 'siracli auth login' first.", err=True)
        raise click.Abort()


def determine_file_type(path: str) -> str:
    """Determine file type from path"""
    if path.endswith('.md'):
        return 'markdown'
    elif path.endswith(('.py', '.js', '.ts', '.sh', '.bash')):
        return 'code'
    elif path.endswith(('.json', '.yaml', '.yml', '.toml', '.ini', '.conf', '.cfg')):
        return 'code'
    elif path.endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx')):
        return 'binary'
    return 'unknown'


@click.group(name="skill")
def skill_group():
    """Skill management"""
    pass


@skill_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--search", "-s", default=None, help="Search keyword")
@click.option("--status", default=None, help="Filter by status (draft/review/published/archived)")
@click.option("--category", "-c", default=None, help="Filter by category")
def skill_list(page: int, limit: int, search: str, status: str, category: str):
    """List all skills"""
    require_auth()
    client = get_client()

    params = {"page": page, "limit": limit}
    if search:
        params["search"] = search
    if status:
        params["status"] = status
    if category:
        params["category"] = category

    try:
        response = client.get("/api/skills", params=params)
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No skills found.")
            return

        click.echo(f"\nTotal: {total} skills\n")
        click.echo(f"{'ID':<40}{'STATUS':<12}{'NAME':<25}{'CATEGORY':<15}")
        click.echo("-" * 100)

        for skill in items:
            skill_id = skill.get("id", "")
            status_val = skill.get("status", "N/A")
            status_icon = "●" if status_val == "published" else "○"
            name = skill.get("name", "N/A")[:23]
            category_val = skill.get("category") or "N/A"
            click.echo(f"{skill_id:<40}{status_icon:<3}{status_val:<9}{name:<25}{category_val:<15}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command(name="search")
@click.argument("keyword")
@click.option("--status", default=None, help="Filter by status (draft/review/published/archived)")
def skill_search(keyword: str, status: str):
    """Search skills by keyword

    Examples:
        siracli skill search weather
        siracli skill search weather --status published
    """
    require_auth()
    client = get_client()

    params = {"search": keyword, "limit": 50}
    if status:
        params["status"] = status

    try:
        response = client.get("/api/skills", params=params)
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo(f"No skills found matching '{keyword}'.")
            return

        click.echo(f"\nFound {total} skills matching '{keyword}':\n")
        click.echo(f"{'ID':<40}{'STATUS':<12}{'NAME':<25}{'CATEGORY':<15}")
        click.echo("-" * 100)

        for skill in items:
            skill_id = skill.get("id", "")
            status_val = skill.get("status", "N/A")
            status_icon = "●" if status_val == "published" else "○"
            name = skill.get("name", "N/A")[:23]
            category_val = skill.get("category") or "N/A"
            click.echo(f"{skill_id:<40}{status_icon:<3}{status_val:<9}{name:<25}{category_val:<15}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
def info(skill_id: str):
    """Get skill details"""
    require_auth()
    client = get_client()

    try:
        skill = client.get(f"/api/skills/{skill_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Skill Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {skill.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {skill.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {skill.get('display_name', 'N/A')}")
        click.echo(f"{'Category':<20} {skill.get('category', 'N/A')}")
        click.echo(f"{'Status':<20} {skill.get('status', 'N/A')}")
        click.echo(f"{'Version':<20} {skill.get('version', 'N/A')}")
        click.echo(f"{'Tags':<20} {', '.join(skill.get('tags', []) or ['N/A'])}")
        click.echo(f"{'Created At':<20} {str(skill.get('created_at', 'N/A'))[:19]}")

        description = skill.get("description")
        if description:
            click.echo(f"\n{'='*60}")
            click.echo(f"Description")
            click.echo(f"{'='*60}")
            click.echo(f"{description}")

        # Display files
        files = skill.get("files", [])
        if files:
            click.echo(f"\n{'='*60}")
            click.echo(f"Files ({len(files)})")
            click.echo(f"{'='*60}")
            for f in files:
                path = f.get("path", "N/A")
                file_type = f.get("type", "unknown")
                content_preview = f.get("content", "")[:100]
                click.echo(f"  [{file_type}] {path}")
                if content_preview:
                    preview = content_preview.replace('\n', ' ')[:80]
                    click.echo(f"           {preview}...")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.option("--name", "-n", required=True, help="Skill name (unique identifier, lowercase with hyphens)")
@click.option("--display-name", "-d", default=None, help="Display name")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="Path to SKILL.md file or skill directory")
@click.option("--description", default=None, help="Description")
@click.option("--category", "-c", default=None, help="Category")
@click.option("--tags", "-t", multiple=True, help="Tags")
def create(name: str, display_name: str, file_path: str, description: str, category: str, tags: tuple):
    """Create a new skill from file or directory

    Supports:
    - Single .md file (will be stored as SKILL.md)
    - Directory with SKILL.md (all files will be included)
    - .zip file (use 'siracli skill import-file' instead)

    Examples:
        siracli skill create -n my-skill -d "My Skill"
        siracli skill create -n my-skill -f ./my-skill/
    """
    require_auth()
    client = get_client()

    import os

    files_data = []

    if file_path:
        if file_path.endswith('.md'):
            # Single markdown file
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                files_data = [{
                    "path": "SKILL.md",
                    "content": content,
                    "type": "markdown"
                }]
            except Exception as e:
                click.echo(f"✗ Error reading file: {e}", err=True)
                return

        elif os.path.isdir(file_path):
            # Directory - read all files, keep SKILL.md unchanged
            skill_dir = file_path
            skill_md_path = os.path.join(skill_dir, "SKILL.md")

            if not os.path.exists(skill_md_path):
                click.echo(f"✗ SKILL.md not found in {file_path}", err=True)
                return

            for root, dirs, files in os.walk(skill_dir):
                for file in files:
                    file_full_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_full_path, skill_dir)

                    try:
                        if file.endswith('.md') or file.endswith('.py') or file.endswith('.js'):
                            with open(file_full_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                        else:
                            with open(file_full_path, 'rb') as f:
                                content = f.read()
                            # Binary files - store as base64 or skip for now
                            import base64
                            content = base64.b64encode(content).decode('ascii')

                        files_data.append({
                            "path": arcname,
                            "content": content,
                            "type": determine_file_type(file)
                        })
                    except Exception as e:
                        click.echo(f"⚠ Warning: Could not read {arcname}: {e}")

    data = {
        "name": name,
        "files": files_data,
    }
    if display_name:
        data["display_name"] = display_name
    if description:
        data["description"] = description
    if category:
        data["category"] = category
    if tags:
        data["tags"] = list(tags)

    try:
        skill = client.post("/api/skills", json=data)
        click.echo(f"✓ Skill created: {skill['name']} [{skill['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="Path to file to update (relative path in skill)")
@click.option("--name", "-n", default=None, help="Skill name")
@click.option("--display-name", "-d", default=None, help="Display name")
@click.option("--description", default=None, help="Description")
@click.option("--category", "-c", default=None, help="Category")
@click.option("--status", "-s", default=None, type=click.Choice(["draft", "review", "published", "archived"]), help="Status")
@click.option("--version-comment", default=None, help="Version comment")
def update(skill_id: str, file_path: str, name: str, display_name: str, description: str, category: str, status: str, version_comment: str):
    """Update a skill

    Use --file to update a specific file content. Without --file,
    only metadata (name, description, etc.) will be updated.
    """
    require_auth()
    client = get_client()

    # First get current skill to get existing files
    try:
        current_skill = client.get(f"/api/skills/{skill_id}")
    except APIError as e:
        click.echo(f"✗ Error fetching skill: {e}", err=True)
        return

    data = {}
    if name:
        data["name"] = name
    if display_name:
        data["display_name"] = display_name
    if description:
        data["description"] = description
    if category:
        data["category"] = category
    if status:
        data["status"] = status
    if version_comment:
        data["version_comment"] = version_comment

    # Update file content if file path provided
    if file_path:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Determine the path in the skill
            file_name = file_path.split('/')[-1]
            files_data = current_skill.get("files", [])

            # Find and update or add file
            found = False
            for f in files_data:
                if f.get("path") == file_name:
                    f["content"] = content
                    f["type"] = determine_file_type(file_name)
                    found = True
                    break

            if not found:
                files_data.append({
                    "path": file_name,
                    "content": content,
                    "type": determine_file_type(file_name)
                })

            data["files"] = files_data

        except Exception as e:
            click.echo(f"✗ Error reading file: {e}", err=True)
            return

    if not data:
        click.echo("✗ No updates provided", err=True)
        return

    try:
        skill = client.patch(f"/api/skills/{skill_id}", json=data)
        click.echo(f"✓ Skill updated: {skill['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
def delete(skill_id: str):
    """Delete a skill (soft delete)"""
    require_auth()

    if not click.confirm(f"Are you sure you want to delete skill {skill_id}?"):
        return

    client = get_client()

    try:
        client.delete(f"/api/skills/{skill_id}")
        click.echo(f"✓ Skill deleted")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
def versions(skill_id: str):
    """List skill versions"""
    require_auth()
    client = get_client()

    try:
        response = client.get(f"/api/skills/{skill_id}/versions")
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No versions found.")
            return

        click.echo(f"\nTotal: {total} versions\n")
        click.echo(f"{'VERSION':<10}{'CREATED AT':<25}{'COMMENT'}")
        click.echo("-" * 80)

        for v in items:
            version = v.get("version", "N/A")
            created_at = str(v.get("created_at", "N/A"))[:19]
            comment = v.get("comment") or ""
            click.echo(f"{version:<10}{created_at:<25}{comment[:40]}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
@click.argument("version", type=int)
def restore(skill_id: str, version: int):
    """Restore skill to a specific version"""
    require_auth()

    if not click.confirm(f"Restore skill {skill_id} to version {version}?"):
        return

    client = get_client()

    try:
        skill = client.post(f"/api/skills/{skill_id}/versions/{version}/restore")
        click.echo(f"✓ Skill restored to version {version}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("url")
@click.option("--name", "-n", default=None, help="Override skill name")
def import_url(url: str, name: str):
    """Import a skill from URL (.md or .zip)"""
    require_auth()
    client = get_client()

    try:
        skill = client.post(f"/api/skills/import/url?url={url}")
        click.echo(f"✓ Skill imported: {skill['name']} [{skill['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("file_path", type=click.Path(exists=True))
def import_file(file_path: str):
    """Import a skill from a local file (.md or .zip) - creates NEW skill"""
    require_auth()

    import requests
    from ..config import get_api_url, get_token

    url = f"{get_api_url()}/api/skills/import/file"
    headers = {}
    token = get_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    filename = file_path.split('/')[-1]

    try:
        with open(file_path, 'rb') as f:
            files = {"file": (filename, f)}

            response = requests.post(url, files=files, headers=headers)

            if not response.ok:
                try:
                    error_data = response.json()
                    message = error_data.get("detail", error_data.get("message", response.text))
                except:
                    message = response.text
                raise APIError(message, response.status_code)

            skill = response.json()
            click.echo(f"✓ Skill imported: {skill['name']} [{skill['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
@click.argument("file_path", type=click.Path(exists=True))
def import_into(skill_id: str, file_path: str):
    """Import file (.zip or .md) INTO an existing skill - updates files only

    Unlike 'import-file' which creates a NEW skill, this imports into an
    existing skill, updating files with the same name.

    Examples:
        siracli skill import-into <skill_id> ./new-files.zip
        siracli skill import-into <skill_id> ./SKILL.md
    """
    require_auth()

    import requests
    from ..config import get_api_url, get_token

    url = f"{get_api_url()}/api/skills/{skill_id}/import/file"
    headers = {}
    token = get_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    filename = file_path.split('/')[-1]

    try:
        with open(file_path, 'rb') as f:
            files = {"file": (filename, f)}

            response = requests.post(url, files=files, headers=headers)

            if not response.ok:
                try:
                    error_data = response.json()
                    message = error_data.get("detail", error_data.get("message", response.text))
                except:
                    message = response.text
                raise APIError(message, response.status_code)

            skill = response.json()
            click.echo(f"✓ File imported into skill: {skill['name']} [{skill['id']}]")
            click.echo(f"  New version: {skill['version']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
@click.option("--platform", "-p", "platform", type=click.Choice(["claude", "openclaw"]), default=None, help="Target platform (auto-detected if not specified)")
@click.option("--dir", "-d", "install_dir", default=None, help="Custom installation directory")
def install(skill_id: str, platform: str, install_dir: str):
    """Install a skill to local Claude or OpenClaw skills directory

    If --platform is not specified, auto-detects by checking for .claude directory
    in current path.

    Examples:
        siracli skill install <skill_id>
        siracli skill install <skill_id> -p claude
        siracli skill install <skill_id> -d ./my-skills/
    """
    require_auth()
    client = get_client()
    import os

    # Get current working directory for relative path detection
    cwd = os.getcwd()

    # Auto-detect platform if not specified
    detected_dir = None
    if not platform:
        if install_dir:
            platform = "claude"  # Custom dir implies claude-style
        elif os.path.exists(os.path.join(cwd, ".claude")):
            platform = "claude"
            detected_dir = os.path.join(cwd, ".claude", "skills")
        elif os.path.exists(os.path.join(cwd, "openclaw.json")):
            platform = "openclaw"
        else:
            click.echo("✗ Cannot auto-detect platform. Use -p to specify or run in a directory with .claude", err=True)
            return
        click.echo(f"Auto-detected platform: {platform}")

    # Determine installation directory
    if install_dir:
        target_dir = os.path.expanduser(install_dir)
    elif detected_dir:
        target_dir = detected_dir
    elif platform == "claude":
        target_dir = os.path.expanduser("~/.claude/skills")
    elif platform == "openclaw":
        target_dir = os.path.expanduser("~/.openclaw/skills")
    else:
        click.echo(f"✗ Unknown platform: {platform}", err=True)
        return

    # Create target directory if needed
    os.makedirs(target_dir, exist_ok=True)

    # Get skill
    try:
        skill = client.get(f"/api/skills/{skill_id}")
        skill_name = skill.get("name", "unknown")
        click.echo(f"Installing skill '{skill_name}'...")

        # Download zip
        import requests
        from ..config import get_api_url, get_token

        url = f"{get_api_url()}/api/skills/{skill_id}/export"
        headers = {}
        token = get_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        response = requests.get(url, headers=headers, stream=True)
        if not response.ok:
            try:
                error_data = response.json()
                message = error_data.get("detail", error_data.get("message", response.text))
            except:
                message = response.text
            raise APIError(message, response.status_code)

        # Extract zip to target directory
        import zipfile
        import io

        skill_dir = os.path.join(target_dir, skill_name)
        os.makedirs(skill_dir, exist_ok=True)

        with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
            zf.extractall(skill_dir)

        click.echo(f"✓ Skill '{skill_name}' installed to {skill_dir}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)


@skill_group.command()
@click.argument("skill_id")
@click.option("--output", "-o", default=None, help="Output zip file path (default: skill-name.zip)")
def export(skill_id: str, output: str):
    """Export skill as a ZIP package"""
    require_auth()

    import requests
    from ..config import get_api_url, get_token

    url = f"{get_api_url()}/api/skills/{skill_id}/export"
    headers = {}
    token = get_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        # Get skill info for default filename
        client = get_client()
        skill = client.get(f"/api/skills/{skill_id}")
        default_filename = f"{skill['name']}.zip"
        output_path = output or default_filename

        response = requests.get(url, headers=headers, stream=True)

        if not response.ok:
            try:
                error_data = response.json()
                message = error_data.get("detail", error_data.get("message", response.text))
            except:
                message = response.text
            raise APIError(message, response.status_code)

        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        click.echo(f"✓ Skill exported to {output_path}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
