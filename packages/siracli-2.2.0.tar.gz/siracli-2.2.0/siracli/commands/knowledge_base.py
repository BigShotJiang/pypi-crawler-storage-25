"""Knowledge base management commands"""

import click
from ..client import get_client, APIError
from ..utils import require_auth


@click.group(name="kb")
def kb_group():
    """Knowledge base management"""
    pass


@kb_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
def kb_list(page: int, limit: int):
    """List all knowledge bases"""
    require_auth()
    client = get_client()

    try:
        response = client.get("/api/knowledge-base/knowledge-bases", params={
            "page": page,
            "limit": limit
        })
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No knowledge bases found.")
            return

        click.echo(f"\nTotal: {total} knowledge bases\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<25}{'DISPLAY NAME':<25}")
        click.echo("-" * 110)

        for kb in items:
            kb_id = kb.get("id", "")
            status = "●" if kb.get("status") == "active" else "○"
            name = kb.get("name", "N/A")[:23]
            display_name = kb.get("display_name", "")[:23]
            click.echo(f"{kb_id:<40}{status:<10}{name:<25}{display_name:<25}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@kb_group.command()
@click.argument("kb_id")
def info(kb_id: str):
    """Get knowledge base details"""
    require_auth()
    client = get_client()

    try:
        kb = client.get(f"/api/knowledge-base/knowledge-bases/{kb_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Knowledge Base Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {kb.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {kb.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {kb.get('display_name', 'N/A')}")
        click.echo(f"{'Status':<20} {kb.get('status', 'N/A')}")
        click.echo(f"{'LLM Model ID':<20} {kb.get('llm_model_id', 'N/A')}")
        click.echo(f"{'Embedding Model ID':<20} {kb.get('embedding_model_id', 'N/A')}")
        click.echo(f"{'Parser Type':<20} {kb.get('parser_type', 'N/A')}")
        click.echo(f"{'Documents':<20} {kb.get('document_count', 0)}")
        click.echo(f"{'Created At':<20} {str(kb.get('created_at', 'N/A'))[:19]}")

        description = kb.get("description")
        if description:
            click.echo(f"\n{'='*60}")
            click.echo(f"Description")
            click.echo(f"{'='*60}")
            click.echo(f"{description}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
