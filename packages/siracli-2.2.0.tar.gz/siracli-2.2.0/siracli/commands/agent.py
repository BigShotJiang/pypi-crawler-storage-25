"""Agent management commands"""

import click
import json
from ..client import get_client, APIError
from ..utils import require_auth, render_delete_conflict


@click.group(name="agent")
def agent_group():
    """Agent management"""
    pass


@agent_group.command(name="list")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--name", "-n", default=None, help="Filter by name")
def agent_list(page: int, limit: int, name: str):
    """List all agents"""
    require_auth()
    client = get_client()

    params = {"page": page, "limit": limit}
    if name:
        params["name"] = name

    try:
        response = client.get("/api/agent-system/agents", params=params)
        items = response.get("items", [])
        total = response.get("total", 0)

        if not items:
            click.echo("No agents found.")
            return

        # Table header
        click.echo(f"\nTotal: {total} agents\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'DISPLAY NAME':<22}{'NAME':<25}{'TOOLS'}")
        click.echo("-" * 110)

        for agent in items:
            status = "●" if agent.get("is_active") else "○"
            agent_id = agent["id"]
            display_name = (agent.get("display_name") or agent["name"])[:20]
            name = agent["name"][:23]
            tool_count = len(agent.get("mcp_tool_ids", []))
            click.echo(f"{agent_id:<40}{status:<10}{display_name:<22}{name:<25}{tool_count}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@agent_group.command()
@click.argument("agent_id")
def get(agent_id: str):
    """Get agent details"""
    require_auth()
    client = get_client()

    try:
        agent = client.get(f"/api/agent-system/agents/{agent_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Agent Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {agent['id']}")
        click.echo(f"{'Name':<20} {agent.get('name', 'N/A')}")
        click.echo(f"{'Display Name':<20} {agent.get('display_name', 'N/A')}")
        click.echo(f"{'Model ID':<20} {agent.get('model_id', 'N/A')}")
        click.echo(f"{'Status':<20} {'● Active' if agent.get('is_active') else '○ Inactive'}")
        click.echo(f"{'Version':<20} {agent.get('version', 'N/A')}")
        click.echo(f"{'Memory':<20} {agent.get('memory_type', 'N/A')}")
        click.echo(f"{'Streaming':<20} {'Enabled' if agent.get('streaming_enabled') else 'Disabled'}")
        click.echo(f"{'Timeout':<20} {agent.get('timeout_seconds', 'N/A')}s")
        click.echo(f"{'Total Executions':<20} {agent.get('total_executions', 0)}")
        click.echo(f"{'Created At':<20} {agent.get('created_at', 'N/A')[:19]}")

        mcp_tool_ids = agent.get("mcp_tool_ids", [])
        if mcp_tool_ids:
            click.echo(f"\nMCP Tool IDs ({len(mcp_tool_ids)}):")
            for tool_id in mcp_tool_ids:
                click.echo(f"  - {tool_id}")

        kb_ids = agent.get("knowledge_base_ids", [])
        if kb_ids:
            click.echo(f"\nKnowledge Base IDs ({len(kb_ids)}):")
            for kb_id in kb_ids:
                click.echo(f"  - {kb_id}")

        skill_ids = agent.get("skill_ids", [])
        if skill_ids:
            click.echo(f"\nSkill IDs ({len(skill_ids)}) [DeepAgents SubAgent only]:")
            for skill_id in skill_ids:
                click.echo(f"  - {skill_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"System Prompt")
        click.echo(f"{'='*60}")
        system_prompt = agent.get("system_prompt", "N/A")
        if system_prompt and system_prompt != "N/A":
            # Show first 500 chars
            display_prompt = system_prompt[:500] + "..." if len(system_prompt) > 500 else system_prompt
            click.echo(display_prompt)
        else:
            click.echo("N/A")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@agent_group.command()
@click.option("--name", required=True, help="Agent name (unique identifier)")
@click.option("--display-name", "-D", required=True, help="Display name")
@click.option("--model-id", "-m", required=True, help="Model ID")
@click.option("--system-prompt", "-s", required=True, help="System prompt")
@click.option("--description", "-d", default="", help="Agent description")
@click.option("--temperature", "-t", default=None, type=float, help="Temperature (0.0-2.0)")
@click.option("--max-tokens", "-x", default=None, type=int, help="Max tokens")
@click.option("--top-p", default=None, type=float, help="Top-p parameter (0.0-1.0)")
@click.option("--frequency-penalty", default=None, type=float, help="Frequency penalty (-2.0-2.0)")
@click.option("--presence-penalty", default=None, type=float, help="Presence penalty (-2.0-2.0)")
@click.option("--planning-prompt", default=None, help="Planning prompt")
@click.option("--planning-strategy", default=None,
              type=click.Choice(["none", "react", "plan_and_execute", "reflexion"]),
              help="Planning strategy")
@click.option("--max-planning-iterations", default=None, type=int, help="Max planning iterations (1-20)")
@click.option("--enable-memory/--disable-memory", default=True, help="Enable memory")
@click.option("--memory-type", default=None,
              type=click.Choice(["none", "summarize_at_limit"]),
              help="Memory type. 'none' = no memory; 'summarize_at_limit' (default) = "
                   "auto-summarize at ~15%% of model context_window. Old values "
                   "(conversation_buffer*, vector_store) auto-migrated to summarize_at_limit.")
@click.option("--tool-choice", default=None,
              type=click.Choice(["auto", "required", "none"]),
              help="Tool choice strategy")
@click.option("--tools", multiple=True, help="MCP tool IDs to enable")
@click.option("--knowledge-bases", multiple=True, help="Knowledge base IDs")
@click.option("--toolbox-toolsets", multiple=True, help="GenAI Toolbox toolset IDs")
@click.option("--skill", multiple=True, help="Skill ID (only for DeepAgents SubAgent, can use multiple times)")
@click.option("--streaming/--no-streaming", default=True, help="Enable streaming")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds (1-600)")
@click.option("--enabled/--disabled", default=True, help="Enable agent after creation")
def create(name: str, display_name: str, model_id: str, system_prompt: str, description: str,
           temperature: float, max_tokens: int, top_p: float, frequency_penalty: float,
           presence_penalty: float, planning_prompt: str, planning_strategy: str,
           max_planning_iterations: int, enable_memory: bool, memory_type: str,
           tool_choice: str, tools: tuple, knowledge_bases: tuple, toolbox_toolsets: tuple,
           skill: tuple, streaming: bool, timeout: int, enabled: bool):
    """Create a new agent"""
    require_auth()
    client = get_client()

    data = {
        "name": name,
        "display_name": display_name,
        "model_id": model_id,
        "system_prompt": system_prompt,
        "description": description,
        "mcp_tool_ids": list(tools),
        "toolbox_toolset_ids": list(toolbox_toolsets),
        "skill_ids": list(skill),
        "knowledge_base_ids": list(knowledge_bases),
        "is_active": enabled,
        "streaming_enabled": streaming,
        "enable_memory": enable_memory,
    }
    if temperature is not None:
        data["temperature"] = temperature
    if max_tokens is not None:
        data["max_tokens"] = max_tokens
    if top_p is not None:
        data["top_p"] = top_p
    if frequency_penalty is not None:
        data["frequency_penalty"] = frequency_penalty
    if presence_penalty is not None:
        data["presence_penalty"] = presence_penalty
    if planning_prompt is not None:
        data["planning_prompt"] = planning_prompt
    if planning_strategy is not None:
        data["planning_strategy"] = planning_strategy
    if max_planning_iterations is not None:
        data["max_planning_iterations"] = max_planning_iterations
    if memory_type is not None:
        data["memory_type"] = memory_type
    if tool_choice is not None:
        data["tool_choice"] = tool_choice
    if timeout is not None:
        data["timeout_seconds"] = timeout

    try:
        agent = client.post("/api/agent-system/agents", json=data)
        click.echo(f"✓ Agent created: {agent['name']} [{agent['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@agent_group.command()
@click.argument("agent_id")
@click.option("--name", "-n", default=None, help="Agent name")
@click.option("--display-name", "-D", default=None, help="Display name")
@click.option("--description", "-d", default=None, help="Agent description")
@click.option("--model-id", "-m", default=None, help="Model ID")
@click.option("--system-prompt", "-s", default=None, help="System prompt")
@click.option("--planning-prompt", default=None, help="Planning prompt")
@click.option("--planning-strategy", default=None,
              type=click.Choice(["none", "react", "plan_and_execute", "reflexion"]),
              help="Planning strategy")
@click.option("--max-planning-iterations", default=None, type=int, help="Max planning iterations (1-20)")
@click.option("--enable-memory/--disable-memory", default=None, help="Enable memory")
@click.option("--memory-type", default=None,
              type=click.Choice(["none", "summarize_at_limit"]),
              help="Memory type. 'none' = no memory; 'summarize_at_limit' (default) = "
                   "auto-summarize at ~15%% of model context_window. Old values "
                   "(conversation_buffer*, vector_store) auto-migrated to summarize_at_limit.")
@click.option("--tool-choice", default=None,
              type=click.Choice(["auto", "required", "none"]),
              help="Tool choice strategy")
@click.option("--tools", multiple=True, help="MCP tool IDs (replaces existing)")
@click.option("--knowledge-bases", multiple=True, help="Knowledge base IDs (replaces existing)")
@click.option("--toolbox-toolsets", multiple=True, help="GenAI Toolbox toolset IDs (replaces existing)")
@click.option("--skill", multiple=True, help="Skill ID (replaces existing, only for DeepAgents SubAgent)")
@click.option("--streaming/--no-streaming", default=None, help="Enable streaming")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds (1-600)")
@click.option("--enabled/--disabled", default=None, help="Enable/disable agent")
def update(agent_id: str, name: str, display_name: str, description: str, model_id: str,
           system_prompt: str, planning_prompt: str, planning_strategy: str,
           max_planning_iterations: int, enable_memory: bool, memory_type: str,
           tool_choice: str, tools: tuple, knowledge_bases: tuple, toolbox_toolsets: tuple,
           skill: tuple, streaming: bool, timeout: int, enabled: bool):
    """Update an agent"""
    require_auth()
    client = get_client()

    data = {}
    if name is not None:
        data["name"] = name
    if display_name is not None:
        data["display_name"] = display_name
    if description is not None:
        data["description"] = description
    if model_id is not None:
        data["model_id"] = model_id
    if system_prompt is not None:
        data["system_prompt"] = system_prompt
    if planning_prompt is not None:
        data["planning_prompt"] = planning_prompt
    if planning_strategy is not None:
        data["planning_strategy"] = planning_strategy
    if max_planning_iterations is not None:
        data["max_planning_iterations"] = max_planning_iterations
    if enable_memory is not None:
        data["enable_memory"] = enable_memory
    if memory_type is not None:
        data["memory_type"] = memory_type
    if tool_choice is not None:
        data["tool_choice"] = tool_choice
    if tools:
        data["mcp_tool_ids"] = list(tools)
    if knowledge_bases:
        data["knowledge_base_ids"] = list(knowledge_bases)
    if toolbox_toolsets:
        data["toolbox_toolset_ids"] = list(toolbox_toolsets)
    if skill:
        data["skill_ids"] = list(skill)
    if streaming is not None:
        data["streaming_enabled"] = streaming
    if timeout is not None:
        data["timeout_seconds"] = timeout
    if enabled is not None:
        data["is_active"] = enabled

    if not data:
        click.echo("No updates provided.")
        return

    try:
        agent = client.put(f"/api/agent-system/agents/{agent_id}", json=data)
        click.echo(f"✓ Agent updated: {agent['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@agent_group.command()
@click.argument("agent_id")
@click.option(
    "--force",
    is_flag=True,
    help="Bypass orchestrator-reference check (dangling refs become broken at runtime).",
)
def delete(agent_id: str, force: bool):
    """Delete an agent.

    By default the backend rejects with 409 AGENT_IN_USE if any
    orchestrator references this agent (single.agent_id, supervisor,
    collaboration, workflow, conditional, deep_agents). Use --force
    to skip the check.
    """
    require_auth()

    if not click.confirm(f"Are you sure you want to delete agent {agent_id}?"):
        return

    client = get_client()
    path = f"/api/agent-system/agents/{agent_id}"
    if force:
        path += "?force=true"

    try:
        client.delete(path)
        click.echo(f"✓ Agent deleted")

    except APIError as e:
        if render_delete_conflict(e):
            return
        click.echo(f"✗ Error: {e}", err=True)
