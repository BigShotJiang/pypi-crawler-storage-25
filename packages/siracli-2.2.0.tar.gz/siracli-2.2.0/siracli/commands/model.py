"""AI Model management commands"""

import click
from ..client import get_client, APIError
from ..utils import require_auth, render_delete_conflict


@click.group(name="model")
def model_group():
    """AI Model management"""
    pass


@model_group.command()
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-l", default=20, help="Items per page")
@click.option("--provider", "-P", default=None, help="Filter by provider (OPENAI, ANTHROPIC, DEEPSEEK, etc.)")
@click.option("--enabled/--all", default=None, help="Show only enabled models")
def list(page: int, limit: int, provider: str, enabled: bool):
    """List all AI models"""
    require_auth()
    client = get_client()

    params = {"page": page, "limit": limit}
    if provider:
        params["provider"] = provider
    if enabled is not None:
        params["is_enabled"] = enabled

    try:
        response = client.get("/api/ai-models", params=params)
        models = response.get("models", [])
        total = response.get("pagination", {}).get("total", 0)

        if not models:
            click.echo("No models found.")
            return

        click.echo(f"\nTotal: {total} models\n")
        click.echo(f"{'ID':<40}{'STATUS':<10}{'NAME':<30}{'PROVIDER':<15}{'TYPE'}")
        click.echo("-" * 110)

        for model in models:
            model_id = model.get("id", "")
            status = "●" if model.get("isEnabled") else "○"
            name = model.get("name", "N/A")[:28]
            provider = model.get("provider", "N/A")[:13]
            model_type = ",".join(model.get("modelType", []))[:15] if model.get("modelType") else "N/A"
            click.echo(f"{model_id:<40}{status:<10}{name:<30}{provider:<15}{model_type}")

        click.echo()

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@model_group.command()
@click.argument("model_id")
def get(model_id: str):
    """Get model details"""
    require_auth()
    client = get_client()

    try:
        # Get model by ID
        model = client.get(f"/api/ai-models/{model_id}")

        click.echo(f"\n{'='*60}")
        click.echo(f"Model Details")
        click.echo(f"{'='*60}")
        click.echo(f"{'ID':<20} {model.get('id', 'N/A')}")
        click.echo(f"{'Name':<20} {model.get('name', 'N/A')}")
        click.echo(f"{'Provider':<20} {model.get('provider', 'N/A')}")
        click.echo(f"{'Model Name':<20} {model.get('modelName', 'N/A')}")
        click.echo(f"{'Type':<20} {', '.join(model.get('modelType', []))}")
        click.echo(f"{'Status':<20} {'● Enabled' if model.get('isEnabled') else '○ Disabled'}")
        click.echo(f"{'Default':<20} {'Yes' if model.get('isDefault') else 'No'}")
        click.echo(f"\n{'='*60}")
        click.echo(f"Configuration")
        click.echo(f"{'='*60}")
        click.echo(f"{'API Base URL':<20} {model.get('apiBaseUrl', 'N/A')}")
        click.echo(f"{'Temperature':<20} {model.get('temperature', 'N/A')}")
        click.echo(f"{'Max Tokens':<20} {model.get('maxTokens', 'N/A')}")
        click.echo(f"{'Context Window':<20} {model.get('contextWindow', 'N/A')}")
        click.echo(f"{'Timeout':<20} {model.get('timeout', 'N/A')}s")
        click.echo(f"{'Top P':<20} {model.get('topP', 'N/A')}")
        click.echo(f"{'Thinking Mode':<20} {'Enabled' if model.get('enableThinking') else 'Disabled'}")
        click.echo(f"{'Reasoning Mode':<20} {'Enabled' if model.get('enableReasoning') else 'Disabled'}")
        click.echo(f"\n{'='*60}")
        click.echo(f"Statistics")
        click.echo(f"{'='*60}")
        click.echo(f"{'Total Requests':<20} {model.get('totalRequests', 0)}")
        click.echo(f"{'Total Tokens':<20} {model.get('totalTokens', 0)}")
        click.echo(f"{'Last Used':<20} {str(model.get('lastUsedAt', 'N/A'))[:19] if model.get('lastUsedAt') else 'N/A'}")
        click.echo(f"{'Created At':<20} {str(model.get('createdAt', 'N/A'))[:19]}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@model_group.command()
@click.option("--name", "-n", required=True, help="Display name")
@click.option("--provider", "-p", required=True,
              type=click.Choice(["openai", "claude", "deepseek", "azure_openai", "qwen", "local", "custom"]),
              help="Model provider")
@click.option("--model-name", "-m", required=True, help="Model identifier (e.g., gpt-4, claude-3-sonnet)")
@click.option("--api-key", "-k", default=None, help="API Key (will be encrypted)")
@click.option("--base-url", "-u", default=None, help="API Base URL")
@click.option("--temperature", "-t", default=None, type=float, help="Temperature (0.0-2.0)")
@click.option("--max-tokens", "-x", default=None, type=int, help="Max tokens")
@click.option("--context-window", "-c", default=None, type=int, help="Context window size")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds")
@click.option("--top-p", default=None, type=float, help="Top-p parameter (0.0-1.0)")
@click.option("--model-type", "-T", default=None, help="Model type(s), comma-separated (e.g., LLM,VISION)")
@click.option("--enable-thinking/--no-thinking", default=False, help="Enable thinking mode (o1/o3)")
@click.option("--enable-reasoning/--no-reasoning", default=False, help="Enable reasoning mode (DeepSeek R1)")
@click.option("--default/--not-default", default=False, help="Set as default model")
@click.option("--enabled/--disabled", default=True, help="Enable model after creation")
def create(name: str, provider: str, model_name: str, api_key: str, base_url: str,
           temperature: float, max_tokens: int, context_window: int, timeout: int,
           top_p: float, model_type: str, enable_thinking: bool, enable_reasoning: bool,
           default: bool, enabled: bool):
    """Create a new AI model configuration"""
    require_auth()
    client = get_client()

    data = {
        "name": name,
        "provider": provider,
        "modelName": model_name,
        "model_id": model_name,
        "is_enabled": enabled,
        "is_default": default,
        "enableThinking": enable_thinking,
        "enableReasoning": enable_reasoning,
    }
    if model_type:
        # Parse comma-separated model types
        valid_types = {"LLM", "EMBEDDING", "VISION"}
        types = [t.strip().upper() for t in model_type.split(",") if t.strip()]
        invalid = set(types) - valid_types
        if invalid:
            click.echo(f"✗ Invalid model types: {invalid}. Valid: {valid_types}", err=True)
            return
        data["modelType"] = types
    if api_key:
        data["apiKey"] = api_key
    if base_url:
        data["apiBaseUrl"] = base_url
    if temperature is not None:
        data["temperature"] = temperature
    if max_tokens is not None:
        data["maxTokens"] = max_tokens
    if context_window is not None:
        data["contextWindow"] = context_window
    if timeout is not None:
        data["timeout"] = timeout
    if top_p is not None:
        data["topP"] = top_p

    try:
        model = client.post("/api/ai-models", json=data)
        click.echo(f"✓ Model created: {model['name']} [{model['id']}]")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@model_group.command()
@click.argument("model_id")
@click.option("--name", "-n", default=None, help="Display name")
@click.option("--api-key", "-k", default=None, help="API Key (leave empty to keep current)")
@click.option("--base-url", "-u", default=None, help="API Base URL")
@click.option("--temperature", "-t", default=None, type=float, help="Temperature (0.0-2.0)")
@click.option("--max-tokens", "-x", default=None, type=int, help="Max tokens")
@click.option("--timeout", default=None, type=int, help="Timeout in seconds")
@click.option("--top-p", default=None, type=float, help="Top-p parameter (0.0-1.0)")
@click.option("--enable-thinking/--no-thinking", default=None, help="Enable thinking mode")
@click.option("--enable-reasoning/--no-reasoning", default=None, help="Enable reasoning mode")
@click.option("--default/--not-default", default=None, help="Set as default model")
@click.option("--enabled/--disabled", default=None, help="Enable/disable model")
def update(model_id: str, name: str, api_key: str, base_url: str,
           temperature: float, max_tokens: int, timeout: int,
           top_p: float, enable_thinking: bool, enable_reasoning: bool,
           default: bool, enabled: bool):
    """Update a model configuration"""
    require_auth()
    client = get_client()

    data = {}
    if name:
        data["name"] = name
    if api_key:
        data["apiKey"] = api_key
    if base_url:
        data["apiBaseUrl"] = base_url
    if temperature is not None:
        data["temperature"] = temperature
    if max_tokens is not None:
        data["maxTokens"] = max_tokens
    if timeout is not None:
        data["timeout"] = timeout
    if top_p is not None:
        data["topP"] = top_p
    if enable_thinking is not None:
        data["enableThinking"] = enable_thinking
    if enable_reasoning is not None:
        data["enableReasoning"] = enable_reasoning
    if default is not None:
        data["is_default"] = default
    if enabled is not None:
        data["is_enabled"] = enabled

    if not data:
        click.echo("No updates provided.")
        return

    try:
        model = client.put(f"/api/ai-models/{model_id}", json=data)
        click.echo(f"✓ Model updated: {model['name']}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)


@model_group.command()
@click.argument("model_id")
@click.option(
    "--force",
    is_flag=True,
    help="Bypass agent/orchestrator-reference check.",
)
def delete(model_id: str, force: bool):
    """Delete a model configuration.

    By default the backend rejects with 409 MODEL_IN_USE if any Agent
    or Orchestrator references this model. Use --force to skip the
    check (referenced agents/orchestrators will fail at chat time).
    """
    require_auth()

    if not click.confirm(f"Are you sure you want to delete model {model_id}?"):
        return

    client = get_client()
    path = f"/api/ai-models/{model_id}"
    if force:
        path += "?force=true"

    try:
        client.delete(path)
        click.echo(f"✓ Model deleted")

    except APIError as e:
        if render_delete_conflict(e):
            return
        click.echo(f"✗ Error: {e}", err=True)


@model_group.command()
@click.argument("model_id")
@click.option("--test-message", "-m", default="Hello, are you working?", help="Test message")
def test(model_id: str, test_message: str):
    """Test model connection"""
    require_auth()
    client = get_client()

    click.echo("Testing model connection...")

    try:
        response = client.post(f"/api/ai-models/{model_id}/test", json={
            "testMessage": test_message
        })
        if response.get("success"):
            click.echo("✓ Model connection successful")
            if response.get("response"):
                click.echo(f"Response: {response['response'][:200]}...")
        else:
            click.echo(f"✗ Test failed: {response.get('error', 'Unknown error')}")

    except APIError as e:
        click.echo(f"✗ Error: {e}", err=True)
