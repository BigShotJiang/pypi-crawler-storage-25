"""Utility functions for siracli"""

import click
from .config import is_authenticated
from .client import APIError


def require_auth():
    """Check if user is authenticated.
    Raises click.Abort if not logged in.
    """
    if not is_authenticated():
        click.echo("✗ Not logged in. Run 'siracli auth login' first.", err=True)
        raise click.Abort()


# Resource-type → label map for rendering 409 conflict payloads. Backend
# payload shape:
#   {"code": "MODEL_IN_USE", "message": "...",
#    "references": {"agents": [...], "orchestrators": [...]},
#    "hint": "..."}
_REFERENCE_LABELS = {
    "agents": "Agents",
    "orchestrators": "Orchestrators",
    "applications": "Applications",
}


def render_delete_conflict(error: APIError, force_hint: str = "--force") -> bool:
    """If ``error`` is a structured 409 conflict, pretty-print it and
    return True. Otherwise return False so the caller can fall back to
    its default error handler.
    """
    if error.status_code != 409 or not error.detail:
        return False

    detail = error.detail
    code = detail.get("code", "CONFLICT")
    message = detail.get("message", str(error))
    references = detail.get("references") or {}

    click.echo(f"\n✗ {code}: {message}\n", err=True)

    for key, items in references.items():
        if not items:
            continue
        label = _REFERENCE_LABELS.get(key, key.title())
        click.echo(f"  Referenced by {len(items)} {label}:", err=True)
        for ref in items[:10]:
            name = ref.get("display_name") or ref.get("name") or ref.get("id", "?")
            field = ref.get("field")
            ref_id = ref.get("id", "")
            line = f"    • {name} ({ref_id})"
            if field:
                line += f"  [{field}]"
            click.echo(line, err=True)
        if len(items) > 10:
            click.echo(f"    ... and {len(items) - 10} more", err=True)

    hint = detail.get("hint") or f"Re-run with {force_hint} to override."
    click.echo(f"\n  Hint: {hint}", err=True)
    return True
