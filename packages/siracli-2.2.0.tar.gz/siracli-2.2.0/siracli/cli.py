"""SiraCLI - Main CLI Entry Point"""

import click
from . import __version__
from .commands.auth import auth_group
from .commands.agent import agent_group
from .commands.orchestrator import orchestrator_group
from .commands.model import model_group
from .commands.application import application_group
from .commands.mcp import mcp_group
from .commands.system import system_group
from .commands.knowledge_base import kb_group
from .commands.toolbox import toolbox_group
from .commands.skill import skill_group
from .commands.sandbox import sandbox_group
from .commands.license import license_group
from .commands.memory import memory_group


@click.group()
@click.version_option(version=__version__, prog_name="siracli")
def main():
    """Sira AI Command Line Interface

    Enterprise AI Agent Platform CLI for managing agents, orchestrators,
    applications, and more.
    """
    pass


# Register command groups
main.add_command(auth_group)
main.add_command(agent_group)
main.add_command(orchestrator_group)
main.add_command(model_group)
main.add_command(application_group)
main.add_command(mcp_group)
main.add_command(system_group)
main.add_command(kb_group)
main.add_command(toolbox_group)
main.add_command(skill_group)
main.add_command(sandbox_group)
main.add_command(license_group)
main.add_command(memory_group)


if __name__ == "__main__":
    main()
