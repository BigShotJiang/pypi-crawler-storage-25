"""Configuration and token storage for siracli"""

import os
import json
from pathlib import Path
from typing import Optional, Dict, Any

CONFIG_DIR = Path.home() / ".siracli"
TOKEN_FILE = CONFIG_DIR / "token.json"


def ensure_config_dir():
    """Ensure config directory exists"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_api_url() -> str:
    """Get API URL from config or default"""
    ensure_config_dir()
    if TOKEN_FILE.exists():
        try:
            data = json.loads(TOKEN_FILE.read_text())
            return data.get("api_url", "http://localhost:8000")
        except (json.JSONDecodeError, IOError):
            pass
    return "http://localhost:8000"


def set_api_url(api_url: str) -> None:
    """Set API URL in config"""
    ensure_config_dir()
    data = {}
    if TOKEN_FILE.exists():
        try:
            data = json.loads(TOKEN_FILE.read_text())
        except (json.JSONDecodeError, IOError):
            pass
    data["api_url"] = api_url.rstrip("/")
    TOKEN_FILE.write_text(json.dumps(data, indent=2))


def get_token() -> Optional[str]:
    """Get stored auth token"""
    ensure_config_dir()
    if not TOKEN_FILE.exists():
        return None
    try:
        data = json.loads(TOKEN_FILE.read_text())
        return data.get("token")
    except (json.JSONDecodeError, IOError):
        return None


def save_token(token: str, user: Dict[str, Any], api_url: str, expires_at: Optional[str] = None) -> None:
    """Save auth token and user info"""
    ensure_config_dir()
    data = {
        "api_url": api_url.rstrip("/"),
        "token": token,
        "user": user,
        "expires_at": expires_at,
    }
    TOKEN_FILE.write_text(json.dumps(data, indent=2))


def get_user() -> Optional[Dict[str, Any]]:
    """Get stored user info"""
    ensure_config_dir()
    if not TOKEN_FILE.exists():
        return None
    try:
        data = json.loads(TOKEN_FILE.read_text())
        return data.get("user")
    except (json.JSONDecodeError, IOError):
        return None


def clear_token() -> None:
    """Remove stored token (logout)"""
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()


def is_authenticated() -> bool:
    """Check if user is logged in"""
    return get_token() is not None
