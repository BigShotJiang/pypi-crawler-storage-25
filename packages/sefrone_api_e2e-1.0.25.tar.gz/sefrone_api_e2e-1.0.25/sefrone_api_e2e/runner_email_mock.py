import re
import time
import os
from typing import Optional

from .step_runner import StepRunner, RunContext, StepResult
from .email_mock_server import EmailMockServer


class EmailMockRunner(StepRunner):
    """
    Runner that manages an in-process mock SMTP/IMAP/HTTP email server and
    handles ``check_email`` steps.

    setup():
        - Rewrites mail-related vars in the .env file so that the running
          application delivers emails to the local mock SMTP server instead
          of a real one.
        - Starts the EmailMockServer (SMTP + IMAP + HTTP API).

    teardown():
        - Stops the EmailMockServer.

    Step syntax::

        - name: "Wait for OTP email and extract code"
          runner: email          # explicit — or omit, auto-detected by 'check_email' key
          check_email:
            to: "user@example.com"       # optional substring match against the To field
            subject: "Your OTP"          # optional substring match against the Subject field
            from: "noreply@app.com"      # optional substring match against the From field
            clear_after: true            # optional — clear the inbox after a successful match
          retry:
            attempts: 15                 # how many times to poll (default 10)
            delay_seconds: 2             # pause between polls (default 1)
          assertions:
            - "{{email.to}} include user@example.com"
            - "{{email.subject}} include OTP"
          save:
            # Plain template — save an entire email field
            email_subject: "{{email.subject}}"
            # Regex extraction — pull a capture group out of a field
            otp_code:
              from: "{{email.body}}"
              regex: "\\b([A-Za-z0-9]{8})\\b"

    Available ``{{email.*}}`` context fields:
        to, from, subject, body, raw, received_at, index, uid, flags

    Overridden .env variables (mail-related):
        MAIL_SERVER          -> docker_smtp_host  (default: platform-aware)
        MAIL_SERVER_PORT     -> smtp_port
        MAIL_USE_SECURITY    -> false

    Credentials (MAIL_ACCOUNT / MAIL_PASSWORD) are intentionally NOT overridden.
    Leaving them unset or empty causes MailKit to skip the AUTH handshake entirely,
    which avoids the "SMTP server does not support authentication" error.
    """

    # Only override transport settings — no credentials so MailKit skips AUTH
    _ENV_OVERRIDES = {
        "MAIL_USE_SECURITY": "false",
    }

    @staticmethod
    def _resolve_default_docker_smtp_host() -> str:
        """
        Resolve a cross-platform default for MAIL_SERVER inside Docker containers.

        Priority:
        1) SEFRONE_DOCKER_SMTP_HOST env var (explicit override)
        2) BITBUCKET_DOCKER_HOST_INTERNAL in Bitbucket pipelines
        3) host.docker.internal on Windows
        4) 172.17.0.1 on Linux/CI as a practical host-gateway fallback
        """
        explicit = os.getenv("SEFRONE_DOCKER_SMTP_HOST", "").strip()
        if explicit:
            return explicit
        bitbucket_host = os.getenv("BITBUCKET_DOCKER_HOST_INTERNAL", "").strip()
        if bitbucket_host:
            return bitbucket_host
        if os.name == "nt":
            return "host.docker.internal"
        return "172.17.0.1"

    def __init__(
        self,
        smtp_host: str = "0.0.0.0",
        smtp_port: int = 1025,
        imap_port: int = 1143,
        http_port: int = 8025,
        docker_smtp_host: Optional[str] = None,
    ):
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._imap_port = imap_port
        self._http_port = http_port
        self._docker_smtp_host = docker_smtp_host or EmailMockRunner._resolve_default_docker_smtp_host()
        self._server: Optional[EmailMockServer] = None

    @property
    def name(self) -> str:
        return "email"

    def handles(self, step: dict) -> bool:
        return "check_email" in step and "method" not in step

    # ------------------------------------------------------------------ #
    #  Lifecycle
    # ------------------------------------------------------------------ #

    def setup(self, env_file_path: str) -> None:
        # env patching is intentionally NOT done here — it must happen before the
        # application (Docker) starts.  Call patch_env_file() before launching
        # containers and this setup() only starts the server.
        self._server = EmailMockServer(
            host=self._smtp_host,
            http_port=self._http_port,
            smtp_port=self._smtp_port,
            imap_port=self._imap_port,
        )
        self._server.start()

    @staticmethod
    def patch_env_file(
        env_file_path: str,
        docker_smtp_host: Optional[str] = None,
        smtp_port: int = 1025,
    ) -> None:
        """
        Patch mail transport settings in *env_file_path* so the application
        delivers emails to the local mock SMTP server.

        Call this BEFORE starting the application (e.g. before docker-compose up)
        so the container picks up the values at startup.

        Only transport settings are changed — credentials are left as-is so that
        applications with no mandatory auth config skip the AUTH handshake.
        """
        resolved_docker_smtp_host = docker_smtp_host or EmailMockRunner._resolve_default_docker_smtp_host()

        overrides = {
            **EmailMockRunner._ENV_OVERRIDES,
            "MAIL_SERVER": resolved_docker_smtp_host,
            "MAIL_SERVER_PORT": str(smtp_port),
        }
        try:
            with open(env_file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError:
            print(f"[WARN] env file not found for EmailMockRunner patch: {env_file_path}")
            return

        new_lines = []
        replaced = set()
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("#") or "=" not in stripped:
                new_lines.append(line)
                continue
            key = stripped.split("=", 1)[0].strip()
            if key in overrides:
                new_lines.append(f"{key}={overrides[key]}\n")
                replaced.add(key)
            else:
                new_lines.append(line)
        for key, val in overrides.items():
            if key not in replaced:
                new_lines.append(f"{key}={val}\n")
        with open(env_file_path, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        print(
            f"[EmailMockRunner] Patched {env_file_path}: "
            f"MAIL_SERVER={resolved_docker_smtp_host}:{smtp_port}, MAIL_USE_SECURITY=false"
        )

    def teardown(self) -> None:
        if self._server is not None:
            self._server.stop()
            self._server = None

    # ------------------------------------------------------------------ #
    #  Execute
    # ------------------------------------------------------------------ #

    def execute(self, step: dict, ctx: RunContext) -> StepResult:
        if self._server is None:
            return StepResult.failed(
                "EmailMockRunner.execute() called but the server is not running. "
                "Ensure setup() was called (runner must be registered via the "
                "runners= parameter of run_all_tests)."
            )

        try:
            email_spec = step["check_email"]
            retry_cfg = step.get("retry", {})
            max_attempts = retry_cfg.get("attempts", 10)
            delay_seconds = retry_cfg.get("delay_seconds", 1)

            matched = self._wait_for_email(email_spec, ctx, max_attempts, delay_seconds)

            if matched is None:
                return StepResult.failed(
                    f"No matching email found after {max_attempts} attempt(s). "
                    f"Filter: {email_spec}. "
                    f"Inbox: {self._server.get_emails()}"
                )

            print(
                f"   Matched email: from={matched.get('from')!r} "
                f"to={matched.get('to')!r} subject={matched.get('subject')!r} "
                f"body={matched.get('body')!r}"
            )

            self._run_assertions(step, matched, ctx)
            self._run_saves(step, matched, ctx)

            if email_spec.get("clear_after", False):
                self._server.clear()

            return StepResult.passed()

        except AssertionError as e:
            return StepResult.failed(str(e))

    # ------------------------------------------------------------------ #
    #  Internal helpers
    # ------------------------------------------------------------------ #

    def _wait_for_email(self, email_spec: dict, ctx: RunContext, max_attempts: int, delay_seconds: float):
        for attempt in range(max_attempts):
            if attempt > 0:
                time.sleep(delay_seconds)

            candidates = self._server.get_emails()

            if "to" in email_spec:
                f = ctx.substitute_stored(str(email_spec["to"])).lower()
                candidates = [e for e in candidates if f in e.get("to", "").lower()]
            if "subject" in email_spec:
                f = ctx.substitute_stored(str(email_spec["subject"])).lower()
                candidates = [e for e in candidates if f in e.get("subject", "").lower()]
            if "from" in email_spec:
                f = ctx.substitute_stored(str(email_spec["from"])).lower()
                candidates = [e for e in candidates if f in e.get("from", "").lower()]

            if candidates:
                return candidates[-1]  # most recent match

        return None

    def _run_assertions(self, step: dict, matched: dict, ctx: RunContext) -> None:
        for expr in step.get("assertions", []):
            try:
                expr = ctx.substitute_stored(expr)
                rendered = ctx.render_template(expr, {"email": matched}, add_quotes=True)
                ctx.try_eval(rendered, expr)
            except Exception as e:
                raise AssertionError(
                    f"Email assertion failed for expression\n    -->'{expr}'\n    -->{e}"
                )

    def _run_saves(self, step: dict, matched: dict, ctx: RunContext) -> None:
        for key, path_expr in step.get("save", {}).items():
            try:
                if isinstance(path_expr, dict) and "from" in path_expr and "regex" in path_expr:
                    # Regex extraction mode: render the source field then apply regex
                    source_tmpl = ctx.substitute_stored(str(path_expr["from"]))
                    source = ctx.render_template(source_tmpl, {"email": matched})
                    m = re.search(path_expr["regex"], source)
                    if m is None:
                        raise AssertionError(
                            f"Regex {path_expr['regex']!r} did not match in email field. "
                            f"Source: {source!r}"
                        )
                    value = m.group(1) if m.lastindex else m.group(0)
                else:
                    # Plain template mode
                    tmpl = ctx.substitute_stored(str(path_expr))
                    value = ctx.render_template(tmpl, {"email": matched})
                ctx.store_value(key, value)
            except AssertionError:
                raise
            except Exception as e:
                raise AssertionError(
                    f"Failed to process email save for key '{key}'\n    -->{e}"
                )

    def _patch_env(self, env_file_path: str) -> None:
        """Instance-level shim — delegates to the public static method."""
        EmailMockRunner.patch_env_file(
            env_file_path,
            docker_smtp_host=self._docker_smtp_host,
            smtp_port=self._smtp_port,
        )


