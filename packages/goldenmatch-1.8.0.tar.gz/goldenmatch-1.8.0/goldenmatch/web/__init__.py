"""GoldenMatch local web UI."""
