import pytest
import src.tickr.daemon as daemon
from unittest.mock import patch

@pytest.fixture(autouse=True)
def clear_running_tasks():
    daemon.running_tasks.clear()
    yield
    daemon.running_tasks.clear()

def test_should_run_evaluation():
    from datetime import datetime, timedelta
    now = datetime.now()
    
    past_task = {"next_run_at": (now - timedelta(minutes=5)).isoformat()}
    future_task = {"next_run_at": (now + timedelta(minutes=5)).isoformat()}
    no_schedule_task = {"next_run_at": None}
    
    assert daemon.should_run(past_task, now) is True
    assert daemon.should_run(future_task, now) is False
    assert daemon.should_run(no_schedule_task, now) is False

@patch("src.tickr.daemon.get_connection")
def test_execute_task_skips_if_already_running(mock_get_conn):
    mock_task = {"id": 99, "name": "clashing-job", "command": "sleep 10", "timeout_seconds": 5}
    
    # fake that the task is actively running
    daemon.running_tasks[99] = True
    
    with patch.object(daemon.logging, "warning") as mock_warn:
        daemon.execute_task(mock_task)
        mock_warn.assert_called_once_with("Task 'clashing-job' is already running, skipping this execution")