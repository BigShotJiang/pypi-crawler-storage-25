import pytest
from datetime import datetime, timedelta
from src.tickr.parser import parse_schedule

@pytest.mark.parametrize("input_str,expected_unit,expected_qty", [
    ("every 5 minutes", "minutes", 5),
    ("every hour", "hours", 1),
    ("every 2 days", "days", 2),
])
def test_parse_schedule_intervals(input_str, expected_unit, expected_qty):
    now = datetime.now()
    result = parse_schedule(input_str)
    
    assert result is not None
    delta = result - now
    
    if expected_unit == "minutes":
        assert abs(delta.total_seconds() - (expected_qty * 60)) < 2
    elif expected_unit == "hours":
        assert abs(delta.total_seconds() - (expected_qty * 3600)) < 2
    elif expected_unit == "days":
        assert abs(delta.days - expected_qty) <= 1

def test_parse_schedule_daily_time():
    result = parse_schedule("every day at 23:59")
    assert result is not None
    assert result.hour == 23
    assert result.minute == 59
    assert result > datetime.now()

def test_parse_schedule_weekdays():
    result = parse_schedule("every weekday")
    assert result is not None
    assert result.weekday() < 5  # 0-4 are Mon-Fri

def test_parse_schedule_invalid():
    assert parse_schedule("not a valid cron alternative") is None