import pytest
import sqlite3
from click.testing import CliRunner
from src.tickr.cli import cli
import src.tickr.database as db


@pytest.fixture(autouse=True)
def mock_db_context(tmp_path, monkeypatch):
    test_db_file = str(tmp_path / "cli_test.db")
    real_connect = sqlite3.connect

    def mock_connect(*args, **kwargs):
        return real_connect(test_db_file)

    monkeypatch.setattr(sqlite3, "connect", mock_connect)

    db.init_db()

    yield


def test_cli_add_command_success():
    runner = CliRunner()
    result = runner.invoke(
        cli, ["add", "my-task", "--run", "echo 'hi'", "--when", "every 5 minutes"]
    )

    assert result.exit_code == 0
    assert "Task 'my-task' scheduled to run every 5 minutes" in result.output

    assert db.get_task_by_name("my-task") is not None


def test_cli_add_invalid_name_fails():
    runner = CliRunner()
    result = runner.invoke(
        cli, ["add", "bad name!!!", "--run", "echo 1", "--when", "every hour"]
    )

    assert (
        "Task name must contain only letters, numbers, hyphens, and underscores."
        in result.output
    )
    assert db.get_all_tasks() == []


def test_cli_list_empty_state():
    runner = CliRunner()
    result = runner.invoke(cli, ["list"])
    assert "No tasks scheduled yet. Use 'schedule add' to create one." in result.output
