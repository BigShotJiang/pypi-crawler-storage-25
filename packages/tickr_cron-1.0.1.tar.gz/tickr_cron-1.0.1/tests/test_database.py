import pytest
import sqlite3
from pathlib import Path
import src.tickr.database as db

@pytest.fixture(autouse=True)
def setup_test_db(tmp_path):
    origin_path = db.DB_PATH
    test_db = tmp_path / "test_schedule.db"
    db.DB_PATH = test_db
    db.init_db()
    
    yield
    
    # Restore production path bindings after tests finish
    db.DB_PATH = origin_path

def test_add_and_get_task():
    db.add_task("test-job", "echo 1", "every 5 minutes")
    task = db.get_task_by_name("test-job")
    
    assert task is not None
    assert task["command"] == "echo 1"
    assert task["enabled"] == 1

    db.add_task("test-job", "echo 2", "every hour")
    assert len(db.get_all_tasks()) == 1