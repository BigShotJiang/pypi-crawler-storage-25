import time
import sys
import os
import signal
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from .database import get_all_tasks, get_connection
from .parser import parse_schedule

# Daemon configuration
DAEMON_DIR = Path.home() / ".tickr"
PID_FILE = DAEMON_DIR / "daemon.pid"
LOG_FILE = DAEMON_DIR / "daemon.log"
MAX_LOG_SIZE = 10 * 1024 * 1024  # 10MB

# Currently running task processes (to prevent duplicate runs)
running_tasks = {}

# Setup logging
def setup_logging():
    """Configure daemon logging with rotation."""
    DAEMON_DIR.mkdir(parents=True, exist_ok=True)
    
    # Simple log rotation - truncate if too large
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_LOG_SIZE:
        with open(LOG_FILE, 'r') as f:
            lines = f.readlines()
        # Keep last 1000 lines
        with open(LOG_FILE, 'w') as f:
            f.writelines(lines[-1000:])
    
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

def write_pid_file():
    """Write daemon PID to file."""
    DAEMON_DIR.mkdir(parents=True, exist_ok=True)
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))
    logging.info(f"Daemon started with PID {os.getpid()}")

def remove_pid_file():
    """Remove PID file on shutdown."""
    if PID_FILE.exists():
        PID_FILE.unlink()
    logging.info("Daemon stopped")

def is_daemon_running():
    """Check if daemon is already running."""
    if not PID_FILE.exists():
        return False
    
    try:
        with open(PID_FILE, 'r') as f:
            pid = int(f.read().strip())
        
        # Check if process with this PID exists
        os.kill(pid, 0)  # Signal 0 doesn't kill, just checks existence
        return True
    except (ProcessLookupError, ValueError):
        # Process doesn't exist or invalid PID
        remove_pid_file()
        return False

def signal_handler(signum, frame):
    """Handle shutdown signals gracefully."""
    logging.info(f"Received signal {signum}, shutting down...")
    remove_pid_file()
    sys.exit(0)

def should_run(task, now):
    """Check if task should run based on next_run_at."""
    if not task['next_run_at']:
        return False
    
    next_run = datetime.fromisoformat(task['next_run_at'])
    return next_run <= now

def calculate_next_run(task):
    """Calculate the next run time based on schedule."""
    schedule = task['schedule']
    next_run = parse_schedule(schedule)
    
    if next_run:
        with get_connection() as conn:
            conn.execute(
                "UPDATE tasks SET next_run_at = ? WHERE id = ?",
                (next_run.isoformat(), task['id'])
            )
            conn.commit()
        logging.info(f"Task '{task['name']}' next run scheduled for {next_run}")
    else:
        logging.error(f"Failed to parse schedule '{schedule}' for task '{task['name']}'")

def execute_task(task, retry_attempt=0):
    """Execute a task and log results."""
    task_id = task['id']
    task_name = task['name']
    command = task['command']
    
    # Check if task is already running
    if task_id in running_tasks:
        logging.warning(f"Task '{task_name}' is already running, skipping this execution")
        return
    
    logging.info(f"Starting task '{task_name}': {command}")
    
    # Record start time
    started_at = datetime.now()
    
    # Create execution record
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO executions (task_id, started_at) VALUES (?, ?)",
            (task_id, started_at.isoformat())
        )
        execution_id = cursor.lastrowid
        conn.commit()
    
    # Mark task as running
    running_tasks[task_id] = True
    
    timeout = task['timeout_seconds']
    try:
        if sys.platform == "win32":
            shell_cmd = ["cmd.exe", "/c", command]
            use_shell = False
        else:
            shell_cmd = command
            use_shell = True
        
        process = subprocess.run(
            shell_cmd,
            shell=use_shell,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        
        finished_at = datetime.now()
        duration = (finished_at - started_at).total_seconds()
        
        stdout = process.stdout if process.stdout else ""
        stderr = process.stderr if process.stderr else ""
        exit_code = process.returncode
        status = "success" if exit_code == 0 else "failed"
        
        # Update execution record
        with get_connection() as conn:
            conn.execute(
                """UPDATE executions 
                   SET finished_at = ?, status = ?, exit_code = ?, stdout = ?, stderr = ?
                   WHERE id = ?""",
                (finished_at.isoformat(), status, exit_code, stdout[:5000], stderr[:5000], execution_id)
            )
            conn.execute(
                "UPDATE tasks SET last_run_at = ? WHERE id = ?",
                (finished_at.isoformat(), task_id)
            )
            conn.commit()
        
        if status == "success":
            logging.info(f"Task '{task_name}' completed successfully in {duration:.1f}s")
        else:
            logging.error(f"Task '{task_name}' failed with exit code {exit_code}")
            
            # Handle retries
            if retry_attempt < task['retries']:
                retry_delay = task['retry_delay_seconds']
                logging.info(f"Retrying task '{task_name}' in {retry_delay}s (attempt {retry_attempt + 1}/{task['retries']})")
                time.sleep(retry_delay)
                running_tasks.pop(task_id, None)  # Allow retry
                execute_task(task, retry_attempt + 1)
                return  # Don't calculate next run yet if retrying
    
    except subprocess.TimeoutExpired:
        finished_at = datetime.now()
        logging.error(f"Task '{task_name}' timed out after {timeout}s")
        
        with get_connection() as conn:
            conn.execute(
                """UPDATE executions 
                   SET finished_at = ?, status = ?, exit_code = ?, stderr = ?
                   WHERE id = ?""",
                (finished_at.isoformat(), "timeout", -1, f"Task exceeded timeout of {timeout}s", execution_id)
            )
            conn.commit()
    
    except Exception as e:
        finished_at = datetime.now()
        logging.error(f"Error executing task '{task_name}': {e}")
        
        with get_connection() as conn:
            conn.execute(
                """UPDATE executions 
                   SET finished_at = ?, status = ?, exit_code = ?, stderr = ?
                   WHERE id = ?""",
                (finished_at.isoformat(), "error", -1, str(e)[:5000], execution_id)
            )
            conn.commit()
    
    finally:
        # Remove from running tasks
        running_tasks.pop(task_id, None)
        
        # Calculate next run time
        calculate_next_run(task)

def run_daemon(foreground=False):
    """Main daemon loop."""
    
    # Check if daemon is already running
    if is_daemon_running():
        print(f"Daemon is already running (PID file: {PID_FILE})")
        sys.exit(1)
    
    # Setup logging
    setup_logging()
    
    # Daemonize if not in foreground mode
    if not foreground:
        # Fork to background (Unix only)
        if sys.platform != "win32":
            try:
                pid = os.fork()
                if pid > 0:
                    # Parent process exits
                    print(f"Daemon started in background (PID: {pid})")
                    sys.exit(0)
            except OSError as e:
                logging.error(f"Fork failed: {e}")
                sys.exit(1)
    
    # Write PID file
    write_pid_file()
    
    # Setup signal handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    logging.info("Daemon started, checking for tasks every 60 seconds")
    
    # Main loop
    while True:
        try:
            now = datetime.now()
            tasks = get_all_tasks()
            
            for task in tasks:
                if task['enabled'] and should_run(task, now):
                    # Execute in separate thread/process to avoid blocking
                    execute_task(task)
            
            time.sleep(60)  # Check every 60 seconds
            
        except KeyboardInterrupt:
            logging.info("Received keyboard interrupt")
            break
        except Exception as e:
            logging.error(f"Unexpected error in daemon loop: {e}")
            time.sleep(60)  # Continue running despite errors
    
    remove_pid_file()

if __name__ == "__main__":
    run_daemon(foreground=True)