import re
from datetime import datetime, timedelta

def parse_schedule(text: str):
    text = text.lower().strip()
    now = datetime.now()
    
    # Pattern 1: "every [N] minute(s)/hour(s)/day(s)"
    # Matches: "every 5 minutes", "every hour", "every 1 day"
    interval_match = re.match(r"every (\d+)?\s*(minute|hour|day)s?$", text)
    if interval_match:
        quantity = int(interval_match.group(1)) if interval_match.group(1) else 1
        unit = interval_match.group(2)
        
        if unit == "minute":
            return now + timedelta(minutes=quantity)
        if unit == "hour":
            return now + timedelta(hours=quantity)
        if unit == "day":
            return now + timedelta(days=quantity)
    
    # Pattern 2: "every day at HH:MM"
    # Matches: "every day at 14:30", "every day at 09:00"
    time_match = re.match(r"every day at (\d{1,2}):(\d{2})", text)
    if time_match:
        hour = int(time_match.group(1))
        minute = int(time_match.group(2))
        
        target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # If that time has already passed today, set it for tomorrow
        if target_time <= now:
            target_time += timedelta(days=1)
            
        return target_time
    
    # Pattern 3: "every weekday at HH:MM"
    # Matches: "every weekday at 9:00", "every weekday at 14:30"
    weekday_time_match = re.match(r"every weekday at (\d{1,2}):(\d{2})", text)
    if weekday_time_match:
        hour = int(weekday_time_match.group(1))
        minute = int(weekday_time_match.group(2))
        
        target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # Find the next weekday (Monday-Friday are 0-4)
        while True:
            if target_time <= now or target_time.weekday() >= 5:  # 5=Saturday, 6=Sunday
                target_time += timedelta(days=1)
            else:
                break
                
        return target_time
    
    # Pattern 4: "every weekday"
    # Matches: "every weekday"
    if text == "every weekday":
        target_time = now + timedelta(days=1)
        
        # Find the next weekday
        while target_time.weekday() >= 5:  # Skip weekends
            target_time += timedelta(days=1)
            
        return target_time
    
    # Pattern 5: "every [day_name] at HH:MM"
    # Matches: "every monday at 9:00", "every friday at 17:30"
    day_time_match = re.match(
        r"every (monday|tuesday|wednesday|thursday|friday|saturday|sunday) at (\d{1,2}):(\d{2})",
        text
    )
    if day_time_match:
        day_name = day_time_match.group(1)
        hour = int(day_time_match.group(2))
        minute = int(day_time_match.group(3))
        
        # Map day names to weekday numbers (0=Monday, 6=Sunday)
        day_map = {
            'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3,
            'friday': 4, 'saturday': 5, 'sunday': 6
        }
        target_weekday = day_map[day_name]
        
        # Start with today at the target time
        target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # Calculate days until target weekday
        current_weekday = now.weekday()
        days_ahead = target_weekday - current_weekday
        
        # If the day is today but time has passed, or day is in the past, go to next week
        if days_ahead < 0 or (days_ahead == 0 and target_time <= now):
            days_ahead += 7
            
        target_time += timedelta(days=days_ahead)
        return target_time
    
    # Pattern 6: "every [day_name]"
    # Matches: "every monday", "every friday"
    day_match = re.match(
        r"every (monday|tuesday|wednesday|thursday|friday|saturday|sunday)$",
        text
    )
    if day_match:
        day_name = day_match.group(1)
        
        # Map day names to weekday numbers
        day_map = {
            'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3,
            'friday': 4, 'saturday': 5, 'sunday': 6
        }
        target_weekday = day_map[day_name]
        
        # Calculate days until target weekday
        current_weekday = now.weekday()
        days_ahead = target_weekday - current_weekday
        
        # If target day is today or in the past, go to next week
        if days_ahead <= 0:
            days_ahead += 7
            
        target_time = now + timedelta(days=days_ahead)
        return target_time
    
    return None


def is_valid_schedule(text: str) -> bool:
    """Check if a schedule string is valid."""
    return parse_schedule(text) is not None


VALID_EXAMPLES = [
    "every 5 minutes",
    "every hour",
    "every day at 14:30",
    "every monday at 9am",
    "every weekday at 8:00",
    "every friday"
]


if __name__ == "__main__":
    test_cases = [
        "every 5 minutes",
        "every hour",
        "every day",
        "every day at 14:30",
        "every weekday",
        "every weekday at 9:00",
        "every monday",
        "every friday at 17:00",
        "invalid schedule"
    ]
    
    print("Testing schedule parser:\n")
    for test in test_cases:
        result = parse_schedule(test)
        if result:
            print(f"✓ '{test}' -> {result.strftime('%Y-%m-%d %H:%M:%S')}")
        else:
            print(f"✗ '{test}' -> Invalid")
