import sqlite3
from pathlib import Path

DB_DIR = Path.home() / ".tickr"
DB_PATH = DB_DIR / "tickr.db"

def get_connection():
    """Establishes a connection to the SQLite database."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)

def init_db():
    """Creates the tables based on your requirements document."""
    with get_connection() as conn:
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                command TEXT NOT NULL,
                schedule TEXT NOT NULL,
                enabled BOOLEAN DEFAULT 1,
                timeout_seconds INTEGER,
                retries INTEGER DEFAULT 0,
                retry_delay_seconds INTEGER DEFAULT 60,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_run_at TIMESTAMP,
                next_run_at TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                started_at TIMESTAMP NOT NULL,
                finished_at TIMESTAMP,
                status TEXT,
                exit_code INTEGER,
                stdout TEXT,
                stderr TEXT,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            )
        ''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_task_name ON tasks(name)')
        
        conn.commit()
    print("database initialized.")

def add_task(name, command, schedule, timeout=None):
    query = """
    INSERT INTO tasks (name, command, schedule, timeout_seconds)
    VALUES (?, ?, ?, ?)
    """
    try:
        with get_connection() as conn:
            conn.execute(query, (name, command, schedule, timeout))
            conn.commit()
    except sqlite3.IntegrityError:
        print(f"error: Task '{name}' already exists.")

def get_task_by_name(name):
    with get_connection() as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tasks WHERE name = ?", (name,))
        row = cursor.fetchone()
        return dict(row) if row else None

def get_all_tasks():
    with get_connection() as conn:
        # This row_factory makes results look like dicts instead of tuples
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tasks")
        return [dict(row) for row in cursor.fetchall()]

def update_next_run(task_name, next_run_time):
    with get_connection() as conn:
        conn.execute(
            "UPDATE tasks SET next_run_at = ? WHERE name = ?",
            (next_run_time, task_name)
        )
        conn.commit()

if __name__ == "__main__":
    init_db()
    add_task("backup", "echo 'hello'", "every 5 minutes")
    tasks = get_all_tasks()
    print(f"Total tasks in DB: {len(tasks)}")
    for t in tasks:
        print(f"- {t['name']}: {t['command']}")