import click
from datetime import datetime
from .database import init_db, get_all_tasks, get_task_by_name, get_connection
from .parser import parse_schedule, VALID_EXAMPLES
import re
import sqlite3


@click.group()
def cli():
    """tickr - Cron for humans"""
    init_db()


@cli.command()
@click.argument('task_name')
@click.option('--run', required=True, help='Command to execute')
@click.option('--when', required=True, help='Schedule in natural language')
@click.option('--timeout', type=int, default=None, help='Kill task after N seconds')
@click.option('--retries', type=int, default=0, help='Retry N times on failure')
@click.option('--retry-delay', type=int, default=60, help='Seconds between retries')
def add(task_name, run, when, timeout, retries, retry_delay):
    
    if not re.match(r'^[a-zA-Z0-9_-]+$', task_name):
        click.echo("Task name must contain only letters, numbers, hyphens, and underscores.")
        return
    
    existing = get_task_by_name(task_name)
    if existing:
        click.echo(f"Task '{task_name}' already exists. Use 'schedule remove {task_name}' first.")
        return
    
    next_run = parse_schedule(when)
    if not next_run:
        click.echo(f"Invalid schedule: '{when}'")
        click.echo("\nValid examples:")
        for example in VALID_EXAMPLES:
            click.echo(f"  {example}")
        return
    
    # Add to database
    try:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO tasks (name, command, schedule, timeout_seconds, retries, 
                                   retry_delay_seconds, next_run_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (task_name, run, when, timeout, retries, retry_delay, next_run)
            )
            conn.commit()
        
        click.echo(f" Task '{task_name}' scheduled to run {when}")
        click.echo(f" Command: {run}")
        click.echo(f" Next run: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")
        
    except Exception as e:
        click.echo(f" Error adding task: {e}")


@cli.command()
@click.option('--verbose', is_flag=True, help='Show detailed information')
def list(verbose):
    tasks = get_all_tasks()
    
    if not tasks:
        click.echo("No tasks scheduled yet. Use 'schedule add' to create one.")
        return
    
    if verbose:
        for task in tasks:
            status = "enabled" if task['enabled'] else "disabled"
            next_run = task['next_run_at'] if task['next_run_at'] else "Not scheduled"
            last_run = task['last_run_at'] if task['last_run_at'] else "Never run"
            
            click.echo(f"\n{'='*60}")
            click.echo(f"Name:         {task['name']}")
            click.echo(f"Command:      {task['command']}")
            click.echo(f"Schedule:     {task['schedule']}")
            click.echo(f"Status:       {status}")
            click.echo(f"Next run:     {next_run}")
            click.echo(f"Last run:     {last_run}")
            click.echo(f"Created:      {task['created_at']}")
            if task['timeout_seconds']:
                click.echo(f"Timeout:      {task['timeout_seconds']}s")
            if task['retries'] > 0:
                click.echo(f"Retries:      {task['retries']} (delay: {task['retry_delay_seconds']}s)")
    else:
        click.echo(f"\n{'NAME':<15} {'SCHEDULE':<25} {'STATUS':<10} {'NEXT RUN':<20} {'LAST RUN'}")
        click.echo("-" * 95)
        
        for task in tasks:
            name = task['name'][:14]
            schedule = task['schedule'][:24]
            status = "enabled" if task['enabled'] else "disabled"
            
            if task['next_run_at']:
                next_run = datetime.fromisoformat(task['next_run_at']).strftime('%Y-%m-%d %H:%M')
            else:
                next_run = "-"
            
            if task['last_run_at']:
                last_run = datetime.fromisoformat(task['last_run_at']).strftime('%Y-%m-%d %H:%M')
            else:
                last_run = "Never"
            
            click.echo(f"{name:<15} {schedule:<25} {status:<10} {next_run:<20} {last_run}")
        
        click.echo(f"\nTotal tasks: {len(tasks)}")
        click.echo("Use --verbose for detailed information")


@cli.command()
@click.argument('task_name')
def remove(task_name):
    task = get_task_by_name(task_name)
    
    if not task:
        click.echo(f" Task '{task_name}' not found. See 'schedule list'.")
        return
    
    if not click.confirm(f"Remove task '{task_name}'? This will delete all execution history."):
        click.echo("Cancelled.")
        return
    
    with get_connection() as conn:
        conn.execute("DELETE FROM tasks WHERE name = ?", (task_name,))
        conn.commit()
    
    click.echo(f" Task '{task_name}' removed.")


@cli.command()
@click.argument('task_name')
def enable(task_name):
    task = get_task_by_name(task_name)
    
    if not task:
        click.echo(f" Task '{task_name}' not found. See 'schedule list'.")
        return
    
    if task['enabled']:
        click.echo(f"Task '{task_name}' is already enabled.")
        return
    
    with get_connection() as conn:
        conn.execute("UPDATE tasks SET enabled = 1 WHERE name = ?", (task_name,))
        conn.commit()
    
    click.echo(f" Task '{task_name}' enabled.")


@cli.command()
@click.argument('task_name')
def disable(task_name):
    task = get_task_by_name(task_name)
    
    if not task:
        click.echo(f" Task '{task_name}' not found. See 'schedule list'.")
        return
    
    if not task['enabled']:
        click.echo(f"Task '{task_name}' is already disabled.")
        return
    
    with get_connection() as conn:
        conn.execute("UPDATE tasks SET enabled = 0 WHERE name = ?", (task_name,))
        conn.commit()
    
    click.echo(f" Task '{task_name}' disabled.")


@cli.command()
@click.argument('task_name')
def run(task_name):
    """Execute a task immediately (ignores schedule)"""
    task = get_task_by_name(task_name)
    
    if not task:
        click.echo(f" Task '{task_name}' not found. See 'schedule list'.")
        return
    
    click.echo(f"Running task '{task_name}'...")
    click.echo(f"Command: {task['command']}")
    click.echo()
    
    from daemon import execute_task
    
    try:
        execute_task(task)
        click.echo(f"\n Task '{task_name}' execution completed")
        click.echo(f"  Check 'schedule logs {task_name}' for details")
    except Exception as e:
        click.echo(f"\n Error executing task: {e}")



@cli.command()
@click.argument('task_name')
@click.option('--limit', type=int, default=10, help='Number of recent runs to show')
@click.option('--failed-only', is_flag=True, help='Only show failed executions')
def logs(task_name, limit, failed_only):
    task = get_task_by_name(task_name)
    
    if not task:
        click.echo(f" Task '{task_name}' not found. See 'schedule list'.")
        return
    
    with get_connection() as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        query = """
            SELECT * FROM executions 
            WHERE task_id = ?
        """
        params = [task['id']]
        
        if failed_only:
            query += " AND status != 'success'"
        
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        
        cursor.execute(query, params)
        executions = [dict(row) for row in cursor.fetchall()]
    
    if not executions:
        click.echo(f"No execution history for '{task_name}'.")
        return
    
    click.echo(f"\nShowing last {len(executions)} run(s) for '{task_name}':\n")
    
    for exe in executions:
        started = datetime.fromisoformat(exe['started_at']).strftime('%Y-%m-%d %H:%M:%S')
        
        if exe['finished_at']:
            finished = datetime.fromisoformat(exe['finished_at'])
            started_dt = datetime.fromisoformat(exe['started_at'])
            duration = (finished - started_dt).total_seconds()
            duration_str = f"({duration:.1f}s)"
        else:
            duration_str = "(running)"
        
        status = exe['status'].upper() if exe['status'] else "UNKNOWN"
        exit_code = exe['exit_code'] if exe['exit_code'] is not None else "N/A"
        
        if status == "SUCCESS":
            status_display = click.style(status, fg='green')
        elif status == "FAILED":
            status_display = click.style(status, fg='red')
        else:
            status_display = click.style(status, fg='yellow')
        
        click.echo(f"{started}  {status_display}  {duration_str}  exit code: {exit_code}")
        
        if exe['stdout'] and exe['stdout'].strip():
            click.echo(f"  └─ {exe['stdout'][:100]}")
        if exe['stderr'] and exe['stderr'].strip():
            click.echo(click.style(f"  └─ ERROR: {exe['stderr'][:100]}", fg='red'))
        
        click.echo()


@cli.command()
@click.option('--foreground', is_flag=True, help='Run in foreground (don\'t daemonize)')
def daemon(foreground):
    """Start the scheduler daemon"""
    from daemon import run_daemon, is_daemon_running, PID_FILE
    
    if is_daemon_running():
        click.echo(f" Daemon is already running (PID file: {PID_FILE})")
        return
    
    if foreground:
        click.echo("Starting daemon in foreground mode (Ctrl+C to stop)...")
        run_daemon(foreground=True)
    else:
        run_daemon(foreground=False)


@cli.command()
def status():
    """Show daemon status"""
    from daemon import is_daemon_running, PID_FILE, LOG_FILE
    from datetime import datetime
    
    if is_daemon_running():
        try:
            with open(PID_FILE, 'r') as f:
                pid = int(f.read().strip())
            
            # Calculate uptime (rough estimate from PID file modification time)
            if PID_FILE.exists():
                pid_mtime = datetime.fromtimestamp(PID_FILE.stat().st_mtime)
                uptime = datetime.now() - pid_mtime
                hours = int(uptime.total_seconds() // 3600)
                minutes = int((uptime.total_seconds() % 3600) // 60)
                uptime_str = f"{hours}h {minutes}m"
            else:
                uptime_str = "unknown"
            
            click.echo(click.style(" Daemon Status: RUNNING", fg='green'))
            click.echo(f"  PID: {pid}")
            click.echo(f"  Uptime: {uptime_str}")
            click.echo(f"  Log file: {LOG_FILE}")
            
            tasks = get_all_tasks()
            enabled_tasks = [t for t in tasks if t['enabled'] and t['next_run_at']]
            
            if enabled_tasks:
                next_task = min(enabled_tasks, key=lambda t: t['next_run_at'])
                next_run = datetime.fromisoformat(next_task['next_run_at'])
                click.echo(f"  Next task: '{next_task['name']}' at {next_run.strftime('%Y-%m-%d %H:%M:%S')}")
            else:
                click.echo(f"  Next task: None")
        except Exception as e:
            click.echo(click.style(f"⚠ Daemon appears to be running but status check failed: {e}", fg='yellow'))
    else:
        click.echo(click.style(" Daemon Status: STOPPED", fg='red'))
        click.echo("  Use 'schedule daemon' to start it")


if __name__ == '__main__':
    cli()