from __future__ import annotations

from pathlib import Path
import importlib
import sys
import traceback


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


MODEL_MODULES = [
    "alpine1",
    "alpine2",
    "australia",
    "collie1",
    "collie2",
    "collie3",
    "flexb",
    "flexi",
    "flexis",
    "gr4j",
    "gsfb",
    "hbv",
    "hillslope",
    "hymod",
    "ihacres",
    "modhydrolog",
    "mopex1",
    "mopex2",
    "mopex3",
    "mopex4",
    "mopex5",
    "newzealand1",
    "newzealand2",
    "penman",
    "plateau",
    "simhyd",
    "smar",
    "susannah1",
    "susannah2",
    "tank",
    "tcm",
    "topmodel",
    "us1",
    "vic",
    "wetland",
    "xinanjiang",
]

PACKAGE_MODULES = [
    "pyrrmod",
    "pyrrmod.models",
    "pyrrmod.catalog",
    "pyrrmod.core",
    "pyrrmod.schemas",
    "pyrrmod.solvers",
    "pyrrmod.unithydro",
]


def _collect_import_failures() -> list[tuple[str, str]]:
    failures: list[tuple[str, str]] = []
    for module_name in PACKAGE_MODULES + [
        f"pyrrmod.models.{name}" for name in MODEL_MODULES
    ]:
        try:
            importlib.import_module(module_name)
        except Exception:
            failures.append((module_name, traceback.format_exc()))
    return failures


def _collect_registry_failures() -> list[tuple[str, str]]:
    failures: list[tuple[str, str]] = []
    from pyrrmod.catalog import (
        MODEL_METADATA,
        MODEL_REGISTRY,
        create_model,
    )

    missing_metadata = sorted(set(MODEL_REGISTRY) - set(MODEL_METADATA))
    if missing_metadata:
        failures.append(
            (
                "MODEL_METADATA",
                f"missing metadata for models: {', '.join(missing_metadata)}",
            )
        )

    for name, model_cls in MODEL_REGISTRY.items():
        try:
            instance = create_model(name)
            if not isinstance(instance, model_cls):
                failures.append(
                    (
                        f"create_model({name!r})",
                        f"returned {type(instance).__name__}, expected {model_cls.__name__}",
                    )
                )
        except Exception:
            failures.append((f"create_model({name!r})", traceback.format_exc()))

    for resolved_name in MODEL_REGISTRY:
        metadata = MODEL_METADATA.get(resolved_name, {})
        legacy_name = metadata.get("legacy_name")
        if not isinstance(legacy_name, str):
            continue
        try:
            instance = create_model(legacy_name)
            expected_cls = MODEL_REGISTRY[resolved_name]
            if not isinstance(instance, expected_cls):
                failures.append(
                    (
                        f"create_model({legacy_name!r})",
                        f"returned {type(instance).__name__}, expected {expected_cls.__name__}",
                    )
                )
        except Exception:
            failures.append((f"create_model({legacy_name!r})", traceback.format_exc()))

    return failures


def main() -> int:
    failures = _collect_import_failures() + _collect_registry_failures()
    if failures:
        print("IMPORT SMOKE FAILURES")
        print("====================")
        for subject, details in failures:
            print(f"\n[{subject}]")
            print(details.rstrip())
        return 1

    print("Import smoke passed.")
    print(f"Checked modules: {len(PACKAGE_MODULES) + len(MODEL_MODULES)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
