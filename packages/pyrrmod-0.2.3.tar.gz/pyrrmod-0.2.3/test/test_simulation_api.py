from __future__ import annotations

from pathlib import Path
import sys

import numpy as np
import pytest
from pydantic import ValidationError

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import collie1
from pyrrmod.schemas import ClimateInput, ModelRunInput


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def load_forcing(n_steps: int = 180) -> dict[str, np.ndarray]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=n_steps)
    return {
        "precip": data[:, 0],
        "temp": data[:, 1],
        "pet": data[:, 2],
        "flow": data[:, 3],
    }


def build_run_payload(
    n_steps: int = 180,
) -> tuple[dict[str, object], dict[str, np.ndarray]]:
    forcing = load_forcing(n_steps)
    payload = {
        "theta": [500.0],
        "delta_t": 1.0,
        "initial_stores": [100.0],
        "climate": {
            "rainfall": forcing["precip"],
            "PET": forcing["pet"],
            "temperature": forcing["temp"],
        },
        "solver_options": {
            "resnorm_tolerance": 0.1,
            "resnorm_maxiter": 6,
        },
    }
    return payload, forcing


def test_model_run_input_accepts_alias_payload_from_csv() -> None:
    payload, forcing = build_run_payload()
    model = collie1()

    run_input = model.validate_run_payload(payload)

    assert isinstance(run_input.input_climate, ClimateInput)
    assert run_input.theta.shape == (1,)
    assert run_input.S0.shape == (1,)
    assert run_input.input_climate.precip.shape[0] == forcing["precip"].shape[0]
    assert run_input.solver_opts is not None


def test_model_run_input_rejects_mismatched_climate_lengths() -> None:
    payload, forcing = build_run_payload()
    payload["climate"] = {
        "rainfall": forcing["precip"],
        "PET": forcing["pet"][:-1],
        "temperature": forcing["temp"],
    }

    with pytest.raises(ValidationError):
        ModelRunInput.model_validate(payload)


def test_collie1_run_from_payload_returns_json_safe_output() -> None:
    payload, forcing = build_run_payload()
    model = collie1()

    result = model.run_from_payload(payload)

    assert result["model"] == "collie1"
    assert result["status"] == 1
    assert isinstance(result["streamflow"], list)
    assert len(result["streamflow"]) == forcing["precip"].shape[0]
    assert "flux_groups" in result
    assert abs(float(result["water_balance_error"])) < 1e-6
    assert "flux_internal" not in result
    assert "store_internal" not in result
    assert "solver_data" not in result
    assert "execution" not in result

    runtime = model.runtime_context
    assert runtime is not None
    assert isinstance(runtime.theta, np.ndarray)
    assert isinstance(runtime.S0, np.ndarray)
    assert isinstance(runtime.precip, np.ndarray)
    assert not isinstance(runtime.climate, ClimateInput)


def test_mcp_payload_can_include_execution_and_solver_metadata() -> None:
    payload, forcing = build_run_payload()
    model = collie1()

    result = model.run_from_payload(
        payload,
        include_solver=True,
        include_execution=True,
    )

    assert len(result["solver_data"]["resnorm"]) == forcing["precip"].shape[0]
    assert set(result["execution"]) == {
        "requested_target",
        "resolved_target",
        "compiler_detail",
    }


def test_format_mcp_error_returns_structured_payload_error() -> None:
    model = collie1()

    try:
        model.validate_run_payload(
            {
                "theta": [500.0],
                "delta_t": 1.0,
                "initial_stores": [100.0],
                "climate": {
                    "rainfall": [1.0, 2.0],
                    "PET": [0.5],
                    "temperature": [10.0, 11.0],
                },
            }
        )
    except Exception as exc:  # pragma: no branch - exercised by validation path
        error_payload = model._format_mcp_error(exc)
    else:  # pragma: no cover - defensive guard
        raise AssertionError("expected validation failure")

    assert error_payload["ok"] is False
    assert error_payload["error"]["category"] == "payload_error"
    assert error_payload["error"]["type"] == "ValidationError"
    assert "details" in error_payload["error"]


def test_collie1_get_output_and_streamflow_use_csv_forcing() -> None:
    payload, forcing = build_run_payload()
    model = collie1()
    model.run(config=ModelRunInput.model_validate(payload))

    flux_output, flux_internal, store_internal = model.get_output(3)
    streamflow = model.get_streamflow()

    assert set(flux_output) == {"Ea", "Q"}
    assert set(flux_internal) == {"ea", "qse"}
    assert set(store_internal) == {"S1"}
    assert streamflow.shape == (forcing["precip"].shape[0],)
    assert np.all(np.isfinite(streamflow))
    assert abs(model.check_water_balance()) < 1e-6


def test_numba_and_python_targets_match_on_csv() -> None:
    pytest.importorskip("numba")
    payload, _ = build_run_payload(120)

    python_model = collie1()
    python_payload = dict(payload)
    python_payload["compile_target"] = "python"
    python_model.run(config=python_payload)

    numba_model = collie1()
    numba_payload = dict(payload)
    numba_payload["compile_target"] = "numba"
    numba_model.run(config=numba_payload)

    assert numba_model.compiler.target in {"numba", "python"}
    if numba_model.compiler.target == "python":
        assert "compiled model unavailable" in numba_model.compiler.detail

    np.testing.assert_allclose(
        python_model.get_streamflow(),
        numba_model.get_streamflow(),
        rtol=1e-10,
        atol=1e-10,
    )
