from __future__ import annotations

import argparse
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.catalog import MODEL_REGISTRY, create_model
from pyrrmod.core import StepKernelModel


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


@dataclass(slots=True)
class BenchResult:
    name: str
    py_median_s: float
    nb_median_s: float
    speedup_py_over_nb: float
    max_abs_drift: float
    max_rel_drift: float
    nb_target: str
    nb_detail: str
    py_water_balance: float
    nb_water_balance: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Benchmark Python vs Numba for migrated non-UH StepKernelModel models."
        )
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=365,
        help="Number of forcing rows to read from the dataset.",
    )
    parser.add_argument(
        "--repeat-forcing",
        type=int,
        default=4,
        help="Repeat forcing block to amplify timing differences.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Timed warm runs per backend (median is reported).",
    )
    parser.add_argument(
        "--solver",
        type=str,
        default="fsolve",
        choices=["fsolve", "numba_newton"],
        help="Solver backend used for timing and drift checks.",
    )
    return parser.parse_args()


def load_forcing(steps: int, repeat_forcing: int) -> dict[str, np.ndarray]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=steps)
    data = np.atleast_2d(data)
    if repeat_forcing > 1:
        data = np.tile(data, (repeat_forcing, 1))
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def theta_from_par_ranges(model) -> np.ndarray:
    n_params = int(model.num_params or 0)
    if n_params <= 0:
        return np.zeros(0, dtype=np.float64)

    ranges = model.par_ranges
    if ranges is None:
        return np.ones(n_params, dtype=np.float64)

    arr = np.asarray(ranges, dtype=np.float64)
    if arr.ndim != 2 or arr.shape != (n_params, 2):
        return np.ones(n_params, dtype=np.float64)

    low = arr[:, 0]
    high = arr[:, 1]
    theta = np.ones(n_params, dtype=np.float64)

    finite = np.isfinite(low) & np.isfinite(high)
    theta[finite] = low[finite] + 0.30 * (high[finite] - low[finite])

    only_low_finite = np.isfinite(low) & ~np.isfinite(high)
    theta[only_low_finite] = low[only_low_finite] + np.maximum(
        1.0, np.abs(low[only_low_finite]) * 0.10
    )

    only_high_finite = ~np.isfinite(low) & np.isfinite(high)
    theta[only_high_finite] = high[only_high_finite] - np.maximum(
        1.0, np.abs(high[only_high_finite]) * 0.10
    )

    both_inf = ~np.isfinite(low) & ~np.isfinite(high)
    theta[both_inf] = 1.0
    return theta


def initial_stores(model) -> np.ndarray:
    n_stores = int(model.num_stores or 0)
    if n_stores <= 0:
        return np.zeros(0, dtype=np.float64)
    return np.full(n_stores, 50.0, dtype=np.float64)


def run_hot(
    model_name: str,
    forcing: dict[str, np.ndarray],
    *,
    compile_target: str,
    solver: str,
    repeats: int,
):
    model = create_model(model_name)
    config = {
        "theta": theta_from_par_ranges(model),
        "delta_t": 1.0,
        "initial_stores": initial_stores(model),
        "climate": forcing,
        "compile_target": compile_target,
    }

    model.configure(config=config)

    model.run(solver=solver)

    timings: list[float] = []
    for _ in range(repeats):
        start = time.perf_counter()
        model.run(solver=solver)
        timings.append(time.perf_counter() - start)

    streamflow = np.asarray(model.get_streamflow(), dtype=np.float64).copy()
    return {
        "median": float(statistics.median(timings)),
        "streamflow": streamflow,
        "water_balance": float(model.check_water_balance()),
        "target": str(model.compiler.target),
        "detail": str(model.compiler.detail),
    }


def max_abs_diff(lhs: np.ndarray, rhs: np.ndarray) -> float:
    return float(np.max(np.abs(np.asarray(lhs) - np.asarray(rhs))))


def non_uh_migrated_models() -> list[str]:
    names: list[str] = []
    for name in sorted(MODEL_REGISTRY):
        model = create_model(name)
        if isinstance(model, StepKernelModel):
            names.append(name)
    return names


def main() -> None:
    args = parse_args()
    forcing = load_forcing(args.steps, args.repeat_forcing)
    names = non_uh_migrated_models()

    print(f"dataset: {DATA_FILE}")
    print(f"time steps used: {forcing['precip'].shape[0]}")
    print(f"solver: {args.solver}")
    print(f"timed repeats: {args.repeats}")
    print(f"migrated non-UH models: {len(names)}")
    print()

    rows: list[BenchResult] = []
    failures: list[tuple[str, str]] = []

    for name in names:
        try:
            py = run_hot(
                name,
                forcing,
                compile_target="python",
                solver=args.solver,
                repeats=args.repeats,
            )
            nb = run_hot(
                name,
                forcing,
                compile_target="numba",
                solver=args.solver,
                repeats=args.repeats,
            )

            max_abs = max_abs_diff(py["streamflow"], nb["streamflow"])
            denom = float(max(1e-12, np.max(np.abs(py["streamflow"]))))
            max_rel = max_abs / denom

            py_median = float(py["median"])
            nb_median = float(nb["median"])
            speedup = py_median / nb_median if nb_median > 0.0 else float("nan")

            rows.append(
                BenchResult(
                    name=name,
                    py_median_s=py_median,
                    nb_median_s=nb_median,
                    speedup_py_over_nb=speedup,
                    max_abs_drift=max_abs,
                    max_rel_drift=max_rel,
                    nb_target=str(nb["target"]),
                    nb_detail=str(nb["detail"]),
                    py_water_balance=float(py["water_balance"]),
                    nb_water_balance=float(nb["water_balance"]),
                )
            )
        except Exception as exc:
            failures.append((name, f"{exc.__class__.__name__}: {exc}"))

    rows.sort(key=lambda item: item.name)

    print(
        "name\tspeedup(py/nb)\tmax_abs_drift\tmax_rel_drift\t"
        "py_median_s\tnb_median_s\tnb_target"
    )
    for row in rows:
        print(
            f"{row.name}\t{row.speedup_py_over_nb:.3f}\t{row.max_abs_drift:.3e}\t"
            f"{row.max_rel_drift:.3e}\t{row.py_median_s:.6f}\t"
            f"{row.nb_median_s:.6f}\t{row.nb_target}"
        )

    print()
    print(f"success: {len(rows)}")
    print(f"failures: {len(failures)}")
    print(f"numba-compiled: {sum(1 for row in rows if row.nb_target == 'numba')}")
    if rows:
        speeds = np.asarray(
            [
                row.speedup_py_over_nb
                for row in rows
                if np.isfinite(row.speedup_py_over_nb)
            ],
            dtype=np.float64,
        )
        drifts = np.asarray([row.max_abs_drift for row in rows], dtype=np.float64)
        rel_drifts = np.asarray([row.max_rel_drift for row in rows], dtype=np.float64)
        print(f"median speedup (py/nb): {float(np.median(speeds)):.3f}x")
        print(f"mean speedup (py/nb): {float(np.mean(speeds)):.3f}x")
        print(f"max abs drift: {float(np.max(drifts)):.3e}")
        print(f"median abs drift: {float(np.median(drifts)):.3e}")
        print(f"max rel drift: {float(np.max(rel_drifts)):.3e}")

    if failures:
        print()
        print("failures detail:")
        for name, message in failures:
            print(f"{name}\t{message}")


if __name__ == "__main__":
    main()
