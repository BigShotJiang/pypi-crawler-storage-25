from __future__ import annotations

import argparse
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import alpine1, gr4j


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"
ALPINE1_THETA = [0.0, 3.0, 500.0, 0.05]
ALPINE1_S0 = [50.0, 120.0]
GR4J_THETA = [500.0, 0.0, 100.0, 2.5]
GR4J_S0 = [250.0, 50.0]


@dataclass(slots=True)
class RunResult:
    elapsed_s: float
    streamflow: np.ndarray
    water_balance: float
    compiler_target: str
    compiler_detail: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Validate Python vs Numba outputs for alpine1 and gr4j using the "
            "current package architecture."
        )
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=365,
        help="Number of source forcing rows to read. 0 means full dataset.",
    )
    parser.add_argument(
        "--repeat-forcing",
        type=int,
        default=2,
        help="Repeat the forcing block to amplify timing differences.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Timed warm runs per scenario (median is reported).",
    )
    return parser.parse_args()


def load_forcing(steps: int, repeat_forcing: int) -> dict[str, np.ndarray]:
    kwargs: dict[str, object] = {"delimiter": ",", "skiprows": 1}
    if steps > 0:
        kwargs["max_rows"] = int(steps)
    data = np.loadtxt(DATA_FILE, **kwargs)
    data = np.atleast_2d(data)
    if repeat_forcing > 1:
        data = np.tile(data, (int(repeat_forcing), 1))
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def run_timed(
    model_cls,
    *,
    theta: list[float],
    s0: list[float],
    forcing: dict[str, np.ndarray],
    compile_target: str,
    solver: str,
    repeats: int,
) -> RunResult:
    timings: list[float] = []
    latest = None
    for _ in range(max(1, int(repeats))):
        model = model_cls()
        config = {
            "theta": theta,
            "delta_t": 1.0,
            "initial_stores": s0,
            "climate": forcing,
            "compile_target": compile_target,
        }
        start = time.perf_counter()
        model.run(config=config, solver=solver)
        timings.append(time.perf_counter() - start)
        latest = model

    if latest is None:
        raise RuntimeError("timed run did not produce a model")

    return RunResult(
        elapsed_s=float(statistics.median(timings)),
        streamflow=np.asarray(latest.get_streamflow(), dtype=np.float64).copy(),
        water_balance=float(latest.check_water_balance()),
        compiler_target=str(latest.compiler.target),
        compiler_detail=str(latest.compiler.detail),
    )


def max_abs_diff(lhs: np.ndarray, rhs: np.ndarray) -> float:
    return float(np.max(np.abs(np.asarray(lhs) - np.asarray(rhs))))


def print_run(label: str, result: RunResult) -> None:
    print(f"{label}: {result.elapsed_s:.6f} s")
    print(f"  compiler target: {result.compiler_target}")
    print(f"  compiler detail: {result.compiler_detail}")
    print(f"  water balance: {result.water_balance:.3e}")


def main() -> None:
    args = parse_args()
    forcing = load_forcing(args.steps, args.repeat_forcing)

    print(f"dataset: {DATA_FILE}")
    print(f"time steps used: {forcing['precip'].shape[0]}")
    print(f"timed repeats: {args.repeats}")
    print()

    alpine_py = run_timed(
        alpine1,
        theta=ALPINE1_THETA,
        s0=ALPINE1_S0,
        forcing=forcing,
        compile_target="python",
        solver="fsolve",
        repeats=args.repeats,
    )
    alpine_nb = run_timed(
        alpine1,
        theta=ALPINE1_THETA,
        s0=ALPINE1_S0,
        forcing=forcing,
        compile_target="numba",
        solver="numba_newton",
        repeats=args.repeats,
    )

    gr4j_py = run_timed(
        gr4j,
        theta=GR4J_THETA,
        s0=GR4J_S0,
        forcing=forcing,
        compile_target="python",
        solver="fsolve",
        repeats=args.repeats,
    )
    gr4j_nb = run_timed(
        gr4j,
        theta=GR4J_THETA,
        s0=GR4J_S0,
        forcing=forcing,
        compile_target="numba",
        solver="numba_newton",
        repeats=args.repeats,
    )

    alpine_diff = max_abs_diff(alpine_py.streamflow, alpine_nb.streamflow)
    gr4j_diff = max_abs_diff(gr4j_py.streamflow, gr4j_nb.streamflow)

    np.testing.assert_allclose(
        alpine_py.streamflow, alpine_nb.streamflow, atol=1e-5, rtol=0.0
    )
    np.testing.assert_allclose(
        gr4j_py.streamflow, gr4j_nb.streamflow, atol=1e-7, rtol=0.0
    )

    print("Validation")
    print(
        f"  alpine1 python(fsolve) vs numba(numba_newton) max diff: {alpine_diff:.3e}"
    )
    print(f"  gr4j python(fsolve) vs numba(numba_newton) max diff: {gr4j_diff:.3e}")
    print()

    print("Performance")
    print_run("  alpine1 python/fsolve", alpine_py)
    print_run("  alpine1 numba/numba_newton", alpine_nb)
    print_run("  gr4j python/fsolve", gr4j_py)
    print_run("  gr4j numba/numba_newton", gr4j_nb)
    print()

    print("Speedup")
    print(
        "  alpine1 python/fsolve over numba/numba_newton: "
        f"{alpine_py.elapsed_s / alpine_nb.elapsed_s:.2f}x"
    )
    print(
        "  gr4j python/fsolve over numba/numba_newton: "
        f"{gr4j_py.elapsed_s / gr4j_nb.elapsed_s:.2f}x"
    )


if __name__ == "__main__":
    main()
