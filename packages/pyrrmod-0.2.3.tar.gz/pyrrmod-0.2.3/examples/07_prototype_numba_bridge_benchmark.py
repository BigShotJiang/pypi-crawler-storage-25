from __future__ import annotations

import time
from pathlib import Path

import numpy as np
from numba import njit, typeof

from pyrrmod.models import alpine1


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def load_forcing(n_steps: int = 365) -> np.ndarray:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=n_steps)
    data = np.atleast_2d(data)
    forcing = np.column_stack((data[:, 0], data[:, 1], data[:, 2]))
    return np.ascontiguousarray(forcing, dtype=np.float64)


@njit(cache=True)
def _clip_state_inplace(
    states: np.ndarray, lower: np.ndarray, upper: np.ndarray
) -> None:
    for index in range(states.shape[0]):
        value = states[index]
        if value < lower[index]:
            value = lower[index]
        elif value > upper[index]:
            value = upper[index]
        states[index] = value


@njit(cache=True)
def _alpine1_dS_out(
    states: np.ndarray,
    forcing_row: np.ndarray,
    params: np.ndarray,
    delta_t: float,
    out_dS: np.ndarray,
) -> None:
    tt = params[0]
    ddf = params[1]
    smax = params[2]
    tc = params[3]

    s1 = states[0]
    s2 = states[1]

    precip_t = forcing_row[0]
    temp_t = forcing_row[1]
    pet_t = forcing_row[2]

    temp_exponent = (temp_t - tt) / 0.01
    if temp_exponent >= 700.0:
        snow_fraction = 0.0
    else:
        snow_fraction = 1.0 / (1.0 + np.exp(temp_exponent))

    flux_ps = precip_t * snow_fraction
    flux_pr = precip_t * (1.0 - snow_fraction)

    flux_qn = ddf * (temp_t - tt)
    if flux_qn < 0.0:
        flux_qn = 0.0
    qn_limit = s1 / delta_t
    if flux_qn > qn_limit:
        flux_qn = qn_limit

    s2_over_dt = s2 / delta_t
    if s2_over_dt < pet_t:
        flux_ea = s2_over_dt
    else:
        flux_ea = pet_t

    storage_max = smax if smax > 0.0 else 0.0
    if 0.01 * storage_max == 0.0:
        storage_exponent = (s2 - storage_max + 0.01 * 5.0 * storage_max) / 0.01
    else:
        storage_exponent = (s2 - storage_max + 0.01 * 5.0 * storage_max) / (
            0.01 * storage_max
        )

    if storage_exponent >= 700.0:
        storage_logistic = 0.0
    else:
        storage_logistic = 1.0 / (1.0 + np.exp(storage_exponent))

    flux_qse = (precip_t + flux_qn) * (1.0 - storage_logistic)
    flux_qss = tc * s2

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_ea - flux_qse - flux_qss


@njit(cache=True)
def _fill_residual(
    dS_fn,
    states: np.ndarray,
    previous_states: np.ndarray,
    forcing_row: np.ndarray,
    params: np.ndarray,
    delta_t: float,
    residual: np.ndarray,
    out_dS: np.ndarray,
) -> None:
    dS_fn(states, forcing_row, params, delta_t, out_dS)
    for index in range(states.shape[0]):
        residual[index] = (states[index] - previous_states[index]) / delta_t - out_dS[
            index
        ]


@njit(cache=True)
def _newton_step_inplace(
    dS_fn,
    previous_states: np.ndarray,
    forcing_row: np.ndarray,
    params: np.ndarray,
    delta_t: float,
    lower: np.ndarray,
    upper: np.ndarray,
    tolerance: float,
    max_iter: int,
    diff_step: float,
    next_states: np.ndarray,
    out_dS: np.ndarray,
    residual: np.ndarray,
    trial_residual: np.ndarray,
    jacobian: np.ndarray,
    right_hand_side: np.ndarray,
    delta: np.ndarray,
    trial_states: np.ndarray,
) -> None:
    n_states = previous_states.shape[0]

    for index in range(n_states):
        next_states[index] = previous_states[index]

    max_delta = 0.0
    for _ in range(max_iter):
        _fill_residual(
            dS_fn,
            next_states,
            previous_states,
            forcing_row,
            params,
            delta_t,
            residual,
            out_dS,
        )

        for col in range(n_states):
            for row in range(n_states):
                trial_states[row] = next_states[row]

            step = diff_step * max(abs(next_states[col]), 1.0)
            trial_states[col] = trial_states[col] + step
            _clip_state_inplace(trial_states, lower, upper)

            effective_step = trial_states[col] - next_states[col]
            if effective_step == 0.0:
                effective_step = step

            _fill_residual(
                dS_fn,
                trial_states,
                previous_states,
                forcing_row,
                params,
                delta_t,
                trial_residual,
                out_dS,
            )

            for row in range(n_states):
                jacobian[row, col] = (
                    trial_residual[row] - residual[row]
                ) / effective_step

        for row in range(n_states):
            right_hand_side[row] = -residual[row]
            jacobian[row, row] = jacobian[row, row] + 1e-12

        delta[:] = np.linalg.solve(jacobian, right_hand_side)

        max_delta = 0.0
        for row in range(n_states):
            next_states[row] = next_states[row] + delta[row]
            abs_delta = abs(delta[row])
            if abs_delta > max_delta:
                max_delta = abs_delta

        _clip_state_inplace(next_states, lower, upper)
        if max_delta < tolerance:
            break


def run_newton_python_bridge(
    dS_fn,
    forcing: np.ndarray,
    params: np.ndarray,
    s0: np.ndarray,
    delta_t: float,
    lower: np.ndarray,
    upper: np.ndarray,
    tolerance: float,
    max_iter: int,
    diff_step: float,
) -> np.ndarray:
    n_steps = forcing.shape[0]
    n_states = s0.shape[0]
    states = np.empty((n_steps + 1, n_states), dtype=np.float64)
    states[0, :] = s0

    out_dS = np.empty(n_states, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    delta = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        _newton_step_inplace(
            dS_fn,
            states[time_index, :],
            forcing[time_index, :],
            params,
            delta_t,
            lower,
            upper,
            tolerance,
            max_iter,
            diff_step,
            states[time_index + 1, :],
            out_dS,
            residual,
            trial_residual,
            jacobian,
            right_hand_side,
            delta,
            trial_states,
        )
    return states


@njit(cache=True)
def run_newton_numba_full(
    dS_fn,
    forcing: np.ndarray,
    params: np.ndarray,
    s0: np.ndarray,
    delta_t: float,
    lower: np.ndarray,
    upper: np.ndarray,
    tolerance: float,
    max_iter: int,
    diff_step: float,
) -> np.ndarray:
    n_steps = forcing.shape[0]
    n_states = s0.shape[0]
    states = np.empty((n_steps + 1, n_states), dtype=np.float64)
    states[0, :] = s0

    out_dS = np.empty(n_states, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    delta = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        _newton_step_inplace(
            dS_fn,
            states[time_index, :],
            forcing[time_index, :],
            params,
            delta_t,
            lower,
            upper,
            tolerance,
            max_iter,
            diff_step,
            states[time_index + 1, :],
            out_dS,
            residual,
            trial_residual,
            jacobian,
            right_hand_side,
            delta,
            trial_states,
        )
    return states


def benchmark(label: str, fn, repeat: int) -> tuple[float, np.ndarray]:
    result = fn()
    start = time.perf_counter()
    for _ in range(repeat):
        result = fn()
    elapsed = (time.perf_counter() - start) / float(repeat)
    print(f"- {label:<28} {elapsed:.6f} s")
    return elapsed, result


def main() -> None:
    base_forcing = load_forcing(365)
    forcing = np.ascontiguousarray(np.tile(base_forcing, (20, 1)), dtype=np.float64)

    params = np.asarray([0.0, 3.0, 500.0, 0.05], dtype=np.float64)
    s0 = np.asarray([50.0, 120.0], dtype=np.float64)
    lower = np.asarray([0.0, 0.0], dtype=np.float64)
    upper = np.asarray([np.inf, np.inf], dtype=np.float64)
    delta_t = 1.0
    tolerance = 1e-8
    max_iter = 20
    diff_step = 1e-7

    print("numba function type:")
    print(f"- typeof(_alpine1_dS_out): {typeof(_alpine1_dS_out)}")
    print()

    # Warm up JIT.
    _ = run_newton_numba_full(
        _alpine1_dS_out,
        forcing[:8],
        params,
        s0,
        delta_t,
        lower,
        upper,
        tolerance,
        max_iter,
        diff_step,
    )
    _ = run_newton_python_bridge(
        _alpine1_dS_out,
        forcing[:8],
        params,
        s0,
        delta_t,
        lower,
        upper,
        tolerance,
        max_iter,
        diff_step,
    )

    print(f"benchmark steps: {forcing.shape[0]}")
    print("newton timing (same equations, same tolerances):")
    t_newton_bridge, states_newton_bridge = benchmark(
        "python loop -> njit step",
        lambda: run_newton_python_bridge(
            _alpine1_dS_out,
            forcing,
            params,
            s0,
            delta_t,
            lower,
            upper,
            tolerance,
            max_iter,
            diff_step,
        ),
        repeat=3,
    )
    t_newton_full, states_newton_full = benchmark(
        "full numba time loop",
        lambda: run_newton_numba_full(
            _alpine1_dS_out,
            forcing,
            params,
            s0,
            delta_t,
            lower,
            upper,
            tolerance,
            max_iter,
            diff_step,
        ),
        repeat=3,
    )

    newton_max_diff = float(np.max(np.abs(states_newton_bridge - states_newton_full)))

    print()
    print("bias check (bridge vs full-numba):")
    print(f"- newton max |delta|: {newton_max_diff:.6e}")
    print()
    print("speedup from removing per-step Python dispatch:")
    if t_newton_full > 0.0:
        print(f"- newton speedup: {t_newton_bridge / t_newton_full:.2f}x")

    short_forcing = base_forcing
    short_states_newton = run_newton_numba_full(
        _alpine1_dS_out,
        short_forcing,
        params,
        s0,
        delta_t,
        lower,
        upper,
        tolerance,
        max_iter,
        diff_step,
    )

    model = alpine1()
    model.run(
        config={
            "theta": params.tolist(),
            "delta_t": delta_t,
            "initial_stores": s0.tolist(),
            "climate": {
                "precip": short_forcing[:, 0],
                "temp": short_forcing[:, 1],
                "pet": short_forcing[:, 2],
            },
            "compile_target": "numba",
        },
        solver="fsolve",
    )
    fsolve_states = np.vstack((s0.reshape(1, -1), model.stores))
    fsolve_vs_newton = float(np.max(np.abs(fsolve_states - short_states_newton)))
    print()
    print("consistency against current fsolve path (365 steps):")
    print(f"- max |fsolve - prototype_newton|: {fsolve_vs_newton:.6e}")

    current_newton_states = run_newton_numba_full(
        _alpine1_dS_out,
        short_forcing,
        params,
        s0,
        delta_t,
        lower,
        upper,
        tolerance,
        max_iter,
        diff_step,
    )
    model_newton = alpine1()
    model_newton.run(
        config={
            "theta": params.tolist(),
            "delta_t": delta_t,
            "initial_stores": s0.tolist(),
            "climate": {
                "precip": short_forcing[:, 0],
                "temp": short_forcing[:, 1],
                "pet": short_forcing[:, 2],
            },
            "compile_target": "numba",
        },
        solver="numba_newton",
    )
    model_newton_states = np.vstack((s0.reshape(1, -1), model_newton.stores))
    print("consistency against current model-level routes (365 steps):")
    print(
        "- max |model numba_newton - prototype_newton|: "
        f"{float(np.max(np.abs(model_newton_states - current_newton_states))):.6e}"
    )


if __name__ == "__main__":
    main()
