from __future__ import annotations

import argparse
import importlib
import json
import math
import sys
import types
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.catalog import MODEL_METADATA, MODEL_REGISTRY, create_model
from pyrrmod.solvers.newton import newton_raphson
from pyrrmod.unithydro import (
    delay_hydrograph,
    full_hydrograph,
    gamma_hydrograph,
    half_hydrograph,
    route,
    uniform_hydrograph,
    update_uh,
)


DEFAULT_DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"
DEFAULT_REPORT_FILE = PROJECT_ROOT / "reports" / "pyrrmod_vs_pymarrmot_03604000.json"


@dataclass(slots=True)
class RunRecord:
    model: str
    legacy_name: str
    percentile_label: str
    percentile: float
    steps: int
    success: bool
    pyrrmod_error: str | None
    pymarrmot_error: str | None
    pyrrmod_water_balance: float | None
    pymarrmot_water_balance: float | None
    max_abs_diff: float | None
    rmse_diff: float | None
    mae_diff: float | None
    nse_ref: float | None
    kge_ref: float | None
    nse_pyrrmod_obs: float | None
    nse_pymarrmot_obs: float | None
    kge_pyrrmod_obs: float | None
    kge_pymarrmot_obs: float | None


@dataclass(slots=True)
class ModelSummary:
    model: str
    legacy_name: str
    success_runs: int
    total_runs: int
    max_abs_diff: float | None
    mean_rmse_diff: float | None
    min_nse_ref: float | None
    best_nse_pyrrmod_obs: float | None
    best_nse_pymarrmot_obs: float | None
    alignment_class: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compare PyRRMod and official pymarrmot runoff simulations using "
            "parameter percentiles p05/p25/p50/p75/p95 on daily forcing."
        )
    )
    parser.add_argument(
        "--data-file",
        type=Path,
        default=DEFAULT_DATA_FILE,
        help="CSV forcing file with columns precip,temp,pet,flow.",
    )
    parser.add_argument(
        "--n-steps",
        type=int,
        default=0,
        help="Rows from forcing to use. 0 means all rows.",
    )
    parser.add_argument(
        "--percentiles",
        type=str,
        default="0.05,0.25,0.50,0.75,0.95",
        help="Comma-separated percentiles in [0,1].",
    )
    parser.add_argument(
        "--delta-t",
        type=float,
        default=1.0,
        help="Simulation time step in days.",
    )
    parser.add_argument(
        "--initial-store",
        type=float,
        default=50.0,
        help="Initial value used for every store.",
    )
    parser.add_argument(
        "--solver",
        type=str,
        default="fsolve",
        choices=["fsolve", "numba_newton"],
        help="PyRRMod solver backend.",
    )
    parser.add_argument(
        "--compile-target",
        type=str,
        default="python",
        choices=["python", "numba", "auto"],
        help="PyRRMod compile target.",
    )
    parser.add_argument(
        "--models",
        type=str,
        default="",
        help="Optional comma-separated PyRRMod model names.",
    )
    parser.add_argument(
        "--report-file",
        type=Path,
        default=DEFAULT_REPORT_FILE,
        help="Output JSON report path.",
    )
    parser.add_argument(
        "--legacy-state-update",
        action="store_true",
        default=True,
        help="Use state writeback from model increments after root solving.",
    )
    parser.add_argument(
        "--disable-legacy-state-update",
        action="store_false",
        dest="legacy_state_update",
        help="Disable increment-based state writeback.",
    )
    parser.add_argument(
        "--retry-solver",
        action="store_true",
        default=True,
        help="Enable Newton/fsolve/least-squares retry chain.",
    )
    parser.add_argument(
        "--disable-retry-solver",
        action="store_false",
        dest="retry_solver",
        help="Disable retry chain and use plain fsolve step.",
    )
    return parser.parse_args()


def _ensure_package(name: str, path: Path | None = None) -> types.ModuleType:
    existing = sys.modules.get(name)
    if existing is not None:
        if path is not None:
            existing_path = getattr(existing, "__path__", None)
            if existing_path is None:
                existing.__path__ = [str(path)]
            elif str(path) not in existing_path:
                existing_path.append(str(path))
        return existing

    module = types.ModuleType(name)
    if path is not None:
        module.__path__ = [str(path)]
    sys.modules[name] = module
    return module


def bootstrap_pymarrmot(src_root: Path) -> None:
    if not src_root.exists():
        raise FileNotFoundError(f"pymarrmot src root not found: {src_root}")

    if not hasattr(np, "math"):
        np.math = math

    _ensure_package("pymarrmot", src_root)
    _ensure_package("pymarrmot.models", src_root / "models")
    _ensure_package("pymarrmot.models.models", src_root / "models" / "models")
    _ensure_package("pymarrmot.models.flux", src_root / "models" / "flux")
    _ensure_package("pymarrmot.functions", src_root / "functions")
    _ensure_package(
        "pymarrmot.functions.objective_functions",
        src_root / "functions" / "objective_functions",
    )

    try:
        import cma  # noqa: F401
    except Exception:
        cma_stub = types.ModuleType("cma")

        def _fmin2_stub(*args: Any, **kwargs: Any) -> Any:
            raise RuntimeError("cma is not available in this environment")

        cma_stub.fmin2 = _fmin2_stub
        sys.modules["cma"] = cma_stub

    solver_pkg = _ensure_package("pymarrmot.functions.solver_functions")
    nr_mod_name = "pymarrmot.functions.solver_functions.NewtonRaphson"
    nr_module = sys.modules.get(nr_mod_name)
    if nr_module is None:
        nr_module = types.ModuleType(nr_mod_name)

        def NewtonRaphson(fun: Any, x0: Any, opts: Any = None) -> tuple[Any, Any, int]:
            root, fval, flag = newton_raphson(fun, x0, opts)
            return root, fval, int(flag)

        nr_module.NewtonRaphson = NewtonRaphson
        sys.modules[nr_mod_name] = nr_module
    solver_pkg.NewtonRaphson = nr_module

    unit_pkg = _ensure_package("pymarrmot.models.unit_hydro")

    def uh_1_half(duration: float, delta_t: float):
        return half_hydrograph(duration, delta_t, power=2.5)

    def uh_2_full(duration: float, delta_t: float):
        return full_hydrograph(duration, delta_t, power=2.5)

    def uh_3_half(duration: float, delta_t: float):
        return half_hydrograph(duration, delta_t, power=1.5)

    def uh_4_full(duration: float, delta_t: float):
        return full_hydrograph(duration, delta_t, power=1.5)

    def uh_5_half(duration: float, delta_t: float):
        return half_hydrograph(duration, delta_t, power=1.0)

    def uh_6_gamma(n: float, k: float, delta_t: float):
        return gamma_hydrograph(n, k, delta_t)

    def uh_7_uniform(duration: float, delta_t: float):
        return uniform_hydrograph(duration, delta_t)

    def uh_8_delay(delay: float, delta_t: float):
        return delay_hydrograph(delay, delta_t)

    unit_functions = {
        "route": route,
        "update_uh": update_uh,
        "uh_1_half": uh_1_half,
        "uh_2_full": uh_2_full,
        "uh_3_half": uh_3_half,
        "uh_4_full": uh_4_full,
        "uh_5_half": uh_5_half,
        "uh_6_gamma": uh_6_gamma,
        "uh_7_uniform": uh_7_uniform,
        "uh_8_delay": uh_8_delay,
    }

    for func_name, func in unit_functions.items():
        setattr(unit_pkg, func_name, func)
        submodule_name = f"pymarrmot.models.unit_hydro.{func_name}"
        mod = sys.modules.get(submodule_name)
        if mod is None:
            mod = types.ModuleType(submodule_name)
            sys.modules[submodule_name] = mod
        setattr(mod, func_name, func)


def parse_percentiles(raw: str) -> list[tuple[str, float]]:
    values: list[float] = []
    for chunk in raw.split(","):
        text = chunk.strip()
        if not text:
            continue
        value = float(text)
        if value < 0.0 or value > 1.0:
            raise ValueError(f"percentile must be in [0,1], got {value}")
        values.append(value)

    if not values:
        raise ValueError("no valid percentiles provided")

    labels: list[tuple[str, float]] = []
    for value in values:
        labels.append((f"p{int(round(value * 100)):02d}", value))
    return labels


def load_forcing(
    data_file: Path, n_steps: int
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    kwargs: dict[str, Any] = {"delimiter": ",", "skiprows": 1}
    if n_steps > 0:
        kwargs["max_rows"] = int(n_steps)
    data = np.loadtxt(data_file, **kwargs)
    data = np.atleast_2d(data)

    forcing = {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }
    q_obs = np.asarray(data[:, 3], dtype=np.float64)
    return forcing, q_obs


def theta_from_ranges(par_ranges: Any, percentile: float, n_params: int) -> np.ndarray:
    if n_params <= 0:
        return np.zeros(0, dtype=np.float64)

    if par_ranges is None:
        return np.ones(n_params, dtype=np.float64)

    arr = np.asarray(par_ranges, dtype=np.float64)
    if arr.ndim != 2 or arr.shape != (n_params, 2):
        return np.ones(n_params, dtype=np.float64)

    low = arr[:, 0]
    high = arr[:, 1]
    theta = np.ones(n_params, dtype=np.float64)

    finite = np.isfinite(low) & np.isfinite(high)
    theta[finite] = low[finite] + percentile * (high[finite] - low[finite])

    only_low_finite = np.isfinite(low) & ~np.isfinite(high)
    theta[only_low_finite] = low[only_low_finite] + np.maximum(
        1.0, np.abs(low[only_low_finite]) * 0.10
    )

    only_high_finite = ~np.isfinite(low) & np.isfinite(high)
    theta[only_high_finite] = high[only_high_finite] - np.maximum(
        1.0, np.abs(high[only_high_finite]) * 0.10
    )

    both_inf = ~np.isfinite(low) & ~np.isfinite(high)
    theta[both_inf] = 1.0
    return theta


def nse(obs: np.ndarray, sim: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if not np.any(mask):
        return float("nan")
    o = obs[mask]
    s = sim[mask]
    denom = float(np.sum((o - np.mean(o)) ** 2))
    if denom <= 0.0:
        return float("nan")
    return float(1.0 - np.sum((s - o) ** 2) / denom)


def kge(obs: np.ndarray, sim: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if not np.any(mask):
        return float("nan")
    o = obs[mask]
    s = sim[mask]
    if o.size < 2:
        return float("nan")

    std_o = float(np.std(o, ddof=0))
    std_s = float(np.std(s, ddof=0))
    mean_o = float(np.mean(o))
    mean_s = float(np.mean(s))
    if std_o == 0.0 or std_s == 0.0 or mean_o == 0.0:
        return float("nan")

    corr = float(np.corrcoef(o, s)[0, 1])
    alpha = std_s / std_o
    beta = mean_s / mean_o
    return float(
        1.0 - math.sqrt((corr - 1.0) ** 2 + (alpha - 1.0) ** 2 + (beta - 1.0) ** 2)
    )


def run_pyrrmod(
    model_name: str,
    theta: np.ndarray,
    forcing: dict[str, np.ndarray],
    *,
    delta_t: float,
    initial_store_value: float,
    solver: str,
    compile_target: str,
    legacy_state_update: bool,
    retry_solver: bool,
) -> tuple[np.ndarray, float]:
    np.random.seed(13)
    model = create_model(model_name)
    n_stores = int(model.num_stores or 0)
    s0 = np.full(n_stores, float(initial_store_value), dtype=np.float64)
    config = {
        "theta": np.asarray(theta, dtype=np.float64),
        "delta_t": float(delta_t),
        "initial_stores": s0,
        "climate": {
            "precip": np.asarray(forcing["precip"], dtype=np.float64),
            "temp": np.asarray(forcing["temp"], dtype=np.float64),
            "pet": np.asarray(forcing["pet"], dtype=np.float64),
        },
        "solver_options": {
            "resnorm_tolerance": 0.1,
            "resnorm_maxiter": 6,
            "legacy_state_update": bool(legacy_state_update),
            "retry_solver": bool(retry_solver),
        },
        "compile_target": compile_target,
    }
    model.run(config=config, solver=solver)
    q_sim = np.asarray(model.get_streamflow(), dtype=np.float64).reshape(-1)
    wb = float(model.check_water_balance())
    return q_sim, wb


def run_pymarrmot(
    legacy_name: str,
    theta: np.ndarray,
    forcing: dict[str, np.ndarray],
    *,
    delta_t: float,
    initial_store_value: float,
) -> tuple[np.ndarray, float]:
    np.random.seed(13)
    module = importlib.import_module(f"pymarrmot.models.models.{legacy_name}")
    model_cls = getattr(module, legacy_name)
    model = model_cls()

    n_stores = int(model.num_stores or 0)
    s0 = np.full(n_stores, float(initial_store_value), dtype=np.float64)

    model.delta_t = float(delta_t)
    model.S0 = np.asarray(s0, dtype=np.float64)
    model.solver_opts = {
        "resnorm_tolerance": 0.1,
        "resnorm_maxiter": 6,
    }
    model.input_climate = {
        "precip": np.asarray(forcing["precip"], dtype=np.float64).copy(),
        "temp": np.asarray(forcing["temp"], dtype=np.float64).copy(),
        "pet": np.asarray(forcing["pet"], dtype=np.float64).copy(),
    }
    model.theta = np.asarray(theta, dtype=np.float64)

    original_model_fun = model.model_fun

    def _model_fun_numpy(states: Any) -> tuple[np.ndarray, np.ndarray]:
        dS, fluxes = original_model_fun(states)
        return (
            np.asarray(dS, dtype=np.float64).reshape(-1),
            np.asarray(fluxes, dtype=np.float64).reshape(-1),
        )

    model.model_fun = _model_fun_numpy

    model.run()
    flux_output, _, _ = model.get_output(3)
    q_sim = np.asarray(flux_output["Q"], dtype=np.float64).reshape(-1)
    wb = float(model.check_waterbalance())
    return q_sim, wb


def classify_alignment(max_abs_diff: float | None) -> str:
    if max_abs_diff is None or not np.isfinite(max_abs_diff):
        return "failed"
    if max_abs_diff <= 1e-8:
        return "identical"
    if max_abs_diff <= 1e-4:
        return "near-identical"
    return "different"


def summarize_results(records: list[RunRecord]) -> list[ModelSummary]:
    grouped: dict[str, list[RunRecord]] = {}
    for record in records:
        grouped.setdefault(record.model, []).append(record)

    summaries: list[ModelSummary] = []
    for model_name, items in sorted(grouped.items()):
        legacy_name = items[0].legacy_name
        ok_items = [item for item in items if item.success]

        max_abs_values = [
            item.max_abs_diff for item in ok_items if item.max_abs_diff is not None
        ]
        rmse_values = [
            item.rmse_diff for item in ok_items if item.rmse_diff is not None
        ]
        nse_ref_values = [item.nse_ref for item in ok_items if item.nse_ref is not None]
        nse_py_values = [
            item.nse_pyrrmod_obs
            for item in ok_items
            if item.nse_pyrrmod_obs is not None
        ]
        nse_off_values = [
            item.nse_pymarrmot_obs
            for item in ok_items
            if item.nse_pymarrmot_obs is not None
        ]

        max_abs_diff = float(np.max(max_abs_values)) if max_abs_values else None
        mean_rmse = float(np.mean(rmse_values)) if rmse_values else None
        min_nse_ref = float(np.min(nse_ref_values)) if nse_ref_values else None
        best_nse_py = float(np.max(nse_py_values)) if nse_py_values else None
        best_nse_off = float(np.max(nse_off_values)) if nse_off_values else None

        summaries.append(
            ModelSummary(
                model=model_name,
                legacy_name=legacy_name,
                success_runs=len(ok_items),
                total_runs=len(items),
                max_abs_diff=max_abs_diff,
                mean_rmse_diff=mean_rmse,
                min_nse_ref=min_nse_ref,
                best_nse_pyrrmod_obs=best_nse_py,
                best_nse_pymarrmot_obs=best_nse_off,
                alignment_class=classify_alignment(max_abs_diff),
            )
        )
    return summaries


def print_summary(summaries: list[ModelSummary], records: list[RunRecord]) -> None:
    total = len(summaries)
    success_models = sum(
        1 for item in summaries if item.success_runs == item.total_runs
    )
    identical = sum(1 for item in summaries if item.alignment_class == "identical")
    near = sum(1 for item in summaries if item.alignment_class == "near-identical")
    different = sum(1 for item in summaries if item.alignment_class == "different")
    failed = sum(1 for item in summaries if item.alignment_class == "failed")

    print("=" * 132)
    print("PyRRMod vs pymarrmot alignment report")
    print("=" * 132)
    print(
        f"Models: {total} | Fully successful: {success_models} | "
        f"identical: {identical} | near-identical: {near} | different: {different} | failed: {failed}"
    )
    print("-" * 132)
    print(
        "model           legacy_name                ok/total  max_abs_diff   mean_rmse      "
        "min_nse_ref    class"
    )
    print("-" * 132)

    for item in summaries:
        max_abs = "-" if item.max_abs_diff is None else f"{item.max_abs_diff:.3e}"
        mean_rmse = "-" if item.mean_rmse_diff is None else f"{item.mean_rmse_diff:.3e}"
        min_nse_ref = "-" if item.min_nse_ref is None else f"{item.min_nse_ref:.6f}"
        print(
            f"{item.model:<15} {item.legacy_name:<26} {item.success_runs:>2}/{item.total_runs:<6} "
            f"{max_abs:<13} {mean_rmse:<13} {min_nse_ref:<13} {item.alignment_class}"
        )

    failed_records = [record for record in records if not record.success]
    if failed_records:
        print("-" * 132)
        print("Failed runs")
        for record in failed_records:
            reason = record.pyrrmod_error or record.pymarrmot_error or "unknown"
            print(f"{record.model} {record.percentile_label}: {reason}")

    print("=" * 132)


def main() -> None:
    args = parse_args()
    forcing, q_obs = load_forcing(args.data_file, args.n_steps)
    percentiles = parse_percentiles(args.percentiles)

    pymarrmot_src = PROJECT_ROOT / "pymarrmot" / "src"
    bootstrap_pymarrmot(pymarrmot_src)

    requested_models: set[str] | None = None
    if args.models.strip():
        requested_models = {
            chunk.strip() for chunk in args.models.split(",") if chunk.strip()
        }

    model_names = sorted(MODEL_REGISTRY)
    if requested_models is not None:
        model_names = [name for name in model_names if name in requested_models]

    records: list[RunRecord] = []

    for model_name in model_names:
        legacy_name = str(MODEL_METADATA[model_name]["legacy_name"])
        pyrr_model_for_range = create_model(model_name)
        n_params = int(pyrr_model_for_range.num_params or 0)
        par_ranges = pyrr_model_for_range.par_ranges

        for label, pct in percentiles:
            theta = theta_from_ranges(par_ranges, pct, n_params)

            py_q: np.ndarray | None = None
            py_wb: float | None = None
            off_q: np.ndarray | None = None
            off_wb: float | None = None
            py_err: str | None = None
            off_err: str | None = None

            py_solver = str(args.solver)
            py_compile_target = str(args.compile_target)
            if py_solver == "numba_newton":
                model_obj = create_model(model_name)
                routed_model = bool(model_obj._uses_discrete_step_solver())
                if not routed_model and model_name not in {"gr4j"}:
                    py_solver = "fsolve"
                    py_compile_target = "python"

            try:
                py_q, py_wb = run_pyrrmod(
                    model_name,
                    theta,
                    forcing,
                    delta_t=float(args.delta_t),
                    initial_store_value=float(args.initial_store),
                    solver=py_solver,
                    compile_target=py_compile_target,
                    legacy_state_update=bool(args.legacy_state_update),
                    retry_solver=bool(args.retry_solver),
                )
            except Exception as exc:
                py_err = f"{exc.__class__.__name__}: {exc}"

            try:
                off_q, off_wb = run_pymarrmot(
                    legacy_name,
                    theta,
                    forcing,
                    delta_t=float(args.delta_t),
                    initial_store_value=float(args.initial_store),
                )
            except Exception as exc:
                off_err = f"{exc.__class__.__name__}: {exc}"

            if py_q is None or off_q is None:
                records.append(
                    RunRecord(
                        model=model_name,
                        legacy_name=legacy_name,
                        percentile_label=label,
                        percentile=float(pct),
                        steps=int(forcing["precip"].shape[0]),
                        success=False,
                        pyrrmod_error=py_err,
                        pymarrmot_error=off_err,
                        pyrrmod_water_balance=py_wb,
                        pymarrmot_water_balance=off_wb,
                        max_abs_diff=None,
                        rmse_diff=None,
                        mae_diff=None,
                        nse_ref=None,
                        kge_ref=None,
                        nse_pyrrmod_obs=None,
                        nse_pymarrmot_obs=None,
                        kge_pyrrmod_obs=None,
                        kge_pymarrmot_obs=None,
                    )
                )
                continue

            if py_q.shape != off_q.shape:
                records.append(
                    RunRecord(
                        model=model_name,
                        legacy_name=legacy_name,
                        percentile_label=label,
                        percentile=float(pct),
                        steps=int(forcing["precip"].shape[0]),
                        success=False,
                        pyrrmod_error=(
                            py_err
                            or f"shape mismatch: pyrrmod={py_q.shape}, pymarrmot={off_q.shape}"
                        ),
                        pymarrmot_error=off_err,
                        pyrrmod_water_balance=py_wb,
                        pymarrmot_water_balance=off_wb,
                        max_abs_diff=None,
                        rmse_diff=None,
                        mae_diff=None,
                        nse_ref=None,
                        kge_ref=None,
                        nse_pyrrmod_obs=None,
                        nse_pymarrmot_obs=None,
                        kge_pyrrmod_obs=None,
                        kge_pymarrmot_obs=None,
                    )
                )
                continue

            diff = np.asarray(py_q - off_q, dtype=np.float64)
            max_abs = float(np.max(np.abs(diff)))
            rmse = float(np.sqrt(np.mean(diff**2)))
            mae = float(np.mean(np.abs(diff)))

            nse_ref = nse(off_q, py_q)
            kge_ref = kge(off_q, py_q)
            nse_py_obs = nse(q_obs, py_q)
            nse_off_obs = nse(q_obs, off_q)
            kge_py_obs = kge(q_obs, py_q)
            kge_off_obs = kge(q_obs, off_q)

            records.append(
                RunRecord(
                    model=model_name,
                    legacy_name=legacy_name,
                    percentile_label=label,
                    percentile=float(pct),
                    steps=int(forcing["precip"].shape[0]),
                    success=True,
                    pyrrmod_error=py_err,
                    pymarrmot_error=off_err,
                    pyrrmod_water_balance=py_wb,
                    pymarrmot_water_balance=off_wb,
                    max_abs_diff=max_abs,
                    rmse_diff=rmse,
                    mae_diff=mae,
                    nse_ref=nse_ref,
                    kge_ref=kge_ref,
                    nse_pyrrmod_obs=nse_py_obs,
                    nse_pymarrmot_obs=nse_off_obs,
                    kge_pyrrmod_obs=kge_py_obs,
                    kge_pymarrmot_obs=kge_off_obs,
                )
            )

    summaries = summarize_results(records)
    print_summary(summaries, records)

    payload = {
        "data_file": str(args.data_file),
        "n_steps": int(forcing["precip"].shape[0]),
        "delta_t": float(args.delta_t),
        "percentiles": [
            {"label": label, "value": value} for label, value in percentiles
        ],
        "pyrrmod_solver": str(args.solver),
        "pyrrmod_compile_target": str(args.compile_target),
        "initial_store": float(args.initial_store),
        "total_models": len(model_names),
        "records": [asdict(record) for record in records],
        "summary": [asdict(item) for item in summaries],
    }

    report_file = args.report_file
    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text(
        json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8"
    )
    print(f"JSON report saved to: {report_file}")


if __name__ == "__main__":
    main()
