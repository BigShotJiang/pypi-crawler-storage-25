from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy.optimize import brentq, fsolve


def solve_scalar_fsolve_bracketed(
    residual_fun: Callable[[float], float],
    initial_guess: float,
    *,
    lower_bound: float,
    upper_bound: float,
    tolerance: float = 1.0e-8,
    maxfev: int = 100,
    sample_points: int = 8,
) -> tuple[float, float, int]:
    lower = float(lower_bound)
    upper = float(upper_bound)
    if upper < lower:
        lower, upper = upper, lower

    def evaluate(value: float) -> float:
        return float(residual_fun(float(value)))

    if upper == lower:
        residual = abs(evaluate(lower))
        return lower, residual, 1

    guess = min(max(float(initial_guess), lower), upper)
    best_x = guess
    best_residual = abs(evaluate(best_x))
    nfev = 1

    def consider(value: float) -> float:
        nonlocal best_x, best_residual, nfev
        clipped = min(max(float(value), lower), upper)
        residual = abs(evaluate(clipped))
        nfev += 1
        if residual < best_residual:
            best_x = clipped
            best_residual = residual
        return residual

    def wrapped(values: np.ndarray) -> np.ndarray:
        return np.asarray([evaluate(float(values[0]))], dtype=np.float64)

    try:
        root, info, _, _ = fsolve(
            wrapped,
            np.asarray([guess], dtype=np.float64),
            full_output=True,
            maxfev=int(max(8, maxfev)),
        )
        nfev += int(info.get("nfev", 0))
        consider(float(root[0]))
        if best_residual <= tolerance:
            return best_x, best_residual, nfev
    except Exception:
        pass

    sample_x = np.linspace(lower, upper, max(2, int(sample_points)), dtype=np.float64)
    bracket_left: float | None = None
    bracket_right: float | None = None
    previous_x = float(sample_x[0])
    previous_f = evaluate(previous_x)
    nfev += 1
    if abs(previous_f) < best_residual:
        best_x = previous_x
        best_residual = abs(previous_f)

    for current_value in sample_x[1:]:
        current_x = float(current_value)
        current_f = evaluate(current_x)
        nfev += 1
        if abs(current_f) < best_residual:
            best_x = current_x
            best_residual = abs(current_f)
        if previous_f == 0.0:
            return previous_x, 0.0, nfev
        if current_f == 0.0:
            return current_x, 0.0, nfev
        if previous_f * current_f < 0.0:
            bracket_left = previous_x
            bracket_right = current_x
            break
        previous_x = current_x
        previous_f = current_f

    if bracket_left is not None and bracket_right is not None:
        try:
            root = float(
                brentq(
                    evaluate,
                    float(bracket_left),
                    float(bracket_right),
                    maxiter=int(max(8, maxfev)),
                )
            )
            residual = abs(evaluate(root))
            nfev += 1
            if residual < best_residual:
                best_x = root
                best_residual = residual
        except Exception:
            pass

    return best_x, best_residual, nfev


__all__ = ["solve_scalar_fsolve_bracketed"]
