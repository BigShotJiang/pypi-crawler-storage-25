from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro.core import update_uh_inplace_nb


@numba.njit(cache=True)
def _clip_inplace(states, lower, upper):
    for index in range(states.shape[0]):
        value = states[index]
        if value < lower[index]:
            value = lower[index]
        elif value > upper[index]:
            value = upper[index]
        states[index] = value


@numba.njit(cache=False)
def _fill_residual(
    step_kernel,
    states,
    previous_states,
    step_index,
    delta_t,
    out_dS,
    out_fluxes,
    out_residual,
):
    step_kernel(states, step_index, out_dS, out_fluxes)
    for row in range(states.shape[0]):
        out_residual[row] = (states[row] - previous_states[row]) / delta_t - out_dS[row]


@numba.njit(cache=False)
def _numba_newton_step(
    step_kernel,
    states,
    previous_states,
    step_index,
    delta_t,
    lower,
    upper,
    tol,
    max_iter,
    diff_step,
    out_dS,
    out_fluxes,
    residual,
    jacobian,
    right_hand_side,
    trial_states,
    trial_residual,
):
    n_states = states.shape[0]
    iterations = 0
    nfev = 0
    njev = 0
    max_delta = 0.0

    for iteration in range(max_iter):
        iterations = iteration + 1
        _fill_residual(
            step_kernel,
            states,
            previous_states,
            step_index,
            delta_t,
            out_dS,
            out_fluxes,
            residual,
        )
        nfev += 1

        for col in range(n_states):
            for row in range(n_states):
                trial_states[row] = states[row]

            reference = states[col]
            step = diff_step * max(abs(reference), 1.0)
            trial_states[col] = reference + step

            _clip_inplace(trial_states, lower, upper)
            effective_step = trial_states[col] - reference
            if effective_step == 0.0:
                effective_step = step

            _fill_residual(
                step_kernel,
                trial_states,
                previous_states,
                step_index,
                delta_t,
                out_dS,
                out_fluxes,
                trial_residual,
            )
            nfev += 1

            for row in range(n_states):
                jacobian[row, col] = (
                    trial_residual[row] - residual[row]
                ) / effective_step

        njev += 1

        for row in range(n_states):
            right_hand_side[row] = -residual[row]
            jacobian[row, row] = jacobian[row, row] + 1e-12

        delta = np.linalg.solve(jacobian, right_hand_side)

        max_delta = 0.0
        for row in range(n_states):
            states[row] = states[row] + delta[row]
            delta_abs = abs(delta[row])
            if delta_abs > max_delta:
                max_delta = delta_abs

        _clip_inplace(states, lower, upper)

        if max_delta < tol:
            break

    _fill_residual(
        step_kernel,
        states,
        previous_states,
        step_index,
        delta_t,
        out_dS,
        out_fluxes,
        residual,
    )
    nfev += 1

    residual_norm = 0.0
    for row in range(n_states):
        residual_norm += residual[row] * residual[row]

    converged = 1 if max_delta < tol else 0
    return residual_norm, iterations, nfev, njev, converged


@numba.njit(cache=False)
def run_numba_newton_kernel(
    step_kernel,
    stores,
    fluxes,
    s0,
    delta_t,
    lower,
    upper,
    tol,
    max_iter,
    diff_step,
    damping,
    jacobian_pattern,
    use_predictor,
    clip_iterates,
):
    n_steps = stores.shape[0]
    n_states = s0.shape[0]
    n_fluxes = fluxes.shape[1]
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.empty(n_steps, dtype=np.int64)
    converged = np.zeros(n_steps, dtype=np.int64)

    current_states = np.empty(n_states, dtype=np.float64)
    previous_states = np.empty(n_states, dtype=np.float64)
    out_dS = np.empty(n_states, dtype=np.float64)
    out_fluxes = np.empty(n_fluxes, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        if time_index == 0:
            for row in range(n_states):
                previous_states[row] = s0[row]
        else:
            for row in range(n_states):
                previous_states[row] = stores[time_index - 1, row]

        if use_predictor:
            step_kernel(
                previous_states,
                time_index,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                current_states[row] = previous_states[row] + delta_t * out_dS[row]
            if clip_iterates:
                _clip_inplace(current_states, lower, upper)
        else:
            for row in range(n_states):
                current_states[row] = previous_states[row]

        iterations_used = 0
        step_nfev = 0
        step_njev = 0
        max_delta = 0.0
        step_converged = 0

        for iteration in range(max_iter):
            iterations_used = iteration + 1
            step_kernel(
                current_states,
                time_index,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                residual[row] = (
                    current_states[row] - previous_states[row]
                ) / delta_t - out_dS[row]
            step_nfev += 1

            residual_norm = 0.0
            for row in range(n_states):
                residual_norm += residual[row] * residual[row]
            residual_norm = residual_norm**0.5
            if residual_norm <= tol:
                step_converged = 1
                max_delta = 0.0
                break

            for row in range(n_states):
                for col in range(n_states):
                    jacobian[row, col] = 0.0

            for col in range(n_states):
                active_column = False
                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        active_column = True
                        break
                if not active_column:
                    continue

                for row in range(n_states):
                    trial_states[row] = current_states[row]

                reference = current_states[col]
                step = diff_step * max(abs(reference), 1.0)
                trial_states[col] = reference + step
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                effective_step = trial_states[col] - reference
                if effective_step == 0.0:
                    effective_step = step

                step_kernel(
                    trial_states,
                    time_index,
                    out_dS,
                    out_fluxes,
                )
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                step_nfev += 1

                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        jacobian[row, col] = (
                            trial_residual[row] - residual[row]
                        ) / effective_step

            step_njev += 1

            for row in range(n_states):
                right_hand_side[row] = -residual[row]
                jacobian[row, row] = jacobian[row, row] + 1e-12

            delta = np.linalg.solve(jacobian, right_hand_side)
            max_delta = 0.0
            step_scale = damping
            accepted_step = False
            for _ in range(8):
                for row in range(n_states):
                    trial_states[row] = current_states[row] + step_scale * delta[row]
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)

                step_kernel(
                    trial_states,
                    time_index,
                    out_dS,
                    out_fluxes,
                )
                trial_norm = 0.0
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                    trial_norm += trial_residual[row] * trial_residual[row]
                step_nfev += 1
                trial_norm = trial_norm**0.5
                if trial_norm < residual_norm:
                    for row in range(n_states):
                        delta_abs = abs(trial_states[row] - current_states[row])
                        if delta_abs > max_delta:
                            max_delta = delta_abs
                        current_states[row] = trial_states[row]
                    residual_norm = trial_norm
                    if residual_norm <= tol:
                        step_converged = 1
                    accepted_step = True
                    break
                step_scale = 0.5 * step_scale

            if not accepted_step:
                break
            if max_delta < tol:
                if residual_norm <= tol:
                    step_converged = 1
                break

        _clip_inplace(current_states, lower, upper)
        step_kernel(
            current_states,
            time_index,
            out_dS,
            out_fluxes,
        )
        for row in range(n_states):
            residual[row] = (
                current_states[row] - previous_states[row]
            ) / delta_t - out_dS[row]
            stores[time_index, row] = current_states[row]
        for col in range(n_fluxes):
            fluxes[time_index, col] = out_fluxes[col] * delta_t
        step_nfev += 1

        residual_norm = 0.0
        for row in range(n_states):
            residual_norm += residual[row] * residual[row]
        residual_norm = residual_norm**0.5
        if residual_norm <= tol:
            step_converged = 1

        residual_norms[time_index] = residual_norm
        iterations[time_index] = iterations_used
        nfev[time_index] = step_nfev
        njev[time_index] = step_njev
        converged[time_index] = step_converged

        if step_converged == 0:
            for remaining_index in range(time_index + 1, n_steps):
                residual_norms[remaining_index] = np.inf
                iterations[remaining_index] = 0
                nfev[remaining_index] = 0
                njev[remaining_index] = 0
                converged[remaining_index] = 0
            return stores, fluxes, residual_norms, iterations, nfev, njev, converged

    return stores, fluxes, residual_norms, iterations, nfev, njev, converged


@numba.njit(cache=False)
def run_routed_numba_newton_kernel_single(
    step_kernel,
    inflow_kernel,
    stores,
    fluxes,
    s0,
    delta_t,
    lower,
    upper,
    tol,
    max_iter,
    diff_step,
    damping,
    jacobian_pattern,
    use_predictor,
    clip_iterates,
    uh_weights,
    uh_pending,
):
    n_steps = stores.shape[0]
    n_states = s0.shape[0]
    n_fluxes = fluxes.shape[1]
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.empty(n_steps, dtype=np.int64)

    current_states = np.empty(n_states, dtype=np.float64)
    previous_states = np.empty(n_states, dtype=np.float64)
    out_dS = np.empty(n_states, dtype=np.float64)
    out_fluxes = np.empty(n_fluxes, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        if time_index == 0:
            for row in range(n_states):
                previous_states[row] = s0[row]
        else:
            for row in range(n_states):
                previous_states[row] = stores[time_index - 1, row]

        if use_predictor:
            step_kernel(
                previous_states,
                time_index,
                uh_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                current_states[row] = previous_states[row] + delta_t * out_dS[row]
            if clip_iterates:
                _clip_inplace(current_states, lower, upper)
        else:
            for row in range(n_states):
                current_states[row] = previous_states[row]

        iterations_used = 0
        max_delta = 0.0
        step_nfev = 0
        step_njev = 0

        for iteration in range(max_iter):
            iterations_used = iteration + 1
            step_kernel(
                current_states,
                time_index,
                uh_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                residual[row] = (
                    current_states[row] - previous_states[row]
                ) / delta_t - out_dS[row]
            step_nfev += 1

            residual_norm = 0.0
            for row in range(n_states):
                residual_norm += residual[row] * residual[row]
            residual_norm = residual_norm**0.5
            if residual_norm <= tol:
                max_delta = 0.0
                break

            for row in range(n_states):
                for col in range(n_states):
                    jacobian[row, col] = 0.0

            for col in range(n_states):
                active_column = False
                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        active_column = True
                        break
                if not active_column:
                    continue

                for row in range(n_states):
                    trial_states[row] = current_states[row]

                reference = current_states[col]
                step = diff_step * max(abs(reference), 1.0)
                trial_states[col] = reference + step
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                effective_step = trial_states[col] - reference
                if effective_step == 0.0:
                    effective_step = step

                step_kernel(
                    trial_states,
                    time_index,
                    uh_pending,
                    out_dS,
                    out_fluxes,
                )
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                step_nfev += 1

                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        jacobian[row, col] = (
                            trial_residual[row] - residual[row]
                        ) / effective_step

            step_njev += 1

            for row in range(n_states):
                right_hand_side[row] = -residual[row]
                jacobian[row, row] = jacobian[row, row] + 1e-12

            delta = np.linalg.solve(jacobian, right_hand_side)
            max_delta = 0.0
            step_scale = damping
            accepted_step = False
            for _ in range(8):
                for row in range(n_states):
                    trial_states[row] = current_states[row] + step_scale * delta[row]
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                step_kernel(
                    trial_states,
                    time_index,
                    uh_pending,
                    out_dS,
                    out_fluxes,
                )
                trial_norm = 0.0
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                    trial_norm += trial_residual[row] * trial_residual[row]
                step_nfev += 1
                trial_norm = trial_norm**0.5
                if trial_norm < residual_norm:
                    for row in range(n_states):
                        delta_abs = abs(trial_states[row] - current_states[row])
                        if delta_abs > max_delta:
                            max_delta = delta_abs
                        current_states[row] = trial_states[row]
                    accepted_step = True
                    break
                step_scale = 0.5 * step_scale

            if not accepted_step:
                for row in range(n_states):
                    delta_abs = abs(trial_states[row] - current_states[row])
                    if delta_abs > max_delta:
                        max_delta = delta_abs
                    current_states[row] = trial_states[row]

            if max_delta < tol:
                break

        _clip_inplace(current_states, lower, upper)
        step_kernel(
            current_states,
            time_index,
            uh_pending,
            out_dS,
            out_fluxes,
        )
        for row in range(n_states):
            residual[row] = (
                current_states[row] - previous_states[row]
            ) / delta_t - out_dS[row]
        step_nfev += 1

        residual_norm = 0.0
        for row in range(n_states):
            stores[time_index, row] = current_states[row]
            residual_norm += residual[row] * residual[row]
        for col in range(n_fluxes):
            fluxes[time_index, col] = out_fluxes[col] * delta_t

        update_uh_inplace_nb(uh_weights, uh_pending, inflow_kernel(fluxes[time_index]))

        residual_norms[time_index] = residual_norm**0.5
        iterations[time_index] = iterations_used
        nfev[time_index] = step_nfev
        njev[time_index] = step_njev
    return stores, fluxes, residual_norms, iterations, nfev, njev


@numba.njit(cache=False)
def run_routed_numba_newton_kernel_double(
    step_kernel,
    inflow_kernel,
    stores,
    fluxes,
    s0,
    delta_t,
    lower,
    upper,
    tol,
    max_iter,
    diff_step,
    damping,
    jacobian_pattern,
    use_predictor,
    clip_iterates,
    uh1_weights,
    uh1_pending,
    uh2_weights,
    uh2_pending,
):
    n_steps = stores.shape[0]
    n_states = s0.shape[0]
    n_fluxes = fluxes.shape[1]
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.empty(n_steps, dtype=np.int64)

    current_states = np.empty(n_states, dtype=np.float64)
    previous_states = np.empty(n_states, dtype=np.float64)
    out_dS = np.empty(n_states, dtype=np.float64)
    out_fluxes = np.empty(n_fluxes, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        if time_index == 0:
            for row in range(n_states):
                previous_states[row] = s0[row]
        else:
            for row in range(n_states):
                previous_states[row] = stores[time_index - 1, row]

        if use_predictor:
            step_kernel(
                previous_states,
                time_index,
                uh1_pending,
                uh2_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                current_states[row] = previous_states[row] + delta_t * out_dS[row]
            if clip_iterates:
                _clip_inplace(current_states, lower, upper)
        else:
            for row in range(n_states):
                current_states[row] = previous_states[row]

        iterations_used = 0
        max_delta = 0.0
        step_nfev = 0
        step_njev = 0

        for iteration in range(max_iter):
            iterations_used = iteration + 1
            step_kernel(
                current_states,
                time_index,
                uh1_pending,
                uh2_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                residual[row] = (
                    current_states[row] - previous_states[row]
                ) / delta_t - out_dS[row]
            step_nfev += 1

            residual_norm = 0.0
            for row in range(n_states):
                residual_norm += residual[row] * residual[row]
            residual_norm = residual_norm**0.5
            if residual_norm <= tol:
                max_delta = 0.0
                break

            for row in range(n_states):
                for col in range(n_states):
                    jacobian[row, col] = 0.0

            for col in range(n_states):
                active_column = False
                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        active_column = True
                        break
                if not active_column:
                    continue

                for row in range(n_states):
                    trial_states[row] = current_states[row]

                reference = current_states[col]
                step = diff_step * max(abs(reference), 1.0)
                trial_states[col] = reference + step
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                effective_step = trial_states[col] - reference
                if effective_step == 0.0:
                    effective_step = step

                step_kernel(
                    trial_states,
                    time_index,
                    uh1_pending,
                    uh2_pending,
                    out_dS,
                    out_fluxes,
                )
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                step_nfev += 1

                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        jacobian[row, col] = (
                            trial_residual[row] - residual[row]
                        ) / effective_step

            step_njev += 1

            for row in range(n_states):
                right_hand_side[row] = -residual[row]
                jacobian[row, row] = jacobian[row, row] + 1e-12

            delta = np.linalg.solve(jacobian, right_hand_side)
            max_delta = 0.0
            step_scale = damping
            accepted_step = False
            for _ in range(8):
                for row in range(n_states):
                    trial_states[row] = current_states[row] + step_scale * delta[row]
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                step_kernel(
                    trial_states,
                    time_index,
                    uh1_pending,
                    uh2_pending,
                    out_dS,
                    out_fluxes,
                )
                trial_norm = 0.0
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                    trial_norm += trial_residual[row] * trial_residual[row]
                step_nfev += 1
                trial_norm = trial_norm**0.5
                if trial_norm < residual_norm:
                    for row in range(n_states):
                        delta_abs = abs(trial_states[row] - current_states[row])
                        if delta_abs > max_delta:
                            max_delta = delta_abs
                        current_states[row] = trial_states[row]
                    accepted_step = True
                    break
                step_scale = 0.5 * step_scale

            if not accepted_step:
                for row in range(n_states):
                    delta_abs = abs(trial_states[row] - current_states[row])
                    if delta_abs > max_delta:
                        max_delta = delta_abs
                    current_states[row] = trial_states[row]

            if max_delta < tol:
                break

        _clip_inplace(current_states, lower, upper)
        step_kernel(
            current_states,
            time_index,
            uh1_pending,
            uh2_pending,
            out_dS,
            out_fluxes,
        )
        for row in range(n_states):
            residual[row] = (
                current_states[row] - previous_states[row]
            ) / delta_t - out_dS[row]
        step_nfev += 1

        residual_norm = 0.0
        for row in range(n_states):
            stores[time_index, row] = current_states[row]
            residual_norm += residual[row] * residual[row]
        for col in range(n_fluxes):
            fluxes[time_index, col] = out_fluxes[col] * delta_t

        inflow_1, inflow_2 = inflow_kernel(fluxes[time_index])
        update_uh_inplace_nb(uh1_weights, uh1_pending, inflow_1)
        update_uh_inplace_nb(uh2_weights, uh2_pending, inflow_2)

        residual_norms[time_index] = residual_norm**0.5
        iterations[time_index] = iterations_used
        nfev[time_index] = step_nfev
        njev[time_index] = step_njev
    return stores, fluxes, residual_norms, iterations, nfev, njev


@numba.njit(cache=False)
def run_routed_numba_newton_kernel_triple(
    step_kernel,
    inflow_kernel,
    stores,
    fluxes,
    s0,
    delta_t,
    lower,
    upper,
    tol,
    max_iter,
    diff_step,
    damping,
    jacobian_pattern,
    use_predictor,
    clip_iterates,
    uh1_weights,
    uh1_pending,
    uh2_weights,
    uh2_pending,
    uh3_weights,
    uh3_pending,
):
    n_steps = stores.shape[0]
    n_states = s0.shape[0]
    n_fluxes = fluxes.shape[1]
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.empty(n_steps, dtype=np.int64)

    current_states = np.empty(n_states, dtype=np.float64)
    previous_states = np.empty(n_states, dtype=np.float64)
    out_dS = np.empty(n_states, dtype=np.float64)
    out_fluxes = np.empty(n_fluxes, dtype=np.float64)
    residual = np.empty(n_states, dtype=np.float64)
    jacobian = np.empty((n_states, n_states), dtype=np.float64)
    right_hand_side = np.empty(n_states, dtype=np.float64)
    trial_states = np.empty(n_states, dtype=np.float64)
    trial_residual = np.empty(n_states, dtype=np.float64)

    for time_index in range(n_steps):
        if time_index == 0:
            for row in range(n_states):
                previous_states[row] = s0[row]
        else:
            for row in range(n_states):
                previous_states[row] = stores[time_index - 1, row]

        if use_predictor:
            step_kernel(
                previous_states,
                time_index,
                uh1_pending,
                uh2_pending,
                uh3_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                current_states[row] = previous_states[row] + delta_t * out_dS[row]
            if clip_iterates:
                _clip_inplace(current_states, lower, upper)
        else:
            for row in range(n_states):
                current_states[row] = previous_states[row]

        iterations_used = 0
        max_delta = 0.0
        step_nfev = 0
        step_njev = 0

        for iteration in range(max_iter):
            iterations_used = iteration + 1
            step_kernel(
                current_states,
                time_index,
                uh1_pending,
                uh2_pending,
                uh3_pending,
                out_dS,
                out_fluxes,
            )
            for row in range(n_states):
                residual[row] = (
                    current_states[row] - previous_states[row]
                ) / delta_t - out_dS[row]
            step_nfev += 1

            residual_norm = 0.0
            for row in range(n_states):
                residual_norm += residual[row] * residual[row]
            residual_norm = residual_norm**0.5
            if residual_norm <= tol:
                max_delta = 0.0
                break

            for row in range(n_states):
                for col in range(n_states):
                    jacobian[row, col] = 0.0

            for col in range(n_states):
                active_column = False
                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        active_column = True
                        break
                if not active_column:
                    continue

                for row in range(n_states):
                    trial_states[row] = current_states[row]

                reference = current_states[col]
                step = diff_step * max(abs(reference), 1.0)
                trial_states[col] = reference + step
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                effective_step = trial_states[col] - reference
                if effective_step == 0.0:
                    effective_step = step

                step_kernel(
                    trial_states,
                    time_index,
                    uh1_pending,
                    uh2_pending,
                    uh3_pending,
                    out_dS,
                    out_fluxes,
                )
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                step_nfev += 1

                for row in range(n_states):
                    if jacobian_pattern[row, col] != 0:
                        jacobian[row, col] = (
                            trial_residual[row] - residual[row]
                        ) / effective_step

            step_njev += 1

            for row in range(n_states):
                right_hand_side[row] = -residual[row]
                jacobian[row, row] = jacobian[row, row] + 1e-12

            delta = np.linalg.solve(jacobian, right_hand_side)
            max_delta = 0.0
            step_scale = damping
            accepted_step = False
            for _ in range(8):
                for row in range(n_states):
                    trial_states[row] = current_states[row] + step_scale * delta[row]
                if clip_iterates:
                    _clip_inplace(trial_states, lower, upper)
                step_kernel(
                    trial_states,
                    time_index,
                    uh1_pending,
                    uh2_pending,
                    uh3_pending,
                    out_dS,
                    out_fluxes,
                )
                trial_norm = 0.0
                for row in range(n_states):
                    trial_residual[row] = (
                        trial_states[row] - previous_states[row]
                    ) / delta_t - out_dS[row]
                    trial_norm += trial_residual[row] * trial_residual[row]
                step_nfev += 1
                trial_norm = trial_norm**0.5
                if trial_norm < residual_norm:
                    for row in range(n_states):
                        delta_abs = abs(trial_states[row] - current_states[row])
                        if delta_abs > max_delta:
                            max_delta = delta_abs
                        current_states[row] = trial_states[row]
                    accepted_step = True
                    break
                step_scale = 0.5 * step_scale

            if not accepted_step:
                for row in range(n_states):
                    delta_abs = abs(trial_states[row] - current_states[row])
                    if delta_abs > max_delta:
                        max_delta = delta_abs
                    current_states[row] = trial_states[row]

            if max_delta < tol:
                break

        _clip_inplace(current_states, lower, upper)
        step_kernel(
            current_states,
            time_index,
            uh1_pending,
            uh2_pending,
            uh3_pending,
            out_dS,
            out_fluxes,
        )
        for row in range(n_states):
            residual[row] = (
                current_states[row] - previous_states[row]
            ) / delta_t - out_dS[row]
        step_nfev += 1

        residual_norm = 0.0
        for row in range(n_states):
            stores[time_index, row] = current_states[row]
            residual_norm += residual[row] * residual[row]
        for col in range(n_fluxes):
            fluxes[time_index, col] = out_fluxes[col] * delta_t

        inflow_1, inflow_2, inflow_3 = inflow_kernel(fluxes[time_index])
        update_uh_inplace_nb(uh1_weights, uh1_pending, inflow_1)
        update_uh_inplace_nb(uh2_weights, uh2_pending, inflow_2)
        update_uh_inplace_nb(uh3_weights, uh3_pending, inflow_3)

        residual_norms[time_index] = residual_norm**0.5
        iterations[time_index] = iterations_used
        nfev[time_index] = step_nfev
        njev[time_index] = step_njev
    return stores, fluxes, residual_norms, iterations, nfev, njev


__all__ = [
    "run_numba_newton_kernel",
    "run_routed_numba_newton_kernel_double",
    "run_routed_numba_newton_kernel_single",
    "run_routed_numba_newton_kernel_triple",
]
