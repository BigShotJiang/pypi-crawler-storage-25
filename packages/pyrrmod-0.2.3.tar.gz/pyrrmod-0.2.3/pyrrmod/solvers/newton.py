from __future__ import annotations

import numpy as np


def _approximate_jacobian(fun, x, fx, diff_step):
    x = np.asarray(x, dtype=float).reshape(-1)
    fx = np.asarray(fx, dtype=float).reshape(-1)
    step_scale = diff_step * np.maximum(1.0, np.abs(x))
    jacobian = np.zeros((fx.size, x.size), dtype=float)

    for index, step in enumerate(step_scale):
        trial = x.copy()
        if step == 0.0:
            step = diff_step
        trial[index] += step
        jacobian[:, index] = (
            np.asarray(fun(trial), dtype=float).reshape(-1) - fx
        ) / step

    return jacobian


def newton_raphson(fun, x0, opts=None):
    options = opts or {}
    max_iter = int(options.get("MaxIter", max(10, np.size(x0) * 10)))
    diff_step = float(options.get("DiffStep", 1e-6))
    tolerance = float(options.get("TolFun", 1e-8))
    damping = float(options.get("Damping", 1.0))
    lower_bounds = options.get("LowerBounds", None)
    upper_bounds = options.get("UpperBounds", None)

    x = np.asarray(x0, dtype=float).reshape(-1)
    fx = np.asarray(fun(x), dtype=float).reshape(-1)
    exit_flag = 0

    for _ in range(max_iter):
        if np.linalg.norm(fx, ord=2) <= tolerance:
            exit_flag = 1
            break

        jacobian = _approximate_jacobian(fun, x, fx, diff_step)
        try:
            step = np.linalg.solve(jacobian, -fx)
        except np.linalg.LinAlgError:
            step, *_ = np.linalg.lstsq(jacobian, -fx, rcond=None)

        x = x + damping * step
        if lower_bounds is not None and upper_bounds is not None:
            lower = np.asarray(lower_bounds, dtype=float).reshape(-1)
            upper = np.asarray(upper_bounds, dtype=float).reshape(-1)
            x = np.minimum(np.maximum(x, lower), upper)
        fx = np.asarray(fun(x), dtype=float).reshape(-1)

    if np.linalg.norm(fx, ord=2) <= tolerance:
        exit_flag = 1

    return x, fx, exit_flag


__all__ = ["newton_raphson"]
