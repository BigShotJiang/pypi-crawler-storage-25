from pyrrmod.solvers.newton import newton_raphson
from pyrrmod.solvers.root_fallback import RootSolveResult, solve_root_with_retries
from pyrrmod.solvers.routed_numba import (
    run_numba_newton_kernel,
    run_routed_numba_newton_kernel_double,
    run_routed_numba_newton_kernel_single,
    run_routed_numba_newton_kernel_triple,
)

__all__ = [
    "newton_raphson",
    "RootSolveResult",
    "solve_root_with_retries",
    "run_numba_newton_kernel",
    "run_routed_numba_newton_kernel_double",
    "run_routed_numba_newton_kernel_single",
    "run_routed_numba_newton_kernel_triple",
]
