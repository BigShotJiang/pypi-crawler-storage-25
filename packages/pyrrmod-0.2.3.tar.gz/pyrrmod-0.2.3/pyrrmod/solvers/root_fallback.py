from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import fsolve, least_squares

from pyrrmod.solvers.newton import newton_raphson


@dataclass(slots=True)
class RootSolveResult:
    state: np.ndarray
    residual: np.ndarray
    residual_norm: float
    solver: str
    iterations: int
    nfev: int
    njev: int


def _clip_to_bounds(
    values: np.ndarray, lower: np.ndarray, upper: np.ndarray
) -> np.ndarray:
    return np.minimum(
        np.maximum(np.asarray(values, dtype=np.float64).reshape(-1), lower), upper
    )


def solve_root_with_retries(
    *,
    residual_fun,
    previous_state: np.ndarray,
    initial_guess: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    tolerance_scale: float,
    max_retries: int,
    lsq_max_nfev: int = 1000,
    newton_max_iter: int | None = None,
) -> RootSolveResult:
    previous = np.asarray(previous_state, dtype=np.float64).reshape(-1)
    guess = np.asarray(initial_guess, dtype=np.float64).reshape(-1)
    lower = np.asarray(lower_bounds, dtype=np.float64).reshape(-1)
    upper = np.asarray(upper_bounds, dtype=np.float64).reshape(-1)
    tolerance = float(tolerance_scale) * float(np.min(np.abs(previous))) + 1.0e-5
    retries = max(1, int(max_retries))

    def evaluate(values: np.ndarray) -> np.ndarray:
        return np.asarray(
            residual_fun(np.asarray(values, dtype=np.float64).reshape(-1)),
            dtype=np.float64,
        ).reshape(-1)

    newton_opts = {"MaxIter": int(max(1, newton_max_iter or previous.size * 10))}
    newton_root, newton_residual, _ = newton_raphson(evaluate, guess, newton_opts)
    best_state = _clip_to_bounds(newton_root, lower, upper)
    if np.any(best_state != np.asarray(newton_root, dtype=np.float64).reshape(-1)):
        best_residual = evaluate(best_state)
    else:
        best_residual = np.asarray(newton_residual, dtype=np.float64).reshape(-1)
    best_residual_norm = float(np.sum(best_residual**2))
    best_solver = "newton"
    best_iterations = int(newton_opts["MaxIter"])
    best_nfev = int(newton_opts["MaxIter"])
    best_njev = 0

    if best_residual_norm > tolerance:
        for attempt in range(1, retries + 1):
            if attempt == 1:
                x0 = best_state.copy()
            elif attempt == 2:
                x0 = previous.copy()
            elif attempt == 3:
                x0 = np.maximum(-2.0e4, lower)
            elif attempt == 4:
                x0 = np.minimum(2.0e4, upper)
            else:
                x0 = np.maximum(
                    0.0,
                    previous + np.random.randn(previous.shape[0]) * previous / 10.0,
                )
            x0 = _clip_to_bounds(x0, lower, upper)

            root, info, _, _ = fsolve(evaluate, x0, full_output=True)
            trial_state = _clip_to_bounds(root, lower, upper)
            if np.any(trial_state != np.asarray(root, dtype=np.float64).reshape(-1)):
                trial_residual = evaluate(trial_state)
            else:
                trial_residual = np.asarray(
                    info.get("fvec", evaluate(trial_state)), dtype=np.float64
                ).reshape(-1)
            trial_norm = float(np.sum(trial_residual**2))

            if trial_norm < best_residual_norm:
                best_state = trial_state
                best_residual = trial_residual
                best_residual_norm = trial_norm
                best_solver = "fsolve"
                best_iterations = int(attempt)
                best_nfev = int(info.get("nfev", 0))
                best_njev = int(info.get("njev", 0))
            if best_residual_norm <= tolerance:
                break

    if best_residual_norm > tolerance:
        for attempt in range(1, retries + 1):
            if attempt == 1:
                x0 = best_state.copy()
            elif attempt == 2:
                x0 = previous.copy()
            elif attempt == 3:
                x0 = np.maximum(-2.0e4, lower)
            elif attempt == 4:
                x0 = np.minimum(2.0e4, upper)
            else:
                x0 = np.maximum(
                    0.0,
                    previous + np.random.randn(previous.shape[0]) * previous / 10.0,
                )
            x0 = _clip_to_bounds(x0, lower, upper)

            lsq_result = least_squares(
                evaluate,
                x0,
                bounds=(lower, upper),
                method="trf",
                max_nfev=int(lsq_max_nfev),
            )
            trial_state = _clip_to_bounds(lsq_result.x, lower, upper)
            trial_residual = np.asarray(lsq_result.fun, dtype=np.float64).reshape(-1)
            if np.any(
                trial_state != np.asarray(lsq_result.x, dtype=np.float64).reshape(-1)
            ):
                trial_residual = evaluate(trial_state)
            trial_norm = float(np.sum(trial_residual**2))

            if trial_norm < best_residual_norm:
                best_state = trial_state
                best_residual = trial_residual
                best_residual_norm = trial_norm
                best_solver = "least_squares"
                best_iterations = int(attempt)
                best_nfev = int(lsq_result.nfev)
                best_njev = int(lsq_result.njev if lsq_result.njev is not None else 0)
            if best_residual_norm <= tolerance:
                break

    final_state = _clip_to_bounds(best_state, lower, upper)
    final_residual = evaluate(final_state)
    return RootSolveResult(
        state=final_state,
        residual=final_residual,
        residual_norm=float(np.linalg.norm(final_residual)),
        solver=best_solver,
        iterations=int(best_iterations),
        nfev=int(best_nfev),
        njev=int(best_njev),
    )


__all__ = ["RootSolveResult", "solve_root_with_retries"]
