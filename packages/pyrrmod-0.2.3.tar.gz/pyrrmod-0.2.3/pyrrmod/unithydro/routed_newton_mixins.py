from __future__ import annotations

from typing import Callable

import numpy as np

import numba
from pyrrmod.schemas import FloatArray, RuntimeContext, UnitHydroState
from pyrrmod.unithydro.unit_hydro_mixins import (
    DoubleUnitHydroMixin,
    SingleUnitHydroMixin,
    TripleUnitHydroMixin,
    UnitHydroMixin,
)


class RoutedNewtonMixin(UnitHydroMixin):
    routed_newton_use_predictor: bool = True
    routed_newton_clip_iterates: bool = True
    routed_newton_default_damping: float = 0.8
    routed_newton_default_diff_step: float = 1e-6
    routed_newton_default_maxiter: int = 50

    def _supports_routed_newton(self) -> bool:
        return (
            self.compiled_step_function is not None
            and self.compiled_commit_inflow_function is not None
        )

    def _make_routed_newton_step_kernel(
        self,
        step_fun: Callable[..., None],
        theta: FloatArray,
        delta_t: float,
        precip: FloatArray,
        pet: FloatArray,
        temp: FloatArray,
    ) -> Callable[..., None]:
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _make_routed_newton_step_kernel"
        )

    def _warmup_routed_newton_step_kernel(
        self,
        kernel: Callable[..., None],
        runtime: RuntimeContext,
        routing: UnitHydroState,
        warm_dS: FloatArray,
        warm_fluxes: FloatArray,
    ) -> None:
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _warmup_routed_newton_step_kernel"
        )

    def _run_routed_newton_kernel(
        self,
        common_args: tuple,
        routing: UnitHydroState,
    ) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray, FloatArray, FloatArray]:
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _run_routed_newton_kernel"
        )

    def _build_routed_newton_step_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[..., None]:
        if (
            self._routed_newton_step_kernel is not None
            and self._routed_newton_step_kernel_runtime is runtime
        ):
            return self._routed_newton_step_kernel

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        step_fun = self._get_or_compile_step_function(
            python_step_function=self.python_step_function,
            compiled_step_function=self.compiled_step_function,
        )

        kernel = self._make_routed_newton_step_kernel(
            step_fun,
            theta,
            delta_t,
            precip,
            pet,
            temp,
        )
        kernel = (
            kernel
            if hasattr(kernel, "nopython_signatures")
            else numba.njit(cache=False)(kernel)
        )
        warm_dS = np.empty(int(self.num_stores), dtype=np.float64)
        warm_fluxes = np.empty(int(self.num_fluxes), dtype=np.float64)
        self._warmup_routed_newton_step_kernel(
            kernel,
            runtime,
            routing,
            warm_dS,
            warm_fluxes,
        )
        self._routed_newton_step_kernel = kernel
        self._routed_newton_step_kernel_runtime = runtime
        return kernel

    def _run_routed_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None or self.stores is None or self.fluxes is None:
            raise RuntimeError("runtime context is not initialised")

        step_kernel = self._build_routed_newton_step_kernel(runtime)
        pattern = np.asarray(self.jacob_pattern, dtype=np.int64)
        if pattern.ndim == 1:
            pattern = pattern.reshape(1, -1)

        inflow_kernel = self.compiled_commit_inflow_function
        if inflow_kernel is None:
            raise RuntimeError("compiled_commit_inflow_function is not defined")

        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        common_args = (
            step_kernel,
            inflow_kernel,
            runtime.stores,
            runtime.fluxes,
            np.asarray(runtime.S0, dtype=np.float64),
            float(runtime.delta_t),
            np.asarray(runtime.store_min, dtype=np.float64),
            np.asarray(runtime.store_max, dtype=np.float64),
            float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
            int(
                self.solver_opts.get(
                    "resnorm_maxiter", self.routed_newton_default_maxiter
                )
            ),
            float(
                self.solver_opts.get("diff_step", self.routed_newton_default_diff_step)
            ),
            float(self.solver_opts.get("damping", self.routed_newton_default_damping)),
            pattern,
            bool(self.routed_newton_use_predictor),
            bool(self.routed_newton_clip_iterates),
        )

        stores, fluxes, resnorm, iterations, nfev, njev = (
            self._run_routed_newton_kernel(
                common_args,
                routing,
            )
        )

        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(
                int(runtime.precip.shape[0]), "numba_newton", dtype=object
            ),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }


class SingleRoutedNewtonMixin(SingleUnitHydroMixin, RoutedNewtonMixin):
    routing_line_count = 1

    def _make_routed_newton_step_kernel(
        self,
        step_fun: Callable[..., None],
        theta: FloatArray,
        delta_t: float,
        precip: FloatArray,
        pet: FloatArray,
        temp: FloatArray,
    ) -> Callable[..., None]:
        def kernel(
            states: FloatArray,
            step_index: int,
            uh_pending: FloatArray,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_pending,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _warmup_routed_newton_step_kernel(
        self,
        kernel: Callable[..., None],
        runtime: RuntimeContext,
        routing: UnitHydroState,
        warm_dS: FloatArray,
        warm_fluxes: FloatArray,
    ) -> None:
        kernel(
            np.asarray(runtime.S0, dtype=np.float64),
            0,
            routing.uh_pending,
            warm_dS,
            warm_fluxes,
        )

    def _run_routed_newton_kernel(
        self,
        common_args: tuple,
        routing: UnitHydroState,
    ) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray, FloatArray, FloatArray]:
        from pyrrmod.solvers.routed_numba import run_routed_numba_newton_kernel_single

        return run_routed_numba_newton_kernel_single(
            *common_args,
            routing.uh_weights,
            routing.uh_pending,
        )


class DoubleRoutedNewtonMixin(DoubleUnitHydroMixin, RoutedNewtonMixin):
    routing_line_count = 2

    def _make_routed_newton_step_kernel(
        self,
        step_fun: Callable[..., None],
        theta: FloatArray,
        delta_t: float,
        precip: FloatArray,
        pet: FloatArray,
        temp: FloatArray,
    ) -> Callable[..., None]:
        def kernel(
            states: FloatArray,
            step_index: int,
            uh1_pending: FloatArray,
            uh2_pending: FloatArray,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh1_pending,
                uh2_pending,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _warmup_routed_newton_step_kernel(
        self,
        kernel: Callable[..., None],
        runtime: RuntimeContext,
        routing: UnitHydroState,
        warm_dS: FloatArray,
        warm_fluxes: FloatArray,
    ) -> None:
        kernel(
            np.asarray(runtime.S0, dtype=np.float64),
            0,
            routing.uh1_pending,
            routing.uh2_pending,
            warm_dS,
            warm_fluxes,
        )

    def _run_routed_newton_kernel(
        self,
        common_args: tuple,
        routing: UnitHydroState,
    ) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray, FloatArray, FloatArray]:
        from pyrrmod.solvers.routed_numba import run_routed_numba_newton_kernel_double

        return run_routed_numba_newton_kernel_double(
            *common_args,
            routing.uh1_weights,
            routing.uh1_pending,
            routing.uh2_weights,
            routing.uh2_pending,
        )


class TripleRoutedNewtonMixin(TripleUnitHydroMixin, RoutedNewtonMixin):
    routing_line_count = 3

    def _make_routed_newton_step_kernel(
        self,
        step_fun: Callable[..., None],
        theta: FloatArray,
        delta_t: float,
        precip: FloatArray,
        pet: FloatArray,
        temp: FloatArray,
    ) -> Callable[..., None]:
        def kernel(
            states: FloatArray,
            step_index: int,
            uh1_pending: FloatArray,
            uh2_pending: FloatArray,
            uh3_pending: FloatArray,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh1_pending,
                uh2_pending,
                uh3_pending,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _warmup_routed_newton_step_kernel(
        self,
        kernel: Callable[..., None],
        runtime: RuntimeContext,
        routing: UnitHydroState,
        warm_dS: FloatArray,
        warm_fluxes: FloatArray,
    ) -> None:
        kernel(
            np.asarray(runtime.S0, dtype=np.float64),
            0,
            routing.uh1_pending,
            routing.uh2_pending,
            routing.uh3_pending,
            warm_dS,
            warm_fluxes,
        )

    def _run_routed_newton_kernel(
        self,
        common_args: tuple,
        routing: UnitHydroState,
    ) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray, FloatArray, FloatArray]:
        from pyrrmod.solvers.routed_numba import run_routed_numba_newton_kernel_triple

        return run_routed_numba_newton_kernel_triple(
            *common_args,
            routing.uh1_weights,
            routing.uh1_pending,
            routing.uh2_weights,
            routing.uh2_pending,
            routing.uh3_weights,
            routing.uh3_pending,
        )


__all__ = [
    "DoubleRoutedNewtonMixin",
    "RoutedNewtonMixin",
    "SingleRoutedNewtonMixin",
    "TripleRoutedNewtonMixin",
]
