from __future__ import annotations

from typing import Any, Callable

import numpy as np

from pyrrmod.schemas import FloatArray, RuntimeContext, UnitHydroState
from pyrrmod.unithydro.core import commit_unit_hydro_inflows


class UnitHydroMixin:
    python_step_function: Callable[..., None] | None = None
    compiled_step_function: Callable[..., None] | None = None
    compiled_commit_inflow_function: Callable[..., Any] | None = None
    routing_line_count: int = 1

    def _resolve_routing_line_count(self, routing: UnitHydroState) -> int:
        line_count = int(routing.line_count)
        expected = int(self.routing_line_count)
        if expected not in (1, 2, 3):
            raise RuntimeError("routing_line_count must be 1, 2, or 3")
        if line_count != expected:
            raise RuntimeError(
                f"routing line count mismatch: expected {expected}, got {line_count}"
            )
        return expected

    def _require_routing_state(self, runtime: RuntimeContext | None) -> UnitHydroState:
        routing = runtime.routing_state if runtime is not None else self.routing_state
        if isinstance(routing, UnitHydroState):
            return routing
        raise RuntimeError(
            f"{self.__class__.__name__} routing state is not initialised"
        )

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _compute_into"
        )

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return self._finite_difference_residual_jacobian(
            states,
            previous_states,
            step_index,
            diff_step=diff_step,
            compute_dS=lambda trial, index, runtime: self._compute_into(
                trial,
                step_index=index,
                ctx=runtime,
            )[0],
        )

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
        solver_config=None,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _bind_kernel"
        )

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        if self.python_step_function is None:
            raise RuntimeError("python_step_function is not defined")
        return self._bind_kernel(self.python_step_function, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        step_fun = self._get_or_compile_step_function(
            python_step_function=self.python_step_function,
            compiled_step_function=self.compiled_step_function,
        )
        kernel = self._bind_kernel(step_fun, runtime)
        return self._compile_bound_kernel(runtime, kernel)

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        del t, y, ctx
        raise NotImplementedError(
            f"{self.__class__.__name__} does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        del ctx
        raise NotImplementedError(
            f"{self.__class__.__name__} does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def _routing_inflows_from_fluxes(
        self,
        routing: UnitHydroState,
        fluxes: FloatArray,
    ) -> tuple[float, ...]:
        inflow_fun = self.compiled_commit_inflow_function
        if inflow_fun is None:
            raise RuntimeError("compiled_commit_inflow_function is not defined")

        inflows = inflow_fun(np.asarray(fluxes, dtype=np.float64))
        if routing.line_count == 1:
            return (float(inflows),)
        if isinstance(inflows, tuple):
            return tuple(float(value) for value in inflows)
        values = np.asarray(inflows, dtype=np.float64).reshape(-1)
        return tuple(float(value) for value in values)

    def step(self) -> None:
        if self.fluxes is None:
            raise RuntimeError("model fluxes are not initialised")

        routing = self._require_routing_state(self.runtime_context)
        inflows = self._routing_inflows_from_fluxes(routing, self.fluxes[self.t])
        commit_unit_hydro_inflows(routing, inflows)
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()


class SingleUnitHydroMixin(UnitHydroMixin):
    routing_line_count = 1

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        if runtime is self.runtime_context and self._python_model_fun is not None:
            self._python_model_fun(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes
        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
        solver_config=None,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip, pet, temp = runtime.precip, runtime.pet, runtime.temp
        uh_pending = routing.uh_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_pending,
                out_states,
                out_fluxes,
            )

        return kernel


class DoubleUnitHydroMixin(UnitHydroMixin):
    routing_line_count = 2

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        if runtime is self.runtime_context and self._python_model_fun is not None:
            self._python_model_fun(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes
        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh1_pending,
            routing.uh2_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
        solver_config=None,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip, pet, temp = runtime.precip, runtime.pet, runtime.temp
        uh1_pending, uh2_pending = routing.uh1_pending, routing.uh2_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh1_pending,
                uh2_pending,
                out_states,
                out_fluxes,
            )

        return kernel


class TripleUnitHydroMixin(UnitHydroMixin):
    routing_line_count = 3

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        if runtime is self.runtime_context and self._python_model_fun is not None:
            self._python_model_fun(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes
        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh1_pending,
            routing.uh2_pending,
            routing.uh3_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
        solver_config=None,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        self._resolve_routing_line_count(routing)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip, pet, temp = runtime.precip, runtime.pet, runtime.temp
        uh1_pending = routing.uh1_pending
        uh2_pending = routing.uh2_pending
        uh3_pending = routing.uh3_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh1_pending,
                uh2_pending,
                uh3_pending,
                out_states,
                out_fluxes,
            )

        return kernel


__all__ = [
    "DoubleUnitHydroMixin",
    "SingleUnitHydroMixin",
    "TripleUnitHydroMixin",
    "UnitHydroMixin",
]
