from typing import Any, Callable, Self
import warnings

import numpy as np
from pydantic import ValidationError
from scipy.optimize import fsolve

import numba
from pyrrmod.schemas import (
    ClimateArrays,
    ClimateInput,
    CompilerState,
    FloatArray,
    ModelConfigInput,
    ModelRunInput,
    RuntimeContext,
    SolverOptionsInput,
    _as_float_array,
)
from pyrrmod.solvers.newton import newton_raphson
from pyrrmod.solvers.root_fallback import solve_root_with_retries


class HydrologyModel:
    def __init__(self) -> None:
        self.num_stores = 0
        self.num_fluxes = 0
        self.num_params = 0

        self.jacob_pattern: FloatArray | None = None
        self.par_ranges: FloatArray | None = None
        self.store_names: list[str] = []
        self.flux_names: list[str] = []
        self.param_names: list[str] = []
        self.param_descriptions: list[str] = []
        self.flux_groups: dict[str, Any] = {}
        self.StoreSigns: FloatArray | None = None

        self.theta: FloatArray | None = None
        self.delta_t: float | None = None
        self.S0: FloatArray | None = None
        self.solver_opts: dict[str, Any] = {}

        self.store_min: FloatArray = np.zeros(0, dtype=np.float64)
        self.store_max: FloatArray = np.zeros(0, dtype=np.float64)

        self.climate_arrays: ClimateArrays | None = None
        self.stores: FloatArray | None = None
        self.fluxes: FloatArray | None = None
        self.solver_data: dict[str, FloatArray] | None = None
        self.runtime_context: RuntimeContext | None = None

        self.status = 0
        self.t = 0
        self.routing_state: Any = None
        self.uhs: Any = None
        self._initial_routing_pending_total = 0.0

        self.compiler = CompilerState()
        self._python_model_fun: (
            Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
        ) = None
        self._compiled_numba_newton_kernel: (
            Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
        ) = None
        self._compiled_numba_newton_kernel_runtime: RuntimeContext | None = None
        self._routed_newton_step_kernel: Callable[..., None] | None = None
        self._routed_newton_step_kernel_runtime: RuntimeContext | None = None

    def init(self) -> None:
        pass

    def step(self) -> None:
        pass

    def _routing_pending_total(self) -> float:
        routing = self.routing_state
        pending_total = getattr(routing, "pending_total", None)
        if callable(pending_total):
            return float(pending_total())

        if self.uhs is None:
            return 0.0

        total = 0.0
        for item in self.uhs:
            if isinstance(item, (tuple, list)) and len(item) == 2:
                total += float(np.sum(np.asarray(item[1], dtype=np.float64)))
        return total

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return None

    def _uses_discrete_step_solver(self) -> bool:
        return False

    def _supports_routed_newton(self) -> bool:
        return False

    def _run_routed_newton(self, runtime: RuntimeContext) -> None:
        raise RuntimeError("routed newton is not available")

    def _supports_compiled_numba_newton(self) -> bool:
        return False

    def _run_compiled_numba_newton(self, runtime: RuntimeContext) -> None:
        raise RuntimeError("compiled numba newton is not available")

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        raise NotImplementedError

    def _as_state_vector(self, states: Any) -> FloatArray:
        return np.asarray(states, dtype=np.float64).reshape(-1)

    def _evaluate_step_outputs_into(
        self,
        states: Any,
        step_index: int,
        out_dS: FloatArray,
        out_fluxes: FloatArray,
        *,
        ctx: RuntimeContext | None = None,
    ) -> None:
        old_t = self.t
        try:
            self.t = int(step_index)
            dS, fluxes = self.model_fun(self._as_state_vector(states))
            out_dS[:] = np.asarray(dS, dtype=np.float64)
            out_fluxes[:] = np.asarray(fluxes, dtype=np.float64)
        finally:
            self.t = old_t

    def _writeback_state_and_fluxes(
        self,
        previous_states: FloatArray,
        solved_states: FloatArray,
        step_index: int,
    ) -> tuple[FloatArray, FloatArray]:
        dS = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        self._evaluate_step_outputs_into(
            solved_states,
            step_index,
            dS,
            fluxes,
            ctx=self.runtime_context,
        )
        state = np.asarray(previous_states, dtype=np.float64) + dS * float(
            self.runtime_context.delta_t
        )
        return np.asarray(state, dtype=np.float64), np.asarray(fluxes, dtype=np.float64)

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError(
                f"{self.__class__.__name__} requires theta, delta_t, and input_climate"
            )

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _warm_bound_kernel(
        self,
        runtime: RuntimeContext,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
    ) -> None:
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)

    def _compile_bound_kernel(
        self,
        runtime: RuntimeContext,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        compiled = (
            kernel
            if hasattr(kernel, "nopython_signatures")
            else numba.njit(cache=False)(kernel)
        )
        self._warm_bound_kernel(runtime, compiled)
        return compiled

    def _get_or_compile_step_function(
        self,
        *,
        python_step_function: Callable[..., None] | None,
        compiled_step_function: Callable[..., None] | None,
    ) -> Callable[..., None]:
        source = (
            compiled_step_function
            if compiled_step_function is not None
            else python_step_function
        )
        if source is None:
            raise RuntimeError("python_step_function is not defined")

        cls = type(self)
        cached = getattr(cls, "_cached_compiled_step_function", None)
        cached_source = getattr(cls, "_cached_compiled_step_source", None)
        if cached is not None and cached_source is source:
            return cached

        compiled = (
            source
            if hasattr(source, "nopython_signatures")
            else numba.njit(cache=True)(source)
        )
        setattr(cls, "_cached_compiled_step_source", source)
        setattr(cls, "_cached_compiled_step_function", compiled)
        return compiled

    def _finite_difference_residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
        compute_dS: Callable[[FloatArray, int, RuntimeContext], FloatArray],
    ) -> FloatArray | None:
        runtime = self.runtime_context
        if runtime is None or self.jacob_pattern is None:
            return None

        state_vector = self._as_state_vector(states)
        previous_vector = self._as_state_vector(previous_states)
        if state_vector.size != int(self.num_stores) or previous_vector.size != int(
            self.num_stores
        ):
            return None

        pattern = np.asarray(self.jacob_pattern, dtype=np.int64)
        if pattern.ndim == 1:
            pattern = pattern.reshape(1, -1)

        base_dS = np.asarray(
            compute_dS(state_vector, int(step_index), runtime),
            dtype=np.float64,
        )
        base_residual = (state_vector - previous_vector) / float(
            runtime.delta_t
        ) - base_dS
        jacobian = np.zeros(
            (int(self.num_stores), int(self.num_stores)),
            dtype=np.float64,
        )

        for col_index in range(int(self.num_stores)):
            if not np.any(pattern[:, col_index] != 0):
                continue

            perturbed = state_vector.copy()
            step = diff_step * max(abs(float(state_vector[col_index])), 1.0)
            perturbed[col_index] = perturbed[col_index] + step
            perturbed = np.minimum(
                np.maximum(perturbed, runtime.store_min),
                runtime.store_max,
            )
            effective_step = float(perturbed[col_index] - state_vector[col_index])
            if effective_step == 0.0:
                effective_step = step

            trial_dS = np.asarray(
                compute_dS(perturbed, int(step_index), runtime),
                dtype=np.float64,
            )
            trial_residual = (perturbed - previous_vector) / float(
                runtime.delta_t
            ) - trial_dS

            for row_index in range(int(self.num_stores)):
                if pattern[row_index, col_index] != 0:
                    jacobian[row_index, col_index] = (
                        trial_residual[row_index] - base_residual[row_index]
                    ) / effective_step

        return jacobian

    def validate_run_payload(self, payload: Any) -> ModelRunInput:
        return ModelRunInput.model_validate(payload)

    def _format_mcp_error(self, exc: Exception) -> dict[str, Any]:
        if isinstance(exc, ValidationError):
            category = "payload_error"
            details = exc.errors()
        elif isinstance(exc, RuntimeError):
            category = "simulation_error"
            details = {"message": str(exc)}
        else:
            category = "configuration_error"
            details = {"message": str(exc)}

        return {
            "ok": False,
            "error": {
                "category": category,
                "type": exc.__class__.__name__,
                "message": str(exc),
                "details": details,
            },
        }

    def _reset_store_bounds(self) -> None:
        self.store_min = np.zeros(self.num_stores, dtype=np.float64)
        self.store_max = np.full(self.num_stores, np.inf, dtype=np.float64)

    def _resolve_config(
        self, config: Any
    ) -> tuple[ModelConfigInput | ModelRunInput | None, FloatArray | None]:
        if config is None:
            return None, None
        if isinstance(config, ModelRunInput):
            return config, config.theta
        if isinstance(config, ModelConfigInput):
            return config, None
        if isinstance(config, dict) and "theta" in config:
            parsed = ModelRunInput.model_validate(config)
            return parsed, parsed.theta
        parsed = ModelConfigInput.model_validate(config)
        return parsed, None

    def configure(
        self,
        *,
        config: Any | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: Any | None = None,
        solver_opts: Any | None = None,
        compile_target: str | None = None,
    ) -> Self:
        parsed_config, parsed_theta = self._resolve_config(config)

        if parsed_config is not None:
            delta_t = float(parsed_config.delta_t)
            S0 = np.asarray(parsed_config.S0, dtype=np.float64)
            input_climate = parsed_config.input_climate
            if parsed_config.solver_opts is not None:
                solver_opts = parsed_config.solver_opts.model_dump()
            if compile_target is None:
                compile_target = parsed_config.compile_target

        if parsed_theta is not None and theta is None:
            theta = parsed_theta

        if theta is not None:
            self.theta = _as_float_array(theta, field_name="theta")
        if delta_t is not None:
            self.delta_t = float(delta_t)
        if S0 is not None:
            self.S0 = _as_float_array(S0, field_name="S0")

        if input_climate is not None:
            climate = (
                input_climate
                if isinstance(input_climate, ClimateInput)
                else ClimateInput.model_validate(input_climate)
            )
            self.climate_arrays = ClimateArrays(
                precip=np.asarray(climate.precip, dtype=np.float64),
                temp=np.asarray(climate.temp, dtype=np.float64),
                pet=np.asarray(climate.pet, dtype=np.float64),
            )

        if (
            self.theta is None
            or self.delta_t is None
            or self.S0 is None
            or self.climate_arrays is None
        ):
            raise RuntimeError(
                "configure requires theta, delta_t, S0, and input_climate"
            )

        if int(self.theta.shape[0]) != int(self.num_params):
            raise ValueError(f"theta length must be {self.num_params}")
        if int(self.S0.shape[0]) != int(self.num_stores):
            raise ValueError(f"S0 length must be {self.num_stores}")

        n_steps = int(self.climate_arrays.precip.shape[0])
        self.stores = np.zeros((n_steps, self.num_stores), dtype=np.float64)
        self.fluxes = np.zeros((n_steps, self.num_fluxes), dtype=np.float64)

        self._reset_store_bounds()
        self.routing_state = None
        self.uhs = None
        self._initial_routing_pending_total = 0.0
        if self.StoreSigns is None or int(self.StoreSigns.shape[0]) != int(
            self.num_stores
        ):
            self.StoreSigns = np.ones(self.num_stores, dtype=np.float64)

        self.init()
        self._initial_routing_pending_total = self._routing_pending_total()
        if int(self.store_min.shape[0]) != int(self.num_stores) or int(
            self.store_max.shape[0]
        ) != int(self.num_stores):
            raise RuntimeError("store bounds must match num_stores")

        solver_dict: dict[str, Any]
        if solver_opts is None:
            solver_dict = {}
        elif isinstance(solver_opts, SolverOptionsInput):
            solver_dict = solver_opts.model_dump()
        else:
            solver_dict = SolverOptionsInput.model_validate(solver_opts).model_dump()
        self.solver_opts = solver_dict

        self.runtime_context = RuntimeContext(
            theta=np.asarray(self.theta, dtype=np.float64),
            delta_t=float(self.delta_t),
            S0=np.asarray(self.S0, dtype=np.float64),
            precip=np.asarray(self.climate_arrays.precip, dtype=np.float64),
            temp=np.asarray(self.climate_arrays.temp, dtype=np.float64),
            pet=np.asarray(self.climate_arrays.pet, dtype=np.float64),
            climate=self.climate_arrays,
            stores=self.stores,
            fluxes=self.fluxes,
            solver_opts=self.solver_opts,
            store_min=np.asarray(self.store_min, dtype=np.float64),
            store_max=np.asarray(self.store_max, dtype=np.float64),
            routing_state=self.routing_state,
        )
        self._routed_newton_step_kernel = None
        self._routed_newton_step_kernel_runtime = None
        self._compiled_numba_newton_kernel = None
        self._compiled_numba_newton_kernel_runtime = None

        requested = "auto" if compile_target is None else str(compile_target)
        self.compile_model_fun(target=requested)
        return self

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        raise NotImplementedError

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        return None

    def compile_model_fun(self, target: str = "auto") -> str:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("configure must be called before compile_model_fun")

        requested = str(target)
        self._python_model_fun = self.build_python_kernel(runtime)
        self.compiler = CompilerState(
            requested_target=requested,
            target="python",
            enabled=False,
            detail="python kernel",
            compiled_model_fun=None,
        )

        if requested == "python":
            return self.compiler.target

        if requested not in {"auto", "numba"}:
            raise ValueError("compile target must be one of: auto, python, numba")

        try:
            compiled = self.build_numba_model_fun(runtime)
            if compiled is None:
                raise RuntimeError("numba kernel not provided")
            self.compiler.target = "numba"
            self.compiler.enabled = True
            self.compiler.compiled_model_fun = compiled
            self.compiler.detail = "numba kernel"
        except Exception as exc:
            self.compiler.target = "python"
            self.compiler.enabled = False
            self.compiler.compiled_model_fun = None
            self.compiler.detail = f"compiled model unavailable: {exc}"
            if requested == "numba":
                warnings.warn(
                    f"Numba requested but compiled model unavailable; using python kernel ({exc})",
                    RuntimeWarning,
                )

        return self.compiler.target

    def _evaluate_step_into(
        self,
        states: FloatArray,
        step_index: int,
        out_dS: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if kernel is None:
            raise RuntimeError("model kernel is not initialised")
        kernel(states, int(step_index), out_dS, out_fluxes)

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        raise NotImplementedError

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        del t, ctx
        state_vector = self._as_state_vector(states)
        dS = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        index = self.t if step_index is None else int(step_index)
        self._evaluate_step_into(state_vector, index, dS, fluxes)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        runtime = self.runtime_context if ctx is None else ctx
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        step = int(max(0, min(runtime.precip.shape[0] - 1, int(t / runtime.delta_t))))
        old_t = self.t
        try:
            self.t = step
            dS, _ = self.model_fun(self._as_state_vector(y))
            return np.asarray(dS, dtype=np.float64)
        finally:
            self.t = old_t

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        if bool(self.solver_opts.get("retry_solver", True)):
            return self._fsolve_step_with_retries(previous_states, step_index)

        delta_t = float(runtime.delta_t)
        previous_states = np.asarray(previous_states, dtype=np.float64).reshape(-1)

        def residual(trial: FloatArray) -> FloatArray:
            dS, _ = self.model_fun(trial)
            return (trial - previous_states) / delta_t - np.asarray(
                dS, dtype=np.float64
            )

        diff_step = float(self.solver_opts.get("diff_step", 1e-6))

        def fprime(trial: FloatArray) -> FloatArray:
            jac = self.residual_jacobian(
                trial,
                previous_states,
                step_index,
                diff_step=diff_step,
            )
            if jac is None:
                raise RuntimeError("residual Jacobian is not available")
            return np.asarray(jac, dtype=np.float64)

        use_jacobian = self.residual_jacobian(
            previous_states,
            previous_states,
            step_index,
            diff_step=diff_step,
        )
        if use_jacobian is None:
            root, info, _, _ = fsolve(residual, previous_states, full_output=True)
        else:
            root, info, _, _ = fsolve(
                residual,
                previous_states,
                fprime=fprime,
                full_output=True,
            )

        trial_state = np.asarray(root, dtype=np.float64)
        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        _, fluxes = self.model_fun(trial_state)
        residual_norm = float(
            np.linalg.norm(np.asarray(residual(trial_state), dtype=np.float64))
        )
        nfev = int(info.get("nfev", 0))
        njev = int(info.get("njev", 0))
        return (
            trial_state,
            np.asarray(fluxes, dtype=np.float64),
            residual_norm,
            nfev,
            njev,
        )

    def _solve_with_retries(
        self,
        *,
        residual_fun,
        previous_state: FloatArray,
        lower_bounds: FloatArray,
        upper_bounds: FloatArray,
    ):
        return solve_root_with_retries(
            residual_fun=residual_fun,
            previous_state=np.asarray(previous_state, dtype=np.float64).reshape(-1),
            initial_guess=np.asarray(previous_state, dtype=np.float64).reshape(-1),
            lower_bounds=np.asarray(lower_bounds, dtype=np.float64).reshape(-1),
            upper_bounds=np.asarray(upper_bounds, dtype=np.float64).reshape(-1),
            tolerance_scale=float(self.solver_opts.get("resnorm_tolerance", 0.1)),
            max_retries=int(self.solver_opts.get("resnorm_maxiter", 6)),
            lsq_max_nfev=1000,
            newton_max_iter=int(max(1, self.num_stores * 10)),
        )

    def _fsolve_step_with_retries(
        self,
        previous_states: FloatArray,
        step_index: int,
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        previous_vector = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        store_min = np.asarray(runtime.store_min, dtype=np.float64).reshape(-1)
        store_max = np.asarray(runtime.store_max, dtype=np.float64).reshape(-1)

        def residual(trial: FloatArray) -> FloatArray:
            trial_vector = np.asarray(trial, dtype=np.float64).reshape(-1)
            dS, _ = self.model_fun(trial_vector)
            return (trial_vector - previous_vector) / delta_t - np.asarray(
                dS, dtype=np.float64
            ).reshape(-1)

        result = self._solve_with_retries(
            residual_fun=residual,
            previous_state=previous_vector,
            lower_bounds=store_min,
            upper_bounds=store_max,
        )

        final_state = np.asarray(result.state, dtype=np.float64).reshape(-1)
        _, fluxes = self.model_fun(final_state)
        return (
            final_state,
            np.asarray(fluxes, dtype=np.float64).reshape(-1),
            float(result.residual_norm),
            int(result.nfev),
            int(result.njev),
        )

    def _newton_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        delta_t = float(runtime.delta_t)

        previous_states = np.asarray(previous_states, dtype=np.float64)

        def residual(trial: FloatArray) -> FloatArray:
            dS, _ = self.model_fun(trial)
            return (trial - previous_states) / delta_t - dS

        opts = {
            "MaxIter": int(self.solver_opts.get("resnorm_maxiter", 50)),
            "DiffStep": float(self.solver_opts.get("diff_step", 1e-6)),
            "TolFun": float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
            "Damping": float(self.solver_opts.get("damping", 1.0)),
            "LowerBounds": runtime.store_min,
            "UpperBounds": runtime.store_max,
        }
        root, residual_vec, _ = newton_raphson(residual, previous_states, opts)
        trial_state = np.asarray(root, dtype=np.float64)
        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        _, fluxes = self.model_fun(trial_state)
        residual_norm = float(
            np.linalg.norm(np.asarray(residual_vec, dtype=np.float64))
        )
        return (
            trial_state,
            np.asarray(fluxes, dtype=np.float64),
            residual_norm,
            int(opts["MaxIter"]),
            0,
        )

    def run(
        self,
        *,
        config: Any | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: Any | None = None,
        solver_opts: Any | None = None,
        compile_target: str | None = None,
        solver: str = "fsolve",
    ) -> Self:
        if (
            config is not None
            or theta is not None
            or delta_t is not None
            or S0 is not None
            or input_climate is not None
        ):
            self.configure(
                config=config,
                theta=theta,
                delta_t=delta_t,
                S0=S0,
                input_climate=input_climate,
                solver_opts=solver_opts,
                compile_target=compile_target,
            )

        if (
            self.runtime_context is None
            or self.stores is None
            or self.fluxes is None
            or self.S0 is None
        ):
            raise RuntimeError("model is not configured")

        if solver == "numba_newton" and self._supports_routed_newton():
            self._run_routed_newton(self.runtime_context)
            return self

        if solver == "numba_newton" and self._supports_compiled_numba_newton():
            try:
                self._run_compiled_numba_newton(self.runtime_context)
                return self
            except RuntimeError as exc:
                warnings.warn(
                    f"compiled numba_newton failed; using fsolve ({exc})",
                    RuntimeWarning,
                )
                solver = "fsolve"

        if solver == "numba_newton":
            warnings.warn(
                "numba_newton is unsupported for this model; using fsolve.",
                RuntimeWarning,
            )
            solver = "fsolve"

        if solver not in {"fsolve", "numba_newton"}:
            warnings.warn(
                f"unknown solver '{solver}'; using fsolve.",
                RuntimeWarning,
            )
            solver = "fsolve"

        n_steps = int(self.runtime_context.precip.shape[0])
        solver_name = np.full(n_steps, solver, dtype=object)
        resnorm = np.zeros(n_steps, dtype=np.float64)
        iteration_count = np.zeros(n_steps, dtype=np.int64)
        nfev = np.zeros(n_steps, dtype=np.int64)
        njev = np.zeros(n_steps, dtype=np.int64)
        for step_index in range(n_steps):
            if bool(self.solver_opts.get("retry_solver", True)):
                np.random.seed(13)
            self.t = step_index
            previous = (
                self.runtime_context.S0
                if step_index == 0
                else self.stores[step_index - 1, :]
            )

            if self._uses_discrete_step_solver() and solver in {
                "fsolve",
                "numba_newton",
            }:
                out_states = np.empty(self.num_stores, dtype=np.float64)
                out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
                self._advance_discrete_step(
                    previous, step_index, out_states, out_fluxes
                )
                state = np.asarray(out_states, dtype=np.float64)
                fluxes = np.asarray(out_fluxes, dtype=np.float64)
                rnorm = 0.0
                iters = 1
                eval_count = 1
                jac_count = 0
            elif solver == "fsolve":
                state, fluxes, rnorm, eval_count, jac_count = self._fsolve_step(
                    previous, step_index
                )
                iters = max(
                    1, min(eval_count, int(self.solver_opts.get("resnorm_maxiter", 50)))
                )
            else:
                raise ValueError("solver must be one of: fsolve, numba_newton")

            legacy_state_update = bool(
                self.solver_opts.get("legacy_state_update", True)
            )
            if legacy_state_update and not self._uses_discrete_step_solver():
                state, fluxes = self._writeback_state_and_fluxes(
                    np.asarray(previous, dtype=np.float64),
                    np.asarray(state, dtype=np.float64),
                    step_index,
                )

            self.stores[step_index, :] = state
            self.fluxes[step_index, :] = fluxes * float(self.runtime_context.delta_t)

            self.runtime_context.stores = self.stores
            self.runtime_context.fluxes = self.fluxes

            resnorm[step_index] = float(rnorm)
            iteration_count[step_index] = int(iters)
            nfev[step_index] = int(eval_count)
            njev[step_index] = int(jac_count)

            self.step()
            self.runtime_context.routing_state = self.routing_state

        self.status = 1
        self.solver_data = {
            "solver": solver_name,
            "resnorm": resnorm,
            "iterations": iteration_count,
            "nfev": nfev,
            "njev": njev,
        }
        return self

    def _resolve_group_flux(self, group_spec: Any) -> FloatArray:
        if self.fluxes is None:
            raise RuntimeError("run must be called first")
        if isinstance(group_spec, int):
            index = abs(group_spec) - 1
            series = np.asarray(self.fluxes[:, index], dtype=np.float64)
            return -series if group_spec < 0 else series
        if isinstance(group_spec, (list, tuple)):
            out = np.zeros(self.fluxes.shape[0], dtype=np.float64)
            for item in group_spec:
                out = out + self._resolve_group_flux(item)
            return out
        raise TypeError(f"unsupported flux group spec: {group_spec}")

    def get_streamflow(self) -> FloatArray:
        if "Q" not in self.flux_groups:
            raise RuntimeError("flux group 'Q' is not defined")
        return self._resolve_group_flux(self.flux_groups["Q"])

    def get_param_names(self) -> list[str]:
        return list(self.param_names)

    def get_param_descriptions(self) -> list[str]:
        return list(self.param_descriptions)

    def check_water_balance(self) -> float:
        if self.runtime_context is None or self.stores is None or self.S0 is None:
            raise RuntimeError("run must be called first")
        precip_total = float(
            np.sum(self.runtime_context.precip) * self.runtime_context.delta_t
        )
        outflux_total = 0.0
        for spec in self.flux_groups.values():
            outflux_total += float(np.sum(self._resolve_group_flux(spec)))
        final_state = np.asarray(self.stores[-1, :], dtype=np.float64)
        signs = np.asarray(self.StoreSigns, dtype=np.float64)
        delta_storage = float(np.sum((final_state - self.S0) * signs))
        routing_delta = self._routing_pending_total() - float(
            self._initial_routing_pending_total
        )
        return precip_total - outflux_total - delta_storage - routing_delta

    def get_output(self, nargout: int = 3):
        flux_output = {
            key: self._resolve_group_flux(spec)
            for key, spec in self.flux_groups.items()
            if key != "Exchange"
        }
        flux_internal = {
            name: np.asarray(self.fluxes[:, idx], dtype=np.float64)
            for idx, name in enumerate(self.flux_names)
        }
        store_internal = {
            name: np.asarray(self.stores[:, idx], dtype=np.float64)
            for idx, name in enumerate(self.store_names)
        }

        if nargout == 3:
            return flux_output, flux_internal, store_internal
        if nargout == 4:
            return (
                flux_output,
                flux_internal,
                store_internal,
                self.check_water_balance(),
            )
        if nargout == 5:
            return (
                flux_output,
                flux_internal,
                store_internal,
                self.check_water_balance(),
                self.solver_data,
            )
        raise ValueError("nargout must be 3, 4, or 5")

    def get_output_dict(
        self,
        *,
        include_flux_internal: bool = False,
        include_store_internal: bool = False,
        include_solver: bool = False,
        include_execution: bool = False,
    ) -> dict[str, Any]:
        if self.fluxes is None:
            raise RuntimeError("run must be called first")

        payload: dict[str, Any] = {
            "model": self.__class__.__name__,
            "status": int(self.status),
            "flux_groups": {
                k: self._resolve_group_flux(v)
                for k, v in self.flux_groups.items()
                if k != "Exchange"
            },
            "streamflow": self.get_streamflow(),
            "water_balance_error": float(self.check_water_balance()),
        }

        if include_flux_internal:
            payload["flux_internal"] = {
                name: np.asarray(self.fluxes[:, idx], dtype=np.float64)
                for idx, name in enumerate(self.flux_names)
            }
        if include_store_internal and self.stores is not None:
            payload["store_internal"] = {
                name: np.asarray(self.stores[:, idx], dtype=np.float64)
                for idx, name in enumerate(self.store_names)
            }
        if include_solver and self.solver_data is not None:
            payload["solver_data"] = self.solver_data
        if include_execution:
            payload["execution"] = {
                "requested_target": self.compiler.requested_target,
                "resolved_target": self.compiler.target,
                "compiler_detail": self.compiler.detail,
            }

        return payload

    def _to_json_safe(self, value: Any) -> Any:
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, dict):
            return {str(k): self._to_json_safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._to_json_safe(v) for v in value]
        return value

    def to_mcp_payload(self, **kwargs: Any) -> dict[str, Any]:
        return self._to_json_safe(self.get_output_dict(**kwargs))

    def run_from_payload(
        self,
        payload: Any,
        *,
        include_flux_internal: bool = False,
        include_store_internal: bool = False,
        include_solver: bool = False,
        include_execution: bool = False,
        solver: str = "fsolve",
    ) -> dict[str, Any]:
        run_input = (
            payload
            if isinstance(payload, ModelRunInput)
            else self.validate_run_payload(payload)
        )
        self.run(config=run_input, solver=solver)
        return self.to_mcp_payload(
            include_flux_internal=include_flux_internal,
            include_store_internal=include_store_internal,
            include_solver=include_solver,
            include_execution=include_execution,
        )


class StepKernelModel(HydrologyModel):
    python_step_function: Callable[..., None] | None = None
    compiled_step_function: Callable[..., None] | None = None
    numba_newton_use_predictor: bool = True
    numba_newton_clip_iterates: bool = True

    def _get_kernel_bind_args(
        self,
        runtime: RuntimeContext,
    ) -> tuple[FloatArray, float, FloatArray, FloatArray, FloatArray]:
        return (
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
        )

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta, delta_t, precip, pet, temp = self._get_kernel_bind_args(runtime)

        def kernel(
            states: FloatArray,
            step_index: int,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _warm_step_fun(
        self,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
        runtime: RuntimeContext,
    ) -> None:
        self._warm_bound_kernel(runtime, kernel)

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _evaluate_step_outputs_into(
        self,
        states: Any,
        step_index: int,
        out_dS: FloatArray,
        out_fluxes: FloatArray,
        *,
        ctx: RuntimeContext | None = None,
    ) -> None:
        self._compute_into(
            states,
            step_index=step_index,
            ctx=ctx,
            out_dS=out_dS,
            out_fluxes=out_fluxes,
        )

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        if self.python_step_function is None:
            raise RuntimeError("python_step_function is not defined")
        return self._bind_kernel(self.python_step_function, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        step_fun = self._get_or_compile_step_function(
            python_step_function=self.python_step_function,
            compiled_step_function=self.compiled_step_function,
        )
        kernel = self._bind_kernel(step_fun, runtime)
        return self._compile_bound_kernel(runtime, kernel)

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        if bool(self.solver_opts.get("retry_solver", True)):
            return self._fsolve_step_with_retries(previous_states, step_index)

        delta_t = float(runtime.delta_t)
        diff_step = float(self.solver_opts.get("diff_step", 1e-6))
        previous_vector = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        residual_buffer = np.empty(self.num_stores, dtype=np.float64)
        scratch_dS = np.empty(self.num_stores, dtype=np.float64)
        scratch_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        trial_dS = np.empty(self.num_stores, dtype=np.float64)
        trial_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        trial_residual = np.empty(self.num_stores, dtype=np.float64)
        jacobian = np.zeros((self.num_stores, self.num_stores), dtype=np.float64)
        perturbed = np.empty(self.num_stores, dtype=np.float64)

        pattern = self.jacob_pattern
        resolved_pattern: FloatArray | None
        if pattern is None:
            resolved_pattern = None
        else:
            resolved_pattern = np.asarray(pattern, dtype=np.int64)
            if resolved_pattern.ndim == 1:
                resolved_pattern = resolved_pattern.reshape(1, -1)

        def fill_residual(
            trial: FloatArray,
            out_residual: FloatArray,
            dS_buffer: FloatArray,
            flux_buffer: FloatArray,
        ) -> FloatArray:
            self._evaluate_step_outputs_into(
                trial,
                step_index,
                dS_buffer,
                flux_buffer,
                ctx=runtime,
            )
            np.subtract(
                np.asarray(trial, dtype=np.float64), previous_vector, out=out_residual
            )
            out_residual /= delta_t
            out_residual -= dS_buffer
            return out_residual

        def residual(trial: FloatArray) -> FloatArray:
            return fill_residual(trial, residual_buffer, scratch_dS, scratch_fluxes)

        if resolved_pattern is None:
            root, info, ier, _ = fsolve(residual, previous_vector, full_output=True)
        else:

            def fprime(trial: FloatArray) -> FloatArray:
                fill_residual(trial, residual_buffer, scratch_dS, scratch_fluxes)
                jacobian.fill(0.0)
                for col_index in range(int(self.num_stores)):
                    if not np.any(resolved_pattern[:, col_index] != 0):
                        continue
                    perturbed[:] = trial
                    step = diff_step * max(abs(float(perturbed[col_index])), 1.0)
                    perturbed[col_index] = perturbed[col_index] + step
                    perturbed[:] = np.minimum(
                        np.maximum(perturbed, runtime.store_min), runtime.store_max
                    )
                    effective_step = float(
                        perturbed[col_index] - float(trial[col_index])
                    )
                    if effective_step == 0.0:
                        effective_step = step
                    fill_residual(
                        perturbed,
                        trial_residual,
                        trial_dS,
                        trial_fluxes,
                    )
                    active_rows = resolved_pattern[:, col_index] != 0
                    jacobian[active_rows, col_index] = (
                        trial_residual[active_rows] - residual_buffer[active_rows]
                    ) / effective_step
                return jacobian

            root, info, ier, _ = fsolve(
                residual,
                previous_vector,
                fprime=fprime,
                full_output=True,
            )

        trial_state = np.asarray(root, dtype=np.float64)
        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        self._evaluate_step_outputs_into(
            trial_state,
            step_index,
            scratch_dS,
            scratch_fluxes,
            ctx=runtime,
        )
        residual_norm = float(
            np.linalg.norm(
                fill_residual(trial_state, residual_buffer, scratch_dS, scratch_fluxes)
            )
        )
        nfev = int(info.get("nfev", 0))
        njev = int(info.get("njev", 0))
        _ = int(ier)
        return (
            trial_state,
            np.asarray(scratch_fluxes, dtype=np.float64),
            residual_norm,
            nfev,
            njev,
        )

    def _fsolve_step_with_retries(
        self,
        previous_states: FloatArray,
        step_index: int,
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        previous_vector = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        store_min = np.asarray(runtime.store_min, dtype=np.float64).reshape(-1)
        store_max = np.asarray(runtime.store_max, dtype=np.float64).reshape(-1)

        scratch_dS = np.empty(self.num_stores, dtype=np.float64)
        scratch_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        residual_buffer = np.empty(self.num_stores, dtype=np.float64)

        def _evaluate_residual(trial: FloatArray) -> FloatArray:
            trial_vector = np.asarray(trial, dtype=np.float64).reshape(-1)
            self._evaluate_step_outputs_into(
                trial_vector,
                step_index,
                scratch_dS,
                scratch_fluxes,
                ctx=runtime,
            )
            np.subtract(trial_vector, previous_vector, out=residual_buffer)
            np.divide(residual_buffer, float(runtime.delta_t), out=residual_buffer)
            np.subtract(residual_buffer, scratch_dS, out=residual_buffer)
            return residual_buffer.copy()

        result = self._solve_with_retries(
            residual_fun=_evaluate_residual,
            previous_state=previous_vector,
            lower_bounds=store_min,
            upper_bounds=store_max,
        )
        final_state = np.asarray(result.state, dtype=np.float64)
        self._evaluate_step_outputs_into(
            final_state,
            step_index,
            scratch_dS,
            scratch_fluxes,
            ctx=runtime,
        )
        return (
            final_state,
            np.asarray(scratch_fluxes, dtype=np.float64),
            float(result.residual_norm),
            int(result.nfev),
            int(result.njev),
        )

    def _supports_compiled_numba_newton(self) -> bool:
        return True

    def _run_compiled_numba_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None or self.stores is None or self.fluxes is None:
            raise RuntimeError("runtime context is not initialised")

        from pyrrmod.solvers.routed_numba import run_numba_newton_kernel

        step_kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled and self.compiler.compiled_model_fun is not None
            else None
        )
        if (
            step_kernel is None
            and self._compiled_numba_newton_kernel is not None
            and self._compiled_numba_newton_kernel_runtime is runtime
        ):
            step_kernel = self._compiled_numba_newton_kernel
        if step_kernel is None:
            step_kernel = self.build_numba_model_fun(runtime)
        if step_kernel is None:
            raise RuntimeError("numba kernel is not available")
        self._compiled_numba_newton_kernel = step_kernel
        self._compiled_numba_newton_kernel_runtime = runtime

        pattern = self.jacob_pattern
        if pattern is None:
            jacobian_pattern = np.ones(
                (int(self.num_stores), int(self.num_stores)), dtype=np.int64
            )
        else:
            jacobian_pattern = np.asarray(pattern, dtype=np.int64)
            if jacobian_pattern.ndim == 1:
                jacobian_pattern = jacobian_pattern.reshape(1, -1)

        stores, fluxes, resnorm, iterations, nfev, njev, converged = (
            run_numba_newton_kernel(
                step_kernel,
                runtime.stores,
                runtime.fluxes,
                np.asarray(runtime.S0, dtype=np.float64),
                float(runtime.delta_t),
                np.asarray(runtime.store_min, dtype=np.float64),
                np.asarray(runtime.store_max, dtype=np.float64),
                float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
                int(self.solver_opts.get("resnorm_maxiter", 50)),
                float(self.solver_opts.get("diff_step", 1e-6)),
                float(self.solver_opts.get("damping", 1.0)),
                jacobian_pattern,
                bool(self.numba_newton_use_predictor),
                bool(self.numba_newton_clip_iterates),
            )
        )

        failed_steps = np.flatnonzero(np.asarray(converged, dtype=np.int64) == 0)
        if failed_steps.size > 0:
            failed_index = int(failed_steps[0])
            failed_resnorm = float(np.asarray(resnorm, dtype=np.float64)[failed_index])
            raise RuntimeError(
                f"non-UH numba_newton did not converge at step {failed_index} (resnorm={failed_resnorm:.3e})"
            )

        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(
                int(runtime.precip.shape[0]), "numba_newton", dtype=object
            ),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        scratch_dS = np.empty(self.num_stores, dtype=np.float64)
        scratch_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        return self._finite_difference_residual_jacobian(
            states,
            previous_states,
            step_index,
            diff_step=diff_step,
            compute_dS=lambda trial, index, runtime: self._compute_into(
                trial,
                step_index=index,
                ctx=runtime,
                out_dS=scratch_dS,
                out_fluxes=scratch_fluxes,
            )[0],
        )


__all__ = ["HydrologyModel", "StepKernelModel"]
