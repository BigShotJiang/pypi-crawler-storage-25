import numpy as np
from pyrrmod.fluxes.smooth_function import smooth_threshold_storage_logistic
import numba


@numba.njit(cache=True)
def baseflow_1(p1: float, S: float) -> float:
    """
    Calculate the outflow from a linear reservoir.

    Parameters
    ----------
    p1 : float
        Time scale parameter [d-1].
    S : float
        Current storage [mm].

    Returns
    -------
    float
        The calculated baseflow outflow.
    """
    out = p1 * S
    return out


@numba.njit(cache=True)
def baseflow_2(S, p1, p2, dt):
    """
    Flux function
    Description: Non-linear outflow from a reservoir
    Constraints: f <= S/dt, S >= 0 (prevents numerical issues with complex numbers)
    (Inputs): S - current storage [mm]
             p1 - time coefficient [d]
             p2 - exponential scaling parameter [-]
             dt - time step size [d]
    """
    out = min((1.0 / p1 * max(S, 0.0)) ** (1.0 / p2), max(S, 0.0) / dt)
    return out


@numba.njit(cache=True)
def baseflow_3(S, Smax):
    """
    Empirical non-linear outflow from a reservoir
    S: current storage [mm]
    Smax: maximum contributing storage [mm]
    """
    out = Smax ** (-4) / 4 * (S**5)
    return out


@numba.njit(cache=True)
def baseflow_4(p1: float, p2: float, S: float) -> float:
    """
    Calculates the exponential outflow from a deficit store.

    Parameters
    ----------
    p1 : float
        Base outflow rate [mm/d].
    p2 : float
        Exponent parameter [mm^-1].
    S : np.ndarray
        Current storage [mm].

    Returns
    -------
    float
        The calculated baseflow outflow.
    """
    out = p1 * np.exp(-p2 * S)
    return out


@numba.njit(cache=True)
def baseflow_5(p1, p2, S, Smax, dt):
    """
    Non-linear scaled outflow from a reservoir.

    Constraints: f <= S/dt
    Inputs:
        p1: base outflow rate [mm/d]
        p2: exponential scaling parameter [-]
        S: current storage [mm]
        Smax: maximum contributing storage [mm]
        dt: time step size [d]
    Output:
        out: scaled outflow from the reservoir
    """
    out = min(S / dt, p1 * ((max(S, 0.0) / Smax) ** p2))
    return out


@numba.njit(cache=True)
def baseflow_6(p1, p2, S, dt):
    """
    Quadratic outflow from a reservoir if a storage threshold is exceeded
    Constraints: f <= S/dt
    Inputs: p1 - linear scaling parameter [mm-1 d-1]
            p2 - threshold that must be exceeded for flow to occur [mm]
            S - current storage [mm]
    """
    out = min(S / dt, p1 * S**2) * (1 - smooth_threshold_storage_logistic(S, p2))
    return out


def baseflow_7(p1, p2, S, dt):
    """
    Flux function.

    Description: Non-linear outflow from a reservoir.

    Constraints: f <= S / dt
                 S >= 0

    Parameters:
    -----------
    p1 : float
        Time coefficient [d^-1].
    p2 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    dt : float
        Time step size [d].

    Returns:
    --------
    out : float
        Resulting flux.
    """
    out = min(S / dt, p1 * max(0, S) ** p2)
    return out


def baseflow_8(p1, p2, S, Smax):
    """
    Flux function for exponential scaled outflow from a deficit store
    Constraints: S <= Smax
    Inputs:
        p1: base outflow rate [mm/d]
        p2: exponential scaling parameter [-]
        S: current storage [mm]
        Smax: maximum contributing storage [mm]
    Returns:
        Computed outflow
    """
    import numpy as np

    out = p1 * (np.exp(p2 * min(1, max(S, 0) / Smax)) - 1)
    return out


@numba.njit(cache=True)
def baseflow_9(p1, p2, S):
    """
    Linear flow above a threshold

    Arguments:
    p1 : float - time coefficient [d-1]
    p2 : float - storage threshold for flow generation [mm]
    S : float - current storage [mm]

    Returns:
    out : float - resulting flow
    """
    out = p1 * max(0, S - p2)
    return out
