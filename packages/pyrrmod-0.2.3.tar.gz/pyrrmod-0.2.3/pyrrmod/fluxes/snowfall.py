import numpy as np
from pyrrmod.fluxes.smooth_function import smooth_threshold_temperature_logistic as sttl
import numba


@numba.njit(cache=True)
def snowfall_1(In, T, p1, r=0.01):
    """
    Calculates snowfall based on a temperature threshold.

    Parameters
    ----------
    In : float
        Incoming precipitation flux [mm/d].
    T : float
        Current temperature [°C].
    p1 : float
        Temperature threshold below which snowfall occurs [°C].
    args : float, optional
        Smoothing variable r (default is 0.01).

    Returns
    -------
    float
        Outgoing snowfall flux [mm/d].
    """
    return In * sttl(T, p1, r)


@numba.njit(cache=True)
def snowfall_2(In: float, T: float, p1: float, p2: float) -> float:
    """
    Calculates snowfall based on a temperature threshold interval.

    Parameters
    ----------
    In : float
        Incoming precipitation flux [mm/d].
    T : float
        Current temperature [°C].
    p1 : float
        Midpoint of the combined rain/snow interval [°C].
    p2 : float
        Length of the mixed snow/rain interval [°C].

    Returns
    -------
    float
        Snowfall amount [mm/d].
    """
    out = min(In, max(0, In * (p1 + 0.5 * p2 - T) / p2))
    return out
