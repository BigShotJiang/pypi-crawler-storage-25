import numba


@numba.njit(cache=True)
def recharge_1(p1, S, Smax, flux):
    """
    Recharge as a scaled fraction of the incoming flux.

    Arguments:
    p1: float - fraction of flux that is recharge [-]
    S: float - current storage [mm]
    Smax: float - maximum contributing storage [mm]
    flux: float - incoming flux [mm/d]

    Returns:
    out: float - recharge amount
    """
    out = p1 * (S / Smax) * flux
    return out


@numba.njit(cache=True)
def recharge_2(p1, S, Smax, flux):
    # Flux function
    # Description: Recharge as a non-linear scaling of incoming flux
    # Constraints: S >= 0
    # @(Inputs): p1 - recharge scaling non-linearity [-]
    #            S - current storage [mm]
    #            Smax - maximum contributing storage [mm]
    #            flux - incoming flux [mm/d]

    out = flux * ((max(S, 0) / Smax) ** p1)

    return out


@numba.njit(cache=True)
def recharge_3(p1, S):
    # WARRANTY. See <https://www.gnu.org/licenses/> for details.

    # Flux function
    # ------------------
    # Description:  Linear recharge
    # Constraints:  -
    # Inputs:    p1   - time coefficient [d-1]
    #            S    - current storage [mm]

    return p1 * S


def recharge_4(p1, S, dt):
    # Flux function
    # Description:  Constant recharge
    # Constraints:  f <= S/dt
    # @(Inputs):    p1   - time coefficient [d-1]
    #               S    - current storage [mm]
    #               dt   - time step size [d]
    out = min(p1, S / dt)
    return out


@numba.njit(cache=True)
def recharge_5(p1, p2, S1, S2):
    # Flux function
    # Description: Recharge to fulfil evaporation demand if the receiving store is below a threshold
    # Constraints: -
    # @(Inputs): p1 - time coefficient [d-1]
    #            p2 - storage threshold in S2 [mm]
    #            S1 - current storage in S1 [mm]
    #            S2 - current storage in S1 [mm]

    out = p1 * S1 * (1 - min(1, S2 / p2))

    return out


def recharge_6(p1, p2, S, dt):
    # Flux function
    # Description:  Recharge to fulfil evaporation demand if the receiving
    #               store is below a threshold
    # Constraints:  f <= S/dt
    #               S >= 0      prevents complex numbers
    # @(Inputs):    p1   - time coefficient [d-1]
    #               p2   - non-linear scaling [mm]
    #               S    - current storage [mm]
    #               dt   - time step size [d]

    out = min(max(S / dt, 0), p1 * max(S, 0) ** p2)

    return out


def recharge_7(p1, fin):
    """
    Constant recharge limited by incoming flux

    :param p1: maximum recharge rate [mm/d]
    :param fin: incoming flux [mm/d]
    :return: minimum of p1 and fin
    """
    out = min(p1, fin)
    return out


def recharge_8(p1, S, Smax, p2, dt):
    # Flux function
    # Description:  Recharge as non-linear scaling of incoming flux
    # Constraints:  f <= S/dt
    #               S >= 0
    # @(Inputs):    p1   - recharge scaling non-linearity [-]
    #               S    - current storage [mm]
    #               Smax - maximum contributing storage [mm]
    #               p2   - maximum flux rate [mm/d]
    #               dt   - time step size [d]

    out = min(p2 * ((max(S, 0) / Smax) ** p1), max(S / dt, 0))

    return out
