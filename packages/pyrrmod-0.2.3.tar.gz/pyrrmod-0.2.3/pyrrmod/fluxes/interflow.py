from pyrrmod.fluxes.smooth_function import smooth_threshold_storage_logistic
import numba
import numpy as np


@numba.njit(cache=True)
def interflow_1(p1, S, Smax, flux):
    # interflow based on incoming flux size
    out = p1 * S / Smax * flux
    return out


@numba.njit(cache=True)
def interflow_10(S, p1, p2, p3):
    # WARRANTY. See <https://www.gnu.org/licenses/> for details.

    # Flux function
    # ------------------
    # Description:  Scaled linear interflow if storage exceeds a threshold
    # Constraints:  f = 0, for S < p2
    # @(Inputs):    p1   - time coefficient [d-1]
    #               p2   - threshold for flow generation [mm]
    #               p3   - linear scaling parameter [-]
    #               S    - current storage [mm]'''

    out = p1 * max(0.0, S - p2) / p3

    return out


@numba.njit(cache=True)
def interflow_11(p1, p2, S, dt, r=0.01, e=5.0):
    """
    Flux function.

    Description: Constant interflow if storage exceeds a threshold.

    Constraints: f <= (S - p2) / dt

    Parameters:
    -----------
    p1 : float
        Interflow rate [mm/d].
    p2 : float
        Storage threshold for flow generation [mm].
    S : float
        Current storage [mm].
    dt : float
        Time step size [d].
    varargin : tuple
        Smoothing variables r (default 0.01) and e (default 5.00).

    Returns:
    --------
    out : float
        Resulting flux.
    """
    return min(p1, (S - p2) / dt) * (
        1.0 - smooth_threshold_storage_logistic(S, p2, r, e)
    )


def interflow_12(p1, p2, p3, S, Smax, dt):
    # interflow_12: interflow_3 with customization -> field capacity (FC) is lower

    # Flux function
    # ------------------
    # Description:  Non-linear interflow (variant) when current storage is over
    #               a threshold (FC) and zero otherwise
    # Constraints:  f <= S-FC
    #               S >= 0  - this avoids numerical issues with complex numbers
    #               p2*Smax = FC
    # @(Inputs):    p1   - time delay [d-1]
    #               p2   - field capacity coefficient[-]
    #               p3   - exponential scaling parameter [-]
    #               S    - current storage [mm]
    #               Smax - maximum storage [mm]
    #               dt   - time step size [d]

    out = (S > (p2 * Smax)) * (
        min(p1 * max((S - (p2 * Smax)), 0) ** (p3), max(S / dt, 0))
    )
    return out


@numba.njit(cache=True)
def interflow_2(p1, S, p2, dt):
    # Flux function
    # Description: Non-linear interflow
    # Constraints: f <= S, S >= 0 - this avoids numerical issues with complex numbers
    # Inputs: p1 - time delay [d-1], p2 - exponential scaling parameter [-], S - current storage [mm], dt - time step size [d]
    return min(p1 * max(S, 0) ** (1 + p2), max(S / dt, 0))


@numba.njit(cache=True)
def interflow_3(p1, p2, S, dt):
    # Flux function
    # Description: Non-linear interflow (variant)
    # Constraints: f <= S, S >= 0 (this avoids numerical issues with complex numbers)
    # Inputs: p1 - time delay [d-1]
    #         p2 - exponential scaling parameter [-]
    #         S - current storage [mm]
    #         dt - time step size [d]
    return min(p1 * max(S, 0.0) ** p2, max(S / dt, 0.0))


def interflow_4(p1, p2, S):
    # Flux function
    # Description: Combined linear and scaled quadratic interflow
    # Constraints: f <= S
    #              S >= 0 - prevents numerical issues with complex numbers
    # @(Inputs):   p1   - time coefficient [d-1]
    #              p2   - scaling factor [mm-1 d-1]
    #              S    - current storage [mm]

    return min(max(S, 0), p1 * max(S, 0) + p2 * max(S, 0) ** 2)


@numba.njit(cache=True)
def interflow_5(p1: float, S: float) -> float:
    """
    Calculates linear interflow.

    Parameters
    ----------
    p1 : float
        Time coefficient [d-1].
    S : float
        Current storage [mm].

    Returns
    -------
    float
        Linear interflow value.
    """
    out = p1 * S
    return out


def interflow_6(p1, p2, S1, S2, S2max):
    # Flux function
    # Description: Scaled linear interflow if a storage in the receiving store exceeds a threshold
    # Constraints: S2/S2max <= 1
    # Inputs: p1 - time coefficient [d-1]
    #         p2 - threshold as fractional storage in S2 [-]
    #         S1 - current storage in S1 [mm]
    #         S2 - current storage in S2 [mm]
    #         S2max - maximum storage in S2 [mm]

    out = (
        p1
        * S1
        * (min(1, S2 / S2max) - p2)
        / (1 - p2)
        * (1 - smooth_threshold_storage_logistic(S2 / S2max, p2))
    )
    return out


@numba.njit(cache=True)
def interflow_7(S, Smax, p1, p2, p3, dt):
    """
    Flux function
    Description: Non-linear interflow if storage exceeds a threshold
    Constraints: f <= (S - p1*Smax) / dt
                 S - p1*Smax >= 0 prevents numerical issues with complex numbers

    Inputs:
    - p1: storage threshold as fraction of Smax [-]
    - p2: time coefficient [d]
    - p3: exponential scaling parameter [-]
    - S: current storage [mm]
    - Smax: maximum storage [mm]
    - dt: time step size [d]
    """
    available = max(0.0, S - p1 * Smax)
    return min(max(0.0, available / dt), (available / p2) ** (1.0 / p3))


@numba.njit(cache=True)
def interflow_8(S, p1, p2):
    # Flux function
    # Description: Linear interflow if storage exceeds a threshold
    # Constraints: f = 0 for S < p2
    # Inputs: S - current storage [mm]
    #         p1 - time coefficient [d-1]
    #         p2 - storage threshold before flow occurs [mm]

    out = max(0.0, p1 * (S - p2))

    return out


@numba.njit(cache=True)
def interflow_9(S, p1, p2, p3, dt):
    # Non-linear interflow if storage exceeds a threshold
    # Constraints:  f <= S-p2
    #               S-p2 >= 0     prevents numerical issues with complex numbers
    # @(Inputs):    p1   - time coefficient [d-1]
    #               p2   - storage threshold for flow generation [mm]
    #               p3   - exponential scaling parameter [-]
    #               S    - current storage [mm]
    #               dt   - time step size [d]

    out = min(max((S - p2) / dt, 0.0), (p1 * max(S - p2, 0.0)) ** p3)
    return out
