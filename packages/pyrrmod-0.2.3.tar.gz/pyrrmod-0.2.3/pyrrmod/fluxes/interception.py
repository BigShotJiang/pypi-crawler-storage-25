import numpy as np
from pyrrmod.fluxes.smooth_function import smooth_threshold_storage_logistic as stsl
import numba


@numba.njit(cache=True)
def interception_1(In, S, Smax, r=0.01, e=5.0):
    """
    Interception excess when maximum capacity is reached.

    Parameters
    ----------
    In : np.ndarray
        Incoming flux [mm/d].
    S : np.ndarray
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    *args : float, optional
        Additional smoothing variables r and e.

    Returns
    -------
    np.ndarray
        Outgoing flux after interception [mm/d].
    """
    return In * (1.0 - stsl(S, Smax, r, e))


@numba.njit(cache=True)
def interception_2(In, p1):
    # Flux function
    # Description: Interception excess after a constant amount is intercepted
    # Constraints: - f >= 0
    # Inputs: In - incoming flux [mm/d]
    #            p1   - interception and evaporation capacity [mm/d]
    # Outputs: f - interception excess [mm/d]

    out = max(In - p1, 0)
    return out


@numba.njit(cache=True)
def interception_3(p1, In):
    """
    Interception excess after a fraction is intercepted

    Parameters:
    p1 : float
        Fraction throughfall [-]
    In : float
        Incoming flux [mm/day]

    Returns:
    out : float
        Interception excess
    """
    out = p1 * In
    return out


@numba.njit(cache=True)
def interception_4(p1, p2, t, tmax, In, dt):
    """
    Creates function for effective rainfall through interception.

    Parameters:
    p1 (float): mean throughfall fraction [-]
    p2 (float): timing of maximum throughfall fraction [d]
    t (float): current time step [-]
    tmax (float): duration of the seasonal cycle [d]
    In (float): incoming flux [mm/d]
    dt (float): time step size [d]

    Returns:
    float: the effective rainfall through interception
    """
    angle = 2.0 * np.pi * (t * dt - p2) / tmax
    out = max(0.0, p1 + (1.0 - p1) * np.cos(angle)) * In
    return out


def interception_5(p1, p2, In):
    # Flux function
    # ------------------
    # Description: Interception excess after a combined absolute amount and fraction are intercepted
    # Constraints: f >= 0
    # @(Inputs): p1 - fraction that is not throughfall [-]
    #            p2 - constant interception and evaporation [mm/d]
    #            In - incoming flux [mm/d]

    out = max(p1 * In - p2, 0)

    return out
