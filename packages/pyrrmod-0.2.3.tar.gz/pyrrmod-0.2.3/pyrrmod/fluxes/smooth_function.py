import numpy as np

import numba


@numba.njit(cache=True)
def smooth_threshold_storage_logistic(s, smax, r=0.01, e=5.0):
    """
    Logisitic smoother for storage threshold functions.

    Converted from MatLab to Python, 2024, RTI International
    WARRANTY. See <https://www.gnu.org/licenses/> for details.

    Smooths the transition of threshold functions of the form:
    Q = { P, if S = Smax
        { 0, if S < Smax

    By transforming the equation above to Q = f(P,S,Smax,e,r):
    Q = P * 1/ (1+exp((S-Smax+r*e*Smax)/(r*Smax)))

    Inputs:
    S       : current storage
    Smax    : maximum storage
    r       : smoothing parameter rho, default = 0.01
    e       : smoothing parameter e, default 5

    NOTE: this function only outputs the multiplier. This needs to be
    applied to the proper flux outside of this function.

    NOTE: can be applied for temperature thresholds as well (i.e. snow
    modules). This simply means that S becomes T, and Smax T0.
    """

    smax = max(0.0, smax)
    if r == 0.0:
        return 1.0 if s <= smax else 0.0

    if r * smax == 0.0:
        exponent = (s - smax + r * e * smax) / r
    else:
        exponent = (s - smax + r * e * smax) / (r * smax)

    if exponent >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp(exponent))


@numba.njit(cache=True)
def smooth_threshold_temperature_logistic(T, Tt, r=0.01):
    """
    Logistic smoother for temperature threshold functions.

    Smooths the transition of threshold functions of the form:
    Snowfall = { P, if T <  Tt
                { 0, if T >= Tt

    By transforming the equation above to Sf = f(P, T, Tt, r):
    Sf = P * 1 / (1 + exp((T - Tt) / r))

    Inputs:

    T       : current temperature
    Tt      : threshold temperature below which snowfall occurs
    r       : smoothing parameter rho, default = 0.01

    NOTE: this function only outputs the multiplier. This needs to be
    applied to the proper flux (P in Sf equation) outside of this function.
    """
    # Calculate multiplier
    # bug fix: 11July2024 - SAS - if else statement added to prevent overflow in np.exp term

    if r == 0.0:
        return 1.0 if T <= Tt else 0.0

    exponent = (T - Tt) / r
    if exponent >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp(exponent))
