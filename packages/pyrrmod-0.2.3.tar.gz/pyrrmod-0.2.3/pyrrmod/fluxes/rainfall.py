import numpy as np
from typing import Tuple, Optional
from pyrrmod.fluxes.smooth_function import smooth_threshold_temperature_logistic
import numba


@numba.njit(cache=True)
def rainfall_1(In, T, p1, r=0.01):
    """
    Rainfall based on temperature threshold.

    Parameters
    ----------
    In : np.ndarray
        Incoming precipitation flux [mm/d].
    T : np.ndarray
        Current temperature [°C].
    p1 : float
        Temperature threshold above which rainfall occurs [°C].
    r : Optional[float], default=0.01
        Smoothing variable.

    Returns
    -------
    np.ndarray
        Modified precipitation flux [mm/d].
    """

    out = In * (1 - smooth_threshold_temperature_logistic(T, p1, r))
    return out


@numba.njit(cache=True)
def rainfall_2(In, T, p1, p2):
    # Rainfall based on a temperature threshold interval
    # Constraints:  -
    # @(Inputs):    In   - incoming precipitation flux [mm/d]
    #               T    - current temperature [oC]
    #               p1   - midpoint of the combined rain/snow interval [oC]
    #               p2   - length of the mixed snow/rain interval [oC]

    out = min(In, max(0, In * (T - (p1 - 0.5 * p2)) / p2))
    return out
