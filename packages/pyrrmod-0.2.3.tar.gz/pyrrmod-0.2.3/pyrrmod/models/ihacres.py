from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    delay_hydrograph,
    half_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import evap_12, saturation_5, split_1
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import TripleRoutedNewtonMixin


def _ihacres_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh1_pending: FloatArray,
    uh2_pending: FloatArray,
    uh3_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    lp = float(theta[0])
    d = float(theta[1])
    p = float(theta[2])
    alpha = float(theta[3])

    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_12(S1, lp, Ep)
    flux_u = saturation_5(S1, d, p, P)
    flux_uq = split_1(alpha, flux_u)
    flux_us = split_1(1.0 - alpha, flux_u)
    flux_xq = route_uh_current_nb(uh1_pending)
    flux_xs = route_uh_current_nb(uh2_pending)
    flux_xt = route_uh_current_nb(uh3_pending)

    out_dS[0] = -P + flux_ea + flux_u

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_u
    out_fluxes[2] = flux_uq
    out_fluxes[3] = flux_us
    out_fluxes[4] = flux_xq
    out_fluxes[5] = flux_xs
    out_fluxes[6] = flux_xt


_ihacres_compute_step_numba = numba.njit(cache=True)(_ihacres_compute_step)


@numba.njit(cache=True)
def _ihacres_commit_inflow_nb(fluxes: FloatArray) -> tuple[float, float, float]:
    return fluxes[2], fluxes[3], fluxes[4] + fluxes[5]


class ihacres(TripleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_ihacres_compute_step)
    compiled_step_function = staticmethod(_ihacres_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_ihacres_commit_inflow_nb)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 7
        self.num_params = 7
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [1, 2000], [0, 10], [0, 1], [1, 700], [1, 700], [0, 119]],
            dtype=np.float64,
        )
        self.param_names = ['lp', 'd', 'p', 'alpha', 'tau_q', 'tau_s', 'tau_d']
        self.param_descriptions = [
            'Wilting point [mm]',
            'Threshold for flow generation [mm]',
            'Flow response non-linearity [-]',
            'Fast/slow flow division [-]',
            'Fast flow routing delay [d]',
            'Slow flow routing delay [d]',
            'Pure time delay of total flow [d]',
        ]
        self.store_names = ["S1"]
        self.flux_names = ["Ea", "u", "uq", "us", "xq", "xs", "Qt"]
        self.flux_groups = {"Ea": 1, "Q": 7}
        self.StoreSigns = np.array([-1.0], dtype=np.float64)

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        delta_t = float(self.delta_t)
        uh1, _ = half_hydrograph(float(theta[4]), delta_t, power=1.0)
        uh2, _ = half_hydrograph(float(theta[5]), delta_t, power=1.0)
        uh3, _ = delay_hydrograph(float(theta[6]), delta_t)
        routing_state = make_unit_hydro_state(uh1, uh2, uh3)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
