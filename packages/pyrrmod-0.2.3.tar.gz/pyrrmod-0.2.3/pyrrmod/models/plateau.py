from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    half_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    capillary_2,
    evap_4,
    infiltration_4,
    interception_2,
    saturation_1,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import SingleRoutedNewtonMixin


def _plateau_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    fmax = float(theta[0])
    dp = float(theta[1])
    sumax = float(theta[2])
    lp = float(theta[3])
    p = float(theta[4])
    c = float(theta[6])
    kp = float(theta[7])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pe = interception_2(P, dp)
    flux_ei = P - flux_pe
    flux_pi = infiltration_4(flux_pe, fmax)
    flux_pie = flux_pe - flux_pi
    flux_et = evap_4(Ep, p, S1, lp, sumax, delta_t)
    flux_c = capillary_2(c, S2, delta_t)
    flux_r = saturation_1(flux_pi + flux_c, S1, sumax)
    flux_qpgw = baseflow_1(kp, S2)
    flux_qpieo = route_uh_current_nb(uh_pending)

    out_dS[0] = flux_pi + flux_c - flux_et - flux_r
    out_dS[1] = flux_r - flux_c - flux_qpgw

    out_fluxes[0] = flux_pe
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_pie
    out_fluxes[3] = flux_pi
    out_fluxes[4] = flux_et
    out_fluxes[5] = flux_r
    out_fluxes[6] = flux_c
    out_fluxes[7] = flux_qpgw
    out_fluxes[8] = flux_qpieo


_plateau_compute_step_numba = numba.njit(cache=True)(_plateau_compute_step)


@numba.njit(cache=True)
def _plateau_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[2]


class plateau(SingleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_plateau_compute_step)
    compiled_step_function = staticmethod(_plateau_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_plateau_commit_inflow_nb)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 9
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 200],
                [0, 5],
                [1, 2000],
                [0.05, 0.95],
                [0, 1],
                [1, 120],
                [0, 4],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.param_names = ['fmax', 'dp', 'sumax', 'lp', 'p', 'tp', 'c', 'kp']
        self.param_descriptions = [
            'Fmax, maximum infiltration rate [mm/d]',
            'Dp, interception capacity [mm]',
            'SUmax, soil misture depth [mm]',
            'Swp, wilting point as fraction of Sumax [-]',
            'p, coefficient for moisture constrained evaporation [-]',
            'tp, time delay for routing [d]',
            'c, capillary rise [mm/d]',
            'kp, base flow time parameter [d-1]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["pe", "ei", "pie", "pi", "et", "r", "c", "qpgw", "qpieo"]
        self.flux_groups = {"Ea": [2, 5], "Q": [8, 9]}

    def init(self) -> None:
        weights, _ = half_hydrograph(
            float(self.theta[5]), float(self.delta_t), power=1.5
        )
        routing_state = make_unit_hydro_state(weights)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
