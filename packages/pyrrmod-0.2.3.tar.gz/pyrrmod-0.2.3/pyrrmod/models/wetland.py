from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_1, interception_2, saturation_2
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _wetland_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    dw = float(theta[0])
    betaw = float(theta[1])
    swmax = float(theta[2])
    kw = float(theta[3])

    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pe = interception_2(P, dw)
    flux_ei = P - flux_pe
    flux_ew = evap_1(S1, Ep, delta_t)
    flux_qwsof = saturation_2(S1, swmax, betaw, flux_pe)
    flux_qwgw = baseflow_1(kw, S1)

    out_dS[0] = flux_pe - flux_ew - flux_qwsof - flux_qwgw

    out_fluxes[0] = flux_pe
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_ew
    out_fluxes[3] = flux_qwsof
    out_fluxes[4] = flux_qwgw


class wetland(StepKernelModel):
    python_step_function = staticmethod(_wetland_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 5
        self.num_params = 4
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array(
            [[0, 5], [0, 10], [1, 2000], [0, 1]], dtype=np.float64
        )
        self.param_names = ['dw', 'betaw', 'swmax', 'kw']
        self.param_descriptions = [
            'Daily interception [mm]',
            'Soil moisture storage distribution parameter [-]',
            'Maximum soil moisture storage [mm]',
            'Runoff coefficient [d-1]',
        ]
        self.store_names = ["S1"]
        self.flux_names = ["pe", "ei", "ew", "qwsof", "qwgw"]
        self.flux_groups = {"Ea": [2, 3], "Q": [4, 5]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

