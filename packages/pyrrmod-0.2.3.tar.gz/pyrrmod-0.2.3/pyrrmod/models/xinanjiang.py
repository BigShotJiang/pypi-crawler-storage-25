from __future__ import annotations

import numpy as np

import numba
from pyrrmod.fluxes import (
    baseflow_1,
    evap_21,
    interflow_5,
    saturation_14,
    saturation_2,
    split_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray


def _xinanjiang_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    aim = float(theta[0])
    a = float(theta[1])
    b = float(theta[2])
    stot = float(theta[3])
    fwm = float(theta[4])
    flm = float(theta[5])
    c = float(theta[6])
    ex = float(theta[7])
    ki = float(theta[8])
    kg = float(theta[9])
    ci = float(theta[10])
    cg = float(theta[11])

    wmax = fwm * stot
    smax = (1.0 - fwm) * stot
    lm = flm * wmax

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_rb = split_1(aim, P)
    flux_pi = split_1(1.0 - aim, P)
    flux_e = evap_21(lm, c, S1, Ep, delta_t)
    flux_r = saturation_14(a, b, S1, wmax, flux_pi)
    flux_rs = saturation_2(S2, smax, ex, flux_r)
    flux_ri = saturation_2(S2, smax, ex, S2 * ki)
    flux_rg = saturation_2(S2, smax, ex, S2 * kg)
    flux_qs = flux_rb + flux_rs
    flux_qi = interflow_5(ci, S3)
    flux_qg = baseflow_1(cg, S4)

    out_dS[0] = flux_pi - flux_e - flux_r
    out_dS[1] = flux_r - flux_rs - flux_ri - flux_rg
    out_dS[2] = flux_ri - flux_qi
    out_dS[3] = flux_rg - flux_qg

    out_fluxes[0] = flux_rb
    out_fluxes[1] = flux_pi
    out_fluxes[2] = flux_e
    out_fluxes[3] = flux_r
    out_fluxes[4] = flux_rs
    out_fluxes[5] = flux_ri
    out_fluxes[6] = flux_rg
    out_fluxes[7] = flux_qs
    out_fluxes[8] = flux_qi
    out_fluxes[9] = flux_qg


_xinanjiang_compute_step_numba = numba.njit(cache=True)(_xinanjiang_compute_step)


class xinanjiang(StepKernelModel):
    python_step_function = staticmethod(_xinanjiang_compute_step)
    compiled_step_function = staticmethod(_xinanjiang_compute_step_numba)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 10
        self.num_params = 12
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [0, 1, 1, 0], [0, 1, 0, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [
                [0, 1],
                [-0.49, 0.49],
                [0, 10],
                [1, 2000],
                [0.01, 0.99],
                [0.01, 0.99],
                [0.01, 0.99],
                [0, 10],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.param_names = ['aim', 'a', 'b', 'stot', 'fwm', 'flm', 'c', 'ex', 'ki', 'kg', 'ci', 'cg']
        self.param_descriptions = [
            'aim,  Fraction impervious area [-]',
            'a,    Tension water distribution inflection parameter [-]',
            'b,    Tension water distribution shape parameter [-]',
            'stot, Total soil moisture storage (W+S) [mm]',
            'fwm,  Fraction of Stot that is Wmax [-]',
            'flm,  Fraction of wmax that is LM [-]',
            'c,    Fraction of LM for second evaporation change [-]',
            'ex,   Free water distribution shape parameter [-]',
            'ki,   Free water interflow parameter [d-1]',
            'kg,   Free water groundwater parameter [d-1]',
            'ci,   Interflow time coefficient [d-1]',
            'cg,   Baseflow time coefficient [d-1]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = ["rb", "pi", "e", "r", "rs", "ri", "rg", "qs", "qi", "qg"]
        self.flux_groups = {"Ea": 3, "Q": [8, 9, 10]}

    def init(self) -> None:
        pass

    def step(self) -> None:
        pass

