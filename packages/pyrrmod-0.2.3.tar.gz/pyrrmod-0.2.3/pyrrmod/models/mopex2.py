from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_7,
    melt_1,
    rainfall_1,
    recharge_3,
    saturation_1,
    snowfall_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _mopex2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tcrit = float(theta[0])
    ddf = float(theta[1])
    s2max = float(theta[2])
    tw = float(theta[3])
    tu = float(theta[4])
    se = float(theta[5])
    tc = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_ps = snowfall_1(P, T, tcrit)
    flux_pr = rainfall_1(P, T, tcrit)
    flux_qn = melt_1(ddf, tcrit, T, S1, delta_t)
    flux_et1 = evap_7(S2, s2max, Ep, delta_t)
    flux_q1f = saturation_1(flux_pr + flux_qn, S2, s2max)
    flux_qw = recharge_3(tw, S2)
    flux_et2 = evap_7(S3, se, Ep, delta_t)
    flux_q2u = baseflow_1(tu, S3)
    flux_qf = baseflow_1(tc, S4)
    flux_qs = baseflow_1(tc, S5)

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_et1 - flux_q1f - flux_qw
    out_dS[2] = flux_qw - flux_et2 - flux_q2u
    out_dS[3] = flux_q1f - flux_qf
    out_dS[4] = flux_q2u - flux_qs

    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pr
    out_fluxes[2] = flux_qn
    out_fluxes[3] = flux_et1
    out_fluxes[4] = flux_q1f
    out_fluxes[5] = flux_qw
    out_fluxes[6] = flux_et2
    out_fluxes[7] = flux_q2u
    out_fluxes[8] = flux_qf
    out_fluxes[9] = flux_qs


class mopex2(StepKernelModel):
    python_step_function = staticmethod(_mopex2_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 10
        self.num_params = 7
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [0, 1, 1, 0, 0],
                [0, 1, 0, 1, 0],
                [0, 0, 1, 0, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [[-3, 3], [0, 20], [1, 2000], [0, 1], [0, 1], [1, 2000], [0, 1]],
            dtype=np.float64,
        )
        self.param_names = ['tcrit', 'ddf', 's2max', 'tw', 'tu', 'se', 'tc']
        self.param_descriptions = [
            'tcrit, Snowfall & snowmelt temperature [oC]',
            'ddf, Degree-day factor for snowmelt [mm/oC/d]',
            'Sb1, Maximum soil moisture storage [mm]',
            'tw, Groundwater leakage time [d-1]',
            'tu, Slow flow routing response time [d-1]',
            'se, Root zone storage capacity [mm]',
            'tc, Mean residence time [d-1]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "ps",
            "pr",
            "qn",
            "et1",
            "q1f",
            "qw",
            "et2",
            "q2u",
            "qf",
            "qs",
        ]
        self.flux_groups = {"Ea": [4, 7], "Q": [9, 10]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

