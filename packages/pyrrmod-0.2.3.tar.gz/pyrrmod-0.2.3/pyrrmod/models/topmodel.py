from __future__ import annotations

import numpy as np

import numba
from pyrrmod.fluxes import (
    baseflow_4,
    evap_3,
    interflow_10,
    saturation_1,
    saturation_7,
    saturation_7_nb,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray


def _topmodel_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    suzmax = float(theta[0])
    st = float(theta[1])
    kd = float(theta[2])
    q0 = float(theta[3])
    f = float(theta[4])
    chi = float(theta[5])
    phi = float(theta[6])
    mu = 3.0
    lambda_ = chi * phi + mu

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_qof = saturation_7(chi, phi, 3, lambda_, f, S2, P)
    flux_peff = P - flux_qof
    flux_ea = evap_3(st, S1, suzmax, Ep, delta_t)
    flux_qex = saturation_1(flux_peff, S1, suzmax)
    flux_qv = interflow_10(S1, kd, st * suzmax, suzmax - st * suzmax)
    flux_qb = baseflow_4(q0, f, S2)

    out_dS[0] = flux_peff - flux_ea - flux_qex - flux_qv
    out_dS[1] = flux_qb - flux_qv

    out_fluxes[0] = flux_qof
    out_fluxes[1] = flux_peff
    out_fluxes[2] = flux_ea
    out_fluxes[3] = flux_qex
    out_fluxes[4] = flux_qv
    out_fluxes[5] = flux_qb


def _topmodel_compute_step_numba_impl(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    suzmax = float(theta[0])
    st = float(theta[1])
    kd = float(theta[2])
    q0 = float(theta[3])
    f = float(theta[4])
    chi = float(theta[5])
    phi = float(theta[6])
    mu = 3.0
    lambda_ = chi * phi + mu

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_qof = saturation_7_nb(chi, phi, 3, lambda_, f, S2, P)
    flux_peff = P - flux_qof
    flux_ea = evap_3(st, S1, suzmax, Ep, delta_t)
    flux_qex = saturation_1(flux_peff, S1, suzmax)
    flux_qv = interflow_10(S1, kd, st * suzmax, suzmax - st * suzmax)
    flux_qb = baseflow_4(q0, f, S2)

    out_dS[0] = flux_peff - flux_ea - flux_qex - flux_qv
    out_dS[1] = flux_qb - flux_qv

    out_fluxes[0] = flux_qof
    out_fluxes[1] = flux_peff
    out_fluxes[2] = flux_ea
    out_fluxes[3] = flux_qex
    out_fluxes[4] = flux_qv
    out_fluxes[5] = flux_qb


_topmodel_compute_step_numba = numba.njit(cache=True)(_topmodel_compute_step_numba_impl)


class topmodel(StepKernelModel):
    python_step_function = staticmethod(_topmodel_compute_step)
    compiled_step_function = staticmethod(_topmodel_compute_step_numba)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 6
        self.num_params = 7
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0, 1], [0.1, 200], [0, 1], [1, 7.5], [0.1, 5]],
            dtype=np.float64,
        )
        self.param_names = ['suzmax', 'st', 'kd', 'q0', 'f', 'chi', 'phi']
        self.param_descriptions = [
            'suzmax, Maximum soil moisture storage in unsaturated zone [mm]',
            'st, Threshold for flow generation and evap change as fraction of suzmax [-]',
            'kd, Leakage to saturated zone flow coefficient [mm/d]',
            'q0, Zero deficit base flow speed [mm/d]',
            'f, Baseflow scaling coefficient [mm-1]',
            'chi, Gamma distribution parameter [-]',
            'phi, Gamma distribution parameter [-]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["qof", "peff", "ea", "qex", "qv", "qb"]
        self.flux_groups = {"Ea": 3, "Q": [1, 4, 6]}
        self.StoreSigns = np.array([1.0, -1.0], dtype=np.float64)

    def init(self) -> None:
        pass
