from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    half_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    capillary_2,
    evap_1,
    interception_2,
    saturation_2,
    split_1,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import SingleRoutedNewtonMixin


def _hillslope_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    dw = float(theta[0])
    betaw = float(theta[1])
    swmax = float(theta[2])
    a = float(theta[3])
    c = float(theta[5])
    kh = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pe = interception_2(P, dw)
    flux_ei = P - flux_pe
    flux_ea = evap_1(S1, Ep, delta_t)
    flux_qse = saturation_2(S1, swmax, betaw, flux_pe)
    flux_qses = split_1(a, flux_qse)
    flux_qseg = split_1(1.0 - a, flux_qse)
    flux_c = capillary_2(c, S2, delta_t)
    flux_qhgw = baseflow_1(kh, S2)
    flux_qhsrf = route_uh_current_nb(uh_pending)
    flux_qt = flux_qhsrf + flux_qhgw

    out_dS[0] = flux_pe + flux_c - flux_ea - flux_qse
    out_dS[1] = flux_qseg - flux_c - flux_qhgw

    out_fluxes[0] = flux_pe
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_ea
    out_fluxes[3] = flux_qse
    out_fluxes[4] = flux_qses
    out_fluxes[5] = flux_qseg
    out_fluxes[6] = flux_c
    out_fluxes[7] = flux_qhgw
    out_fluxes[8] = flux_qhsrf
    out_fluxes[9] = flux_qt


_hillslope_compute_step_numba = numba.njit(cache=True)(_hillslope_compute_step)


@numba.njit(cache=True)
def _hillslope_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[4]


class hillslope(SingleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_hillslope_compute_step)
    compiled_step_function = staticmethod(_hillslope_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_hillslope_commit_inflow_nb)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 10
        self.num_params = 7
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[0, 5], [0, 10], [1, 2000], [0, 1], [1, 120], [0, 4], [0, 1]],
            dtype=np.float64,
        )
        self.param_names = ['dw', 'betaw', 'swmax', 'a', 'th', 'c', 'kh']
        self.param_descriptions = [
            'Dw, interception capacity [mm]',
            'Betaw, soil misture distribution parameter [-]',
            'Swmax, soil misture depth [mm]',
            'a, surface/groundwater division [-]',
            'th, time delay for routing [d]',
            'c, capillary rise [mm/d]',
            'kw, base flow time parameter [d-1]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = [
            "pe",
            "ei",
            "ea",
            "qse",
            "qses",
            "qseg",
            "c",
            "qhgw",
            "qhsrf",
            "qt",
        ]
        self.flux_groups = {"Ea": [2, 3], "Q": [10]}

    def init(self) -> None:
        weights, _ = half_hydrograph(
            float(self.theta[4]), float(self.delta_t), power=1.5
        )
        routing_state = make_unit_hydro_state(weights)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
