from __future__ import annotations

import numpy as np

from pyrrmod.fluxes import (
    baseflow_2,
    evap_3,
    evap_7,
    interflow_9,
    saturation_1,
    split_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray


def _collie3_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    S1max = float(theta[0])
    Sfc = float(theta[1])
    a = float(theta[2])
    M = float(theta[3])
    b = float(theta[4])
    lambda_ = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_eb = evap_7(S1, S1max, (1.0 - M) * Ep, delta_t)
    flux_ev = evap_3(Sfc, S1, S1max, M * Ep, delta_t)
    flux_qse = saturation_1(P, S1, S1max)
    flux_qss = interflow_9(S1, a, Sfc * S1max, b, delta_t)
    flux_qsss = split_1(lambda_, flux_qss)
    flux_qsg = baseflow_2(S2, 1.0 / a, 1.0 / b, delta_t)
    flux_qt = flux_qse + (1.0 - lambda_) * flux_qss + flux_qsg

    out_dS[0] = P - flux_eb - flux_ev - flux_qse - flux_qss
    out_dS[1] = flux_qsss - flux_qsg

    out_fluxes[0] = flux_eb
    out_fluxes[1] = flux_ev
    out_fluxes[2] = flux_qse
    out_fluxes[3] = flux_qss
    out_fluxes[4] = flux_qsss
    out_fluxes[5] = flux_qsg
    out_fluxes[6] = flux_qt


class collie3(StepKernelModel):
    python_step_function = staticmethod(_collie3_compute_step)

    def __init__(self, delta_t=None, theta=None):
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 7
        self.num_params = 6
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0.05, 0.95],
                [0, 1],
                [0.05, 0.95],
                [1, 5],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.param_names = ['S1max', 'Sfc', 'a', 'M', 'b', 'lambda_']
        self.param_descriptions = [
            'Smax [mm]',
            'fc as fraction of Smax [-]',
            'a, subsurface runoff coefficient [d-1]',
            'M, fraction forest cover [-]',
            'b, flow non-linearity [-]',
            'lambda, flow distribution [-]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["eb", "ev", "qse", "qss", "qsss", "qsg", "qt"]
        self.flux_groups = {"Ea": [1, 2], "Q": 7}

        if delta_t is not None:
            self.delta_t = delta_t
        if theta is not None:
            self.theta = theta

    def init(self) -> None:
        pass

