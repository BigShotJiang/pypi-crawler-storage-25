from __future__ import annotations

import numpy as np
import numba

from pyrrmod.fluxes import (
    abstraction_1,
    baseflow_1,
    baseflow_6,
    effective_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext
from pyrrmod.solvers.scalar_root import solve_scalar_fsolve_bracketed


def _tcm_prepare_theta(theta: FloatArray, precip: FloatArray) -> FloatArray:
    prepared = np.empty(theta.size + 1, dtype=np.float64)
    prepared[: theta.size] = theta
    prepared[theta.size] = float(theta[4]) * float(np.mean(precip))
    return prepared


def _tcm_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    phi = float(theta[0])
    rc = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])
    k2 = float(theta[5])
    ca = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = effective_1(P, Ep)
    flux_en = P - flux_pn
    flux_pby = split_1(phi, flux_pn)
    flux_pin = split_1(1.0 - phi, flux_pn)
    flux_ea = evap_1(S1, Ep, delta_t)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_qex1 = saturation_1(flux_pin, S1, rc)
    flux_qex2 = saturation_9(flux_qex1, S2, 0.01)
    flux_quz = baseflow_1(k1, S3)
    flux_a = abstraction_1(ca)
    flux_q = baseflow_6(k2, 0, S4, delta_t)

    out_dS[0] = flux_pin - flux_ea - flux_qex1
    out_dS[1] = flux_et + flux_qex2 - flux_qex1
    out_dS[2] = flux_qex2 + flux_pby - flux_quz
    out_dS[3] = flux_quz - flux_a - flux_q

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_pby
    out_fluxes[3] = flux_pin
    out_fluxes[4] = flux_ea
    out_fluxes[5] = flux_et
    out_fluxes[6] = flux_qex1
    out_fluxes[7] = flux_qex2
    out_fluxes[8] = flux_quz
    out_fluxes[9] = flux_a
    out_fluxes[10] = flux_q


@numba.njit(cache=True)
def _tcm_s1_residual(
    s1: float,
    s1_prev: float,
    pin: float,
    Ep: float,
    rc: float,
    delta_t: float,
) -> float:
    flux_ea = evap_1(s1, Ep, delta_t)
    flux_qex1 = saturation_1(pin, s1, rc)
    return (s1 - s1_prev) / delta_t - (pin - flux_ea - flux_qex1)


@numba.njit(cache=True)
def _tcm_s2_residual(
    s2: float,
    s2_prev: float,
    qex1: float,
    et: float,
    delta_t: float,
) -> float:
    flux_qex2 = saturation_9(qex1, s2, 0.01)
    return (s2 - s2_prev) / delta_t - (et + flux_qex2 - qex1)


@numba.njit(cache=True)
def _tcm_s4_residual(
    s4: float,
    s4_prev: float,
    quz: float,
    abstraction: float,
    k2: float,
    delta_t: float,
) -> float:
    flux_q = baseflow_6(k2, 0.0, s4, delta_t)
    return (s4 - s4_prev) / delta_t - (quz - abstraction - flux_q)


@numba.njit(cache=True)
def _tcm_bisect_s1(
    s1_prev: float,
    pin: float,
    Ep: float,
    rc: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(s1_prev + delta_t * max(pin, 0.0) + 1.0, 1.0)
    f_lower = _tcm_s1_residual(lower, s1_prev, pin, Ep, rc, delta_t)
    f_upper = _tcm_s1_residual(upper, s1_prev, pin, Ep, rc, delta_t)
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _tcm_s1_residual(upper, s1_prev, pin, Ep, rc, delta_t)
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _tcm_s1_residual(mid, s1_prev, pin, Ep, rc, delta_t)
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _tcm_bisect_s2(
    s2_prev: float,
    qex1: float,
    et: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(s2_prev + delta_t * (qex1 + et) + 1.0, 1.0)
    f_lower = _tcm_s2_residual(lower, s2_prev, qex1, et, delta_t)
    f_upper = _tcm_s2_residual(upper, s2_prev, qex1, et, delta_t)
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _tcm_s2_residual(upper, s2_prev, qex1, et, delta_t)
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _tcm_s2_residual(mid, s2_prev, qex1, et, delta_t)
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _tcm_bisect_s4(
    s4_prev: float,
    quz: float,
    abstraction: float,
    k2: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(s4_prev + delta_t * max(quz, 0.0) + 1.0, 1.0)
    f_lower = _tcm_s4_residual(lower, s4_prev, quz, abstraction, k2, delta_t)
    f_upper = _tcm_s4_residual(upper, s4_prev, quz, abstraction, k2, delta_t)
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _tcm_s4_residual(upper, s4_prev, quz, abstraction, k2, delta_t)
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _tcm_s4_residual(mid, s4_prev, quz, abstraction, k2, delta_t)
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _run_tcm_numba_solver(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    tolerance: float,
    max_iter: int,
) -> tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
]:
    n_steps = precip.shape[0]
    stores = np.empty((n_steps, 4), dtype=np.float64)
    fluxes = np.empty((n_steps, 11), dtype=np.float64)
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.zeros(n_steps, dtype=np.int64)

    phi = float(theta[0])
    rc = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])
    k2 = float(theta[5])
    ca = float(theta[6])

    prev = np.empty(4, dtype=np.float64)
    dS = np.empty(4, dtype=np.float64)
    step_fluxes = np.empty(11, dtype=np.float64)
    residual = np.empty(4, dtype=np.float64)
    prev[:] = s0

    for step_index in range(n_steps):
        P = float(precip[step_index])
        Ep = float(pet[step_index])

        flux_pn = effective_1(P, Ep)
        flux_en = P - flux_pn
        flux_pby = split_1(phi, flux_pn)
        flux_pin = split_1(1.0 - phi, flux_pn)

        s1, r1, nfev1 = _tcm_bisect_s1(
            prev[0],
            flux_pin,
            Ep,
            rc,
            delta_t,
            tolerance,
            max_iter,
        )
        flux_ea = evap_1(s1, Ep, delta_t)
        flux_et = evap_16(gam, np.inf, s1, 0.01, Ep, delta_t)
        flux_qex1 = saturation_1(flux_pin, s1, rc)

        s2, r2, nfev2 = _tcm_bisect_s2(
            prev[1],
            flux_qex1,
            flux_et,
            delta_t,
            tolerance,
            max_iter,
        )
        flux_qex2 = saturation_9(flux_qex1, s2, 0.01)

        s3 = (prev[2] + delta_t * (flux_qex2 + flux_pby)) / (1.0 + delta_t * k1)
        flux_quz = baseflow_1(k1, s3)
        requested_abstraction = abstraction_1(ca)
        lower_residual = _tcm_s4_residual(
            0.0,
            prev[3],
            flux_quz,
            requested_abstraction,
            k2,
            delta_t,
        )
        if lower_residual >= 0.0:
            s4 = 0.0
            flux_q = 0.0
            flux_a = max(0.0, flux_quz + prev[3] / delta_t)
            r4 = 0.0
            nfev4 = 1
        else:
            s4, r4, nfev4 = _tcm_bisect_s4(
                prev[3],
                flux_quz,
                requested_abstraction,
                k2,
                delta_t,
                tolerance,
                max_iter,
            )
            flux_q = baseflow_6(k2, 0.0, s4, delta_t)
            flux_a = requested_abstraction

        dS[0] = flux_pin - flux_ea - flux_qex1
        dS[1] = flux_et + flux_qex2 - flux_qex1
        dS[2] = flux_qex2 + flux_pby - flux_quz
        dS[3] = flux_quz - flux_a - flux_q

        residual[0] = (s1 - prev[0]) / delta_t - dS[0]
        residual[1] = (s2 - prev[1]) / delta_t - dS[1]
        residual[2] = (s3 - prev[2]) / delta_t - dS[2]
        residual[3] = (s4 - prev[3]) / delta_t - dS[3]
        residual_norm = (
            residual[0] * residual[0]
            + residual[1] * residual[1]
            + residual[2] * residual[2]
            + residual[3] * residual[3]
        ) ** 0.5

        stores[step_index, 0] = s1
        stores[step_index, 1] = s2
        stores[step_index, 2] = s3
        stores[step_index, 3] = s4

        step_fluxes[0] = flux_pn
        step_fluxes[1] = flux_en
        step_fluxes[2] = flux_pby
        step_fluxes[3] = flux_pin
        step_fluxes[4] = flux_ea
        step_fluxes[5] = flux_et
        step_fluxes[6] = flux_qex1
        step_fluxes[7] = flux_qex2
        step_fluxes[8] = flux_quz
        step_fluxes[9] = flux_a
        step_fluxes[10] = flux_q
        for flux_index in range(11):
            fluxes[step_index, flux_index] = step_fluxes[flux_index] * delta_t

        residual_norms[step_index] = residual_norm
        iterations[step_index] = max_iter
        nfev[step_index] = nfev1 + nfev2 + nfev4 + 1

        prev[0] = s1
        prev[1] = s2
        prev[2] = s3
        prev[3] = s4
    return stores, fluxes, residual_norms, iterations, nfev, njev


class tcm(StepKernelModel):
    python_step_function = staticmethod(_tcm_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 11
        self.num_params = 6
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [0, 0, 1, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [[0, 1], [1, 2000], [0, 1], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.param_names = ['phi', 'rc', 'gam', 'k1', 'fa', 'k2']
        self.param_descriptions = [
            'phi, Fraction preferential recharge [-]',
            'rc, Maximum soil moisture depth [mm]',
            'gam, Fraction of Ep reduction with depth [-]',
            'k1, Runoff coefficient [d-1]',
            'fa, Fraction of mean(P) that forms abstraction rate [mm/d]',
            'k2, Runoff coefficient [mm-1 d-1]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "pn",
            "en",
            "pby",
            "pin",
            "ea",
            "et",
            "qex1",
            "qex2",
            "quz",
            "a",
            "q",
        ]
        self.flux_groups = {"Ea": [2, 5, 6], "Q": 11, "Abstraction": 10}
        self.StoreSigns = np.array([1.0, -1.0, 1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        self._cached_step_index: int | None = None
        self._cached_step_state: FloatArray | None = None
        self._cached_step_fluxes: FloatArray | None = None

    def _get_kernel_bind_args(
        self,
        runtime: RuntimeContext,
    ) -> tuple[FloatArray, float, FloatArray, FloatArray, FloatArray]:
        return (
            _tcm_prepare_theta(
                np.asarray(runtime.theta, dtype=np.float64),
                runtime.precip,
            ),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
        )

    def _prepared_theta(self) -> FloatArray:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        return _tcm_prepare_theta(
            np.asarray(runtime.theta, dtype=np.float64),
            runtime.precip,
        )

    def _uses_discrete_step_solver(self) -> bool:
        return True

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        previous = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        theta = self._prepared_theta()
        delta_t = float(runtime.delta_t)
        phi = float(theta[0])
        rc = float(theta[1])
        gam = float(theta[2])
        k1 = float(theta[3])
        k2 = float(theta[5])
        ca = float(theta[6])
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])

        flux_pn = effective_1(P, Ep)
        flux_en = P - flux_pn
        flux_pby = split_1(phi, flux_pn)
        flux_pin = split_1(1.0 - phi, flux_pn)

        s1, _, _ = self._solve_s1(previous, flux_pin, Ep, rc)
        flux_ea = evap_1(s1, Ep, delta_t)
        flux_et = evap_16(gam, np.inf, s1, 0.01, Ep, delta_t)
        flux_qex1 = saturation_1(flux_pin, s1, rc)

        s2, _, _ = self._solve_s2(previous, flux_qex1, flux_et)
        flux_qex2 = saturation_9(flux_qex1, s2, 0.01)

        s3 = (float(previous[2]) + delta_t * (flux_qex2 + flux_pby)) / (1.0 + delta_t * k1)
        flux_quz = baseflow_1(k1, s3)
        requested_abstraction = abstraction_1(ca)
        lower_residual = _tcm_s4_residual(
            0.0,
            float(previous[3]),
            flux_quz,
            requested_abstraction,
            k2,
            delta_t,
        )
        if lower_residual >= 0.0:
            s4 = 0.0
            flux_q = 0.0
            flux_a = max(0.0, flux_quz + float(previous[3]) / delta_t)
        else:
            s4, _, _ = self._solve_s4(previous, flux_quz, requested_abstraction, k2)
            flux_q = baseflow_6(k2, 0.0, s4, delta_t)
            flux_a = requested_abstraction

        out_states[:] = np.asarray([s1, s2, s3, s4], dtype=np.float64)
        out_fluxes[:] = np.asarray(
            [
                flux_pn,
                flux_en,
                flux_pby,
                flux_pin,
                flux_ea,
                flux_et,
                flux_qex1,
                flux_qex2,
                flux_quz,
                flux_a,
                flux_q,
            ],
            dtype=np.float64,
        )

    def _solve_s1(
        self,
        previous: FloatArray,
        pin: float,
        Ep: float,
        rc: float,
    ) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(float(previous[0]) + delta_t * max(pin, 0.0) + 1.0, 1.0)
        return solve_scalar_fsolve_bracketed(
            lambda value: _tcm_s1_residual(
                float(value),
                float(previous[0]),
                pin,
                Ep,
                rc,
                delta_t,
            ),
            float(previous[0]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )

    def _solve_s2(
        self,
        previous: FloatArray,
        qex1: float,
        et: float,
    ) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(float(previous[1]) + delta_t * (qex1 + et) + 1.0, 1.0)
        return solve_scalar_fsolve_bracketed(
            lambda value: _tcm_s2_residual(
                float(value),
                float(previous[1]),
                qex1,
                et,
                delta_t,
            ),
            float(previous[1]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )

    def _solve_s4(
        self,
        previous: FloatArray,
        quz: float,
        abstraction: float,
        k2: float,
    ) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(float(previous[3]) + delta_t * max(quz, 0.0) + 1.0, 1.0)
        return solve_scalar_fsolve_bracketed(
            lambda value: _tcm_s4_residual(
                float(value),
                float(previous[3]),
                quz,
                abstraction,
                k2,
                delta_t,
            ),
            float(previous[3]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        previous = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        theta = self._prepared_theta()
        delta_t = float(runtime.delta_t)
        phi = float(theta[0])
        rc = float(theta[1])
        gam = float(theta[2])
        k1 = float(theta[3])
        k2 = float(theta[5])
        ca = float(theta[6])
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])

        flux_pn = effective_1(P, Ep)
        flux_en = P - flux_pn
        flux_pby = split_1(phi, flux_pn)
        flux_pin = split_1(1.0 - phi, flux_pn)

        s1, _, nfev1 = self._solve_s1(previous, flux_pin, Ep, rc)
        flux_ea = evap_1(s1, Ep, delta_t)
        flux_et = evap_16(gam, np.inf, s1, 0.01, Ep, delta_t)
        flux_qex1 = saturation_1(flux_pin, s1, rc)

        s2, _, nfev2 = self._solve_s2(previous, flux_qex1, flux_et)
        flux_qex2 = saturation_9(flux_qex1, s2, 0.01)

        s3 = (float(previous[2]) + delta_t * (flux_qex2 + flux_pby)) / (1.0 + delta_t * k1)
        flux_quz = baseflow_1(k1, s3)
        requested_abstraction = abstraction_1(ca)
        lower_residual = _tcm_s4_residual(
            0.0,
            float(previous[3]),
            flux_quz,
            requested_abstraction,
            k2,
            delta_t,
        )
        if lower_residual >= 0.0:
            s4 = 0.0
            flux_q = 0.0
            flux_a = max(0.0, flux_quz + float(previous[3]) / delta_t)
            nfev4 = 1
        else:
            s4, _, nfev4 = self._solve_s4(previous, flux_quz, requested_abstraction, k2)
            flux_q = baseflow_6(k2, 0.0, s4, delta_t)
            flux_a = requested_abstraction

        state = np.asarray([s1, s2, s3, s4], dtype=np.float64)
        fluxes = np.asarray(
            [
                flux_pn,
                flux_en,
                flux_pby,
                flux_pin,
                flux_ea,
                flux_et,
                flux_qex1,
                flux_qex2,
                flux_quz,
                flux_a,
                flux_q,
            ],
            dtype=np.float64,
        )
        residual = np.asarray(
            [
                _tcm_s1_residual(s1, float(previous[0]), flux_pin, Ep, rc, delta_t),
                _tcm_s2_residual(
                    s2,
                    float(previous[1]),
                    flux_qex1,
                    flux_et,
                    delta_t,
                ),
                (s3 - float(previous[2])) / delta_t - (flux_qex2 + flux_pby - flux_quz),
                _tcm_s4_residual(
                    s4,
                    float(previous[3]),
                    flux_quz,
                    flux_a,
                    k2,
                    delta_t,
                ),
            ],
            dtype=np.float64,
        )
        self._cached_step_index = int(step_index)
        self._cached_step_state = state.copy()
        self._cached_step_fluxes = fluxes.copy()
        return state, fluxes, float(np.linalg.norm(residual)), int(nfev1 + nfev2 + nfev4 + 1), 0

    def _writeback_state_and_fluxes(
        self,
        previous_states: FloatArray,
        solved_states: FloatArray,
        step_index: int,
    ) -> tuple[FloatArray, FloatArray]:
        if (
            self._cached_step_index == int(step_index)
            and self._cached_step_state is not None
            and self._cached_step_fluxes is not None
        ):
            return self._cached_step_state.copy(), self._cached_step_fluxes.copy()
        return super()._writeback_state_and_fluxes(previous_states, solved_states, step_index)

    def _run_compiled_numba_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        tolerance = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        max_iter = int(self.solver_opts.get("resnorm_maxiter", 40))
        stores, fluxes, resnorm, iterations, nfev, njev = _run_tcm_numba_solver(
            self._prepared_theta(),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            tolerance,
            max_iter,
        )
        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(int(runtime.precip.shape[0]), "numba_newton", dtype=object),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }

    def step(self) -> None:
        pass

