from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import evap_3, evap_7, interflow_8, saturation_1
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _collie2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    S1max = float(theta[0])
    Sfc = float(theta[1])
    a = float(theta[2])
    M = float(theta[3])

    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_eb = evap_7(S1, S1max, (1.0 - M) * Ep, delta_t)
    flux_ev = evap_3(Sfc, S1, S1max, M * Ep, delta_t)
    flux_qse = saturation_1(P, S1, S1max)
    flux_qss = interflow_8(S1, a, Sfc * S1max)

    out_dS[0] = P - flux_eb - flux_ev - flux_qse - flux_qss

    out_fluxes[0] = flux_eb
    out_fluxes[1] = flux_ev
    out_fluxes[2] = flux_qse
    out_fluxes[3] = flux_qss


class collie2(StepKernelModel):
    python_step_function = staticmethod(_collie2_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 4
        self.num_params = 4
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0, 1], [0.05, 0.95]],
            dtype=np.float64,
        )
        self.param_names = ['S1max', 'Sfc', 'a', 'M']
        self.param_descriptions = [
            'Maximum soil moisture storage [mm]',
            'Field capacity as fraction of S1max [-]',
            'Subsurface runoff coefficient [d-1]',
            'Fraction forest cover [-]',
        ]
        self.store_names = ["S1"]
        self.flux_names = ["eb", "ev", "qse", "qss"]
        self.flux_groups = {"Ea": [1, 2], "Q": [3, 4]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

