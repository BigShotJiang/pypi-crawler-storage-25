from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    interflow_8,
    melt_1,
    rainfall_1,
    saturation_1,
    snowfall_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _alpine2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    ddf = float(theta[1])
    Smax = float(theta[2])
    Cfc = float(theta[3])
    tcin = float(theta[4])
    tcbf = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_ps = snowfall_1(P, T, tt)
    flux_pr = rainfall_1(P, T, tt)
    flux_qn = melt_1(ddf, tt, T, S1, delta_t)
    flux_ea = evap_1(S2, Ep, delta_t)
    flux_qse = saturation_1(P + flux_qn, S2, Smax)
    flux_qin = interflow_8(S2, tcin, Cfc * Smax)
    flux_qbf = baseflow_1(tcbf, S2)

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_ea - flux_qse - flux_qin - flux_qbf

    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pr
    out_fluxes[2] = flux_qn
    out_fluxes[3] = flux_ea
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qin
    out_fluxes[6] = flux_qbf


class alpine2(StepKernelModel):
    python_step_function = staticmethod(_alpine2_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 7
        self.num_params = 6
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[-3, 5], [0, 20], [1, 2000], [0.05, 0.95], [0, 1], [0, 1]],
            dtype=np.float64,
        )
        self.param_names = ['tt', 'ddf', 'Smax', 'Cfc', 'tcin', 'tcbf']
        self.param_descriptions = [
            'tt [celsius]',
            'degree-day-factor [mm/degree celsius/d]',
            'Smax [mm]',
            'Field capacity as fraction of Smax [-]',
            'time delay of interflow [d-1]',
            'time delay of baseflow [d-1]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["ps", "pr", "qn", "ea", "qse", "qin", "qbf"]
        self.flux_groups = {"Ea": [4], "Q": [5, 6, 7]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

