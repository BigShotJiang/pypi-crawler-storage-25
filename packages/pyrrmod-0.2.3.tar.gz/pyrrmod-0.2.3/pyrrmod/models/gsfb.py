from __future__ import annotations

import numpy as np
import numba

from pyrrmod.fluxes import (
    baseflow_1,
    baseflow_9,
    evap_20,
    interflow_11,
    recharge_5,
    saturation_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext
from pyrrmod.solvers.scalar_root import solve_scalar_fsolve_bracketed


def _gsfb_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    c = float(theta[0])
    ndc = float(theta[1])
    smax = float(theta[2])
    emax = float(theta[3])
    frate = float(theta[4])
    b = float(theta[5])
    dpf = float(theta[6])
    sdrmax = float(theta[7])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    threshold = ndc * smax
    flux_ea = evap_20(emax, ndc, S1, smax, Ep, delta_t)
    flux_qs = saturation_1(P, S1, smax)
    flux_f = interflow_11(frate, threshold, S1, delta_t)
    flux_qb = baseflow_9(b * dpf, sdrmax, S2)
    flux_dp = baseflow_1((1.0 - b) * dpf, S2)
    flux_qdr = recharge_5(c, threshold, S3, S1)

    out_dS[0] = P + flux_qdr - flux_ea - flux_qs - flux_f
    out_dS[1] = flux_f - flux_qb - flux_dp
    out_dS[2] = flux_dp - flux_qdr

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qs
    out_fluxes[2] = flux_f
    out_fluxes[3] = flux_qb
    out_fluxes[4] = flux_dp
    out_fluxes[5] = flux_qdr


@numba.njit(cache=True)
def _gsfb_recharge_factor(s1: float, threshold: float) -> float:
    if threshold <= 0.0:
        return 0.0
    ratio = s1 / threshold
    if ratio <= 0.0:
        return 1.0
    if ratio >= 1.0:
        return 0.0
    return 1.0 - ratio


@numba.njit(cache=True)
def _gsfb_s2_closed_form(
    s2_prev: float,
    flux_f: float,
    b: float,
    dpf: float,
    sdrmax: float,
    delta_t: float,
) -> tuple[float, float, float]:
    dp_coeff = (1.0 - b) * dpf
    lower_candidate = (s2_prev + delta_t * flux_f) / (1.0 + delta_t * dp_coeff)
    if lower_candidate <= sdrmax:
        s2 = lower_candidate
        qb = 0.0
        dp = baseflow_1(dp_coeff, s2)
        return s2, qb, dp

    upper_candidate = (s2_prev + delta_t * (flux_f + b * dpf * sdrmax)) / (
        1.0 + delta_t * dpf
    )
    s2 = upper_candidate
    qb = baseflow_9(b * dpf, sdrmax, s2)
    dp = baseflow_1(dp_coeff, s2)
    return s2, qb, dp


@numba.njit(cache=True)
def _gsfb_s1_residual(
    s1: float,
    s1_prev: float,
    s2_prev: float,
    s3_prev: float,
    P: float,
    Ep: float,
    c: float,
    threshold: float,
    smax: float,
    emax: float,
    frate: float,
    b: float,
    dpf: float,
    sdrmax: float,
    delta_t: float,
) -> float:
    flux_ea = evap_20(emax, threshold / smax, s1, smax, Ep, delta_t)
    flux_qs = saturation_1(P, s1, smax)
    flux_f = interflow_11(frate, threshold, s1, delta_t)
    _, _, flux_dp = _gsfb_s2_closed_form(s2_prev, flux_f, b, dpf, sdrmax, delta_t)
    recharge_factor = _gsfb_recharge_factor(s1, threshold)
    s3 = (s3_prev + delta_t * flux_dp) / (1.0 + delta_t * c * recharge_factor)
    flux_qdr = recharge_5(c, threshold, s3, s1)
    return (s1 - s1_prev) / delta_t - (P + flux_qdr - flux_ea - flux_qs - flux_f)


@numba.njit(cache=True)
def _gsfb_bisect_s1(
    s1_prev: float,
    s2_prev: float,
    s3_prev: float,
    P: float,
    Ep: float,
    c: float,
    threshold: float,
    smax: float,
    emax: float,
    frate: float,
    b: float,
    dpf: float,
    sdrmax: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(
        s1_prev
        + delta_t * (max(P, 0.0) + max(c * (s2_prev + s3_prev + 1.0), 0.0) + frate)
        + threshold
        + 1.0,
        1.0,
    )
    f_lower = _gsfb_s1_residual(
        lower,
        s1_prev,
        s2_prev,
        s3_prev,
        P,
        Ep,
        c,
        threshold,
        smax,
        emax,
        frate,
        b,
        dpf,
        sdrmax,
        delta_t,
    )
    f_upper = _gsfb_s1_residual(
        upper,
        s1_prev,
        s2_prev,
        s3_prev,
        P,
        Ep,
        c,
        threshold,
        smax,
        emax,
        frate,
        b,
        dpf,
        sdrmax,
        delta_t,
    )
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _gsfb_s1_residual(
            upper,
            s1_prev,
            s2_prev,
            s3_prev,
            P,
            Ep,
            c,
            threshold,
            smax,
            emax,
            frate,
            b,
            dpf,
            sdrmax,
            delta_t,
        )
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _gsfb_s1_residual(
            mid,
            s1_prev,
            s2_prev,
            s3_prev,
            P,
            Ep,
            c,
            threshold,
            smax,
            emax,
            frate,
            b,
            dpf,
            sdrmax,
            delta_t,
        )
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _run_gsfb_numba_solver(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    tolerance: float,
    max_iter: int,
) -> tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
]:
    n_steps = precip.shape[0]
    stores = np.empty((n_steps, 3), dtype=np.float64)
    fluxes = np.empty((n_steps, 6), dtype=np.float64)
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.zeros(n_steps, dtype=np.int64)

    c = float(theta[0])
    ndc = float(theta[1])
    smax = float(theta[2])
    emax = float(theta[3])
    frate = float(theta[4])
    b = float(theta[5])
    dpf = float(theta[6])
    sdrmax = float(theta[7])
    threshold = ndc * smax

    prev = np.empty(3, dtype=np.float64)
    dS = np.empty(3, dtype=np.float64)
    step_fluxes = np.empty(6, dtype=np.float64)
    residual = np.empty(3, dtype=np.float64)
    prev[:] = s0

    for step_index in range(n_steps):
        P = float(precip[step_index])
        Ep = float(pet[step_index])

        s1, r1, nfev1 = _gsfb_bisect_s1(
            prev[0],
            prev[1],
            prev[2],
            P,
            Ep,
            c,
            threshold,
            smax,
            emax,
            frate,
            b,
            dpf,
            sdrmax,
            delta_t,
            tolerance,
            max_iter,
        )
        flux_ea = evap_20(emax, ndc, s1, smax, Ep, delta_t)
        flux_qs = saturation_1(P, s1, smax)
        flux_f = interflow_11(frate, threshold, s1, delta_t)
        s2, flux_qb, flux_dp = _gsfb_s2_closed_form(
            prev[1],
            flux_f,
            b,
            dpf,
            sdrmax,
            delta_t,
        )
        recharge_factor = _gsfb_recharge_factor(s1, threshold)
        s3 = (prev[2] + delta_t * flux_dp) / (1.0 + delta_t * c * recharge_factor)
        flux_qdr = recharge_5(c, threshold, s3, s1)

        dS[0] = P + flux_qdr - flux_ea - flux_qs - flux_f
        dS[1] = flux_f - flux_qb - flux_dp
        dS[2] = flux_dp - flux_qdr

        residual[0] = (s1 - prev[0]) / delta_t - dS[0]
        residual[1] = (s2 - prev[1]) / delta_t - dS[1]
        residual[2] = (s3 - prev[2]) / delta_t - dS[2]
        residual_norm = (
            residual[0] * residual[0]
            + residual[1] * residual[1]
            + residual[2] * residual[2]
        ) ** 0.5

        stores[step_index, 0] = s1
        stores[step_index, 1] = s2
        stores[step_index, 2] = s3

        step_fluxes[0] = flux_ea
        step_fluxes[1] = flux_qs
        step_fluxes[2] = flux_f
        step_fluxes[3] = flux_qb
        step_fluxes[4] = flux_dp
        step_fluxes[5] = flux_qdr
        for flux_index in range(6):
            fluxes[step_index, flux_index] = step_fluxes[flux_index] * delta_t

        residual_norms[step_index] = residual_norm
        iterations[step_index] = max_iter
        nfev[step_index] = nfev1 + 1

        prev[0] = s1
        prev[1] = s2
        prev[2] = s3
    return stores, fluxes, residual_norms, iterations, nfev, njev


class gsfb(StepKernelModel):
    python_step_function = staticmethod(_gsfb_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 6
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 0, 1], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 1],
                [0.05, 0.95],
                [1, 2000],
                [0, 20],
                [0, 200],
                [0, 1],
                [0, 1],
                [1, 300],
            ],
            dtype=np.float64,
        )
        self.param_names = ['c', 'ndc', 'smax', 'emax', 'frate', 'b', 'dpf', 'sdrmax']
        self.param_descriptions = [
            'c, Recharge time coeffcient [d-1]',
            'ndc, Threshold fraction of Smax [-]',
            'smax, Maximum soil moisture storage [mm]',
            'emax, Maximum evaporation flux [mm/d]',
            'frate, Maximum infiltration rate [mm/d]',
            'b, Fraction of subsurface flow that is baseflow [-]',
            'dpf, Baseflow time coefficient [d-1]',
            'sdrmax, Threshold before baseflow can occur [mm]',
        ]
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qs", "f", "qb", "dp", "qdr"]
        self.flux_groups = {"Ea": 1, "Q": [2, 4]}

    def init(self) -> None:
        pass

    def _solve_s1(self, previous: FloatArray, step_index: int) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])
        c = float(theta[0])
        ndc = float(theta[1])
        smax = float(theta[2])
        emax = float(theta[3])
        frate = float(theta[4])
        b = float(theta[5])
        dpf = float(theta[6])
        sdrmax = float(theta[7])
        threshold = ndc * smax
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(
            float(previous[0])
            + delta_t
            * (
                max(P, 0.0)
                + max(c * (float(previous[1]) + float(previous[2]) + 1.0), 0.0)
                + frate
            )
            + threshold
            + 1.0,
            1.0,
        )
        return solve_scalar_fsolve_bracketed(
            lambda value: _gsfb_s1_residual(
                float(value),
                float(previous[0]),
                float(previous[1]),
                float(previous[2]),
                P,
                Ep,
                c,
                threshold,
                smax,
                emax,
                frate,
                b,
                dpf,
                sdrmax,
                delta_t,
            ),
            float(previous[0]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        previous = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        c = float(theta[0])
        ndc = float(theta[1])
        smax = float(theta[2])
        emax = float(theta[3])
        frate = float(theta[4])
        b = float(theta[5])
        dpf = float(theta[6])
        sdrmax = float(theta[7])
        threshold = ndc * smax
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])

        s1, _, nfev1 = self._solve_s1(previous, step_index)
        flux_ea = evap_20(emax, ndc, s1, smax, Ep, delta_t)
        flux_qs = saturation_1(P, s1, smax)
        flux_f = interflow_11(frate, threshold, s1, delta_t)
        s2, flux_qb, flux_dp = _gsfb_s2_closed_form(
            float(previous[1]),
            flux_f,
            b,
            dpf,
            sdrmax,
            delta_t,
        )
        recharge_factor = _gsfb_recharge_factor(s1, threshold)
        s3 = (float(previous[2]) + delta_t * flux_dp) / (1.0 + delta_t * c * recharge_factor)
        flux_qdr = recharge_5(c, threshold, s3, s1)

        state = np.asarray([s1, s2, s3], dtype=np.float64)
        fluxes = np.asarray(
            [flux_ea, flux_qs, flux_f, flux_qb, flux_dp, flux_qdr],
            dtype=np.float64,
        )
        residual = np.asarray(
            [
                _gsfb_s1_residual(
                    s1,
                    float(previous[0]),
                    float(previous[1]),
                    float(previous[2]),
                    P,
                    Ep,
                    c,
                    threshold,
                    smax,
                    emax,
                    frate,
                    b,
                    dpf,
                    sdrmax,
                    delta_t,
                ),
                (s2 - float(previous[1])) / delta_t - (flux_f - flux_qb - flux_dp),
                (s3 - float(previous[2])) / delta_t - (flux_dp - flux_qdr),
            ],
            dtype=np.float64,
        )
        return state, fluxes, float(np.linalg.norm(residual)), int(nfev1 + 1), 0

    def _run_compiled_numba_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        tolerance = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        max_iter = int(self.solver_opts.get("resnorm_maxiter", 40))
        stores, fluxes, resnorm, iterations, nfev, njev = _run_gsfb_numba_solver(
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            tolerance,
            max_iter,
        )
        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(int(runtime.precip.shape[0]), "numba_newton", dtype=object),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }

    def step(self) -> None:
        pass

