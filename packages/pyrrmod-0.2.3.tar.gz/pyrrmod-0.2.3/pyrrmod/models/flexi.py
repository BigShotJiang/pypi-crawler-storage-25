from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    half_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_3,
    interception_1,
    percolation_2,
    saturation_3,
    split_1,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import DoubleRoutedNewtonMixin


def _flexi_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh1_pending: FloatArray,
    uh2_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    smax = float(theta[0])
    beta = float(theta[1])
    d = float(theta[2])
    percmax = float(theta[3])
    lp = float(theta[4])
    kf = float(theta[7])
    ks = float(theta[8])
    imax = float(theta[9])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_peff = interception_1(P, S1, imax)
    flux_ei = evap_1(S1, Ep, delta_t)
    flux_ru = saturation_3(S2, smax, beta, flux_peff)
    flux_eur = evap_3(lp, S2, smax, Ep, delta_t)
    flux_ps = percolation_2(percmax, S2, smax, delta_t)
    flux_rf = split_1(1.0 - d, flux_peff - flux_ru)
    flux_rs = split_1(d, flux_peff - flux_ru)
    flux_rfl = route_uh_current_nb(uh1_pending)
    flux_rsl = route_uh_current_nb(uh2_pending)
    flux_qf = baseflow_1(kf, S3)
    flux_qs = baseflow_1(ks, S4)

    out_dS[0] = P - flux_peff - flux_ei
    out_dS[1] = flux_ru - flux_eur - flux_ps
    out_dS[2] = flux_rfl - flux_qf
    out_dS[3] = flux_rsl - flux_qs

    out_fluxes[0] = flux_peff
    out_fluxes[1] = flux_ei
    out_fluxes[2] = flux_ru
    out_fluxes[3] = flux_eur
    out_fluxes[4] = flux_ps
    out_fluxes[5] = flux_rf
    out_fluxes[6] = flux_rs
    out_fluxes[7] = flux_rfl
    out_fluxes[8] = flux_rsl
    out_fluxes[9] = flux_qf
    out_fluxes[10] = flux_qs


_flexi_compute_step_numba = numba.njit(cache=True)(_flexi_compute_step)


@numba.njit(cache=True)
def _flexi_commit_inflow_nb(fluxes: FloatArray) -> tuple[float, float]:
    return fluxes[5], fluxes[4] + fluxes[6]


class flexi(DoubleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_flexi_compute_step)
    compiled_step_function = staticmethod(_flexi_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_flexi_commit_inflow_nb)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 11
        self.num_params = 10
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [1, 1, 0, 1]],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0, 10],
                [0, 1],
                [0, 20],
                [0.05, 0.95],
                [1, 5],
                [1, 15],
                [0, 1],
                [0, 1],
                [0, 5],
            ],
            dtype=np.float64,
        )
        self.param_names = ['smax', 'beta', 'd', 'percmax', 'lp', 'nlagf', 'nlags', 'kf', 'ks', 'imax']
        self.param_descriptions = [
            'URmax, Maximum soil moisture storage [mm]',
            'beta, Unsaturated zone shape parameter [-]',
            'D, Fast/slow runoff distribution parameter [-]',
            'PERCmax, Maximum percolation rate [mm/d]',
            'Lp, Wilting point as fraction of s1max [-]',
            'Nlagf, Flow delay before fast runoff [d]',
            'Nlags, Flow delay before slow runoff [d]',
            'Kf, Fast runoff coefficient [d-1]',
            'Ks, Slow runoff coefficient [d-1]',
            'Imax, Maximum interception storage [mm]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "peff",
            "ei",
            "ru",
            "eur",
            "ps",
            "rf",
            "rs",
            "rfl",
            "rsl",
            "qf",
            "qs",
        ]
        self.flux_groups = {"Ea": [2, 4], "Q": [10, 11]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        uh1, _ = half_hydrograph(float(theta[5]), float(self.delta_t), power=1.5)
        uh2, _ = half_hydrograph(float(theta[6]), float(self.delta_t), power=1.5)
        routing_state = make_unit_hydro_state(uh1, uh2)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
