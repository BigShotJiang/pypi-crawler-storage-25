from __future__ import annotations

import numpy as np
from scipy.optimize import fsolve

import numba

from pyrrmod.unithydro import (
    full_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    capillary_1,
    evap_3,
    excess_1,
    infiltration_3,
    interflow_2,
    melt_1,
    percolation_1,
    rainfall_2,
    recharge_2,
    refreeze_1,
    snowfall_2,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray, RuntimeContext
from pyrrmod.solvers.root_fallback import solve_root_with_retries
from pyrrmod.unithydro.routed_newton_mixins import SingleRoutedNewtonMixin


def _hbv_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    tti = float(theta[1])
    ttm = float(theta[2])
    cfr = float(theta[3])
    cfmax = float(theta[4])
    whc = float(theta[5])
    cflux = float(theta[6])
    fc = float(theta[7])
    lp = float(theta[8])
    beta = float(theta[9])
    k0 = float(theta[10])
    alpha = float(theta[11])
    perc = float(theta[12])
    k1 = float(theta[13])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_sf = snowfall_2(P, T, tt, tti)
    flux_refr = refreeze_1(cfr, cfmax, ttm, T, S2, delta_t)
    flux_melt = melt_1(cfmax, ttm, T, S1, delta_t)
    flux_rf = rainfall_2(P, T, tt, tti)
    flux_in = infiltration_3(flux_rf + flux_melt, S2, whc * S1)
    flux_se = excess_1(S2, whc * S1, delta_t)
    flux_cf = capillary_1(cflux, S3, fc, S4, delta_t)
    flux_ea = evap_3(lp, S3, fc, Ep, delta_t)
    flux_r = recharge_2(beta, S3, fc, flux_in + flux_se)
    flux_q0 = interflow_2(k0, S4, alpha, delta_t)
    flux_perc = percolation_1(perc, S4, delta_t)
    flux_q1 = baseflow_1(k1, S5)
    flux_qt = route_uh_current_nb(uh_pending)

    out_dS[0] = flux_sf + flux_refr - flux_melt
    out_dS[1] = flux_rf + flux_melt - flux_refr - flux_in - flux_se
    out_dS[2] = flux_in + flux_se + flux_cf - flux_ea - flux_r
    out_dS[3] = flux_r - flux_cf - flux_q0 - flux_perc
    out_dS[4] = flux_perc - flux_q1

    out_fluxes[0] = flux_sf
    out_fluxes[1] = flux_refr
    out_fluxes[2] = flux_melt
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_in
    out_fluxes[5] = flux_se
    out_fluxes[6] = flux_cf
    out_fluxes[7] = flux_ea
    out_fluxes[8] = flux_r
    out_fluxes[9] = flux_q0
    out_fluxes[10] = flux_perc
    out_fluxes[11] = flux_q1
    out_fluxes[12] = flux_qt


_hbv_compute_step_numba = numba.njit(cache=True)(_hbv_compute_step)


def _hbv_compute_step_prev_s2(
    states: FloatArray,
    step_index: int,
    s2_old: float,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    tti = float(theta[1])
    ttm = float(theta[2])
    cfr = float(theta[3])
    cfmax = float(theta[4])
    whc = float(theta[5])
    cflux = float(theta[6])
    fc = float(theta[7])
    lp = float(theta[8])
    beta = float(theta[9])
    k0 = float(theta[10])
    alpha = float(theta[11])
    perc = float(theta[12])
    k1 = float(theta[13])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_sf = snowfall_2(P, T, tt, tti)
    flux_refr = refreeze_1(cfr, cfmax, ttm, T, S2, delta_t)
    flux_melt = melt_1(cfmax, ttm, T, S1, delta_t)
    flux_rf = rainfall_2(P, T, tt, tti)
    flux_in = infiltration_3(flux_rf + flux_melt, S2, whc * S1)
    flux_se = excess_1(s2_old, whc * S1, delta_t)
    flux_cf = capillary_1(cflux, S3, fc, S4, delta_t)
    flux_ea = evap_3(lp, S3, fc, Ep, delta_t)
    flux_r = recharge_2(beta, S3, fc, flux_in + flux_se)
    flux_q0 = interflow_2(k0, S4, alpha, delta_t)
    flux_perc = percolation_1(perc, S4, delta_t)
    flux_q1 = baseflow_1(k1, S5)
    flux_qt = route_uh_current_nb(uh_pending)

    out_dS[0] = flux_sf + flux_refr - flux_melt
    out_dS[1] = flux_rf + flux_melt - flux_refr - flux_in - flux_se
    out_dS[2] = flux_in + flux_se + flux_cf - flux_ea - flux_r
    out_dS[3] = flux_r - flux_cf - flux_q0 - flux_perc
    out_dS[4] = flux_perc - flux_q1

    out_fluxes[0] = flux_sf
    out_fluxes[1] = flux_refr
    out_fluxes[2] = flux_melt
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_in
    out_fluxes[5] = flux_se
    out_fluxes[6] = flux_cf
    out_fluxes[7] = flux_ea
    out_fluxes[8] = flux_r
    out_fluxes[9] = flux_q0
    out_fluxes[10] = flux_perc
    out_fluxes[11] = flux_q1
    out_fluxes[12] = flux_qt


def _hbv_compute_step_prev_s2_no_route(
    states: FloatArray,
    step_index: int,
    s2_old: float,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    tti = float(theta[1])
    ttm = float(theta[2])
    cfr = float(theta[3])
    cfmax = float(theta[4])
    whc = float(theta[5])
    cflux = float(theta[6])
    fc = float(theta[7])
    lp = float(theta[8])
    beta = float(theta[9])
    k0 = float(theta[10])
    alpha = float(theta[11])
    perc = float(theta[12])
    k1 = float(theta[13])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_sf = snowfall_2(P, T, tt, tti)
    flux_refr = refreeze_1(cfr, cfmax, ttm, T, S2, delta_t)
    flux_melt = melt_1(cfmax, ttm, T, S1, delta_t)
    flux_rf = rainfall_2(P, T, tt, tti)
    flux_in = infiltration_3(flux_rf + flux_melt, S2, whc * S1)
    flux_se = excess_1(s2_old, whc * S1, delta_t)
    flux_cf = capillary_1(cflux, S3, fc, S4, delta_t)
    flux_ea = evap_3(lp, S3, fc, Ep, delta_t)
    flux_r = recharge_2(beta, S3, fc, flux_in + flux_se)
    flux_q0 = interflow_2(k0, S4, alpha, delta_t)
    flux_perc = percolation_1(perc, S4, delta_t)
    flux_q1 = baseflow_1(k1, S5)

    out_dS[0] = flux_sf + flux_refr - flux_melt
    out_dS[1] = flux_rf + flux_melt - flux_refr - flux_in - flux_se
    out_dS[2] = flux_in + flux_se + flux_cf - flux_ea - flux_r
    out_dS[3] = flux_r - flux_cf - flux_q0 - flux_perc
    out_dS[4] = flux_perc - flux_q1

    out_fluxes[0] = flux_sf
    out_fluxes[1] = flux_refr
    out_fluxes[2] = flux_melt
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_in
    out_fluxes[5] = flux_se
    out_fluxes[6] = flux_cf
    out_fluxes[7] = flux_ea
    out_fluxes[8] = flux_r
    out_fluxes[9] = flux_q0
    out_fluxes[10] = flux_perc
    out_fluxes[11] = flux_q1
    out_fluxes[12] = 0.0


@numba.njit(cache=True)
def _hbv_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[9] + fluxes[11]


class hbv(SingleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_hbv_compute_step)
    compiled_step_function = staticmethod(_hbv_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_hbv_commit_inflow_nb)
    routed_newton_use_predictor = False
    routed_newton_clip_iterates = False
    routed_newton_default_damping = 0.8
    routed_newton_default_diff_step = 1e-7

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 13
        self.num_params = 15
        self.jacob_pattern = np.array(
            [
                [1, 1, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [1, 1, 1, 1, 0],
                [1, 1, 1, 1, 0],
                [0, 0, 0, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [-3, 5],
                [0, 17],
                [-3, 3],
                [0, 1],
                [0, 20],
                [0, 1],
                [0, 4],
                [1, 2000],
                [0.05, 0.95],
                [0, 10],
                [0, 1],
                [0, 4],
                [0, 20],
                [0, 1],
                [1, 120],
            ],
            dtype=np.float64,
        )
        self.param_names = ['tt', 'tti', 'ttm', 'cfr', 'cfmax', 'whc', 'cflux', 'fc', 'lp', 'beta', 'k0', 'alpha', 'perc', 'k1', 'maxbas']
        self.param_descriptions = [
            'TT, threshold temperature for snowfall [oC]',
            'TTI, interval length of rain-snow spectrum [oC]',
            'TTM, threshold temperature for snowmelt [oC]',
            'CFR, coefficient of refreezing of melted snow [-]',
            'CFMAX, degree-day factor of snowmelt and refreezing [mm/oC/d]',
            'WHC, maximum water holding content of snow pack [-]',
            'CFLUX, maximum rate of capillary rise [mm/d]',
            'FC, maximum soil moisture storage [mm]',
            'LP, wilting point as fraction of FC [-]',
            'BETA, non-linearity coefficient of upper zone recharge [-]',
            'K0, runoff coefficient from upper zone [d-1]',
            'ALPHA, non-linearity coefficient of runoff from upper zone [-]',
            'PERC, maximum rate of percolation to lower zone [mm/d]',
            'K1, runoff coefficient from lower zone [d-1]',
            'MAXBAS, flow routing delay [d]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "sf",
            "refr",
            "melt",
            "rf",
            "in",
            "se",
            "cf",
            "ea",
            "r",
            "q0",
            "perc",
            "q1",
            "qt",
        ]
        self.flux_groups = {"Ea": 8, "Q": 13}

    def init(self) -> None:
        weights, _ = full_hydrograph(
            float(self.theta[14]), float(self.delta_t), power=1.5
        )
        routing_state = make_unit_hydro_state(weights)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _bind_kernel(self, step_fun, runtime: RuntimeContext):
        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        uh_pending = routing.uh_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_pending,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and self._python_model_fun is not None:
            self._python_model_fun(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = self._require_routing_state(runtime)
        _hbv_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _build_routed_newton_step_kernel(self, runtime: RuntimeContext):
        if (
            self._routed_newton_step_kernel is not None
            and self._routed_newton_step_kernel_runtime is runtime
        ):
            return self._routed_newton_step_kernel

        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        step_fun = self._get_or_compile_step_function(
            python_step_function=self.python_step_function,
            compiled_step_function=self.compiled_step_function,
        )

        def kernel(
            states: FloatArray,
            step_index: int,
            uh_pending: FloatArray,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                uh_pending,
                out_dS,
                out_fluxes,
            )

        kernel = numba.njit(cache=False)(kernel)
        warm_dS = np.empty(int(self.num_stores), dtype=np.float64)
        warm_fluxes = np.empty(int(self.num_fluxes), dtype=np.float64)
        kernel(
            np.asarray(runtime.S0, dtype=np.float64),
            0,
            routing.uh_pending,
            warm_dS,
            warm_fluxes,
        )
        self._routed_newton_step_kernel = kernel
        self._routed_newton_step_kernel_runtime = runtime
        return kernel

    def residual_jacobian(
        self,
        states,
        previous_states,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        del states, previous_states, step_index, diff_step
        # HBV switches branches around snow and infiltration thresholds, so the
        # generic finite-difference Jacobian is less reliable than Jacobian-free fsolve.
        return None

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        use_prev_s2 = bool(self.solver_opts.get("hbv_use_previous_s2_excess", False))
        if bool(self.solver_opts.get("retry_solver", True)):
            use_prev_s2 = True

        if not use_prev_s2:
            return super()._fsolve_step(previous_states, step_index)

        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        previous_vector = np.asarray(previous_states, dtype=np.float64).reshape(-1)

        out_dS = np.empty(self.num_stores, dtype=np.float64)
        out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        routing = self._require_routing_state(runtime)
        s2_old = (
            float(runtime.S0[1])
            if step_index <= 0
            else float(runtime.stores[int(step_index) - 1, 1])
        )

        def residual(trial: FloatArray) -> FloatArray:
            trial_vector = np.asarray(trial, dtype=np.float64).reshape(-1)
            _hbv_compute_step_prev_s2_no_route(
                trial_vector,
                int(step_index),
                s2_old,
                theta,
                delta_t,
                runtime.precip,
                runtime.pet,
                runtime.temp,
                out_dS,
                out_fluxes,
            )
            return (trial_vector - previous_vector) / delta_t - out_dS

        if bool(self.solver_opts.get("retry_solver", True)):
            result = solve_root_with_retries(
                residual_fun=residual,
                previous_state=previous_vector,
                initial_guess=previous_vector,
                lower_bounds=np.asarray(runtime.store_min, dtype=np.float64),
                upper_bounds=np.asarray(runtime.store_max, dtype=np.float64),
                tolerance_scale=float(self.solver_opts.get("resnorm_tolerance", 0.1)),
                max_retries=int(self.solver_opts.get("resnorm_maxiter", 6)),
                lsq_max_nfev=1000,
                newton_max_iter=int(max(1, self.num_stores * 10)),
            )
            trial_state = np.asarray(result.state, dtype=np.float64)
            nfev = int(result.nfev)
            njev = int(result.njev)
            residual_norm = float(result.residual_norm)
        else:
            root, info, _, _ = fsolve(residual, previous_vector, full_output=True)
            trial_state = np.asarray(root, dtype=np.float64)
            nfev = int(info.get("nfev", 0))
            njev = int(info.get("njev", 0))
            residual_norm = float(
                np.linalg.norm(np.asarray(residual(trial_state), dtype=np.float64))
            )

        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        _hbv_compute_step_prev_s2(
            trial_state,
            int(step_index),
            s2_old,
            theta,
            delta_t,
            runtime.precip,
            runtime.pet,
            runtime.temp,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return (
            trial_state,
            np.asarray(out_fluxes, dtype=np.float64),
            residual_norm,
            nfev,
            njev,
        )

    def _writeback_state_and_fluxes(
        self,
        previous_states: FloatArray,
        solved_states: FloatArray,
        step_index: int,
    ) -> tuple[FloatArray, FloatArray]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        dS = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        s2_old = (
            float(runtime.S0[1])
            if step_index <= 0
            else float(runtime.stores[int(step_index) - 1, 1])
        )
        _hbv_compute_step_prev_s2(
            np.asarray(solved_states, dtype=np.float64).reshape(-1),
            int(step_index),
            s2_old,
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            self._require_routing_state(runtime).uh_pending,
            dS,
            fluxes,
        )
        state = np.asarray(previous_states, dtype=np.float64) + dS * float(
            runtime.delta_t
        )
        return np.asarray(state, dtype=np.float64), np.asarray(fluxes, dtype=np.float64)

    def _supports_routed_newton(self) -> bool:
        # HBV still uses the routed Newton path, but starts from the previous
        # state instead of the explicit predictor because threshold-driven
        # branches are sensitive to the initial iterate.
        return super()._supports_routed_newton()

    def run(
        self,
        *,
        config=None,
        theta=None,
        delta_t=None,
        S0=None,
        input_climate=None,
        solver_opts=None,
        compile_target=None,
        solver: str = "fsolve",
    ):
        return super().run(
            config=config,
            theta=theta,
            delta_t=delta_t,
            S0=S0,
            input_climate=input_climate,
            solver_opts=solver_opts,
            compile_target="python" if compile_target is None else compile_target,
            solver=solver,
        )

    def get_streamflow(self) -> FloatArray:
        if self.fluxes is None:
            raise RuntimeError("run must be called first")
        return np.asarray(self.fluxes[:, 12], dtype=np.float64)
