from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    full_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_5,
    evap_6,
    interception_1,
    interflow_9,
    saturation_1,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import SingleRoutedNewtonMixin


def _newzealand2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    s1max = float(theta[0])
    s2max = float(theta[1])
    sfc = float(theta[2])
    m = float(theta[3])
    a = float(theta[4])
    b = float(theta[5])
    tcbf = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_eint = evap_1(S1, Ep, delta_t)
    flux_qtf = interception_1(P, S1, s1max)
    flux_veg = evap_6(m, sfc, S2, s2max, Ep, delta_t)
    flux_ebs = evap_5(m, S2, s2max, Ep, delta_t)
    flux_qse = saturation_1(flux_qtf, S2, s2max)
    flux_qss = interflow_9(S2, a, sfc * s2max, b, delta_t)
    flux_qbf = baseflow_1(tcbf, S2)
    flux_qt = route_uh_current_nb(uh_pending)

    out_dS[0] = P - flux_eint - flux_qtf
    out_dS[1] = flux_qtf - flux_veg - flux_ebs - flux_qse - flux_qss - flux_qbf

    out_fluxes[0] = flux_eint
    out_fluxes[1] = flux_qtf
    out_fluxes[2] = flux_veg
    out_fluxes[3] = flux_ebs
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss
    out_fluxes[6] = flux_qbf
    out_fluxes[7] = flux_qt


_newzealand2_compute_step_numba = numba.njit(cache=True)(_newzealand2_compute_step)


@numba.njit(cache=True)
def _newzealand2_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[4] + fluxes[5] + fluxes[6]


class newzealand2(SingleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_newzealand2_compute_step)
    compiled_step_function = staticmethod(_newzealand2_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_newzealand2_commit_inflow_nb)
    routed_newton_use_predictor = False
    routed_newton_clip_iterates = False

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 8
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 5],
                [1, 2000],
                [0.05, 0.95],
                [0.05, 0.95],
                [0, 1],
                [1, 5],
                [0, 1],
                [1, 120],
            ],
            dtype=np.float64,
        )
        self.param_names = ['s1max', 's2max', 'sfc', 'm', 'a', 'b', 'tcbf', 'd']
        self.param_descriptions = [
            'Maximum interception storage [mm]',
            'Smax, Maximum soil moisture storage [mm]',
            'sfc, Field capacity as fraction of maximum soil moisture [-]',
            'm, Fraction forest [-]',
            'a, Subsurface runoff coefficient [d-1]',
            'b, Runoff non-linearity [-]',
            'tcbf, Baseflow runoff coefficient [d-1]',
            'Routing time delay [d]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["eint", "qtf", "veg", "ebs", "qse", "qss", "qbf", "qt"]
        self.flux_groups = {"Ea": [1, 3, 4], "Q": 8}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        self.store_max = np.array([theta[0], theta[1]], dtype=np.float64)
        weights, _ = full_hydrograph(float(theta[7]), float(self.delta_t), power=1.5)
        routing_state = make_unit_hydro_state(weights)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def residual_jacobian(
        self,
        states: FloatArray,
        previous_states: FloatArray,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        del states, previous_states, step_index, diff_step
        return None
