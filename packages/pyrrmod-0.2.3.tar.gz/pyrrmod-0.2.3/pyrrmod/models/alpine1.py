from __future__ import annotations

import numpy as np

import numba
from pyrrmod.fluxes import melt_1, rainfall_1, saturation_1, snowfall_1

from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray


def _alpine1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    ddf = float(theta[1])
    Smax = float(theta[2])
    tc = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    precip_t = float(precip[step_index])
    pet_t = float(pet[step_index])
    temp_t = float(temp[step_index])

    flux_ps = snowfall_1(precip_t, temp_t, tt)
    flux_pr = rainfall_1(precip_t, temp_t, tt)
    flux_qn = melt_1(ddf, tt, temp_t, S1, delta_t)
    flux_ea = min(S2 / delta_t, pet_t)
    flux_qse = saturation_1(precip_t + flux_qn, S2, Smax)
    flux_qss = tc * S2

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_ea - flux_qse - flux_qss
    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pr
    out_fluxes[2] = flux_qn
    out_fluxes[3] = flux_ea
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss


_alpine1_compute_step_numba = numba.njit(cache=True)(_alpine1_compute_step)


class alpine1(StepKernelModel):
    """Alpine model v1 with a single shared numeric step kernel."""

    python_step_function = staticmethod(_alpine1_compute_step)
    compiled_step_function = staticmethod(_alpine1_compute_step_numba)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 6
        self.num_params = 4

        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [-3, 5],
                [0, 20],
                [1, 2000],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.param_names = ['tt', 'ddf', 'Smax', 'tc']
        self.param_descriptions = [
            'tt [degree celsius]',
            'degree-day-factor [mm/degree celsius/day]',
            'Smax [mm]',
            'time delay of subsurface flow [d-1]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["ps", "pr", "qn", "ea", "qse", "qss"]
        self.flux_groups = {
            "Ea": 4,
            "Q": [5, 6],
        }

    def init(self) -> None:
        """No model-specific runtime initialization is required."""

    def step(self) -> None:
        """No post-step routing update is required for alpine1."""
