from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_1, interflow_8, recharge_3
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _tank_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    a0 = float(theta[0])
    b0 = float(theta[1])
    c0 = float(theta[2])
    a1 = float(theta[3])
    fa = float(theta[4])
    fb = float(theta[5])
    fc = float(theta[6])
    fd = float(theta[7])
    st = float(theta[8])
    f2 = float(theta[9])
    f1 = float(theta[10])
    f3 = float(theta[11])

    t2 = f2 * st
    t1 = t2 + f1 * (st - t2)
    t3 = f3 * (st - t1)
    t4 = st - t1 - t3
    a2 = fa * a1
    b1 = fb * a2
    c1 = fc * b1
    d1 = fd * c1

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_y1 = interflow_8(S1, a1, t1)
    flux_y2 = interflow_8(S1, a2, t2)
    flux_y3 = interflow_8(S2, b1, t3)
    flux_y4 = interflow_8(S3, c1, t4)
    flux_y5 = baseflow_1(d1, S4)
    flux_e1 = evap_1(S1, Ep, delta_t)
    flux_e2 = evap_1(S2, max(0.0, Ep - flux_e1), delta_t)
    flux_e3 = evap_1(S3, max(0.0, Ep - flux_e1 - flux_e2), delta_t)
    flux_e4 = evap_1(S4, max(0.0, Ep - flux_e1 - flux_e2 - flux_e3), delta_t)
    flux_f12 = recharge_3(a0, S1)
    flux_f23 = recharge_3(b0, S2)
    flux_f34 = recharge_3(c0, S3)

    out_dS[0] = P - flux_e1 - flux_f12 - flux_y1 - flux_y2
    out_dS[1] = flux_f12 - flux_e2 - flux_f23 - flux_y3
    out_dS[2] = flux_f23 - flux_e3 - flux_f34 - flux_y4
    out_dS[3] = flux_f34 - flux_e4 - flux_y5

    out_fluxes[0] = flux_y1
    out_fluxes[1] = flux_y2
    out_fluxes[2] = flux_y3
    out_fluxes[3] = flux_y4
    out_fluxes[4] = flux_y5
    out_fluxes[5] = flux_e1
    out_fluxes[6] = flux_e2
    out_fluxes[7] = flux_e3
    out_fluxes[8] = flux_e4
    out_fluxes[9] = flux_f12
    out_fluxes[10] = flux_f23
    out_fluxes[11] = flux_f34


class tank(StepKernelModel):
    python_step_function = staticmethod(_tank_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 12
        self.num_params = 12
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [1, 1, 1, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [0, 1],
                [1, 2000],
                [0.01, 0.99],
                [0.01, 0.99],
                [0.01, 0.99],
            ],
            dtype=np.float64,
        )
        self.param_names = ['a0', 'b0', 'c0', 'a1', 'fa', 'fb', 'fc', 'fd', 'st', 'f2', 'f1', 'f3']
        self.param_descriptions = [
            'a0, Time parameter for drainage 1>2 [d-1]',
            'b0, Time parameter for drainage 2>3 [d-1]',
            'c0, Time parameter for drainage 3>4 [d-1]',
            'a1, Time parameter for surface runoff 1 [d-1]',
            'fa, Fraction of a1 that is a2 [-]',
            'fb, Fraction of a2 that is b1 [-]',
            'fc, Fraction of b1 that is c1 [-]',
            'fd, Fraction of c1 that is d1 [-]',
            'st, Maximum soil depth (sum of runoff thresholds) [mm]',
            'f2, Fraction of st that consitutes threshold t2 [-]',
            'f1, Fraction of st-t2 that is added to t2 to find threshold 1 [-] (ensures t1 > t2)',
            'f3, Fraction of st-t1-t2 that consitutes threshold 3 [-]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "y1",
            "y2",
            "y3",
            "y4",
            "y5",
            "e1",
            "e2",
            "e3",
            "e4",
            "f12",
            "f23",
            "f34",
        ]
        self.flux_groups = {"Ea": [6, 7, 8, 9], "Q": [1, 2, 3, 4, 5]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

