from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    baseflow_2,
    evap_5,
    evap_6,
    interflow_7,
    saturation_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext


def _susannah1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    sb = float(theta[0])
    sfc = float(theta[1])
    m = float(theta[2])
    a = float(theta[3])
    b = float(theta[4])
    r = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ebs = evap_5(m, S1, sb, Ep, delta_t)
    flux_eveg = evap_6(m, sfc, S1, sb, Ep, delta_t)
    flux_qse = saturation_1(P, S1, sb)
    flux_qss = interflow_7(S1, sb, sfc, a, b, delta_t)
    flux_qr = baseflow_1(r, flux_qss)
    flux_qb = baseflow_2(S2, a, b, delta_t)
    flux_qt = flux_qse + (flux_qss - flux_qr) + flux_qb

    out_dS[0] = P - flux_ebs - flux_eveg - flux_qse - flux_qss
    out_dS[1] = flux_qr - flux_qb

    out_fluxes[0] = flux_ebs
    out_fluxes[1] = flux_eveg
    out_fluxes[2] = flux_qse
    out_fluxes[3] = flux_qss
    out_fluxes[4] = flux_qr
    out_fluxes[5] = flux_qb
    out_fluxes[6] = flux_qt


class susannah1(StepKernelModel):
    python_step_function = staticmethod(_susannah1_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 7
        self.num_params = 6
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0.05, 0.95], [1, 50], [0.2, 1], [0, 1]],
            dtype=np.float64,
        )
        self.param_names = ['sb', 'sfc', 'm', 'a', 'b', 'r']
        self.param_descriptions = [
            'Sb, Maximum soil moisture storage [mm]',
            'Sfc, Wilting point as fraction of sb [-]',
            'M, Fraction forest [-]',
            'a, Runoff coefficient [d] (should be > 0)',
            'b, Runoff coefficient [-] (should be > 0)',
            'r, Runoff coefficient [d-1]',
        ]
        self.store_names = ["S1", "S2"]
        self.flux_names = ["Ebs", "Evg", "Qse", "Qss", "qr", "Qb", "qt"]
        self.flux_groups = {"Ea": [1, 2], "Q": 7}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass

