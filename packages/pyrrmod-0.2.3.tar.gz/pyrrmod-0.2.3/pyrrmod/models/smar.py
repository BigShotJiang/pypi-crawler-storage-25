from __future__ import annotations

import numpy as np

import numba
from pyrrmod.unithydro import (
    gamma_hydrograph,
    make_unit_hydro_state,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    effective_1,
    evap_13,
    evap_14,
    infiltration_4,
    saturation_1,
    saturation_6,
    split_1,
)
from pyrrmod.core import HydrologyModel
from pyrrmod.schemas import FloatArray
from pyrrmod.unithydro.routed_newton_mixins import SingleRoutedNewtonMixin


def _smar_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    h = float(theta[0])
    y = float(theta[1])
    smax = float(theta[2])
    c = float(theta[3])
    g = float(theta[4])
    kg = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])
    S6 = float(states[5])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pstar = effective_1(P, Ep)
    flux_estar = effective_1(Ep, P)
    flux_evap = min(Ep, P)
    flux_r1 = saturation_6(h, S1 + S2 + S3 + S4 + S5, smax, flux_pstar)
    flux_i = infiltration_4(flux_pstar - flux_r1, y)
    flux_r2 = effective_1(flux_pstar - flux_r1, flux_i)
    flux_e1 = evap_13(c, 0, flux_estar, S1, delta_t)
    flux_e2 = evap_14(c, 1, flux_estar, S2, S1, 0.1, delta_t)
    flux_e3 = evap_14(c, 2, flux_estar, S3, S2, 0.1, delta_t)
    flux_e4 = evap_14(c, 3, flux_estar, S4, S3, 0.1, delta_t)
    flux_e5 = evap_14(c, 4, flux_estar, S5, S4, 0.1, delta_t)
    flux_q1 = saturation_1(flux_i, S1, smax / 5.0)
    flux_q2 = saturation_1(flux_q1, S2, smax / 5.0)
    flux_q3 = saturation_1(flux_q2, S3, smax / 5.0)
    flux_q4 = saturation_1(flux_q3, S4, smax / 5.0)
    flux_r3 = saturation_1(flux_q4, S5, smax / 5.0)
    flux_rg = split_1(g, flux_r3)
    flux_r3star = split_1(1.0 - g, flux_r3)
    flux_qr = route_uh_current_nb(uh_pending)
    flux_qg = baseflow_1(kg, S6)

    out_dS[0] = flux_i - flux_e1 - flux_q1
    out_dS[1] = flux_q1 - flux_e2 - flux_q2
    out_dS[2] = flux_q2 - flux_e3 - flux_q3
    out_dS[3] = flux_q3 - flux_e4 - flux_q4
    out_dS[4] = flux_q4 - flux_e5 - flux_r3
    out_dS[5] = flux_rg - flux_qg

    out_fluxes[0] = flux_pstar
    out_fluxes[1] = flux_estar
    out_fluxes[2] = flux_evap
    out_fluxes[3] = flux_r1
    out_fluxes[4] = flux_i
    out_fluxes[5] = flux_r2
    out_fluxes[6] = flux_e1
    out_fluxes[7] = flux_e2
    out_fluxes[8] = flux_e3
    out_fluxes[9] = flux_e4
    out_fluxes[10] = flux_e5
    out_fluxes[11] = flux_q1
    out_fluxes[12] = flux_q2
    out_fluxes[13] = flux_q3
    out_fluxes[14] = flux_q4
    out_fluxes[15] = flux_r3
    out_fluxes[16] = flux_rg
    out_fluxes[17] = flux_r3star
    out_fluxes[18] = flux_qr
    out_fluxes[19] = flux_qg


_smar_compute_step_numba = numba.njit(cache=True)(_smar_compute_step)


@numba.njit(cache=True)
def _smar_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[3] + fluxes[5] + fluxes[17]


class smar(SingleRoutedNewtonMixin, HydrologyModel):
    python_step_function = staticmethod(_smar_compute_step)
    compiled_step_function = staticmethod(_smar_compute_step_numba)
    compiled_commit_inflow_function = staticmethod(_smar_commit_inflow_nb)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 6
        self.num_fluxes = 20
        self.num_params = 8
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0, 0],
                [1, 1, 0, 0, 0, 0],
                [1, 1, 1, 0, 0, 0],
                [1, 1, 1, 1, 0, 0],
                [1, 1, 1, 1, 1, 0],
                [1, 1, 1, 1, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [[0, 1], [0, 200], [1, 2000], [0, 1], [0, 1], [0, 1], [1, 10], [1, 120]],
            dtype=np.float64,
        )
        self.param_names = ['h', 'y', 'smax', 'c', 'g', 'kg', 'n', 'nk']
        self.param_descriptions = [
            'h, Maximum fraction of direct runoff [-]',
            'y, Infiltration rate [mm/d]',
            'smax, Maximum soil moisture storage [mm]',
            'c, Evaporation reduction coefficient [-]',
            'g, Groundwater recharge coefficient [-]',
            'kg, Groundwater time parameter [d-1]',
            'n, Number of Nash cascade reservoirs [-]',
            'n*k, Routing delay [d]',
        ]
        self.store_names = ["S1", "S2", "S3", "S4", "S5", "S6"]
        self.flux_names = [
            "pstar",
            "estar",
            "evap",
            "r1",
            "i",
            "r2",
            "e1",
            "e2",
            "e3",
            "e4",
            "e5",
            "q1",
            "q2",
            "q3",
            "q4",
            "r3",
            "rg",
            "r3star",
            "qr",
            "qg",
        ]
        self.flux_groups = {"Ea": [3, 7, 8, 9, 10, 11], "Q": [19, 20]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        n = float(theta[6])
        nk = float(theta[7])
        weights, _ = gamma_hydrograph(n, nk / n, float(self.delta_t))
        routing_state = make_unit_hydro_state(weights)
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
