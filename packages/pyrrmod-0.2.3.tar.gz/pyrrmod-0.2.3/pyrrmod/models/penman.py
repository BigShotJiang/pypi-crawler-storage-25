from __future__ import annotations

import numpy as np
import numba

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.core import StepKernelModel
from pyrrmod.schemas import FloatArray, RuntimeContext
from pyrrmod.solvers.scalar_root import solve_scalar_fsolve_bracketed


def _penman_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    smax = float(theta[0])
    phi = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_1(S1, Ep, delta_t)
    flux_qex = saturation_1(P, S1, smax)
    flux_u1 = split_1(phi, flux_qex)
    flux_q12 = split_1(1.0 - phi, flux_qex)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_u2 = saturation_9(flux_q12, S2, 0.01)
    flux_q = baseflow_1(k1, S3)

    out_dS[0] = P - flux_ea - flux_qex
    out_dS[1] = flux_et + flux_u2 - flux_q12
    out_dS[2] = flux_u1 + flux_u2 - flux_q

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qex
    out_fluxes[2] = flux_u1
    out_fluxes[3] = flux_q12
    out_fluxes[4] = flux_et
    out_fluxes[5] = flux_u2
    out_fluxes[6] = flux_q


@numba.njit(cache=True)
def _penman_s1_residual(
    s1: float,
    s1_prev: float,
    P: float,
    Ep: float,
    smax: float,
    delta_t: float,
) -> float:
    flux_ea = evap_1(s1, Ep, delta_t)
    flux_qex = saturation_1(P, s1, smax)
    return (s1 - s1_prev) / delta_t - (P - flux_ea - flux_qex)


@numba.njit(cache=True)
def _penman_s2_residual(
    s2: float,
    s2_prev: float,
    q12: float,
    et: float,
    delta_t: float,
) -> float:
    flux_u2 = saturation_9(q12, s2, 0.01)
    return (s2 - s2_prev) / delta_t - (et + flux_u2 - q12)


@numba.njit(cache=True)
def _penman_bisect_s1(
    s1_prev: float,
    P: float,
    Ep: float,
    smax: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(s1_prev + delta_t * max(P, 0.0) + 1.0, 1.0)
    f_lower = _penman_s1_residual(lower, s1_prev, P, Ep, smax, delta_t)
    f_upper = _penman_s1_residual(upper, s1_prev, P, Ep, smax, delta_t)
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _penman_s1_residual(upper, s1_prev, P, Ep, smax, delta_t)
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _penman_s1_residual(mid, s1_prev, P, Ep, smax, delta_t)
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _penman_bisect_s2(
    s2_prev: float,
    q12: float,
    et: float,
    delta_t: float,
    tolerance: float,
    max_iter: int,
) -> tuple[float, float, int]:
    lower = 0.0
    upper = max(s2_prev + delta_t * (q12 + et) + 1.0, 1.0)
    f_lower = _penman_s2_residual(lower, s2_prev, q12, et, delta_t)
    f_upper = _penman_s2_residual(upper, s2_prev, q12, et, delta_t)
    nfev = 2
    best_x = lower
    best_residual = abs(f_lower)
    if abs(f_upper) < best_residual:
        best_x = upper
        best_residual = abs(f_upper)

    expansion_count = 0
    while f_upper < 0.0 and expansion_count < 12:
        upper = 2.0 * upper + 1.0
        f_upper = _penman_s2_residual(upper, s2_prev, q12, et, delta_t)
        nfev += 1
        if abs(f_upper) < best_residual:
            best_x = upper
            best_residual = abs(f_upper)
        expansion_count += 1

    for _ in range(max_iter):
        mid = 0.5 * (lower + upper)
        f_mid = _penman_s2_residual(mid, s2_prev, q12, et, delta_t)
        nfev += 1
        abs_mid = abs(f_mid)
        if abs_mid < best_residual:
            best_x = mid
            best_residual = abs_mid
        if abs_mid <= tolerance or 0.5 * (upper - lower) <= tolerance:
            return mid, abs_mid, nfev
        if f_lower * f_mid <= 0.0:
            upper = mid
            f_upper = f_mid
        else:
            lower = mid
            f_lower = f_mid

    return best_x, best_residual, nfev


@numba.njit(cache=True)
def _run_penman_numba_solver(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    tolerance: float,
    max_iter: int,
) -> tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
]:
    n_steps = precip.shape[0]
    stores = np.empty((n_steps, 3), dtype=np.float64)
    fluxes = np.empty((n_steps, 7), dtype=np.float64)
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.zeros(n_steps, dtype=np.int64)

    smax = float(theta[0])
    phi = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])

    prev = np.empty(3, dtype=np.float64)
    dS = np.empty(3, dtype=np.float64)
    step_fluxes = np.empty(7, dtype=np.float64)
    residual = np.empty(3, dtype=np.float64)

    prev[:] = s0

    for step_index in range(n_steps):
        P = float(precip[step_index])
        Ep = float(pet[step_index])

        s1, r1, nfev1 = _penman_bisect_s1(
            prev[0],
            P,
            Ep,
            smax,
            delta_t,
            tolerance,
            max_iter,
        )
        flux_ea = evap_1(s1, Ep, delta_t)
        flux_qex = saturation_1(P, s1, smax)
        flux_u1 = split_1(phi, flux_qex)
        flux_q12 = split_1(1.0 - phi, flux_qex)
        flux_et = evap_16(gam, np.inf, s1, 0.01, Ep, delta_t)

        s2, r2, nfev2 = _penman_bisect_s2(
            prev[1],
            flux_q12,
            flux_et,
            delta_t,
            tolerance,
            max_iter,
        )
        flux_u2 = saturation_9(flux_q12, s2, 0.01)
        s3 = (prev[2] + delta_t * (flux_u1 + flux_u2)) / (1.0 + delta_t * k1)
        flux_q = baseflow_1(k1, s3)

        dS[0] = P - flux_ea - flux_qex
        dS[1] = flux_et + flux_u2 - flux_q12
        dS[2] = flux_u1 + flux_u2 - flux_q

        residual[0] = (s1 - prev[0]) / delta_t - dS[0]
        residual[1] = (s2 - prev[1]) / delta_t - dS[1]
        residual[2] = (s3 - prev[2]) / delta_t - dS[2]
        residual_norm = (
            residual[0] * residual[0]
            + residual[1] * residual[1]
            + residual[2] * residual[2]
        ) ** 0.5

        stores[step_index, 0] = s1
        stores[step_index, 1] = s2
        stores[step_index, 2] = s3

        step_fluxes[0] = flux_ea
        step_fluxes[1] = flux_qex
        step_fluxes[2] = flux_u1
        step_fluxes[3] = flux_q12
        step_fluxes[4] = flux_et
        step_fluxes[5] = flux_u2
        step_fluxes[6] = flux_q
        for flux_index in range(7):
            fluxes[step_index, flux_index] = step_fluxes[flux_index] * delta_t

        residual_norms[step_index] = residual_norm
        iterations[step_index] = max_iter
        nfev[step_index] = nfev1 + nfev2 + 1

        prev[0] = s1
        prev[1] = s2
        prev[2] = s3
    return stores, fluxes, residual_norms, iterations, nfev, njev


class penman(StepKernelModel):
    python_step_function = staticmethod(_penman_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 7
        self.num_params = 4
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.param_names = ['smax', 'phi', 'gam', 'k1']
        self.param_descriptions = [
            'smax, Maximum soil moisture storage [mm]',
            'phi, Fraction of direct runoff [-]',
            'gam, Evaporation reduction in lower zone [-]',
            'k1, Runoff coefficient [d-1]',
        ]
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qex", "u1", "q12", "et", "u2", "q"]
        self.flux_groups = {"Ea": [1, 5], "Q": [7]}
        self.StoreSigns = np.array([1.0, -1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        pass

    def _solve_s1(self, previous: FloatArray, step_index: int) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        smax = float(runtime.theta[0])
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])
        delta_t = float(runtime.delta_t)
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(float(previous[0]) + delta_t * max(P, 0.0) + 1.0, 1.0)
        root, residual, nfev = solve_scalar_fsolve_bracketed(
            lambda value: _penman_s1_residual(
                float(value),
                float(previous[0]),
                P,
                Ep,
                smax,
                delta_t,
            ),
            float(previous[0]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )
        return root, residual, nfev

    def _solve_s2(
        self,
        previous: FloatArray,
        q12: float,
        et: float,
        step_index: int,
    ) -> tuple[float, float, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        delta_t = float(runtime.delta_t)
        tol = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        upper = max(float(previous[1]) + delta_t * (q12 + et) + 1.0, 1.0)
        root, residual, nfev = solve_scalar_fsolve_bracketed(
            lambda value: _penman_s2_residual(
                float(value),
                float(previous[1]),
                q12,
                et,
                delta_t,
            ),
            float(previous[1]),
            lower_bound=0.0,
            upper_bound=upper,
            tolerance=tol,
        )
        return root, residual, nfev

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        previous = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        P = float(runtime.precip[step_index])
        Ep = float(runtime.pet[step_index])
        smax = float(theta[0])
        phi = float(theta[1])
        gam = float(theta[2])
        k1 = float(theta[3])

        s1, r1, nfev1 = self._solve_s1(previous, step_index)
        flux_ea = evap_1(s1, Ep, delta_t)
        flux_qex = saturation_1(P, s1, smax)
        flux_u1 = split_1(phi, flux_qex)
        flux_q12 = split_1(1.0 - phi, flux_qex)
        flux_et = evap_16(gam, np.inf, s1, 0.01, Ep, delta_t)

        s2, r2, nfev2 = self._solve_s2(previous, flux_q12, flux_et, step_index)
        flux_u2 = saturation_9(flux_q12, s2, 0.01)
        s3 = (float(previous[2]) + delta_t * (flux_u1 + flux_u2)) / (1.0 + delta_t * k1)
        flux_q = baseflow_1(k1, s3)

        state = np.asarray([s1, s2, s3], dtype=np.float64)
        fluxes = np.asarray(
            [flux_ea, flux_qex, flux_u1, flux_q12, flux_et, flux_u2, flux_q],
            dtype=np.float64,
        )
        residual = np.asarray(
            [
                _penman_s1_residual(s1, float(previous[0]), P, Ep, smax, delta_t),
                _penman_s2_residual(s2, float(previous[1]), flux_q12, flux_et, delta_t),
                (s3 - float(previous[2])) / delta_t - (flux_u1 + flux_u2 - flux_q),
            ],
            dtype=np.float64,
        )
        return state, fluxes, float(np.linalg.norm(residual)), int(nfev1 + nfev2 + 1), 0

    def _run_compiled_numba_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        tolerance = float(self.solver_opts.get("resnorm_tolerance", 1.0e-8))
        max_iter = int(self.solver_opts.get("resnorm_maxiter", 40))
        stores, fluxes, resnorm, iterations, nfev, njev = _run_penman_numba_solver(
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            tolerance,
            max_iter,
        )
        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(int(runtime.precip.shape[0]), "numba_newton", dtype=object),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }

    def step(self) -> None:
        pass

