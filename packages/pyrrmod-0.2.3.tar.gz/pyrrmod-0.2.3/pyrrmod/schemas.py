from dataclasses import dataclass
from typing import Any, Callable, Literal, Self

import numpy as np
from pydantic import AliasChoices, BaseModel, ConfigDict, Field
from pydantic import field_validator, model_validator


FloatArray = np.ndarray


def _as_float_array(value: Any, *, field_name: str) -> FloatArray:
    array = np.asarray(value, dtype=np.float64).reshape(-1)
    if array.size == 0:
        raise ValueError(f"{field_name} cannot be empty")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{field_name} must contain only finite values")
    return array


@dataclass(slots=True, kw_only=True)
class UnitHydroLine:
    weights: FloatArray
    pending: FloatArray


@dataclass(slots=True, kw_only=True)
class UnitHydroState:
    lines: tuple[UnitHydroLine, ...]

    def pending_total(self) -> float:
        return float(sum(np.sum(line.pending) for line in self.lines))

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [(line.weights, line.pending) for line in self.lines]

    def pending_args(self) -> tuple[FloatArray, ...]:
        return tuple(line.pending for line in self.lines)

    def copy_pending(self) -> tuple[FloatArray, ...]:
        return tuple(
            np.ascontiguousarray(line.pending.copy(), dtype=np.float64)
            for line in self.lines
        )

    def restore_pending(self, pending_arrays: tuple[FloatArray, ...]) -> None:
        if len(pending_arrays) != len(self.lines):
            raise ValueError("pending array count must match unit hydrograph count")
        for line, pending in zip(self.lines, pending_arrays):
            line.pending[:] = np.asarray(pending, dtype=np.float64)

    @property
    def line_count(self) -> int:
        return len(self.lines)

    def _single_line(self) -> UnitHydroLine:
        if self.line_count != 1:
            raise AttributeError("single unit hydrograph properties are unavailable")
        return self.lines[0]

    def _indexed_line(
        self, index: int, *, minimum_count: int, name: str
    ) -> UnitHydroLine:
        if self.line_count < minimum_count:
            raise AttributeError(name)
        return self.lines[index]

    @property
    def uh_weights(self) -> FloatArray:
        return self._single_line().weights

    @property
    def uh_pending(self) -> FloatArray:
        return self._single_line().pending

    @property
    def uh1_weights(self) -> FloatArray:
        return self._indexed_line(0, minimum_count=2, name="uh1_weights").weights

    @property
    def uh1_pending(self) -> FloatArray:
        return self._indexed_line(0, minimum_count=2, name="uh1_pending").pending

    @property
    def uh2_weights(self) -> FloatArray:
        return self._indexed_line(1, minimum_count=2, name="uh2_weights").weights

    @property
    def uh2_pending(self) -> FloatArray:
        return self._indexed_line(1, minimum_count=2, name="uh2_pending").pending

    @property
    def uh3_weights(self) -> FloatArray:
        return self._indexed_line(2, minimum_count=3, name="uh3_weights").weights

    @property
    def uh3_pending(self) -> FloatArray:
        return self._indexed_line(2, minimum_count=3, name="uh3_pending").pending


class SingleUHState(UnitHydroState):
    def __init__(self, *, uh_weights: FloatArray, uh_pending: FloatArray) -> None:
        super().__init__(lines=(UnitHydroLine(weights=uh_weights, pending=uh_pending),))


class DoubleUHState(UnitHydroState):
    def __init__(
        self,
        *,
        uh1_weights: FloatArray,
        uh1_pending: FloatArray,
        uh2_weights: FloatArray,
        uh2_pending: FloatArray,
    ) -> None:
        super().__init__(
            lines=(
                UnitHydroLine(weights=uh1_weights, pending=uh1_pending),
                UnitHydroLine(weights=uh2_weights, pending=uh2_pending),
            )
        )


class TripleUHState(UnitHydroState):
    def __init__(
        self,
        *,
        uh1_weights: FloatArray,
        uh1_pending: FloatArray,
        uh2_weights: FloatArray,
        uh2_pending: FloatArray,
        uh3_weights: FloatArray,
        uh3_pending: FloatArray,
    ) -> None:
        super().__init__(
            lines=(
                UnitHydroLine(weights=uh1_weights, pending=uh1_pending),
                UnitHydroLine(weights=uh2_weights, pending=uh2_pending),
                UnitHydroLine(weights=uh3_weights, pending=uh3_pending),
            )
        )


class ClimateInput(BaseModel):
    model_config = ConfigDict(
        arbitrary_types_allowed=True, populate_by_name=True, extra="forbid"
    )

    precip: Any = Field(validation_alias=AliasChoices("precip", "rainfall"))
    temp: Any = Field(validation_alias=AliasChoices("temp", "temperature"))
    pet: Any = Field(validation_alias=AliasChoices("pet", "PET"))

    @field_validator("precip", "temp", "pet", mode="before")
    @classmethod
    def _coerce_array(cls, value: Any, info: Any) -> FloatArray:
        return _as_float_array(value, field_name=str(info.field_name))

    @model_validator(mode="after")
    def _validate_lengths(self) -> Self:
        n = int(self.precip.shape[0])
        if int(self.temp.shape[0]) != n or int(self.pet.shape[0]) != n:
            raise ValueError("climate arrays must have the same length")
        return self


class SolverOptionsInput(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    resnorm_tolerance: float = Field(
        1e-8, validation_alias=AliasChoices("resnorm_tolerance", "TolFun")
    )
    resnorm_maxiter: int = Field(
        50, validation_alias=AliasChoices("resnorm_maxiter", "MaxIter")
    )
    diff_step: float = Field(
        1e-6, validation_alias=AliasChoices("diff_step", "DiffStep")
    )
    damping: float = Field(1.0, validation_alias=AliasChoices("damping", "Damping"))
    legacy_state_update: bool = Field(
        True,
        validation_alias=AliasChoices(
            "legacy_state_update",
            "compat_writeback",
        ),
    )
    retry_solver: bool = Field(
        True,
        validation_alias=AliasChoices(
            "retry_solver",
            "compat_rerun",
        ),
    )


class ModelConfigInput(BaseModel):
    model_config = ConfigDict(
        arbitrary_types_allowed=True, populate_by_name=True, extra="forbid"
    )

    delta_t: float
    S0: Any = Field(validation_alias=AliasChoices("S0", "initial_stores"))
    input_climate: Any = Field(
        validation_alias=AliasChoices("input_climate", "climate")
    )
    solver_opts: Any | None = Field(
        default=None,
        validation_alias=AliasChoices("solver_opts", "solver_options"),
    )
    compile_target: Literal["auto", "python", "numba"] = "numba"

    @field_validator("S0", mode="before")
    @classmethod
    def _coerce_s0(cls, value: Any) -> FloatArray:
        return _as_float_array(value, field_name="S0")

    @field_validator("input_climate", mode="before")
    @classmethod
    def _coerce_input_climate(cls, value: Any) -> ClimateInput:
        if isinstance(value, ClimateInput):
            return value
        return ClimateInput.model_validate(value)

    @field_validator("solver_opts", mode="before")
    @classmethod
    def _coerce_solver_opts(cls, value: Any) -> SolverOptionsInput | None:
        if value is None or isinstance(value, SolverOptionsInput):
            return value
        return SolverOptionsInput.model_validate(value)


class ModelRunInput(ModelConfigInput):
    theta: Any

    @field_validator("theta", mode="before")
    @classmethod
    def _coerce_theta(cls, value: Any) -> FloatArray:
        return _as_float_array(value, field_name="theta")


@dataclass(slots=True)
class ClimateArrays:
    precip: FloatArray
    temp: FloatArray
    pet: FloatArray


@dataclass(slots=True)
class RuntimeContext:
    theta: FloatArray
    delta_t: float
    S0: FloatArray
    precip: FloatArray
    temp: FloatArray
    pet: FloatArray
    climate: ClimateArrays
    stores: FloatArray
    fluxes: FloatArray
    solver_opts: dict[str, Any]
    store_min: FloatArray
    store_max: FloatArray
    routing_state: Any = None


@dataclass(slots=True)
class CompilerState:
    requested_target: str = "auto"
    target: str = "python"
    enabled: bool = False
    detail: str = "python kernel"
    compiled_model_fun: (
        Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
    ) = None


__all__ = [
    "ClimateArrays",
    "ClimateInput",
    "CompilerState",
    "DoubleUHState",
    "FloatArray",
    "ModelConfigInput",
    "ModelRunInput",
    "RuntimeContext",
    "SingleUHState",
    "SolverOptionsInput",
    "TripleUHState",
    "UnitHydroLine",
    "UnitHydroState",
    "_as_float_array",
]
