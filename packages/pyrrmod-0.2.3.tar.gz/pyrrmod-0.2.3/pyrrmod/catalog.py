from pyrrmod.models.collie1 import collie1
from pyrrmod.models.wetland import wetland
from pyrrmod.models.collie2 import collie2
from pyrrmod.models.newzealand1 import newzealand1
from pyrrmod.models.ihacres import ihacres
from pyrrmod.models.alpine1 import alpine1
from pyrrmod.models.gr4j import gr4j
from pyrrmod.models.us1 import us1
from pyrrmod.models.susannah1 import susannah1
from pyrrmod.models.susannah2 import susannah2
from pyrrmod.models.collie3 import collie3
from pyrrmod.models.alpine2 import alpine2
from pyrrmod.models.hillslope import hillslope
from pyrrmod.models.topmodel import topmodel
from pyrrmod.models.plateau import plateau
from pyrrmod.models.newzealand2 import newzealand2
from pyrrmod.models.penman import penman
from pyrrmod.models.simhyd import simhyd
from pyrrmod.models.australia import australia
from pyrrmod.models.gsfb import gsfb
from pyrrmod.models.flexb import flexb
from pyrrmod.models.vic import vic
from pyrrmod.models.mopex1 import mopex1
from pyrrmod.models.tcm import tcm
from pyrrmod.models.flexi import flexi
from pyrrmod.models.tank import tank
from pyrrmod.models.xinanjiang import xinanjiang
from pyrrmod.models.hymod import hymod
from pyrrmod.models.mopex2 import mopex2
from pyrrmod.models.mopex3 import mopex3
from pyrrmod.models.mopex4 import mopex4
from pyrrmod.models.flexis import flexis
from pyrrmod.models.mopex5 import mopex5
from pyrrmod.models.modhydrolog import modhydrolog
from pyrrmod.models.hbv import hbv
from pyrrmod.models.smar import smar

MODEL_REGISTRY = {
    "collie1": collie1,
    "wetland": wetland,
    "collie2": collie2,
    "newzealand1": newzealand1,
    "ihacres": ihacres,
    "alpine1": alpine1,
    "gr4j": gr4j,
    "us1": us1,
    "susannah1": susannah1,
    "susannah2": susannah2,
    "collie3": collie3,
    "alpine2": alpine2,
    "hillslope": hillslope,
    "topmodel": topmodel,
    "plateau": plateau,
    "newzealand2": newzealand2,
    "penman": penman,
    "simhyd": simhyd,
    "australia": australia,
    "gsfb": gsfb,
    "flexb": flexb,
    "vic": vic,
    "mopex1": mopex1,
    "tcm": tcm,
    "flexi": flexi,
    "tank": tank,
    "xinanjiang": xinanjiang,
    "hymod": hymod,
    "mopex2": mopex2,
    "mopex3": mopex3,
    "mopex4": mopex4,
    "flexis": flexis,
    "mopex5": mopex5,
    "modhydrolog": modhydrolog,
    "hbv": hbv,
    "smar": smar,
}

MODEL_METADATA = {
    "collie1": {
        "legacy_name": "m_01_collie1_1p_1s",
        "index": 1,
        "parameter_count": 1,
        "store_count": 1,
    },
    "wetland": {
        "legacy_name": "m_02_wetland_4p_1s",
        "index": 2,
        "parameter_count": 4,
        "store_count": 1,
    },
    "collie2": {
        "legacy_name": "m_03_collie2_4p_1s",
        "index": 3,
        "parameter_count": 4,
        "store_count": 1,
    },
    "newzealand1": {
        "legacy_name": "m_04_newzealand1_6p_1s",
        "index": 4,
        "parameter_count": 6,
        "store_count": 1,
    },
    "ihacres": {
        "legacy_name": "m_05_ihacres_7p_1s",
        "index": 5,
        "parameter_count": 7,
        "store_count": 1,
    },
    "alpine1": {
        "legacy_name": "m_06_alpine1_4p_2s",
        "index": 6,
        "parameter_count": 4,
        "store_count": 2,
    },
    "gr4j": {
        "legacy_name": "m_07_gr4j_4p_2s",
        "index": 7,
        "parameter_count": 4,
        "store_count": 2,
    },
    "us1": {
        "legacy_name": "m_08_us1_5p_2s",
        "index": 8,
        "parameter_count": 5,
        "store_count": 2,
    },
    "susannah1": {
        "legacy_name": "m_09_susannah1_6p_2s",
        "index": 9,
        "parameter_count": 6,
        "store_count": 2,
    },
    "susannah2": {
        "legacy_name": "m_10_susannah2_6p_2s",
        "index": 10,
        "parameter_count": 6,
        "store_count": 2,
    },
    "collie3": {
        "legacy_name": "m_11_collie3_6p_2s",
        "index": 11,
        "parameter_count": 6,
        "store_count": 2,
    },
    "alpine2": {
        "legacy_name": "m_12_alpine2_6p_2s",
        "index": 12,
        "parameter_count": 6,
        "store_count": 2,
    },
    "hillslope": {
        "legacy_name": "m_13_hillslope_7p_2s",
        "index": 13,
        "parameter_count": 7,
        "store_count": 2,
    },
    "topmodel": {
        "legacy_name": "m_14_topmodel_7p_2s",
        "index": 14,
        "parameter_count": 7,
        "store_count": 2,
    },
    "plateau": {
        "legacy_name": "m_15_plateau_8p_2s",
        "index": 15,
        "parameter_count": 8,
        "store_count": 2,
    },
    "newzealand2": {
        "legacy_name": "m_16_newzealand2_8p_2s",
        "index": 16,
        "parameter_count": 8,
        "store_count": 2,
    },
    "penman": {
        "legacy_name": "m_17_penman_4p_3s",
        "index": 17,
        "parameter_count": 4,
        "store_count": 3,
    },
    "simhyd": {
        "legacy_name": "m_18_simhyd_7p_3s",
        "index": 18,
        "parameter_count": 7,
        "store_count": 3,
    },
    "australia": {
        "legacy_name": "m_19_australia_8p_3s",
        "index": 19,
        "parameter_count": 8,
        "store_count": 3,
    },
    "gsfb": {
        "legacy_name": "m_20_gsfb_8p_3s",
        "index": 20,
        "parameter_count": 8,
        "store_count": 3,
    },
    "flexb": {
        "legacy_name": "m_21_flexb_9p_3s",
        "index": 21,
        "parameter_count": 9,
        "store_count": 3,
    },
    "vic": {
        "legacy_name": "m_22_vic_10p_3s",
        "index": 22,
        "parameter_count": 10,
        "store_count": 3,
    },
    "lascam": {
        "legacy_name": "m_23_lascam_24p_3s",
        "index": 23,
        "parameter_count": 24,
        "store_count": 3,
    },
    "mopex1": {
        "legacy_name": "m_24_mopex1_5p_4s",
        "index": 24,
        "parameter_count": 5,
        "store_count": 4,
    },
    "tcm": {
        "legacy_name": "m_25_tcm_6p_4s",
        "index": 25,
        "parameter_count": 6,
        "store_count": 4,
    },
    "flexi": {
        "legacy_name": "m_26_flexi_10p_4s",
        "index": 26,
        "parameter_count": 10,
        "store_count": 4,
    },
    "tank": {
        "legacy_name": "m_27_tank_12p_4s",
        "index": 27,
        "parameter_count": 12,
        "store_count": 4,
    },
    "xinanjiang": {
        "legacy_name": "m_28_xinanjiang_12p_4s",
        "index": 28,
        "parameter_count": 12,
        "store_count": 4,
    },
    "hymod": {
        "legacy_name": "m_29_hymod_5p_5s",
        "index": 29,
        "parameter_count": 5,
        "store_count": 5,
    },
    "mopex2": {
        "legacy_name": "m_30_mopex2_7p_5s",
        "index": 30,
        "parameter_count": 7,
        "store_count": 5,
    },
    "mopex3": {
        "legacy_name": "m_31_mopex3_8p_5s",
        "index": 31,
        "parameter_count": 8,
        "store_count": 5,
    },
    "mopex4": {
        "legacy_name": "m_32_mopex4_10p_5s",
        "index": 32,
        "parameter_count": 10,
        "store_count": 5,
    },
    "sacramento": {
        "legacy_name": "m_33_sacramento_11p_5s",
        "index": 33,
        "parameter_count": 11,
        "store_count": 5,
    },
    "flexis": {
        "legacy_name": "m_34_flexis_12p_5s",
        "index": 34,
        "parameter_count": 12,
        "store_count": 5,
    },
    "mopex5": {
        "legacy_name": "m_35_mopex5_12p_5s",
        "index": 35,
        "parameter_count": 12,
        "store_count": 5,
    },
    "modhydrolog": {
        "legacy_name": "m_36_modhydrolog_15p_5s",
        "index": 36,
        "parameter_count": 15,
        "store_count": 5,
    },
    "hbv": {
        "legacy_name": "m_37_hbv_15p_5s",
        "index": 37,
        "parameter_count": 15,
        "store_count": 5,
    },
    "tank2": {
        "legacy_name": "m_38_tank2_16p_5s",
        "index": 38,
        "parameter_count": 16,
        "store_count": 5,
    },
    "mcrm": {
        "legacy_name": "m_39_mcrm_16p_5s",
        "index": 39,
        "parameter_count": 16,
        "store_count": 5,
    },
    "smar": {
        "legacy_name": "m_40_smar_8p_6s",
        "index": 40,
        "parameter_count": 8,
        "store_count": 6,
    },
    "nam": {
        "legacy_name": "m_41_nam_10p_6s",
        "index": 41,
        "parameter_count": 10,
        "store_count": 6,
    },
    "hycymodel": {
        "legacy_name": "m_42_hycymodel_12p_6s",
        "index": 42,
        "parameter_count": 12,
        "store_count": 6,
    },
    "gsmsocont": {
        "legacy_name": "m_43_gsmsocont_12p_6s",
        "index": 43,
        "parameter_count": 12,
        "store_count": 6,
    },
    "echo": {
        "legacy_name": "m_44_echo_16p_6s",
        "index": 44,
        "parameter_count": 16,
        "store_count": 6,
    },
    "prms": {
        "legacy_name": "m_45_prms_18p_7s",
        "index": 45,
        "parameter_count": 18,
        "store_count": 7,
    },
    "classic": {
        "legacy_name": "m_46_classic_12p_8s",
        "index": 46,
        "parameter_count": 12,
        "store_count": 8,
    },
    "ihm19": {
        "legacy_name": "m_47_ihm19_16p_4s",
        "index": 47,
        "parameter_count": 16,
        "store_count": 4,
    },
}


def create_model(name):
    resolved_name = name
    if resolved_name not in MODEL_REGISTRY:
        for model_name, metadata in MODEL_METADATA.items():
            if metadata.get("legacy_name") == name:
                resolved_name = model_name
                break
    if resolved_name not in MODEL_REGISTRY:
        available = ", ".join(sorted(MODEL_REGISTRY))
        raise KeyError(f"Unknown model '{name}'. Available models: {available}")
    return MODEL_REGISTRY[resolved_name]()


__all__ = [
    "MODEL_REGISTRY",
    "MODEL_METADATA",
    "create_model",
    "collie1",
    "wetland",
    "collie2",
    "newzealand1",
    "ihacres",
    "alpine1",
    "gr4j",
    "us1",
    "susannah1",
    "susannah2",
    "collie3",
    "alpine2",
    "hillslope",
    "topmodel",
    "plateau",
    "newzealand2",
    "penman",
    "simhyd",
    "australia",
    "gsfb",
    "flexb",
    "vic",
    "mopex1",
    "tcm",
    "flexi",
    "tank",
    "xinanjiang",
    "hymod",
    "mopex2",
    "mopex3",
    "mopex4",
    "flexis",
    "mopex5",
    "modhydrolog",
    "hbv",
    "smar",
]
