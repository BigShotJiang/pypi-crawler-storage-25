# Solver Benchmark Update for `03604000.csv`

This note records the latest targeted check for the three previously slow non-UH models:

- `gsfb`
- `penman`
- `tcm`

## Current Decision

These three models now use specialized `numba_newton` implementations again.

They no longer route all `solver='numba_newton'` calls through `fsolve`.

This means:

- `numba_newton` is actually executed
- speed is dramatically better
- some deviation from `pymarrmot` is accepted for this path

## Why `tcm` Was Expensive

`tcm` does not need a generic 4D root solve at every time step.

Its store dependence is effectively lower-triangular:

1. `S1` depends only on `S1`
2. `S2` depends on `S1` and `S2`
3. `S3` depends on `S1`, `S2`, `S3`
4. `S4` depends on `S3`, `S4`

So the expensive part in the old path was not the model physics itself, but using a generic multi-variable `fsolve` loop for something that can be solved in sequence.

The current `tcm` `numba_newton` path now does this instead:

- scalar solve for `S1`
- scalar solve for `S2`
- closed-form update for `S3`
- scalar solve for `S4`

That is why the runtime drops from tens of seconds to a few milliseconds.

## Benchmark Setup

- Dataset: `E:\PyCode\PyRRMod\data\03604000.csv`
- Forcing length: `365 * 4 = 1460`
- Initial stores: all `50.0`
- Parameter pick: `low + 0.30 * (high - low)`
- Compile target below: `numba`
- Timing metric below: one hot run after one warm-up run

## Updated Timings

| model | requested solver | actual solver | elapsed (s) | max resnorm |
| --- | --- | --- | ---: | ---: |
| `gsfb` | `fsolve` | `fsolve` | 3.074029 | 4.015685e+01 |
| `gsfb` | `numba_newton` | `numba_newton` | 0.002506 | 1.168611e-05 |
| `penman` | `fsolve` | `fsolve` | 0.162386 | 9.833784e-09 |
| `penman` | `numba_newton` | `numba_newton` | 0.002923 | 5.489610e-05 |
| `tcm` | `fsolve` | `fsolve` | 30.077907 | 1.451590e+02 |
| `tcm` | `numba_newton` | `numba_newton` | 0.003210 | 3.079582e-04 |

## Alignment With `pymarrmot`

I checked `solver='numba_newton'` with `compile_target='numba'` over parameter percentiles `p05/p25/p50/p75/p95`.

Maximum streamflow deviation versus `pymarrmot`:

| model | max `|Q_pyrrmod - Q_pymarrmot|` over `p05..p95` |
| --- | ---: |
| `gsfb` | 42.080217 |
| `penman` | 12.966286 |
| `tcm` | 8.308108 |

Interpretation:

- `gsfb`: much faster, but high-parameter-range differences remain
- `penman`: much faster, moderate differences remain
- `tcm`: much faster, and the dedicated sequential logic avoids the old large time cost

## Files Changed

- `pyrrmod/models/gsfb.py`
- `pyrrmod/models/penman.py`
- `pyrrmod/models/tcm.py`
- `test/test_solver_backends.py`

## Verification

Passed:

```bash
python -m pytest test/test_solver_backends.py -q -k specialized_non_uh_numba_newton_smoke
```

Result:

- `3 passed`
