# -- coding: utf-8 --
# Project: fiuai-sdk-python
# Created Date: 2026-03-09
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

import asyncio
import functools
from typing import Callable, Optional, Union

from ...utils.logger import get_logger
from .cache_client import CacheClient
from .types import CacheConfig

logger = get_logger(__name__)

_default_client: Optional[CacheClient] = None


def init_cache(config: CacheConfig) -> CacheClient:
    """初始化模块级默认 CacheClient (供 @cached 装饰器使用)

    项目启动时调用一次:
        from fiuai_sdk_python.pkg.cache import init_cache, CacheConfig
        init_cache(CacheConfig(redis_db_name="default", default_ttl=120, key_prefix="finnexus"))
    """
    global _default_client
    _default_client = CacheClient(config)
    return _default_client


def get_default_client() -> Optional[CacheClient]:
    return _default_client


def cached(
    key: Union[str, Callable[..., str]],
    ttl: Optional[int] = None,
    prefix: str = "",
    client: Optional[CacheClient] = None,
):
    """函数级缓存装饰器 (cache-aside)

    支持 sync 和 async 函数。
    key 可以是固定字符串, 也可以是根据函数参数动态生成 key 的 callable。

    用法:
        @cached(key=lambda company_id, side: f"config:{company_id}:{side}", ttl=120)
        def get_company_config(company_id: str, side: str) -> Config:
            ...

        @cached(key="global_settings", ttl=300)
        async def get_settings() -> Settings:
            ...
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            cache = client or _default_client
            if cache is None:
                return await fn(*args, **kwargs)

            cache_key = _resolve_key(key, prefix, args, kwargs)
            return await cache.get_or_load(
                key=cache_key,
                loader=lambda: fn(*args, **kwargs),
                ttl=ttl,
            )

        @functools.wraps(fn)
        def sync_wrapper(*args, **kwargs):
            cache = client or _default_client
            if cache is None:
                return fn(*args, **kwargs)

            cache_key = _resolve_key(key, prefix, args, kwargs)
            return cache.get_or_load_sync(
                key=cache_key,
                loader=lambda: fn(*args, **kwargs),
                ttl=ttl,
            )

        if asyncio.iscoroutinefunction(fn):
            return async_wrapper
        return sync_wrapper

    return decorator


def _resolve_key(
    key: Union[str, Callable],
    prefix: str,
    args: tuple,
    kwargs: dict,
) -> str:
    if callable(key) and not isinstance(key, str):
        raw = key(*args, **kwargs)
    else:
        raw = str(key)
    if prefix:
        return f"{prefix}:{raw}"
    return raw
