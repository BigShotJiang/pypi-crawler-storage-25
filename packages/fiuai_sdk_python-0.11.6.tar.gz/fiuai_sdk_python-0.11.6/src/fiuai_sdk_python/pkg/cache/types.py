# -- coding: utf-8 --
# Project: fiuai-sdk-python
# Created Date: 2026-03-09
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class CircuitState(str, Enum):
    """熔断器状态"""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerConfig(BaseModel):
    """熔断器配置"""

    failure_threshold: int = Field(
        default=5,
        description="连续失败次数达此值后熔断",
    )
    recovery_timeout: float = Field(
        default=30.0,
        description="熔断后冷却秒数, 之后进入半开",
    )
    half_open_max_calls: int = Field(
        default=1,
        description="半开状态允许探测的请求数",
    )


class CacheConfig(BaseModel):
    """CacheClient 配置"""

    default_ttl: Optional[int] = Field(
        default=None,
        description="默认 TTL (秒), None 表示不过期",
    )
    key_prefix: str = Field(
        default="",
        description="key 前缀, 如 'finnexus' 或 'world'",
    )
    redis_db_name: str = Field(
        default="default",
        description="redis_manager 中注册的连接池名称",
    )
    circuit_breaker: CircuitBreakerConfig = Field(
        default_factory=CircuitBreakerConfig,
        description="熔断器配置, 用于 Redis 不可用时降级",
    )
