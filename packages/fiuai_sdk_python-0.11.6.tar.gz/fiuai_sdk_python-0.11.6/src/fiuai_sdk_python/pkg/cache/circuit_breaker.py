# -- coding: utf-8 --
# Project: fiuai-sdk-python
# Created Date: 2026-03-09
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

import threading
import time

from ...utils.logger import get_logger
from .types import CircuitBreakerConfig, CircuitState

logger = get_logger(__name__)


class CircuitBreaker:
    """三态熔断器 (CLOSED -> OPEN -> HALF_OPEN -> CLOSED)

    CLOSED:    正常, 记录连续失败
    OPEN:      熔断, 所有调用直接跳过 Redis, 走 fallback
    HALF_OPEN: 冷却期过后, 允许少量探测请求
    """

    def __init__(self, config: CircuitBreakerConfig):
        self._config = config
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: float = 0
        self._half_open_calls = 0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                elapsed = time.monotonic() - self._last_failure_time
                if elapsed >= self._config.recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_calls = 0
                    logger.info("circuit breaker: OPEN -> HALF_OPEN")
            return self._state

    @property
    def allow_request(self) -> bool:
        """当前是否允许请求 Redis"""
        current_state = self.state
        if current_state == CircuitState.CLOSED:
            return True
        if current_state == CircuitState.HALF_OPEN:
            with self._lock:
                if self._half_open_calls < self._config.half_open_max_calls:
                    self._half_open_calls += 1
                    return True
            return False
        return False

    def record_success(self):
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                logger.info("circuit breaker: HALF_OPEN -> CLOSED")
            self._state = CircuitState.CLOSED
            self._failure_count = 0

    def record_failure(self):
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.monotonic()
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                logger.warning("circuit breaker: HALF_OPEN -> OPEN (probe failed)")
            elif self._failure_count >= self._config.failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    f"circuit breaker: CLOSED -> OPEN "
                    f"(failures={self._failure_count})"
                )
