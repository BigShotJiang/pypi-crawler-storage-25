# -- coding: utf-8 --
# Project: fiuai-sdk-python
# Created Date: 2024-03-21
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Dict, List, Set

from pydantic import BaseModel, Field
from redis import ConnectionPool as SyncConnectionPool
from redis import Redis as SyncRedis
from redis.asyncio import ConnectionPool as AsyncConnectionPool
from redis.asyncio import Redis as AsyncRedis

from ...utils.logger import get_logger
from ...utils.text import safe_str

logger = get_logger(__name__)


class RedisDBConfig(BaseModel):
    name: str = Field(description="连接名称")
    host: str = Field(description="Redis主机")
    port: int = Field(description="Redis端口")
    password: str = Field(description="Redis密码")
    db: int = Field(description="Redis数据库编号")
    pool_size: int = Field(description="Redis连接池大小", default=20)
    ttl: int = Field(description="Redis TTL", default=86400)


class RedisManager:
    """Redis 连接池管理器 (单例)

    管理多个 Redis 连接池, 每个连接池对应不同的数据库。
    支持同步和异步两种模式, 支持增量注册新连接池。
    """

    _instance = None
    _async_pools: Dict[str, AsyncConnectionPool] = {}
    _sync_pools: Dict[str, SyncConnectionPool] = {}
    _async_registered: Set[str] = set()
    _sync_registered: Set[str] = set()

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, "_inited"):
            self._async_pools = {}
            self._sync_pools = {}
            self._async_registered = set()
            self._sync_registered = set()
            self._inited = True

    @property
    def is_initialized(self) -> bool:
        return bool(self._async_registered or self._sync_registered)

    async def initialize(
        self,
        async_dbs: List[RedisDBConfig] | None = None,
        sync_dbs: List[RedisDBConfig] | None = None,
    ):
        """初始化 Redis 连接池 (支持增量注册: 已存在的 pool 跳过, 新的追加)"""
        for db in async_dbs or []:
            if db.name not in self._async_registered:
                await self.get_async_pool(db)
                self._async_registered.add(db.name)
                logger.info(f"registered async pool: {db.name}")

        for db in sync_dbs or []:
            if db.name not in self._sync_registered:
                self.get_sync_pool(db)
                self._sync_registered.add(db.name)
                logger.info(f"registered sync pool: {db.name}")

    async def get_async_pool(self, db: RedisDBConfig) -> AsyncConnectionPool:
        """获取指定数据库的异步连接池, 不存在则创建"""
        if db.name not in self._async_pools:
            self._async_pools[db.name] = AsyncConnectionPool.from_url(
                f"redis://:{safe_str(db.password)}@{db.host}:{db.port}/{db.db}",
                db=db.db,
                decode_responses=True,
                max_connections=db.pool_size,
            )
        return self._async_pools[db.name]

    def get_sync_pool(self, db: RedisDBConfig) -> SyncConnectionPool:
        """获取指定数据库的同步连接池, 不存在则创建 (纯连接池, 不执行 LangGraph setup)"""
        if db.name not in self._sync_pools:
            self._sync_pools[db.name] = SyncConnectionPool.from_url(
                f"redis://:{safe_str(db.password)}@{db.host}:{db.port}/{db.db}",
                db=db.db,
                decode_responses=True,
                max_connections=db.pool_size,
            )
        return self._sync_pools[db.name]

    def get_async_client(self, db_name: str) -> AsyncRedis:
        """获取指定数据库的异步 Redis 客户端"""
        if db_name not in self._async_pools:
            raise RuntimeError(f"async pool not registered: {db_name}")
        return AsyncRedis(connection_pool=self._async_pools[db_name])

    def get_sync_client(self, db_name: str) -> SyncRedis:
        """获取指定数据库的同步 Redis 客户端"""
        if db_name not in self._sync_pools:
            raise RuntimeError(f"sync pool not registered: {db_name}")
        return SyncRedis(connection_pool=self._sync_pools[db_name])

    def setup_langgraph_checkpoint(self, db_name: str):
        """按需初始化 LangGraph checkpoint (仅 Agent 场景需要, lazy import)"""
        from langgraph.checkpoint.redis import RedisSaver

        pool = self._sync_pools.get(db_name)
        if not pool:
            raise RuntimeError(f"sync pool not registered: {db_name}")

        client = SyncRedis(connection_pool=pool)
        with RedisSaver.from_conn_string(redis_client=client) as saver:
            saver.setup()
        logger.info(f"langgraph checkpoint setup done: {db_name}")

    async def setup_langgraph_checkpoint_async(self, db_name: str):
        """异步版 LangGraph checkpoint 初始化"""
        from langgraph.checkpoint.redis import AsyncRedisSaver

        pool = self._async_pools.get(db_name)
        if not pool:
            raise RuntimeError(f"async pool not registered: {db_name}")

        client = AsyncRedis(connection_pool=pool)
        async with AsyncRedisSaver.from_conn_string(redis_client=client) as saver:
            await saver.asetup()
        logger.info(f"langgraph async checkpoint setup done: {db_name}")

    async def close_all(self):
        """关闭所有连接池"""
        for pool in self._async_pools.values():
            await pool.disconnect()
        self._async_pools.clear()

        for pool in self._sync_pools.values():
            pool.disconnect()
        self._sync_pools.clear()

        self._async_registered.clear()
        self._sync_registered.clear()


redis_manager = RedisManager()
