# -- coding: utf-8 --
# Project: fiuai_sdk_python
# Created Date: 2025 09 Th
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


# -- coding: utf-8 --
# Project: response
# Created Date: 2025 05 Tu
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


from pydantic import BaseModel, Field, field_validator, model_validator
from typing import List, Literal, Optional, Self
from .utils.text import safe_string_name
from enum import StrEnum

class TaxPayerType(StrEnum):
    GeneralTaxPayer = "general_tax_payer"
    SmallTaxPayer = "small_tax_payer"
    OtherTaxPayer = "other_tax_payer"


PROVINCE_CODE = {
    "China": [
        ["1100", "北京市"],
        ["1200", "天津市"],
        ["1300", "河北省"],
        ["1400", "山西省"],
        ["1500", "内蒙古自治区"],
        ["2100", "辽宁省"],
        ["2200", "吉林省"],
        ["2300", "黑龙江省"],
        ["3100", "上海市"],
        ["3200", "江苏省"],
        ["3300", "浙江省"],
        ["3400", "安徽省"],
        ["3500", "福建省"],
        ["3600", "江西省"],
        ["3700", "山东省"],
        ["4100", "河南省"],
        ["4200", "湖北省"],
        ["4300", "湖南省"],
        ["4400", "广东省"],
        ["4500", "广西壮族自治区"],
        ["4600", "海南省"],
        ["5000", "重庆市"],
        ["5100", "四川省"],
        ["5200", "贵州省"],
        ["5300", "云南省"],
        ["5400", "西藏自治区"],
        ["6100", "陕西省"],
        ["6200", "甘肃省"],
        ["6300", "青海省"],
        ["6400", "宁夏回族自治区"],
        ["6500", "新疆维吾尔自治区"],
        ["7100", "台湾省"],
        ["8100", "香港特别行政区"],
        ["8200", "澳门特别行政区"],
    ],
}

_CHINA_PROVINCE_CODES: frozenset[str] = frozenset(
    row[0] for row in PROVINCE_CODE["China"]
)


def _is_china_country_region(region: str) -> bool:
    r = region.strip()
    if not r:
        return False
    else:
        if r.casefold() == "china":
            return True
        else:
            return False


class UserCompanyInfo(BaseModel):
    name: str = Field(description="公司id")
    full_name: str = Field(description="公司名称")

class UserBaseInfo(BaseModel):
    name: str = Field(description="用户名id")
    email: str = Field(description="邮箱")
    first_name: str = Field(description="名")
    full_name: str = Field(description="全名")
    language: str = Field(description="语言")
    time_zone: str = Field(description="时区")
    auth_tenant_id: str = Field(description="租户id")
    current_company: str = Field(description="当前公司")
    tax_account_username: Optional[str] = Field(description="税账号用户名", default=None)
    tax_account_type: Optional[str] = Field(description="税账号类型", default=None)
    available_companies: List[UserCompanyInfo] = Field(description="用户在租户下可以访问的公司列表", default_factory=list)


class UserPermissionInfo(BaseModel):
    can_select: List[str] = Field(description="可以查询的文档", default_factory=list)
    can_read: List[str] = Field(description="可以读取的文档", default_factory=list)
    can_write: List[str] = Field(description="可以写入的文档", default_factory=list)
    can_create: List[str] = Field(description="可以创建的文档", default_factory=list)
    can_delete: List[str] = Field(description="可以删除的文档", default_factory=list)
    can_submit: List[str] = Field(description="可以提交的文档", default_factory=list)
    can_cancel: List[str] = Field(description="可以取消的文档", default_factory=list)
    can_search: List[str] = Field(description="可以搜索的文档", default_factory=list)

    # def __init__(self, user: str):
    #     super().__init__()
    
    # def can_select(self, doctype: str) -> bool:
    #     return doctype in self.can_select
    
    # def can_read(self, doctype: str) -> bool:
    #     return doctype in self.can_read
    
    # def can_write(self, doctype: str) -> bool:
    #     return doctype in self.can_write
    
    # def can_create(self, doctype: str) -> bool:
    #     return doctype in self.can_create
    
    # def can_delete(self, doctype: str) -> bool:
    #     return doctype in self.can_delete
    
    # def can_submit(self, doctype: str) -> bool:
    #     return doctype in self.can_submit
    
    # def can_cancel(self, doctype: str) -> bool:
    #     return doctype in self.can_cancel
    
    # def can_search(self, doctype: str) -> bool:
    #     return doctype in self.can_search
    
class UserTenantInfo(BaseModel):
    name: str = Field(description="租户id")
    tenant_name: str = Field(description="租户名称")


class UserCurrentCompanyInfo(BaseModel):
    name: str = Field(description="公司id")
    full_name: str = Field(description="公司名称")
    unique_no: str = Field(description="公司唯一编号")
    country_region: str = Field(description="国家")
    default_currency: str = Field(description="货币")
    company_size: str = Field(description="公司规模")
    industry: Optional[str] = Field(default=None, description="行业")
    entity_type: Literal["Enterprise", "Individual", "Other"] = Field(description="公司类型")
    tax_payer_type: Optional[TaxPayerType] = Field(default=None, description="纳税人类型,一般纳税人,小规模纳税人,其他")
    tax_source_location: Optional[str] = Field(default=None, description="税务登记地,中国特有配置，按省级行政区划分,比如江苏是3200")
    company_profile: Optional[str] = Field(default=None, description="公司业务特点提示词")

    @field_validator("tax_payer_type", mode="before")
    @classmethod
    def validate_tax_payer_type_when_present(cls, value: object) -> TaxPayerType | None:
        if value is None or value == "":
            return None
        if isinstance(value, TaxPayerType):
            return value
        if isinstance(value, str):
            try:
                return TaxPayerType(value)
            except ValueError:
                allowed = ", ".join(repr(m.value) for m in TaxPayerType)
                raise ValueError(
                    f"tax_payer_type must be one of [{allowed}], got {value!r}"
                ) from None
        raise TypeError(
            f"tax_payer_type must be str, TaxPayerType or None, got {type(value).__name__}"
        )

    @field_validator("tax_source_location", mode="before")
    @classmethod
    def normalize_tax_source_location(cls, value: object) -> str | None:
        if value is None:
            return None
        if not isinstance(value, str):
            raise TypeError(
                "tax_source_location must be str or None, "
                f"got {type(value).__name__}"
            )
        stripped = value.strip()
        return None if stripped == "" else stripped

    @model_validator(mode="after")
    def validate_tax_source_location_against_china_provinces(self) -> Self:
        loc = self.tax_source_location
        china = _is_china_country_region(self.country_region)

        if loc is not None and not china:
            raise ValueError(
                "tax_source_location is only applicable when country_region is China, CN or 中国"
            )
        if loc is not None and china and loc not in _CHINA_PROVINCE_CODES:
            raise ValueError(
                "tax_source_location must be a valid China province admin code "
                f"(e.g. 3200 for Jiangsu), got {loc!r}"
            )
        return self


class UserProfileInfo(BaseModel):
    user_base_info: UserBaseInfo = Field(description="用户基础信息")
    user_permissions: UserPermissionInfo = Field(description="用户权限")
    user_tenant_info: UserTenantInfo = Field(description="用户租户信息")
    user_current_company_info: UserCurrentCompanyInfo = Field(description="用户当前公司信息")
    
    
    def create_safe_name_profile(self) -> 'UserProfileInfo':

        """替换对象中的所有的name为安全字符串"""

        return UserProfileInfo(
            user_base_info=UserBaseInfo(
                name=safe_string_name(self.user_base_info.name),
                email=self.user_base_info.email,
                first_name=self.user_base_info.first_name,
                full_name=self.user_base_info.full_name,
                language=self.user_base_info.language,
                time_zone=self.user_base_info.time_zone,
                auth_tenant_id=self.user_base_info.auth_tenant_id,
                current_company=self.user_base_info.current_company,
                available_companies=self.user_base_info.available_companies,
            ),
            user_permissions=self.user_permissions,
            user_tenant_info=UserTenantInfo(
                name=self.user_tenant_info.name,
                tenant_name=safe_string_name(self.user_tenant_info.tenant_name),
            ),
            user_current_company_info=UserCurrentCompanyInfo(
                name=self.user_current_company_info.name,
                full_name=safe_string_name(self.user_current_company_info.full_name),
                unique_no=self.user_current_company_info.unique_no,
                country_region=self.user_current_company_info.country_region,
                default_currency=self.user_current_company_info.default_currency,
                company_size=self.user_current_company_info.company_size,
                industry=self.user_current_company_info.industry,
                entity_type=self.user_current_company_info.entity_type,
                tax_payer_type=self.user_current_company_info.tax_payer_type,
                tax_source_location=self.user_current_company_info.tax_source_location,
                company_profile=self.user_current_company_info.company_profile,
            ),
        )