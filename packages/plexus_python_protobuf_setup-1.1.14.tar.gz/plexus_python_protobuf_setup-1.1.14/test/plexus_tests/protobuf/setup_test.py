import pathlib
import tempfile
import unittest

import plexus.protobuf.setup
from testenv import resources_directory


class TestSetup(unittest.TestCase):

    def test_compile_protos(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "unittest" / "setup" / "protos"]
            include_dirs = [resources_directory / "unittest" / "setup" / "protos"]

            plexus.protobuf.setup.compile_protos(temp_directory,
                                                 proto_dirs,
                                                 include_dirs,
                                                 package_root_dir=temp_directory / "dummy",
                                                 descriptor_path=temp_directory / "descriptor.proto",
                                                 with_grpc=True)

            self.assertTrue((temp_directory / "descriptor.proto").exists())
            self.assertFalse((temp_directory / "__init__.py").exists())
            self.assertTrue((temp_directory / "dummy" / "person_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "person_pb2.pyi").exists())
            self.assertTrue((temp_directory / "dummy" / "person_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "__init__.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "company_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "company_pb2.pyi").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "company_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "family_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "family_pb2.pyi").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "family_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "__init__.py").exists())

    def test_compile_protos__without_grpc(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "unittest" / "setup" / "protos"]
            include_dirs = [resources_directory / "unittest" / "setup" / "protos"]

            plexus.protobuf.setup.compile_protos(temp_directory, proto_dirs, include_dirs, with_grpc=False)

            self.assertFalse((temp_directory / "descriptor.proto").exists())
            self.assertTrue((temp_directory / "__init__.py").exists())
            self.assertTrue((temp_directory / "dummy" / "person_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "person_pb2.pyi").exists())
            self.assertFalse((temp_directory / "dummy" / "person_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "__init__.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "company_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "company_pb2.pyi").exists())
            self.assertFalse((temp_directory / "dummy" / "relationship" / "company_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "family_pb2.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "family_pb2.pyi").exists())
            self.assertFalse((temp_directory / "dummy" / "relationship" / "family_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "dummy" / "relationship" / "__init__.py").exists())

    def test_compile_protos__absent_out_dir(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "unittest" / "setup" / "protos"]
            include_dirs = [resources_directory / "unittest" / "setup" / "protos"]

            plexus.protobuf.setup.compile_protos(temp_directory / "out",
                                                 proto_dirs,
                                                 include_dirs,
                                                 package_root_dir=temp_directory / "out" / "dummy",
                                                 descriptor_path=temp_directory / "out" / "descriptor.proto",
                                                 with_grpc=True)

            self.assertTrue((temp_directory / "out" / "descriptor.proto").exists())
            self.assertFalse((temp_directory / "out" / "__init__.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "person_pb2.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "person_pb2.pyi").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "person_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "__init__.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "company_pb2.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "company_pb2.pyi").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "company_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "family_pb2.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "family_pb2.pyi").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "family_pb2_grpc.py").exists())
            self.assertTrue((temp_directory / "out" / "dummy" / "relationship" / "__init__.py").exists())

    def test_compile_protos__no_proto_found(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            plexus.protobuf.setup.compile_protos(temp_directory, [temp_directory], [temp_directory])

            with self.assertRaises(ValueError):
                plexus.protobuf.setup.compile_protos(temp_directory, [temp_directory], [temp_directory], strict=True)

    def test_compile_protos__absent_proto_dir(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "absent" / "protos"]
            include_dirs = [resources_directory / "unittest" / "setup" / "protos"]

            with self.assertRaises(FileNotFoundError):
                plexus.protobuf.setup.compile_protos(temp_directory,
                                                     proto_dirs,
                                                     include_dirs,
                                                     package_root_dir=temp_directory / "dummy",
                                                     descriptor_path=temp_directory / "descriptor.proto",
                                                     with_grpc=True)

    def test_compile_protos__absent_include_dir(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "unittest" / "setup" / "protos"]
            include_dirs = [resources_directory / "absent" / "protos"]

            with self.assertRaises(FileNotFoundError):
                plexus.protobuf.setup.compile_protos(temp_directory,
                                                     proto_dirs,
                                                     include_dirs,
                                                     package_root_dir=temp_directory / "dummy",
                                                     descriptor_path=temp_directory / "descriptor.proto",
                                                     with_grpc=True)

    def test_compile_protos__bad_package_dir(self):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            proto_dirs = [resources_directory / "unittest" / "setup" / "protos"]
            include_dirs = [resources_directory / "unittest" / "setup" / "protos"]

            with self.assertRaises(ValueError):
                plexus.protobuf.setup.compile_protos(temp_directory / "out",
                                                     proto_dirs,
                                                     include_dirs,
                                                     # package_root_dir is outside of out_dir
                                                     package_root_dir=temp_directory / "bad",
                                                     descriptor_path=temp_directory / "descriptor.proto",
                                                     with_grpc=True)
