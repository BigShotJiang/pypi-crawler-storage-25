# Plexus Python Protocol Buffer Setup Module

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/plexus-python-protobuf-setup?style=for-the-badge)
![PyPI - Version](https://img.shields.io/pypi/v/plexus-python-protobuf-setup?style=for-the-badge)
![Codecov](https://img.shields.io/codecov/c/github/ruyangshou/plexus-python-protobuf-setup?token=J4rQVKXeRx&style=for-the-badge)

## Usage

1. **Modify the `pyproject.toml` file** as follows:
    ```toml
    [build-system]
    requires = [
        "setuptools>=80.0",
        "setuptools-scm>=9.0",
        "plexus-python-protobuf-setup>=1.0"  # This is required
    ]
    ```
2. **Use this tool in your `setup.py` script**:
    ```python
    import os
    from setuptools import setup
    from plexus.protobuf.setup import compile_protos
   
    # Call this code generation before setup
    compile_protos(out_dir,
                   proto_dirs,
                   include_dirs,
                   descriptor_path=os.path.join(out_dir, "descriptor.proto"))
    setup()
    ```
