from ._core import result

__all__ = ["result"]
