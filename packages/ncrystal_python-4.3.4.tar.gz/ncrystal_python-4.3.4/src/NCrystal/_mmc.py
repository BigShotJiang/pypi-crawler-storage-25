
################################################################################
##                                                                            ##
##  This file is part of NCrystal (see https://mctools.github.io/ncrystal/)   ##
##                                                                            ##
##  Copyright 2015-2026 NCrystal developers                                   ##
##                                                                            ##
##  Licensed under the Apache License, Version 2.0 (the "License");           ##
##  you may not use this file except in compliance with the License.          ##
##  You may obtain a copy of the License at                                   ##
##                                                                            ##
##      http://www.apache.org/licenses/LICENSE-2.0                            ##
##                                                                            ##
##  Unless required by applicable law or agreed to in writing, software       ##
##  distributed under the License is distributed on an "AS IS" BASIS,         ##
##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  ##
##  See the License for the specific language governing permissions and       ##
##  limitations under the License.                                            ##
##                                                                            ##
################################################################################

""" Obsolete interface. Use the NCrystal.minimc module instead."""

__all__ = ['quick_diffraction_pattern','runsim_diffraction_pattern']

from ._common import warn as _ncwarn
_ncwarn('The NCrystal._mmc module is obsolete.'
        ' Please use the NCrystal.minimc module instead (more info'
        ' at https://github.com/mctools/ncrystal/wiki/minimc).')

def runsim_diffraction_pattern( *a, **kwargs ):
    """Obsolete function. Calling it now will result in an error.
    More info at: https://github.com/mctools/ncrystal/wiki/minimc
    """
    from .exceptions import NCException
    raise NCException('The runsim_diffraction_pattern(..) function is'
                      ' obsolete. Please migrate your code to use the'
                      ' NCrystal.minimc.run(..) function instead (more info'
                      ' at https://github.com/mctools/ncrystal/wiki/minimc).')

__cache_qdpwarn=[True]
def quick_diffraction_pattern( cfgstr, *,
                               neutron_energy,
                               material_thickness,
                               nstat = 'auto',
                               nthreads = 'auto',
                               suppress_obsoletion_warning = False ):

    from .minimc import run as mmcrun
    migratemsg = ('Please migrate your code to use the'
                  ' NCrystal.minimc.run(..) function instead'
                  ' (more info at'
                  ' https://github.com/mctools/ncrystal/wiki/minimc).')
    warnmsg = ('The quick_diffraction_pattern(..) function is obsolete.'
               f' {migratemsg}')

    if __cache_qdpwarn[0] and not suppress_obsoletion_warning:
        __cache_qdpwarn[0] = False
        from ._common import warn
        warn(warnmsg)

    assert ';' not in neutron_energy
    assert ';' not in material_thickness
    neutron_energy = ''.join(neutron_energy.split())
    material_thickness = ''.join(material_thickness.split())
    scenario_cfg = f'{neutron_energy} pencil on {material_thickness} sphere'
    enginecfg = f';nthreads={nthreads};tally=theta;tallybins=theta:1800:0:180'

    def simfct( n, cfgstr ):
        import time
        t0 = time.time()
        res = mmcrun( cfgstr,
                      scenario=scenario_cfg + f' {n} times',
                      enginecfg = enginecfg )
        t1 = time.time()
        return t1-t0, res

    if nstat is None or nstat=='auto':
        for nstat in [1e4,1e5,1e6,1e7]:
            t,res = simfct(nstat,cfgstr)
            #Usually, end within a second in total, but in worst cases, up to
            #10seconds:
            if ( t>0.1 and nstat >= 1e6 ) or t>1.0:
                break
    else:
        t,res=simfct(nstat,cfgstr)

    class MiniMCObsoleteResult:
        """Backwards compatible results class for the obsolete
        quick_diffraction_pattern() function. The NCrystal.minimc.run(..)
        function should be used instead.

        More info at: https://github.com/mctools/ncrystal/wiki/minimc
        """
        def __init__(self,res):
            self.__res = res

        def _real_mmcresult( self ):
            return self.__res

        def plot_breakdown(self,rebin_factor=1,logy=False):
            self.__res.tally('theta').plot(rebin_factor=rebin_factor,
                                           logy=logy)

        def __getattr__(self, name):
            if not name.startswith('_'):
                from .exceptions import NCException
                raise NCException(f'".{name}" is not available on results from'
                                  ' the obsolete quick_diffraction_pattern'
                                  ' function. Only .plot_breakdown(..) is.'
                                  f' {migratemsg}')

    return MiniMCObsoleteResult(res)
