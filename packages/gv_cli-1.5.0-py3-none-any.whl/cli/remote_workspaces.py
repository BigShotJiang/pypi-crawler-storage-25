from __future__ import annotations
import asyncio,os
from dataclasses import dataclass
from pathlib import Path
from typing import Any,Protocol
import click,httpx
class EnvLike(Protocol):url:str|None;opencode_username:str;opencode_password:str|None
@dataclass(frozen=True)
class ProjectRecord:label:str;worktree:str;sandboxes:tuple[str,...]
@dataclass(frozen=True)
class WorkspaceRecord:project_label:str;workspace_label:str;directory:str;project_directory:str
async def discover_workspace_records(env:EnvLike)->list[WorkspaceRecord]:
	A=env
	if not A.opencode_password:raise RuntimeError('OpenCode password is required to discover workspaces.')
	async with httpx.AsyncClient(timeout=15,auth=httpx.BasicAuth(A.opencode_username,A.opencode_password))as B:return await fetch_workspace_records(B,A.url or'')
def discover_env_workspace_records(env:EnvLike)->list[WorkspaceRecord]:
	if not env.url:return[]
	try:return valid_workspace_records(asyncio.run(discover_workspace_records(env)))
	except(RuntimeError,ValueError,httpx.HTTPError):return[]
def valid_workspace_records(records:list[WorkspaceRecord])->list[WorkspaceRecord]:
	B:list[WorkspaceRecord]=[];C:set[str]=set()
	for A in records:
		if A.directory in{'','/'}or A.directory in C:continue
		C.add(A.directory);B.append(A)
	return B
async def fetch_workspace_records(client:httpx.AsyncClient,base_url:str)->list[WorkspaceRecord]:A=await fetch_projects(client,base_url);return build_workspace_records(A)
async def fetch_projects(client:httpx.AsyncClient,base_url:str)->list[ProjectRecord]:
	D=await client.get(f"{base_url.rstrip("/")}/project");D.raise_for_status();E=D.json();F=_extract_items(E,singular='project',plural='projects');B:list[ProjectRecord]=[]
	for C in F:
		A=_string(C.get('worktree'))
		if not A:continue
		G=_string(C.get('name'));H=G or Path(A).name or A;I=tuple(B for B in(_string(A)for A in C.get('sandboxes',[]))if B and B!=A);B.append(ProjectRecord(label=H,worktree=A,sandboxes=I))
	B.sort(key=lambda project:(project.label.lower(),project.worktree));return B
def build_workspace_records(projects:list[ProjectRecord])->list[WorkspaceRecord]:
	C:list[WorkspaceRecord]=[];D:set[tuple[str,str]]=set()
	for A in projects:
		for B in(A.worktree,*A.sandboxes):
			E=A.label,B
			if E in D:continue
			D.add(E);F='main'if B==A.worktree else Path(B).name or B;C.append(WorkspaceRecord(project_label=A.label,workspace_label=F,directory=B,project_directory=A.worktree))
	return C
def choose_workspace_record(env_name:str,workspace_records:list[WorkspaceRecord])->WorkspaceRecord:
	A=workspace_records;click.echo(f"\nWorkspaces for {env_name}\n");C:str|None=None
	for(D,B)in enumerate(A,start=1):
		if B.project_directory!=C:C=B.project_directory;click.echo(display_directory(B.project_directory))
		click.echo(f"  [{D}] {B.workspace_label}")
	if len(A)==1:return A[0]
	E=click.prompt('Choose a workspace (input number)',type=click.IntRange(1,len(A)));return A[E-1]
def display_directory(directory:str)->str:
	A=directory;B=str(Path.home())
	if A==B:return'~'
	if A.startswith(B+os.sep):return'~'+A[len(B):]
	return A
def _extract_items(payload:Any,*,singular:str,plural:str)->list[dict[str,Any]]:
	C=plural;A=payload
	if isinstance(A,list):return[A for A in A if isinstance(A,dict)]
	if isinstance(A,dict):
		for D in(C,singular):
			B=A.get(D)
			if isinstance(B,list):return[A for A in B if isinstance(A,dict)]
			if isinstance(B,dict):return[B]
	raise RuntimeError(f"OpenCode returned an invalid {C} response.")
def _string(value:Any)->str|None:
	A=value
	if A is None:return
	B=str(A);return B or None