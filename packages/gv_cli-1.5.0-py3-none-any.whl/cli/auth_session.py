from __future__ import annotations
import json,os,time
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib import error,parse,request
CONFIG_DIR=Path.home()/'.config'/'gv'
CONFIG_PATH=CONFIG_DIR/'config.json'
HTTP_USER_AGENT='gv-cli/0.1'
@dataclass(frozen=True)
class OAuthSession:
	access_token:str;expires_at:float|None;refresh_token:str|None=None;token_endpoint:str|None=None;client_id:str|None=None
	def to_config(A)->dict[str,Any]:
		B={'access_token':A.access_token,'expires_at':A.expires_at}
		if A.refresh_token:B['refresh_token']=A.refresh_token
		if A.token_endpoint:B['token_endpoint']=A.token_endpoint
		if A.client_id:B['client_id']=A.client_id
		return B
	@classmethod
	def from_config(H,payload:Any)->'OAuthSession | None':
		A=payload
		if not isinstance(A,dict):return
		B=A.get('access_token')
		if not isinstance(B,str)or not B.strip():return
		C=A.get('expires_at');D=None
		if isinstance(C,(int,float)):D=float(C)
		E=A.get('refresh_token');F=A.get('token_endpoint');G=A.get('client_id');return H(access_token=B,expires_at=D,refresh_token=E if isinstance(E,str)else None,token_endpoint=F if isinstance(F,str)else None,client_id=G if isinstance(G,str)else None)
def load_cli_config()->dict[str,Any]:
	if not CONFIG_PATH.is_file():return{}
	try:return json.loads(CONFIG_PATH.read_text())
	except(OSError,json.JSONDecodeError)as A:raise RuntimeError(f"Failed to read CLI config from {CONFIG_PATH}: {A}")from A
def save_cli_config(config:dict[str,Any])->None:CONFIG_DIR.mkdir(parents=True,exist_ok=True);CONFIG_PATH.write_text(json.dumps(config,indent=2,sort_keys=True)+'\n');os.chmod(CONFIG_PATH,384)
def load_oauth_session()->OAuthSession|None:return OAuthSession.from_config(load_cli_config().get('oauth'))
def save_oauth_session(session:OAuthSession|None)->None:
	B=session;A=load_cli_config()
	if B is None:A.pop('oauth',None)
	else:A['oauth']=B.to_config()
	save_cli_config(A)
def get_valid_access_token()->str:
	A=load_oauth_session()
	if A is None:raise RuntimeError('Not logged in. Run `gv auth --help`.')
	if A.expires_at is None or A.expires_at>time.time()+60:return A.access_token
	B=refresh_oauth_session(A)
	if B is not None:save_oauth_session(B);return B.access_token
	raise RuntimeError('Your auth session has expired. Run `gv auth --help`.')
def refresh_oauth_session(session:OAuthSession)->OAuthSession|None:
	A=session
	if not A.refresh_token or not A.token_endpoint or not A.client_id:return
	G=parse.urlencode({'grant_type':'refresh_token','client_id':A.client_id,'refresh_token':A.refresh_token}).encode('utf-8');H=request.Request(A.token_endpoint,method='POST',data=G,headers={'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json','User-Agent':HTTP_USER_AGENT})
	try:
		with request.urlopen(H,timeout=30)as I:B=json.loads(I.read().decode('utf-8'))
	except(error.HTTPError,error.URLError,json.JSONDecodeError):return
	C=B.get('access_token')
	if not isinstance(C,str)or not C:return
	D=B.get('expires_in');E=None
	if isinstance(D,(int,float)):E=time.time()+float(D)
	F=B.get('refresh_token');return OAuthSession(access_token=C,expires_at=E,refresh_token=F if isinstance(F,str)else A.refresh_token,token_endpoint=A.token_endpoint,client_id=A.client_id)
def get_api_auth_header()->str:return f"Bearer {get_valid_access_token().strip()}"
def redact_cli_config(config:dict[str,Any])->dict[str,Any]:
	C=dict(config);D=C.get('oauth')
	if isinstance(D,dict):
		A=dict(D)
		if'access_token'in A:B=str(A['access_token']);A['access_token']=f"{B[:4]}***{B[-4:]}"if len(B)>=8 else'***'
		if'refresh_token'in A:B=str(A['refresh_token']);A['refresh_token']=f"{B[:4]}***{B[-4:]}"if len(B)>=8 else'***'
		C['oauth']=A
	return C