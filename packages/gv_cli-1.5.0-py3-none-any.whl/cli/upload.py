from __future__ import annotations
import os,shlex,subprocess
from pathlib import Path
from typing import Callable,Protocol
import click
from.import interactive,remote_workspaces,ssh_access
class UploadEnv(Protocol):id:str;name:str;url:str|None;opencode_username:str;opencode_password:str
def build_rsync_upload_command(host:str,username:str,key_path:str,local_paths:tuple[str,...],remote_path:str,*,force:bool=False)->list[str]:
	B=' '.join(shlex.quote(A)for A in ssh_access.build_ssh_transport_command(key_path));A=['rsync','-a','-e',B]
	if not force:A.insert(2,'--ignore-existing')
	A.extend(local_paths);A.append(f"{username}@{host}:{remote_path}");return A
def run_rsync_upload(env_id:str,env_ssh_access:ssh_access.EnvSshAccess,local_paths:tuple[str,...],remote_path:str,*,force:bool=False)->int:
	D=remote_path;C=local_paths;B=env_id;A=env_ssh_access;ensure_remote_upload_destination(B,A,C,D);E=ssh_access.write_private_key_to_config(B,A.private_key);F=build_rsync_upload_command(A.public_ip,A.username,E,C,D,force=force)
	try:G=subprocess.run(F,check=False)
	except FileNotFoundError as H:raise RuntimeError('rsync and OpenSSH are required for this command.')from H
	return int(G.returncode)
def ensure_remote_upload_destination(env_id:str,env_ssh_access:ssh_access.EnvSshAccess,local_paths:tuple[str,...],remote_path:str)->None:
	A=remote_path;C=A
	if _remote_upload_targets_file(local_paths,A):C=_remote_dirname(A)
	E='\n'.join(['set -eu','path="$1"','case "$path" in','  \'~\') path="$HOME" ;;','  \'~/\'*) path="$HOME/${path#~/}" ;;','esac','mkdir -p "$path"']);B=ssh_access.run_ssh_process(env_id,env_ssh_access,('bash','-s','--',C),input_text=E,capture_output=True)
	if B.returncode!=0:D=(B.stderr or B.stdout or'').strip();F=f": {D}"if D else'';raise RuntimeError(f"Failed to prepare remote destination{F}")
def remote_path_exists(env_id:str,env_ssh_access:ssh_access.EnvSshAccess,remote_path:str)->bool:
	C='\n'.join(['set -eu','path="$1"','case "$path" in','  \'~\') path="$HOME" ;;','  \'~/\'*) path="$HOME/${path#~/}" ;;','esac','test -e "$path"']);A=ssh_access.run_ssh_process(env_id,env_ssh_access,('bash','-s','--',remote_path),input_text=C,capture_output=True)
	if A.returncode==0:return True
	if A.returncode==1:return False
	B=(A.stderr or A.stdout or'').strip();D=f": {B}"if B else'';raise RuntimeError(f"Failed to check remote destination{D}")
def handle_upload(local_paths:tuple[str,...],remote_path:str|None,force:bool,workspace_name:str|None,env_name:str|None,*,resolve_env:Callable[[str|None],tuple[str,UploadEnv]],fetch_ssh_access:Callable[[str,str],ssh_access.EnvSshAccess],is_interactive_input:Callable[[],bool])->int:
	J=workspace_name;I=force;H=local_paths;F=remote_path;B=is_interactive_input
	try:
		G=B();C:tuple[str,...]|None=None
		if H or not G:C=_resolve_upload_paths(H,is_interactive_input=B)
		D:remote_workspaces.WorkspaceRecord|None=None
		if(F is None or not F.strip())and not G:raise click.ClickException('Missing required option: --to REMOTE_PATH')
		N,E=resolve_env(env_name)
		if G and J is None and(F is None or _remote_path_is_workspace_relative(F.strip())):D=_select_upload_workspace_interactively(E)
		if C is None:C=_resolve_upload_paths(H,is_interactive_input=B)
		A=_resolve_upload_remote_path(F,D,is_interactive_input=B)
		if J is None and D is None and _remote_path_is_workspace_relative(A)and not G:raise click.ClickException('Relative remote destinations require --workspace in non-interactive use.')
		if D is None:D=_resolve_upload_workspace(E,J,required=_remote_path_is_workspace_relative(A),is_interactive_input=B)
		A=_resolve_upload_remote_destination(A,D);K=fetch_ssh_access(N,E.id)
		if not I and remote_path_exists(E.id,K,A):
			if B()and click.confirm(f"Remote destination already exists: {A}. Overwrite?",default=False):I=True
			else:raise click.ClickException(f"Remote destination already exists: {A}. Re-run with --force to overwrite.")
		L=run_rsync_upload(E.id,K,C,A,force=I)
	except RuntimeError as M:raise click.ClickException(str(M))from M
	if L==0:O='path'if len(C)==1 else'paths';click.echo(f"Uploaded {len(C)} {O} to {E.name}:{A}")
	return L
def _validate_upload_paths(local_paths:tuple[str,...])->tuple[str,...]:
	B=local_paths
	if not B:raise click.ClickException('Usage: gv upload LOCAL_PATH... --to REMOTE_PATH')
	C:list[str]=[]
	for D in B:
		A=Path(D).expanduser()
		if not A.exists():raise click.ClickException(f"Local path not found: {D}")
		if A.is_dir()and not any(A.iterdir()):raise click.ClickException(f"Local directory is empty: {D}")
		if A.is_dir()and len(B)==1:C.append(f"{A}{os.sep}")
		else:C.append(str(A))
	return tuple(C)
def _prompt_upload_paths()->tuple[str,...]:
	C=click.prompt('Local file or directory path(s) to upload')
	try:A=tuple(shlex.split(C))
	except ValueError as B:raise click.ClickException(f"Could not parse local path(s): {B}")from B
	if not A:raise click.ClickException('Enter at least one local path.')
	return A
def _resolve_upload_paths(local_paths:tuple[str,...],*,is_interactive_input:Callable[[],bool])->tuple[str,...]:return interactive.resolve_interactive_value(local_paths or None,missing_error='Usage: gv upload LOCAL_PATH... --to REMOTE_PATH',prompt_value=_prompt_upload_paths,validate=_validate_upload_paths,is_interactive_input=is_interactive_input)
def _validate_upload_remote_path(remote_path:str)->str:
	A=remote_path.strip()
	if not A:raise click.ClickException('Missing required option: --to REMOTE_PATH')
	return A
def _resolve_upload_remote_path(remote_path:str|None,workspace:remote_workspaces.WorkspaceRecord|None=None,*,is_interactive_input:Callable[[],bool])->str:
	A=workspace;B='Remote destination path'
	if A is not None:B=f"Remote destination path inside workspace {A.workspace_label}"
	return interactive.resolve_interactive_value(remote_path,missing_error='Missing required option: --to REMOTE_PATH',prompt_value=lambda:click.prompt(B,default='.'),validate=_validate_upload_remote_path,is_interactive_input=is_interactive_input)
def _remote_path_is_workspace_relative(remote_path:str)->bool:return not remote_path.startswith(('/','~'))
def _join_workspace_remote_path(workspace_directory:str,remote_path:str)->str:
	B=workspace_directory;A=remote_path
	if A in{'','.'}:return B
	if A.startswith('./'):A=A[2:]
	return f"{B.rstrip("/")}/{A.lstrip("/")}"
def _workspace_reference(record:remote_workspaces.WorkspaceRecord)->str:A=record;return f"{A.project_label}:{A.workspace_label}"
def _find_workspace_record(workspace_records:list[remote_workspaces.WorkspaceRecord],workspace_name:str)->remote_workspaces.WorkspaceRecord:
	C=workspace_records;B=workspace_name;D=B.strip();A=[A for A in C if D in{A.directory,A.workspace_label,_workspace_reference(A)}]
	if not A:E=', '.join(_workspace_reference(A)for A in C);raise click.ClickException(f"Workspace not found: {B}. Available workspaces: {E}")
	if len(A)>1:F=', '.join(_workspace_reference(A)for A in A);raise click.ClickException(f"Workspace name is ambiguous: {B}. Use one of: {F}")
	return A[0]
def _resolve_upload_workspace(env:UploadEnv,workspace_name:str|None,*,required:bool,is_interactive_input:Callable[[],bool])->remote_workspaces.WorkspaceRecord|None:
	B=workspace_name;A=env
	if B is None and not required:return
	if B is None and not is_interactive_input():raise click.ClickException('Relative remote destinations require --workspace in non-interactive use.')
	C=remote_workspaces.discover_env_workspace_records(A)
	if B is not None:
		if not C:raise click.ClickException(f"No workspaces found for {A.name}.")
		return _find_workspace_record(C,B)
	if not C:raise click.ClickException(f"No workspaces found for {A.name}. Pass an absolute --to path instead.")
	return remote_workspaces.choose_workspace_record(A.name,C)
def _select_upload_workspace_interactively(env:UploadEnv)->remote_workspaces.WorkspaceRecord|None:
	A=remote_workspaces.discover_env_workspace_records(env)
	if not A:return
	return remote_workspaces.choose_workspace_record(env.name,A)
def _resolve_upload_remote_destination(remote_path:str,workspace:remote_workspaces.WorkspaceRecord|None)->str:
	B=workspace;A=remote_path
	if B is None or not _remote_path_is_workspace_relative(A):return A
	return _join_workspace_remote_path(B.directory,A)
def _remote_upload_targets_file(local_paths:tuple[str,...],remote_path:str)->bool:A=local_paths;return len(A)==1 and not A[0].endswith(os.sep)and not remote_path.endswith('/')
def _remote_dirname(remote_path:str)->str:
	A=remote_path
	if A in{'','.','~'}:return A or'.'
	if A.startswith('~/'):B=A.rsplit('/',1)[0];return B if B!='~'else'~'
	if'/'not in A:return'.'
	B=A.rsplit('/',1)[0];return B or'/'