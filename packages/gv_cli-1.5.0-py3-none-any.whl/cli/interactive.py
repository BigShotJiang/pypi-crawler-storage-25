from __future__ import annotations
from typing import Callable,TypeVar
import click
T=TypeVar('T')
def is_interactive_input()->bool:return click.get_text_stream('stdin').isatty()
def resolve_interactive_value(value:T|None,*,missing_error:str,prompt_value:Callable[[],T],validate:Callable[[T],T],is_interactive_input:Callable[[],bool]=is_interactive_input)->T:
	C=is_interactive_input;B=prompt_value;A=value
	while True:
		try:
			if A is None:
				if not C():raise click.ClickException(missing_error)
				A=B()
			return validate(A)
		except click.ClickException as D:
			if not C():raise
			click.echo(f"Error: {D.message}",err=True);A=B()