## What does this PR do?

## Why?

## Testing
- [ ] Tests pass (`uv run pytest`)
- [ ] Tested manually
