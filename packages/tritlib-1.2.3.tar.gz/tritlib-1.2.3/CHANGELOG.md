# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## [1.2.3] — 2026-04-22
- added TFloat conversion from and into int/Tryte/Trits
- renamed to_tryte into to_raw

## [1.2.2] — 2026-04-05
- Updated README.md and pyproject.toml


## [1.2.1] — 2026-04-05
- Symmetric Euclidean `__divmod__` implementation


## [1.2.0] — 2026-04-05

### Added
- Native trit-level multiplication on `TFloat` (Tekum arithmetic)
  - Double-width Tryte arithmetic for the product
  - Exponent addition, scale reduction via ternary shift
  - Normalization into Tekum's [0.5, 1.5) range

## [1.1.0] — 2026-04-05

### Added
- Native trit-level addition on `TFloat` (Tekum arithmetic)
  - Direct manipulation of extended mantissas via `Tryte` operations
  - Exponent alignment via ternary shift
  - Normalization with Tekum's truncation-equals-rounding property
  - No longer relies on Python float for addition
- `_find_regime` and `_assemble_raw` internal helpers factored out of `from_float`

## [1.0.0] — 2026-04-04

### Changed
- API declared stable
- Version bumped to 1.0.0 — no breaking changes from 0.7.0

### Added
- `py.typed` marker for mypy support
- CHANGELOG.md
- 99% test coverage

## [0.7.0] — 2026-04-04

### Added
- `TFloat` — Tekum tapered precision floating-point type (arXiv:2512.10964)
  - Decode from `Tryte` and encode from Python `float`
  - Arithmetic via float conversion (`+`, `-`, `*`, `/`)
  - Negation, comparison, hashing
  - Special values: zero, infinity, NaR
  - Configurable width (even, ≥ 8)
- `pluralize` function and `PluralResult` dataclass for logical pluralism
- `logic_mode` context manager for runtime logic system selection
- Logic aliases: `K3`, `L3`, `HT`, `BI3`, `RM3`
- `Trit.imply` method dispatched via context manager
- `context.py` module with `ContextVar`-based logic dispatch
- Docstrings on all public classes and methods
- This CHANGELOG

### Changed
- `Trit.__and__`, `__or__`, `__invert__` now dispatch via active logic system (Kleene by default, fast path when no context manager is active)

## [0.2.0] — 2026-04-03

### Added
- `Tryte` — fixed-width ternary word type
  - Three addition modes: truncating, with carry, saturating
  - Shifts (`<<`, `>>`) and rotations (`rotate_left`, `rotate_right`)
  - Per-trit access (`__getitem__`) and immutable modification (`set`)
  - Sign extraction, absolute value
  - Consensus and anti-consensus (`cons`, `acons`)
  - Resize across widths (`to_width`)
  - Division (`__floordiv__`, `__mod__`, `__divmod__`)
- Five ternary logic systems with `TernaryLogic` abstract base class
  - Kleene (K3), Łukasiewicz (L3), Heyting (HT), Bochvar (BI3), R-mingle (RM3)
  - Each implements NOT, AND, OR, IMPLY, XOR, EQUIV
- `Trits` division via double trial quotient method
- Kleene logic operators on `Trit` (`&`, `|`, `~`)
- `Trit.cons` and `Trit.acons` operators

### Changed
- `Trits` internal storage changed to tuple (immutable)
- `Trits._from_trits` centralizes normalization and construction

## [0.1.0] — 2026-04-02

### Added
- `Trit` — immutable single balanced ternary digit
  - Construction from int with validation
  - Negation, multiplication
  - Half-adder and full-adder with ternary carry
  - Equality, hashing, comparison
  - Immutability via `__setattr__` guard
- `Trits` — arbitrary-precision balanced ternary integer
  - Construction from `int` or balanced ternary string
  - Addition, subtraction, multiplication
  - Conversion to/from Python `int`
  - Comparison operators
- Constants `P`, `Z`, `N`
- `pyproject.toml` with hatchling build system
- MIT license
- Initial README

[Unreleased]: https://codeberg.org/newick_2/tritlib/compare/v0.7.0...HEAD
[0.7.0]: https://codeberg.org/newick_2/tritlib/compare/v0.2.0...v0.7.0
[0.2.0]: https://codeberg.org/newick_2/tritlib/compare/v0.1.0...v0.2.0
[0.1.0]: https://codeberg.org/newick_2/tritlib/releases/tag/v0.1.0
