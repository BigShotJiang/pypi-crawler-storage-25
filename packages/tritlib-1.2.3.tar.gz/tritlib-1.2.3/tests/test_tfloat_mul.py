"""Tests for native trit-level TFloat multiplication."""
import pytest
from tritlib import TFloat


# ── Special values ──────────────────────────────────────────────

def test_mul_by_one():
    a = TFloat(3.0, width=20)
    one = TFloat(1.0, width=20)
    assert float(a * one) == float(a)
    assert float(one * a) == float(a)

def test_mul_by_zero():
    a = TFloat(3.0, width=20)
    zero = TFloat(0.0, width=20)
    assert (a * zero).special == "zero"
    assert (zero * a).special == "zero"

def test_mul_nar_propagates():
    a = TFloat(3.0, width=20)
    nar = TFloat(float('nan'), width=20)
    assert (a * nar).special == "nar"
    assert (nar * a).special == "nar"

def test_mul_zero_inf():
    # 0 × inf = NaR (indeterminate)
    zero = TFloat(0.0, width=20)
    inf = TFloat(float('inf'), width=20)
    assert (zero * inf).special == "nar"
    assert (inf * zero).special == "nar"

def test_mul_inf_finite():
    inf = TFloat(float('inf'), width=20)
    a = TFloat(42.0, width=20)
    assert (inf * a).special == "inf"
    assert (a * inf).special == "inf"

def test_mul_inf_inf():
    inf = TFloat(float('inf'), width=20)
    assert (inf * inf).special == "inf"


# ── Basic multiplication ────────────────────────────────────────

def test_mul_same_sign_positive():
    a = TFloat(3.0, width=20)
    b = TFloat(4.0, width=20)
    assert abs(float(a * b) - 12.0) < 0.1

def test_mul_powers_of_three():
    a = TFloat(9.0, width=20)
    b = TFloat(27.0, width=20)
    assert abs(float(a * b) - 243.0) < 1.0

def test_mul_negative_positive():
    a = TFloat(-3.0, width=20)
    b = TFloat(4.0, width=20)
    assert abs(float(a * b) - (-12.0)) < 0.1

def test_mul_negative_negative():
    a = TFloat(-3.0, width=20)
    b = TFloat(-4.0, width=20)
    assert abs(float(a * b) - 12.0) < 0.1

def test_mul_fractional():
    a = TFloat(0.5, width=20)
    b = TFloat(2.0, width=20)
    assert abs(float(a * b) - 1.0) < 0.01

def test_mul_small_times_large():
    a = TFloat(0.01, width=26)
    b = TFloat(100.0, width=26)
    assert abs(float(a * b) - 1.0) < 0.01


# ── Commutativity ───────────────────────────────────────────────

def test_mul_commutative():
    for va, vb in [(3.0, 7.0), (2.5, 1.3), (-4.0, 9.0), (0.1, 0.2)]:
        a = TFloat(va, width=26)
        b = TFloat(vb, width=26)
        assert (a * b) == (b * a), f"Failed for {va} × {vb}"


# ── Width validation ────────────────────────────────────────────

def test_mul_different_widths_raises():
    a = TFloat(1.0, width=8)
    b = TFloat(1.0, width=10)
    with pytest.raises(TypeError):
        a * b


# ── Accuracy against float reference ────────────────────────────

def test_mul_accuracy():
    pairs = [
        (1.0, 2.0),
        (3.5, 4.5),
        (-1.5, 2.5),
        (100.0, 0.5),
        (0.1, 0.2),
        (1e-5, 1e5),
        (3.14, 2.71),
    ]
    for va, vb in pairs:
        a = TFloat(va, width=26)
        b = TFloat(vb, width=26)
        result = float(a * b)
        expected = va * vb
        if expected == 0:
            assert abs(result) < 1e-6, f"{va}×{vb}: got {result}"
        else:
            rel_error = abs(result - expected) / abs(expected)
            assert rel_error < 0.001, \
                f"{va}×{vb}={expected}, got {result}, rel_error={rel_error}"


# ── Very small and very large ───────────────────────────────────

def test_mul_very_small():
    a = TFloat(1e-25, width=26)
    b = TFloat(1e-25, width=26)
    result = a * b
    assert float(result) > 0
    rel_error = abs(float(result) - 1e-50) / 1e-50
    assert rel_error < 0.01

def test_mul_very_large():
    a = TFloat(1e25, width=26)
    b = TFloat(1e25, width=26)
    result = a * b
    rel_error = abs(float(result) - 1e50) / 1e50
    assert rel_error < 0.01

def test_mul_large_times_small():
    a = TFloat(1e20, width=26)
    b = TFloat(1e-20, width=26)
    result = a * b
    assert abs(float(result) - 1.0) < 0.01


# ── Identity and inversion ──────────────────────────────────────

def test_mul_by_minus_one():
    a = TFloat(42.0, width=20)
    minus_one = TFloat(-1.0, width=20)
    assert abs(float(a * minus_one) + 42.0) < 0.1

def test_mul_square():
    for v in [2.0, 3.0, 5.0, 7.0]:
        a = TFloat(v, width=26)
        result = a * a
        assert abs(float(result) - v*v) / (v*v) < 0.001, \
            f"{v}² failed: got {float(result)}"
