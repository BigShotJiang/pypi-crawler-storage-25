"""Tests for native trit-level TFloat addition."""
import pytest
from tritlib import TFloat


# ── Special values ──────────────────────────────────────────────

def test_add_zero_identity():
    a = TFloat(3.0, width=20)
    zero = TFloat(0.0, width=20)
    assert float(a + zero) == float(a)
    assert float(zero + a) == float(a)

def test_add_nar_propagates():
    a = TFloat(3.0, width=20)
    nar = TFloat(float('nan'), width=20)
    assert (a + nar).special == "nar"
    assert (nar + a).special == "nar"

def test_add_inf_inf():
    inf = TFloat(float('inf'), width=20)
    assert (inf + inf).special == "inf"

def test_add_inf_minus_inf():
    inf = TFloat(float('inf'), width=20)
    minus_inf = -inf
    # inf + (-inf) is indeterminate → NaR
    assert (inf + minus_inf).special == "nar"

def test_add_inf_finite():
    inf = TFloat(float('inf'), width=20)
    a = TFloat(42.0, width=20)
    assert (inf + a).special == "inf"
    assert (a + inf).special == "inf"


# ── Basic arithmetic ────────────────────────────────────────────

def test_add_same_exponent():
    a = TFloat(1.0, width=20)
    b = TFloat(1.0, width=20)
    assert abs(float(a + b) - 2.0) < 0.01

def test_add_different_exponents():
    a = TFloat(9.0, width=20)
    b = TFloat(3.0, width=20)
    assert abs(float(a + b) - 12.0) < 0.1

def test_add_opposite_signs_exact_cancellation():
    a = TFloat(5.0, width=20)
    b = TFloat(-5.0, width=20)
    result = a + b
    assert result.special == "zero" or abs(float(result)) < 1e-6

def test_add_opposite_signs_partial():
    a = TFloat(7.0, width=20)
    b = TFloat(-3.0, width=20)
    assert abs(float(a + b) - 4.0) < 0.1

def test_add_very_different_magnitudes():
    # b is much smaller than a — b should be negligible
    a = TFloat(1e10, width=26)
    b = TFloat(1.0, width=26)
    result = a + b
    # The smaller value may be lost to rounding
    assert abs(float(result) - 1e10) / 1e10 < 0.01


# ── Commutativity ───────────────────────────────────────────────

def test_add_commutative():
    for va, vb in [(3.0, 7.0), (2.5, 1.3), (-4.0, 9.0), (0.1, 0.2)]:
        a = TFloat(va, width=26)
        b = TFloat(vb, width=26)
        assert (a + b) == (b + a), f"Failed for {va} + {vb}"


# ── Width validation ────────────────────────────────────────────

def test_add_different_widths_raises():
    a = TFloat(1.0, width=8)
    b = TFloat(1.0, width=10)
    with pytest.raises(TypeError):
        _ = a + b


# ── Accuracy against float reference ────────────────────────────

def test_add_accuracy():
    pairs = [
        (1.0, 2.0),
        (3.5, 4.5),
        (-1.5, 2.5),
        (100.0, 0.5),
        (0.1, 0.2),
        (1e-5, 1e-5),
        (1e5, -1e5),
    ]
    for va, vb in pairs:
        a = TFloat(va, width=26)
        b = TFloat(vb, width=26)
        result = float(a + b)
        expected = va + vb
        if expected == 0:
            assert abs(result) < 1e-6, f"{va}+{vb}: got {result}"
        else:
            rel_error = abs(result - expected) / abs(expected)
            assert rel_error < 0.001, \
                f"{va}+{vb}={expected}, got {result}, rel_error={rel_error}"


# ── Associativity (approximate) ─────────────────────────────────

def test_add_associative_approximate():
    """Float arithmetic is not strictly associative, but for well-scaled
    values the result should be close."""
    a = TFloat(2.0, width=26)
    b = TFloat(3.0, width=26)
    c = TFloat(4.0, width=26)
    left = (a + b) + c
    right = a + (b + c)
    assert abs(float(left) - float(right)) < 0.01


# ── Subtraction via negation ────────────────────────────────────

def test_sub_via_add_neg():
    a = TFloat(10.0, width=20)
    b = TFloat(3.0, width=20)
    assert abs(float(a - b) - 7.0) < 0.1
    assert abs(float(b - a) + 7.0) < 0.1


# ── Regression: small values ────────────────────────────────────

def test_add_very_small():
    a = TFloat(1e-50, width=26)
    b = TFloat(1e-50, width=26)
    result = a + b
    assert float(result) > 0
    assert abs(float(result) - 2e-50) / 2e-50 < 0.01


def test_add_very_large():
    a = TFloat(1e50, width=26)
    b = TFloat(1e50, width=26)
    result = a + b
    assert abs(float(result) - 2e50) / 2e50 < 0.01
