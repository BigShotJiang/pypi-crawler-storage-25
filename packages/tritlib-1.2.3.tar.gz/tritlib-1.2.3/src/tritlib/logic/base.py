from abc import ABC, abstractmethod
from tritlib import Trit
class TernaryLogic(ABC):
    """
    Abstract base class for ternary logic operations.
    Defines methods for logical NOT, AND, OR, and IMPLY operations on trits.
    Subclasses must implement the `imply_op` method.

    Methods:
        not_op(a): Returns the logical NOT of a trit.
        and_op(a, b): Returns the logical AND of two trits.
        or_op(a, b): Returns the logical OR of two trits.
        imply_op(a, b): Abstract method for logical implication (to be implemented by subclasses).
        xor_op(a,b): Returns the logical XOR of two trits.
    """

    def not_op(self, a: Trit) -> Trit: 
        return Trit(-a.value)

    def and_op(self, a: Trit, b: Trit) -> Trit: 
        return Trit(min(b.value, a.value))
    
    def or_op(self, a: Trit, b: Trit) -> Trit: 
        return Trit(max(a.value,b.value))

    @abstractmethod
    def imply_op(self, a: Trit, b: Trit) -> Trit: ...

    def xor_op(self, a: Trit, b: Trit) -> Trit:
        return self.or_op(
            self.and_op(a, self.not_op(b)),
            self.and_op(self.not_op(a), b)
        )

    def equiv_op(self, a: Trit, b: Trit) -> Trit:
        return self.not_op(self.xor_op(a,b))
