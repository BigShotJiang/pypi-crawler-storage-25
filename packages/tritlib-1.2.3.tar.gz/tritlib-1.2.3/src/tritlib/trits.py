from __future__ import annotations
from functools import total_ordering
from typing import Tuple
from tritlib.trit import Trit, N, Z, P
from itertools import zip_longest


def _str_to_trits(s: str):
    """Parse a balanced ternary string into a list of Trit (little-endian).

    Characters '+', '0', '-' map to P, Z, N respectively.
    The input string is big-endian (most significant trit first),
    and the output list is little-endian (least significant trit first).

    Args:
        s: A string of '+', '0', and '-' characters.

    Returns:
        A list of Trit in little-endian order.

    Raises:
        ValueError: If any character is not in {'+', '0', '-'}.
    """
    trit_dict = {"+": P, "-": N, "0": Z}
    trits = []
    for char in reversed(s):
        if char not in trit_dict:
            raise ValueError
        else:
            trits.append(trit_dict.get(char))
    return trits


@total_ordering
class Trits:
    """Arbitrary-length balanced ternary integer.

    Represents a signed integer in balanced ternary using digits from
    {-1, 0, +1}. Trits are stored internally in little-endian order
    (least significant trit first) and automatically normalized
    (leading zeros stripped, except for the value zero which is stored
    as a single Z trit).

    Trits is immutable: all operations return new instances.

    Can be constructed from a Python int or a balanced ternary string
    using '+', '0', '-' symbols (e.g. "+-0+" represents 8).

    Examples:
        >>> Trits(42)
        Trits("++--0")
        >>> Trits("+-0+")
        Trits("+-0+")
        >>> int(Trits(42))
        42
        >>> Trits(13) + Trits(14)
        Trits("+000")
    """

    __slots__ = ("_trits",)

    def __hash__(self) -> int:
        return hash(self._trits)

    def __setattr__(self, name, value):
        raise AttributeError("Trits is immutable")

    @classmethod
    def _from_trits(cls, trits: list[Trit] | tuple[Trit]) -> Trits:
        """Internal constructor from a list of trits (little-endian).

        Normalizes by stripping trailing Z trits (leading zeros in
        big-endian), keeping at least one trit for zero.
        """
        if isinstance(trits, tuple):
            trits = list(trits)
        while len(trits) > 1 and trits[-1] == Z:
            trits.pop()
        obj = cls.__new__(cls)
        if len(trits) == 0:
            trits = [Z]
        object.__setattr__(obj, "_trits", tuple(trits))
        return obj

    @classmethod
    def from_be_trits(cls, trits: list[Trit]) -> Trits:
        """Construct a Trits from big-endian trit list.

        Args:
            trits: List of Trit, most significant first.

        Returns:
            A new normalized Trits.
        """
        return cls._from_trits(list(reversed(trits)))

    @property
    def _be_trits(self):
        """Internal: trits in big-endian order (most significant first)."""
        return list(reversed(self.trits))

    def __getitem__(self, key):
        """Access individual trits or slices.

        Args:
            key: An int index returns a single Trit.
                A slice returns a Trits of the selected range.

        Raises:
            TypeError: If key is neither int nor slice.
        """
        if isinstance(key, int):
            return self._trits[key]
        elif isinstance(key, slice):
            return Trits._from_trits(list(self._trits[key]))
        else:
            raise TypeError

    @classmethod
    def from_str(cls, str_value: str) -> Trits:
        """Construct a Trits from a balanced ternary string.

        Args:
            str_value: A string of '+', '0', '-' characters,
                most significant trit first.

        Returns:
            A new normalized Trits.

        Raises:
            ValueError: If any character is invalid.
        """
        return cls._from_trits(_str_to_trits(str_value))

    def __str__(self) -> str:
        """Human-readable balanced ternary string (big-endian, +/0/- symbols)."""
        trit_dict = {P: "+", N: "-", Z: "0"}
        return "".join(trit_dict[t] for t in reversed(self._trits))

    def __init__(self, n):
        """Construct a Trits from an int or a balanced ternary string.

        Args:
            n: A Python int, or a string of '+', '0', '-' characters.

        Raises:
            TypeError: If n is neither int nor str.
        """
        if isinstance(n, str):
            object.__setattr__(self, "_trits", tuple(_str_to_trits(n)))
        elif isinstance(n, int):
            if n == 0:
                object.__setattr__(self, "_trits", (Z,))
                return
            _trits = []
            while n != 0:
                n, r = divmod(n, 3)
                if r == 2:
                    n += 1
                    _trits.append(N)
                elif r == 1:
                    _trits.append(P)
                else:
                    _trits.append(Z)
            object.__setattr__(self, "_trits", tuple(_trits))
        else:
            raise TypeError(f"cannot convert {type(n)} to Trits")

    def __repr__(self) -> str:
        return f"Trits(\"{str(self)}\")"

    def __int__(self) -> int:
        """Convert to Python int using Horner's method."""
        acc = 0
        for trit in reversed(self._trits):
            acc = acc * 3 + trit.value
        return acc

    @property
    def trits(self) -> Tuple[Trit]:
        """The underlying trits as a tuple (little-endian)."""
        return self._trits

    def __eq__(self, other) -> bool:
        if not isinstance(other, Trits):
            return NotImplemented
        return self.trits == other.trits

    def __abs__(self) -> Trits:
        """Return the absolute value as a new Trits."""
        if self.trits[-1] == N:
            return -self
        return self

    # ── Arithmetic ──────────────────────────────────────────────────

    def __add__(self, other) -> Trits:
        """Addition with carry propagation, arbitrary precision.

        Uses full_add trit-by-trit with zip_longest to handle
        operands of different lengths.
        """
        if not isinstance(other, Trits):
            return NotImplemented
        _trits = []
        c = Z
        for a, b in zip_longest(self.trits, other.trits, fillvalue=Z):
            s, c = a.full_add(b, c)
            _trits.append(s)
        if c != Z:
            _trits.append(c)
        return Trits._from_trits(_trits)

    def __neg__(self) -> Trits:
        """Negate by inverting every trit. In balanced ternary,
        negation requires no carry propagation."""
        return Trits._from_trits([-t for t in self._trits])

    def __sub__(self, other) -> Trits:
        """Subtraction via addition of the negated operand."""
        if not isinstance(other, Trits):
            return NotImplemented
        return self + -other

    def __mul__(self, other) -> Trits:
        """Multiplication by long multiplication.

        For each trit of self (from least significant), multiply
        other by that single trit (no carry possible since
        Trit * Trit stays within {-1, 0, 1}), shift by position,
        and accumulate. Zero trits are skipped as an optimization.
        """
        if not isinstance(other, Trits):
            return NotImplemented
        result = Trits._from_trits([Z])
        for i, t in enumerate(self._trits):
            if t == Z:
                continue
            partial = [Z] * i + [t * a for a in other._trits]
            p = Trits._from_trits(partial)
            result = result + p
        return result

    def __len__(self):
        """Return the number of trits (excluding leading zeros)."""
        return len(self._trits)

    # ── Comparison ──────────────────────────────────────────────────

    def __lt__(self, other):
        """Less-than comparison.

        Compares by length first (longer number with positive leading
        trit is greater), then trit-by-trit from most significant.
        """
        if not isinstance(other, Trits):
            return NotImplemented
        if len(self) < len(other):
            return other.trits[-1] == P
        elif len(self) > len(other):
            return self.trits[-1] == N
        else:
            for t1, t2 in zip(reversed(self.trits), reversed(other.trits)):
                if t1 < t2:
                    return True
                elif t1 > t2:
                    return False
            return False

    # ── Division ────────────────────────────────────────────────────

    def __divmod__(self, other) -> tuple[Trits, Trits]:
        """Balanced ternary division using the double trial quotient method.

        At each step, the most significant trit of the partial remainder
        and the divisor determine the quotient trit: same sign yields P,
        opposite sign yields N, zero yields Z. No magnitude comparison
        is needed.

        Returns (quotient, remainder) such that
        self == other * quotient + remainder.
        The remainder carries the sign of the dividend.

        Raises:
            ZeroDivisionError: If other is zero.
        """
        if not isinstance(other, Trits):
            return NotImplemented
        if other == Trits(0):
            raise ZeroDivisionError
        if self._trits == (Z,):
            return Trits(0), Trits(0)
        if len(self) < len(other):
            return Trits(0), self
        sign_s = self._be_trits[0] == P
        sign_d = other._be_trits[0] == P

        s = abs(self)._be_trits
        d = abs(other)._be_trits
        partial_rest = s[:len(d) - 1]
        rem = s[len(d) - 1:]
        q_be_trits = []
        while len(rem) > 0:
            partial_rest += [rem.pop(0)]
            if d[0] * partial_rest[0] == P:
                q_be_trits.append(P)
                pr = Trits.from_be_trits(partial_rest) - abs(other)
                partial_rest = pr._be_trits
            elif d[0] * partial_rest[0] == N:
                q_be_trits.append(N)
                pr = Trits.from_be_trits(partial_rest) + abs(other)
                partial_rest = pr._be_trits
            else:
                q_be_trits.append(Z)
        q = Trits.from_be_trits(q_be_trits)
        pr = Trits.from_be_trits(partial_rest)
        while pr > other:
            q = q + Trits(1)
            pr = pr - abs(other)
        # quotient sign: negative if operand signs differ
        if sign_s != sign_d:
            q = -q
        # remainder sign: same as dividend
        if not sign_s:
            pr = -pr
        return q, pr

    def __floordiv__(self, other) -> Trits:
        """Floor division (quotient only)."""
        return divmod(self, other)[0]

    def __mod__(self, other) -> Trits:
        """Modulo (remainder only)."""
        return divmod(self, other)[1]
