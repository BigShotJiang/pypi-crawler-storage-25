"""Tekum: balanced ternary tapered precision floating-point arithmetic.

Implements the Tekum format as defined by Laslo Hunhold
(arXiv:2512.10964). Tekum is a tapered precision number system for
balanced ternary logic, inspired by posit and takum formats.

Key properties:
- No sign trit: the sign is implicit in the balanced ternary mantissa.
- Tapered precision: the regime determines how many trits are allocated
  to the exponent vs. the fraction. Numbers near 1.0 have maximum
  precision; extreme values trade precision for dynamic range.
- Truncation is rounding: reducing precision is a simple truncation
  of the anchor, with no carry propagation needed.
- Three special values: zero (all Z), infinity (all P), NaR (all N).
- Width must be even and >= 8.

The value of a non-special tekum is:
    θ(t) = sign × (1 + fraction_value) × 3^exponent_value

where the exponent_value combines a regime-dependent bias with an
explicitly encoded exponent, and fraction_value ∈ (-0.5, 0.5).
"""

from __future__ import annotations
from functools import total_ordering
from math import floor, log, isnan, isinf
from typing import Optional
from tritlib import Z, N, P, Tryte, Trits, Trit

BIAS = [0, 1, 2, 4, 10, 28, 82, 244]
"""Exponent bias table indexed by |regime|.

For a given regime value r, the bias is sign(r) × BIAS[|r|].
The bias shifts the exponent window so that each regime covers
a distinct, non-overlapping range of exponent values.
"""


@total_ordering
class TFloat:
    """Balanced ternary tapered precision floating-point number (Tekum format).

    Stores the raw Tryte representation and derives all components
    (regime, exponent, fraction, sign) on demand via properties.
    Immutable: all operations return new instances.

    Can be constructed from a Tryte (decoding a register or memory word)
    or from a Python float/int (encoding into Tekum format).

    Args:
        v: A Tryte to decode, or a float/int to encode.
        width: Required when constructing from float/int. Must be even
            and >= 8.

    Raises:
        ValueError: If width is odd, < 8, or missing for float construction.
        TypeError: If v is neither Tryte nor float/int.

    Examples:
        >>> TFloat(Tryte(1640, 8))       # decode: θ = 1.0
        TFloat(1.0, width=8)
        >>> TFloat(3.14, width=20)       # encode
        TFloat(3.1399..., width=20)
        >>> float(TFloat(1.0, width=8))
        1.0
    """

    __slots__ = ('_raw', '_special')

    def __setattr__(self, name, value):
        raise AttributeError("TFloat is immutable")

    def __hash__(self):
        return hash(self._raw)

    def __init__(self, v: float | Tryte, width: Optional[int] = None):
        if isinstance(v, Tryte):
            self._from_raw_tryte(v)
        elif isinstance(v, (int, float)):
            if width is None:
                raise ValueError("width required for float construction")
            self.from_float(v, width)
        else:
            raise TypeError

    # ── Construction ────────────────────────────────────────────────

    def from_float(self, v: float, width: int):
        """Encode a Python float into Tekum format.

        Determines the optimal regime, exponent, and fraction to
        represent the value within the given width. The fraction
        is clamped to the representable range to handle floating-point
        rounding edge cases.

        Args:
            v: The float value to encode.
            width: Trit width, must be even and >= 8.

        Raises:
            ValueError: If width is odd or < 8.
        """
        if width < 8 or width % 2 != 0:
            raise ValueError('Length of Tryte must be even and >=8')
        if v == 0.0:
            object.__setattr__(self, "_raw", Tryte(0, width))
            object.__setattr__(self, "_special", "zero")
            return
        if isinf(v):
            object.__setattr__(self, "_raw", Tryte._from_trits([P] * width, width))
            object.__setattr__(self, "_special", "inf")
            return
        if isnan(v):
            object.__setattr__(self, "_raw", Tryte._from_trits([N] * width, width))
            object.__setattr__(self, "_special", "nar")
            return
        s = 1 if v > 0 else -1
        v_abs = abs(v)
        e = floor(log(v_abs) / log(3))
        f = v_abs / 3**e - 1
        # Ensure f ∈ (-0.5, 0.5) — adjust exponent if needed
        if f >= 0.5:
            e += 1
            f = v_abs / 3**e - 1
        elif f < -0.5:
            e -= 1
            f = v_abs / 3**e - 1
        r_signed, c, e_trits_val = self._find_regime(e)
        # Quantize the fraction, clamp to representable range
        p = width - c - 3
        f_int = round(f * 3**p)
        max_f = (3**p - 1) // 2
        f_int = max(-max_f, min(max_f, f_int))
        p = width - c - 3
        fraction_trits = Tryte(f_int, p).trits
        anc = self._assemble_raw(sign=s, r_signed=r_signed, e_trits_val=e_trits_val, c=c, fraction_trits_le=fraction_trits, width=width)
        object.__setattr__(self, '_raw', anc)
        object.__setattr__(self, '_special', None)

    @classmethod
    def _find_regime(cls, e_total) -> tuple[int, int, int]:
        """Returns (r_signed, c, e_trits_val) for a given total exponent.

        Args:
            e_total: the int value of the exponent
        """
        r_sign = 1 if e_total >= 0 else -1
        e_abs = abs(e_total)
        found_r = 0
        for r in range(8):
            c = max(0, r - 2)
            max_e = (3**c - 1) // 2 if c > 0 else 0
            if e_abs <= BIAS[r] + max_e:
                found_r = r
                break
        r_signed = r_sign * found_r
        c = max(0, found_r - 2)
        b = r_sign * BIAS[found_r]
        e_trits_val = e_total - b
        return (r_signed, c, e_trits_val)

    @classmethod
    def _assemble_raw(cls, sign: int, r_signed: int, e_trits_val: int, c: int, 
                      fraction_trits_le: tuple[Trit, ...], width:int):
        """Assemble les composants en Tryte raw."""
        regime_trits = Tryte(r_signed, 3).trits
        exponent_trits = Tryte(e_trits_val, c).trits if c > 0 else ()
        le_raw = fraction_trits_le + exponent_trits + regime_trits
        be = list(reversed(le_raw))
        assert len(be) == width
        anc = Tryte.from_be_trits(be, width) + Tryte(
            "".join(["+-" for _ in range(width // 2)]), width
        )
        if sign < 0:
            anc = -anc
        return anc

    @classmethod
    def from_int(cls, value: int|Trits|Tryte, width: Optional[int] = None):
        if (not isinstance(value,Tryte)) and (width is None):
            raise ValueError("width required for Trits construction")
        if isinstance(value, int):
            value = Trits(value)
        elif isinstance(value, Tryte):
            width = value.width
            value = value.to_trits()
        if value == Trits(0):
            return TFloat(0.0, width=width)
        assert width is not None
        if width % 2 != 0:
            raise ValueError("width must be even")
        if width < 8:
            raise ValueError("width must be >= 8")
        sign = int(value._be_trits[0])
        abs_value = abs(value)
        e = len(value) - 1
        fraction_be = abs_value._be_trits[1:]
        r_signed, c, e_trits_val = TFloat._find_regime(e)
        p_final = width-c-3
        if len(fraction_be) > p_final:
            fraction_be = fraction_be[:p_final]
        else:
            fraction_be = fraction_be + [Z]*(p_final - len(fraction_be))
        anc = TFloat._assemble_raw(sign=sign, r_signed=r_signed, e_trits_val=e_trits_val, 
                                 c=c, 
                fraction_trits_le=tuple(reversed(fraction_be)), width=width)
        obj = cls.__new__(cls)
        object.__setattr__(obj, '_raw', anc)
        object.__setattr__(obj, '_special', None)
        return obj

    def __int__(self) -> int:
        return int(self.to_trits()) 

    def to_trits(self) -> Trits:
        if self._special is not None:
            match self._special:
                case 'zero':
                    return Trits(0)
                case 'nar':
                    raise ValueError
                case 'inf':
                    raise OverflowError
        e = self.exponent_value
        if e < 0:
            return Trits(0)
        if len(self.fraction) >= e:
            result = Trits.from_be_trits([P] + self.fraction[:e])
        else:
            result = Trits.from_be_trits([P] + self.fraction + [Z] * (e - len(self.fraction)))
        if self.sign == N:
            return -result
        return result

    def to_tryte(self, width) -> Tryte:
        p_final = width - self._c - 3
        if p_final <= 0 :
            raise OverflowError
        e = self.exponent_value
        trits_le = [Z] * max(0, e - p_final) + self.fraction[::-1][-min(e, p_final):] + [P]
        result = Tryte._from_trits(trits_le, width)
        if self.sign == N:
            return -result
        return result


    def _from_raw_tryte(self, t: Tryte):
        """Decode a Tryte as a Tekum floating-point value.

        Interprets the raw trit pattern according to the Tekum format:
        detects special values (zero, infinity, NaR) and stores the
        raw Tryte for on-demand decoding of regime, exponent, and
        fraction via properties.

        Args:
            t: The Tryte to interpret as a Tekum number.

        Raises:
            ValueError: If the Tryte width is odd or < 8.
        """
        if t.width < 8 or t.width % 2 != 0:
            raise ValueError('Length of Tryte must be even and >=8')
        if len(set(t._trits)) == 1:
            object.__setattr__(self, "_raw", t)
            if t._trits[0] == Z:
                object.__setattr__(self, "_special", "zero")
            elif t._trits[0] == N:
                object.__setattr__(self, "_special", "nar")
            else:
                object.__setattr__(self, "_special", "inf")
            return
        object.__setattr__(self, "_special", None)
        object.__setattr__(self, "_raw", t)

    def to_raw(self) -> Tryte:
        """Return the underlying raw Tryte representation."""
        return self._raw

    # ── Core properties ─────────────────────────────────────────────

    @property
    def special(self) -> str | None:
        """The special value kind, or None for normal numbers.

        Returns 'zero', 'inf', 'nar', or None.
        """
        return self._special

    @property
    def width(self) -> int:
        """The trit width of this Tekum number."""
        return len(self._raw)

    @property
    def sign(self) -> Trit:
        """The sign of this value as a Trit (P, Z, or N)."""
        return self._raw.sign()

    # ── Anchor and decoding ─────────────────────────────────────────

    @property
    def anchor(self) -> Tryte:
        """The anchor: anc(t) = |t| - +-+-...+-

        The anchor is the central decoding tool of the Tekum format.
        It normalizes the raw Tryte by taking its absolute value and
        subtracting the midpoint pattern +-+-..., yielding a
        representation where regime, exponent, and fraction can be
        read directly.
        """
        return abs(self._raw) - Tryte(
            "".join(["+-" for _ in range(self.width // 2)]), self.width
        )

    @property
    def _be_anchor(self) -> list[Trit]:
        """The anchor trits in big-endian order (most significant first)."""
        return list(reversed(self.anchor.trits))

    @property
    def regime(self) -> int:
        """The regime value r ∈ {-7, ..., 7}.

        Extracted from the three most significant trits of the anchor.
        Determines the number of exponent trits and the exponent bias.
        """
        if self._special is not None:
            return 0
        return int(Trits.from_be_trits(self._be_anchor[0:3]))

    @property
    def _c(self) -> int:
        """The exponent trit count: c = max(0, |r| - 2)."""
        return max(0, abs(self.regime) - 2)

    @property
    def exponent_trit_count(self) -> int:
        """The number of trits allocated to the exponent."""
        return self._c

    @property
    def fraction_trit_count(self) -> int:
        """The number of trits allocated to the fraction."""
        return self.width - self._c - 3

    @property
    def exponent(self) -> list[Trit]:
        """The raw exponent trits (big-endian), empty if c = 0."""
        if self._special is not None:
            return [Z]
        if self._c == 0:
            return []
        return self._be_anchor[3:3 + self._c]

    @property
    def exponent_value(self) -> int:
        """The total exponent value e = int(exponent_trits) + bias.

        Combines the regime-dependent bias with the value encoded
        in the exponent trits. When there are no exponent trits
        (c = 0), returns the bias alone.
        """
        if self._special is not None:
            return 0
        r = self.regime
        b = 0 if r == 0 else (abs(r) // r) * BIAS[abs(r)]
        if self._c == 0:
            return b
        return int(Trits.from_be_trits(self.exponent)) + b

    @property
    def fraction(self) -> list[Trit]:
        """The raw fraction trits (big-endian)."""
        if self._special is not None:
            return [Z]
        return self._be_anchor[3 + self._c:]

    @property
    def fraction_value(self) -> float:
        """The fraction value f ∈ (-0.5, 0.5).

        Computed as the sum of each fraction trit weighted by
        decreasing powers of 3: f = Σ trit_i × 3^(-i).
        """
        if self._special is not None:
            return 0
        f = sum(
            trit.value * 3**(-i)
            for i, trit in enumerate(
                self.anchor[-self._c - 4::-1], start=1
            )
        )
        return f

    # ── Conversion ──────────────────────────────────────────────────

    def __float__(self) -> float:
        """Convert to Python float: θ = sign × (1 + f) × 3^e.

        Returns 0.0 for zero, float('inf') for infinity,
        and float('nan') for NaR.
        """
        if self._special is not None:
            if self._special == "zero":
                return 0.0
            elif self._special == "inf":
                return float('inf')
            elif self._special == "nar":
                return float('nan')
        e = self.exponent_value
        return int(self.sign) * (1 + self.fraction_value) * 3**e

    def __repr__(self):
        if self._special == "nar":
            return "TFloat(NaR)"
        if self._special == "inf":
            return "TFloat(∞)"
        if self._special == "zero":
            return "TFloat(0)"
        return f"TFloat({float(self)}, width={self.width})"

    def __str__(self):
        """Human-readable string of the float value."""
        if self._special == "nar":
            return "NaR"
        if self._special == "inf":
            return "∞"
        return str(float(self))

    # ── Comparison ──────────────────────────────────────────────────

    def __eq__(self, other) -> bool:
        """Equality by raw Tryte comparison."""
        if not isinstance(other, TFloat):
            return NotImplemented
        return self._raw == other._raw

    def __lt__(self, other) -> bool:
        """Less-than by raw Tryte integer comparison.

        Tekum monotonicity (Proposition 4) guarantees that integer
        ordering on the raw Tryte corresponds to numerical ordering
        of the represented values.
        """
        if not isinstance(other, TFloat):
            return NotImplemented
        return self._raw < other._raw

    def __neg__(self) -> TFloat:
        """Negate by inverting all trits of the raw Tryte.

        Proposition 3 of the Tekum paper guarantees θ(-t) = -θ(t).
        """
        return TFloat(-self._raw)

    def __sub__(self, other) -> TFloat:
        """Subtraction via negation and addition.

        Raises:
            TypeError: If widths differ.
        """
        return self + (-other)

    # Non native Artithmetic
    # Uses Python float

    def __truediv__(self, other) -> TFloat:
        """Division via float conversion.

        Division by zero returns infinity (Tekum convention:
        1/0 = ∞ in the real wheel algebra).

        Raises:
            TypeError: If widths differ.
        """
        if not isinstance(other, TFloat):
            return NotImplemented
        if self.width != other.width:
            raise TypeError
        if float(other) == 0.0:
            return TFloat(float('inf'), width=self.width)
        return TFloat(float(self) / float(other), width=self.width)


    # ── Native Arithmetic ────────────────────────────────────────────
    #
    # Native arhtithmetic operations preserving the exact Tekum rounding
    # behaviour.

    def __add__(self, other) -> TFloat:
        """Addition using Tekum native format

        Raises:
            TypeError: If widths differ.
        """
        if not isinstance(other, TFloat):
            return NotImplemented
        if self.width != other.width:
            raise TypeError

        if (self._special is not None) or (other._special is not None):
            if self._special == 'nar' or other._special == 'nar':
                return TFloat(float('nan'), self.width)
            if self._special == 'inf' or other._special == 'inf':
                return TFloat(float('inf'), self.width)
            if self._special == 'zero':
                return other
            if other._special == 'zero':
                return self
        e1 = self.exponent_value
        e2 = other.exponent_value
        e_total = max(e1, e2)
        # Récupérer les fractions comme int signés
        p_self = self.fraction_trit_count
        p_other = other.fraction_trit_count
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0

        # Mantisses entières normalisées à la même échelle
        p_work = max(p_self, p_other) + 2  # avec garde
        M1_int = (3**p_self + f1_int) * 3**(p_work - p_self)
        M2_int = (3**p_other + f2_int) * 3**(p_work - p_other)

        # Signes
        if self.sign == N:
            M1_int = -M1_int
        if other.sign == N:
            M2_int = -M2_int

        # Créer les Tryte
        work_width = p_work + 3
        M1 = Tryte(M1_int, work_width)
        M2 = Tryte(M2_int, work_width)
        diff = abs(e1 - e2)
        if e1 > e2:
            M2 = M2 >> diff
        else:
            M1 = M1 >> diff
        M_result = M1 + M2
        if M_result == Tryte(0, work_width):
            return TFloat(float(0), width = self.width)
        # Normalization of M
        low = Tryte((3**p_work + 1) // 2, work_width)     # ceil(3^p / 2)
        high = Tryte((3**(p_work+1) + 1) // 2, work_width) # ceil(3^(p+1) / 2)
        while abs(M_result) >= high:
            M_result = M_result >> 1
            e_total += 1

        while abs(M_result) != Tryte(0, work_width) and abs(M_result) < low:
            M_result = M_result << 1
            e_total -= 1

        sign = 1 if M_result.sign() == P else -1
        be = list(reversed(abs(M_result).trits))
        # be[0] == P
        # b[1:] -> fraction_trits_be
        r_signed, c, e_trits_val = self._find_regime(e_total)
        p_final = self.width - c - 3

        leading_idx = 0
        for i, t in enumerate(be):
            if t != Z:
                leading_idx = i
                break

        # be[leading_idx] est le "1" de la mantisse
        # be[leading_idx+1:] sont les trits de fraction
        fraction_be = be[leading_idx + 1 : leading_idx + 1 + p_final]
        if len(fraction_be) < p_final:
            fraction_be = fraction_be + [Z] * (p_final - len(fraction_be))
        fraction_trits_le = tuple(reversed(fraction_be))
        anc = self._assemble_raw(sign=sign, r_signed=r_signed, c=c, e_trits_val=e_trits_val,
                                 fraction_trits_le=fraction_trits_le, width=self.width)
        # Assemble the anchor in little-endian order
        obj = TFloat.__new__(TFloat)
        object.__setattr__(obj, '_raw', anc)
        object.__setattr__(obj, '_special', None)
        return obj


    def __mul__(self, other) -> TFloat:
        """Multiplication using native arithmetic.

        Raises:
            TypeError: If widths differ.
        """
        if not isinstance(other, TFloat):
            return NotImplemented
        if self.width != other.width:
            raise TypeError

        if (self._special is not None) or (other._special is not None):
            if self._special == 'nar' or other._special == 'nar':
                return TFloat(float('nan'), self.width)
            
            if self._special == 'zero':
                if other._special == 'inf':
                    return TFloat(float('nan'), self.width)
                else :
                    return TFloat(0.0, self.width)
            if other._special == 'zero':
                if self._special == 'inf':
                    return TFloat(float('nan'), self.width)
                else :
                    return TFloat(0.0, self.width)

            if other._special == 'inf' or self._special == 'inf':
                return TFloat(float('inf'), self.width)

        e1 = self.exponent_value
        e2 = other.exponent_value
        e_total = e1 + e2
        # Récupérer les fractions comme int signés
        p_self = self.fraction_trit_count
        p_other = other.fraction_trit_count
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0

        # Construire les mantisses entières signées à échelle commune
        work_scale = max(p_self, p_other) + 2  # échelle avec garde
        work_width = work_scale + 3
        # f1 comme entier signé
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0

        # Mantisses (1+f) × 3^work_scale comme entiers
        M1_int = (3**p_self + f1_int) * 3**(work_scale - p_self)
        M2_int = (3**p_other + f2_int) * 3**(work_scale - p_other)
        if self.sign == N:
            M1_int = -M1_int
        if other.sign == N:
            M2_int = -M2_int
        # Créer les Tryte
        double_width = work_width * 2
        M1 = Tryte(M1_int, double_width)
        M2 = Tryte(M2_int, double_width)
        M_result = M1 * M2
        M_result = M_result >> work_scale
        # Normalization of M
        low = Tryte((3**work_scale + 1) // 2, double_width)     # ceil(3^p / 2)
        high = Tryte((3**(work_scale+1) + 1) // 2, double_width) # ceil(3^(p+1) / 2)
        while abs(M_result) >= high:
            M_result = M_result >> 1
            e_total += 1

        while abs(M_result) != Tryte(0, double_width) and abs(M_result) < low:
            M_result = M_result << 1
            e_total -= 1

        sign = 1 if M_result.sign() == P else -1
        be = list(reversed(abs(M_result).trits))
        # be[0] == P
        # b[1:] -> fraction_trits_be
        r_signed, c, e_trits_val = self._find_regime(e_total)
        p_final = self.width - c - 3

        leading_idx = 0
        for i, t in enumerate(be):
            if t != Z:
                leading_idx = i
                break

        # be[leading_idx] est le "1" de la mantisse
        # be[leading_idx+1:] sont les trits de fraction
        fraction_be = be[leading_idx + 1 : leading_idx + 1 + p_final]
        if len(fraction_be) < p_final:
            fraction_be = fraction_be + [Z] * (p_final - len(fraction_be))
        fraction_trits_le = tuple(reversed(fraction_be))
        anc = self._assemble_raw(sign=sign, r_signed=r_signed, c=c, e_trits_val=e_trits_val,
                                 fraction_trits_le=fraction_trits_le, width=self.width)
        # Assemble the anchor in little-endian order
        obj = TFloat.__new__(TFloat)
        object.__setattr__(obj, '_raw', anc)
        object.__setattr__(obj, '_special', None)
        return obj
