"""Vector embeddings for semantic vault search.

Uses FastEmbed (all-MiniLM-L6-v2) for local embeddings — never sent to cloud.
Hybrid search: 70% vector similarity + 30% keyword (FTS5).
Stored in SQLite alongside FTS5 index.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime

import aiosqlite

from agntspace.vault.reader import VaultReader

log = logging.getLogger(__name__)

# Multilingual embedding model — supports 100+ languages so semantic search
# works across Swedish/English/etc. content without re-indexing per language.
# Falls back to the English-only model if the multilingual one isn't available
# in the installed fastembed catalog.
#
# bge-m3       1024-dim  multilingual (default, SOTA for cross-lingual)
# e5-large     1024-dim  multilingual (alternative)
# bge-small-en  384-dim  English-only (legacy fallback)
EMBEDDING_MODEL_MULTILINGUAL = "BAAI/bge-m3"
EMBEDDING_MODEL_ENGLISH = "BAAI/bge-small-en-v1.5"

# Dimension is determined at load time from the actual model because
# bge-m3 (1024) and bge-small-en-v1.5 (384) differ.
EMBEDDING_MODEL = EMBEDDING_MODEL_MULTILINGUAL
EMBEDDING_DIM = 1024  # bge-m3 default; updated at load time if fallback triggers

CHUNK_SIZE = 500  # arch:deterministic -- BGE-M3 has a 512-token sequence ceiling and tokenization expands ~1.3x; 500 chars is the structurally safe upper bound for text that fits in one embedding pass without truncation, not a user-tunable preference
CHUNK_OVERLAP = 50  # arch:deterministic -- 10% overlap is the empirically standard value for sliding-window text embedding to preserve cross-chunk context, fixed by the embedder's input window not by user choice


class VaultEmbeddings:
    """Semantic search over vault using local embeddings."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        vault: VaultReader,
        exclude_dirs: list[str] | None = None,
    ) -> None:
        self._db = db
        self._vault = vault
        self._exclude_dirs = set(exclude_dirs or [])
        self._model = None  # lazy load

    def _get_model(self):  # noqa: ANN202
        """Lazy-load the embedding model (downloads on first use, ~500MB for bge-m3).

        Tries the multilingual bge-m3 first so cross-language semantic search
        works out of the box. Falls back to the English-only bge-small-en-v1.5
        if the multilingual variant isn't in the installed fastembed catalog
        (older fastembed versions).
        """
        if self._model is None:
            try:
                from fastembed import TextEmbedding
            except ImportError as exc:
                raise ImportError(
                    "fastembed is required for semantic search. "
                    "Install it with: pip install agntspace[embeddings]"
                ) from exc
            global EMBEDDING_MODEL, EMBEDDING_DIM  # noqa: PLW0603
            try:
                self._model = TextEmbedding(model_name=EMBEDDING_MODEL_MULTILINGUAL)
                EMBEDDING_MODEL = EMBEDDING_MODEL_MULTILINGUAL
                EMBEDDING_DIM = 1024
                log.info("Embedding model loaded: %s (multilingual, %d-dim)",
                         EMBEDDING_MODEL, EMBEDDING_DIM)
            except Exception as exc:
                log.warning(
                    "Multilingual embedding model %s unavailable (%s) — "
                    "falling back to English-only %s",
                    EMBEDDING_MODEL_MULTILINGUAL, exc, EMBEDDING_MODEL_ENGLISH,
                )
                self._model = TextEmbedding(model_name=EMBEDDING_MODEL_ENGLISH)
                EMBEDDING_MODEL = EMBEDDING_MODEL_ENGLISH
                EMBEDDING_DIM = 384
                log.info("Embedding model loaded: %s (English-only, %d-dim)",
                         EMBEDDING_MODEL, EMBEDDING_DIM)
        return self._model

    async def init_schema(self) -> None:
        """Create embedding tables if they don't exist.

        If the configured embedding model has changed since the last run
        (e.g., user upgraded from bge-small-en to bge-m3), the existing
        vectors are now unusable — different dimension, different vector
        space. We wipe them so the next search triggers a fresh re-index.
        """
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS vault_embeddings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                chunk_text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                content_hash TEXT NOT NULL,
                indexed_at TEXT NOT NULL,
                UNIQUE(path, chunk_index)
            );
            CREATE INDEX IF NOT EXISTS idx_emb_path ON vault_embeddings(path);
            CREATE TABLE IF NOT EXISTS vault_embedding_meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)
        await self._db.commit()

        # Check for model change — if so, wipe all vectors.
        cursor = await self._db.execute(
            "SELECT value FROM vault_embedding_meta WHERE key = 'model'"
        )
        row = await cursor.fetchone()
        stored_model = row[0] if row else None
        # Load model name without forcing the model itself (cheap).
        current_model = EMBEDDING_MODEL
        if stored_model and stored_model != current_model:
            log.warning(
                "Embedding model changed %s → %s — clearing %s vectors (will re-index)",
                stored_model, current_model, "stale",
            )
            await self._db.execute("DELETE FROM vault_embeddings")
        # Record current model so the next start can detect further changes.
        await self._db.execute(
            "INSERT OR REPLACE INTO vault_embedding_meta (key, value) VALUES ('model', ?)",
            (current_model,),
        )
        await self._db.commit()

    async def index_vault(self) -> int:
        """Index all vault files with embeddings. Returns count indexed."""
        model = self._get_model()
        files = self._vault.list_files(pattern="**/*.md")
        indexed = 0

        for file_path in files:
            if self._vault.paths:
                relative = self._vault.paths.to_logical(file_path)
            else:
                relative = str(file_path.relative_to(self._vault.vault_dir)).replace("\\", "/")

            if any(relative.startswith(f"{d}/") for d in self._exclude_dirs):
                continue

            try:
                doc = self._vault.read(relative)
            except Exception:
                continue

            content_hash = hashlib.md5(doc.raw.encode()).hexdigest()

            # Check if already indexed with same hash
            cursor = await self._db.execute(
                "SELECT content_hash FROM vault_embeddings WHERE path = ? LIMIT 1",
                (relative,),
            )
            row = await cursor.fetchone()
            if row and row[0] == content_hash:
                continue

            # Delete old embeddings for this file
            await self._db.execute("DELETE FROM vault_embeddings WHERE path = ?", (relative,))

            # Chunk the content
            chunks = self._chunk_text(doc.content)
            if not chunks:
                continue

            # Generate embeddings
            embeddings = list(model.embed(chunks))

            # Store
            now = datetime.now(UTC).isoformat()
            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                emb_bytes = embedding.tobytes()
                await self._db.execute(
                    "INSERT INTO vault_embeddings (path, chunk_index, chunk_text, embedding, content_hash, indexed_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (relative, i, chunk, emb_bytes, content_hash, now),
                )

            indexed += 1

        await self._db.commit()
        log.info("Vault embeddings indexed: %d files", indexed)
        return indexed

    async def search(self, query: str, limit: int = 10) -> list[dict]:
        """Semantic search using vector similarity.

        Returns results ranked by cosine similarity.
        """
        import numpy as np

        if not query.strip():
            return []

        model = self._get_model()
        query_embedding = list(model.embed([query]))[0]

        # Fetch all embeddings (for small vaults this is fine;
        # for large vaults, use sqlite-vec extension)
        cursor = await self._db.execute(
            "SELECT path, chunk_index, chunk_text, embedding FROM vault_embeddings"
        )
        rows = await cursor.fetchall()

        if not rows:
            return []

        # Compute cosine similarity
        results = []
        query_norm = np.linalg.norm(query_embedding)

        for row in rows:
            path, chunk_idx, chunk_text, emb_bytes = row
            embedding = np.frombuffer(emb_bytes, dtype=np.float32)
            emb_norm = np.linalg.norm(embedding)

            if query_norm == 0 or emb_norm == 0:
                continue

            similarity = np.dot(query_embedding, embedding) / (query_norm * emb_norm)
            results.append({
                "path": path,
                "chunk_index": chunk_idx,
                "text": chunk_text,
                "score": float(similarity),
            })

        # Sort by similarity descending
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    async def hybrid_search(
        self, query: str, limit: int = 10, vector_weight: float = 0.7
    ) -> list[dict]:
        """Hybrid search: 70% vector + 30% keyword (FTS5).

        Combines semantic understanding with exact keyword matching.
        """
        from agntspace.vault.search import VaultSearch

        # Vector results
        vector_results = await self.search(query, limit=limit * 2)

        # Keyword results (FTS5)
        fts_search = VaultSearch(self._db, self._vault)
        keyword_results = await fts_search.search(query, limit=limit * 2)

        # Normalize scores
        max_vec = max((r["score"] for r in vector_results), default=1.0)
        max_kw = max((abs(r.get("score", 0)) for r in keyword_results), default=1.0)

        # Merge by path
        merged: dict[str, dict] = {}

        for r in vector_results:
            key = f"{r['path']}:{r.get('chunk_index', 0)}"
            merged[key] = {
                "path": r["path"],
                "text": r["text"],
                "vector_score": r["score"] / max_vec if max_vec else 0,
                "keyword_score": 0,
            }

        for r in keyword_results:
            key = f"{r['path']}:0"
            if key in merged:
                merged[key]["keyword_score"] = abs(r.get("score", 0)) / max_kw if max_kw else 0
            else:
                merged[key] = {
                    "path": r["path"],
                    "text": r.get("snippet", ""),
                    "vector_score": 0,
                    "keyword_score": abs(r.get("score", 0)) / max_kw if max_kw else 0,
                }

        # Compute hybrid score
        results = []
        for item in merged.values():
            hybrid = (vector_weight * item["vector_score"]) + ((1 - vector_weight) * item["keyword_score"])
            results.append({
                "path": item["path"],
                "text": item["text"],
                "score": hybrid,
                "vector_score": item["vector_score"],
                "keyword_score": item["keyword_score"],
            })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    @staticmethod
    def _chunk_text(text: str) -> list[str]:
        """Split text into overlapping chunks."""
        if len(text) <= CHUNK_SIZE:
            return [text] if text.strip() else []

        chunks = []
        start = 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk.strip())
            start = end - CHUNK_OVERLAP

        return chunks
