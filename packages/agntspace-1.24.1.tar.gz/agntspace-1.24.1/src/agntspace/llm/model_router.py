"""Model router — resolves agent model tiers to specific LLM models.

Architecture:
- Agents specify `model_tier` in their definition (reasoning, capable, fast)
- Users pick a `quality_profile` in Settings (quality, balanced, economy)
- This module resolves: profile + provider + tier → specific model name

Configuration loaded from skills/_meta/model-routing/config/models.yaml.
Falls back to hardcoded defaults if YAML not found.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

# Hardcoded fallback — used when YAML config not found
_FALLBACK_PROFILES: dict[str, dict[str, dict[str, str]]] = {
    "quality": {
        "anthropic": {
            "reasoning": "claude-opus-4-20250514",
            "capable": "claude-sonnet-4-20250514",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1",
            "capable": "gpt-4.1",
            "fast": "gpt-4.1-mini",
        },
    },
    "balanced": {
        "anthropic": {
            "reasoning": "claude-sonnet-4-20250514",
            "capable": "claude-sonnet-4-20250514",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1",
            "capable": "gpt-4.1-mini",
            "fast": "gpt-4.1-nano",
        },
    },
    "economy": {
        "anthropic": {
            "reasoning": "claude-sonnet-4-20250514",
            "capable": "claude-haiku-4-5-20251001",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1-mini",
            "capable": "gpt-4.1-mini",
            "fast": "gpt-4.1-nano",
        },
    },
}

_DEFAULT_TIER = "capable"

# arch:deterministic — fallback capability matrix when capabilities.yaml is
# missing or malformed. Conservative defaults: cloud tiers get reliable
# everything, local models get patched tool calling with unreliable JSON
# and no vision. The real vocabulary lives in the YAML; this is the
# safety net so first boot / corrupted YAML never crashes capability
# queries. Identical shape to capabilities.yaml.
_FALLBACK_CAPABILITIES: dict[str, Any] = {
    "profiles": {
        p: {
            t: {
                "tool_calling": "reliable",
                "json_mode": "reliable",
                "vision": "reliable" if p == "quality" else ("reliable" if t != "fast" else "unavailable"),
                "streaming": "reliable",
                "ctx_window": 200000 if p == "quality" else 128000,
            }
            for t in ("reasoning", "capable", "fast")
        }
        for p in ("quality", "balanced", "economy")
    },
    "local_models": {
        "_default": {
            "tool_calling": "patched",
            "json_mode": "unreliable",
            "vision": "unavailable",
            "streaming": "reliable",
            "ctx_window": 8000,
        }
    },
}

# Capability levels that mean "the feature works and you can rely on it
# either directly or via the skill-driven patches." Everything else
# (unreliable, unavailable, unknown) means callers MUST have a fallback
# or degrade explicitly. Kept as a module-level frozenset so downstream
# callers can import it without re-typing the literal.
CAPABILITY_OK_LEVELS = frozenset({"reliable", "patched"})


def _deep_merge_capabilities(base: dict, override: dict) -> dict:
    """Recursively merge `override` on top of `base`.

    Leaves in `override` replace leaves in `base`; nested dicts merge
    per-key. Lists and scalars in `override` fully replace their
    counterparts in `base` — deep-merging into lists is rarely what a
    YAML author means and causes surprising behavior. Returns a new
    dict; neither input is mutated.

    Used specifically by the capability-matrix loader so a user YAML
    that declares only some fields for a tier still inherits the
    remaining fields from `_FALLBACK_CAPABILITIES`. Without this, a
    single-field YAML override wiped all other fields for that tier.
    """
    if not isinstance(override, dict):
        return override if override is not None else base
    result: dict = {}
    # Start from base keys
    for key, base_val in base.items():
        if key in override:
            ov_val = override[key]
            if isinstance(base_val, dict) and isinstance(ov_val, dict):
                result[key] = _deep_merge_capabilities(base_val, ov_val)
            else:
                result[key] = ov_val
        else:
            result[key] = base_val
    # Add keys that are in override but not in base
    for key, ov_val in override.items():
        if key not in result:
            result[key] = ov_val
    return result


class ModelRouter:
    """Resolves model tiers to specific model names."""

    def __init__(
        self,
        provider: str = "anthropic",
        profile: str = "balanced",
        default_model: str = "",
        skills_dir: Path | None = None,
    ) -> None:
        self._provider = provider
        self._profile = profile
        self._default_model = default_model
        self._profiles: dict[str, Any] = {}
        self._capabilities: dict[str, Any] = {}
        self._load(skills_dir)

    def _load(self, skills_dir: Path | None) -> None:
        """Load model routing config from YAML, fall back to hardcoded."""
        self._profiles = _FALLBACK_PROFILES
        self._capabilities = _FALLBACK_CAPABILITIES

        if not skills_dir:
            return

        try:
            import yaml
        except Exception:
            return

        models_path = skills_dir / "_meta" / "model-routing" / "config" / "models.yaml"
        if models_path.is_file():
            try:
                data = yaml.safe_load(models_path.read_text(encoding="utf-8"))
                self._profiles = data.get("profiles", {}) or _FALLBACK_PROFILES
                log.debug(
                    "Model routing loaded from YAML: %d profiles",
                    len(self._profiles),
                )
            except Exception:
                log.warning("Failed to load model routing YAML, using fallback")

        caps_path = skills_dir / "_meta" / "model-routing" / "config" / "capabilities.yaml"
        if caps_path.is_file():
            try:
                data = yaml.safe_load(caps_path.read_text(encoding="utf-8")) or {}
                # Deep-merge so a partial YAML (e.g. a user who only sets
                # `profiles.balanced.fast.vision: reliable`) still inherits
                # the other fields for that tier from `_FALLBACK_CAPABILITIES`.
                # Shallow-merge was a bug — it silently wiped ctx_window,
                # streaming, tool_calling, json_mode when a user declared
                # any single cap for a tier.
                merged = _deep_merge_capabilities(_FALLBACK_CAPABILITIES, data)
                self._capabilities = merged
                log.debug(
                    "Capability matrix loaded: %d profiles, %d local model families",
                    len(merged.get("profiles", {}) or {}),
                    len(merged.get("local_models", {}) or {}),
                )
            except Exception:
                log.warning("Failed to load capabilities YAML, using fallback")

    def resolve(self, model_tier: str | None = None) -> str:
        """Resolve a model tier to a specific model name.

        Args:
            model_tier: "reasoning", "capable", or "fast". None → default tier.

        Returns:
            Specific model name (e.g., "claude-sonnet-4-20250514")
        """
        tier = model_tier or _DEFAULT_TIER

        profile_data = self._profiles.get(self._profile, {})
        provider_data = profile_data.get(self._provider, {})
        model = provider_data.get(tier)

        if model:
            return self._ensure_prefix(model)

        # Fallback chain: default model → capable tier → provider default
        if self._default_model:
            return self._ensure_prefix(self._default_model)

        capable = provider_data.get("capable")
        if capable:
            return self._ensure_prefix(capable)

        return self._ensure_prefix(self._default_model or "claude-sonnet-4-20250514")

    def _ensure_prefix(self, model: str) -> str:
        """Ensure model name has provider/ prefix for LiteLLM routing."""
        if "/" in model:
            return model
        return f"{self._provider}/{model}"

    @property
    def profile(self) -> str:
        return self._profile

    @profile.setter
    def profile(self, value: str) -> None:
        self._profile = value

    def get_profile_summary(self) -> dict[str, str]:
        """Get the model assignments for the current profile."""
        profile_data = self._profiles.get(self._profile, {})
        provider_data = profile_data.get(self._provider, {})
        return dict(provider_data)

    # ----- capability matrix ---------------------------------------------
    #
    # Entry points for "does this tier/model support X?" queries. Callers
    # should check BEFORE assuming a feature works. The goal is to make
    # "cloud-only" features explicit and to prevent silent degradation on
    # local mode (journal_today regression of 2026-04-18).

    def capability(
        self,
        name: str,
        *,
        tier: str | None = None,
        model: str | None = None,
    ) -> Any:
        """Return the declared capability level for a tier or local model.

        Args:
            name: capability name — e.g. ``tool_calling``, ``json_mode``,
                ``vision``, ``streaming``, ``ctx_window``.
            tier: cloud-mode tier (``reasoning``/``capable``/``fast``).
                Defaults to the default tier.
            model: local-mode Ollama model name (e.g. ``qwen2.5:14b``).
                If provided, ``tier`` is ignored and capability is looked
                up in ``local_models`` by longest-prefix family match.

        Returns:
            For binary caps: ``"reliable"`` / ``"patched"`` / ``"unreliable"``
            / ``"unavailable"`` / ``"unknown"``. For ``ctx_window``: an int.
            Never raises — an unknown name returns ``"unknown"`` (or 0 for
            numeric caps) so callers can treat it as "do not rely on this."
        """
        table = self._lookup_capability_table(tier=tier, model=model)
        if name not in table:
            # ctx_window has a numeric default; everything else is a string
            if name == "ctx_window":
                return 0
            return "unknown"
        return table[name]

    def capability_ok(
        self,
        name: str,
        *,
        tier: str | None = None,
        model: str | None = None,
    ) -> bool:
        """True if the capability level indicates the feature works.

        "Works" means either ``reliable`` (direct support) or ``patched``
        (works via skill/prompt support such as local-intents). Anything
        else — ``unreliable`` / ``unavailable`` / ``unknown`` — returns
        False and callers must have a fallback or degrade explicitly.
        """
        level = self.capability(name, tier=tier, model=model)
        return isinstance(level, str) and level in CAPABILITY_OK_LEVELS

    def context_window(
        self,
        *,
        tier: str | None = None,
        model: str | None = None,
    ) -> int:
        """Return the declared context window in tokens (0 if unknown)."""
        raw = self.capability("ctx_window", tier=tier, model=model)
        try:
            return int(raw)
        except (TypeError, ValueError):
            return 0

    def _lookup_capability_table(
        self,
        *,
        tier: str | None,
        model: str | None,
    ) -> dict[str, Any]:
        """Resolve the correct capability block for (tier) or (model)."""
        if model:
            families = self._capabilities.get("local_models") or {}
            if not isinstance(families, dict):
                families = {}
            # Longest-prefix match — "qwen2.5:14b" matches "qwen2.5" before "_default".
            # Sorted descending by key length so sub-family overrides parent when
            # declared (e.g. "llama3.1" wins over "llama3" for "llama3.1:70b").
            for family in sorted(families.keys(), key=lambda k: -len(str(k))):
                if family == "_default":
                    continue
                if str(model).startswith(str(family)):
                    block = families.get(family)
                    if isinstance(block, dict):
                        return block
            default_block = families.get("_default")
            if isinstance(default_block, dict):
                return default_block
            return {}

        profiles = self._capabilities.get("profiles") or {}
        if not isinstance(profiles, dict):
            return {}
        profile_block = profiles.get(self._profile) or {}
        if not isinstance(profile_block, dict):
            return {}
        resolved_tier = tier or _DEFAULT_TIER
        tier_block = profile_block.get(resolved_tier) or {}
        if isinstance(tier_block, dict):
            return tier_block
        return {}
