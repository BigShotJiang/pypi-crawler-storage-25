"""Base channel interface for messaging platforms."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass
class ChannelMessage:
    """A message received from or sent to a channel."""

    channel: str
    sender: str
    text: str
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    metadata: dict = field(default_factory=dict)


class Channel(ABC):
    """Abstract base for messaging channel integrations."""

    name: str = "unknown"

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the channel."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the channel."""

    @abstractmethod
    async def send_message(self, chat_id: str, text: str) -> None:
        """Send a message to a specific chat."""

    @abstractmethod
    async def send_notification(self, chat_id: str, text: str) -> None:
        """Send a notification (may differ from message in formatting)."""

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Whether the channel is currently connected."""

    def on_message(self, callback) -> None:  # noqa: ANN001
        """Register a callback for incoming messages."""
        self._message_callback = callback
