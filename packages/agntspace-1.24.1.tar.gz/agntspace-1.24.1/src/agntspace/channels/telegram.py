"""Telegram channel — Bot API with long-polling or webhook.

When no webhook URL is provided, the channel starts a background polling
loop (``getUpdates`` with 30s long-poll timeout) so it works behind NAT
and firewalls with zero setup.  When a webhook URL IS provided, polling
is skipped and the server receives pushes from Telegram instead.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Any

import httpx

from agntspace.channels.base import Channel, ChannelMessage

log = logging.getLogger(__name__)

_MAX_MSG_LEN = 4096
_POLL_TIMEOUT = 30  # Telegram long-poll timeout (seconds)


class TelegramChannel(Channel):
    """Telegram Bot API channel with automatic polling fallback."""

    name = "telegram"

    def __init__(self, bot_token: str, webhook_url: str = "") -> None:
        self._token = bot_token
        self._webhook_url = webhook_url
        self._base_url = f"https://api.telegram.org/bot{bot_token}"
        self._connected = False
        self._message_callback: Callable | None = None
        self._chat_id: str | None = None
        self._bot_username: str | None = None
        self._bot_name: str | None = None
        self._poll_task: asyncio.Task | None = None
        self._poll_offset: int = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Validate bot token, set webhook or start polling."""
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(f"{self._base_url}/getMe")
            data = resp.json()
            if not data.get("ok"):
                raise ConnectionError(f"Telegram bot token invalid: {data}")

            bot_info = data["result"]
            self._bot_username = bot_info.get("username")
            self._bot_name = bot_info.get("first_name")
            log.info("Telegram connected: @%s", self._bot_username)

            if self._webhook_url:
                # Webhook mode — Telegram pushes to us
                wh_resp = await client.post(
                    f"{self._base_url}/setWebhook",
                    json={"url": self._webhook_url},
                )
                wh_data = wh_resp.json()
                if not wh_data.get("ok"):
                    log.warning("Telegram webhook set failed: %s", wh_data)
                else:
                    log.info("Telegram webhook set: %s", self._webhook_url)
            else:
                # Polling mode — we pull from Telegram
                # Clear any stale webhook first
                await client.post(f"{self._base_url}/deleteWebhook")
                log.info("Telegram polling mode — no webhook, starting getUpdates loop")

        self._connected = True

        # Start polling if no webhook
        if not self._webhook_url:
            self._poll_task = asyncio.create_task(self._poll_loop())

    async def disconnect(self) -> None:
        """Stop polling, remove webhook, mark disconnected."""
        # Stop polling first
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except (asyncio.CancelledError, Exception):
                pass
            self._poll_task = None

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.post(f"{self._base_url}/deleteWebhook")
        except Exception:
            log.debug("Telegram deleteWebhook failed (ignoring)", exc_info=True)

        self._connected = False
        self._bot_username = None
        self._bot_name = None
        log.info("Telegram disconnected")

    @property
    def is_connected(self) -> bool:
        return self._connected

    def get_info(self) -> dict[str, Any]:
        """Return bot metadata for status endpoints."""
        return {
            "bot_username": self._bot_username,
            "bot_name": self._bot_name,
            "webhook_url": self._webhook_url or None,
            "chat_id": self._chat_id,
            "mode": "webhook" if self._webhook_url else "polling",
        }

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        """Background loop: long-poll getUpdates and dispatch messages."""
        log.debug("Telegram poll loop started (offset=%d)", self._poll_offset)
        while self._connected:
            try:
                async with httpx.AsyncClient(timeout=_POLL_TIMEOUT + 10) as client:
                    resp = await client.get(
                        f"{self._base_url}/getUpdates",
                        params={
                            "offset": self._poll_offset,
                            "timeout": _POLL_TIMEOUT,
                            "allowed_updates": '["message"]',
                        },
                    )
                    data = resp.json()
                    if not data.get("ok"):
                        log.warning("Telegram getUpdates error: %s", data)
                        await asyncio.sleep(5)
                        continue

                    for update in data.get("result", []):
                        self._poll_offset = update["update_id"] + 1
                        # Dispatch via the same handler as webhook
                        try:
                            await self.handle_webhook(update)
                        except Exception:
                            log.exception("Telegram poll handler error")

            except asyncio.CancelledError:
                break
            except Exception:
                log.debug("Telegram poll error, retrying in 5s", exc_info=True)
                await asyncio.sleep(5)

        log.debug("Telegram poll loop stopped")

    # ------------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------------

    async def send_message(self, chat_id: str, text: str) -> None:
        """Send a text message, splitting if it exceeds Telegram's 4096-char limit."""
        if not text:
            return
        chunks = _split_message(text)
        async with httpx.AsyncClient(timeout=15) as client:
            for chunk in chunks:
                try:
                    resp = await client.post(
                        f"{self._base_url}/sendMessage",
                        json={
                            "chat_id": chat_id,
                            "text": chunk,
                            "parse_mode": "Markdown",
                        },
                    )
                    data = resp.json()
                    # Markdown parse failure — retry as plain text
                    if not data.get("ok") and "parse" in str(data.get("description", "")).lower():
                        await client.post(
                            f"{self._base_url}/sendMessage",
                            json={"chat_id": chat_id, "text": chunk},
                        )
                except Exception:
                    log.exception("Telegram send_message failed for chat %s", chat_id)

    async def send_notification(self, chat_id: str, text: str) -> None:
        """Send a notification (bell-prefixed message)."""
        await self.send_message(chat_id, f"\U0001f514 {text}")

    # ------------------------------------------------------------------
    # Receiving
    # ------------------------------------------------------------------

    async def handle_webhook(self, payload: dict[str, Any]) -> str | None:
        """Process an incoming Telegram update (from webhook or poll).

        Returns the agent's response text, or None if not a text message.
        """
        message = payload.get("message", {})
        text = message.get("text", "")
        chat_id = str(message.get("chat", {}).get("id", ""))
        sender_first = message.get("from", {}).get("first_name", "User")
        sender_last = message.get("from", {}).get("last_name", "")
        sender = f"{sender_first} {sender_last}".strip() if sender_last else sender_first
        sender_id = str(message.get("from", {}).get("id", ""))

        if not text or not chat_id:
            return None

        self._chat_id = chat_id

        channel_msg = ChannelMessage(
            channel="telegram",
            sender=sender,
            text=text,
            metadata={
                "chat_id": chat_id,
                "sender_id": sender_id,
                "message_id": str(message.get("message_id", "")),
            },
        )

        if self._message_callback:
            response = await self._message_callback(channel_msg)
            if response:
                await self.send_message(chat_id, response)
            return response

        return None


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _split_message(text: str) -> list[str]:
    """Split long text into chunks that fit Telegram's per-message limit."""
    if len(text) <= _MAX_MSG_LEN:
        return [text]

    chunks: list[str] = []
    remaining = text
    while remaining:
        if len(remaining) <= _MAX_MSG_LEN:
            chunks.append(remaining)
            break

        split_at = _MAX_MSG_LEN
        for sep in ("\n\n", "\n", " "):
            idx = remaining.rfind(sep, 0, _MAX_MSG_LEN)
            if idx > _MAX_MSG_LEN // 2:
                split_at = idx + len(sep)
                break

        chunks.append(remaining[:split_at])
        remaining = remaining[split_at:]

    return chunks
