"""Knowledge taxonomy — hierarchical classification for wiki articles.

Loads the taxonomy tree from the knowledge-taxonomy skill's config/taxonomy.yaml.
Provides methods to classify articles, build the tree with counts, and resolve paths.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

log = logging.getLogger(__name__)

# Flat representation of a taxonomy node
TaxonomyNode = dict[str, Any]


def load_taxonomy(skills_dir: Path) -> list[dict]:
    """Load taxonomy tree from the knowledge-taxonomy skill config.

    Returns the raw tree (list of top-level nodes), each with possible 'children'.
    Falls back to a minimal default if the file is missing.
    """
    yaml_path = skills_dir / "_meta" / "knowledge-taxonomy" / "config" / "taxonomy.yaml"
    if not yaml_path.is_file():
        log.warning("Taxonomy file not found: %s — using minimal default", yaml_path)
        return [{"name": "General", "slug": "general", "description": "All articles"}]

    try:
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        tree = data.get("taxonomy", [])
        if not tree:
            return [{"name": "General", "slug": "general", "description": "All articles"}]
        return tree
    except Exception:
        log.exception("Failed to parse taxonomy YAML")
        return [{"name": "General", "slug": "general", "description": "All articles"}]


def flatten_taxonomy(tree: list[dict], parent_path: str = "") -> list[TaxonomyNode]:
    """Flatten the taxonomy tree into a list of nodes with full paths.

    Each node gets:
      - path: "parent-slug/child-slug"
      - depth: 0, 1, 2
      - entity_types: inherited from parent if not set
    """
    nodes: list[TaxonomyNode] = []
    for node in tree:
        slug = node.get("slug", "")
        path = f"{parent_path}/{slug}" if parent_path else slug
        depth = path.count("/")
        flat = {
            "name": node.get("name", slug),
            "slug": slug,
            "path": path,
            "depth": depth,
            "description": node.get("description", ""),
            "entity_types": node.get("entity_types", []),
        }
        nodes.append(flat)
        children = node.get("children", [])
        if children:
            # Children inherit entity_types if they don't define their own
            for child in children:
                if "entity_types" not in child and "entity_types" in node:
                    child.setdefault("entity_types", node["entity_types"])
            nodes.extend(flatten_taxonomy(children, path))
    return nodes


def classify_article(
    entity_type: str,
    category: str,
    title: str,
    flat_nodes: list[TaxonomyNode],
) -> str:
    """Determine the best taxonomy_path for an article based on its metadata.

    Priority:
    1. entity_type match on a leaf node
    2. category keyword match on node slug/description
    3. Fall back to "general"
    """
    # Ignore generic categories that don't carry classification signal
    _GENERIC_CATEGORIES = {"article", "paper", "image", "data", "code", "uncategorized", ""}
    raw_category = category.lower().strip() if category else ""
    category_lower = "" if raw_category in _GENERIC_CATEGORIES else raw_category
    title_lower = title.lower().strip() if title else ""

    # 1. entity_type match — only for specific types (person, organization, source_summary)
    #    Skip generic types like "concept" that appear across many categories.
    if entity_type and entity_type not in ("concept",):
        et_matches = [n for n in flat_nodes if entity_type in n.get("entity_types", [])]
        if et_matches:
            # Prefer the deepest match
            et_matches.sort(key=lambda n: n["depth"], reverse=True)
            return et_matches[0]["path"]

    # 2. category/title keyword match against slugs, names, and descriptions
    best_match = ""
    best_score = 0
    search_text = f"{category_lower} {title_lower}"
    search_words = [w for w in search_text.split() if len(w) > 2]

    for node in flat_nodes:
        score = 0
        slug = node["slug"]
        name_lower = node["name"].lower()
        desc_lower = node["description"].lower()
        match_text = f"{slug} {name_lower} {desc_lower}"

        # Exact category match to slug
        if category_lower and category_lower == slug:
            score += 10

        # Category words in slug or name
        if category_lower:
            for word in category_lower.split():
                if len(word) > 2 and word in slug:
                    score += 3
                if len(word) > 2 and word in name_lower:
                    score += 2

        # Search text words in name + description + slug
        for word in search_words:
            if word in match_text:
                score += 2

        # Prefer leaf nodes (deeper = more specific)
        if score > 0:
            score += node["depth"] * 0.5

        if score > best_score:
            best_score = score
            best_match = node["path"]

    return best_match if best_match else "general"


def build_taxonomy_tree_with_counts(
    tree: list[dict], articles: list[dict],
) -> list[dict]:
    """Build the taxonomy tree annotated with article counts per node.

    Each node in the returned tree has:
      - name, slug, description, children
      - count: number of articles directly in this node
      - total: count + sum of children totals
      - articles: list of {slug, title} for articles in this node
    """
    # Index articles by their taxonomy_path
    path_articles: dict[str, list[dict]] = {}
    unclassified: list[dict] = []
    for art in articles:
        tp = art.get("taxonomy_path", "")
        if tp:
            path_articles.setdefault(tp, []).append(art)
        else:
            # Try to match by category for backwards compatibility
            cat = art.get("category", "")
            if cat:
                path_articles.setdefault(cat, []).append(art)
            else:
                unclassified.append(art)

    def _annotate(nodes: list[dict], parent_path: str = "") -> list[dict]:
        result = []
        for node in nodes:
            slug = node.get("slug", "")
            path = f"{parent_path}/{slug}" if parent_path else slug
            children = node.get("children", [])

            # Articles directly at this node (exact path match)
            direct = path_articles.get(path, [])
            # Also match articles whose taxonomy_path starts with this path but has no further /
            # (i.e. they're classified at the parent level, not a child)

            annotated_children = _annotate(children, path) if children else []
            child_total = sum(c.get("total", 0) for c in annotated_children)

            result.append({
                "name": node.get("name", slug),
                "slug": slug,
                "path": path,
                "description": node.get("description", ""),
                "count": len(direct),
                "total": len(direct) + child_total,
                "articles": [{"slug": a.get("slug", ""), "title": a.get("title", "")} for a in direct],
                "children": annotated_children,
            })
        return result

    annotated = _annotate(tree)

    # Add unclassified as a virtual node if there are any
    if unclassified:
        annotated.append({
            "name": "Unclassified",
            "slug": "unclassified",
            "path": "unclassified",
            "description": "Articles not yet classified into the taxonomy",
            "count": len(unclassified),
            "total": len(unclassified),
            "articles": [{"slug": a.get("slug", ""), "title": a.get("title", "")} for a in unclassified],
            "children": [],
        })

    return annotated


def taxonomy_for_prompt(tree: list[dict], indent: int = 0) -> str:
    """Render the taxonomy tree as indented text for LLM prompts.

    Example output:
      - People & Organizations (slug: people-organizations) — Individuals, teams, companies
        - People (slug: people) — Individual persons
        - Organizations (slug: organizations) — Companies, institutions
    """
    lines = []
    prefix = "  " * indent
    for node in tree:
        name = node.get("name", "")
        slug = node.get("slug", "")
        desc = node.get("description", "")
        lines.append(f"{prefix}- {name} (slug: {slug}) — {desc}")
        children = node.get("children", [])
        if children:
            lines.append(taxonomy_for_prompt(children, indent + 1))
    return "\n".join(lines)
