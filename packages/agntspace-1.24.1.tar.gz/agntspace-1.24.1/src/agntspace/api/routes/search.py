"""Vault search API endpoint."""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(prefix="/search", tags=["search"])


@router.get("")
async def search_vault(request: Request, q: str, limit: int = 10) -> list[dict]:
    """Search vault content via FTS5."""
    vault_search = request.app.state.vault_search
    return await vault_search.search(q, limit=limit)


@router.get("/semantic")
async def semantic_search(request: Request, q: str, limit: int = 10) -> list[dict]:
    """Semantic search via vector embeddings. First call downloads the model (~80MB)."""
    embeddings = getattr(request.app.state, "vault_embeddings", None)
    if not embeddings:
        return []
    return await embeddings.search(q, limit=limit)


@router.get("/hybrid")
async def hybrid_search(request: Request, q: str, limit: int = 10) -> list[dict]:
    """Hybrid search: 70% semantic + 30% keyword."""
    embeddings = getattr(request.app.state, "vault_embeddings", None)
    if not embeddings:
        # Fallback to keyword-only
        vault_search = request.app.state.vault_search
        return await vault_search.search(q, limit=limit)
    return await embeddings.hybrid_search(q, limit=limit)


@router.post("/reindex")
async def reindex(request: Request) -> dict:
    """Rebuild the vault search index (FTS5 + embeddings)."""
    vault_search = request.app.state.vault_search
    fts_count = await vault_search.index_vault()

    emb_count = 0
    embeddings = getattr(request.app.state, "vault_embeddings", None)
    if embeddings:
        emb_count = await embeddings.index_vault()

    return {"fts_indexed": fts_count, "embeddings_indexed": emb_count}
