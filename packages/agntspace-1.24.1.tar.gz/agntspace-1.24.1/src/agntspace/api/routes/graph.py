"""Knowledge graph API — query entities, traverse connections, SPO triples, visualize."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/graph", tags=["graph"])


@router.get("")
async def get_graph(request: Request) -> dict:
    """Get full graph data for UI visualization (nodes + edges)."""
    graph = request.app.state.knowledge_graph
    return graph.get_graph_data()


@router.get("/stats")
async def graph_stats(request: Request) -> dict:
    """Get graph statistics including SPO triple data."""
    graph = request.app.state.knowledge_graph
    return graph.get_stats()


@router.post("/build")
async def rebuild_graph(request: Request) -> dict:
    """Rebuild the knowledge graph from vault files."""
    graph = request.app.state.knowledge_graph
    edges = graph.build()
    return {"rebuilt": True, "edges": edges}


@router.post("/rebuild-registry")
async def rebuild_registry(request: Request) -> dict:
    """Rebuild the entity registry from scanned file frontmatter.

    Walks knowledge dirs, reads frontmatter from each markdown file, and
    populates the registry with entities (title + entity_type + aliases).
    Use this to recover after entities.json has been wiped or to backfill
    entities from existing wiki/agent/skill pages.
    """
    graph = request.app.state.knowledge_graph
    added = graph.rebuild_registry_from_files()
    # Rebuild the wikilink/SPO graph so the new entities canonicalize wikilinks
    edges = graph.build()
    return {
        "rebuilt": True,
        "entities_registered": added,
        "edges": edges,
        "total_entities": len(graph._registry.entities),
    }


@router.get("/entity/{entity}")
async def get_entity(request: Request, entity: str, depth: int = 2) -> list[dict]:
    """Get all entities connected to a given entity (wiki-link based)."""
    graph = request.app.state.knowledge_graph
    return graph.get_connected(entity, depth=depth)


@router.get("/entity/{entity}/triples")
async def get_entity_triples(request: Request, entity: str, depth: int = 2) -> dict:
    """Get structured knowledge about an entity (SPO triples + connections)."""
    graph = request.app.state.knowledge_graph
    result = graph.query_entity(entity, depth=depth)
    if result is None:
        return {"found": False, "message": f"Entity '{entity}' not found."}
    return {"found": True, **result}


@router.get("/path/{entity_a}/{entity_b}")
async def get_path(request: Request, entity_a: str, entity_b: str) -> dict:
    """Find the connection path between two entities."""
    graph = request.app.state.knowledge_graph
    path = graph.query_path(entity_a, entity_b)
    if path is None:
        return {"found": False, "message": f"No path between '{entity_a}' and '{entity_b}'."}
    return {"found": True, "path": path}


@router.get("/search")
async def search_entities(request: Request, q: str) -> list[dict]:
    """Search for entities by name (searches both wiki-links and SPO entities)."""
    graph = request.app.state.knowledge_graph
    return graph.search_entities(q)


class ExtractRequest(BaseModel):
    text: str
    source_file: str = ""
    authority: str = "system"


@router.post("/triples/extract")
async def extract_triples(request: Request, body: ExtractRequest) -> dict:
    """Extract SPO triples from text using LLM."""
    graph = request.app.state.knowledge_graph
    triples = await graph.extract_triples_llm(
        body.text,
        source_file=body.source_file,
        authority=body.authority,
    )
    return {"extracted": len(triples), "triples": triples}


@router.post("/decay/evaluate")
async def evaluate_decay(request: Request) -> dict:
    """Evaluate decay conditions on all entities and triples."""
    graph = request.app.state.knowledge_graph
    return graph.evaluate_decay()


@router.get("/contradictions")
async def get_contradictions(request: Request) -> dict:
    """Find all contradictions in the knowledge graph."""
    graph = request.app.state.knowledge_graph
    contradictions = graph.get_contradictions()
    return {"count": len(contradictions), "contradictions": contradictions}


@router.get("/ontology/predicates")
async def get_predicates(request: Request) -> list[dict]:
    """List all predicate definitions from the ontology."""
    from agntspace.memory.ontology import list_predicates
    return list_predicates()


@router.get("/ontology/entity-types")
async def get_entity_types(request: Request) -> list[dict]:
    """List all entity types from the ontology."""
    from agntspace.memory.ontology import EntityType
    return [{"value": t.value, "name": t.name} for t in EntityType]


@router.get("/ontology/fallbacks")
async def get_fallbacks(request: Request, min_count: int = 1) -> dict:
    """Get predicates that fell back to related_to — candidates for new definitions."""
    from agntspace.memory.ontology import get_fallback_report
    report = get_fallback_report(min_count)
    return {"fallbacks": report, "count": len(report)}


@router.post("/ontology/reload")
async def reload_ontology_endpoint(request: Request) -> dict:
    """Force-reload ontology from YAML after changes."""
    from agntspace.memory.ontology import reload_ontology
    graph = request.app.state.knowledge_graph
    skills_dir = graph._vault.vault_dir / "skills"
    result = reload_ontology(str(skills_dir) if skills_dir.exists() else None)
    return result


@router.get("/registry/stats")
async def registry_stats(request: Request) -> dict:
    """Get entity registry statistics."""
    graph = request.app.state.knowledge_graph
    return graph.registry.stats()


@router.get("/registry/search")
async def registry_search(request: Request, q: str, limit: int = 20) -> list[dict]:
    """Search the entity registry."""
    graph = request.app.state.knowledge_graph
    return graph.registry.search(q, limit=limit)


class MergeRequest(BaseModel):
    keep: str
    remove: str


@router.post("/registry/merge")
async def merge_entities(request: Request, body: MergeRequest) -> dict:
    """Merge two entities (keep one, absorb the other)."""
    graph = request.app.state.knowledge_graph
    # Resolve names to slugs
    keep_slug = graph.registry.resolve(body.keep)
    remove_slug = graph.registry.resolve(body.remove)
    if not keep_slug:
        return {"merged": False, "error": f"Entity '{body.keep}' not found"}
    if not remove_slug:
        return {"merged": False, "error": f"Entity '{body.remove}' not found"}

    # Use unified merge that also repoints triple references (Fix #8)
    result = graph.merge_entities(keep_slug, remove_slug)
    if not result["merged"]:
        return {"merged": False, "error": result.get("reason", "Merge failed")}

    return {"merged": True, "kept": body.keep, "removed": body.remove, "triples_updated": result["triples_repointed"]}


@router.get("/article-triples/{article_path:path}")
async def get_article_triples(request: Request, article_path: str) -> dict:
    """Get all triples that are expressed in a wiki article."""
    graph = request.app.state.knowledge_graph
    triples = graph.get_article_triples(article_path)
    return {"article": article_path, "triples": triples, "count": len(triples)}


@router.get("/triple/{triple_id}/articles")
async def get_triple_articles(request: Request, triple_id: int) -> dict:
    """Get all wiki articles that express a given triple."""
    graph = request.app.state.knowledge_graph
    articles = graph.get_triple_articles(triple_id)
    return {"triple_id": triple_id, "articles": articles, "count": len(articles)}


@router.get("/entity/{entity}/at/{date}")
async def get_entity_at_date(request: Request, entity: str, date: str) -> dict:
    """Query what was known about an entity at a specific point in time."""
    graph = request.app.state.knowledge_graph
    result = graph.query_entity_at(entity, date)
    if result is None:
        return {"found": False, "message": f"No data for '{entity}' at {date}"}
    return {"found": True, **result}


@router.get("/stale-articles")
async def get_stale_articles(request: Request) -> dict:
    """Find wiki articles that may contain outdated information."""
    graph = request.app.state.knowledge_graph
    stale = graph.get_stale_articles()
    return {"stale_articles": stale, "count": len(stale)}


@router.post("/propagate/{triple_id}")
async def propagate_change(request: Request, triple_id: int) -> dict:
    """Find articles affected by a change to a triple."""
    graph = request.app.state.knowledge_graph
    return graph.propagate_change(triple_id)
