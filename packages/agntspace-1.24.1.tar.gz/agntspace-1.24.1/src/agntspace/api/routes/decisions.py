"""Decision log API — queryable "why" behind every agent action."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/decisions", tags=["decisions"])


@router.get("")
async def list_decisions(
    request: Request,
    actor: str | None = None,
    action_type: str | None = None,
    goal_id: str | None = None,
    since: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict:
    """Return decision records newest-first, filterable by actor/action/goal/time."""
    decisions = getattr(request.app.state, "decisions", None)
    if decisions is None:
        return {"items": [], "total": 0}
    items = await decisions.query(
        actor=actor,
        action_type=action_type,
        goal_id=goal_id,
        since=since,
        limit=limit,
        offset=offset,
    )
    return {"items": items, "total": len(items)}


@router.get("/stats")
async def decision_stats(request: Request) -> dict:
    """Aggregate stats: total, by actor, by action type, blocked count."""
    decisions = getattr(request.app.state, "decisions", None)
    if decisions is None:
        return {"total": 0, "by_actor": {}, "by_action_type": {}, "blocked": 0}
    return await decisions.stats()


@router.get("/health")
async def decision_health(request: Request) -> dict:
    """Meta-monitoring (gap #10): attempts, failures, last error, retention state.

    Lets a caller verify the observability layer itself is healthy. If
    `failure_rate` starts climbing, the silent except-pass in record() is
    losing data — check `last_error` for the cause.
    """
    decisions = getattr(request.app.state, "decisions", None)
    if decisions is None:
        return {"status": "unavailable"}
    return decisions.health()


@router.post("/prune")
async def decision_prune(request: Request) -> dict:
    """Apply the retention policy now (usually scheduled, but callable on demand)."""
    decisions = getattr(request.app.state, "decisions", None)
    if decisions is None:
        return {"by_age": 0, "by_count": 0, "total_pruned": 0}
    return await decisions.prune()


class _RetentionConfig(BaseModel):
    max_rows: int | None = None
    max_age_days: int | None = None


@router.put("/retention")
async def update_retention(request: Request, body: _RetentionConfig) -> dict:
    """Update the retention policy at runtime.

    Sent from the admin UI — does not persist across restart (retention
    defaults live in the DecisionLogger constructor). For permanent
    changes, edit main.py or ship a config override.
    """
    decisions = getattr(request.app.state, "decisions", None)
    if decisions is None:
        return {"ok": False, "reason": "DecisionLogger unavailable"}
    if body.max_rows is not None and body.max_rows > 0:
        decisions._max_rows = int(body.max_rows)  # noqa: SLF001
    if body.max_age_days is not None and body.max_age_days > 0:
        decisions._max_age_days = int(body.max_age_days)  # noqa: SLF001
    return {
        "ok": True,
        "max_rows": decisions._max_rows,  # noqa: SLF001
        "max_age_days": decisions._max_age_days,  # noqa: SLF001
    }
