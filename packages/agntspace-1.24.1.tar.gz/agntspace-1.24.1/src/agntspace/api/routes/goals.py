"""Goals and coaching API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/goals", tags=["goals"])


class GoalCreateRequest(BaseModel):
    title: str
    description: str
    goal_type: str = "goal"
    target_date: str = ""
    success_metric: str = ""
    budget: float = 0.0
    max_attempts: int = 20
    domain: str = "general"


class GoalStatusRequest(BaseModel):
    status: str


class GoalUpdateRequest(BaseModel):
    description: str | None = None
    target_date: str | None = None


class GoalRenameRequest(BaseModel):
    title: str


class GoalPursuitUpdateRequest(BaseModel):
    success_metric: str | None = None
    budget: float | None = None
    max_dispatches: int | None = None
    max_attempts: int | None = None


class TrustOverrideRequest(BaseModel):
    enabled: bool


class DomainUpdateRequest(BaseModel):
    domain: str


@router.get("")
async def list_goals(request: Request, status: str | None = None) -> list[dict]:
    """List all goals."""
    coach = request.app.state.coach
    return coach.list_goals(status_filter=status)


@router.post("")
async def create_goal(request: Request, body: GoalCreateRequest) -> dict:
    """Create a new goal."""
    coach = request.app.state.coach
    path = coach.create_goal(
        title=body.title,
        description=body.description,
        goal_type=body.goal_type,
        target_date=body.target_date,
        success_metric=body.success_metric,
        budget=body.budget,
        max_attempts=body.max_attempts,
        domain=body.domain,
    )
    return {"path": path, "status": "active"}


@router.get("/progress-summary")
async def get_progress_summary(request: Request) -> dict:
    """Aggregated progress summary for the dashboard card."""
    coach = request.app.state.coach
    task_svc = request.app.state.task_service
    project_svc = request.app.state.project_service

    goals = coach.list_goals()
    tasks = task_svc.list_tasks()
    projects = project_svc.list_projects()

    active_goals = [g for g in goals if g.get("status") == "active"]
    achieved_goals = [g for g in goals if g.get("status") == "achieved"]

    from agntspace.infra.config import get_settings
    try:
        llm_mode = get_settings().llm.mode
    except Exception:
        llm_mode = "cloud"

    pursuing = []
    for g in active_goals:
        try:
            ps = coach.get_pursuit_status(g["slug"])
            if ps.get("pursuit_status") == "pursuing":
                pursuing.append({
                    "slug": g["slug"],
                    "title": g["title"],
                    "budget": ps.get("budget", 0),
                    "budget_consumed": ps.get("budget_consumed", 0),
                    "dispatches": ps.get("dispatches", 0),
                    "max_dispatches": ps.get("max_dispatches", 50),
                    "success_metric": ps.get("success_metric", ""),
                })
        except Exception:
            pass

    tasks_done = len([t for t in tasks if t.get("status") == "done"])
    tasks_active = len([t for t in tasks if t.get("status") in ("in_progress", "delegated")])
    tasks_blocked = len([t for t in tasks if t.get("status") == "blocked"])

    stalls = []
    try:
        stalls = coach.detect_stalls()
    except Exception:
        pass

    halted = []
    try:
        halted = coach.list_halted_goals(max_age_hours=6)
    except Exception:
        pass

    return {
        "goals_total": len(goals),
        "goals_active": len(active_goals),
        "goals_achieved": len(achieved_goals),
        "goals_pursuing": pursuing,
        "goals_stalled": [{"slug": s["slug"], "title": s["goal"], "days": s["days_inactive"]} for s in stalls],
        "goals_halted": halted,
        "tasks_total": len(tasks),
        "tasks_done": tasks_done,
        "tasks_active": tasks_active,
        "tasks_blocked": tasks_blocked,
        "projects_active": len([p for p in projects if p.get("status") == "active"]),
        "llm_mode": llm_mode,
    }


@router.get("/halted")
async def list_halted_goals(request: Request, hours: int = 6) -> list[dict]:
    """Return goals in ``pursuing`` status whose last_block_at is within
    ``hours``. Feeds the dashboard chip + goal-modal halted banner."""
    coach = request.app.state.coach
    try:
        return coach.list_halted_goals(max_age_hours=hours)
    except Exception:
        return []


@router.get("/nudges")
async def get_nudges(request: Request) -> list[str]:
    """Get coaching nudges for stalled goals and deadlines."""
    coach = request.app.state.coach
    return coach.generate_nudges()


@router.get("/stalls")
async def get_stalls(request: Request) -> list[dict]:
    """Detect stalled goals."""
    coach = request.app.state.coach
    return coach.detect_stalls()


@router.get("/{slug}")
async def get_goal(request: Request, slug: str) -> dict:
    """Get a single goal."""
    coach = request.app.state.coach
    goal = coach.get_goal(slug)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    return goal


@router.put("/{slug}")
async def update_goal(request: Request, slug: str, body: GoalUpdateRequest) -> dict:
    """Update a goal's description and/or target date."""
    coach = request.app.state.coach
    try:
        coach.update_goal(
            slug=slug,
            description=body.description,
            target_date=body.target_date,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": "updated"}


@router.post("/{slug}/rename")
async def rename_goal(request: Request, slug: str, body: GoalRenameRequest) -> dict:
    """Rename a goal: rewrite title, move file, update project references."""
    coach = request.app.state.coach
    try:
        result = coach.rename_goal(slug, body.title)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity and result["slug"] != slug:
        activity.log(
            category="user_override",
            action="goal_renamed",
            summary=f"User renamed goal '{slug}' → '{result['slug']}' ('{body.title}')",
            details={"old_slug": slug, "new_slug": result["slug"], "projects_updated": result.get("projects_updated", 0)},
            importance="medium",
        )
    return {"slug": result["slug"], "projects_updated": result.get("projects_updated", 0)}


@router.patch("/{slug}/status")
async def update_goal_status(
    request: Request, slug: str, body: GoalStatusRequest
) -> dict:
    """Update a goal's status."""
    coach = request.app.state.coach
    try:
        coach.update_goal_status(slug, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}


@router.get("/{slug}/projects")
async def list_goal_projects(request: Request, slug: str) -> list[dict]:
    """Reverse lookup: list projects whose related_goals contains this goal."""
    project_svc = request.app.state.project_service
    projects = project_svc.list_projects()
    return [p for p in projects if slug in (p.get("related_goals") or [])]


@router.post("/{slug}/projects/{project_slug}")
async def attach_goal_to_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Attach this goal to a project (adds to project.related_goals)."""
    # The goal route authorizes create_task, but updating a project file
    # needs modify_project. Mark it authorized for this cross-entity write.
    try:
        from agntspace.activity.decisions import mark_action_authorized
        mark_action_authorized("modify_project")
    except Exception:
        pass

    coach = request.app.state.coach
    if not coach.get_goal(slug):
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug in goals:
        return {"slug": slug, "project": project_slug, "status": "already_linked"}
    goals.append(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_attached_to_project",
            summary=f"User linked goal '{slug}' to project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "attached"}


@router.delete("/{slug}/projects/{project_slug}")
async def detach_goal_from_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Detach this goal from a project (removes from project.related_goals)."""
    try:
        from agntspace.activity.decisions import mark_action_authorized
        mark_action_authorized("modify_project")
    except Exception:
        pass

    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug not in goals:
        return {"slug": slug, "project": project_slug, "status": "not_linked"}
    goals.remove(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_detached_from_project",
            summary=f"User unlinked goal '{slug}' from project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "detached"}


@router.get("/{slug}/pursuit")
async def get_pursuit_status(request: Request, slug: str) -> dict:
    """Get pursuit tracking status for a goal.

    Includes ``llm_mode`` so the UI can show mode-appropriate budget info:
    - cloud: dollar budget is meaningful, show $/$ progress bar
    - local: cost is always $0, show dispatch N/M progress bar instead

    Also enriches with trust info for the goal's domain so the UI can show
    the halted banner + path-to-next-level without a second round trip.
    """
    coach = request.app.state.coach
    try:
        status = coach.get_pursuit_status(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    from agntspace.infra.config import get_settings
    try:
        llm_mode = get_settings().llm.mode
    except Exception:
        llm_mode = "cloud"
    status["llm_mode"] = llm_mode

    # Enrich with trust snapshot for the goal's domain
    trust_svc = getattr(request.app.state, "trust_service", None)
    contract = getattr(request.app.state, "contract", None)
    proactivity = contract.rules.proactivity if contract else "advisor"
    status["proactivity"] = proactivity
    if trust_svc:
        try:
            check = trust_svc.check_tool_trust(
                "create_task", proactivity, is_autonomous=True,
            )
            explain = trust_svc.explain_domain(status.get("domain", "general"))
            status["trust"] = {
                "effective_level": check.effective_level,
                "domain_trust": check.domain_trust,
                "effective_score": getattr(check, "effective_score", None),
                "path_to_next_level": explain.get("path_to_next_level", {}),
            }
        except Exception:
            status["trust"] = None
    else:
        status["trust"] = None

    # Attach heartbeat next-tick ETA so the UI can show "Next check in N min"
    # instead of leaving the user guessing why an unblocked pursuit isn't
    # happening. The heartbeat interval (900s by default) is the only reason
    # a gate-passing goal hasn't dispatched yet.
    hb = getattr(request.app.state, "heartbeat", None)
    if hb:
        try:
            hb_status = await hb.get_status()
            last_pulse = hb_status.get("last_pulse") or {}
            last_ts = last_pulse.get("ts") if isinstance(last_pulse, dict) else None
            interval = hb_status.get("interval_seconds", 900)
            if last_ts:
                from datetime import datetime as _dt
                try:
                    last_dt = _dt.fromisoformat(last_ts.replace("Z", "+00:00"))
                    from datetime import timedelta as _td
                    next_dt = last_dt + _td(seconds=interval)
                    status["heartbeat"] = {
                        "last_pulse_at": last_ts,
                        "next_pulse_at": next_dt.isoformat(),
                        "interval_seconds": interval,
                    }
                except (ValueError, TypeError):
                    status["heartbeat"] = {
                        "last_pulse_at": last_ts,
                        "next_pulse_at": None,
                        "interval_seconds": interval,
                    }
            else:
                status["heartbeat"] = {
                    "last_pulse_at": None,
                    "next_pulse_at": None,
                    "interval_seconds": interval,
                }
        except Exception:
            status["heartbeat"] = None
    else:
        status["heartbeat"] = None
    return status


@router.post("/{slug}/pursuit/start")
async def start_pursuit(request: Request, slug: str) -> dict:
    """Start autonomous pursuit of a goal."""
    coach = request.app.state.coach
    try:
        coach.set_pursuit_status(slug, "pursuing")
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "pursuit_status": "pursuing"}


@router.post("/{slug}/pursuit/pause")
async def pause_pursuit(request: Request, slug: str) -> dict:
    """Pause autonomous pursuit of a goal."""
    coach = request.app.state.coach
    try:
        coach.set_pursuit_status(slug, "paused", reason="User paused")
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "pursuit_status": "paused"}


@router.post("/{slug}/pursuit/dispatch-now")
async def dispatch_pursuit_now(request: Request, slug: str) -> dict:
    """Enqueue an immediate pursuit job instead of waiting for the next
    15-minute heartbeat tick.

    Runs the same gate checks the heartbeat would (trust unless
    ``trust_override``, dispatch cap, cloud-only budget) so we don't
    bypass the safety rails. On success, enqueues the same ``pursue_goal``
    job the heartbeat uses — the work queue handler is the single
    execution path.
    """
    coach = request.app.state.coach
    work_queue = getattr(request.app.state, "work_queue", None)
    if not work_queue:
        raise HTTPException(status_code=503, detail="Work queue not available")

    try:
        status = coach.get_pursuit_status(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    if status.get("pursuit_status") != "pursuing":
        raise HTTPException(
            status_code=400,
            detail=f"Goal is not pursuing (status: {status.get('pursuit_status')})",
        )

    live = status.get("live_block")
    if live:
        raise HTTPException(
            status_code=409,
            detail={
                "message": "Goal is blocked — resolve the block before dispatching",
                "reason": live["reason"],
                "details": live["details"],
            },
        )

    goal = coach.get_goal(slug)
    budget = status["budget"]
    consumed = status["budget_consumed"]
    dispatches = status["dispatches"]
    max_dispatches = status["max_dispatches"]
    llm_mode = getattr(coach, "_llm_mode", None) or "local"
    local_mode = llm_mode == "local"

    try:
        job_id = await work_queue.enqueue(
            "pursue_goal",
            {
                "goal_slug": slug,
                "goal_title": goal.get("title", slug) if goal else slug,
                "goal_metric": status.get("success_metric", ""),
                "budget_remaining": budget - consumed,
                "dispatch_number": dispatches + 1,
                "max_dispatches": max_dispatches,
                "local_mode": local_mode,
            },
            deduplicate=True,
        )
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=500, detail=f"Failed to enqueue: {exc}") from exc

    if not job_id:
        # Deduplicated — same job already pending
        return {"slug": slug, "dispatched": False, "reason": "already_queued"}

    # Clear any stale recorded block; live_block is already None (checked above)
    try:
        coach.clear_block(slug)
    except Exception:
        pass  # best-effort — don't fail the dispatch on a clear error

    return {"slug": slug, "dispatched": True, "job_id": job_id}


@router.post("/{slug}/pursuit/raise-trust")
async def raise_trust_for_goal(request: Request, slug: str) -> dict:
    """Grant positive trust signals in this goal's domain to cross the
    Assistant threshold.

    The number of signals needed comes from ``explain_domain.path_to_next_level``
    — we grant exactly that many (capped at 10 to avoid runaway jumps) so the
    user sees an immediate promotion without over-vouching. Also clears any
    recorded block so the goal resumes on the next heartbeat tick.
    """
    coach = request.app.state.coach
    trust_svc = getattr(request.app.state, "trust_service", None)
    if not trust_svc:
        raise HTTPException(status_code=503, detail="Trust service not available")

    try:
        status = coach.get_pursuit_status(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    domain = status.get("domain", "general")
    explain = trust_svc.explain_domain(domain)
    needed = int(explain.get("path_to_next_level", {}).get("signals_needed", 0) or 0)
    signals = max(1, min(needed, 10))

    last = None
    for _ in range(signals):
        last = trust_svc.record_feedback(domain, "good")

    try:
        coach.clear_block(slug)
    except Exception:
        pass

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_trust_raised",
            summary=f"User raised trust in '{domain}' by {signals} signal(s) to unblock goal '{slug}'",
            details={
                "goal_slug": slug,
                "domain": domain,
                "signals_granted": signals,
                "new_level": (last or {}).get("new_level"),
                "new_score": (last or {}).get("score"),
            },
            importance="high",
        )
    return {
        "slug": slug,
        "domain": domain,
        "signals_granted": signals,
        "new_level": (last or {}).get("new_level"),
        "new_score": (last or {}).get("score"),
        "effective_score": (last or {}).get("effective_score"),
    }


@router.post("/{slug}/pursuit/override")
async def set_goal_trust_override(
    request: Request, slug: str, body: TrustOverrideRequest,
) -> dict:
    """Toggle the per-goal trust-gate bypass.

    When ``enabled=True``, the heartbeat skips the trust check for this goal
    (dispatch cap + budget are still enforced). Lets the user say "I've
    explicitly approved this one, just run it."
    """
    coach = request.app.state.coach
    try:
        new_value = coach.set_trust_override(slug, body.enabled)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    if body.enabled:
        try:
            coach.clear_block(slug)
        except Exception:
            pass

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_trust_override_set" if body.enabled else "goal_trust_override_cleared",
            summary=f"User {'enabled' if body.enabled else 'disabled'} trust override for goal '{slug}'",
            details={"goal_slug": slug, "trust_override": new_value},
            importance="high",
        )
    return {"slug": slug, "trust_override": new_value}


@router.patch("/{slug}/pursuit/domain")
async def set_goal_domain(
    request: Request, slug: str, body: DomainUpdateRequest,
) -> dict:
    """Change which trust domain gates this goal's pursuit."""
    coach = request.app.state.coach
    try:
        new_domain = coach.set_domain(slug, body.domain)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        coach.clear_block(slug)
    except Exception:
        pass

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user",
            action="goal_domain_changed",
            summary=f"User changed goal '{slug}' domain to '{new_domain}'",
            details={"goal_slug": slug, "domain": new_domain},
            importance="medium",
        )
    return {"slug": slug, "domain": new_domain}


@router.post("/{slug}/pursuit/reset")
async def reset_pursuit(request: Request, slug: str) -> dict:
    """Reset pursuit counters (dispatches, cost, failures) so the goal can be re-pursued.

    Keeps the budget, metric, and max_dispatches config intact.
    Appends a RESET marker to the pursuit log.
    """
    coach = request.app.state.coach
    try:
        result = coach.reset_pursuit(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_pursuit_reset",
            summary=f"User reset pursuit of goal '{slug}' "
                    f"(was: {result['reset']['old_dispatches']} dispatches, "
                    f"${result['reset']['old_budget_consumed']:.2f} spent)",
            details=result,
            importance="medium",
        )
    return result


@router.patch("/{slug}/pursuit")
async def update_pursuit_config(request: Request, slug: str, body: GoalPursuitUpdateRequest) -> dict:
    """Update pursuit configuration (metric, budget, max_attempts)."""
    import re as _re

    path = f"goals/{slug}.md"
    reader = request.app.state.vault
    if not reader.exists(path):
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")

    doc = reader.read(path)
    content = doc.raw
    writer = request.app.state.writer

    if body.success_metric is not None:
        content = _re.sub(
            r'^success_metric:\s*".*"', f'success_metric: "{body.success_metric}"',
            content, count=1, flags=_re.MULTILINE,
        )
    if body.budget is not None:
        content = _re.sub(
            r"^budget:\s*[\d.]+", f"budget: {body.budget}",
            content, count=1, flags=_re.MULTILINE,
        )
    if body.max_dispatches is not None:
        if _re.search(r"^max_dispatches:", content, flags=_re.MULTILINE):
            content = _re.sub(
                r"^max_dispatches:\s*\d+", f"max_dispatches: {body.max_dispatches}",
                content, count=1, flags=_re.MULTILINE,
            )
        else:
            # Backfill for goals created before max_dispatches existed
            content = _re.sub(
                r"^(dispatches:\s*\d+)", rf"\1\nmax_dispatches: {body.max_dispatches}",
                content, count=1, flags=_re.MULTILINE,
            )
    if body.max_attempts is not None:
        content = _re.sub(
            r"^max_attempts:\s*\d+", f"max_attempts: {body.max_attempts}",
            content, count=1, flags=_re.MULTILINE,
        )

    writer.write(path, content, contract_action="create_task")
    return {"slug": slug, "status": "updated"}


@router.delete("/{slug}")
async def delete_goal(request: Request, slug: str) -> dict:
    """Delete a goal and clean up project references."""
    coach = request.app.state.coach
    try:
        result = coach.delete_goal(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user",
            action="goal_deleted",
            summary=f"User deleted goal '{slug}' (cleaned {result['projects_cleaned']} project refs)",
            details=result,
            importance="medium",
        )
    return result


@router.get("/{slug}/history")
async def get_goal_history(
    request: Request, slug: str, limit: int = 100,
) -> dict:
    """Unified pursuit history — decisions, dispatches, costs, and progress log.

    Aggregates data from four sources into a single timeline:
    1. Decision log (filtered by goal_id)
    2. Dispatch log (filtered by goal_id)
    3. Cost log (per-goal breakdown)
    4. Pursuit log from the goal file itself
    """
    coach = request.app.state.coach
    try:
        status = coach.get_pursuit_status(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # 1. Decisions for this goal
    decisions_logger = getattr(request.app.state, "decisions", None)
    decisions = []
    if decisions_logger:
        try:
            decisions = await decisions_logger.query(goal_id=slug, limit=limit)
        except Exception:
            pass

    # 2. Dispatches for this goal
    orchestrator = getattr(request.app.state, "orchestrator", None)
    dispatches = []
    if orchestrator:
        try:
            dispatches = await orchestrator.get_dispatch_log(goal_id=slug, limit=limit)
        except Exception:
            pass

    # 3. Cost breakdown for this goal
    cost_tracker = getattr(request.app.state, "cost_tracker", None)
    cost_summary = {"total": 0.0, "entries": []}
    if cost_tracker:
        try:
            cost_summary["total"] = await cost_tracker.get_goal_cost(slug)
            cost_summary["entries"] = await cost_tracker.get_goal_cost_breakdown(slug, limit=limit)
        except Exception:
            pass

    # 4. Pursuit log from the goal file
    pursuit_log: list[str] = []
    try:
        reader = request.app.state.vault
        doc = reader.read(f"goals/{slug}.md")
        content = doc.content if hasattr(doc, "content") else ""
        if "## Pursuit Log" in content:
            log_section = content.split("## Pursuit Log", 1)[1]
            # Stop at next ## heading or end of file
            if "\n## " in log_section:
                log_section = log_section.split("\n## ", 1)[0]
            pursuit_log = [
                line.strip().lstrip("- ")
                for line in log_section.strip().split("\n")
                if line.strip().startswith("- ")
            ]
    except Exception:
        pass

    # Build unified timeline — merge all sources sorted by timestamp
    timeline: list[dict] = []

    for d in decisions:
        timeline.append({
            "type": "decision",
            "timestamp": d.get("timestamp", ""),
            "actor": d.get("actor", ""),
            "action": d.get("action_type", ""),
            "target": d.get("action_target", ""),
            "rationale": d.get("rationale", ""),
            "contract_result": d.get("contract_result", ""),
            "skills": d.get("context_skills", []),
            "correlation_id": d.get("correlation_id", ""),
        })

    for d in dispatches:
        timeline.append({
            "type": "dispatch",
            "timestamp": d.get("started_at", ""),
            "actor": d.get("agent_key", ""),
            "agent_name": d.get("agent_name", ""),
            "task": (d.get("task", "") or "")[:200],
            "content": (d.get("content", "") or "")[:200],
            "input_tokens": d.get("input_tokens", 0),
            "output_tokens": d.get("output_tokens", 0),
            "duration_ms": d.get("duration_ms", 0),
        })

    for entry in cost_summary.get("entries", []):
        timeline.append({
            "type": "cost",
            "timestamp": entry.get("timestamp", ""),
            "model": entry.get("model", ""),
            "input_tokens": entry.get("input_tokens", 0),
            "output_tokens": entry.get("output_tokens", 0),
            "cost": entry.get("estimated_cost", 0),
            "action": entry.get("action", ""),
        })

    # Sort timeline newest-first
    timeline.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    timeline = timeline[:limit]

    from agntspace.infra.config import get_settings
    try:
        llm_mode = get_settings().llm.mode
    except Exception:
        llm_mode = "cloud"

    return {
        "slug": slug,
        "pursuit_status": status,
        "cost_total": cost_summary["total"],
        "llm_mode": llm_mode,
        "pursuit_log": pursuit_log,
        "timeline": timeline,
        "counts": {
            "decisions": len(decisions),
            "dispatches": len(dispatches),
            "cost_entries": len(cost_summary.get("entries", [])),
        },
    }
