"""MCP API — manage MCP server and external connections."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/mcp", tags=["mcp"])


class MCPServerConfig(BaseModel):
    name: str
    command: str
    args: list[str] = []
    env: dict[str, str] = {}
    auto_connect: bool = True


@router.get("/status")
async def mcp_status(request: Request) -> dict:
    """Get MCP server status and connected external servers."""
    mcp_client = request.app.state.mcp_client
    return {
        "server": "running",
        "external_servers": mcp_client.list_servers(),
        "external_tools": len(mcp_client.get_external_tool_definitions()),
    }


@router.post("/servers/add")
async def add_server(request: Request, body: MCPServerConfig) -> dict:
    """Register an external MCP server."""
    from agntspace.mcp.client import ExternalMCPServer

    mcp_client = request.app.state.mcp_client
    mcp_client.register_server(ExternalMCPServer(
        name=body.name, command=body.command,
        args=body.args, env=body.env,
        auto_connect=body.auto_connect,
    ))
    return {"registered": True, "name": body.name}


@router.post("/servers/{name}/connect")
async def connect_server(request: Request, name: str) -> dict:
    """Connect to an external MCP server."""
    mcp_client = request.app.state.mcp_client
    try:
        tools = await mcp_client.connect_server(name)
        return {"connected": True, "tools": len(tools), "tool_names": [t["name"] for t in tools]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/servers/{name}/disconnect")
async def disconnect_server(request: Request, name: str) -> dict:
    """Disconnect from an external MCP server."""
    mcp_client = request.app.state.mcp_client
    ok = await mcp_client.disconnect_server(name)
    return {"disconnected": ok, "name": name}


@router.delete("/servers/{name}")
async def remove_server(request: Request, name: str) -> dict:
    """Remove an external MCP server configuration."""
    mcp_client = request.app.state.mcp_client
    ok = mcp_client.remove_server(name)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Server '{name}' not found")
    return {"removed": True, "name": name}


@router.get("/tools")
async def list_external_tools(request: Request) -> list[dict]:
    """List tools from all connected external MCP servers."""
    mcp_client = request.app.state.mcp_client
    return [
        {"name": t["name"], "description": t.get("description", ""), "server": t.get("_mcp_server", "")}
        for t in mcp_client.get_external_tool_definitions()
    ]
