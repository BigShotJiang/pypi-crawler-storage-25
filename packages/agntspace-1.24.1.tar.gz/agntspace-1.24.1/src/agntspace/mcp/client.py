"""MCP Client — connects to external MCP servers.

Allows AgntSpace to use tools from external MCP servers
(databases, APIs, file systems, custom tools).
External tools appear in the agent's tool list alongside
built-in tools, all contract-enforced.
"""

from __future__ import annotations

import json
import logging
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

log = logging.getLogger(__name__)


@dataclass
class ExternalMCPServer:
    """Configuration for an external MCP server."""

    name: str
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    auto_connect: bool = True


class MCPClientManager:
    """Manages connections to external MCP servers."""

    def __init__(self, config_path: Path | None = None) -> None:
        self._servers: dict[str, ExternalMCPServer] = {}
        self._sessions: dict[str, ClientSession] = {}
        self._transports: dict[str, object] = {}  # keep transport refs alive
        self._external_tools: dict[str, dict] = {}
        self._config_path = config_path

    # ---- Config persistence ----

    def _save_config(self) -> None:
        """Persist server configs to JSON file."""
        if not self._config_path:
            return
        data = {
            name: {
                "command": s.command,
                "args": s.args,
                "env": s.env,
                "auto_connect": s.auto_connect,
            }
            for name, s in self._servers.items()
        }
        self._config_path.parent.mkdir(parents=True, exist_ok=True)
        self._config_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load_config(self) -> None:
        """Load server configs from JSON file."""
        if not self._config_path or not self._config_path.exists():
            return
        try:
            data = json.loads(self._config_path.read_text(encoding="utf-8"))
            for name, cfg in data.items():
                self._servers[name] = ExternalMCPServer(
                    name=name,
                    command=cfg["command"],
                    args=cfg.get("args", []),
                    env=cfg.get("env", {}),
                    auto_connect=cfg.get("auto_connect", True),
                )
            log.debug("Loaded %d MCP server configs", len(data))
        except Exception:
            log.warning("Failed to load MCP config", exc_info=True)

    async def auto_connect_all(self) -> None:
        """Connect to all servers marked auto_connect."""
        import os
        import sys

        for name, server in self._servers.items():
            if server.auto_connect:
                # Suppress MCP subprocess banner noise during startup
                old_stderr, old_stdout = sys.stderr, sys.stdout
                with open(os.devnull, "w") as devnull:  # noqa: SIM115
                    try:
                        sys.stderr = sys.stdout = devnull
                        await self.connect_server(name)
                    except Exception:
                        pass  # non-critical — server will work without MCP
                    finally:
                        sys.stderr, sys.stdout = old_stderr, old_stdout

    # ---- Server management ----

    def register_server(self, server: ExternalMCPServer) -> None:
        """Register an external MCP server configuration."""
        self._servers[server.name] = server
        self._save_config()
        log.info("MCP server registered: %s (%s)", server.name, server.command)

    def remove_server(self, name: str) -> bool:
        """Remove a server config (disconnects first if needed)."""
        if name not in self._servers:
            return False
        # Clean up connection if active
        if name in self._sessions:
            # Best-effort cleanup — will be fully cleaned in disconnect
            self._sessions.pop(name, None)
            self._transports.pop(name, None)
        # Remove tools from this server
        to_remove = [k for k, v in self._external_tools.items() if v.get("_mcp_server") == name]
        for k in to_remove:
            del self._external_tools[k]
        del self._servers[name]
        self._save_config()
        log.info("MCP server removed: %s", name)
        return True

    async def connect_server(self, name: str) -> list[dict]:
        """Connect to an external MCP server and discover its tools."""
        server = self._servers.get(name)
        if not server:
            raise ValueError(f"Unknown MCP server: {name}")

        # Disconnect existing session if reconnecting
        if name in self._sessions:
            await self.disconnect_server(name)

        # Merge env with current environment so the subprocess inherits PATH etc.
        import os

        merged_env = {**os.environ, **(server.env or {})}
        params = StdioServerParameters(
            command=server.command,
            args=server.args,
            env=merged_env,
        )

        transport = None
        session = None
        self._devnull = open(os.devnull, "w")  # noqa: SIM115
        try:
            transport = stdio_client(params, errlog=self._devnull)
            read, write = await transport.__aenter__()
            session = ClientSession(read, write)
            await session.__aenter__()
            await session.initialize()
        except Exception:
            # Clean up partial state on connection failure
            if session:
                with suppress(Exception):
                    await session.__aexit__(None, None, None)
            if transport and hasattr(transport, "__aexit__"):
                with suppress(Exception):
                    await transport.__aexit__(None, None, None)
            log.exception("MCP connection failed for '%s'", name)
            raise

        self._sessions[name] = session
        self._transports[name] = transport  # prevent GC

        # Discover tools
        try:
            tools_result = await session.list_tools()
        except Exception:
            log.exception("MCP tool discovery failed for '%s'", name)
            await self.disconnect_server(name)
            raise

        tools = []
        for tool in tools_result.tools:
            tool_def = {
                "name": f"mcp_{name}_{tool.name}",
                "description": f"[{name}] {tool.description or ''}",
                "input_schema": tool.inputSchema if hasattr(tool, "inputSchema") else {"type": "object", "properties": {}},
                "_mcp_server": name,
                "_mcp_tool": tool.name,
            }
            tools.append(tool_def)
            self._external_tools[tool_def["name"]] = tool_def

        log.debug("Connected to MCP server '%s': %d tools discovered", name, len(tools))
        return tools

    async def disconnect_server(self, name: str) -> bool:
        """Disconnect a single MCP server."""
        session = self._sessions.pop(name, None)
        transport = self._transports.pop(name, None)
        if session:
            try:
                await session.__aexit__(None, None, None)
            except Exception:
                pass
        if transport and hasattr(transport, "__aexit__"):
            try:
                await transport.__aexit__(None, None, None)
            except Exception:
                pass
        # Remove tools from this server
        to_remove = [k for k, v in self._external_tools.items() if v.get("_mcp_server") == name]
        for k in to_remove:
            del self._external_tools[k]
        log.debug("Disconnected MCP server: %s", name)
        return True

    async def call_tool(self, tool_name: str, arguments: dict) -> dict:
        """Call a tool on an external MCP server."""
        tool_def = self._external_tools.get(tool_name)
        if not tool_def:
            return {"error": f"Unknown MCP tool: {tool_name}"}

        server_name = tool_def["_mcp_server"]
        real_tool_name = tool_def["_mcp_tool"]
        session = self._sessions.get(server_name)

        if not session:
            return {"error": f"MCP server '{server_name}' not connected"}

        try:
            result = await session.call_tool(real_tool_name, arguments)
            text_parts = []
            for content in result.content:
                if hasattr(content, "text"):
                    text_parts.append(content.text)
            return {"result": "\n".join(text_parts)}
        except Exception as e:
            return {"error": str(e)}

    def get_external_tool_definitions(self) -> list[dict]:
        """Get all external tool definitions for the agent."""
        return list(self._external_tools.values())

    def list_servers(self) -> list[dict]:
        """List registered MCP servers and their connection status."""
        return [
            {
                "name": name,
                "command": server.command,
                "args": server.args,
                "connected": name in self._sessions,
                "auto_connect": server.auto_connect,
                "tools": len([
                    t for t in self._external_tools.values()
                    if t.get("_mcp_server") == name
                ]),
            }
            for name, server in self._servers.items()
        ]

    async def disconnect_all(self) -> None:
        """Disconnect from all MCP servers."""
        for name in list(self._sessions.keys()):
            await self.disconnect_server(name)
