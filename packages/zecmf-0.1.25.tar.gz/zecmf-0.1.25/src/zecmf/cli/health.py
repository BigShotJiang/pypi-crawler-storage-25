"""Health check CLI commands."""

import click
from flask.cli import with_appcontext
from sqlalchemy import text

from zecmf.extensions.database import db


def health_check_impl() -> None:
    """Implement health check logic.

    Verifies that critical application dependencies are operational:
    - Database connection
    """
    click.echo("Checking application health...")

    # Check database connection
    try:
        # Use text() to wrap SQL string for proper typing
        db.session.execute(text("SELECT 1"))
        click.echo("Database connection: OK")
    except Exception as e:
        click.echo(f"Database connection: FAILED ({e!s})")
        return

    click.echo("All systems operational!")


@click.command("health-check")
@with_appcontext
def health_check() -> None:
    """Check the health of the application and its dependencies."""
    health_check_impl()
