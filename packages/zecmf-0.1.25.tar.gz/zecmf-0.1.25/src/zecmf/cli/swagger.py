"""Swagger/OpenAPI extraction CLI commands."""

import json
from pathlib import Path

import click
from flask import current_app
from flask.cli import with_appcontext


def extract_swagger_impl(output: str, pretty: bool) -> None:
    """Implement swagger extraction logic.

    Extracts the OpenAPI/Swagger specification from the Flask-RESTX API
    instance and writes it to a file.

    Args:
        output: Output file path for swagger.json
        pretty: Whether to format the JSON output with indentation

    """
    click.echo("Extracting swagger.json from current application...")

    # Access the API instance directly from Flask extensions
    # ZecMF stores the Flask-RESTX Api instance in app.extensions
    api = current_app.extensions.get("restx/api")

    if api is None:
        click.echo(
            "Error: Flask-RESTX API not found in app extensions",
            err=True,
        )
        click.echo(
            f"Available extensions: {list(current_app.extensions.keys())}",
            err=True,
        )
        raise click.Abort()

    # Get the schema directly without making HTTP requests
    #
    # Flask-RESTX relies on ``url_for`` when generating the schema.  When
    # called outside of an active request context this results in
    # ``RuntimeError: Unable to build URLs outside an active request``.
    #
    # The CLI runs within an application context only, so we temporarily push
    # a request context while accessing ``api.__schema__``.  This mirrors what
    # happens during a real HTTP request and allows ``url_for`` to build URLs
    # without needing ``SERVER_NAME`` to be configured.
    try:
        with current_app.test_request_context():
            swagger_data = api.__schema__
    except Exception as e:
        click.echo(f"Error: Failed to access API schema: {e}", err=True)
        raise click.Abort() from e

    if not swagger_data:
        click.echo("Error: Empty swagger schema returned", err=True)
        raise click.Abort()

    # Write to output file
    output_path = Path(output)
    with open(output_path, "w", encoding="utf-8") as f:
        if pretty:
            json.dump(swagger_data, f, indent=2)
        else:
            json.dump(swagger_data, f)

    click.echo(f"Successfully extracted swagger.json to '{output_path}'")
    click.echo(f"API Title: {swagger_data.get('info', {}).get('title', 'Unknown')}")
    click.echo(f"API Version: {swagger_data.get('info', {}).get('version', 'Unknown')}")
    click.echo(f"Number of paths: {len(swagger_data.get('paths', {}))}")


@click.command("extract-swagger")
@click.option(
    "--output",
    "-o",
    default="swagger.json",
    help="Output file path for swagger.json (default: swagger.json)",
)
@click.option(
    "--pretty",
    "-p",
    is_flag=True,
    help="Pretty print the JSON output with indentation",
)
@with_appcontext
def extract_swagger(output: str, pretty: bool) -> None:
    r"""Extract swagger.json from the current Flask application.

    This command extracts the OpenAPI/Swagger specification directly from the
    Flask-RESTX API instance, without making HTTP requests.

    \b
    Examples:
        flask extract-swagger
        flask extract-swagger -o api-spec.json
        flask extract-swagger --output docs/swagger.json --pretty
    """
    extract_swagger_impl(output, pretty)
