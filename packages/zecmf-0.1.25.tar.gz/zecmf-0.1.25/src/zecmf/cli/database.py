"""Database setup CLI commands."""

import os

import click
from flask import current_app
from flask.cli import with_appcontext
from flask_migrate import init, migrate, upgrade
from sqlalchemy import inspect
from sqlalchemy.exc import ProgrammingError

from zecmf.extensions.database import db


def setup_db_impl() -> None:
    """Implement database setup logic.

    This function:
    1. Checks for existing tables and migrations
    2. Initializes migrations directory if needed
    3. Creates initial migration if no tables exist
    4. Applies all migrations

    If migration fails, the command will crash with diagnostic information.
    No fallback to create_all() is attempted - migrations must succeed.
    """
    click.echo("Setting up database...")

    # Get database connection
    inspector = inspect(db.engine)

    # Check if tables already exist
    existing_tables = inspector.get_table_names()

    # Check if migrations directory exists
    app_root = current_app.root_path
    migrations_dir = os.path.join(os.path.dirname(app_root), "migrations")
    migrations_dir_exists = os.path.exists(migrations_dir)

    # Initialize migrations directory if it doesn't exist
    if not migrations_dir_exists:
        click.echo("Initializing migrations directory...")
        init()
        # Create initial migration if needed
        if not existing_tables:
            click.echo("Creating initial migration...")
            migrate(message="Initial migration")

    # Try to apply migrations
    try:
        click.echo("Applying migrations...")
        upgrade()
        click.echo("Migrations applied successfully!")
    except ProgrammingError as e:
        click.echo(f"ERROR: Migration failed: {e!s}", err=True)
        click.echo(
            "Check migrations/versions/ and verify database schema is in sync.",
            err=True,
        )
        raise

    click.echo("Database setup complete!")


@click.command("setup-db")
@with_appcontext
def setup_db() -> None:
    """Set up database migrations and apply them.

    This command:
    1. Initializes the migrations directory if it doesn't exist
    2. Creates an initial migration if no tables exist
    3. Applies all existing migrations to the database

    If migration fails, the command will crash with diagnostic information.
    """
    setup_db_impl()
