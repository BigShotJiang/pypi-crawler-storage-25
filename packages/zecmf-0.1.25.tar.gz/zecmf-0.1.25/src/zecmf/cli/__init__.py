"""Command-line interface module for Flask applications."""

# Re-export implementation functions for backward compatibility
from zecmf.cli.database import setup_db, setup_db_impl
from zecmf.cli.health import health_check, health_check_impl
from zecmf.cli.migrations import init_migrations, init_migrations_impl
from zecmf.cli.registry import register_commands
from zecmf.cli.swagger import extract_swagger, extract_swagger_impl

__all__ = [
    "extract_swagger",
    "extract_swagger_impl",
    "health_check",
    "health_check_impl",
    "init_migrations",
    "init_migrations_impl",
    "register_commands",
    "setup_db",
    # Implementation functions
    "setup_db_impl",
]
