"""Migration initialization CLI commands."""

import importlib
import os

import click
from flask import current_app, has_app_context

from zecmf.migrations import setup_migrations


def init_migrations_impl(models_module: list[str]) -> None:
    """Implement migrations initialization logic.

    Generates a migrations directory with Alembic configuration and
    automatically imports the specified model modules.

    Args:
        models_module: Modules containing models to import (e.g., app.models.user)

    """
    # Determine base directory for migrations (app root if available, else cwd)
    if has_app_context():
        base_dir = os.path.dirname(current_app.root_path)
    else:
        base_dir = os.path.dirname(os.getcwd())
    migrations_dir = os.path.join(base_dir, "migrations")

    # Generate import statements
    model_imports = []
    for module_name in models_module:
        try:
            module = importlib.import_module(module_name)
            # Get model classes from the module
            for attr_name in dir(module):
                if attr_name.startswith("_"):
                    continue
                attr = getattr(module, attr_name)
                if hasattr(attr, "__tablename__"):
                    model_imports.append(f"from {module_name} import {attr_name}")
        except ImportError:
            click.echo(f"Warning: Could not import module {module_name}")

    # Add import statements for the models
    click.echo(f"Setting up migrations in {migrations_dir}")
    setup_migrations(
        destination_dir=migrations_dir,
        models_import_statements=model_imports if model_imports else None,
    )
    click.echo("Migrations directory initialized successfully.")
    click.echo("\nNext steps:")
    click.echo("1. Review the generated files")
    click.echo("2. Run 'flask db init' to initialize Alembic")
    click.echo(
        "3. Run 'flask db migrate -m \"Initial migration\"' to create your first migration"
    )
    click.echo("4. Run 'flask db upgrade' to apply the migration")


@click.command("init-migrations")
@click.option(
    "--models-module",
    "-m",
    multiple=True,
    help="Modules containing models to import (format: app.models.user)",
)
def init_migrations(models_module: list[str]) -> None:
    """Initialize migrations directory with templates from the framework.

    This creates a migrations directory with the standard Alembic files,
    configured to work with the application's models.

    Args:
        models_module: Modules containing models to import (e.g., app.models.user)

    """
    init_migrations_impl(models_module)
