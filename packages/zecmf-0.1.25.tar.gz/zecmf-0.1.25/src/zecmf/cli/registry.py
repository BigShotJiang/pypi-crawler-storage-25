"""CLI command registration."""

from flask import Flask

from zecmf.cli.database import setup_db
from zecmf.cli.health import health_check
from zecmf.cli.migrations import init_migrations
from zecmf.cli.swagger import extract_swagger


def register_commands(app: Flask) -> None:
    """Register custom Flask CLI commands.

    Args:
        app: The Flask application.

    """
    app.cli.add_command(setup_db)
    app.cli.add_command(health_check)
    app.cli.add_command(init_migrations)
    app.cli.add_command(extract_swagger)
