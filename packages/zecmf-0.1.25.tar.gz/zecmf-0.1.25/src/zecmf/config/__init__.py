"""Configuration module for micro-framework."""

from zecmf.config.base import (
    BaseConfig,
    BaseDevelopmentConfig,
    BaseProductionConfig,
    BaseTestingConfig,
)
from zecmf.config.base import (
    BaseTestingConfig as TestingConfig,  # Alias required for tests
)
from zecmf.config.loader import get_config

__all__ = [
    "BaseConfig",
    "BaseDevelopmentConfig",
    "BaseProductionConfig",
    "BaseTestingConfig",
    "TestingConfig",
    "get_config",
]
