"""Utility functions for parsing API response data into dataclasses.

This module provides helpers for forward-compatible parsing that tolerates
unknown fields in API responses, preventing SDK crashes when downstream
services add new fields.
"""

from dataclasses import fields
from typing import Any


def from_dict[T](cls: type[T], data: dict[str, Any]) -> T:
    """Create a dataclass instance from a dict, ignoring unknown keys.

    This function enables forward-compatible parsing of API responses.
    When a service adds new fields to its response, consumers using this
    SDK won't crash with "unexpected keyword argument" errors.

    Args:
        cls: The dataclass type to instantiate.
        data: The dictionary containing the data (e.g., from resp.json()).

    Returns:
        An instance of the dataclass with only known fields populated.

    Example:
        >>> @dataclass
        ... class Profile:
        ...     id: int
        ...     name: str
        ...
        >>> data = {"id": 1, "name": "Test", "new_field": "ignored"}
        >>> profile = from_dict(Profile, data)
        >>> profile.id
        1

    """
    known = {f.name for f in fields(cls)}  # type: ignore[arg-type]
    return cls(**{k: v for k, v in data.items() if k in known})
