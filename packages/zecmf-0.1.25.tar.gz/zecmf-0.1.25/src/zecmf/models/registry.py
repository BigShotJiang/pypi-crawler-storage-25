"""Model registry utilities."""

from zecmf.models.task_monitoring import TaskExecution, TaskExecutionLog


def get_all_models() -> list:
    """Get all available framework models.

    Returns:
        List of all model classes that should be included in migrations.

    """
    return [TaskExecution, TaskExecutionLog]
