"""Migrations initialization module for microservices."""

from zecmf.migrations.setup import setup_migrations

__all__ = ["setup_migrations"]
