"""API module for Flask-RESTX integration."""

from zecmf.api.init import init_api

__all__ = ["init_api"]
