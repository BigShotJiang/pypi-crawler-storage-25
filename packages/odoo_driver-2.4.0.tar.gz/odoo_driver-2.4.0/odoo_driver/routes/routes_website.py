import os
import platform
from pathlib import Path

import psutil
from flask import redirect, render_template, send_from_directory, url_for
from flask_babel import gettext as _
from loguru import logger

from ..app import app
from ..tools import tools_usb_device
from ..tools.tools_interface import interface

# ##################################################
# Main Pages
# ##################################################


@app.route("/")
@app.route("/drivers.html")
@logger.catch
def drivers():
    return render_template("drivers.html.jinja", interface=interface)


@app.route("/driver_errored_tasks.html/<string:driver_function>")
@logger.catch
def driver_errored_tasks(driver_function):
    if driver_function not in interface.drivers:
        raise Exception(f"{driver_function} is not a valid device type.")
    driver = interface.drivers.get(driver_function)
    return render_template("driver_errored_tasks.html.jinja", driver=driver)


@app.route("/driver_disconnections.html/<string:driver_function>")
@logger.catch
def driver_disconnections(driver_function):
    if driver_function not in interface.drivers:
        raise Exception(f"{driver_function} is not a valid device type.")
    driver = interface.drivers.get(driver_function)
    return render_template("driver_disconnections.html.jinja", device=driver)


@app.route("/usb_core_devices.html", methods=["GET"])
@logger.catch
def usb_core_devices():
    return render_template(
        "usb_core_devices.html.jinja",
        interface=interface,
        tools_usb_device=tools_usb_device,
    )


@app.route("/usb_core_devices_refresh")
@logger.catch
def usb_core_devices_refresh():
    interface.refresh_usb_core_devices(manual=True)
    return redirect(url_for("usb_core_devices"))


@app.route("/supported_devices.html", methods=["GET"])
@logger.catch
def supported_devices():
    supported_devices_data = {}
    for vendor_product_code, usb_device_info in tools_usb_device.usb_devices.items():
        usb_device_info.update(
            {
                "vendor_id": vendor_product_code[0],
                "product_id": vendor_product_code[1],
            }
        )
        if usb_device_info["driver_function"] not in supported_devices_data:
            supported_devices_data[usb_device_info["driver_function"]] = []
        supported_devices_data[usb_device_info["driver_function"]].append(
            usb_device_info
        )

    return render_template(
        "supported_devices.html.jinja",
        interface=interface,
        supported_devices_data=supported_devices_data,
    )


@app.route("/system.html")
@logger.catch
def system():
    system_info = [
        (_("Operating System"), platform.system()),
        (_("Kernel Release"), platform.release()),
        (_("Operating System Version"), platform.version()),
        (_("Architecture"), " / ".join(platform.architecture())),
        (_("Processors Type"), platform.processor()),
        (
            _("Processors Quantity"),
            f"{psutil.cpu_count(logical=False)} / {psutil.cpu_count()}",
        ),
        (
            _("Processors Frequency"),
            f"{(psutil.cpu_freq().current / 1024):.1f} Ghz",
        ),
        (
            _("Processors Load"),
            f"{(psutil.getloadavg()[0] / psutil.cpu_count() * 100):.2f} %",
        ),
        (
            _("Total Memory"),
            f"{(psutil.virtual_memory().total / (pow(1024, 3))):.2f} Gb",
        ),
        (_("Memory Usage"), f"{(psutil.virtual_memory().percent):.2f} %"),
        (_("Python Version"), platform.python_version()),
    ]
    return render_template("system.html.jinja", system_info=system_info)


@app.route("/application.html")
@logger.catch
def application():
    # Lazy import, to avoid circular import problem
    from .. import __package_name__, __version__, code_hash
    from ..tools.tools_plugins import installed_plugins

    application_info = [
        (_("Start datetime"), interface.start_date),
    ]
    package_info = [
        (__package_name__, __version__, code_hash),
    ]

    for module_name, plugin in installed_plugins.items():
        package_info.append((module_name, plugin.__version__, plugin.code_hash))

    return render_template(
        "application.html.jinja",
        application_info=application_info,
        package_info=package_info,
    )


# ##################################################
# Images
# ##################################################


@app.route("/favicon.ico")
@logger.catch
def favicon():
    return send_from_directory(
        os.path.join(app.root_path, "static", "img"),
        "favicon.png",
        mimetype="image/png",
    )


@app.route("/device_image/<int:vendor_id>/<int:product_id>")
@logger.catch
def device_image(vendor_id, product_id):
    image_path = False
    vendor_product_code = (vendor_id, product_id)
    device_info = tools_usb_device.usb_devices.get(vendor_product_code, {})
    if device_info:
        if device_info.get("image"):
            image_path = Path(
                device_info.get("plugin_path", ""),
                "static",
                "img",
                device_info.get("image"),
            )
        if not image_path.exists():
            image_path = Path(
                device_info["plugin_path"], "static", "img", "generic_device.png"
            )
    if not image_path or not image_path.exists():
        image_path = Path(app.root_path, "static", "img", "unknown_device.png")

    return send_from_directory(
        image_path.absolute().parent,
        image_path.name,
        mimetype="image/png",
    )
