import torch
import torch.nn as nn
import numpy as np
from sagan.models.controller_arch import ControllerLSTM

class LSTMSymbolicFitter(nn.Module):
    """
    5-layer LSTM Fitter that maps price sequences to mathematical coefficients.
    USP: Neural-guided fitting for explainable symbolic models.
    """
    def __init__(self, input_size=1, hidden_size=256, n_harmonics=3):
        super().__init__()
        # We use the vocab_size as the output dimension for coefficients
        # num_coeffs = 3 (poly: a0, a1, a2) + 3 * n_harmonics (fourier: ai, bi, wi)
        self.num_coeffs = 3 + 3 * n_harmonics
        
        # We reuse ControllerLSTM but we need to map its output to a continuous vector
        # The original ControllerLSTM has a vocab embedding/fc head.
        # Let's create a specialized version for regression.
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=5, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden_size, self.num_coeffs)
        
    def forward(self, x):
        # x: (B, T, 1)
        _, (h, _) = self.lstm(x)
        # Take the top layer hidden state
        top_h = h[-1] # (B, H)
        coeffs = self.fc(top_h) # (B, Num_Coeffs)
        return coeffs

    @staticmethod
    def evaluate_math(t, coeffs, n_harmonics=3):
        """
        Evaluate the math function at time t given coefficients.
        coeffs: [a0, a1, a2, A1, B1, w1, A2, B2, w2, ...]
        """
        # Poly part
        a0, a1, a2 = coeffs[0], coeffs[1], coeffs[2]
        res = a0 + a1 * t + a2 * (t**2)
        
        # Fourier part
        for i in range(n_harmonics):
            A = coeffs[3 + i*3]
            B = coeffs[3 + i*3 + 1]
            w = coeffs[3 + i*3 + 2]
            res += A * torch.cos(w * t) + B * torch.sin(w * t)
            
        return res

    def get_formula(self, coeffs, n_harmonics=3):
        """
        Returns a human-readable string of the fitted math function.
        """
        c = coeffs.detach().cpu().numpy()
        terms = [f"{c[0]:.4f}", f"({c[1]:.4f} * t)", f"({c[2]:.4f} * t^2)"]
        
        for i in range(n_harmonics):
            A, B, w = c[3+i*3], c[3+i*3+1], c[3+i*3+2]
            terms.append(f"({A:.4f} * cos({w:.4f}*t))")
            terms.append(f"({B:.4f} * sin({w:.4f}*t))")
            
        return " + ".join(terms)
