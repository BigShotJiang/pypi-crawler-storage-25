use std::sync::{Arc};
use pyo3::{Bound, PyAny, pyclass, pymethods};
use pyo3::prelude::*;
use pyo3_async_runtimes::tokio::{future_into_py_with_locals, get_current_locals};
use tokio::sync::watch;
use waproto::whatsapp::Message as WhatsappMessage;
use waproto::whatsapp::message::{self as wa};
use wacore::proto_helpers::build_quote_context;
use prost::Message;
use whatsapp_rust::{Client, UploadOptions};
use crate::clients::chat_actions::ChatActionsClient;
use crate::clients::chatstate::ChatstateClient;
use crate::clients::community::CommunityClient;
use crate::clients::contacts::ContactClient;
use crate::clients::blocking::BlockingClient;
use crate::clients::groups::GroupsClient;
use crate::clients::newsletter::NewsletterClient;
use crate::clients::polls::PollsClient;
use crate::clients::presence::PresenceClient;
use crate::clients::privacy::PrivacyClient;
use crate::clients::profile::ProfileClient;
use crate::clients::status::StatusClient;
use crate::events::types::{EvMessage};
use crate::types::{JID, MediaReuploadResult, SendResult, UploadResponse};
use crate::wacore::download::MediaType;
#[pyclass]
pub struct TryxClient {
    pub client_rx: watch::Receiver<Option<Arc<Client>>>,
    #[pyo3(get)]
    pub contact: Py<ContactClient>,
    #[pyo3(get)]
    pub chat_actions: Py<ChatActionsClient>,
    #[pyo3(get)]
    pub community: Py<CommunityClient>,
    #[pyo3(get)]
    pub newsletter: Py<NewsletterClient>,
    #[pyo3(get)]
    pub groups: Py<GroupsClient>,
    #[pyo3(get)]
    pub status: Py<StatusClient>,
    #[pyo3(get)]
    pub chatstate: Py<ChatstateClient>,
    #[pyo3(get)]
    pub blocking: Py<BlockingClient>,
    #[pyo3(get)]
    pub polls: Py<PollsClient>,
    #[pyo3(get)]
    pub presence: Py<PresenceClient>,
    #[pyo3(get)]
    pub privacy: Py<PrivacyClient>,
    #[pyo3(get)]
    pub profile: Py<ProfileClient>,
}

impl TryxClient {
    fn quote_context(py: Python<'_>, quoted: Option<&Py<EvMessage>>) -> Option<waproto::whatsapp::ContextInfo> {
        quoted.map(|q| {
            let quote = q.bind(py).borrow();
            let msg = quote.inner.as_ref();
            build_quote_context(
                quote.inner_message_info.id.clone(),
                quote.inner_message_info.source.chat.clone(),
                msg,
            )
        })
    }

    fn into_send_result(py: Python<'_>, result: whatsapp_rust::SendResult) -> PyResult<Py<SendResult>> {
        let to = Py::new(py, JID::from(result.to))?;
        Py::new(
            py,
            SendResult {
                message_id: result.message_id,
                to,
            },
        )
    }
}

#[pymethods]
impl TryxClient {
    fn is_connected(&self) -> bool {
        self.client_rx.borrow().is_some()
    }
    // fn download_media_to_writter<'py>(&self, py: Python<'py>, message: Py<PyAny>, path: String) -> PyResult<Bound<'py, PyAny>> {
    //     let client = self.client_rx.borrow().clone().ok_or_else(|| {
    //         PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
    //     })?;
    //     let message_type_name = message
    //         .getattr(py, "DESCRIPTOR")
    //         .and_then(|descriptor| descriptor.getattr(py, "name"))
    //         .and_then(|name| name.extract::<String>(py))
    //         .unwrap_or_default();
    //     let serialized: Vec<u8> = message
    //         .call_method0(py, "SerializeToString")?
    //         .extract(py)?;

    //     let locals = get_current_locals(py)?;
    //     future_into_py_with_locals(py, locals, async move {
    //         match message_type_name.as_str() {
    //             "ImageMessage" => {
    //                 let media = wa::ImageMessage::decode(serialized.as_slice()).map_err(|e| {
    //                     PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         format!("Failed to decode ImageMessage: {}", e),
    //                     )
    //                 })?;
    //                 client.download_to_writer(&media, path).await
    //             }
    //             "VideoMessage" => {
    //                 let media = wa::VideoMessage::decode(serialized.as_slice()).map_err(|e| {
    //                     PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         format!("Failed to decode VideoMessage: {}", e),
    //                     )
    //                 })?;
    //                 client.download_to_writer(&media, path).await
    //             }
    //             "DocumentMessage" => {
    //                 let media = wa::DocumentMessage::decode(serialized.as_slice()).map_err(|e| {
    //                     PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         format!("Failed to decode DocumentMessage: {}", e),
    //                     )
    //                 })?;
    //                 client.download_to_writer(&media, path).await
    //             }
    //             "AudioMessage" => {
    //                 let media = wa::AudioMessage::decode(serialized.as_slice()).map_err(|e| {
    //                     PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         format!("Failed to decode AudioMessage: {}", e),
    //                     )
    //                 })?;
    //                 client.download_to_writer(&media, path).await
    //             }
    //             "StickerMessage" => {
    //                 let media = wa::StickerMessage::decode(serialized.as_slice()).map_err(|e| {
    //                     PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         format!("Failed to decode StickerMessage: {}", e),
    //                     )
    //                 })?;
    //                 client.download_to_writer(&media, path).await
    //             }
    //             _ => {
    //                 // Fallback path for unknown wrappers from Python side.
    //                 if let Ok(media) = wa::ImageMessage::decode(serialized.as_slice()) {
    //                     client.download_to_writer(&media, path).await
    //                 } else if let Ok(media) = wa::VideoMessage::decode(serialized.as_slice()) {
    //                     client.download_to_writer(&media, path).await
    //                 } else if let Ok(media) = wa::DocumentMessage::decode(serialized.as_slice()) {
    //                     client.download_to_writer(&media, path).await
    //                 } else if let Ok(media) = wa::AudioMessage::decode(serialized.as_slice()) {
    //                     client.download_to_writer(&media, path).await
    //                 } else if let Ok(media) = wa::StickerMessage::decode(serialized.as_slice()) {
    //                     client.download_to_writer(&media, path).await
    //                 } else {
    //                     return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
    //                         "Failed to decode message as supported media message",
    //                     ));
    //                 }
    //             }
    //         }.map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    fn download_media<'py>(&self, py: Python<'py>, message: Py<PyAny>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let message_type_name = message
            .getattr(py, "DESCRIPTOR")
            .and_then(|descriptor| descriptor.getattr(py, "name"))
            .and_then(|name| name.extract::<String>(py))
            .unwrap_or_default();
        let serialized: Vec<u8> = message
            .call_method0(py, "SerializeToString")?
            .extract(py)?;

        let locals = get_current_locals(py)?;
        future_into_py_with_locals::<_, Vec<u8>>(py, locals, async move {
            let download = match message_type_name.as_str() {
                "ImageMessage" => {
                    let media = wa::ImageMessage::decode(serialized.as_slice()).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            format!("Failed to decode ImageMessage: {}", e),
                        )
                    })?;
                    client.download(&media).await
                }
                "VideoMessage" => {
                    let media = wa::VideoMessage::decode(serialized.as_slice()).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            format!("Failed to decode VideoMessage: {}", e),
                        )
                    })?;
                    client.download(&media).await
                }
                "DocumentMessage" => {
                    let media = wa::DocumentMessage::decode(serialized.as_slice()).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            format!("Failed to decode DocumentMessage: {}", e),
                        )
                    })?;
                    client.download(&media).await
                }
                "AudioMessage" => {
                    let media = wa::AudioMessage::decode(serialized.as_slice()).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            format!("Failed to decode AudioMessage: {}", e),
                        )
                    })?;
                    client.download(&media).await
                }
                "StickerMessage" => {
                    let media = wa::StickerMessage::decode(serialized.as_slice()).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            format!("Failed to decode StickerMessage: {}", e),
                        )
                    })?;
                    client.download(&media).await
                }
                _ => {
                    // Fallback path for unknown wrappers from Python side.
                    if let Ok(media) = wa::ImageMessage::decode(serialized.as_slice()) {
                        client.download(&media).await
                    } else if let Ok(media) = wa::VideoMessage::decode(serialized.as_slice()) {
                        client.download(&media).await
                    } else if let Ok(media) = wa::DocumentMessage::decode(serialized.as_slice()) {
                        client.download(&media).await
                    } else if let Ok(media) = wa::AudioMessage::decode(serialized.as_slice()) {
                        client.download(&media).await
                    } else if let Ok(media) = wa::StickerMessage::decode(serialized.as_slice()) {
                        client.download(&media).await
                    } else {
                        return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                            "Failed to decode message as supported media message",
                        ));
                    }
                }
            };

            download.map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
        })
    }
    fn upload_file<'py>(&self, py: Python<'py>, path: String, media_type: Py<MediaType>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let media_type_enum = media_type.bind(py).borrow_mut().to_wacore_enum();
        let locals = get_current_locals(py)?;
        let data = std::fs::read(&path)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        future_into_py_with_locals(py, locals, async move {
            let url = client
                .upload(data, media_type_enum, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            let result= UploadResponse {
                url: url.url,
                direct_path: url.direct_path,
                media_key: url.media_key.to_vec(),
                file_enc_sha256: url.file_enc_sha256.to_vec(),
                file_sha256: url.file_sha256.to_vec(),
                file_length: url.file_length,
            };
            Ok(result)
        })
    }
    fn upload<'py>(&self, py: Python<'py>, data: &[u8], media_type: Py<MediaType>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let data_vec = data.to_vec();
        let mtype = media_type.bind(py).borrow_mut().to_wacore_enum();
        let locals = get_current_locals(py)?;
        future_into_py_with_locals::<_, UploadResponse>(py, locals, async move {
            let url = client
                .upload(data_vec, mtype, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            let result= UploadResponse {
                url: url.url,
                direct_path: url.direct_path,
                media_key: url.media_key.to_vec(),
                file_enc_sha256: url.file_enc_sha256.to_vec(),
                file_sha256: url.file_sha256.to_vec(),
                file_length: url.file_length,
            };
            Ok(result)
        })
        //     Ok(url)
        // })
    }
    fn send_message<'py>(&self, py: Python<'py>, to: Py<JID>, message: Py<PyAny>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;

        let jid = to.bind(py).borrow().as_whatsapp_jid();

        // Python protobuf object -> bytes -> Rust proto
        let serialized: Vec<u8> = message
            .call_method0(py, "SerializeToString")?
            .extract(py)?;

        let whatsapp_message = WhatsappMessage::decode(serialized.as_slice()).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(
                format!("Failed to decode WhatsAppMessage proto: {}", e),
            )
        })?;

        let locals = get_current_locals(py)?;
        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let send_result = client
                .send_message(jid, whatsapp_message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }
    #[pyo3(signature = (to, text, quoted=None))]
    fn send_text<'py>(&self, py: Python<'py>, to: Py<JID>, text: String, quoted: Option<Py<EvMessage>>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());
        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            match quoted {
                Some(_) => {
                    let message = WhatsappMessage {
                        extended_text_message: Some(Box::new(wa::ExtendedTextMessage {
                            text: Some(text),
                            context_info: context_info.map(Box::new),
                            ..Default::default()
                        })),
                        ..Default::default()
                    };
                    let send_result = client
                        .send_message(jid, message)
                        .await
                        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
                    Python::attach(|py| Self::into_send_result(py, send_result))
                }
                None => {
                    let message = WhatsappMessage {
                        conversation: Some(text),
                        ..Default::default()
                    };
                    let send_result = client
                        .send_message(jid, message)
                        .await
                        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
                    Python::attach(|py| Self::into_send_result(py, send_result))
                }
            }
        })
    }
    #[pyo3(signature = (to, photo_data, caption=None, quoted=None))]
    fn send_photo<'py>(&self, py: Python<'py>, to: Py<JID>, photo_data: &[u8], caption: Option<String>, quoted: Option<Py<EvMessage>>) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let photo_clone = photo_data.to_vec();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());
        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let upload = client
                .upload(photo_clone, wacore::download::MediaType::Image, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            let message = WhatsappMessage {
                image_message: Some(Box::new(wa::ImageMessage {
                url: Some(upload.url),
                direct_path: Some(upload.direct_path),
                media_key: Some(upload.media_key.to_vec()),
                file_enc_sha256: Some(upload.file_enc_sha256.to_vec()),
                file_sha256: Some(upload.file_sha256.to_vec()),
                file_length: Some(upload.file_length),
                caption,
                context_info: context_info.map(Box::new),
                ..Default::default()
            })),
                ..Default::default()
            };
            let send_result = client
                .send_message(jid, message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }

    #[pyo3(signature = (to, document_data, mimetype, file_name=None, caption=None, quoted=None))]
    fn send_document<'py>(
        &self,
        py: Python<'py>,
        to: Py<JID>,
        document_data: &[u8],
        mimetype: String,
        file_name: Option<String>,
        caption: Option<String>,
        quoted: Option<Py<EvMessage>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let data = document_data.to_vec();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());

        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let upload = client
                .upload(data, wacore::download::MediaType::Document, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

            let message = WhatsappMessage {
                document_message: Some(Box::new(wa::DocumentMessage {
                    url: Some(upload.url),
                    mimetype: Some(mimetype),
                    title: file_name.clone(),
                    file_sha256: Some(upload.file_sha256.to_vec()),
                    file_length: Some(upload.file_length),
                    media_key: Some(upload.media_key.to_vec()),
                    file_name,
                    file_enc_sha256: Some(upload.file_enc_sha256.to_vec()),
                    direct_path: Some(upload.direct_path),
                    caption,
                    context_info: context_info.map(Box::new),
                    ..Default::default()
                })),
                ..Default::default()
            };

            let send_result = client
                .send_message(jid, message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }

    #[pyo3(signature = (to, audio_data, mimetype=None, ptt=false, seconds=None, quoted=None))]
    fn send_audio<'py>(
        &self,
        py: Python<'py>,
        to: Py<JID>,
        audio_data: &[u8],
        mimetype: Option<String>,
        ptt: bool,
        seconds: Option<u32>,
        quoted: Option<Py<EvMessage>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let data = audio_data.to_vec();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());

        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let upload = client
                .upload(data, wacore::download::MediaType::Audio, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

            let message = WhatsappMessage {
                audio_message: Some(Box::new(wa::AudioMessage {
                    url: Some(upload.url),
                    mimetype: Some(mimetype.unwrap_or_else(|| "audio/ogg; codecs=opus".to_string())),
                    file_sha256: Some(upload.file_sha256.to_vec()),
                    file_length: Some(upload.file_length),
                    seconds,
                    ptt: Some(ptt),
                    media_key: Some(upload.media_key.to_vec()),
                    file_enc_sha256: Some(upload.file_enc_sha256.to_vec()),
                    direct_path: Some(upload.direct_path),
                    context_info: context_info.map(Box::new),
                    ..Default::default()
                })),
                ..Default::default()
            };

            let send_result = client
                .send_message(jid, message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }

    #[pyo3(signature = (to, video_data, mimetype=None, caption=None, seconds=None, gif_playback=false, quoted=None))]
    fn send_video<'py>(
        &self,
        py: Python<'py>,
        to: Py<JID>,
        video_data: &[u8],
        mimetype: Option<String>,
        caption: Option<String>,
        seconds: Option<u32>,
        gif_playback: bool,
        quoted: Option<Py<EvMessage>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let data = video_data.to_vec();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());

        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let upload = client
                .upload(data, wacore::download::MediaType::Video, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

            let message = WhatsappMessage {
                video_message: Some(Box::new(wa::VideoMessage {
                    url: Some(upload.url),
                    mimetype: Some(mimetype.unwrap_or_else(|| "video/mp4".to_string())),
                    file_sha256: Some(upload.file_sha256.to_vec()),
                    file_length: Some(upload.file_length),
                    seconds,
                    media_key: Some(upload.media_key.to_vec()),
                    caption,
                    gif_playback: Some(gif_playback),
                    file_enc_sha256: Some(upload.file_enc_sha256.to_vec()),
                    direct_path: Some(upload.direct_path),
                    context_info: context_info.map(Box::new),
                    ..Default::default()
                })),
                ..Default::default()
            };

            let send_result = client
                .send_message(jid, message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }

    #[pyo3(signature = (to, gif_data, caption=None, seconds=None, quoted=None))]
    fn send_gif<'py>(
        &self,
        py: Python<'py>,
        to: Py<JID>,
        gif_data: &[u8],
        caption: Option<String>,
        seconds: Option<u32>,
        quoted: Option<Py<EvMessage>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        self.send_video(py, to, gif_data, Some("video/mp4".to_string()), caption, seconds, true, quoted)
    }

    #[pyo3(signature = (to, sticker_data, is_animated=false, quoted=None))]
    fn send_sticker<'py>(
        &self,
        py: Python<'py>,
        to: Py<JID>,
        sticker_data: &[u8],
        is_animated: bool,
        quoted: Option<Py<EvMessage>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let jid = to.bind(py).borrow().as_whatsapp_jid();
        let data = sticker_data.to_vec();
        let locals = get_current_locals(py)?;
        let context_info = Self::quote_context(py, quoted.as_ref());

        future_into_py_with_locals::<_, Py<SendResult>>(py, locals, async move {
            let upload = client
                .upload(data, wacore::download::MediaType::Sticker, UploadOptions::default())
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

            let message = WhatsappMessage {
                sticker_message: Some(Box::new(wa::StickerMessage {
                    url: Some(upload.url),
                    file_sha256: Some(upload.file_sha256.to_vec()),
                    file_enc_sha256: Some(upload.file_enc_sha256.to_vec()),
                    media_key: Some(upload.media_key.to_vec()),
                    mimetype: Some("image/webp".to_string()),
                    direct_path: Some(upload.direct_path),
                    file_length: Some(upload.file_length),
                    is_animated: Some(is_animated),
                    context_info: context_info.map(Box::new),
                    ..Default::default()
                })),
                ..Default::default()
            };

            let send_result = client
                .send_message(jid, message)
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            Python::attach(|py| Self::into_send_result(py, send_result))
        })
    }

    #[pyo3(signature = (message_id, chat_jid, media_key, is_from_me=false, participant=None))]
    fn request_media_reupload<'py>(
        &self,
        py: Python<'py>,
        message_id: String,
        chat_jid: Py<JID>,
        media_key: &[u8],
        is_from_me: bool,
        participant: Option<Py<JID>>,
    ) -> PyResult<Bound<'py, PyAny>> {
        if media_key.is_empty() {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "media_key cannot be empty",
            ));
        }

        let client = self.client_rx.borrow().clone().ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Bot is not running")
        })?;
        let chat_jid_value = chat_jid.bind(py).borrow().as_whatsapp_jid();
        let participant_value = participant
            .as_ref()
            .map(|value| value.bind(py).borrow().as_whatsapp_jid());
        let media_key_data = media_key.to_vec();
        let locals = get_current_locals(py)?;

        future_into_py_with_locals::<_, MediaReuploadResult>(py, locals, async move {
            let req = whatsapp_rust::MediaReuploadRequest {
                msg_id: message_id.as_str(),
                chat_jid: &chat_jid_value,
                media_key: media_key_data.as_slice(),
                is_from_me,
                participant: participant_value.as_ref(),
            };

            client
                .media_reupload()
                .request(&req)
                .await
                .map(MediaReuploadResult::from)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
        })
    }
}

