"""Reusable MySQL backup and restore library."""

from __future__ import annotations

import logging as _stdlib_logging

_stdlib_logging.getLogger(__name__).addHandler(_stdlib_logging.NullHandler())

from mysql_backup_manager.backup import BackupService, MySQLBackupManager
from mysql_backup_manager.config import (
    DumpConfig,
    MySQLConnectionConfig,
    RestoreConfig,
    RetentionConfig,
    ScheduleConfig,
)
from mysql_backup_manager.models import BackupResult, RestoreResult, RetentionResult
from mysql_backup_manager.restore import RestoreService
from mysql_backup_manager.retention import RetentionService
from mysql_backup_manager.scheduler import SchedulerService

__all__ = [
    "BackupResult",
    "BackupService",
    "DumpConfig",
    "MySQLBackupManager",
    "MySQLConnectionConfig",
    "RestoreConfig",
    "RestoreResult",
    "RestoreService",
    "RetentionConfig",
    "RetentionResult",
    "RetentionService",
    "ScheduleConfig",
    "SchedulerService",
]
