import sys
from typing import Any, cast

import jsonpickle

from .runner.output import OutputBatch
from .runner.run_params import RunParams


# A very simple visualizer for now
class Visualizer:
    def visualize(self, run_params: RunParams) -> None:
        save_f = run_params.save_file
        if not save_f.exists() or not save_f.is_file():
            print(f"Error: {save_f} does not exist or is not a file.", file=sys.stderr)
            return

        metadata_f = run_params.metadata_file
        if not metadata_f.exists() or not metadata_f.is_file():
            print(
                f"Error: {metadata_f} does not exist or is not a file.", file=sys.stderr
            )
            return

        print(f"Reading metadata from {metadata_f}...\n")
        try:
            metadata = cast(dict[str, Any], jsonpickle.decode(metadata_f.read_text()))
            for k, v in metadata.items():
                print(f"  {k}: {v}")
        except Exception as e:
            print(f"Error decoding metadata: {e}", file=sys.stderr)

        print(f"\n\nVisualizing results from {save_f}...\n")
        try:
            with open(save_f, "r") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        output = cast(
                            OutputBatch[Any, Any, Any], jsonpickle.decode(line)
                        )
                        print(f"--- Entry {i + 1} ---")
                        print(f"Data:\n{output.input_data}")
                        print("\nResults:")
                        if len(output.solutions) > 0:
                            for j, (
                                sol,
                                gen_time,
                                total_gen_time,
                                checker_output,
                            ) in enumerate(output):
                                print(f"  Result {j + 1}:")
                                print(f"    Solution: {sol}")
                                print(f"    Status:   {checker_output.result}")
                                print(f"    Checking time: {checker_output.runtime}")
                                print(f"    Generation time: {gen_time}")
                                print(f"    Total generation time: {total_gen_time}")
                        else:
                            print("  No results found.")
                        print("\n" + "=" * 40 + "\n")

                    except Exception as e:
                        print(f"Error decoding line {i + 1}: {e}", file=sys.stderr)
        except Exception as e:
            print(f"Error reading file {save_f}: {e}", file=sys.stderr)
