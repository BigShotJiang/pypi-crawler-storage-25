from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import timedelta
from enum import Enum
from typing import Any, Generic, Optional, Type, TypeVar

from .adapter import SolutionT
from .data import DataT

ResultT = TypeVar("ResultT", bound=Enum)


@dataclass(frozen=True)
class CheckerOutput(Generic[ResultT]):
    result: ResultT
    runtime: Optional[timedelta]
    # Additional metadata can be added


class Checker(ABC, Generic[DataT, SolutionT, ResultT]):
    @abstractmethod
    def check(
        self, data: DataT, solution_batch: list[SolutionT]
    ) -> list[CheckerOutput[ResultT]]: ...


CheckerT = TypeVar("CheckerT", bound=Checker)


class CheckerFactory(Generic[CheckerT]):
    def __init__(self, checker_cls: Type[CheckerT], **kwargs: object) -> None:
        self._checker_cls = checker_cls
        self._kwargs = kwargs

    def create(self) -> CheckerT:
        return self._checker_cls(**self._kwargs)

    def get_params(self) -> dict[str, Any]:
        return self._kwargs
