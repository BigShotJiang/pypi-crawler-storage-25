import argparse
import json
import sys
from pathlib import Path

# We use raw jsons to avoid issues with unpickling types etc.
# This file needs to be updated for each API breaking change, but it works nicely


def _merge_batches(dst: dict, src: dict) -> None:
    dst["solutions"].extend(src.get("solutions", []))
    dst["solution_runtimes"].extend(src.get("solution_runtimes", []))
    dst["solution_total_times"].extend(src.get("solution_total_times", []))
    dst["checker_outputs"].extend(src.get("checker_outputs", []))


def main() -> None:
    parser = argparse.ArgumentParser(description="Combine APE run results.")
    parser.add_argument("folder", help="Folder containing .jsonl run files")
    args = parser.parse_args()

    folder = Path(args.folder)
    if not folder.exists() or not folder.is_dir():
        print(f"Error: {folder} does not exist or is not a directory.", file=sys.stderr)
        sys.exit(1)

    output_path = folder / "combined.jsonl"

    if output_path.exists():
        print(
            f"Error: Output file {output_path} already exists. Aborting to prevent overwriting.",
            file=sys.stderr,
        )
        sys.exit(1)

    input_files = []
    for f in folder.glob("*.jsonl"):
        input_files.append(f)

    if not input_files:
        print("No .jsonl files found to combine.")
        return

    # Sort files for deterministic order
    input_files.sort()

    print(f"Found {len(input_files)} files to combine into {output_path}")

    merged_data: dict[str, dict] = {}

    def process_file(fpath: Path) -> None:
        print(f"Reading {fpath.name}...")
        count = 0
        try:
            with open(fpath, "r") as infile:
                for line in infile:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        output = json.loads(line)
                        data_id = output["input_data"]["_Data__id"]
                        if data_id in merged_data:
                            _merge_batches(merged_data[data_id], output)
                        else:
                            merged_data[data_id] = output
                        count += 1
                    except Exception as e:
                        print(
                            f"  Error decoding line in {fpath.name}: {e}",
                            file=sys.stderr,
                        )
            print(f"  Processed {count} entries.")
        except Exception as e:
            print(f"  Error reading {fpath.name}: {e}", file=sys.stderr)

    for fpath in input_files:
        process_file(fpath)

    print(f"Writing merged results ({len(merged_data)} items) to {output_path}...")
    try:
        with open(output_path, "w") as outfile:
            for output in merged_data.values():
                outfile.write(json.dumps(output) + "\n")
    except Exception as e:
        print(f"Error writing to {output_path}: {e}", file=sys.stderr)
        sys.exit(1)

    print("Done.")


if __name__ == "__main__":
    main()
