from google import genai
from google.genai import types
from google.genai.chats import Chat

from .model import ChatSession, LLMModel


class GeminiChatSession(ChatSession):
    def __init__(self, chat: Chat) -> None:
        self._chat = chat

    def send_message(self, message: str) -> str:
        response = self._chat.send_message(message)
        if hasattr(response, "text"):
            return str(response.text)
        if hasattr(response, "parts") and response.parts:
            return "".join(
                part.text for part in response.parts if part.text is not None
            )
        return str(response)


class GeminiModel(LLMModel):
    def __init__(self, client: genai.Client, model_name: str):
        self._client = client
        self._model_name = model_name

    def start_chat(self, system_instruction: str | None = None) -> ChatSession:
        config = None
        if system_instruction:
            config = types.GenerateContentConfig(system_instruction=system_instruction)
        # Verify model name or handling?
        # The user might pass "gemini-3.0-pro" here.
        chat = self._client.chats.create(model=self._model_name, config=config)
        return GeminiChatSession(chat)
