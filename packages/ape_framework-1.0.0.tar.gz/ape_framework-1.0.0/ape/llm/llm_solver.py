import logging
import os
from typing import Callable, Optional

from google import genai

from ..checker import CheckerOutput, ResultT
from ..data import DataT
from ..solver import Solver
from .gemini_model import GeminiModel
from .model import ChatSession, LLMModel, ModelChoice

RawT = str

logger = logging.getLogger(__name__)


class LLMSolver(Solver[DataT, RawT, ResultT]):
    """
    A generic solver that uses an injected LLM model to solve problems.
    It manages the chat session state and delegates prompt creation/checking to helpers.
    """

    def __init__(
        self,
        model: LLMModel | ModelChoice,
        prompt_formatter: Callable[[DataT], str],
        feedback_formatter: Callable[[list[CheckerOutput[ResultT]]], str] | None = None,
        max_turns: int = 5,
        system_instruction: str | None = None,
    ):
        """
        Args:
            model: An implementation of LLMModel (e.g. GeminiModel) or a ModelChoice enum.
            prompt_formatter: Function to convert DataT into a prompt string.
            feedback_formatter: Optional function to convert results into a feedback message.
            max_turns: Maximum number of interaction turns allowed.
            system_instruction: Optional system instruction to prepend to the session.
        """
        if isinstance(model, ModelChoice):
            api_key = os.environ.get("GEMINI_API_KEY")
            if not api_key:
                raise ValueError("GEMINI_API_KEY environment variable not set.")
            client = genai.Client(api_key=api_key)
            self._model: LLMModel = GeminiModel(client, model.value)
        else:
            self._model = model

        self._prompt_formatter = prompt_formatter
        self._feedback_formatter = feedback_formatter or self._default_feedback
        self._max_turns = max_turns
        self._system_instruction = system_instruction

        # Session state
        self._chat: ChatSession | None = None
        self._current_turn: int = 0
        self._last_response: str = ""

    def session_alive(self) -> bool:
        return self._current_turn < self._max_turns

    def _default_feedback(self, outputs: list[CheckerOutput[ResultT]]) -> str:
        results = []
        for output in outputs:
            results.append(output.result)
        return f"The previous solution was incorrect. Results: {results}. Please try again."

    def begin_session(self, data: DataT) -> RawT:
        self._current_turn = 0
        self._last_response = ""
        try:
            # Initialize chat session.
            self._chat = self._model.start_chat(
                system_instruction=self._system_instruction
            )

            prompt = self._prompt_formatter(data)

            logger.info(f"Starting session. Prompt: {prompt[:100]}...")
            self._last_response = self._chat.send_message(prompt)
            return self._last_response

        except Exception as e:
            logger.error(f"Error in begin_session: {e}")
            # we return empty string, Runner will likely fail adaptation and try retry_last or fail
            return ""

    def retry_last(self) -> RawT:
        """
        Asks the model to retry the last response, typically because parsing failed.
        """
        try:
            if self._chat is None:
                raise RuntimeError("Chat session not initialized.")

            logger.info("Retrying last response due to parsing failure.")
            msg = "The previous response could not be parsed. Please conform to the format constraints."
            self._last_response = self._chat.send_message(msg)
            return self._last_response
        except Exception as e:
            logger.error(f"Error in retry_last: {e}")
            return ""

    def advance_session(self, outputs: list[CheckerOutput[ResultT]]) -> Optional[RawT]:
        self._current_turn += 1
        if self._current_turn >= self._max_turns:
            logger.info("Max turns reached. Ending session.")
            return None

        try:
            if self._chat is None:
                raise RuntimeError("Chat session not initialized.")

            feedback = self._feedback_formatter(outputs)
            logger.info(f"Turn {self._current_turn}. Feedback: {feedback}")
            self._last_response = self._chat.send_message(feedback)
            return self._last_response

        except Exception as e:
            logger.error(f"Error in advance_session: {e}")
            return None
