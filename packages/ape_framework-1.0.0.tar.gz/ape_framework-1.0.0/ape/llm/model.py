from abc import ABC, abstractmethod
from enum import StrEnum


class ModelChoice(StrEnum):
    GEMINI_3_PRO = "gemini-3-pro-preview"
    GEMINI_3_FLASH = "gemini-3-flash-preview"
    GEMINI_2_5_FLASH = "gemini-2.5-flash"
    GEMINI_2_5_PRO = "gemini-2.5-pro"


class ChatSession(ABC):
    @abstractmethod
    def send_message(self, message: str) -> str:
        """Sends a message to the chat session and returns the response text."""
        ...


class LLMModel(ABC):
    @abstractmethod
    def start_chat(self, system_instruction: str | None = None) -> ChatSession:
        """Starts a new chat session."""
        ...
