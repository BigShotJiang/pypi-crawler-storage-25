import logging

from .adapter import SolutionAdapter
from .checker import Checker, CheckerFactory, CheckerOutput
from .cli import CLI
from .report import Report
from .solver import Solver, SolverFactory
from .visualizer import Visualizer

# Prevent logging if the user did not configure it
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

__all__ = [
    "SolutionAdapter",
    "Checker",
    "CheckerFactory",
    "CheckerOutput",
    "CLI",
    "Report",
    "Solver",
    "SolverFactory",
    "Visualizer",
]
