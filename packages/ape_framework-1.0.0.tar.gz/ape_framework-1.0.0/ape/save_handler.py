import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Generic, Optional, cast

import jsonpickle

from .adapter import SolutionT
from .checker import ResultT
from .data import Data, SchemaT
from .runner.output import OutputBatch
from .runner.run_params import RunParams

logger = logging.getLogger(__name__)


class SaveHandler(Generic[SchemaT, SolutionT, ResultT]):
    """Responsible for handling the result file; so loading the save if it is present,
    and appending new output to it."""

    def __init__(
        self,
        run_params: RunParams,
        solver_params: dict[str, Any],
        checker_params: dict[str, Any],
    ):
        """Create a new save handler. If the output file exists, look for a save
        in it for cross-run persistence. If a save is present, the last saved data id is
        found and can be retrieved by calling `last_from_save`. The save format is JSONL for the output
        batches and JSON for run metadata.
        """
        self._save_file: Path = run_params.save_file
        self._metadata_file: Path = run_params.metadata_file
        self._last: Optional[str] = None

        self._save_file.parent.mkdir(parents=True, exist_ok=True)
        self._metadata_file.parent.mkdir(parents=True, exist_ok=True)

        if run_params.load_save:
            try:
                metadata = cast(
                    dict[str, Any], jsonpickle.decode(self._metadata_file.read_text())
                )
                _ = self._save_file.read_text()  # Run to ensure the file exists

                last_id = metadata.get("last_id")
                self._last = str(last_id) if last_id is not None else None

                logger.info(f"Save found and loaded. Last label: {self._last}.")
                return
            except FileNotFoundError:
                logger.info("No save found.")
            except Exception as e:
                logger.warning(
                    f"Tried to read save from file {self._save_file}, but the save is corrupted. "
                    f"Error encountered: {e}."
                )

        logger.info("Creating new save files.")
        try:
            self._save_file.touch(exist_ok=False)
        except FileExistsError:
            logger.critical(
                "Found save files when creating new files. Stopping to prevent data overwriting."
            )
            raise RuntimeError

        metadata = {
            "run_params": run_params,
            "solver_params": solver_params,
            "checker_params": checker_params,
            "start_date": datetime.now(),
        }
        metadata_payload = cast(
            str,
            jsonpickle.encode(metadata, unpicklable=True, make_refs=False),
        )
        self._metadata_file.write_text(metadata_payload)

    def last_from_save(self) -> str | None:
        """See which Data id was the last calculated in the previous run.

        Returns:
            id (str | None): the last id (or None if no save loaded).
        """
        return self._last

    def save(
        self,
        output_batch: OutputBatch[Data[SchemaT], SolutionT, ResultT],
    ) -> None:
        """Add the new results to the save file.

        Params:
            data (Data[SchemaT]): the data item the given batch is for
            solution_result_pairs (list[tuple[SolutionT, ResultT]]): a list of
                corresponding pairs (solution, result)
        """
        metadata = cast(
            dict[str, Any], jsonpickle.decode(self._metadata_file.read_text())
        )
        metadata["last_id"] = output_batch.input_data.id
        metadata["last_time"] = datetime.now()
        total = metadata.get("total", 0)
        metadata["total"] = int(total) + 1

        metadata_payload = cast(
            str,
            jsonpickle.encode(metadata, unpicklable=True, make_refs=False),
        )
        self._metadata_file.write_text(metadata_payload)

        with open(self._save_file, "a") as f:
            output_payload = cast(
                str,
                jsonpickle.encode(output_batch, unpicklable=True, make_refs=False),
            )
            f.write(output_payload + "\n")
            f.flush()
            os.fsync(f.fileno())
