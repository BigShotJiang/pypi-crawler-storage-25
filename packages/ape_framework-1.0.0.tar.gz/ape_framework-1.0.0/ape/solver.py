from abc import ABC, abstractmethod
from typing import Any, Generic, Optional, Type, TypeVar

from .adapter import RawT
from .checker import CheckerOutput, ResultT
from .data import DataT


class Solver(ABC, Generic[DataT, RawT, ResultT]):
    @abstractmethod
    def begin_session(self, data: DataT) -> RawT:
        """Starts the solving session and returns a first raw solution.
        Should only be called right after construction, or after advance_session returned None.
        """
        ...

    @abstractmethod
    def advance_session(self, outputs: list[CheckerOutput[ResultT]]) -> Optional[RawT]:
        """Receives the results of the previous solution and tries to make another one,
        or decides to stop here and return None.
        Should not be called again after returning None, or not until begin_session was called again.
        """
        ...

    @abstractmethod
    def retry_last(self) -> RawT:
        """Tries to generate the solution again, in an event that the previous raw solution
        could not be parsed.
        Should only be called after a call to begin_session or advance_session, if it returned something.
        """
        ...


SolverT = TypeVar("SolverT", bound=Solver)


class SolverFactory(Generic[SolverT]):
    def __init__(self, solver_cls: Type[SolverT], **kwargs: object) -> None:
        self._solver_cls = solver_cls
        self._kwargs = kwargs

    def create(self) -> SolverT:
        return self._solver_cls(**self._kwargs)

    def get_params(self) -> dict[str, Any]:
        return self._kwargs
