from abc import ABC, abstractmethod
from typing import Generic, TypeVar

RawT = TypeVar("RawT")
SolutionT = TypeVar("SolutionT")


class SolutionAdapter(ABC, Generic[RawT, SolutionT]):
    @classmethod
    @abstractmethod
    def adapt(cls, raw: RawT) -> list[SolutionT]: ...
