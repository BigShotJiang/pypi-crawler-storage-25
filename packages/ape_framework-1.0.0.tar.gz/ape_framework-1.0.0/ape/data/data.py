from __future__ import annotations

from pprint import pformat
from typing import Any, Callable, Generic, Type, TypeVar, overload

NO_NAME_STR = "_"

SchemaT = TypeVar("SchemaT")

ValueT = TypeVar("ValueT")


class Field(Generic[ValueT]):
    __name: str
    __dtype: Callable[[Any], ValueT]

    def __init__(self, dtype: Callable[[Any], ValueT], name: str = NO_NAME_STR) -> None:
        self.__dtype = dtype
        self.__name = name

    # If the name is not specified in the constructor it will default
    # to the name of the attribute in the schema class.
    def __set_name__(self, owner: Type[Any], name: str) -> None:
        if self.__name == NO_NAME_STR:
            self.__name = name

    @property
    def name(self) -> str:
        return self.__name

    @property
    def dtype(self) -> Callable[[Any], ValueT]:
        return self.__dtype

    @classmethod
    def required(
        cls, dtype: Type[ValueT], name: str = NO_NAME_STR
    ) -> RequiredField[ValueT]:
        return RequiredField(dtype, name)

    @classmethod
    def optional(
        cls, dtype: Type[ValueT], name: str = NO_NAME_STR
    ) -> OptionalField[ValueT]:
        return OptionalField(dtype, name)


class RequiredField(Field[ValueT]):
    pass


class OptionalField(Field[ValueT]):
    pass


class Data(Generic[SchemaT]):
    __id: str
    __storage: dict[str, Any]
    __schema_name: str | None

    def __init__(self, id: str, schema_name: str | None = None) -> None:
        self.__id = id
        self.__storage = {}
        self.__schema_name = schema_name

    def __str__(self) -> str:
        # Best-effort name extraction
        if self.__schema_name is not None:
            schema_name = self.__schema_name
        elif hasattr(self, "__orig_class__"):
            # Extract the schema name from the generic parameter
            schema = self.__orig_class__.__args__[0]
            schema_name = getattr(schema, "__name__", "Unknown Schema")
        else:
            schema_name = "Unknown Schema"

        lines = []
        for field, value in self.__storage.items():
            lines.append(f"'{field}': {pformat(value, sort_dicts=False)}")

        return schema_name + " {\n " + "\n ".join(lines) + "\n}"

    @property
    def id(self) -> str:
        return self.__id

    @overload
    def get(self, field: RequiredField[ValueT]) -> ValueT: ...

    @overload
    def get(self, field: OptionalField[ValueT]) -> ValueT | None: ...

    def get(self, field: Field[ValueT]) -> ValueT | None:
        return self.__storage.get(field.name)

    def set(self, field: Field[ValueT], value: Any) -> None:
        self.__storage[field.name] = field.dtype(value)


class SchemaMapper(Generic[SchemaT]):
    __key_map: dict[str, Field[Any]]
    __required_fields: list[RequiredField[Any]]

    def __init__(self, schema: Type[SchemaT]) -> None:
        self.__key_map = {}
        self.__required_fields = []

        for attr_name in dir(schema):
            attr_value = getattr(schema, attr_name)

            if isinstance(attr_value, Field):
                self.__key_map[attr_value.name] = attr_value

            if isinstance(attr_value, RequiredField):
                self.__required_fields.append(attr_value)

    @property
    def required_fields(self) -> list[RequiredField[Any]]:
        return self.__required_fields

    def get_field(self, key: str) -> Field[Any] | None:
        return self.__key_map.get(key)
