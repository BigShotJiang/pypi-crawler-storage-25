from __future__ import annotations

import csv
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Generic, Iterator, TextIO, Type

from .data import Data, Field, RequiredField, SchemaMapper, SchemaT


class DataProvider(ABC, Iterator[Data[SchemaT]], Generic[SchemaT]):
    __schema: Type[SchemaT]
    __mapper: SchemaMapper[SchemaT]
    _file: TextIO
    __iterator: Iterator[dict[str, Any]]

    def __init__(self, schema: Type[SchemaT], input: Path) -> None:
        self.__schema: Type[SchemaT] = schema
        self.__mapper: SchemaMapper[SchemaT] = SchemaMapper(schema)
        self._input_path: Path = Path(input)
        self._file: TextIO = open(self._input_path, mode="r", encoding="utf-8")
        self.__iterator: Iterator[dict[str, Any]] = self._get_iterator()

    def __del__(self) -> None:
        self._file.close()

    def __next__(self) -> Data[SchemaT]:
        # Current iterator position determines the record.
        # Raises StopIteration exception when there are none left.
        record = next(self.__iterator)

        # Extract ID separately from other fields to initiate Data.
        id_field = getattr(self.__schema, "id", None)
        if not isinstance(id_field, Field):
            raise ValueError("Schema doesn't define an 'id' Field.")

        record_id = record.get(id_field.name)
        if record_id is None:
            raise ValueError(f"Record doesn't have an id under '{id_field.name}' key.")

        data: Data[SchemaT] = Data[SchemaT](
            str(record_id), schema_name=self.__schema.__name__
        )

        found_required_fields: set[str] = set()

        # Extract all fields from the record.
        for key, value in record.items():
            field = self.__mapper.get_field(key)
            if field is None:
                raise ValueError(
                    f"Record contains '{key}' key, absent from the schema."
                )

            if value is None and isinstance(field, RequiredField):
                raise ValueError(
                    f"Record has None value for '{key}', but it's a required field."
                )

            data.set(field, value)

            if isinstance(field, RequiredField):
                found_required_fields.add(field.name)

        # Check if all required fields defined in the Schema were found.
        required_count = len(self.__mapper.required_fields)
        if len(found_required_fields) < required_count:
            missing = {
                f.name for f in self.__mapper.required_fields
            } - found_required_fields
            raise ValueError(f"Record {record_id} missing required fields: {missing}.")

        return data

    def seek(self, id: str) -> int:
        """Tries to find the data record with given ID. After this method is called,
        the record returned by calling `__next__` will be the one just after the found one.
        Returns the number of data records consumed by getting to the id.
        """
        count = 0
        try:
            while next(self).id != id:
                count += 1
            return count + 1
        except StopIteration:
            raise ValueError("Provided id not found.")

    @classmethod
    def load(cls, input: Path, schema: Type[SchemaT]) -> DataProvider[SchemaT]:
        file_extension = input.suffix.lower()

        if file_extension == ".csv":
            return CSVDataProvider(schema=schema, input=input)
        if file_extension == ".jsonl":
            return JSONLDataProvider(schema=schema, input=input)

        raise ValueError(f"No DataProvider for {file_extension} format.")

    @abstractmethod
    def count(self) -> int:
        """Returns the total amount of Data records in the file."""
        ...

    @abstractmethod
    def _get_iterator(self) -> Iterator[dict[str, Any]]: ...


class CSVDataProvider(DataProvider[SchemaT]):
    def _get_iterator(self) -> Iterator[dict[str, Any]]:
        return csv.DictReader(self._file)

    def count(self) -> int:
        with open(self._input_path, mode="r", encoding="utf-8") as fh:
            return sum(1 for _ in csv.DictReader(fh))


class JSONLDataProvider(DataProvider[SchemaT]):
    def _get_iterator(self) -> Iterator[dict[str, Any]]:
        for line in self._file:
            line = line.strip()
            if line:
                yield json.loads(line)

    def count(self) -> int:
        with open(self._input_path, mode="r", encoding="utf-8") as fh:
            return sum(1 for line in fh if line.strip())
