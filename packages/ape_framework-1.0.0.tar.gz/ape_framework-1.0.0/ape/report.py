from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Generic

from .adapter import SolutionT
from .checker import ResultT
from .data import DataT
from .runner import Output


class Report(ABC, Generic[DataT, SolutionT, ResultT]):

    @abstractmethod
    def __init__(self, output: Output[DataT, SolutionT, ResultT]) -> None: ...

    @abstractmethod
    def save(self, path: Path) -> None: ...

    @abstractmethod
    def dump_data(self, path: Path) -> None: ...
