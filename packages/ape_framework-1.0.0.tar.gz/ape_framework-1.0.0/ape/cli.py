from __future__ import annotations

import logging
import logging.config
from collections import deque
from contextlib import AbstractContextManager
from datetime import datetime
from pathlib import Path
from types import TracebackType
from typing import Any, Callable, Literal, Optional

from rich import box
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from .runner import Runner


class LogBufferHandler(logging.Handler):
    def __init__(self, add_entry: Callable[[dict[str, str]], None]) -> None:
        super().__init__()
        self._add_entry = add_entry

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = {
                "time": datetime.fromtimestamp(record.created).strftime("%H:%M:%S"),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
            }
            self._add_entry(entry)
        except Exception:
            self.handleError(record)


class CLI(AbstractContextManager):
    def __init__(
        self,
        runner: Runner,
        *,
        log_file: Path | str = Path("output/run.log"),
        log_level: int | str = logging.INFO,
    ) -> None:
        self._runner = runner
        self._log_file = Path(log_file)
        self._log_level = self._resolve_log_level(log_level)
        self._progress_task_id: Optional[TaskID] = None
        self._log_buffer: deque[dict[str, str]] = deque(maxlen=50)
        self._solver_statuses: list[dict[str, Any]] = []
        self._checker_statuses: list[dict[str, Any]] = []

    def __enter__(self) -> CLI:
        self._setup_logging()
        self._logger = logging.getLogger(__name__)
        self._console = Console()
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("{task.description}", justify="left"),
            BarColumn(bar_width=None),
            TaskProgressColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TimeElapsedColumn(),
            console=self._console,
            transient=False,
            expand=True,
        )
        self._log_handler = LogBufferHandler(self._add_log_entry)
        self._log_handler.setLevel(self._log_level)
        logging.getLogger().addHandler(self._log_handler)
        self._live = Live(
            self._render_dashboard(),
            console=self._console,
            refresh_per_second=8,
            transient=False,
        )
        self._live.start()
        self._progress.start()
        self._refresh_dashboard()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> Literal[False]:
        if self._live:
            self._live.stop()
        if self._progress:
            self._progress.stop()
        if self._log_handler:
            logging.getLogger().removeHandler(self._log_handler)
            self._log_handler.close()
        return False

    def run(self, *args: Any, **kwargs: Any) -> Any:
        self._logger.info("CLI runner starting")

        forwarded = dict(kwargs)
        forwarded.setdefault("progress_hook", self._progress_hook)
        forwarded.setdefault("worker_status_hook", self._status_hook)

        result = self._runner.run(*args, **forwarded)

        self._logger.info("CLI runner finished")
        return result

    def _progress_hook(self, done: int, total: int) -> None:
        # Initialize task on first call
        if self._progress_task_id is None:
            description = "Processing data"
            self._progress_task_id = self._progress.add_task(description, total=total)

        if self._progress_task_id is not None:
            self._progress.update(self._progress_task_id, completed=done, total=total)
        self._refresh_dashboard()

    def _status_hook(self, snapshot: dict[str, list[dict[str, Any]]]) -> None:
        self._solver_statuses = snapshot.get("solvers", [])
        self._checker_statuses = snapshot.get("checkers", [])
        self._refresh_dashboard()

    def _setup_logging(self) -> None:
        self._log_file.parent.mkdir(parents=True, exist_ok=True)

        logging.config.dictConfig(
            {
                "version": 1,
                "disable_existing_loggers": False,
                "formatters": {
                    "default": {
                        "format": "%(asctime)s %(name)s %(levelname)s %(message)s",
                    }
                },
                "handlers": {
                    "file": {
                        "class": "logging.FileHandler",
                        "level": self._log_level,
                        "formatter": "default",
                        "filename": str(self._log_file),
                        "encoding": "utf-8",
                    }
                },
                "root": {
                    "level": self._log_level,
                    "handlers": ["file"],
                },
            }
        )

    @staticmethod
    def _resolve_log_level(level: int | str) -> int:
        if isinstance(level, int):
            return level

        normalized = level.strip().upper()
        level_map = logging.getLevelNamesMapping()
        if normalized in level_map:
            return level_map[normalized]

        if normalized.isdigit():
            return int(normalized)

        raise ValueError(
            f"Invalid log level: {level!r}. Use a valid logging level name or integer."
        )

    def _add_log_entry(self, entry: dict[str, str]) -> None:
        self._log_buffer.append(entry)
        self._refresh_dashboard()

    def _refresh_dashboard(self) -> None:
        try:
            self._live.update(self._render_dashboard(), refresh=True)
        except Exception:
            # Avoid crashing the run due to rendering issues.
            return

    def _render_dashboard(self) -> Layout:
        layout = Layout(name="root")
        layout.split_column(
            Layout(self._render_progress_panel(), name="progress", size=4),
            Layout(self._render_workers_panel(), name="workers", ratio=2),
            Layout(self._render_logs_panel(), name="logs", ratio=3),
        )
        return layout

    def _render_progress_panel(self) -> Panel:
        if self._progress is None or self._progress_task_id is None:
            body: Any = "Waiting for progress updates..."
        else:
            body = self._progress

        return Panel(body, title="Run Progress", box=box.SIMPLE)

    def _render_workers_panel(self) -> Panel:
        solvers = Table(
            show_header=True,
            header_style="bold",
            expand=True,
            box=box.SIMPLE,
            padding=(0, 0),
            title="Solvers",
            title_style="bold",
        )
        solvers.add_column("Solver", justify="center")
        solvers.add_column("State", justify="center")
        solvers.add_column("Data", justify="center")
        solvers.add_column("Runs completed", justify="center")
        solvers.add_column("Session length", justify="center")

        if not self._solver_statuses:
            solvers.add_row("-", "-", "-", "-", "-")
        else:
            for st in self._solver_statuses:
                solvers.add_row(
                    str(st.get("id", "-")),
                    str(st.get("state", "-")),
                    str(st.get("data_id", "-")),
                    f"{st.get('curr_run', '-')}/{st.get('total_runs', '-')}",
                    str(st.get("session_length", "-")),
                )

        checkers = Table(
            show_header=True,
            header_style="bold",
            expand=True,
            box=box.SIMPLE,
            padding=(0, 0),
            title="Checkers",
            title_style="bold",
        )
        checkers.add_column("Checker", justify="center")
        checkers.add_column("State", justify="center")
        checkers.add_column("Data", justify="center")
        checkers.add_column("From solver", justify="center")

        if not self._checker_statuses:
            checkers.add_row("-", "-", "-", "-")
        else:
            for st in self._checker_statuses:
                checkers.add_row(
                    str(st.get("id", "-")),
                    str(st.get("state", "-")),
                    str(st.get("data_id", "-")),
                    str(st.get("solver_id", "-")),
                )

        grid = Table.grid(expand=True)
        grid.add_column(ratio=1)
        grid.add_column(ratio=1)
        grid.add_row(solvers, checkers)

        return Panel(grid, box=box.SIMPLE)

    def _render_logs_panel(self) -> Panel:
        table = Table(
            show_header=True,
            header_style="bold",
            expand=True,
            box=box.SIMPLE,
            padding=(0, 0),
        )
        table.add_column("Time", style="dim", width=8, no_wrap=True)
        table.add_column("Level", width=8, no_wrap=True)
        table.add_column("Logger", style="dim", width=20, no_wrap=True)
        table.add_column("Message", overflow="fold")

        if not self._log_buffer:
            table.add_row("-", "-", "-", "Waiting for logs...")
        else:
            max_rows = 6
            if self._console is not None:
                max_rows = max(6, min(30, self._console.size.height - 12))

            for entry in reversed(list(self._log_buffer)[-max_rows:]):
                table.add_row(
                    entry.get("time", ""),
                    entry.get("level", ""),
                    entry.get("logger", ""),
                    entry.get("message", ""),
                )
                table.add_section()

        return Panel(table, title="Latest Logs", box=box.SIMPLE, padding=(0, 0))
