import logging
from concurrent.futures import ThreadPoolExecutor
from queue import Empty, Queue
from threading import Event, Lock
from typing import Any, Callable, Optional, Type

from ..adapter import RawT, SolutionAdapter, SolutionT
from ..checker import Checker, CheckerFactory, CheckerOutput, ResultT
from ..data import Data, DataProvider, SchemaT
from ..save_handler import SaveHandler
from ..solver import Solver, SolverFactory
from .checker_worker import checker_worker
from .monitor import WorkerStatusTracker
from .output import OutputBatch
from .run_params import RunParams
from .solver_worker import solver_worker

logger = logging.getLogger(__name__)


class Runner:
    @classmethod
    def run(
        cls,
        solver_factory: SolverFactory[Solver[Data[SchemaT], RawT, ResultT]],
        checker_factory: CheckerFactory[Checker[Data[SchemaT], SolutionT, ResultT]],
        adapter_cls: Type[SolutionAdapter[RawT, SolutionT]],
        data_provider: DataProvider[SchemaT],
        params: Optional[RunParams] = None,
        progress_hook: Optional[Callable[[int, int], None]] = None,
        worker_status_hook: Optional[
            Callable[[dict[str, list[dict[str, Any]]]], None]
        ] = None,
    ) -> None:
        if params is None:
            params = RunParams()

        logger.info(f"Runner started with params: {params}.")
        logger.info(f"Checker params: {checker_factory.get_params()}.")
        logger.info(f"Solver params: {solver_factory.get_params()}.")

        save_handler: SaveHandler[SchemaT, SolutionT, ResultT] = SaveHandler(
            params, solver_factory.get_params(), checker_factory.get_params()
        )
        total_data_count = data_provider.count()

        if params.load_save:
            last = save_handler.last_from_save()
            if last is not None:
                consumed = data_provider.seek(last)
                total_data_count -= consumed

        # Solvers will consume data items from this queue. We limit the queue size so that we do not
        # preload too much data at once.
        data_q: Queue[Data[SchemaT] | None] = Queue(params.data_q_capacity)

        # Solvers will pass their solutions here so that checkers can consume them
        solutions_q: Queue[tuple[Data[SchemaT], int, list[SolutionT]] | None] = Queue()

        # Checkers will output results to the queue corresponding with the solver the request came from
        result_qs: dict[int, Queue[list[CheckerOutput[ResultT]] | None]] = {
            idx: Queue() for idx in range(params.solver_workers)
        }
        rqs_lock = Lock()

        # Solvers will pass the final results here for us to aggregate
        outputs_q: Queue[OutputBatch[Data[SchemaT], SolutionT, ResultT]] = Queue()

        def emit_progress(done: int) -> None:
            if progress_hook is None:
                return
            try:
                progress_hook(done, total_data_count)
            except Exception as exc:
                logger.debug(f"Progress hook raised an exception: {exc}")

        emit_progress(0)

        # If worker hook is None, then calling this will do nothing.
        status_tracker = WorkerStatusTracker(
            params.solver_workers,
            params.checker_workers,
            worker_status_hook,
        )

        max_workers = params.checker_workers + params.solver_workers + 1
        executor = ThreadPoolExecutor(max_workers)

        helper_future = None
        stopped = False
        cancel = Event()

        try:
            for checker_id in range(params.checker_workers):
                executor.submit(
                    checker_worker,
                    checker_id,
                    checker_factory.create(),
                    solutions_q,
                    result_qs,
                    rqs_lock,
                    status_tracker.checker_cb,
                    cancel,
                )

            for idx in range(params.solver_workers):
                executor.submit(
                    solver_worker,
                    idx,
                    params,
                    solver_factory.create(),
                    adapter_cls,
                    data_q,
                    solutions_q,
                    result_qs[idx],
                    outputs_q,
                    status_tracker.solver_cb,
                    cancel,
                )

            # Helper thread that will insert data items into the queue. We don't want
            # the main thread blocking on this operation, so this simplifies the logic.
            def inserter(cancel: Event) -> None:
                logger.debug("Data inserter helper started.")

                for data_item in data_provider:
                    if cancel.is_set():
                        logger.info("Inserter was interrupted. Stopping.")
                        return
                    data_q.put(data_item)

                logger.debug("Inserter finished.")

            helper_future = executor.submit(inserter, cancel)

            collected = 0

            while collected < total_data_count:
                status_tracker.drain()

                if helper_future.done():
                    exc = helper_future.exception()
                    if exc is not None:
                        raise exc

                try:
                    output_batch = outputs_q.get(timeout=1)
                    save_handler.save(output_batch)
                    logger.info(
                        f"Processing finished for data item with id {output_batch.input_data.id}. "
                        f"Generated {len(output_batch)} outputs."
                    )
                    collected += 1
                    emit_progress(collected)
                except Empty:
                    continue
            logger.info("Run completed. Stopping all workers.")
        except KeyboardInterrupt:
            stopped = True
            logger.info("Interrupt received. Stopping workers immediately.")
            cancel.set()
            # Empty the queue so helper wakes up
            while True:
                try:
                    data_q.get_nowait()
                except Empty:
                    break
        finally:
            status_tracker.drain()
            # Make the queue infinite for no blocking
            data_q.maxsize = -1

            # Put sentinels so solvers wake up
            with rqs_lock:
                for i in range(params.solver_workers):
                    data_q.put(None)
                    result_qs[i].put(None)

            # Insert sentinels so checkers stop
            for _ in range(params.checker_workers):
                solutions_q.put(None)
            executor.shutdown(wait=True)

        if stopped:
            logger.info("Runner interrupted before completion.")
            raise KeyboardInterrupt
        else:
            logger.info("Runner finished.")
