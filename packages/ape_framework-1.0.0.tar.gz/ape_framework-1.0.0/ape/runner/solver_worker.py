import logging
import time
from datetime import timedelta
from queue import Queue
from threading import Event
from typing import Optional, Type, cast

from ..adapter import RawT, SolutionAdapter, SolutionT
from ..checker import CheckerOutput, ResultT
from ..data import Data, SchemaT
from ..solver import Solver
from .monitor import SolverHookType
from .output import OutputBatch
from .run_params import RunParams

logger = logging.getLogger(__name__)


class TooManyAttempts(Exception): ...


def _assert_solution_batch_size(
    solver_id: int, solution_batch: list[SolutionT], size: Optional[int]
) -> None:
    if size is None:
        return

    if size != len(solution_batch):
        logger.warning(
            f"Solver {solver_id} generated an incorrect number of solutions. "
            f"Expected: {size}, got: {len(solution_batch)}."
        )
        raise ValueError


def _assert_batches_match(
    solver_id: int,
    solution_batch: list[SolutionT],
    checker_output_batch: list[CheckerOutput[ResultT]],
) -> None:
    if len(solution_batch) != len(checker_output_batch):
        raise ValueError(
            f"Length mismatch in Solver {solver_id}: "
            f"solution_batch has {len(solution_batch)} elements, "
            f"but checker_output_batch has {len(checker_output_batch)} elements."
        )


def _solver_try_generate(
    solver_id: int,
    data_item: Data[SchemaT],
    solver: Solver[Data[SchemaT], RawT, ResultT],
    adapter_cls: Type[SolutionAdapter[RawT, SolutionT]],
    params: RunParams,
    cancel: Event,
    checker_output_batch: Optional[list[CheckerOutput[ResultT]]] = None,
) -> tuple[Optional[list[SolutionT]], Optional[timedelta]]:
    attempts_left: int = params.attempts_allowed_per_data
    first_attempt = True
    while True:
        if cancel.is_set():
            raise InterruptedError
        try:
            raw: Optional[RawT]
            gen_time_start = time.perf_counter()
            if first_attempt:
                if checker_output_batch is None:
                    raw = solver.begin_session(data_item)
                else:
                    raw = solver.advance_session(checker_output_batch)
                    # Solver ended
                    if raw is None:
                        return None, None
            else:
                raw = solver.retry_last()
            gen_time_end = time.perf_counter()

            solution_batch: list[SolutionT] = adapter_cls.adapt(raw)
            _assert_solution_batch_size(
                solver_id, solution_batch, params.solutions_expected
            )
            return solution_batch, timedelta(seconds=gen_time_end - gen_time_start)
        except Exception as e:
            attempts_left -= 1
            first_attempt = False
            logger.debug(f"Solver {solver_id} error while generating solutions: {e}")
            logger.warning(
                f"Solver {solver_id} failed to generate a batch of solutions. "
                f"{attempts_left} fails left."
            )
            if attempts_left == 0:
                raise TooManyAttempts


def solver_worker(
    solver_id: int,
    params: RunParams,
    solver: Solver[Data[SchemaT], RawT, ResultT],
    adapter_cls: Type[SolutionAdapter[RawT, SolutionT]],
    data_q: Queue[Data[SchemaT] | None],
    solutions_q: Queue[tuple[Data[SchemaT], int, list[SolutionT]] | None],
    result_q: Queue[list[CheckerOutput[ResultT]] | None],
    outputs_q: Queue[OutputBatch[Data[SchemaT], SolutionT, ResultT]],
    status_cb: SolverHookType,
    cancel: Event,
) -> None:
    logger.debug(f"Solver {solver_id} starting.")
    status_cb(
        solver_id,
        state="idle",
        data_id=None,
        curr_run=0,
        total_runs=params.runs_per_data,
        session_length=0,
    )

    for data_item in iter(data_q.get, None):
        logger.debug(f"Solver {solver_id} got data with id {data_item.id}.")
        output_batch: OutputBatch = OutputBatch(
            input_data=data_item,
            solutions=[],
            checker_outputs=[],
            solution_runtimes=[],
            solution_total_times=[],
        )

        status_cb(
            solver_id,
            state="busy",
            data_id=data_item.id,
            curr_run=0,
            total_runs=params.runs_per_data,
            session_length=0,
        )

        try:
            for i in range(params.runs_per_data):
                status_cb(
                    solver_id,
                    state="busy",
                    data_id=data_item.id,
                    curr_run=i,
                    total_runs=params.runs_per_data,
                    session_length=0,
                )

                # Kickstart the solution generation
                time_start = time.perf_counter()
                new_batch, new_gen_time = _solver_try_generate(
                    solver_id, data_item, solver, adapter_cls, params, cancel
                )
                time_end = time.perf_counter()
                total_gen_time = timedelta(seconds=time_end - time_start)

                session_length = 0
                while new_batch is not None:
                    assert new_gen_time is not None
                    solution_batch = new_batch
                    gen_time = new_gen_time
                    session_length += 1
                    status_cb(
                        solver_id,
                        state="busy",
                        data_id=data_item.id,
                        curr_run=i,
                        total_runs=params.runs_per_data,
                        session_length=session_length,
                    )

                    # Get the result batch from the checker
                    solutions_q.put((data_item, solver_id, solution_batch))
                    checker_opt_batch: list[CheckerOutput[ResultT]] | None = (
                        result_q.get()
                    )
                    # We need to check here because the output might be a None sentinel
                    # to wake us up
                    if cancel.is_set():
                        raise InterruptedError
                    assert checker_opt_batch is not None
                    checker_output_batch: list[CheckerOutput[ResultT]] = (
                        checker_opt_batch
                    )
                    _assert_batches_match(
                        solver_id, solution_batch, checker_output_batch
                    )
                    # Attempt to generate a new batch based off of results. If none,
                    # then it means the solver decided to end the session.
                    time_start = time.perf_counter()
                    new_batch, new_gen_time = _solver_try_generate(
                        solver_id,
                        data_item,
                        solver,
                        adapter_cls,
                        params,
                        cancel,
                        checker_output_batch,
                    )
                    time_end = time.perf_counter()
                    total_gen_time += timedelta(seconds=time_end - time_start)

                if session_length == 0 or len(solution_batch) == 0:
                    logger.warning(
                        f"Solver {solver_id} failed to generate any data for a run "
                        f"on data with id {data_item.id}."
                    )
                    continue

                # Extend with the last (hopefully the best) generated output
                # In gen_time we have the time it took for the final request to go through
                # on the solver's side. This is the time it took to generate all solutions in this
                # one batch, so we need to average the time. (We have no way of calculating exact times
                # for each solution, because they come from one RawT)
                # In total_gen_time we have the total time that was spent in the solver to produce the
                # final result; all retries are counted. We have to average it out similarily
                avg: timedelta = cast(timedelta, gen_time / len(solution_batch))
                solution_runtimes: list[timedelta] = [avg] * len(solution_batch)
                avg_total: timedelta = cast(
                    timedelta, total_gen_time / len(solution_batch)
                )
                solution_total_times: list[timedelta] = [avg_total] * len(
                    solution_batch
                )

                output_batch.extend(
                    OutputBatch(
                        input_data=data_item,
                        solutions=solution_batch,
                        checker_outputs=checker_output_batch,
                        solution_runtimes=solution_runtimes,
                        solution_total_times=solution_total_times,
                    )
                )

        except TooManyAttempts:
            logger.warning(
                f"Solver {solver_id} failed too many times when trying to generate "
                f"solutions for data with id {data_item.id}. Skipping for this data."
            )
        except InterruptedError:
            logger.info(f"Solver {solver_id} was interrupted. Stopping.")
            return

        outputs_q.put(output_batch)
        logger.debug(
            f"Solver {solver_id} completed data {data_item.id} with {len(output_batch)} results."
        )

        status_cb(
            solver_id,
            state="idle",
            data_id=None,
            curr_run=0,
            total_runs=0,
            session_length=0,
        )
    logger.debug(f"Solver {solver_id} finished.")
