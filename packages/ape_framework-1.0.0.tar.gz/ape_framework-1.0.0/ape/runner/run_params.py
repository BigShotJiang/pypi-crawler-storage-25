from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class RunParams:
    """Parameters that can be passed to the `Runner` class methods."""

    save_file: Path = Path("output/results.jsonl")
    """Where to save results during a run to prevent lost progress."""
    metadata_file: Path = Path("output/metadata.json")
    """Where to save metadata about the run."""
    checker_workers: int = 1
    """How many checker workers should be created."""
    solver_workers: int = 1
    """How many solver workers should be created."""
    data_q_capacity: int = 10
    """How many data items should the queue be able to hold."""
    runs_per_data: int = 1
    """How many solver sessions should be attempted for each data item."""
    load_save: bool = True
    """Should the save handler attempt to load the save from the provided save file."""
    attempts_allowed_per_data: int = 3
    """How many times can the solver try (and possibly fail) to generate a solution batch per data item."""
    solutions_expected: Optional[int] = None
    """How many solutions should the adapter be able to extract from each solver raw solution."""
