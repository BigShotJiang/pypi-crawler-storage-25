from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Any, Generic, Iterator, cast

import jsonpickle

from ..adapter import SolutionT
from ..checker import CheckerOutput, ResultT
from ..data import DataT


@dataclass
class OutputBatch(Generic[DataT, SolutionT, ResultT]):
    input_data: DataT
    solutions: list[SolutionT]
    solution_runtimes: list[timedelta]
    """These are the times that the solver took to generate each of the solutions."""
    solution_total_times: list[timedelta]
    """These are the times that the solver took to generate each of the solutions, but
    also counting in all the retries that happened to get to the final result."""
    checker_outputs: list[CheckerOutput[ResultT]]

    def __post_init__(self) -> None:
        # Uses a set to easily check for all equalities
        lengths = {
            len(self.solutions),
            len(self.solution_runtimes),
            len(self.solution_total_times),
            len(self.checker_outputs),
        }
        if len(lengths) != 1:
            raise ValueError("All batches must have the same size.")

    def extend(self, other: OutputBatch[DataT, SolutionT, ResultT]) -> None:
        assert self.input_data == other.input_data
        self.solutions.extend(other.solutions)
        self.solution_runtimes.extend(other.solution_runtimes)
        self.solution_total_times.extend(other.solution_total_times)
        self.checker_outputs.extend(other.checker_outputs)

    def __len__(self) -> int:
        return len(self.solutions)

    def __iter__(
        self,
    ) -> Iterator[tuple[SolutionT, timedelta, timedelta, CheckerOutput[ResultT]]]:
        yield from zip(
            self.solutions,
            self.solution_runtimes,
            self.solution_total_times,
            self.checker_outputs,
        )


@dataclass(init=False)
class Output(Generic[DataT, SolutionT, ResultT]):
    metadata: dict[str, Any]
    results: list[OutputBatch[DataT, SolutionT, ResultT]]

    def __init__(
        self,
        metadata_file: Path | str,
        results_file: Path | str,
    ) -> None:
        metadata_payload = Path(metadata_file).read_text(encoding="utf-8")
        self.metadata = cast(dict[str, Any], jsonpickle.decode(metadata_payload))

        self.results = []
        with open(results_file, "r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                payload = line.strip()
                if not payload:
                    continue

                decoded = jsonpickle.decode(payload)
                if not isinstance(decoded, OutputBatch):
                    raise ValueError(
                        f"Line {i} in {results_file} does not decode to OutputBatch."
                    )

                self.results.append(
                    cast(OutputBatch[DataT, SolutionT, ResultT], decoded)
                )
