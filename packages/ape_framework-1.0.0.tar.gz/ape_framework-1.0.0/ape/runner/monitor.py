from __future__ import annotations

import logging
from queue import Empty, SimpleQueue
from threading import Lock
from typing import Any, Callable, Optional, Protocol


class SolverHookType(Protocol):
    def __call__(
        self,
        solver_id: int,
        *,
        state: str,
        data_id: Optional[Any],
        curr_run: int,
        total_runs: int,
        session_length: int,
    ) -> None: ...


class CheckerHookType(Protocol):
    def __call__(
        self,
        checker_id: int,
        *,
        state: str,
        data_id: Optional[Any],
        solver_id: Optional[int],
    ) -> None: ...


logger = logging.getLogger(__name__)


class WorkerStatusTracker:
    """Thread-safe tracker that batches worker status snapshots.

    Workers call the setter callbacks; the main thread should periodically
    call ``drain`` to deliver snapshots to the provided hook.
    """

    def __init__(
        self,
        solver_workers: int,
        checker_workers: int,
        hook: Optional[Callable[[dict[str, list[dict[str, Any]]]], None]],
    ) -> None:
        self._hook: Optional[Callable[[dict[str, list[dict[str, Any]]]], None]] = hook
        self._lock: Lock = Lock()
        self._updates: SimpleQueue[dict[str, list[dict[str, Any]]]] = SimpleQueue()
        self._solvers: dict[int, dict[str, Any]] = {
            idx: {
                "id": idx,
                "state": "idle",
                "data_id": None,
                "curr_run": 0,
                "total_runs": 0,
                "session_length": 0,
            }
            for idx in range(solver_workers)
        }
        self._checkers: dict[int, dict[str, Any]] = {
            idx: {"id": idx, "state": "idle", "data_id": None, "solver_id": None}
            for idx in range(checker_workers)
        }
        self._enqueue_snapshot()

    def solver_cb(
        self,
        solver_id: int,
        *,
        state: str,
        data_id: Optional[Any],
        curr_run: int,
        total_runs: int,
        session_length: int,
    ) -> None:
        with self._lock:
            if self._hook is None:
                return
            solver_state = self._solvers.get(solver_id)
            if solver_state is None:
                raise ValueError(f"Unknown Solver of id {solver_id}.")
            solver_state.update(
                {
                    "state": state,
                    "data_id": data_id,
                    "curr_run": curr_run,
                    "total_runs": total_runs,
                    "session_length": session_length,
                }
            )
        self._enqueue_snapshot()

    def checker_cb(
        self,
        checker_id: int,
        *,
        state: str,
        data_id: Optional[Any],
        solver_id: Optional[int],
    ) -> None:
        with self._lock:
            if self._hook is None:
                return
            checker_state = self._checkers.get(checker_id)
            if checker_state is None:
                raise ValueError(f"Unknown Checker of id {checker_id}.")
            checker_state.update(
                {
                    "state": state,
                    "data_id": data_id,
                    "solver_id": solver_id,
                }
            )
        self._enqueue_snapshot()

    def drain(self) -> None:
        """Deliver any queued snapshots to the hook from the caller thread."""
        with self._lock:
            if self._hook is None:
                return

            while True:
                try:
                    snapshot = self._updates.get_nowait()
                except Empty:
                    break

                try:
                    self._hook(snapshot)
                except Exception as e:
                    logger.debug(f"Worker status hook raised an exception: {e}")
                    # Reset the hook and empty the queue
                    self._hook = None
                    while True:
                        try:
                            self._updates.get_nowait()
                        except Empty:
                            return

    def _enqueue_snapshot(self) -> None:
        with self._lock:
            snapshot = {
                "solvers": list(self._solvers.values()),
                "checkers": list(self._checkers.values()),
            }
            self._updates.put(snapshot)
