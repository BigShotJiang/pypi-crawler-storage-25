import logging
from queue import Queue
from threading import Event, Lock

from ..adapter import SolutionT
from ..checker import Checker, CheckerOutput, ResultT
from ..data import Data, SchemaT
from .monitor import CheckerHookType

logger = logging.getLogger(__name__)


def checker_worker(
    checker_id: int,
    checker: Checker[Data[SchemaT], SolutionT, ResultT],
    solutions_q: Queue[tuple[Data[SchemaT], int, list[SolutionT]] | None],
    result_qs: dict[int, Queue[list[CheckerOutput[ResultT]] | None]],
    rqs_lock: Lock,
    status_cb: CheckerHookType,
    cancel: Event,
) -> None:
    logger.debug(f"Checker {checker_id} starting.")
    status_cb(checker_id, state="idle", data_id=None, solver_id=None)

    for item in iter(solutions_q.get, None):
        data_item, solver_id, solution_batch = item
        status_cb(
            checker_id,
            state="busy",
            data_id=data_item.id,
            solver_id=solver_id,
        )

        if cancel.is_set():
            logger.info(f"Checker {checker_id} interrupted. Stopping.")
            return

        checker_output = checker.check(data_item, solution_batch)

        with rqs_lock:
            ch = result_qs.get(solver_id)
        if ch is not None:
            ch.put(checker_output)
        else:
            raise RuntimeError(
                f"Checker {checker_id} tried to return results to a solver channel that doesn't exist."
            )

        logger.debug(
            f"Checker {checker_id} finished for data with id {data_item.id} and Solver {solver_id}."
        )
        status_cb(checker_id, state="idle", data_id=None, solver_id=None)

    logger.debug(f"Checker {checker_id} finished.")
