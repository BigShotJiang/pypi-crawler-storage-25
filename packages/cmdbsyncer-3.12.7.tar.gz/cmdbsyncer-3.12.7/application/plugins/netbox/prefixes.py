"""
Create Prefixes in Netbox
"""

from .netbox import SyncNetbox

class SyncPrefixes(SyncNetbox):
    """
    Netbox Prefix Operations
    """
    console = None

#   .--- Sync Cluster
    def sync_prefixes(self):
        """
        Update Prefixes in Netbox
        """
        current_objects = self.nb.ipam.prefixes
        self.sync_generic('Prefix', current_objects,
                          'prefix', list_mode='prefixes',
                          prevent_duplicates='prefix')
#.
