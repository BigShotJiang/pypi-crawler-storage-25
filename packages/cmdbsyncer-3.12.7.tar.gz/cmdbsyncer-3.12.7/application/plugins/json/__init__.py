"""JSON import plugin."""
import click
from application import app
from application.helpers.cron import register_cronjob
from application.helpers.plugins import register_cli_group

from .json import import_hosts_json

_cli_json = register_cli_group(app, 'json', 'json', "JSON File Import/ Inventorize")

@_cli_json.command('import_hosts')
@click.argument("account")
@click.option("--debug", default=False, is_flag=True)
def import_hosts(account, debug):
    """
    ## Import Hosts from JSON File
    """
    import_hosts_json(account, debug)


register_cronjob('JSON FILE: Import Hosts', import_hosts_json)
