import io
import threading
import queue
from typing import Any, Callable

_ALL_TASK_NAMES: set[str] = set()


class BackgroundStream:
    """A wrapper for background thread execution with a thread-safe queue."""

    def __init__(self) -> None:
        self._thread: threading.Thread | None = None
        self._queue: queue.Queue[str] | None = None
        self._started: bool = False
        self._stopped: bool = False
        self._stop_function: Callable[[], Any] | None = None
        self._input_function: Callable[[str], Any] | None = None
        self._lock = threading.Lock()
        self._success = False
        self._output = io.StringIO()

    def success(self) -> bool:
        return self._success

    def start(self, function: Callable[[queue.Queue[str]], Any], stop_function: Callable[[], Any], input_function: Callable[[str], Any] | None = None) -> None:
        """Start the background thread with the given function.

        Args:
            function: A callable that accepts a queue.Queue[str] as its argument.
                     The function can put strings into the queue for retrieval by other threads.
        """
        with self._lock:
            if self._started:
                return

            self._queue = queue.Queue()

            def func(v: BackgroundStream, function: Callable[[queue.Queue[str]], Any]) -> None:
                v._success = False if function(v._queue) == False else True # defaultly success
            self._thread = threading.Thread(
                target=func, args=(self, function), daemon=True)
            self._stop_function = stop_function
            self._input_function = input_function
            self._started = True
        self._thread.start()

    def input(self, data: str) -> bool:
        if self._input_function:
            return bool(self._input_function(data))
        return False

    def thread_is_alive(self) -> bool:
        with self._lock:
            return self._thread is not None and self._thread.is_alive()

    def wait(self, timeout: float | None = None) -> None:
        """Wait for the background thread to complete."""
        if not self.thread_is_alive():
            return
        thread = self._thread
        if thread is None:
            return
        thread.join(timeout=timeout)
        if not thread.is_alive():
            with self._lock:
                self._thread = None

    def get_output(self) -> str:
        if self._queue is None:
            return self._output.getvalue()

        while True:
            try:
                self._output.write(self._queue.get_nowait())
            except queue.Empty:
                break
        return self._output.getvalue()

    def pop_output(self) -> str:
        output = self.get_output()
        self._output.truncate(0)
        self._output.seek(0)
        return output

    def get_queue(self) -> queue.Queue[str] | None:
        """Get the thread-safe queue for retrieving messages.

        Returns:
            The queue if started, None otherwise.
        """
        return self._queue

    def is_started(self) -> bool:
        """Check if the stream has been started."""
        return self._started

    def is_stopped(self) -> bool:
        """Check if the stream has been stopped."""
        return self._stopped

    def stop(self) -> bool:
        """Stop the background thread.

        Returns:
            True if the thread was stopped, False if it was not running.
        """
        with self._lock:
            if not self._started or self._stopped:
                return False
            self._stopped = True
            thread_alive = self._thread is not None and self._thread.is_alive()
            stop_func = self._stop_function if thread_alive else None

        if stop_func is not None:
            try:
                stop_func()
            except Exception:
                pass
        return thread_alive


_ALL_TASK: dict[str, BackgroundStream] = dict()

def generate_task_id(kind: str, name: str | None = None) -> str:
    values = [kind]
    if name:
        values.append(name)
    base_id = '_'.join(values)

    # Ensure uniqueness by checking _ALL_TASK_NAMES
    task_id = base_id
    counter = 1
    while task_id in _ALL_TASK_NAMES:
        task_id = f"{base_id}_{counter}"
        counter += 1
    _ALL_TASK_NAMES.add(task_id)
    return task_id


def remove_task_id(task_id: str) -> BackgroundStream | None:
    """Remove a task_id from the global task names set.

    Args:
        task_id: The task identifier to remove.
    """
    try:
        _ALL_TASK_NAMES.discard(task_id)
        return _ALL_TASK.pop(task_id)
    except:
        pass
    return None


def add_task(task_id: str, stream: BackgroundStream) -> None:
    """Add a task to the global task registry.

    Args:
        task_id: Unique identifier for the task.
        stream: The BackgroundStream instance to manage (should already be started).
    """
    _ALL_TASK[task_id] = stream
    _ALL_TASK_NAMES.add(task_id)


def get_all_tasks() -> dict[str, BackgroundStream]:
    return _ALL_TASK


def join_task(task_id: str) -> bool:
    """Join a task and clean up its resources.

    Args:
        task_id: The task identifier to join.

    Returns:
        True if the task was found and joined, False otherwise.
    """
    if task_id not in _ALL_TASK:
        return False

    stream = _ALL_TASK.pop(task_id)
    stream.wait()
    _ALL_TASK_NAMES.discard(task_id)
    return True
