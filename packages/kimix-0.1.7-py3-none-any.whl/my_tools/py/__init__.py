import sys
import os
from pathlib import Path

import anyio
from my_tools.common import _maybe_export_output_async, _export_to_temp_file_async, ProcessTask
from kimi_agent_sdk import CallableTool2, ToolError, ToolOk, ToolReturnValue
from pydantic import BaseModel, Field


class Params(BaseModel):
    code: str = Field(
        description="Python code to execute.",
    )
    dest: str | None = Field(
        default=None,
        description="Output file path (optional)."
    )
    timeout: int = Field(
        default=10,
        ge=1,
        le=60,
        description="Timeout in seconds."
    )
    run_in_background: bool = Field(
        default=False,
        description="Run in an independent background process. Returns immediately with a task_id. Use TaskList, TaskOutput, and TaskWait to manage."
    )


# Force UTF-8 encoding for subprocess on Windows
os.environ['PYTHONIOENCODING'] = 'utf-8'


class Python(CallableTool2[Params]):
    name: str = "Python"
    description: str = "Execute Python code in subprocess."
    params: type[Params] = Params

    async def __call__(self, params: Params) -> ToolReturnValue:
        # Handle background execution
        if params.run_in_background:
            return await self._run_in_background(params)

        task = ProcessTask(sys.executable, ['-u', '-c', params.code], None, params.timeout)
        task_id = task.start("python", "python")

        # Wait for completion with timeout (allow a small buffer for cleanup)
        wait_timeout = params.timeout
        await anyio.to_thread.run_sync(task.wait, wait_timeout)

        if task.thread_is_alive():
            return ToolError(
                output=f'Running in background. task_id: `{task_id}`. use `TaskOutput` or `TaskStop` tool',
                message="Python execution timeout",
                brief="Timeout"
            )
        # Clean up foreground task registration
        from my_tools.background.utils import remove_task_id
        remove_task_id(task_id)
        # Get output
        output = task.stream.pop_output() if task.stream else ""

        # Handle dest parameter if provided
        if params.dest:
            async with await anyio.open_file(params.dest, 'w', encoding='utf-8', errors='replace') as f:
                await f.write(output)
            output = f'output exported to: {params.dest}'
        else:
            output = await _maybe_export_output_async(output)

        # Check success
        success = task.stream.success() if task.stream else False



        if not success:
            if output and not params.dest:
                temp_path, _ = await _export_to_temp_file_async(key=None, content=output, ext='.txt')
                output = f'saved to file `{temp_path}`'
            return ToolError(
                output=output,
                message="Python execution failed",
                brief="Python execution error"
            )

        return ToolOk(output=output)

    async def _run_in_background(self, params: Params) -> ToolReturnValue:
        """Run Python code in the background and register it as a background task.

        Args:
            params: The Python execution parameters.

        Returns:
            ToolOk with task_id on success, ToolError on failure.
        """
        try:
            task = ProcessTask(sys.executable, ['-u', '-c', params.code], None, params.timeout)
            task_id = task.start("python", "python")

            # Return success with task_id
            return ToolOk(
                output=f"Python process started in background.\nTask ID: {task_id}\n\nUse 'TaskList' to view all tasks, 'TaskOutput' to get output, 'TaskStop' to kill process, 'Input' to input to process."
            )

        except Exception as exc:
            return ToolError(
                output="",
                message=f"Failed to start background Python process: {str(exc)}",
                brief="Failed to start background task"
            )
