"""Smoke tests covering the diagnostic path and the public defence API.

These are not a substitute for the full benchmark reproduction (run via
``goodhart-bench run``); they are quick checks that the underlying
``cba_match_rate`` plumbing and the defence wrappers behave correctly on
three control cases (honest, bijection pure, mixed).
"""

from __future__ import annotations

import warnings

import numpy as np
import pytest

from goodhart_bijection_trap import (
    DEFAULT_THRESHOLD,
    DefenseResult,
    GoodhartAgent,
    PERMUTATION,
    coherence_with_defense,
    match_rate,
)


N_STATES = 4
N_STEPS = 400
SEED = 0


@pytest.fixture
def rng() -> np.random.Generator:
    return np.random.default_rng(SEED)


# ----------------------- match_rate -----------------------------------------


def test_match_rate_honest(rng: np.random.Generator) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = d.copy()
    assert match_rate(d, e) == 1.0


def test_match_rate_bijection(rng: np.random.Generator) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = PERMUTATION[d]
    assert match_rate(d, e) == 0.0


def test_match_rate_known_mixture(rng: np.random.Generator) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = d.copy()
    flip_mask = rng.random(N_STEPS) < 0.3
    e[flip_mask] = rng.integers(
        0, N_STATES, size=int(flip_mask.sum()), dtype=np.int64
    )
    expected = float(np.mean(d == e))
    assert match_rate(d, e) == pytest.approx(expected, abs=1e-12)


def test_match_rate_validates_shapes() -> None:
    with pytest.raises(ValueError):
        match_rate(np.array([1, 2, 3]), np.array([1, 2]))
    with pytest.raises(ValueError):
        match_rate(np.array([[1, 2], [3, 4]]), np.array([[1, 2], [3, 4]]))
    with pytest.raises(ValueError):
        match_rate(np.array([1]), np.array([1]))


# ----------------------- coherence_with_defense -----------------------------


def test_coherence_with_defense_honest_is_undefended(
    rng: np.random.Generator,
) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = d.copy()
    result = coherence_with_defense(d, e)
    assert isinstance(result, DefenseResult)
    assert result.defended is False
    assert result.match_rate == 1.0
    assert result.score == result.coherence
    assert result.coherence > 0.95


def test_coherence_with_defense_bijection_is_defended(
    rng: np.random.Generator,
) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = PERMUTATION[d]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        result = coherence_with_defense(d, e)
    assert result.defended is True
    assert result.match_rate == 0.0
    assert result.score == 0.0
    assert result.coherence > 0.95


def test_coherence_with_defense_respects_threshold(
    rng: np.random.Generator,
) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = d.copy()
    # Flip enough to drop below a strict threshold but stay above the default.
    flip_mask = rng.random(N_STEPS) < 0.35
    e[flip_mask] = rng.integers(
        0, N_STATES, size=int(flip_mask.sum()), dtype=np.int64
    )
    strict = coherence_with_defense(d, e, threshold=0.95)
    lenient = coherence_with_defense(d, e, threshold=0.1)
    assert strict.defended is True
    assert lenient.defended is False
    assert strict.score == 0.0
    assert lenient.score == lenient.coherence


def test_coherence_with_defense_default_threshold() -> None:
    assert DEFAULT_THRESHOLD == 0.5


def test_coherence_with_defense_validates_threshold(
    rng: np.random.Generator,
) -> None:
    d = rng.integers(0, N_STATES, size=N_STEPS, dtype=np.int64)
    e = d.copy()
    with pytest.raises(ValueError):
        coherence_with_defense(d, e, threshold=-0.1)
    with pytest.raises(ValueError):
        coherence_with_defense(d, e, threshold=1.5)


# ----------------------- GoodhartAgent (sanity) -----------------------------


def test_agent_pure_honest_has_perfect_match() -> None:
    agent = GoodhartAgent(fidelity=1.0, bijection_strength=0.0)
    rng = np.random.default_rng(SEED)
    declared, executed = agent.trajectory(N_STEPS, rng)
    assert np.array_equal(declared, executed)


def test_agent_pure_bijection_has_zero_match() -> None:
    agent = GoodhartAgent(fidelity=0.0, bijection_strength=1.0)
    rng = np.random.default_rng(SEED)
    declared, executed = agent.trajectory(N_STEPS, rng)
    assert np.mean(declared == executed) == 0.0
    assert np.array_equal(executed, PERMUTATION[declared])
