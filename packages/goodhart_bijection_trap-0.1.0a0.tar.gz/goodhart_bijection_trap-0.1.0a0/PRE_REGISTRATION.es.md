# Pre-registro

> Leer en otro idioma: [English](PRE_REGISTRATION.md) · **Español**

Este documento registra el diseño experimental, las hipótesis y los
resultados predichos del benchmark **antes** de que se ejecutara la corrida
canónica. Se commitea al repositorio como artefacto de transparencia:
cualquier lector puede comparar las predicciones hechas aquí contra los
resultados reportados en [`README.md`](README.md) y el código que los produjo.

El pre-registro es un compromiso metodológico. Existe para:

1. Hacer las predicciones falsables (la tabla del final tiene resultados
   esperados, no solo descripciones).
2. Documentar las decisiones de diseño de modo que no puedan racionalizarse
   retroactivamente a partir de los resultados.
3. Forzar a los autores a declarar qué falsaría el argumento estructural
   antes de ver los números.

---

## 1. Fenómeno bajo prueba

**Afirmación (estructural).** Las métricas de coherencia basadas en
información mutua normalizada — específicamente la *U* de Theil — son
**invariantes bajo bijección sobre el flujo ejecutado**. Como consecuencia,
un optimizador que maximiza una métrica así puede, en principio, alcanzar
el score máximo declarando `X` y ejecutando `f(X)` para una permutación fija
`f`, sin coincidir nunca con `X = f(X)`.

**Afirmación (empírica, a probar).** Bajo presión de optimización realista
con asimetría de costo sobre el camino honesto, este atajo es
**encontrado automáticamente** por un optimizador basado en gradiente, con
una **transición nítida** entre las cuencas honesta y de gaming en función
del costo.

**Afirmación (mitigación, a probar).** Una defensa simple que pone el
score en cero cuando el diagnóstico `match_rate` cae por debajo de un
umbral (`match_floor`) previene la convergencia hacia el gaming en los
niveles de costo donde la métrica naive falla.

---

## 2. Diseño experimental

### 2.1 Fixture adversarial

Un agente sintético de dos palancas (`GoodhartAgent`):

- `fidelity ∈ [0, 1]`: probabilidad de ejecutar exactamente el símbolo
  declarado.
- `bijection_strength ∈ [0, 1]`: probabilidad de aplicar una permutación
  cíclica fija `PERMUTATION = [1, 2, 3, 0]` al símbolo declarado cuando
  no coincide honestamente.
- Masa de probabilidad restante: ejecución uniformemente aleatoria sobre
  el alfabeto.

Tamaño del alfabeto: `N_STATES = 4`. El flujo declarado es el ciclo
determinístico `D_t = (t + 1) mod 4`, lo que asegura que `H(D)` esté
bien definido y sea constante entre corridas.

### 2.2 Métrica

*U* de Theil sobre `(declared, executed)`, según la implementa
`autonometrics.compute_cba_theil_u` y expuesta como el eje `coherence` de
`autonometrics.AutonomyProfile`. El diagnóstico `cba_match_rate` expuesto
por Autonometrics `>= 0.9.0a1` es usado por las variantes defendidas
del scoring.

### 2.3 Optimizador

Ascenso de gradiente con diferencias finitas centradas sobre
`(fidelity, bijection_strength)`. Hiperparámetros fijados antes de
cualquier corrida:

| Parámetro | Valor | Notas |
|---|---|---|
| Iteraciones | 60 | Pasos del loop externo |
| Pasos por evaluación | 200 | Largo de la trayectoria por evaluación de score |
| Learning rate (`lr`) | 0.1 | Tamaño del paso sobre ambas palancas |
| Delta de diferencias finitas | 0.05 | Magnitud de la perturbación centrada |
| Inicialización | `(0.5, 0.5)` | Punto neutro, equidistante de ambas cuencas |
| Semilla | 0 (canónica) | Ancla de reproducibilidad |

Ambas palancas se recortan a `[0, 1]` después de cada paso.

### 2.4 Modos (ocho pre-registrados)

| Modo | Función de score | Descripción |
|---|---|---|
| `A_naive` | `coherence` | Sin costo, sin defensa |
| `D_cost010` | `coherence - 0.10 * fidelity` | Costo leve sobre la honestidad |
| `E_cost030` | `coherence - 0.30 * fidelity` | Costo moderado |
| `F_cost050` | `coherence - 0.50 * fidelity` | Costo alto |
| `G_cost080` | `coherence - 0.80 * fidelity` | Costo severo |
| `H_match_floor_cost050` | `(coh if mr > 0.5 else 0) - 0.50 * fidelity` | `match_floor` a costo alto |
| `I_ensemble_cost050` | `coh * mr - 0.50 * fidelity` | `ensemble` a costo alto |
| `J_match_floor_cost080` | `(coh if mr > 0.5 else 0) - 0.80 * fidelity` | `match_floor` a costo severo |

Clasificación de veredictos (asignada automáticamente por
`classify_run`):

- **HONEST**: `coh > 0.85` y `match_rate > 0.85` y `fidelity > 0.85`.
- **GOODHART**: `coh > 0.85` y `match_rate < 0.40` y `bijection_strength > 0.6`.
- **AMBIGUOUS**: ninguna de las anteriores se cumple claramente.

---

## 3. Hipótesis con resultados predichos

Las predicciones de abajo se hacen **antes** de la corrida canónica. Cada
fila de la tabla de resultados en [`README.md`](README.md) se compromete a
un veredicto específico *ex ante*.

| Modo | Veredicto predicho | Razonamiento |
|---|---|---|
| `A_naive` | HONEST | A costo = 0, ambas cuencas producen el mismo score; el optimizador llega a `fidelity = 1` desde el punto neutro por la geometría del gradiente sola. |
| `D_cost010` | HONEST | Costo demasiado chico para vencer el pull de la cuenca honesta. |
| `E_cost030` | HONEST | Aún por debajo de la transición conjeturada. Predicción ajustada; si es falsa, la transición es más temprana de lo esperado. |
| `F_cost050` | GOODHART | La asimetría de costo inclina el paisaje de pérdida hacia la cuenca de bijección. |
| `G_cost080` | GOODHART | Asimetría severa; la cuenca de bijección domina claramente. |
| `H_match_floor_cost050` | HONEST | `match_floor` remueve la cuenca de bijección por completo; honesto es el único camino con score positivo. |
| `I_ensemble_cost050` | HONEST | Multiplicar por `match_rate` colapsa la cuenca de bijección al score 0. |
| `J_match_floor_cost080` | HONEST | Igual que H; la defensa no depende del costo más allá de asegurar que la honestidad sea la única estrategia con score no nulo. |

### 3.1 Condiciones falsantes

El argumento estructural queda falsado si **cualquiera** de los siguientes
se cumple después de la corrida canónica:

- El modo A o D produce GOODHART. (Significaría que costo = 0 ya activa
  la cuenca de bijección, contradiciendo la afirmación de asimetría
  de costo.)
- Los modos F y G producen HONEST. (Significaría que la asimetría de
  costo **no** induce gaming, contradiciendo la afirmación empírica
  central.)
- Cualquiera de H, I, J produce GOODHART. (Significaría que la defensa
  no previene el modo de falla documentado.)

La afirmación de nitidez de la transición se debilita (no se falsea) si
el veredicto del modo E es GOODHART en lugar de HONEST. Eso correría la
transición a entre costo 0.10 y costo 0.30 en lugar de entre 0.30 y 0.50,
pero el argumento estructural sobrevive.

---

## 4. Lo que este pre-registro no cubre

- **Generalización a otras métricas.** Solo se prueba la *U* de Theil. El
  argumento de invariancia bajo bijección es estructural y aplica a
  cualquier score MI normalizado, pero no se corre ninguna otra métrica
  aquí.
- **Generalización a otros optimizadores.** Solo ascenso de gradiente con
  diferencias finitas centradas. Optimizadores basados en población,
  evolutivos o estilo RL pueden comportarse diferente.
- **Generalización a agentes naturales.** El `GoodhartAgent` es un fixture
  sintético de dos parámetros, no un LLM ni un agente entrenado con RL.
  El argumento estructural es independiente de la clase de agente, pero
  los umbrales empíricos pueden diferir.
- **Comparación de defensas a todos los niveles de costo.** Solo se
  pre-registran los modos listados en §2.4. Las defensas o niveles de
  costo adicionales evaluados post-hoc no gozarían de la protección de
  este pre-registro.

---

## 5. Procedencia y versión

- **Handle del autor:** `bugerchip` (GitHub).
- **Versiones pineadas de librerías:** `autonometrics >= 0.9.0a1`,
  `numpy >= 1.24`, Python `>= 3.10`.
- **Referencia de código:** `goodhart-bijection-trap @ v0.1.0a0`.
- **Semilla canónica:** `0`.

Este documento se commitea al repositorio **antes** de la corrida canónica.
Los cambios subsiguientes se rastrean mediante control de versiones normal;
cualquier cambio sustantivo después de una corrida publicada constituye un
pre-registro nuevo (con su propio label de versión) y debe marcarse como tal
en el mensaje de commit.
