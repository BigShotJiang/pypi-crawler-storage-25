"""The synthetic adversarial fixture: ``GoodhartAgent``.

A two-lever optimisation target over a small discrete alphabet:

- ``fidelity``: probability of matching the declaration honestly.
- ``bijection_strength``: probability of applying a fixed permutation
  when not matching honestly (the gaming pathway).

The remaining probability mass is uniform noise. The agent is deliberately
toy — its purpose is to be an unambiguous, reproducible adversarial fixture
for measuring whether a coherence metric can be gamed.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

N_STATES: int = 4
"""Alphabet size for the benchmark. Fixed at 4 across all pre-registered modes."""

PERMUTATION: np.ndarray = np.array([1, 2, 3, 0], dtype=np.int64)
"""The fixed bijection used by the gaming pathway: ``E = (D + 1) mod N_STATES``.

Choosing a single non-identity permutation suffices: under mutual-information
similarity, all non-identity bijections produce the same ``coherence`` score.
"""


@dataclass
class GoodhartAgent:
    """Two-lever synthetic agent for the bijection-trap benchmark.

    At each timestep, with declared symbol ``D_t``:

    1. With probability ``fidelity``, execute ``E_t = D_t`` (honest match).
    2. Else with probability ``bijection_strength``, execute
       ``E_t = PERMUTATION[D_t]`` (fixed-bijection gaming).
    3. Otherwise, execute a uniform random symbol from the alphabet (noise).

    The declared stream is a deterministic cycle ``D_t = (t + 1) mod N_STATES``,
    which gives a well-defined ``H(D)`` and makes the experiment reproducible.

    Attributes:
        fidelity: Probability of honest match per step. In ``[0, 1]``.
        bijection_strength: Conditional probability of bijection gaming when
            not matching honestly. In ``[0, 1]``.
        n_states: Alphabet size. Defaults to ``N_STATES`` (4).
    """

    fidelity: float = 0.5
    bijection_strength: float = 0.5
    n_states: int = N_STATES

    def trajectory(
        self,
        n_steps: int,
        rng: np.random.Generator,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Generate ``(declared, executed)`` streams of length ``n_steps``.

        The declared stream is a cyclic counter modulo ``n_states``. The
        executed stream samples honest / bijection / noise paths according
        to the agent's current lever values.
        """
        declared = np.array(
            [(t + 1) % self.n_states for t in range(n_steps)],
            dtype=np.int64,
        )
        executed = np.empty(n_steps, dtype=np.int64)

        u = rng.random(n_steps)
        bij_threshold = self.fidelity + (1.0 - self.fidelity) * self.bijection_strength
        noise_alphabet = rng.integers(0, self.n_states, size=n_steps).astype(np.int64)

        honest_mask = u < self.fidelity
        bijection_mask = (u >= self.fidelity) & (u < bij_threshold)
        noise_mask = u >= bij_threshold

        executed[honest_mask] = declared[honest_mask]
        executed[bijection_mask] = PERMUTATION[declared[bijection_mask]]
        executed[noise_mask] = noise_alphabet[noise_mask]

        return declared, executed
