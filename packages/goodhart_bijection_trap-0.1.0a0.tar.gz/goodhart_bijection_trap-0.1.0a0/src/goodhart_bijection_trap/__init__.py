"""Pre-registered empirical benchmark of the bijection trap in MI-based coherence metrics.

A two-lever Goodhart agent (``fidelity`` vs ``bijection_strength``) optimises a
coherence score computed by ``autonometrics``. Under cost asymmetry on the
honest lever, the agent reliably discovers the bijection shortcut. A simple
``match_rate`` diagnostic, exposed by ``autonometrics >= 0.9.0a1``, supports
a defence (``match_floor``) that resists the same optimisation pressure.

Public API
----------

Defence utilities (preferred entry point for users defending their own pipeline)::

    from goodhart_bijection_trap import (
        coherence_with_defense,
        match_rate,
        match_floor_defense,
        match_rate_below_floor,
        DefenseResult,
        DEFAULT_THRESHOLD,
    )

Reproduction surface (the adversarial fixture itself)::

    from goodhart_bijection_trap import (
        GoodhartAgent,
        N_STATES,
        PERMUTATION,
        SCORE_MODES,
        optimize,
        classify_run,
        RunLog,
        IterationLog,
    )

See the README and PRE_REGISTRATION.md for the methodology and full story.
"""

from goodhart_bijection_trap.agent import (
    N_STATES,
    PERMUTATION,
    GoodhartAgent,
)
from goodhart_bijection_trap.defense import (
    DEFAULT_THRESHOLD,
    DefenseResult,
    coherence_with_defense,
    match_floor_defense,
    match_rate,
    match_rate_below_floor,
)
from goodhart_bijection_trap.optimizer import (
    IterationLog,
    RunLog,
    classify_run,
    optimize,
)
from goodhart_bijection_trap.scoring import (
    SCORE_MODES,
    make_score_costly_honesty,
    make_score_ensemble_costly,
    make_score_match_floor_costly,
    score_naive,
)

__version__ = "0.1.0a0"

__all__ = [
    # Defence utilities.
    "DEFAULT_THRESHOLD",
    "DefenseResult",
    "coherence_with_defense",
    "match_rate",
    "match_floor_defense",
    "match_rate_below_floor",
    # Reproduction surface.
    "N_STATES",
    "PERMUTATION",
    "GoodhartAgent",
    "SCORE_MODES",
    "score_naive",
    "make_score_costly_honesty",
    "make_score_match_floor_costly",
    "make_score_ensemble_costly",
    "optimize",
    "classify_run",
    "RunLog",
    "IterationLog",
    # Metadata.
    "__version__",
]
