"""Command-line entry point for the benchmark.

Two subcommands:

- ``goodhart-bench run [--seed N]`` — run the full 8-mode suite and print
  the per-mode summary table.
- ``goodhart-bench smoke`` — verify the diagnostic path (honest, bijection
  pure, mixed control cases) without running the optimiser.
"""

from __future__ import annotations

import argparse
import sys
import warnings

import numpy as np

from goodhart_bijection_trap import __version__
from goodhart_bijection_trap.agent import N_STATES, PERMUTATION
from goodhart_bijection_trap.defense import _measure_coherence_and_match_rate
from goodhart_bijection_trap.optimizer import (
    DELTA,
    LR,
    N_ITERATIONS,
    N_STEPS_PER_EVAL,
    classify_run,
    optimize,
)
from goodhart_bijection_trap.scoring import SCORE_MODES


def _format_summary_row(mode: str, log, verdict: str) -> str:
    final = log.history[-1]
    return (
        f"  {mode:<24}  "
        f"{final.fidelity:>5.2f}  "
        f"{final.bijection_strength:>5.2f}  "
        f"{final.coherence:>5.2f}  "
        f"{final.match_rate:>5.2f}  "
        f"{verdict}"
    )


def cmd_run(args: argparse.Namespace) -> int:
    """Run the full 8-mode suite."""
    print(f"goodhart-bench v{__version__}")
    print(f"Seed: {args.seed}")
    print(
        f"Optimiser: finite-diff (delta={DELTA}), lr={LR}, "
        f"n_iterations={N_ITERATIONS}, n_steps_per_eval={N_STEPS_PER_EVAL}"
    )
    print(f"Agent: GoodhartAgent over alphabet of size {N_STATES}, "
          f"permutation={PERMUTATION.tolist()}")
    print()

    results = []
    for mode_name, score_fn in SCORE_MODES.items():
        log = optimize(mode_name, score_fn, seed=args.seed)
        verdict, explanation = classify_run(log)
        results.append((mode_name, log, verdict, explanation))
        print(f"[{verdict:<10}]  {mode_name}")
        print(f"             {explanation}")

    print()
    print("Summary")
    print("=" * 70)
    print(
        f"  {'mode':<24}  {'fid':>5}  {'bij':>5}  {'coh':>5}  "
        f"{'mr':>5}  verdict"
    )
    print("  " + "-" * 66)
    for mode_name, log, verdict, _ in results:
        print(_format_summary_row(mode_name, log, verdict))

    return 0


def cmd_smoke(args: argparse.Namespace) -> int:
    """Verify the diagnostic path on three control cases.

    Confirms that ``coherence`` and ``cba_match_rate`` from Autonometrics
    match a direct ``np.mean(declared == executed)`` computation, and that
    the bijection-pure case produces the documented ``(coh=1, mr=0)``
    signature.
    """
    rng = np.random.default_rng(args.seed)
    n = 400

    failures = 0

    def check(label: str, condition: bool, detail: str) -> None:
        nonlocal failures
        status = "PASS" if condition else "FAIL"
        if not condition:
            failures += 1
        print(f"  [{status}] {label}: {detail}")

    print("Smoke check: three control cases for the diagnostic path")
    print()

    # Case 1: honest — declared == executed exactly.
    d1 = rng.integers(0, N_STATES, size=n, dtype=np.int64)
    e1 = d1.copy()
    coh1, mr1 = _measure_coherence_and_match_rate(d1, e1)
    mr1_manual = float(np.mean(d1 == e1))
    check(
        "honest: cba_match_rate matches np.mean(d == e) bit-for-bit",
        abs(mr1 - mr1_manual) < 1e-12,
        f"profile={mr1:.6f}, manual={mr1_manual:.6f}",
    )
    check(
        "honest: match_rate is exactly 1.0",
        mr1 == 1.0,
        f"match_rate={mr1:.6f}",
    )

    # Case 2: bijection pure — E = PERMUTATION[D] always.
    d2 = rng.integers(0, N_STATES, size=n, dtype=np.int64)
    e2 = PERMUTATION[d2]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        coh2, mr2 = _measure_coherence_and_match_rate(d2, e2)
    mr2_manual = float(np.mean(d2 == e2))
    check(
        "bijection: cba_match_rate matches np.mean(d == e) bit-for-bit",
        abs(mr2 - mr2_manual) < 1e-12,
        f"profile={mr2:.6f}, manual={mr2_manual:.6f}",
    )
    check(
        "bijection: match_rate is exactly 0.0",
        mr2 == 0.0,
        f"match_rate={mr2:.6f}",
    )
    check(
        "bijection: coherence is approximately 1.0",
        coh2 > 0.95,
        f"coherence={coh2:.4f}",
    )

    # Case 3: noisy mixture.
    d3 = rng.integers(0, N_STATES, size=n, dtype=np.int64)
    e3 = d3.copy()
    flip_mask = rng.random(n) < 0.3
    n_flip = int(flip_mask.sum())
    e3[flip_mask] = rng.integers(0, N_STATES, size=n_flip, dtype=np.int64)
    coh3, mr3 = _measure_coherence_and_match_rate(d3, e3)
    mr3_manual = float(np.mean(d3 == e3))
    check(
        "mixed: cba_match_rate matches np.mean(d == e) bit-for-bit",
        abs(mr3 - mr3_manual) < 1e-12,
        f"profile={mr3:.6f}, manual={mr3_manual:.6f}",
    )

    print()
    if failures == 0:
        print("All control cases passed.")
        return 0
    print(f"{failures} check(s) failed.")
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="goodhart-bench",
        description=(
            "Pre-registered empirical benchmark of the bijection trap "
            "in MI-based coherence metrics."
        ),
    )
    parser.add_argument("-V", "--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser(
        "run",
        help="Run the full 8-mode benchmark suite.",
    )
    run_parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="Random seed for the optimiser (default: 0).",
    )
    run_parser.set_defaults(func=cmd_run)

    smoke_parser = subparsers.add_parser(
        "smoke",
        help="Run a smoke check on the diagnostic path (no optimisation).",
    )
    smoke_parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="Random seed for the control arrays (default: 0).",
    )
    smoke_parser.set_defaults(func=cmd_smoke)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
