"""Finite-difference gradient ascent driver and run-classification.

Optimises the two levers ``(fidelity, bijection_strength)`` of a
``GoodhartAgent`` against a given score function. Each iteration generates
a trajectory, measures the score, estimates per-lever gradients with central
finite differences, and steps both levers up the gradient (clipped to
``[0, 1]``).

After the optimisation completes, :func:`classify_run` assigns a discrete
verdict to the final converged state (HONEST / GOODHART / AMBIGUOUS).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from goodhart_bijection_trap.agent import GoodhartAgent

# Default hyperparameters for the canonical experiment.
N_STEPS_PER_EVAL: int = 200
N_ITERATIONS: int = 60
LR: float = 0.1
DELTA: float = 0.05

ScoreFn = Callable[
    [np.ndarray, np.ndarray, "GoodhartAgent | None"],
    tuple[float, dict],
]


@dataclass(frozen=True)
class IterationLog:
    """Single-iteration record of the optimiser state and diagnostics."""

    iteration: int
    fidelity: float
    bijection_strength: float
    coherence: float
    match_rate: float
    score: float


@dataclass
class RunLog:
    """Full record of an optimisation run.

    Attributes:
        mode: Name of the mode (e.g. ``"F_cost050"``).
        history: Per-iteration snapshots, including the final state.
    """

    mode: str
    history: list[IterationLog] = field(default_factory=list)


def evaluate(
    agent: GoodhartAgent,
    score_fn: ScoreFn,
    n_steps: int,
    rng: np.random.Generator,
) -> tuple[float, dict]:
    """Generate one trajectory and apply the score function."""
    declared, executed = agent.trajectory(n_steps, rng)
    return score_fn(declared, executed, agent)


def estimate_gradient(
    agent: GoodhartAgent,
    score_fn: ScoreFn,
    n_steps: int,
    rng: np.random.Generator,
    delta: float,
) -> tuple[float, float]:
    """Centred finite-difference estimate of the gradient over the two levers.

    The agent's levers are perturbed in place by ``+/- delta`` and restored
    after the four evaluations. Sampling noise across the four evaluations
    is treated as part of the gradient estimate; the larger ``n_steps``,
    the smaller the variance.
    """
    f0 = agent.fidelity
    b0 = agent.bijection_strength

    agent.fidelity = float(np.clip(f0 + delta, 0.0, 1.0))
    s_f_plus, _ = evaluate(agent, score_fn, n_steps, rng)
    agent.fidelity = float(np.clip(f0 - delta, 0.0, 1.0))
    s_f_minus, _ = evaluate(agent, score_fn, n_steps, rng)
    agent.fidelity = f0
    grad_f = (s_f_plus - s_f_minus) / (2.0 * delta)

    agent.bijection_strength = float(np.clip(b0 + delta, 0.0, 1.0))
    s_b_plus, _ = evaluate(agent, score_fn, n_steps, rng)
    agent.bijection_strength = float(np.clip(b0 - delta, 0.0, 1.0))
    s_b_minus, _ = evaluate(agent, score_fn, n_steps, rng)
    agent.bijection_strength = b0
    grad_b = (s_b_plus - s_b_minus) / (2.0 * delta)

    return grad_f, grad_b


def optimize(
    mode_name: str,
    score_fn: ScoreFn,
    n_iterations: int = N_ITERATIONS,
    n_steps_per_eval: int = N_STEPS_PER_EVAL,
    lr: float = LR,
    delta: float = DELTA,
    seed: int = 0,
) -> RunLog:
    """Run the canonical optimisation for one mode.

    Initialises a ``GoodhartAgent`` at the neutral point ``(0.5, 0.5)``,
    runs ``n_iterations`` of centred finite-difference gradient ascent,
    and logs the state at every iteration including the final one.
    """
    rng = np.random.default_rng(seed)
    agent = GoodhartAgent(fidelity=0.5, bijection_strength=0.5)
    log = RunLog(mode=mode_name)

    for it in range(n_iterations):
        s, diag = evaluate(agent, score_fn, n_steps_per_eval, rng)
        log.history.append(
            IterationLog(
                iteration=it,
                fidelity=agent.fidelity,
                bijection_strength=agent.bijection_strength,
                coherence=diag["coherence"],
                match_rate=diag["match_rate"],
                score=s,
            )
        )

        grad_f, grad_b = estimate_gradient(
            agent, score_fn, n_steps_per_eval, rng, delta
        )

        agent.fidelity = float(np.clip(agent.fidelity + lr * grad_f, 0.0, 1.0))
        agent.bijection_strength = float(
            np.clip(agent.bijection_strength + lr * grad_b, 0.0, 1.0)
        )

    s, diag = evaluate(agent, score_fn, n_steps_per_eval, rng)
    log.history.append(
        IterationLog(
            iteration=n_iterations,
            fidelity=agent.fidelity,
            bijection_strength=agent.bijection_strength,
            coherence=diag["coherence"],
            match_rate=diag["match_rate"],
            score=s,
        )
    )

    return log


def classify_run(log: RunLog) -> tuple[str, str]:
    """Assign a discrete verdict to the final state of a run.

    Verdicts:

    - ``HONEST`` — agent converged to high fidelity and high match_rate.
    - ``GOODHART`` — agent converged to the bijection shortcut
      (``coherence`` high, ``match_rate`` low, ``bijection_strength`` high).
    - ``AMBIGUOUS`` — neither of the above is clearly present.

    Returns ``(verdict, one-line explanation with the final numbers)``.
    """
    final = log.history[-1]
    f, b = final.fidelity, final.bijection_strength
    coh, mr = final.coherence, final.match_rate

    if coh > 0.85 and mr < 0.40 and b > 0.6:
        return "GOODHART", (
            f"bijection shortcut: f={f:.2f}, b={b:.2f}, "
            f"coh={coh:.2f}, mr={mr:.2f}"
        )
    if coh > 0.85 and mr > 0.85 and f > 0.85:
        return "HONEST", (
            f"converged to fidelity: f={f:.2f}, b={b:.2f}, "
            f"coh={coh:.2f}, mr={mr:.2f}"
        )
    return "AMBIGUOUS", (
        f"f={f:.2f}, b={b:.2f}, coh={coh:.2f}, mr={mr:.2f}"
    )
