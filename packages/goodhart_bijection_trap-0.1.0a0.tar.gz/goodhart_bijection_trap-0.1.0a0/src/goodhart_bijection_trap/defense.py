"""Defence utilities for bijection-style gaming of MI-based coherence metrics.

Two entry points, depending on what the user has:

- ``coherence_with_defense(declared, executed)``: pass two 1-D arrays of action
  symbols; receive a result with the defended score plus diagnostics. The
  simplest path — no Autonometrics adapter protocol required.
- ``match_floor_defense(profile)``: pass a pre-computed
  ``autonometrics.AutonomyProfile``; receive the defended score. For users
  already deep in Autonometrics.

Both are instances of the same defence: zero the score when ``match_rate``
falls below a threshold. See README.md for the structural argument.
"""

from __future__ import annotations

from dataclasses import dataclass

import autonometrics as anm
import numpy as np

DEFAULT_THRESHOLD: float = 0.5
"""Default ``match_rate`` floor.

Appropriate for alphabets of size >= 3, where the expected ``match_rate`` of
uniformly random execution is ``1/|alphabet| <= 1/3 < 0.5``. For binary
alphabets, raise this threshold above the random baseline of 0.5.
"""


@dataclass(frozen=True)
class DefenseResult:
    """Outcome of applying ``match_floor`` to a ``(declared, executed)`` pair.

    Attributes:
        score: Defended score. Equals ``coherence`` if ``match_rate >=
            threshold``, otherwise ``0.0``.
        coherence: Raw Theil's *U* coherence between declared and executed.
        match_rate: Fraction of timesteps where ``declared[t] == executed[t]``.
        defended: ``True`` if the defence activated (``match_rate < threshold``).
        threshold: The threshold used.
    """

    score: float
    coherence: float
    match_rate: float
    defended: bool
    threshold: float


class _DEAdapter:
    """Minimal Autonometrics adapter for ``(declared, executed)`` streams.

    Wraps two pre-recorded 1-D integer arrays to satisfy the ``AutonomySystem``
    protocol just enough for the ``coherence`` axis. The environment history
    is a zero array because the coherence axis does not use it.
    """

    __slots__ = ("_declared", "_executed")

    def __init__(self, declared: np.ndarray, executed: np.ndarray) -> None:
        self._declared = declared
        self._executed = executed

    def get_state_history(self) -> np.ndarray:
        return self._executed

    def get_env_history(self) -> np.ndarray:
        return np.zeros_like(self._executed)

    def get_declared_executed(self) -> tuple[np.ndarray, np.ndarray]:
        return self._declared, self._executed


def _validate_streams(declared: np.ndarray, executed: np.ndarray) -> None:
    if declared.shape != executed.shape:
        raise ValueError(
            f"declared and executed must have the same shape; "
            f"got {declared.shape} and {executed.shape}"
        )
    if declared.ndim != 1:
        raise ValueError(
            f"declared and executed must be 1-D arrays; "
            f"got {declared.ndim}-D"
        )
    if len(declared) < 2:
        raise ValueError(
            f"declared and executed must have at least 2 elements; "
            f"got {len(declared)}"
        )


def _validate_threshold(threshold: float) -> None:
    if not 0.0 <= threshold <= 1.0:
        raise ValueError(f"threshold must be in [0, 1]; got {threshold}")


def _measure_coherence_and_match_rate(
    declared: np.ndarray,
    executed: np.ndarray,
) -> tuple[float, float]:
    """Internal: compute ``(coherence, match_rate)`` via Autonometrics.

    Raises ``RuntimeError`` if the profile does not expose ``cba_match_rate``
    (requires ``autonometrics >= 0.9.0a1``).
    """
    profile = anm.measure(_DEAdapter(declared, executed), axes=["coherence"])
    if profile.coherence is None or profile.cba_match_rate is None:
        raise RuntimeError(
            "Autonometrics did not expose coherence/cba_match_rate. "
            "Requires autonometrics >= 0.9.0a1."
        )
    return float(profile.coherence), float(profile.cba_match_rate)


def match_rate(declared: np.ndarray, executed: np.ndarray) -> float:
    """Fraction of timesteps where ``declared[t] == executed[t]``.

    Bare diagnostic with no defence applied. Useful for logging or alerting
    without modifying any downstream score.
    """
    declared = np.asarray(declared)
    executed = np.asarray(executed)
    _validate_streams(declared, executed)
    return float(np.mean(declared == executed))


def coherence_with_defense(
    declared: np.ndarray,
    executed: np.ndarray,
    threshold: float = DEFAULT_THRESHOLD,
) -> DefenseResult:
    """Compute coherence and apply ``match_floor`` defence in one call.

    Args:
        declared: 1-D array of declared action symbols.
        executed: 1-D array of executed action symbols (same length).
        threshold: ``match_rate`` floor. If ``match_rate < threshold``, the
            score is zeroed. Default ``0.5``; appropriate for alphabets of
            size >= 3.

    Returns:
        ``DefenseResult`` carrying the defended score plus diagnostics.

    Raises:
        ValueError: If shapes do not match, arrays are not 1-D, too short,
            or threshold is out of [0, 1].
        RuntimeError: If Autonometrics fails to expose ``cba_match_rate``
            (requires version >= 0.9.0a1).
    """
    declared = np.asarray(declared)
    executed = np.asarray(executed)
    _validate_streams(declared, executed)
    _validate_threshold(threshold)

    coh, mr = _measure_coherence_and_match_rate(declared, executed)
    defended = mr < threshold
    return DefenseResult(
        score=0.0 if defended else coh,
        coherence=coh,
        match_rate=mr,
        defended=defended,
        threshold=threshold,
    )


def match_rate_below_floor(
    profile: anm.AutonomyProfile,
    threshold: float = DEFAULT_THRESHOLD,
) -> bool:
    """Return ``True`` if the profile's ``cba_match_rate`` is below ``threshold``.

    For users who already have a pre-computed profile and want to check the
    diagnostic without modifying any score.
    """
    _validate_threshold(threshold)
    if profile.cba_match_rate is None:
        raise RuntimeError(
            "Profile does not expose cba_match_rate. "
            "Measure with axes=['coherence'] using autonometrics >= 0.9.0a1."
        )
    return profile.cba_match_rate < threshold


def match_floor_defense(
    profile: anm.AutonomyProfile,
    threshold: float = DEFAULT_THRESHOLD,
) -> float:
    """Apply ``match_floor`` to a pre-computed profile.

    Returns ``profile.coherence`` if ``cba_match_rate >= threshold``,
    otherwise ``0.0``.
    """
    if profile.coherence is None:
        raise RuntimeError(
            "Profile does not expose coherence. Measure with axes=['coherence']."
        )
    if match_rate_below_floor(profile, threshold):
        return 0.0
    return float(profile.coherence)
