# Pre-registration

> Read in another language: **English** · [Español](PRE_REGISTRATION.es.md)

This document records the experimental design, hypotheses, and predicted
outcomes of the benchmark **before** the canonical run was executed. It is
committed to the repository as a transparency artefact: any reader can compare
the predictions made here against the results reported in [`README.md`](README.md)
and the code that produced them.

The pre-registration is a methodological commitment. It exists to:

1. Make the predictions falsifiable (the table at the end has expected
   outcomes, not just descriptions).
2. Document the design choices so they cannot be retroactively rationalised
   by the results.
3. Force the authors to declare what would falsify the structural argument
   before seeing the numbers.

---

## 1. Phenomenon under test

**Claim (structural).** Coherence metrics based on normalised mutual
information — specifically Theil's *U* — are **invariant under bijection on
the executed stream**. As a consequence, an optimiser that maximises such a
metric can, in principle, achieve the maximum score by declaring `X` and
executing `f(X)` for a fixed permutation `f`, without ever matching `X = f(X)`.

**Claim (empirical, to be tested).** Under realistic optimisation pressure
with cost asymmetry on the honest pathway, this loophole is **found
automatically** by a gradient-based optimiser, with a **sharp transition**
between the honest and gaming basins as a function of cost.

**Claim (mitigation, to be tested).** A simple defence that zeros the
score whenever the `match_rate` diagnostic falls below a threshold
(`match_floor`) prevents the gaming convergence at cost levels where the
naive metric fails.

---

## 2. Experimental setup

### 2.1 Adversarial fixture

A two-lever synthetic agent (`GoodhartAgent`):

- `fidelity ∈ [0, 1]`: probability of executing exactly the declared symbol.
- `bijection_strength ∈ [0, 1]`: probability of applying a fixed cyclic
  permutation `PERMUTATION = [1, 2, 3, 0]` to the declared symbol when not
  matching honestly.
- Remaining probability mass: uniformly random execution over the alphabet.

Alphabet size is `N_STATES = 4`. The declared stream is the deterministic
cycle `D_t = (t + 1) mod 4`, ensuring `H(D)` is well-defined and constant
across runs.

### 2.2 Metric

Theil's *U* on `(declared, executed)`, as implemented by
`autonometrics.compute_cba_theil_u` and exposed as the `coherence` axis of
`autonometrics.AutonomyProfile`. The diagnostic `cba_match_rate` exposed by
Autonometrics `>= 0.9.0a1` is used by the defended scoring variants.

### 2.3 Optimiser

Centred finite-difference gradient ascent over `(fidelity,
bijection_strength)`. Hyperparameters fixed before any run:

| Parameter | Value | Notes |
|---|---|---|
| Iterations | 60 | Steps of the outer loop |
| Steps per evaluation | 200 | Trajectory length per score evaluation |
| Learning rate (`lr`) | 0.1 | Step size on both levers |
| Finite-difference delta | 0.05 | Centred perturbation magnitude |
| Initialisation | `(0.5, 0.5)` | Neutral start, equidistant from both basins |
| Seed | 0 (canonical) | Reproducibility anchor |

Both levers are clipped to `[0, 1]` after each step.

### 2.4 Modes (eight pre-registered)

| Mode | Score function | Description |
|---|---|---|
| `A_naive` | `coherence` | No cost, no defence |
| `D_cost010` | `coherence - 0.10 * fidelity` | Mild cost on honesty |
| `E_cost030` | `coherence - 0.30 * fidelity` | Moderate cost |
| `F_cost050` | `coherence - 0.50 * fidelity` | High cost |
| `G_cost080` | `coherence - 0.80 * fidelity` | Severe cost |
| `H_match_floor_cost050` | `(coh if mr > 0.5 else 0) - 0.50 * fidelity` | `match_floor` at high cost |
| `I_ensemble_cost050` | `coh * mr - 0.50 * fidelity` | `ensemble` at high cost |
| `J_match_floor_cost080` | `(coh if mr > 0.5 else 0) - 0.80 * fidelity` | `match_floor` at severe cost |

Verdict classification (assigned automatically by `classify_run`):

- **HONEST**: `coh > 0.85` and `match_rate > 0.85` and `fidelity > 0.85`.
- **GOODHART**: `coh > 0.85` and `match_rate < 0.40` and `bijection_strength > 0.6`.
- **AMBIGUOUS**: neither of the above is clearly present.

---

## 3. Hypotheses with predicted outcomes

The predictions below are made **before** the canonical run. Each row of the
results table in [`README.md`](README.md) is committed to a specific verdict
*ex ante*.

| Mode | Predicted verdict | Reasoning |
|---|---|---|
| `A_naive` | HONEST | At cost = 0, both basins yield the same score; the optimiser arrives at `fidelity = 1` from the neutral start by gradient geometry alone. |
| `D_cost010` | HONEST | Cost too small to overcome the honest basin's pull. |
| `E_cost030` | HONEST | Still below the conjectured transition. Tight prediction; if false, the transition is earlier than expected. |
| `F_cost050` | GOODHART | Cost asymmetry tilts the loss landscape towards the bijection basin. |
| `G_cost080` | GOODHART | Severe asymmetry; bijection basin clearly dominates. |
| `H_match_floor_cost050` | HONEST | `match_floor` removes the bijection basin entirely; honest is the only positive-score path. |
| `I_ensemble_cost050` | HONEST | Multiplying by `match_rate` collapses the bijection basin to score 0. |
| `J_match_floor_cost080` | HONEST | Same as H; the defence does not depend on cost beyond ensuring honesty is the only non-zero strategy. |

### 3.1 Falsifying conditions

The structural argument is falsified if **any** of the following hold after
the canonical run:

- Mode A or D yields GOODHART. (Would mean cost = 0 already triggers the
  bijection basin, contradicting the cost-asymmetry claim.)
- Modes F and G yield HONEST. (Would mean cost asymmetry does **not**
  induce gaming, contradicting the central empirical claim.)
- Either of H, I, J yields GOODHART. (Would mean the defence does not
  prevent the documented failure mode.)

The transition-sharpness claim is weakened (not falsified) if the verdict
on mode E is GOODHART rather than HONEST. That would push the transition
between cost 0.10 and cost 0.30 rather than between 0.30 and 0.50, but the
structural argument survives.

---

## 4. What this pre-registration does not cover

- **Generalisation to other metrics.** Only Theil's *U* is tested. The
  bijection-invariance argument is structural and applies to any normalised
  MI score, but no other metric is run here.
- **Generalisation to other optimisers.** Only centred finite-difference
  gradient ascent. Population-based, evolutionary, or RL-style optimisers
  may behave differently.
- **Generalisation to natural agents.** The `GoodhartAgent` is a
  two-parameter synthetic fixture, not an LLM or RL-trained agent. The
  structural argument is independent of the agent class, but empirical
  thresholds may differ.
- **Defence comparison at all cost levels.** Only the modes listed in §2.4
  are pre-registered. Additional defences or cost levels evaluated post-hoc
  would not enjoy the protection of this pre-registration.

---

## 5. Provenance and version

- **Author handle:** `bugerchip` (GitHub).
- **Library pins:** `autonometrics >= 0.9.0a1`, `numpy >= 1.24`,
  Python `>= 3.10`.
- **Code reference:** `goodhart-bijection-trap @ v0.1.0a0`.
- **Canonical seed:** `0`.

This document is committed to the repository **prior to** the canonical run.
Subsequent changes are tracked through normal version control; any
substantive change after a published run constitutes a new pre-registration
(with its own version label) and must be flagged as such in the commit message.
