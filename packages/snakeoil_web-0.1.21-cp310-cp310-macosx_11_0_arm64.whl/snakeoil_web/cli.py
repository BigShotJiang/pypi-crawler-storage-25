"""snakeoil-web CLI — project initialisation."""

import os
import subprocess
import sys


PYTEST_INI = '''\
[pytest]
python_files = *.py
'''


CONFIG = '''\
"""
snakeoil.web.config.py — configure your web test settings here.
"""

URL        = "https://www.saucedemo.com"
BROWSER    = "chromium"   # chromium | firefox | webkit | msedge
HEADLESS   = False
MAXIMIZED  = True
TIMEOUT    = 30_000       # milliseconds
RESULT_DIR = "."          # where report.html is saved (default: project root)
'''


CONFTEST = '''\
import os
import pytest
from snakeoil_web import WebAgent


def _load_project_config() -> dict:
    """Load snakeoil.web.config.py searching upward from the current directory."""
    start = os.getcwd()
    while True:
        candidate = os.path.join(start, "snakeoil.web.config.py")
        if os.path.exists(candidate):
            cfg = {}
            with open(candidate) as f:
                exec(f.read(), cfg)
            return cfg
        parent = os.path.dirname(start)
        if parent == start:
            break
        start = parent
    return {}


def pytest_configure(config):
    cfg = _load_project_config()
    result_dir = cfg.get("RESULT_DIR", ".")
    os.makedirs(result_dir, exist_ok=True)
    if not config.option.htmlpath:
        config.option.htmlpath = os.path.join(result_dir, "report.html")


@pytest.fixture
def agent():
    cfg = _load_project_config()
    a = WebAgent(url=cfg.get("URL"))
    yield a
    a.close()
'''


ENGLISH_TEST = '''\
"""
test_english.py — English instruction API example using pytest.

Each test_ function is an isolated test with its own browser session.
Use f-strings to embed Python variables inside instructions.
"""

# Test data
username = "standard_user"
password = "secret_sauce"


def test_login(agent):
    agent.run([
        f\'type "{username}" into "Username"\',   # type into field identified by placeholder label
        f\'type "{password}" into "Password"\',   # type into password field
        \'click "Login"\',                          # click login button by text
        \'verify text "Products" is present\',     # assert we landed on the products page
    ])


def test_product_interactions(agent):
    agent.run([
        f\'type "{username}" into "Username"\',
        f\'type "{password}" into "Password"\',
        \'click "Login"\',
        \'select "Price (low to high)" from "product_sort_container"\',  # select dropdown option by class
        \'verify text "Sauce Labs Onesie" is present\',                  # assert cheapest item is first
    ])

    price = agent.run(\'extract text next to "Add to cart"\')  # spatial extract — price is left of button
    print(f"Cheapest product price: {price}")
    assert price, "No price extracted"

    agent.run([
        \'click "Add to cart" below "Sauce Labs Onesie"\',  # spatial click — button is below product name
        \'verify "Remove" is present\',                      # assert button changed to Remove
        \'hover "shopping_cart_link"\',                      # hover over cart icon by class
        \'click "shopping_cart_link"\',                      # click cart icon by class name
        \'verify text "Your Cart" is present\',              # assert we landed on cart page
    ])

    cart_item = agent.run(\'extract text from first "inventory item name"\')  # extract first cart item name
    print(f"Cart item: {cart_item}")
    assert cart_item == "Sauce Labs Onesie", f"Expected Sauce Labs Onesie in cart, got: {cart_item}"
'''


PYTHONIC_TEST = '''\
"""
test_pythonic.py — Pythonic API example using pytest.

Each test_ function is an isolated test with its own browser session.
IDE autocomplete guides you through every method.
"""

# Test data
username = "standard_user"
password = "secret_sauce"


def test_login(agent):
    (agent
        .type(username, into="Username")   # type into field identified by placeholder label
        .type(password, into="Password")   # type into password field
        .click("Login")                    # click login button by text
        .verify_text("Products")           # assert we landed on the products page
    )


def test_product_interactions(agent):
    (agent
        .type(username, into="Username")
        .type(password, into="Password")
        .click("Login")
        .select("Price (low to high)", from_="product_sort_container")  # select dropdown option by class
        .verify_text("Sauce Labs Onesie")                               # assert cheapest item is first
    )

    price = agent.extract_text(next_to="Add to cart")  # spatial extract — price is left of button
    print(f"Cheapest product price: {price}")
    assert price, "No price extracted"

    (agent
        .click("Add to cart", below="Sauce Labs Onesie")  # spatial click — button is below product name
        .verify_present("Remove")                          # assert button changed to Remove
        .hover("shopping_cart_link")                       # hover over cart icon by class
        .click("shopping_cart_link")                       # click cart icon by class name
        .verify_text("Your Cart")                          # assert we landed on cart page
    )

    cart_item = agent.extract_text("inventory item name")  # extract first cart item name
    print(f"Cart item: {cart_item}")
    assert cart_item == "Sauce Labs Onesie", f"Expected Sauce Labs Onesie in cart, got: {cart_item}"
'''


def init():
    """Create project structure for snakeoil-web."""
    cwd       = os.getcwd()
    web_tests = os.path.join(cwd, "web-tests")

    os.makedirs(web_tests, exist_ok=True)

    files = {
        os.path.join(cwd, "pytest.ini"):               PYTEST_INI,
        os.path.join(cwd, "snakeoil.web.config.py"):   CONFIG,
        os.path.join(cwd, "conftest.py"):               CONFTEST,
        os.path.join(web_tests, "test_english.py"):    ENGLISH_TEST,
        os.path.join(web_tests, "test_pythonic.py"):   PYTHONIC_TEST,
    }

    created = []
    skipped = []

    for path, content in files.items():
        if os.path.exists(path):
            skipped.append(path)
        else:
            with open(path, "w") as f:
                f.write(content)
            created.append(path)

    # Install dependencies
    print("\nInstalling dependencies...")
    for pkg in ["pytest", "pytest-html"]:
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", pkg],
                           check=True, capture_output=True)
        except subprocess.CalledProcessError:
            print(f"Warning: could not install {pkg}. Run 'pip install {pkg}' manually.")

    print("\nInstalling browser binaries...")
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True
        )
        print("Browsers installed.")
    except subprocess.CalledProcessError:
        print("Warning: could not install browsers. Run 'playwright install' manually.")

    print("\nsnakeoil-web project initialised.\n")

    if created:
        print("Created:")
        for f in created:
            print(f"  {f}")

    if skipped:
        print("\nSkipped (already exist):")
        for f in skipped:
            print(f"  {f}")

    print("""
Next steps:
  1. Edit snakeoil.web.config.py — set your URL, browser and options
  2. Run your tests:   pytest web-tests/
  3. View report:      open report.html
""")


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "init":
        print("Usage: snakeoil init")
        sys.exit(1)
    init()


if __name__ == "__main__":
    main()
