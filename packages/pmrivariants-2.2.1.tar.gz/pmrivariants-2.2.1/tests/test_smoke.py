import pandas as pd
from pmri_variants import compute_pmri_lite, compute_pmri_core, compute_pmri_plus, compute_pmri_plus_data_driven, compute_pmri_sri

def test_smoke():
    df = pd.DataFrame({
        "Actual":[70,72,75,78,80,82],
        "Predicted":[69,73,74,79,81,83],
        "Latitude":[53.27,53.28,53.29,53.30,53.31,53.32],
        "Longitude":[-9.05,-9.04,-9.03,-9.02,-9.01,-9.00],
        "Feature_1":[12,13,14,15,16,17],
        "Feature_2":[20,25,18,22,24,19],
    })
    compute_pmri_lite(df["Actual"], df["Predicted"], export_json="lite.json")
    compute_pmri_core(df["Actual"], df["Predicted"], export_json="core.json")
    compute_pmri_plus(df["Actual"], df["Predicted"], export_json="plus.json")
    compute_pmri_plus_data_driven(df, "Actual", "Predicted", export_json="dd.json")
    compute_pmri_sri(df, "Actual", "Predicted", "Latitude", "Longitude", export_json="sri.json")
