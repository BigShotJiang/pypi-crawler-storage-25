from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from .core import compute_pmri_lite, compute_pmri_core, compute_pmri_plus
from .sri import compute_pmri_sri

@dataclass
class PMRIResult:
    summary: dict
    details: dict

class PMRIAnalyzer:
    def __init__(self, actual_col="Actual", predicted_col="Predicted", lat_col="Latitude", lon_col="Longitude"):
        self.actual_col = actual_col; self.predicted_col = predicted_col; self.lat_col = lat_col; self.lon_col = lon_col

    def compute_all(self, df: pd.DataFrame):
        lite = compute_pmri_lite(df[self.actual_col], df[self.predicted_col])
        core = compute_pmri_core(df[self.actual_col], df[self.predicted_col])
        plus = compute_pmri_plus(df[self.actual_col], df[self.predicted_col])
        out = {"pmri_lite": lite["pmri_lite"], "pmri_lite_class": lite["class"], "pmri_core": core["pmri_core"], "pmri_core_class": core["class"], "pmri_plus": plus["pmri_plus"], "pmri_plus_class": plus["class"]}
        if self.lat_col in df.columns and self.lon_col in df.columns:
            sri = compute_pmri_sri(df, self.actual_col, self.predicted_col, self.lat_col, self.lon_col)
            out["pmri_sri"] = sri["sri_mean"]; out["pmri_sri_class"] = sri["class"]
        return PMRIResult(summary=out, details={"lite": lite, "core": core, "plus": plus})
