from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, ks_2samp, levene, pearsonr, t as student_t

def classify(score: float) -> str:
    if np.isnan(score): return "N/A"
    if score > 0.80: return "Operational"
    if score >= 0.60: return "Decision-support"
    return "Exploratory"

def to_numpy(x): return np.asarray(x, dtype=float)

def common_metrics(actual, predicted):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    sse = np.sum((actual - predicted) ** 2)
    sst = np.sum((actual - np.mean(actual)) ** 2)
    r2 = 1 - sse / sst if sst != 0 else np.nan
    mse = float(np.mean((actual - predicted) ** 2))
    rmse = float(np.sqrt(mse))
    mae = float(np.mean(np.abs(actual - predicted)))
    mbe = float(np.mean(predicted - actual))
    mape = float(np.mean(np.abs((actual - predicted) / (actual + 1e-9))) * 100)
    pabe = float(np.mean(np.abs(predicted - actual) / (np.abs(actual) + 1e-9)) * 100)
    try: pear, _ = pearsonr(actual, predicted)
    except Exception: pear = np.nan
    try: spear, _ = spearmanr(actual, predicted, nan_policy="omit")
    except Exception: spear = np.nan
    return {"R2": float(r2) if not np.isnan(r2) else np.nan, "RMSE": rmse, "MSE": mse, "MAE": mae, "MAPE": mape, "PABE": pabe, "MBE": mbe, "Bias": mbe, "Pearson_r": float(pear) if not np.isnan(pear) else np.nan, "Spearman_rho": float(spear) if not np.isnan(spear) else np.nan}

def rank01(actual, predicted):
    rho, _ = spearmanr(actual, predicted, nan_policy="omit")
    if np.isnan(rho): return np.nan, np.nan
    return float(rho), float((rho + 1) / 2)

def car(actual, predicted, threshold=None):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    if threshold is None: threshold = float(np.nanmedian(actual))
    return float(np.mean((predicted > threshold) == (actual > threshold))), threshold

def stability(actual, predicted, n_blocks=5):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    if len(actual) < 6: return np.nan
    blocks = np.array_split(np.arange(len(actual)), n_blocks)
    rmses = np.array([np.sqrt(np.mean((predicted[b] - actual[b]) ** 2)) for b in blocks if len(b) > 0], dtype=float)
    denom = np.max(rmses) if np.max(rmses) != 0 else 1.0
    return float(np.clip(1 - np.std(rmses) / denom, 0, 1))

def empirical_pi(actual, predicted):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    resid = predicted - actual
    sigma = float(np.std(resid, ddof=0))
    lo = predicted - 1.96 * sigma
    hi = predicted + 1.96 * sigma
    return lo, hi, sigma

def picp(actual, lo, hi):
    actual = to_numpy(actual)
    return float(np.mean((actual >= lo) & (actual <= hi)))

def disteq(actual, predicted):
    ks_stat, _ = ks_2samp(actual, predicted)
    return float(max(0, 1 - ks_stat))

def vareq(actual, predicted):
    _, p = levene(actual, predicted, center="median")
    return 1 if p >= 0.05 else 0

def tail(actual, predicted):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    iqr = np.subtract(*np.percentile(actual, [75, 25]))
    return float(np.clip(1 - abs(np.quantile(predicted, 0.95) - np.quantile(actual, 0.95)) / (iqr + 1e-9), 0, 1))

def equivalence(actual, predicted, delta=None, alpha=0.05):
    actual = to_numpy(actual); predicted = to_numpy(predicted)
    resid = predicted - actual
    if delta is None: delta = 0.05 * np.std(actual, ddof=0) if np.std(actual, ddof=0) > 0 else 0.05
    mean_d = float(np.mean(resid))
    sd = np.std(resid, ddof=1) if len(resid) > 1 else 0.0
    se = sd / np.sqrt(len(resid)) if sd > 0 else 0.0
    if se == 0: return 1 if abs(mean_d) < delta else 0
    t1 = (mean_d + delta) / se
    p1 = 1 - student_t.cdf(t1, df=len(resid) - 1)
    t2 = (mean_d - delta) / se
    p2 = student_t.cdf(t2, df=len(resid) - 1)
    return 1 if (p1 < alpha and p2 < alpha) else 0

def ensure_parent(path):
    if path: Path(path).parent.mkdir(parents=True, exist_ok=True)

def export_bundle(df=None, summary=None, metrics=None, export_excel=None, export_csv=None, export_json=None, export_txt=None):
    out = {}
    if export_excel:
        ensure_parent(export_excel)
        with pd.ExcelWriter(export_excel) as writer:
            if summary is not None: pd.DataFrame([summary]).to_excel(writer, sheet_name="Summary", index=False)
            if metrics is not None: pd.DataFrame([metrics]).to_excel(writer, sheet_name="Metrics", index=False)
            if df is not None: df.to_excel(writer, sheet_name="Details", index=False)
        out["excel"] = str(export_excel)
    if export_csv and df is not None:
        ensure_parent(export_csv); df.to_csv(export_csv, index=False); out["csv"] = str(export_csv)
    if export_json:
        ensure_parent(export_json)
        with open(export_json, "w", encoding="utf-8") as f: json.dump({"summary": summary, "metrics": metrics}, f, indent=2)
        out["json"] = str(export_json)
    if export_txt:
        ensure_parent(export_txt)
        with open(export_txt, "w", encoding="utf-8") as f:
            f.write("PMRI Results\n")
            if summary:
                for k,v in summary.items(): f.write(f"{k}: {v}\n")
            if metrics:
                f.write("\nMetrics\n")
                for k,v in metrics.items(): f.write(f"{k}: {v}\n")
        out["txt"] = str(export_txt)
    return out
