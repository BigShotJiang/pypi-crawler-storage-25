from __future__ import annotations
import numpy as np
from .utils import classify, common_metrics, export_bundle
from .plots import make_basic_plots

def compute_pmri_sri(df, actual_col, predicted_col, lat_col, lon_col, export_excel=None, export_csv=None, export_json=None, export_txt=None, make_plots=False, plot_dir=None):
    d = df.copy()
    actual = d[actual_col].to_numpy(dtype=float); predicted = d[predicted_col].to_numpy(dtype=float)
    resid = predicted - actual
    sigma = float(np.std(resid, ddof=0))
    lo = predicted - 1.96 * sigma; hi = predicted + 1.96 * sigma
    covered = ((actual >= lo) & (actual <= hi)).astype(int)
    rmse_local = np.sqrt(resid ** 2); bias_local = np.abs(resid)
    rmse_norm = (rmse_local - rmse_local.min()) / (rmse_local.max() - rmse_local.min() + 1e-9)
    bias_norm = (bias_local - bias_local.min()) / (bias_local.max() - bias_local.min() + 1e-9)
    sri = (1 - rmse_norm + 1 - bias_norm + covered) / 3.0
    d["Residual"] = resid; d["PI_lo_95"] = lo; d["PI_hi_95"] = hi; d["Covered_PI95"] = covered; d["PMRI_SRI"] = sri; d["PMRI_SRI_Class"] = [classify(v) for v in sri]
    sri_mean = float(np.nanmean(sri))
    metrics = common_metrics(actual, predicted)
    summary = {"sri_mean": sri_mean, "class": classify(sri_mean)}
    exports = export_bundle(d, summary, metrics, export_excel, export_csv, export_json, export_txt)
    plots = make_basic_plots(actual, predicted, {"SRI_mean": sri_mean}, plot_dir, "pmri_sri") if make_plots else []
    return {**summary, "metrics": metrics, "data": d, "exports": exports, "plots": plots}
