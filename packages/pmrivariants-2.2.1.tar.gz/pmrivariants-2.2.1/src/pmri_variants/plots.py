from __future__ import annotations
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

def make_basic_plots(actual, predicted, components=None, plot_dir=None, prefix="pmri"):
    if plot_dir is None: return []
    plot_dir = Path(plot_dir); plot_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    actual = np.asarray(actual, dtype=float); predicted = np.asarray(predicted, dtype=float)
    residual = predicted - actual

    fig, ax = plt.subplots(figsize=(5,4))
    ax.scatter(actual, predicted, alpha=0.7)
    mn = min(actual.min(), predicted.min()); mx = max(actual.max(), predicted.max())
    ax.plot([mn, mx], [mn, mx], linestyle="--")
    ax.set_xlabel("Actual"); ax.set_ylabel("Predicted"); ax.set_title("Actual vs Predicted")
    p = plot_dir / f"{prefix}_scatter.png"; fig.tight_layout(); fig.savefig(p, dpi=200); plt.close(fig); paths.append(str(p))

    fig, ax = plt.subplots(figsize=(5,4))
    ax.hist(residual, bins=15)
    ax.set_xlabel("Residual"); ax.set_ylabel("Frequency"); ax.set_title("Residual Histogram")
    p = plot_dir / f"{prefix}_residual_hist.png"; fig.tight_layout(); fig.savefig(p, dpi=200); plt.close(fig); paths.append(str(p))

    if components:
        fig, ax = plt.subplots(figsize=(7,4))
        names = list(components.keys()); vals = list(components.values())
        ax.bar(names, vals); ax.set_ylim(0, 1.05); ax.set_ylabel("Score"); ax.set_title("PMRI Component Comparison")
        ax.tick_params(axis='x', rotation=45)
        p = plot_dir / f"{prefix}_components.png"; fig.tight_layout(); fig.savefig(p, dpi=200); plt.close(fig); paths.append(str(p))
    return paths
