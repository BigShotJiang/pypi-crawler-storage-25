from __future__ import annotations
import numpy as np
from sklearn.cluster import KMeans
from .utils import classify, rank01, car, stability, empirical_pi, picp, disteq, vareq, tail, equivalence, common_metrics, export_bundle
from .plots import make_basic_plots

def compute_pmri_lite(actual, predicted, export_excel=None, export_csv=None, export_json=None, export_txt=None, make_plots=False, plot_dir=None):
    rho, r01 = rank01(actual, predicted)
    metrics = common_metrics(actual, predicted)
    summary = {"pmri_lite": r01, "class": classify(r01)}
    import pandas as pd
    details = pd.DataFrame({"Actual": np.asarray(actual, float), "Predicted": np.asarray(predicted, float)})
    details["PMRI_Lite"] = r01; details["PMRI_Lite_Class"] = classify(r01)
    exports = export_bundle(details, summary, metrics, export_excel, export_csv, export_json, export_txt)
    plots = make_basic_plots(actual, predicted, {"Rank01": r01}, plot_dir, "pmri_lite") if make_plots else []
    return {**summary, "metrics": metrics, "details": details, "exports": exports, "plots": plots}

def compute_pmri_core(actual, predicted, threshold=None, export_excel=None, export_csv=None, export_json=None, export_txt=None, make_plots=False, plot_dir=None):
    actual = np.asarray(actual, float); predicted = np.asarray(predicted, float)
    _, r01 = rank01(actual, predicted); c, threshold = car(actual, predicted, threshold); s = stability(actual, predicted)
    score = float(np.nanmean([c, s, r01]))
    metrics = common_metrics(actual, predicted)
    summary = {"pmri_core": score, "class": classify(score), "rank01": r01, "car": c, "stability": s, "threshold": threshold}
    import pandas as pd
    details = pd.DataFrame({"Actual": actual, "Predicted": predicted})
    details["PMRI_Core"] = score; details["PMRI_Core_Class"] = classify(score)
    exports = export_bundle(details, summary, metrics, export_excel, export_csv, export_json, export_txt)
    plots = make_basic_plots(actual, predicted, {"Rank01": r01, "CAR": c, "Stability": s}, plot_dir, "pmri_core") if make_plots else []
    return {**summary, "metrics": metrics, "details": details, "exports": exports, "plots": plots}

def compute_pmri_plus(actual, predicted, threshold=None, delta=None, export_excel=None, export_csv=None, export_json=None, export_txt=None, make_plots=False, plot_dir=None):
    actual = np.asarray(actual, float); predicted = np.asarray(predicted, float)
    rho, r01 = rank01(actual, predicted); c, threshold = car(actual, predicted, threshold); s = stability(actual, predicted)
    lo, hi, sigma = empirical_pi(actual, predicted); p = picp(actual, lo, hi); d = disteq(actual, predicted); v = vareq(actual, predicted); t = tail(actual, predicted); e = equivalence(actual, predicted, delta)
    score = float(np.nanmean([p, c, s, d, v, t, r01, e]))
    metrics = common_metrics(actual, predicted)
    summary = {"pmri_plus": score, "class": classify(score), "rank01": r01, "car": c, "stability": s, "picp": p, "disteq": d, "vareq": v, "tail": t, "equivalence": e, "threshold": threshold, "pi_sigma": sigma}
    import pandas as pd
    details = pd.DataFrame({"Actual": actual, "Predicted": predicted, "PI_lo_95": lo, "PI_hi_95": hi})
    details["Covered_PI95"] = ((actual >= lo) & (actual <= hi)).astype(int)
    details["PMRI_Plus"] = score; details["PMRI_Plus_Class"] = classify(score)
    exports = export_bundle(details, summary, metrics, export_excel, export_csv, export_json, export_txt)
    comps = {"PICP": p, "CAR": c, "Stability": s, "DistEq": d, "VarEq": v, "Tail": t, "Rank01": r01, "Equivalence": e}
    plots = make_basic_plots(actual, predicted, comps, plot_dir, "pmri_plus") if make_plots else []
    return {**summary, "metrics": metrics, "details": details, "exports": exports, "plots": plots}

def compute_pmri_plus_data_driven(df, actual_col, predicted_col, feature_cols=None, n_clusters=3, export_excel=None, export_csv=None, export_json=None, export_txt=None, make_plots=False, plot_dir=None):
    data = df.copy()
    if feature_cols is None:
        feature_cols = [c for c in data.select_dtypes(include=["number"]).columns if c not in [actual_col, predicted_col]]
    X = data[feature_cols].select_dtypes(include=["number"]).fillna(data[feature_cols].median(numeric_only=True))
    labels = KMeans(n_clusters=n_clusters, n_init=10, random_state=42).fit_predict(X)
    data["Regime"] = labels
    scores = []; weights = []; regimes = []
    for g in sorted(np.unique(labels)):
        sub = data[data["Regime"] == g]
        if len(sub) >= 4:
            res = compute_pmri_plus(sub[actual_col], sub[predicted_col])
            scores.append(res["pmri_plus"]); weights.append(len(sub)); regimes.append({"regime": int(g), "n": int(len(sub)), "pmri_plus": res["pmri_plus"], "class": res["class"]})
    score = float(np.average(scores, weights=weights)) if weights else np.nan
    metrics = common_metrics(data[actual_col], data[predicted_col])
    summary = {"pmri_plus_dd": score, "class": classify(score), "feature_cols": feature_cols, "n_clusters": n_clusters}
    exports = export_bundle(data, summary, metrics, export_excel, export_csv, export_json, export_txt)
    comps = {f"Regime_{r['regime']}": r["pmri_plus"] for r in regimes} if regimes else None
    plots = make_basic_plots(data[actual_col], data[predicted_col], comps, plot_dir, "pmri_dd") if make_plots else []
    return {**summary, "metrics": metrics, "regimes": regimes, "data": data, "exports": exports, "plots": plots}
