"""Autonomous Ralph convergence loop built from Mobius QA and evolve."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, TypedDict

from mobius.config import MobiusPaths
from mobius.core.types import ExitCode
from mobius.persistence.event_store import EventRecord, EventStore
from mobius.workflow.evolve import prepare_evolution, run_foreground
from mobius.workflow.ids import readable_session_id
from mobius.workflow.lateral import Suggestion, suggest_persona
from mobius.workflow.lifecycle import (
    DetachedWorkerSpec,
    WorkerInterrupted,
    append_and_emit,
    cleanup_pid,
    start_detached_worker_process,
    write_pid,
)
from mobius.workflow.qa import Verdict, evaluate_run_qa

RALPH_STAGNATION_REASONS = frozenset(
    {
        "converged",
        "period_two_oscillation",
        "repetitive_feedback",
        "max_generations",
    }
)

RalphStopReason = Literal[
    "dry_run",
    "qa_passed",
    "stagnation",
    "max_iterations",
    "evolve_failed",
]


class RalphSourceNotFoundError(ValueError):
    """Raised when Ralph cannot find the requested source run."""


class RalphMetadata(TypedDict):
    source_run_id: str
    max_iterations: int


@dataclass(frozen=True)
class RalphPaths:
    """Filesystem paths for one Ralph session."""

    directory: Path
    pid_file: Path
    log_file: Path
    metadata_file: Path


@dataclass(frozen=True)
class PreparedRalph:
    """A prepared Ralph convergence loop ready to execute."""

    ralph_id: str
    source_run_id: str
    max_iterations: int
    paths: RalphPaths


@dataclass(frozen=True)
class RalphIteration:
    """One Ralph loop iteration."""

    iteration: int
    run_id: str
    qa_verdict: str
    evolution_id: str | None = None
    evolution_reason: str | None = None
    persona: str | None = None
    persona_reason: str | None = None


@dataclass(frozen=True)
class RalphResult:
    """Structured result for a Ralph convergence loop."""

    run_id: str | None
    max_iterations: int
    dry_run: bool
    stop_reason: RalphStopReason
    ralph_id: str | None = None
    iterations: list[RalphIteration] = field(default_factory=list)
    steps: list[str] = field(default_factory=list)
    next_command: str | None = None
    exit_code: int = int(ExitCode.OK)

    @property
    def completed(self) -> bool:
        """Return whether Ralph reached a successful QA pass."""
        return self.stop_reason == "qa_passed"


@dataclass(frozen=True)
class _EvolutionSummary:
    evolution_id: str
    reason: str | None
    suggestion: Suggestion | None


def explain_ralph(
    run_id: str | None,
    *,
    max_iterations: int,
) -> RalphResult:
    """Return the non-mutating Ralph plan for dry-run output."""
    return RalphResult(
        run_id=run_id,
        ralph_id=None,
        max_iterations=max_iterations,
        dry_run=True,
        stop_reason="dry_run",
        steps=_ralph_steps(),
        next_command=(
            f"mobius ralph --from {run_id} --max-iterations {max_iterations}"
            if run_id
            else None
        ),
    )


def run_ralph(
    paths: MobiusPaths,
    run_id: str | None,
    *,
    max_iterations: int = 10,
    stream_events: bool = True,
    ralph_id: str | None = None,
) -> RalphResult:
    """Run QA -> one-generation evolve until pass, stagnation, or iteration cap."""
    resolved_run_id = run_id or latest_run_id(paths)
    if resolved_run_id is None:
        raise RalphSourceNotFoundError(
            "aucun run disponible; commencez avec `mobius go \"votre idée\"`"
        )

    capped_iterations = max(1, max_iterations)
    session_id = ralph_id or readable_session_id("ralph", resolved_run_id)

    with EventStore(paths.event_store) as store:
        row = store.connection.execute(
            "SELECT status, metadata FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()

        if row is None:
            store.create_session(
                session_id,
                runtime="ralph",
                metadata={"source_run_id": resolved_run_id, "max_iterations": capped_iterations},
                status="running",
            )
        else:
            previous_metadata: dict[str, object] = {}
            raw_metadata = "{}"
            try:
                raw_metadata = row["metadata"]
                if isinstance(raw_metadata, str):
                    parsed = json.loads(raw_metadata)
                    if isinstance(parsed, dict):
                        previous_metadata = parsed
            except json.JSONDecodeError:
                previous_metadata = {}

            if isinstance(raw_metadata, str):
                merged = {
                    **previous_metadata,
                    "source_run_id": resolved_run_id,
                    "max_iterations": capped_iterations,
                }
                store.connection.execute(
                    "UPDATE sessions SET status = ?, metadata = ? WHERE session_id = ?",
                    ("running", json.dumps(merged, sort_keys=True), session_id),
                )

        existing_events = store.read_events(session_id)
        iterations = _load_ralph_iterations(existing_events)

        append_and_emit(
            store,
            session_id,
            "ralph.started",
            {"source_run_id": resolved_run_id, "max_iterations": capped_iterations},
            stream_events=stream_events,
        )
    try:
        for iteration in range(len(iterations) + 1, capped_iterations + 1):

            report = evaluate_run_qa(paths.event_store, resolved_run_id)
            if report is None:
                raise RalphSourceNotFoundError(f"run introuvable : {resolved_run_id}")
            qa_verdict = report.summary.global_verdict.value
            if report.summary.global_verdict == Verdict.PASS:
                item = RalphIteration(
                    iteration=iteration,
                    run_id=resolved_run_id,
                    qa_verdict=qa_verdict,
                )
                iterations.append(item)
                _record_ralph_iteration(paths, session_id, item, stream_events=stream_events)
                result = RalphResult(
                    run_id=resolved_run_id,
                    ralph_id=session_id,
                    max_iterations=capped_iterations,
                    dry_run=False,
                    stop_reason="qa_passed",
                    iterations=iterations,
                    steps=_ralph_steps(),
                )
                _record_ralph_terminal(paths, session_id, result, stream_events=stream_events)
                return result

            prepared = prepare_evolution(paths, resolved_run_id, generations=1)
            exit_code = run_foreground(paths, prepared)
            summary = _read_evolution_summary(paths, prepared.evolution_id)
            item = RalphIteration(
                iteration=iteration,
                run_id=resolved_run_id,
                qa_verdict=qa_verdict,
                evolution_id=prepared.evolution_id,
                evolution_reason=summary.reason,
                persona=summary.suggestion.persona if summary.suggestion else None,
                persona_reason=summary.suggestion.reason if summary.suggestion else None,
            )
            iterations.append(item)
            _record_ralph_iteration(paths, session_id, item, stream_events=stream_events)
            if exit_code != int(ExitCode.OK):
                result = RalphResult(
                    run_id=resolved_run_id,
                    ralph_id=session_id,
                    max_iterations=capped_iterations,
                    dry_run=False,
                    stop_reason="evolve_failed",
                    iterations=iterations,
                    steps=_ralph_steps(),
                    exit_code=exit_code,
                )
                _record_ralph_terminal(paths, session_id, result, stream_events=stream_events)
                return result
            if summary.reason in RALPH_STAGNATION_REASONS:
                result = RalphResult(
                    run_id=resolved_run_id,
                    ralph_id=session_id,
                    max_iterations=capped_iterations,
                    dry_run=False,
                    stop_reason="stagnation",
                    iterations=iterations,
                    steps=_ralph_steps(),
                )
                _record_ralph_terminal(paths, session_id, result, stream_events=stream_events)
                return result
            if summary.reason == "criteria_all_passed":
                result = RalphResult(
                    run_id=resolved_run_id,
                    ralph_id=session_id,
                    max_iterations=capped_iterations,
                    dry_run=False,
                    stop_reason="qa_passed",
                    iterations=iterations,
                    steps=_ralph_steps(),
                )
                _record_ralph_terminal(paths, session_id, result, stream_events=stream_events)
                return result

        result = RalphResult(
            run_id=resolved_run_id,
            ralph_id=session_id,
            max_iterations=capped_iterations,
            dry_run=False,
            stop_reason="max_iterations",
            iterations=iterations,
            steps=_ralph_steps(),
        )
        _record_ralph_terminal(paths, session_id, result, stream_events=stream_events)
        return result
    except Exception:
        _record_ralph_failure(paths, session_id, stream_events=stream_events)
        raise


def get_ralph_paths(paths: MobiusPaths, ralph_id: str) -> RalphPaths:
    """Return the Ralph directory paths for ``ralph_id``."""
    directory = paths.state_dir / "ralph" / ralph_id
    return RalphPaths(
        directory=directory,
        pid_file=directory / "pid",
        log_file=directory / "log",
        metadata_file=directory / "metadata.json",
    )


def prepare_ralph(
    paths: MobiusPaths,
    run_id: str | None,
    *,
    max_iterations: int,
) -> PreparedRalph:
    """Resolve a source run and create durable Ralph metadata."""
    source_run_id = run_id or latest_run_id(paths)
    if source_run_id is None:
        raise RalphSourceNotFoundError(
            "aucun run disponible; commencez avec `mobius go \"votre idée\"`"
        )
    ralph_id = readable_session_id("ralph", source_run_id)
    capped_iterations = max(1, max_iterations)
    ralph_paths = get_ralph_paths(paths, ralph_id)
    ralph_paths.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(ralph_paths.directory, 0o700)
    ralph_paths.metadata_file.write_text(
        json.dumps(
            {"source_run_id": source_run_id, "max_iterations": capped_iterations},
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    os.chmod(ralph_paths.metadata_file, 0o600)
    return PreparedRalph(
        ralph_id=ralph_id,
        source_run_id=source_run_id,
        max_iterations=capped_iterations,
        paths=ralph_paths,
    )


def start_detached_worker(paths: MobiusPaths, prepared: PreparedRalph) -> int:
    """Fork a detached Ralph worker and write its PID file."""
    return start_detached_worker_process(
        paths,
        DetachedWorkerSpec(
            session_id=prepared.ralph_id,
            runtime="ralph",
            metadata={
                "source_run_id": prepared.source_run_id,
                "max_iterations": prepared.max_iterations,
            },
            command=["mobius", "_worker", "ralph", prepared.ralph_id],
            files=prepared.paths,
        ),
    )


def run_foreground_session(paths: MobiusPaths, prepared: PreparedRalph) -> int:
    """Execute Ralph in the current process."""
    write_pid(prepared.paths.pid_file, os.getpid())
    return execute_ralph(paths, prepared.ralph_id, stream_events=True)


def execute_ralph(paths: MobiusPaths, ralph_id: str, *, stream_events: bool) -> int:
    """Worker entry point for a prepared Ralph session."""
    ralph_paths = get_ralph_paths(paths, ralph_id)
    metadata = _read_ralph_metadata(ralph_paths)
    source_run_id = str(metadata["source_run_id"])
    max_iterations = int(metadata["max_iterations"])
    RalphInterrupted(paths=paths, ralph_id=ralph_id, pid_file=ralph_paths.pid_file).install()
    try:
        result = run_ralph(
            paths,
            source_run_id,
            max_iterations=max_iterations,
            stream_events=stream_events,
            ralph_id=ralph_id,
        )
    finally:
        cleanup_pid(ralph_paths.pid_file)
    return result.exit_code


class RalphInterrupted(WorkerInterrupted):
    """Signal handlers for a running Ralph worker."""

    def __init__(self, *, paths: MobiusPaths, ralph_id: str, pid_file: Path) -> None:
        super().__init__(paths=paths, session_id=ralph_id, runtime="ralph", pid_file=pid_file)

    @property
    def ralph_id(self) -> str:
        """Ralph identifier preserved for callers that inspect the handler."""
        return self.session_id


def resume_ralph(paths: MobiusPaths, ralph_id: str) -> RalphResult:
    """Resume a durable Ralph session by id."""
    metadata = _read_ralph_metadata(get_ralph_paths(paths, ralph_id))
    return run_ralph(
        paths,
        str(metadata["source_run_id"]),
        max_iterations=int(metadata["max_iterations"]),
        ralph_id=ralph_id,
    )


def _read_ralph_metadata(ralph_paths: RalphPaths) -> RalphMetadata:
    try:
        raw = json.loads(ralph_paths.metadata_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        msg = f"session Ralph invalide : {ralph_paths.directory.name}"
        raise RalphSourceNotFoundError(msg) from exc
    if not isinstance(raw, dict):
        msg = f"metadata Ralph invalide : {ralph_paths.directory.name}"
        raise RalphSourceNotFoundError(msg)
    if not isinstance(raw.get("source_run_id"), str):
        msg = f"metadata Ralph sans source_run_id : {ralph_paths.directory.name}"
        raise RalphSourceNotFoundError(msg)
    max_iterations = raw.get("max_iterations")
    if not isinstance(max_iterations, int):
        msg = f"metadata Ralph sans max_iterations entier : {ralph_paths.directory.name}"
        raise RalphSourceNotFoundError(msg)
    return {
        "source_run_id": raw["source_run_id"],
        "max_iterations": raw["max_iterations"],
    }


def _optional_str(payload: dict[str, object], key: str) -> str | None:
    value = payload.get(key)
    return value if isinstance(value, str) else None


def _load_ralph_iterations(events: list[EventRecord]) -> list[RalphIteration]:
    iterations: list[RalphIteration] = []
    for event in events:
        if event.type != "ralph.iteration":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            continue
        iteration = payload.get("iteration")
        run_id = payload.get("run_id")
        qa_verdict = payload.get("qa_verdict")
        if (
            not isinstance(iteration, int)
            or not isinstance(run_id, str)
            or not isinstance(qa_verdict, str)
        ):
            continue
        iterations.append(
            RalphIteration(
                iteration=iteration,
                run_id=run_id,
                qa_verdict=qa_verdict,
                evolution_id=_optional_str(payload, "evolution_id"),
                evolution_reason=_optional_str(payload, "evolution_reason"),
                persona=_optional_str(payload, "persona"),
                persona_reason=_optional_str(payload, "persona_reason"),
            )
        )
    return iterations


def _record_ralph_iteration(
    paths: MobiusPaths,
    ralph_id: str,
    item: RalphIteration,
    *,
    stream_events: bool,
) -> None:
    with EventStore(paths.event_store) as store:
        append_and_emit(
            store,
            ralph_id,
            "ralph.iteration",
            {
                "iteration": item.iteration,
                "run_id": item.run_id,
                "qa_verdict": item.qa_verdict,
                "evolution_id": item.evolution_id,
                "evolution_reason": item.evolution_reason,
                "persona": item.persona,
                "persona_reason": item.persona_reason,
            },
            stream_events=stream_events,
        )


def _record_ralph_terminal(
    paths: MobiusPaths,
    ralph_id: str,
    result: RalphResult,
    *,
    stream_events: bool,
) -> None:
    event_type = "ralph.failed" if result.exit_code != int(ExitCode.OK) else "ralph.completed"
    status = "failed" if event_type == "ralph.failed" else "completed"
    with EventStore(paths.event_store) as store:
        append_and_emit(
            store,
            ralph_id,
            event_type,
            {
                "run_id": result.run_id,
                "stop_reason": result.stop_reason,
                "iterations": len(result.iterations),
                "exit_code": result.exit_code,
            },
            stream_events=stream_events,
        )
        store.end_session(ralph_id, status=status)


def _record_ralph_failure(paths: MobiusPaths, ralph_id: str, *, stream_events: bool) -> None:
    with EventStore(paths.event_store) as store:
        row = store.connection.execute(
            "SELECT status FROM sessions WHERE session_id = ?",
            (ralph_id,),
        ).fetchone()
        if row is not None and str(row["status"]) in {"completed", "failed", "cancelled"}:
            return
        append_and_emit(
            store,
            ralph_id,
            "ralph.failed",
            {"reason": "exception"},
            stream_events=stream_events,
        )
        store.end_session(ralph_id, status="failed")


def latest_run_id(paths: MobiusPaths) -> str | None:
    """Return the latest run session id, if an event store exists."""
    if not paths.event_store.exists():
        return None
    with EventStore(paths.event_store, read_only=True) as store:
        row = store.connection.execute(
            """
            SELECT session_id
            FROM sessions
            WHERE runtime = 'run'
            ORDER BY started_at DESC, session_id DESC
            LIMIT 1
            """
        ).fetchone()
    return None if row is None else str(row["session_id"])


def _read_evolution_summary(paths: MobiusPaths, evolution_id: str) -> _EvolutionSummary:
    reason: str | None = None
    suggestion: Suggestion | None = None
    with EventStore(paths.event_store, read_only=True) as store:
        for event in store.read_events(evolution_id):
            payload: Any = event.payload_data
            if event.type == "evolution.completed" and isinstance(payload, dict):
                raw_reason = payload.get("reason")
                reason = raw_reason if isinstance(raw_reason, str) else None
            if event.type == "agent.suggest_persona" and isinstance(payload, dict):
                persona = payload.get("persona")
                detail = payload.get("reason")
                confidence = payload.get("confidence")
                if isinstance(persona, str) and isinstance(detail, str):
                    suggestion = Suggestion(
                        persona,
                        detail,
                        confidence if isinstance(confidence, float | int) else 0.0,
                    )
        if suggestion is None:
            try:
                suggestion = suggest_persona(store, evolution_id)
            except Exception:
                suggestion = None
    return _EvolutionSummary(evolution_id=evolution_id, reason=reason, suggestion=suggestion)


def _ralph_steps() -> list[str]:
    return [
        "Lancer `mobius qa` sur le run source.",
        "Si QA passe, arrêter proprement.",
        "Si QA échoue, lancer `mobius evolve --generations 1 --foreground`.",
        "Lire la raison de fin d'évolution et la persona suggérée.",
        "Répéter jusqu'à pass, stagnation/convergence ou cap d'itérations.",
    ]
