"""UltraQA: deterministic QA followed by a bounded Ralph fix loop."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Literal

from mobius.config import MobiusPaths
from mobius.core.types import ExitCode
from mobius.persistence.event_store import EventStore
from mobius.workflow.ids import readable_session_id
from mobius.workflow.lifecycle import append_and_emit
from mobius.workflow.qa import Verdict, evaluate_run_qa
from mobius.workflow.ralph import latest_run_id, run_ralph

UltraQAStopReason = Literal[
    "dry_run",
    "qa_passed",
    "fixed_by_ralph",
    "fix_loop_incomplete",
    "source_not_found",
]


class UltraQASourceNotFoundError(ValueError):
    """Raised when UltraQA cannot find the requested source run."""


@dataclass(frozen=True)
class UltraQAResult:
    """Structured result for the UltraQA fix loop."""

    run_id: str | None
    max_iterations: int
    dry_run: bool
    stop_reason: UltraQAStopReason
    ultraqa_id: str | None = None
    initial_verdict: str | None = None
    final_verdict: str | None = None
    fixed: bool = False
    ralph_id: str | None = None
    ralph_stop_reason: str | None = None
    steps: list[str] = field(default_factory=list)
    next_command: str | None = None
    exit_code: int = int(ExitCode.OK)

    @property
    def completed(self) -> bool:
        """Return whether UltraQA ended with a passing QA state."""
        return self.fixed


def explain_ultraqa(run_id: str | None, *, max_iterations: int) -> UltraQAResult:
    """Return the non-mutating UltraQA plan for dry-run output."""
    capped_iterations = max(0, max_iterations)
    return UltraQAResult(
        run_id=run_id,
        max_iterations=capped_iterations,
        dry_run=True,
        stop_reason="dry_run",
        steps=_ultraqa_steps(),
        next_command=(
            f"mobius ultraqa {run_id} --max-iterations {capped_iterations}"
            if run_id
            else f"mobius ultraqa --max-iterations {capped_iterations}"
        ),
    )


def run_ultraqa(
    paths: MobiusPaths,
    run_id: str | None,
    *,
    max_iterations: int = 3,
    stream_events: bool = True,
) -> UltraQAResult:
    """Run QA once, then Ralph as a bounded deterministic fix loop if needed."""
    resolved_run_id = run_id or latest_run_id(paths)
    if resolved_run_id is None:
        raise UltraQASourceNotFoundError(
            "aucun run disponible; commencez avec `mobius go \"votre idée\"`"
        )

    capped_iterations = max(0, max_iterations)
    ultraqa_id = readable_session_id("ultraqa", resolved_run_id)
    _start_ultraqa_session(paths, ultraqa_id, resolved_run_id, capped_iterations, stream_events)

    report = evaluate_run_qa(paths.event_store, resolved_run_id)
    if report is None:
        _record_ultraqa_terminal(
            paths,
            ultraqa_id,
            run_id=resolved_run_id,
            stop_reason="source_not_found",
            fixed=False,
            exit_code=int(ExitCode.NOT_FOUND),
            stream_events=stream_events,
        )
        raise UltraQASourceNotFoundError(f"run introuvable : {resolved_run_id}")

    initial_verdict = _verdict_value(report.summary.global_verdict)
    _record_qa_checked(paths, ultraqa_id, resolved_run_id, initial_verdict, stream_events)
    if report.summary.global_verdict == Verdict.PASS:
        result = UltraQAResult(
            run_id=resolved_run_id,
            ultraqa_id=ultraqa_id,
            max_iterations=capped_iterations,
            dry_run=False,
            initial_verdict=initial_verdict,
            final_verdict=initial_verdict,
            fixed=True,
            stop_reason="qa_passed",
            steps=_ultraqa_steps(),
        )
        _record_ultraqa_terminal_from_result(paths, result, stream_events=stream_events)
        return result

    if capped_iterations == 0:
        result = UltraQAResult(
            run_id=resolved_run_id,
            ultraqa_id=ultraqa_id,
            max_iterations=capped_iterations,
            dry_run=False,
            initial_verdict=initial_verdict,
            final_verdict=initial_verdict,
            fixed=False,
            stop_reason="fix_loop_incomplete",
            steps=_ultraqa_steps(),
            exit_code=int(ExitCode.GENERIC_ERROR),
        )
        _record_ultraqa_terminal_from_result(paths, result, stream_events=stream_events)
        return result

    _record_fix_started(paths, ultraqa_id, resolved_run_id, capped_iterations, stream_events)
    ralph_result = run_ralph(
        paths,
        resolved_run_id,
        max_iterations=capped_iterations,
        stream_events=stream_events,
    )
    fixed = ralph_result.completed and ralph_result.exit_code == int(ExitCode.OK)
    stop_reason: UltraQAStopReason = "fixed_by_ralph" if fixed else "fix_loop_incomplete"
    exit_code = int(ExitCode.OK) if fixed else int(ExitCode.GENERIC_ERROR)
    final_verdict = "pass" if fixed else initial_verdict
    result = UltraQAResult(
        run_id=resolved_run_id,
        ultraqa_id=ultraqa_id,
        max_iterations=capped_iterations,
        dry_run=False,
        initial_verdict=initial_verdict,
        final_verdict=final_verdict,
        fixed=fixed,
        stop_reason=stop_reason,
        ralph_id=ralph_result.ralph_id,
        ralph_stop_reason=ralph_result.stop_reason,
        steps=_ultraqa_steps(),
        exit_code=exit_code,
    )
    _record_ultraqa_terminal_from_result(paths, result, stream_events=stream_events)
    return result


def _start_ultraqa_session(
    paths: MobiusPaths,
    ultraqa_id: str,
    source_run_id: str,
    max_iterations: int,
    stream_events: bool,
) -> None:
    metadata = {"source_run_id": source_run_id, "max_iterations": max_iterations}
    with EventStore(paths.event_store) as store:
        row = store.connection.execute(
            "SELECT status FROM sessions WHERE session_id = ?",
            (ultraqa_id,),
        ).fetchone()
        if row is None:
            store.create_session(ultraqa_id, runtime="ultraqa", metadata=metadata, status="running")
        else:
            store.connection.execute(
                "UPDATE sessions SET status = ?, metadata = ? WHERE session_id = ?",
                ("running", json.dumps(metadata, sort_keys=True), ultraqa_id),
            )
        append_and_emit(
            store,
            ultraqa_id,
            "ultraqa.started",
            metadata,
            stream_events=stream_events,
        )


def _record_qa_checked(
    paths: MobiusPaths,
    ultraqa_id: str,
    run_id: str,
    verdict: str,
    stream_events: bool,
) -> None:
    with EventStore(paths.event_store) as store:
        append_and_emit(
            store,
            ultraqa_id,
            "ultraqa.qa_checked",
            {"run_id": run_id, "verdict": verdict},
            stream_events=stream_events,
        )


def _record_fix_started(
    paths: MobiusPaths,
    ultraqa_id: str,
    run_id: str,
    max_iterations: int,
    stream_events: bool,
) -> None:
    with EventStore(paths.event_store) as store:
        append_and_emit(
            store,
            ultraqa_id,
            "ultraqa.fix_started",
            {"run_id": run_id, "max_iterations": max_iterations, "strategy": "ralph"},
            stream_events=stream_events,
        )


def _record_ultraqa_terminal_from_result(
    paths: MobiusPaths,
    result: UltraQAResult,
    *,
    stream_events: bool,
) -> None:
    if result.ultraqa_id is None:
        return
    _record_ultraqa_terminal(
        paths,
        result.ultraqa_id,
        run_id=result.run_id,
        stop_reason=result.stop_reason,
        fixed=result.fixed,
        exit_code=result.exit_code,
        stream_events=stream_events,
        ralph_id=result.ralph_id,
        initial_verdict=result.initial_verdict,
        final_verdict=result.final_verdict,
    )


def _record_ultraqa_terminal(
    paths: MobiusPaths,
    ultraqa_id: str,
    *,
    run_id: str | None,
    stop_reason: str,
    fixed: bool,
    exit_code: int,
    stream_events: bool,
    ralph_id: str | None = None,
    initial_verdict: str | None = None,
    final_verdict: str | None = None,
) -> None:
    event_type = "ultraqa.completed" if exit_code == int(ExitCode.OK) else "ultraqa.failed"
    status = "completed" if event_type == "ultraqa.completed" else "failed"
    with EventStore(paths.event_store) as store:
        append_and_emit(
            store,
            ultraqa_id,
            event_type,
            {
                "run_id": run_id,
                "stop_reason": stop_reason,
                "fixed": fixed,
                "exit_code": exit_code,
                "ralph_id": ralph_id,
                "initial_verdict": initial_verdict,
                "final_verdict": final_verdict,
            },
            stream_events=stream_events,
        )
        store.end_session(ultraqa_id, status=status)


def _verdict_value(value: object) -> str:
    if isinstance(value, Verdict):
        return value.value
    return str(value)


def _ultraqa_steps() -> list[str]:
    return [
        "Lancer `mobius qa` sur le run source.",
        "Si QA passe, arrêter sans mutation supplémentaire.",
        (
            "Si QA échoue ou reste non vérifiée, lancer `mobius ralph` "
            "comme boucle de correction bornée."
        ),
        "Retourner un verdict final explicite: fixed ou fix_loop_incomplete.",
    ]
