"""Deterministic offline QA heuristics for Mobius runs."""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

from mobius.persistence.event_store import EventRecord, EventStore
from mobius.workflow.criterion_match import (
    command_matches,
    references_for,
)
from mobius.workflow.lifecycle import is_terminal_state
from mobius.workflow.seed import (
    SeedSpec,
    SeedSpecValidationError,
    SpecGrade,
    assign_bronze_grade,
    load_seed_spec,
)
from mobius.workflow.session_facts import (
    SessionFacts,
    decode_json_object,
    parent_id_from_metadata,
    read_session_facts,
    spec_path_from_events,
    spec_path_from_session,
)
from mobius.workflow.verify import ProofRecord, run_verification

_decode_json_object = decode_json_object
_FAILURE_EVENT_TYPES = frozenset({"run.failed", "run.crashed", "run.cancelled", "run.interrupted"})


class Verdict(StrEnum):
    """Ternary QA verdict with worst-wins ordering."""

    PASS = "pass"
    FAIL = "fail"
    UNVERIFIED = "unverified"


class QASummary(BaseModel):
    """Aggregate QA verdict counts."""

    model_config = ConfigDict(extra="forbid")

    total: int
    passed: int
    failed: int
    unverified: int
    global_verdict: Verdict


class QAResult(BaseModel):
    """One deterministic QA check result."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    verdict: Verdict
    detail: str
    output: str | None = None

    @property
    def passed(self) -> bool:
        """Return whether this result is a passing verdict."""
        return self.verdict == Verdict.PASS


class DeltaChange(StrEnum):
    """Classification du changement d'un critère entre deux runs."""

    STABLE = "stable"
    IMPROVED = "improved"
    REGRESSED = "regressed"
    STILL_FAILING = "still_failing"
    NEW = "new"


class QADelta(BaseModel):
    """Delta d'un critère entre le run courant et son parent."""

    model_config = ConfigDict(extra="forbid")

    criterion_id: str
    label: str
    previous_verdict: Verdict | None
    current_verdict: Verdict
    change: DeltaChange


class QAProgression(BaseModel):
    """Score de progression global entre deux runs."""

    model_config = ConfigDict(extra="forbid")

    parent_run_id: str
    previous_passed: int
    previous_total: int
    current_passed: int
    current_total: int
    regressions: int


class QAReport(BaseModel):
    """Structured output for ``mobius qa``."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    mode: str
    state: str
    summary: QASummary
    results: list[QAResult]
    grade: str | None = None
    delta: list[QADelta] | None = None
    progression: QAProgression | None = None


@dataclass(frozen=True)
class _CriteriaEvaluation:
    """Structured internal result for criterion proof checks."""

    results: list[QAResult]
    linked_count: int
    malformed_count: int


def evaluate_run_qa(event_store_path: Path, run_id: str) -> QAReport | None:
    """Evaluate a run with local, deterministic heuristics.

    The offline judge intentionally does not call an LLM. It checks the durable
    event-store facts that indicate a run reached a successful terminal state
    and that its seed spec contains acceptance criteria to judge against.
    """
    with EventStore(event_store_path) as store:
        session = read_session_facts(store, run_id)
        if session is None:
            return None
        events = store.read_events(run_id)

    state = session.status
    spec_criteria_count = _load_success_criteria_count(events, session)
    event_types = {event.type for event in events}
    failure_events = sorted(event_types & _FAILURE_EVENT_TYPES)

    results = [
        QAResult(
            id="session_terminal",
            label="Session reached a terminal state",
            verdict=_bool_verdict(is_terminal_state(state)),
            detail=f"state={state}",
        ),
        QAResult(
            id="run_completed_successfully",
            label="Run completed successfully",
            verdict=_bool_verdict(state == "completed"),
            detail=f"state={state}",
        ),
        QAResult(
            id="event_stream_started",
            label="Event stream contains run.started",
            verdict=_bool_verdict("run.started" in event_types),
            detail=_event_detail("run.started", event_types),
        ),
        QAResult(
            id="event_stream_completed",
            label="Event stream contains run.completed",
            verdict=_bool_verdict("run.completed" in event_types),
            detail=_event_detail("run.completed", event_types),
        ),
        QAResult(
            id="spec_has_success_criteria",
            label="Seed spec contains success criteria",
            verdict=_bool_verdict(spec_criteria_count > 0),
            detail=f"success_criteria={spec_criteria_count}",
        ),
        QAResult(
            id="no_failure_events",
            label="Event stream contains no failure events",
            verdict=_bool_verdict(not failure_events),
            detail=("none" if not failure_events else f"failure_events={','.join(failure_events)}"),
        ),
    ]
    criteria_evaluation = _evaluate_success_criteria(
        event_store_path,
        run_id,
        events,
        session,
    )
    criterion_results = criteria_evaluation.results
    if not criterion_results and spec_criteria_count > 0:
        sentinel = QAResult(
            id="criteria_not_evaluated",
            label=f"{spec_criteria_count} critère(s) déclaré(s) mais non évaluable(s)",
            verdict=Verdict.UNVERIFIED,
            detail="spec introuvable ou invalide — les critères de succès n'ont pas été vérifiés",
        )
        criterion_results = [sentinel]
    results.extend(criterion_results)
    contract_result = _criteria_proof_contract_result(
            max(spec_criteria_count, len(criterion_results)),
        linked_count=criteria_evaluation.linked_count,
        malformed_count=criteria_evaluation.malformed_count,
    )
    if contract_result is not None:
        results.append(contract_result)
    summary = _summarize_results(results, criterion_results)
    grade = _assign_static_grade(events, session)
    if grade is not None:
        with EventStore(event_store_path) as store:
            store.append_event(run_id, "spec.grade_assigned", grade.to_event_payload())
            try:
                store.append_event(
                    run_id,
                    "qa.completed",
                    {
                        "summary": summary.model_dump(mode="json"),
                        "results": [
                            result.model_dump(mode="json")
                            for result in _persisted_qa_results(criterion_results, contract_result)
                        ],
                    },
                )
            except Exception as exc:
                sys.stderr.write(f"mobius: could not record QA completion events: {exc}\n")
    delta_list: list[QADelta] | None = None
    progression: QAProgression | None = None
    parent_id = parent_id_from_metadata(session.metadata)
    if parent_id and criterion_results:
        parent_verdicts = _load_parent_criterion_verdicts(event_store_path, parent_id)
        if parent_verdicts is not None:
            delta_list = _compute_delta(criterion_results, parent_verdicts)
            progression = _compute_progression(
                parent_id, delta_list, parent_verdicts, criterion_results
            )

    return QAReport(
        run_id=run_id,
        mode="offline",
        state=state,
        summary=summary,
        results=results,
        grade=grade.grade if grade is not None else None,
        delta=delta_list,
        progression=progression,
    )


def _criteria_proof_contract_result(
    spec_criteria_count: int, *, linked_count: int, malformed_count: int
) -> QAResult | None:
    """Return the deterministic semantic contract check for QA depth.

    Mobius does not guess whether an implementation "sounds" aligned with the
    goal. It requires each success criterion to be bound to executable evidence:
    either a linked verification command or a global/suite verification command.
    Missing links are reported as ``UNVERIFIED``; malformed commands are ``FAIL``.
    """
    if spec_criteria_count <= 0:
        return None

    expected = max(spec_criteria_count, linked_count)
    unlinked = max(expected - linked_count, 0)
    if malformed_count:
        verdict = Verdict.FAIL
    elif unlinked:
        verdict = Verdict.UNVERIFIED
    else:
        verdict = Verdict.PASS

    return QAResult(
        id="semantic_proof_contract",
        label="Contrat sémantique déterministe: critères liés à des preuves",
        verdict=verdict,
        detail=(
            f"linked={linked_count}/{expected}, "
            f"unlinked={unlinked}, malformed={malformed_count}"
        ),
    )


def _persisted_qa_results(
    criterion_results: list[QAResult], contract_result: QAResult | None
) -> list[QAResult]:
    """Return QA results persisted for lineage/durable evidence."""
    if contract_result is None:
        return criterion_results
    return [*criterion_results, contract_result]


def _load_parent_criterion_verdicts(
    event_store_path: Path, parent_id: str
) -> dict[str, Verdict] | None:
    """Charge les verdicts QA du run parent depuis l'événement qa.completed."""
    with EventStore(event_store_path) as store:
        parent_events = store.read_events(parent_id)
    for event in reversed(parent_events):
        if event.type != "qa.completed":
            continue
        payload = decode_json_object(event.payload)
        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            return None
        verdicts: dict[str, Verdict] = {}
        for raw in raw_results:
            if (
                isinstance(raw, dict)
                and "id" in raw
                and "verdict" in raw
                and str(raw["id"]).startswith("criterion_")
            ):
                try:
                    verdicts[str(raw["id"])] = Verdict(str(raw["verdict"]))
                except ValueError:
                    continue
        return verdicts if verdicts else None
    return None


def _classify_change(previous: Verdict | None, current: Verdict) -> DeltaChange:
    if previous is None:
        return DeltaChange.NEW
    if previous == Verdict.PASS and current == Verdict.PASS:
        return DeltaChange.STABLE
    if previous == Verdict.PASS and current != Verdict.PASS:
        return DeltaChange.REGRESSED
    if previous != Verdict.PASS and current == Verdict.PASS:
        return DeltaChange.IMPROVED
    return DeltaChange.STILL_FAILING


def _compute_delta(
    criterion_results: list[QAResult],
    parent_verdicts: dict[str, Verdict],
) -> list[QADelta]:
    deltas: list[QADelta] = []
    for result in criterion_results:
        previous = parent_verdicts.get(result.id)
        change = _classify_change(previous, result.verdict)
        deltas.append(
            QADelta(
                criterion_id=result.id,
                label=result.label,
                previous_verdict=previous,
                current_verdict=result.verdict,
                change=change,
            )
        )
    return deltas


def _compute_progression(
    parent_id: str,
    delta_list: list[QADelta],
    parent_verdicts: dict[str, Verdict],
    criterion_results: list[QAResult],
) -> QAProgression:
    parent_criterion_verdicts = {
        key: verdict for key, verdict in parent_verdicts.items() if key.startswith("criterion_")
    }
    previous_passed = sum(1 for v in parent_criterion_verdicts.values() if v == Verdict.PASS)
    current_passed = sum(1 for r in criterion_results if r.verdict == Verdict.PASS)
    regressions = sum(1 for d in delta_list if d.change == DeltaChange.REGRESSED)
    return QAProgression(
        parent_run_id=parent_id,
        previous_passed=previous_passed,
        previous_total=len(parent_criterion_verdicts),
        current_passed=current_passed,
        current_total=len(criterion_results),
        regressions=regressions,
    )


def _load_success_criteria_count(events: list[EventRecord], session: SessionFacts) -> int:
    """Return how many success criteria the seed spec declares.

    Prefers the durable count emitted by ``run.completed`` (set once a run
    has executed). Falls back to parsing the seed spec on disk so the check
    still works for runs that have only been seeded — otherwise QA would
    report ``success_criteria=0`` while simultaneously listing those same
    criteria as ``unverified``.
    """
    for event in reversed(events):
        if event.type != "run.completed":
            continue
        payload = decode_json_object(event.payload)
        count = payload.get("success_criteria_count")
        if isinstance(count, int):
            return count
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return 0
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return 0
    return len(spec.success_criteria)


def assign_silver_grade(spec: SeedSpec) -> SpecGrade:
    """Assign the highest static grade available to a parsed spec.

    Silver requires all Bronze checks plus at least one verification command
    linked to every success criterion, at least one non-goal, and an owner.
    """
    bronze = assign_bronze_grade(spec)
    linked_criteria = _success_criteria_with_commands(spec)
    details = {
        **bronze.details,
        "all_success_criteria_linked": linked_criteria == len(spec.success_criteria),
        "non_goals_present": len(spec.non_goals) >= 1,
        "owner_present": _owner_present(spec.owner),
    }
    criteria_met = sum(1 for passed in details.values() if passed)
    grade = "silver" if criteria_met == len(details) else bronze.grade
    return SpecGrade(
        grade=grade,
        criteria_met=criteria_met,
        criteria_total=len(details),
        details=details,
    )


def _assign_static_grade(events: list[EventRecord], session: SessionFacts) -> SpecGrade | None:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return None
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return None
    return assign_silver_grade(spec)


def _evaluate_success_criteria(
    event_store_path: Path,
    run_id: str,
    events: list[EventRecord],
    session: SessionFacts,
) -> _CriteriaEvaluation:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)

    config = _load_verification_config(event_store_path.parent)
    results: list[QAResult] = []
    linked_count = 0
    malformed_count = 0
    with EventStore(event_store_path) as store:
        for index, criterion in enumerate(spec.success_criteria, start=1):
            references = references_for(index, criterion)
            command_specs = [
                command
                for command in spec.verification_commands
                if command_matches(command, references) or _is_global_verification(command)
            ]
            if not command_specs:
                results.append(_unverified_criterion_result(index, criterion))
                continue
            linked_count += 1
            proofs: list[ProofRecord] = []
            for command_spec in command_specs:
                try:
                    proof = run_verification(command_spec, spec_path.parent, config)
                except ValueError as exc:
                    malformed_count += 1
                    results.append(_malformed_command_result(index, criterion, exc))
                    proofs = []
                    break
                store.append_event(
                    run_id,
                    "qa.verification_executed",
                    proof.executed_event_payload(),
                )
                store.append_event(run_id, "qa.proof_collected", proof.proof_event_payload())
                proofs.append(proof)
            if proofs:
                results.append(_qa_result_from_proofs(index, criterion, proofs))
    return _CriteriaEvaluation(
        results=results, linked_count=linked_count, malformed_count=malformed_count
    )


def _load_verification_config(mobius_home: Path) -> dict[str, Any]:
    config_path = mobius_home / "config.json"
    if not config_path.exists():
        return {}
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return dict(raw) if isinstance(raw, dict) else {}


def _is_global_verification(command: dict[str, Any]) -> bool:
    return str(command.get("scope", "")).strip().lower() in {"all", "global", "suite"}


_MAX_OUTPUT_LINES = 50


def _qa_result_from_proofs(index: int, criterion: str, proofs: list[ProofRecord]) -> QAResult:
    verdict = _worst_verdict(
        Verdict.PASS if proof.exit_code == 0 and not proof.timed_out else Verdict.FAIL
        for proof in proofs
    )
    proof_details = []
    output_parts: list[str] = []
    for proof in proofs:
        timeout_detail = ", timed_out=true" if proof.timed_out else ""
        truncated_detail = ", truncated=true" if proof.truncated else ""
        proof_details.append(
            f"{proof.command!r}: exit_code={proof.exit_code}, duration_ms={proof.duration_ms}"
            f"{timeout_detail}{truncated_detail}"
        )
        if proof.exit_code != 0 or proof.timed_out:
            output_parts.extend(_collect_proof_output(proof))
    output = "\n".join(output_parts)[-_MAX_OUTPUT_LINES * 200 :] if output_parts else None
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=verdict,
        detail="; ".join(proof_details),
        output=_tail_lines(output, _MAX_OUTPUT_LINES) if output else None,
    )


def _collect_proof_output(proof: ProofRecord) -> list[str]:
    parts: list[str] = []
    if proof.stdout.strip():
        parts.append(proof.stdout.strip())
    if proof.stderr.strip():
        parts.append(proof.stderr.strip())
    return parts


def _tail_lines(text: str, max_lines: int) -> str:
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    return "\n".join(lines[-max_lines:])


def _unverified_criterion_result(index: int, criterion: str) -> QAResult:
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=Verdict.UNVERIFIED,
        detail="no verification_command linked to this criterion",
    )


def _malformed_command_result(index: int, criterion: str, exc: ValueError) -> QAResult:
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=Verdict.FAIL,
        detail=f"malformed verification_command: {exc}",
    )


def _success_criteria_with_commands(spec: SeedSpec) -> int:
    linked = 0
    for index, criterion in enumerate(spec.success_criteria, start=1):
        references = references_for(index, criterion)
        if any(command_matches(command, references) for command in spec.verification_commands):
            linked += 1
    return linked


def _owner_present(owner: str | list[str]) -> bool:
    if isinstance(owner, list):
        return any(item.strip() for item in owner)
    return bool(owner.strip())


def _event_detail(event_type: str, event_types: set[str]) -> str:
    return "present" if event_type in event_types else f"missing {event_type}"


def _bool_verdict(passed: bool) -> Verdict:
    return Verdict.PASS if passed else Verdict.FAIL


def _summarize_results(results: list[QAResult], criterion_results: list[QAResult]) -> QASummary:
    counted_results = criterion_results if criterion_results else results
    passed = sum(1 for result in counted_results if result.verdict == Verdict.PASS)
    failed = sum(1 for result in counted_results if result.verdict == Verdict.FAIL)
    unverified = sum(1 for result in counted_results if result.verdict == Verdict.UNVERIFIED)
    return QASummary(
        total=len(counted_results),
        passed=passed,
        failed=failed,
        unverified=unverified,
        global_verdict=_worst_verdict(result.verdict for result in results),
    )


def _worst_verdict(verdicts: Any) -> Verdict:
    worst = Verdict.PASS
    for verdict in verdicts:
        if verdict == Verdict.FAIL:
            return Verdict.FAIL
        if verdict == Verdict.UNVERIFIED:
            worst = Verdict.UNVERIFIED
    return worst
