# Mobius

[![CI](https://github.com/charlescstpierr/mobius-charles/actions/workflows/ci.yml/badge.svg)](https://github.com/charlescstpierr/mobius-charles/actions/workflows/ci.yml)
[![Coverage](https://img.shields.io/badge/coverage-%E2%89%A595%25-brightgreen.svg)](docs/benchmarks.md)
[![PyPI](https://img.shields.io/pypi/v/mobius-charles.svg)](https://pypi.org/project/mobius-charles/)
[![License](https://img.shields.io/github/license/charlescstpierr/mobius-charles)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.12%2B-blue.svg)](pyproject.toml)

Mobius est une CLI Python **local-first, auditable et déterministe** pour piloter des agents IA. Event sourcing SQLite, lineage rejouable, routage d'agent offline (PAL Router) — zéro serveur, zéro dépendance réseau. Un **chemin débutant en une commande** :

```sh
mobius go "je veux une app de recettes"
```

Cette commande clarifie l'idée, écrit `spec.yaml`, crée le seed, lance un run, puis vous indique les prochaines commandes lisibles (`mobius status`, `mobius qa`, `mobius ralph`). Quand l'exécution est activée, `go` transmet l'approbation agent au run généré par défaut; utilisez `--ask-agent` pour reprendre une validation explicite.

> **Event sourcing** — chaque décision, chaque run, chaque évaluation est un événement immuable dans SQLite (WAL). Rejouez n'importe quel état passé avec `mobius lineage`.
>
> **PAL Router** — routage déterministe offline vers l'agent optimal (claude, codex, droid) sans appel LLM. `--agent auto --approve-agent` résout localement.
>
> **Transparence totale** — le code réel reste exécuté par votre agent choisi ou vos commandes locales; Mobius orchestre le happy path et trace les preuves. Pas de serveur, pas de LLM caché.

## Installation

Paquet public PyPI (nom de distribution: `mobius-charles`, commande installée: `mobius`) :

```bash
uv tool install mobius-charles
```

```bash
mobius --help
```

Chemins équivalents :

```sh
pipx install mobius-charles
# ou depuis un checkout de développement
uv tool install . --force
./install.sh
```

Puis démarrez le chemin débutant :

```sh
mobius go "mon idée"
```

## Répertoire d'état

Mobius stocke l'état dans SQLite à `$MOBIUS_HOME/events.db`. Sans `MOBIUS_HOME`, le chemin par défaut est `~/.mobius/events.db`, partagé entre les projets (`shared across every Mobius project`). Pour isoler un workspace :

```sh
export MOBIUS_HOME="$PWD/.mobius"
```

`mobius init` affiche le chemin résolu et `mobius config get event_store` le retourne à tout moment.

## Démarrage rapide

```sh
uv tool install mobius-charles
mobius go "je veux une petite CLI qui salue l'utilisateur"
mobius status
mobius qa
mobius ralph --dry-run
```

Chemin CI/script avancé :

```bash
export MOBIUS_HOME="$(mktemp -d)"  # optionnel: isole l'état
cat > /tmp/mobius-fixture.yaml <<'YAML'
project_type: greenfield
goal: Livrer un petit test de fumée CLI.
constraints:
  - Garder tout l'état dans le MOBIUS_HOME temporaire.
  - Éviter les services réseau.
success:
  - Interview écrit une spec.
  - Seed crée une session.
  - Run se termine avec succès.
YAML
mobius interview --non-interactive --input /tmp/mobius-fixture.yaml --output /tmp/mobius-spec.yaml
mobius seed /tmp/mobius-spec.yaml --json
run_id="$(mobius run --spec /tmp/mobius-spec.yaml)"
mobius status "$run_id" --follow
```

Pour démarrer un vrai workspace :

```sh
mobius go "mon idée de projet"
```

## Commandes principales

- `mobius interview` — entretien projet interactif (modes deep, quick, conversationnel) avec juge interne à 3 lentilles (Clarté, Risques, Faisabilité), breadth keeper par questions-ponts, et persistance par tour.
- `mobius seed` — valide une spec et crée une session seed.
- `mobius run` — exécute avec un agent (`--agent codex --model gpt-5.5`, `--agent claude`, `--agent droid`). Chaque run est isolé dans un git worktree pour permettre l'exécution parallèle.
- `mobius status` — affiche la santé globale ou le statut d'un run.
- `mobius qa [RUN_ID]` — évalue un run avec un juge local déterministe.
- `mobius evolve [RUN_ID]` — lance une boucle d'évolution depuis un run existant.
- `mobius cancel RUN_ID` — annule un run détaché et nettoie son PID.
- `mobius lineage [AGGREGATE_ID]` — affiche les ancêtres, descendants ou le hash de replay.
- `mobius init` — crée un `spec.yaml` de départ et initialise l'event store.
- `mobius setup` — installe les assets d'intégration agent.
- `mobius config` — affiche, lit ou modifie la configuration Mobius.
- `mobius handoff` — génère un prompt versionné pour un agent de code.
- `mobius hud` — tableau de bord basé sur les projections.

Commandes avancées :

- `mobius build` — compose une première spec guidée depuis une idée.
- `mobius projection` — gère le cache de projections.
- `mobius cold-start` — mesure le budget de démarrage à froid.

## Exécution parallèle

Chaque `mobius run` isole automatiquement l'agent dans un **git worktree** dédié. Cela permet de lancer plusieurs runs en parallèle sans conflit :

```sh
mobius run --spec spec-auth.yaml --agent codex --model gpt-5.5 --approve-agent
mobius run --spec spec-ui.yaml --agent codex --model gpt-5.5 --approve-agent
mobius run --spec spec-api.yaml --agent claude --model opus-4.7 --approve-agent
# Les 3 tournent en parallèle, chacun dans son propre espace.
```

## Interview Deep améliorée

Le mode `--mode deep` inclut :

- **Persistance par tour** — chaque round est sauvegardé dans un fichier JSON incrémental. Un crash ne perd aucune donnée.
- **Juge interne à 3 lentilles** — Clarté (Socrate), Risques (Avocat), Faisabilité (Architecte). Le juge guide silencieusement le choix des questions et hausse le ton quand un problème est détecté.
- **Breadth keeper** — si un axe thématique est touché 2 fois de suite, une question-pont connecte naturellement vers un axe non couvert.
- **Recommandations argumentées** — chaque question inclut la recommandation de Mobius avant de demander l'avis de l'utilisateur.
- **Reprise après crash** — détection automatique d'une interview interrompue avec 3 choix (reprendre / recommencer / voir le résumé).

## Préparation release PyPI

Avant publication, sans effet externe :

1. Vérifier que le nom PyPI public est libre/choisi : `mobius-charles` (le nom `mobius` est déjà pris sur PyPI).
2. Vérifier les métadonnées : `uv build --out-dir /tmp/mobius-dist`.
3. Valider les artefacts : `uvx twine check /tmp/mobius-dist/*`.
4. Installer le wheel dans un environnement propre et lancer `mobius --help`.
5. Tester les assets sans écrire : `mobius setup --runtime claude|codex|hermes --dry-run`.
6. Vérifier l'authentification de publication sans contacter PyPI : `uv run python scripts/verify_publish_auth.py`.
7. Publier seulement après GO explicite, idéalement via GitHub Actions `Publish PyPI` + PyPI Trusted Publishing. En local seulement si token disponible : `uv publish --token "$PYPI_TOKEN" /tmp/mobius-dist/*`.
8. Après publication, vérifier le paquet réellement publié : `uv run python scripts/verify_post_publish.py --version 0.3.0`.

Voir aussi [`docs/cli-reference.md`](docs/cli-reference.md), [`CHANGELOG.md`](CHANGELOG.md), [`CONTRIBUTING.md`](CONTRIBUTING.md) et [`SECURITY.md`](SECURITY.md).
