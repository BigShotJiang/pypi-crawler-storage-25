# ErrorLens

A CLI and TUI tool that analyzes codebases for bugs and security issues using multiple AI providers.

---

## Features

- **Multi-provider analysis** — Anthropic (Claude), Groq (Llama 3), and Mistral
- **Two interfaces** — a classic CLI for scripting and a rich Terminal UI (TUI) for interactive use
- **Parallel file processing** — analyzes directories concurrently
- **Multiple output formats** — console, JSON, and Markdown
- **12+ languages supported** — Python, JavaScript, TypeScript, Go, Rust, Java, and more

---

## Installation

### From PyPI (recommended)

```bash
pip install errorlens
```

That's it. The `errorlens` command is now available globally.

### From source

```bash
git clone https://github.com/your-repo/errorlens.git
cd errorlens
pip install .
```

### For development

```bash
git clone https://github.com/your-repo/errorlens.git
cd errorlens
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -e .
```

---

## Configuration

Create a `.env` file in your working directory (or export the variables in your shell):

```bash
ANTHROPIC_API_KEY="your-anthropic-api-key"
MISTRAL_API_KEY="your-mistral-api-key"
GROQ_API_KEY="your-groq-api-key"
```

You only need keys for the providers you plan to use.

| Provider  | Model                  | Get a key                        |
|-----------|------------------------|----------------------------------|
| Anthropic | claude-3-opus-20240229 | console.anthropic.com            |
| Groq      | llama3-70b-8192        | console.groq.com                 |
| Mistral   | mistral-large-latest   | console.mistral.ai               |

---

## Usage

### TUI (default)

Launch the interactive terminal interface:

```bash
errorlens
```

```
┌─────────────────────────────────────────────────────────┐
│  ErrorLens                                   12:00:00   │
├────────────────┬────────────────────────────────────────┤
│                │                                        │
│  Path          │  Analyzing: example_test.py            │
│  [___________] │  Provider: mistral                     │
│                │  ════════════════════════════════════  │
│  Provider      │                                        │
│  ○ anthropic   │  ✔  example_test.py  [python]          │
│  ○ mistral     │                                        │
│  ○ groq        │  ── MISTRAL ──                         │
│  ● all         │  Security Issues:                      │
│                │    • Hardcoded credentials detected    │
│  [Run Analysis]│    • Insecure pickle deserialization   │
│                │  Potential Bugs:                       │
│  Analyzing...  │    • Division by zero                  │
│                │                                        │
├────────────────┴────────────────────────────────────────┤
│  R Run  C Clear  Q Quit                                 │
└─────────────────────────────────────────────────────────┘
```

**Keybindings**

| Key | Action        |
|-----|---------------|
| `R` | Run analysis  |
| `C` | Clear results |
| `Q` | Quit          |

Results are color-coded:
- **Red** — Security issues
- **Yellow** — Potential bugs
- **Cyan** — Code quality issues
- **Green** — Suggestions / no issues found

### CLI (non-interactive)

```bash
# Analyze a file or directory
errorlens-cli path/to/file.py
errorlens-cli path/to/project/

# Choose a specific provider
errorlens-cli file.py --provider anthropic
errorlens-cli file.py --provider groq
errorlens-cli file.py --provider mistral

# Change output format
errorlens-cli file.py --output json
errorlens-cli file.py --output markdown

# Verbose logging
errorlens-cli file.py --verbose
```

**CLI options**

| Flag         | Values                                    | Default   |
|--------------|-------------------------------------------|-----------|
| `--provider` | `anthropic`, `mistral`, `groq`, `mock`, `all` | `all` |
| `--output`   | `console`, `json`, `markdown`             | `console` |
| `--verbose`  | —                                         | off       |
| `--config`   | path to JSON config file                  | —         |

**Example output**

```
ErrorLens — analyzing: example_test.py  provider: groq

==================================================
ERRORLENS ANALYSIS RESULTS
==================================================

File: example_test.py
Language: python

--- GROQ ---
Security Issues:
  - Hardcoded credentials found in DB_PASSWORD and API_KEY variables
  - SQL injection vulnerability in login() function
  - Insecure deserialization using pickle.loads()
Potential Bugs:
  - Division by zero possible in complex_calculation()
Code Quality:
  - Unused function detected
Suggestions:
  - Use environment variables for credentials
  - Use parameterized queries
```

---

## Supported Languages

| Language   | Extension(s)   |
|------------|----------------|
| Python     | `.py`          |
| JavaScript | `.js`          |
| TypeScript | `.ts`          |
| Java       | `.java`        |
| C / C++    | `.c`, `.cpp`   |
| Go         | `.go`          |
| Rust       | `.rs`          |
| Ruby       | `.rb`          |
| PHP        | `.php`         |
| Swift      | `.swift`       |
| Kotlin     | `.kt`          |
| C#         | `.cs`          |

---

## Project Structure

```
errorlens/
├── pyproject.toml
├── setup.py
├── requirements.txt
├── .env.example
├── example_test.py
└── errorlens/                      # installable package
    ├── __init__.py
    ├── tui.py                      # `errorlens` command — Textual TUI
    ├── cli.py                      # `errorlens-cli` command — non-interactive
    ├── core/
    │   ├── analyzer.py             # file discovery and analysis orchestration
    │   └── config.py               # configuration and env loading
    └── providers/
        ├── anthropic_provider.py   # Anthropic Claude integration
        ├── groq_provider.py        # Groq Llama 3 integration
        ├── mistral_provider.py     # Mistral integration
        └── mock_provider.py        # offline mock for testing
```

---

## Testing with the Example File

`example_test.py` is bundled with intentional security flaws and bugs — use it to verify your setup:

```bash
errorlens-cli example_test.py --provider mock   # no API key needed
errorlens-cli example_test.py --provider groq
```

---

## License

MIT License — see LICENSE for details.
