from setuptools import setup

# All configuration lives in pyproject.toml
setup()
