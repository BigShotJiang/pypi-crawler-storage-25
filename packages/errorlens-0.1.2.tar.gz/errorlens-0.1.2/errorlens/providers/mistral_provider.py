"""
Mistral API Provider Integration
Handles communication with Mistral's API for code analysis
"""

import os
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class MistralProvider:
    def __init__(self, api_key: Optional[str] = None):
        """Initialize Mistral provider with API key"""
        self.api_key = api_key or os.getenv("MISTRAL_API_KEY")
        if not self.api_key:
            raise ValueError("Mistral API key not provided and MISTRAL_API_KEY environment variable not set")
        
        # Mock client for now - actual implementation would use Mistral API
        self.client = None
        self.model = "mistral-large-latest"  # Default model
    
    def analyze_code(self, code: str, language: str = "python", 
                    analysis_type: str = "security_and_bugs") -> Dict[str, Any]:
        """
        Analyze code for bugs and security issues using Mistral API
        
        Args:
            code: The source code to analyze
            language: Programming language of the code
            analysis_type: Type of analysis to perform
        
        Returns:
            Dictionary containing analysis results
        """
        prompt = self._build_analysis_prompt(code, language, analysis_type)
        
        try:
            # Mock response for testing
            mock_response = {
                "choices": [{
                    "message": {
                        "content": self._generate_mock_analysis(code, language)
                    }
                }]
            }
            
            return self._parse_response(mock_response)
            
        except Exception as e:
            return {
                "error": str(e),
                "success": False,
                "provider": "mistral"
            }
    
    def _generate_mock_analysis(self, code: str, language: str) -> str:
        """Generate mock analysis for testing"""
        import json
        
        # Simple analysis based on code content
        analysis = {
            "security_issues": [],
            "bugs": [],
            "code_quality": [],
            "suggestions": []
        }
        
        # Check for common security issues
        if "password" in code.lower() or "api_key" in code.lower():
            analysis["security_issues"].append("Hardcoded credentials detected")
        
        if "pickle" in code.lower():
            analysis["security_issues"].append("Potential insecure deserialization using pickle")
        
        if "request.args" in code or "request.data" in code:
            analysis["security_issues"].append("Potential input validation issues")
        
        # Check for common bugs
        if "/" in code and "try:" not in code:
            analysis["bugs"].append("Potential division by zero without error handling")
        
        # Check for code quality issues
        if "unused" in code.lower() or "todo" in code.lower():
            analysis["code_quality"].append("Unused code or TODO comments found")
        
        return json.dumps(analysis)
    
    def _build_analysis_prompt(self, code: str, language: str, 
                               analysis_type: str) -> str:
        """Build the prompt for code analysis"""
        base_prompt = f"""Analyze the following {language} code for {analysis_type}:

```{language}
{code}
```

Please provide:
1. Security vulnerabilities and risks
2. Potential bugs and edge cases  
3. Code quality issues
4. Suggested improvements

Format your response as JSON with keys: security_issues, bugs, code_quality, suggestions"""
        
        return base_prompt
    
    def _parse_response(self, response: Any) -> Dict[str, Any]:
        """Parse the API response into structured data"""
        result = {
            "success": True,
            "provider": "mistral",
            "raw_response": response["choices"][0]["message"]["content"] if response.get("choices") else "",
            "analysis": {}
        }
        
        # Try to parse JSON response if available
        try:
            import json
            content = result["raw_response"]
            result["analysis"] = json.loads(content)
        except (json.JSONDecodeError, IndexError):
            # Fallback to raw text analysis
            result["analysis"] = {
                "raw_analysis": content
            }
        
        return result
    
    def set_model(self, model_name: str):
        """Set the model to use for analysis"""
        self.model = model_name