"""
Mock Provider for Testing
Provides mock analysis without requiring API keys
"""

import os
from typing import Dict, Any, Optional
import json


class MockProvider:
    def __init__(self):
        """Initialize mock provider - no API key required"""
        self.model = "mock-analysis-v1"
    
    def analyze_code(self, code: str, language: str = "python", 
                    analysis_type: str = "security_and_bugs") -> Dict[str, Any]:
        """
        Analyze code for bugs and security issues using mock analysis
        
        Args:
            code: The source code to analyze
            language: Programming language of the code
            analysis_type: Type of analysis to perform
        
        Returns:
            Dictionary containing analysis results
        """
        try:
            mock_response = {
                "choices": [{
                    "message": {
                        "content": self._generate_mock_analysis(code, language)
                    }
                }]
            }
            
            return self._parse_response(mock_response)
            
        except Exception as e:
            return {
                "error": str(e),
                "success": False,
                "provider": "mock"
            }
    
    def _generate_mock_analysis(self, code: str, language: str) -> str:
        """Generate mock analysis for testing"""
        # Simple analysis based on code content
        analysis = {
            "security_issues": [],
            "bugs": [],
            "code_quality": [],
            "suggestions": []
        }
        
        # Check for common security issues
        if "password" in code.lower() or "api_key" in code.lower():
            analysis["security_issues"].append("Hardcoded credentials detected")
        
        if "pickle" in code.lower():
            analysis["security_issues"].append("Potential insecure deserialization using pickle")
        
        if "request.args" in code or "request.data" in code:
            analysis["security_issues"].append("Potential input validation issues")
        
        if "sql" in code.lower() or "query" in code.lower():
            analysis["security_issues"].append("Potential SQL injection vulnerability")
        
        # Check for common bugs
        if "/" in code and "try:" not in code:
            analysis["bugs"].append("Potential division by zero without error handling")
        
        if "debug=true" in code.lower() or "debug=true" in code.lower():
            analysis["bugs"].append("Debug mode enabled in production")
        
        # Check for code quality issues
        if "unused" in code.lower() or "todo" in code.lower():
            analysis["code_quality"].append("Unused code or TODO comments found")
        
        if len(code.split('\n')) > 100:
            analysis["code_quality"].append("File is too long - consider breaking into smaller functions")
        
        # Generate suggestions based on findings
        if analysis["security_issues"]:
            analysis["suggestions"].append("Use environment variables for sensitive data")
            analysis["suggestions"].append("Implement input validation and sanitization")
        
        if analysis["bugs"]:
            analysis["suggestions"].append("Add proper error handling and edge case testing")
        
        if analysis["code_quality"]:
            analysis["suggestions"].append("Refactor code for better maintainability")
        
        return json.dumps(analysis)
    
    def _parse_response(self, response: Any) -> Dict[str, Any]:
        """Parse the API response into structured data"""
        result = {
            "success": True,
            "provider": "mock",
            "raw_response": response["choices"][0]["message"]["content"] if response.get("choices") else "",
            "analysis": {}
        }
        
        # Try to parse JSON response if available
        try:
            content = result["raw_response"]
            result["analysis"] = json.loads(content)
        except (json.JSONDecodeError, IndexError):
            # Fallback to raw text analysis
            result["analysis"] = {
                "raw_analysis": content
            }
        
        return result
    
    def set_model(self, model_name: str):
        """Set the model to use for analysis"""
        self.model = model_name