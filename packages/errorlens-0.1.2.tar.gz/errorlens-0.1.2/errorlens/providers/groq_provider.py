"""
Groq API Provider Integration
Handles communication with Groq's API for code analysis
"""

import os
from typing import Dict, Any, Optional
from groq import Groq
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class GroqProvider:
    def __init__(self, api_key: Optional[str] = None):
        """Initialize Groq provider with API key"""
        self.api_key = api_key or os.getenv("GROQ_API_KEY")
        if not self.api_key:
            raise ValueError("Groq API key not provided and GROQ_API_KEY environment variable not set")
        
        self.client = Groq(api_key=self.api_key)
        self.model = "llama3-70b-8192"  # Default model
    
    def analyze_code(self, code: str, language: str = "python", 
                    analysis_type: str = "security_and_bugs") -> Dict[str, Any]:
        """
        Analyze code for bugs and security issues using Groq API
        
        Args:
            code: The source code to analyze
            language: Programming language of the code
            analysis_type: Type of analysis to perform
        
        Returns:
            Dictionary containing analysis results
        """
        prompt = self._build_analysis_prompt(code, language, analysis_type)
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a senior security engineer and code reviewer. Provide detailed analysis of code quality, security issues, and potential bugs."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.3,
                max_tokens=1024
            )
            
            return self._parse_response(response)
            
        except Exception as e:
            return {
                "error": str(e),
                "success": False,
                "provider": "groq"
            }
    
    def _build_analysis_prompt(self, code: str, language: str, 
                               analysis_type: str) -> str:
        """Build the prompt for code analysis"""
        base_prompt = f"""Analyze the following {language} code for {analysis_type}:

```{language}
{code}
```

Please provide:
1. Security vulnerabilities and risks
2. Potential bugs and edge cases
3. Code quality issues
4. Suggested improvements

Format your response as JSON with keys: security_issues, bugs, code_quality, suggestions"""
        
        return base_prompt
    
    def _parse_response(self, response: Any) -> Dict[str, Any]:
        """Parse the API response into structured data"""
        result = {
            "success": True,
            "provider": "groq",
            "raw_response": response.choices[0].message.content if response.choices else "",
            "analysis": {}
        }
        
        # Try to parse JSON response if available
        try:
            import json
            content = result["raw_response"]
            result["analysis"] = json.loads(content)
        except (json.JSONDecodeError, IndexError):
            # Fallback to raw text analysis
            result["analysis"] = {
                "raw_analysis": content
            }
        
        return result
    
    def set_model(self, model_name: str):
        """Set the model to use for analysis"""
        self.model = model_name