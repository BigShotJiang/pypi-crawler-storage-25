#!/usr/bin/env python3
"""
ErrorLens TUI — Terminal User Interface powered by Textual
"""

from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import (
    Header, Footer, Input, Button, Label, Select,
    Static, RadioSet, RadioButton, RichLog
)
from textual.reactive import reactive
from textual import work

from errorlens.core.analyzer import CodeAnalyzer
from errorlens.core.config import Config


PROVIDERS = ["anthropic", "mistral", "groq", "all"]

SEVERITY_STYLES = {
    "Security Issues":    "bold red",
    "Potential Bugs":     "bold yellow",
    "Code Quality Issues": "bold cyan",
    "Suggestions":        "bold green",
}


class ErrorLensApp(App):
    CSS = """
    Screen {
        layout: vertical;
    }

    #main {
        layout: horizontal;
        height: 1fr;
    }

    #left-panel {
        width: 30;
        min-width: 28;
        border: solid $primary;
        padding: 1 2;
        height: 100%;
    }

    #left-panel Label {
        margin-top: 1;
        color: $text-muted;
    }

    #path-input {
        margin-top: 1;
        width: 100%;
    }

    #provider-set {
        margin-top: 1;
    }

    #run-btn {
        margin-top: 2;
        width: 100%;
    }

    #status {
        margin-top: 1;
        color: $text-muted;
        text-align: center;
    }

    #right-panel {
        width: 1fr;
        border: solid $primary;
        padding: 1 2;
        height: 100%;
    }

    RichLog {
        height: 1fr;
    }
    """

    BINDINGS = [
        ("r", "run_analysis", "Run"),
        ("c", "clear_results", "Clear"),
        ("q", "quit", "Quit"),
    ]

    running = reactive(False)

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main"):
            with Vertical(id="left-panel"):
                yield Label("Path")
                yield Input(placeholder="file or directory", id="path-input")
                yield Label("Provider")
                with RadioSet(id="provider-set"):
                    for p in PROVIDERS:
                        yield RadioButton(p, value=(p == "all"))
                yield Button("Run Analysis", id="run-btn", variant="primary")
                yield Static("", id="status")
            with Vertical(id="right-panel"):
                yield RichLog(highlight=True, markup=True, id="results-log")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#path-input", Input).focus()
        log = self.query_one(RichLog)
        log.write("[bold]ErrorLens[/bold] — ready. Enter a path and press [bold]R[/bold] or click Run.")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "run-btn":
            self.action_run_analysis()

    def action_run_analysis(self) -> None:
        if self.running:
            return
        path_str = self.query_one("#path-input", Input).value.strip()
        if not path_str:
            self._set_status("Enter a path first.", error=True)
            return
        provider = self._selected_provider()
        self._start_analysis(path_str, provider)

    def action_clear_results(self) -> None:
        self.query_one(RichLog).clear()

    def _selected_provider(self) -> str:
        radio_set = self.query_one("#provider-set", RadioSet)
        if radio_set.pressed_button:
            return str(radio_set.pressed_button.label)
        return "all"

    def _set_status(self, msg: str, error: bool = False) -> None:
        style = "bold red" if error else "$text-muted"
        self.query_one("#status", Static).update(f"[{style}]{msg}[/{style}]")

    @work(thread=True)
    def _start_analysis(self, path_str: str, provider: str) -> None:
        self.running = True
        self.call_from_thread(self._set_status, "Analyzing...")
        log = self.query_one(RichLog)

        target = Path(path_str)
        if not target.exists():
            self.call_from_thread(self._set_status, f"Path not found: {path_str}", error=True)
            self.running = False
            return

        try:
            analyzer = CodeAnalyzer()
            provider_list = ["anthropic", "mistral", "groq"] if provider == "all" else [provider]
            analyzer.initialize_providers(provider_list)

            self.call_from_thread(
                log.write,
                f"\n[bold cyan]Analyzing:[/bold cyan] {path_str}  [bold cyan]Provider:[/bold cyan] {provider}\n"
            )

            results = analyzer.analyze_path(target, provider_list)
            self.call_from_thread(self._render_results, results, log)
            self.call_from_thread(self._set_status, "Done.")
        except Exception as e:
            self.call_from_thread(self._set_status, f"Error: {e}", error=True)

        self.running = False

    def _render_results(self, results: dict, log: RichLog) -> None:
        log.write("=" * 60)
        if "directory" in results:
            log.write(f"[bold]Directory:[/bold] {results['directory']}")
            log.write(
                f"Files: {len(results['files'])}  |  "
                f"OK: {results['summary']['successful_analyses']}  |  "
                f"Failed: {results['summary']['failed_analyses']}"
            )
            for file_result in results["files"]:
                self._render_file(file_result, log)
        else:
            self._render_file(results, log)
        log.write("=" * 60)

    def _render_file(self, file_result: dict, log: RichLog) -> None:
        log.write("")
        status_icon = "[bold green]✔[/bold green]" if file_result.get("success") else "[bold red]✘[/bold red]"
        log.write(f"{status_icon}  [bold]{file_result['file']}[/bold]  [{file_result.get('language', 'unknown')}]")

        if not file_result.get("success"):
            log.write(f"  [red]Error: {file_result.get('error', 'Unknown')}[/red]")
            return

        for provider_name, provider_result in file_result.get("providers", {}).items():
            log.write(f"\n  [bold magenta]── {provider_name.upper()} ──[/bold magenta]")
            if not provider_result.get("success", True):
                log.write(f"  [red]{provider_result.get('error', 'Failed')}[/red]")
                continue

            analysis = provider_result.get("analysis", {})
            sections = {
                "Security Issues":     analysis.get("security_issues", []),
                "Potential Bugs":      analysis.get("bugs", []),
                "Code Quality Issues": analysis.get("code_quality", []),
                "Suggestions":         analysis.get("suggestions", []),
            }
            found_any = False
            for section, items in sections.items():
                if not items:
                    continue
                found_any = True
                style = SEVERITY_STYLES[section]
                log.write(f"  [{style}]{section}:[/{style}]")
                for item in items:
                    log.write(f"    • {item}")

            if not found_any:
                log.write("  [green]No issues found.[/green]")


def main():
    app = ErrorLensApp()
    app.run()


if __name__ == "__main__":
    main()
