"""
Core Analysis Engine
Handles file discovery, code extraction, and analysis orchestration
"""

import os
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from errorlens.providers.anthropic_provider import AnthropicProvider
from errorlens.providers.mistral_provider import MistralProvider
from errorlens.providers.groq_provider import GroqProvider
from errorlens.providers.mock_provider import MockProvider


class CodeAnalyzer:
    def __init__(self):
        self.providers = {
            "anthropic": None,
            "mistral": None,
            "groq": None
        }
        self.logger = logging.getLogger(__name__)

    def initialize_providers(self, provider_names: List[str] = None):
        provider_names = provider_names or ["anthropic", "mistral", "groq"]
        for name in provider_names:
            try:
                if name == "anthropic":
                    self.providers["anthropic"] = AnthropicProvider()
                elif name == "mistral":
                    self.providers["mistral"] = MistralProvider()
                elif name == "groq":
                    self.providers["groq"] = GroqProvider()
                elif name == "mock":
                    self.providers["mock"] = MockProvider()
                self.logger.info(f"Initialized {name} provider")
            except Exception as e:
                self.logger.warning(f"Failed to initialize {name} provider: {e}")
                self.providers[name] = None

    def analyze_path(self, path: Union[str, Path],
                     providers: List[str] = None) -> Dict[str, Any]:
        path = Path(path)
        if path.is_file():
            return self._analyze_file(path, providers)
        return self._analyze_directory(path, providers)

    def _analyze_file(self, file_path: Path,
                      providers: List[str] = None) -> Dict[str, Any]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            language = self._get_language_from_extension(file_path.suffix)
            provider_results = self._analyze_with_providers(content, language, providers)
            return {
                "file": str(file_path),
                "language": language,
                "providers": provider_results,
                "success": True
            }
        except Exception as e:
            return {"file": str(file_path), "error": str(e), "success": False}

    def _analyze_directory(self, directory_path: Path,
                           providers: List[str] = None) -> Dict[str, Any]:
        results = {"directory": str(directory_path), "files": [], "summary": {}}
        code_files = self._find_code_files(directory_path)

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [
                executor.submit(self._analyze_file, fp, providers)
                for fp in code_files
            ]
            for future in as_completed(futures):
                results["files"].append(future.result())

        results["summary"] = self._generate_summary(results["files"])
        return results

    def _analyze_with_providers(self, code: str, language: str,
                                providers: List[str] = None) -> Dict[str, Any]:
        providers = providers or ["anthropic", "mistral", "groq"]
        results = {}
        for provider_name in providers:
            provider = self.providers.get(provider_name)
            if not provider:
                continue
            try:
                results[provider_name] = provider.analyze_code(code, language)
            except Exception as e:
                results[provider_name] = {"error": str(e), "success": False}
        return results

    def _find_code_files(self, directory_path: Path) -> List[Path]:
        code_extensions = {
            '.py', '.js', '.ts', '.java', '.c', '.cpp', '.go',
            '.rb', '.php', '.swift', '.kt', '.rs', '.cs'
        }
        return [
            p for p in directory_path.rglob('*')
            if p.is_file() and p.suffix in code_extensions
        ]

    def _get_language_from_extension(self, extension: str) -> str:
        extension_map = {
            '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
            '.java': 'java', '.c': 'c', '.cpp': 'cpp', '.go': 'go',
            '.rb': 'ruby', '.php': 'php', '.swift': 'swift',
            '.kt': 'kotlin', '.rs': 'rust', '.cs': 'csharp'
        }
        return extension_map.get(extension.lower(), 'unknown')

    def _generate_summary(self, file_results: List[Dict]) -> Dict[str, Any]:
        summary = {
            "total_files": len(file_results),
            "successful_analyses": sum(1 for r in file_results if r.get("success")),
            "failed_analyses": sum(1 for r in file_results if not r.get("success")),
            "findings_by_severity": {"critical": 0, "high": 0, "medium": 0, "low": 0}
        }
        return summary
