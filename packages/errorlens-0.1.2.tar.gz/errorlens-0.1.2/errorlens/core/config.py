"""
Configuration System
Handles loading and managing configuration from various sources
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv


class Config:
    def __init__(self, config_file: Optional[str] = None):
        load_dotenv()

        self.config = {
            "api_keys": {
                "anthropic": os.getenv("ANTHROPIC_API_KEY"),
                "mistral": os.getenv("MISTRAL_API_KEY"),
                "groq": os.getenv("GROQ_API_KEY")
            },
            "analysis": {
                "max_file_size_kb": int(os.getenv("MAX_FILE_SIZE_KB", "1000")),
                "timeout_seconds": int(os.getenv("TIMEOUT_SECONDS", "30")),
                "concurrent_workers": 4,
                "default_providers": ["anthropic", "mistral", "groq"]
            },
            "models": {
                "anthropic": os.getenv("ANTHROPIC_MODEL", "claude-3-opus-20240229"),
                "mistral": os.getenv("MISTRAL_MODEL", "mistral-large-latest"),
                "groq": os.getenv("GROQ_MODEL", "llama3-70b-8192")
            },
            "output": {
                "format": "console",
                "verbose": False,
                "show_raw_responses": False
            }
        }

        if config_file:
            self.load_config_file(config_file)

    def load_config_file(self, config_file: str):
        try:
            config_path = Path(config_file)
            if not config_path.exists():
                raise FileNotFoundError(f"Config file {config_file} not found")
            with open(config_path, 'r', encoding='utf-8') as f:
                file_config = json.load(f)
            self._deep_update(self.config, file_config)
        except Exception as e:
            raise RuntimeError(f"Failed to load config file: {e}")

    def _deep_update(self, original: Dict, update: Dict):
        for key, value in update.items():
            if isinstance(value, dict) and key in original and isinstance(original[key], dict):
                self._deep_update(original[key], value)
            else:
                original[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split('.')
        config = self.config
        for k in keys:
            if k in config:
                config = config[k]
            else:
                return default
        return config

    def set(self, key: str, value: Any):
        keys = key.split('.')
        config = self.config
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value

    def validate(self) -> bool:
        errors = []
        for provider in self.config["analysis"]["default_providers"]:
            if not self.config["api_keys"].get(provider):
                errors.append(f"Missing API key for {provider}")
        if errors:
            raise RuntimeError("Configuration validation failed: " + ", ".join(errors))
        return True
