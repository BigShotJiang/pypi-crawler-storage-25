#!/usr/bin/env python3
"""
ErrorLens CLI — non-interactive analysis mode
"""

import argparse
import json
import logging
import sys
from pathlib import Path

from errorlens.core.analyzer import CodeAnalyzer
from errorlens.core.config import Config


def main():
    parser = argparse.ArgumentParser(
        description="ErrorLens - Find bugs and security issues in your codebase"
    )
    parser.add_argument(
        "path", nargs="?", default=".",
        help="Path to file or directory to analyze (default: current directory)"
    )
    parser.add_argument(
        "--provider", choices=["anthropic", "mistral", "groq", "mock", "all"],
        default="all", help="AI provider to use (default: all)"
    )
    parser.add_argument(
        "--output", choices=["console", "json", "markdown"],
        default="console", help="Output format (default: console)"
    )
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("--config", help="Path to configuration file")

    args = parser.parse_args()
    config = Config(args.config)

    logging.basicConfig(
        level=logging.INFO if args.verbose or config.get("output.verbose") else logging.WARNING,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    target_path = Path(args.path)
    if not target_path.exists():
        print(f"Error: Path '{args.path}' does not exist")
        sys.exit(1)

    provider_list = ["anthropic", "mistral", "groq"] if args.provider == "all" else [args.provider]

    analyzer = CodeAnalyzer()
    analyzer.initialize_providers(provider_list)

    print(f"ErrorLens — analyzing: {args.path}  provider: {args.provider}")
    results = analyzer.analyze_path(target_path, provider_list)
    _output_results(results, args.output)


def _output_results(results: dict, output_format: str):
    if output_format == "json":
        print(json.dumps(results, indent=2))
    elif output_format == "markdown":
        _output_markdown(results)
    else:
        _output_console(results)


def _output_console(results: dict):
    print("\n" + "=" * 50)
    print("ERRORLENS ANALYSIS RESULTS")
    print("=" * 50)
    if "directory" in results:
        print(f"Directory: {results['directory']}")
        print(f"Files analyzed: {len(results['files'])}")
        print(f"Successful: {results['summary']['successful_analyses']}")
        print(f"Failed: {results['summary']['failed_analyses']}")
        for file_result in results['files']:
            _print_file_result(file_result)
    else:
        _print_file_result(results)


def _print_file_result(file_result: dict):
    print(f"\nFile: {file_result['file']}")
    print(f"Language: {file_result.get('language', 'unknown')}")
    if not file_result.get('success'):
        print(f"Error: {file_result.get('error', 'Unknown error')}")
        return
    for provider_name, provider_result in file_result['providers'].items():
        print(f"\n--- {provider_name.upper()} ---")
        if provider_result.get('success'):
            analysis = provider_result.get('analysis', {})
            for label, key in [
                ("Security Issues", "security_issues"),
                ("Potential Bugs", "bugs"),
                ("Code Quality", "code_quality"),
                ("Suggestions", "suggestions"),
            ]:
                items = analysis.get(key, [])
                if items:
                    print(f"{label}:")
                    for item in items:
                        print(f"  - {item}")
        else:
            print(f"Error: {provider_result.get('error', 'Unknown error')}")


def _output_markdown(results: dict):
    print("# ErrorLens Analysis Results\n")
    if "directory" in results:
        print(f"## Directory: {results['directory']}")
        print(f"- Files: {len(results['files'])}")
        print(f"- OK: {results['summary']['successful_analyses']}")
        print(f"- Failed: {results['summary']['failed_analyses']}\n")
        for file_result in results['files']:
            _print_file_markdown(file_result)
    else:
        _print_file_markdown(results)


def _print_file_markdown(file_result: dict):
    status = "✅" if file_result.get('success') else "❌"
    print(f"## {status} {file_result['file']}")
    if not file_result.get('success'):
        print(f"**Error:** {file_result.get('error', 'Unknown error')}\n")
        return
    for provider_name, provider_result in file_result['providers'].items():
        print(f"### {provider_name.upper()}")
        if provider_result.get('success'):
            analysis = provider_result.get('analysis', {})
            for label, key in [
                ("Security Issues", "security_issues"),
                ("Potential Bugs", "bugs"),
                ("Code Quality Issues", "code_quality"),
                ("Suggestions", "suggestions"),
            ]:
                items = analysis.get(key, [])
                if items:
                    print(f"**{label}:**")
                    for item in items:
                        print(f"- {item}")
        else:
            print(f"**Error:** {provider_result.get('error', 'Unknown error')}")
    print()


if __name__ == "__main__":
    main()
