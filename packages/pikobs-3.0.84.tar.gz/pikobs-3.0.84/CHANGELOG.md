# Changelog
All notable changes to this project will be documented in this file.

Please use the following tags when editing this file:
*Added* for new features.
*Changed* for changes in existing functionality.
*Deprecated* for soon-to-be removed features.
*Removed* for now removed features.
*Fixed* for any bug fixes.

## [2.0.7] - 2024-04-29
### Added
- First release of pikobs as a separate package

## [2.0.8] - 2024-05-29
### Added
- Scatter plots
## [2.0.9] - 2024-05-29
### Added
- cartopy bug
## [2.0.10] - 2024-05-29
### Added
- install bug
## [2.0.11] - 2024-05-30
### Added
- install bug
## [2.0.12] - 2024-05-30
### Added
- scatter plots

## [2.0.20] 2024-05-30
### Added
- extension path

## [2.0.20] 2024-05-30
### Added
- scatter add

## [2.0.22] 2024-06-17
### Added
- cardio add

## [2.0.23] 2024-06-17
### Added
- extension add

## [2.0.24] 2024-06-17
### Added
- bugs

## [2.0.25] 2024-06-17
### Added
- bugs

## [2.0.26] 2024-06-17
### Added
- bugs

## [2.0.27] 2024-06-28
### Added
- bugs
## [2.0.45] 2025-07-16
### Added
- bugs
## [2.0.46] 2025-07-16
### Added
- bugs
## [2.0.47] 2025-07-16
### Added
- bugs
## [2.0.48] 2025-07-16
### Added
- bugs
## [2.0.49] 2025-07-18
### Added
- bugs
## [2.0.50] 2025-07-18
### Added
- bugs
## [2.0.51] 2025-07-18
### Added
- bugs
## [2.0.52] 2025-07-18
### Added
- bugs
## [2.0.53] 2025-08-14
### Added
- bugs
## [2.0.54] 2025-08-14
### Added
- bugs
## [2.0.55] 2025-08-14
### Added
- bugs
## [2.0.56] 2025-08-14
### Added
- bugs
## [2.0.57] 2025-08-26
### Added
- bugs
## [2.0.58] 2025-09-05
### Added
-bugs
## [2.0.59] 2025-03-20
### Added
-bugs
## [2.0.60] 2025-03-20
### Added
-bugs
## [2.0.61] 2025-03-29
### Added
-bugs
## [2.0.62] 2025-03-31
### Added
-Evolution
## [3.0.62] 2025-04-02
### Added
-Profile
## [3.0.72] 2026-04-20
#Added
-bugs
## [3.0.73] 2026-04-20
#Added
-bugs
## [3.0.74] 2026-05-10
#Added
-bugs
## [3.0.75] 2026-05-12
#Added
-bugs 
## [3.0.76] 2026-05-14
#Added


## [3.0.77] 2026-05-14
### Added
- bugs

## [3.0.78] 2026-05-14
### Added
- bugs

## [3.0.79] 2026-05-14
### Added
- bugs

## [3.0.80] 2026-05-15
### Added
- bugs

## [3.0.81] 2026-05-15
### Added
- bugs

## [3.0.82] 2026-05-15
### Added
- bugs

## [3.0.83] 2026-05-15
### Added
- bugs

## [3.0.84] 2026-05-15
### Added
- bugs
