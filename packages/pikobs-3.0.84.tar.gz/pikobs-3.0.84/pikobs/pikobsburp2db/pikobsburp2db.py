#!/usr/bin/env python3
"""
Pikobs BURP to SQLite Conversion Module
=======================================

This module provides the core functionality to convert meteorological BURP 
binary files into SQLite databases for the Pikobs diagnostic pipeline.

It supports:
    * Parallel processing via Dask.
    * Automatic family discovery.
    * Integrity checks for generated SQLite files.
"""

import os
import sys
import argparse
import datetime
import shutil
import subprocess
from datetime import timedelta
import dask
from dask.distributed import Client

# =============================================================================
#  BURP TYPE MAPPING
# =============================================================================

def get_burp_type(family_name: str) -> str:
    """
    Maps a family name to its corresponding burp2rdb observation type.
    
    :param family_name: Raw name of the observation family.
    :return: Normalized string for the '-type' argument in burp2rdb.
    """
    f = family_name.lower()
    f = f.replace("_qc", "").replace("_allsky", "").replace("fsr1", "").replace("fsr2", "")

    mapping = {
        "to_amsua": "amsua",
        "to_amsub": "amsub",
        "gp": "gbgps",
    }
    return mapping.get(f, f)

# =============================================================================
#  BURP2RDB RESOLUTION
# =============================================================================

def _resolve_burp2rdb() -> str:
    """Resolves the path to the burp2rdb binary."""
    env_path = os.environ.get("BURP2RDB_BIN", "").strip()
    if env_path and os.path.isfile(env_path) and os.access(env_path, os.X_OK):
        return env_path

    found = shutil.which("burp2rdb")
    if found:
        return found
    return ""

# =============================================================================
#  CONVERSION ENGINE
# =============================================================================

def _is_sqlite3_intact(filepath: str) -> bool:
    """Checks if a file is a valid and non-corrupted SQLite3 database."""
    if not os.path.isfile(filepath):
        return False
    try:
        import sqlite3
        with sqlite3.connect(filepath, timeout=5) as conn:
            conn.execute("SELECT name FROM sqlite_master LIMIT 1;").fetchone()
        return True
    except sqlite3.DatabaseError:
        return False

def convert_single_file(f_in: str, exp_name: str, family: str, f_out: str, fdate: str) -> bool:
    """
    Converts a single BURP file to SQLite.
    
    This function is designed to be called in parallel by Dask workers.
    """
    if _is_sqlite3_intact(f_out):
        print(f"[OK] Already converted: {exp_name}/{os.path.basename(f_out)}")
        return True

    if not os.path.isfile(f_in):
        print(f"[WARNING] Missing pass! File {fdate} for {family} not found in {exp_name}")
        return False

    file_size = os.path.getsize(f_in)
    if file_size < 100:
        print(f"[WARNING] Possible empty file! {os.path.basename(f_in)} is {file_size} bytes.")
        return False

    burp2rdb_bin = _resolve_burp2rdb()
    if not burp2rdb_bin:
        return False

    b_type = get_burp_type(family)
    f_tmp = f_out + ".tmp"
    
    if os.path.isfile(f_tmp):
        try: os.remove(f_tmp)
        except OSError: pass

    print(f"[RUNNING] Converting {fdate} ({family}) for {exp_name}...")
    
    cmd = [burp2rdb_bin, "-in", f_in, "-type", b_type, "-out", f_tmp]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode("utf-8", errors="ignore") if e.stderr else ""
        print(f"[ERROR] burp2rdb failed for {fdate} in {exp_name} ({family}).")
        print(f"        Details: {stderr.strip()}")
        if os.path.isfile(f_tmp):
            os.remove(f_tmp)
        return False

    if not _is_sqlite3_intact(f_tmp):
        print(f"[ERROR] Corrupted generated file for {fdate} ({family}).")
        os.remove(f_tmp)
        return False

    try:
        os.replace(f_tmp, f_out)
    except OSError as e:
        print(f"[ERROR] Could not save {f_out}: {e}")
        return False

    return True

# =============================================================================
#  ORCHESTRATOR
# =============================================================================

def run_pikobsburp2db(args):
    """
    Main orchestration logic for the mass conversion pipeline.
    
    Sets up the Dask client, generates tasks, and executes them.
    """
    burp_bin = _resolve_burp2rdb()
    if not burp_bin:
        sys.exit("\n[CRITICAL ERROR] burp2rdb not found. Load the environment first.\n")

    try:
        dt_start = datetime.datetime.strptime(args.datestart, "%Y%m%d%H")
        dt_end   = datetime.datetime.strptime(args.dateend,   "%Y%m%d%H")
    except ValueError:
        sys.exit("\n[ERROR] Dates must be in YYYYMMDDHH format.\n")

    if os.path.exists(args.pathwork):
        if args.force_clean:
            shutil.rmtree(args.pathwork)
        else:
            response = input(f"\n[WARNING] Output directory '{args.pathwork}' exists.\nDelete? (yes/no): ")
            if response.strip().lower() == "yes":
                shutil.rmtree(args.pathwork)

    target_families = args.family
    if not target_families:
        detected = set()
        for path_exp in args.path_experience_files:
            if os.path.isdir(path_exp):
                for item in os.listdir(path_exp):
                    if len(item) > 11 and item[10] == "_":
                        date_part = item[:10]
                        if date_part.isdigit():
                            detected.add(item[11:])
        target_families = sorted(list(detected))
        if not target_families:
            sys.exit("\n[ERROR] No valid family files detected.\n")

    tasks = []
    current_date = dt_start
    while current_date <= dt_end:
        fdate = current_date.strftime("%Y%m%d%H")
        for path_exp, name_exp in zip(args.path_experience_files, args.experience_name):
            exp_out_dir = os.path.join(args.pathwork, name_exp)
            os.makedirs(exp_out_dir, exist_ok=True)
            for family in target_families:
                file_in = os.path.join(path_exp, f"{fdate}_{family}")
                file_out = os.path.join(exp_out_dir, f"{fdate}_{family}")
                tasks.append((file_in, name_exp, family, file_out, fdate))
        current_date += timedelta(hours=6)

    if args.n_cpus <= 1:
        for t in tasks:
            convert_single_file(*t)
    else:
        with Client(processes=True, threads_per_worker=1, n_workers=args.n_cpus, silence_logs=40):
            dask.compute(*[dask.delayed(convert_single_file)(*t) for t in tasks])

# =============================================================================
#  CLI PARSER
# =============================================================================

def arg_call():
    """Command-line interface entry point."""
    parser = argparse.ArgumentParser(description="Mass convert BURP files to SQLite")
    parser.add_argument("--path_experience_files", nargs="+", required=True)
    parser.add_argument("--experience_name", nargs="+", required=True)
    parser.add_argument("--pathwork", required=True)
    parser.add_argument("--datestart", required=True)
    parser.add_argument("--dateend", required=True)
    parser.add_argument("--n_cpus", default=1, type=int)
    parser.add_argument("--family", nargs="+", default=[])
    parser.add_argument("--force_clean", action="store_true")

    args = parser.parse_args()
    if len(args.path_experience_files) != len(args.experience_name):
        sys.exit("\n[ERROR] Number of paths does not match experiment names.\n")

    run_pikobsburp2db(args)

if __name__ == "__main__":
    arg_call()
