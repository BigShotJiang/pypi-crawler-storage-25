#/bin/bach
# ==============================================================================
# Script: run_conversion.sh
# Description: Wrapper to execute the mass conversion of BURP files to SQLite.
#              It handles environment loading, dynamic binary resolution, and
#              triggers the parallel execution of pikobs_convert.py.
# ==============================================================================

echo "[INFO] Initializing Pikobs Conversion Pipeline..."
 r.load.dot cmd/cmda/utils/20260202/burp2rdb_5.25_rhel-9-amd64-64
. ssmuse-sh -d eccc/cmd/cmda/utils/20260202
. ssmuse-sh -d eccc/cmo/cmoi/base/20260205

# 1. Load the required ECCC/CMC environment modules
# This ensures that all dependencies, including burp2rdb, are available.

# 2. Dynamically resolve the path to the burp2rdb binary
# Using 'which' makes the script resilient to future server/path updates.
export BURP2RDB_BIN=$(which burp2rdb 2>/dev/null)

# 3. Security Check: Ensure the binary was successfully located
if [ -z "$BURP2RDB_BIN" ]; then
    echo "[CRITICAL ERROR] 'burp2rdb' could not be found in the system PATH."
    echo "Please verify that the environment (. r.load.dot) was loaded correctly."
    exit 1
fi

echo "[INFO] Successfully mapped burp2rdb to: $BURP2RDB_BIN"

# 1. Define cuál es TU Python (el que sí tiene numpy/pandas que funcionan):
python -c 'import pikobs; pikobs.pikobsburp2db.arg_call()' \
     --path_experience_files  /home/ata000/ppp8/investigation/roCodesJospep/CTL /home/ata000/ppp8/investigation/roCodesJospep/EXP1-MW_SSMIS160  /home/ata000/ppp8/investigation/roCodesJospep/EXP2-MW_SSMIS120  \
     --experience_name  Control Expericience1 Experience2  \
     --pathwork /home/dlo001/sites8/comvert/\
     --datestart 2022053100 \
     --dateend   2022062812 \
     --n_cpu 40  #\
   #  --surface sea \
   #  --common_sample



#--path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
# --experience_name  GIC5DA1E22_DDT\
#
# --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#  --control_name G2IC5DA1E22 \

