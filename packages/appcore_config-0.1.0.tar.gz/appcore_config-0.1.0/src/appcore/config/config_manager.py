"""Configuration loading and access helpers."""

from __future__ import annotations

import copy
import logging
import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import ValidationError

from appcore.common import exceptions as common_exceptions
from appcore.config import settings_models

LOGGER = logging.getLogger(__name__)
VALID_ENVIRONMENTS = {"dev", "test", "production"}
ENV_PREFIX = "APP__"


def resolve_environment(value: str | None = None) -> str:
    """Resolve the application environment once using the APP_ENV convention."""
    environment = (value or os.getenv("APP_ENV", "dev")).lower()
    if environment not in VALID_ENVIRONMENTS:
        raise common_exceptions.ConfigurationError(f"Unknown APP_ENV: {environment!r}")
    return environment


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge dictionaries where the override wins on conflicts."""
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def overlay_env_vars(data: dict[str, Any]) -> dict[str, Any]:
    """Overlay environment variables using the APP__ dotted path convention."""
    merged = copy.deepcopy(data)
    for env_key, raw_value in os.environ.items():
        if not env_key.startswith(ENV_PREFIX):
            continue
        path = env_key[len(ENV_PREFIX) :].lower().split("__")
        node: dict[str, Any] = merged
        for key in path[:-1]:
            child = node.get(key)
            if not isinstance(child, dict):
                child = {}
                node[key] = child
            node = child
        node[path[-1]] = yaml.safe_load(raw_value)
    return merged


class ConfigManager:
    """Load, validate, and expose immutable application configuration."""

    def __init__(self, env: str, config_dir: Path) -> None:
        """Load and validate configuration files for the given environment."""
        load_dotenv()
        self._environment = resolve_environment(env)
        self._config_dir = config_dir
        raw = self._load_merged_data()
        try:
            self._settings = settings_models.AppSettings.model_validate(raw)
        except ValidationError as exc:
            raise common_exceptions.ConfigurationError(
                f"Configuration validation failed: {exc}"
            ) from exc
        self._raw = self._settings.model_dump(mode="python")

    @property
    def environment(self) -> str:
        """Return the resolved environment name."""
        return self._environment

    @property
    def raw(self) -> dict[str, Any]:
        """Return a defensive copy of the merged configuration dictionary."""
        return copy.deepcopy(self._raw)

    @property
    def settings(self) -> settings_models.AppSettings:
        """Return the validated immutable settings object."""
        return self._settings

    def get(self, key: str, default: Any = None) -> Any:
        """Return a configuration value using dot-notation lookups."""
        current: Any = self._raw
        for part in key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]
        return copy.deepcopy(current)

    def get_str(self, key: str, default: str = "") -> str:
        """Return a string configuration value."""
        value = self.get(key, default)
        return value if isinstance(value, str) else str(value)

    def get_int(self, key: str, default: int = 0) -> int:
        """Return an integer configuration value or the fallback default."""
        value = self.get(key, default)
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Return a boolean configuration value or the fallback default."""
        value = self.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"1", "true", "yes", "on"}:
                return True
            if normalized in {"0", "false", "no", "off"}:
                return False
        return bool(value)

    def get_section(self, prefix: str) -> dict[str, Any]:
        """Return a sub-dictionary for a dot-notation prefix."""
        value = self.get(prefix, {})
        if isinstance(value, dict):
            return value
        return {}

    def _load_yaml_file(self, path: Path) -> dict[str, Any]:
        """Load a YAML file into a dictionary."""
        with path.open("r", encoding="utf-8") as handle:
            content = yaml.safe_load(handle) or {}
        if not isinstance(content, dict):
            raise common_exceptions.ConfigurationError(
                f"Configuration file must contain a mapping: {path}"
            )
        return content

    def _load_merged_data(self) -> dict[str, Any]:
        """Load, merge, and overlay all configuration sources."""
        base_path = self._config_dir / "appsettings.yaml"
        if not base_path.exists():
            raise common_exceptions.ConfigurationError(
                f"Missing required configuration file: {base_path}"
            )
        base_dict = self._load_yaml_file(base_path)

        env_path = self._config_dir / f"appsettings.{self._environment}.yaml"
        if env_path.exists():
            env_dict = self._load_yaml_file(env_path)
        else:
            LOGGER.warning("Environment configuration file not found: %s", env_path)
            env_dict = {}

        merged = deep_merge(base_dict, env_dict)
        return overlay_env_vars(merged)
