# Copyright 2025-2026 Dimensional Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import time
from typing import TypeAlias

from dimos_lcm.geometry_msgs import (
    PoseWithCovarianceStamped as LCMPoseWithCovarianceStamped,
)
import numpy as np
from plum import dispatch

from dimos.msgs.geometry_msgs.Pose import Pose, PoseConvertable
from dimos.msgs.geometry_msgs.PoseWithCovariance import PoseWithCovariance
from dimos.types.timestamped import Timestamped

# Types that can be converted to/from PoseWithCovarianceStamped
PoseWithCovarianceStampedConvertable: TypeAlias = (
    tuple[PoseConvertable, list[float] | np.ndarray]
    | LCMPoseWithCovarianceStamped
    | dict[str, PoseConvertable | list[float] | np.ndarray | float | str]
)


def sec_nsec(ts):  # type: ignore[no-untyped-def]
    s = int(ts)
    return [s, int((ts - s) * 1_000_000_000)]


class PoseWithCovarianceStamped(PoseWithCovariance, Timestamped):
    msg_name = "geometry_msgs.PoseWithCovarianceStamped"
    ts: float
    frame_id: str

    @dispatch
    def __init__(self, ts: float = 0.0, frame_id: str = "", **kwargs) -> None:
        """Initialize with timestamp and frame_id."""
        self.frame_id = frame_id
        self.ts = ts if ts != 0 else time.time()
        super().__init__(**kwargs)

    @dispatch  # type: ignore[no-redef]
    def __init__(
        self,
        ts: float = 0.0,
        frame_id: str = "",
        pose: Pose | PoseConvertable | None = None,
        covariance: list[float] | np.ndarray | None = None,
    ) -> None:
        """Initialize with timestamp, frame_id, pose and covariance."""
        self.frame_id = frame_id
        self.ts = ts if ts != 0 else time.time()
        if pose is None:
            super().__init__()
        else:
            super().__init__(pose, covariance)

    def lcm_encode(self) -> bytes:
        lcm_msg = LCMPoseWithCovarianceStamped()
        lcm_msg.pose.pose = self.pose
        # LCM expects list, not numpy array
        if isinstance(self.covariance, np.ndarray):
            lcm_msg.pose.covariance = self.covariance.tolist()
        else:
            lcm_msg.pose.covariance = list(self.covariance)
        [lcm_msg.header.stamp.sec, lcm_msg.header.stamp.nsec] = sec_nsec(self.ts)  # type: ignore[no-untyped-call]
        lcm_msg.header.frame_id = self.frame_id
        return lcm_msg.lcm_encode()  # type: ignore[no-any-return]

    @classmethod
    def lcm_decode(cls, data: bytes) -> PoseWithCovarianceStamped:
        lcm_msg = LCMPoseWithCovarianceStamped.lcm_decode(data)
        return cls(
            ts=lcm_msg.header.stamp.sec + (lcm_msg.header.stamp.nsec / 1_000_000_000),
            frame_id=lcm_msg.header.frame_id,
            pose=Pose(
                position=[
                    lcm_msg.pose.pose.position.x,
                    lcm_msg.pose.pose.position.y,
                    lcm_msg.pose.pose.position.z,
                ],
                orientation=[
                    lcm_msg.pose.pose.orientation.x,
                    lcm_msg.pose.pose.orientation.y,
                    lcm_msg.pose.pose.orientation.z,
                    lcm_msg.pose.pose.orientation.w,
                ],
            ),
            covariance=lcm_msg.pose.covariance,
        )

    def __str__(self) -> str:
        return (
            f"PoseWithCovarianceStamped(pos=[{self.x:.3f}, {self.y:.3f}, {self.z:.3f}], "
            f"euler=[{self.roll:.3f}, {self.pitch:.3f}, {self.yaw:.3f}], "
            f"cov_trace={np.trace(self.covariance_matrix):.3f})"
        )
