"""``qz`` — ``quantzone`` 的短别名。

允许用户 ``import qz`` 然后直接 ``qz.init(...)`` / ``qz.get_factors(...)`` /
``qz.QuantZone(...)``。与 ``import quantzone as qz`` 等价,无需用户手动 alias。
"""

from quantzone import *  # noqa: F401, F403
from quantzone import __all__, __version__  # noqa: F401
