"""QuantZone 主类 — 组装所有模块,提供统一 API。"""

from datetime import date
from pathlib import Path

import pandas as pd

from ._auth import get_credentials
from ._dates import DateLike
from ._http import HttpClient
from .calendar import CalendarService
from .factor import FactorService
from .quota import Quota, QuotaService
from .stock import StockService


class QuantZone:
    """宽舟科技量化数据平台客户端(AK/SK 双密钥)。

    使用示例::

        from quantzone import QuantZone

        client = QuantZone(
            access_key="AKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            sign_secret="...",
            base_url="https://your-api.example.com",
        )

        df = client.get_factors(
            order_book_ids=["000001.SZ", "000002.SZ"],
            factor=["alpha1", "vwap"],
            start_date="2024-01-01",
            end_date="2024-12-31",
        )

        client.close()
    """

    def __init__(
        self,
        access_key: str | None = None,
        sign_secret: str | None = None,
        *,
        base_url: str,
        timeout: float = 60.0,
        download_dir: Path | str | None = None,
    ) -> None:
        """初始化客户端。

        Args:
            access_key: 公开标识符;None 时从 keyring 读取。
            sign_secret: 签名密钥;None 时从 keyring 读取。
            base_url: 服务端地址,必须显式提供(SDK 不内置默认地址)。
            timeout: 请求超时(秒),默认 60。大数据量查询调到 600+。
            download_dir: 默认下载目录;None 表示 ``~/.quantzone/downloads``。
        """
        resolved_ak, resolved_sk = get_credentials(access_key, sign_secret)

        self._http = HttpClient(
            access_key=resolved_ak,
            sign_secret=resolved_sk,
            base_url=base_url,
            timeout=timeout,
        )
        resolved_dir = Path(download_dir).expanduser() if download_dir else None
        self._factor_svc = FactorService(self._http, download_dir=resolved_dir)
        self._stock_svc = StockService(self._http)
        self._quota_svc = QuotaService(self._http)
        self._calendar_svc = CalendarService(self._http)

    def close(self) -> None:
        """关闭底层 HTTP 连接。"""
        self._http.close()

    def __enter__(self) -> "QuantZone":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        self.close()
        return False

    # ── 因子 ──────────────────────────────────────────────

    def get_factors(
        self,
        order_book_ids: str | list[str] | None = None,
        factor: str | list[str] | None = None,
        start_date: DateLike | None = None,
        end_date: DateLike | None = None,
        filename: str | None = None,
    ) -> pd.DataFrame:
        """一次性返回完整因子数据(窄表)。

        Args:
            order_book_ids: 股票代码(``str`` / ``list[str]`` / None=全市场)。
            factor: 因子名(``str`` / ``list[str]`` / None=全部)。
            start_date: 起始日期。
            end_date: 截止日期。
            filename: 自定义保存文件名。

        Returns:
            窄表 ``DataFrame``,列:``DataDate / ukey / x / factorname``。
        """
        return self._factor_svc.get_factors(
            order_book_ids=order_book_ids,
            factor=factor,
            start_date=start_date,
            end_date=end_date,
            filename=filename,
        )

    def list_factors(self) -> list[dict]:
        """获取因子元信息列表(含描述、分类)。"""
        return self._factor_svc.list_factors()

    # ── 合约元信息 ────────────────────────────────────

    def list_stocks(self) -> pd.DataFrame:
        """获取全量合约(``order_book_id / industry_name / symbol``)。"""
        return self._stock_svc.list_stocks()

    # ── 交易日历 ──────────────────────────────────────

    def get_trading_dates(self, start_date: DateLike, end_date: DateLike) -> list[date]:
        """获取区间内交易日列表。"""
        return self._calendar_svc.get_trading_dates(start_date, end_date)

    def get_previous_trading_date(self, current_date: DateLike, n: int = 1) -> date:
        """前 n 个交易日。"""
        return self._calendar_svc.get_previous_trading_date(current_date, n)

    def get_next_trading_date(self, current_date: DateLike, n: int = 1) -> date:
        """后 n 个交易日。"""
        return self._calendar_svc.get_next_trading_date(current_date, n)

    def is_trading_date(self, current_date: DateLike) -> bool:
        """判断是否为交易日。"""
        return self._calendar_svc.is_trading_date(current_date)

    # ── 配额 ──────────────────────────────────────────

    def get_quota(self) -> Quota:
        """获取当前用户配额。"""
        return self._quota_svc.get_quota()
