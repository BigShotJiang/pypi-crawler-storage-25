"""交易日历查询服务（仅 A 股）。

接口约定（服务端实现见 quant-cloud）：

- ``GET /api/calendar/trading-dates?start_date=&end_date=`` → ``["2024-01-02", ...]``
- ``GET /api/calendar/previous?date=&n=1`` → ``"2024-01-12"``
- ``GET /api/calendar/next?date=&n=1`` → ``"2024-01-16"``
- ``GET /api/calendar/is-trading-date?date=`` → ``{"is_trading": true}``
"""

from datetime import date

from ._dates import DateLike, normalize_date
from ._http import HttpClient


def _to_date(s: str) -> date:
    """ISO 字符串转 ``date``。"""
    return date.fromisoformat(s)


class CalendarService:
    """交易日历查询服务。"""

    def __init__(self, http: HttpClient) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
        """
        self._http = http

    def get_trading_dates(self, start_date: DateLike, end_date: DateLike) -> list[date]:
        """获取区间内所有交易日（含起止两端）。

        Args:
            start_date: 起始日期。
            end_date: 截止日期。

        Returns:
            升序排列的交易日列表。
        """
        params = {
            "start_date": normalize_date(start_date),
            "end_date": normalize_date(end_date),
        }
        data = self._http.get("/api/calendar/trading-dates", params=params)
        items = data if isinstance(data, list) else data.get("items", [])
        return [_to_date(s) for s in items]

    def get_previous_trading_date(self, current_date: DateLike, n: int = 1) -> date:
        """返回 ``current_date`` 之前第 n 个交易日。

        Args:
            current_date: 参考日期（不计入返回结果）。
            n: 向前偏移的交易日数，默认 1。

        Returns:
            交易日。
        """
        params = {"date": normalize_date(current_date), "n": str(n)}
        data = self._http.get("/api/calendar/previous", params=params)
        if isinstance(data, dict):
            return _to_date(data["date"])
        return _to_date(data)

    def get_next_trading_date(self, current_date: DateLike, n: int = 1) -> date:
        """返回 ``current_date`` 之后第 n 个交易日。

        Args:
            current_date: 参考日期（不计入返回结果）。
            n: 向后偏移的交易日数，默认 1。

        Returns:
            交易日。
        """
        params = {"date": normalize_date(current_date), "n": str(n)}
        data = self._http.get("/api/calendar/next", params=params)
        if isinstance(data, dict):
            return _to_date(data["date"])
        return _to_date(data)

    def is_trading_date(self, current_date: DateLike) -> bool:
        """判断给定日期是否为交易日。

        Args:
            current_date: 待判断日期。

        Returns:
            是否为交易日。
        """
        params = {"date": normalize_date(current_date)}
        data = self._http.get("/api/calendar/is-trading-date", params=params)
        if isinstance(data, dict):
            return bool(data.get("is_trading", False))
        return bool(data)
