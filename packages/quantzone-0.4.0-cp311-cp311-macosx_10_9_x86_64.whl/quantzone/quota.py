"""配额查询服务。

对外暴露简洁字段:``bytes_limit / bytes_used / remaining_days / license_type``。

后端 ``/api/quota/`` 返回的是三层账本字段(``daily_quota_bytes`` / ``daily_used_bytes``
/ ``extra_quota_bytes`` 等),SDK 在此处映射为对外简洁字段。
"""

from typing import TypedDict

from ._http import HttpClient


class Quota(TypedDict, total=False):
    """配额信息字典。

    Attributes:
        bytes_limit: 总流量上限（字节）。
        bytes_used: 已用流量（字节）。
        remaining_days: 许可剩余天数。
        license_type: 许可证类型（如 ``"trial"`` / ``"commercial"``）。
    """

    bytes_limit: int
    bytes_used: int
    remaining_days: int
    license_type: str


class QuotaService:
    """用户配额查询服务。"""

    def __init__(self, http: HttpClient) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
        """
        self._http = http

    def get_quota(self) -> Quota:
        """获取当前用户配额。

        把后端三层字段映射为对外简洁字段:
        - ``bytes_limit = daily_quota_bytes + extra_quota_bytes``
        - ``bytes_used  = daily_used_bytes``
        - ``remaining_days`` / ``license_type`` 透传

        Returns:
            配额字典,含 ``bytes_limit`` / ``bytes_used`` / ``remaining_days`` /
            ``license_type``。服务端缺失的源字段在结果中也会缺失。
        """
        data = self._http.get("/api/quota/")
        if not isinstance(data, dict):
            return {}

        result: Quota = {}
        if "daily_quota_bytes" in data and "extra_quota_bytes" in data:
            result["bytes_limit"] = int(data["daily_quota_bytes"]) + int(data["extra_quota_bytes"])
        if "daily_used_bytes" in data:
            result["bytes_used"] = int(data["daily_used_bytes"])
        if "remaining_days" in data:
            result["remaining_days"] = int(data["remaining_days"])
        if "license_type" in data:
            result["license_type"] = str(data["license_type"])
        return result
