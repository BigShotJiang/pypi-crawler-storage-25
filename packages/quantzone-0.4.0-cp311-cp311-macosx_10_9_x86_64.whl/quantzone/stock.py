"""股票/合约元信息查询服务。

接口约定:

- ``GET /api/stocks/`` → 全量合约列表(服务端缓存,12h TTL)

返回 ``DataFrame``,列固定 3 列:``order_book_id / industry_name / symbol``。
"""

import pandas as pd

from ._http import HttpClient

INSTRUMENT_COLUMNS = ["order_book_id", "industry_name", "symbol"]


def _to_dataframe(items: list[dict]) -> pd.DataFrame:
    """把 ``list[dict]`` 转为合约 ``DataFrame``,缺失列补 ``NA``,列顺序固定。"""
    if not items:
        return pd.DataFrame(columns=INSTRUMENT_COLUMNS)
    df = pd.DataFrame(items)
    for col in INSTRUMENT_COLUMNS:
        if col not in df.columns:
            df[col] = pd.NA
    return df[INSTRUMENT_COLUMNS]


class StockService:
    """股票/合约信息查询服务。"""

    def __init__(self, http: HttpClient) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
        """
        self._http = http

    def list_stocks(self) -> pd.DataFrame:
        """获取全量合约列表。

        服务端不再支持按交易所过滤,客户端拿全量后自行筛选,例如::

            df = client.list_stocks()
            sz = df[df["order_book_id"].str.endswith(".SZ")]

        Returns:
            合约 ``DataFrame``,列固定 3 列:
            ``order_book_id / industry_name / symbol``。
        """
        data = self._http.get("/api/stocks/")
        items = data if isinstance(data, list) else data.get("items", data.get("stocks", []))
        return _to_dataframe(items)
