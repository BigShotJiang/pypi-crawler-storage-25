"""日期参数归一化工具。

接受 int(YYYYMMDD) / str / date / datetime / Timestamp 多种格式,
本模块统一归一为 ISO ``YYYY-MM-DD`` 字符串发往服务端。
"""

from datetime import date, datetime
from typing import Union

import pandas as pd

DateLike = Union[int, str, date, datetime, pd.Timestamp]

_ISO_LEN = 10
_INT_DATE_LEN = 8
_INT_DATE_MIN = 19000101
_INT_DATE_MAX = 99991231


def normalize_date(value: DateLike | None) -> str | None:
    """把多种日期表示归一为 ISO ``YYYY-MM-DD`` 字符串。

    Args:
        value: 日期，支持 ``int(YYYYMMDD)`` / ``str`` / ``date`` / ``datetime`` /
            ``pd.Timestamp``；为 None 时直接返回 None。

    Returns:
        ISO 格式日期字符串，或 None。

    Raises:
        ValueError: 类型不支持或字符串无法解析为日期。
    """
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError(f"日期不接受 bool 类型: {value!r}")
    if isinstance(value, int):
        if not (_INT_DATE_MIN <= value <= _INT_DATE_MAX) or len(str(value)) != _INT_DATE_LEN:
            raise ValueError(f"int 日期必须为 8 位 YYYYMMDD: {value!r}")
        return f"{value // 10000:04d}-{(value // 100) % 100:02d}-{value % 100:02d}"
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, pd.Timestamp):
        return value.date().isoformat()
    if isinstance(value, str):
        return pd.Timestamp(value).date().isoformat()
    raise ValueError(f"不支持的日期类型: {type(value).__name__}={value!r}")
