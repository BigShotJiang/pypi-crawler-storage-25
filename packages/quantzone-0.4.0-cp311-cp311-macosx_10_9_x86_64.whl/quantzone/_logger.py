"""SDK 共享 logger,默认输出到 stderr。

用户可通过 ``logging.getLogger("quantzone").setLevel(...)`` 调整级别;
若用户已配置 root logger,可设置 ``logger.propagate = True`` 让消息传递。
"""

import logging
import sys

logger = logging.getLogger("quantzone")

if not logger.handlers:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("[quantzone] %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
