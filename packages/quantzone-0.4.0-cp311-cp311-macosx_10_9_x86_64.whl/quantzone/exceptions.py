"""宽舟科技 SDK 异常定义."""


class QuantError(Exception):
    """SDK 基类异常.

    Attributes:
        message: 错误信息。
        status_code: HTTP 状态码;非 HTTP 错误为 None。
        code: 服务端业务错误码(对齐 dwyeapi ApiResponse.code);
            未知/未携带时为 None。
    """

    def __init__(
        self,
        message: str = "",
        *,
        status_code: int | None = None,
        code: str | None = None,
    ):
        self.message = message
        self.status_code = status_code
        self.code = code
        super().__init__(message)


class AuthError(QuantError):
    """API Key 无效或已过期."""

    def __init__(self, message: str = "API Key 无效或已过期", *, code: str | None = None):
        super().__init__(message, status_code=401, code=code)


class ApiKeyRevokedError(AuthError):
    """API Key 已被吊销 → 服务端返回 401 + code=API_KEY_REVOKED.

    用户应在 admin 后台重置 / 重新申请 API Key 后再调用 SDK。
    """

    def __init__(
        self,
        message: str = "API Key 已被吊销,请联系管理员或重新申请",
    ):
        super().__init__(message, code="API_KEY_REVOKED")


class IpNotAllowedError(QuantError):
    """请求来源 IP 不在白名单 → 服务端返回 403 + code=IP_NOT_ALLOWED.

    用户应检查 admin 后台为该 API Key 设置的 IP 白名单是否覆盖当前出口 IP。
    """

    def __init__(
        self,
        message: str = "请求来源 IP 不在 API Key 白名单内",
    ):
        super().__init__(message, status_code=403, code="IP_NOT_ALLOWED")


class ApiKeyRateLimitError(QuantError):
    """API Key 调用频率超限 → 服务端返回 422 + code=API_KEY_RATE_LIMITED.

    与 QuotaExceededError 区分:前者是按"调用次数"限流(防滥用),
    后者是按"流量字节"扣费(配额耗尽)。
    """

    def __init__(
        self,
        message: str = "API Key 调用频率超限,请稍后再试",
    ):
        super().__init__(message, status_code=422, code="API_KEY_RATE_LIMITED")


class QuotaExceededError(QuantError):
    """配额不足."""

    def __init__(self, message: str = "配额不足", *, remaining: int = 0, required: int = 0):
        self.remaining = remaining
        self.required = required
        super().__init__(message, status_code=429)


class NetworkError(QuantError):
    """网络连接问题."""

    def __init__(self, message: str = "网络连接失败", *, cause: Exception | None = None):
        self.cause = cause
        super().__init__(message)


class SignatureError(QuantError):
    """签名校验失败（服务端返回 401）."""

    def __init__(self, message: str = "请求签名校验失败"):
        super().__init__(message, status_code=401)


class SDKVersionError(QuantError):
    """SDK 版本过低,服务端已停止支持（HTTP 426）。

    错误消息包含升级命令,用户按提示执行 `pip install -U quantzone` 即可。
    """

    def __init__(
        self,
        message: str = "当前 SDK 版本已停止支持,请执行 `pip install -U quantzone` 升级后重试",
    ):
        super().__init__(message, status_code=426)
