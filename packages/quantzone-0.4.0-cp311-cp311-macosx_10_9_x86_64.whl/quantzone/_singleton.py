"""模块级 ``quantzone.init(...)`` 维护的单例 ``QuantZone``。

顶层 init 风格:用户在程序启动时调用一次 ``init``,
之后通过模块顶层函数(如 ``quantzone.get_factors``)直接使用。
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import QuantZone

_INSTANCE: "QuantZone | None" = None


def init(
    access_key: str | None = None,
    sign_secret: str | None = None,
    *,
    base_url: str,
    timeout: float = 60.0,
    download_dir: Path | str | None = None,
) -> "QuantZone":
    """初始化模块级单例 ``QuantZone``。

    Args:
        access_key: 公开标识符;None 时从 keyring 读取。
        sign_secret: 签名密钥;None 时从 keyring 读取。
        base_url: 服务端地址,必须显式传入。
        timeout: 请求超时(秒)。
        download_dir: 下载目录;None 时使用 ``~/.quantzone/downloads``。

    Returns:
        已初始化的 ``QuantZone``。重复调用会先关闭旧实例再创建新的。
    """
    from .client import QuantZone

    global _INSTANCE
    if _INSTANCE is not None:
        _INSTANCE.close()
    _INSTANCE = QuantZone(
        access_key=access_key,
        sign_secret=sign_secret,
        base_url=base_url,
        timeout=timeout,
        download_dir=download_dir,
    )
    return _INSTANCE


def get_instance() -> "QuantZone":
    """获取已初始化的单例。

    Returns:
        当前单例。

    Raises:
        RuntimeError: 调用 ``init()`` 之前调用本函数。
    """
    if _INSTANCE is None:
        raise RuntimeError("尚未调用 quantzone.init(),请先初始化")
    return _INSTANCE


def reset() -> None:
    """关闭并清除单例(仅用于测试隔离)。"""
    global _INSTANCE
    if _INSTANCE is not None:
        _INSTANCE.close()
    _INSTANCE = None
