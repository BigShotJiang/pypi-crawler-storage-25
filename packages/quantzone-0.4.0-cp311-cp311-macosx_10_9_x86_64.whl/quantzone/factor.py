"""因子查询。

对外仅提供 :meth:`FactorService.get_factors` — 一次性返回完整 ``DataFrame``。

底层走 ``POST /api/factors/stream`` 拉 Arrow IPC stream:
- 边收边解码:每个 RecordBatch 立即转 ``DataFrame``。
- 边收边落盘:HTTP 字节同时写到 ``download_dir/temp/<id>.arrow``。
- 流自然结束 → 原子重命名到 ``download_dir/factors_<ts>.arrow``。
- 失败 → temp 文件保留,不删除。

字段名与 DolphinDB 表 ``dfs://factor_day/normal_factors_DB`` 一致:
``DataDate / ukey / x / factorname``。SDK 不做列名转换或宽表 pivot。
"""

from __future__ import annotations

import io
import os
import uuid
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path
from typing import IO, Any

import pandas as pd
import pyarrow.ipc as ipc

from ._dates import DateLike, normalize_date
from ._http import HttpClient
from ._logger import logger

DEFAULT_DOWNLOAD_DIR = Path.home() / ".quantzone" / "downloads"
PERSIST_FILENAME_PREFIX = "factors_"
TEMP_SUBDIR = "temp"
ARROW_EXT = ".arrow"


class _TeeReader(io.RawIOBase):
    """把上游 chunk 流复制一份到磁盘文件,同时对外暴露 file-like ``read`` 接口。

    用于 ``pa.ipc.open_stream`` 这种需要 file-like 的解码器:它从这里 ``read``,
    我们一边给它字节、一边把字节写到 temp 文件,实现 tee。

    继承 ``io.RawIOBase`` 是为了一次性补齐 ``closed`` / ``seekable`` / ``writable``
    等 pyarrow 校验需要的属性。
    """

    def __init__(self, chunks: Iterator[bytes], sink: IO[bytes]) -> None:
        """初始化。

        Args:
            chunks: 上游 HTTP chunk 字节迭代器(``httpx.Response.iter_bytes``)。
            sink: 已打开的 temp 文件句柄(二进制写)。
        """
        super().__init__()
        self._chunks = chunks
        self._sink = sink
        self._buffer = bytearray()

    def _pull_one(self) -> bool:
        """从上游再拉一个 chunk,同时写入 sink。返回是否拉到。"""
        try:
            chunk = next(self._chunks)
        except StopIteration:
            return False
        if not chunk:
            return True
        self._buffer.extend(chunk)
        self._sink.write(chunk)
        return True

    def read(self, n: int = -1) -> bytes:
        """读取至多 n 字节;n<0 表示读到 EOF。"""
        if n is None or n < 0:
            while self._pull_one():
                pass
            data = bytes(self._buffer)
            self._buffer.clear()
            return data
        while len(self._buffer) < n:
            if not self._pull_one():
                break
        take = bytes(self._buffer[:n])
        del self._buffer[:n]
        return take

    def readall(self) -> bytes:
        return self.read(-1)

    def readinto(self, b) -> int:
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    def readable(self) -> bool:
        return True

    def writable(self) -> bool:
        return False

    def seekable(self) -> bool:
        return False


def _to_str_list(value: str | list[str] | None) -> list[str] | None:
    """把 ``str`` / ``list[str]`` / None 归一为 ``list[str]`` 或 None。"""
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    return list(value)


class FactorService:
    """因子数据查询服务。"""

    def __init__(self, http: HttpClient, download_dir: Path | None = None) -> None:
        """初始化。

        Args:
            http: HTTP 客户端。
            download_dir: 默认下载目录;None 表示 ``~/.quantzone/downloads``。
        """
        self._http = http
        self._download_dir = download_dir or DEFAULT_DOWNLOAD_DIR

    def get_factors(
        self,
        order_book_ids: str | list[str] | None = None,
        factor: str | list[str] | None = None,
        start_date: DateLike | None = None,
        end_date: DateLike | None = None,
        filename: str | None = None,
    ) -> pd.DataFrame:
        """一次性返回完整因子数据(窄表)。

        服务端按月分批查 DolphinDB,每个 RecordBatch 立即推过来;SDK 边收边解码、
        边落盘到 ``download_dir/temp/<id>.arrow``。流自然结束后原子重命名到
        ``download_dir/<filename or factors_<ts>.arrow>``;失败 → temp 文件保留,
        不删除。

        Args:
            order_book_ids: 股票代码(``str`` 或 ``list[str]``),None 表示全市场。
                示例:``"000001.SZ"`` 或 ``["000001.SZ", "000002.SZ"]``。
            factor: 因子名(``str`` 或 ``list[str]``),None 表示全部因子。
                示例:``"alpha1"`` 或 ``["alpha1", "vwap"]``。
            start_date: 起始日期,支持 ``int(YYYYMMDD)`` / ``str`` / ``date`` /
                ``datetime`` / ``Timestamp``。None 表示不限。
            end_date: 截止日期,格式同上。
            filename: 自定义最终文件名(落到 ``download_dir`` 下);None 时按时间戳生成。

        Returns:
            窄表 ``DataFrame``,列:``DataDate / ukey / x / factorname``。
            空结果时返回带正确列名的空 DataFrame。
        """
        ids_list = _to_str_list(order_book_ids)
        factor_list = _to_str_list(factor)

        body: dict[str, Any] = {}
        if factor_list:
            body["factor"] = factor_list
        if ids_list:
            body["order_book_ids"] = ids_list
        if start_date is not None:
            body["start_date"] = normalize_date(start_date)
        if end_date is not None:
            body["end_date"] = normalize_date(end_date)

        download_dir = self._download_dir
        temp_dir = download_dir / TEMP_SUBDIR
        temp_dir.mkdir(parents=True, exist_ok=True)
        download_dir.mkdir(parents=True, exist_ok=True)

        temp_path = temp_dir / f"{uuid.uuid4().hex}{ARROW_EXT}"
        final_name = filename or (
            f"{PERSIST_FILENAME_PREFIX}{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:8]}{ARROW_EXT}"
        )
        final_path = download_dir / final_name

        logger.info("下载文件(temp): %s", temp_path)

        chunks_dfs = list(self._iter_batches(body, temp_path, final_path))
        if not chunks_dfs:
            return pd.DataFrame(columns=["DataDate", "ukey", "x", "factorname"])
        return pd.concat(chunks_dfs, ignore_index=True)

    def _iter_batches(
        self,
        body: dict[str, Any],
        temp_path: Path,
        final_path: Path,
    ) -> Iterator[pd.DataFrame]:
        """流式解码生成器:每个 RecordBatch 立即 yield ``DataFrame``,边收边写 temp。"""
        success = False
        sink = temp_path.open("wb")
        try:
            with self._http.stream_post_iter("/api/factors/stream", body) as chunks:
                tee = _TeeReader(chunks, sink)
                reader = ipc.open_stream(tee)
                while True:
                    try:
                        batch = reader.read_next_batch()
                    except StopIteration:
                        break
                    if batch is None:
                        break
                    yield batch.to_pandas()
            success = True
        finally:
            sink.flush()
            sink.close()
            if success:
                os.replace(temp_path, final_path)
                size = final_path.stat().st_size
                logger.info("已保存到: %s (%d bytes)", final_path, size)
            else:
                logger.info("流未正常结束,temp 文件保留: %s", temp_path)

    def list_factors(self) -> list[dict]:
        """获取可用因子元信息列表。

        字段与 DolphinDB 表 ``dfs://factor_meta/factor_meta_info`` 原始列对齐。

        Returns:
            因子列表,每个元素含 ``factorname`` / ``startDate`` / ``endDate`` 三个字段。
        """
        data = self._http.get("/api/factors/")
        if isinstance(data, list):
            return data
        return data.get("items", data.get("factors", []))
