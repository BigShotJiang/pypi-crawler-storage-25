"""宽舟科技量化数据平台 Python SDK。

两种使用方式:

1. 实例化客户端(推荐)::

    from quantzone import QuantZone

    client = QuantZone(access_key="AK...", sign_secret="...", base_url="https://...")
    df = client.get_factors(order_book_ids="000001.SZ", factor="alpha1",
                            start_date="2024-01-01", end_date="2024-12-31")

2. 模块级单例(可用 ``import qz`` 简写)::

    import qz

    qz.init(access_key="AK...", sign_secret="...", base_url="https://...")
    df = qz.get_factors(order_book_ids="000001.SZ", factor="alpha1",
                       start_date="2024-01-01", end_date="2024-12-31")
"""

from datetime import date

import pandas as pd

from ._dates import DateLike
from ._singleton import get_instance, init
from .client import QuantZone
from .exceptions import (
    ApiKeyRateLimitError,
    ApiKeyRevokedError,
    AuthError,
    IpNotAllowedError,
    NetworkError,
    QuantError,
    QuotaExceededError,
    SDKVersionError,
    SignatureError,
)
from .quota import Quota

__version__ = "0.4.0"


def get_factors(
    order_book_ids: str | list[str] | None = None,
    factor: str | list[str] | None = None,
    start_date: DateLike | None = None,
    end_date: DateLike | None = None,
    filename: str | None = None,
) -> pd.DataFrame:
    """模块级 ``get_factors``(需先调用 ``quantzone.init``)。"""
    return get_instance().get_factors(
        order_book_ids=order_book_ids,
        factor=factor,
        start_date=start_date,
        end_date=end_date,
        filename=filename,
    )


def list_factors() -> list[dict]:
    """模块级 ``list_factors``。"""
    return get_instance().list_factors()


def list_stocks() -> pd.DataFrame:
    """模块级 ``list_stocks``。"""
    return get_instance().list_stocks()


def get_trading_dates(start_date: DateLike, end_date: DateLike) -> list[date]:
    """模块级 ``get_trading_dates``。"""
    return get_instance().get_trading_dates(start_date, end_date)


def get_previous_trading_date(current_date: DateLike, n: int = 1) -> date:
    """模块级 ``get_previous_trading_date``。"""
    return get_instance().get_previous_trading_date(current_date, n)


def get_next_trading_date(current_date: DateLike, n: int = 1) -> date:
    """模块级 ``get_next_trading_date``。"""
    return get_instance().get_next_trading_date(current_date, n)


def is_trading_date(current_date: DateLike) -> bool:
    """模块级 ``is_trading_date``。"""
    return get_instance().is_trading_date(current_date)


def get_quota() -> Quota:
    """模块级 ``get_quota``。"""
    return get_instance().get_quota()


__all__ = [
    "ApiKeyRateLimitError",
    "ApiKeyRevokedError",
    "QuantZone",
    "Quota",
    "QuantError",
    "AuthError",
    "IpNotAllowedError",
    "QuotaExceededError",
    "NetworkError",
    "SignatureError",
    "SDKVersionError",
    "init",
    "get_factors",
    "list_factors",
    "list_stocks",
    "get_trading_dates",
    "get_previous_trading_date",
    "get_next_trading_date",
    "is_trading_date",
    "get_quota",
    "__version__",
]
