"""
polymarket-arb-detector — Arbitrage gap detector for Polymarket.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.arbitrage import find_arbitrage_gaps

__all__ = ["find_arbitrage_gaps"]
__version__ = "0.1.0"
