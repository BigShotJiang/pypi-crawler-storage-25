# polymarket-arb-detector

Arbitrage gap detector for Polymarket. Scans markets where YES+NO prices don't sum to 1.00.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-arb-detector
```

## Usage

```python
from polymarket_arb_detector import find_arbitrage_gaps
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
