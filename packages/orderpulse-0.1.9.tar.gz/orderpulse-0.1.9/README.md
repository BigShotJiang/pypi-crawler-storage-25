# OrderPulse

OrderPulse is a high-performance binary market-feed parser built in Rust and packaged for Python. It is designed for workflows where Python is used for strategy research, monitoring, and analytics, while the heavy parsing work stays inside a native extension.

The current Rust binding is centered on a single Python-facing class, `ReadMsgFromBinary`, which loads a feed file, decodes order and trade packets, optionally filters by token, and exposes sequential and aggregate access methods.

## Why OrderPulse

- Rust-backed parsing for low-overhead feed ingestion.
- Memory-mapped file reading through `memmap2` for large binary files.
- Python-friendly API for analysis, debugging, and offline replay.
- Built-in support for order and trade message separation.
- Optional token filtering during object construction to reduce downstream work.
- Simple formatted output for inspection without writing custom decoders first.

## Installation

Install from PyPI:

```bash
pip install orderpulse
```


# Build From Source

## Requirements

- Rust >= 1.75
- Python >= 3.9
- maturin

---

## Install maturin

```bash
pip install maturin
```

---

## Build Wheel

```bash
maturin build --release
```

## Install Local Wheel

```bash
pip install target/wheels/*.whl --force-reinstall
```


---

## Import Path

The package published on PyPI is named `OrderPulse`.

In the current project layout, the native extension is configured around the `fastreader` module name, so examples below use:

```python
from fastreader import ReadMsgFromBinary
```

If you are working from an older local build and do not see `ReadMsgFromBinary`, rebuild the extension before testing examples.

## Quick Start

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")

print("total messages:", reader.total_messages())
print("total trades:", reader.total_trades())
print("total orders:", reader.total_orders())

print(reader.next_message())
```

To load only a single token:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin", token=1333)
print(reader.total_messages())
```

## Architecture

OrderPulse follows a compact four-layer design.

### 1. Binary Layout Layer

The `structure.rs` module defines the low-level packet layout used by the feed parser:

- `StreamHeader` stores framing metadata such as message length and sequence number.
- `OrderMessage` models order-specific fields like `order_id`, `token`, `price`, and `quantity`.
- `TradeMessage` models trade-specific fields like `buy_order_id`, `sell_order_id`, `trade_price`, and `trade_quantity`.
- `OrderPacket` and `TradePacket` wrap decoded payloads with transport metadata and local timestamp fields.
- `Message` is the internal enum used to store either an order or trade packet in one collection.

This layer is the schema contract between raw bytes and higher-level Python methods.

### 2. Parsing Layer

The `read_trd_ord_only.rs` module performs the heavy lifting:

- Opens the binary file.
- Maps it into memory with `memmap2`.
- Walks the buffer packet by packet.
- Identifies message types using a lightweight peek structure.
- Decodes order packets for `N`, `M`, and `X` message types.
- Decodes trade packets for `T` message types.
- Applies little-endian fixups to numeric fields.
- Falls back to byte-wise resynchronization on unknown message markers.

This design keeps parsing fast while still being resilient to malformed or partially truncated buffers.

### 3. Python Bridge Layer

The `lib.rs` module exposes the parser to Python with PyO3.

`ReadMsgFromBinary` owns:

- `messages`: a `Vec<Message>` containing decoded feed events.
- `current_index`: a cursor used for sequential iteration through the decoded stream.

The constructor reads the file once, optionally filters by token, and then all later operations work on the in-memory decoded message list.

### 4. Timing Utilities

The `tsc.rs` module provides cycle-counter helpers for low-level benchmarking on supported CPU architectures. This is an internal performance utility layer and is not part of the Python-facing public API.

## Data Flow

```text
Binary feed file
	-> memory map
	-> peek message type
	-> decode packet struct
	-> normalize endianness
	-> store as Message::Order or Message::Trade
	-> expose through ReadMsgFromBinary methods
```

## Public API

The current Python-facing API described below is based on the class exposed in `src/lib.rs`.

### `ReadMsgFromBinary(path, token=None)`

Creates a reader from a binary feed file.

Parameters:

- `path`: path to the binary market-feed file.
- `token`: optional token filter applied immediately after parsing.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
filtered_reader = ReadMsgFromBinary("/data/feed.bin", token=26000)
```

When to use it:

- Use without `token` when you want full-feed analytics.
- Use with `token` when you want a smaller in-memory slice for one instrument.

### `all_messages(msg_type, limit=None)`

Returns formatted messages for one side of the feed.

Parameters:

- `msg_type`: expected values are `"order"` or `"trade"`.
- `limit`: optional cap on how many formatted rows to return.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")

orders = reader.all_messages("order", limit=5)
for row in orders:
	print(row)
```

Practical use:

- Quick inspection during parser validation.
- Building lightweight text exports without writing a formatter yourself.

### `total_messages()`

Returns the number of decoded messages currently stored in the reader.

Example:

```python
from fastreader  import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
count = reader.total_messages()
print(count)
```

### `total_orders()`

Returns the number of order messages in the current in-memory slice.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
print(reader.total_orders())
```

### `total_trades()`

Returns the number of trade messages in the current in-memory slice.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
print(reader.total_trades())
```

### `summary()`

Provides a compact overview of the loaded dataset.

Use it when you want one command to inspect feed size and composition after loading or filtering.

Example:

```python
from fastreader  import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin", token=1333)
summary = reader.summary()
print(summary)
```

Typical output intent:

```python
(total_messages, total_trades, total_orders)
```

### `next_message()`

Returns the next decoded message as a formatted string and advances the internal cursor. Once the cursor reaches the end of the message list, it returns `"END"`.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")

while True:
	msg = reader.next_message()
	if msg == "END":
		break
	print(msg)
```

This is the simplest way to replay a feed sequentially from Python.

### `delete_messages(order_id)`

Removes messages associated with a given order identifier.

The method is intended to:

- delete order messages whose `order_id` matches the provided value.
- delete trade messages where either the buy-side or sell-side order id matches the provided value.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
removed = reader.delete_messages(987654321)
print("removed:", removed)
print("remaining:", reader.total_messages())
```

### `print_messages(limit=None)`

Prints formatted messages directly to standard output.

Parameters:

- `limit`: optional maximum number of messages to print.

Example:

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin")
reader.print_messages(limit=10)
```

Use this when you want quick console inspection instead of collecting strings into Python lists.

## Message Types

The current parser distinguishes messages as follows:

- `T`: trade packet
- `N`: order packet
- `M`: order packet
- `X`: order packet

Anything else triggers a resynchronization step in the parser.

## Debugging Parser Runs

The parser includes optional debug logging controlled by environment variables:

```bash
export ORDERPULSE_DEBUG=1
export ORDERPULSE_DEBUG_LIMIT=100
```

This is useful when validating offsets, truncated packets, or unknown message markers in a corrupted feed sample.

## Example Workflow

```python
from fastreader import ReadMsgFromBinary

reader = ReadMsgFromBinary("/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin", token=500112)

print("messages:", reader.total_messages())
print("orders:", reader.total_orders())
print("trades:", reader.total_trades())

print("first event:")
print(reader.next_message())

recent_trades = reader.all_messages("trade", limit=3)
for trade in recent_trades:
	print(trade)
```

## Performance Notes

- Parsing is implemented in Rust to minimize Python overhead on binary decoding.
- Memory mapping avoids copying the entire input into an intermediate Python buffer.
- Filtering by token at construction time reduces later traversal work for focused workflows.
- Sequential reads through `next_message()` are backed by an internal cursor, which keeps replay logic simple.

## Best Fit Use Cases

- Exchange feed replay tooling
- Order-flow research pipelines
- Token-level diagnostics and post-trade analysis
- Parser validation against captured market data
- Python analytics workflows that need native-speed decoding

## Build and Publish Notes

- Build from the project root where `Cargo.toml` and `pyproject.toml` live.
- If you change the extension API, rebuild the wheel before validating Python examples.
- Keep the package version synchronized across Rust and Python metadata before publishing a new release.

## License

Add your license here before publishing to PyPI.
