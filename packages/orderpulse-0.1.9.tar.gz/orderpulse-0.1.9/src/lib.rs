use pyo3::prelude::*;

mod structure;
mod read_trd_ord_only;
mod tsc;

use read_trd_ord_only::read_messages;
use structure::Message;

/// format message function to convert a Message enum into a human-readable string this function takes a reference to a Message and matches on its type (Order or Trade) to extract the relevant fields and format them into a descriptive string this allows for easy inspection of the message details in a readable format
fn format_message(msg: &Message) -> String {
    match msg {
        Message::Order(order_packet) => {
            let seq_no = order_packet.hdr.seq_no;
            let msg_len = order_packet.hdr.msg_len;
            let msg_type = order_packet.ord.msg_type as char;
            let exch_ts = order_packet.ord.exch_ts;
            let order_id = order_packet.ord.order_id;
            let local_ts = order_packet.local_ts;
            let missed = if order_packet.flags { 1 } else { 0 };
            let token = order_packet.ord.token;
            let order_type = order_packet.ord.order_type as char;
            let price = order_packet.ord.price;
            let quantity = order_packet.ord.quantity;

            format!(
                "Order Message: SeqNo{}, msg_len{}, Msg_Type'{}', Exch_ts{}, local_ts{}, order_id{}, Token{}, order_Type'{}', Price{}, Quantity{}, missed{}",
                seq_no,
                msg_len,
                msg_type,
                exch_ts,
                local_ts,
                order_id,
                token,
                order_type,
                price,
                quantity,
                missed
            )
        }
        Message::Trade(trade_packet) => {
            let seq_no = trade_packet.hdr.seq_no;
            let msg_len = trade_packet.hdr.msg_len;
            let msg_type = trade_packet.trd.msg_type as char;
            let exch_ts = trade_packet.trd.exch_ts;
            let local_ts = trade_packet.local_ts;
            let order_id_buy = trade_packet.trd.buy_order_id;
            let order_id_sell = trade_packet.trd.sell_order_id;
            let missed = if trade_packet.flags { 1 } else { 0 };
            let token = trade_packet.trd.token;
            let price = trade_packet.trd.trade_price;
            let quantity = trade_packet.trd.trade_quantity;

            format!(
                "Trade Message: SeqNo{}, msg_len{}, Msg_Type'{}', Exch_ts{}, local_ts{}, order_id_buy{}, order_id_sell{}, Token{}, Price{}, Quantity{}, missed{}",
                seq_no,
                msg_len,
                msg_type,
                exch_ts,
                local_ts,
                order_id_buy,
                order_id_sell,
                token,
                price,
                quantity,
                missed
            )
        }
    }
}

#[pyclass]
pub struct ReadMsgFromBinary {
    /// all messages read from the binary file (orders and trades) 
    ///this is the main data structure that holds the messages and is manipulated by the various methods 
    messages: Vec<Message>,
    current_index: usize,
}

#[pymethods]
impl ReadMsgFromBinary {  
    #[new] // constructor to create a new instance of ReadMsgFromBinary by reading messages from the specified binary file path and optionally filtering by token
    #[pyo3(signature = (path, token=None))] 
    fn new(path: String, token: Option<u32>) -> PyResult<Self> {
        let messages = read_messages(&path)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let filtered_messages = if let Some(filter_token) = token {
            messages
                .into_iter()
                .filter(|msg| match msg {
                    Message::Order(o) => o.ord.token == filter_token,
                    Message::Trade(t) => t.trd.token as u32 == filter_token,
                })
                .collect()
        } else {
            messages
        };

        Ok(Self {
            messages: filtered_messages,
            current_index: 0,
        })
    }

    #[pyo3(signature = (msg_type, limit=None))]
    fn all_messages(&self, msg_type: String, limit: Option<usize>) -> Vec<String> {
        /// all messages method to retrieve all messages of a specific type 
         ///this method takes a message type as a parameter and an optional
         ///  limit to specify how many messages to return if the limit is not provided it will return all messages of the specified type the method filters the messages based on the message type and returns a vector of formatted strings representing each message this allows for easy retrieval and inspection of messages of a specific type in a human-readable format
        self
            .messages
            .iter()
            .filter(|msg| match (msg_type.as_str(), msg) {
                ("order", Message::Order(_)) => true,
                ("trade", Message::Trade(_)) => true,
                _ => false,
            })
            .take(limit.unwrap_or(usize::MAX))
            .map(format_message)
            .collect()
    }

    fn total_messages(&self) -> usize {
        self.messages.len()
    }

    fn total_orders(&self) -> usize {
        self.messages
            .iter()
            .filter(|m| matches!(m, Message::Order(_)))
            .count()
    }

    fn total_trades(&self) -> usize {
        self.messages
            .iter()
            .filter(|m| matches!(m, Message::Trade(_)))
            .count()
    }

///summary method to print the total number of messages trades and orders in the current istance of ReadMsgFromBinary this provides a quick overview of the data contained in the instance and is useful for understanding the composition of the messages after any filtering or deletions have been applied
    fn summary(&self) -> (usize, usize, usize) {
        (
            self.total_messages(),
            self.total_trades(),
            self.total_orders(),
        )
    }
    
/// next message method to retrieve the next message in the list of messages and format it as a 
/// humman-readable string this method checks if the current index has reached the end of the 
/// messages list and returns "END" if there are no more messages otherwise it retrieves the current message based on the current index increments the index for the next call and formats the message details into a string depending on whether it's an order or trade message this allows for easy inspection of individual messages in a readable format
    fn next_message(&mut self) -> String {
        if self.current_index >= self.messages.len() {
            return "END".to_string();
        }

        let msg = &self.messages[self.current_index];

        self.current_index += 1;

        format_message(msg)
    }

    #[pyo3(signature = (order_id))]
    fn delete_messages(&mut self, order_id: u64) -> usize {
        ///delete messages method to remove messages from the list based on a specific order ID this method takes an order ID as a parameter and filters the messages list to exclude any messages that match the given order ID this allows for the removal of specific messages from the instance based on their order ID which can be useful for cleaning up data or focusing on relevant messages
        let before = self.messages.len();
        
        self.messages.retain(|m| {
            match m {
                Message::Order(o) => o.ord.order_id != order_id,
                Message::Trade(t) => {
                    t.trd.buy_order_id != order_id && t.trd.sell_order_id != order_id
                }
            }
        });

        before - self.messages.len()
    }

    #[pyo3(signature = (limit=None))]
    fn print_messages(&mut self, limit: Option<usize>) {
        ///print messages method to print the messages in a human-readable format this method takes an optional 
        /// parameter to specify how many messages to print if the limit is not provided it will print all messages the
        /// method uses a loop to call the next_message method and prints each message until it reaches the end of the messages or the specified
        /// limit this allows for easy inspection of the messages in a readable format without overwhelming the output if there are many messages
        let mut count = 0usize;

        loop {
            if let Some(max) = limit {
                if count >= max {
                    break;
                }
            }

            let msg = self.next_message();

            if msg == "END" {
                break;
            }

            println!("{}", msg);

            count += 1;
        }
    }
}

#[pymodule]
fn fastreader(_py: Python, m: &Bound<PyModule>) -> PyResult<()> {
    m.add_class::<ReadMsgFromBinary>()?;
    Ok(())
}