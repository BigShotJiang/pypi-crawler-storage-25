"""
Intégration NiceGUI pour Taskiq-Flow.

Ce module fournit des composants NiceGUI pour visualiser et interagir
avec les DAG et pipelines Taskiq-Flow.

Auteur: SoniqueBay Team
Version: 1.0.2
"""

from taskiq_flow.integration.nicegui.mermaid import MermaidGenerator

__all__ = ["MermaidGenerator"]
