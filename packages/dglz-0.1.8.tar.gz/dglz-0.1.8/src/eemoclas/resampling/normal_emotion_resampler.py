"""Normal-subject emotion resampler for Classifier 2 (neutral vs positive)."""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import torch

from eemoclas.data.eeg_io import load_train_mat
from eemoclas.data.eeg_splitter import split_train_emotion
from eemoclas.data.preprocessing import (
    channel_select,
    clip_signal,
    z_score,
)
from eemoclas.resampling.base_resampler import BaseResampler
from eemoclas.resampling.manifest import build_emotion_manifest_row
from eemoclas.resampling.stats import compute_resample_stats
from eemoclas.resampling.truncated_gaussian import TruncatedGaussianWindowSampler

logger = logging.getLogger(__name__)

# Emotion label constants.
EMOTION_NEU = 0  # neutral
EMOTION_POS = 1  # positive

# This resampler only processes normal (group_label=0) subjects.
GROUP_LABEL = 0


class NormalEmotionResampler(BaseResampler):
    """Generate the resampled dataset for Classifier 2.

    Only subjects with ``group_label == 0`` (normal) are processed.  Each of
    the 8 segments (4 neutral + 4 positive) from a subject is treated
    independently.  For every repeat a random 10-second window is cropped,
    preprocessed, and saved as an individual ``[C_eff, 2500]`` sample with an
    emotion label (neutral / positive).
    """

    def run(self) -> None:
        """Execute the full resampling pipeline."""
        self.save_config_snapshot()

        cfg = self.config
        data_cfg = cfg["data"]
        resample_cfg = cfg.get("resample", {})

        fs: int = data_cfg.get("fs", 250)
        samples_per_segment: int = resample_cfg.get("samples_per_segment", 8)
        base_seed: int = cfg.get("seed", 42)
        channel_set: str = data_cfg.get("channel_set", "standard")

        mu_seconds: float = resample_cfg.get("mu_seconds", 25.0)
        sigma_seconds: float = resample_cfg.get("sigma_seconds", 8.0)
        lower_seconds: float = resample_cfg.get("lower_seconds", 5.0)
        upper_seconds: float = resample_cfg.get("upper_seconds", 45.0)
        window_seconds: float = resample_cfg.get("window_seconds", 10.0)

        subjects_csv = data_cfg.get("index_file", data_cfg.get("subjects_csv", "train_subjects.csv"))
        subject_list = self._load_normal_subjects(subjects_csv)

        from eemoclas.utils.config import resolve_c_eff

        c_eff = resolve_c_eff(cfg)

        _, token_meta = channel_select(
            np.zeros((30, 2500)),
            channel_set=channel_set,
            return_meta=True,
        )

        _params = {
            "fs": fs,
            "samples_per_segment": samples_per_segment,
            "base_seed": base_seed,
            "channel_set": channel_set,
            "mu_seconds": mu_seconds,
            "sigma_seconds": sigma_seconds,
            "lower_seconds": lower_seconds,
            "upper_seconds": upper_seconds,
            "window_seconds": window_seconds,
            "c_eff": c_eff,
            "token_meta": token_meta,
        }

        # Assign deterministic global sample offset per subject.
        # Each subject has 8 segments * samples_per_segment samples.
        samples_per_subject = 8 * samples_per_segment
        subject_offsets: dict[str, int] = {}
        offset = 0
        for entry in subject_list:
            subject_offsets[entry["subject_id"]] = offset
            offset += samples_per_subject

        def _process_subject(subject_entry: dict) -> list[dict]:
            return self._process_subject_samples(
                subject_entry, _params, subject_offsets[subject_entry["subject_id"]]
            )

        manifest_rows = self._parallel_map(
            _process_subject,
            subject_list,
            desc="normal_emotion",
        )

        self.write_manifest(manifest_rows)
        stats = compute_resample_stats(manifest_rows, task_name="normal_emotion")
        self.write_stats(stats)

        logger.info(
            "Normal-emotion resampling complete: %d samples from %d subjects.",
            len(manifest_rows),
            len(subject_list),
        )

    # ------------------------------------------------------------------
    # Per-subject worker (thread-safe)
    # ------------------------------------------------------------------

    def _process_subject_samples(
        self,
        subject_entry: dict,
        params: dict[str, Any],
        global_offset: int,
    ) -> list[dict]:
        """Process a single subject and return manifest rows."""
        subject_id = subject_entry["subject_id"]
        mat_path = subject_entry["mat_path"]

        fs = params["fs"]
        samples_per_segment = params["samples_per_segment"]
        base_seed = params["base_seed"]
        channel_set = params["channel_set"]
        mu_seconds = params["mu_seconds"]
        sigma_seconds = params["sigma_seconds"]
        lower_seconds = params["lower_seconds"]
        upper_seconds = params["upper_seconds"]
        window_seconds = params["window_seconds"]
        c_eff = params["c_eff"]
        token_meta = params["token_meta"]

        logger.info("Processing normal subject %s", subject_id)

        raw = load_train_mat(mat_path)
        neu_segments = split_train_emotion(raw["EEG_data_neu"])
        pos_segments = split_train_emotion(raw["EEG_data_pos"])

        segments_info = []
        for i, seg in enumerate(neu_segments):
            segments_info.append(
                {"segment": seg, "emotion": EMOTION_NEU, "seg_id": f"neu_{i}"}
            )
        for i, seg in enumerate(pos_segments):
            segments_info.append(
                {"segment": seg, "emotion": EMOTION_POS, "seg_id": f"pos_{i}"}
            )

        manifest_rows: list[dict] = []
        sample_idx = global_offset

        for seg_info in segments_info:
            seg = seg_info["segment"]       # (30, 12500)
            emotion = seg_info["emotion"]
            seg_id = seg_info["seg_id"]
            segment_points = seg.shape[1]

            for repeat in range(samples_per_segment):
                seed = base_seed + sample_idx

                sampler = TruncatedGaussianWindowSampler(
                    fs=fs,
                    window_seconds=window_seconds,
                    mu_seconds=mu_seconds,
                    sigma_seconds=sigma_seconds,
                    lower_seconds=lower_seconds,
                    upper_seconds=upper_seconds,
                    seed=seed,
                )

                window = sampler.sample_window(segment_points)
                cropped = sampler.crop(seg, window)

                processed = channel_select(cropped, channel_set=channel_set)
                processed = z_score(processed)
                processed = clip_signal(processed)

                x_tensor = torch.from_numpy(processed).float()  # (C_eff, L)

                self.validate_token_meta(x_tensor, token_meta)

                sample_id = f"ne_{subject_id}_{seg_id}_{repeat:04d}"

                sample = {
                    "x": x_tensor,
                    "y": torch.LongTensor([emotion]),
                    "subject_id": subject_id,
                    "group_label": GROUP_LABEL,
                    "emotion_label": emotion,
                    "segment_id": seg_id,
                    "token_meta": token_meta,
                    "meta": {
                        "sampler": "truncated_gaussian",
                        "center_seconds": window["center_seconds"],
                        "start_sample": window["start_sample"],
                        "end_sample": window["end_sample"],
                    },
                }

                path = self.save_sample(sample, sample_id)

                row = build_emotion_manifest_row(
                    sample_id=sample_id,
                    sample_path=path,
                    subject_id=subject_id,
                    group_label=GROUP_LABEL,
                    emotion_label=emotion,
                    segment_id=seg_id,
                    center_seconds=window["center_seconds"],
                    start_sample=window["start_sample"],
                    end_sample=window["end_sample"],
                    c_eff=c_eff,
                    length=x_tensor.shape[-1],
                    seed=seed,
                )
                manifest_rows.append(row)
                sample_idx += 1

        return manifest_rows

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_normal_subjects(csv_path: str) -> list[dict]:
        """Load only normal (group_label=0) subjects from the CSV."""
        import pandas as pd
        from pathlib import Path

        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f"Subjects CSV not found: {csv_path}")

        df = pd.read_csv(path)
        required = {"subject_id", "group_label", "mat_path"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(
                f"Subjects CSV missing required columns: {missing}"
            )

        df = df[df["group_label"] == 0]
        if df.empty:
            logger.warning("No normal (group_label=0) subjects found in %s", csv_path)

        return df.to_dict(orient="records")
