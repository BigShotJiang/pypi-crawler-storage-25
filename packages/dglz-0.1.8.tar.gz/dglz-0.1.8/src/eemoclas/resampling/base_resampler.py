"""Abstract base class for EEG resamplers."""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import torch
import yaml

logger = logging.getLogger(__name__)


class BaseResampler(ABC):
    """Base class for all resampling pipelines.

    Parameters
    ----------
    config : dict
        Full configuration dictionary.  Must contain at least
        ``config["data"]["output_dir"]``.
    """

    def __init__(self, config: dict) -> None:
        self.config = config
        self.output_dir = Path(config["data"]["output_dir"])
        self.samples_dir = self.output_dir / "samples"
        self.samples_dir.mkdir(parents=True, exist_ok=True)
        self._workers: int = config.get("resample", {}).get("workers", 1)

    # ------------------------------------------------------------------
    # Abstract
    # ------------------------------------------------------------------

    @abstractmethod
    def run(self) -> None:
        """Execute the full resampling pipeline."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Parallel execution helper
    # ------------------------------------------------------------------

    def _parallel_map(
        self,
        func: Callable[..., list[dict]],
        items: list[Any],
        *,
        desc: str = "processing",
    ) -> list[dict]:
        """Apply *func* to each item, optionally in parallel with Rich progress.

        When ``workers > 1``, uses :class:`ThreadPoolExecutor`.  Results are
        collected in the original *items* order so that manifest rows stay
        deterministic regardless of thread scheduling.

        Parameters
        ----------
        func:
            A callable that takes a single item and returns a list of
            manifest-row dicts.
        items:
            Iterable of work items (e.g. subject entries).
        desc:
            Human-readable label for log messages and progress bar.

        Returns
        -------
        list[dict]
            All manifest rows, concatenated in input order.
        """
        workers = max(1, self._workers)
        total = len(items)

        if total == 0:
            return []

        # Try Rich progress bar; fall back to plain loop
        progress = self._create_progress(desc, total, workers)
        all_rows: list[dict] = []

        if workers == 1 or total <= 1:
            # Sequential path
            for item in items:
                all_rows.extend(func(item))
                if progress is not None:
                    progress.advance(0)
            if progress is not None:
                progress.stop()
            return all_rows

        # Parallel path
        logger.info(
            "%s: using %d worker threads for %d items",
            desc, workers, total,
        )

        indexed_results: dict[int, list[dict]] = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(func, item): idx
                for idx, item in enumerate(items)
            }
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    indexed_results[idx] = future.result()
                except Exception:
                    if progress is not None:
                        progress.stop()
                    logger.exception(
                        "%s: worker failed for item index %d", desc, idx
                    )
                    raise
                if progress is not None:
                    progress.advance(0)

        if progress is not None:
            progress.stop()

        # Re-assemble in original order.
        for idx in range(total):
            all_rows.extend(indexed_results.get(idx, []))
        return all_rows

    def _create_progress(self, desc: str, total: int, workers: int):
        """Create a Rich progress display if available."""
        try:
            from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, MofNCompleteColumn
            from eemoclas.cli.utils import console

            progress = Progress(
                SpinnerColumn(),
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                console=console,
                transient=False,
            )
            task_id = progress.add_task(desc, total=total)
            progress.start()

            # Wrapper to allow advance via task_id
            class _ProgressWrapper:
                def __init__(self, progress, task_id):
                    self._progress = progress
                    self._task_id = task_id
                def advance(self, _=0):
                    self._progress.advance(self._task_id)
                def stop(self):
                    self._progress.stop()

            return _ProgressWrapper(progress, task_id)
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def save_sample(self, sample: dict, sample_id: str) -> str:
        """Save a sample dictionary as a ``.pt`` file.

        Parameters
        ----------
        sample : dict
            Arbitrary payload (tensors, strings, lists, etc.).
        sample_id : str
            Unique identifier used as the file name (without extension).

        Returns
        -------
        str
            Absolute path to the saved file.
        """
        path = self.samples_dir / f"{sample_id}.pt"
        torch.save(sample, str(path))
        return str(path)

    def write_manifest(self, rows: list[dict]) -> None:
        """Write a list of row-dicts as ``manifest.csv``.

        Parameters
        ----------
        rows : list[dict]
            Each dict represents one row in the manifest.
        """
        if not rows:
            # Write an empty CSV so downstream tools don't break.
            pd.DataFrame().to_csv(self.output_dir / "manifest.csv", index=False)
            return
        df = pd.DataFrame(rows)
        df.to_csv(self.output_dir / "manifest.csv", index=False)

    def write_stats(self, stats: dict) -> None:
        """Write ``stats.json`` to the output directory.

        Parameters
        ----------
        stats : dict
            Statistics dictionary (JSON-serialisable).
        """
        stats_path = self.output_dir / "stats.json"
        with open(stats_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

    def save_config_snapshot(self) -> None:
        """Save the current config as ``config_snapshot.yaml``."""
        snapshot_path = self.output_dir / "config_snapshot.yaml"
        with open(snapshot_path, "w", encoding="utf-8") as f:
            yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def validate_token_meta(self, x: torch.Tensor, token_meta: list[dict]) -> None:
        """Validate that ``token_meta`` length matches the spatial dimension of *x*.

        For shape ``[C_eff, T]`` or ``[8, C_eff, T]`` the expected length is
        ``C_eff`` (the second-to-last dimension).

        Parameters
        ----------
        x : torch.Tensor
            Data tensor.
        token_meta : list[dict]
            Per-token metadata.

        Raises
        ------
        ValueError
            If the lengths do not match.
        """
        expected = x.shape[-2]
        actual = len(token_meta)
        if actual != expected:
            raise ValueError(
                f"token_meta length {actual} != C_eff {expected}"
            )
