# /faq 命令说明

## 功能
FAQ 管理：列表、查看、搜索、删除。支持子命令和自动推断。

## 用法
- `/faq [ls|view|search|del] [参数]`

## 子命令

| 子命令 | 用法 | 权限 | 说明 |
|--------|------|------|------|
| ls | `/faq ls` | public | 列出当前群组所有 FAQ 条目 |
| view | `/faq view <ID>` | public | 查看指定 ID 的 FAQ 详细内容 |
| search | `/faq search <关键词>` | public | 按关键词搜索 FAQ |
| del | `/faq del <ID>` | admin | 删除指定 FAQ |

## 自动推断

无需显式写子命令，系统自动推断意图：
- 无参数 `/faq` → 列表（ls）
- 参数为 ID 格式（如 `20241205-001`）→ 查看（view）
- 参数为非 ID 格式（如 `登录`）→ 搜索（search）
- 显式子命令优先，不会被推断覆盖

## 示例
- `/faq` — 列出所有 FAQ
- `/faq 20241205-001` — 查看 ID 为 20241205-001 的 FAQ（自动推断为 view）
- `/faq 登录` — 搜索包含"登录"的 FAQ（自动推断为 search）
- `/faq del 20241205-001` — 删除指定 FAQ（需管理员）
- `/faq view 20241205-001` — 显式查看（等同推断结果）

## 说明
- 子命令权限在 `config.json` 的 `subcommands` 中声明（`del` 为 `admin`），分发层自动检查。
- 自动推断规则在 `config.json` 的 `inference` 中配置，分发层自动处理。
- 默认列表最多展示 20 条，搜索结果最多展示 10 条。
- 删除操作不可逆，请谨慎执行。
