from __future__ import annotations

import asyncio
import json
import logging
import re
import sys
import threading
import time
import types
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, cast

from Undefined.services.commands.context import CommandContext

logger = logging.getLogger(__name__)

CommandHandler = Callable[[list[str], CommandContext], Awaitable[None]]
CommandVisibilityChecker = Callable[[CommandContext], bool]
CommandSnapshot = tuple[int | None, int | None, int | None, int | None]

_COMMAND_CONFIG_FILENAME = "config.json"
_COMMAND_HANDLER_FILENAME = "handler.py"
_COMMAND_DOC_FILENAME = "README.md"
_COMMAND_POLICY_FILENAME = "policy.py"
_RELOAD_SCAN_INTERVAL_SECONDS = 0.2


@dataclass
class CommandRateLimit:
    """命令限流规则（单位：秒，0表示无限制）"""

    user: int = 10
    admin: int = 5
    superadmin: int = 0


@dataclass
class SubcommandInferenceRule:
    """子命令推断规则：正则匹配 args[0] 推断为指定子命令。"""

    pattern: re.Pattern[str]
    subcommand: str


@dataclass
class SubcommandInference:
    """子命令自动推断配置。"""

    default: str | None = None
    rules: list[SubcommandInferenceRule] = field(default_factory=list)
    fallback: str | None = None


@dataclass
class SubcommandMeta:
    """子命令元信息。"""

    name: str
    description: str
    permission: str
    allow_in_private: bool
    rate_limit: CommandRateLimit
    args: str = ""


@dataclass
class CommandMeta:
    """命令元信息。"""

    name: str
    description: str
    usage: str
    example: str
    permission: str
    rate_limit: CommandRateLimit
    show_in_help: bool
    order: int
    aliases: list[str]
    allow_in_private: bool
    help_footer: list[str]
    handler_path: Path
    doc_path: Path | None
    module_name: str
    visibility_path: Path | None
    visibility_module_name: str | None
    subcommands: dict[str, SubcommandMeta] = field(default_factory=dict)
    inference: SubcommandInference | None = None
    handler: CommandHandler | None = None
    visibility_checker: CommandVisibilityChecker | None = None


class CommandRegistry:
    """基于目录的命令注册表。"""

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self._commands: dict[str, CommandMeta] = {}
        self._aliases: dict[str, str] = {}
        self._lock = threading.RLock()
        self._last_snapshot: dict[str, CommandSnapshot] = {}
        self._last_scan_at = 0.0

    def load_commands(self) -> None:
        with self._lock:
            self._load_commands_locked()
            self._last_snapshot = self._build_snapshot()
            self._last_scan_at = time.monotonic()

    def maybe_reload(self) -> bool:
        now = time.monotonic()
        with self._lock:
            if now - self._last_scan_at < _RELOAD_SCAN_INTERVAL_SECONDS:
                return False
            self._last_scan_at = now
            latest_snapshot = self._build_snapshot()
            if latest_snapshot == self._last_snapshot:
                return False
            logger.info("[CommandRegistry] 检测到命令目录变化，开始热重载")
            self._load_commands_locked()
            self._last_snapshot = self._build_snapshot()
            return True

    def _load_commands_locked(self) -> None:
        commands: dict[str, CommandMeta] = {}
        aliases: dict[str, str] = {}
        if not self.base_dir.exists():
            logger.warning("命令目录不存在: %s", self.base_dir)
            self._commands = commands
            self._aliases = aliases
            return

        logger.info("[CommandRegistry] 开始扫描命令目录: %s", self.base_dir)

        for command_dir in sorted(self.base_dir.iterdir()):
            if not command_dir.is_dir() or command_dir.name.startswith("_"):
                continue
            self._load_command_dir(command_dir, commands, aliases)

        self._commands = commands
        self._aliases = aliases

        command_names = sorted(commands.keys())
        logger.info(
            "[CommandRegistry] 已加载 %s 个命令: %s",
            len(command_names),
            ", ".join(command_names),
        )
        if aliases:
            alias_pairs = ", ".join(
                f"{alias}->{target}" for alias, target in sorted(aliases.items())
            )
            logger.info("[CommandRegistry] 别名映射: %s", alias_pairs)

    def _load_command_dir(
        self,
        command_dir: Path,
        commands: dict[str, CommandMeta],
        aliases: dict[str, str],
    ) -> None:
        config_path = command_dir / _COMMAND_CONFIG_FILENAME
        handler_path = command_dir / _COMMAND_HANDLER_FILENAME
        if not config_path.exists() or not handler_path.exists():
            logger.debug(
                "[CommandRegistry] 跳过目录(缺少 config.json 或 handler.py): %s",
                command_dir,
            )
            return

        try:
            config = self._read_config(config_path)
            name = str(config.get("name") or "").strip().lower()
            if not name:
                logger.warning("命令配置缺少 name: %s", config_path)
                return

            module_name = ".".join(
                [
                    "Undefined",
                    "skills",
                    "commands",
                    command_dir.name,
                    "handler",
                ]
            )

            parent_rate_limit = self._normalize_rate_limit(config.get("rate_limit"))
            parent_permission = self._normalize_permission(config.get("permission"))
            parent_allow_private = bool(config.get("allow_in_private", False))

            meta = CommandMeta(
                name=name,
                description=str(config.get("description") or "").strip(),
                usage=str(config.get("usage") or f"/{name}").strip(),
                example=str(config.get("example") or "").strip(),
                permission=parent_permission,
                rate_limit=parent_rate_limit,
                show_in_help=bool(config.get("show_in_help", True)),
                order=int(config.get("order", 999)),
                aliases=self._normalize_aliases(config.get("aliases")),
                allow_in_private=parent_allow_private,
                help_footer=self._normalize_help_footer(config.get("help_footer")),
                handler_path=handler_path,
                doc_path=(command_dir / _COMMAND_DOC_FILENAME)
                if (command_dir / _COMMAND_DOC_FILENAME).exists()
                else None,
                module_name=module_name,
                visibility_path=(command_dir / _COMMAND_POLICY_FILENAME)
                if (command_dir / _COMMAND_POLICY_FILENAME).exists()
                else None,
                visibility_module_name=".".join(
                    [
                        "Undefined",
                        "skills",
                        "commands",
                        command_dir.name,
                        "policy",
                    ]
                )
                if (command_dir / _COMMAND_POLICY_FILENAME).exists()
                else None,
                subcommands=self._normalize_subcommands(
                    config.get("subcommands"),
                    parent_permission,
                    parent_allow_private,
                    parent_rate_limit,
                ),
                inference=self._normalize_inference(config.get("inference")),
            )
            if name in commands:
                logger.warning(
                    "[CommandRegistry] 命令名重复，后者覆盖前者: name=%s dir=%s",
                    name,
                    command_dir,
                )
            commands[name] = meta
            subcmd_info = (
                f" subcommands={len(meta.subcommands)}" if meta.subcommands else ""
            )
            logger.info(
                "[CommandRegistry] 已注册命令: /%s permission=%s rate_limit=%s private=%s aliases=%s%s",
                meta.name,
                meta.permission,
                f"U:{meta.rate_limit.user}s/A:{meta.rate_limit.admin}s/S:{meta.rate_limit.superadmin}s",
                meta.allow_in_private,
                meta.aliases or "[]",
                subcmd_info,
            )
            for alias in meta.aliases:
                existing = aliases.get(alias)
                if existing is not None and existing != name:
                    logger.warning(
                        "[CommandRegistry] 别名冲突，保留首个映射: alias=%s current=%s ignored=%s",
                        alias,
                        existing,
                        name,
                    )
                    continue
                aliases[alias] = name
        except Exception as exc:
            logger.exception("加载命令目录失败: %s, err=%s", command_dir, exc)

    def _read_config(self, config_path: Path) -> dict[str, Any]:
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError(f"命令配置必须是 JSON 对象: {config_path}")
        return data

    def _normalize_permission(self, value: Any) -> str:
        text = str(value or "public").strip().lower()
        if text in {"public", "admin", "superadmin"}:
            return text
        return "public"

    def _normalize_rate_limit(self, value: Any) -> CommandRateLimit:
        if isinstance(value, dict):
            try:
                return CommandRateLimit(
                    user=int(value.get("user", 10)),
                    admin=int(value.get("admin", 5)),
                    superadmin=int(value.get("superadmin", 0)),
                )
            except (ValueError, TypeError):
                logger.warning(
                    "[CommandRegistry] 命令限流配置解析失败，使用默认值: %s", value
                )
                return CommandRateLimit()

        text = str(value or "default").strip().lower()
        if text == "none":
            return CommandRateLimit(user=0, admin=0, superadmin=0)
        elif text == "stats":
            return CommandRateLimit(user=3600, admin=0, superadmin=0)
        return CommandRateLimit()

    def _merge_rate_limit(
        self, value: Any, parent_rate_limit: CommandRateLimit
    ) -> CommandRateLimit:
        if not isinstance(value, dict):
            return parent_rate_limit
        try:
            return CommandRateLimit(
                user=int(value.get("user", parent_rate_limit.user)),
                admin=int(value.get("admin", parent_rate_limit.admin)),
                superadmin=int(value.get("superadmin", parent_rate_limit.superadmin)),
            )
        except (ValueError, TypeError):
            logger.warning(
                "[CommandRegistry] 子命令限流配置解析失败，继承父命令: %s",
                value,
            )
            return parent_rate_limit

    def _normalize_aliases(self, value: Any) -> list[str]:
        if not isinstance(value, list):
            return []
        aliases: list[str] = []
        for item in value:
            alias = str(item).strip().lower()
            if alias:
                aliases.append(alias)
        return aliases

    def _normalize_help_footer(self, value: Any) -> list[str]:
        if not isinstance(value, list):
            return []
        footer: list[str] = []
        for item in value:
            line = str(item).strip()
            if line:
                footer.append(line)
        return footer

    def _normalize_subcommands(
        self,
        value: Any,
        parent_permission: str,
        parent_allow_private: bool,
        parent_rate_limit: CommandRateLimit,
    ) -> dict[str, SubcommandMeta]:
        if not isinstance(value, dict):
            return {}
        result: dict[str, SubcommandMeta] = {}
        for sub_name, sub_cfg in value.items():
            if not isinstance(sub_cfg, dict):
                logger.warning("[CommandRegistry] 子命令配置无效，跳过: %s", sub_name)
                continue
            name = str(sub_name).strip().lower()
            if not name:
                continue
            sub_permission = self._normalize_permission(
                sub_cfg.get("permission", parent_permission)
            )
            sub_allow_private = bool(
                sub_cfg.get("allow_in_private", parent_allow_private)
            )
            sub_rate_limit = self._merge_rate_limit(
                sub_cfg.get("rate_limit"), parent_rate_limit
            )
            result[name] = SubcommandMeta(
                name=name,
                description=str(sub_cfg.get("description") or "").strip(),
                permission=sub_permission,
                allow_in_private=sub_allow_private,
                rate_limit=sub_rate_limit,
                args=str(sub_cfg.get("args") or "").strip(),
            )
        return result

    def _normalize_inference(self, value: Any) -> SubcommandInference | None:
        if not isinstance(value, dict):
            return None
        default = None
        if "default" in value:
            default = str(value["default"]).strip().lower() or None
        rules: list[SubcommandInferenceRule] = []
        raw_rules = value.get("rules")
        if isinstance(raw_rules, list):
            for rule_cfg in raw_rules:
                if not isinstance(rule_cfg, dict):
                    continue
                pattern_str = str(rule_cfg.get("pattern") or "").strip()
                subcmd = str(rule_cfg.get("subcommand") or "").strip().lower()
                if pattern_str and subcmd:
                    try:
                        compiled = re.compile(pattern_str)
                        rules.append(
                            SubcommandInferenceRule(pattern=compiled, subcommand=subcmd)
                        )
                    except re.error:
                        logger.warning(
                            "[CommandRegistry] 推断规则正则编译失败: %s",
                            pattern_str,
                        )
        fallback = None
        if "fallback" in value:
            fallback = str(value["fallback"]).strip().lower() or None
        if default is None and not rules and fallback is None:
            return None
        return SubcommandInference(default=default, rules=rules, fallback=fallback)

    def resolve_subcommand(
        self, meta: CommandMeta, args: list[str]
    ) -> tuple[str | None, list[str], SubcommandMeta | None]:
        """解析/推断子命令，返回 (subcmd_name, rewritten_args, subcmd_meta)。

        rewritten_args 为 [subcmd, *sub_args]，handler 统一按此格式分发。
        若无法推断则 subcmd_name=None, subcmd_meta=None, args 不变。
        """
        if not meta.subcommands:
            return None, args, None

        # 1. args[0] 显式匹配子命令名
        if args:
            first = args[0].strip().lower()
            if first in meta.subcommands:
                return first, args, meta.subcommands[first]

        # 2. 推断流程
        inference = meta.inference
        if inference is None:
            return None, args, None

        # 2a. 无参数 + default
        if not args and inference.default is not None:
            subcmd_name = inference.default
            if subcmd_name in meta.subcommands:
                return subcmd_name, [subcmd_name], meta.subcommands[subcmd_name]

        # 2b. rules 匹配 args[0]
        if args and inference.rules:
            for rule in inference.rules:
                if rule.pattern.fullmatch(args[0]):
                    subcmd_name = rule.subcommand
                    if subcmd_name in meta.subcommands:
                        return (
                            subcmd_name,
                            [subcmd_name, *args],
                            meta.subcommands[subcmd_name],
                        )

        # 2c. fallback
        if args and inference.fallback is not None:
            subcmd_name = inference.fallback
            if subcmd_name in meta.subcommands:
                return subcmd_name, [subcmd_name, *args], meta.subcommands[subcmd_name]

        return None, args, None

    def _build_snapshot(self) -> dict[str, CommandSnapshot]:
        if not self.base_dir.exists():
            return {}
        snapshot: dict[str, CommandSnapshot] = {}
        for command_dir in sorted(self.base_dir.iterdir()):
            if not command_dir.is_dir() or command_dir.name.startswith("_"):
                continue
            snapshot[command_dir.name] = (
                self._read_mtime_ns(command_dir / _COMMAND_CONFIG_FILENAME),
                self._read_mtime_ns(command_dir / _COMMAND_HANDLER_FILENAME),
                self._read_mtime_ns(command_dir / _COMMAND_DOC_FILENAME),
                self._read_mtime_ns(command_dir / _COMMAND_POLICY_FILENAME),
            )
        return snapshot

    def _read_mtime_ns(self, path: Path) -> int | None:
        try:
            stat_result = path.stat()
        except FileNotFoundError:
            return None
        return stat_result.st_mtime_ns

    def resolve(self, command_name: str) -> CommandMeta | None:
        self.maybe_reload()
        normalized = command_name.strip().lower()
        with self._lock:
            canonical = self._aliases.get(normalized, normalized)
            if canonical != normalized:
                logger.info(
                    "[CommandRegistry] 命令别名解析: /%s -> /%s",
                    normalized,
                    canonical,
                )
            return self._commands.get(canonical)

    def list_commands(self, *, include_hidden: bool = False) -> list[CommandMeta]:
        self.maybe_reload()
        with self._lock:
            items = list(self._commands.values())
            if not include_hidden:
                items = [item for item in items if item.show_in_help]
            return sorted(items, key=lambda item: (item.order, item.name))

    def is_visible(self, command: CommandMeta, context: CommandContext) -> bool:
        self.maybe_reload()
        with self._lock:
            checker = command.visibility_checker
            if (
                checker is None
                and command.visibility_path is not None
                and command.visibility_module_name is not None
            ):
                checker = self._load_visibility_checker(command)
                command.visibility_checker = checker
        if checker is None:
            return True
        try:
            return bool(checker(context))
        except Exception:
            logger.exception(
                "[CommandRegistry] 命令可见性检查失败，已隐藏: /%s",
                command.name,
            )
            return False

    async def execute(
        self,
        command: CommandMeta,
        args: list[str],
        context: CommandContext,
    ) -> None:
        start_time = time.perf_counter()
        logger.info(
            "[CommandRegistry] 开始执行命令: /%s group=%s sender=%s args_count=%s",
            command.name,
            context.group_id,
            context.sender_id,
            len(args),
        )
        logger.debug("[CommandRegistry] 命令参数 /%s: %s", command.name, args)
        with self._lock:
            if command.handler is None:
                command.handler = self._load_handler(command)
            handler = command.handler
        if handler is None:
            raise RuntimeError(f"命令处理器加载失败: /{command.name}")
        try:
            await handler(args, context)
            duration = time.perf_counter() - start_time
            logger.info(
                "[CommandRegistry] 命令执行成功: /%s duration=%.3fs",
                command.name,
                duration,
            )
        except Exception:
            duration = time.perf_counter() - start_time
            logger.exception(
                "[CommandRegistry] 命令执行失败: /%s duration=%.3fs",
                command.name,
                duration,
            )
            raise

    def _load_handler(self, command: CommandMeta) -> CommandHandler:
        module = self._load_module(command.module_name, command.handler_path)
        execute = getattr(module, "execute", None)
        if execute is None:
            raise RuntimeError(f"命令处理器缺少 execute: {command.handler_path}")
        if not callable(execute):
            raise RuntimeError(f"命令处理器 execute 不可调用: {command.handler_path}")
        if not asyncio.iscoroutinefunction(execute):
            raise RuntimeError(
                f"命令处理器 execute 必须是 async: {command.handler_path}"
            )
        logger.info(
            "[CommandRegistry] 命令处理器已加载: /%s module=%s",
            command.name,
            command.module_name,
        )
        return cast(CommandHandler, execute)

    def _load_visibility_checker(
        self, command: CommandMeta
    ) -> CommandVisibilityChecker | None:
        assert command.visibility_path is not None
        assert command.visibility_module_name is not None
        module = self._load_module(
            command.visibility_module_name, command.visibility_path
        )
        checker = getattr(module, "is_command_visible", None)
        if checker is None:
            logger.debug(
                "[CommandRegistry] 可见性模块未声明 is_command_visible: /%s",
                command.name,
            )
            return None
        if not callable(checker):
            raise RuntimeError(f"命令可见性函数不可调用: {command.visibility_path}")
        if asyncio.iscoroutinefunction(checker):
            raise RuntimeError(f"命令可见性函数不能是 async: {command.visibility_path}")
        logger.info(
            "[CommandRegistry] 命令可见性策略已加载: /%s module=%s",
            command.name,
            command.visibility_module_name,
        )
        return cast(CommandVisibilityChecker, checker)

    def _load_module(self, module_name: str, path: Path) -> types.ModuleType:
        sys.modules.pop(module_name, None)
        module = types.ModuleType(module_name)
        module.__file__ = str(path)
        module.__package__ = module_name.rpartition(".")[0]
        source = path.read_text(encoding="utf-8")
        code = compile(source, str(path), "exec")
        sys.modules[module_name] = module
        try:
            exec(code, module.__dict__)
        except Exception:
            sys.modules.pop(module_name, None)
            raise
        return module
