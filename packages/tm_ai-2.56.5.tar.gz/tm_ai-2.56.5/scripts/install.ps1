$ErrorActionPreference = "Continue"

$PackageName  = "tm-ai[all]"
$PyPIName     = "tm-ai"
$UvInstallUrl = "https://astral.sh/uv/install.ps1"

# Fetch latest version from PyPI for display
$LatestVersion = ""
try {
    $LatestVersion = (Invoke-RestMethod "https://pypi.org/pypi/tm-ai/json").info.version
} catch {}
$CvcVersionStr = if ($LatestVersion) { " v$LatestVersion" } else { "" }

# CVC branded colours (24-bit truecolor)
$ESC        = [char]27
$CVC_RED    = "$ESC[38;2;204;51;51m"
$CVC_BRIGHT = "$ESC[38;2;255;68;68m"
$CVC_DIM    = "$ESC[38;2;139;112;112m"
$CVC_GREEN  = "$ESC[38;2;80;200;120m"
$BOLD       = "$ESC[1m"
$RESET      = "$ESC[0m"

function Write-CvcInfo ($msg) { Write-Host "  ${CVC_DIM}$msg${RESET}" }
function Write-CvcOk   ($msg) { Write-Host "  ${CVC_GREEN}${BOLD}[OK]${RESET} $msg" }
function Write-CvcWarn ($msg) { Write-Host "  ${CVC_DIM}[!] $msg${RESET}" }

Write-Host "$CVC_RED$BOLD* Installing ${CVC_BRIGHT}CVC${CVC_RED}...$RESET"

# Require Python
$Script:pyExe = Get-Command python -ErrorAction SilentlyContinue
if (-not $Script:pyExe) { $Script:pyExe = Get-Command python3 -ErrorAction SilentlyContinue }
if (-not $Script:pyExe) {
    Write-Host "${CVC_DIM}Python 3.10+ is required. Please install it first.$RESET"
    exit 1
}

# Ensure uv is available
$Script:uvIsModule = $false
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-CvcInfo "Installing uv package manager..."
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13
        Set-ExecutionPolicy Bypass -Scope Process -Force
        Invoke-Expression (Invoke-RestMethod -Uri $UvInstallUrl) | Out-Null
        $env:PATH = [System.Environment]::GetEnvironmentVariable("Path","User") + ";" + [System.Environment]::GetEnvironmentVariable("Path","Machine")
    } catch {}
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        & $Script:pyExe -m pip install --user uv 2>&1 | Out-Null
        $Script:uvIsModule = $true
    }
}

function Invoke-Uv { param([Parameter(ValueFromRemainingArguments)]$a)
    if ($Script:uvIsModule) { & $Script:pyExe -m uv @a }
    else                    { uv @a }
}

# Step 1: purge every old tm-ai / cvc installation (silent)

# Determine the uv tool bin directory UP FRONT
$uvToolBinEarly = $null
try { $uvToolBinEarly = (Invoke-Uv tool dir --bin 2>&1).Trim() } catch {}
if (-not $uvToolBinEarly -or -not (Test-Path $uvToolBinEarly)) {
    $uvToolBinEarly = Join-Path $env:USERPROFILE ".local\bin"
}
$uvToolBinEarly = $uvToolBinEarly.TrimEnd("\").TrimEnd("/")

function Test-UvOwned ($path) {
    $norm = $path.TrimEnd("\").TrimEnd("/")
    return $norm.StartsWith($uvToolBinEarly, [System.StringComparison]::OrdinalIgnoreCase)
}

# 1a. Find every Python interpreter on PATH and uninstall tm-ai
$seenPythons = @{}
$pathDirs = $env:PATH -split ";" | Where-Object { $_ -and (Test-Path $_ -ErrorAction SilentlyContinue) }
foreach ($dir in $pathDirs) {
    foreach ($exe in @("python.exe","python3.exe","python311.exe","python312.exe","python313.exe")) {
        $full = Join-Path $dir $exe
        if ((Test-Path $full) -and -not $seenPythons.ContainsKey($full)) {
            $seenPythons[$full] = $true
            try {
                $pkg = & $full -m pip show tm-ai 2>&1 | Select-String "^Name"
                if ($pkg) {
                    & $full -m pip uninstall tm-ai -y 2>&1 | Out-Null
                }
            } catch {}
        }
    }
}

# 1b. Uninstall from conda base env if present
$condaExe = Get-Command conda -ErrorAction SilentlyContinue
if ($condaExe) {
    try {
        & conda run -n base pip uninstall tm-ai -y 2>&1 | Out-Null
    } catch {}
    try { & conda remove -n base tm-ai -y 2>&1 | Out-Null } catch {}
}

# 1c. Remove stale cvc shims from PATH dirs
foreach ($dir in $pathDirs) {
    foreach ($stale in @("cvc.exe","cvc","cvc-script.py","cvc.cmd")) {
        $stalePath = Join-Path $dir $stale
        if (Test-Path $stalePath) {
            if (-not (Test-UvOwned $stalePath)) {
                try {
                    Remove-Item $stalePath -Force -ErrorAction SilentlyContinue
                } catch {}
            }
        }
    }
}

# 1c-extra. Explicitly scan conda/miniconda/anaconda Script dirs
$condaRoots = @(
    "$env:USERPROFILE\miniconda3",
    "$env:USERPROFILE\anaconda3",
    "$env:USERPROFILE\AppData\Local\miniconda3",
    "$env:USERPROFILE\AppData\Local\anaconda3",
    "$env:ProgramData\miniconda3",
    "$env:ProgramData\anaconda3",
    "C:\ProgramData\miniconda3",
    "C:\ProgramData\anaconda3"
)
if ($env:CONDA_PREFIX) { $condaRoots += $env:CONDA_PREFIX }
foreach ($root in $condaRoots) {
    if (-not (Test-Path $root)) { continue }
    foreach ($subDir in @("Scripts","bin","envs\base\Scripts")) {
        foreach ($stale in @("cvc.exe","cvc","cvc-script.py","cvc.cmd")) {
            $stalePath = Join-Path (Join-Path $root $subDir) $stale
            if ((Test-Path $stalePath) -and (-not (Test-UvOwned $stalePath))) {
                try {
                    Remove-Item $stalePath -Force -ErrorAction SilentlyContinue
                } catch {}
            }
        }
    }
}

# 1c-extra2. Find ALL cvc executables and kill non-uv ones
try {
    Get-Command cvc -All -ErrorAction SilentlyContinue | ForEach-Object {
        $src = $_.Source
        if ($src -and (-not (Test-UvOwned $src)) -and (Test-Path $src)) {
            try {
                Remove-Item $src -Force -ErrorAction SilentlyContinue
            } catch {}
        }
    }
} catch {}

# 1d. Remove existing uv tool entry (force clean reinstall)
$toolList = Invoke-Uv tool list 2>&1
if ($toolList -match "(^|\s)$PyPIName(\s|@|$)") {
    Invoke-Uv tool uninstall $PyPIName 2>&1 | Out-Null
}

# Step 2: fresh install via uv tool
# Try to move the currently-running cvc.exe so uv can write the new one
$cvcTarget = Join-Path $uvToolBinEarly "cvc.exe"
$cvcOld    = Join-Path $uvToolBinEarly "cvc.exe.old"
if (Test-Path $cvcTarget) {
    try {
        if (Test-Path $cvcOld) { Remove-Item $cvcOld -Force -ErrorAction SilentlyContinue }
        [System.IO.File]::Move($cvcTarget, $cvcOld)
    } catch {}
}
$installOut = Invoke-Uv tool install --force --refresh $PackageName 2>&1
$uvExitCode = $LASTEXITCODE
# The "Failed to install entrypoint" error is non-fatal: uv updated the venv
# (all packages installed) but couldn't overwrite the running cvc.exe shim.
# The existing shim still works because it delegates to the updated venv.
$entrypointFail = $false
if ($uvExitCode -ne 0 -and $null -ne $uvExitCode) {
    $outStr = ($installOut | Out-String)
    if ($outStr -match "Failed to install entrypoint") {
        $entrypointFail = $true
    } else {
        Write-Host ""
        Write-Host "$CVC_RED${BOLD}Installation failed. uv output:$RESET"
        Write-Host $installOut
        exit 1
    }
}
# Clean up the renamed old exe
if (Test-Path $cvcOld) {
    try { Remove-Item $cvcOld -Force -ErrorAction SilentlyContinue } catch {}
}
# If the entrypoint copy failed, try to do it ourselves now
if ($entrypointFail) {
    $srcExe = Join-Path (Join-Path $env:APPDATA "uv\tools\tm-ai\Scripts") "cvc.exe"
    if (Test-Path $srcExe) {
        try { Copy-Item $srcExe $cvcTarget -Force -ErrorAction SilentlyContinue } catch {}
    }
}

# Step 3: force uv tool bin to the FRONT of User PATH
$uvToolBin = $uvToolBinEarly
if (-not (Test-Path $uvToolBin)) {
    New-Item -ItemType Directory -Path $uvToolBin -Force | Out-Null
}

$userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
if (-not $userPath) { $userPath = "" }
$pathParts = $userPath -split ";" | Where-Object { $_ -and $_ -ne $uvToolBin }
$newUserPath = ($uvToolBin + ";" + ($pathParts -join ";")).TrimEnd(";")
[System.Environment]::SetEnvironmentVariable("Path", $newUserPath, "User")

$env:PATH = $uvToolBin + ";" + (($env:PATH -split ";" | Where-Object { $_ -and $_ -ne $uvToolBin }) -join ";")

try { Invoke-Uv tool update-shell 2>&1 | Out-Null } catch {}

# Step 4: verify the installed version matches PyPI
$installedVersion = ""
$cvcExe = Get-Command cvc -ErrorAction SilentlyContinue
if ($cvcExe) {
    try {
        $verLine = & cvc --version 2>&1 | Select-Object -First 1
        $installedVersion = ($verLine -replace '[^0-9.]','').Trim('.')
    } catch {}
}

Write-Host ""
$vStr = if ($installedVersion) { " v$installedVersion" } else { "" }
Write-Host "$CVC_RED$BOLD* ${CVC_BRIGHT}CVC${vStr}${CVC_RED} installed successfully.$RESET"
Write-Host ""
Write-Host "${CVC_DIM}Run ${RESET}${CVC_BRIGHT}${BOLD}cvc${RESET}${CVC_DIM} to start.${RESET}"
Write-Host ""
