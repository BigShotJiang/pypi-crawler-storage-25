# Releasing CVC — PyPI, npm, VS Code

Three independent release pipelines, each triggered by a Git tag.
All pipelines: verify version, build, lint (warn-only), publish, create GitHub Release.

---

## 1. tm-ai → PyPI   (tag: `pypi-v*`)

**Pre-flight:**
1. Edit `pyproject.toml` — bump `version = "X.Y.Z"`
2. Update `docs/CHANGELOG.md`
3. Commit: `git commit -am "chore: bump tm-ai to X.Y.Z"`

**Release:**
```bash
git tag pypi-vX.Y.Z
git push origin main pypi-vX.Y.Z
```

**Secrets required (one-time setup):**
- Preferred: configure OIDC Trusted Publishing on PyPI  
  https://pypi.org/manage/project/tm-ai/settings/publishing/  
  Publisher: `github.com/mannuking/cvc`, workflow: `publish-pypi.yml`
- Fallback: add `PYPI_TOKEN` to GitHub repo secrets and uncomment the token block in the workflow

**Result:** published to https://pypi.org/project/tm-ai/ + GitHub Release

---

## 2. @cvc/cli → npm   (tag: `npm-v*`)

**Pre-flight:**
1. Edit `cvc-node/package.json` — bump `"version": "X.Y.Z"`
2. Update `docs/CHANGELOG.md`
3. Commit: `git commit -am "chore: bump @cvc/cli to X.Y.Z"`

**Release:**
```bash
git tag npm-vX.Y.Z
git push origin main npm-vX.Y.Z
```

**Secrets required (one-time setup):**
- Create an npm Automation token at https://www.npmjs.com/settings/<user>/tokens
- Add it to GitHub repo secrets as `NPM_TOKEN`

**Result:** published to https://www.npmjs.com/package/@cvc/cli + GitHub Release

---

## 3. VS Code Extension   (tag: `vscode-v*`)

**Pre-flight:**
1. Edit `vscode-extension/package.json` — bump version
2. Commit and push

**Release:**
```bash
git tag vscode-vX.Y.Z
git push origin main vscode-vX.Y.Z
```

**Secrets required:** `VSCE_PAT` (already configured)

---

## Version parity note

`pyproject.toml` (currently `2.5.12`) and `cvc-node/package.json` (currently `2.1.1`) are on different version tracks — they can be released independently.

## Hardening checklist (future)

- [ ] Change `|| true` to exit-1 in lint/test steps once test coverage is stable
- [ ] Add branch protection rule: only main can trigger publish tags
- [ ] Pin action versions (e.g. `actions/checkout@v4.1.2`) for supply-chain safety
