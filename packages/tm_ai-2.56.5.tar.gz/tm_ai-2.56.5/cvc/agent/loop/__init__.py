"""CVC agentic loop primitives — Phase 1, Category 2.

Each module is a focused concern; nothing is wired into ``cvc/agent/llm.py``
or ``cvc/agent/chat.py`` yet. Integration happens in Category 3.
"""
from .budget import IterationBudget
from .compression import CompressionConfig, CompressionResult, ContextCompressor
from .errors import (
    Classification,
    FailoverReason,
    RecoveryAction,
    classify_http,
    jittered_backoff,
)
from .guardrails import (
    DestructiveCheck,
    GuardrailVerdict,
    ToolCallGuardrailController,
    ToolGuardrailDecision,
    is_destructive,
)
from .multimodal import (
    cache_image_block,
    is_multimodal_tool_result,
    multimodal_text_summary,
)
from .output_limits import DEFAULT_LIMITS, TruncationResult, get_limit, truncate_output
from .parallel import ToolCall, ToolResult, execute_parallel, partition_calls
from .platform import (
    PLATFORM_PROMPT_FRAGMENTS,
    detect_platform_from_session,
    install_safe_stdio,
    platform_prompt,
)
from .request_options import (
    StreamingCallbacks,
    apply_prefill,
    merge_request_overrides,
    normalize_service_tier,
    validate_prefill,
)
from .sanitize import (
    ThinkScrubber,
    redact_dict,
    redact_text,
    repair_tool_call_arguments,
    sanitize_messages,
    sanitize_surrogates,
    scrub_think_blocks,
    strip_non_ascii,
)
from .trajectory import TrajectoryRecorder, TurnRecord

__all__ = [
    "IterationBudget",
    "CompressionConfig", "CompressionResult", "ContextCompressor",
    "Classification", "FailoverReason", "RecoveryAction",
    "classify_http", "jittered_backoff",
    "DestructiveCheck", "GuardrailVerdict",
    "ToolCallGuardrailController", "ToolGuardrailDecision", "is_destructive",
    "cache_image_block", "is_multimodal_tool_result", "multimodal_text_summary",
    "DEFAULT_LIMITS", "TruncationResult", "get_limit", "truncate_output",
    "ToolCall", "ToolResult", "execute_parallel", "partition_calls",
    "PLATFORM_PROMPT_FRAGMENTS", "detect_platform_from_session",
    "install_safe_stdio", "platform_prompt",
    "StreamingCallbacks", "apply_prefill", "merge_request_overrides",
    "normalize_service_tier", "validate_prefill",
    "ThinkScrubber", "redact_dict", "redact_text", "repair_tool_call_arguments",
    "sanitize_messages", "sanitize_surrogates", "scrub_think_blocks", "strip_non_ascii",
    "TrajectoryRecorder", "TurnRecord",
]
