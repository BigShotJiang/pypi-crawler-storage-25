"""Skills catalog API.

Returns the list of skill ids that personas can attach. Source order:

1. Built-in CVC tool ids (always present).
2. Skill directories under ``~/.cvc/skills/<name>/`` (flat layout).
3. Skill directories under ``~/.hermes/skills/<category>/<name>/`` (nested
   Hermes layout — 100+ skills shipped by default).

The frontend persona-create form uses this to render a skill multi-select
without hardcoding the catalog client-side.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import FastAPI

logger = logging.getLogger(__name__)

_CVC_SKILLS_DIR = Path.home() / ".cvc" / "skills"
_HERMES_SKILLS_DIR = Path.home() / ".hermes" / "skills"

# Canonical CVC tool ids — must stay in sync with cvc/agent/executor.py
_BUILTIN_SKILLS: List[Dict[str, str]] = [
    {"id": "read_file", "kind": "tool", "category": "core", "description": "Read a text file with line numbers."},
    {"id": "search_files", "kind": "tool", "category": "core", "description": "Search file contents or find files by name."},
    {"id": "patch", "kind": "tool", "category": "core", "description": "Targeted find-and-replace edits in files."},
    {"id": "write_file", "kind": "tool", "category": "core", "description": "Write content to a file (overwrite)."},
    {"id": "terminal", "kind": "tool", "category": "core", "description": "Execute shell commands."},
    {"id": "cvc_commit", "kind": "tool", "category": "cvc", "description": "Create a cognitive commit."},
    {"id": "cvc_recall", "kind": "tool", "category": "cvc", "description": "Semantic search across CVC commits."},
    {"id": "cvc_status", "kind": "tool", "category": "cvc", "description": "Show CVC workspace status."},
    {"id": "cvc_log", "kind": "tool", "category": "cvc", "description": "List recent commits on active branch."},
    {"id": "cvc_smart_search", "kind": "tool", "category": "cvc", "description": "Smart hybrid search across commits."},
]


def _parse_skill_md(skill_md: Path) -> Tuple[str, Optional[str]]:
    """Extract (description, name) from SKILL.md YAML-ish frontmatter.

    We do a tolerant parse — no PyYAML dep. Reads only the first 4 KB.
    """
    description = ""
    name: Optional[str] = None
    try:
        head = skill_md.read_text(encoding="utf-8", errors="ignore")[:4096]
        in_fm = False
        for raw in head.splitlines():
            s = raw.strip()
            if s == "---":
                if not in_fm:
                    in_fm = True
                    continue
                break
            if not in_fm:
                # Some skills omit fenced frontmatter — keep scanning top-of-file.
                pass
            if s.lower().startswith("description:") and not description:
                description = s.split(":", 1)[1].strip().strip("\"'")
            elif s.lower().startswith("name:") and not name:
                name = s.split(":", 1)[1].strip().strip("\"'")
    except Exception:  # noqa: BLE001
        pass
    return description, name


def _enumerate_dir(root: Path, *, nested: bool) -> List[Dict[str, str]]:
    """Walk a skills root.

    nested=False — flat layout: ``<root>/<skill>/SKILL.md``.
    nested=True  — Hermes layout: ``<root>/<category>/<skill>/SKILL.md``
                  (with optional sub-grouping a level deeper).
    """
    out: List[Dict[str, str]] = []
    if not root.exists():
        return out
    try:
        if not nested:
            for child in sorted(root.iterdir()):
                if not child.is_dir():
                    continue
                skill_md = child / "SKILL.md"
                if not skill_md.exists():
                    continue
                desc, _ = _parse_skill_md(skill_md)
                out.append({
                    "id": child.name,
                    "kind": "skill",
                    "category": "user",
                    "description": desc,
                })
            return out

        # Nested Hermes layout.
        for category_dir in sorted(root.iterdir()):
            if not category_dir.is_dir():
                continue
            cat = category_dir.name
            # Direct children of category may either be skill dirs OR sub-groups.
            for entry in sorted(category_dir.rglob("SKILL.md")):
                try:
                    skill_dir = entry.parent
                    # Use folder name as id; namespace if it would collide.
                    skill_id = skill_dir.name
                    desc, _ = _parse_skill_md(entry)
                    # Build a human-friendly category breadcrumb relative to root.
                    rel_parts = skill_dir.relative_to(root).parts
                    if len(rel_parts) > 1:
                        category_label = "/".join(rel_parts[:-1])
                    else:
                        category_label = cat
                    out.append({
                        "id": skill_id,
                        "kind": "skill",
                        "category": category_label,
                        "description": desc,
                    })
                except Exception:  # noqa: BLE001
                    continue
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed enumerating skills in %s: %s", root, exc)
    return out


def register_skills_routes(app: FastAPI) -> None:
    """Mount /api/skills route."""

    @app.get("/api/skills")
    async def list_skills() -> Dict[str, Any]:
        builtins = list(_BUILTIN_SKILLS)
        cvc_user = _enumerate_dir(_CVC_SKILLS_DIR, nested=False)
        hermes = _enumerate_dir(_HERMES_SKILLS_DIR, nested=True)

        # Dedupe by id (builtins win, then cvc-user, then hermes).
        seen: set = set()
        merged: List[Dict[str, str]] = []
        for src in (builtins, cvc_user, hermes):
            for s in src:
                if s["id"] in seen:
                    continue
                seen.add(s["id"])
                merged.append(s)
        return {
            "skills": merged,
            "count": len(merged),
            "builtin_count": len(builtins),
            "user_count": len(cvc_user),
            "hermes_count": len(hermes),
        }
