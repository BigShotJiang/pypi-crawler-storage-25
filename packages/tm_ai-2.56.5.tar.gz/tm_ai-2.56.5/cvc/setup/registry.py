"""cvc.setup.registry — Provider spec registry for the setup wizard.

Combines:
  • cvc/providers/base.py ProviderProfile registry (transport / auth / api_mode)
  • Wizard-facing metadata (display name, hue, description, hint, recommended flag)
  • cvc/adapters factory support (whether create_adapter() can build it)

Adding a new provider:
  1. Register a ProviderProfile in cvc/providers/base.py:_bootstrap_defaults()
  2. Add a create_adapter() branch in cvc/adapters/__init__.py
  3. Add an entry to PROVIDER_SPECS below
  ⇒ wizard, dashboard, and `cvc doctor` pick it up automatically.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

from cvc.providers.base import all_profiles, ProviderProfile


@dataclass(frozen=True)
class ProviderSpec:
    """User-facing provider metadata for the setup wizard."""

    key: str                    # canonical name, must match ProviderProfile.name
    display_name: str           # human label shown in menu
    description: str            # one-line summary
    color: str                  # rich color or hex (e.g. "#55AA55", "magenta")
    hint: str = ""              # optional secondary hint shown under description
    recommended: bool = False   # marks the wizard's primary recommendation
    free_tier: bool = False     # true if zero marginal cost (Copilot sub, NVIDIA NIM, local)
    local: bool = False         # true if runs entirely on user's machine
    requires_oauth: bool = False
    default_model: str = ""     # falls back to ProviderProfile.fallback_models[0]

    def env_keys(self) -> list[str]:
        prof = _profile_for(self.key)
        return list(prof.env_vars) if prof else []

    def base_url(self) -> str:
        prof = _profile_for(self.key)
        return prof.base_url if prof else ""

    def auth_type(self) -> str:
        prof = _profile_for(self.key)
        return prof.auth_type if prof else ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["env_keys"] = self.env_keys()
        d["base_url"] = self.base_url()
        d["auth_type"] = self.auth_type()
        return d


# ---------------------------------------------------------------------------
# Wizard-facing metadata.  ORDER = order shown in the menu.
# ---------------------------------------------------------------------------
# Recommended progression for new users:
#   1. passthrough  — zero-config capture for Claude Code / Cursor users
#   2. github       — GitHub Copilot subscription, browser OAuth, no API key
#   3. anthropic    — first-party Claude
#   4. nvidia       — free-tier Nemotron 3 Super 120B (NEW: previously hidden!)
#   5. google       — first-party Gemini
#   6. openai       — first-party GPT-5.x
#   7. vertex       — enterprise Gemini via gcloud ADC
#   8. ollama       — fully local
#   9. lmstudio     — fully local with LM Studio UI
# ---------------------------------------------------------------------------

PROVIDER_SPECS: tuple[ProviderSpec, ...] = (
    ProviderSpec(
        key="passthrough",
        display_name="Passthrough",
        description="No API key — CVC captures context; your tool uses its own auth",
        hint="Best for Claude Code / Cursor / Aider users who want CVC as middleware",
        color="#55AA55",
        recommended=True,
        free_tier=True,
    ),
    ProviderSpec(
        key="github",
        display_name="GitHub Copilot",
        description="Browser OAuth — Sonnet 4.5/4.6, GPT-5, Gemini 2.5 Pro at $0/req",
        hint="Best zero-marginal-cost option if you have a Copilot subscription",
        color="#6E40C9",
        recommended=True,
        free_tier=True,
        requires_oauth=True,
        default_model="claude-sonnet-4.6",
    ),
    ProviderSpec(
        key="anthropic",
        display_name="Anthropic (Claude)",
        description="First-party access to Claude Opus 4.6, Sonnet 4.6, Haiku 4.5",
        color="#CC3333",
        default_model="claude-opus-4-6",
    ),
    ProviderSpec(
        key="nvidia",
        display_name="NVIDIA NIM",
        description="Nemotron 3 Super 120B (262K ctx) + Kimi K2 + MiniMax M2 — free tier",
        hint="Heavy-context / zero-cost workloads; OpenAI-compatible",
        color="#76B900",  # NVIDIA green
        free_tier=True,
        default_model="nvidia/nemotron-3-super-120b-instruct",
    ),
    ProviderSpec(
        key="google",
        display_name="Google Gemini",
        description="Gemini 3.1 Pro Preview, 2.5 Flash, Flash Lite via Google AI Studio",
        color="#AA8844",
        default_model="gemini-2.5-flash",
    ),
    ProviderSpec(
        key="openai",
        display_name="OpenAI",
        description="GPT-5.3, GPT-5.2, GPT-5.2-codex, GPT-4.1 — direct API",
        color="#CC6666",
        default_model="gpt-5.2",
    ),
    ProviderSpec(
        key="vertex",
        display_name="Google Cloud Vertex AI",
        description="Enterprise Gemini & Model Garden via gcloud ADC (no API key)",
        hint="Requires `gcloud auth application-default login`",
        color="#4285F4",
        requires_oauth=True,
        default_model="gemini-2.5-flash",
    ),
    ProviderSpec(
        key="ollama",
        display_name="Ollama",
        description="Fully local models — no API key, no network, no cost",
        hint="Install Ollama and pull a model first (e.g. `ollama pull qwen2.5-coder`)",
        color="magenta",
        free_tier=True,
        local=True,
        default_model="qwen2.5-coder:7b",
    ),
    ProviderSpec(
        key="lmstudio",
        display_name="LM Studio",
        description="Local models served by the LM Studio app on port 1234",
        hint="Open LM Studio, load a model, start the server",
        color="cyan",
        free_tier=True,
        local=True,
        default_model="loaded-model",
    ),
)


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------

def _profile_for(key: str) -> ProviderProfile | None:
    if key == "passthrough":
        return None
    for p in all_profiles():
        if p.name == key or key in (p.aliases or []):
            return p
    return None


def list_provider_specs() -> list[ProviderSpec]:
    """Return all provider specs in wizard menu order."""
    return list(PROVIDER_SPECS)


def get_provider_spec(key: str) -> ProviderSpec | None:
    for s in PROVIDER_SPECS:
        if s.key == key:
            return s
    return None


def registry_snapshot() -> dict[str, Any]:
    """JSON-serialisable snapshot of providers + features — consumed by the dashboard."""
    from cvc.setup.features import list_feature_specs, feature_categories

    feats = list_feature_specs()
    return {
        "providers": [s.to_dict() for s in PROVIDER_SPECS],
        "provider_count": len(PROVIDER_SPECS),
        "features": [f.to_dict() for f in feats],
        "feature_count": len(feats),
        "feature_categories": feature_categories(),
        "schema_version": 1,
    }


__all__ = [
    "ProviderSpec",
    "PROVIDER_SPECS",
    "list_provider_specs",
    "get_provider_spec",
    "registry_snapshot",
]
