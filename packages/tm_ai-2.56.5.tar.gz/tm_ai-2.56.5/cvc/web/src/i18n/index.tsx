/**
 * Minimal i18n shim for CVC Phase B.
 *
 * Hermes' upstream i18n returns `t` as a *translations object*
 * (e.g. `t.theme.switchTheme`) — call sites then use `??` to provide an
 * English fallback. We mirror that shape with an empty translations object
 * so every lookup falls through to the inline fallback string. This keeps
 * the ported components (`ThemeSwitcher`, etc.) drop-in.
 *
 * Phase D will swap this for a real provider when CVC ships translations.
 */
import { createContext, useContext } from "react";
import type { ReactNode } from "react";

export type Locale = "en";

/** Open-ended translations bag. Every leaf is optional → callers always
 *  use `??` fallbacks, which is exactly what the ported Hermes code does. */
export type Translations = Record<string, Record<string, string | undefined>>;

interface I18nValue {
  t: Translations;
  locale: Locale;
  setLocale: (l: Locale) => void;
}

const EMPTY_T: Translations = {};

const I18nContext = createContext<I18nValue>({
  t: EMPTY_T,
  locale: "en",
  setLocale: () => {},
});

export function useI18n(): I18nValue {
  return useContext(I18nContext);
}

export function I18nProvider({ children }: { children: ReactNode }) {
  return (
    <I18nContext.Provider
      value={{ t: EMPTY_T, locale: "en", setLocale: () => {} }}
    >
      {children}
    </I18nContext.Provider>
  );
}
