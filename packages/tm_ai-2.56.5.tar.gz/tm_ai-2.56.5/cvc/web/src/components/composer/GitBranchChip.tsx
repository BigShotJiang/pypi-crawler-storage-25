import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  GitBranch,
  Plus,
  RefreshCw,
} from "lucide-react";
import { api } from "@/lib/api";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import { cn } from "@/lib/utils";
import type {
  GitBranchEntry,
  GitBranchesResponse,
  GitStatusInfo,
} from "@/lib/types";

interface GitBranchChipProps {
  /** Identifier of the active workspace — refetches when it changes. */
  workspaceKey: string | null;
  /** Optional callback after a successful checkout/create. */
  onBranchSwitched?(branch: string, opts: { created: boolean }): void;
  /** Drop the menu upward (default true — composer is anchored to bottom). */
  dropUp?: boolean;
}

/**
 * Composer chip that mirrors WorkspaceChip but for the active workspace's
 * Git branch. Shows current branch, lists local branches, lets the user
 * switch or create a new branch — all scoped to the gateway's active
 * workspace path. Hidden when the active workspace is not a git repo.
 */
export function GitBranchChip({
  workspaceKey,
  onBranchSwitched,
  dropUp = true,
}: GitBranchChipProps) {
  const [status, setStatus] = useState<GitStatusInfo | null>(null);
  const [branches, setBranches] = useState<GitBranchEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const wrapperRef = useRef<HTMLDivElement>(null);
  const close = useCallback(() => {
    setOpen(false);
    setCreating(false);
    setNewName("");
    setActionError(null);
  }, []);
  useDismissableDropdown(open, close, wrapperRef);

  const fetchAll = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    setError(null);
    try {
      const s = await api.gitStatus();
      setStatus(s);
      if (s.is_repo) {
        const b: GitBranchesResponse = await api.gitBranches();
        setBranches(b.branches);
      } else {
        setBranches([]);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setBranches([]);
      setStatus(null);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // Refetch whenever the active workspace changes
  useEffect(() => {
    void fetchAll(false);
  }, [workspaceKey, fetchAll]);

  const handleSwitch = useCallback(
    async (name: string, force = false) => {
      if (!name || busy) return;
      setBusy(true);
      setActionError(null);
      try {
        await api.gitCheckout(name, { create: false, force });
        await fetchAll(true);
        onBranchSwitched?.(name, { created: false });
        close();
      } catch (e) {
        setActionError(e instanceof Error ? e.message : String(e));
      } finally {
        setBusy(false);
      }
    },
    [busy, fetchAll, onBranchSwitched, close],
  );

  const handleCreate = useCallback(async () => {
    const name = newName.trim();
    if (!name) {
      setActionError("Enter a branch name");
      return;
    }
    setBusy(true);
    setActionError(null);
    try {
      await api.gitCheckout(name, { create: true });
      await fetchAll(true);
      onBranchSwitched?.(name, { created: true });
      close();
    } catch (e) {
      setActionError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }, [newName, fetchAll, onBranchSwitched, close]);

  // Don't render at all if the workspace isn't a git repo.
  // (Keeps the composer row clean for non-git workspaces.)
  if (!loading && status && !status.is_repo) return null;

  const label = status?.branch || (loading ? "…" : "no branch");
  const isDirty = !!status?.dirty;
  const detached = !!status?.detached;

  return (
    <div ref={wrapperRef} className="relative min-w-0 shrink">
      <div className="inline-flex h-8 max-w-full items-stretch overflow-hidden rounded-full border border-[color:var(--color-border)] bg-[color:var(--midground-base)]/8">
        <div
          className={cn(
            "flex h-full w-9 items-center justify-center",
            "bg-[color:var(--midground-base)]/[0.06] text-foreground/70",
          )}
          aria-hidden
          title={detached ? "Detached HEAD" : "Git branch"}
        >
          {detached ? (
            <AlertTriangle className="h-4 w-4 text-[color:var(--color-warning)]" strokeWidth={2} />
          ) : (
            <GitBranch className="h-4 w-4" strokeWidth={2} />
          )}
        </div>
        <div className="w-px self-stretch bg-[color:var(--color-border)]" aria-hidden />
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className={cn(
            "inline-flex h-full items-center gap-1.5 px-3",
            "text-[13px] text-foreground/85 hover:text-foreground hover:bg-[color:var(--midground-base)]/10 transition-colors",
          )}
          aria-label="Switch git branch"
          aria-expanded={open}
          aria-haspopup="listbox"
          title={
            status?.head
              ? `${label}${isDirty ? " · uncommitted changes" : ""} (${status.head})`
              : "Choose branch"
          }
        >
          <span className="truncate max-w-[140px] min-w-0">{label}</span>
          {isDirty && (
            <span
              className="h-1.5 w-1.5 rounded-full bg-[color:var(--color-warning)]"
              title="Working tree has uncommitted changes"
              aria-label="dirty"
            />
          )}
          <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.5} />
        </button>
      </div>

      {open && (
        <div
          role="listbox"
          aria-label="Git branch"
          className={cn(
            "absolute z-50 min-w-[360px] max-w-[440px] rounded-xl",
            dropUp ? "left-0 bottom-full mb-2" : "left-0 top-full mt-2",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_12px_40px_-8px_rgba(0,0,0,0.7)]",
            "py-1 overflow-hidden max-h-[60vh] overflow-y-auto",
          )}
        >
          <div className="flex items-center justify-between px-3 py-1.5">
            <span className="text-[10px] uppercase tracking-[0.15em] text-foreground/40">
              Git branch
            </span>
            <button
              type="button"
              onClick={() => void fetchAll(true)}
              disabled={refreshing}
              className={cn(
                "flex h-5 w-5 items-center justify-center rounded-md text-foreground/55 hover:text-foreground/95 hover:bg-[color:var(--midground-base)]/10",
                refreshing && "opacity-60 cursor-wait",
              )}
              aria-label="Refresh branches"
              title="Refresh"
            >
              <RefreshCw className={cn("h-3 w-3", refreshing && "animate-spin")} strokeWidth={2.5} />
            </button>
          </div>

          {error && (
            <div className="mx-3 mb-1.5 rounded-md border border-[color:var(--color-destructive)]/40 bg-[color:var(--color-destructive)]/10 px-2 py-1.5 text-[11.5px] text-[color:var(--color-destructive)]">
              {error}
            </div>
          )}

          {isDirty && (
            <div className="mx-3 mb-1.5 rounded-md border border-[color:var(--color-warning)]/40 bg-[color:var(--color-warning)]/10 px-2 py-1.5 text-[11.5px] text-[color:var(--color-warning)]">
              {status?.dirty_count ?? 0} uncommitted change
              {(status?.dirty_count ?? 0) === 1 ? "" : "s"} — switching requires
              <span className="font-semibold"> Force</span>.
            </div>
          )}

          {loading ? (
            <div className="px-3 py-3 text-[12.5px] text-foreground/50">Loading…</div>
          ) : branches.length === 0 ? (
            <div className="px-3 py-3 text-[12.5px] text-foreground/50">
              No local branches found.
            </div>
          ) : (
            branches.map((b) => (
              <div
                key={b.name}
                className={cn(
                  "flex w-full items-stretch transition-colors",
                  "hover:bg-[color:var(--midground-base)]/10",
                  b.is_current && "bg-[color:var(--midground-base)]/[0.06]",
                )}
              >
                <button
                  type="button"
                  role="option"
                  aria-selected={b.is_current}
                  disabled={busy || b.is_current}
                  onClick={() => void handleSwitch(b.name, isDirty)}
                  className="flex flex-1 items-center gap-2.5 px-3 py-2 text-left disabled:cursor-default"
                  title={
                    b.is_current
                      ? `${b.name} (current)`
                      : isDirty
                      ? `Force-switch to ${b.name}`
                      : `Switch to ${b.name}`
                  }
                >
                  <GitBranch
                    className={cn(
                      "h-3.5 w-3.5 shrink-0",
                      b.is_current ? "text-[color:var(--color-warning)]" : "text-foreground/55",
                    )}
                    strokeWidth={2}
                  />
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span
                      className={cn(
                        "truncate text-[13px]",
                        b.is_current ? "text-[color:var(--color-warning)]" : "text-foreground/90",
                      )}
                    >
                      {b.name}
                    </span>
                    <span className="truncate text-[11px] text-foreground/45">
                      {b.head}
                      {b.last_commit_subject ? ` · ${b.last_commit_subject}` : ""}
                    </span>
                  </div>
                  <Check
                    className={cn(
                      "h-3.5 w-3.5 shrink-0 text-[color:var(--color-warning)]",
                      b.is_current ? "opacity-100" : "opacity-0",
                    )}
                    strokeWidth={2.5}
                  />
                </button>
              </div>
            ))
          )}

          {/* Create-branch footer (mirrors WorkspaceChip's add-workspace UX) */}
          <div className="border-t border-[color:var(--color-border)] mt-1">
            {!creating ? (
              <button
                type="button"
                onClick={() => setCreating(true)}
                disabled={!status?.is_repo}
                className={cn(
                  "flex w-full items-center gap-2 px-3 py-2.5 text-[13px]",
                  "text-foreground/75 hover:bg-[color:var(--midground-base)]/10 hover:text-[color:var(--color-warning)]",
                  "transition-colors disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent",
                )}
              >
                <Plus className="h-3.5 w-3.5" strokeWidth={2.5} />
                <span>Create branch…</span>
              </button>
            ) : (
              <div className="flex flex-col gap-2 px-3 py-2.5">
                <input
                  autoFocus
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void handleCreate();
                    if (e.key === "Escape") {
                      setCreating(false);
                      setNewName("");
                      setActionError(null);
                    }
                  }}
                  placeholder="feature/my-branch"
                  className={cn(
                    "w-full rounded-md px-2 py-1.5 text-[13px]",
                    "bg-[color:var(--midground-base)]/[0.08] text-foreground/90 placeholder:text-foreground/35",
                    "border border-[color:var(--color-border)] outline-none",
                    "focus:border-[color:var(--midground-base)]/35 font-mono",
                  )}
                />
                {actionError && (
                  <div
                    className="text-[11px] text-[color:var(--color-destructive)] truncate"
                    title={actionError}
                  >
                    {actionError}
                  </div>
                )}
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10.5px] text-foreground/40">
                    Forks from <code className="font-mono">{status?.branch || "HEAD"}</code>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setCreating(false);
                        setNewName("");
                        setActionError(null);
                      }}
                      className="rounded-md px-2 py-1 text-[12px] text-foreground/60 hover:text-foreground/90"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleCreate()}
                      disabled={busy || !newName.trim()}
                      className={cn(
                        "rounded-md px-3 py-1 text-[12px] font-medium transition-colors",
                        busy || !newName.trim()
                          ? "bg-[color:var(--midground-base)]/10 text-foreground/40 cursor-not-allowed"
                          : "bg-[color-mix(in_srgb,var(--color-warning)_90%,transparent)] text-black hover:bg-[color:var(--color-warning)]",
                      )}
                    >
                      {busy ? "Creating…" : "Create & switch"}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
