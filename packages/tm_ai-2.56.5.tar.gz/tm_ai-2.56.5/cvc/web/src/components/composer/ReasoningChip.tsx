import { useCallback, useRef, useState } from "react";
import { Check, ChevronDown, Contrast } from "lucide-react";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import { cn } from "@/lib/utils";
import type { ReasoningEffort } from "@/lib/types";

interface ReasoningChipProps {
  effort: ReasoningEffort;
  onChange(effort: ReasoningEffort): void;
  dropUp?: boolean;
}

const EFFORT_OPTIONS: ReasoningEffort[] = [
  "none",
  "minimal",
  "low",
  "medium",
  "high",
  "xhigh",
];

const LABELS: Record<ReasoningEffort, string> = {
  none: "none",
  minimal: "minimal",
  low: "low",
  medium: "medium",
  high: "high",
  xhigh: "xhigh",
};

/**
 * Reasoning-effort chip. Half-moon contrast icon mirrors the reference UI.
 */
export function ReasoningChip({ effort, onChange, dropUp = true }: ReasoningChipProps) {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useDismissableDropdown(open, close, wrapperRef);

  return (
    <div ref={wrapperRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "inline-flex h-8 items-center gap-1.5 rounded-full px-2.5",
          "text-[13px] text-foreground/85 hover:bg-[color:var(--midground-base)]/10 hover:text-foreground transition-colors",
        )}
        aria-label="Reasoning effort"
        aria-expanded={open}
        aria-haspopup="listbox"
        title={`Reasoning: ${LABELS[effort]}`}
      >
        <Contrast className="h-4 w-4" strokeWidth={2} />
        <span>{LABELS[effort]}</span>
        <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.5} />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="Reasoning effort"
          className={cn(
            "absolute z-50 min-w-[180px] rounded-xl",
            dropUp ? "left-0 bottom-full mb-2" : "left-0 top-full mt-2",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_12px_40px_-8px_rgba(0,0,0,0.7)]",
            "py-1 overflow-hidden",
          )}
        >
          <div className="px-3 py-1.5 text-[10px] uppercase tracking-[0.15em] text-foreground/40">
            Reasoning
          </div>
          {EFFORT_OPTIONS.map((opt) => {
            const isActive = opt === effort;
            return (
              <button
                type="button"
                key={opt}
                role="option"
                aria-selected={isActive}
                onClick={() => {
                  onChange(opt);
                  close();
                }}
                className={cn(
                  "flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors",
                  "hover:bg-[color:var(--midground-base)]/10",
                  isActive && "bg-[color:var(--midground-base)]/[0.06]",
                )}
              >
                <span className={cn("flex-1 text-[13px]", isActive ? "text-[color:var(--color-warning)]" : "text-foreground/90")}>
                  {LABELS[opt]}
                </span>
                <Check
                  className={cn(
                    "h-3.5 w-3.5 shrink-0 text-[color:var(--color-warning)]",
                    isActive ? "opacity-100" : "opacity-0",
                  )}
                  strokeWidth={2.5}
                />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
