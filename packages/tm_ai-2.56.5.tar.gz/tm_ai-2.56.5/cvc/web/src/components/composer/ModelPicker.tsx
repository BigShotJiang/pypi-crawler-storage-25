import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Cpu, Plus, X } from "lucide-react";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import { cn } from "@/lib/utils";
import type { ModelCatalog, ModelInfo } from "@/lib/types";

interface ModelPickerProps {
  catalog: ModelCatalog | null;
  current: { provider: string; model: string };
  onSwitch(provider: string, model: string): Promise<void> | void;
  dropUp?: boolean;
}

const PROVIDER_BADGE_LABEL: Record<string, string> = {
  github: "GitHub Copilot",
  copilot: "GitHub Copilot",
  anthropic: "Anthropic",
  openai: "OpenAI",
  google: "Google",
  ollama: "Ollama",
  lmstudio: "LM Studio",
  nvidia: "NVIDIA",
  vertex: "Google Vertex",
};

function providerLabel(catalog: ModelCatalog | null, provider: string): string {
  const explicit = catalog?.provider_labels?.[provider];
  if (explicit) return explicit;
  const items = catalog?.providers?.[provider] ?? [];
  const carried = items.find((m) => m.provider_label)?.provider_label;
  if (carried) return carried;
  const base = PROVIDER_BADGE_LABEL[provider] ?? provider;
  return `${base} (${items.length})`;
}

function providerBadge(provider: string): string {
  return PROVIDER_BADGE_LABEL[provider] ?? provider;
}

function findModelName(catalog: ModelCatalog | null, provider: string, model: string): string {
  const items = catalog?.providers?.[provider] ?? [];
  const found = items.find((m) => m.id === model);
  return found?.name || model;
}

/**
 * Model picker chip — opens a richer popover with:
 *  • search across all models
 *  • custom model-id entry (e.g. `openai/gpt-5.4`)
 *  • a CONFIGURED section that highlights the live primary model
 *  • per-provider groups with the real catalog (from /api/models/catalog)
 *
 * All data is pulled from the live gateway — no hard-coded placeholders.
 */
export function ModelPicker({ catalog, current, onSwitch, dropUp = true }: ModelPickerProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [customId, setCustomId] = useState("");
  const wrapperRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useDismissableDropdown(open, close, wrapperRef);

  useEffect(() => {
    if (open) {
      setQuery("");
      setCustomId("");
      // focus search on open
      requestAnimationFrame(() => searchRef.current?.focus());
    }
  }, [open]);

  const groups = useMemo(() => {
    if (!catalog?.providers) {
      return [] as Array<{ provider: string; label: string; models: ModelInfo[] }>;
    }
    const q = query.trim().toLowerCase();
    return Object.entries(catalog.providers)
      .map(([provider, models]) => {
        const filtered = q
          ? models.filter(
              (m) =>
                (m.id || "").toLowerCase().includes(q) ||
                (m.name || "").toLowerCase().includes(q) ||
                (m.description || "").toLowerCase().includes(q),
            )
          : models;
        return {
          provider,
          label: providerLabel(catalog, provider),
          models: filtered,
        };
      })
      .filter((g) => g.models.length > 0);
  }, [catalog, query]);

  // Locate the live primary (CONFIGURED) entry.
  const primary = useMemo(() => {
    if (!catalog?.providers) return null;
    for (const [provider, models] of Object.entries(catalog.providers)) {
      for (const m of models) {
        if (m.is_primary) return { provider, model: m };
        if (provider === current.provider && m.id === current.model) {
          return { provider, model: m };
        }
      }
    }
    return null;
  }, [catalog, current]);

  const display = findModelName(catalog, current.provider, current.model);

  const submitCustom = useCallback(async () => {
    const raw = customId.trim();
    if (!raw) return;
    // Accept "provider/model" or fall back to current provider.
    let provider = current.provider;
    let model = raw;
    if (raw.includes("/")) {
      const [p, ...rest] = raw.split("/");
      if (p && rest.length > 0) {
        provider = p;
        model = rest.join("/");
      }
    }
    close();
    await onSwitch(provider, model);
  }, [customId, current.provider, onSwitch, close]);

  return (
    <div ref={wrapperRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "inline-flex h-8 items-center gap-1.5 rounded-full px-2.5",
          "text-[13px] text-foreground/85 hover:bg-[color:var(--midground-base)]/10 hover:text-foreground transition-colors",
        )}
        aria-label="Switch model"
        aria-expanded={open}
        aria-haspopup="listbox"
        title={`${current.provider} · ${current.model}`}
      >
        <Cpu className="h-4 w-4" strokeWidth={2} />
        <span className="truncate max-w-[200px]">{display}</span>
        <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.5} />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="Model"
          className={cn(
            "absolute z-50 w-[380px] rounded-2xl",
            dropUp ? "left-0 bottom-full mb-2" : "left-0 top-full mt-2",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_16px_48px_-8px_rgba(0,0,0,0.75)]",
            "overflow-hidden",
          )}
        >
          {/* Header */}
          <div className="px-4 pt-3 pb-2 border-b border-[color:var(--color-border)]/60">
            <div className="text-[12.5px] text-foreground/80">
              <span className="font-semibold text-foreground">Applies to this conversation</span>{" "}
              from your next message.
            </div>
            <div className="mt-2.5 relative">
              <input
                ref={searchRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search models..."
                className={cn(
                  "w-full h-9 rounded-lg pl-3 pr-9 text-[13px]",
                  "bg-[color:var(--midground-base)]/10 border border-[color:var(--color-border)]/60",
                  "text-foreground placeholder:text-foreground/40",
                  "focus:outline-none focus:ring-1 focus:ring-[color:var(--color-warning)]/40",
                )}
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-5 w-5 items-center justify-center rounded-full text-foreground/60 hover:bg-[color:var(--midground-base)]/15 hover:text-foreground"
                  aria-label="Clear search"
                >
                  <X className="h-3.5 w-3.5" strokeWidth={2.5} />
                </button>
              )}
            </div>
          </div>

          {/* Custom model id */}
          <div className="px-4 pt-3 pb-3 border-b border-[color:var(--color-border)]/60">
            <div className="text-[10px] uppercase tracking-[0.15em] text-foreground/45">
              Custom model ID
            </div>
            <div className="mt-1.5 flex gap-1.5">
              <input
                type="text"
                value={customId}
                onChange={(e) => setCustomId(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    submitCustom();
                  }
                }}
                placeholder="e.g. openai/gpt-5.4"
                className={cn(
                  "flex-1 h-9 rounded-lg px-3 text-[13px]",
                  "bg-[color:var(--midground-base)]/10 border border-[color:var(--color-border)]/60",
                  "text-foreground placeholder:text-foreground/35 tabular-nums",
                  "focus:outline-none focus:ring-1 focus:ring-[color:var(--color-warning)]/40",
                )}
              />
              <button
                type="button"
                onClick={submitCustom}
                disabled={!customId.trim()}
                className={cn(
                  "inline-flex h-9 w-9 items-center justify-center rounded-lg",
                  "border border-[color:var(--color-border)]/60 bg-[color:var(--midground-base)]/10",
                  "text-foreground/80 hover:bg-[color:var(--midground-base)]/20",
                  "disabled:opacity-40 disabled:cursor-not-allowed",
                )}
                aria-label="Use custom model"
              >
                <Plus className="h-4 w-4" strokeWidth={2.5} />
              </button>
            </div>
          </div>

          {/* Scrollable lists */}
          <div className="max-h-[50vh] overflow-y-auto py-1">
            {/* CONFIGURED section */}
            {primary && (
              <div>
                <div className="sticky top-0 z-10 bg-[color:var(--background-base)]/95 px-3 py-1.5 text-[10px] uppercase tracking-[0.15em] text-foreground/45 backdrop-blur-md">
                  Configured
                </div>
                <div
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5",
                    "bg-[color:var(--midground-base)]/[0.08]",
                  )}
                >
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-[13px] font-medium text-foreground">
                        {primary.model.name || primary.model.id}
                      </span>
                      <span className="shrink-0 rounded-full bg-[color:var(--color-warning)]/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.1em] text-[color:var(--color-warning)]">
                        Primary ({providerBadge(primary.provider)})
                      </span>
                    </div>
                    <span className="truncate text-[11px] text-foreground/45 tabular-nums">
                      {primary.model.id}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Provider groups */}
            {groups.map((group) => (
              <div key={group.provider}>
                <div className="sticky top-0 z-10 bg-[color:var(--background-base)]/95 px-3 py-1.5 text-[10px] uppercase tracking-[0.15em] text-foreground/45 backdrop-blur-md">
                  {group.label}
                </div>
                {group.models.map((m) => {
                  const isActive =
                    current.provider === group.provider && current.model === m.id;
                  return (
                    <button
                      type="button"
                      key={`${group.provider}::${m.id}`}
                      role="option"
                      aria-selected={isActive}
                      onClick={async () => {
                        close();
                        await onSwitch(group.provider, m.id);
                      }}
                      className={cn(
                        "flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors",
                        "hover:bg-[color:var(--midground-base)]/10",
                        isActive && "bg-[color:var(--midground-base)]/[0.06]",
                      )}
                    >
                      <div className="flex min-w-0 flex-1 flex-col">
                        <span
                          className={cn(
                            "truncate text-[13px]",
                            isActive
                              ? "text-[color:var(--color-warning)]"
                              : "text-foreground/90",
                          )}
                        >
                          {m.name || m.id}
                        </span>
                        <span className="truncate text-[11px] text-foreground/45 tabular-nums">
                          {m.id}
                        </span>
                      </div>
                      <span className="shrink-0 rounded-md border border-[color:var(--color-border)]/60 px-1.5 py-0.5 text-[10px] text-foreground/60">
                        {providerBadge(group.provider)}
                      </span>
                    </button>
                  );
                })}
              </div>
            ))}

            {groups.length === 0 && !primary && (
              <div className="px-4 py-6 text-center text-[12.5px] text-foreground/45">
                No models match “{query}”
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
