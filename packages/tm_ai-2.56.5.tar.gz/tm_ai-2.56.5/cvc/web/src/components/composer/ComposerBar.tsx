import {
  forwardRef,
  useCallback,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import {
  ArrowUp,
  FileText,
  Image as ImageIcon,
  Mic,
  Paperclip,
  Square,
  X,
} from "lucide-react";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";
import type { Attachment, ReasoningEffort } from "@/lib/types";

export interface ComposerSendOptions {
  personaId: string;
  workspaceId: string;
  provider: string;
  model: string;
  reasoningEffort: ReasoningEffort;
  attachments?: Attachment[];
}

interface ComposerBarProps {
  personaChip?: ReactNode;
  workspaceChip?: ReactNode;
  gitBranchChip?: ReactNode;
  modelChip?: ReactNode;
  reasoningChip?: ReactNode;
  meter?: ReactNode;
  skillsBadge?: ReactNode;
  sendOptions: ComposerSendOptions;
  onSend(text: string, opts: ComposerSendOptions): void;
  streaming: boolean;
  onAbort(): void;
  placeholder?: string;
  className?: string;
}

type RecState = "idle" | "recording" | "transcribing" | "error";

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Hermes-style composer bar with voice + multimodal file attachments.
 *
 * Bottom row: [attach] [mic] | [persona] [workspace] [model] [reasoning] ... [meter] [send]
 * Top of pill: banner for recording / transcribing / upload / error.
 * Above textarea: attachment chips when files are pinned.
 */
export const ComposerBar = forwardRef<HTMLTextAreaElement, ComposerBarProps>(
  function ComposerBar(
    {
      personaChip,
      workspaceChip,
      gitBranchChip,
      modelChip,
      reasoningChip,
      meter,
      skillsBadge,
      sendOptions,
      onSend,
      streaming,
      onAbort,
      placeholder = "Message Sofia…",
      className,
    },
    ref,
  ) {
    const [text, setText] = useState("");
    const [recState, setRecState] = useState<RecState>("idle");
    const [recError, setRecError] = useState<string | null>(null);
    const [attachments, setAttachments] = useState<Attachment[]>([]);
    const [uploading, setUploading] = useState(false);
    const [uploadError, setUploadError] = useState<string | null>(null);
    const recorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<BlobPart[]>([]);
    const streamRef = useRef<MediaStream | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const submit = useCallback(() => {
      const trimmed = text.trim();
      if ((!trimmed && attachments.length === 0) || streaming) return;
      onSend(trimmed, { ...sendOptions, attachments });
      setText("");
      setAttachments([]);
    }, [text, streaming, onSend, sendOptions, attachments]);

    const onKeyDown = useCallback(
      (e: KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
          e.preventDefault();
          submit();
        }
      },
      [submit],
    );

    const handleFiles = useCallback(async (files: FileList | File[]) => {
      const arr = Array.from(files).filter((f) => f.size > 0);
      if (arr.length === 0) return;
      setUploadError(null);
      setUploading(true);
      try {
        const { files: uploaded } = await api.uploadFiles(arr);
        setAttachments((prev) => [...prev, ...uploaded]);
      } catch (e) {
        setUploadError(e instanceof Error ? e.message : String(e));
        setTimeout(() => setUploadError(null), 5000);
      } finally {
        setUploading(false);
      }
    }, []);

    const onAttachClick = useCallback(() => {
      fileInputRef.current?.click();
    }, []);

    const onFileInputChange = useCallback(
      (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
          void handleFiles(e.target.files);
        }
        // Reset so picking the same file twice still fires onChange
        e.target.value = "";
      },
      [handleFiles],
    );

    const removeAttachment = useCallback((idx: number) => {
      setAttachments((prev) => prev.filter((_, i) => i !== idx));
    }, []);

    const stopTracks = useCallback(() => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    }, []);

    const transcribeBlob = useCallback(async (blob: Blob) => {
      setRecState("transcribing");
      setRecError(null);
      try {
        const ext = blob.type.includes("ogg") ? "ogg" : "webm";
        const { text: transcript } = await api.transcribe(blob, `recording.${ext}`);
        if (transcript) {
          setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
        setRecState("idle");
      } catch (e) {
        setRecError(e instanceof Error ? e.message : String(e));
        setRecState("error");
        setTimeout(() => setRecState("idle"), 4000);
      }
    }, []);

    const startRecording = useCallback(async () => {
      if (recState === "recording") return;
      setRecError(null);
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("Microphone not available in this browser");
        }
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;

        const mimeCandidates = [
          "audio/webm;codecs=opus",
          "audio/webm",
          "audio/ogg;codecs=opus",
          "audio/mp4",
        ];
        const mimeType = mimeCandidates.find(
          (m) =>
            typeof MediaRecorder !== "undefined" &&
            MediaRecorder.isTypeSupported &&
            MediaRecorder.isTypeSupported(m),
        );

        const rec = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
        chunksRef.current = [];
        rec.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
        };
        rec.onstop = () => {
          stopTracks();
          const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
          chunksRef.current = [];
          if (blob.size > 0) void transcribeBlob(blob);
          else setRecState("idle");
        };
        rec.onerror = (ev) => {
          setRecError((ev as ErrorEvent).message || "Recorder error");
          setRecState("error");
          stopTracks();
        };
        recorderRef.current = rec;
        rec.start();
        setRecState("recording");
      } catch (e) {
        setRecError(e instanceof Error ? e.message : String(e));
        setRecState("error");
        stopTracks();
        setTimeout(() => setRecState("idle"), 4000);
      }
    }, [recState, stopTracks, transcribeBlob]);

    const stopRecording = useCallback(() => {
      const rec = recorderRef.current;
      if (rec && rec.state !== "inactive") rec.stop();
    }, []);

    const toggleMic = useCallback(() => {
      if (recState === "recording") stopRecording();
      else if (recState === "idle" || recState === "error") void startRecording();
    }, [recState, startRecording, stopRecording]);

    const canSend =
      (text.trim().length > 0 || attachments.length > 0) && !streaming && !uploading;
    const isRecording = recState === "recording";
    const isTranscribing = recState === "transcribing";
    const showBanner =
      isRecording || isTranscribing || recState === "error" || uploading || !!uploadError;

    return (
      <div
        className={cn(
          "rounded-2xl border border-[color:var(--color-border)] bg-[color:var(--background-base)]/85 backdrop-blur-md",
          "shadow-[0_4px_24px_-8px_rgba(0,0,0,0.5)]",
          "flex flex-col gap-2 px-4 pt-3 pb-2",
          "transition-colors focus-within:border-[color:var(--midground-base)]/30",
          isRecording && "border-[color:var(--color-destructive)]/40",
          className,
        )}
      >
        {/* Hidden file input — drives the paperclip button */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          accept="image/*,application/pdf,text/*,.md,.json,.yaml,.yml,.csv,.toml,.xml,.log,application/json,application/x-yaml,application/zip,.docx,.xlsx,.pptx,audio/*,video/*"
          onChange={onFileInputChange}
        />

        {/* Status banner */}
        {showBanner && (
          <div className="flex items-center gap-2 text-[12px]">
            {isRecording && (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[color:var(--color-destructive)] opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-[color:var(--color-destructive)]" />
                </span>
                <span className="text-[color:var(--color-destructive)]">Listening…</span>
              </>
            )}
            {isTranscribing && (
              <>
                <span className="h-2 w-2 animate-pulse rounded-full bg-[color:var(--color-warning)]" />
                <span className="text-[color:var(--color-warning)]">Transcribing…</span>
              </>
            )}
            {uploading && (
              <>
                <span className="h-2 w-2 animate-pulse rounded-full bg-[color:var(--color-warning)]" />
                <span className="text-[color:var(--color-warning)]">Uploading…</span>
              </>
            )}
            {recState === "error" && recError && (
              <>
                <span className="h-2 w-2 rounded-full bg-[color:var(--color-destructive)]" />
                <span className="text-[color:var(--color-destructive)] truncate" title={recError}>
                  {recError}
                </span>
              </>
            )}
            {uploadError && (
              <>
                <span className="h-2 w-2 rounded-full bg-[color:var(--color-destructive)]" />
                <span className="text-[color:var(--color-destructive)] truncate" title={uploadError}>
                  {uploadError}
                </span>
              </>
            )}
          </div>
        )}

        {/* Attachment chips */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {attachments.map((a, idx) => (
              <div
                key={`${a.stored_name}-${idx}`}
                className={cn(
                  "group relative inline-flex items-center gap-1.5 rounded-lg",
                  "border border-[color:var(--color-border)] bg-[color:var(--midground-base)]/10",
                  "px-2 py-1 text-[12px] text-foreground/85",
                  "max-w-[240px]",
                )}
                title={`${a.name} · ${formatSize(a.size)} · ${a.mime}`}
              >
                {a.kind === "image" && a.data_url ? (
                  <img
                    src={a.data_url}
                    alt={a.name}
                    className="h-6 w-6 rounded object-cover shrink-0"
                  />
                ) : a.kind === "image" ? (
                  <ImageIcon className="h-3.5 w-3.5 shrink-0 text-foreground/60" />
                ) : (
                  <FileText className="h-3.5 w-3.5 shrink-0 text-foreground/60" />
                )}
                <span className="truncate">{a.name}</span>
                <span className="text-foreground/45 shrink-0">{formatSize(a.size)}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(idx)}
                  className="ml-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-foreground/50 hover:bg-[color:var(--color-destructive)]/20 hover:text-[color:var(--color-destructive)] transition-colors"
                  aria-label={`Remove ${a.name}`}
                >
                  <X className="h-3 w-3" strokeWidth={2.5} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Textarea */}
        <textarea
          ref={ref}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          rows={1}
          className={cn(
            "w-full resize-none bg-transparent",
            "border-0 outline-none focus:outline-none focus:ring-0",
            "text-[15px] leading-relaxed text-foreground/95",
            "placeholder:text-foreground/40",
            "min-h-[28px] max-h-[240px]",
          )}
          aria-label="Message"
          disabled={streaming}
        />

        {/* Bottom row */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onAttachClick}
            disabled={uploading}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
              uploading
                ? "text-foreground/40 cursor-wait"
                : "text-foreground/55 hover:bg-[color:var(--midground-base)]/10 hover:text-foreground/90",
            )}
            aria-label="Attach file"
            title="Attach images, documents, audio, or video"
          >
            <Paperclip className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={toggleMic}
            disabled={isTranscribing}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
              isRecording
                ? "bg-[color:var(--color-destructive)]/20 text-[color:var(--color-destructive)] hover:bg-[color:var(--color-destructive)]/30"
                : "text-foreground/55 hover:bg-[color:var(--midground-base)]/10 hover:text-foreground/90",
              isTranscribing && "opacity-60 cursor-wait",
            )}
            aria-label={isRecording ? "Stop recording" : "Voice input"}
            aria-pressed={isRecording}
            title={isRecording ? "Stop recording" : "Voice input"}
          >
            <Mic className="h-4 w-4" />
          </button>

          <div className="mx-1 h-5 w-px bg-[color:var(--midground-base)]/10" aria-hidden />

          {personaChip}
          {workspaceChip}
          {gitBranchChip}
          {modelChip}
          {reasoningChip}
          {skillsBadge}

          <div className="ml-auto flex items-center gap-2">
            {meter}
            {streaming ? (
              <button
                type="button"
                onClick={onAbort}
                className={cn(
                  "flex h-9 w-9 items-center justify-center rounded-full",
                  "bg-[color-mix(in_srgb,var(--color-warning)_90%,transparent)] text-black hover:bg-[color:var(--color-warning)] transition-colors",
                )}
                aria-label="Stop streaming"
                title="Stop"
              >
                <Square className="h-4 w-4 fill-current" />
              </button>
            ) : (
              <button
                type="button"
                onClick={submit}
                disabled={!canSend}
                className={cn(
                  "flex h-9 w-9 items-center justify-center rounded-full transition-colors",
                  canSend
                    ? "bg-[color-mix(in_srgb,var(--color-warning)_90%,transparent)] text-black hover:bg-[color:var(--color-warning)]"
                    : "bg-[color:var(--midground-base)]/10 text-foreground/40 cursor-not-allowed",
                )}
                aria-label="Send message"
                title="Send (⏎)"
              >
                <ArrowUp className="h-4 w-4" strokeWidth={2.5} />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  },
);
