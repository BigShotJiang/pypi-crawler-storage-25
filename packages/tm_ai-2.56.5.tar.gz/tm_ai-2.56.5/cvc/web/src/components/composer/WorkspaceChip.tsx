import { useCallback, useRef, useState } from "react";
import { Check, ChevronDown, Folder, FolderOpen, Plus } from "lucide-react";
import { api } from "@/lib/api";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import { cn } from "@/lib/utils";
import type { WorkspaceInfo } from "@/lib/types";

interface WorkspaceChipProps {
  active: WorkspaceInfo | null;
  workspaces: WorkspaceInfo[];
  onSwitch(workspaceId: string): Promise<void> | void;
  onAdded?(ws: WorkspaceInfo): void;
  onTogglePanel?(): void;
  onOpenPanelFor?(workspaceId: string): void;
  panelOpen?: boolean;
  dropUp?: boolean;
}

function workspaceKey(w: WorkspaceInfo): string {
  return w.workspace_id ?? w.path ?? w.name ?? "";
}

function workspaceLabel(w: WorkspaceInfo): string {
  return w.name ?? w.workspace_id ?? w.path ?? "workspace";
}

export function WorkspaceChip({
  active,
  workspaces,
  onSwitch,
  onAdded,
  onTogglePanel,
  onOpenPanelFor,
  panelOpen,
  dropUp = true,
}: WorkspaceChipProps) {
  const [open, setOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const [newPath, setNewPath] = useState("");
  const [addError, setAddError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const close = useCallback(() => {
    setOpen(false);
    setAdding(false);
    setNewPath("");
    setAddError(null);
  }, []);
  useDismissableDropdown(open, close, wrapperRef);

  const label = active ? workspaceLabel(active) : "workspace";

  const handleAdd = useCallback(async () => {
    const path = newPath.trim();
    if (!path) {
      setAddError("Enter an absolute path");
      return;
    }
    setBusy(true);
    setAddError(null);
    try {
      const res = await api.workspaceAdd(path, true);
      onAdded?.({
        workspace_id: res.workspace_id,
        path: res.path,
        name: res.name,
      } as WorkspaceInfo);
      setAdding(false);
      setNewPath("");
      setOpen(false);
    } catch (e) {
      setAddError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }, [newPath, onAdded]);

  return (
    <div ref={wrapperRef} className="relative">
      <div className="inline-flex h-8 items-stretch overflow-hidden rounded-full border border-[color:var(--color-border)] bg-[color:var(--midground-base)]/8">
        <button
          type="button"
          onClick={onTogglePanel}
          className={cn(
            "flex h-full w-9 items-center justify-center transition-colors",
            "bg-[color:var(--midground-base)]/[0.06]",
            "text-foreground/70 hover:text-foreground/95 hover:bg-[color:var(--midground-base)]/12",
            panelOpen && "text-[color:var(--color-warning)] bg-[color:var(--midground-base)]/12",
          )}
          aria-label="Toggle workspace files"
          aria-pressed={panelOpen}
          title="Show workspace files"
        >
          {panelOpen ? (
            <FolderOpen className="h-4 w-4" strokeWidth={2} />
          ) : (
            <Folder className="h-4 w-4" strokeWidth={2} />
          )}
        </button>
        <div className="w-px self-stretch bg-[color:var(--color-border)]" aria-hidden />
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className={cn(
            "inline-flex h-full items-center gap-1.5 px-3",
            "text-[13px] text-foreground/85 hover:text-foreground hover:bg-[color:var(--midground-base)]/10 transition-colors",
          )}
          aria-label="Switch workspace"
          aria-expanded={open}
          aria-haspopup="listbox"
          title={active?.path ?? "Choose workspace"}
        >
          <span className="truncate max-w-[140px]">{label}</span>
          <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.5} />
        </button>
      </div>

      {open && (
        <div
          role="listbox"
          aria-label="Workspace"
          className={cn(
            "absolute z-50 min-w-[340px] rounded-xl",
            dropUp ? "left-0 bottom-full mb-2" : "left-0 top-full mt-2",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_12px_40px_-8px_rgba(0,0,0,0.7)]",
            "py-1 overflow-hidden max-h-[60vh] overflow-y-auto",
          )}
        >
          <div className="px-3 py-1.5 text-[10px] uppercase tracking-[0.15em] text-foreground/40">
            Workspace
          </div>

          {workspaces.map((w) => {
            const key = workspaceKey(w);
            const isActive = workspaceKey(active ?? ({} as WorkspaceInfo)) === key;
            return (
              <div
                key={key || workspaceLabel(w)}
                className={cn(
                  "flex w-full items-stretch transition-colors",
                  "hover:bg-[color:var(--midground-base)]/10",
                  isActive && "bg-[color:var(--midground-base)]/[0.06]",
                )}
              >
                <button
                  type="button"
                  onClick={() => {
                    onOpenPanelFor?.(key);
                  }}
                  className={cn(
                    "flex w-9 items-center justify-center text-foreground/60 hover:text-[color:var(--color-warning)]",
                    "border-r border-[color:var(--midground-base)]/[0.07]",
                  )}
                  aria-label={`Open files for ${workspaceLabel(w)}`}
                  title="Open files in workspace"
                >
                  <Folder className="h-4 w-4" strokeWidth={2} />
                </button>
                <button
                  type="button"
                  role="option"
                  aria-selected={isActive}
                  onClick={async () => {
                    close();
                    await onSwitch(key);
                  }}
                  className="flex flex-1 items-center gap-2.5 px-3 py-2 text-left"
                >
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span
                      className={cn(
                        "truncate text-[13px]",
                        isActive ? "text-[color:var(--color-warning)]" : "text-foreground/90",
                      )}
                    >
                      {workspaceLabel(w)}
                    </span>
                    {w.path && (
                      <span className="truncate text-[11px] text-foreground/45">{w.path}</span>
                    )}
                  </div>
                  <Check
                    className={cn(
                      "h-3.5 w-3.5 shrink-0 text-[color:var(--color-warning)]",
                      isActive ? "opacity-100" : "opacity-0",
                    )}
                    strokeWidth={2.5}
                  />
                </button>
              </div>
            );
          })}

          {/* Add workspace footer */}
          <div className="border-t border-[color:var(--color-border)] mt-1">
            {!adding ? (
              <button
                type="button"
                onClick={() => setAdding(true)}
                className="flex w-full items-center gap-2 px-3 py-2.5 text-[13px] text-foreground/75 hover:bg-[color:var(--midground-base)]/10 hover:text-[color:var(--color-warning)] transition-colors"
              >
                <Plus className="h-3.5 w-3.5" strokeWidth={2.5} />
                <span>Add workspace…</span>
              </button>
            ) : (
              <div className="flex flex-col gap-2 px-3 py-2.5">
                <input
                  autoFocus
                  type="text"
                  value={newPath}
                  onChange={(e) => setNewPath(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void handleAdd();
                    if (e.key === "Escape") {
                      setAdding(false);
                      setNewPath("");
                      setAddError(null);
                    }
                  }}
                  placeholder="/absolute/path/to/folder"
                  className={cn(
                    "w-full rounded-md px-2 py-1.5 text-[13px]",
                    "bg-[color:var(--midground-base)]/[0.08] text-foreground/90 placeholder:text-foreground/35",
                    "border border-[color:var(--color-border)] outline-none",
                    "focus:border-[color:var(--midground-base)]/35",
                  )}
                />
                {addError && (
                  <div className="text-[11px] text-[color:var(--color-destructive)] truncate" title={addError}>
                    {addError}
                  </div>
                )}
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAdding(false);
                      setNewPath("");
                      setAddError(null);
                    }}
                    className="rounded-md px-2 py-1 text-[12px] text-foreground/60 hover:text-foreground/90"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleAdd()}
                    disabled={busy || !newPath.trim()}
                    className={cn(
                      "rounded-md px-3 py-1 text-[12px] font-medium transition-colors",
                      busy || !newPath.trim()
                        ? "bg-[color:var(--midground-base)]/10 text-foreground/40 cursor-not-allowed"
                        : "bg-[color-mix(in_srgb,var(--color-warning)_90%,transparent)] text-black hover:bg-[color:var(--color-warning)]",
                    )}
                  >
                    {busy ? "Adding…" : "Add"}
                  </button>
                </div>
                <div className="text-[10.5px] text-foreground/40">
                  Initialises <code className="font-mono">.cvc/</code> if missing, then switches.
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
