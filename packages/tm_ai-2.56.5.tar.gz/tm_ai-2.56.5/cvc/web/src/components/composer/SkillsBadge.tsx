import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface SkillsBadgeProps {
  count: number;
  personaId: string;
  onClick?(): void;
}

/**
 * Compact skills badge displayed next to other chips. Mostly informational —
 * shows the active persona's skill count. Tap to (eventually) open the
 * skills panel.
 */
export function SkillsBadge({ count, personaId, onClick }: SkillsBadgeProps) {
  const label = `${count}`;
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className={cn(
        "inline-flex h-8 items-center gap-1.5 rounded-full px-2.5",
        "text-[13px] text-foreground/70 hover:bg-[color:var(--midground-base)]/10 hover:text-foreground/95 transition-colors",
        !onClick && "cursor-default",
      )}
      aria-label={`${count} skills loaded for ${personaId}`}
      title={`${count} skills loaded for persona "${personaId}"`}
    >
      <Sparkles className="h-3.5 w-3.5" strokeWidth={2} />
      <span className="tabular-nums">{label}</span>
    </button>
  );
}
