import { useCallback, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { useDismissableDropdown } from "@/lib/hooks/useDismissableDropdown";
import type { ContextMeter as ContextMeterData } from "@/lib/types";

interface ContextMeterProps {
  meter: ContextMeterData | null;
  compact?: boolean;
}

function formatK(n: number): string {
  if (!Number.isFinite(n)) return "0";
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return new Intl.NumberFormat().format(Math.round(n));
}

/**
 * Circular context-window meter. Click the ring to reveal a popover with the
 * real numbers pulled live from `/api/context/meter` (used %, used/total
 * tokens, and the auto-compress threshold).
 */
export function ContextMeter({ meter, compact = false }: ContextMeterProps) {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useDismissableDropdown(open, close, wrapperRef);

  const pct = meter ? Math.max(0, Math.min(1, meter.used_pct)) : 0;
  const pctRounded = Math.round(pct * 100);

  // SVG ring geometry
  const size = compact ? 28 : 32;
  const stroke = 2.5;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct);

  const ringColor =
    pctRounded >= 80
      ? "var(--color-destructive)"
      : pctRounded >= 60
        ? "var(--color-warning)"
        : "rgba(255,217,192,0.55)";

  const remainingPct = meter ? 100 - pctRounded : 0;
  const thresholdPct = meter ? Math.round(meter.auto_compact_threshold_pct * 100) : 0;

  return (
    <div
      ref={wrapperRef}
      className="relative inline-flex"
      onMouseEnter={() => meter && setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        onClick={() => meter && setOpen((o) => !o)}
        className={cn(
          "relative inline-flex items-center justify-center rounded-full",
          "transition-colors hover:bg-[color:var(--midground-base)]/10",
          !meter && "cursor-default",
        )}
        style={{ width: size, height: size }}
        aria-label="Context window"
        aria-expanded={open}
        aria-haspopup="dialog"
        disabled={!meter}
      >
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke="rgba(255,217,192,0.12)"
            strokeWidth={stroke}
          />
          {meter && (
            <circle
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={ringColor}
              strokeWidth={stroke}
              strokeDasharray={c}
              strokeDashoffset={offset}
              strokeLinecap="round"
              style={{ transition: "stroke-dashoffset 400ms ease" }}
            />
          )}
        </svg>
        <span
          className="absolute text-[9px] font-medium tabular-nums text-foreground/70"
          style={{ lineHeight: 1 }}
        >
          {meter ? pctRounded : "—"}
        </span>
      </button>

      {open && meter && (
        <div
          role="dialog"
          aria-label="Context window"
          className={cn(
            "absolute z-50 right-0 bottom-full mb-2",
            "min-w-[260px] rounded-2xl px-4 py-3",
            "border border-[color:var(--color-border)] bg-[color:var(--background-base)]/95 backdrop-blur-md",
            "shadow-[0_12px_40px_-8px_rgba(0,0,0,0.7)]",
          )}
        >
          <div className="text-[13px] font-semibold text-foreground">Context window</div>
          <div className="mt-2 space-y-1 text-[12.5px] text-foreground/80">
            <div>
              <span className="tabular-nums">{pctRounded}%</span> used (
              <span className="tabular-nums">{remainingPct}%</span> left)
            </div>
            <div className="tabular-nums">
              {formatK(meter.used_tokens)} / {formatK(meter.total_tokens)} tokens used
            </div>
            <div>
              Auto-compress at{" "}
              <span className="tabular-nums">{formatK(meter.auto_compact_threshold_tokens)}</span> (
              <span className="tabular-nums">{thresholdPct}%</span>)
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
