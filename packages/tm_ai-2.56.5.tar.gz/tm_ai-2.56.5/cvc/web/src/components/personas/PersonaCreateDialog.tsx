import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import type { PersonaDetail } from "@/lib/types";

interface Skill {
  id: string;
  kind: string;
  category?: string;
  description?: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onCreated: (p: PersonaDetail) => void;
}

export function PersonaCreateDialog({ open, onClose, onCreated }: Props) {
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [defaultModel, setDefaultModel] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [selectedSkills, setSelectedSkills] = useState<Set<string>>(new Set());
  const [catalog, setCatalog] = useState<Skill[]>([]);
  const [query, setQuery] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    api
      .skillsCatalog()
      .then((r) => setCatalog((r.skills ?? []) as Skill[]))
      .catch(() => setCatalog([]));
  }, [open]);

  useEffect(() => {
    if (!open) {
      setId("");
      setName("");
      setDescription("");
      setDefaultModel("");
      setSystemPrompt("");
      setSelectedSkills(new Set());
      setQuery("");
      setError(null);
      setSubmitting(false);
    }
  }, [open]);

  // Filter + group by category.
  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = q
      ? catalog.filter(
          (s) =>
            s.id.toLowerCase().includes(q) ||
            (s.description ?? "").toLowerCase().includes(q) ||
            (s.category ?? "").toLowerCase().includes(q),
        )
      : catalog;
    const byCat = new Map<string, Skill[]>();
    for (const s of filtered) {
      const cat = s.category || (s.kind === "tool" ? "core" : "other");
      const arr = byCat.get(cat) ?? [];
      arr.push(s);
      byCat.set(cat, arr);
    }
    // Stable category order: core/cvc first, then alpha.
    const order = (k: string) =>
      k === "core" ? 0 : k === "cvc" ? 1 : k === "user" ? 2 : 3;
    return [...byCat.entries()].sort(([a], [b]) => {
      const da = order(a);
      const db = order(b);
      if (da !== db) return da - db;
      return a.localeCompare(b);
    });
  }, [catalog, query]);

  if (!open) return null;

  const toggleSkill = (sid: string) => {
    setSelectedSkills((prev) => {
      const next = new Set(prev);
      if (next.has(sid)) next.delete(sid);
      else next.add(sid);
      return next;
    });
  };

  const toggleCategory = (skills: Skill[], allSelected: boolean) => {
    setSelectedSkills((prev) => {
      const next = new Set(prev);
      for (const s of skills) {
        if (allSelected) next.delete(s.id);
        else next.add(s.id);
      }
      return next;
    });
  };

  const selectAllVisible = () => {
    const ids = grouped.flatMap(([, list]) => list.map((s) => s.id));
    setSelectedSkills(new Set(ids));
  };
  const clearAll = () => setSelectedSkills(new Set());

  const submit = async () => {
    setError(null);
    if (!id.trim() || !name.trim()) {
      setError("id and name required");
      return;
    }
    setSubmitting(true);
    try {
      const created = await api.createPersona({
        id: id.trim(),
        name: name.trim(),
        description: description.trim() || undefined,
        default_model: defaultModel.trim() || undefined,
        system_prompt: systemPrompt.trim() || undefined,
        skills: Array.from(selectedSkills),
      });
      onCreated(created);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSubmitting(false);
    }
  };

  const totalCount = catalog.length;
  const visibleCount = grouped.reduce((n, [, list]) => n + list.length, 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-[min(720px,94vw)] max-h-[92vh] overflow-auto rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="mb-4 text-lg font-semibold text-[var(--color-card-foreground)]">
          New Persona
        </h2>

        {error && (
          <div className="mb-3 rounded border border-[var(--color-destructive)] bg-[var(--color-destructive)]/10 p-2 text-sm text-[var(--color-destructive)]">
            {error}
          </div>
        )}

        <div className="space-y-3">
          <Field label="ID (slug)">
            <input
              value={id}
              onChange={(e) => setId(e.target.value)}
              placeholder="my-persona"
              className={inputCls}
            />
          </Field>
          <Field label="Name">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My Persona"
              className={inputCls}
            />
          </Field>
          <Field label="Description">
            <input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={inputCls}
            />
          </Field>
          <Field label="Default model">
            <input
              value={defaultModel}
              onChange={(e) => setDefaultModel(e.target.value)}
              placeholder="claude-sonnet-4.6"
              className={inputCls}
            />
          </Field>
          <Field label="System prompt">
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              rows={4}
              className={inputCls}
            />
          </Field>

          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="block text-xs font-medium text-[var(--color-muted-foreground)]">
                Skills ({selectedSkills.size} selected / {visibleCount} shown / {totalCount} total)
              </span>
              <div className="flex gap-2 text-xs">
                <button
                  type="button"
                  onClick={selectAllVisible}
                  className="rounded border border-[var(--color-border)] px-2 py-0.5 hover:bg-[var(--color-muted)]"
                >
                  Select visible
                </button>
                <button
                  type="button"
                  onClick={clearAll}
                  className="rounded border border-[var(--color-border)] px-2 py-0.5 hover:bg-[var(--color-muted)]"
                >
                  Clear
                </button>
              </div>
            </div>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search skills (id, description, category)…"
              className={`${inputCls} mb-2`}
            />
            <div className="max-h-72 overflow-auto rounded border border-[var(--color-border)] p-2">
              {grouped.length === 0 && (
                <div className="text-xs text-[var(--color-muted-foreground)]">
                  No skills match.
                </div>
              )}
              {grouped.map(([cat, list]) => {
                const allSel = list.every((s) => selectedSkills.has(s.id));
                return (
                  <div key={cat} className="mb-3 last:mb-0">
                    <div className="mb-1 flex items-center justify-between border-b border-[var(--color-border)] pb-0.5">
                      <span className="text-xs font-semibold uppercase tracking-wide text-[var(--color-muted-foreground)]">
                        {cat} ({list.length})
                      </span>
                      <button
                        type="button"
                        onClick={() => toggleCategory(list, allSel)}
                        className="text-[10px] text-[var(--color-muted-foreground)] hover:text-[var(--color-card-foreground)]"
                      >
                        {allSel ? "unselect all" : "select all"}
                      </button>
                    </div>
                    {list.map((s) => (
                      <label
                        key={s.id}
                        className="flex cursor-pointer items-start gap-2 py-1 text-sm"
                        title={s.description ?? ""}
                      >
                        <input
                          type="checkbox"
                          checked={selectedSkills.has(s.id)}
                          onChange={() => toggleSkill(s.id)}
                          className="mt-1"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-xs">{s.id}</span>
                            <span className="text-[10px] text-[var(--color-muted-foreground)]">
                              [{s.kind}]
                            </span>
                          </div>
                          {s.description && (
                            <div className="truncate text-[11px] text-[var(--color-muted-foreground)]">
                              {s.description}
                            </div>
                          )}
                        </div>
                      </label>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onClose}
            disabled={submitting}
            className="rounded border border-[var(--color-border)] px-3 py-1.5 text-sm hover:bg-[var(--color-muted)]"
          >
            Cancel
          </button>
          <button
            onClick={submit}
            disabled={submitting}
            className="rounded bg-[var(--color-primary)] px-3 py-1.5 text-sm text-[var(--color-primary-foreground)] hover:opacity-90 disabled:opacity-50"
          >
            {submitting ? "Creating…" : "Create"}
          </button>
        </div>
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded border border-[var(--color-border)] bg-[var(--color-input)] px-2 py-1.5 text-sm text-[var(--color-card-foreground)] focus:outline-none focus:ring-1 focus:ring-[var(--color-ring)]";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-[var(--color-muted-foreground)]">
        {label}
      </span>
      {children}
    </label>
  );
}
