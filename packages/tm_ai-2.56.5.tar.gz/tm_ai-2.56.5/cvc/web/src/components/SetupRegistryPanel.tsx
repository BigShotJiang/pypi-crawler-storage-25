import { useEffect, useState } from "react";
import { CheckCircle2, Circle, Sparkles, Star, Zap, Cpu } from "lucide-react";
import { api } from "@/lib/api";

type Snap = Awaited<ReturnType<typeof api.setupRegistry>>;

const CAT_LABELS: Record<string, string> = {
  core: "Core",
  agent: "Agent",
  hive: "Hive (Core 4 Team)",
  dashboard: "Dashboard",
  mcp: "MCP / IDE",
  integration: "Integrations",
  observability: "Observability",
};

/**
 * Single-source-of-truth overview of every CVC capability.
 *
 * Reads /api/setup/registry — the same blob `cvc setup` consumes — so
 * dashboard, CLI wizard, and voice wizard never drift apart.
 */
export default function SetupRegistryPanel() {
  const [snap, setSnap] = useState<Snap | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const s = await api.setupRegistry();
        if (!cancelled) setSnap(s);
      } catch (e) {
        if (!cancelled) setError(String((e as Error)?.message ?? e));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (error) {
    return (
      <div className="rounded-lg border border-red-900/40 bg-red-950/20 p-4 text-sm text-red-300">
        Failed to load setup registry: {error}
      </div>
    );
  }
  if (!snap) {
    return (
      <div className="rounded-lg border border-zinc-800 bg-zinc-950/40 p-4 text-sm text-zinc-500">
        Loading capabilities…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Providers */}
      <section>
        <header className="mb-3 flex items-center gap-2">
          <Cpu className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold text-zinc-100">
            LLM Providers ({snap.provider_count})
          </h3>
        </header>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {snap.providers.map((p) => (
            <div
              key={p.key}
              className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3 transition hover:border-zinc-700"
            >
              <div className="flex items-center gap-2">
                <span className="font-semibold text-zinc-100">{p.display_name}</span>
                {p.recommended && (
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                )}
                {p.free_tier && (
                  <span className="rounded bg-emerald-900/40 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">
                    FREE
                  </span>
                )}
                {p.local && (
                  <span className="rounded bg-blue-900/40 px-1.5 py-0.5 text-[10px] font-medium text-blue-300">
                    LOCAL
                  </span>
                )}
              </div>
              <p className="mt-1 text-xs text-zinc-400">{p.description}</p>
              {p.default_model && (
                <p className="mt-1 font-mono text-[10px] text-zinc-600">
                  {p.default_model}
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Features grouped by category */}
      <section>
        <header className="mb-3 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold text-zinc-100">
            Capabilities ({snap.feature_count})
          </h3>
          <span className="text-[10px] text-zinc-500">
            <Zap className="mr-1 inline h-3 w-3" />
            All ship installed — toggle on as you use them
          </span>
        </header>
        <div className="space-y-4">
          {snap.feature_categories.map((cat) => {
            const items = snap.features.filter((f) => f.category === cat);
            if (items.length === 0) return null;
            return (
              <div key={cat}>
                <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-emerald-400/80">
                  {CAT_LABELS[cat] ?? cat}
                </div>
                <ul className="space-y-1">
                  {items.map((f) => (
                    <li key={f.key} className="flex items-start gap-2 text-xs">
                      {f.default_enabled ? (
                        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                      ) : (
                        <Circle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-zinc-600" />
                      )}
                      <div>
                        <span className="font-medium text-zinc-200">{f.name}</span>
                        <span className="ml-2 text-zinc-500">{f.description}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
