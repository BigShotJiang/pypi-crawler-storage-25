import { useEffect, useMemo, useState } from "react";
import {
  MessageSquare,
  Plus,
  Trash2,
  Pencil,
  Check,
  X,
  Search,
} from "lucide-react";
import { api } from "@/lib/api";
import type {
  ConversationThread,
  WorkspaceInfo,
} from "@/lib/types";

export interface ChatHistorySidebarProps {
  activeWorkspace: WorkspaceInfo | null;
  activeThreadId: string | null;
  onSelectThread: (threadId: string) => void;
  onNewThread: () => void;
  /** External signal — bump to force a re-fetch (e.g. after appending). */
  refreshKey?: number;
}

type ScopeMode = "current" | "all";

export function ChatHistorySidebar({
  activeWorkspace,
  activeThreadId,
  onSelectThread,
  onNewThread,
  refreshKey = 0,
}: ChatHistorySidebarProps) {
  const [scope, setScope] = useState<ScopeMode>("current");
  const [threads, setThreads] = useState<ConversationThread[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const wsPath = activeWorkspace?.path ?? null;

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const wsParam = scope === "current" && wsPath ? wsPath : undefined;
    api
      .conversations(wsParam, 200)
      .then((list) => {
        if (!cancelled) setThreads(list ?? []);
      })
      .catch(() => {
        if (!cancelled) setThreads([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [scope, wsPath, refreshKey]);

  // Group by workspace for the "All" view.
  const grouped = useMemo(() => {
    if (scope === "current") return null;
    const m = new Map<string, ConversationThread[]>();
    for (const t of threads) {
      const arr = m.get(t.workspace_path) ?? [];
      arr.push(t);
      m.set(t.workspace_path, arr);
    }
    return Array.from(m.entries()).sort(
      (a, b) => b[1][0].updated_at - a[1][0].updated_at,
    );
  }, [scope, threads]);

  const visible = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return threads;
    return threads.filter((t) => t.title.toLowerCase().includes(q));
  }, [filter, threads]);

  async function handleDelete(t: ConversationThread) {
    if (!confirm(`Delete "${t.title}"?`)) return;
    try {
      await api.deleteConversation(t.id);
      setThreads((prev) => prev.filter((x) => x.id !== t.id));
      if (t.id === activeThreadId) onNewThread();
    } catch {
      /* swallow */
    }
  }

  async function commitRename(t: ConversationThread) {
    const title = editTitle.trim();
    setEditingId(null);
    if (!title || title === t.title) return;
    try {
      const updated = await api.renameConversation(t.id, title);
      setThreads((prev) => prev.map((x) => (x.id === t.id ? updated : x)));
    } catch {
      /* swallow */
    }
  }

  function renderRow(t: ConversationThread) {
    const isActive = t.id === activeThreadId;
    const editing = editingId === t.id;
    return (
      <div
        key={t.id}
        className={`group flex items-center gap-2 rounded-md px-2 py-1.5 text-sm cursor-pointer transition-colors ${
          isActive
            ? "bg-noui-panel-2 text-noui-fg"
            : "text-noui-fg-muted hover:bg-noui-panel-2 hover:text-noui-fg"
        }`}
        onClick={() => !editing && onSelectThread(t.id)}
      >
        <MessageSquare className="h-3.5 w-3.5 flex-shrink-0 opacity-70" />
        {editing ? (
          <>
            <input
              autoFocus
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitRename(t);
                else if (e.key === "Escape") setEditingId(null);
              }}
              className="flex-1 bg-transparent outline-none border-b border-noui-accent text-xs"
              onClick={(e) => e.stopPropagation()}
            />
            <button
              className="opacity-70 hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                commitRename(t);
              }}
              aria-label="Save"
            >
              <Check className="h-3 w-3" />
            </button>
            <button
              className="opacity-70 hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                setEditingId(null);
              }}
              aria-label="Cancel"
            >
              <X className="h-3 w-3" />
            </button>
          </>
        ) : (
          <>
            <span className="flex-1 truncate" title={t.title}>
              {t.title}
            </span>
            <span className="text-[10px] text-noui-fg-muted opacity-0 group-hover:opacity-100 flex items-center gap-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setEditTitle(t.title);
                  setEditingId(t.id);
                }}
                aria-label="Rename"
                className="hover:text-noui-fg"
              >
                <Pencil className="h-3 w-3" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(t);
                }}
                aria-label="Delete"
                className="hover:text-noui-danger"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            </span>
          </>
        )}
      </div>
    );
  }

  return (
    <aside className="flex h-full w-64 flex-col border-r border-noui-border bg-noui-panel">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-noui-border">
        <span className="text-xs font-semibold uppercase tracking-wider text-noui-fg-muted">
          History
        </span>
        <button
          onClick={onNewThread}
          className="flex items-center gap-1 rounded-md bg-noui-accent/10 px-2 py-1 text-xs text-noui-accent hover:bg-noui-accent/20"
          aria-label="New conversation"
        >
          <Plus className="h-3 w-3" />
          New
        </button>
      </div>

      {/* Scope toggle */}
      <div className="flex gap-1 px-3 py-2">
        <button
          onClick={() => setScope("current")}
          className={`flex-1 rounded-md px-2 py-1 text-xs ${
            scope === "current"
              ? "bg-noui-accent text-noui-bg"
              : "bg-noui-panel-2 text-noui-fg-muted hover:text-noui-fg"
          }`}
          title={activeWorkspace?.name ?? "Current workspace"}
        >
          {activeWorkspace?.name ?? "Current"}
        </button>
        <button
          onClick={() => setScope("all")}
          className={`flex-1 rounded-md px-2 py-1 text-xs ${
            scope === "all"
              ? "bg-noui-accent text-noui-bg"
              : "bg-noui-panel-2 text-noui-fg-muted hover:text-noui-fg"
          }`}
        >
          All
        </button>
      </div>

      {/* Filter */}
      <div className="px-3 pb-2">
        <div className="flex items-center gap-1.5 rounded-md bg-noui-panel-2 px-2 py-1">
          <Search className="h-3 w-3 text-noui-fg-muted" />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Search…"
            className="w-full bg-transparent text-xs outline-none placeholder:text-noui-fg-muted"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-2 pb-2">
        {loading ? (
          <div className="px-3 py-4 text-xs text-noui-fg-muted">Loading…</div>
        ) : visible.length === 0 ? (
          <div className="px-3 py-4 text-xs text-noui-fg-muted">
            {scope === "current"
              ? "No conversations in this workspace yet."
              : "No conversations yet."}
          </div>
        ) : scope === "current" || filter ? (
          visible.map(renderRow)
        ) : (
          (grouped ?? []).map(([ws, list]) => {
            const wsName = ws.split("/").pop() || ws;
            return (
              <div key={ws} className="mt-2 first:mt-0">
                <div
                  className="px-2 py-1 text-[10px] uppercase tracking-wider text-noui-fg-muted truncate"
                  title={ws}
                >
                  {wsName}
                </div>
                {list.map(renderRow)}
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}
