import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import "highlight.js/styles/github-dark.css";

interface MarkdownProps {
  children: string;
  /** Compact spacing for streaming assistant bubbles. */
  compact?: boolean;
}

/**
 * Polished markdown renderer for chat assistant output.
 *
 * Tightens spacing, gives headings real visual weight, paints bold/code
 * in accent tones, and pipes fenced code through highlight.js so a long
 * model response actually reads like documentation instead of raw `###`
 * + `**` characters.
 */
export function Markdown({ children, compact = false }: MarkdownProps) {
  return (
    <div
      className={
        "chat-md text-[0.92rem] leading-relaxed text-midground" +
        (compact ? " chat-md-compact" : "")
      }
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight]}
        components={{
          h1: (props) => (
            <h1
              className="mt-5 mb-2 text-[1.35rem] font-semibold tracking-tight text-foreground"
              {...props}
            />
          ),
          h2: (props) => (
            <h2
              className="mt-5 mb-2 text-[1.15rem] font-semibold tracking-tight text-foreground"
              {...props}
            />
          ),
          h3: (props) => (
            <h3
              className="mt-4 mb-1.5 text-[1.02rem] font-semibold tracking-tight text-[color:var(--color-warning)]"
              {...props}
            />
          ),
          h4: (props) => (
            <h4
              className="mt-4 mb-1.5 text-[0.95rem] font-semibold text-foreground/90"
              {...props}
            />
          ),
          p: (props) => <p className="my-2 first:mt-0 last:mb-0" {...props} />,
          strong: (props) => (
            <strong className="font-semibold text-foreground" {...props} />
          ),
          em: (props) => <em className="italic text-foreground/95" {...props} />,
          ul: (props) => (
            <ul className="my-2 ml-5 list-disc space-y-1 marker:text-midground/50" {...props} />
          ),
          ol: (props) => (
            <ol className="my-2 ml-5 list-decimal space-y-1 marker:text-midground/50" {...props} />
          ),
          li: (props) => <li className="leading-relaxed" {...props} />,
          a: (props) => (
            <a
              className="text-[color:var(--color-accent,#7aa2f7)] underline decoration-dotted underline-offset-2 hover:opacity-80"
              target="_blank"
              rel="noreferrer noopener"
              {...props}
            />
          ),
          blockquote: (props) => (
            <blockquote
              className="my-3 border-l-2 border-[color:var(--color-border)] pl-3 text-midground/80 italic"
              {...props}
            />
          ),
          hr: () => (
            <hr className="my-4 border-0 border-t border-[color:var(--color-border)]/60" />
          ),
          table: (props) => (
            <div className="my-3 overflow-x-auto rounded-md border border-[color:var(--color-border)]/60">
              <table className="w-full border-collapse text-[0.85rem]" {...props} />
            </div>
          ),
          thead: (props) => (
            <thead className="bg-[color:var(--midground-base)]/10 text-foreground/90" {...props} />
          ),
          th: (props) => (
            <th
              className="px-3 py-1.5 text-left font-semibold border-b border-[color:var(--color-border)]/60"
              {...props}
            />
          ),
          td: (props) => (
            <td
              className="px-3 py-1.5 border-b border-[color:var(--color-border)]/30"
              {...props}
            />
          ),
          code: ({ className, children, ...rest }: any) => {
            const isBlock = !!className;
            if (isBlock) {
              return (
                <code className={className} {...rest}>
                  {children}
                </code>
              );
            }
            return (
              <code
                className="rounded bg-[color:var(--midground-base)]/15 px-1.5 py-0.5 font-mono text-[0.85em] text-[color:var(--color-warning)]"
                {...rest}
              >
                {children}
              </code>
            );
          },
          pre: ({ children }: any) => (
            <pre className="my-3 overflow-x-auto rounded-lg border border-[color:var(--color-border)]/60 bg-black/55 p-3 text-[0.82rem] leading-relaxed">
              {children}
            </pre>
          ),
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
