import { useEffect, useRef, useState } from "react";
import { MessageSquare, Loader2 } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  ChatWS,
  type ChatEvent,
  type ChatMessage,
} from "@/lib/api";
import type {
  ContextMeter as ContextMeterData,
  CurrentModel,
  ModelCatalog,
  PersonaActive,
  PersonaSummary,
  ReasoningEffort,
  WorkspaceInfo,
} from "@/lib/types";
import {
  ComposerBar,
  type ComposerSendOptions,
} from "@/components/composer/ComposerBar";
import { PersonaChip } from "@/components/composer/PersonaChip";
import { PersonaCreateDialog } from "@/components/personas/PersonaCreateDialog";
import { WorkspaceChip } from "@/components/composer/WorkspaceChip";
import { GitBranchChip } from "@/components/composer/GitBranchChip";
import { ModelPicker } from "@/components/composer/ModelPicker";
import { ReasoningChip } from "@/components/composer/ReasoningChip";
import { ContextMeter } from "@/components/composer/ContextMeter";
import { WorkspaceTreePanel } from "@/components/composer/WorkspaceTreePanel";
import { Markdown } from "@/components/chat/Markdown";
import { ChatHistorySidebar } from "@/components/chat/ChatHistorySidebar";

interface DisplayMessage {
  role: "user" | "assistant" | "system";
  content: string;
  pending?: boolean;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [status, setStatus] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  // Composer-bar state
  const [personas, setPersonas] = useState<PersonaSummary[]>([]);
  const [personaDialogOpen, setPersonaDialogOpen] = useState(false);
  const [activePersona, setActivePersona] = useState<PersonaSummary | null>(null);
  const [workspaces, setWorkspaces] = useState<WorkspaceInfo[]>([]);
  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceInfo | null>(null);
  const [catalog, setCatalog] = useState<ModelCatalog | null>(null);
  const [currentModel, setCurrentModel] = useState<CurrentModel>({
    provider: "",
    model: "",
  });
  const [reasoningEffort, setReasoningEffort] = useState<ReasoningEffort>("medium");
  const [contextMeter, setContextMeter] = useState<ContextMeterData | null>(null);
  const [treePanelOpen, setTreePanelOpen] = useState(false);
  const [showHidden, setShowHidden] = useState(false);

  // ── Conversation history (persistent) ──────────────────────────────────
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [historyRefreshKey, setHistoryRefreshKey] = useState(0);
  const pendingAssistantContentRef = useRef<string>("");
  const activeThreadIdRef = useRef<string | null>(null);
  useEffect(() => {
    activeThreadIdRef.current = activeThreadId;
  }, [activeThreadId]);

  const wsRef = useRef<ChatWS | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // ── Initial fetches ─────────────────────────────────────────────────────
  useEffect(() => {
    api.personas().then((r) => setPersonas(r.personas ?? [])).catch(() => {});
    api
      .activePersona()
      .then((a: PersonaActive) => {
        // resolve active id → summary later via personas effect
        setActivePersona((prev) => prev ?? ({ id: a.persona_id } as PersonaSummary));
      })
      .catch(() => {});
    api
      .gatewayWorkspaces()
      .then((r) => {
        const list: WorkspaceInfo[] = (r.workspaces ?? []).map((w) => ({
          workspace_id: w.workspace_id ?? w.id,
          path: w.root_path,
          name: w.name,
        }));
        setWorkspaces(list);
      })
      .catch(() => {});
    api
      .workspaceCurrent()
      .then((w) => setActiveWorkspace(w))
      .catch(() => {});
    api.modelCatalog().then((c) => {
      setCatalog(c);
      if (c.current_provider && c.current_model) {
        setCurrentModel({ provider: c.current_provider, model: c.current_model });
      }
    }).catch(() => {});
    api
      .currentModel()
      .then((m) => {
        if (m?.model) setCurrentModel({ provider: m.provider, model: m.model });
      })
      .catch(() => {});
    api
      .getReasoningEffort()
      .then((r) => r?.effort && setReasoningEffort(r.effort))
      .catch(() => {});
    api.contextMeter().then(setContextMeter).catch(() => {});
  }, []);

  // Resolve activePersona summary once personas list is loaded.
  useEffect(() => {
    if (!activePersona || activePersona.name) return;
    const found = personas.find((p) => p.id === activePersona.id);
    if (found) setActivePersona(found);
  }, [personas, activePersona]);

  // Poll context meter every 2s while not streaming.
  useEffect(() => {
    if (streaming) return;
    const id = setInterval(() => {
      api.contextMeter().then(setContextMeter).catch(() => {});
    }, 2000);
    return () => clearInterval(id);
  }, [streaming]);

  // ── WS bridge ───────────────────────────────────────────────────────────
  useEffect(() => {
    const ws = new ChatWS();
    wsRef.current = ws;

    ws.on("text", (ev: ChatEvent) => {
      const chunk = ev.content ?? "";
      pendingAssistantContentRef.current += chunk;
      setMessages((prev) => {
        const next = [...prev];
        const last = next[next.length - 1];
        if (last && last.role === "assistant" && last.pending) {
          next[next.length - 1] = { ...last, content: last.content + chunk };
        } else {
          next.push({ role: "assistant", content: chunk, pending: true });
        }
        return next;
      });
    });
    ws.on("tool_start", (ev: ChatEvent) => setStatus(`tool: ${ev.name ?? "?"}…`));
    ws.on("tool_result", () => {
      setStatus("");
      api.contextMeter().then(setContextMeter).catch(() => {});
    });
    ws.on("status", (ev: ChatEvent) => setStatus(ev.message ?? ""));
    ws.on("done", () => {
      setStreaming(false);
      setStatus("");
      setMessages((prev) =>
        prev.map((m) => (m.pending ? { ...m, pending: false } : m)),
      );
      api.contextMeter().then(setContextMeter).catch(() => {});

      // Persist the assistant turn to history (best-effort).
      const finalContent = pendingAssistantContentRef.current;
      pendingAssistantContentRef.current = "";
      const tid = activeThreadIdRef.current;
      if (tid && finalContent) {
        api.appendMessage(tid, "assistant", finalContent)
          .then(() => setHistoryRefreshKey((k) => k + 1))
          .catch(() => {});
      }
    });
    ws.on("error", (ev: ChatEvent) => {
      setError(ev.message ?? "stream error");
      setStreaming(false);
      setStatus("");
    });

    ws.connect();
    return () => ws.disconnect();
  }, []);

  // Autoscroll
  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, status]);

  // ── Composer callbacks ──────────────────────────────────────────────────
  function handleSend(text: string, opts: ComposerSendOptions) {
    setError(null);
    const atts = opts.attachments ?? [];
    // Compose a user-visible payload that embeds attachment references so the
    // assistant sees the files in the conversation history. Images with an
    // inline data URL are sent as markdown image syntax so vision-capable
    // models can consume them; everything else is referenced by name + path.
    let composed = text;
    if (atts.length > 0) {
      const lines: string[] = [];
      if (text.trim()) lines.push(text);
      lines.push("");
      lines.push(`📎 Attached ${atts.length} file${atts.length === 1 ? "" : "s"}:`);
      for (const a of atts) {
        if (a.kind === "image" && a.data_url) {
          lines.push(`![${a.name}](${a.data_url})`);
        } else {
          lines.push(`- **${a.name}** (${a.mime}, ${a.size} bytes) → \`${a.rel_path}\``);
        }
      }
      composed = lines.join("\n");
    }
    const userMsg: DisplayMessage = { role: "user", content: composed };
    const history: ChatMessage[] = [...messages, userMsg].map((m) => ({
      role: m.role,
      content: m.content,
    }));
    setMessages((prev) => [...prev, userMsg]);
    setStreaming(true);

    // Persist user turn — create thread on first message of a fresh chat.
    const wsPath = activeWorkspace?.path ?? activeWorkspace?.workspace_id ?? "";
    if (wsPath) {
      if (!activeThreadIdRef.current) {
        api
          .createConversation({
            workspace_path: wsPath,
            persona_id: opts.personaId || undefined,
            first_message: { role: "user", content: composed },
          })
          .then((t) => {
            activeThreadIdRef.current = t.id;
            setActiveThreadId(t.id);
            setHistoryRefreshKey((k) => k + 1);
          })
          .catch(() => {});
      } else {
        api
          .appendMessage(activeThreadIdRef.current, "user", composed)
          .then(() => setHistoryRefreshKey((k) => k + 1))
          .catch(() => {});
      }
    }

    wsRef.current?.send({
      messages: history,
      model: opts.model || undefined,
      provider: opts.provider || undefined,
      persona_id: opts.personaId || undefined,
      reasoning_effort: opts.reasoningEffort,
      workspace_id: opts.workspaceId || undefined,
      attachments: atts.length > 0 ? atts : undefined,
    });
  }

  function handleAbort() {
    wsRef.current?.abort();
    setStreaming(false);
    setStatus("");
  }

  function clearChat() {
    setMessages([]);
    setError(null);
    setActiveThreadId(null);
    activeThreadIdRef.current = null;
    pendingAssistantContentRef.current = "";
  }

  async function handleSelectThread(threadId: string) {
    try {
      const detail = await api.conversation(threadId);
      setMessages(
        detail.messages.map((m) => ({
          role: (m.role === "tool" ? "system" : m.role) as DisplayMessage["role"],
          content: m.content,
        })),
      );
      setActiveThreadId(threadId);
      activeThreadIdRef.current = threadId;
      setError(null);
    } catch {
      /* swallow */
    }
  }

  async function handlePersonaChange(personaId: string) {
    const next = personas.find((p) => p.id === personaId);
    if (next) setActivePersona(next);
    const wsId = activeWorkspace?.workspace_id ?? "";
    try {
      await api.setActivePersona(wsId, personaId);
    } catch {
      /* non-fatal */
    }
  }

  async function handleWorkspaceSwitch(workspaceId: string) {
    try {
      await api.workspaceSwitch(workspaceId);
      const next = workspaces.find(
        (w) => (w.workspace_id ?? w.path ?? w.name) === workspaceId,
      );
      if (next) setActiveWorkspace(next);
    } catch {
      /* non-fatal */
    }
  }

  async function handleModelSwitch(provider: string, model: string) {
    setCurrentModel({ provider, model });
    try {
      await api.switchModel(provider, model);
    } catch {
      /* non-fatal */
    }
  }

  async function handleReasoningChange(effort: ReasoningEffort) {
    setReasoningEffort(effort);
    try {
      await api.setReasoningEffort(effort);
    } catch {
      /* non-fatal */
    }
  }

  const sendOptions: ComposerSendOptions = {
    personaId: activePersona?.id ?? "",
    workspaceId:
      activeWorkspace?.workspace_id ?? activeWorkspace?.path ?? "",
    provider: currentModel.provider,
    model: currentModel.model,
    reasoningEffort,
  };

  return (
    <div className="flex h-full">
      <ChatHistorySidebar
        activeWorkspace={activeWorkspace}
        activeThreadId={activeThreadId}
        onSelectThread={handleSelectThread}
        onNewThread={clearChat}
        refreshKey={historyRefreshKey}
      />
      <div className="mx-auto flex h-full w-full max-w-[1100px] flex-1 flex-col gap-4 px-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <MessageSquare className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Chat
          </Typography>
        </div>
        <button
          type="button"
          onClick={clearChat}
          disabled={messages.length === 0 || streaming}
          className="rounded-md border border-border bg-card/40 px-2.5 py-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/70 hover:bg-card/70 disabled:opacity-40"
        >
          Clear
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-400">
          {error}
        </div>
      )}

      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto rounded-lg border border-border bg-card/30 p-4"
      >
        {messages.length === 0 && !streaming && (
          <div className="flex h-full items-center justify-center text-center text-sm text-midground/55">
            <div>
              <div className="font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/50">
                CVC Chat
              </div>
              <div className="mt-2 text-midground/70">
                Connected to gateway. Send a message to start.
              </div>
            </div>
          </div>
        )}
        <div className="flex flex-col gap-3">
          {messages.map((m, i) => (
            <div
              key={i}
              className={
                m.role === "user"
                  ? "self-end max-w-[85%] rounded-lg border border-border bg-midground/10 px-4 py-2.5 text-sm text-midground"
                  : "self-start max-w-[90%] rounded-lg border border-border bg-card/60 px-4 py-2.5 text-sm text-midground/95"
              }
            >
              <div className="mb-1 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
                {m.role}
                {m.pending && " · streaming"}
              </div>
              {m.role === "assistant" ? (
                <Markdown compact>{m.content || ""}</Markdown>
              ) : (
                <div className="whitespace-pre-wrap break-words">{m.content}</div>
              )}
            </div>
          ))}
          {status && (
            <div className="self-start flex items-center gap-2 rounded-md border border-border bg-card/40 px-3 py-1.5 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/60">
              <Loader2 className="h-3 w-3 animate-spin" />
              {status}
            </div>
          )}
        </div>
      </div>

      <ComposerBar
        sendOptions={sendOptions}
        onSend={handleSend}
        streaming={streaming}
        onAbort={handleAbort}
        personaChip={
          <PersonaChip
            active={activePersona}
            personas={personas}
            onChange={handlePersonaChange}
            liveModel={currentModel.model || null}
            onCreate={() => setPersonaDialogOpen(true)}
          />
        }
        workspaceChip={
          <WorkspaceChip
            active={activeWorkspace}
            workspaces={workspaces}
            onSwitch={handleWorkspaceSwitch}
            onAdded={(ws) => {
              setWorkspaces((prev) => {
                const key = ws.workspace_id ?? ws.path;
                if (prev.some((w) => (w.workspace_id ?? w.path) === key)) return prev;
                return [...prev, ws];
              });
              setActiveWorkspace(ws);
            }}
            onTogglePanel={() => setTreePanelOpen((o) => !o)}
            onOpenPanelFor={async (wsId) => {
              if (wsId && wsId !== (activeWorkspace?.workspace_id ?? activeWorkspace?.path)) {
                await handleWorkspaceSwitch(wsId);
              }
              setTreePanelOpen(true);
            }}
            panelOpen={treePanelOpen}
          />
        }
        gitBranchChip={
          <GitBranchChip
            workspaceKey={
              activeWorkspace?.workspace_id ??
              activeWorkspace?.path ??
              null
            }
          />
        }
        modelChip={
          <ModelPicker
            catalog={catalog}
            current={currentModel}
            onSwitch={handleModelSwitch}
          />
        }
        reasoningChip={
          <ReasoningChip effort={reasoningEffort} onChange={handleReasoningChange} />
        }
        meter={<ContextMeter meter={contextMeter} compact />}
      />

      <WorkspaceTreePanel
        rootPath={activeWorkspace?.path ?? ""}
        open={treePanelOpen}
        onClose={() => setTreePanelOpen(false)}
        showHidden={showHidden}
        onToggleHidden={setShowHidden}
      />
      <PersonaCreateDialog
        open={personaDialogOpen}
        onClose={() => setPersonaDialogOpen(false)}
        onCreated={(p) => {
          setPersonas((prev) => [
            ...prev.filter((x) => x.id !== p.id),
            {
              id: p.id,
              name: p.name,
              description: p.description,
              default_model: p.default_model,
              default_provider: p.default_provider,
              skills_count: Array.isArray(p.skills) ? p.skills.length : 0,
            },
          ]);
        }}
      />
      </div>
    </div>
  );
}
