import { useEffect, useState } from "react";
import { LayoutDashboard } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type CommitSummary,
  type OpsStatus,
  type ServicesResponse,
  type StatsResponse,
  type WorkspaceInfo,
} from "@/lib/api";
import { useDashboardWS } from "@/lib/useDashboardWS";

function ago(ts?: number | string): string {
  if (!ts) return "—";
  const t = typeof ts === "string" ? Date.parse(ts) / 1000 : ts;
  if (!Number.isFinite(t)) return "—";
  const d = Date.now() / 1000 - t;
  if (d < 60) return `${Math.floor(d)}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  return `${Math.floor(d / 86400)}d ago`;
}

export default function OverviewPage() {
  const [opsStatus, setOpsStatus] = useState<OpsStatus | null>(null);
  const [workspace, setWorkspace] = useState<WorkspaceInfo | null>(null);
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [commits, setCommits] = useState<CommitSummary[] | null>(null);
  const [services, setServices] = useState<ServicesResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { lastEvent } = useDashboardWS();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [s, ws, st, cm, sv] = await Promise.all([
          api.opsStatus().catch(() => null),
          api.workspaceCurrent().catch(() => null),
          api.stats().catch(() => null),
          api.commits(5).catch(() => [] as CommitSummary[]),
          api.services().catch(() => null),
        ]);
        if (cancelled) return;
        setOpsStatus(s);
        setWorkspace(ws);
        setStats(st);
        setCommits(Array.isArray(cm) ? cm : []);
        setServices(sv);
        if (!s && !st) setError("Could not reach gateway.");
      } catch (e) {
        if (!cancelled) setError(String((e as Error)?.message ?? e));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [lastEvent]);

  const serviceList = services?.services
    ? Object.entries(services.services)
    : [];

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <LayoutDashboard className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Overview
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-lg border border-border bg-card/40 p-4">
          <div className="text-[0.65rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
            Workspace
          </div>
          <div className="mt-2 truncate text-sm text-midground">
            {workspace?.name ?? workspace?.path ?? "—"}
          </div>
          {workspace?.path && workspace?.name && (
            <div className="mt-0.5 truncate text-xs text-midground/50 font-mono-ui">
              {workspace.path}
            </div>
          )}
          <div className="mt-3 flex items-center gap-2 text-xs text-midground/70">
            <span className="text-[0.65rem] uppercase tracking-wider text-midground/50">
              Branch
            </span>
            <code className="rounded bg-midground/10 px-1.5 py-0.5 font-mono text-[0.7rem] text-midground">
              {opsStatus?.branch ?? "—"}
            </code>
            {opsStatus?.head && (
              <code className="truncate rounded bg-midground/10 px-1.5 py-0.5 font-mono text-[0.7rem] text-midground/70">
                {opsStatus.head.slice(0, 12)}
              </code>
            )}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card/40 p-4">
          <div className="text-[0.65rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
            Stats
          </div>
          <div className="mt-3 grid grid-cols-3 gap-3">
            <div>
              <div className="text-2xl font-bold text-midground tabular-nums">
                {stats?.total_commits ?? 0}
              </div>
              <div className="text-[0.65rem] uppercase tracking-wider text-midground/50">
                Commits
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-midground tabular-nums">
                {stats?.total_branches ?? 0}
              </div>
              <div className="text-[0.65rem] uppercase tracking-wider text-midground/50">
                Branches
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-midground tabular-nums">
                {stats?.total_agents ?? 0}
              </div>
              <div className="text-[0.65rem] uppercase tracking-wider text-midground/50">
                Agents
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card/40 p-4">
          <div className="mb-3 text-[0.65rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
            Recent Commits
          </div>
          {commits && commits.length > 0 ? (
            <div className="flex flex-col gap-2">
              {commits.map((c) => (
                <div
                  key={c.hash}
                  className="flex items-start gap-3 rounded-md border border-border/60 bg-card/30 px-3 py-2"
                >
                  <code className="shrink-0 rounded bg-midground/10 px-1.5 py-0.5 font-mono text-[0.65rem] text-midground/80">
                    {(c.short_hash ?? c.hash ?? "").slice(0, 8)}
                  </code>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs text-midground">
                      {c.message || "(no message)"}
                    </div>
                    <div className="mt-0.5 text-[0.6rem] uppercase tracking-wider text-midground/50">
                      {ago(c.timestamp)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm text-midground/60">No commits yet.</div>
          )}
        </div>

        <div className="rounded-lg border border-border bg-card/40 p-4">
          <div className="mb-3 text-[0.65rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
            Active Services
          </div>
          {serviceList.length > 0 ? (
            <div className="flex flex-col gap-1.5">
              {serviceList.map(([key, svc]) => {
                const isUp = svc.status === "running";
                return (
                  <div
                    key={key}
                    className="flex items-center justify-between rounded-md border border-border/60 bg-card/30 px-3 py-1.5"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2 w-2 rounded-full ${
                          isUp
                            ? "bg-emerald-400"
                            : svc.status === "error"
                              ? "bg-red-400"
                              : "bg-midground/30"
                        }`}
                      />
                      <span className="text-sm text-midground">
                        {svc.name ?? key}
                      </span>
                    </div>
                    <span className="text-[0.65rem] uppercase tracking-wider text-midground/55">
                      {svc.status}
                      {svc.port ? ` · :${svc.port}` : ""}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-sm text-midground/60">
              No services reported.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
