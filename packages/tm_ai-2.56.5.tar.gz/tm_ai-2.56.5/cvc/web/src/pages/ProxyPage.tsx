import { useCallback, useEffect, useMemo, useState } from "react";
import { Server, RefreshCw, Plus } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type GatewayWorkspaceEntry,
  type SessionEntry,
} from "@/lib/api";

function fmtTs(t: string | number | undefined): string {
  if (t == null) return "—";
  const n = typeof t === "string" ? Date.parse(t) : t < 1e12 ? t * 1000 : t;
  if (!Number.isFinite(n)) return String(t);
  return new Date(n).toLocaleString();
}

export default function ProxyPage() {
  const [workspaces, setWorkspaces] = useState<GatewayWorkspaceEntry[]>([]);
  const [sessions, setSessions] = useState<SessionEntry[]>([]);
  const [uptime, setUptime] = useState<string>("—");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlashMsg] = useState<{ kind: "ok" | "err"; msg: string } | null>(
    null,
  );
  const [showRegister, setShowRegister] = useState(false);
  const [regId, setRegId] = useState("");
  const [regName, setRegName] = useState("");
  const [regRoot, setRegRoot] = useState("");

  const showFlash = (kind: "ok" | "err", msg: string) => {
    setFlashMsg({ kind, msg });
    window.setTimeout(() => setFlashMsg(null), 3000);
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [ws, sx, h] = await Promise.all([
        api.gatewayWorkspaces().catch(() => ({ workspaces: [] as GatewayWorkspaceEntry[] })),
        api.sessions().catch(() => ({ sessions: [] as SessionEntry[] })),
        api.health().catch(() => ({ status: "unknown" }) as { status: string; version?: string }),
      ]);
      setWorkspaces(Array.isArray(ws.workspaces) ? ws.workspaces : []);
      const sList = Array.isArray(sx)
        ? (sx as SessionEntry[])
        : Array.isArray((sx as { sessions?: SessionEntry[] }).sessions)
          ? (sx as { sessions: SessionEntry[] }).sessions
          : [];
      setSessions(sList);
      setUptime(
        (h as { version?: string }).version
          ? `v${(h as { version?: string }).version}`
          : (h as { status?: string }).status ?? "—",
      );
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const closeWorkspace = async (id: string) => {
    setBusy(`close:${id}`);
    try {
      await api.workspaceClose(id);
      showFlash("ok", `Closed ${id}`);
      await load();
    } catch (e) {
      showFlash("err", `Error: ${(e as Error)?.message ?? e}`);
    } finally {
      setBusy(null);
    }
  };

  const submitRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regId.trim()) return;
    setBusy("register");
    try {
      await api.gatewayRegisterWorkspace({
        workspace_id: regId.trim(),
        id: regId.trim(),
        name: regName.trim() || regId.trim(),
        root_path: regRoot.trim() || undefined,
      });
      showFlash("ok", `Registered ${regId}`);
      setRegId("");
      setRegName("");
      setRegRoot("");
      setShowRegister(false);
      await load();
    } catch (err) {
      showFlash("err", `Error: ${(err as Error)?.message ?? err}`);
    } finally {
      setBusy(null);
    }
  };

  const stats = useMemo(
    () => ({
      ws: workspaces.length,
      sx: sessions.length,
      up: uptime,
    }),
    [workspaces, sessions, uptime],
  );

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Server className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Proxy
          </Typography>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="inline-flex items-center gap-1 rounded border border-border bg-card/60 px-2.5 py-1.5 text-xs text-midground/80 hover:bg-midground/10 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          {error}
        </div>
      )}
      {flash && (
        <div
          className={`text-xs ${flash.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flash.msg}
        </div>
      )}

      {/* Top stats */}
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Workspaces" value={String(stats.ws)} />
        <Stat label="Sessions" value={String(stats.sx)} />
        <Stat label="Gateway" value={stats.up} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Workspaces */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <Typography variant="sm" compressed className="text-midground/70">
              Workspaces
            </Typography>
            <button
              type="button"
              onClick={() => setShowRegister((v) => !v)}
              className="inline-flex items-center gap-1 rounded-md bg-[var(--accent,#ef4444)] px-3 py-1.5 text-[0.65rem] font-semibold uppercase tracking-wider text-white hover:opacity-90"
            >
              <Plus className="h-3 w-3" /> Register
            </button>
          </div>

          {showRegister && (
            <form
              onSubmit={submitRegister}
              className="flex flex-col gap-2 rounded-lg border border-border bg-card/40 p-3"
            >
              <input
                value={regId}
                onChange={(e) => setRegId(e.target.value)}
                placeholder="workspace_id (required)"
                className="rounded border border-border bg-card/60 px-2 py-1.5 text-sm text-midground"
              />
              <input
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="name"
                className="rounded border border-border bg-card/60 px-2 py-1.5 text-sm text-midground"
              />
              <input
                value={regRoot}
                onChange={(e) => setRegRoot(e.target.value)}
                placeholder="/absolute/root_path"
                className="rounded border border-border bg-card/60 px-2 py-1.5 text-sm text-midground"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={busy === "register"}
                  className="rounded border border-border bg-midground/10 px-3 py-1.5 text-xs uppercase tracking-wider text-midground hover:bg-midground/20 disabled:opacity-50"
                >
                  Submit
                </button>
                <button
                  type="button"
                  onClick={() => setShowRegister(false)}
                  className="rounded border border-border bg-card/60 px-3 py-1.5 text-xs uppercase tracking-wider text-midground/70 hover:bg-midground/10"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {workspaces.length === 0 ? (
            <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/55">
              No workspaces registered.
            </div>
          ) : (
            <ul className="flex flex-col gap-2">
              {workspaces.map((w) => {
                const id = w.workspace_id ?? w.id ?? "";
                return (
                  <li
                    key={id}
                    className="flex flex-col gap-2 rounded-lg border border-border bg-card/40 p-3"
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <div className="font-mono text-xs text-midground/85">{id}</div>
                      <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55">
                        {w.status ?? "—"}
                      </span>
                    </div>
                    <div className="text-xs text-midground/70">{w.name ?? "—"}</div>
                    <div className="flex items-center justify-between gap-2 text-[0.7rem] text-midground/55">
                      <span>last seen {fmtTs(w.last_seen)}</span>
                      <button
                        type="button"
                        disabled={busy === `close:${id}`}
                        onClick={() => closeWorkspace(id)}
                        className="rounded border border-border bg-card/60 px-2 py-1 text-[0.65rem] uppercase tracking-wider text-midground/80 hover:bg-midground/10 disabled:opacity-50"
                      >
                        Close
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* Sessions */}
        <section className="flex flex-col gap-3">
          <Typography variant="sm" compressed className="text-midground/70">
            Active Sessions
          </Typography>
          {sessions.length === 0 ? (
            <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/55">
              No active sessions.
            </div>
          ) : (
            <ul className="flex flex-col gap-2">
              {sessions.map((s, i) => {
                const id = s.id ?? s.session_id ?? `#${i + 1}`;
                return (
                  <li
                    key={id}
                    className="flex flex-col gap-1 rounded-lg border border-border bg-card/40 p-3"
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <div className="font-mono text-xs text-midground/85">{id}</div>
                      <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55">
                        {s.model ?? s.provider ?? "—"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2 text-[0.7rem] text-midground/55">
                      <span>started {fmtTs(s.started_at)}</span>
                      <span>{s.message_count ?? 0} msgs</span>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
        {label}
      </div>
      <div className="mt-1.5 text-2xl font-bold text-midground tabular-nums">
        {value}
      </div>
    </div>
  );
}
