import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  api,
  type AgentFromPromptResponse,
  type AgentTemplate,
  type AgentsListResponse,
  type CommitEntry,
  type HiveMindAgent,
  type SquadInfo,
} from "@/lib/api";

// ── style tokens (per dossier) ────────────────────────────────────────────
const CARD = "rounded-xl border border-white/10 bg-white/5 p-5";
const SECTION_TITLE =
  "text-xs font-semibold uppercase tracking-[0.2em] text-white/60";
const PRIMARY_BTN =
  "inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50";
const SUBTLE_BTN =
  "rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5 disabled:opacity-50";
const DANGER_BTN =
  "rounded-md border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-xs uppercase tracking-wider text-red-300 hover:bg-red-500/20 disabled:opacity-50";
const INPUT =
  "w-full rounded-md border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-[var(--accent)]";
const LABEL = "block text-[0.65rem] uppercase tracking-[0.18em] text-white/55";

const RANKS = ["private", "corporal", "sergeant", "commander"] as const;
const TIERS = ["full", "standard", "readonly", "minimal"] as const;

type SubTab = "manual" | "prompt" | "template" | "squad";

interface ManualForm {
  agent_id: string;
  name: string;
  description: string;
  role: string;
  rank: string;
  squad: string;
  tool_tier: string;
  system_prompt: string;
}

const EMPTY_MANUAL: ManualForm = {
  agent_id: "",
  name: "",
  description: "",
  role: "",
  rank: "private",
  squad: "none",
  tool_tier: "standard",
  system_prompt: "",
};

type FlashKind = "ok" | "err" | null;
interface Flash {
  kind: FlashKind;
  text: string;
}

function templateToManual(t: AgentTemplate): ManualForm {
  return {
    agent_id: t.id ?? "",
    name: t.name ?? "",
    description: t.description ?? "",
    role: (t as { role?: string }).role ?? "",
    rank: t.rank ?? "private",
    squad: t.squad ?? "none",
    tool_tier: t.tool_tier ?? "standard",
    system_prompt: t.system_prompt ?? "",
  };
}

function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}

function asArray<T>(v: T[] | { [k: string]: unknown } | null | undefined, key: string): T[] {
  if (Array.isArray(v)) return v;
  if (v && typeof v === "object") {
    const inner = (v as Record<string, unknown>)[key];
    if (Array.isArray(inner)) return inner as T[];
  }
  return [];
}

export default function AgentsPage() {
  // tabs + data
  const [tab, setTab] = useState<SubTab>("manual");
  const [list, setList] = useState<AgentsListResponse | null>(null);
  const [builtins, setBuiltins] = useState<AgentTemplate[]>([]);
  const [hiveAgents, setHiveAgents] = useState<HiveMindAgent[]>([]);
  const [squads, setSquads] = useState<SquadInfo[]>([]);
  const [flash, setFlash] = useState<Flash>({ kind: null, text: "" });
  const [busy, setBusy] = useState(false);

  // manual form
  const [manual, setManual] = useState<ManualForm>(EMPTY_MANUAL);
  const [manualErr, setManualErr] = useState<string | null>(null);

  // prompt form
  const [prompt, setPrompt] = useState("");
  const [preview, setPreview] = useState<AgentTemplate | null>(null);
  const [promptErr, setPromptErr] = useState<string | null>(null);

  // squad form
  const [squadName, setSquadName] = useState("");
  const [squadDesc, setSquadDesc] = useState("");
  const [squadAgents, setSquadAgents] = useState<Set<string>>(new Set());
  const [squadErr, setSquadErr] = useState<string | null>(null);

  // history modal
  const [historyFor, setHistoryFor] = useState<string | null>(null);
  const [historyEntries, setHistoryEntries] = useState<CommitEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const setOk = useCallback((text: string) => {
    setFlash({ kind: "ok", text });
    window.setTimeout(() => setFlash({ kind: null, text: "" }), 3000);
  }, []);
  const setErr = useCallback((text: string) => {
    setFlash({ kind: "err", text });
    window.setTimeout(() => setFlash({ kind: null, text: "" }), 4000);
  }, []);

  const refreshAll = useCallback(async () => {
    try {
      const [l, b, ha, sq] = await Promise.all([
        api.agentsList().catch(() => null),
        api.agentsBuiltin().catch(() => [] as AgentTemplate[]),
        api
          .hivemindAgents()
          .catch(() => [] as HiveMindAgent[])
          .then((r) => asArray<HiveMindAgent>(r, "agents")),
        api.squadList().catch(() => [] as SquadInfo[]),
      ]);
      setList(l);
      setBuiltins(Array.isArray(b) ? b : []);
      setHiveAgents(ha);
      setSquads(sq);
    } catch (e) {
      setErr(errMsg(e));
    }
  }, [setErr]);

  useEffect(() => {
    void refreshAll();
  }, [refreshAll]);

  // ── derived ─────────────────────────────────────────
  const squadOptions = useMemo<string[]>(() => {
    const s = new Set<string>(["none"]);
    for (const sq of squads) if (sq.name) s.add(sq.name);
    return Array.from(s);
  }, [squads]);

  const allAgentChoices = useMemo<{ id: string; label: string }[]>(() => {
    const seen = new Map<string, string>();
    for (const a of hiveAgents) {
      if (a.agent_id && !seen.has(a.agent_id)) seen.set(a.agent_id, a.name ?? a.agent_id);
    }
    for (const t of list?.templates ?? []) {
      if (t.id && !seen.has(t.id)) seen.set(t.id, t.name ?? t.id);
    }
    return Array.from(seen, ([id, label]) => ({ id, label }));
  }, [hiveAgents, list]);

  // ── handlers: manual ────────────────────────────────
  async function onCreateManual(e: FormEvent) {
    e.preventDefault();
    setManualErr(null);
    if (!manual.agent_id.trim()) {
      setManualErr("Agent ID is required");
      return;
    }
    setBusy(true);
    try {
      const payload: Partial<AgentTemplate> & { role?: string } = {
        id: manual.agent_id.trim(),
        name: manual.name.trim() || manual.agent_id.trim(),
        description: manual.description.trim(),
        system_prompt: manual.system_prompt.trim(),
        rank: manual.rank,
        tool_tier: manual.tool_tier,
        squad: manual.squad === "none" ? "" : manual.squad,
        role: manual.role.trim() || undefined,
      };
      await api.agentCreate(payload);
      setManual(EMPTY_MANUAL);
      setOk(`Created ${payload.name ?? payload.id}`);
      await refreshAll();
    } catch (err) {
      setManualErr(errMsg(err));
      setErr(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  // ── handlers: prompt ────────────────────────────────
  async function onGenerateFromPrompt(e: FormEvent) {
    e.preventDefault();
    setPromptErr(null);
    if (!prompt.trim()) {
      setPromptErr("Describe the agent first");
      return;
    }
    setBusy(true);
    try {
      const r: AgentFromPromptResponse = await api.agentFromPrompt(prompt.trim());
      setPreview(r.template);
    } catch (err) {
      setPromptErr(errMsg(err));
      setErr(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  async function onConfirmPreview() {
    if (!preview) return;
    setBusy(true);
    try {
      await api.agentCreate(preview);
      setOk(`Created ${preview.name ?? preview.id}`);
      setPreview(null);
      setPrompt("");
      await refreshAll();
    } catch (err) {
      setPromptErr(errMsg(err));
      setErr(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  function onPrefillFromPreview() {
    if (!preview) return;
    setManual(templateToManual(preview));
    setTab("manual");
  }

  // ── handlers: template ──────────────────────────────
  function onUseTemplate(t: AgentTemplate) {
    setManual(templateToManual(t));
    setTab("manual");
    setOk(`Loaded template "${t.name ?? t.id}"`);
  }

  // ── handlers: squad ─────────────────────────────────
  async function onCreateSquad(e: FormEvent) {
    e.preventDefault();
    setSquadErr(null);
    if (!squadName.trim()) {
      setSquadErr("Squad name required");
      return;
    }
    setBusy(true);
    try {
      await api.squadCreate(squadName.trim(), Array.from(squadAgents));
      setOk(`Squad "${squadName.trim()}" created`);
      setSquadName("");
      setSquadDesc("");
      setSquadAgents(new Set());
      await refreshAll();
    } catch (err) {
      setSquadErr(errMsg(err));
      setErr(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  function toggleSquadAgent(id: string) {
    setSquadAgents((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  // ── handlers: existing agents table ─────────────────
  async function onDeleteAgent(id: string) {
    if (!window.confirm(`Delete agent ${id}?`)) return;
    setBusy(true);
    try {
      await api.agentDelete(id);
      setOk(`Deleted ${id}`);
      await refreshAll();
    } catch (err) {
      setErr(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  async function onShowHistory(id: string) {
    setHistoryFor(id);
    setHistoryEntries([]);
    setHistoryLoading(true);
    try {
      const h = await api.agentHistory(id);
      setHistoryEntries(Array.isArray(h) ? h : []);
    } catch (err) {
      setErr(errMsg(err));
    } finally {
      setHistoryLoading(false);
    }
  }

  // ── existing agents merged view ─────────────────────
  const existingRows = useMemo(() => {
    const byId = new Map<
      string,
      { id: string; name: string; role: string; rank: string; squad: string }
    >();
    for (const t of list?.templates ?? []) {
      byId.set(t.id, {
        id: t.id,
        name: t.name ?? "—",
        role: (t as { role?: string }).role ?? t.description ?? "—",
        rank: t.rank ?? "private",
        squad: t.squad ?? "—",
      });
    }
    for (const a of hiveAgents) {
      if (!a.agent_id) continue;
      const existing = byId.get(a.agent_id);
      byId.set(a.agent_id, {
        id: a.agent_id,
        name: a.name ?? existing?.name ?? "—",
        role: a.role ?? existing?.role ?? "—",
        rank: a.rank ?? existing?.rank ?? "private",
        squad: a.squad ?? existing?.squad ?? "—",
      });
    }
    return Array.from(byId.values());
  }, [list, hiveAgents]);

  // ── render ──────────────────────────────────────────
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className={SECTION_TITLE}>Agents</h1>
        {flash.kind && (
          <div
            className={`text-xs ${
              flash.kind === "ok" ? "text-emerald-400" : "text-red-400"
            }`}
          >
            {flash.text}
          </div>
        )}
      </div>

      {/* Sub-tab strip */}
      <div className="flex gap-2">
        {([
          ["manual", "Manual"],
          ["prompt", "From Prompt"],
          ["template", "From Template"],
          ["squad", "Squad"],
        ] as const).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={
              tab === key
                ? "rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white"
                : SUBTLE_BTN
            }
          >
            {label}
          </button>
        ))}
      </div>

      {/* Forms */}
      <section className={CARD}>
        {tab === "manual" && (
          <form onSubmit={onCreateManual} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Field label="Agent ID *">
              <input
                className={INPUT}
                value={manual.agent_id}
                onChange={(e) => setManual({ ...manual, agent_id: e.target.value })}
                required
              />
            </Field>
            <Field label="Name">
              <input
                className={INPUT}
                value={manual.name}
                onChange={(e) => setManual({ ...manual, name: e.target.value })}
              />
            </Field>
            <Field label="Role">
              <input
                className={INPUT}
                value={manual.role}
                onChange={(e) => setManual({ ...manual, role: e.target.value })}
              />
            </Field>
            <Field label="Rank">
              <select
                className={INPUT}
                value={manual.rank}
                onChange={(e) => setManual({ ...manual, rank: e.target.value })}
              >
                {RANKS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Squad">
              <select
                className={INPUT}
                value={squadOptions.includes(manual.squad) ? manual.squad : "none"}
                onChange={(e) => setManual({ ...manual, squad: e.target.value })}
              >
                {squadOptions.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Tool Tier">
              <select
                className={INPUT}
                value={manual.tool_tier}
                onChange={(e) => setManual({ ...manual, tool_tier: e.target.value })}
              >
                {TIERS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </Field>
            <div className="sm:col-span-2">
              <Field label="System Prompt">
                <textarea
                  className={`${INPUT} min-h-[140px] font-mono`}
                  value={manual.system_prompt}
                  onChange={(e) => setManual({ ...manual, system_prompt: e.target.value })}
                  rows={6}
                />
              </Field>
            </div>
            <div className="sm:col-span-2 flex items-center justify-between">
              {manualErr ? (
                <span className="text-xs text-red-400">{manualErr}</span>
              ) : (
                <span />
              )}
              <button type="submit" className={PRIMARY_BTN} disabled={busy}>
                Create
              </button>
            </div>
          </form>
        )}

        {tab === "prompt" && (
          <div className="flex flex-col gap-3">
            <form onSubmit={onGenerateFromPrompt} className="flex flex-col gap-3">
              <Field label="Describe the agent">
                <textarea
                  className={`${INPUT} min-h-[120px]`}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={5}
                  placeholder="A senior security reviewer that audits Python code for OWASP top-10 issues..."
                />
              </Field>
              <div className="flex items-center justify-between">
                {promptErr ? (
                  <span className="text-xs text-red-400">{promptErr}</span>
                ) : (
                  <span />
                )}
                <button type="submit" className={PRIMARY_BTN} disabled={busy}>
                  Generate
                </button>
              </div>
            </form>

            {preview && (
              <div className="rounded-lg border border-white/10 bg-black/30 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-white">{preview.name}</div>
                    <div className="font-mono text-[0.65rem] text-white/55">{preview.id}</div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {preview.tool_tier && (
                      <Tag color="blue">{preview.tool_tier}</Tag>
                    )}
                    {preview.rank && <Tag color="green">{preview.rank}</Tag>}
                    {preview.squad && <Tag>{preview.squad}</Tag>}
                  </div>
                </div>
                {preview.description && (
                  <p className="mt-2 text-xs text-white/70">{preview.description}</p>
                )}
                {preview.system_prompt && (
                  <pre className="mt-3 max-h-56 overflow-auto whitespace-pre-wrap rounded bg-black/40 p-3 font-mono text-[0.7rem] text-white/80">
                    {preview.system_prompt}
                  </pre>
                )}
                <div className="mt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    className={SUBTLE_BTN}
                    onClick={onPrefillFromPreview}
                    disabled={busy}
                  >
                    Prefill Manual Form
                  </button>
                  <button
                    type="button"
                    className={PRIMARY_BTN}
                    onClick={onConfirmPreview}
                    disabled={busy}
                  >
                    Confirm Create
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "template" && (
          <div className="flex flex-col gap-3">
            <h2 className={SECTION_TITLE}>Built-in templates</h2>
            {builtins.length === 0 ? (
              <p className="text-xs text-white/55">No built-in templates available.</p>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {builtins.map((t) => (
                  <div
                    key={t.id}
                    className="flex flex-col gap-2 rounded-lg border border-white/10 bg-black/20 p-4"
                  >
                    <div className="text-sm font-semibold text-white">{t.name}</div>
                    <div className="font-mono text-[0.65rem] text-white/55">{t.id}</div>
                    {t.description && (
                      <div className="text-xs text-white/70 line-clamp-3">{t.description}</div>
                    )}
                    <div className="flex flex-wrap gap-1.5">
                      {t.tool_tier && <Tag color="blue">{t.tool_tier}</Tag>}
                      {t.rank && <Tag color="green">{t.rank}</Tag>}
                      {t.squad && <Tag>{t.squad}</Tag>}
                    </div>
                    <div className="mt-auto flex justify-end">
                      <button
                        type="button"
                        className={PRIMARY_BTN}
                        onClick={() => onUseTemplate(t)}
                      >
                        Use
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "squad" && (
          <form onSubmit={onCreateSquad} className="flex flex-col gap-3">
            <Field label="Squad name *">
              <input
                className={INPUT}
                value={squadName}
                onChange={(e) => setSquadName(e.target.value)}
                required
              />
            </Field>
            <Field label="Description">
              <textarea
                className={`${INPUT} min-h-[80px]`}
                value={squadDesc}
                onChange={(e) => setSquadDesc(e.target.value)}
                rows={3}
              />
            </Field>
            <Field label="Members">
              {allAgentChoices.length === 0 ? (
                <p className="text-xs text-white/55">No agents available yet.</p>
              ) : (
                <div className="grid max-h-60 grid-cols-1 gap-1 overflow-auto rounded-md border border-white/10 bg-black/30 p-3 sm:grid-cols-2">
                  {allAgentChoices.map((a) => (
                    <label
                      key={a.id}
                      className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 text-xs text-white/80 hover:bg-white/5"
                    >
                      <input
                        type="checkbox"
                        checked={squadAgents.has(a.id)}
                        onChange={() => toggleSquadAgent(a.id)}
                      />
                      <span className="truncate">
                        <span className="text-white">{a.label}</span>
                        <span className="ml-2 font-mono text-[0.6rem] text-white/45">
                          {a.id}
                        </span>
                      </span>
                    </label>
                  ))}
                </div>
              )}
            </Field>
            <div className="flex items-center justify-between">
              {squadErr ? (
                <span className="text-xs text-red-400">{squadErr}</span>
              ) : (
                <span />
              )}
              <button type="submit" className={PRIMARY_BTN} disabled={busy}>
                Create Squad
              </button>
            </div>
          </form>
        )}
      </section>

      {/* Existing agents table */}
      <section className={CARD}>
        <div className="mb-3 flex items-center justify-between">
          <h2 className={SECTION_TITLE}>Existing agents</h2>
          <span className="text-[0.65rem] uppercase tracking-wider text-white/45">
            {existingRows.length} total
          </span>
        </div>
        {existingRows.length === 0 ? (
          <p className="text-xs text-white/55">No agents registered.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="text-[0.65rem] uppercase tracking-wider text-white/55">
                  <th className="border-b border-white/10 px-3 py-2">ID</th>
                  <th className="border-b border-white/10 px-3 py-2">Name</th>
                  <th className="border-b border-white/10 px-3 py-2">Role</th>
                  <th className="border-b border-white/10 px-3 py-2">Rank</th>
                  <th className="border-b border-white/10 px-3 py-2">Squad</th>
                  <th className="border-b border-white/10 px-3 py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {existingRows.map((row) => (
                  <tr key={row.id} className="hover:bg-white/5">
                    <td className="border-b border-white/5 px-3 py-2 font-mono text-xs text-white/80">
                      {row.id}
                    </td>
                    <td className="border-b border-white/5 px-3 py-2 text-white">{row.name}</td>
                    <td className="border-b border-white/5 px-3 py-2 text-white/70">
                      {row.role}
                    </td>
                    <td className="border-b border-white/5 px-3 py-2">
                      <Tag>{row.rank}</Tag>
                    </td>
                    <td className="border-b border-white/5 px-3 py-2">
                      <Tag color="blue">{row.squad}</Tag>
                    </td>
                    <td className="border-b border-white/5 px-3 py-2 text-right">
                      <div className="inline-flex gap-2">
                        <button
                          type="button"
                          className={SUBTLE_BTN}
                          onClick={() => onShowHistory(row.id)}
                        >
                          History
                        </button>
                        <button
                          type="button"
                          className={DANGER_BTN}
                          onClick={() => onDeleteAgent(row.id)}
                          disabled={busy}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Squads list */}
      <section className={CARD}>
        <div className="mb-3 flex items-center justify-between">
          <h2 className={SECTION_TITLE}>Squads</h2>
          <span className="text-[0.65rem] uppercase tracking-wider text-white/45">
            {squads.length} total
          </span>
        </div>
        {squads.length === 0 ? (
          <p className="text-xs text-white/55">No squads configured.</p>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {squads.map((s) => (
              <div key={s.name} className="rounded-lg border border-white/10 bg-black/20 p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-white">{s.name}</div>
                  <Tag color="blue">
                    {s.agent_count} agent{s.agent_count !== 1 ? "s" : ""}
                  </Tag>
                </div>
                {s.branch && (
                  <div className="mt-1 font-mono text-[0.65rem] text-white/55">
                    branch: {s.branch}
                  </div>
                )}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {s.agents.map((a, idx) => {
                    const id =
                      (a as { agent_id?: string; id?: string }).agent_id ??
                      (a as { id?: string }).id ??
                      String(a);
                    return <Tag key={`${id}-${idx}`}>{id}</Tag>;
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* History modal */}
      {historyFor && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6"
          onClick={() => setHistoryFor(null)}
        >
          <div
            className="flex max-h-[80vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-white/10 bg-[#1a1a1a] p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className={SECTION_TITLE}>History</div>
                <div className="font-mono text-xs text-white/70">{historyFor}</div>
              </div>
              <button
                type="button"
                className={SUBTLE_BTN}
                onClick={() => setHistoryFor(null)}
              >
                Close
              </button>
            </div>
            <div className="flex-1 overflow-auto">
              {historyLoading ? (
                <p className="text-xs text-white/55">Loading…</p>
              ) : historyEntries.length === 0 ? (
                <p className="text-xs text-white/55">No history.</p>
              ) : (
                <ul className="flex flex-col gap-2">
                  {historyEntries.map((c) => (
                    <li
                      key={c.hash}
                      className="rounded border border-white/10 bg-black/30 px-3 py-2"
                    >
                      <div className="flex items-center gap-2">
                        <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[0.65rem] text-white/80">
                          {(c.short_hash ?? c.hash ?? "").slice(0, 12)}
                        </code>
                        <span className="truncate text-xs text-white">{c.message}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── small helpers ─────────────────────────────────────
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className={LABEL}>{label}</label>
      {children}
    </div>
  );
}

function Tag({
  children,
  color,
}: {
  children: React.ReactNode;
  color?: "blue" | "green";
}) {
  const cls =
    color === "blue"
      ? "border-sky-400/30 bg-sky-400/10 text-sky-200"
      : color === "green"
        ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-200"
        : "border-white/15 bg-white/5 text-white/75";
  return (
    <span
      className={`inline-flex items-center rounded border px-1.5 py-0.5 font-mono text-[0.6rem] uppercase tracking-wider ${cls}`}
    >
      {children}
    </span>
  );
}
