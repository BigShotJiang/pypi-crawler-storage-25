import { useEffect, useState } from "react";
import { GitBranch } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type BranchSummary } from "@/lib/api";

export default function BranchesPage() {
  const [branches, setBranches] = useState<BranchSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .opsBranches()
      .then((r) => {
        if (cancelled) return;
        const arr = Array.isArray(r) ? r.map((n) => ({ name: n, head: "", status: "" })) : (r.branches ?? []);
        setBranches(arr);
      })
      .catch((e) => !cancelled && setError(String(e?.message ?? e)));
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <GitBranch className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Branches
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}

      {branches && branches.length === 0 && !error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          No branches yet.
        </div>
      )}

      {branches && branches.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border bg-card/40">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-midground/5">
              <tr className="text-[0.65rem] uppercase tracking-wider text-midground/55">
                <th className="px-4 py-2 font-medium">Name</th>
                <th className="px-4 py-2 font-medium">Head</th>
                <th className="px-4 py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {branches.map((b) => (
                <tr
                  key={b.name}
                  className="border-b border-border/40 last:border-b-0 hover:bg-midground/5"
                >
                  <td className="px-4 py-2.5 text-midground">{b.name}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-midground/70">
                    {b.head}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-midground/60">
                    {b.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
