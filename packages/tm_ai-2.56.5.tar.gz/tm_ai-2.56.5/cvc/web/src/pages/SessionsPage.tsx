import { useEffect, useState } from "react";
import { Activity } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type OpsStatus, type WorkspaceInfo } from "@/lib/api";

export default function SessionsPage() {
  const [status, setStatus] = useState<OpsStatus | null>(null);
  const [ws, setWs] = useState<WorkspaceInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      api.opsStatus().catch(() => null),
      api.workspaceCurrent().catch(() => null),
    ]).then(([s, w]) => {
      if (cancelled) return;
      if (!s && !w) setError("Gateway unreachable.");
      setStatus(s);
      setWs(w);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <Activity className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Sessions
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          {error} <code>cvc gateway start</code>?
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label="Workspace" value={ws?.name ?? ws?.path ?? "—"} />
        <Field label="Workspace ID" value={ws?.workspace_id ?? "—"} mono />
        <Field label="Active branch" value={status?.branch ?? "—"} />
        <Field
          label="HEAD"
          value={status?.head ? status.head.slice(0, 12) : "—"}
          mono
        />
        <Field
          label="Total commits"
          value={status?.total_commits != null ? String(status.total_commits) : "—"}
        />
      </div>
    </div>
  );
}

function Field({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
        {label}
      </div>
      <div
        className={`mt-1.5 text-sm text-midground ${mono ? "font-mono text-xs" : ""}`}
      >
        {value}
      </div>
    </div>
  );
}
