import { useEffect, useState } from "react";
import { GitBranch, History, Activity, Sparkles, Wifi, WifiOff } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api } from "@/lib/api";
import { useDashboardWS } from "@/lib/useDashboardWS";

interface StatCardProps {
  label: string;
  value: string;
  hint?: string;
  icon: React.ComponentType<{ className?: string }>;
}

function StatCard({ label, value, hint, icon: Icon }: StatCardProps) {
  return (
    <div className="relative overflow-hidden rounded-lg border border-border bg-card p-5 shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.08)]">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="text-[0.7rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
            {label}
          </div>
          <div className="mt-2 text-3xl font-bold text-midground tabular-nums">
            {value}
          </div>
          {hint && <div className="mt-1 text-xs text-midground/50">{hint}</div>}
        </div>
        <Icon className="h-4 w-4 shrink-0 text-midground/40" />
      </div>
    </div>
  );
}

export default function HomePage() {
  const [connected, setConnected] = useState(false);
  const [stats, setStats] = useState<{
    branches: number;
    commits: number;
    workspace: string;
  } | null>(null);
  const { status: wsStatus, lastEvent } = useDashboardWS();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [analytics, ws] = await Promise.all([
          api.analytics(),
          api.workspaceCurrent().catch(() => ({} as { name?: string })),
        ]);
        if (cancelled) return;
        setConnected(true);
        setStats({
          branches: analytics.branches?.length ?? 0,
          commits: analytics.commits?.total ?? 0,
          workspace: ws.name ?? "—",
        });
      } catch {
        if (!cancelled) setConnected(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [lastEvent]); // refetch when a live event arrives

  const wsBadge =
    wsStatus === "open" ? (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[0.65rem] font-medium uppercase tracking-wider text-emerald-300">
        <Wifi className="h-3 w-3" /> Live
      </span>
    ) : (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-current/15 bg-midground/5 px-2.5 py-0.5 text-[0.65rem] font-medium uppercase tracking-wider text-midground/55">
        <WifiOff className="h-3 w-3" /> {wsStatus}
      </span>
    );

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8">
      <div className="flex items-start gap-4">
        <div
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.5)]"
          style={{
            background:
              "linear-gradient(135deg, var(--midground-base) 0%, color-mix(in srgb, var(--midground-base) 60%, var(--background-base)) 100%)",
          }}
        >
          <Sparkles className="h-5 w-5 text-background-base" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <Typography variant="md" compressed className="text-midground">
              Cognitive Version Control
            </Typography>
            {wsBadge}
          </div>
          <p className="mt-1 max-w-2xl text-sm text-midground/65">
            A Merkle-DAG of your AI conversations. Branch, merge, restore, and
            replay every cognitive turn.
            {stats?.workspace && stats.workspace !== "—" && (
              <>
                {" "}
                Workspace:{" "}
                <code className="rounded bg-midground/10 px-1.5 py-0.5 text-xs text-midground">
                  {stats.workspace}
                </code>
              </>
            )}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Sessions"
          value={connected ? "1" : "—"}
          hint={connected ? "this workspace" : "connect gateway"}
          icon={Activity}
        />
        <StatCard
          label="Branches"
          value={connected ? String(stats?.branches ?? 0) : "—"}
          hint={connected ? "active" : "connect gateway"}
          icon={GitBranch}
        />
        <StatCard
          label="Commits"
          value={connected ? String(stats?.commits ?? 0) : "—"}
          hint={connected ? "total" : "connect gateway"}
          icon={History}
        />
        <StatCard
          label="Tokens saved"
          value="—"
          hint="via COGNOME"
          icon={Sparkles}
        />
      </div>

      {!connected && (
        <div className="rounded-lg border border-border bg-card/60 p-6">
          <Typography variant="sm" compressed className="text-midground uppercase">
            Gateway not connected
          </Typography>
          <p className="mt-2 text-sm text-midground/65">
            The CVC gateway isn't reachable at{" "}
            <code className="rounded bg-midground/10 px-1.5 py-0.5 text-xs text-midground">
              /api
            </code>
            . Start it with{" "}
            <code className="rounded bg-midground/10 px-1.5 py-0.5 text-xs text-midground">
              cvc gateway start
            </code>{" "}
            to populate this dashboard.
          </p>
        </div>
      )}
    </div>
  );
}
