import { useEffect, useRef, useState } from "react";
import { Activity, Gauge } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type LoopConfig, type LoopSnapshot } from "@/lib/api";

function pct(used: number, max: number): number {
  if (!max) return 0;
  return Math.min(100, Math.round((used / max) * 100));
}

export default function LoopPage() {
  const [snap, setSnap] = useState<LoopSnapshot | null>(null);
  const [cfg, setCfg] = useState<LoopConfig | null>(null);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const [s, c] = await Promise.all([api.loopState(), api.loopConfig()]);
        if (cancelled) return;
        setSnap(s);
        setCfg(c);
        setError(null);
      } catch (e) {
        if (!cancelled) setError(String((e as Error)?.message ?? e));
      }
    };
    load();

    try {
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      const url = `${proto}://${window.location.host}/ws/loop`;
      const ws = new WebSocket(url);
      wsRef.current = ws;
      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg?.event === "loop.snapshot" && msg.data) {
            setSnap(msg.data as LoopSnapshot);
          }
        } catch {
          /* ignore */
        }
      };
      ws.onerror = () => {
        /* fallback to polling */
      };
    } catch {
      /* ignore */
    }

    const id = setInterval(load, 5000);
    return () => {
      cancelled = true;
      clearInterval(id);
      wsRef.current?.close();
    };
  }, []);

  const b = snap?.budget;
  const g = snap?.guardrails;
  const c = snap?.compressor;
  const r = snap?.recorder;
  const usedPct = b ? pct(b.used, b.max) : 0;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <Activity className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Agentic Loop
        </Typography>
      </div>

      {error && (
        <div className="rounded-md border border-rose-400/40 bg-rose-500/10 px-3 py-2 font-mono-ui text-xs text-rose-300">
          {error}
        </div>
      )}

      {/* Budget */}
      <section className="rounded-md border border-border bg-card/40 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Gauge className="h-4 w-4 text-midground/70" />
          <Typography variant="sm" compressed className="text-midground">
            Iteration budget {b?.active ? "(live)" : "(idle)"}
          </Typography>
        </div>
        <div className="font-mono-ui text-xs text-midground/70">
          {b?.used ?? 0} / {b?.max ?? 0} used · {b?.remaining ?? 0} remaining
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded bg-background/60">
          <div
            className={`h-full ${
              usedPct > 85
                ? "bg-rose-400"
                : usedPct > 60
                  ? "bg-amber-400"
                  : "bg-emerald-400"
            }`}
            style={{ width: `${usedPct}%` }}
          />
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Card title="Guardrails">
          <Row label="Active" value={String(g?.active ?? false)} />
          <Row label="Calls / turn" value={`${g?.calls_this_turn ?? 0}`} />
          <Row label="Max identical" value={`${g?.max_identical_per_turn ?? "-"}`} />
          <Row label="Max total" value={`${g?.max_total_per_turn ?? "-"}`} />
        </Card>
        <Card title="Compression">
          <Row label="Active" value={String(c?.active ?? false)} />
          <Row label="Trigger" value={`${c?.trigger_tokens ?? "-"} tok`} />
          <Row label="Keep recent" value={`${c?.keep_recent ?? "-"}`} />
          <Row label="Target ratio" value={`${c?.target_ratio ?? "-"}`} />
        </Card>
        <Card title="Trajectory">
          <Row label="Active" value={String(r?.active ?? false)} />
          <Row label="Enabled" value={String(r?.enabled ?? false)} />
          <Row label="Path" value={r?.path ?? "—"} mono />
        </Card>
      </div>

      {cfg && (
        <section className="rounded-md border border-border bg-card/40 p-4">
          <Typography variant="sm" compressed className="mb-2 text-midground">
            Defaults
          </Typography>
          <pre className="overflow-x-auto font-mono-ui text-[0.7rem] text-midground/70">
            {JSON.stringify(cfg, null, 2)}
          </pre>
        </section>
      )}
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-border bg-card/40 p-4">
      <Typography variant="sm" compressed className="mb-2 text-midground">
        {title}
      </Typography>
      <div className="flex flex-col gap-1 font-mono-ui text-xs">{children}</div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-midground/60">{label}</span>
      <span className={mono ? "truncate text-midground/80" : "text-midground"}>
        {value}
      </span>
    </div>
  );
}
