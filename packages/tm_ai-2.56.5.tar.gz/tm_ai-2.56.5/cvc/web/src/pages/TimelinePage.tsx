import { useEffect, useMemo, useState } from "react";
import { GitCommitVertical } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type TimelineEntry } from "@/lib/api";
import { useDashboardWS } from "@/lib/useDashboardWS";

function toMs(ts: number | string | undefined): number {
  if (!ts) return 0;
  if (typeof ts === "number") return ts < 1e12 ? ts * 1000 : ts;
  const n = Date.parse(ts);
  return Number.isFinite(n) ? n : 0;
}

function bucketOf(ts: number | string | undefined): "Today" | "Yesterday" | "Older" {
  const t = toMs(ts);
  if (!t) return "Older";
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startYesterday = startToday - 86400_000;
  if (t >= startToday) return "Today";
  if (t >= startYesterday) return "Yesterday";
  return "Older";
}

function formatTime(ts: number | string | undefined): string {
  const t = toMs(ts);
  if (!t) return "—";
  return new Date(t).toLocaleString();
}

export default function TimelinePage() {
  const [entries, setEntries] = useState<TimelineEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { lastEvent } = useDashboardWS();

  useEffect(() => {
    let cancelled = false;
    api
      .opsTimeline(50)
      .then((r) => {
        if (cancelled) return;
        const arr = Array.isArray(r) ? r : (r.entries ?? []);
        setEntries(arr);
      })
      .catch((e) => !cancelled && setError(String(e?.message ?? e)));
    return () => {
      cancelled = true;
    };
  }, [lastEvent]);

  const grouped = useMemo(() => {
    const out: Record<"Today" | "Yesterday" | "Older", TimelineEntry[]> = {
      Today: [],
      Yesterday: [],
      Older: [],
    };
    for (const e of entries ?? []) out[bucketOf(e.timestamp)].push(e);
    return out;
  }, [entries]);

  const order: Array<"Today" | "Yesterday" | "Older"> = ["Today", "Yesterday", "Older"];

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <GitCommitVertical className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Timeline
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}

      {entries && entries.length === 0 && !error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Timeline is empty.
        </div>
      )}

      {entries && entries.length > 0 && (
        <div className="flex flex-col gap-6">
          {order.map((label) => {
            const group = grouped[label];
            if (!group.length) return null;
            return (
              <div key={label} className="flex flex-col gap-3">
                <div className="text-[0.65rem] font-medium uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
                  {label}
                </div>
                <div className="relative ml-3 border-l border-border pl-5">
                  <div className="flex flex-col gap-3">
                    {group.map((e) => (
                      <div key={e.hash} className="relative">
                        <span className="absolute -left-[1.6rem] top-2 h-2.5 w-2.5 rounded-full border border-border bg-card" />
                        <div className="rounded-lg border border-border bg-card/40 px-4 py-3 hover:bg-card/70">
                          <div className="flex items-start gap-3">
                            <code className="shrink-0 rounded bg-midground/10 px-2 py-0.5 font-mono text-[0.7rem] text-midground/80">
                              {e.hash.slice(0, 12)}
                            </code>
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-sm text-midground">
                                {e.message || "(no message)"}
                              </div>
                              <div className="mt-0.5 flex items-center gap-3 text-[0.65rem] uppercase tracking-wider text-midground/50">
                                {e.commit_type && <span>{e.commit_type}</span>}
                                {e.branch && <span>· {e.branch}</span>}
                                <span>· {formatTime(e.timestamp)}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
