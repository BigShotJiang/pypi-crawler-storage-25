/**
 * SettingsPage — multi-section settings parity with old dashboard.
 *
 * Sections (collapsible cards):
 *   - Provider & Model (schema-driven)
 *   - Agent Behavior   (schema-driven)
 *   - Permissions      (allow/deny tag lists)
 *   - Environment      (key/value rows, PUT /settings/env)
 *   - Hooks            (grouped by event, add/remove)
 *   - Plugins          (toggle list, schema-driven names)
 *   - Audit            (recent /audit table)
 *   - Advanced         (schema-driven misc)
 *   - API Keys         (separate card; per-provider edit/delete/test)
 *
 * Top: level tabs [GLOBAL] [PROJECT] [LOCAL] driving GET/PUT /api/settings/{level}.
 * Top: search filter that hides field labels not matching the substring.
 * Footer: Save / Discard / Reset-all.
 */

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { ChevronDown, ChevronRight, Settings as SettingsIcon } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type AuditEntry,
  type SettingsField,
  type SettingsSchema,
  type SettingsSection,
} from "@/lib/api";

type Level = "global" | "project" | "local";
const LEVELS: Level[] = ["global", "project", "local"];

const SECTION_ORDER = [
  "provider",
  "agent",
  "permissions",
  "env",
  "hooks",
  "plugins",
  "audit",
  "advanced",
] as const;

const SECTION_TITLES: Record<string, string> = {
  provider: "Provider & Model",
  agent: "Agent Behavior",
  permissions: "Agent Permissions",
  env: "Environment",
  hooks: "Hooks",
  plugins: "Plugins",
  audit: "Audit Log",
  advanced: "Advanced",
};

// ── helpers ───────────────────────────────────────────────────────────────

function isOptionObject(
  o: unknown,
): o is { value: string; label: string; desc?: string } {
  return typeof o === "object" && o !== null && "value" in o;
}

function fmtTime(t: string | number | undefined): string {
  if (t == null) return "—";
  const n = typeof t === "number" ? t : Date.parse(String(t));
  if (!Number.isFinite(n)) return String(t);
  const d = new Date(n < 1e12 ? n * 1000 : n);
  return d.toISOString().replace("T", " ").slice(0, 19);
}

// ── small visual primitives ───────────────────────────────────────────────

function CardSection({
  title,
  icon,
  defaultOpen = true,
  children,
  hidden,
}: {
  title: string;
  icon?: string;
  defaultOpen?: boolean;
  children: ReactNode;
  hidden?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  if (hidden) return null;
  return (
    <div className="rounded-xl border border-white/10 bg-white/5">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-5 py-3 text-left"
      >
        <span className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-white/70">
          {icon && <span aria-hidden>{icon}</span>}
          {title}
        </span>
        {open ? (
          <ChevronDown className="h-4 w-4 text-white/50" />
        ) : (
          <ChevronRight className="h-4 w-4 text-white/50" />
        )}
      </button>
      {open && <div className="border-t border-white/10 p-5">{children}</div>}
    </div>
  );
}

function inputCls() {
  return "w-full rounded-md border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-[var(--accent)]";
}
function btnPrimary() {
  return "inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50";
}
function btnSubtle() {
  return "rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5 disabled:opacity-50";
}

// ── schema field renderer ────────────────────────────────────────────────

interface FieldInputProps {
  field: SettingsField;
  value: unknown;
  onChange: (v: unknown) => void;
}

function FieldInput({ field, value, onChange }: FieldInputProps) {
  switch (field.type) {
    case "toggle":
      return (
        <label className="inline-flex items-center gap-2 text-sm text-white/80">
          <input
            type="checkbox"
            checked={Boolean(value)}
            onChange={(e) => onChange(e.target.checked)}
          />
          {Boolean(value) ? "On" : "Off"}
        </label>
      );
    case "number":
    case "slider":
      return (
        <input
          type="number"
          value={value == null ? "" : Number(value as number)}
          min={field.min}
          max={field.max}
          step={field.step}
          onChange={(e) =>
            onChange(e.target.value === "" ? null : Number(e.target.value))
          }
          className={inputCls()}
        />
      );
    case "password":
      return (
        <input
          type="password"
          value={value == null ? "" : String(value)}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
          className={inputCls()}
        />
      );
    case "select":
    case "model_select":
    case "radio": {
      const opts = field.options ?? [];
      return (
        <select
          value={value == null ? "" : String(value)}
          onChange={(e) => onChange(e.target.value)}
          className={inputCls()}
        >
          <option value="">—</option>
          {opts.map((o) => {
            const ov = isOptionObject(o) ? o.value : String(o);
            const ol = isOptionObject(o) ? o.label : String(o);
            return (
              <option key={ov} value={ov}>
                {ol}
              </option>
            );
          })}
        </select>
      );
    }
    case "tag_list": {
      const arr = Array.isArray(value) ? (value as unknown[]).map(String) : [];
      return (
        <input
          type="text"
          value={arr.join(", ")}
          placeholder="tag1, tag2"
          onChange={(e) =>
            onChange(
              e.target.value
                .split(",")
                .map((t) => t.trim())
                .filter(Boolean),
            )
          }
          className={inputCls()}
        />
      );
    }
    case "text":
    default:
      // long string → textarea
      if (typeof value === "string" && value.length > 80) {
        return (
          <textarea
            value={String(value ?? "")}
            onChange={(e) => onChange(e.target.value)}
            placeholder={field.placeholder}
            rows={4}
            className={inputCls()}
          />
        );
      }
      return (
        <input
          type="text"
          value={value == null ? "" : String(value)}
          onChange={(e) => onChange(e.target.value)}
          placeholder={field.placeholder}
          className={inputCls()}
        />
      );
  }
}

// ── Schema-driven fields renderer (for a section + level) ─────────────────

function SchemaFields({
  fields,
  state,
  onField,
  filter,
}: {
  fields: SettingsField[];
  state: Record<string, unknown>;
  onField: (key: string, v: unknown) => void;
  filter: string;
}) {
  if (!fields.length) {
    return <div className="text-sm text-white/55">No fields.</div>;
  }
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {fields.map((f) => {
        const label = f.label || f.key;
        if (filter && !label.toLowerCase().includes(filter)) return null;
        return (
          <label key={f.key} className="flex flex-col gap-1 text-xs text-white/70">
            <span className="text-white/85">{label}</span>
            <FieldInput
              field={f}
              value={state[f.key]}
              onChange={(v) => onField(f.key, v)}
            />
            {f.description && (
              <span className="text-[0.65rem] text-white/45">
                {f.description}
              </span>
            )}
          </label>
        );
      })}
    </div>
  );
}

// ── API Keys card ─────────────────────────────────────────────────────────

interface ApiKeysCardProps {
  keys: Record<string, string>;
  onChanged: () => void;
  flash: (msg: string, kind?: "ok" | "err") => void;
}

const KNOWN_PROVIDERS = ["anthropic", "openai", "google", "openrouter", "groq", "deepseek"];

function ApiKeysCard({ keys, onChanged, flash }: ApiKeysCardProps) {
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [tested, setTested] = useState<Record<string, "ok" | "err" | null>>({});
  const [busy, setBusy] = useState(false);

  const providers = useMemo(() => {
    const merged = new Set<string>(KNOWN_PROVIDERS);
    for (const k of Object.keys(keys)) merged.add(k);
    return [...merged].sort();
  }, [keys]);

  const setVal = (p: string, v: string) =>
    setEditing((s) => ({ ...s, [p]: v }));

  const save = async (p: string) => {
    const v = editing[p];
    if (!v) return;
    setBusy(true);
    try {
      await api.setApiKey(p, v);
      flash(`Saved ${p} key.`, "ok");
      setEditing((s) => {
        const { [p]: _omit, ...rest } = s;
        return rest;
      });
      onChanged();
    } catch (e) {
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const remove = async (p: string) => {
    if (!confirm(`Delete ${p} API key?`)) return;
    setBusy(true);
    try {
      await api.removeApiKey(p);
      flash(`Removed ${p}.`, "ok");
      onChanged();
    } catch (e) {
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const test = async (p: string) => {
    setBusy(true);
    try {
      const r = await api.testApiKey(p);
      const ok = String((r as unknown as { status?: string }).status ?? "ok") === "ok";
      setTested((s) => ({ ...s, [p]: ok ? "ok" : "err" }));
      flash(`${p}: ${ok ? "OK" : "FAIL"}`, ok ? "ok" : "err");
    } catch (e) {
      setTested((s) => ({ ...s, [p]: "err" }));
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <CardSection title="API Keys" icon="🔑">
      <div className="overflow-hidden rounded border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-white/10 bg-white/5">
            <tr className="text-[0.65rem] uppercase tracking-wider text-white/55">
              <th className="px-3 py-2 font-medium">Provider</th>
              <th className="px-3 py-2 font-medium">Key</th>
              <th className="px-3 py-2 font-medium">Status</th>
              <th className="px-3 py-2 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {providers.map((p) => {
              const has = !!keys[p];
              const masked = has ? "••••••••" : "";
              const editVal = editing[p];
              const t = tested[p];
              return (
                <tr key={p} className="border-b border-white/5 last:border-b-0">
                  <td className="px-3 py-2 font-mono text-xs text-white/85">{p}</td>
                  <td className="px-3 py-2">
                    <input
                      type="password"
                      value={editVal ?? masked}
                      placeholder="sk-…"
                      onChange={(e) => setVal(p, e.target.value)}
                      className={inputCls()}
                    />
                  </td>
                  <td className="px-3 py-2">
                    {has ? (
                      <span className="inline-flex items-center gap-1 rounded bg-emerald-500/15 px-2 py-0.5 text-[0.6rem] uppercase tracking-wider text-emerald-300">
                        ● set
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded bg-white/10 px-2 py-0.5 text-[0.6rem] uppercase tracking-wider text-white/55">
                        ○ empty
                      </span>
                    )}
                    {t === "ok" && (
                      <span className="ml-2 text-[0.6rem] uppercase tracking-wider text-emerald-300">
                        ✓ test ok
                      </span>
                    )}
                    {t === "err" && (
                      <span className="ml-2 text-[0.6rem] uppercase tracking-wider text-red-300">
                        ✗ fail
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <div className="inline-flex gap-1">
                      <button
                        type="button"
                        disabled={busy || !editVal}
                        onClick={() => save(p)}
                        className={btnSubtle()}
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        disabled={busy || !has}
                        onClick={() => test(p)}
                        className={btnSubtle()}
                      >
                        Test
                      </button>
                      <button
                        type="button"
                        disabled={busy || !has}
                        onClick={() => remove(p)}
                        className={btnSubtle()}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </CardSection>
  );
}

// ── Permissions card ──────────────────────────────────────────────────────

function PermissionsCard({
  state,
  onField,
  filter,
}: {
  state: Record<string, unknown>;
  onField: (key: string, v: unknown) => void;
  filter: string;
}) {
  const allow = Array.isArray(state.permission_allow)
    ? (state.permission_allow as unknown[]).map(String)
    : Array.isArray((state.permissions as { allow?: unknown[] } | undefined)?.allow)
      ? ((state.permissions as { allow: unknown[] }).allow.map(String))
      : [];
  const deny = Array.isArray(state.permission_deny)
    ? (state.permission_deny as unknown[]).map(String)
    : Array.isArray((state.permissions as { deny?: unknown[] } | undefined)?.deny)
      ? ((state.permissions as { deny: unknown[] }).deny.map(String))
      : [];

  const updateAt = (which: "allow" | "deny", arr: string[]) => {
    onField(which === "allow" ? "permission_allow" : "permission_deny", arr);
  };

  const renderList = (label: string, key: "allow" | "deny", arr: string[]) => {
    if (filter && !label.toLowerCase().includes(filter)) return null;
    return (
      <div>
        <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-white/70">
          {label}
        </div>
        <div className="flex flex-col gap-2">
          {arr.map((row, i) => (
            <div key={`${key}-${i}`} className="flex gap-2">
              <input
                type="text"
                value={row}
                onChange={(e) => {
                  const next = arr.slice();
                  next[i] = e.target.value;
                  updateAt(key, next);
                }}
                placeholder="tool/pattern"
                className={inputCls()}
              />
              <button
                type="button"
                onClick={() => updateAt(key, arr.filter((_, j) => j !== i))}
                className={btnSubtle()}
              >
                Remove
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => updateAt(key, [...arr, ""])}
            className={btnSubtle()}
          >
            + Add row
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
      {renderList("Allow patterns", "allow", allow)}
      {renderList("Deny patterns", "deny", deny)}
    </div>
  );
}

// ── Env vars card ─────────────────────────────────────────────────────────

function EnvVarsCard({
  envVars,
  onChanged,
  flash,
  filter,
}: {
  envVars: Record<string, string>;
  onChanged: () => void;
  flash: (msg: string, kind?: "ok" | "err") => void;
  filter: string;
}) {
  const [rows, setRows] = useState<Array<{ k: string; v: string }>>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setRows(Object.entries(envVars).map(([k, v]) => ({ k, v })));
  }, [envVars]);

  const save = async () => {
    const dict: Record<string, string> = {};
    for (const r of rows) {
      if (r.k.trim()) dict[r.k.trim()] = r.v;
    }
    setBusy(true);
    try {
      await api.setEnvVars(dict);
      flash("Saved environment vars.", "ok");
      onChanged();
    } catch (e) {
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const visible = filter
    ? rows.filter(
        (r) =>
          r.k.toLowerCase().includes(filter) || r.v.toLowerCase().includes(filter),
      )
    : rows;

  return (
    <div className="flex flex-col gap-2">
      {visible.length === 0 ? (
        <div className="text-sm text-white/55">No environment variables.</div>
      ) : (
        visible.map((row, i) => {
          const realIdx = rows.indexOf(row);
          return (
            <div key={i} className="flex gap-2">
              <input
                type="text"
                value={row.k}
                placeholder="KEY"
                onChange={(e) => {
                  const next = rows.slice();
                  next[realIdx] = { ...next[realIdx], k: e.target.value };
                  setRows(next);
                }}
                className={inputCls()}
              />
              <input
                type="text"
                value={row.v}
                placeholder="value"
                onChange={(e) => {
                  const next = rows.slice();
                  next[realIdx] = { ...next[realIdx], v: e.target.value };
                  setRows(next);
                }}
                className={inputCls()}
              />
              <button
                type="button"
                onClick={() => setRows(rows.filter((_, j) => j !== realIdx))}
                className={btnSubtle()}
              >
                Remove
              </button>
            </div>
          );
        })
      )}
      <div className="flex gap-2 pt-2">
        <button
          type="button"
          onClick={() => setRows([...rows, { k: "", v: "" }])}
          className={btnSubtle()}
        >
          + Add variable
        </button>
        <button type="button" onClick={save} disabled={busy} className={btnPrimary()}>
          Save env
        </button>
      </div>
    </div>
  );
}

// ── Hooks card ────────────────────────────────────────────────────────────

function HooksCard({
  hooks,
  onChanged,
  flash,
  filter,
}: {
  hooks: Record<string, unknown[]>;
  onChanged: () => void;
  flash: (msg: string, kind?: "ok" | "err") => void;
  filter: string;
}) {
  const [showForm, setShowForm] = useState(false);
  const [evt, setEvt] = useState("PreToolUse");
  const [cmd, setCmd] = useState("");
  const [busy, setBusy] = useState(false);

  const events = [
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "Notification",
    "Stop",
    "SubagentStop",
    "SessionEnd",
  ];

  const add = async (e: FormEvent) => {
    e.preventDefault();
    if (!evt.trim() || !cmd.trim()) return;
    setBusy(true);
    try {
      await api.addHook(evt.trim(), cmd.trim());
      flash("Hook added.", "ok");
      setCmd("");
      setShowForm(false);
      onChanged();
    } catch (err) {
      flash(`Error: ${(err as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const remove = async (event: string, idx: number) => {
    if (!confirm(`Delete hook #${idx} for ${event}?`)) return;
    setBusy(true);
    try {
      await api.removeHook(event, idx);
      flash("Hook removed.", "ok");
      onChanged();
    } catch (err) {
      flash(`Error: ${(err as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const entries = Object.entries(hooks).filter(([event]) =>
    filter ? event.toLowerCase().includes(filter) : true,
  );

  return (
    <div className="flex flex-col gap-3">
      {entries.length === 0 ? (
        <div className="text-sm text-white/55">No hooks configured.</div>
      ) : (
        entries.map(([event, cmds]) => (
          <div key={event} className="rounded-md border border-white/10 bg-white/5 p-3">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-white/80">
              {event}
            </div>
            <ul className="flex flex-col gap-1.5">
              {(Array.isArray(cmds) ? cmds : []).map((c, i) => {
                const cmdStr =
                  typeof c === "string"
                    ? c
                    : typeof c === "object" && c !== null && "command" in c
                      ? String((c as { command: unknown }).command)
                      : JSON.stringify(c);
                return (
                  <li
                    key={i}
                    className="flex items-center gap-2 rounded bg-black/30 px-2 py-1.5"
                  >
                    <code className="flex-1 truncate font-mono text-xs text-white/80">
                      {cmdStr}
                    </code>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => remove(event, i)}
                      className={btnSubtle()}
                    >
                      Delete
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))
      )}
      {!showForm ? (
        <button
          type="button"
          onClick={() => setShowForm(true)}
          className={btnPrimary()}
        >
          + Add Hook
        </button>
      ) : (
        <form
          onSubmit={add}
          className="flex flex-col gap-2 rounded-md border border-white/10 bg-black/20 p-3"
        >
          <label className="flex flex-col gap-1 text-xs text-white/70">
            Event
            <select
              value={evt}
              onChange={(e) => setEvt(e.target.value)}
              className={inputCls()}
            >
              {events.map((ev) => (
                <option key={ev} value={ev}>
                  {ev}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1 text-xs text-white/70">
            Command
            <textarea
              value={cmd}
              onChange={(e) => setCmd(e.target.value)}
              placeholder="echo hello"
              rows={3}
              className={inputCls()}
            />
          </label>
          <div className="flex gap-2">
            <button type="submit" disabled={busy} className={btnPrimary()}>
              Add
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className={btnSubtle()}
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

// ── Plugins card (schema-driven names + toggle) ───────────────────────────

function PluginsCard({
  schema,
  state,
  onField,
  filter,
}: {
  schema: SettingsSchema | null;
  state: Record<string, unknown>;
  onField: (key: string, v: unknown) => void;
  filter: string;
}) {
  // Look for any plugin_toggles field in schema; fall back to state.enabledPlugins
  const pluginField =
    schema?.sections
      ?.flatMap((s) => s.fields ?? [])
      ?.find((f) => f.type === "plugin_toggles") ?? null;

  const enabledPlugins =
    (state.enabledPlugins as Record<string, boolean> | undefined) ??
    (state.enabled_plugins as Record<string, boolean> | undefined) ??
    {};

  const names = pluginField?.options
    ? pluginField.options.map((o) => (isOptionObject(o) ? o.value : String(o)))
    : Object.keys(enabledPlugins);

  if (!names.length) {
    return <div className="text-sm text-white/55">No plugins available.</div>;
  }

  const visible = filter
    ? names.filter((n) => n.toLowerCase().includes(filter))
    : names;

  return (
    <div className="flex flex-col gap-2">
      {visible.map((name) => {
        const checked = Boolean(enabledPlugins[name]);
        return (
          <label
            key={name}
            className="flex items-center justify-between rounded border border-white/10 bg-black/20 px-3 py-2 text-sm text-white/85"
          >
            <span className="font-mono text-xs">{name}</span>
            <input
              type="checkbox"
              checked={checked}
              onChange={(e) => {
                const next = { ...enabledPlugins, [name]: e.target.checked };
                onField("enabledPlugins", next);
              }}
            />
          </label>
        );
      })}
    </div>
  );
}

// ── Audit card ────────────────────────────────────────────────────────────

function AuditCard({ entries }: { entries: AuditEntry[] }) {
  if (!entries.length) {
    return <div className="text-sm text-white/55">No audit entries.</div>;
  }
  return (
    <div className="overflow-hidden rounded border border-white/10">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-white/10 bg-white/5">
          <tr className="text-[0.65rem] uppercase tracking-wider text-white/55">
            <th className="px-3 py-2 font-medium">Time</th>
            <th className="px-3 py-2 font-medium">Event</th>
            <th className="px-3 py-2 font-medium">Target</th>
            <th className="px-3 py-2 font-medium">Details</th>
          </tr>
        </thead>
        <tbody>
          {entries.slice(0, 50).map((e, i) => {
            const time = (e.timestamp ?? (e as Record<string, unknown>).created_at) as
              | string
              | number
              | undefined;
            const action =
              (e.action as string | undefined) ??
              ((e as Record<string, unknown>).event_type as string | undefined) ??
              "—";
            const target =
              ((e as Record<string, unknown>).target as string | undefined) ??
              ((e as Record<string, unknown>).resource as string | undefined) ??
              "—";
            const details =
              e.details ??
              (typeof (e as Record<string, unknown>).action_detail === "object"
                ? JSON.stringify((e as Record<string, unknown>).action_detail)
                : ((e as Record<string, unknown>).action_detail as string | undefined)) ??
              "";
            return (
              <tr key={i} className="border-b border-white/5 last:border-b-0">
                <td className="px-3 py-2 font-mono text-xs text-white/65">
                  {fmtTime(time)}
                </td>
                <td className="px-3 py-2 font-mono text-xs text-white/85">{action}</td>
                <td className="px-3 py-2 font-mono text-xs text-white/65">{target}</td>
                <td className="px-3 py-2 text-xs text-white/65 break-all">
                  {String(details ?? "")}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────

export default function SettingsPage() {
  const [level, setLevel] = useState<Level>("global");
  const [schema, setSchema] = useState<SettingsSchema | null>(null);
  const [originalForm, setOriginalForm] = useState<Record<string, unknown>>({});
  const [formState, setFormState] = useState<Record<string, unknown>>({});
  const [hooks, setHooks] = useState<Record<string, unknown[]>>({});
  const [envVars, setEnvVars] = useState<Record<string, string>>({});
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [flashMsg, setFlashMsg] = useState<{ msg: string; kind: "ok" | "err" } | null>(
    null,
  );

  const flash = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    setFlashMsg({ msg, kind });
    setTimeout(() => setFlashMsg(null), 3000);
  }, []);

  const loadSchema = useCallback(async () => {
    try {
      const sch = await api.settingsSchema();
      setSchema(sch);
    } catch {
      setSchema(null);
    }
  }, []);

  const loadLevel = useCallback(async (lv: Level) => {
    try {
      const data = await api.settingsLevel(lv).catch(async () => {
        // fallback to monolithic /settings response
        const all = await api.settings();
        if (lv === "global") return (all.global as unknown as Record<string, unknown>) ?? {};
        if (lv === "project") return (all.project as unknown as Record<string, unknown>) ?? {};
        const dyn = all as unknown as Record<string, unknown>;
        return (dyn["local"] as Record<string, unknown> | undefined) ?? {};
      });
      const obj = (data ?? {}) as Record<string, unknown>;
      setOriginalForm(obj);
      setFormState(obj);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  }, []);

  const loadAux = useCallback(async () => {
    const [hk, env, keys, au] = await Promise.all([
      api.hooks().catch(() => ({}) as Record<string, unknown[]>),
      api.envVars().catch(() => ({}) as Record<string, string>),
      api.apiKeys().catch(() => ({}) as Record<string, string>),
      api.audit(50).catch(() => [] as AuditEntry[]),
    ]);
    setHooks(hk);
    setEnvVars(env);
    setApiKeys(keys);
    const arr = Array.isArray(au)
      ? au
      : ((au as { entries?: AuditEntry[] }).entries ?? []);
    setAudit(arr);
  }, []);

  useEffect(() => {
    loadSchema();
    loadAux();
  }, [loadSchema, loadAux]);

  useEffect(() => {
    loadLevel(level);
  }, [level, loadLevel]);

  const setField = (key: string, v: unknown) =>
    setFormState((p) => ({ ...p, [key]: v }));

  const dirty = useMemo(() => {
    try {
      return JSON.stringify(formState) !== JSON.stringify(originalForm);
    } catch {
      return true;
    }
  }, [formState, originalForm]);

  const save = async () => {
    setBusy(true);
    try {
      await api.settingsUpdate(level, formState);
      flash(`Saved ${level} settings.`, "ok");
      await loadLevel(level);
    } catch (e) {
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  const discard = () => {
    setFormState(originalForm);
    flash("Discarded local changes.", "ok");
  };

  const resetAll = async () => {
    if (!confirm(`Reset ALL ${level} settings to defaults?`)) return;
    setBusy(true);
    try {
      await api.settingsReset(level);
      flash(`Reset ${level} settings.`, "ok");
      await loadLevel(level);
    } catch (e) {
      flash(`Error: ${(e as Error).message}`, "err");
    } finally {
      setBusy(false);
    }
  };

  // ── partition schema fields by section + level ────────────────────────
  const sectionsByKey = useMemo(() => {
    const map: Record<string, SettingsSection> = {};
    for (const s of schema?.sections ?? []) {
      map[s.id] = s;
    }
    return map;
  }, [schema]);

  const fieldsForSection = (id: string): SettingsField[] => {
    const sec = sectionsByKey[id];
    if (!sec) return [];
    return (sec.fields ?? []).filter((f) => f.level === level);
  };

  const filter = search.trim().toLowerCase();

  // section title from schema overrides default
  const titleFor = (id: string) =>
    sectionsByKey[id]?.title ?? SECTION_TITLES[id] ?? id;
  const iconFor = (id: string) => sectionsByKey[id]?.icon;

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <SettingsIcon className="h-5 w-5 text-white/70" />
        <Typography variant="md" compressed className="text-white">
          Settings
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">
          {error}
        </div>
      )}
      {flashMsg && (
        <div
          className={`text-xs ${flashMsg.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flashMsg.msg}
        </div>
      )}

      {/* Level tabs + search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex gap-1 rounded-lg border border-white/10 bg-white/5 p-1">
          {LEVELS.map((lv) => (
            <button
              key={lv}
              type="button"
              onClick={() => setLevel(lv)}
              className={`rounded px-3 py-1 text-xs uppercase tracking-wider transition ${
                level === lv
                  ? "bg-[var(--accent)] text-white"
                  : "text-white/60 hover:text-white/85"
              }`}
            >
              {lv}
            </button>
          ))}
        </div>
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search settings…"
          className="w-72 rounded-md border border-white/10 bg-black/30 px-3 py-1.5 text-sm text-white outline-none focus:border-[var(--accent)]"
        />
      </div>

      {/* Sections */}
      <div className="flex flex-col gap-4">
        {SECTION_ORDER.map((id) => {
          if (id === "permissions") {
            return (
              <CardSection
                key={id}
                title={titleFor(id)}
                icon={iconFor(id) ?? "🛡️"}
              >
                <PermissionsCard
                  state={formState}
                  onField={setField}
                  filter={filter}
                />
              </CardSection>
            );
          }
          if (id === "env") {
            return (
              <CardSection
                key={id}
                title={titleFor(id)}
                icon={iconFor(id) ?? "🌐"}
              >
                <EnvVarsCard
                  envVars={envVars}
                  onChanged={loadAux}
                  flash={flash}
                  filter={filter}
                />
              </CardSection>
            );
          }
          if (id === "hooks") {
            return (
              <CardSection
                key={id}
                title={titleFor(id)}
                icon={iconFor(id) ?? "🪝"}
              >
                <HooksCard
                  hooks={hooks}
                  onChanged={loadAux}
                  flash={flash}
                  filter={filter}
                />
              </CardSection>
            );
          }
          if (id === "plugins") {
            return (
              <CardSection
                key={id}
                title={titleFor(id)}
                icon={iconFor(id) ?? "🔌"}
              >
                <PluginsCard
                  schema={schema}
                  state={formState}
                  onField={setField}
                  filter={filter}
                />
              </CardSection>
            );
          }
          if (id === "audit") {
            return (
              <CardSection
                key={id}
                title={titleFor(id)}
                icon={iconFor(id) ?? "📜"}
              >
                <AuditCard entries={audit} />
              </CardSection>
            );
          }
          // schema-driven sections (provider / agent / advanced)
          const fields = fieldsForSection(id);
          return (
            <CardSection
              key={id}
              title={titleFor(id)}
              icon={iconFor(id)}
            >
              <SchemaFields
                fields={fields}
                state={formState}
                onField={setField}
                filter={filter}
              />
            </CardSection>
          );
        })}

        {/* Any extra schema sections we didn't enumerate */}
        {(schema?.sections ?? [])
          .filter((s) => !SECTION_ORDER.includes(s.id as (typeof SECTION_ORDER)[number]))
          .map((s) => (
            <CardSection key={s.id} title={s.title} icon={s.icon}>
              <SchemaFields
                fields={(s.fields ?? []).filter((f) => f.level === level)}
                state={formState}
                onField={setField}
                filter={filter}
              />
            </CardSection>
          ))}

        {/* API Keys card (separate from level-scoped settings) */}
        <ApiKeysCard
          keys={apiKeys}
          onChanged={loadAux}
          flash={flash}
        />
      </div>

      {/* Footer save bar */}
      <div className="sticky bottom-3 z-10 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/70 px-4 py-3 backdrop-blur">
        <div className="text-xs text-white/65">
          {dirty ? (
            <span className="text-amber-300">● Unsaved changes</span>
          ) : (
            <span>All changes saved</span>
          )}
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={resetAll}
            disabled={busy}
            className={btnSubtle()}
          >
            Reset {level}
          </button>
          <button
            type="button"
            onClick={discard}
            disabled={busy || !dirty}
            className={btnSubtle()}
          >
            Discard
          </button>
          <button
            type="button"
            onClick={save}
            disabled={busy || !dirty}
            className={btnPrimary()}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
