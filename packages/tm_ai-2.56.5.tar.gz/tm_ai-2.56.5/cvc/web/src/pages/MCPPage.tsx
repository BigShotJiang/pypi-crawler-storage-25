import { useCallback, useEffect, useMemo, useState } from "react";
import { Boxes, RefreshCw, Search } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type MCPStatus, type MCPTool } from "@/lib/api";

interface MCPToolEx extends MCPTool {
  server?: string;
}

function serverOf(t: MCPToolEx): string {
  if (t.server) return t.server;
  // Convention: tool names look like "<server>_<func>" (e.g. mcp_cvc_cvc_status).
  const ix = t.name.indexOf("_");
  if (ix > 0) return t.name.slice(0, ix);
  return "default";
}

export default function MCPPage() {
  const [status, setStatus] = useState<MCPStatus | null>(null);
  const [tools, setTools] = useState<MCPToolEx[]>([]);
  const [filter, setFilter] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [enabledCount, setEnabledCount] = useState<number | null>(null);
  const [errorsCount, setErrorsCount] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, t] = await Promise.all([
        api.mcpStatus().catch(() => null),
        api.mcpTools().catch(() => ({ tools: [] as MCPTool[] })),
      ]);
      setStatus(s);
      const list = (Array.isArray(t.tools) ? t.tools : []) as MCPToolEx[];
      setTools(list);
      // Derive optional counts if present in status object
      const sx = (s ?? {}) as Record<string, unknown>;
      setEnabledCount(
        typeof sx.enabled_count === "number"
          ? (sx.enabled_count as number)
          : typeof sx.servers_enabled === "number"
            ? (sx.servers_enabled as number)
            : null,
      );
      setErrorsCount(
        typeof sx.errors === "number"
          ? (sx.errors as number)
          : typeof sx.error_count === "number"
            ? (sx.error_count as number)
            : null,
      );
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return tools;
    return tools.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        (t.description ?? "").toLowerCase().includes(q),
    );
  }, [tools, filter]);

  const grouped = useMemo(() => {
    const m = new Map<string, MCPToolEx[]>();
    for (const t of filtered) {
      const k = serverOf(t);
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(t);
    }
    return Array.from(m.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [filtered]);

  const connectedCount = useMemo(
    () =>
      status?.available
        ? typeof (status as unknown as Record<string, unknown>).connected === "number"
          ? ((status as unknown as Record<string, unknown>).connected as number)
          : 1
        : 0,
    [status],
  );

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Boxes className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            MCP
          </Typography>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="inline-flex items-center gap-1 rounded border border-border bg-card/60 px-2.5 py-1.5 text-xs text-midground/80 hover:bg-midground/10 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          {error}
        </div>
      )}

      {/* Status */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Enabled" value={enabledCount != null ? String(enabledCount) : "—"} />
        <Stat label="Connected" value={String(connectedCount)} />
        <Stat
          label="Tools"
          value={
            status?.tools_count != null
              ? String(status.tools_count)
              : String(tools.length)
          }
        />
        <Stat label="Errors" value={errorsCount != null ? String(errorsCount) : "0"} />
      </section>

      {status?.note && (
        <div className="rounded-lg border border-border bg-card/40 p-3 text-xs text-midground/70">
          {status.note}
        </div>
      )}

      {/* Tools — grouped by server */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-3">
          <Typography variant="sm" compressed className="text-midground/70">
            Tools
          </Typography>
          <div className="relative w-64">
            <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-midground/50" />
            <input
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Filter by name…"
              className="w-full rounded border border-border bg-card/60 pl-7 pr-2 py-1.5 text-xs text-midground"
            />
          </div>
        </div>
        {grouped.length === 0 ? (
          <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
            {tools.length === 0 ? "No tools available." : "No tools match filter."}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {grouped.map(([server, list]) => (
              <div
                key={server}
                className="overflow-hidden rounded-lg border border-border bg-card/40"
              >
                <div className="flex items-center justify-between border-b border-border bg-midground/5 px-4 py-2">
                  <span className="font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/80">
                    {server}
                  </span>
                  <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55">
                    {list.length} tools
                  </span>
                </div>
                <ul className="divide-y divide-border/40">
                  {list.map((t) => (
                    <li key={t.name} className="flex flex-col gap-1.5 px-4 py-3">
                      <div className="font-mono-ui text-sm text-midground">
                        {t.name}
                      </div>
                      {t.description && (
                        <div className="text-xs text-midground/70">
                          {t.description}
                        </div>
                      )}
                      {t.parameters && Object.keys(t.parameters).length > 0 && (
                        <details className="mt-1">
                          <summary className="cursor-pointer text-[0.65rem] uppercase tracking-wider text-midground/55">
                            parameters
                          </summary>
                          <pre className="mt-1 max-h-48 overflow-auto rounded border border-border bg-background-base/40 p-2 font-mono text-[0.7rem] text-midground/80">
                            {JSON.stringify(t.parameters, null, 2)}
                          </pre>
                        </details>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
        {label}
      </div>
      <div className="mt-1.5 text-2xl font-bold text-midground tabular-nums">
        {value}
      </div>
    </div>
  );
}
