import { useCallback, useEffect, useMemo, useState } from "react";
import { Brain, RefreshCw } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type BlobEntry,
  type MemoryBlobsResponse,
  type MemoryContextResponse,
  type MemoryStatsResponse,
} from "@/lib/api";
import { useDashboardWS } from "@/lib/useDashboardWS";

function formatBytes(n: number | undefined): string {
  if (!n || !Number.isFinite(n)) return "—";
  const u = ["B", "KB", "MB", "GB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 ? 1 : 0)} ${u[i]}`;
}

function fmtTs(t: number | undefined): string {
  if (!t) return "—";
  const ms = t < 1e12 ? t * 1000 : t;
  return new Date(ms).toLocaleString();
}

export default function MemoryPage() {
  const [stats, setStats] = useState<MemoryStatsResponse | null>(null);
  const [blobs, setBlobs] = useState<BlobEntry[]>([]);
  const [ctx, setCtx] = useState<MemoryContextResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [flash, setFlashMsg] = useState<{ kind: "ok" | "err"; msg: string } | null>(
    null,
  );
  const [expanded, setExpanded] = useState<string | null>(null);

  const showFlash = (kind: "ok" | "err", msg: string) => {
    setFlashMsg({ kind, msg });
    window.setTimeout(() => setFlashMsg(null), 3000);
  };

  const refresh = useCallback(async () => {
    try {
      const [s, b, c] = await Promise.all([
        api.memoryStats().catch(() => null),
        api
          .memoryBlobs(50)
          .catch(() => ({ blobs: [], total: 0 }) as MemoryBlobsResponse),
        api.memoryContext().catch(() => null),
      ]);
      setStats(s);
      setBlobs(b.blobs ?? []);
      setCtx(c);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const { lastEvent } = useDashboardWS();
  useEffect(() => {
    if (!lastEvent) return;
    const t = lastEvent.type ?? "";
    if (t.includes("memory") || t.includes("commit")) void refresh();
  }, [lastEvent, refresh]);

  const compact = async () => {
    setBusy(true);
    try {
      await api.hiveMemoryCompact();
      showFlash("ok", "Memory compacted");
      await refresh();
    } catch (e) {
      showFlash("err", `Error: ${(e as Error)?.message ?? e}`);
    } finally {
      setBusy(false);
    }
  };

  const ctxMessages = useMemo(() => ctx?.context ?? [], [ctx]);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Brain className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Memory
          </Typography>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void refresh()}
            className="inline-flex items-center gap-1 rounded border border-border bg-card/60 px-2.5 py-1.5 text-xs text-midground/80 hover:bg-midground/10"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
          <button
            type="button"
            onClick={compact}
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-md bg-[var(--accent,#ef4444)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50"
          >
            Compact
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}
      {flash && (
        <div
          className={`text-xs ${flash.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flash.msg}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCell label="Blobs" value={String(stats?.blob_count ?? 0)} />
        <StatCell label="DB size" value={formatBytes(stats?.database_size_bytes)} />
        <StatCell label="Blob bytes" value={formatBytes(stats?.blob_total_bytes)} />
        <StatCell label="Context msgs" value={String(ctxMessages.length)} />
      </div>

      {/* Recent Blobs */}
      <section className="overflow-hidden rounded-lg border border-border bg-card/40">
        <div className="border-b border-border bg-midground/5 px-4 py-2 text-[0.65rem] uppercase tracking-wider text-midground/55 font-mono-ui">
          Recent Blobs
        </div>
        {blobs.length === 0 ? (
          <div className="px-4 py-6 text-sm text-midground/55">No blobs stored.</div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-midground/5">
              <tr className="text-[0.65rem] uppercase tracking-wider text-midground/55">
                <th className="px-4 py-2 font-medium">Hash</th>
                <th className="px-4 py-2 font-medium">Size</th>
                <th className="px-4 py-2 font-medium">Type</th>
                <th className="px-4 py-2 font-medium">Created</th>
              </tr>
            </thead>
            <tbody>
              {blobs.map((b) => {
                const isOpen = expanded === b.hash;
                return (
                  <>
                    <tr
                      key={b.hash}
                      onClick={() => setExpanded(isOpen ? null : b.hash)}
                      className="cursor-pointer border-b border-border/40 last:border-b-0 hover:bg-midground/5"
                    >
                      <td className="px-4 py-2 font-mono text-xs text-midground/80">
                        {b.hash.slice(0, 16)}…
                      </td>
                      <td className="px-4 py-2 text-xs tabular-nums text-midground/70">
                        {formatBytes(b.size_bytes)}
                      </td>
                      <td className="px-4 py-2 text-xs text-midground/70">
                        {b.type ?? "—"}
                      </td>
                      <td className="px-4 py-2 text-xs text-midground/55">
                        {fmtTs(b.modified)}
                      </td>
                    </tr>
                    {isOpen && (
                      <tr key={`${b.hash}-x`} className="bg-midground/5">
                        <td colSpan={4} className="px-4 py-3">
                          <div className="text-[0.65rem] uppercase tracking-wider text-midground/55 font-mono-ui mb-1">
                            Context preview
                          </div>
                          <pre className="max-h-64 overflow-auto rounded border border-border bg-background-base/40 p-2 font-mono text-[0.7rem] text-midground/80">
                            {ctxMessages.length === 0
                              ? "(no context loaded)"
                              : ctxMessages
                                  .slice(0, 10)
                                  .map((m) => `[${m.role}] ${m.content.slice(0, 240)}`)
                                  .join("\n\n")}
                          </pre>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}

function StatCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
        {label}
      </div>
      <div className="mt-1.5 text-2xl font-bold text-midground tabular-nums">
        {value}
      </div>
    </div>
  );
}
