import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Network, RefreshCw, Send, Database, ChevronDown, ChevronRight } from "lucide-react";
import { api, type HiveMemoryEntry, type HiveMemoryStats } from "@/lib/api";

// ── Tailwind tokens (per dossier) ──────────────────────────────
const CARD = "rounded-xl border border-white/10 bg-white/5 p-5";
const TITLE = "text-xs font-semibold uppercase tracking-[0.2em] text-white/60";
const PRIMARY_BTN =
  "inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50";
const SUBTLE_BTN =
  "inline-flex items-center gap-2 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5 disabled:opacity-50";
const INPUT =
  "w-full rounded-md border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-[var(--accent)]";

const CATEGORIES = [
  "general",
  "insight",
  "decision",
  "discovery",
  "warning",
  "error",
  "task_result",
  "learning",
] as const;

const CATEGORY_BADGE: Record<string, string> = {
  insight: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  decision: "bg-purple-500/15 text-purple-300 border-purple-500/30",
  discovery: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  warning: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  error: "bg-red-500/15 text-red-300 border-red-500/30",
  task_result: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  learning: "bg-pink-500/15 text-pink-300 border-pink-500/30",
  general: "bg-white/10 text-white/70 border-white/20",
};

function fmtTime(ts: number | string): string {
  try {
    const d = typeof ts === "number" ? new Date(ts * 1000) : new Date(ts);
    return d.toLocaleString();
  } catch {
    return String(ts);
  }
}

type Flash = { kind: "ok" | "err"; msg: string } | null;

export default function HiveMindPage() {
  const [stats, setStats] = useState<HiveMemoryStats | null>(null);
  const [entries, setEntries] = useState<HiveMemoryEntry[]>([]);
  const [summary, setSummary] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [flash, setFlash] = useState<Flash>(null);
  const flashTimer = useRef<number | null>(null);

  // filter state
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [filterAgent, setFilterAgent] = useState<string>("");
  const [filterQuery, setFilterQuery] = useState<string>("");

  // writer form
  const [writerOpen, setWriterOpen] = useState(true);
  const [wAgent, setWAgent] = useState("");
  const [wCategory, setWCategory] = useState<string>("general");
  const [wTags, setWTags] = useState("");
  const [wContent, setWContent] = useState("");
  const [writing, setWriting] = useState(false);

  // compact result
  const [compactInfo, setCompactInfo] = useState<{
    before?: number;
    after?: number;
    message?: string;
  } | null>(null);

  const flashFor = useCallback((kind: "ok" | "err", msg: string) => {
    setFlash({ kind, msg });
    if (flashTimer.current) window.clearTimeout(flashTimer.current);
    flashTimer.current = window.setTimeout(() => setFlash(null), 3000);
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const s = await api.hiveMemoryStats();
      setStats(s);
    } catch {
      /* ignore */
    }
  }, []);

  const loadFeed = useCallback(async () => {
    try {
      const data = await api.hiveMemory({
        query: filterQuery || undefined,
        category: filterCategory || undefined,
        agent_id: filterAgent || undefined,
        limit: 50,
      });
      setEntries(data.entries || []);
    } catch (e) {
      flashFor("err", `Feed load failed: ${(e as Error).message}`);
    }
  }, [filterQuery, filterCategory, filterAgent, flashFor]);

  const loadSummary = useCallback(async () => {
    try {
      const s = await api.hiveMemorySummary(10);
      setSummary(s?.context || "");
    } catch {
      setSummary("");
    }
  }, []);

  const loadAll = useCallback(async () => {
    setLoading(true);
    await Promise.all([loadStats(), loadFeed(), loadSummary()]);
    setLoading(false);
  }, [loadStats, loadFeed, loadSummary]);

  useEffect(() => {
    void loadAll();
    return () => {
      if (flashTimer.current) window.clearTimeout(flashTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const dynamicCategories = useMemo(() => {
    const fromStats = Object.keys(stats?.categories || {});
    const merged = new Set<string>([...CATEGORIES, ...fromStats]);
    return Array.from(merged);
  }, [stats]);

  const latestLabel = useMemo(() => {
    if (!entries.length) return stats && stats.total_entries > 0 ? "Active" : "Empty";
    return fmtTime(entries[0].timestamp);
  }, [entries, stats]);

  async function onApplyFilter(e: FormEvent) {
    e.preventDefault();
    await loadFeed();
  }

  async function onWrite(e: FormEvent) {
    e.preventDefault();
    if (!wAgent.trim()) {
      flashFor("err", "Agent ID required");
      return;
    }
    if (!wContent.trim()) {
      flashFor("err", "Content required");
      return;
    }
    const tags = wTags
      ? wTags.split(",").map((s) => s.trim()).filter(Boolean)
      : [];
    setWriting(true);
    try {
      await api.hiveMemoryWrite(wAgent.trim(), wContent.trim(), wCategory, tags);
      setWContent("");
      setWTags("");
      flashFor("ok", "Saved");
      await Promise.all([loadStats(), loadFeed()]);
    } catch (err) {
      flashFor("err", (err as Error).message);
    } finally {
      setWriting(false);
    }
  }

  async function onCompact() {
    try {
      const before = stats?.total_entries ?? entries.length;
      const result = (await api.hiveMemoryCompact()) as unknown as {
        message?: string;
        before?: number;
        after?: number;
        total_entries?: number;
      };
      const newStats = await api.hiveMemoryStats();
      setStats(newStats);
      setCompactInfo({
        before: result.before ?? before,
        after: result.after ?? result.total_entries ?? newStats.total_entries,
        message: result.message,
      });
      await loadFeed();
      flashFor("ok", "Compacted");
    } catch (e) {
      flashFor("err", (e as Error).message);
    }
  }

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Network className="h-5 w-5 text-white/70" />
          <h1 className="text-sm font-semibold uppercase tracking-[0.2em] text-white">
            Hive Mind · Memory
          </h1>
        </div>
        <button
          type="button"
          onClick={() => void loadAll()}
          disabled={loading}
          className={SUBTLE_BTN}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {flash && (
        <div
          className={`text-xs ${flash.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flash.msg}
        </div>
      )}

      {/* Stats grid (4 cards) */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total Entries" value={stats?.total_entries ?? 0} />
        <StatCard
          label="Categories"
          value={Object.keys(stats?.categories || {}).length}
        />
        <StatCard label="Agents" value={stats?.agent_count ?? 0} />
        <StatCard label="Latest" value={latestLabel} mono={false} />
      </div>

      {/* Body 2-col */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* LEFT — feed (col-span-2) */}
        <div className="flex flex-col gap-4 lg:col-span-2">
          {/* Filter bar */}
          <form
            onSubmit={onApplyFilter}
            className={`${CARD} flex flex-col gap-3`}
          >
            <div className={TITLE}>Filter Feed</div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              <div className="flex flex-col gap-1">
                <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                  Category
                </label>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className={INPUT}
                >
                  <option value="">All</option>
                  {dynamicCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                      {stats?.categories?.[c] != null
                        ? ` (${stats.categories[c]})`
                        : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                  Search
                </label>
                <input
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  placeholder="text…"
                  className={INPUT}
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                  Agent ID
                </label>
                <input
                  value={filterAgent}
                  onChange={(e) => setFilterAgent(e.target.value)}
                  placeholder="agent_id…"
                  className={INPUT}
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button type="submit" className={PRIMARY_BTN}>
                Apply
              </button>
            </div>
          </form>

          {/* Feed */}
          <div className={`${CARD} flex flex-col gap-3`}>
            <div className="flex items-center justify-between">
              <div className={TITLE}>Memory Feed</div>
              <span className="text-[0.65rem] uppercase tracking-wider text-white/40">
                {entries.length} shown
              </span>
            </div>
            {entries.length === 0 ? (
              <p className="text-sm text-white/50">
                No hive memory entries yet. Write one on the right →
              </p>
            ) : (
              <div className="flex flex-col gap-2">
                {entries.map((e) => (
                  <EntryCard key={e.id} entry={e} />
                ))}
              </div>
            )}
          </div>

          {/* Compact button + result */}
          <div className={`${CARD} flex flex-col gap-3`}>
            <div className="flex items-center justify-between">
              <div className={TITLE}>Maintenance</div>
              <button
                type="button"
                onClick={() => void onCompact()}
                className={PRIMARY_BTN}
              >
                <Database className="h-3.5 w-3.5" />
                Compact Memory
              </button>
            </div>
            {compactInfo && (
              <div className="rounded-md border border-white/10 bg-black/20 p-3 text-xs text-white/70">
                <div className="font-semibold uppercase tracking-wider text-white/60">
                  Compaction Result
                </div>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  <div>
                    Before:{" "}
                    <span className="font-mono text-white">
                      {compactInfo.before ?? "—"}
                    </span>
                  </div>
                  <div>
                    After:{" "}
                    <span className="font-mono text-white">
                      {compactInfo.after ?? "—"}
                    </span>
                  </div>
                </div>
                {compactInfo.message && (
                  <div className="mt-2 text-white/60">{compactInfo.message}</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT — writer + summary */}
        <div className="flex flex-col gap-4">
          {/* Writer */}
          <div className={`${CARD} flex flex-col gap-3`}>
            <button
              type="button"
              onClick={() => setWriterOpen((v) => !v)}
              className="flex items-center justify-between text-left"
            >
              <span className={TITLE}>New Entry</span>
              {writerOpen ? (
                <ChevronDown className="h-4 w-4 text-white/60" />
              ) : (
                <ChevronRight className="h-4 w-4 text-white/60" />
              )}
            </button>
            {writerOpen && (
              <form onSubmit={onWrite} className="flex flex-col gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                    Agent ID *
                  </label>
                  <input
                    value={wAgent}
                    onChange={(e) => setWAgent(e.target.value)}
                    className={INPUT}
                    placeholder="e.g. SPC-AEG-01"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                    Category
                  </label>
                  <select
                    value={wCategory}
                    onChange={(e) => setWCategory(e.target.value)}
                    className={INPUT}
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                    Tags (comma-separated)
                  </label>
                  <input
                    value={wTags}
                    onChange={(e) => setWTags(e.target.value)}
                    className={INPUT}
                    placeholder="alpha, beta"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[0.65rem] uppercase tracking-[0.18em] text-white/50">
                    Content *
                  </label>
                  <textarea
                    value={wContent}
                    onChange={(e) => setWContent(e.target.value)}
                    rows={5}
                    className={`${INPUT} resize-y`}
                    placeholder="Share an insight, decision, discovery…"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={writing}
                    className={PRIMARY_BTN}
                  >
                    <Send className="h-3.5 w-3.5" />
                    {writing ? "Writing…" : "Write"}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Summary */}
          <div className={`${CARD} flex flex-col gap-3`}>
            <div className="flex items-center justify-between">
              <div className={TITLE}>Summary Context</div>
              <button
                type="button"
                onClick={() => void loadSummary()}
                className={SUBTLE_BTN}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh
              </button>
            </div>
            <div className="max-h-96 overflow-auto rounded-md border border-white/10 bg-black/30 p-3">
              {summary ? (
                <pre className="whitespace-pre-wrap break-words font-mono text-xs text-white/80">
                  {summary}
                </pre>
              ) : (
                <p className="text-sm text-white/50">No summary available yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  mono = true,
}: {
  label: string;
  value: number | string;
  mono?: boolean;
}) {
  return (
    <div className={CARD}>
      <div className="text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-white/50">
        {label}
      </div>
      <div
        className={`mt-2 ${mono ? "font-mono" : ""} text-2xl font-semibold text-white`}
      >
        {value}
      </div>
    </div>
  );
}

function EntryCard({ entry }: { entry: HiveMemoryEntry }) {
  const badgeCls =
    CATEGORY_BADGE[entry.category] ?? CATEGORY_BADGE.general;
  return (
    <div className="rounded-lg border border-white/10 bg-black/20 p-3">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="font-mono text-white/80">🤖 {entry.agent_id}</span>
        <span
          className={`rounded-md border px-2 py-0.5 text-[0.65rem] uppercase tracking-wider ${badgeCls}`}
        >
          {entry.category}
        </span>
        <span className="ml-auto text-white/40">{fmtTime(entry.timestamp)}</span>
      </div>
      <div className="mt-2 whitespace-pre-wrap text-sm text-white/85">
        {entry.content}
      </div>
      {entry.tags && entry.tags.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {entry.tags.map((t) => (
            <span
              key={t}
              className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-[0.65rem] text-white/70"
            >
              #{t}
            </span>
          ))}
        </div>
      )}
      {entry.commit_hash && (
        <div className="mt-2 font-mono text-[0.65rem] text-white/40">
          {entry.commit_hash.slice(0, 8)}
        </div>
      )}
    </div>
  );
}
