import { useCallback, useEffect, useMemo, useState } from "react";
import { Cpu, RefreshCw, Search } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type CurrentModel,
  type ModelCatalog,
  type ModelInfo,
} from "@/lib/api";

interface CatalogRow {
  provider: string;
  model: ModelInfo;
}

export default function ModelsPage() {
  const [current, setCurrent] = useState<CurrentModel | null>(null);
  const [catalog, setCatalog] = useState<ModelCatalog | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [flash, setFlashMsg] = useState<{ kind: "ok" | "err"; msg: string } | null>(
    null,
  );
  const [search, setSearch] = useState("");
  const [providerFilter, setProviderFilter] = useState<string>("all");

  const showFlash = (kind: "ok" | "err", msg: string) => {
    setFlashMsg({ kind, msg });
    window.setTimeout(() => setFlashMsg(null), 3000);
  };

  const refresh = useCallback(async () => {
    try {
      const [c, cat] = await Promise.all([
        api.currentModel().catch(() => null),
        api.modelCatalog().catch(() => null),
      ]);
      setCurrent(c);
      setCatalog(cat);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const switchTo = async (provider: string, model: string) => {
    setBusy(true);
    try {
      await api.switchModel(provider, model);
      showFlash("ok", `Switched to ${provider}/${model}`);
      const c = await api.currentModel().catch(() => null);
      setCurrent(c);
    } catch (e) {
      showFlash("err", `Error: ${(e as Error)?.message ?? e}`);
    } finally {
      setBusy(false);
    }
  };

  const rows: CatalogRow[] = useMemo(() => {
    const out: CatalogRow[] = [];
    const providers = catalog?.providers ?? {};
    for (const [prov, models] of Object.entries(providers)) {
      for (const m of models) out.push({ provider: prov, model: m });
    }
    return out;
  }, [catalog]);

  const providerNames = useMemo(
    () => Object.keys(catalog?.providers ?? {}),
    [catalog],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (providerFilter !== "all" && r.provider !== providerFilter) return false;
      if (!q) return true;
      const hay = `${r.provider} ${r.model.id} ${r.model.name ?? ""}`.toLowerCase();
      return hay.includes(q);
    });
  }, [rows, search, providerFilter]);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Cpu className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Models
          </Typography>
        </div>
        <button
          type="button"
          onClick={() => void refresh()}
          className="inline-flex items-center gap-1 rounded border border-border bg-card/60 px-2.5 py-1.5 text-xs text-midground/80 hover:bg-midground/10"
        >
          <RefreshCw className="h-3.5 w-3.5" /> Refresh
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}
      {flash && (
        <div
          className={`text-xs ${flash.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flash.msg}
        </div>
      )}

      {/* Current model card */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
          Current model
        </div>
        <div className="mt-2 flex flex-wrap items-baseline gap-3">
          <div className="text-3xl font-bold text-midground">
            {current?.model ?? "—"}
          </div>
          <div className="text-sm text-midground/65">
            {current?.provider ?? "—"}
          </div>
          {current && (
            <span
              className={`ml-auto rounded-full border px-2.5 py-0.5 text-[0.65rem] uppercase tracking-wider ${
                current.api_key_set
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                  : "border-amber-500/30 bg-amber-500/10 text-amber-300"
              }`}
            >
              {current.api_key_set ? "key set" : "no key"}
            </span>
          )}
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {current?.provider && (
            <Chip>provider: {current.provider}</Chip>
          )}
          {current?.model && <Chip>model: {current.model}</Chip>}
        </div>
      </div>

      {/* Search + provider filter */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-midground/50" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search provider/model…"
            className="w-full rounded-md border border-border bg-card/60 pl-8 pr-3 py-2 text-sm text-midground outline-none focus:border-midground/40"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          <FilterChip
            active={providerFilter === "all"}
            onClick={() => setProviderFilter("all")}
            label="All"
          />
          {providerNames.map((p) => (
            <FilterChip
              key={p}
              active={providerFilter === p}
              onClick={() => setProviderFilter(p)}
              label={p}
            />
          ))}
        </div>
      </div>

      {/* Catalog grid */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.length === 0 ? (
          <div className="col-span-full rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/55">
            No models match.
          </div>
        ) : (
          filtered.map((r) => {
            const isCurrent =
              current?.provider === r.provider && current?.model === r.model.id;
            return (
              <div
                key={`${r.provider}/${r.model.id}`}
                className={`flex flex-col gap-2 rounded-lg border p-4 ${
                  isCurrent
                    ? "border-emerald-500/40 bg-emerald-500/5"
                    : "border-border bg-card/40"
                }`}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <div className="font-mono-ui text-sm font-medium text-midground">
                    {r.model.name || r.model.id}
                  </div>
                  <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55">
                    {r.provider}
                  </span>
                </div>
                {r.model.description && (
                  <div className="line-clamp-2 text-[0.7rem] text-midground/60">
                    {r.model.description}
                  </div>
                )}
                <div className="flex flex-wrap gap-1">
                  {r.model.context_window != null && (
                    <Chip>{Math.round(r.model.context_window / 1000)}k ctx</Chip>
                  )}
                  {r.model.max_output != null && (
                    <Chip>{Math.round(r.model.max_output / 1000)}k out</Chip>
                  )}
                </div>
                <button
                  type="button"
                  disabled={busy || isCurrent}
                  onClick={() => switchTo(r.provider, r.model.id)}
                  className="mt-auto inline-flex items-center justify-center gap-2 rounded-md bg-[var(--accent,#ef4444)] px-3 py-1.5 text-[0.65rem] font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-40"
                >
                  {isCurrent ? "Active" : "Switch"}
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded border border-border bg-midground/5 px-1.5 py-0.5 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/70">
      {children}
    </span>
  );
}

function FilterChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-3 py-1 text-[0.65rem] uppercase tracking-wider transition ${
        active
          ? "border-midground/40 bg-midground/15 text-midground"
          : "border-border bg-card/60 text-midground/65 hover:bg-midground/10"
      }`}
    >
      {label}
    </button>
  );
}
