import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Wrench } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type BranchSummary,
  type DiffResult,
  type OpsStatus,
  type RecallResult,
} from "@/lib/api";

type Flash = { kind: "ok" | "err"; text: string } | null;

const cardCls = "rounded-xl border border-white/10 bg-white/5 p-5";
const titleCls =
  "text-xs font-semibold uppercase tracking-[0.2em] text-white/60";
const inputCls =
  "w-full rounded-md border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-[var(--accent)]";
const primaryBtn =
  "inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90 disabled:opacity-50";
const subtleBtn =
  "rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5 disabled:opacity-50";

function FlashLine({ flash }: { flash: Flash }) {
  if (!flash) return null;
  return (
    <div
      className={`text-xs ${
        flash.kind === "ok" ? "text-emerald-400" : "text-red-400"
      }`}
    >
      {flash.text}
    </div>
  );
}

function useFlash(): [Flash, (f: Flash) => void] {
  const [flash, setFlash] = useState<Flash>(null);
  const set = useCallback((f: Flash) => {
    setFlash(f);
    if (f) setTimeout(() => setFlash(null), 3000);
  }, []);
  return [flash, set];
}

function fmtTs(t: string | number | undefined): string {
  if (!t) return "—";
  const d = typeof t === "number" ? new Date(t * (t < 1e12 ? 1000 : 1)) : new Date(t);
  if (isNaN(d.getTime())) return String(t);
  return d.toLocaleString();
}

function normalizeBranches(
  resp: { branches: BranchSummary[] } | string[] | BranchSummary[],
): BranchSummary[] {
  if (Array.isArray(resp)) {
    if (resp.length === 0) return [];
    if (typeof resp[0] === "string") {
      return (resp as string[]).map((name) => ({
        name,
        head: "",
        status: "",
      }));
    }
    return resp as BranchSummary[];
  }
  return resp.branches ?? [];
}

export default function OperationsPage() {
  // ── Status ────────────────────────────────────────────
  const [status, setStatus] = useState<OpsStatus | null>(null);
  const [branches, setBranches] = useState<BranchSummary[]>([]);
  const [activeBranch, setActiveBranch] = useState<string>("");

  const refreshAll = useCallback(async () => {
    try {
      const s = await api.opsStatus();
      setStatus(s);
      setActiveBranch((prev) => prev || s.branch);
    } catch {
      /* ignore */
    }
    try {
      const b = await api.opsBranches();
      setBranches(normalizeBranches(b));
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    void refreshAll();
  }, [refreshAll]);

  // ── Commit ────────────────────────────────────────────
  const [commitMsg, setCommitMsg] = useState("");
  const [commitFlash, setCommitFlash] = useFlash();
  const [commitBusy, setCommitBusy] = useState(false);

  async function handleCommit(e: FormEvent) {
    e.preventDefault();
    if (!commitMsg.trim()) return;
    setCommitBusy(true);
    try {
      const r = await api.opsCommit({ message: commitMsg.trim() });
      setCommitFlash({
        kind: "ok",
        text: `Committed${r.hash ? ` ${String(r.hash).slice(0, 12)}` : ""}`,
      });
      setCommitMsg("");
      void refreshAll();
    } catch (err) {
      setCommitFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setCommitBusy(false);
    }
  }

  // ── Branches ──────────────────────────────────────────
  const [newBranch, setNewBranch] = useState("");
  const [branchFlash, setBranchFlash] = useFlash();
  const [branchBusy, setBranchBusy] = useState(false);
  const [mergingFrom, setMergingFrom] = useState<string | null>(null);

  async function handleCreateBranch(e: FormEvent) {
    e.preventDefault();
    if (!newBranch.trim()) return;
    setBranchBusy(true);
    try {
      const r = await api.opsBranch({ name: newBranch.trim() });
      setBranchFlash({ kind: "ok", text: `Created ${r.branch ?? newBranch}` });
      setNewBranch("");
      void refreshAll();
    } catch (err) {
      setBranchFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setBranchBusy(false);
    }
  }

  async function handleSwitch(name: string) {
    setActiveBranch(name);
    setBranchFlash({ kind: "ok", text: `Switched to ${name}` });
    void refreshAll();
  }

  async function handleMerge(source: string) {
    if (source === "main") {
      setBranchFlash({ kind: "err", text: "Cannot merge main into main" });
      return;
    }
    setMergingFrom(source);
    try {
      await api.opsMerge({ source, target: "main" });
      setBranchFlash({ kind: "ok", text: `Merged ${source} → main` });
      void refreshAll();
    } catch (err) {
      setBranchFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setMergingFrom(null);
    }
  }

  // ── Diff ──────────────────────────────────────────────
  const [diffA, setDiffA] = useState("");
  const [diffB, setDiffB] = useState("");
  const [diffResult, setDiffResult] = useState<DiffResult | null>(null);
  const [diffFlash, setDiffFlash] = useFlash();
  const [diffBusy, setDiffBusy] = useState(false);

  async function handleDiff(e: FormEvent) {
    e.preventDefault();
    if (!diffA.trim() || !diffB.trim()) return;
    setDiffBusy(true);
    try {
      const r = await api.opsDiff(diffA.trim(), diffB.trim());
      setDiffResult(r);
    } catch (err) {
      setDiffFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setDiffBusy(false);
    }
  }

  // ── Recall ────────────────────────────────────────────
  const [recallQuery, setRecallQuery] = useState("");
  const [recallResult, setRecallResult] = useState<RecallResult | null>(null);
  const [recallFlash, setRecallFlash] = useFlash();
  const [recallBusy, setRecallBusy] = useState(false);

  async function handleRecall(e: FormEvent) {
    e.preventDefault();
    if (!recallQuery.trim()) return;
    setRecallBusy(true);
    try {
      const r = await api.opsRecall(recallQuery.trim(), 10);
      setRecallResult(r);
      if (!r.results?.length) {
        setRecallFlash({ kind: "ok", text: "No matches" });
      }
    } catch (err) {
      setRecallFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setRecallBusy(false);
    }
  }

  // ── Restore ───────────────────────────────────────────
  const [restoreHash, setRestoreHash] = useState("");
  const [restoreFlash, setRestoreFlash] = useFlash();
  const [restoreBusy, setRestoreBusy] = useState(false);

  async function handleRestore(e: FormEvent) {
    e.preventDefault();
    const hash = restoreHash.trim();
    if (!hash) return;
    if (
      !window.confirm(
        "This will rewrite the current branch HEAD. Continue?",
      )
    ) {
      return;
    }
    setRestoreBusy(true);
    try {
      await api.opsRestore({ commit_hash: hash });
      setRestoreFlash({ kind: "ok", text: `Restored to ${hash.slice(0, 12)}` });
      setRestoreHash("");
      void refreshAll();
    } catch (err) {
      setRestoreFlash({ kind: "err", text: String((err as Error)?.message ?? err) });
    } finally {
      setRestoreBusy(false);
    }
  }

  // ── Render ────────────────────────────────────────────
  const headShort = (status?.head ?? "").slice(0, 8);

  const diffLines: { line: string; cls: string }[] = (() => {
    if (!diffResult) return [];
    const text =
      typeof diffResult.diff === "string"
        ? diffResult.diff
        : JSON.stringify(diffResult.diff, null, 2);
    return text.split("\n").map((line) => {
      let cls = "text-white/70";
      if (line.startsWith("+") && !line.startsWith("+++"))
        cls = "text-emerald-400";
      else if (line.startsWith("-") && !line.startsWith("---"))
        cls = "text-red-400";
      else if (line.startsWith("@@")) cls = "text-cyan-400";
      return { line, cls };
    });
  })();

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <Wrench className="h-5 w-5 text-white/70" />
        <Typography variant="md" compressed className="text-white">
          Operations
        </Typography>
      </div>

      {/* ── Status ─────────────────────────────────────── */}
      <div className={cardCls}>
        <div className="mb-3 flex items-center justify-between">
          <div className={titleCls}>Status</div>
          <button
            type="button"
            onClick={() => void refreshAll()}
            className={subtleBtn}
          >
            Refresh
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div>
            <div className="text-[0.65rem] uppercase tracking-wider text-white/40">
              Branch
            </div>
            <div className="mt-1 flex items-center gap-2 text-sm text-white">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" />
              {status?.branch ?? "—"}
            </div>
          </div>
          <div>
            <div className="text-[0.65rem] uppercase tracking-wider text-white/40">
              Head
            </div>
            <div className="mt-1 font-mono text-sm text-white">
              {headShort || "—"}
            </div>
          </div>
          <div>
            <div className="text-[0.65rem] uppercase tracking-wider text-white/40">
              Commits
            </div>
            <div className="mt-1 text-sm text-white">
              {status?.total_commits ?? 0}
            </div>
          </div>
          <div>
            <div className="text-[0.65rem] uppercase tracking-wider text-white/40">
              Branches
            </div>
            <div className="mt-1 text-sm text-white">{branches.length}</div>
          </div>
        </div>
      </div>

      {/* ── Quick Commit ──────────────────────────────── */}
      <div className={cardCls}>
        <div className={`${titleCls} mb-3`}>Quick Commit</div>
        <form onSubmit={handleCommit} className="flex flex-col gap-3">
          <input
            type="text"
            value={commitMsg}
            onChange={(e) => setCommitMsg(e.target.value)}
            placeholder="Commit message"
            className={inputCls}
          />
          <div className="flex items-center justify-between gap-3">
            <FlashLine flash={commitFlash} />
            <button
              type="submit"
              disabled={commitBusy || !commitMsg.trim()}
              className={primaryBtn}
            >
              {commitBusy ? "Committing…" : "Commit"}
            </button>
          </div>
        </form>
      </div>

      {/* ── 2-col grid ────────────────────────────────── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Left: branches + diff */}
        <div className="flex flex-col gap-6">
          {/* Branches */}
          <div className={cardCls}>
            <div className={`${titleCls} mb-3`}>Branches</div>
            <div className="flex flex-col gap-2">
              {branches.length === 0 && (
                <div className="text-xs text-white/50">No branches.</div>
              )}
              {branches.map((b) => {
                const isActive =
                  b.name === activeBranch || b.name === status?.branch;
                return (
                  <div
                    key={b.name}
                    className={`flex flex-wrap items-center gap-2 rounded-md border px-3 py-2 ${
                      isActive
                        ? "border-[var(--accent)]/60 bg-[var(--accent)]/10"
                        : "border-white/10 bg-black/20"
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        {isActive && (
                          <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" />
                        )}
                        <span className="text-sm text-white">{b.name}</span>
                        {b.commit_count != null && (
                          <span className="text-[0.65rem] uppercase tracking-wider text-white/40">
                            {b.commit_count} commits
                          </span>
                        )}
                      </div>
                      <div className="mt-0.5 flex items-center gap-3 text-[0.65rem] text-white/40">
                        {b.head && (
                          <span className="font-mono">
                            {String(b.head).slice(0, 8)}
                          </span>
                        )}
                        {b.last_activity != null && (
                          <span>{fmtTs(b.last_activity)}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => void handleSwitch(b.name)}
                        disabled={isActive}
                        className={subtleBtn}
                      >
                        {isActive ? "Active" : "Switch"}
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleMerge(b.name)}
                        disabled={
                          mergingFrom === b.name || b.name === "main"
                        }
                        className={subtleBtn}
                      >
                        {mergingFrom === b.name ? "Merging…" : "Merge → main"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <form
              onSubmit={handleCreateBranch}
              className="mt-4 flex items-center gap-2"
            >
              <input
                type="text"
                value={newBranch}
                onChange={(e) => setNewBranch(e.target.value)}
                placeholder="new-branch-name"
                className={inputCls}
              />
              <button
                type="submit"
                disabled={branchBusy || !newBranch.trim()}
                className={primaryBtn}
              >
                {branchBusy ? "Creating…" : "Create"}
              </button>
            </form>
            <div className="mt-2">
              <FlashLine flash={branchFlash} />
            </div>
          </div>

          {/* Diff */}
          <div className={cardCls}>
            <div className={`${titleCls} mb-3`}>Diff Viewer</div>
            <form onSubmit={handleDiff} className="flex flex-col gap-2">
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <input
                  type="text"
                  value={diffA}
                  onChange={(e) => setDiffA(e.target.value)}
                  placeholder="commit_a"
                  className={inputCls}
                />
                <input
                  type="text"
                  value={diffB}
                  onChange={(e) => setDiffB(e.target.value)}
                  placeholder="commit_b"
                  className={inputCls}
                />
              </div>
              <div className="flex items-center justify-between gap-3">
                <FlashLine flash={diffFlash} />
                <button
                  type="submit"
                  disabled={diffBusy || !diffA.trim() || !diffB.trim()}
                  className={primaryBtn}
                >
                  {diffBusy ? "Computing…" : "Compute Diff"}
                </button>
              </div>
            </form>
            {diffResult && (
              <pre className="mt-3 max-h-96 overflow-auto rounded-md border border-white/10 bg-black/40 p-3 font-mono text-xs leading-relaxed">
                {diffLines.map((l, i) => (
                  <div key={i} className={l.cls}>
                    {l.line || " "}
                  </div>
                ))}
              </pre>
            )}
          </div>
        </div>

        {/* Right: recall + restore */}
        <div className="flex flex-col gap-6">
          {/* Recall */}
          <div className={cardCls}>
            <div className={`${titleCls} mb-3`}>Recall</div>
            <form onSubmit={handleRecall} className="flex items-center gap-2">
              <input
                type="text"
                value={recallQuery}
                onChange={(e) => setRecallQuery(e.target.value)}
                placeholder="search query"
                className={inputCls}
              />
              <button
                type="submit"
                disabled={recallBusy || !recallQuery.trim()}
                className={primaryBtn}
              >
                {recallBusy ? "Searching…" : "Recall"}
              </button>
            </form>
            <div className="mt-2">
              <FlashLine flash={recallFlash} />
            </div>
            {recallResult && recallResult.results?.length > 0 && (
              <div className="mt-3 flex flex-col gap-2">
                {recallResult.results.map((r, i) => (
                  <div
                    key={`${r.hash}-${i}`}
                    className="rounded-md border border-white/10 bg-black/20 p-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[0.65rem] text-white/80">
                        {r.hash.slice(0, 12)}
                      </code>
                      <div className="flex items-center gap-3 text-[0.6rem] uppercase tracking-wider text-white/50">
                        <span>score {r.score.toFixed(3)}</span>
                        {r.timestamp != null && <span>{fmtTs(r.timestamp)}</span>}
                      </div>
                    </div>
                    <div className="mt-1 text-xs text-white/80">{r.message}</div>
                    {(r.excerpt || r.content) && (
                      <div className="mt-1 line-clamp-3 text-[0.7rem] text-white/50">
                        {r.excerpt ?? r.content}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Restore */}
          <div className={cardCls}>
            <div className={`${titleCls} mb-3`}>Restore</div>
            <form onSubmit={handleRestore} className="flex flex-col gap-2">
              <input
                type="text"
                value={restoreHash}
                onChange={(e) => setRestoreHash(e.target.value)}
                placeholder="commit hash"
                className={inputCls}
              />
              <div className="flex items-center justify-between gap-3">
                <FlashLine flash={restoreFlash} />
                <button
                  type="submit"
                  disabled={restoreBusy || !restoreHash.trim()}
                  className={primaryBtn}
                >
                  {restoreBusy ? "Restoring…" : "Restore"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
