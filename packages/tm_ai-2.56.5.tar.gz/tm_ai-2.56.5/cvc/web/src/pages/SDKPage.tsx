import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Boxes, RefreshCw } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type AgentTemplate,
  type AgentsListResponse,
  type HiveMindAgent,
  type SquadInfo,
} from "@/lib/api";
import { useDashboardWS, type DashboardEvent } from "@/lib/useDashboardWS";

interface SdkAgent {
  id: string;
  name: string;
  role: string;
  rank: string;
  squad: string;
  source: string;
}

function normalize(
  agents: AgentsListResponse | null,
  hive: HiveMindAgent[],
): SdkAgent[] {
  const out = new Map<string, SdkAgent>();

  // From /api/agents — registered + templates
  if (agents) {
    for (const r of agents.registered ?? []) {
      const o = r as Record<string, unknown>;
      const id =
        (o.agent_id as string) ?? (o.id as string) ?? "";
      if (!id) continue;
      out.set(id, {
        id,
        name: (o.name as string) ?? "—",
        role: (o.role as string) ?? "—",
        rank: (o.rank as string) ?? "—",
        squad: (o.squad as string) ?? "—",
        source: "registered",
      });
    }
    for (const t of agents.templates ?? []) {
      if (out.has(t.id)) continue;
      out.set(t.id, sdkFromTemplate(t, "template"));
    }
    for (const t of agents.builtins ?? []) {
      if (out.has(t.id)) continue;
      out.set(t.id, sdkFromTemplate(t, "builtin"));
    }
  }

  // From /api/hivemind/agents
  for (const a of hive) {
    if (out.has(a.agent_id)) {
      const cur = out.get(a.agent_id)!;
      cur.source = `${cur.source}+hive`;
      continue;
    }
    out.set(a.agent_id, {
      id: a.agent_id,
      name: a.name ?? "—",
      role: a.role ?? "—",
      rank: a.rank ?? "—",
      squad: a.squad ?? "—",
      source: "hive",
    });
  }

  return Array.from(out.values()).sort((a, b) => a.id.localeCompare(b.id));
}

function sdkFromTemplate(t: AgentTemplate, source: string): SdkAgent {
  return {
    id: t.id,
    name: t.name ?? "—",
    role: t.source ?? "template",
    rank: t.rank ?? "—",
    squad: t.squad ?? "—",
    source,
  };
}

const FEED_LIMIT = 25;

export default function SDKPage() {
  const [agents, setAgents] = useState<AgentsListResponse | null>(null);
  const [hive, setHive] = useState<HiveMindAgent[]>([]);
  const [squads, setSquads] = useState<SquadInfo[]>([]);
  const [templates, setTemplates] = useState<AgentTemplate[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [flash, setFlashMsg] = useState<{ kind: "ok" | "err"; msg: string } | null>(
    null,
  );
  const [feed, setFeed] = useState<DashboardEvent[]>([]);
  const feedRef = useRef<HTMLPreElement | null>(null);

  const showFlash = (kind: "ok" | "err", msg: string) => {
    setFlashMsg({ kind, msg });
    window.setTimeout(() => setFlashMsg(null), 2000);
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [a, h, sq, tp] = await Promise.all([
        api
          .agentsList()
          .catch(
            () =>
              ({
                registered: [],
                templates: [],
                builtins: [],
                total: 0,
              }) as AgentsListResponse,
          ),
        api
          .hivemindAgents()
          .catch(() => [] as HiveMindAgent[])
          .then((r) =>
            Array.isArray(r) ? r : ((r as { agents?: HiveMindAgent[] }).agents ?? []),
          ),
        api.squadList().catch(() => [] as SquadInfo[]),
        api.agentsBuiltin().catch(() => [] as AgentTemplate[]),
      ]);
      setAgents(a);
      setHive(h);
      setSquads(sq);
      setTemplates(tp);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Telemetry stream from dashboard WS
  useDashboardWS((evt) => {
    setFeed((prev) => {
      const next = [...prev, evt];
      if (next.length > FEED_LIMIT) next.splice(0, next.length - FEED_LIMIT);
      return next;
    });
    // auto-scroll
    requestAnimationFrame(() => {
      if (feedRef.current) {
        feedRef.current.scrollTop = feedRef.current.scrollHeight;
      }
    });
  });

  const rows = useMemo(() => normalize(agents, hive), [agents, hive]);

  const stats = useMemo(
    () => ({
      agents: rows.length,
      squads: squads.length,
      templates: templates.length,
    }),
    [rows, squads, templates],
  );

  const ping = async (id: string) => {
    showFlash("ok", `Pinged ${id}`);
    void api
      .telemetry({ event: "ping", target_agent_id: id })
      .catch(() => {
        /* fire-and-forget */
      });
  };

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Boxes className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            SDK
          </Typography>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="inline-flex items-center gap-1 rounded border border-border bg-card/60 px-2.5 py-1.5 text-xs text-midground/80 hover:bg-midground/10 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          {error}
        </div>
      )}
      {flash && (
        <div
          className={`text-xs ${flash.kind === "ok" ? "text-emerald-400" : "text-red-400"}`}
        >
          {flash.msg}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Agents" value={String(stats.agents)} />
        <Stat label="Squads" value={String(stats.squads)} />
        <Stat label="Templates" value={String(stats.templates)} />
      </div>

      {/* Agents table */}
      <section className="overflow-hidden rounded-lg border border-border bg-card/40">
        <div className="border-b border-border bg-midground/5 px-4 py-2 text-[0.65rem] uppercase tracking-wider text-midground/55 font-mono-ui">
          Agents
        </div>
        {rows.length === 0 ? (
          <div className="px-4 py-6 text-sm text-midground/55">
            No agents registered.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-border bg-midground/5">
                <tr className="text-[0.65rem] uppercase tracking-wider text-midground/55">
                  <th className="px-4 py-2 font-medium">ID</th>
                  <th className="px-4 py-2 font-medium">Name</th>
                  <th className="px-4 py-2 font-medium">Role</th>
                  <th className="px-4 py-2 font-medium">Rank</th>
                  <th className="px-4 py-2 font-medium">Squad</th>
                  <th className="px-4 py-2 font-medium">Source</th>
                  <th className="px-4 py-2 font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((a) => (
                  <tr
                    key={a.id}
                    className="border-b border-border/40 last:border-b-0 hover:bg-midground/5"
                  >
                    <td className="px-4 py-2 font-mono text-xs text-midground/85">
                      {a.id}
                    </td>
                    <td className="px-4 py-2 text-xs text-midground/85">{a.name}</td>
                    <td className="px-4 py-2 text-xs text-midground/70">{a.role}</td>
                    <td className="px-4 py-2 text-xs text-midground/70">{a.rank}</td>
                    <td className="px-4 py-2 text-xs text-midground/70">{a.squad}</td>
                    <td className="px-4 py-2 font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/55">
                      {a.source}
                    </td>
                    <td className="px-4 py-2">
                      <button
                        type="button"
                        onClick={() => ping(a.id)}
                        className="rounded border border-border bg-card/60 px-2 py-1 text-[0.65rem] uppercase tracking-wider text-midground/80 hover:bg-midground/10"
                      >
                        Ping
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Telemetry feed */}
      <section className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Typography variant="sm" compressed className="text-midground/70">
            Telemetry Stream
          </Typography>
          <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55">
            last {feed.length}/{FEED_LIMIT}
          </span>
        </div>
        <pre
          ref={feedRef}
          className="max-h-80 overflow-auto rounded-lg border border-border bg-background-base/40 p-3 font-mono text-[0.7rem] text-midground/80"
        >
          {feed.length === 0
            ? "(waiting for events…)"
            : feed
                .map((e) =>
                  JSON.stringify(
                    { type: e.type, ts: e.timestamp, payload: e.payload },
                    null,
                    0,
                  ),
                )
                .join("\n")}
        </pre>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="text-[0.65rem] uppercase tracking-[0.18em] text-midground/55 font-mono-ui">
        {label}
      </div>
      <div className="mt-1.5 text-2xl font-bold text-midground tabular-nums">
        {value}
      </div>
    </div>
  );
}
