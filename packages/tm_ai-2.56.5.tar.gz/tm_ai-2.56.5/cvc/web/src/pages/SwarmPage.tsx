/**
 * SwarmPage — hierarchical, zoomable swarm visualisation.
 *
 * The Singularity sits at the center. The Mission Controller (MC-01) orbits it.
 * Squad captains orbit the MC. Each captain has its own constellation of
 * specialists clustered around it. Each squad gets its own colour so the
 * hierarchy is readable at a glance.
 *
 * Mouse wheel = zoom (around cursor). Drag = pan. Hover/click = inspector.
 */
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import {
  Maximize2,
  Minimize2,
  Network,
  Pause,
  Play,
  RefreshCcw,
  Trash2,
} from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api } from "@/lib/api";
import { useDashboardWS, type DashboardEvent } from "@/lib/useDashboardWS";

// ── types ───────────────────────────────────────────────────────────────────

type Tier = "mc" | "captain" | "specialist" | "misc";

interface SwarmNode {
  id: string;
  name?: string;
  role?: string;
  squad?: string;
  rank?: string;
  status?: string;
  tier: Tier;
}

interface NodePos extends SwarmNode {
  x: number;
  y: number;
  squadColor: string;
}

interface Pulse {
  id: number;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  color: string;
  t: number;
  startedAt: number;
  durationMs: number;
}

interface TelemetryRow {
  id: number;
  ts: number;
  type: string;
  from?: string;
  to?: string;
  text: string;
}

type TelemetryPayload = { [k: string]: unknown };

// ── constants ───────────────────────────────────────────────────────────────

const VIEW_W = 1600;
const VIEW_H = 1000;
const CENTER_X = VIEW_W / 2;
const CENTER_Y = VIEW_H / 2;
const SUPERBRAIN_ID = "__superbrain__";
const SUPERBRAIN_RADIUS = 42;
const MC_RADIUS = 28;
const CAPTAIN_RADIUS = 22;
const SPECIALIST_RADIUS = 12;
const PULSE_DURATION_MS = 900;
const MAX_LOG = 60;

// Stable per-squad colour palette — vivid, distinguishable.
const SQUAD_PALETTE = [
  "#ff6b6b", // coral
  "#4dabf7", // sky
  "#51cf66", // green
  "#ffd43b", // amber
  "#cc5de8", // violet
  "#ff922b", // orange
  "#22d3ee", // cyan
  "#f06595", // pink
  "#94d82d", // lime
  "#ff8787", // soft red
];
const MC_COLOR = "#ffffff";
const SINGULARITY_COLOR = "#ff5252";
const PULSE_COLORS: Record<string, string> = {
  "agent.message": "#ffaa00",
  "agent.spawn": "#22d3ee",
  telemetry: "#d06262",
  default: "#ffffff",
};

// ── helpers ─────────────────────────────────────────────────────────────────

function pickStr(o: TelemetryPayload, ...keys: string[]): string | undefined {
  for (const k of keys) {
    const v = o[k];
    if (typeof v === "string" && v.length > 0) return v;
  }
  return undefined;
}

function squadColor(name: string, index: number): string {
  if (!name || name === "Command" || name === "alpha") return MC_COLOR;
  return SQUAD_PALETTE[index % SQUAD_PALETTE.length];
}

interface SquadGroup {
  name: string;
  captain: SwarmNode | null;
  specialists: SwarmNode[];
  others: SwarmNode[];
  color: string;
}

/**
 * Hierarchical layout:
 *  - Singularity at centre (drawn separately; not a node).
 *  - MC orbits singularity at radius R0.
 *  - Each squad gets a slice of the circle around the MC at radius R1,
 *    with the captain at the slice's centre. Specialists cluster around
 *    the captain in a small ring at radius R2.
 *  - Squads with no captain land in their own ring at R1.
 */
function layoutHierarchical(nodes: SwarmNode[]): NodePos[] {
  if (nodes.length === 0) return [];

  // Bucket
  const mc = nodes.find((n) => n.tier === "mc") || null;
  const squadsMap = new Map<string, SquadGroup>();
  for (const n of nodes) {
    if (n === mc) continue;
    const sq = n.squad || "unaffiliated";
    let g = squadsMap.get(sq);
    if (!g) {
      g = {
        name: sq,
        captain: null,
        specialists: [],
        others: [],
        color: "#888",
      };
      squadsMap.set(sq, g);
    }
    if (n.tier === "captain" && !g.captain) g.captain = n;
    else if (n.tier === "specialist") g.specialists.push(n);
    else g.others.push(n);
  }

  // Stable squad ordering: by member count desc, then name.
  const squads = Array.from(squadsMap.values()).sort((a, b) => {
    const sa = (a.captain ? 1 : 0) + a.specialists.length + a.others.length;
    const sb = (b.captain ? 1 : 0) + b.specialists.length + b.others.length;
    if (sa !== sb) return sb - sa;
    return a.name.localeCompare(b.name);
  });
  squads.forEach((s, i) => {
    s.color = squadColor(s.name, i);
  });

  const out: NodePos[] = [];

  // MC orbit
  const MC_RING = 130;
  if (mc) {
    out.push({
      ...mc,
      x: CENTER_X,
      y: CENTER_Y - MC_RING,
      squadColor: MC_COLOR,
    });
  }

  // Captain ring radius (kept inside VIEW_H/2 so squad clusters never clip).
  const CAP_RING = 320;
  // Specialist cluster radius around captain
  const SPC_RING = 100;

  squads.forEach((sq, sqIdx) => {
    const totalSlices = squads.length;
    const sliceCenterAngle =
      (sqIdx / totalSlices) * Math.PI * 2 - Math.PI / 2;
    const cx = CENTER_X + Math.cos(sliceCenterAngle) * CAP_RING;
    const cy = CENTER_Y + Math.sin(sliceCenterAngle) * CAP_RING;

    if (sq.captain) {
      out.push({
        ...sq.captain,
        x: cx,
        y: cy,
        squadColor: sq.color,
      });
    }

    const specialistTargets = [...sq.specialists, ...sq.others];
    const n = specialistTargets.length;
    if (n === 0) return;

    // Spread specialists in a partial arc facing AWAY from singularity,
    // so the cluster reads as "this squad", not just dots overlapping.
    const facingOut = sliceCenterAngle; // outward direction
    const arcSpan = Math.min(Math.PI * 1.4, 0.5 + n * 0.18);
    const startAngle = facingOut - arcSpan / 2;
    for (let i = 0; i < n; i += 1) {
      const t = n === 1 ? 0.5 : i / (n - 1);
      const a = startAngle + t * arcSpan;
      // Two sub-rings if more than 8 specialists, to avoid label collisions
      const ring = n > 8 && i % 2 === 1 ? SPC_RING + 60 : SPC_RING;
      const x = cx + Math.cos(a) * ring;
      const y = cy + Math.sin(a) * ring;
      out.push({
        ...specialistTargets[i],
        x,
        y,
        squadColor: sq.color,
      });
    }
  });

  return out;
}

// ── component ───────────────────────────────────────────────────────────────

export default function SwarmPage() {
  const [nodes, setNodes] = useState<SwarmNode[]>([]);
  const [edges, setEdges] = useState<Array<{ from: string; to: string; type: string }>>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [paused, setPaused] = useState(false);
  const [hovered, setHovered] = useState<string | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(
    null,
  );
  const [log, setLog] = useState<TelemetryRow[]>([]);

  // ── viewport (zoom + pan) ──────────────────────────────────────────────
  // Tracks an SVG viewBox transform: x, y, zoom (1 = fit).
  const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 });
  const isPanningRef = useRef(false);
  const panStartRef = useRef<{ mx: number; my: number; vx: number; vy: number } | null>(null);

  const pulsesRef = useRef<Map<number, Pulse>>(new Map());
  const pulseSeqRef = useRef(0);
  const logSeqRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const pausedRef = useRef(false);
  pausedRef.current = paused;
  const [pulseTick, setPulseTick] = useState(0);

  const layout = useMemo<NodePos[]>(() => layoutHierarchical(nodes), [nodes]);

  // Auto-fit whenever layout changes (until the user manually pans/zooms,
  // tracked by didUserInteractRef). This keeps the swarm centered when new
  // agents join.
  const didUserInteractRef = useRef(false);
  useEffect(() => {
    if (didUserInteractRef.current) return;
    if (layout.length === 0) return;
    requestAnimationFrame(() => {
      const padding = 120;
      const xs = [CENTER_X, ...layout.map((p) => p.x)];
      const ys = [CENTER_Y, ...layout.map((p) => p.y)];
      const minX = Math.min(...xs) - padding;
      const maxX = Math.max(...xs) + padding;
      const minY = Math.min(...ys) - padding;
      const maxY = Math.max(...ys) + padding;
      const w = Math.max(1, maxX - minX);
      const h = Math.max(1, maxY - minY);
      const zoom = Math.min(VIEW_W / w, VIEW_H / h);
      const vbW = VIEW_W / zoom;
      const vbH = VIEW_H / zoom;
      const cx = (minX + maxX) / 2;
      const cy = (minY + maxY) / 2;
      setViewport({ x: cx - vbW / 2, y: cy - vbH / 2, zoom });
    });
  }, [layout]);
  const posIndex = useMemo(() => {
    const m = new Map<string, NodePos>();
    for (const p of layout) m.set(p.id, p);
    return m;
  }, [layout]);

  // Squad list for the legend
  const squadLegend = useMemo(() => {
    const groups = new Map<string, { count: number; color: string; captain?: string }>();
    for (const p of layout) {
      const sq = p.squad || "unaffiliated";
      const g = groups.get(sq) ?? { count: 0, color: p.squadColor };
      g.count += 1;
      if (p.tier === "captain") g.captain = p.id;
      g.color = p.squadColor;
      groups.set(sq, g);
    }
    return Array.from(groups.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.count - a.count);
  }, [layout]);

  // ── data fetch ─────────────────────────────────────────────────────────
  const refreshTopology = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.swarmTopology();
      const ns: SwarmNode[] = (data.nodes ?? []).map((n) => ({
        id: n.id,
        name: n.name,
        role: n.role,
        rank: n.rank,
        squad: n.squad,
        status: n.status,
        tier: (n.tier as Tier) ?? "misc",
      }));
      setNodes(ns);
      setEdges(data.edges ?? []);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshTopology();
  }, [refreshTopology]);

  // ── pulse spawning ────────────────────────────────────────────────────
  const spawnPulse = useCallback(
    (fromId: string, toId: string, color: string) => {
      const tryResolve = (attempt: number) => {
        const fromPos =
          fromId === SUPERBRAIN_ID
            ? { x: CENTER_X, y: CENTER_Y }
            : posIndex.get(fromId);
        const toPos =
          toId === SUPERBRAIN_ID
            ? { x: CENTER_X, y: CENTER_Y }
            : posIndex.get(toId);
        if (!fromPos || !toPos) {
          if (attempt < 10) {
            window.setTimeout(() => tryResolve(attempt + 1), 50);
          }
          return;
        }
        const id = ++pulseSeqRef.current;
        pulsesRef.current.set(id, {
          id,
          fromX: fromPos.x,
          fromY: fromPos.y,
          toX: toPos.x,
          toY: toPos.y,
          color,
          t: 0,
          startedAt: performance.now(),
          durationMs: PULSE_DURATION_MS,
        });
      };
      tryResolve(0);
    },
    [posIndex],
  );

  const onEvent = useCallback(
    (evt: DashboardEvent) => {
      if (!evt || typeof evt.type !== "string") return;
      const type = evt.type;
      if (
        type !== "agent.message" &&
        type !== "agent.spawn" &&
        type !== "telemetry"
      )
        return;
      const payload: TelemetryPayload =
        evt.payload && typeof evt.payload === "object"
          ? (evt.payload as TelemetryPayload)
          : {};
      const from = pickStr(payload, "from", "sender", "agent_id", "agent", "src");
      const to = pickStr(payload, "to", "receiver", "target", "dst");
      if (type === "agent.spawn" && from && !to) {
        spawnPulse(SUPERBRAIN_ID, from, PULSE_COLORS["agent.spawn"]);
      } else {
        const fromId = from ?? SUPERBRAIN_ID;
        const toId = to ?? SUPERBRAIN_ID;
        if (fromId !== toId) {
          spawnPulse(fromId, toId, PULSE_COLORS[type] ?? PULSE_COLORS.default);
        }
      }
      const text =
        pickStr(payload, "message", "text", "content", "summary") ??
        pickStr(payload, "action", "category") ??
        type;
      logSeqRef.current += 1;
      setLog((prev) =>
        [
          {
            id: logSeqRef.current,
            ts: typeof evt.timestamp === "number" ? evt.timestamp : Date.now(),
            type,
            from,
            to,
            text,
          },
          ...prev,
        ].slice(0, MAX_LOG),
      );
    },
    [spawnPulse],
  );

  useDashboardWS(onEvent);

  // ── animation loop ────────────────────────────────────────────────────
  useEffect(() => {
    let mounted = true;
    const step = () => {
      if (!mounted) return;
      if (!pausedRef.current) {
        const now = performance.now();
        const live = pulsesRef.current;
        const dead: number[] = [];
        for (const p of live.values()) {
          p.t = Math.min(1, (now - p.startedAt) / p.durationMs);
          if (p.t >= 1) dead.push(p.id);
        }
        for (const id of dead) live.delete(id);
        setPulseTick((n) => (live.size > 0 ? n + 1 : n));
      }
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      mounted = false;
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  // ── handlers ──────────────────────────────────────────────────────────
  const onClear = () => {
    setLog([]);
    pulsesRef.current.clear();
  };
  const resetView = () => {
    didUserInteractRef.current = false;
    fitToContent();
  };
  const fitToContent = useCallback(() => {
    const padding = 80;
    const xs: number[] = [CENTER_X];
    const ys: number[] = [CENTER_Y];
    for (const p of layout) {
      xs.push(p.x);
      ys.push(p.y);
    }
    if (xs.length < 2) {
      setViewport({ x: 0, y: 0, zoom: 1 });
      return;
    }
    const minX = Math.min(...xs) - padding;
    const maxX = Math.max(...xs) + padding;
    const minY = Math.min(...ys) - padding;
    const maxY = Math.max(...ys) + padding;
    const w = Math.max(1, maxX - minX);
    const h = Math.max(1, maxY - minY);
    const zoom = Math.min(VIEW_W / w, VIEW_H / h);
    const vbW = VIEW_W / zoom;
    const vbH = VIEW_H / zoom;
    // Center the bbox inside the viewBox.
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    setViewport({ x: cx - vbW / 2, y: cy - vbH / 2, zoom });
  }, [layout]);
  const zoomBy = (factor: number) =>
    setViewport((v) => ({ ...v, zoom: Math.min(8, Math.max(0.2, v.zoom * factor)) }));

  const svgRef = useRef<SVGSVGElement | null>(null);

  /** Convert mouse-event coords to internal viewBox coords. */
  const clientToView = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } => {
      const svg = svgRef.current;
      if (!svg) return { x: 0, y: 0 };
      const rect = svg.getBoundingClientRect();
      const px = (clientX - rect.left) / rect.width; // 0..1
      const py = (clientY - rect.top) / rect.height;
      // Current viewBox: (vx, vy, vw, vh)
      const vw = VIEW_W / viewport.zoom;
      const vh = VIEW_H / viewport.zoom;
      return {
        x: viewport.x + px * vw,
        y: viewport.y + py * vh,
      };
    },
    [viewport.x, viewport.y, viewport.zoom],
  );

  // Wheel = zoom around cursor
  const onWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    didUserInteractRef.current = true;
    const direction = e.deltaY < 0 ? 1.15 : 1 / 1.15;
    const newZoom = Math.min(8, Math.max(0.2, viewport.zoom * direction));
    if (newZoom === viewport.zoom) return;
    // Anchor zoom at cursor: keep the world point under the cursor stationary.
    const cursor = clientToView(e.clientX, e.clientY);
    const oldVW = VIEW_W / viewport.zoom;
    const oldVH = VIEW_H / viewport.zoom;
    const newVW = VIEW_W / newZoom;
    const newVH = VIEW_H / newZoom;
    // cursorPx in 0..1
    const svg = svgRef.current;
    const rect = svg?.getBoundingClientRect();
    const px = rect ? (e.clientX - rect.left) / rect.width : 0.5;
    const py = rect ? (e.clientY - rect.top) / rect.height : 0.5;
    const newX = cursor.x - px * newVW;
    const newY = cursor.y - py * newVH;
    // Touch oldVW/oldVH so eslint doesn't complain about unused vars.
    void oldVW;
    void oldVH;
    setViewport({ x: newX, y: newY, zoom: newZoom });
  };

  const onMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    didUserInteractRef.current = true;
    isPanningRef.current = true;
    panStartRef.current = {
      mx: e.clientX,
      my: e.clientY,
      vx: viewport.x,
      vy: viewport.y,
    };
  };
  const onMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPanningRef.current || !panStartRef.current) return;
    const svg = svgRef.current;
    const rect = svg?.getBoundingClientRect();
    if (!rect) return;
    const dxPx = e.clientX - panStartRef.current.mx;
    const dyPx = e.clientY - panStartRef.current.my;
    const vw = VIEW_W / viewport.zoom;
    const vh = VIEW_H / viewport.zoom;
    const dxView = (dxPx / rect.width) * vw;
    const dyView = (dyPx / rect.height) * vh;
    setViewport((v) => ({
      ...v,
      x: panStartRef.current!.vx - dxView,
      y: panStartRef.current!.vy - dyView,
    }));
  };
  const onMouseUp = () => {
    isPanningRef.current = false;
    panStartRef.current = null;
  };

  const onAgentEnter = (id: string, e: React.MouseEvent<SVGGElement>) => {
    setHovered(id);
    const rect = svgRef.current?.getBoundingClientRect();
    if (rect) setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };
  const onAgentMove = (e: React.MouseEvent<SVGGElement>) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (rect) setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };
  const onAgentLeave = () => {
    setHovered(null);
    setTooltipPos(null);
  };

  const hoveredAgent = hovered ? layout.find((n) => n.id === hovered) ?? null : null;

  const pulseList: Pulse[] = useMemo(
    () => Array.from(pulsesRef.current.values()),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pulseTick],
  );

  // Resolved viewBox
  const vbW = VIEW_W / viewport.zoom;
  const vbH = VIEW_H / viewport.zoom;
  const viewBox = `${viewport.x} ${viewport.y} ${vbW} ${vbH}`;

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-3">
          <Network className="h-5 w-5 text-midground/80" />
          <div>
            <Typography variant="md" compressed className="text-midground uppercase">
              Swarm
            </Typography>
            <div className="text-xs text-midground/55">
              Hierarchical topology · {nodes.length} agents · {squadLegend.length} squads ·{" "}
              {paused ? "paused" : "streaming"}
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => zoomBy(1.25)}
            className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5"
            title="Zoom in"
          >
            <Maximize2 className="h-3.5 w-3.5" /> Zoom +
          </button>
          <button
            type="button"
            onClick={() => zoomBy(1 / 1.25)}
            className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5"
            title="Zoom out"
          >
            <Minimize2 className="h-3.5 w-3.5" /> Zoom −
          </button>
          <button
            type="button"
            onClick={resetView}
            className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5"
          >
            <RefreshCcw className="h-3.5 w-3.5" /> Fit
          </button>
          <button
            type="button"
            onClick={() => setPaused((p) => !p)}
            className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5"
          >
            {paused ? (
              <>
                <Play className="h-3.5 w-3.5" /> Resume
              </>
            ) : (
              <>
                <Pause className="h-3.5 w-3.5" /> Pause
              </>
            )}
          </button>
          <button
            type="button"
            onClick={onClear}
            className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-3 py-1.5 text-xs uppercase tracking-wider text-white/80 hover:bg-white/5"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </button>
          <button
            type="button"
            onClick={() => void refreshTopology()}
            className="inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-white hover:opacity-90"
          >
            Reload
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-md border border-red-400/40 bg-red-400/10 px-3 py-2 text-xs text-red-300">
          {error}
        </div>
      )}

      {/* Canvas card */}
      <div className="relative rounded-xl border border-white/10 bg-white/5 p-3">
        <div
          className="relative w-full overflow-hidden rounded-lg bg-[radial-gradient(ellipse_at_center,_#1a0808_0%,_#000_70%)] select-none"
          style={{ aspectRatio: `${VIEW_W} / ${VIEW_H}`, cursor: isPanningRef.current ? "grabbing" : "grab" } as CSSProperties}
          onWheel={onWheel}
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={onMouseUp}
          onMouseLeave={() => {
            onMouseUp();
            onAgentLeave();
          }}
        >
          <svg
            ref={svgRef}
            viewBox={viewBox}
            preserveAspectRatio="xMidYMid meet"
            className="absolute inset-0 h-full w-full"
          >
            <defs>
              <radialGradient id="brain-grad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
                <stop offset="55%" stopColor={SINGULARITY_COLOR} stopOpacity="0.55" />
                <stop offset="100%" stopColor="#1a0303" stopOpacity="0.1" />
              </radialGradient>
              <filter id="glow" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="glow-soft" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Edges from topology — command (white) and squad (squad colour). */}
            <g fill="none">
              {edges.map((e, i) => {
                const a = posIndex.get(e.from);
                const b = posIndex.get(e.to);
                if (!a || !b) return null;
                const stroke =
                  e.type === "command" ? "rgba(255,255,255,0.55)" : b.squadColor;
                const opacity = e.type === "command" ? 0.6 : 0.35;
                return (
                  <line
                    key={`edge-${i}`}
                    x1={a.x}
                    y1={a.y}
                    x2={b.x}
                    y2={b.y}
                    stroke={stroke}
                    strokeWidth={e.type === "command" ? 1.8 : 1}
                    opacity={opacity}
                  />
                );
              })}
              {/* Singularity → MC line (if MC exists) */}
              {layout
                .filter((n) => n.tier === "mc")
                .map((mc) => (
                  <line
                    key="link-mc"
                    x1={CENTER_X}
                    y1={CENTER_Y}
                    x2={mc.x}
                    y2={mc.y}
                    stroke="rgba(255,255,255,0.7)"
                    strokeWidth={2}
                  />
                ))}
            </g>

            {/* Singularity */}
            <g transform={`translate(${CENTER_X}, ${CENTER_Y})`} filter="url(#glow)">
              <circle r={SUPERBRAIN_RADIUS + 14} fill="url(#brain-grad)" />
              <circle
                r={SUPERBRAIN_RADIUS}
                fill="none"
                stroke="#ffffff"
                strokeOpacity={0.55}
                strokeWidth={1.4}
              />
              <text
                y={4}
                textAnchor="middle"
                className="font-mono-ui"
                fontSize={12}
                fontWeight={700}
                fill="#fff"
                style={{ letterSpacing: "0.22em" }}
              >
                SINGULARITY
              </text>
            </g>

            {/* Pulses */}
            <g>
              {pulseList.map((p) => {
                const x = p.fromX + (p.toX - p.fromX) * p.t;
                const y = p.fromY + (p.toY - p.fromY) * p.t;
                return (
                  <circle key={p.id} cx={x} cy={y} r={6} fill={p.color} opacity={1 - p.t * 0.4} />
                );
              })}
            </g>

            {/* Nodes */}
            <g>
              {layout.map((p) => {
                const isHovered = hovered === p.id;
                const radius =
                  p.tier === "mc"
                    ? MC_RADIUS
                    : p.tier === "captain"
                      ? CAPTAIN_RADIUS
                      : SPECIALIST_RADIUS;
                const ringColor = p.tier === "mc" ? MC_COLOR : p.squadColor;
                return (
                  <g
                    key={`node-${p.id}`}
                    transform={`translate(${p.x}, ${p.y})`}
                    onMouseEnter={(e) => onAgentEnter(p.id, e)}
                    onMouseMove={onAgentMove}
                    onMouseLeave={onAgentLeave}
                    style={{ cursor: "pointer" }}
                    filter={p.tier === "captain" || p.tier === "mc" ? "url(#glow-soft)" : undefined}
                  >
                    <circle
                      r={radius + (isHovered ? 4 : 0)}
                      fill="rgba(0,0,0,0.55)"
                      stroke={ringColor}
                      strokeWidth={p.tier === "mc" ? 2.5 : p.tier === "captain" ? 2 : 1.4}
                    />
                    <circle r={Math.max(3, radius * 0.3)} fill={ringColor} />
                    {(p.tier === "mc" || p.tier === "captain" || isHovered || viewport.zoom > 1.5) && (
                      <text
                        y={radius + 12}
                        textAnchor="middle"
                        fontSize={p.tier === "mc" ? 12 : p.tier === "captain" ? 11 : 9}
                        fontWeight={p.tier === "mc" || p.tier === "captain" ? 700 : 400}
                        fill="rgba(255,255,255,0.85)"
                        className="font-mono-ui"
                        style={{ pointerEvents: "none" }}
                      >
                        {p.id}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Tooltip */}
          {hoveredAgent && tooltipPos && (
            <div
              className="pointer-events-none absolute z-10 max-w-[260px] rounded-md border border-white/15 bg-black/85 px-2.5 py-1.5 text-[11px] text-white shadow-lg"
              style={{ left: Math.min(tooltipPos.x + 12, 9999), top: tooltipPos.y + 12 }}
            >
              <div
                className="font-mono-ui font-semibold uppercase tracking-wider"
                style={{ color: hoveredAgent.squadColor }}
              >
                {hoveredAgent.name ?? hoveredAgent.id}
              </div>
              <div className="text-white/60">{hoveredAgent.id}</div>
              {hoveredAgent.role && <div className="text-white/70">role: {hoveredAgent.role}</div>}
              {hoveredAgent.squad && <div className="text-white/70">squad: {hoveredAgent.squad}</div>}
              <div className="text-white/70">tier: {hoveredAgent.tier}</div>
            </div>
          )}

          {/* Squad legend */}
          {squadLegend.length > 0 && (
            <div className="absolute left-3 top-3 max-h-[80%] w-[220px] overflow-y-auto rounded-md border border-white/10 bg-black/70 p-2 text-[11px]">
              <div className="mb-1.5 font-mono-ui text-[10px] uppercase tracking-wider text-white/50">
                Squads ({squadLegend.length})
              </div>
              <ul className="space-y-1">
                {squadLegend.map((s) => (
                  <li key={s.name} className="flex items-center gap-2">
                    <span
                      className="inline-block h-2.5 w-2.5 rounded-full"
                      style={{ background: s.color }}
                    />
                    <span className="font-mono-ui text-white/85">{s.name}</span>
                    <span className="ml-auto text-white/50">{s.count}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Zoom indicator */}
          <div className="pointer-events-none absolute right-3 top-3 rounded-md border border-white/10 bg-black/70 px-2 py-1 font-mono-ui text-[10px] uppercase tracking-wider text-white/60">
            zoom {viewport.zoom.toFixed(2)}× · scroll to zoom · drag to pan
          </div>

          {loading && nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-white/50">
              Loading swarm…
            </div>
          )}
          {!loading && nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-white/50">
              No agents registered.
            </div>
          )}
        </div>
      </div>

      {/* Inspector — recent telemetry */}
      <div className="rounded-xl border border-white/10 bg-white/5 p-5">
        <div className="mb-3 flex items-center justify-between">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] text-white/60">
            Recent Telemetry
          </div>
          <div className="text-[10px] uppercase tracking-wider text-white/40">
            showing last {Math.min(log.length, 12)} of {log.length}
          </div>
        </div>
        {log.length === 0 ? (
          <div className="text-xs text-white/40">
            No telemetry yet. Events will appear here as agents communicate.
          </div>
        ) : (
          <ul className="max-h-64 space-y-1 overflow-y-auto pr-1">
            {log.slice(0, 12).map((row) => (
              <li
                key={row.id}
                className="flex items-start gap-3 rounded-md border border-white/5 bg-black/30 px-2.5 py-1.5 text-[11px]"
              >
                <span className="font-mono-ui text-white/40">
                  {new Date(row.ts).toLocaleTimeString([], { hour12: false })}
                </span>
                <span
                  className="font-mono-ui font-semibold uppercase tracking-wider"
                  style={{ color: PULSE_COLORS[row.type] ?? PULSE_COLORS.default }}
                >
                  {row.type}
                </span>
                {row.from && <span className="font-mono-ui text-white/70">{row.from}</span>}
                {row.to && (
                  <>
                    <span className="text-white/40">→</span>
                    <span className="font-mono-ui text-white/70">{row.to}</span>
                  </>
                )}
                <span className="min-w-0 flex-1 truncate text-white/80">{row.text}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
