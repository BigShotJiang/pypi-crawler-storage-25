import { useEffect, useState } from "react";
import { Crown, Code2, FlaskConical, Briefcase, Users, RefreshCw } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type TeamMember } from "@/lib/api";

const ICONS: Record<string, typeof Crown> = {
  "SOFIA-01": Crown,
  "TINA-01": Code2,
  "SAM-01": FlaskConical,
  "ROBIN-01": Briefcase,
};

const ACCENT: Record<string, string> = {
  "SOFIA-01": "text-amber-300 border-amber-400/40 bg-amber-500/5",
  "TINA-01": "text-emerald-300 border-emerald-400/40 bg-emerald-500/5",
  "SAM-01": "text-sky-300 border-sky-400/40 bg-sky-500/5",
  "ROBIN-01": "text-fuchsia-300 border-fuchsia-400/40 bg-fuchsia-500/5",
};

export default function TeamPage() {
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    try {
      const snap = await api.team();
      setTeam(snap.team.length ? snap.team : snap.canonical);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  const ensure = async () => {
    setBusy(true);
    try {
      await api.teamEnsure();
      await refresh();
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 8000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            The Core 4
          </Typography>
        </div>
        <button
          type="button"
          onClick={ensure}
          disabled={busy}
          className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1 font-mono-ui text-xs text-midground hover:bg-card/50 disabled:opacity-50"
        >
          <RefreshCw className={`h-3 w-3 ${busy ? "animate-spin" : ""}`} />
          Ensure registered
        </button>
      </div>

      {error && (
        <div className="rounded-md border border-rose-400/40 bg-rose-500/10 px-3 py-2 font-mono-ui text-xs text-rose-300">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {team.map((m) => {
          const Icon = ICONS[m.agent_id] ?? Users;
          const accent = ACCENT[m.agent_id] ?? "text-midground border-border bg-card/40";
          return (
            <div
              key={m.agent_id}
              className={`flex items-start gap-3 rounded-md border p-4 ${accent}`}
            >
              <Icon className="mt-0.5 h-6 w-6" />
              <div className="flex flex-1 flex-col gap-1">
                <div className="flex items-baseline justify-between gap-2">
                  <Typography variant="md" compressed>
                    {m.name}
                  </Typography>
                  <span className="font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/60">
                    {m.agent_id}
                  </span>
                </div>
                <div className="font-mono-ui text-[0.7rem] text-midground/70">
                  {m.role} · {m.rank} · squad: {m.squad}
                </div>
                {m.description && (
                  <div className="font-mono-ui text-xs text-midground/80">
                    {m.description}
                  </div>
                )}
                {m.capabilities && m.capabilities.length > 0 && (
                  <div className="mt-1 flex flex-wrap gap-1">
                    {m.capabilities.map((c) => (
                      <span
                        key={c}
                        className="rounded bg-card/60 px-1.5 py-0.5 font-mono-ui text-[0.6rem] text-midground/80"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
