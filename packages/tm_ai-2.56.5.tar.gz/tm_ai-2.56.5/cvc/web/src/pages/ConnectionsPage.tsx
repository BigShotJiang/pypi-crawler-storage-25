import { useEffect, useState } from "react";
import { Plug } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type ConnectionInfo } from "@/lib/api";

interface ConnRow extends ConnectionInfo {
  type?: string;
  status?: string;
  last_seen?: string | number;
}

function statusColor(status?: string): string {
  const s = (status ?? "").toLowerCase();
  if (
    s === "ok" ||
    s === "connected" ||
    s === "online" ||
    s === "running" ||
    s === "active" ||
    s === "healthy"
  ) {
    return "bg-emerald-400";
  }
  if (
    s === "warning" ||
    s === "degraded" ||
    s === "pending" ||
    s === "connecting" ||
    s === "idle"
  ) {
    return "bg-amber-400";
  }
  if (s) return "bg-rose-400";
  return "bg-midground/30";
}

function formatLastSeen(v?: string | number): string {
  if (v == null || v === "") return "—";
  if (typeof v === "number") {
    try {
      const ms = v < 1e12 ? v * 1000 : v;
      return new Date(ms).toLocaleString();
    } catch {
      return String(v);
    }
  }
  const n = Number(v);
  if (!Number.isNaN(n) && n > 0) {
    const ms = n < 1e12 ? n * 1000 : n;
    try {
      return new Date(ms).toLocaleString();
    } catch {
      return String(v);
    }
  }
  return v;
}

export default function ConnectionsPage() {
  const [rows, setRows] = useState<ConnRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const r = await api.connections();
        if (cancelled) return;
        const arr = Array.isArray(r) ? r : (r.connections ?? []);
        setRows(arr as ConnRow[]);
        setError(null);
      } catch (e) {
        if (!cancelled) setError(String((e as Error)?.message ?? e));
      }
    };
    load();
    const id = setInterval(load, 5000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <Plug className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Connections
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}

      {rows && rows.length === 0 && !error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          No connections.
        </div>
      )}

      {rows && rows.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border bg-card/40">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-midground/5">
              <tr className="text-[0.65rem] uppercase tracking-wider text-midground/55">
                <th className="px-4 py-2 font-medium">Type</th>
                <th className="px-4 py-2 font-medium">Name</th>
                <th className="px-4 py-2 font-medium">Status</th>
                <th className="px-4 py-2 font-medium">Last seen</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c, i) => (
                <tr
                  key={`${c.name}-${i}`}
                  className="border-b border-border/40 last:border-b-0 hover:bg-midground/5"
                >
                  <td className="px-4 py-2.5 text-xs text-midground/70 font-mono-ui">
                    {c.type ?? "—"}
                  </td>
                  <td className="px-4 py-2.5 text-midground">{c.name}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2 w-2 rounded-full ${statusColor(c.status)}`}
                      />
                      <span className="text-xs text-midground/70">
                        {c.status ?? "unknown"}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-midground/60">
                    {formatLastSeen(c.last_seen)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
