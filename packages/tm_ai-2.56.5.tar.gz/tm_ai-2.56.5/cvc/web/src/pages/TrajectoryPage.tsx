import { useEffect, useState } from "react";
import { FileText, Layers } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import {
  api,
  type TrajectoryFile,
  type TrajectorySummary,
  type TrajectoryTurn,
} from "@/lib/api";

export default function TrajectoryPage() {
  const [files, setFiles] = useState<TrajectoryFile[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [turns, setTurns] = useState<TrajectoryTurn[]>([]);
  const [summary, setSummary] = useState<TrajectorySummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = async () => {
    try {
      const fs = await api.trajectoryFiles();
      setFiles(fs.files);
      const target = active ?? fs.files[0]?.path ?? null;
      if (target) {
        const [tail, sum] = await Promise.all([
          api.trajectoryTail(target, 80),
          api.trajectorySummary(target),
        ]);
        setTurns(tail.turns);
        setSummary(sum);
      } else {
        setTurns([]);
        setSummary(null);
      }
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 6000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <Layers className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Trajectory
        </Typography>
      </div>

      {error && (
        <div className="rounded-md border border-rose-400/40 bg-rose-500/10 px-3 py-2 font-mono-ui text-xs text-rose-300">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-[1fr_2fr]">
        <section className="rounded-md border border-border bg-card/40 p-3">
          <Typography variant="sm" compressed className="mb-2 text-midground">
            Files ({files.length})
          </Typography>
          <ul className="flex flex-col gap-1 font-mono-ui text-[0.7rem]">
            {files.length === 0 && (
              <li className="text-midground/50">No trajectory files yet.</li>
            )}
            {files.map((f) => {
              const selected = (active ?? files[0]?.path) === f.path;
              return (
                <li key={f.path}>
                  <button
                    type="button"
                    onClick={() => setActive(f.path)}
                    className={`flex w-full items-center justify-between gap-2 rounded px-2 py-1 text-left ${
                      selected
                        ? "bg-emerald-500/10 text-emerald-300"
                        : "text-midground/80 hover:bg-card/60"
                    }`}
                  >
                    <span className="flex items-center gap-1.5 truncate">
                      <FileText className="h-3 w-3" />
                      <span className="truncate">{f.name}</span>
                    </span>
                    <span className="text-midground/50">
                      {(f.size_bytes / 1024).toFixed(1)} KB
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="flex flex-col gap-3">
          {summary && (
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Turns" value={summary.turns} />
              <Stat label="Prompt tok" value={summary.tokens.prompt} />
              <Stat label="Completion tok" value={summary.tokens.completion} />
            </div>
          )}
          <div className="overflow-x-auto rounded-md border border-border">
            <table className="w-full font-mono-ui text-xs">
              <thead className="bg-card/40 text-midground/60">
                <tr>
                  <th className="px-3 py-2 text-left">#</th>
                  <th className="px-3 py-2 text-left">Provider:Model</th>
                  <th className="px-3 py-2 text-right">Prompt</th>
                  <th className="px-3 py-2 text-right">Completion</th>
                  <th className="px-3 py-2 text-right">Tools</th>
                </tr>
              </thead>
              <tbody>
                {turns.map((t) => (
                  <tr key={t.turn} className="border-t border-border/40">
                    <td className="px-3 py-1.5 text-midground/70">{t.turn}</td>
                    <td className="px-3 py-1.5 text-midground">
                      {t.provider ?? "?"}:{t.model ?? "?"}
                    </td>
                    <td className="px-3 py-1.5 text-right text-midground/80">
                      {t.prompt_tokens ?? 0}
                    </td>
                    <td className="px-3 py-1.5 text-right text-midground/80">
                      {t.completion_tokens ?? 0}
                    </td>
                    <td className="px-3 py-1.5 text-right text-midground/60">
                      {(t.tool_calls ?? []).length}
                    </td>
                  </tr>
                ))}
                {turns.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-3 py-6 text-center text-midground/50">
                      No turns recorded.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border border-border bg-card/40 px-3 py-2">
      <div className="font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/60">
        {label}
      </div>
      <div className="font-mono-ui text-xl text-midground">{value}</div>
    </div>
  );
}
