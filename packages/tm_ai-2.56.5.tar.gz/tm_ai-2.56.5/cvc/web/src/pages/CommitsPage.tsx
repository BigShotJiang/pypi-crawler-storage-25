import { useEffect, useState } from "react";
import { History } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type CommitSummary } from "@/lib/api";
import { useDashboardWS } from "@/lib/useDashboardWS";

function ago(ts?: number | string): string {
  if (!ts) return "—";
  const t = typeof ts === "string" ? Date.parse(ts) / 1000 : ts;
  if (!Number.isFinite(t)) return "—";
  const d = Date.now() / 1000 - t;
  if (d < 60) return `${Math.floor(d)}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  return `${Math.floor(d / 86400)}d ago`;
}

export default function CommitsPage() {
  const [commits, setCommits] = useState<CommitSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { lastEvent } = useDashboardWS();

  useEffect(() => {
    let cancelled = false;
    api
      .commits(100)
      .then((r) => !cancelled && setCommits(Array.isArray(r) ? r : []))
      .catch((e) => !cancelled && setError(String(e?.message ?? e)));
    return () => {
      cancelled = true;
    };
  }, [lastEvent]);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <History className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">
          Commits
        </Typography>
      </div>

      {error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          Could not reach gateway. <code>cvc gateway start</code>?
        </div>
      )}

      {commits && commits.length === 0 && !error && (
        <div className="rounded-lg border border-border bg-card/60 p-4 text-sm text-midground/70">
          No commits yet. Run <code>cvc commit "your message"</code>.
        </div>
      )}

      {commits && commits.length > 0 && (
        <div className="flex flex-col gap-2">
          {commits.map((c) => (
            <div
              key={c.hash}
              className="flex items-start gap-4 rounded-lg border border-border bg-card/40 px-4 py-3 hover:bg-card/70"
            >
              <code className="shrink-0 rounded bg-midground/10 px-2 py-0.5 font-mono text-[0.7rem] text-midground/80">
                {(c.short_hash ?? c.hash ?? "").slice(0, 12)}
              </code>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm text-midground">
                  {c.message || "(no message)"}
                </div>
                <div className="mt-0.5 flex items-center gap-3 text-[0.65rem] uppercase tracking-wider text-midground/50">
                  {c.commit_type && <span>{c.commit_type}</span>}
                  {c.branch && <span>· {c.branch}</span>}
                  <span>· {ago(c.timestamp)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
