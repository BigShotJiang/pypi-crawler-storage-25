import { useEffect, useState } from "react";
import { KeyRound, Plus, RefreshCw, Trash2 } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import SetupRegistryPanel from "@/components/SetupRegistryPanel";
import {
  api,
  type CredentialPoolStats,
  type PooledCredentialView,
  type ProviderProfile,
} from "@/lib/api";

export default function ProvidersPage() {
  const [providers, setProviders] = useState<ProviderProfile[] | null>(null);
  const [creds, setCreds] = useState<Record<string, PooledCredentialView[]>>({});
  const [stats, setStats] = useState<CredentialPoolStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    provider: "",
    label: "",
    access_token: "",
    auth_type: "bearer",
    base_url: "",
  });

  const load = async () => {
    try {
      const [p, c, s] = await Promise.all([
        api.providers(),
        api.credentials(),
        api.credentialStats(),
      ]);
      setProviders(p.providers ?? []);
      setCreds(c.credentials ?? {});
      setStats(s);
      setError(null);
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 8000);
    return () => clearInterval(id);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.addCredential({
        provider: form.provider.trim(),
        label: form.label.trim() || form.provider.trim(),
        access_token: form.access_token.trim(),
        auth_type: form.auth_type || undefined,
        base_url: form.base_url.trim() || undefined,
      });
      setShowAdd(false);
      setForm({ provider: "", label: "", access_token: "", auth_type: "bearer", base_url: "" });
      await load();
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  const remove = async (provider: string, id: string) => {
    if (!confirm(`Remove credential ${id}?`)) return;
    try {
      await api.removeCredential(provider, id);
      await load();
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  const reset = async (provider: string, id: string) => {
    try {
      await api.resetCredential(provider, id);
      await load();
    } catch (e) {
      setError(String((e as Error)?.message ?? e));
    }
  };

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <SetupRegistryPanel />
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <KeyRound className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Providers &amp; Credentials
          </Typography>
        </div>
        <button
          type="button"
          onClick={() => setShowAdd((s) => !s)}
          className="flex items-center gap-1.5 rounded-md border border-border bg-card/40 px-3 py-1.5 font-mono-ui text-xs uppercase tracking-wider text-midground hover:bg-card/60"
        >
          <Plus className="h-3.5 w-3.5" /> Add credential
        </button>
      </div>

      {error && (
        <div className="rounded-md border border-rose-400/40 bg-rose-500/10 px-3 py-2 font-mono-ui text-xs text-rose-300">
          {error}
        </div>
      )}

      {stats && (
        <div className="grid grid-cols-3 gap-3">
          <Stat label="Total" value={stats.total} />
          <Stat label="Available" value={stats.available} tone="ok" />
          <Stat label="Exhausted" value={stats.exhausted} tone="warn" />
        </div>
      )}

      {showAdd && (
        <form
          onSubmit={submit}
          className="grid gap-2 rounded-md border border-border bg-card/40 p-3 font-mono-ui text-xs"
        >
          <div className="grid grid-cols-2 gap-2">
            <input
              required
              placeholder="provider (e.g. copilot, nvidia, openai)"
              className="rounded border border-border bg-background/60 px-2 py-1.5"
              value={form.provider}
              onChange={(e) => setForm({ ...form, provider: e.target.value })}
            />
            <input
              placeholder="label"
              className="rounded border border-border bg-background/60 px-2 py-1.5"
              value={form.label}
              onChange={(e) => setForm({ ...form, label: e.target.value })}
            />
          </div>
          <input
            required
            type="password"
            placeholder="access token / api key"
            className="rounded border border-border bg-background/60 px-2 py-1.5"
            value={form.access_token}
            onChange={(e) => setForm({ ...form, access_token: e.target.value })}
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              placeholder="auth_type (bearer)"
              className="rounded border border-border bg-background/60 px-2 py-1.5"
              value={form.auth_type}
              onChange={(e) => setForm({ ...form, auth_type: e.target.value })}
            />
            <input
              placeholder="base_url (optional)"
              className="rounded border border-border bg-background/60 px-2 py-1.5"
              value={form.base_url}
              onChange={(e) => setForm({ ...form, base_url: e.target.value })}
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAdd(false)}
              className="rounded border border-border px-3 py-1.5 uppercase tracking-wider"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded border border-emerald-400/40 bg-emerald-500/10 px-3 py-1.5 uppercase tracking-wider text-emerald-300"
            >
              Save
            </button>
          </div>
        </form>
      )}

      <section className="flex flex-col gap-2">
        <Typography variant="sm" compressed className="text-midground/70">
          Providers ({providers?.length ?? 0})
        </Typography>
        <div className="overflow-x-auto rounded-md border border-border">
          <table className="w-full font-mono-ui text-xs">
            <thead className="bg-card/40 text-midground/60">
              <tr>
                <th className="px-3 py-2 text-left">Name</th>
                <th className="px-3 py-2 text-left">Auth</th>
                <th className="px-3 py-2 text-left">Mode</th>
                <th className="px-3 py-2 text-left">Base URL</th>
                <th className="px-3 py-2 text-left">Caps</th>
              </tr>
            </thead>
            <tbody>
              {(providers ?? []).map((p) => (
                <tr key={p.name} className="border-t border-border/40">
                  <td className="px-3 py-2 text-midground">{p.name}</td>
                  <td className="px-3 py-2 text-midground/70">{p.auth_type ?? "—"}</td>
                  <td className="px-3 py-2 text-midground/70">{p.api_mode ?? "—"}</td>
                  <td className="px-3 py-2 text-midground/60">{p.base_url ?? "—"}</td>
                  <td className="px-3 py-2 text-midground/60">
                    {[
                      p.supports_streaming && "stream",
                      p.supports_tools && "tools",
                      p.supports_reasoning && "reasoning",
                      p.supports_prompt_cache && "cache",
                    ]
                      .filter(Boolean)
                      .join(" · ") || "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="flex flex-col gap-2">
        <Typography variant="sm" compressed className="text-midground/70">
          Credentials
        </Typography>
        <div className="overflow-x-auto rounded-md border border-border">
          <table className="w-full font-mono-ui text-xs">
            <thead className="bg-card/40 text-midground/60">
              <tr>
                <th className="px-3 py-2 text-left">Provider</th>
                <th className="px-3 py-2 text-left">Label</th>
                <th className="px-3 py-2 text-left">Token</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-left">Use</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(creds).flatMap(([prov, list]) =>
                list.map((c) => (
                  <tr key={`${prov}:${c.id}`} className="border-t border-border/40">
                    <td className="px-3 py-2 text-midground">{prov}</td>
                    <td className="px-3 py-2 text-midground/80">{c.label}</td>
                    <td className="px-3 py-2 text-midground/60">{c.masked_token}</td>
                    <td className="px-3 py-2">
                      {c.exhausted ? (
                        <span className="rounded bg-rose-500/10 px-2 py-0.5 text-rose-300">
                          exhausted
                        </span>
                      ) : (
                        <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-emerald-300">
                          available
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-midground/60">{c.use_count ?? 0}</td>
                    <td className="px-3 py-2">
                      <div className="flex justify-end gap-1.5">
                        <button
                          type="button"
                          title="Reset"
                          onClick={() => reset(prov, c.id)}
                          className="rounded border border-border p-1 hover:bg-card/60"
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          title="Remove"
                          onClick={() => remove(prov, c.id)}
                          className="rounded border border-rose-400/40 p-1 text-rose-300 hover:bg-rose-500/10"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )),
              )}
              {Object.keys(creds).length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-midground/50">
                    No credentials registered.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: "ok" | "warn";
}) {
  const color =
    tone === "ok" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : "text-midground";
  return (
    <div className="rounded-md border border-border bg-card/40 px-3 py-2">
      <div className="font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/60">
        {label}
      </div>
      <div className={`font-mono-ui text-xl ${color}`}>{value}</div>
    </div>
  );
}
