import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

const BACKEND = process.env.CVC_GATEWAY_URL ?? "http://127.0.0.1:9119";

// Vendored Nous Research UI: alias `@nous-research/ui/...` imports to
// `cvc/web/src/vendor/nous-ui/...`. No npm dep at install time.
const NOUS_UI_DIR = path.resolve(__dirname, "./src/vendor/nous-ui");

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: [
      { find: "@/", replacement: path.resolve(__dirname, "./src") + "/" },
      // Match `@nous-research/ui/...` deep imports (utils, hooks, components)
      {
        find: /^@nous-research\/ui$/,
        replacement: path.resolve(NOUS_UI_DIR, "index.js"),
      },
      {
        find: /^@nous-research\/ui\/(.+)$/,
        replacement: path.resolve(NOUS_UI_DIR, "$1") + ".js",
      },
    ],
    dedupe: ["react", "react-dom", "three"],
  },
  build: {
    outDir: path.resolve(__dirname, "../web_dist"),
    emptyOutDir: true,
  },
  server: {
    port: 9120,
    proxy: {
      "/api": { target: BACKEND, ws: true, changeOrigin: true },
    },
  },
});
