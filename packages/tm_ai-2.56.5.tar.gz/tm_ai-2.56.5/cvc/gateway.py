"""
cvc.gateway — The CVC Gateway (Unified Server).

A FastAPI application that runs on ``http://127.0.0.1:13421`` and provides:

1. A web-based dashboard UI (Open WebUI-style) for managing all CVC features.
2. A management REST API for service lifecycle control.
3. An agent chat endpoint (streaming) — full CVC Agent in the browser.
4. Operations API: commit, branch, merge, restore, recall, diff, timeline.
5. Memory & context browsing.
6. Model catalog and provider switching.
7. Hive Mind / SDK multi-agent management.
8. Real-time event streaming via WebSocket.
9. **Workspace-routed LLM proxy** — intercepts LLM API calls for all registered
   workspaces, replacing the standalone ``cvc serve`` proxy entirely.

The gateway is the single process users need. Running ``cvc gateway start``
provides both the dashboard AND the cognitive proxy.  Each workspace is
dynamically registered via ``POST /gateway/register_workspace`` and gets
its own isolated CVCEngine, reachable at ``/ws/{workspace_id}/v1/...``.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse, HTMLResponse, StreamingResponse
from starlette.websockets import WebSocket, WebSocketDisconnect

logger = logging.getLogger("cvc.gateway")

# ---------------------------------------------------------------------------
# Module-level singletons (initialised in lifespan)
# ---------------------------------------------------------------------------

_manager = None        # GatewayManager
_workspace_mgr = None  # WorkspaceManager — multi-workspace isolation
_event_bus = None      # EventBus
_health_task = None    # Background health poller
_project_root = None   # Discovered project root
_agent_llm = None      # AgentLLM (direct LLM client for chat)
_agent_tools = []      # Tool definitions for the dashboard agent
_tool_executor = None  # ToolExecutor for executing agent tool calls
_system_prompt = ""    # Agent system prompt
_chat_messages = []    # Persistent conversation history (system + user + assistant + tool)

# ── Tool permission system ───────────────────────────────────────────
_autopilot: bool = False  # When True, all tools execute without confirmation
_tool_confirm_event: asyncio.Event | None = None  # Set when user confirms/denies
_tool_confirm_result: str = ""  # Decision string from user

# ── Abort / Stop system ──────────────────────────────────────────────
_chat_abort: bool = False  # When True, the agentic loop stops ASAP

# Session-level tool trust ("Always allow X this session")
_session_trusted_tools: set[str] = set()
# Session-level "Trust ALL commands" flag
_session_trust_all: bool = False

# Tools that are always safe to auto-approve (read-only, no side effects)
_SAFE_TOOLS: set[str] = {
    "read_file", "grep", "glob", "list_dir",
    "cvc_status", "cvc_log", "cvc_search", "cvc_smart_search", "cvc_diff",
    "cvc_get_context", "cvc_switch_workspace",
}

# Valid permission decisions (matches CLI-style options)
# allow_once  — execute this one time only
# allow_always — always allow this tool for the rest of the session
# trust_all  — trust ALL tools this session (like _session_trust_all)
# deny       — deny and inject error message
# deny_suggest — deny and ask agent to suggest an alternative
_VALID_DECISIONS = {"allow_once", "allow_always", "trust_all", "deny", "deny_suggest"}

# Agentic loop limits
_MAX_AGENT_ITERATIONS = 50
_MAX_AGENT_ITERATIONS_EXPENSIVE = 10  # Opus models: 3x premium request multiplier
_MAX_TOOL_OUTPUT_LLM = 15000   # chars fed back to LLM
_MAX_TOOL_OUTPUT_EXPENSIVE = 5000  # chars for expensive models (Opus)
_AGENT_TIMEOUT = 300.0         # seconds total per chat turn (5 min)

_EXPENSIVE_MODEL_KEYWORDS = ("opus",)


def _is_expensive_model(model_name: str) -> bool:
    """Check if a model is in the expensive/premium tier."""
    name_lower = model_name.lower()
    return any(kw in name_lower for kw in _EXPENSIVE_MODEL_KEYWORDS)

_GATEWAY_PORT: int = int(os.environ.get("CVC_GATEWAY_PORT", "13421"))
_PROXY_PORT: int = int(os.environ.get("CVC_PROXY_PORT", str(_GATEWAY_PORT)))  # deprecated, defaults to gateway port
_HOST: str = os.environ.get("CVC_GATEWAY_HOST", "127.0.0.1")


class _StaticAsset304Filter(logging.Filter):
    """Hide noisy uvicorn access logs for cached static assets (304 responses)."""

    def filter(self, record: logging.LogRecord) -> bool:
        args = getattr(record, "args", ())
        if not isinstance(args, tuple) or len(args) < 5:
            return True

        method = str(args[1])
        path = str(args[2])
        status = str(args[4])
        if method == "GET" and path.startswith("/static/") and status == "304":
            return False
        return True


class _WebSocketNoiseFilter(logging.Filter):
    """Suppress low-value websocket lifecycle chatter from uvicorn logs."""

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage().strip().lower()
        return message not in {"connection open", "connection closed"}


def _configure_gateway_logging() -> None:
    """Filter routine cache/websocket noise while keeping real logs visible."""
    access_logger = logging.getLogger("uvicorn.access")
    if not any(isinstance(f, _StaticAsset304Filter) for f in access_logger.filters):
        access_logger.addFilter(_StaticAsset304Filter())

    error_logger = logging.getLogger("uvicorn.error")
    if not any(isinstance(f, _WebSocketNoiseFilter) for f in error_logger.filters):
        error_logger.addFilter(_WebSocketNoiseFilter())


def _set_tool_confirm(evt: asyncio.Event | None, result: str) -> None:
    """Set the module-level tool confirmation state."""
    global _tool_confirm_event, _tool_confirm_result
    _tool_confirm_event = evt
    _tool_confirm_result = result


def _get_tool_confirm_result() -> str:
    """Read the current tool confirmation result."""
    return _tool_confirm_result


def _get_event_bus():
    global _event_bus
    if _event_bus is None:
        from cvc.sdk.events import EventBus
        _event_bus = EventBus()
    return _event_bus


async def _health_poll_loop():
    while True:
        try:
            if _manager:
                _manager.refresh_health()
        except Exception:
            logger.debug("Health poll error", exc_info=True)
        await asyncio.sleep(10)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _manager, _workspace_mgr, _health_task, _project_root
    global _agent_llm, _system_prompt, _agent_tools, _tool_executor

    from cvc.core.models import discover_cvc_root
    from cvc.gateway_manager import GatewayManager
    from cvc.workspace_manager import WorkspaceManager

    _configure_gateway_logging()

    _project_root = discover_cvc_root()
    if _project_root is None:
        _project_root = Path.cwd()

    # Prefer last-active workspace from previous gateway session.
    # This makes "save your workspace selection" survive restart.
    _last_active = WorkspaceManager.load_active_workspace()
    if _last_active is not None and _last_active.exists():
        logger.info("Restoring last-active workspace: %s", _last_active)
        _project_root = _last_active

    # Initialize WorkspaceManager and activate the discovered workspace
    _workspace_mgr = WorkspaceManager()
    _workspace_mgr.switch_to(_project_root)

    cvc_root = _project_root / ".cvc"
    _manager = GatewayManager(cvc_root, host=_HOST)

    # Load settings to check for Telegram Bot Integration
    try:
        from cvc.agent.settings import load_settings
        settings = load_settings(_project_root)
        print(f"DEBUG: Telegram settings: enabled={settings.telegram.enabled}, token_present={bool(settings.telegram.bot_token)}")
        if settings.telegram.enabled and settings.telegram.bot_token:
            from cvc.adapters.telegram_gateway import start_telegram_gateway
            print("DEBUG: Calling start_telegram_gateway")
            asyncio.create_task(start_telegram_gateway(settings, _workspace_mgr))
            logger.info("Telegram gateway task created")
        else:
            print("DEBUG: Telegram not enabled or no token")
    except Exception as e:
        print(f"DEBUG: Failed to init Telegram gateway: {e}")
        logger.warning("Failed to initialize Telegram gateway", exc_info=True)

    # Launch proxy without blocking on health check — the background
    # health poll will update its status once it's ready.
    # NOTE: Proxy is now integrated into the gateway itself via
    # workspace-routed endpoints (/ws/{workspace_id}/v1/...).
    # We no longer spawn a separate proxy process.
    # Mark proxy as "running" (it's us now)
    if _manager:
        proxy_rec = _manager.get_service("proxy")
        if proxy_rec:
            proxy_rec.status = "running"
            proxy_rec.port = _GATEWAY_PORT  # proxy runs on gateway port now
            proxy_rec.started_at = time.time()

    # Defer Agent LLM init to a background task so the HTTP server
    # starts accepting requests immediately.
    asyncio.create_task(_init_agent_llm_background())

    _health_task = asyncio.create_task(_health_poll_loop())
    logger.info("CVC Gateway started — http://%s:%d", _HOST, _GATEWAY_PORT)

    yield

    if _health_task:
        _health_task.cancel()
    if _agent_llm:
        try:
            await _agent_llm.close()
        except Exception:
            pass
    if _workspace_mgr:
        _workspace_mgr.close_all()

    try:
        from cvc.adapters.telegram_gateway import stop_telegram_gateway
        await stop_telegram_gateway()
    except Exception:
        pass

    logger.info("CVC Gateway shut down.")


async def _init_agent_llm_background() -> None:
    """Initialise Agent LLM + ToolExecutor in a background task.

    Runs after the event loop is already serving HTTP, so the dashboard
    loads instantly.  Chat endpoints gracefully handle _agent_llm=None
    until this completes.
    """
    global _agent_llm, _system_prompt, _agent_tools, _tool_executor

    # Yield control so uvicorn can bind the port first
    await asyncio.sleep(0)

    try:
        from cvc.agent.executor import ToolExecutor
        from cvc.agent.llm import AgentLLM
        from cvc.agent.system_prompt import build_system_prompt
        from cvc.agent.tools import AGENT_TOOLS
        from cvc.core.models import GlobalConfig

        gc = GlobalConfig.load()
        provider = os.getenv("CVC_PROVIDER", gc.provider)
        model = os.getenv("CVC_MODEL", gc.model)

        # Resolve API key (same logic as CLI agent)
        env_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "google": "GOOGLE_API_KEY",
            "ollama": "",
            "lmstudio": "",
            "copilot": "COPILOT_GITHUB_TOKEN",
            "github": "GITHUB_TOKEN",
            "vertex": "",  # Uses gcloud ADC, not an API key
        }
        env_key = env_map.get(provider, "")
        api_key = os.getenv(env_key, "") if env_key else ""
        if not api_key:
            api_key = gc.api_keys.get(provider, "")

        base_url_map = {
            "anthropic": "https://api.anthropic.com",
            "openai": "https://api.openai.com",
            "google": "https://generativelanguage.googleapis.com",
            "ollama": os.getenv("OLLAMA_HOST", "http://localhost:11434"),
            "lmstudio": os.getenv("LMSTUDIO_HOST", "http://localhost:1234"),
            "copilot": "https://api.githubcopilot.com",
        }
        base_url = base_url_map.get(provider, "")
        if provider == "vertex":
            from cvc.adapters.vertex import build_vertex_base_url, get_vertex_credentials
            try:
                _creds, adc_project = get_vertex_credentials()
            except RuntimeError:
                adc_project = ""
            v_project = gc.vertex_project_id or os.getenv("VERTEX_PROJECT_ID", "") or adc_project
            v_location = gc.vertex_location or os.getenv("VERTEX_LOCATION", "us-central1")
            base_url = build_vertex_base_url(v_project, v_location)

        _agent_llm = AgentLLM(
            provider=provider,
            api_key=api_key,
            model=model,
            base_url=base_url,
        )

        _system_prompt = build_system_prompt(
            workspace=str(_project_root),
            provider=provider,
            model=model,
            branch=_workspace_mgr.engine.active_branch if _workspace_mgr.engine else "main",
        )

        # Dashboard-safe tool subset (same definitions as CLI agent)
        _DASHBOARD_TOOL_NAMES = {
            "read_file", "write_file", "edit_file", "patch_file",
            "bash", "glob", "grep", "list_dir", "web_search",
            "cvc_status", "cvc_log", "cvc_commit", "cvc_branch",
            "cvc_restore", "cvc_merge", "cvc_search", "cvc_smart_search", "cvc_diff",
            "cvc_switch_workspace",
        }
        _agent_tools = [t for t in AGENT_TOOLS if t.get("function", {}).get("name") in _DASHBOARD_TOOL_NAMES]

        # Create ToolExecutor scoped to the current workspace
        _tool_executor = ToolExecutor(_project_root, _workspace_mgr.engine)

        # Pre-warm the TCP + TLS connection
        asyncio.create_task(_agent_llm.warm_connection())
        logger.info("Agent LLM initialised — %s/%s (%d tools)", provider, model, len(_agent_tools))
    except Exception:
        logger.warning("Agent LLM init failed — chat will fall back to proxy", exc_info=True)


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------

try:
    from cvc import __version__ as _cvc_version
except ImportError:
    _cvc_version = "2.0.0"

app = FastAPI(
    title="CVC Gateway",
    version=_cvc_version,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _ensure(what="gateway"):
    if not _manager or not _workspace_mgr or not _workspace_mgr.db or not _workspace_mgr.config:
        raise HTTPException(status_code=503, detail=f"{what} not initialised yet")


# Thin accessors — route handlers use these instead of module-level singletons.
# All delegate to _workspace_mgr so the active workspace can change at runtime.

def _get_db():
    return _workspace_mgr.db if _workspace_mgr else None


def _get_config():
    return _workspace_mgr.config if _workspace_mgr else None


def _get_engine():
    return _workspace_mgr.engine if _workspace_mgr else None


# ═══════════════════════════════════════════════════════════════════════
# 1. HEALTH
# ═══════════════════════════════════════════════════════════════════════


@app.post("/api/telemetry")
async def post_telemetry(payload: dict):
    """Receive Swarm telemetry from SDK and broadcast to Dashboard UI."""
    try:

        if _get_event_bus():
            _get_event_bus().emit(
                "telemetry", payload)
    except Exception:
        pass
    return {"status": "ok"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "cvc-gateway", "version": _cvc_version}


# ═══════════════════════════════════════════════════════════════════════
# 1b. WORKSPACE MANAGEMENT — Multi-workspace isolation
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/setup/registry")
async def setup_registry():
    """Unified setup registry: providers + features.

    Single source of truth shared by `cvc setup` (CLI) and the dashboard
    settings/onboarding pages. Adding a new provider in cvc/setup/registry.py
    or a new feature in cvc/setup/features.py automatically appears here.
    """
    from cvc.setup import registry_snapshot
    return registry_snapshot()


@app.get("/api/workspace/current")
async def workspace_current():
    """Return the currently active workspace path and stats."""
    if not _workspace_mgr or not _workspace_mgr.current:
        raise HTTPException(503, "No workspace active")
    inst = _workspace_mgr.current
    info = {
        "path": str(inst.path),
        "name": inst.path.name or str(inst.path),
        "workspace_id": _make_workspace_id(inst.path),
        "last_accessed": inst.last_accessed,
        "initialized": inst.initialized,
    }
    if inst.engine:
        info["branch"] = inst.engine.active_branch
        try:
            commits = inst.db.index.list_all_commits(limit=9999)
            info["commit_count"] = len(commits)
        except Exception:
            info["commit_count"] = 0
    return info


@app.get("/api/workspace/list")
async def workspace_list():
    """List all known workspaces (open + from persistent registry)."""
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    return {"workspaces": _workspace_mgr.list_workspaces()}


@app.post("/api/workspace/switch")
async def workspace_switch(request: Request):
    """Switch the active workspace. Auto-initializes .cvc/ if needed."""
    global _tool_executor, _system_prompt, _project_root
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    body = await request.json()
    target_path = body.get("path", "")
    if not target_path:
        raise HTTPException(400, "Missing 'path' in request body")

    target = Path(target_path).resolve()
    if not target.exists():
        raise HTTPException(404, f"Directory does not exist: {target}")
    if not target.is_dir():
        raise HTTPException(400, f"Not a directory: {target}")

    inst = _workspace_mgr.switch_to(target)

    # Re-scope tool executor and system prompt to new workspace
    _project_root = inst.path
    try:
        from cvc.agent.executor import ToolExecutor
        _tool_executor = ToolExecutor(inst.path, inst.engine)
    except Exception:
        logger.warning("Failed to re-scope ToolExecutor", exc_info=True)

    try:
        from cvc.agent.system_prompt import build_system_prompt
        provider = _agent_llm.provider if _agent_llm else inst.config.provider
        model = _agent_llm.model if _agent_llm else inst.config.model
        _system_prompt = build_system_prompt(
            workspace=str(inst.path),
            provider=provider,
            model=model,
            branch=inst.engine.active_branch,
        )
    except Exception:
        logger.warning("Failed to rebuild system prompt", exc_info=True)

    return {
        "status": "ok",
        "path": str(inst.path),
        "branch": inst.engine.active_branch if inst.engine else "main",
    }


@app.post("/api/workspace/init")
async def workspace_init(request: Request):
    """Explicitly initialize .cvc/ in a directory (without switching)."""
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    body = await request.json()
    target_path = body.get("path", "")
    if not target_path:
        raise HTTPException(400, "Missing 'path' in request body")

    target = Path(target_path).resolve()
    inst = _workspace_mgr.init_workspace(target)
    return {
        "status": "ok",
        "path": str(inst.path),
        "branch": inst.engine.active_branch if inst.engine else "main",
    }


@app.post("/api/workspace/add")
async def workspace_add(request: Request):
    """Add a workspace by absolute filesystem path.

    Single-shot: validates the path, initialises ``.cvc/`` if missing,
    registers it with the gateway proxy, and optionally switches to it.

    Body: ``{"path": "/abs/path", "switch": true}``
    """
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    body = await request.json()
    raw_path = (body.get("path") or "").strip()
    do_switch = bool(body.get("switch", True))
    if not raw_path:
        raise HTTPException(400, "Missing 'path'")

    # Expand ~ for convenience
    target = Path(os.path.expanduser(raw_path)).resolve()
    if not target.exists():
        raise HTTPException(404, f"Directory does not exist: {target}")
    if not target.is_dir():
        raise HTTPException(400, f"Not a directory: {target}")

    # Initialise + open
    inst = _workspace_mgr.init_workspace(target)

    # Register with the gateway proxy registry
    workspace_id = _make_workspace_id(target)
    _registered_workspaces[workspace_id] = target

    if do_switch:
        global _tool_executor, _project_root
        inst = _workspace_mgr.switch_to(target)
        _project_root = inst.path
        try:
            from cvc.agent.executor import ToolExecutor
            _tool_executor = ToolExecutor(inst.path, inst.engine)
        except Exception:
            logger.warning("Failed to re-scope ToolExecutor", exc_info=True)

    return {
        "status": "ok",
        "workspace_id": workspace_id,
        "path": str(target),
        "name": target.name,
        "branch": inst.engine.active_branch if inst.engine else "main",
        "switched": do_switch,
    }


# ─── Voice transcription (speech-to-text) ─────────────────────────────────
#
# Accepts an audio file (webm/ogg/wav/mp3/m4a) and returns plain text.
# Tries providers in this order until one succeeds:
#   1. Groq (whisper-large-v3)      — GROQ_API_KEY
#   2. OpenAI (whisper-1 / gpt-4o-transcribe) — OPENAI_API_KEY
#   3. Google Gemini (1.5-flash inline audio) — GOOGLE_API_KEY
# 415 if none configured.

async def _stt_groq(audio: bytes, filename: str, content_type: str) -> str | None:
    key = os.environ.get("GROQ_API_KEY")
    if not key:
        return None
    import httpx
    async with httpx.AsyncClient(timeout=60.0) as client:
        files = {"file": (filename, audio, content_type)}
        data = {"model": "whisper-large-v3", "response_format": "json"}
        r = await client.post(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {key}"},
            files=files,
            data=data,
        )
        if r.status_code >= 400:
            logger.warning("Groq STT failed %s: %s", r.status_code, r.text[:200])
            return None
        return (r.json().get("text") or "").strip()


async def _stt_openai(audio: bytes, filename: str, content_type: str) -> str | None:
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return None
    import httpx
    async with httpx.AsyncClient(timeout=60.0) as client:
        files = {"file": (filename, audio, content_type)}
        data = {"model": "whisper-1", "response_format": "json"}
        r = await client.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {key}"},
            files=files,
            data=data,
        )
        if r.status_code >= 400:
            logger.warning("OpenAI STT failed %s: %s", r.status_code, r.text[:200])
            return None
        return (r.json().get("text") or "").strip()


async def _stt_gemini(audio: bytes, content_type: str) -> str | None:
    key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if not key:
        return None
    import base64
    import httpx
    b64 = base64.b64encode(audio).decode("ascii")
    body = {
        "contents": [{
            "parts": [
                {"text": "Transcribe the speech in this audio verbatim. Return only the transcript text — no preface, no quotes."},
                {"inline_data": {"mime_type": content_type or "audio/webm", "data": b64}},
            ]
        }]
    }
    async with httpx.AsyncClient(timeout=90.0) as client:
        r = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={key}",
            json=body,
        )
        if r.status_code >= 400:
            logger.warning("Gemini STT failed %s: %s", r.status_code, r.text[:200])
            return None
        try:
            text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
            return (text or "").strip()
        except Exception:
            return None


@app.post("/api/voice/transcribe")
async def voice_transcribe(audio: UploadFile = File(...)):
    """Transcribe an uploaded audio blob to text via Groq → OpenAI → Gemini."""
    data = await audio.read()
    if not data:
        raise HTTPException(400, "Empty audio payload")
    if len(data) > 25 * 1024 * 1024:
        raise HTTPException(413, "Audio file too large (max 25 MB)")

    filename = audio.filename or "recording.webm"
    content_type = audio.content_type or "audio/webm"

    for fn in (_stt_groq, _stt_openai):
        try:
            text = await fn(data, filename, content_type)
        except Exception:
            logger.exception("STT provider failed")
            text = None
        if text:
            return {"text": text, "provider": fn.__name__.replace("_stt_", "")}

    try:
        text = await _stt_gemini(data, content_type)
    except Exception:
        logger.exception("Gemini STT failed")
        text = None
    if text:
        return {"text": text, "provider": "gemini"}

    raise HTTPException(
        415,
        "No speech-to-text provider configured. Set GROQ_API_KEY, OPENAI_API_KEY, or GOOGLE_API_KEY.",
    )


# ── File upload (multimodal attachments) ─────────────────────────────────────
import base64 as _b64
import uuid as _uuid
import mimetypes as _mimetypes
from typing import List as _List

_IMAGE_MIMES = {"image/png", "image/jpeg", "image/jpg", "image/webp", "image/gif"}
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB cap
_INLINE_IMAGE_CAP = 6 * 1024 * 1024  # 6 MB → inline as data URL for vision models


def _classify_upload(mime: str, name: str) -> str:
    m = (mime or "").lower()
    n = (name or "").lower()
    if m.startswith("image/"):
        return "image"
    if m.startswith("video/"):
        return "video"
    if m.startswith("audio/"):
        return "audio"
    if m == "application/pdf" or n.endswith(".pdf"):
        return "pdf"
    if any(n.endswith(ext) for ext in (".ppt", ".pptx", ".key")):
        return "slides"
    if any(n.endswith(ext) for ext in (".doc", ".docx", ".odt", ".rtf")):
        return "doc"
    if any(n.endswith(ext) for ext in (".xls", ".xlsx", ".csv", ".tsv", ".ods")):
        return "sheet"
    if any(
        n.endswith(ext)
        for ext in (".txt", ".md", ".json", ".yaml", ".yml", ".xml", ".html", ".log")
    ):
        return "text"
    if m.startswith("text/"):
        return "text"
    return "other"


@app.post("/api/files/upload")
async def files_upload(files: _List[UploadFile] = File(...)):
    """Upload one or more files into the active workspace's .cvc/uploads/ directory.

    Returns metadata so the composer can attach the files to the next chat send.
    For images under 6 MB, also returns a base64 data URL so vision-capable
    models can consume them inline without a follow-up fetch.
    """
    if not files:
        raise HTTPException(400, "No files provided")

    base = Path(_project_root) if _project_root else Path.cwd()
    uploads_dir = base / ".cvc" / "uploads"
    uploads_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for f in files:
        data = await f.read()
        if not data:
            continue
        if len(data) > _MAX_UPLOAD_BYTES:
            raise HTTPException(
                413,
                f"File '{f.filename}' exceeds {_MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit",
            )

        orig_name = f.filename or "upload.bin"
        # Sanitise filename — keep extension, prefix with short uuid for uniqueness
        suffix = Path(orig_name).suffix.lower()
        if not suffix:
            guessed = _mimetypes.guess_extension(f.content_type or "") or ""
            suffix = guessed
        safe_stem = "".join(
            c for c in Path(orig_name).stem if c.isalnum() or c in ("-", "_", ".")
        )[:60] or "upload"
        unique = f"{_uuid.uuid4().hex[:8]}-{safe_stem}{suffix}"
        out_path = uploads_dir / unique
        out_path.write_bytes(data)

        mime = f.content_type or _mimetypes.guess_type(orig_name)[0] or "application/octet-stream"
        kind = _classify_upload(mime, orig_name)

        entry = {
            "name": orig_name,
            "stored_name": unique,
            "path": str(out_path),
            "rel_path": str(out_path.relative_to(base)),
            "size": len(data),
            "mime": mime,
            "kind": kind,
        }
        if kind == "image" and len(data) <= _INLINE_IMAGE_CAP:
            entry["data_url"] = f"data:{mime};base64,{_b64.b64encode(data).decode('ascii')}"
        results.append(entry)

    if not results:
        raise HTTPException(400, "All uploads were empty")
    return {"files": results}


@app.delete("/api/workspace/close")
async def workspace_close(request: Request):
    """Close a workspace's DB connections (does not delete .cvc/)."""
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    body = await request.json()
    target_path = body.get("path", "")
    if not target_path:
        raise HTTPException(400, "Missing 'path' in request body")

    closed = _workspace_mgr.close_workspace(target_path)
    if not closed:
        raise HTTPException(404, f"Workspace not open: {target_path}")
    return {"status": "ok", "path": target_path, "closed": True}


# ═══════════════════════════════════════════════════════════════════════
# 1b. GIT BRANCH OPERATIONS (active-workspace-scoped)
#
# Lightweight wrapper around `git` for the currently-active workspace so the
# composer can show a Git Branch picker alongside the Workspace picker.
# All commands run with cwd=active workspace path. Safe: read-only ops never
# mutate state; checkout refuses on dirty tree unless `force=true`; branch
# creation always forks from current HEAD.
# ═══════════════════════════════════════════════════════════════════════

def _active_workspace_path() -> Path:
    if not _workspace_mgr or not _workspace_mgr.current:
        raise HTTPException(503, "No workspace active")
    return _workspace_mgr.current.path


def _run_git(args: list[str], cwd: Path, timeout: float = 8.0) -> tuple[int, str, str]:
    """Run a git subcommand under ``cwd`` and return (rc, stdout, stderr)."""
    import subprocess  # local import keeps cold-start cheap
    try:
        proc = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except FileNotFoundError:
        raise HTTPException(500, "git executable not found on PATH")
    except subprocess.TimeoutExpired:
        raise HTTPException(504, f"git {' '.join(args)} timed out")


def _is_git_repo(cwd: Path) -> bool:
    rc, out, _ = _run_git(["rev-parse", "--is-inside-work-tree"], cwd)
    return rc == 0 and out == "true"


_BRANCH_NAME_RE = __import__("re").compile(r"^[A-Za-z0-9._/\-]{1,200}$")


def _validate_branch_name(name: str) -> str:
    name = (name or "").strip()
    if not name:
        raise HTTPException(400, "Branch name is required")
    if name.startswith("-") or ".." in name or name.endswith("/") or name.endswith(".lock"):
        raise HTTPException(400, f"Invalid branch name: {name!r}")
    if not _BRANCH_NAME_RE.match(name):
        raise HTTPException(400, f"Invalid branch name: {name!r}")
    return name


@app.get("/api/git/status")
async def git_status():
    """Return the active workspace's git status: branch, head, dirty flag."""
    ws = _active_workspace_path()
    if not _is_git_repo(ws):
        return {"is_repo": False, "path": str(ws)}
    rc_b, branch, _ = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], ws)
    rc_h, head, _ = _run_git(["rev-parse", "--short", "HEAD"], ws)
    rc_s, status_out, _ = _run_git(["status", "--porcelain"], ws)
    detached = branch == "HEAD"
    return {
        "is_repo": True,
        "path": str(ws),
        "branch": branch if rc_b == 0 else "",
        "head": head if rc_h == 0 else "",
        "detached": detached,
        "dirty": bool(status_out) if rc_s == 0 else False,
        "dirty_count": len(status_out.splitlines()) if rc_s == 0 and status_out else 0,
    }


@app.get("/api/git/branches")
async def git_branches():
    """List local branches with last-commit metadata for the active workspace."""
    ws = _active_workspace_path()
    if not _is_git_repo(ws):
        raise HTTPException(409, "Active workspace is not a git repository")

    _, current, _ = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], ws)

    fmt = "%(refname:short)%09%(objectname:short)%09%(committerdate:iso-strict)%09%(subject)"
    rc, out, err = _run_git(
        ["for-each-ref", f"--format={fmt}", "--sort=-committerdate", "refs/heads"],
        ws,
        timeout=12.0,
    )
    if rc != 0:
        raise HTTPException(500, f"git for-each-ref failed: {err}")

    branches: list[dict[str, Any]] = []
    for line in out.splitlines():
        parts = line.split("\t", 3)
        if len(parts) < 2:
            continue
        name = parts[0]
        head = parts[1] if len(parts) > 1 else ""
        when = parts[2] if len(parts) > 2 else ""
        subject = parts[3] if len(parts) > 3 else ""
        branches.append({
            "name": name,
            "head": head,
            "last_commit_at": when,
            "last_commit_subject": subject,
            "is_current": name == current,
        })
    return {
        "branches": branches,
        "current": current if current != "HEAD" else "",
        "detached": current == "HEAD",
        "count": len(branches),
    }


@app.post("/api/git/checkout")
async def git_checkout(request: Request):
    """Switch to (or create) a branch in the active workspace."""
    ws = _active_workspace_path()
    if not _is_git_repo(ws):
        raise HTTPException(409, "Active workspace is not a git repository")

    body = await request.json()
    name = _validate_branch_name(body.get("name", ""))
    create = bool(body.get("create", False))
    force = bool(body.get("force", False))

    rc_s, status_out, _ = _run_git(["status", "--porcelain"], ws)
    dirty = rc_s == 0 and bool(status_out)
    if dirty and not force:
        raise HTTPException(
            409,
            "Working tree has uncommitted changes. Commit/stash first, or pass force=true.",
        )

    if not create:
        rc_v, _, _ = _run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{name}"], ws)
        if rc_v != 0:
            raise HTTPException(404, f"Branch not found locally: {name}")

    args = ["checkout"]
    if force:
        args.append("-f")
    if create:
        args.append("-b")
    args.append(name)

    rc, out, err = _run_git(args, ws, timeout=15.0)
    if rc != 0:
        raise HTTPException(500, f"git checkout failed: {err or out}")

    _, head, _ = _run_git(["rev-parse", "--short", "HEAD"], ws)
    return {
        "status": "ok",
        "branch": name,
        "head": head,
        "created": create,
    }


# ═══════════════════════════════════════════════════════════════════════
# 1c. WORKSPACE-ROUTED LLM PROXY (replaces standalone cvc serve)
#
# AI tools (Claude Code, Aider, Codex, Gemini CLI, Kiro, etc.) send
# LLM requests to  http://127.0.0.1:13421/ws/{workspace_id}/v1/...
# The gateway looks up the correct CVCEngine for that workspace and
# runs full CVC interception (context capture, auto-commit, etc.).
# ═══════════════════════════════════════════════════════════════════════

# -- Workspace registration ------------------------------------------------

# Maps workspace_id (short hash) → resolved Path
_registered_workspaces: dict[str, Path] = {}

# Per-workspace session trackers, adapters, graphs, and config
_ws_adapters: dict[str, Any] = {}
_ws_graphs: dict[str, Any] = {}
_ws_session_trackers: dict[str, Any] = {}  # workspace_id → _SessionTracker


# Time Machine configuration (same knobs as the old proxy)
_TIME_MACHINE_ENABLED: bool = os.environ.get("CVC_TIME_MACHINE", "0") == "1"
_TIME_MACHINE_INTERVAL: int = int(os.environ.get("CVC_TIME_MACHINE_INTERVAL", "1"))
_NORMAL_INTERVAL: int = int(os.environ.get("CVC_AUTO_COMMIT_INTERVAL", "3"))
_SESSION_TIMEOUT: int = int(os.environ.get("CVC_SESSION_TIMEOUT", "1800"))


class _SessionTracker:
    """Lightweight tracker for agent sessions going through the proxy."""

    def __init__(self) -> None:
        self.sessions: list[dict[str, Any]] = []
        self._current: dict[str, Any] | None = None
        self._last_request_ts: float = 0.0

    def touch(self, *, tool_hint: str = "") -> dict[str, Any]:
        now = time.time()
        gap = now - self._last_request_ts if self._last_request_ts else 0
        self._last_request_ts = now

        if self._current is None or gap > _SESSION_TIMEOUT:
            if self._current is not None:
                self._current["ended_at"] = now - gap
                self.sessions.append(self._current)

            self._current = {
                "id": len(self.sessions) + 1,
                "started_at": now,
                "ended_at": None,
                "tool": tool_hint or "unknown",
                "messages": 0,
                "commits": 0,
                "branch_at_start": "",
            }

        self._current["messages"] += 1
        if tool_hint and self._current["tool"] == "unknown":
            self._current["tool"] = tool_hint
        return self._current

    def record_commit(self) -> None:
        if self._current:
            self._current["commits"] += 1

    def all_sessions(self) -> list[dict[str, Any]]:
        result = list(self.sessions)
        if self._current:
            result.append({**self._current, "active": True})
        return result


def _make_workspace_id(path: Path) -> str:
    """Generate a short, URL-safe workspace identifier from a directory path."""
    return hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:12]


def _get_ws_engine(workspace_id: str):
    """Return the CVCEngine for a registered workspace, or raise 404."""
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")
    ws_path = _registered_workspaces.get(workspace_id)
    if ws_path is None:
        raise HTTPException(404, f"Workspace not registered: {workspace_id}")
    key = str(ws_path.resolve())
    inst = _workspace_mgr._workspaces.get(key)
    if inst is None or not inst.initialized:
        # Re-initialize on demand
        inst = _workspace_mgr.switch_to(ws_path)
    inst.touch()
    return inst.engine, inst.config, inst.db


def _get_ws_tracker(workspace_id: str) -> _SessionTracker:
    """Return (or lazily create) the session tracker for a workspace."""
    if workspace_id not in _ws_session_trackers:
        _ws_session_trackers[workspace_id] = _SessionTracker()
    return _ws_session_trackers[workspace_id]


async def _get_ws_adapter(workspace_id: str, config):
    """Return (or lazily create) the LLM adapter for a workspace."""
    if workspace_id not in _ws_adapters:
        from cvc.adapters import create_adapter
        _ws_adapters[workspace_id] = create_adapter(
            provider=config.provider,
            api_key=config.api_key,
            model=config.model,
            base_url=config.upstream_base_url,
        )
    return _ws_adapters[workspace_id]


def _get_ws_graph(workspace_id: str, engine):
    """Return (or lazily create) the CVC state-machine graph for a workspace."""
    if workspace_id not in _ws_graphs:
        from cvc.operations.state_machine import build_cvc_graph
        graph_builder = build_cvc_graph(engine)
        _ws_graphs[workspace_id] = graph_builder.compile()
    return _ws_graphs[workspace_id]


@app.post("/gateway/register_workspace")
async def register_workspace(request: Request):
    """Register a workspace directory with the gateway.

    Body: ``{"path": "/home/user/project-a"}``

    Returns a ``workspace_id`` that the launcher injects into env vars
    so the AI tool's requests are routed to the correct .cvc/ database.
    """
    if not _workspace_mgr:
        raise HTTPException(503, "Workspace manager not initialised")

    body = await request.json()
    raw_path = body.get("path", "")
    if not raw_path:
        raise HTTPException(400, "Missing 'path' in request body")

    target = Path(raw_path).resolve()
    if not target.is_dir():
        raise HTTPException(400, f"Not a directory: {target}")

    workspace_id = _make_workspace_id(target)

    # Register in the memory map
    _registered_workspaces[workspace_id] = target

    # Initialize the workspace (auto-creates .cvc/ if needed)
    inst = _workspace_mgr.switch_to(target)

    logger.info(
        "Workspace registered: %s → %s (branch=%s)",
        workspace_id,
        target,
        inst.engine.active_branch if inst.engine else "main",
    )

    return {
        "workspace_id": workspace_id,
        "path": str(target),
        "branch": inst.engine.active_branch if inst.engine else "main",
        "base_url": f"http://{_HOST}:{_GATEWAY_PORT}/ws/{workspace_id}",
    }


@app.get("/gateway/workspaces")
async def list_registered_workspaces():
    """List all workspaces currently registered with the gateway proxy."""
    result = []
    for ws_id, ws_path in _registered_workspaces.items():
        info: dict[str, Any] = {
            "workspace_id": ws_id,
            "path": str(ws_path),
            "name": ws_path.name or str(ws_path),
        }
        try:
            engine, _, _ = _get_ws_engine(ws_id)
            info["branch"] = engine.active_branch
            info["context_size"] = len(engine.context_window)
        except Exception:
            info["branch"] = "unknown"
            info["context_size"] = 0
        tracker = _ws_session_trackers.get(ws_id)
        if tracker:
            info["sessions"] = len(tracker.all_sessions())
        result.append(info)
    return {"workspaces": result, "count": len(result)}


# -- Proxy interception helpers -------------------------------------------

def _detect_tool_from_ua(ua: str) -> str:
    ua_lower = ua.lower()
    for keyword in ("claude", "aider", "codex", "cursor", "copilot", "gemini", "kiro"):
        if keyword in ua_lower:
            return keyword
    return ""


def _ws_should_auto_commit(engine) -> bool:
    assistant_msgs = [m for m in engine.context_window if m.role == "assistant"]
    count = len(assistant_msgs)
    if count == 0:
        return False
    interval = _TIME_MACHINE_INTERVAL if _TIME_MACHINE_ENABLED else _NORMAL_INTERVAL
    return count % interval == 0


def _ws_build_auto_commit_message(engine) -> str:
    recent = [m for m in engine.context_window if m.role in ("user", "assistant")]
    if not recent:
        return "Auto-checkpoint"
    last_user = next((m for m in reversed(recent) if m.role == "user"), None)
    if last_user:
        summary = last_user.content[:120].replace("\n", " ").strip()
        return f"Auto: {summary}"
    return f"Auto-checkpoint ({len(recent)} messages)"


# -- OpenAI-compatible Chat Completions (workspace-routed) ----------------

@app.post("/ws/{workspace_id}/v1/chat/completions")
async def ws_chat_completions(workspace_id: str, raw_request: Request):
    """Workspace-routed OpenAI-compatible chat completions endpoint.

    Replaces the old standalone proxy's ``/v1/chat/completions``.
    """
    engine, config, db = _get_ws_engine(workspace_id)
    graph = _get_ws_graph(workspace_id, engine)
    adapter = await _get_ws_adapter(workspace_id, config)
    tracker = _get_ws_tracker(workspace_id)

    # Session tracking
    ua = raw_request.headers.get("user-agent", "")
    tool_hint = _detect_tool_from_ua(ua)
    session = tracker.touch(tool_hint=tool_hint)
    if not session.get("branch_at_start"):
        session["branch_at_start"] = engine.active_branch

    from cvc.core.models import (
        ChatCompletionChoice, ChatCompletionRequest, ChatCompletionResponse,
        ChatMessage, CVCCommitRequest, CVCOperationResponse,
    )
    from cvc.operations.state_machine import CVCGraphState

    body = await raw_request.json()
    request = ChatCompletionRequest(**body)

    # 1. Run through the CVC state machine
    initial_state: CVCGraphState = {
        "request": request,
        "is_cvc_command": False,
        "cvc_tool_name": "",
        "cvc_tool_args": {},
        "response": None,
        "cvc_result": None,
        "active_branch": engine.active_branch,
        "head_hash": engine.head_hash or "",
        "committed_prefix_len": 0,
    }
    result_state = graph.invoke(initial_state)

    # 2. CVC command → return directly
    if result_state.get("is_cvc_command") and result_state.get("cvc_result"):
        cvc_result: CVCOperationResponse = result_state["cvc_result"]
        wrapped = ChatCompletionResponse(
            model=request.model,
            choices=[
                ChatCompletionChoice(
                    message=ChatMessage(
                        role="assistant",
                        content=json.dumps(cvc_result.model_dump(), indent=2),
                    ),
                    finish_reason="stop",
                )
            ],
        )
        return JSONResponse(
            content=wrapped.model_dump(),
            headers={"X-CVC-Operation": cvc_result.operation},
        )

    # 3. Standard generation — capture context & proxy upstream
    existing_count = len(engine.context_window)
    inbound_count = len(request.messages)
    if inbound_count > existing_count:
        for msg in request.messages[existing_count:]:
            if msg.role in ("user", "system", "tool"):
                engine.push_chat_message(msg)

    committed_prefix_len = result_state.get("committed_prefix_len", 0)
    is_streaming = bool(body.get("stream", False))

    # COGNOME injection — compile an Engram and prepend it before the
    # upstream LLM call, giving it curated workspace context.
    _cognome_engram = None
    try:
        from cvc.operations.cognome_runtime import CognomeRuntime
        runtime = CognomeRuntime.for_engine(engine)
        if runtime.is_active():
            raw_msgs = [{"role": m.role, "content": m.content or ""} for m in request.messages]
            updated_msgs, _cognome_engram = await runtime.resolve_messages(
                raw_msgs,
                provider=config.provider,
                model=config.model,
                branch=request.cvc_branch,
            )
            if _cognome_engram and _cognome_engram.preamble:
                from cvc.core.models import ChatMessage as CM
                request.messages = [CM(**m) for m in updated_msgs]
                committed_prefix_len += 1
    except Exception as exc:
        logger.warning("COGNOME injection failed (ws %s, non-fatal): %s", workspace_id, exc)

    # Passthrough mode: no internal adapter — client must use /v1/messages directly
    if config.provider == "passthrough":
        raise HTTPException(
            status_code=400,
            detail=(
                "CVC is in passthrough mode. Claude Code and Anthropic tools should use "
                "/v1/messages (set ANTHROPIC_BASE_URL). OpenAI-compatible tools: "
                "run 'cvc setup --provider openai' to configure a provider."
            ),
        )

    try:
        response = await adapter.complete(request, committed_prefix_len=committed_prefix_len)
    except Exception as exc:
        logger.error("Upstream provider error (ws %s): %s", workspace_id, exc)
        raise HTTPException(status_code=502, detail=f"Upstream error: {exc}") from exc

    # 4. Record assistant response
    if response.choices:
        assistant_msg = response.choices[0].message
        engine.push_chat_message(assistant_msg)

    # 5. Auto-commit
    if _ws_should_auto_commit(engine):
        auto_msg = _ws_build_auto_commit_message(engine)
        auto_result = engine.commit(CVCCommitRequest(message=auto_msg, commit_type="checkpoint"))
        if auto_result.success:
            tracker.record_commit()
            logger.info("Auto-commit (ws %s): %s", workspace_id,
                        auto_result.commit_hash and auto_result.commit_hash[:12])

    # 6. If client requested streaming, wrap full response as SSE chunks
    if is_streaming:
        from fastapi.responses import StreamingResponse as _StreamRes
        resp_data = response.model_dump()
        resp_id = resp_data.get("id", f"chatcmpl-{int(time.time())}")
        model_name = resp_data.get("model", request.model)
        content = ""
        finish_reason = "stop"
        if response.choices:
            choice = response.choices[0]
            content = choice.message.content or ""
            finish_reason = choice.finish_reason or "stop"

        def _sse_chunks():
            # Role delta
            yield "data: " + json.dumps({
                "id": resp_id, "object": "chat.completion.chunk",
                "model": model_name,
                "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
            }) + "\n\n"
            # Content in chunks of ~100 chars
            chunk_size = 100
            for i in range(0, max(len(content), 1), chunk_size):
                chunk = content[i:i + chunk_size]
                yield "data: " + json.dumps({
                    "id": resp_id, "object": "chat.completion.chunk",
                    "model": model_name,
                    "choices": [{"index": 0, "delta": {"content": chunk}, "finish_reason": None}],
                }) + "\n\n"
            # Stop chunk
            yield "data: " + json.dumps({
                "id": resp_id, "object": "chat.completion.chunk",
                "model": model_name,
                "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
            }) + "\n\n"
            yield "data: [DONE]\n\n"

        return _StreamRes(
            _sse_chunks(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    return JSONResponse(content=response.model_dump())


# -- Anthropic Messages API (workspace-routed, for Claude Code) -----------

@app.post("/ws/{workspace_id}/v1/messages")
async def ws_anthropic_messages(workspace_id: str, raw_request: Request):
    """Workspace-routed Anthropic-native Messages API endpoint.

    Claude Code CLI sends requests to ANTHROPIC_BASE_URL + '/v1/messages'.
    """
    engine, config, db = _get_ws_engine(workspace_id)
    tracker = _get_ws_tracker(workspace_id)

    ua = raw_request.headers.get("user-agent", "")
    tool_hint = _detect_tool_from_ua(ua)
    session = tracker.touch(tool_hint=tool_hint)
    if not session.get("branch_at_start"):
        session["branch_at_start"] = engine.active_branch

    from cvc.core.models import (
        ChatCompletionRequest, ChatMessage, CVCCommitRequest, CVCOperationResponse,
    )
    from cvc.operations.state_machine import CVCGraphState

    body = await raw_request.json()

    # Convert Anthropic format → internal OpenAI format
    messages_in = body.get("messages", [])
    system_text = body.get("system", "")
    openai_messages: list[dict[str, Any]] = []

    if system_text:
        if isinstance(system_text, list):
            sys_parts = [b.get("text", "") for b in system_text if b.get("type") == "text"]
            system_text = "\n".join(sys_parts)
        openai_messages.append({"role": "system", "content": system_text})

    for msg in messages_in:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if isinstance(content, list):
            text_parts = [b.get("text", "") for b in content if b.get("type") == "text"]
            content = "\n".join(text_parts)
        openai_messages.append({"role": role, "content": content})

    internal_request = ChatCompletionRequest(
        model=body.get("model", config.model),
        messages=[ChatMessage(**m) for m in openai_messages],
        temperature=body.get("temperature", 0.7),
        max_tokens=body.get("max_tokens", 4096),
    )

    # Convert Anthropic tools → OpenAI tools
    anthropic_tools = body.get("tools", [])
    if anthropic_tools:
        openai_tools = []
        for t in anthropic_tools:
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": t.get("name", ""),
                    "description": t.get("description", ""),
                    "parameters": t.get("input_schema", {}),
                },
            })
        internal_request.tools = openai_tools

    # Run through CVC state machine
    graph = _get_ws_graph(workspace_id, engine)

    existing_count = len(engine.context_window)
    for msg in internal_request.messages[existing_count:]:
        if msg.role in ("user", "system", "tool"):
            engine.push_chat_message(msg)

    initial_state: CVCGraphState = {
        "request": internal_request,
        "is_cvc_command": False,
        "cvc_tool_name": "",
        "cvc_tool_args": {},
        "response": None,
        "cvc_result": None,
        "active_branch": engine.active_branch,
        "head_hash": engine.head_hash or "",
        "committed_prefix_len": 0,
    }
    result_state = graph.invoke(initial_state)

    # CVC command → Anthropic format
    if result_state.get("is_cvc_command") and result_state.get("cvc_result"):
        cvc_result: CVCOperationResponse = result_state["cvc_result"]
        return JSONResponse(content={
            "id": f"msg_cvc_{int(time.time())}",
            "type": "message",
            "role": "assistant",
            "model": internal_request.model,
            "content": [{"type": "text", "text": json.dumps(cvc_result.model_dump(), indent=2)}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 0, "output_tokens": 0},
        }, headers={"X-CVC-Operation": cvc_result.operation})

    # Forward to upstream Anthropic API
    client_api_key = raw_request.headers.get("x-api-key", "") or ""
    auth_header = raw_request.headers.get("authorization", "")
    if auth_header.lower().startswith("bearer "):
        client_api_key = client_api_key or auth_header[7:].strip()
    upstream_key = client_api_key or config.api_key

    # In passthrough mode, the client MUST supply its own key.
    # For any other provider, a missing key is a config error.
    if not upstream_key:
        if config.provider == "passthrough":
            raise HTTPException(
                status_code=401,
                detail=(
                    "CVC is in passthrough mode and no API key was found in the request. "
                    "Ensure your AI tool (e.g. Claude Code) is sending its own API key via "
                    "the x-api-key or Authorization header."
                ),
            )
        raise HTTPException(
            status_code=401,
            detail=(
                "No API key available. Pass x-api-key header, set ANTHROPIC_API_KEY, "
                "or run 'cvc setup' to configure a provider."
            ),
        )

    import httpx
    from fastapi.responses import StreamingResponse
    headers = {
        "x-api-key": upstream_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    beta = raw_request.headers.get("anthropic-beta")
    if beta:
        headers["anthropic-beta"] = beta

    upstream_body = dict(body)
    
    # --- Inject Prompt Caching ---
    _breakpoints = 0
    if "system" in upstream_body and upstream_body["system"]:
        if isinstance(upstream_body["system"], str):
            upstream_body["system"] = [{"type": "text", "text": upstream_body["system"]}]
        if isinstance(upstream_body["system"], list) and len(upstream_body["system"]) > 0:
            upstream_body["system"][-1]["cache_control"] = {"type": "ephemeral"}
            _breakpoints += 1

    if "messages" in upstream_body and isinstance(upstream_body["messages"], list) and len(upstream_body["messages"]) > 0:
        if _breakpoints < 4:
            last_msg = upstream_body["messages"][-1]
            if "content" in last_msg:
                if isinstance(last_msg["content"], str):
                    last_msg["content"] = [{"type": "text", "text": last_msg["content"]}]
                if isinstance(last_msg["content"], list) and len(last_msg["content"]) > 0:
                    last_msg["content"][-1]["cache_control"] = {"type": "ephemeral"}
                    _breakpoints += 1
    # -----------------------------
    
    is_streaming = bool(upstream_body.get("stream", False))

    try:
        # passthrough → always forward to Anthropic; other providers use config URL
        upstream_url = "https://api.anthropic.com"
        if config.provider not in ("anthropic", "passthrough"):
            upstream_url = config.upstream_base_url.rstrip("/")

        if is_streaming:
            # Stream SSE directly to the client while capturing text for CVC
            async def _stream_and_capture():
                accumulated_text: list[str] = []
                try:
                    async with httpx.AsyncClient(timeout=300.0) as http_client:
                        async with http_client.stream(
                            "POST",
                            f"{upstream_url}/v1/messages",
                            json=upstream_body,
                            headers=headers,
                        ) as resp:
                            resp.raise_for_status()
                            async for raw_line in resp.aiter_lines():
                                if raw_line.startswith("data:"):
                                    payload = raw_line[5:].strip()
                                    if payload and payload != "[DONE]":
                                        try:
                                            evt = json.loads(payload)
                                            # Capture content_block_delta text
                                            delta = evt.get("delta", {})
                                            if delta.get("type") == "text_delta":
                                                accumulated_text.append(delta.get("text", ""))
                                        except Exception:
                                            pass
                                yield raw_line + "\n"
                except Exception as exc:
                    logger.error("Upstream stream error (ws %s): %s", workspace_id, exc)
                    yield f"data: {json.dumps({'error': str(exc)})}\n\n"
                    return

                # After stream completes, save to CVC
                full_text = "".join(accumulated_text).strip()
                if full_text:
                    engine.push_chat_message(ChatMessage(role="assistant", content=full_text))
                    if _ws_should_auto_commit(engine):
                        auto_msg = _ws_build_auto_commit_message(engine)
                        auto_result = engine.commit(CVCCommitRequest(message=auto_msg, commit_type="checkpoint"))
                        if auto_result.success:
                            tracker.record_commit()

            return StreamingResponse(
                _stream_and_capture(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "X-Accel-Buffering": "no",
                    "Connection": "keep-alive",
                },
            )

        # Non-streaming path
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(f"{upstream_url}/v1/messages", json=upstream_body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        logger.error("Upstream Anthropic error (ws %s): %s", workspace_id, exc)
        raise HTTPException(status_code=502, detail=f"Upstream error: {exc}") from exc

    # Record assistant response (non-streaming)
    content_blocks = data.get("content", [])
    text_parts = [b["text"] for b in content_blocks if b.get("type") == "text"]
    if text_parts:
        engine.push_chat_message(ChatMessage(role="assistant", content="\n".join(text_parts)))

    # Auto-commit
    if _ws_should_auto_commit(engine):
        auto_msg = _ws_build_auto_commit_message(engine)
        auto_result = engine.commit(CVCCommitRequest(message=auto_msg, commit_type="checkpoint"))
        if auto_result.success:
            tracker.record_commit()

    return JSONResponse(content=data)


# -- Model listing (workspace-routed) -------------------------------------

@app.get("/ws/{workspace_id}/v1/models")
async def ws_list_models(workspace_id: str):
    """Workspace-routed OpenAI-compatible model listing."""
    engine, config, _ = _get_ws_engine(workspace_id)
    return {
        "object": "list",
        "data": [{
            "id": config.model,
            "object": "model",
            "created": int(time.time()),
            "owned_by": f"cvc-gateway ({config.provider})",
            "permission": [],
        }],
    }


# -- Workspace proxy health -----------------------------------------------

@app.get("/ws/{workspace_id}/health")
async def ws_proxy_health(workspace_id: str):
    """Health check scoped to a workspace."""
    try:
        engine, config, _ = _get_ws_engine(workspace_id)
        return {
            "status": "ok",
            "service": "cvc-gateway-proxy",
            "workspace_id": workspace_id,
            "branch": engine.active_branch,
            "version": _cvc_version,
        }
    except HTTPException:
        raise
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


# -- CVC control endpoints (workspace-routed) ------------------------------

@app.get("/ws/{workspace_id}/cvc/status")
async def ws_cvc_status(workspace_id: str):
    engine, _, db = _get_ws_engine(workspace_id)
    branches = db.index.list_branches()
    return {
        "agent_id": engine.config.agent_id,
        "active_branch": engine.active_branch,
        "head_hash": engine.head_hash,
        "context_size": len(engine.context_window),
        "branches": [
            {"name": b.name, "head": b.head_hash[:12], "status": b.status.value}
            for b in branches
        ],
    }


@app.get("/ws/{workspace_id}/cvc/sessions")
async def ws_cvc_sessions(workspace_id: str):
    tracker = _get_ws_tracker(workspace_id)
    sessions = tracker.all_sessions()
    return {
        "time_machine": _TIME_MACHINE_ENABLED,
        "auto_commit_interval": _TIME_MACHINE_INTERVAL if _TIME_MACHINE_ENABLED else _NORMAL_INTERVAL,
        "session_timeout_seconds": _SESSION_TIMEOUT,
        "total": len(sessions),
        "sessions": sessions,
    }


# ═══════════════════════════════════════════════════════════════════════
# 2. SERVICE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/services")
async def get_services():
    _ensure()
    services = _manager.service_status()
    enriched = {}
    for svc in services:
        name = svc["name"]
        enriched[name] = svc
        enriched[name]["uptime"] = _manager.get_service(name).uptime_display
    if _get_db():
        try:
            agents = _get_db().index.list_agents() if hasattr(_get_db().index, "list_agents") else []
            enriched.get("sdk", {})["registered_agents"] = len(agents)
        except Exception:
            pass
        try:
            total = len(_get_db().index.list_all_commits(limit=9999)) if hasattr(_get_db().index, "list_all_commits") else 0
            enriched.get("sdk", {})["total_commits"] = total
        except Exception:
            pass
    return enriched


@app.post("/api/gateway/services/{service_name}/{action}")
async def service_action(service_name: str, action: str):
    _ensure()
    if service_name == "proxy":
        port = _manager.get_service("proxy").port or _PROXY_PORT
        actions = {
            "start": lambda: _manager.start_proxy(port),
            "stop": lambda: _manager.stop_proxy(),
            "restart": lambda: _manager.restart_proxy(port),
            "pause": lambda: _manager.pause_proxy(),
            "resume": lambda: _manager.resume_proxy(),
        }
    else:
        raise HTTPException(400, f"Service '{service_name}' does not support lifecycle actions")
    if action not in actions:
        raise HTTPException(400, f"Unknown action '{action}'. Use: start, stop, restart, pause, resume")
    result = actions[action]()
    _get_event_bus().emit("service.action", {"service": service_name, "action": action, "status": result.status})
    return result.to_dict()


# ═══════════════════════════════════════════════════════════════════════
# 3. ANALYTICS & COMMITS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/analytics")
async def get_analytics():
    _ensure()
    analytics: dict[str, Any] = {
        "commits": {"total": 0, "by_type": {}, "by_branch": {}},
        "branches": [],
        "tokens": {"total": 0, "estimated_cost_usd": 0.0},
        "recent_activity": [],
    }
    try:
        idx = _get_db().index
        commits = idx.list_all_commits(limit=9999) if hasattr(idx, "list_all_commits") else []
        analytics["commits"]["total"] = len(commits)
        by_type: dict[str, int] = {}
        for c in commits:
            ct = _field(c, "commit_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
        analytics["commits"]["by_type"] = by_type

        branches = idx.list_branches() if hasattr(idx, "list_branches") else []
        analytics["branches"] = [
            {
                "name": b.name if hasattr(b, "name") else b.get("name", ""),
                "head": (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12],
                "status": b.status if hasattr(b, "status") else b.get("status", "active"),
            }
            for b in branches
        ]

        if hasattr(idx, "query_audit_log"):
            audit = idx.query_audit_log(limit=500)
            total_tokens = sum(e.get("token_count", 0) for e in audit if isinstance(e, dict))
            analytics["tokens"]["total"] = total_tokens
            analytics["tokens"]["estimated_cost_usd"] = round(total_tokens * 3.0 / 1_000_000, 4)

        recent = commits[-20:] if len(commits) > 20 else commits
        analytics["recent_activity"] = [
            {
                "hash": _field(c, "commit_hash", "")[:12],
                "type": _field(c, "commit_type", ""),
                "message": _field(c, "message", "")[:80],
                "agent_id": _meta(c, "agent_id", ""),
                "created_at": _ts(c),
            }
            for c in recent
        ]
    except Exception:
        logger.debug("Analytics query error", exc_info=True)
    return analytics


@app.get("/api/gateway/commits")
async def get_commits(limit: int = 50, offset: int = 0, branch: str | None = None, agent_id: str | None = None):
    _ensure()
    try:
        commits = _get_db().index.list_all_commits(limit=9999) if hasattr(_get_db().index, "list_all_commits") else []
        commits = list(reversed(commits))
        if branch:
            commits = [c for c in commits if _meta(c, "branch") == branch]
        if agent_id:
            commits = [c for c in commits if _meta(c, "agent_id") == agent_id]
        total = len(commits)
        page = commits[offset:offset + limit]
        return {
            "total": total, "offset": offset, "limit": limit,
            "commits": [
                {
                    "hash": _field(c, "commit_hash", "")[:12],
                    "type": _field(c, "commit_type", ""),
                    "message": _field(c, "message", ""),
                    "created_at": _ts(c),
                    "agent_id": _meta(c, "agent_id", ""),
                    "branch": _meta(c, "branch", ""),
                }
                for c in page
            ],
        }
    except Exception:
        logger.debug("Commits query error", exc_info=True)
        return {"total": 0, "offset": offset, "limit": limit, "commits": []}


# ═══════════════════════════════════════════════════════════════════════
# 4. OPERATIONS — commit, branch, merge, restore, recall, diff
# ═══════════════════════════════════════════════════════════════════════

@app.post("/api/ops/commit")
async def ops_commit(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import CommitRequest
    req = CommitRequest(
        message=body.get("message", "Dashboard commit"),
        content=body.get("content", ""),
        commit_type=body.get("type", "checkpoint"),
        tags=body.get("tags", []),
    )
    result = _get_engine().commit(req)
    _get_event_bus().emit("commit.created", {"hash": result.commit_hash[:12], "message": req.message})
    return {"commit_hash": result.commit_hash[:12], "message": req.message, "status": "ok"}


@app.post("/api/ops/branch")
async def ops_branch(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import BranchRequest
    req = BranchRequest(name=body["name"])
    result = _get_engine().branch(req)
    return {"branch": result.name, "head": result.head_hash[:12] if result.head_hash else "", "status": "ok"}


@app.post("/api/ops/merge")
async def ops_merge(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import MergeRequest
    req = MergeRequest(source_branch=body["source_branch"], strategy=body.get("strategy", "semantic"))
    result = _get_engine().merge(req)
    return {"merge_commit": result.commit_hash[:12] if hasattr(result, "commit_hash") else "", "status": "ok"}


@app.post("/api/ops/restore")
async def ops_restore(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import RestoreRequest
    hash_val = body.get("hash") or body.get("commit_hash", "")
    req = RestoreRequest(commit_hash=hash_val)
    _get_engine().restore(req)
    return {"restored_to": hash_val, "status": "ok"}


@app.get("/api/ops/status")
async def ops_status():
    _ensure("engine")
    try:
        branches = _get_db().index.list_branches() if hasattr(_get_db().index, "list_branches") else []
        commits = _get_db().index.list_all_commits(limit=9999) if hasattr(_get_db().index, "list_all_commits") else []
        active = _get_config().default_branch
        head = ""
        for b in branches:
            name = b.name if hasattr(b, "name") else b.get("name", "")
            if name == active:
                head = (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12]
                break
        db_path = _get_config().cvc_root / "cvc.db"
        blobs_dir = _get_config().cvc_root / "objects"
        return {
            "branch": active, "head": head,
            "total_branches": len(branches), "total_commits": len(commits),
            "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "blob_count": len(list(blobs_dir.glob("*"))) if blobs_dir.exists() else 0,
            "cvc_root": str(_get_config().cvc_root),
        }
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/ops/recall")
async def ops_recall(query: str, limit: int = 10):
    _ensure()
    try:
        results = _get_db().search_conversations(query, limit=limit)
        return {"results": results, "total": len(results)}
    except Exception as exc:
        logger.debug("Recall search error", exc_info=True)
        return {"results": [], "total": 0, "error": str(exc)}


@app.get("/api/ops/diff")
async def ops_diff(hash1: str, hash2: str):
    _ensure()
    try:
        idx = _get_db().index
        c1 = idx.get_commit(hash1) if hasattr(idx, "get_commit") else None
        c2 = idx.get_commit(hash2) if hasattr(idx, "get_commit") else None
        if not c1 or not c2:
            raise HTTPException(404, "One or both commits not found")

        # Build a meaningful diff from commit metadata + blob content
        diff_lines = []
        diff_lines.append(f"--- Commit A: {hash1[:12]}")
        diff_lines.append(f"+++ Commit B: {hash2[:12]}")
        diff_lines.append("")

        m1, m2 = _field(c1, "message", ""), _field(c2, "message", "")
        t1, t2 = _field(c1, "commit_type", ""), _field(c2, "commit_type", "")
        diff_lines.append(f"Message A: {m1}")
        diff_lines.append(f"Message B: {m2}")
        if t1 != t2:
            diff_lines.append(f"Type: {t1} → {t2}")

        # Try to diff blob contents
        try:
            h1_full = _field(c1, "commit_hash", hash1)
            h2_full = _field(c2, "commit_hash", hash2)
            blob1 = _get_db().retrieve_blob(h1_full)
            blob2 = _get_db().retrieve_blob(h2_full)
            if blob1 and blob2:
                msgs1 = [f"[{m.role}] {m.content[:100]}" for m in (blob1.messages or [])]
                msgs2 = [f"[{m.role}] {m.content[:100]}" for m in (blob2.messages or [])]
                diff_lines.append("")
                diff_lines.append(f"Context A: {len(blob1.messages or [])} messages")
                diff_lines.append(f"Context B: {len(blob2.messages or [])} messages")
                # Show what's new in B
                msgs1_set = set(msgs1)
                for m in msgs2:
                    if m not in msgs1_set:
                        diff_lines.append(f"+ {m}")
                msgs2_set = set(msgs2)
                for m in msgs1:
                    if m not in msgs2_set:
                        diff_lines.append(f"- {m}")
        except Exception:
            pass

        return {
            "commit_a": {"hash": hash1, "message": m1, "type": t1},
            "commit_b": {"hash": hash2, "message": m2, "type": t2},
            "diff": "\n".join(diff_lines),
        }
    except HTTPException:
        raise
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/ops/timeline")
async def ops_timeline(limit: int = 100):
    _ensure()
    try:
        commits = _get_db().index.list_all_commits(limit=limit) if hasattr(_get_db().index, "list_all_commits") else []
        commits = list(reversed(commits))[:limit]
        return {
            "timeline": [
                {
                    "hash": _field(c, "commit_hash", "")[:12],
                    "type": _field(c, "commit_type", ""),
                    "message": _field(c, "message", ""),
                    "created_at": _ts(c),
                    "agent_id": _meta(c, "agent_id", ""),
                    "branch": _meta(c, "branch", ""),
                }
                for c in commits
            ]
        }
    except Exception as exc:
        return {"timeline": [], "error": str(exc)}


@app.get("/api/ops/branches")
async def ops_branches():
    _ensure()
    try:
        branches = _get_db().index.list_branches() if hasattr(_get_db().index, "list_branches") else []
        return {
            "branches": [
                {
                    "name": b.name if hasattr(b, "name") else b.get("name", ""),
                    "head": (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12],
                    "status": b.status if hasattr(b, "status") else b.get("status", "active"),
                }
                for b in branches
            ]
        }
    except Exception as exc:
        return {"branches": [], "error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 5. MEMORY & CONTEXT
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/memory/context")
async def get_context(limit: int = 50):
    _ensure()
    try:
        ctx = _get_engine().context_window if _get_engine() else []
        messages = ctx[:limit]
        token_count = sum(len(getattr(m, 'content', '').split()) for m in ctx)
        return {
            "messages": [
                {"role": getattr(m, 'role', ''), "content": getattr(m, 'content', '')[:500], "timestamp": getattr(m, 'timestamp', 0)}
                for m in messages
            ],
            "total": len(ctx),
            "token_count": token_count,
        }
    except Exception as exc:
        return {"messages": [], "total": 0, "token_count": 0, "error": str(exc)}


@app.get("/api/memory/blobs")
async def get_blobs(limit: int = 20):
    _ensure()
    try:
        blobs_dir = _get_config().cvc_root / "objects"
        if not blobs_dir.exists():
            return {"blobs": [], "total": 0}
        blob_files = sorted(blobs_dir.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
        return {
            "blobs": [{"hash": f.name, "size_bytes": f.stat().st_size, "modified": f.stat().st_mtime} for f in blob_files],
            "total": len(list(blobs_dir.glob("*"))),
        }
    except Exception as exc:
        return {"blobs": [], "total": 0, "error": str(exc)}


@app.get("/api/memory/stats")
async def get_memory_stats():
    _ensure()
    try:
        db_path = _get_config().cvc_root / "cvc.db"
        blobs_dir = _get_config().cvc_root / "objects"
        return {
            "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "blob_count": len(list(blobs_dir.glob("*"))) if blobs_dir.exists() else 0,
            "blob_total_bytes": sum(f.stat().st_size for f in blobs_dir.glob("*")) if blobs_dir.exists() else 0,
            "cvc_root": str(_get_config().cvc_root),
        }
    except Exception as exc:
        return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 6. MODEL CATALOG & PROVIDER
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/models/catalog")
async def get_model_catalog():
    try:
        from cvc.adapters import PROVIDER_DEFAULTS
        # Build a proper model catalog per provider
        MODEL_CATALOG = {
            "anthropic": [
                {"id": "claude-3-opus", "name": "Claude 3 Opus", "context_window": 200000},
                {"id": "claude-3.5-sonnet", "name": "Claude 3.5 Sonnet", "context_window": 200000},
                {"id": "claude-3-5-haiku-20241022", "name": "Claude 3.5 Haiku", "context_window": 200000},
            ],
            "openai": [
                {"id": "gpt-4o", "name": "GPT-4o", "context_window": 128000},
                {"id": "gpt-4", "name": "GPT-4", "context_window": 128000},
                {"id": "o1-preview", "name": "o1 Preview", "context_window": 128000},
                {"id": "o1-mini", "name": "o1 Mini", "context_window": 128000},
            ],
            "google": [
                {"id": "gemini-3.1-pro-preview", "name": "Gemini 3.1 Pro", "context_window": 1000000},
                {"id": "gemini-3-flash-preview", "name": "Gemini 3 Flash", "context_window": 1000000},
            ],
            "ollama": [
                {"id": "qwen2.5-coder:7b", "name": "Qwen 2.5 Coder 7B", "context_window": 32768},
                {"id": "qwen3-coder:latest", "name": "Qwen 3 Coder", "context_window": 32768},
                {"id": "deepseek-r1:latest", "name": "DeepSeek-R1", "context_window": 32768},
                {"id": "llama3:8b", "name": "Llama 3 8B", "context_window": 8192},
            ],
            "lmstudio": [
                {"id": "loaded-model", "name": "LM Studio (loaded model)", "context_window": 0},
            ],
            "github": []
        }

        # Dynamically fetch actual GitHub Copilot models available for this user
        from cvc.core.models import GlobalConfig
        gc = GlobalConfig.load()
        if gc and "github" in gc.api_keys:
            oauth_token = gc.api_keys["github"]
            from cvc.agent.providers.github_auth import fetch_copilot_token
            import httpx
            token_data = fetch_copilot_token(oauth_token)
            if token_data:
                copilot_token = token_data.get("token")
                proxy_ep = token_data.get("endpoints", {}).get("api", "https://api.individual.githubcopilot.com")
                try:
                    resp = httpx.get(
                        f"{proxy_ep.rstrip('/')}/models",
                        headers={
                            "Authorization": f"Bearer {copilot_token}",
                            "Accept": "application/json",
                            "editor-version": "vscode/1.93.0",
                            "editor-plugin-version": "copilot-chat/0.20.0"
                        },
                        timeout=5.0
                    )
                    if resp.status_code == 200:
                        models_data = resp.json().get("data", [])
                        gh_models = []
                        for m in models_data:
                            if m.get("policy", {}).get("state") == "disabled":
                                continue
                            mid = m["id"].lower()
                            if "3.5" in mid or "3-5" in mid or "opus-3" in mid:
                                continue
                            gh_models.append({
                                "id": m["id"],
                                "name": m.get("name", m["id"]),
                                "context_window": 128000
                            })
                        if gh_models:
                            MODEL_CATALOG["github"] = gh_models
                except Exception:
                    pass
        
        catalog = {}
        for provider, defaults in PROVIDER_DEFAULTS.items():
            if provider == "github":
                catalog[provider] = MODEL_CATALOG.get("github", [])
            else:
                catalog[provider] = MODEL_CATALOG.get(provider, [{"id": defaults["model"], "name": defaults["model"]}])

        # Decorate every entry with `is_primary` + `provider_label` so the
        # frontend picker doesn't have to do string munging or cross-lookups.
        cur_provider = _agent_llm.provider if _agent_llm else (
            _get_config().provider if _get_config() else ""
        )
        cur_model = _agent_llm.model if _agent_llm else (
            _get_config().model if _get_config() else ""
        )
        _PROVIDER_LABELS = {
            "anthropic": "Anthropic",
            "openai": "OpenAI",
            "google": "Google",
            "ollama": "Ollama",
            "lmstudio": "LM Studio",
            "github": "GitHub Copilot",
            "copilot": "GitHub Copilot",
            "vertex": "Google Vertex",
            "nvidia": "NVIDIA",
        }
        for provider, models in catalog.items():
            label_base = _PROVIDER_LABELS.get(provider, provider.title())
            count = len(models)
            label = f"{label_base} ({count} model{'s' if count != 1 else ''})"
            for entry in models:
                entry["provider"] = provider
                entry["provider_label"] = label
                entry["is_primary"] = bool(
                    provider == cur_provider and entry.get("id") == cur_model
                )
        return {
            "providers": catalog,
            "current_provider": cur_provider,
            "current_model": cur_model,
        }
    except Exception as exc:
        return {"providers": {}, "error": str(exc)}


@app.get("/api/models/current")
async def get_current_model():
    _ensure()
    from cvc.core.models import GlobalConfig as GC
    gc = GC.load()
    # Prefer the live agent LLM config (matches what chat actually uses)
    provider = _agent_llm.provider if _agent_llm else _get_config().provider
    model = _agent_llm.model if _agent_llm else _get_config().model
    return {
        "provider": provider,
        "model": model,
        "api_key_set": bool(_get_config().api_key) or bool(_agent_llm),
        "api_keys_stored": {k: bool(v) for k, v in gc.api_keys.items()},
    }


@app.post("/api/models/switch")
async def switch_model(request: Request):
    global _agent_llm, _system_prompt
    _ensure()
    body = await request.json()
    new_provider = body.get("provider", _get_config().provider)
    new_model = body.get("model", _get_config().model)
    from cvc.core.models import GlobalConfig as GC
    gc = GC.load()
    gc.provider = new_provider
    gc.model = new_model
    gc.save()
    _get_config().provider = new_provider
    _get_config().model = new_model

    # Re-create the AgentLLM with the new provider/model
    try:
        from cvc.agent.llm import AgentLLM
        from cvc.agent.system_prompt import build_system_prompt

        env_map = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY", "google": "GOOGLE_API_KEY", "ollama": "", "lmstudio": "", "github": "GITHUB_TOKEN"}
        env_key = env_map.get(new_provider, "")
        api_key = os.getenv(env_key, "") if env_key else ""
        if not api_key:
            api_key = gc.api_keys.get(new_provider, "")
        base_url_map = {
            "anthropic": "https://api.anthropic.com", "openai": "https://api.openai.com",
            "google": "https://generativelanguage.googleapis.com",
            "ollama": os.getenv("OLLAMA_HOST", "http://localhost:11434"),
            "lmstudio": os.getenv("LMSTUDIO_HOST", "http://localhost:1234"),
            "copilot": "https://api.githubcopilot.com",
        }
        if _agent_llm:
            try:
                await _agent_llm.close()
            except Exception:
                pass
        _agent_llm = AgentLLM(provider=new_provider, api_key=api_key, model=new_model, base_url=base_url_map.get(new_provider, ""))
        _system_prompt = build_system_prompt(workspace=str(_project_root), provider=new_provider, model=new_model, branch=_get_engine().active_branch)
        asyncio.create_task(_agent_llm.warm_connection())
        logger.info("Agent LLM switched to %s/%s", new_provider, new_model)
    except Exception:
        logger.warning("Failed to re-create AgentLLM after model switch", exc_info=True)

    # Notify the proxy to reload config (best-effort)
    try:
        import httpx
        httpx.post(f"http://{_HOST}:{_PROXY_PORT}/cvc/reload-config", timeout=3.0)
    except Exception:
        pass
    return {"provider": new_provider, "model": new_model, "status": "ok"}


# ═══════════════════════════════════════════════════════════════════════
# 7. HIVE MIND / SDK
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/config")
async def get_config():
    _ensure()
    provider = _agent_llm.provider if _agent_llm else _get_config().provider
    model = _agent_llm.model if _agent_llm else _get_config().model
    return {
        "version": _cvc_version,
        "provider": provider,
        "model": model,
        "agent_id": _get_config().agent_id,
        "default_branch": _get_config().default_branch,
        "proxy_port": _PROXY_PORT,
        "gateway_port": _GATEWAY_PORT,
        "host": _HOST,
        "api_key_set": bool(_get_config().api_key) or bool(_agent_llm),
        "cvc_root": str(_get_config().cvc_root),
    }


@app.get("/api/hivemind/agents")
async def get_hivemind_agents():
    _ensure()
    try:
        agents = _get_db().index.list_agents() if hasattr(_get_db().index, "list_agents") else []
        result = []
        for a in agents:
            if isinstance(a, dict):
                result.append(a)
            else:
                d = {}
                for attr in ('agent_id', 'name', 'role', 'rank', 'squad', 'status'):
                    if hasattr(a, attr):
                        d[attr] = getattr(a, attr)
                result.append(d)
        return {"agents": result, "total": len(result)}
    except Exception:
        return {"agents": [], "total": 0}


@app.post("/api/hivemind/register")
async def register_agent(request: Request):
    _ensure()
    body = await request.json()
    try:
        agent_id = body["agent_id"]
        _get_db().index.insert_agent(
            agent_id=agent_id,
            name=body.get("name", agent_id),
            role=body.get("role", "worker"),
            rank=body.get("rank", "private"),
            squad=body.get("squad", "alpha"),
        )
        return {"agent_id": agent_id, "status": "registered"}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/hivemind/agents/{agent_id}")
async def remove_agent(agent_id: str):
    _ensure()
    try:
        if hasattr(_get_db().index, "delete_agent") and _get_db().index.delete_agent(agent_id):
            return {"agent_id": agent_id, "status": "removed"}
        raise HTTPException(404, f"Agent '{agent_id}' not found")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, str(exc))


# ═══════════════════════════════════════════════════════════════════════
# 7b. SETTINGS — Comprehensive Configuration Management
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/settings")
async def get_settings():
    """Return merged settings from all levels + global config."""
    _ensure()
    from cvc.agent.settings import load_settings
    from cvc.core.models import SETTINGS_SCHEMA, GlobalConfig

    gc = GlobalConfig.load()
    workspace = Path(_project_root) if _project_root else Path.cwd()
    settings = load_settings(workspace)

    # Mask API keys
    masked_keys = {}
    for prov, key in gc.api_keys.items():
        if key and len(key) > 8:
            masked_keys[prov] = f"{key[:4]}***{key[-4:]}"
        elif key:
            masked_keys[prov] = "***"
        else:
            masked_keys[prov] = ""

    return {
        "global": {
            "provider": gc.provider,
            "model": gc.model,
            "agent_id": gc.agent_id,
            "api_keys": masked_keys,
        },
        "project": settings.to_dict(),
        "schema": SETTINGS_SCHEMA,
    }


@app.put("/api/settings/global")
async def update_global_settings(request: Request):
    """Update global config fields (provider, model, agent_id)."""
    _ensure()
    from cvc.core.models import GlobalConfig
    body = await request.json()
    gc = GlobalConfig.load()

    allowed_fields = {"provider", "model", "agent_id"}
    for key, value in body.items():
        if key in allowed_fields and isinstance(value, str):
            setattr(gc, key, value)

    gc.save()

    # Live-update the agent LLM if running
    global _agent_llm
    if _agent_llm:
        if "provider" in body or "model" in body:
            try:
                from cvc.adapters import get_adapter
                new_provider = body.get("provider", gc.provider)
                new_model = body.get("model", gc.model)
                _agent_llm = get_adapter(
                    new_provider, model=new_model,
                    api_key=gc.api_keys.get(new_provider, ""),
                )
            except Exception:
                pass

    return {"status": "ok", "saved": list(body.keys())}


@app.put("/api/settings/project")
async def update_project_settings(request: Request):
    """Update .cvc/settings.json (shared project settings)."""
    _ensure()
    from cvc.agent.settings import save_project_settings
    body = await request.json()
    workspace = Path(_project_root) if _project_root else Path.cwd()

    for key, value in body.items():
        save_project_settings(workspace, key, value, local=False)

    return {"status": "ok", "saved": list(body.keys())}


@app.put("/api/settings/local")
async def update_local_settings(request: Request):
    """Update .cvc/settings.local.json (local, not committed)."""
    _ensure()
    from cvc.agent.settings import save_project_settings
    body = await request.json()
    workspace = Path(_project_root) if _project_root else Path.cwd()

    for key, value in body.items():
        save_project_settings(workspace, key, value, local=True)

    return {"status": "ok", "saved": list(body.keys())}


@app.get("/api/settings/schema")
async def get_settings_schema():
    """Return JSON schema for dynamic form rendering."""
    from cvc.core.models import SETTINGS_SCHEMA
    return SETTINGS_SCHEMA


@app.post("/api/settings/reset")
async def reset_settings(request: Request):
    """Reset a settings level to defaults."""
    _ensure()
    body = await request.json()
    level = body.get("level", "local")
    workspace = Path(_project_root) if _project_root else Path.cwd()

    if level == "global":
        from cvc.core.models import GlobalConfig
        gc = GlobalConfig()
        gc.save()
    elif level == "project":
        path = workspace / ".cvc" / "settings.json"
        if path.exists():
            path.write_text("{}\n", encoding="utf-8")
    elif level == "local":
        path = workspace / ".cvc" / "settings.local.json"
        if path.exists():
            path.write_text("{}\n", encoding="utf-8")

    return {"status": "ok", "level": level}


@app.get("/api/settings/keys")
async def get_api_keys():
    """List configured API key providers (keys masked)."""
    from cvc.core.models import GlobalConfig
    gc = GlobalConfig.load()
    result = {}
    for prov, key in gc.api_keys.items():
        if key and len(key) > 8:
            result[prov] = {"masked": f"{key[:4]}***{key[-4:]}", "set": True}
        elif key:
            result[prov] = {"masked": "***", "set": True}
        else:
            result[prov] = {"masked": "", "set": False}
    return {"keys": result}


@app.put("/api/settings/keys/{provider}")
async def set_api_key(provider: str, request: Request):
    """Set or update an API key for a provider."""
    from cvc.core.models import GlobalConfig
    body = await request.json()
    api_key = body.get("api_key", "")
    if not api_key:
        raise HTTPException(400, "api_key is required")

    gc = GlobalConfig.load()
    gc.api_keys[provider] = api_key
    gc.save()
    return {"provider": provider, "status": "ok"}


@app.delete("/api/settings/keys/{provider}")
async def remove_api_key(provider: str):
    """Remove an API key for a provider."""
    from cvc.core.models import GlobalConfig
    gc = GlobalConfig.load()
    gc.api_keys.pop(provider, None)
    gc.save()
    return {"provider": provider, "status": "removed"}


@app.post("/api/settings/keys/{provider}/test")
async def test_api_key(provider: str):
    """Test if the configured API key for a provider works."""
    from cvc.core.models import GlobalConfig
    gc = GlobalConfig.load()
    api_key = gc.api_keys.get(provider, "")
    if not api_key:
        return {"provider": provider, "valid": False, "error": "No API key configured"}

    try:
        import httpx
        if provider == "anthropic":
            r = httpx.get(
                "https://api.anthropic.com/v1/models",
                headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
                timeout=10.0,
            )
            valid = r.status_code == 200
        elif provider == "openai":
            r = httpx.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=10.0,
            )
            valid = r.status_code == 200
        elif provider == "google":
            r = httpx.get(
                f"https://generativelanguage.googleapis.com/v1/models?key={api_key}",
                timeout=10.0,
            )
            valid = r.status_code == 200
        elif provider == "ollama":
            host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
            r = httpx.get(f"{host}/api/tags", timeout=5.0)
            valid = r.status_code == 200
        elif provider == "lmstudio":
            r = httpx.get("http://localhost:1234/v1/models", timeout=5.0)
            valid = r.status_code == 200
        else:
            return {"provider": provider, "valid": False, "error": "Unknown provider"}

        return {"provider": provider, "valid": valid, "status_code": r.status_code}
    except Exception as exc:
        return {"provider": provider, "valid": False, "error": str(exc)}


@app.get("/api/settings/hooks")
async def get_hooks():
    """List all configured hooks."""
    _ensure()
    from cvc.agent.settings import load_settings
    workspace = Path(_project_root) if _project_root else Path.cwd()
    settings = load_settings(workspace)
    return {"hooks": settings.hooks}


@app.post("/api/settings/hooks")
async def add_hook(request: Request):
    """Add a new hook."""
    _ensure()
    from cvc.agent.settings import load_settings, save_project_settings
    body = await request.json()
    event = body.get("event", "PreToolUse")
    hook_config = body.get("config", {})
    workspace = Path(_project_root) if _project_root else Path.cwd()

    settings = load_settings(workspace)
    hooks = dict(settings.hooks)
    if event not in hooks:
        hooks[event] = []
    hooks[event].append(hook_config)
    save_project_settings(workspace, "hooks", hooks, local=False)
    return {"status": "ok", "event": event}


@app.delete("/api/settings/hooks/{event}/{index}")
async def remove_hook(event: str, index: int):
    """Remove a hook by event type and index."""
    _ensure()
    from cvc.agent.settings import load_settings, save_project_settings
    workspace = Path(_project_root) if _project_root else Path.cwd()

    settings = load_settings(workspace)
    hooks = dict(settings.hooks)
    if event in hooks and 0 <= index < len(hooks[event]):
        hooks[event].pop(index)
        if not hooks[event]:
            del hooks[event]
        save_project_settings(workspace, "hooks", hooks, local=False)
        return {"status": "ok"}
    raise HTTPException(404, "Hook not found")


@app.get("/api/settings/env")
async def get_env_vars():
    """Return CVC-relevant environment variables."""
    cvc_vars = {}
    for key, val in os.environ.items():
        if key.startswith("CVC_") or key.endswith("_API_KEY") or key == "OLLAMA_HOST":
            if "KEY" in key and val and len(val) > 8:
                cvc_vars[key] = f"{val[:4]}***{val[-4:]}"
            elif "KEY" in key and val:
                cvc_vars[key] = "***"
            else:
                cvc_vars[key] = val
    return {"env": cvc_vars}


# ═══════════════════════════════════════════════════════════════════════
# 7c. AGENT TEMPLATES — Create, manage, and deploy custom agents
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/agents")
async def list_agents():
    """List all agents (registered + templates)."""
    _ensure()

    # Registered agents from DB
    registered = []
    try:
        agents = _get_db().index.list_agents() if hasattr(_get_db().index, "list_agents") else []
        for a in agents:
            d = a if isinstance(a, dict) else {}
            d["source"] = "registered"
            registered.append(d)
    except Exception:
        pass

    # Agent templates from .cvc/agent_templates/
    templates = []
    workspace = Path(_project_root) if _project_root else Path.cwd()
    tpl_dir = workspace / ".cvc" / "agent_templates"
    if tpl_dir.exists():
        for fp in sorted(tpl_dir.glob("*.json")):
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                data["source"] = "template"
                templates.append(data)
            except (json.JSONDecodeError, OSError):
                pass

    # Builtin agents
    builtins = _get_builtin_agents()

    return {
        "registered": registered,
        "templates": templates,
        "builtins": builtins,
        "total": len(registered) + len(templates) + len(builtins),
    }


@app.get("/api/agents/builtin")
async def get_builtin_agents():
    """List the built-in sub-agent types with their configs."""
    return _get_builtin_agents()


def _get_builtin_agents() -> list[dict[str, Any]]:
    """Return builtin agent definitions (subagent builtins + enterprise template library)."""
    result = []

    # 1. Core sub-agent builtins
    try:
        from cvc.agent.subagent import BUILTIN_AGENTS
        for name, cfg in BUILTIN_AGENTS.items():
            result.append({
                "id": name.lower(),
                "name": cfg.name if hasattr(cfg, "name") else name,
                "description": cfg.description if hasattr(cfg, "description") else "",
                "system_prompt": cfg.system_prompt if hasattr(cfg, "system_prompt") else "",
                "tools_allow": list(cfg.tools) if hasattr(cfg, "tools") else [],
                "tools_deny": [],
                "tool_tier": _infer_tool_tier(cfg.tools) if hasattr(cfg, "tools") else "coding",
                "max_turns": cfg.max_turns if hasattr(cfg, "max_turns") else 10,
                "rank": "specialist",
                "squad": "",
                "capabilities": [],
                "skills": [],
                "auto_respond": False,
                "auto_share_to_hive": True,
                "model_override": "",
                "provider_override": "",
                "is_builtin": True,
                "source": "builtin",
            })
    except ImportError:
        pass

    # 2. Enterprise template library
    try:
        from cvc.sdk.agent_templates import get_enterprise_templates
        seen_ids = {r["id"] for r in result}
        for tpl in get_enterprise_templates():
            if tpl["id"] not in seen_ids:
                result.append(tpl)
                seen_ids.add(tpl["id"])
    except ImportError:
        pass

    return result


def _infer_tool_tier(tools: frozenset[str] | set[str]) -> str:
    """Infer tool tier from tool set."""
    tool_names = {str(t) for t in tools}
    if any("agent" in t or "spawn" in t or "delegat" in t for t in tool_names):
        return "orchestration"
    if any("web" in t or "fetch" in t for t in tool_names):
        return "research"
    if any("write" in t or "edit" in t or "bash" in t or "patch" in t for t in tool_names):
        return "coding"
    return "read_only"


@app.post("/api/agents")
async def create_agent(request: Request):
    """Create a new agent from explicit config."""
    _ensure()
    body = await request.json()
    workspace = Path(_project_root) if _project_root else Path.cwd()
    tpl_dir = workspace / ".cvc" / "agent_templates"
    tpl_dir.mkdir(parents=True, exist_ok=True)

    from cvc.core.models import AgentTemplate
    template = AgentTemplate(**body)
    template.updated_at = time.time()

    # Save template
    tpl_path = tpl_dir / f"{template.id}.json"
    tpl_path.write_text(
        json.dumps(template.model_dump(), indent=2, default=str),
        encoding="utf-8",
    )

    # Also register in the hive mind registry
    try:
        _get_db().index.insert_agent(
            agent_id=template.id,
            name=template.name,
            role=template.description[:50] if template.description else "custom",
            rank=template.rank,
            squad=template.squad or None,
        )
    except Exception:
        pass

    return {"id": template.id, "status": "created", "template": template.model_dump()}


@app.post("/api/agents/from-prompt")
async def create_agent_from_prompt(request: Request):
    """
    Create an agent from a natural language description.

    Uses the current LLM to analyze the description and generate
    an AgentTemplate with appropriate tools, model, and config.
    """
    _ensure()
    body = await request.json()
    description = body.get("prompt", "") or body.get("description", "")
    if not description:
        raise HTTPException(400, "A prompt or description is required")

    # Build generation prompt
    gen_prompt = f"""You are an agent configuration generator. Based on the user's description,
generate a JSON configuration for a new AI agent.

User's description: "{description}"

Available tool tiers:
- "read_only": read_file, grep, glob, list_dir, cvc_search, cvc_status, cvc_log
- "coding": All read_only + write_file, edit_file, patch_file, bash
- "research": All read_only + web_search, web_fetch
- "orchestration": All coding + agent spawning, delegation

Available ranks: "specialist", "captain", "mission_controller", "zeus"

Respond with ONLY valid JSON (no markdown, no explanation):
{{
  "name": "descriptive agent name",
  "description": "what this agent does",
  "system_prompt": "detailed instructions for the agent",
  "tool_tier": "one of: read_only, coding, research, orchestration",
  "tools_allow": ["specific tools to allow"],
  "tools_deny": ["specific tools to deny"],
  "max_turns": 20,
  "rank": "specialist",
  "squad": "",
  "capabilities": ["list", "of", "capabilities"],
  "skills": ["list", "of", "skills"],
  "auto_respond": false,
  "auto_share_to_hive": true
}}"""

    # Use the current LLM to generate the config
    if _agent_llm:
        try:
            response = await _agent_llm.chat(
                messages=[
                    {"role": "system", "content": "You are a precise JSON generator. Output ONLY valid JSON."},
                    {"role": "user", "content": gen_prompt},
                ],
                tools=[],
                temperature=0.7,
                max_tokens=8192,
            )
            # Parse the LLMResponse
            content = response.text if hasattr(response, 'text') else str(response)
            # Extract JSON from response
            import re
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                config = json.loads(json_match.group())
                from cvc.core.models import AgentTemplate
                template = AgentTemplate(**config)
                return {
                    "status": "generated",
                    "template": template.model_dump(),
                    "raw_description": description,
                }
        except Exception as exc:
            raise HTTPException(500, f"LLM generation failed: {exc}")

    # Fallback: generate a reasonable template from keyword analysis when no LLM is available
    from cvc.core.models import AgentTemplate
    template = _generate_template_from_keywords(description)
    return {
        "status": "generated",
        "template": template.model_dump(),
        "raw_description": description,
        "note": "Generated via keyword analysis (no LLM active). Configure an LLM provider for richer results.",
    }


def _generate_template_from_keywords(description: str):
    """Generate an AgentTemplate from keyword analysis when no LLM is available."""
    import re as _re

    from cvc.core.models import AgentTemplate
    desc_lower = description.lower()

    # Detect tool tier
    if any(w in desc_lower for w in ("orchestrat", "delegat", "multi-agent", "spawn", "coordinate")):
        tool_tier = "orchestration"
        rank = "mission_controller"
    elif any(w in desc_lower for w in ("research", "search", "web", "browse", "fetch", "scrape", "internet")):
        tool_tier = "research"
        rank = "specialist"
    elif any(w in desc_lower for w in ("write", "edit", "code", "build", "creat", "implement", "fix", "refactor",
                                        "develop", "deploy", "test", "debug", "generat")):
        tool_tier = "coding"
        rank = "specialist"
    else:
        tool_tier = "read_only"
        rank = "specialist"

    # Detect capabilities
    capabilities = []
    cap_keywords = {
        "code_generation": ["code", "implement", "build", "develop", "generat"],
        "analysis": ["analy", "review", "audit", "inspect", "assess"],
        "testing": ["test", "qa", "quality", "verify", "validat"],
        "documentation": ["document", "doc", "readme", "guide", "wiki"],
        "security": ["secur", "vulnerab", "owasp", "audit", "penetrat"],
        "data_processing": ["data", "csv", "json", "etl", "pipeline", "transform"],
        "devops": ["deploy", "ci/cd", "docker", "kubernetes", "infra"],
        "communication": ["report", "email", "notify", "alert", "messag"],
        "memory_management": ["memory", "context", "remember", "recall", "knowledge"],
        "optimization": ["optim", "perform", "speed", "effici", "improv"],
    }
    for cap, keywords in cap_keywords.items():
        if any(k in desc_lower for k in keywords):
            capabilities.append(cap)
    if not capabilities:
        capabilities = ["general_purpose"]

    # Extract a name from the description
    words = _re.sub(r"[^a-zA-Z\s]", "", description).split()
    name_words = [w.capitalize() for w in words[:4] if len(w) > 2]
    name = " ".join(name_words[:3]) + " Agent" if name_words else "Custom Agent"

    # Build system prompt from description
    system_prompt = (
        f"You are a specialized AI agent. Your purpose: {description}\n\n"
        f"Core responsibilities:\n"
    )
    for i, cap in enumerate(capabilities, 1):
        system_prompt += f"  {i}. {cap.replace('_', ' ').title()}\n"
    system_prompt += (
        f"\nOperate with the '{tool_tier}' tool tier. "
        f"Be thorough, accurate, and proactive. Share results to the hive mind."
    )

    agent_id = f"agent-{_re.sub(r'[^a-z0-9]', '-', name.lower()).strip('-')[:30]}"

    return AgentTemplate(
        id=agent_id,
        name=name,
        description=description[:200],
        system_prompt=system_prompt,
        tool_tier=tool_tier,
        max_turns=20,
        rank=rank,
        capabilities=capabilities,
        auto_share_to_hive=True,
    )


@app.post("/api/agents/squad")
async def create_squad(request: Request):
    """Create a new squad (auto-creates the squad branch)."""
    _ensure()
    body = await request.json()
    squad_name = body.get("name", "")
    if not squad_name:
        raise HTTPException(400, "Squad name is required")

    try:
        from cvc.core.models import CVCBranchRequest
        branch_name = f"squad/{squad_name}"
        bp = _get_db().index.get_branch(branch_name)
        if bp is None:
            _get_engine().branch(CVCBranchRequest(
                name=branch_name,
                description=f"Squad: {squad_name}",
            ))
        return {"squad": squad_name, "branch": branch_name, "status": "created"}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/agents/squads")
async def list_squads():
    """List all squads with their member agents."""
    _ensure()
    try:
        branches = _get_db().index.list_branches()
        squads = []
        for bp in branches:
            if bp.name.startswith("squad/"):
                squad_name = bp.name.removeprefix("squad/")
                agents = _get_db().index.list_agents(squad=squad_name) if hasattr(_get_db().index, "list_agents") else []
                squads.append({
                    "name": squad_name,
                    "branch": bp.name,
                    "agents": [a if isinstance(a, dict) else {} for a in agents],
                    "agent_count": len(agents),
                })
        return {"squads": squads}
    except Exception:
        return {"squads": []}


@app.get("/api/agents/{agent_id}")
async def get_agent_detail(agent_id: str):
    """Get detailed info about an agent."""
    _ensure()
    workspace = Path(_project_root) if _project_root else Path.cwd()

    # Check template file
    tpl_path = workspace / ".cvc" / "agent_templates" / f"{agent_id}.json"
    if tpl_path.exists():
        try:
            data = json.loads(tpl_path.read_text(encoding="utf-8"))
            data["source"] = "template"
            return data
        except (json.JSONDecodeError, OSError):
            pass

    # Check registry
    try:
        profile = _get_db().index.get_agent(agent_id)
        if profile:
            profile["source"] = "registered"
            return profile
    except Exception:
        pass

    # Check builtin agents
    for b in _get_builtin_agents():
        if b.get("id") == agent_id:
            return b

    raise HTTPException(404, f"Agent '{agent_id}' not found")


@app.put("/api/agents/{agent_id}")
async def update_agent(agent_id: str, request: Request):
    """Update an agent's configuration."""
    _ensure()
    body = await request.json()
    workspace = Path(_project_root) if _project_root else Path.cwd()

    # Update template file if it exists
    tpl_path = workspace / ".cvc" / "agent_templates" / f"{agent_id}.json"
    if tpl_path.exists():
        try:
            data = json.loads(tpl_path.read_text(encoding="utf-8"))
            data.update(body)
            data["updated_at"] = time.time()
            tpl_path.write_text(
                json.dumps(data, indent=2, default=str),
                encoding="utf-8",
            )
            return {"id": agent_id, "status": "updated"}
        except (json.JSONDecodeError, OSError) as exc:
            raise HTTPException(500, str(exc))

    # Update registry
    try:
        _get_db().index.update_agent(agent_id, **body)
        return {"id": agent_id, "status": "updated"}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/agents/{agent_id}")
async def delete_agent(agent_id: str):
    """Delete an agent (template + registry)."""
    _ensure()
    workspace = Path(_project_root) if _project_root else Path.cwd()

    # Remove template
    tpl_path = workspace / ".cvc" / "agent_templates" / f"{agent_id}.json"
    if tpl_path.exists():
        tpl_path.unlink()

    # Remove from registry
    try:
        if hasattr(_get_db().index, "delete_agent"):
            _get_db().index.delete_agent(agent_id)
    except Exception:
        pass

    return {"id": agent_id, "status": "deleted"}


@app.get("/api/agents/{agent_id}/history")
async def get_agent_history(agent_id: str, limit: int = 50):
    """Get an agent's commit history."""
    _ensure()
    try:
        commits = _get_db().index.list_commits_by_agent(agent_id, limit=limit)
        return {
            "agent_id": agent_id,
            "commits": [
                {
                    "hash": c.commit_hash[:12] if hasattr(c, "commit_hash") else "",
                    "message": c.message if hasattr(c, "message") else "",
                    "type": str(c.commit_type) if hasattr(c, "commit_type") else "",
                    "timestamp": c.metadata.timestamp if hasattr(c, "metadata") else 0,
                }
                for c in commits
            ],
            "total": len(commits),
        }
    except Exception:
        return {"agent_id": agent_id, "commits": [], "total": 0}


# ═══════════════════════════════════════════════════════════════════════
# 7d. HIVE MEMORY — Shared cognitive space
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/hivemind/memory")
async def get_hive_memory(
    query: str = "",
    category: str | None = None,
    agent_id: str | None = None,
    limit: int = 20,
):
    """Read from the shared hive memory."""
    _ensure()
    try:
        from cvc.sdk.hivemind import HiveMemory, HiveMind
        workspace = Path(_project_root) if _project_root else Path.cwd()
        cvc_root = workspace / ".cvc"
        hive = HiveMind(str(cvc_root))
        memory = HiveMemory(hive)
        entries = await memory.read(query, category=category, agent_id=agent_id, limit=limit)
        return {"entries": entries, "total": len(entries)}
    except Exception as exc:
        logger.debug("Hive memory read error: %s", exc)
        return {"entries": [], "total": 0}


@app.post("/api/hivemind/memory")
async def write_hive_memory(request: Request):
    """Write an entry to the shared hive memory."""
    _ensure()
    body = await request.json()
    content = body.get("content", "")
    if not content:
        raise HTTPException(400, "content is required")

    try:
        from cvc.sdk.hivemind import HiveMemory, HiveMind
        workspace = Path(_project_root) if _project_root else Path.cwd()
        cvc_root = workspace / ".cvc"
        hive = HiveMind(str(cvc_root))
        memory = HiveMemory(hive)
        commit_hash = await memory.write(
            agent_id=body.get("agent_id", "human"),
            content=content,
            category=body.get("category", "general"),
            tags=body.get("tags", []),
        )
        return {"commit_hash": commit_hash, "status": "ok"}
    except Exception as exc:
        raise HTTPException(500, str(exc))


@app.get("/api/hivemind/memory/stats")
async def get_hive_memory_stats():
    """Get hive memory statistics."""
    _ensure()
    try:
        from cvc.sdk.hivemind import HiveMemory, HiveMind
        workspace = Path(_project_root) if _project_root else Path.cwd()
        cvc_root = workspace / ".cvc"
        hive = HiveMind(str(cvc_root))
        memory = HiveMemory(hive)
        return await memory.stats()
    except Exception:
        return {"total_entries": 0, "categories": {}, "contributing_agents": [], "agent_count": 0}


@app.get("/api/hivemind/memory/summary")
async def get_hive_memory_summary(limit: int = 10):
    """Get a text summary of the hive memory state."""
    _ensure()
    try:
        from cvc.sdk.hivemind import HiveMemory, HiveMind
        workspace = Path(_project_root) if _project_root else Path.cwd()
        cvc_root = workspace / ".cvc"
        hive = HiveMind(str(cvc_root))
        memory = HiveMemory(hive)
        summary = await memory.summary_context(limit=limit)
        return {"context": summary}
    except Exception:
        return {"context": "No hive memory available."}


@app.post("/api/hivemind/memory/compact")
async def compact_hive_memory(request: Request):
    """Trigger compaction of old hive memory entries."""
    _ensure()
    body = await request.json()
    try:
        from cvc.sdk.hivemind import HiveMind
        workspace = Path(_project_root) if _project_root else Path.cwd()
        cvc_root = workspace / ".cvc"
        hive = HiveMind(str(cvc_root))
        result = hive.compact(
            branch="hive/memory",
            max_age_hours=body.get("max_age_hours", 48),
        )
        return {
            "status": "ok",
            "compacted": result.commits_compacted if hasattr(result, "commits_compacted") else 0,
        }
    except Exception as exc:
        raise HTTPException(500, str(exc))


# ═══════════════════════════════════════════════════════════════════════
# 8. SESSIONS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/sessions")
async def get_sessions():
    import httpx
    try:
        r = httpx.get(f"http://{_HOST}:{_PROXY_PORT}/cvc/sessions", timeout=5.0)
        return r.json()
    except Exception:
        return {"sessions": [], "error": "Proxy not reachable"}


# ═══════════════════════════════════════════════════════════════════════
# 9. AGENT CHAT — Full Agentic Loop (same brain as CLI `cvc agent`)
#
# 9a. Workspace switch helper (used by the agentic loop)
# ═══════════════════════════════════════════════════════════════════════

async def _execute_workspace_switch(arguments: dict) -> str:
    """
    Execute a workspace switch from within the agentic chat loop.
    This is a gateway-level operation that re-scopes the tool executor,
    system prompt, and all CVC operations to the new workspace.
    """
    global _tool_executor, _system_prompt, _project_root

    target_path = arguments.get("path", "")
    if not target_path:
        return "Error: 'path' argument is required for cvc_switch_workspace."

    target = Path(target_path).resolve()
    if not target.exists():
        return f"Error: Directory does not exist: {target}"
    if not target.is_dir():
        return f"Error: Not a directory: {target}"

    try:
        inst = _workspace_mgr.switch_to(target)
        _project_root = inst.path

        # Re-scope tool executor to the new workspace
        from cvc.agent.executor import ToolExecutor
        _tool_executor = ToolExecutor(inst.path, inst.engine)

        # Rebuild system prompt with new workspace context
        from cvc.agent.system_prompt import build_system_prompt
        provider = _agent_llm.provider if _agent_llm else inst.config.provider
        model = _agent_llm.model if _agent_llm else inst.config.model
        _system_prompt = build_system_prompt(
            workspace=str(inst.path),
            provider=provider,
            model=model,
            branch=inst.engine.active_branch,
        )

        return (
            f"Successfully switched to workspace: {inst.path}\n"
            f"Branch: {inst.engine.active_branch}\n"
            f"CVC root: {inst.config.cvc_root}\n"
            f"All CVC operations now target this workspace."
        )
    except Exception as exc:
        return f"Error switching workspace: {exc}"


# ═══════════════════════════════════════════════════════════════════════
# 9b. AGENT CHAT — Full Agentic Loop
#
#    Architecture:  Server-side agentic loop.
#    1. Send messages + tools → LLM
#    2. Stream text tokens to the browser in real-time (SSE)
#    3. If LLM returns tool_calls → execute server-side → stream progress
#    4. Feed tool results back to LLM → goto 1
#    5. When LLM returns only text (no tool calls) → done
#
#    SSE event types:
#      {"type":"text",       "content":"…"}
#      {"type":"tool_start", "name":"…", "args":{…}}
#      {"type":"tool_result","name":"…", "output":"…"}
#      {"type":"status",     "message":"…"}
#      [DONE]
# ═══════════════════════════════════════════════════════════════════════

def _sse(payload) -> str:
    """Format a single SSE data line."""
    return f"data: {json.dumps(payload)}\n\n"


# ── Composer-bar helpers ────────────────────────────────────────────────

_VALID_REASONING_EFFORTS = ("none", "minimal", "low", "medium", "high", "xhigh")
_DEFAULT_REASONING_EFFORT = "medium"
_AUTO_COMPACT_PCT = 0.5  # auto-compress threshold as fraction of context


def _active_workspace_settings_path() -> Path:
    """Return path to the active workspace's settings.local.json."""
    base = Path(_project_root) if _project_root else Path.cwd()
    return base / ".cvc" / "settings.local.json"


def _read_workspace_settings() -> dict:
    p = _active_workspace_settings_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8") or "{}") or {}
    except Exception:
        return {}


def _write_workspace_settings(updates: dict) -> dict:
    p = _active_workspace_settings_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    data = _read_workspace_settings()
    data.update(updates)
    p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return data


def _get_active_model_context_window() -> int:
    """Best-effort lookup of the active model's context_window from the catalog."""
    if not _agent_llm:
        return 0
    provider = _agent_llm.provider
    model = _agent_llm.model
    # Inline minimal catalog (covers common cases without a network call)
    static = {
        "anthropic": {"claude-3-opus": 200000, "claude-3.5-sonnet": 200000,
                      "claude-3-5-haiku-20241022": 200000, "claude-opus-4.7": 200000},
        "openai": {"gpt-4o": 128000, "gpt-4": 128000, "o1-preview": 128000, "o1-mini": 128000},
        "google": {"gemini-3.1-pro-preview": 1000000, "gemini-3-flash-preview": 1000000},
        "ollama": {"qwen2.5-coder:7b": 32768, "qwen3-coder:latest": 32768,
                   "deepseek-r1:latest": 32768, "llama3:8b": 8192},
    }
    win = static.get(provider, {}).get(model)
    if win:
        return win
    # GitHub Copilot defaults to 128k for Claude/GPT models routed through it
    if provider in ("github", "copilot"):
        return 128000
    return 200000  # conservative default


def _estimate_used_tokens() -> int:
    """Rough token estimate from the active engine's context window."""
    try:
        eng = _get_engine()
        if not eng:
            return 0
        # ≈4 chars per token heuristic
        total_chars = 0
        for m in eng.context_window:
            content = getattr(m, "content", "") or ""
            if isinstance(content, str):
                total_chars += len(content)
            else:
                total_chars += len(json.dumps(content))
        return total_chars // 4
    except Exception:
        return 0


@app.get("/api/chat/reasoning_effort")
async def get_reasoning_effort() -> dict[str, str]:
    """Return the active workspace's persisted reasoning effort."""
    settings = _read_workspace_settings()
    effort = settings.get("reasoning_effort") or _DEFAULT_REASONING_EFFORT
    if effort not in _VALID_REASONING_EFFORTS:
        effort = _DEFAULT_REASONING_EFFORT
    return {"effort": effort}


@app.put("/api/chat/reasoning_effort")
async def set_reasoning_effort(request: Request) -> dict[str, str]:
    """Set the active workspace's reasoning effort.

    Body: ``{"effort": "<none|minimal|low|medium|high|xhigh>"}``
    """
    body = await request.json()
    effort = (body or {}).get("effort", "")
    if effort not in _VALID_REASONING_EFFORTS:
        raise HTTPException(422, f"Invalid effort. Must be one of {_VALID_REASONING_EFFORTS}")
    _write_workspace_settings({"reasoning_effort": effort})
    return {"effort": effort}


@app.get("/api/chat/context_meter")
async def get_context_meter() -> dict[str, Any]:
    """Live context-window meter for the active engine + active model."""
    used = _estimate_used_tokens()
    total = _get_active_model_context_window() or 0
    pct = (used / total) if total > 0 else 0.0
    threshold_tokens = int(total * _AUTO_COMPACT_PCT)
    provider = _agent_llm.provider if _agent_llm else (_get_config().provider if _get_config() else "")
    model = _agent_llm.model if _agent_llm else (_get_config().model if _get_config() else "")
    return {
        "used_tokens": used,
        "total_tokens": total,
        "used_pct": pct,
        "auto_compact_threshold_tokens": threshold_tokens,
        "auto_compact_threshold_pct": _AUTO_COMPACT_PCT,
        "model": model,
        "provider": provider,
    }


@app.get("/api/workspace/tree")
async def get_workspace_tree(
    path: str = "",
    depth: int = 2,
    show_hidden: bool = False,
) -> dict[str, Any]:
    """Return a recursive directory listing of the active workspace.

    `path` is *relative* to the active workspace root. `depth` caps recursion
    (1 = direct children only). `show_hidden=False` filters dot-files.
    """
    if not _project_root:
        raise HTTPException(503, "No active workspace")
    root = Path(_project_root).resolve()

    # Resolve & guard against escapes outside the workspace root
    target = (root / path).resolve() if path else root
    try:
        target.relative_to(root)
    except ValueError:
        raise HTTPException(400, f"Path escapes workspace root: {path}")
    if not target.exists():
        raise HTTPException(404, f"Path not found: {path}")

    depth = max(0, min(int(depth or 0), 6))

    def _node(p: Path, remaining: int) -> dict[str, Any]:
        try:
            st = p.stat()
        except Exception:
            st = None
        rel = ""
        try:
            rel = str(p.relative_to(root))
        except ValueError:
            rel = ""
        node: dict[str, Any] = {
            "name": p.name or str(p),
            "path": str(p),
            "rel_path": rel,
            "is_dir": p.is_dir(),
            "size": st.st_size if st else 0,
            "mtime": st.st_mtime if st else 0.0,
            "children": None,
        }
        if p.is_dir() and remaining > 0:
            kids: list[dict[str, Any]] = []
            try:
                entries = sorted(
                    p.iterdir(),
                    key=lambda x: (not x.is_dir(), x.name.lower()),
                )
            except PermissionError:
                entries = []
            for child in entries:
                if not show_hidden and child.name.startswith("."):
                    continue
                kids.append(_node(child, remaining - 1))
            node["children"] = kids
        return node

    return _node(target, depth)


@app.get("/api/workspace/file")
async def get_workspace_file(path: str) -> dict[str, Any]:
    """Return the contents of a single file inside the active workspace.

    `path` is relative to the active workspace root. Refuses paths that
    escape the root, binary files larger than 2 MB, and non-files.
    """
    if not _project_root:
        raise HTTPException(503, "No active workspace")
    if not path:
        raise HTTPException(400, "Missing path")
    root = Path(_project_root).resolve()
    target = (root / path).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise HTTPException(400, f"Path escapes workspace root: {path}")
    if not target.exists():
        raise HTTPException(404, f"Path not found: {path}")
    if not target.is_file():
        raise HTTPException(400, f"Not a file: {path}")

    try:
        st = target.stat()
    except Exception:
        raise HTTPException(500, "Failed to stat file")

    MAX_BYTES = 2 * 1024 * 1024  # 2 MB
    is_text = True
    content = ""
    truncated = False
    try:
        raw = target.read_bytes()
        if len(raw) > MAX_BYTES:
            raw = raw[:MAX_BYTES]
            truncated = True
        try:
            content = raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                content = raw.decode("latin-1")
            except Exception:
                is_text = False
                content = ""
    except Exception as exc:
        raise HTTPException(500, f"Read failed: {exc}")

    ext = target.suffix.lstrip(".").lower()
    import mimetypes
    mime, _ = mimetypes.guess_type(str(target))
    rel = str(target.relative_to(root))

    return {
        "name": target.name,
        "path": str(target),
        "rel_path": rel,
        "size": st.st_size,
        "mtime": st.st_mtime,
        "ext": ext,
        "mime": mime or ("text/plain" if is_text else "application/octet-stream"),
        "is_text": is_text,
        "truncated": truncated,
        "content": content,
    }


@app.post("/api/chat")
async def agent_chat(request: Request):
    global _chat_abort
    _chat_abort = False  # Reset abort flag for new chat turn
    body = await request.json()
    messages = body.get("messages", [])
    stream = body.get("stream", True)

    # ── Composer-bar additions: per-request reasoning + persona override ──
    req_effort = body.get("reasoning_effort") or ""
    if req_effort and req_effort not in _VALID_REASONING_EFFORTS:
        req_effort = ""
    if not req_effort:
        # Fall back to persisted workspace setting
        req_effort = _read_workspace_settings().get("reasoning_effort") or ""
    # AgentLLM's effort_level expects "low|medium|high" mostly; pass through
    # all values — adapters that don't recognise extras (e.g. "xhigh", "minimal",
    # "none") will simply ignore the unknown level.
    effort_for_llm = "" if req_effort in ("none", "") else req_effort

    # Persona override (optional). If supplied & valid, swap the system prompt
    # for this single chat turn.
    req_persona_id = body.get("persona_id") or ""
    turn_system_prompt = _system_prompt
    if req_persona_id:
        try:
            from cvc.dashboard.personas_api import _get_persona  # type: ignore
            persona = _get_persona(req_persona_id)
            if persona and persona.get("system_prompt"):
                turn_system_prompt = persona["system_prompt"]
        except Exception:
            logger.debug("Persona override failed for %s", req_persona_id, exc_info=True)

    if _agent_llm is None or not _agent_tools:
        return await _proxy_chat_fallback(messages, stream)

    # Build the LLM message list: system + conversation history from client
    llm_messages: list[dict[str, Any]] = [{"role": "system", "content": turn_system_prompt}]
    for m in messages:
        # Pass content as-is (could be string or list for multimodal)
        llm_messages.append({"role": m.get("role", "user"), "content": m.get("content", "")})

    if not stream:
        try:
            resp = await _agent_llm.chat(llm_messages, tools=_agent_tools, temperature=0.7, max_tokens=8192)
            return {
                "choices": [{"message": {"role": "assistant", "content": resp.text or ""}, "finish_reason": "stop"}],
                "model": _agent_llm.model,
            }
        except Exception as exc:
            raise HTTPException(502, f"LLM error: {exc}")

    # ── Streaming agentic loop ───────────────────────────────────────
    async def agentic_stream():
        global _session_trust_all
        nonlocal llm_messages
        iteration = 0
        _expensive = _is_expensive_model(_agent_llm.model) if _agent_llm else False
        _iter_limit = _MAX_AGENT_ITERATIONS_EXPENSIVE if _expensive else _MAX_AGENT_ITERATIONS
        _tool_trunc = _MAX_TOOL_OUTPUT_EXPENSIVE if _expensive else _MAX_TOOL_OUTPUT_LLM

        try:
            while iteration < _iter_limit:
                # ── Abort check ──────────────────────────────────
                if _chat_abort:
                    yield _sse({"type": "status", "message": "Stopped by user."})
                    break

                iteration += 1
                response_text = ""
                tool_calls = []
                current_tool_call = None
                tool_call_args_buffer: dict[int, str] = {}
                gemini_parts = None

                # Adaptive parameters: first call is conversational, subsequent are tool-oriented
                # Expensive models (Opus) get tighter token budgets to reduce verbosity
                if _expensive:
                    max_tok = 4096 if iteration == 1 else 8192
                else:
                    max_tok = 8192 if iteration == 1 else 16384
                temp = 0.7 if iteration == 1 else 0.5

                async for event in _agent_llm.chat_stream(
                    messages=llm_messages,
                    tools=_agent_tools,
                    temperature=temp,
                    max_tokens=max_tok,
                    effort_level=effort_for_llm,
                ):
                    if event.type == "text_delta" and event.text:
                        response_text += event.text
                        yield _sse({"type": "text", "content": event.text})

                    elif event.type == "tool_call_start" and event.tool_call:
                        tc = event.tool_call
                        tool_calls.append(tc)
                        tool_call_args_buffer[event.tool_call_index] = ""

                    elif event.type == "tool_call_delta":
                        idx = event.tool_call_index
                        if idx in tool_call_args_buffer:
                            tool_call_args_buffer[idx] += event.args_delta
                        # Try to parse accumulated args into the tool call
                        if tool_calls and idx < len(tool_calls):
                            try:
                                tool_calls[idx].arguments = json.loads(tool_call_args_buffer[idx])
                            except (json.JSONDecodeError, ValueError):
                                pass  # Still accumulating

                    elif event.type == "done":
                        # Capture raw Gemini parts — preserves thoughtSignature
                        # required by Gemini 3 for multi-turn function calling.
                        if event._provider_meta.get("gemini_parts"):
                            gemini_parts = event._provider_meta["gemini_parts"]

                # ── No tool calls → final text response, break loop ──
                if not tool_calls:
                    if response_text:
                        llm_messages.append({"role": "assistant", "content": response_text})
                    break

                # ── Tool calls detected → execute and loop ───────────
                # Build the assistant message with tool calls for the LLM history
                # GitHub uses OpenAI-compatible API, so it goes in the OpenAI branch.
                # The _fix_github_claude_messages() in llm.py converts to Anthropic format
                # when the model is Claude.
                assistant_msg: dict[str, Any] = {"role": "assistant", "content": response_text or ""}
                if _agent_llm.provider in ("openai", "ollama", "lmstudio", "github"):
                    assistant_msg["tool_calls"] = [
                        {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                        for tc in tool_calls
                    ]
                elif _agent_llm.provider == "anthropic":
                    # Anthropic uses content blocks
                    content_blocks = []
                    if response_text:
                        content_blocks.append({"type": "text", "text": response_text})
                    for tc in tool_calls:
                        content_blocks.append({"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.arguments})
                    assistant_msg = {"role": "assistant", "content": content_blocks}
                elif _agent_llm.provider == "google":
                    # Google uses function_call in content parts — the LLM module handles this
                    assistant_msg["tool_calls"] = [
                        {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                        for tc in tool_calls
                    ]
                    # Preserve raw Gemini parts (includes thoughtSignature)
                    # so _build_gemini_body sends them back verbatim.
                    if gemini_parts:
                        assistant_msg["_gemini_parts"] = gemini_parts
                llm_messages.append(assistant_msg)

                # Notify client about status
                yield _sse({"type": "status", "message": f"Executing {len(tool_calls)} tool{'s' if len(tool_calls) != 1 else ''}..."})

                # Execute each tool
                for tc in tool_calls:
                    # Stream tool_start to client
                    # Truncate args for display (don't send huge file contents)
                    display_args = {}
                    for k, v in tc.arguments.items():
                        sv = str(v)
                        display_args[k] = sv[:200] + "…" if len(sv) > 200 else sv

                    # ── Permission check ─────────────────────────────
                    # 1. Safe (read-only) tools → auto-approve
                    # 2. Autopilot mode → auto-approve all
                    # 3. Session trust-all → auto-approve all
                    # 4. Session trusted tool → auto-approve this tool
                    # 5. Otherwise → ask user with 5-option card
                    needs_confirm = (
                        not _autopilot
                        and not _session_trust_all
                        and tc.name not in _SAFE_TOOLS
                        and tc.name not in _session_trusted_tools
                    )

                    if needs_confirm:
                        _confirm_evt = asyncio.Event()
                        _set_tool_confirm(evt=_confirm_evt, result="")
                        yield _sse({
                            "type": "tool_confirm",
                            "name": tc.name,
                            "args": display_args,
                        })
                        # Wait for user to POST /api/chat/confirm
                        try:
                            await asyncio.wait_for(
                                _confirm_evt.wait(), timeout=120.0
                            )
                        except asyncio.TimeoutError:
                            _set_tool_confirm(evt=None, result="deny")
                        decision = _get_tool_confirm_result()
                        _set_tool_confirm(evt=None, result="")

                        # ── Handle enhanced permission decisions ──
                        if decision == "allow_always":
                            _session_trusted_tools.add(tc.name)
                        elif decision == "trust_all":
                            _session_trust_all = True
                        elif decision == "deny":
                            result = f"Tool '{tc.name}' was denied by the user."
                            yield _sse({"type": "tool_result", "name": tc.name, "output": result})
                            llm_messages.append({
                                "role": "tool",
                                "tool_call_id": tc.id,
                                "content": result,
                            })
                            continue
                        elif decision == "deny_suggest":
                            result = (
                                f"Tool '{tc.name}' was denied by the user. "
                                f"Please suggest an alternative approach that doesn't require this tool."
                            )
                            yield _sse({"type": "tool_result", "name": tc.name, "output": result})
                            llm_messages.append({
                                "role": "tool",
                                "tool_call_id": tc.id,
                                "content": result,
                            })
                            continue
                        # allow_once (or legacy "allow") → fall through to execution

                    yield _sse({"type": "tool_start", "name": tc.name, "args": display_args})

                    # Execute the tool server-side
                    try:
                        # Special handling for workspace switching (gateway-level operation)
                        if tc.name == "cvc_switch_workspace":
                            result = await _execute_workspace_switch(tc.arguments)
                        else:
                            loop = asyncio.get_event_loop()
                            result = await loop.run_in_executor(
                                None, _tool_executor.execute, tc.name, tc.arguments
                            )
                    except Exception as exc:
                        result = f"Error executing {tc.name}: {exc}"

                    # Truncate for LLM context
                    llm_result = result[:_tool_trunc] if len(result) > _tool_trunc else result
                    if len(result) > _tool_trunc:
                        llm_result += f"\n... (truncated, {len(result) - _tool_trunc:,} chars omitted)"

                    # Stream tool_result to client (truncated for display)
                    display_output = result[:3000] + f"\n... ({len(result):,} chars total)" if len(result) > 3000 else result
                    yield _sse({"type": "tool_result", "name": tc.name, "output": display_output})

                    # Add tool result to LLM message history
                    llm_messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": llm_result,
                    })

                    # ── Abort check after each tool ──────────────
                    if _chat_abort:
                        yield _sse({"type": "status", "message": "Stopped by user."})
                        break

                # Break outer loop too if aborted during tool execution
                if _chat_abort:
                    break

                # Loop continues — LLM will process tool results

            # If we hit max iterations, notify
            if iteration >= _iter_limit:
                yield _sse({"type": "status", "message": "Reached maximum iterations."})

        except Exception as exc:
            logger.error("Agentic chat error: %s", exc, exc_info=True)
            yield _sse({"type": "text", "content": f"\n\n**Error:** {exc}"})

        yield "data: [DONE]\n\n"

    return StreamingResponse(
        agentic_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── Tool Permission Endpoints ────────────────────────────────────────

@app.post("/api/chat/confirm")
async def confirm_tool(request: Request):
    """User confirms or denies a pending tool execution (5-option system)."""
    body = await request.json()
    raw = body.get("decision", "deny")
    # Map legacy "allow" → "allow_once" for backward compatibility
    if raw == "allow":
        raw = "allow_once"
    decision = raw if raw in _VALID_DECISIONS else "deny"
    _set_tool_confirm(evt=_tool_confirm_event, result=decision)
    if _tool_confirm_event is not None:
        _tool_confirm_event.set()
    return {"ok": True, "decision": decision}


@app.post("/api/chat/abort")
async def abort_chat():
    """Stop the running agentic chat loop."""
    global _chat_abort
    _chat_abort = True
    # Also unblock any pending permission wait so the loop can exit
    if _tool_confirm_event is not None:
        _set_tool_confirm(evt=_tool_confirm_event, result="deny")
        _tool_confirm_event.set()
    return {"ok": True}


@app.get("/api/chat/autopilot")
async def get_autopilot():
    """Get current auto-pilot state."""
    return {"autopilot": _autopilot}


@app.post("/api/chat/autopilot")
async def set_autopilot(request: Request):
    """Toggle auto-pilot mode. When on, tools execute without asking."""
    global _autopilot
    body = await request.json()
    _autopilot = bool(body.get("autopilot", False))
    logger.info("Auto-pilot %s", "ON" if _autopilot else "OFF")
    return {"autopilot": _autopilot}


async def _proxy_chat_fallback(messages: list, stream: bool):
    """Fallback to proxy-based chat if AgentLLM is not available."""
    import httpx
    proxy_url = f"http://{_HOST}:{_PROXY_PORT}/v1/chat/completions"
    model = _get_config().model if _get_config() else ""
    chat_body = {"model": model, "messages": messages, "stream": False}

    if not stream:
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(proxy_url, json=chat_body)
                return r.json()
        except Exception as exc:
            raise HTTPException(502, f"Proxy error: {exc}")

    async def gen():
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(proxy_url, json=chat_body)
                data = r.json()
                content = ""
                if "choices" in data and data["choices"]:
                    content = data["choices"][0].get("message", {}).get("content", "")
                if not content:
                    yield _sse({"type": "text", "content": "No response from model."})
                else:
                    words = content.split(" ")
                    for i in range(0, len(words), 4):
                        chunk = " ".join(words[i:i + 4])
                        if i > 0:
                            chunk = " " + chunk
                        yield _sse({"type": "text", "content": chunk})
            yield "data: [DONE]\n\n"
        except Exception as exc:
            yield _sse({"type": "text", "content": f"Error: {exc}"})
            yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


@app.get("/api/chat/models")
async def chat_models():
    if _agent_llm:
        return {"data": [{"id": _agent_llm.model, "object": "model", "owned_by": _agent_llm.provider}]}
    import httpx
    try:
        r = httpx.get(f"http://{_HOST}:{_PROXY_PORT}/v1/models", timeout=5.0)
        return r.json()
    except Exception:
        return {"data": [{"id": _get_config().model, "object": "model", "owned_by": _get_config().provider}] if _get_config() else []}



@app.websocket("/api/ws/chat")
async def ws_chat(websocket: WebSocket):
    await websocket.accept()
    global _session_trust_all, _system_prompt
    
    client_queue = asyncio.Queue()
    
    async def receive_loop():
        try:
            while True:
                data = await websocket.receive_json()
                await client_queue.put(data)
        except WebSocketDisconnect:
            await client_queue.put({"type": "disconnect"})
    
    receiver_task = asyncio.create_task(receive_loop())
    
    try:
        init_data = await client_queue.get()
        if init_data.get("type") == "disconnect":
            return
        
        messages = init_data.get("messages", [])
        
        if _agent_llm is None or not _agent_tools:
            await websocket.send_json({"type": "status", "message": "No active agent configuration."})
            return

        llm_messages: list[dict[str, Any]] = [{"role": "system", "content": _system_prompt}]
        for m in messages:
            llm_messages.append({"role": m.get("role", "user"), "content": m.get("content", "")})
            
        iteration = 0
        # Loop-detection state — port from cvc.agent.continuation._detect_stall.
        # Tracks the signature of each iteration's tool calls; if the same
        # signature repeats 3 times in a row, the agent is stuck and we abort.
        recent_tool_signatures: list[str] = []
        consecutive_no_progress = 0  # iterations with no text + repeated tools
        while iteration < _MAX_AGENT_ITERATIONS:
            if not client_queue.empty():
                evt = client_queue.get_nowait()
                if evt.get("type") in ("abort", "disconnect"):
                    await websocket.send_json({"type": "status", "message": "Stopped by user."})
                    break

            iteration += 1
            await websocket.send_json({
                "type": "iteration",
                "n": iteration,
                "max": _MAX_AGENT_ITERATIONS,
            })
            response_text = ""
            tool_calls = []
            tool_call_args_buffer: dict[int, str] = {}
            gemini_parts = None

            max_tok = 8192 if iteration == 1 else 16384
            temp = 0.7 if iteration == 1 else 0.5

            try:
                stream_iter = _agent_llm.chat_stream(
                    messages=llm_messages,
                    tools=_agent_tools,
                    temperature=temp,
                    max_tokens=max_tok,
                )
                async for event in stream_iter:
                    if not client_queue.empty():
                        evt = client_queue.get_nowait()
                        if evt.get("type") in ("abort", "disconnect"):
                            await websocket.send_json({"type": "status", "message": "Stopped by user."})
                            break
                    
                    if event.type == "text_delta" and event.text:
                        response_text += event.text
                        await websocket.send_json({"type": "text", "content": event.text})
                    elif event.type == "tool_call_start" and event.tool_call:
                        tc = event.tool_call
                        tool_calls.append(tc)
                        tool_call_args_buffer[event.tool_call_index] = ""
                    elif event.type == "tool_call_delta":
                        idx = event.tool_call_index
                        if idx in tool_call_args_buffer:
                            tool_call_args_buffer[idx] += event.args_delta
                        if tool_calls and idx < len(tool_calls):
                            try:
                                tool_calls[idx].arguments = json.loads(tool_call_args_buffer[idx])
                            except (json.JSONDecodeError, ValueError):
                                pass
                    elif event.type == "done":
                        if event._provider_meta.get("gemini_parts"):
                            gemini_parts = event._provider_meta["gemini_parts"]

            except Exception as e:
                await websocket.send_json({"type": "status", "message": f"LLM error: {e}"})
                break
                
            if not tool_calls:
                if response_text:
                    llm_messages.append({"role": "assistant", "content": response_text})
                await websocket.send_json({"type": "done"})
                break

            # ── Loop / stall detection ──────────────────────────────────────
            # If the model emits the exact same set of tool calls three
            # iterations in a row, or burns 5 iterations without ever
            # producing assistant text, it is stuck — break out instead of
            # silently grinding until _MAX_AGENT_ITERATIONS.
            sig = "|".join(sorted(f"{tc.name}:{json.dumps(tc.arguments, sort_keys=True)[:200]}" for tc in tool_calls))
            recent_tool_signatures.append(sig)
            if len(recent_tool_signatures) > 5:
                recent_tool_signatures = recent_tool_signatures[-5:]
            if (
                len(recent_tool_signatures) >= 3
                and recent_tool_signatures[-1] == recent_tool_signatures[-2] == recent_tool_signatures[-3]
            ):
                await websocket.send_json({
                    "type": "status",
                    "message": (
                        f"Loop detected — same {len(tool_calls)} tool call(s) repeated "
                        f"3 iterations in a row. Aborting to prevent runaway."
                    ),
                })
                await websocket.send_json({"type": "done"})
                break

            if not response_text:
                consecutive_no_progress += 1
            else:
                consecutive_no_progress = 0
            if consecutive_no_progress >= 5:
                await websocket.send_json({
                    "type": "status",
                    "message": (
                        "No progress for 5 iterations (no assistant text, only tool calls). "
                        "Aborting to prevent runaway."
                    ),
                })
                await websocket.send_json({"type": "done"})
                break

            assistant_msg: dict[str, Any] = {"role": "assistant", "content": response_text or ""}
            if _agent_llm.provider in ("openai", "ollama", "lmstudio", "github"):
                assistant_msg["tool_calls"] = [
                    {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                    for tc in tool_calls
                ]
            elif _agent_llm.provider == "anthropic":
                content_blocks = []
                if response_text:
                    content_blocks.append({"type": "text", "text": response_text})
                for tc in tool_calls:
                    content_blocks.append({"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.arguments})
                assistant_msg = {"role": "assistant", "content": content_blocks}
            elif _agent_llm.provider == "google":
                assistant_msg["tool_calls"] = [
                    {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                    for tc in tool_calls
                ]
                if gemini_parts:
                    assistant_msg["_gemini_parts"] = gemini_parts
            llm_messages.append(assistant_msg)

            await websocket.send_json({"type": "status", "message": f"Executing {len(tool_calls)} tool(s)..."})

            for tc in tool_calls:
                display_args = {}
                for k, v in tc.arguments.items():
                    sv = str(v)
                    display_args[k] = sv[:200] + "…" if len(sv) > 200 else sv

                needs_confirm = (
                    not _autopilot
                    and not _session_trust_all
                    and tc.name not in _SAFE_TOOLS
                    and tc.name not in _session_trusted_tools
                )

                if needs_confirm:
                    await websocket.send_json({
                        "type": "tool_confirm",
                        "name": tc.name,
                        "args": display_args,
                    })
                    decision = "deny"
                    try:
                        while True:
                            evt = await asyncio.wait_for(client_queue.get(), timeout=120.0)
                            if evt.get("type") == "confirm":
                                decision = evt.get("result", "deny")
                                break
                            elif evt.get("type") in ("abort", "disconnect"):
                                break
                    except asyncio.TimeoutError:
                        decision = "deny"
                        
                    if decision == "allow_always":
                        _session_trusted_tools.add(tc.name)
                    elif decision == "trust_all":
                        _session_trust_all = True
                    elif decision == "deny":
                        result = f"Tool '{tc.name}' was denied by the user."
                        await websocket.send_json({"type": "tool_result", "name": tc.name, "output": result})
                        llm_messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
                        continue
                    elif decision == "deny_suggest":
                        result = f"Tool '{tc.name}' was denied. Please suggest an alternative approach."
                        await websocket.send_json({"type": "tool_result", "name": tc.name, "output": result})
                        llm_messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
                        continue
                        
                await websocket.send_json({"type": "tool_start", "name": tc.name, "args": display_args})

                try:
                    if tc.name == "cvc_switch_workspace":
                        result = await _execute_workspace_switch(tc.arguments)
                    else:
                        loop = asyncio.get_running_loop()
                        result = await loop.run_in_executor(
                            None, _tool_executor.execute, tc.name, tc.arguments
                        )
                except Exception as exc:
                    result = f"Error executing {tc.name}: {exc}"

                llm_result = result[:_MAX_TOOL_OUTPUT_LLM] if len(result) > _MAX_TOOL_OUTPUT_LLM else result
                if len(result) > _MAX_TOOL_OUTPUT_LLM:
                    llm_result += f"\n... (truncated, {len(result) - _MAX_TOOL_OUTPUT_LLM:,} chars omitted)"

                display_output = result[:3000] + f"\n... ({len(result):,} chars total)" if len(result) > 3000 else result
                await websocket.send_json({"type": "tool_result", "name": tc.name, "output": display_output})

                llm_messages.append({"role": "tool", "tool_call_id": tc.id, "content": llm_result})

        else:
            # while loop exited because iteration == _MAX_AGENT_ITERATIONS
            # without a natural break (no `done`, no stall, no abort).
            await websocket.send_json({
                "type": "status",
                "message": (
                    f"Iteration cap reached ({_MAX_AGENT_ITERATIONS}). "
                    "Stopping — refine your request or raise CVC_MAX_ITER."
                ),
            })
            await websocket.send_json({"type": "done"})

    finally:
        receiver_task.cancel()


# ═══════════════════════════════════════════════════════════════════════
# 10. MCP SERVER INFO
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/mcp/tools")
async def mcp_tools():
    try:
        from cvc.mcp_server import TOOL_DEFINITIONS
        return {"tools": TOOL_DEFINITIONS, "total": len(TOOL_DEFINITIONS)}
    except ImportError:
        tools = [
            "cvc_status", "cvc_commit", "cvc_branch", "cvc_merge", "cvc_restore",
            "cvc_log", "cvc_capture_context", "cvc_set_workspace", "cvc_get_context",
            "cvc_recall", "cvc_export", "cvc_inject", "cvc_diff", "cvc_stats",
            "cvc_compact", "cvc_timeline", "cvc_audit",
            "cvc_sync_push", "cvc_sync_pull", "cvc_sync_status",
            "cvc_register_agent", "cvc_agent_commit", "cvc_agent_recall",
            "cvc_list_agents", "cvc_agent_context", "cvc_hive_status",
        ]
        return {"tools": [{"name": t} for t in tools], "total": len(tools)}
    except Exception:
        return {"tools": [], "total": 0}


@app.get("/api/mcp/status")
async def mcp_status():
    return {
        "transport": "stdio",
        "status": "available",
        "tools_count": 26,
        "note": "MCP server runs as a subprocess launched by IDEs, not as a persistent service",
    }


# ═══════════════════════════════════════════════════════════════════════
# 11. GIT / VCS BRIDGE
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/vcs/status")
async def vcs_status():
    _ensure()
    try:
        import subprocess as _sp
        git_dir = _project_root / ".git" if _project_root else None
        has_repo = bool(git_dir and git_dir.exists())
        hooks_installed = False
        current_branch = ""
        repo_root = str(_project_root) if _project_root else ""
        if has_repo:
            post_commit = git_dir / "hooks" / "post-commit"
            hooks_installed = post_commit.exists() and "cvc" in post_commit.read_text(encoding="utf-8", errors="ignore").lower() if post_commit.exists() else False
            try:
                result = _sp.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], capture_output=True, text=True, cwd=str(_project_root), timeout=5)
                if result.returncode == 0:
                    current_branch = result.stdout.strip()
            except Exception:
                pass
        return {
            "provider": "git" if has_repo else "",
            "has_repo": has_repo,
            "repo_root": repo_root,
            "current_branch": current_branch,
            "hooks_installed": hooks_installed,
        }
    except Exception as exc:
        return {"provider": "", "has_repo": False, "repo_root": "", "current_branch": "", "error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 12. AUDIT & STATS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/audit")
async def get_audit(limit: int = 100):
    _ensure()
    try:
        if hasattr(_get_db().index, "query_audit_log"):
            entries = _get_db().index.query_audit_log(limit=limit)
            return {"entries": entries, "total": len(entries)}
        return {"entries": [], "total": 0}
    except Exception as exc:
        return {"entries": [], "error": str(exc)}


@app.get("/api/stats")
async def get_stats():
    _ensure()
    try:
        commits = _get_db().index.list_all_commits(limit=9999) if hasattr(_get_db().index, "list_all_commits") else []
        branches = _get_db().index.list_branches() if hasattr(_get_db().index, "list_branches") else []
        agents = _get_db().index.list_agents() if hasattr(_get_db().index, "list_agents") else []
        by_type: dict[str, int] = {}
        total_tokens = 0
        for c in commits:
            ct = _field(c, "commit_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
            total_tokens += _meta_dict(c).get("token_count", 0)
        db_path = _get_config().cvc_root / "cvc.db"
        blobs_dir = _get_config().cvc_root / "objects"
        return {
            "total_commits": len(commits), "total_branches": len(branches), "total_agents": len(agents),
            "commits_by_type": by_type, "total_tokens": total_tokens,
            "estimated_cost_usd": round(total_tokens * 3.0 / 1_000_000, 4),
            "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "blob_count": len(list(blobs_dir.glob("*"))) if blobs_dir.exists() else 0,
        }
    except Exception as exc:
        return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 12.5  SWARM & HIVEMIND  (Phase A — server-side topology + live feed)
# ═══════════════════════════════════════════════════════════════════════

def _agent_to_node(a: Any) -> dict:
    """Normalise an agent record (dict or dataclass) to a topology node."""
    if isinstance(a, dict):
        get = a.get
    else:
        def get(k, default=None):  # type: ignore[no-redef]
            return getattr(a, k, default)
    aid = get("agent_id") or get("id") or ""
    return {
        "id": aid,
        "name": get("name") or aid,
        "role": get("role") or "",
        "rank": get("rank") or "",
        "squad": get("squad") or "",
        "status": get("status") or "active",
        "capabilities": get("capabilities") or [],
        "created_at": get("created_at"),
        "updated_at": get("updated_at"),
    }


@app.get("/api/swarm")
async def get_swarm_topology():
    """
    Server-side topology view of the active workspace.

    Returns nodes (agents), squads (groupings), and edges (squad → captain
    where ranks are present). Lets the UI skip client-side aggregation and
    keeps the topology consistent across consumers.
    """
    _ensure()
    try:
        raw = _get_db().index.list_agents() if hasattr(_get_db().index, "list_agents") else []
        nodes = [_agent_to_node(a) for a in raw if a is not None]
        # Classify nodes: tier (mc | captain | specialist | misc) for richer UI rendering.
        def _classify(n: dict) -> str:
            rank = (n.get("rank") or "").lower()
            role = (n.get("role") or "").lower()
            aid = (n.get("id") or "").upper()
            if rank in ("mc", "master_controller", "commander") or aid.startswith("MC-") or "mission controller" in role:
                return "mc"
            if rank == "captain" or aid.startswith("CAP-") or role.startswith("captain"):
                return "captain"
            if aid.startswith("SPC-") or role.startswith("specialist"):
                return "specialist"
            return "misc"

        for n in nodes:
            n["tier"] = _classify(n)

        # Find global Mission Controller (orbits Singularity directly, captains report up to it).
        mc_node = next((n for n in nodes if n["tier"] == "mc"), None)
        mc_id = mc_node["id"] if mc_node else None

        # Group by squad
        squads: dict[str, dict] = {}
        for n in nodes:
            sq = n["squad"] or "unaffiliated"
            s = squads.setdefault(sq, {"name": sq, "members": [], "captain": None, "count": 0})
            s["members"].append(n["id"])
            s["count"] += 1
            if n["tier"] == "captain" and not s["captain"]:
                s["captain"] = n["id"]

        # Edges: MC → captains, captains → specialists in their squad.
        edges: list[dict] = []
        for sq in squads.values():
            cap = sq["captain"]
            if cap and mc_id and cap != mc_id:
                edges.append({"from": mc_id, "to": cap, "type": "command"})
            if not cap:
                continue
            for m in sq["members"]:
                if m != cap:
                    edges.append({"from": cap, "to": m, "type": "squad"})
        return {
            "nodes": nodes,
            "squads": list(squads.values()),
            "edges": edges,
            "total_nodes": len(nodes),
            "total_squads": len(squads),
            "workspace": str(_get_config().cvc_root.parent) if _get_config() else "",
        }
    except Exception as exc:
        return {"nodes": [], "squads": [], "edges": [], "total_nodes": 0, "total_squads": 0, "error": str(exc)}


@app.get("/api/hivemind")
async def get_hivemind_overview():
    """High-level HiveMind overview: agent count, memory size, recent activity."""
    _ensure()
    try:
        db = _get_db()
        agents = db.index.list_agents() if hasattr(db.index, "list_agents") else []
        commits = db.index.list_all_commits(limit=200) if hasattr(db.index, "list_all_commits") else []
        branches = db.index.list_branches() if hasattr(db.index, "list_branches") else []
        recent_authors: dict[str, int] = {}
        for c in commits[:100]:
            author = _meta_dict(c).get("agent_id") or _field(c, "author", "")
            if author:
                recent_authors[author] = recent_authors.get(author, 0) + 1
        return {
            "agents": len(agents),
            "commits": len(commits),
            "branches": len(branches),
            "recent_active_agents": sorted(
                [{"agent_id": k, "commits": v} for k, v in recent_authors.items()],
                key=lambda x: -x["commits"],
            )[:10],
            "workspace": str(_get_config().cvc_root.parent) if _get_config() else "",
        }
    except Exception as exc:
        return {"agents": 0, "commits": 0, "branches": 0, "error": str(exc)}


@app.get("/api/hivemind/stats")
async def get_hivemind_stats():
    """Aggregate stats for the HiveMind page (counts + per-squad breakdown)."""
    _ensure()
    try:
        db = _get_db()
        agents_raw = db.index.list_agents() if hasattr(db.index, "list_agents") else []
        commits = db.index.list_all_commits(limit=500) if hasattr(db.index, "list_all_commits") else []
        nodes = [_agent_to_node(a) for a in agents_raw if a is not None]
        by_squad: dict[str, int] = {}
        by_rank: dict[str, int] = {}
        for n in nodes:
            by_squad[n["squad"] or "unaffiliated"] = by_squad.get(n["squad"] or "unaffiliated", 0) + 1
            by_rank[n["rank"] or "unranked"] = by_rank.get(n["rank"] or "unranked", 0) + 1
        # Commits in last hour / 24h
        now = time.time()
        last_hour = sum(1 for c in commits if (_field(c, "created_at", 0) or 0) >= now - 3600)
        last_day = sum(1 for c in commits if (_field(c, "created_at", 0) or 0) >= now - 86400)
        return {
            "total_agents": len(nodes),
            "total_commits": len(commits),
            "by_squad": by_squad,
            "by_rank": by_rank,
            "commits_last_hour": last_hour,
            "commits_last_24h": last_day,
        }
    except Exception as exc:
        return {"total_agents": 0, "total_commits": 0, "error": str(exc)}


@app.get("/api/hivemind/feed")
async def get_hivemind_feed(limit: int = 50, agent_id: str | None = None, squad: str | None = None):
    """
    Recent activity feed: commits + agent registrations + memory writes.

    Filterable by agent_id or squad. Ordered newest-first.
    """
    _ensure()
    try:
        db = _get_db()
        commits = db.index.list_all_commits(limit=max(limit * 3, 100)) if hasattr(db.index, "list_all_commits") else []
        agents_raw = db.index.list_agents() if hasattr(db.index, "list_agents") else []
        agent_squad: dict[str, str] = {}
        for a in agents_raw or []:
            n = _agent_to_node(a)
            if n["id"]:
                agent_squad[n["id"]] = n["squad"] or ""
        events: list[dict] = []
        for c in commits:
            meta = _meta_dict(c)
            author = meta.get("agent_id") or _field(c, "author", "") or ""
            sq = agent_squad.get(author, "")
            if agent_id and author != agent_id:
                continue
            if squad and sq != squad:
                continue
            events.append({
                "type": "commit",
                "commit_hash": _field(c, "commit_hash", ""),
                "agent_id": author,
                "squad": sq,
                "message": _field(c, "message", "") or meta.get("message", ""),
                "tags": meta.get("tags", []),
                "branch": _field(c, "branch", ""),
                "timestamp": _field(c, "created_at", 0),
            })
        events.sort(key=lambda e: e.get("timestamp") or 0, reverse=True)
        return {"events": events[:limit], "total": len(events)}
    except Exception as exc:
        return {"events": [], "total": 0, "error": str(exc)}


@app.websocket("/api/swarm/ws")
async def ws_swarm(websocket: WebSocket):
    """
    Live swarm/HiveMind events: agent registrations, commits, memory writes.

    On connect, sends a topology snapshot, then streams events from the bus.
    """
    await websocket.accept()
    bus = _get_event_bus()
    sub_id = f"swarm-{id(websocket)}"
    sub = bus.subscribe(sub_id, replay=True)
    try:
        # Initial snapshot
        try:
            snap = await get_swarm_topology()  # type: ignore[func-returns-value]
            await websocket.send_json({"event": "swarm.snapshot", "data": snap, "timestamp": time.time()})
        except Exception:
            logger.debug("Swarm snapshot send failed", exc_info=True)
        while sub.active:
            try:
                envelope = await asyncio.wait_for(sub.get(), timeout=15.0)
                await websocket.send_json({
                    "event": envelope.event,
                    "data": envelope.data,
                    "timestamp": envelope.timestamp,
                })
            except asyncio.TimeoutError:
                # Heartbeat with refreshed counts so the UI stays current even
                # without bus traffic.
                try:
                    await websocket.send_json({
                        "event": "swarm.heartbeat",
                        "data": {"timestamp": time.time()},
                        "timestamp": time.time(),
                    })
                except Exception:
                    break
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.debug("Swarm WebSocket error", exc_info=True)
    finally:
        bus.unsubscribe(sub_id)


# ═══════════════════════════════════════════════════════════════════════
# 13. CONNECTIONS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/connections")
async def get_connections():
    base = f"http://{_HOST}:{_PROXY_PORT}"
    return {
        "proxy_url": f"{base}/v1",
        "api_key": "cvc",
        "tools": [
            {"name": "VS Code", "type": "ide", "method": "BYOK settings.json", "icon": "vscode"},
            {"name": "Cursor", "type": "ide", "method": "BYOK settings.json", "icon": "cursor"},
            {"name": "Antigravity", "type": "ide", "method": "MCP config", "icon": "antigravity"},
            {"name": "Windsurf", "type": "ide", "method": "MCP config", "icon": "windsurf"},
            {"name": "Claude Code", "type": "cli", "method": "ANTHROPIC_BASE_URL env", "icon": "claude"},
            {"name": "Aider", "type": "cli", "method": "OPENAI_API_BASE env", "icon": "aider"},
            {"name": "Codex CLI", "type": "cli", "method": "OPENAI_BASE_URL env", "icon": "codex"},
            {"name": "Gemini CLI", "type": "cli", "method": "CVC MCP", "icon": "gemini"},
            {"name": "Continue.dev", "type": "extension", "method": "config.json", "icon": "continue"},
            {"name": "Cline", "type": "extension", "method": "MCP or API endpoint", "icon": "cline"},
            {"name": "Open WebUI", "type": "web", "method": "OpenAI API endpoint", "icon": "openwebui"},
        ],
    }


# ═══════════════════════════════════════════════════════════════════════
# WEBSOCKET — Real-Time Dashboard Events
# ═══════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════
# DASHBOARD SUB-ROUTERS — surface Phase-1 plumbing on the HTTP API
# ═══════════════════════════════════════════════════════════════════════
try:
    from cvc.dashboard.providers_api import register_providers_routes
    register_providers_routes(app)
except Exception as _exc:  # pragma: no cover — never break gateway boot
    logger.warning("Failed to register providers routes: %s", _exc)

try:
    from cvc.dashboard.loop_api import register_loop_routes
    register_loop_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register loop routes: %s", _exc)

try:
    from cvc.dashboard.trajectory_api import register_trajectory_routes
    register_trajectory_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register trajectory routes: %s", _exc)

try:
    from cvc.dashboard.team_api import register_team_routes
    register_team_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register team routes: %s", _exc)

try:
    from cvc.dashboard.personas_api import register_personas_routes
    register_personas_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register personas routes: %s", _exc)

try:
    from cvc.dashboard.themes_api import register_themes_routes
    register_themes_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register themes routes: %s", _exc)

try:
    from cvc.dashboard.skills_api import register_skills_routes
    register_skills_routes(app)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register skills routes: %s", _exc)

try:
    from cvc.dashboard.conversations_api import router as _conversations_router
    app.include_router(_conversations_router)
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to register conversations routes: %s", _exc)


@app.websocket("/ws/dashboard")
async def ws_dashboard(websocket: WebSocket):
    await websocket.accept()
    bus = _get_event_bus()
    sub_id = f"dashboard-{id(websocket)}"
    sub = bus.subscribe(sub_id, replay=True)
    try:
        if _manager:
            await websocket.send_json({
                "event": "services.snapshot",
                "data": {s.name: s.to_dict() for s in _manager.all_services().values()},
                "timestamp": time.time(),
            })
        while sub.active:
            try:
                envelope = await asyncio.wait_for(sub.get(), timeout=10.0)
                await websocket.send_json({"event": envelope.event, "data": envelope.data, "timestamp": envelope.timestamp})
            except asyncio.TimeoutError:
                if _manager:
                    _manager.refresh_health()
                    await websocket.send_json({
                        "event": "services.snapshot",
                        "data": {s.name: s.to_dict() for s in _manager.all_services().values()},
                        "timestamp": time.time(),
                    })
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.debug("Dashboard WebSocket error", exc_info=True)
    finally:
        bus.unsubscribe(sub_id)


# ═══════════════════════════════════════════════════════════════════════
# STATIC FILES — Dashboard SPA
# ═══════════════════════════════════════════════════════════════════════

# Phase A cleanup: legacy HTML mockup removed. Phase B will populate
# `cvc/web_dist/` via `cvc setup-ui` (Vite build of cvc/web/).
_DASHBOARD_DIR = Path(__file__).parent.parent / "cvc" / "web_dist"
if not _DASHBOARD_DIR.exists():
    _DASHBOARD_DIR = Path(__file__).parent / "web_dist"

if _DASHBOARD_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(_DASHBOARD_DIR)), name="dashboard-static")
    # Phase C: mount Vite-emitted asset folders at root paths so the built
    # index.html (which references /assets, /ds-assets, /fonts, /favicon.svg
    # absolutely) loads without rewrites.
    for _sub in ("assets", "ds-assets", "fonts"):
        _p = _DASHBOARD_DIR / _sub
        if _p.exists():
            app.mount(f"/{_sub}", StaticFiles(directory=str(_p)), name=f"dashboard-{_sub}")

    @app.get("/favicon.svg", include_in_schema=False)
    async def _favicon():
        fav = _DASHBOARD_DIR / "favicon.svg"
        if fav.exists():
            return FileResponse(str(fav), media_type="image/svg+xml")
        return JSONResponse({"error": "not_found"}, status_code=404)


@app.get("/", include_in_schema=False)
async def serve_dashboard():
    index_path = _DASHBOARD_DIR / "index.html"
    if index_path.exists():
        html = index_path.read_text(encoding="utf-8")
        # Inject the real CVC version — replaces {{CVC_VERSION}} placeholders
        # which cache-busts every CSS/JS link on each new release.
        html = html.replace("{{CVC_VERSION}}", _cvc_version)
        return HTMLResponse(
            content=html,
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
            },
        )
    return JSONResponse({"message": "CVC Gateway running.", "api": "/api/gateway/services"}, status_code=200)


# SPA fallback — for client-side routes like /agents, /swarm, /settings,
# serve index.html so React Router can take over. Must be the LAST GET
# route so it doesn't shadow API or static mounts.
_SPA_RESERVED_PREFIXES = (
    "/api", "/gateway", "/ws", "/static", "/assets", "/ds-assets",
    "/fonts", "/favicon", "/health", "/docs", "/openapi", "/redoc",
)

@app.middleware("http")
async def _spa_fallback_middleware(request, call_next):
    response = await call_next(request)
    if (
        response.status_code == 404
        and request.method == "GET"
        and not any(request.url.path.startswith(p) for p in _SPA_RESERVED_PREFIXES)
        and "text/html" in request.headers.get("accept", "")
        and _DASHBOARD_DIR.exists()
    ):
        index_path = _DASHBOARD_DIR / "index.html"
        if index_path.exists():
            html = index_path.read_text(encoding="utf-8").replace("{{CVC_VERSION}}", _cvc_version)
            return HTMLResponse(
                content=html,
                headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache"},
            )
    return response


# ═══════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _field(obj: Any, key: str, default: Any = "") -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _ts(obj: Any) -> float:
    """Extract Unix timestamp (seconds) from a commit object."""
    if isinstance(obj, dict):
        # Raw DB row or dict
        if "created_at" in obj and obj["created_at"]:
            return float(obj["created_at"])
        md = obj.get("metadata_json", "")
        if isinstance(md, str) and md:
            try:
                return float(json.loads(md).get("timestamp", 0))
            except (json.JSONDecodeError, TypeError, ValueError):
                return 0.0
        return 0.0
    # Pydantic CognitiveCommit
    meta = getattr(obj, "metadata", None)
    if meta is not None:
        return float(getattr(meta, "timestamp", 0))
    return 0.0


def _meta_dict(obj: Any) -> dict:
    # Pydantic CognitiveCommit — metadata is a CommitMetadata model
    meta = getattr(obj, "metadata", None)
    if meta is not None and hasattr(meta, "model_dump"):
        return meta.model_dump()
    # Raw DB row — metadata_json is a JSON string column
    raw = _field(obj, "metadata_json", "")
    if not raw:
        return {}
    try:
        return json.loads(raw) if isinstance(raw, str) else raw
    except (json.JSONDecodeError, TypeError):
        return {}


def _meta(obj: Any, key: str, default: Any = "") -> Any:
    return _meta_dict(obj).get(key, default)
