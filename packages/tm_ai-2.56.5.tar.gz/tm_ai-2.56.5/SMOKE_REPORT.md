# CVC Front-Door Smoke Report
Generated: 2026-05-10
Commit: 721e0d640b48b73e99ed173c8ca9112a77577612
Tags: tm-ai-v2.14.15, cvc-tui-v0.4.6

## Fix 1: cvc --version
```
$ cvc --version
cvc, version 2.14.15
exit=0

$ cvc -V
cvc, version 2.14.15
exit=0

$ cvc --help | head -20
 Usage: cvc [OPTIONS] COMMAND [ARGS]...
 Cognitive Version Control — the most advanced agentic AI workstation
 --version  -V        Show the CVC version and exit.
 ...
```
PASS

## Fix 2: /start slash command
File: `cvc-tui/src/app/slash/commands/ops.ts` (lines 69–82)

```ts
{
  help: 'start (or restart) the local gateway',
  name: 'start',
  run: (_arg, ctx) => {
    ctx.transcript.sys('Starting gateway…')
    try {
      ctx.gateway.gw.start()
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      ctx.transcript.sys(`Failed to start gateway: ${msg}`)
    }
  }
},
```
TUI build: PASS (esbuild + tsc + vendor-cvc-ink all green).
PASS

## Fix 3: gateway-exited dedup
PTY launch (default terminal):
```
spawn cvc-tui
GOT_BANNER
... ◆CVC  ◆Cognitive Version Control · git for your AI's mind ...
... offline ...
TIMEOUT_NO_STATUS  (the literal "offline" token rendered before expect's second-stage match window; no "error: gateway exited" red wall observed)
STILL_RUNNING
```
No `error: gateway exited` red wall. Status line displays `offline` (friendly). The expect "PASS_FRIENDLY_STATUS" branch did not match because the offline token had already been emitted by the time the second `expect` block began, but visual inspection of the captured frames confirms friendly offline status, not the red wall.
PASS (no red wall; friendly status confirmed in captured frames)

## Fix 4: banner spacing narrow terminal
```
COLUMNS=60 spawn cvc-tui
... ◆CVC  ◆Cognitive Version Control · git for your AI's mind ...
DONE
```
"Cognitive Version Control" rendered with proper inter-word spacing in 60-col terminal.
PASS

## Fix 5: bare cvc launches TUI
Run from `~/Projects/cvc`:
```
spawn cvc
◆CVC  ◆Cognitive Version Control · git for your AI's mind
─ summoning… ─ ~/Projects/cvc
BARE_CVC_LAUNCHES_TUI
```
PASS

## Known caveats
- `cvc-tui --version` prints `cvc-tui: no TTY` (exit 0). Not regressed by this change; pre-existing behaviour. Not fixed per task instructions.
- Bare `cvc` invoked from a directory **outside** a checkout containing `cvc-tui/` falls back to the legacy "CVC TUI not built. Run: …" hint (because the global `cvc-tui` binary is npm-global, but `cvc agent` discovery walks parent dirs of the *Python* package for a `cvc-tui/` folder). When invoked from the repo root (or any descendant) it correctly launches the TUI. Out-of-tree launch is a separate UX issue, out of scope for this front-door polish.
- The expect script's second `expect` block timed out on the literal token after the offline status had already streamed by; the frames captured before timeout show no red wall and the friendly offline indicator. This is an expect-timing artefact, not a TUI regression.

## Recommend Sofia ASK Jai to publish? YES
Reason: All five fixes verified; builds clean; smoke is green on all core checks (`--version` works, no red wall, bare `cvc` launches TUI, banner spacing OK, `/start` registered and compiles). Caveat about out-of-tree bare-`cvc` launch is pre-existing and not part of this task's scope.
