# Changelog

All notable changes to the **CVC — Cognitive Version Control** extension will be documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and the [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) format.

---

## [0.1.0] — 2025-05-07

### 🎉 Initial Release

The first public release of CVC for Visual Studio Code. Git for your AI brain.

---

### ✨ Added

#### Core Engine
- **Merkle-DAG commit store** — every AI context snapshot is stored as a cryptographically linked commit (SHA-256). Full provenance from the first message to today.
- **Three commit types**: `checkpoint` (auto-saved turns), `analysis` (structured findings), `generation` (code output events).
- **`cvc init`** — initialises the `.cvc/` directory in your workspace with SQLite store, branch pointers, and default config.
- **`cvc status`** — shows active branch, HEAD commit hash, context window size, and all branches.
- **`cvc log`** — paginated commit history for the active branch.
- **`cvc diff`** — semantic diff between any two commits: added/removed messages, reasoning trace delta, source file changes, token delta.
- **`cvc restore`** — time-travel to any prior commit hash. Full cognitive state re-hydrated.

#### Branching
- **`cvc branch <name>`** — create a cognitive branch to explore alternative reasoning paths without touching the main context.
- **`cvc merge <source> <target>`** — semantic three-way merge of two branches. Combines insights using vector similarity to resolve conflicts.
- Full branch list shown in VS Code sidebar with active branch indicator.

#### Semantic Recall
- **`cvc recall <query>`** — natural-language search across all past conversations. Tier 3 vector search (SQLite-vec) when available; full-text fallback always active.
- Deep content search: searches inside conversation messages, not just commit messages.
- Agent-scoped recall: agents only see commits in their accessible branches.

#### COGNOME — Smart Context Compression
- **COGNOME Layer 1** — compiles a minimal query-specific Engram from the DAG. Only noemata relevant to the current query are included, bounded by a hard token budget (default 1 200 tokens).
- Deterministic compilation: same DAG + same query + same budget = byte-identical Engram.
- **`cvc cognome enable/disable`** — toggle Engram injection into upstream LLM calls.
- **`cvc cognome status`** — shows total compiles, tokens saved, cached Engrams, active layer.
- **`cvc cognome audit`** — full audit trail of what was compiled, how much was saved, and which commits contributed.

#### Multi-Agent Hive Mind
- **Agent registration** — create agents with `agent_id`, `name`, `role`, `rank` (specialist → zeus), and `squad`.
- **Scoped branches** — each agent squad gets its own branch. Agents read commits within their rank permissions.
- **Hive Memory (The Plüberous)** — shared cognitive memory space. Agents write findings as `insight`, `decision`, `warning`, `learning`, `task_result` entries. Agents never communicate directly — they share one memory.
- **`cvc hive read/write/stats`** — read shared memories, write new entries, and get category breakdowns.
- **`cvc list agents`** — list all registered agents, filterable by squad or rank.
- **Inter-agent commits** — agents can target a `target_agent_id` in a commit for directed messaging.

#### Security Audit Trail
- **`cvc audit`** — compliance-ready audit log of all AI-generated code decisions.
- Risk levels: `low`, `medium`, `high`, `critical`.
- Event types: `commit`, `merge`, `restore`, `compact`, `code_injection`, `sync_push`, `sync_pull`.
- **Compliance score** (0–100) and risk assessment included in every audit response.
- Export as JSON or CSV for external compliance tools.

#### Team Sync
- **`cvc sync push <remote_path>`** — push cognitive commits and blobs to a shared `.cvc/` directory (network drive, cloud-mounted folder, etc.).
- **`cvc sync pull <remote_path>`** — pull and fast-forward local branch from a remote. Re-hydrates full context.
- Auto-initialises remote `.cvc/` if it doesn't exist.
- **`cvc sync status`** — shows all configured remotes, last push/pull hashes, and timestamps.

#### Cross-Project Context Transfer
- **`cvc inject <source_project> <query>`** — pull relevant conversations from a different CVC workspace into the current one. Great for reusing solutions across projects.

#### Context Compaction
- **`cvc compact`** — smart context window compression. Preserves important messages (decisions, code, architecture) while summarising routine conversation. Configurable `target_ratio` and `keep_recent` count.

#### Export & Share
- **`cvc export [commit_hash]`** — export any commit as a shareable Markdown document with full conversation, metadata, reasoning trace, and referenced files.

#### VS Code Panel
- **CVC Dashboard** — sidebar panel with:
  - Branch list with active branch highlight
  - Recent commits timeline with indigo-violet accent colours
  - One-click restore, diff, and export actions
  - Semantic search input with live results
- **Status bar item** — shows `⚡ CVC: <branch> ✓ • Last commit: <time>` at all times.
- **Command palette** integration — all CVC commands registered under `CVC:` prefix.
- **Keybindings** — six default shortcuts for the most common operations (all rebindable).
- **Settings** — 9 configurable settings under the `cvc.*` namespace.

#### Context Capture
- **`cvc capture context`** — manually capture conversation messages into CVC context. Useful when the IDE doesn't support automatic context capture (e.g., GitHub Copilot Chat).

#### Timeline View
- **`cvc timeline`** — visual commit timeline across all branches. Shows commit types, merge points, branch points, provider/model info, and timing.

#### Analytics
- **`cvc stats`** — aggregated analytics: total tokens, estimated costs, message counts by role, commit types, providers/models, most-discussed source files, branch activity, and timing patterns.

---

### 🧱 Technical Foundation
- Storage: SQLite (WAL mode) with optional sqlite-vec extension for vector search
- Commit addressing: SHA-256 Merkle DAG (same design as git object store)
- Python ≥ 3.11 required (`pip install tm-ai`)
- VS Code ≥ 1.85 required
- No cloud dependency — fully local by default
- MCP (Model Context Protocol) server included for IDE integration

---

[0.1.0]: https://github.com/mannuking/cvc/releases/tag/v0.1.0
