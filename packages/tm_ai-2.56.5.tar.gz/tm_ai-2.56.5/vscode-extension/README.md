<div align="center">

![CVC Icon](media/icon.svg)

# CVC — Cognitive Version Control

**Git for your AI brain.**

[![Version](https://img.shields.io/visual-studio-marketplace/v/mannuking.cvc?style=flat-square&color=6366f1&label=version)](https://marketplace.visualstudio.com/items?itemName=mannuking.cvc)
[![Installs](https://img.shields.io/visual-studio-marketplace/i/mannuking.cvc?style=flat-square&color=8b5cf6&label=installs)](https://marketplace.visualstudio.com/items?itemName=mannuking.cvc)
[![License](https://img.shields.io/badge/license-MIT-a5b4fc?style=flat-square)](LICENSE)
[![GitHub](https://img.shields.io/badge/GitHub-mannuking%2Fcvc-7c3aed?style=flat-square&logo=github)](https://github.com/mannuking/cvc)

> **CVC monitors, saves, and restores everything your AI knows about your project — so you never lose context again.**

</div>

---

## What is CVC?

Every time you start a new AI chat, your assistant forgets everything. CVC fixes that.

CVC is a **cognitive version control system** — a Merkle-DAG checkpoint engine that captures your AI's full context (conversation, reasoning, code references, decisions) into cryptographic commits. Branch. Diff. Restore. Merge. Just like `git`, but for your AI's brain state.

![CVC Dashboard](media/screenshot-dashboard.png)

---

## ✨ Features

- 🧠 **Auto-checkpoint** — CVC watches your AI conversations and commits snapshots on every significant turn
- 🌿 **Cognitive branches** — Explore multiple solution paths simultaneously without losing your primary context
- 🔍 **Semantic recall** — Natural-language search across every past conversation and decision your AI has made
- ⏱️ **Time-travel restore** — Rewind your AI's brain to any checkpoint with a single click
- 🔀 **Smart merge** — Combine insights from two branches using semantic three-way merge
- 👥 **Hive mind / multi-agent** — Register sub-agents (Tina, Samantha, Robin…) with scoped memory lanes
- 🔒 **Audit trail** — Compliance-ready security log of every AI-generated code decision, with risk scoring
- ⚡ **COGNOME compression** — Compile a minimal context preamble from the DAG — fraction of the tokens, full provenance
- 📤 **Team sync** — Push/pull cognitive commits to a shared remote so your whole team shares AI context
- 📋 **Export** — One-click export any commit as a shareable Markdown document for code review

![CVC Branch View](media/screenshot-branches.png)

---

## 🚀 Quick Start

**Step 1 — Install & initialise**

```bash
# Install the tm-ai package (Python ≥ 3.11)
pip install tm-ai
cvc init
```

**Step 2 — Open the CVC panel**

Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS) → `CVC: Open Dashboard`

**Step 3 — Start working**

Your AI conversations are now versioned. Every significant turn is auto-committed. Use the panel to browse history, branch, restore, or run semantic search.

![CVC Quick Start](media/screenshot-quickstart.png)

---

## ⌨️ Keybindings

| Command | macOS | Windows / Linux |
|---|---|---|
| Open CVC Dashboard | `⌘ Shift C` | `Ctrl+Shift+C` |
| Commit current context | `⌘ Shift S` | `Ctrl+Shift+S` |
| Recall (semantic search) | `⌘ Shift R` | `Ctrl+Shift+R` |
| Restore HEAD | `⌘ Shift Z` | `Ctrl+Shift+Z` |
| New branch | `⌘ Shift B` | `Ctrl+Shift+B` |
| Open Hive Mind | `⌘ Shift H` | `Ctrl+Shift+H` |

All bindings are rebindable via `File → Preferences → Keyboard Shortcuts`.

---

## ⚙️ Settings

| Setting | Type | Default | Description |
|---|---|---|---|
| `cvc.autoCommit` | boolean | `true` | Auto-commit context on each AI turn |
| `cvc.autoCommitDebounceMs` | number | `3000` | Debounce delay before auto-commit fires (ms) |
| `cvc.defaultBranch` | string | `"main"` | Default branch name for new workspaces |
| `cvc.cognomeEnabled` | boolean | `true` | Inject COGNOME Engrams into upstream LLM calls |
| `cvc.cognomeBudgetTokens` | number | `1200` | Token budget for compiled Engram preambles |
| `cvc.hiveEnabled` | boolean | `false` | Enable shared Hive Memory across agents |
| `cvc.syncRemotePath` | string | `""` | Absolute path to a shared remote `.cvc/` directory |
| `cvc.auditRetentionDays` | number | `90` | Days to retain audit trail records |
| `cvc.statusBarEnabled` | boolean | `true` | Show CVC branch & commit status in the status bar |

---

## 🗂️ How It Works

```
Your AI Chat
     │
     ▼
┌─────────────────────────────────┐
│   CVC Capture Layer             │  ← watches conversation turns
└────────────────┬────────────────┘
                 │
                 ▼
        Merkle-DAG Commit
        (SHA-256 hashed)
                 │
       ┌─────────┴──────────┐
       ▼                    ▼
  Branch: main       Branch: feature/auth
       │                    │
  5 commits            3 commits
       │
       ▼
  COGNOME Layer
  (semantic compression)
       │
       ▼
  Next LLM Call ← minimal Engram preamble injected
```

Each commit contains: full conversation snapshot, reasoning trace, referenced source files, token counts, provider/model metadata, and a cryptographic parent pointer.

---

## ❓ FAQ

**Q: Does CVC send my code or conversations to any server?**

No. CVC runs entirely locally. The `.cvc/` directory is stored in your workspace — nothing leaves your machine unless you explicitly configure `cvc.syncRemotePath` to a shared folder you control.

**Q: Does this slow down Copilot / Claude / other AI extensions?**

Negligibly. CVC commits are written asynchronously to a local SQLite store. The COGNOME Engram injection adds ~50–150 tokens to upstream calls (configurable), which is far less than re-pasting your full context manually.

**Q: Can I use CVC without the VS Code extension?**

Yes — CVC is a standalone Python CLI (`pip install tm-ai`). The VS Code extension is a visual frontend for the same underlying engine. All commits made in the extension are accessible from the CLI and vice versa.

---

## 🗺️ Roadmap

- [ ] GitHub Copilot deep integration (auto-capture Copilot Chat turns)
- [ ] JetBrains plugin
- [ ] Cloud sync via CVC Hub
- [ ] Visual diff viewer for cognitive branches
- [ ] Slack / Teams notification hooks for audit events

---

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you'd like to change.

```bash
git clone https://github.com/mannuking/cvc
cd cvc/vscode-extension
npm install
code .
# Press F5 to open a new Extension Development Host
```

---

## 📄 License

MIT © [Jai Kumar Meena](https://github.com/mannuking)

---

<div align="center">

**[GitHub](https://github.com/mannuking/cvc)** • **[Issues](https://github.com/mannuking/cvc/issues)** • **[Discussions](https://github.com/mannuking/cvc/discussions)** • **[Changelog](CHANGELOG.md)**

*Never lose context again.* 🧠

</div>
