from alloy_runtime_types.dtos.executions import GetExecutionResponse
from cli.commands.executions.get.transcript_renderer import (
    render_activity_blocks,
    render_appendices,
    render_execution_header,
)
from cli.infrastructure.output import OutputFormat, OutputService


def present_execution(
    response: GetExecutionResponse,
    *,
    include_metadata: bool = True,
    start_index: int = 0,
) -> int:
    output = OutputService.get()
    if output.format == OutputFormat.JSON:
        output.raw(response)
        return len(response.activity)

    blocks: list[str] = []
    if include_metadata:
        blocks.append(render_execution_header(response))

    activity_blocks = render_activity_blocks(
        response.activity,
        start_index=start_index,
    )
    if activity_blocks:
        if include_metadata:
            blocks.append(
                "────────────────────────────────────────────────────────────"
            )
        blocks.append(activity_blocks)
    elif include_metadata and response.activity_state == "unavailable":
        blocks.append("────────────────────────────────────────────────────────────")
        blocks.append("No live activity is available yet.")

    if include_metadata:
        appendices = render_appendices(response)
        if appendices:
            if blocks:
                blocks.append(
                    "────────────────────────────────────────────────────────────"
                )
            blocks.append(appendices)

    rendered = "\n\n".join(blocks).rstrip()
    if rendered:
        output.text(rendered)

    return len(response.activity)
