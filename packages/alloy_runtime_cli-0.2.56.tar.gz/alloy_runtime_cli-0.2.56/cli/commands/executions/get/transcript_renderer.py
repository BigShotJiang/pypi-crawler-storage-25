import json
from datetime import datetime
from typing import Any

from alloy_runtime_types.dtos.executions import (
    ExecutionActivityItem,
    GetExecutionResponse,
)


def render_execution_header(response: GetExecutionResponse) -> str:
    rows: list[tuple[str, str | None]] = [
        ("Execution", _stringify(response.execution_id)),
        ("Status", _stringify(response.status)),
        ("Origin", _stringify(response.origin_label)),
        ("Purpose", _stringify(response.execution_purpose)),
        ("Provider", _stringify(response.provider_key)),
        ("Model", _stringify(response.provider_model_name)),
        ("Queued", _format_datetime(response.queued_at)),
        ("Started", _format_datetime(response.started_at)),
        ("Last Activity", _format_datetime(response.last_activity_at)),
        ("Completed", _format_datetime(response.completed_at)),
        ("Activity", _stringify(response.activity_state)),
    ]

    if response.error_message:
        rows.append(("Error", _stringify(response.error_message)))

    width = max(len(label) for label, _ in rows)
    return "\n".join(
        f"{label.ljust(width)}  {value}" for label, value in rows if value is not None
    )


def render_activity_blocks(
    activities: list[ExecutionActivityItem], *, start_index: int = 0
) -> str:
    rendered: list[str] = []
    for activity in activities[start_index:]:
        header = _render_activity_header(activity)
        body = _render_activity_body(activity)
        if body:
            rendered.append(f"{header}\n{body}")
        else:
            rendered.append(header)
    return "\n\n".join(rendered)


def render_appendices(response: GetExecutionResponse) -> str:
    appendices: list[str] = []
    if response.output_text:
        appendices.append(f"Final Output\n{response.output_text}")
    if response.error_message:
        appendices.append(f"Error\n{response.error_message}")
    return "\n\n".join(appendices)


def _render_activity_header(activity: ExecutionActivityItem) -> str:
    timestamp = _format_time(activity.timestamp)
    kind = activity.kind
    tool_name = _stringify(activity.tool_name)

    if kind == "reasoning":
        return f"Reasoning [{timestamp}]"
    if kind == "assistant_text":
        return f"Assistant [{timestamp}]"
    if kind == "tool_call":
        return f"Tool Call · {tool_name or 'tool'} [{timestamp}]"
    if kind == "tool_started":
        return f"Tool Started · {tool_name or 'tool'} [{timestamp}]"
    if kind == "tool_completed":
        return f"Tool Output · {tool_name or 'tool'} [{timestamp}]"
    if kind == "tool_failed":
        return f"Tool Error · {tool_name or 'tool'} [{timestamp}]"
    return f"Activity [{timestamp}]"


def _render_activity_body(activity: ExecutionActivityItem) -> str:
    content_text = activity.content_text
    content_structured = activity.content_structured

    if isinstance(content_text, str) and content_text:
        return content_text
    if isinstance(content_structured, dict):
        return _format_structured(content_structured)
    return ""


def _format_structured(payload: dict[str, Any]) -> str:
    if set(payload.keys()) == {"arguments"} and isinstance(
        payload.get("arguments"), str
    ):
        return _format_argument_string(payload["arguments"])

    if "arguments" in payload and isinstance(payload.get("arguments"), str):
        enriched = dict(payload)
        enriched["arguments"] = _maybe_parse_json_string(payload["arguments"])
        return json.dumps(enriched, indent=2, ensure_ascii=False)

    return json.dumps(payload, indent=2, ensure_ascii=False)


def _format_argument_string(value: str) -> str:
    parsed = _maybe_parse_json_string(value)
    if isinstance(parsed, dict):
        return json.dumps(parsed, indent=2, ensure_ascii=False)
    return value


def _maybe_parse_json_string(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _format_datetime(value: Any) -> str | None:
    if not isinstance(value, datetime):
        return None
    return value.strftime("%Y-%m-%d %H:%M:%S %Z")


def _format_time(value: Any) -> str:
    if not isinstance(value, datetime):
        return "--:--:--"
    return value.strftime("%H:%M:%S")


def _stringify(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)
