# Publishing Wolf2XFinder to PyPI

This guide provides step-by-step instructions for publishing the Wolf2XFinder package to the Python Package Index (PyPI).

---

## Prerequisites

1. **PyPI Account**: Create an account at https://pypi.org/account/register/
2. **API Token**: Generate an API token at https://pypi.org/manage/account/token/
   - Token name: `wolf2xfinder`
   - Scope: Entire account (or specific to wolf2xfinder)
3. **Build Tools**: Ensure you have the latest build tools
   ```bash
   pip install --upgrade build twine setuptools wheel
   ```

---

## Publishing Workflow

### Step 1: Update Version (if needed)

Edit `pyproject.toml` to increment the version:
```toml
[project]
version = "0.1.1"  # Increment as needed
```

### Step 2: Clean Previous Builds

```bash
# Remove old build artifacts
rm -rf build/ dist/ *.egg-info
# On Windows:
rmdir /s /q build dist
del /s /q *.egg-info
```

### Step 3: Build the Package

```bash
# Build both wheel and source distribution
python -m build

# Or use the custom build script
python build_package.py --wheel
```

This creates:
- `dist/wolf2xfinder-X.X.X-py3-none-any.whl` (Wheel)
- `dist/wolf2xfinder-X.X.X.tar.gz` (Source distribution)

### Step 4: Verify the Package

```bash
# Check package metadata and structure
twine check dist/*

# Test installation locally
pip install dist/wolf2xfinder-0.1.0-py3-none-any.whl
```

### Step 5: Publish to TestPyPI (Recommended)

First publish to TestPyPI to verify everything works:

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Install from TestPyPI to test
pip install --index-url https://test.pypi.org/simple/ wolf2xfinder
```

### Step 6: Publish to PyPI

Once verified, publish to the official PyPI:

```bash
# Upload to PyPI
twine upload dist/*
```

You'll be prompted for:
- **Username**: `__token__`
- **Password**: Your PyPI API token (starts with `pypi-`)

---

## Authentication Methods

### Method 1: Token Authentication (Recommended)

```bash
twine upload dist/* --username __token__ --password pypi-xxxxxx
```

### Method 2: Config File

Create or edit `~/.pypirc`:
```ini
[pypi]
  username = __token__
  password = pypi-xxxxxx

[testpypi]
  username = __token__
  password = pypi-xxxxxx
```

Then upload without prompts:
```bash
twine upload dist/*
```

---

## Quick Publish Commands

### Full Publish Workflow (Copy & Paste)

```bash
# 1. Clean
rm -rf build dist *.egg-info

# 2. Build
python -m build

# 3. Check
twine check dist/*

# 4. Upload to PyPI
twine upload dist/* --username __token__
```

### TestPyPI Workflow

```bash
# Clean, build, check
rm -rf build dist *.egg-info
python -m build
twine check dist/*

# Upload to TestPyPI
twine upload --repository testpypi dist/* --username __token__

# Test installation
pip install --index-url https://test.pypi.org/simple/ wolf2xfinder
```

---

## Post-Publishing Verification

### 1. Check PyPI Page
Visit: https://pypi.org/project/wolf2xfinder/

### 2. Test Installation
```bash
# Uninstall existing
pip uninstall wolf2xfinder -y

# Install from PyPI
pip install wolf2xfinder

# Test CLI
wolf2xfinder --help
wolf2xfinder scan https://example.com --max-pages 1
```

### 3. Verify Metadata
```bash
pip show wolf2xfinder
```

---

## Version Management

Follow Semantic Versioning (MAJOR.MINOR.PATCH):

- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

Example versions:
- `0.1.0` - Initial release
- `0.1.1` - Bug fix
- `0.2.0` - New feature
- `1.0.0` - Stable release

---

## Troubleshooting

### Error: "File already exists"
- Increment version in `pyproject.toml`
- Rebuild the package

### Error: "403 Forbidden"
- Check API token permissions
- Verify token scope

### Error: "Invalid or missing authentication credentials"
- Use `__token__` as username
- Ensure password starts with `pypi-`

### Package not showing on PyPI
- Wait 5-10 minutes for indexing
- Check your PyPI account's "Projects" tab

---

## Best Practices

1. **Always test on TestPyPI first**
2. **Use `twine check` before uploading**
3. **Keep CHANGELOG.md updated**
4. **Tag releases in Git**:
   ```bash
   git tag v0.1.0
   git push origin v0.1.0
   ```
5. **Verify README rendering on PyPI**
6. **Check all classifiers in pyproject.toml**

---

## Project Files for PyPI

Ensure these files exist and are properly configured:

- ✅ `pyproject.toml` - Package metadata
- ✅ `README.md` - Package documentation (used on PyPI)
- ✅ `LICENSE` - License file (MIT in pyproject.toml)
- ✅ `src/wolf2xfinder/` - Package source code
- ✅ `MANIFEST.in` - Additional files to include (if needed)

---

## Support

- **PyPI Documentation**: https://packaging.python.org/tutorials/packaging-projects/
- **Twine Documentation**: https://twine.readthedocs.io/
- **Cyber Wolf Team**: https://www.cyberwolf.pro

---

**Last Updated**: 2026-04-30
