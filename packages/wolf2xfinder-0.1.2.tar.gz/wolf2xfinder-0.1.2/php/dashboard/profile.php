<?php
// Start output buffering to prevent unwanted output
ob_start();

// Disable error display for clean JSON responses
error_reporting(0);
ini_set('display_errors', 0);

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../lib/db.php';

// Include PHPMailer for 2FA OTP emails
require_once __DIR__ . '/../../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include Firebase Helper for Firestore integration
require_once __DIR__ . '/../lib/firebase.php';

/**
 * Sync user profile and 2FA data to Firestore
 * @param int $userId User ID
 * @param array $profileData Profile data to sync
 * @param array $twoFaData 2FA data to sync
 * @return bool Success status
 */
function syncUserToFirestore($userId, $profileData, $twoFaData = null) {
    if (!FirebaseHelper::isEnabled()) {
        error_log("Firebase not enabled, skipping Firestore sync for user $userId");
        return false;
    }

    // Prepare user data for Firestore
    $firestoreData = [
        'user_id' => $userId,
        'email' => $profileData['email'] ?? '',
        'name' => $profileData['name'] ?? '',
        'photo_url' => $profileData['photo_url'] ?? '',
        'role' => $profileData['role'] ?? 'user',
        'created_at' => $profileData['created_at'] ?? date('Y-m-d H:i:s'),
        'last_login' => $profileData['last_login'] ?? '',
        'last_updated' => date('Y-m-d H:i:s'),
        'synced_at' => date('Y-m-d H:i:s'),
        'source' => 'profile_php'
    ];

    // Add 2FA data if provided
    if ($twoFaData !== null) {
        $firestoreData['two_fa'] = [
            'enabled' => $twoFaData['enabled'] ?? false,
            'email' => $twoFaData['email'] ?? '',
            'verified_at' => $twoFaData['verified_at'] ?? '',
            'setup_completed' => $twoFaData['setup_completed'] ?? false,
            'last_verified' => $twoFaData['last_verified'] ?? ''
        ];
    }

    // Add email verification tracking
    $firestoreData['email_verification'] = [
        'primary_email' => $profileData['email'] ?? '',
        'primary_verified' => true, // User is logged in, so primary email is verified
        '2fa_email' => $twoFaData['email'] ?? '',
        '2fa_email_verified' => $twoFaData['enabled'] ?? false,
        'verified_at' => $twoFaData['verified_at'] ?? ''
    ];

    // Add security metadata
    $firestoreData['security'] = [
        'two_fa_status' => ($twoFaData['enabled'] ?? false) ? 'enabled' : 'disabled',
        'last_2fa_change' => date('Y-m-d H:i:s'),
        'email_verification_status' => ($twoFaData['enabled'] ?? false) ? '2fa_verified' : 'primary_only'
    ];

    // Sync to Firestore
    $result = FirebaseHelper::setDocument('users', (string)$userId, $firestoreData);

    if ($result) {
        error_log("User $userId synced to Firestore successfully");
    } else {
        error_log("Failed to sync user $userId to Firestore");
    }

    return (bool)$result;
}

/**
 * Log 2FA activity to Firestore audit collection
 * @param int $userId User ID
 * @param string $action Action performed (enable, disable, verify, send_otp)
 * @param string $email Email used for 2FA
 * @param string $status Status of the action
 * @param string $details Additional details
 * @return bool Success status
 */
function log2FAToFirestore($userId, $action, $email, $status, $details = '') {
    if (!FirebaseHelper::isEnabled()) {
        return false;
    }

    $auditData = [
        'user_id' => $userId,
        'action' => $action,
        'email' => $email,
        'status' => $status,
        'details' => $details,
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'timestamp' => date('Y-m-d H:i:s'),
        'created_at' => date('Y-m-d H:i:s')
    ];

    // Use auto-generated document ID for audit logs
    $result = FirebaseHelper::setDocument('2fa_audit_logs', null, $auditData);

    return (bool)$result;
}

/**
 * Store email verification record in Firestore
 * @param int $userId User ID
 * @param string $email Email being verified
 * @param string $type Type of verification (primary, 2fa)
 * @param bool $verified Verification status
 * @param string $otp OTP used (hashed for security)
 * @return bool Success status
 */
function storeEmailVerification($userId, $email, $type, $verified, $otp = '') {
    if (!FirebaseHelper::isEnabled()) {
        return false;
    }

    $verificationData = [
        'user_id' => $userId,
        'email' => $email,
        'verification_type' => $type, // 'primary' or '2fa'
        'verified' => $verified,
        'verified_at' => $verified ? date('Y-m-d H:i:s') : null,
        'otp_hash' => $otp ? hash('sha256', $otp) : '', // Store hashed OTP for audit
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'created_at' => date('Y-m-d H:i:s')
    ];

    $docId = "{$userId}_{$type}_" . date('YmdHis');
    $result = FirebaseHelper::setDocument('email_verifications', $docId, $verificationData);

    return (bool)$result;
}

// Check if user_id is set in session
if (!isset($_SESSION['user_id'])) {
    error_log("2FA Debug - user_id not in session!");
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';

error_log("2FA Debug - Session user_id: $userId");
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Fetch current profile data from database
$mysqli = wolf2x_db();
$stmt = $mysqli->prepare('SELECT name, email, photo_url, created_at, last_login FROM users WHERE id = ?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();
$profile = $result->fetch_assoc();
$stmt->close();

$currentName = $profile['name'] ?? $userName;
$currentEmail = $profile['email'] ?? $_SESSION['user_email'] ?? '';
$currentPhoto = $profile['photo_url'] ?? $userPhoto;
$memberSince = $profile['created_at'] ?? date('Y-m-d');
$lastLogin = $profile['last_login'] ?? 'Never';

// Get user statistics
$stats = ['total_scans' => 0, 'total_findings' => 0, 'last_scan' => 'Never'];
$stmt = $mysqli->prepare('SELECT COUNT(*) as total FROM scans');
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['total_scans'] = $row['total'];
}
$stmt->close();

$stmt = $mysqli->prepare('SELECT COUNT(*) as total FROM findings');
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['total_findings'] = $row['total'];
}
$stmt->close();

$stmt = $mysqli->prepare('SELECT target, created_at FROM scans ORDER BY created_at DESC LIMIT 1');
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $stats['last_scan'] = $row['target'] . ' (' . date('M d, Y', strtotime($row['created_at'])) . ')';
}
$stmt->close();

// Get recent activity
$recentActivity = [];
$stmt = $mysqli->prepare('SELECT target, created_at FROM scans ORDER BY created_at DESC LIMIT 5');
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $recentActivity[] = [
        'type' => 'scan',
        'description' => 'Scanned ' . $row['target'],
        'date' => $row['created_at']
    ];
}
$stmt->close();

// Handle 2FA AJAX requests
$twofaMessage = '';
$twofaError = '';
$twofaEnabled = false;
$twofaEmail = '';

// Check current 2FA status
$stmt = $mysqli->prepare('SELECT twofa_enabled, twofa_email, twofa_secret FROM users WHERE id = ?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();
$user2FA = $result->fetch_assoc();
$stmt->close();

// Debug logging
error_log("2FA Check - UserID: $userId, Data: " . json_encode($user2FA));

// Explicit check for 2FA enabled (handles both int 1 and boolean)
$twofaEnabled = ($user2FA && isset($user2FA['twofa_enabled']) && $user2FA['twofa_enabled'] == 1) ? true : false;
$twofaEmail = $user2FA && $user2FA['twofa_email'] ? $user2FA['twofa_email'] : $userEmail;

// Handle 2FA setup/enabling
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        // Clear any previous output and set JSON header
        if (ob_get_level() > 0) {
            ob_clean();
        }
        header('Content-Type: application/json');
        
        $action = $_POST['action'] ?? '';
        
        if ($action === 'send_otp') {
        $email = $_POST['email'] ?? $userEmail;
        
        // Generate 6-digit OTP
        $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $otpExpiry = date('Y-m-d H:i:s', strtotime('+60 seconds'));
        
        // Store OTP in session and database
        $_SESSION['twofa_otp'] = $otp;
        $_SESSION['twofa_otp_expiry'] = $otpExpiry;
        $_SESSION['twofa_setup_email'] = $email;
        
        // Save to database (wrapped in try-catch for column errors)
        try {
            $stmt = $mysqli->prepare('UPDATE users SET twofa_email = ?, twofa_temp_otp = ?, twofa_otp_expiry = ? WHERE id = ?');
            if (!$stmt) {
                throw new Exception('Database prepare failed: ' . $mysqli->error);
            }
            $stmt->bind_param('sssi', $email, $otp, $otpExpiry, $userId);
            if (!$stmt->execute()) {
                throw new Exception('Database update failed: ' . $stmt->error);
            }
            $stmt->close();
        } catch (Exception $dbError) {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $dbError->getMessage() . '. Please run the SQL setup.']);
            exit;
        }
        
        // Send OTP via PHPMailer
        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'wolf2xfinder.in@gmail.com';
            $mail->Password = 'pjjb npge tgby aehy';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            $mail->setFrom('wolf2xfinder.in@gmail.com', 'Wolf2XFinder Security');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Your Two-Factor Authentication OTP - Wolf2XFinder';
            
            $mail->Body = "
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                    <div style='background: #0B0F1A; padding: 20px; text-align: center; border-bottom: 3px solid #00E5FF;'>
                        <h2 style='color: #00E5FF; margin: 0;'>Wolf2X Finder Security</h2>
                    </div>
                    <div style='background: #12182A; padding: 30px; color: #E6EAF2;'>
                        <h3 style='color: #00E5FF; margin-top: 0;'>Two-Factor Authentication Setup</h3>
                        <p>Hello {$userName},</p>
                        <p>You are setting up Two-Factor Authentication for your Wolf2XFinder account.</p>
                        <div style='background: rgba(0, 229, 255, 0.1); border: 2px solid #00E5FF; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0;'>
                            <p style='margin: 0 0 10px 0; color: #8A93A6; font-size: 0.9rem;'>Your OTP Code:</p>
                            <h1 style='margin: 0; font-size: 2.5rem; color: #00E5FF; letter-spacing: 5px;'>{$otp}</h1>
                            <p style='margin: 10px 0 0 0; color: #ff4d4d; font-size: 0.85rem;'>⏱️ Expires in 60 seconds</p>
                        </div>
                        <p style='font-size: 0.9rem; color: #8A93A6;'>If you didn't request this, please ignore this email or contact support.</p>
                        <p style='font-size: 0.85rem; color: #666; margin-top: 30px;'>Wolf2XFinder Security Team<br>Cyber Wolf Team - www.cyberwolf.pro</p>
                    </div>
                </div>
            ";
            
            $mail->send();

            // Log to Firestore audit
            log2FAToFirestore($userId, 'send_otp', $email, 'success', 'OTP sent for 2FA setup');

            // Store email verification attempt in Firestore
            storeEmailVerification($userId, $email, '2fa', false, $otp);

            echo json_encode(['success' => true, 'message' => 'OTP sent to ' . $email]);
            exit;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();

            // Log failure to Firestore
            log2FAToFirestore($userId, 'send_otp', $email, 'failed', $errorMsg);

            echo json_encode(['success' => false, 'error' => 'Failed to send OTP: ' . $errorMsg]);
            exit;
        }
    }
    
    if ($_POST['action'] === 'verify_otp') {
        error_log("2FA Verify - UserID from session: $userId");
        
        $enteredOtp = $_POST['otp'] ?? '';
        $storedOtp = $_SESSION['twofa_otp'] ?? '';
        $expiry = $_SESSION['twofa_otp_expiry'] ?? '';
        $setupEmail = $_SESSION['twofa_setup_email'] ?? $userEmail;
        
        // Check if OTP expired
        if (strtotime($expiry) < time()) {
            echo json_encode(['success' => false, 'error' => 'OTP expired. Please request a new one.']);
            exit;
        }
        
        if ($enteredOtp === $storedOtp) {
            // Enable 2FA
            $secret = bin2hex(random_bytes(16));
            
            error_log("2FA Enable - UserID: $userId, Email: $setupEmail");
            
            $stmt = $mysqli->prepare('UPDATE users SET twofa_enabled = 1, twofa_email = ?, twofa_secret = ?, twofa_temp_otp = NULL, twofa_otp_expiry = NULL WHERE id = ?');
            if (!$stmt) {
                error_log("2FA Enable - Prepare failed: " . $mysqli->error);
                echo json_encode(['success' => false, 'error' => 'Database prepare failed: ' . $mysqli->error]);
                exit;
            }
            $stmt->bind_param('ssi', $setupEmail, $secret, $userId);
            $result = $stmt->execute();
            if (!$result) {
                error_log("2FA Enable - Execute failed: " . $stmt->error);
                echo json_encode(['success' => false, 'error' => 'Database update failed: ' . $stmt->error]);
                exit;
            }
            $affectedRows = $stmt->affected_rows;
            error_log("2FA Enable - Affected rows: $affectedRows");
            if ($affectedRows === 0) {
                error_log("2FA Enable - WARNING: No rows updated! UserID: $userId may not exist or data unchanged.");
            }
            $stmt->close();
            
            $_SESSION['twofa_enabled'] = true;
            $_SESSION['twofa_verified'] = true;

            // Prepare profile data for Firestore sync
            $profileData = [
                'email' => $currentEmail,
                'name' => $userName,
                'photo_url' => $userPhoto,
                'role' => $userRole,
                'created_at' => $memberSince,
                'last_login' => $lastLogin
            ];

            // Prepare 2FA data for Firestore
            $twoFaData = [
                'enabled' => true,
                'email' => $setupEmail,
                'verified_at' => date('Y-m-d H:i:s'),
                'setup_completed' => true,
                'last_verified' => date('Y-m-d H:i:s')
            ];

            // Sync to Firestore
            syncUserToFirestore($userId, $profileData, $twoFaData);

            // Log to Firestore audit
            log2FAToFirestore($userId, 'enable', $setupEmail, 'success', '2FA enabled successfully');

            // Store successful email verification
            storeEmailVerification($userId, $setupEmail, '2fa', true);

            echo json_encode(['success' => true, 'message' => 'Two-Factor Authentication enabled successfully!']);
            exit;
        } else {
            // Log failed verification attempt
            log2FAToFirestore($userId, 'verify_otp', $setupEmail, 'failed', 'Invalid OTP entered');

            echo json_encode(['success' => false, 'error' => 'Invalid OTP. Please try again.']);
            exit;
        }
    }
    
    if ($_POST['action'] === 'disable_2fa') {
        $stmt = $mysqli->prepare('UPDATE users SET twofa_enabled = 0, twofa_email = NULL, twofa_secret = NULL, twofa_temp_otp = NULL, twofa_otp_expiry = NULL WHERE id = ?');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $stmt->close();

        unset($_SESSION['twofa_enabled']);
        unset($_SESSION['twofa_verified']);

        // Prepare profile data for Firestore sync
        $profileData = [
            'email' => $currentEmail,
            'name' => $userName,
            'photo_url' => $userPhoto,
            'role' => $userRole,
            'created_at' => $memberSince,
            'last_login' => $lastLogin
        ];

        // Prepare 2FA data (disabled)
        $twoFaData = [
            'enabled' => false,
            'email' => '',
            'verified_at' => '',
            'setup_completed' => false,
            'last_verified' => '',
            'disabled_at' => date('Y-m-d H:i:s')
        ];

        // Sync to Firestore
        syncUserToFirestore($userId, $profileData, $twoFaData);

        // Log to Firestore audit
        log2FAToFirestore($userId, 'disable', $userEmail, 'success', '2FA disabled by user');

        echo json_encode(['success' => true, 'message' => 'Two-Factor Authentication disabled.']);
        exit;
    }
    
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
        exit;
    }
}

$mysqli->close();

// Initial sync to Firestore on page load
$profileData = [
    'email' => $currentEmail,
    'name' => $currentName,
    'photo_url' => $currentPhoto,
    'role' => $userRole,
    'created_at' => $memberSince,
    'last_login' => $lastLogin
];

$twoFaData = [
    'enabled' => $twofaEnabled,
    'email' => $twofaEmail,
    'verified_at' => $twofaEnabled ? date('Y-m-d H:i:s') : '',
    'setup_completed' => $twofaEnabled,
    'last_verified' => $twofaEnabled ? date('Y-m-d H:i:s') : ''
];

// Sync user data to Firestore (non-blocking)
syncUserToFirestore($userId, $profileData, $twoFaData);

?><!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profile - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }

      .profile-container {
        grid-template-columns: 1fr;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }

      .profile-container {
        grid-template-columns: 1fr;
        padding: 0;
        margin: 20px 0;
      }

      .profile-card {
        padding: 20px;
      }

      .profile-photo-large {
        width: 120px;
        height: 120px;
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }

      .tabs {
        flex-wrap: wrap;
      }

      .tab-btn {
        padding: 10px 18px;
        font-size: 13px;
      }
    }

    .btn-spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 2px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: #fff;
      animation: spin 0.8s linear infinite;
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
    }
    @keyframes spin {
      to { transform: translateY(-50%) rotate(360deg); }
    }

    /* Profile Enhancement Styles */
    .profile-container {
      display: grid;
      grid-template-columns: 300px 1fr;
      gap: 30px;
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .profile-sidebar {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .profile-main {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .profile-card {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 28px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4), 0 0 20px rgba(0, 229, 255, 0.05);
    }

    .profile-header {
      text-align: center;
      padding-bottom: 24px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
    }

    .profile-photo-large {
      width: 150px;
      height: 150px;
      border-radius: 0;
      object-fit: cover;
      border: 3px solid #00E5FF;
      box-shadow: 0 4px 30px rgba(0, 229, 255, 0.3);
      margin-bottom: 15px;
    }

    .profile-name {
      font-size: 1.8rem;
      font-weight: normal;
      color: #E6EAF2;
      margin-bottom: 8px;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .profile-role {
      display: inline-block;
      background: linear-gradient(135deg, #00E5FF 0%, #6C63FF 100%);
      color: #0B0F1A;
      padding: 6px 16px;
      border-radius: 0;
      font-size: 0.85rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      margin-top: 20px;
    }

    .stat-box {
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 18px;
      text-align: center;
      transition: all 0.3s ease;
    }

    .stat-box:hover {
      border-color: rgba(0, 229, 255, 0.4);
      box-shadow: 0 4px 15px rgba(0, 229, 255, 0.1);
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: #00E5FF;
      display: block;
      font-family: 'Orbitron', sans-serif;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.3);
    }

    .stat-label {
      font-size: 0.85rem;
      color: #8A93A6;
      margin-top: 8px;
      letter-spacing: 0.5px;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 14px 0;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
    }

    .info-row:last-child {
      border-bottom: none;
    }

    .info-label {
      color: #8A93A6;
      font-size: 0.9rem;
    }

    .info-value {
      color: #E6EAF2;
      font-weight: 500;
    }

    .tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 24px;
      border-bottom: 2px solid rgba(0, 229, 255, 0.15);
    }

    .tab-btn {
      background: transparent;
      border: none;
      color: #8A93A6;
      padding: 14px 28px;
      cursor: pointer;
      font-size: 0.95rem;
      border-bottom: 3px solid transparent;
      transition: all 0.3s ease;
      font-weight: 500;
    }

    .tab-btn:hover {
      color: #00E5FF;
    }

    .tab-btn.active {
      color: #00E5FF;
      border-bottom-color: #00E5FF;
      font-weight: 600;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.3);
    }

    .tab-content {
      display: none;
    }

    .tab-content.active {
      display: block;
    }

    .activity-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .activity-item {
      display: flex;
      align-items: flex-start;
      gap: 15px;
      padding: 16px 0;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
    }

    .activity-item:last-child {
      border-bottom: none;
    }

    .activity-icon {
      width: 44px;
      height: 44px;
      background: rgba(0, 229, 255, 0.1);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      flex-shrink: 0;
      color: #00E5FF;
    }

    .activity-content {
      flex: 1;
    }

    .activity-title {
      color: #E6EAF2;
      font-weight: 500;
      margin-bottom: 4px;
    }

    .activity-time {
      color: #8A93A6;
      font-size: 0.85rem;
    }

    .form-section {
      margin-bottom: 25px;
    }

    .form-section-title {
      font-size: 1.1rem;
      color: #00E5FF;
      margin-bottom: 20px;
      padding-bottom: 12px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
      font-weight: 600;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }

    .photo-actions {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-top: 15px;
    }

    @media (max-width: 768px) {
      .profile-container {
        grid-template-columns: 1fr;
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Navigation Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="index.php" class="btn-secondary">Dashboard</a>
        </div>
      </header>

      <main class="container">
    <!-- Sidebar -->
    <aside class="profile-sidebar">
      <!-- Profile Card -->
      <div class="profile-card">
        <div class="profile-header">
          <img id="photoPreview" class="profile-photo-large" src="<?php echo $currentPhoto ?: '../logo/wolf2xfinder.png'; ?>" alt="Profile Photo" />
          <div class="profile-name"><?php echo htmlspecialchars($currentName); ?></div>
          <span class="profile-role"><?php echo htmlspecialchars($userRole); ?></span>

          <div class="photo-actions">
            <label for="photoInput" class="btn-secondary" style="cursor: pointer; font-size: 0.85rem;">
              Change Photo
            </label>
            <input type="file" id="photoInput" name="photo" accept="image/*" style="display: none;" />
            <?php if ($currentPhoto): ?>
            <button type="button" id="removePhotoBtn" class="btn-secondary" style="border-color: rgba(255, 77, 109, 0.5); color: #FF4D6D; font-size: 0.85rem;">
              Remove
            </button>
            <?php endif; ?>
          </div>
        </div>

        <div class="stats-grid">
          <div class="stat-box">
            <span class="stat-value"><?php echo $stats['total_scans']; ?></span>
            <span class="stat-label">Scans</span>
          </div>
          <div class="stat-box">
            <span class="stat-value"><?php echo $stats['total_findings']; ?></span>
            <span class="stat-label">Findings</span>
          </div>
          <div class="stat-box">
            <span class="stat-value"><?php echo count($recentActivity); ?></span>
            <span class="stat-label">Activity</span>
          </div>
        </div>
      </div>

      <!-- Account Info -->
      <div class="profile-card">
        <div class="form-section-title">Account Information</div>
        <div class="info-row">
          <span class="info-label">Email</span>
          <span class="info-value"><?php echo htmlspecialchars($currentEmail); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Member Since</span>
          <span class="info-value"><?php echo date('M d, Y', strtotime($memberSince)); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Last Login</span>
          <span class="info-value"><?php echo $lastLogin != 'Never' ? date('M d, Y H:i', strtotime($lastLogin)) : 'Never'; ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Last Scan</span>
          <span class="info-value" style="font-size: 0.85rem;"><?php echo $stats['last_scan']; ?></span>
        </div>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="profile-main">
      <!-- Tabs -->
      <div class="tabs">
        <button class="tab-btn active" data-tab="profile">Profile Settings</button>
        <button class="tab-btn" data-tab="activity">Recent Activity</button>
        <button class="tab-btn" data-tab="security">Security</button>
      </div>

      <!-- Profile Tab -->
      <div id="profile" class="tab-content active">
        <div class="profile-card">
          <div id="errorMessage" class="auth-error" style="display: none;"></div>
          <div id="successMessage" class="auth-success" style="display: none;"></div>

          <form id="profileForm">
            <div class="form-section">
              <div class="form-section-title">Personal Information</div>

              <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($currentName); ?>" required placeholder="Enter your full name" />
                <small class="form-hint">This name will be displayed on your profile and reports</small>
              </div>

              <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($currentEmail); ?>" readonly style="background: #1a1a1a; cursor: not-allowed;" />
                <small class="form-hint">Email cannot be changed. Contact admin for assistance.</small>
              </div>

              <div class="form-group">
                <label for="role">Account Role</label>
                <input type="text" id="role" name="role" value="<?php echo htmlspecialchars(ucfirst($userRole)); ?>" readonly style="background: #1a1a1a; cursor: not-allowed;" />
                <small class="form-hint">Role is assigned by administrator</small>
              </div>
            </div>

            <button type="submit" class="btn-primary" id="saveBtn" style="width: auto; padding: 14px 40px; position: relative; display: block; margin: 0 auto;">
              <span id="saveBtnText">Save Changes</span>
              <span id="saveBtnSpinner" class="btn-spinner" style="display: none;"></span>
            </button>
          </form>
        </div>
      </div>

      <!-- Activity Tab -->
      <div id="activity" class="tab-content">
        <div class="profile-card">
          <div class="form-section-title">Recent Activity</div>
          <?php if (empty($recentActivity)): ?>
            <p style="color: #666; text-align: center; padding: 30px;">No recent activity found.</p>
          <?php else: ?>
            <ul class="activity-list">
              <?php foreach ($recentActivity as $activity): ?>
              <li class="activity-item">
                <div class="activity-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.35-4.35"/>
                  </svg>
                </div>
                <div class="activity-content">
                  <div class="activity-title"><?php echo htmlspecialchars($activity['description']); ?></div>
                  <div class="activity-time"><?php echo date('M d, Y H:i', strtotime($activity['date'])); ?></div>
                </div>
              </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>

      <!-- Security Tab -->
      <div id="security" class="tab-content">
        <div class="profile-card">
          <div class="form-section-title">Password Change</div>
          <p style="color: #999; margin-bottom: 20px;">To change your password, please contact the administrator or use the password reset feature on the login page.</p>
          <a href="../auth/login.php" class="btn-secondary">Go to Login Page</a>
        </div>

        <!-- Two-Factor Authentication Section -->
        <div class="profile-card" style="margin-top: 20px;">
          <div class="form-section-title">
            <span style="display: flex; align-items: center; gap: 10px;">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00E5FF" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                <path d="m9 12 2 2 4-4"/>
              </svg>
              Two-Factor Authentication (2FA)
            </span>
          </div>
          
          <!-- 2FA Status -->
          <div id="twofaStatus" style="margin-bottom: 20px;">
            <div class="info-row">
              <span class="info-label">2FA Status</span>
              <span class="info-value" id="twofaStatusText" style="color: <?php echo $twofaEnabled ? '#00E5FF' : '#ff4d4d'; ?>; font-weight: 600;">
                <?php echo $twofaEnabled ? '✓ Enabled' : '✗ Not Enabled'; ?>
              </span>
            </div>
            <?php if ($twofaEnabled): ?>
            <div class="info-row">
              <span class="info-label">2FA Email</span>
              <span class="info-value" id="twofaEmailText"><?php echo htmlspecialchars($twofaEmail); ?></span>
            </div>
            <?php endif; ?>
          </div>
          
          <!-- 2FA Setup / Disable Forms -->
          <div id="twofaSetupSection" style="display: <?php echo $twofaEnabled ? 'none' : 'block'; ?>;">
            <p style="color: #999; margin-bottom: 20px; line-height: 1.6;">
              Enhance your account security with Two-Factor Authentication. 
              When enabled, you'll receive a one-time password (OTP) via email each time you log in.
            </p>
            
            <!-- Step 1: Enter Email -->
            <div id="twofaStep1">
              <div class="form-group">
                <label for="twofaEmail">Email for 2FA OTP</label>
                <input type="email" id="twofaEmail" value="<?php echo htmlspecialchars($currentEmail); ?>" placeholder="Enter your email for OTP" />
                <small class="form-hint">OTP will be sent to this email address (60 second expiry)</small>
              </div>
              <button type="button" class="btn-primary" id="sendOtpBtn" onclick="send2FAOTP()" style="width: 100%; margin-top: 10px;">
                <span id="sendOtpBtnText">Send OTP</span>
                <span id="sendOtpSpinner" class="btn-spinner" style="display: none;"></span>
              </button>
            </div>
            
            <!-- Step 2: Enter OTP -->
            <div id="twofaStep2" style="display: none; margin-top: 20px;">
              <div style="background: rgba(0, 229, 255, 0.05); border: 1px solid rgba(0, 229, 255, 0.2); padding: 15px; border-radius: 0; margin-bottom: 20px;">
                <p style="color: #00E5FF; margin: 0 0 10px 0; font-size: 0.9rem;">✉️ OTP sent! Check your email</p>
                <p style="color: #8A93A6; margin: 0; font-size: 0.85rem;">The OTP expires in <span id="otpCountdown" style="color: #ff4d4d; font-weight: 600;">60</span> seconds</p>
              </div>
              
              <div class="form-group">
                <label for="otpCode">Enter 6-digit OTP</label>
                <input type="text" id="otpCode" maxlength="6" placeholder="000000" style="text-align: center; font-size: 1.5rem; letter-spacing: 10px;" />
              </div>
              
              <div style="display: flex; gap: 10px;">
                <button type="button" class="btn-secondary" onclick="resend2FAOTP()" id="resendBtn" style="flex: 1;" disabled>
                  Resend (<span id="resendCountdown">60</span>s)
                </button>
                <button type="button" class="btn-primary" onclick="verify2FAOTP()" id="verifyBtn" style="flex: 2;">
                  <span id="verifyBtnText">Enable 2FA</span>
                  <span id="verifyBtnSpinner" class="btn-spinner" style="display: none;"></span>
                </button>
              </div>
            </div>
          </div>
          
          <!-- Disable 2FA Section -->
          <div id="twofaDisableSection" style="display: <?php echo $twofaEnabled ? 'block' : 'none'; ?>;">
            <div style="background: rgba(0, 229, 255, 0.05); border-left: 3px solid #00E5FF; padding: 15px; margin-bottom: 20px;">
              <p style="color: #E6EAF2; margin: 0; font-size: 0.9rem;">
                <strong style="color: #00E5FF;">✓ 2FA is Active</strong><br>
                Your account is protected with email-based Two-Factor Authentication.
              </p>
            </div>
            <button type="button" class="btn-secondary" onclick="disable2FA()" id="disableBtn" style="width: 100%; border-color: #ff4d4d; color: #ff4d4d;">
              <span id="disableBtnText">Disable Two-Factor Authentication</span>
              <span id="disableBtnSpinner" class="btn-spinner" style="display: none;"></span>
            </button>
            <p style="color: #8A93A6; font-size: 0.8rem; margin-top: 10px; text-align: center;">
              ⚠️ Disabling 2FA will reduce your account security
            </p>
          </div>
          
          <!-- Messages -->
          <div id="twofaError" class="auth-error" style="display: none; margin-top: 15px;"></div>
          <div id="twofaSuccess" class="auth-success" style="display: none; margin-top: 15px;"></div>
        </div>

        <div class="profile-card" style="margin-top: 20px;">
          <div class="form-section-title">Security Information</div>
          <div class="info-row">
            <span class="info-label">Account Created</span>
            <span class="info-value"><?php echo date('M d, Y', strtotime($memberSince)); ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Last Login</span>
            <span class="info-value"><?php echo $lastLogin !== 'Never' ? date('M d, Y H:i', strtotime($lastLogin)) : 'Never'; ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Password Last Changed</span>
            <span class="info-value">Unknown</span>
          </div>
        </div>
      </div>
    </div>
    </main>
    </div>
  </div>

  <script>
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        // Remove active from all tabs
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        // Add active to clicked tab
        this.classList.add('active');
        const tabId = this.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
      });
    });

    const photoInput = document.getElementById('photoInput');
    const photoPreview = document.getElementById('photoPreview');
    const removePhotoBtn = document.getElementById('removePhotoBtn');
    const profileForm = document.getElementById('profileForm');
    let photoFile = null;
    let removePhoto = false;

    // Photo preview
    photoInput.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        // Validate file size (2MB max)
        if (file.size > 2 * 1024 * 1024) {
          showError('Photo must be less than 2MB');
          photoInput.value = '';
          return;
        }

        // Validate file type
        if (!file.type.match(/^image\/(jpeg|png|gif)$/)) {
          showError('Only JPG, PNG, and GIF images are allowed');
          photoInput.value = '';
          return;
        }

        photoFile = file;
        removePhoto = false;
        const reader = new FileReader();
        reader.onload = function(e) {
          photoPreview.src = e.target.result;
        };
        reader.readAsDataURL(file);
        removePhotoBtn.style.display = 'inline-block';
      }
    });

    // Remove photo
    removePhotoBtn.addEventListener('click', function() {
      photoFile = null;
      removePhoto = true;
      photoInput.value = '';
      photoPreview.src = '../logo/wolf2xfinder.png';
      removePhotoBtn.style.display = 'none';
    });

    // Form submission
    profileForm.addEventListener('submit', async function(e) {
      e.preventDefault();

      const name = document.getElementById('name').value.trim();
      if (!name) {
        showError('Name is required');
        return;
      }

      const saveBtn = document.getElementById('saveBtn');
      const saveBtnText = document.getElementById('saveBtnText');
      const saveBtnSpinner = document.getElementById('saveBtnSpinner');

      // Show loading state
      saveBtn.disabled = true;
      saveBtnText.textContent = 'Saving...';
      saveBtnSpinner.style.display = 'inline-block';

      // Add 1s delay for animation
      await new Promise(resolve => setTimeout(resolve, 1000));

      const formData = new FormData();
      formData.append('action', 'update');
      formData.append('name', name);
      if (photoFile) {
        formData.append('photo', photoFile);
      }
      if (removePhoto) {
        formData.append('remove_photo', '1');
      }

      try {
        const response = await fetch('profile_update.php', {
          method: 'POST',
          body: formData
        });

        const data = await response.json();
        if (data.ok) {
          showSuccess('Profile updated successfully!');
          // Update session data
          if (data.name) {
            // Will be updated on next page load
          }
          if (data.photo_url !== undefined) {
            photoPreview.src = data.photo_url || '../logo/wolf2xfinder.png';
            if (!data.photo_url) {
              removePhotoBtn.style.display = 'none';
            }
          }
          photoFile = null;
          removePhoto = false;
          photoInput.value = '';
        } else {
          showError(data.error || 'Failed to update profile');
        }
      } catch (error) {
        showError('Network error. Please try again.');
      } finally {
        saveBtn.disabled = false;
        saveBtnText.textContent = 'Save Changes';
        saveBtnSpinner.style.display = 'none';
      }
    });

    function showError(message) {
      const el = document.getElementById('errorMessage');
      const successEl = document.getElementById('successMessage');
      if (el) {
        el.textContent = message;
        el.style.display = 'block';
      }
      if (successEl) successEl.style.display = 'none';
    }

    function showSuccess(message) {
      const el = document.getElementById('successMessage');
      const errorEl = document.getElementById('errorMessage');
      if (el) {
        el.textContent = message;
        el.style.display = 'block';
      }
      if (errorEl) errorEl.style.display = 'none';
    }

    // ==================== TWO-FACTOR AUTHENTICATION (2FA) ====================
    
    let otpCountdownInterval;
    let resendCountdownInterval;

    // Send OTP for 2FA setup
    async function send2FAOTP() {
      const emailInput = document.getElementById('twofaEmail');
      if (!emailInput) {
        console.error('2FA Email input not found');
        return;
      }
      const email = emailInput.value.trim();
      
      if (!email || !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        show2FAError('Please enter a valid email address');
        return;
      }
      
      const btn = document.getElementById('sendOtpBtn');
      const btnText = document.getElementById('sendOtpBtnText');
      const spinner = document.getElementById('sendOtpSpinner');
      
      if (btn) btn.disabled = true;
      if (btnText) btnText.textContent = 'Sending...';
      if (spinner) spinner.style.display = 'inline-block';
      hide2FAMessages();
      
      try {
        const formData = new FormData();
        formData.append('action', 'send_otp');
        formData.append('email', email);
        
        const response = await fetch('profile.php', {
          method: 'POST',
          body: formData
        });
        
        // Get response text for debugging
        const responseText = await response.text();
        console.log('Server response:', responseText);
        
        let data;
        try {
          data = JSON.parse(responseText);
        } catch (parseError) {
          console.error('JSON parse error:', parseError);
          show2FAError('Server error: Invalid response. Check console for details.');
          return;
        }
        
        if (data.success) {
          // Show OTP input step
          document.getElementById('twofaStep1').style.display = 'none';
          document.getElementById('twofaStep2').style.display = 'block';
          
          // Start countdowns
          startOTPCountdown();
          startResendCountdown();
          
          show2FASuccess(data.message);
        } else {
          show2FAError(data.error || 'Failed to send OTP');
        }
      } catch (error) {
        show2FAError('Error: ' + (error.message || 'Network error. Please check console.'));
        console.error('2FA Send OTP Error:', error);
      } finally {
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = 'Send OTP';
        if (spinner) spinner.style.display = 'none';
      }
    }
    
    // Resend OTP
    async function resend2FAOTP() {
      await send2FAOTP();
      const step1 = document.getElementById('twofaStep1');
      const step2 = document.getElementById('twofaStep2');
      if (step1) step1.style.display = 'none';
      if (step2) step2.style.display = 'block';
    }
    
    // Verify OTP and enable 2FA
    async function verify2FAOTP() {
      const otpInput = document.getElementById('otpCode');
      if (!otpInput) {
        console.error('OTP input not found');
        return;
      }
      const otp = otpInput.value.trim();
      
      if (!otp || otp.length !== 6 || !/^\d{6}$/.test(otp)) {
        show2FAError('Please enter a valid 6-digit OTP');
        return;
      }
      
      const btn = document.getElementById('verifyBtn');
      const btnText = document.getElementById('verifyBtnText');
      const spinner = document.getElementById('verifyBtnSpinner');
      
      if (btn) btn.disabled = true;
      if (btnText) btnText.textContent = 'Verifying...';
      if (spinner) spinner.style.display = 'inline-block';
      hide2FAMessages();
      
      try {
        const formData = new FormData();
        formData.append('action', 'verify_otp');
        formData.append('otp', otp);
        
        const response = await fetch('profile.php', {
          method: 'POST',
          body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
          show2FASuccess(data.message);
          
          // Update UI with null checks
          const twofaStatusText = document.getElementById('twofaStatusText');
          const twofaEmailText = document.getElementById('twofaEmailText');
          const twofaSetupSection = document.getElementById('twofaSetupSection');
          const twofaDisableSection = document.getElementById('twofaDisableSection');
          const twofaEmail = document.getElementById('twofaEmail');
          
          if (twofaStatusText) {
            twofaStatusText.textContent = '✓ Enabled';
            twofaStatusText.style.color = '#00E5FF';
          }
          if (twofaEmailText && twofaEmail) {
            twofaEmailText.textContent = twofaEmail.value;
          }
          
          // Show disable section, hide setup section
          if (twofaSetupSection) twofaSetupSection.style.display = 'none';
          if (twofaDisableSection) twofaDisableSection.style.display = 'block';
          
          // Add 2FA email row if not exists
          const emailRow = document.getElementById('twofaEmailRow');
          const statusDiv = document.getElementById('twofaStatus');
          const twofaEmailInput = document.getElementById('twofaEmail');
          if (!emailRow && statusDiv && twofaEmailInput) {
            const newRow = document.createElement('div');
            newRow.className = 'info-row';
            newRow.id = 'twofaEmailRow';
            newRow.innerHTML = `
              <span class="info-label">2FA Email</span>
              <span class="info-value" id="twofaEmailText">${twofaEmailInput.value}</span>
            `;
            statusDiv.appendChild(newRow);
          }
          
          // Clear countdowns
          clearInterval(otpCountdownInterval);
          clearInterval(resendCountdownInterval);
        } else {
          show2FAError(data.error || 'Invalid OTP');
        }
      } catch (error) {
        show2FAError('Error: ' + (error.message || 'Network error. Please check console.'));
        console.error('2FA Verify Error:', error);
      } finally {
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = 'Enable 2FA';
        if (spinner) spinner.style.display = 'none';
      }
    }
    
    // Disable 2FA
    async function disable2FA() {
      if (!confirm('Are you sure you want to disable Two-Factor Authentication? This will reduce your account security.')) {
        return;
      }
      
      const btn = document.getElementById('disableBtn');
      const btnText = document.getElementById('disableBtnText');
      const spinner = document.getElementById('disableBtnSpinner');
      
      if (btn) btn.disabled = true;
      if (btnText) btnText.textContent = 'Disabling...';
      if (spinner) spinner.style.display = 'inline-block';
      hide2FAMessages();
      
      try {
        const formData = new FormData();
        formData.append('action', 'disable_2fa');
        
        const response = await fetch('profile.php', {
          method: 'POST',
          body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
          show2FASuccess(data.message);
          
          // Update UI with null checks
          const twofaStatusText = document.getElementById('twofaStatusText');
          if (twofaStatusText) {
            twofaStatusText.textContent = '✗ Not Enabled';
            twofaStatusText.style.color = '#ff4d4d';
          }
          
          // Remove 2FA email row
          const emailRow = document.getElementById('twofaEmailRow');
          if (emailRow) {
            emailRow.remove();
          }
          
          // Show setup section, hide disable section
          const twofaSetupSection = document.getElementById('twofaSetupSection');
          const twofaDisableSection = document.getElementById('twofaDisableSection');
          const twofaStep1 = document.getElementById('twofaStep1');
          const twofaStep2 = document.getElementById('twofaStep2');
          const otpCode = document.getElementById('otpCode');
          
          if (twofaSetupSection) twofaSetupSection.style.display = 'block';
          if (twofaDisableSection) twofaDisableSection.style.display = 'none';
          
          // Reset forms
          if (twofaStep1) twofaStep1.style.display = 'block';
          if (twofaStep2) twofaStep2.style.display = 'none';
          if (otpCode) otpCode.value = '';
        } else {
          show2FAError(data.error || 'Failed to disable 2FA');
        }
      } catch (error) {
        show2FAError('Error: ' + (error.message || 'Network error. Please check console.'));
        console.error('2FA Disable Error:', error);
      } finally {
        if (btn) btn.disabled = false;
        if (btnText) btnText.textContent = 'Disable Two-Factor Authentication';
        if (spinner) spinner.style.display = 'none';
      }
    }
    
    // OTP Countdown (60 seconds)
    function startOTPCountdown() {
      let seconds = 60;
      const otpCountdown = document.getElementById('otpCountdown');
      if (otpCountdown) otpCountdown.textContent = seconds;
      
      clearInterval(otpCountdownInterval);
      otpCountdownInterval = setInterval(() => {
        seconds--;
        const otpEl = document.getElementById('otpCountdown');
        if (otpEl) otpEl.textContent = seconds;
        
        if (seconds <= 0) {
          clearInterval(otpCountdownInterval);
          show2FAError('OTP expired. Please request a new one.');
        }
      }, 1000);
    }
    
    // Resend Countdown (60 seconds cooldown)
    function startResendCountdown() {
      let seconds = 60;
      const resendBtn = document.getElementById('resendBtn');
      const countdownSpan = document.getElementById('resendCountdown');
      
      if (resendBtn) resendBtn.disabled = true;
      if (countdownSpan) countdownSpan.textContent = seconds;
      
      clearInterval(resendCountdownInterval);
      resendCountdownInterval = setInterval(() => {
        seconds--;
        if (countdownSpan) countdownSpan.textContent = seconds;
        
        if (seconds <= 0) {
          clearInterval(resendCountdownInterval);
          if (resendBtn) {
            resendBtn.disabled = false;
            resendBtn.innerHTML = 'Resend OTP';
          }
        }
      }, 1000);
    }
    
    // Show 2FA error
    function show2FAError(message) {
      const el = document.getElementById('twofaError');
      const successEl = document.getElementById('twofaSuccess');
      if (el) {
        el.textContent = message;
        el.style.display = 'block';
      }
      if (successEl) {
        successEl.style.display = 'none';
      }
      console.error('2FA Error:', message);
    }
    
    // Show 2FA success
    function show2FASuccess(message) {
      const el = document.getElementById('twofaSuccess');
      const errorEl = document.getElementById('twofaError');
      if (el) {
        el.textContent = message;
        el.style.display = 'block';
      }
      if (errorEl) {
        errorEl.style.display = 'none';
      }
      console.log('2FA Success:', message);
    }
    
    // Hide 2FA messages
    function hide2FAMessages() {
      const errorEl = document.getElementById('twofaError');
      const successEl = document.getElementById('twofaSuccess');
      if (errorEl) errorEl.style.display = 'none';
      if (successEl) successEl.style.display = 'none';
    }
    
    // Allow only digits in OTP input
    const otpCodeInput = document.getElementById('otpCode');
    if (otpCodeInput) {
      otpCodeInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/\D/g, '').substring(0, 6);
      });
    }
  </script>
</body>
</html>
