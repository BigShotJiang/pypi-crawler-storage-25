<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

require_once __DIR__ . '/../lib/db.php';

// Include PHPMailer from vendor directory
require_once __DIR__ . '/../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Fetch available scans for the user
$mysqli = wolf2x_db();
$scans = [];
$stmt = $mysqli->prepare('SELECT id, target, generated_at, total_pages, created_at FROM scans ORDER BY created_at DESC');
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $scans[] = $row;
}
$stmt->close();

// Handle form submission
$sent = false;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scanId = $_POST['scan_id'] ?? '';
    $recipientEmail = $_POST['recipient_email'] ?? '';
    $recipientName = $_POST['recipient_name'] ?? '';
    $subject = $_POST['subject'] ?? 'Wolf2XFinder Security Scan Report';
    $message = $_POST['message'] ?? '';
    $includeFindings = isset($_POST['include_findings']);
    $format = $_POST['format'] ?? 'html';

    if (empty($scanId) || empty($recipientEmail)) {
        $error = 'Please select a scan and enter recipient email.';
    } elseif (!filter_var($recipientEmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } else {
        // Fetch scan details
        $stmt = $mysqli->prepare('SELECT * FROM scans WHERE id = ?');
        $stmt->bind_param('i', $scanId);
        $stmt->execute();
        $scan = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($scan) {
            // Fetch findings if requested
            $findings = [];
            if ($includeFindings) {
                $stmt = $mysqli->prepare('SELECT * FROM findings WHERE scan_id = ? ORDER BY severity DESC');
                $stmt->bind_param('i', $scanId);
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $findings[] = $row;
                }
                $stmt->close();
            }

            // Send email using PHPMailer
            try {
                $mail = new PHPMailer(true);

                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'wolf2xfinder.in@gmail.com'; // UPDATE: Your Gmail address
                $mail->Password = 'pjjb npge tgby aehy'; // UPDATE: Your 16-char app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('wolf2xfinder.in@gmail.com', 'wolfx2finder');
                $mail->addAddress($recipientEmail, $recipientName);

                // Content
                $mail->isHTML($format === 'html');
                $mail->Subject = $subject;

                // Build email body
                $emailBody = buildEmailBody($scan, $findings, $message, $userName, $format);
                $mail->Body = $emailBody;

                if ($format === 'html') {
                    $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $emailBody));
                }

                $mail->send();
                $sent = true;
                $success = 'Report sent successfully to ' . htmlspecialchars($recipientEmail);
            } catch (Exception $e) {
                // Email failed - save to file as fallback
                $timestamp = date('Y-m-d_H-i-s');
                // Sanitize target URL for filename
                $safeTarget = preg_replace('/[^a-zA-Z0-9]/', '_', $scan['target']);
                $filename = "report_{$safeTarget}_{$timestamp}.html";
                $reportsDir = __DIR__ . '/../../reports';
                
                // Create reports directory if it doesn't exist
                if (!is_dir($reportsDir)) {
                    mkdir($reportsDir, 0755, true);
                }
                
                $filepath = $reportsDir . '/' . $filename;
                
                // Build email body for file
                $emailBody = buildEmailBody($scan, $findings, $message, $userName, 'html');
                
                // Save report to file
                file_put_contents($filepath, $emailBody);
                
                $sent = true;
                $success = "Email failed: " . $e->getMessage() . ". Report saved to: <a href='/Wolf2X-Finder/reports/{$filename}' target='_blank'>{$filename}</a>";
            }
        } else {
            $error = 'Scan not found.';
        }
    }
}

$mysqli->close();

function buildEmailBody($scan, $findings, $customMessage, $senderName, $format) {
    $severityColors = [
        'CRITICAL' => '#ff0000',
        'HIGH' => '#ff6600',
        'MEDIUM' => '#ffcc00',
        'LOW' => '#00cc00',
        'INFO' => '#0066cc'
    ];

    if ($format === 'html') {
        $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #1a1a1a, #0d0d0d); color: #A37D37; padding: 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 24px; }
        .header p { margin: 10px 0 0; color: #ccc; }
        .content { padding: 30px; }
        .scan-info { background: #f9f9f9; border-left: 4px solid #A37D37; padding: 20px; margin-bottom: 20px; border-radius: 5px; }
        .scan-info h2 { margin-top: 0; color: #333; }
        .info-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
        .info-label { font-weight: bold; color: #666; }
        .info-value { color: #333; }
        .findings { margin-top: 30px; }
        .findings h2 { color: #333; border-bottom: 2px solid #A37D37; padding-bottom: 10px; }
        .finding-item { border: 1px solid #ddd; border-radius: 8px; margin-bottom: 15px; overflow: hidden; }
        .finding-header { padding: 15px; color: #000; font-weight: bold; display: flex; justify-content: space-between; align-items: center; }
        .finding-body { padding: 15px; background: #fafafa; }
        .finding-body p { margin: 5px 0; }
        .severity-CRITICAL { background: #ff0000; }
        .severity-HIGH { background: #ff6600; }
        .severity-MEDIUM { background: #ffcc00; color: #000; }
        .severity-LOW { background: #00cc00; }
        .severity-INFO { background: #0066cc; }
        .footer { background: #1a1a1a; color: #999; text-align: center; padding: 20px; font-size: 12px; }
        .custom-message { background: #e8f4f8; border: 1px solid #b8d4e3; border-radius: 5px; padding: 15px; margin-bottom: 20px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .summary-box { text-align: center; padding: 20px; border-radius: 8px; background: #f0f0f0; }
        .summary-value { font-size: 32px; font-weight: bold; color: #A37D37; }
        .summary-label { font-size: 12px; color: #666; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
              Wolf2XFinder Security Report
            </h1>
            <p>Generated by {$senderName} on {$scan['generated_at']}</p>
        </div>
        <div class="content">
HTML;

        if ($customMessage) {
            $html .= '<div class="custom-message"><strong>Note:</strong> ' . nl2br(htmlspecialchars($customMessage)) . '</div>';
        }

        // Summary
        $critical = count(array_filter($findings, fn($f) => strtoupper(trim($f['severity'])) === 'CRITICAL'));
        $high = count(array_filter($findings, fn($f) => strtoupper(trim($f['severity'])) === 'HIGH'));
        $medium = count(array_filter($findings, fn($f) => strtoupper(trim($f['severity'])) === 'MEDIUM'));
        $low = count(array_filter($findings, fn($f) => strtoupper(trim($f['severity'])) === 'LOW'));
        $totalFindingsCount = count($findings);

        $html .= <<<HTML
            <div class="summary">
                <div class="summary-box">
                    <div class="summary-value">{$critical}</div>
                    <div class="summary-label">Critical</div>
                </div>
                <div class="summary-box">
                    <div class="summary-value">{$high}</div>
                    <div class="summary-label">High</div>
                </div>
                <div class="summary-box">
                    <div class="summary-value">{$medium}</div>
                    <div class="summary-label">Medium</div>
                </div>
                <div class="summary-box">
                    <div class="summary-value">{$low}</div>
                    <div class="summary-label">Low</div>
                </div>
            </div>

            <div class="scan-info">
                <h2>Scan Details</h2>
                <div class="info-row">
                    <span class="info-label">Target URL:</span>
                    <span class="info-value">{$scan['target']}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Scan Date:</span>
                    <span class="info-value">{$scan['generated_at']}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Pages Scanned:</span>
                    <span class="info-value">{$scan['total_pages']}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Findings:</span>
                    <span class="info-value">{$totalFindingsCount}</span>
                </div>
            </div>
HTML;

        if (!empty($findings)) {
            // Group findings by severity
            $severityOrder = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'];
            $groupedFindings = [];
            $unknownSeverityFindings = [];
            
            foreach ($findings as $finding) {
                $severity = strtoupper(trim($finding['severity']));
                if (!isset($groupedFindings[$severity])) {
                    $groupedFindings[$severity] = [];
                }
                $groupedFindings[$severity][] = $finding;
            }

            $html .= '<div class="findings"><h2>Vulnerability Findings</h2>';
            
            // Check if there are any findings
            $totalFindings = count($findings);
            if ($totalFindings === 0) {
                $html .= '<div style="text-align: center; padding: 40px; background: rgba(0,200,0,0.1); border-radius: 8px; border: 1px solid rgba(0,200,0,0.3);">';
                $html .= '<h3 style="color: #00cc00; margin: 0 0 10px 0;">✓ No Vulnerabilities Found</h3>';
                $html .= '<p style="color: #999; margin: 0;">The scan completed successfully and no security issues were detected.</p>';
                $html .= '</div>';
            } else {
                // Display findings grouped by severity
                foreach ($groupedFindings as $severity => $severityFindings) {
                    $severityClass = 'severity-' . strtolower($severity);
                    $severityColor = '';
                    $findingCount = count($severityFindings);
                    
                    switch ($severity) {
                        case 'CRITICAL': $severityColor = '#ff0000'; break;
                        case 'HIGH': $severityColor = '#ff6600'; break;
                        case 'MEDIUM': $severityColor = '#ffcc00'; break;
                        case 'LOW': $severityColor = '#00cc00'; break;
                        case 'INFO': $severityColor = '#0066cc'; break;
                        default: $severityColor = '#666666'; break;
                    }
                    
                    $html .= <<<HTML
                    <div class="severity-section">
                        <div class="severity-header" style="background: {$severityColor}; color: #ff0000; padding: 12px 15px; border-radius: 6px; margin-bottom: 15px; font-weight: bold; font-size: 1.1rem;">
                            {$severity} SEVERITY ({$findingCount} findings)
                        </div>
HTML;
                    
                    foreach ($severityFindings as $finding) {
                        $evidenceHtml = nl2br(htmlspecialchars($finding['evidence']));
                        $recommendationHtml = nl2br(htmlspecialchars($finding['recommendation']));
                        
                        $html .= <<<HTML
                        <div class="finding-item">
                            <div class="finding-header {$severityClass}">
                                <span>{$finding['vuln_type']}</span>
                            </div>
                            <div class="finding-body">
                                <h4 style="margin: 0 0 10px 0; color: #000000;">{$finding['title']}</h4>
                                <p><strong>URL:</strong> {$finding['url']}</p>
                                <p><strong>Evidence:</strong> {$evidenceHtml}</p>
                                <p><strong>Recommendation:</strong> {$recommendationHtml}</p>
                            </div>
                        </div>
HTML;
                    }
                    
                    $html .= '</div>';
                }
            }
            
            $html .= '</div>';
        }

        $html .= <<<HTML
        </div>
        <div class="footer">
            <p>Generated by Wolf2XFinder - Cyber Wolf Team</p>
            <p>www.cyberwolf.pro | Report any issues to support</p>
        </div>
    </div>
</body>
</html>
HTML;
        return $html;
    } else {
        // Plain text format
        $text = "WOLF2XFINDER SECURITY SCAN REPORT\n";
        $text .= "================================\n\n";
        $text .= "Generated by: {$senderName}\n";
        $text .= "Scan Date: {$scan['generated_at']}\n\n";

        if ($customMessage) {
            $text .= "NOTE: {$customMessage}\n\n";
        }

        $text .= "SCAN DETAILS\n";
        $text .= "------------\n";
        $text .= "Target: {$scan['target']}\n";
        $text .= "Pages: {$scan['total_pages']}\n";
        $text .= "Total Findings: " . count($findings) . "\n\n";

        if (!empty($findings)) {
            $text .= "VULNERABILITY FINDINGS\n";
            $text .= "----------------------\n\n";
            foreach ($findings as $finding) {
                $text .= "[{$finding['severity']}] {$finding['vuln_type']}\n";
                $text .= "Title: {$finding['title']}\n";
                $text .= "URL: {$finding['url']}\n";
                $text .= "Evidence: {$finding['evidence']}\n";
                $text .= "Recommendation: {$finding['recommendation']}\n";
                $text .= "---\n\n";
            }
        }

        $text .= "\nGenerated by Wolf2XFinder - Cyber Wolf Team\n";
        $text .= "www.cyberwolf.pro\n";
        return $text;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Send Report - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }

      .page-title {
        font-size: 1.5rem;
      }

      .form-section {
        padding: 20px;
      }

      .form-row {
        grid-template-columns: 1fr;
      }

      .radio-group {
        flex-direction: column;
        gap: 10px;
      }
    }

    /* Page specific styles */
    .container { max-width: 900px; padding: 0; }
    .page-title { font-size: 2rem; color: #00E5FF; margin-bottom: 10px; font-family: 'HeaderFont', 'Orbitron', sans-serif; font-weight: normal; text-shadow: 0 0 20px rgba(0, 229, 255, 0.3); text-transform: uppercase; letter-spacing: 2px; }
    .page-subtitle { color: #8A93A6; margin-bottom: 30px; }
    .form-section { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; padding: 30px; margin-bottom: 20px; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4); }
    .section-title { font-size: 1.3rem; color: #00E5FF; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(0, 229, 255, 0.2); font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; margin-bottom: 10px; color: #E6EAF2; font-weight: 500; letter-spacing: 0.5px; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 16px; border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; background: rgba(18, 24, 42, 0.8); color: #E6EAF2; font-size: 0.95rem; transition: all 0.3s ease; font-family: 'TruenoLight', 'Inter', sans-serif; }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #00E5FF; box-shadow: 0 0 15px rgba(0, 229, 255, 0.2); }
    .form-group textarea { min-height: 120px; resize: vertical; }
    .checkbox-group { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
    .checkbox-group input[type="checkbox"] { width: 20px; height: 20px; accent-color: #00E5FF; }
    .radio-group { display: flex; gap: 24px; margin-bottom: 24px; }
    .radio-group label { display: flex; align-items: center; gap: 10px; cursor: pointer; color: #E6EAF2; }
    .scan-list { max-height: 200px; overflow-y: auto; border: 1px solid rgba(0, 229, 255, 0.15); border-radius: 0; background: rgba(18, 24, 42, 0.6); }
    .scan-item { padding: 14px 16px; border-bottom: 1px solid rgba(0, 229, 255, 0.1); cursor: pointer; transition: all 0.3s ease; }
    .scan-item:hover { background: rgba(0, 229, 255, 0.08); border-left: 3px solid rgba(0, 229, 255, 0.5); }
    .scan-item.selected { background: rgba(95, 209, 200, 0.15); border-left: 3px solid #5FD1C8; }
    .scan-item:last-child { border-bottom: none; }
    .scan-target { font-weight: 600; color: #5FD1C8; }
    .scan-date { font-size: 0.85rem; color: #8A93A6; }
    .btn-send { width: auto; padding: 14px 40px; font-size: 16px; background: linear-gradient(135deg, #5FD1C8 0%, #4ECDC4 100%); border: none; border-radius: 0; color: #0B0F1A; font-weight: 600; cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); letter-spacing: 0.3px; box-shadow: 0 4px 20px rgba(95, 209, 200, 0.25); font-family: 'TruenoLight', 'Inter', sans-serif; display: block; margin: 0 auto; }
    .btn-send:hover { background: linear-gradient(135deg, #6FE5DC 0%, #5FD1C8 100%); transform: translateY(-2px); box-shadow: 0 6px 30px rgba(95, 209, 200, 0.35); }
    .btn-send:disabled { opacity: 0.5; cursor: not-allowed; transform: none; background: #8A93A6; box-shadow: none; }
    .alert { padding: 16px 20px; border-radius: 0; margin-bottom: 24px; font-weight: 500; }
    .alert-success { background: rgba(61, 220, 132, 0.1); border: 1px solid rgba(61, 220, 132, 0.3); color: #3ddc84; }
    .alert-error { background: rgba(255, 77, 109, 0.1); border: 1px solid rgba(255, 77, 109, 0.3); color: #FF4D6D; }
    .alert-warning { background: rgba(255, 176, 32, 0.1); border: 1px solid rgba(255, 176, 32, 0.3); color: #ffb020; }
    @media (max-width: 768px) {
      .form-row { grid-template-columns: 1fr; }
      .radio-group { flex-direction: column; gap: 12px; }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
    <h1 class="page-title">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
        <rect width="20" height="16" x="2" y="4" rx="2"/>
        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
      </svg>
      Send Scan Report
    </h1>
    <p class="page-subtitle">Send security scan reports to clients or team members via email</p>

    <?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <!-- Select Scan -->
      <div class="form-section">
        <div class="section-title">1. Select Scan Report</div>
        <?php if (empty($scans)): ?>
          <p style="color: #666;">No scans available. <a href="index.php" style="color: #A37D37;">Run a scan first</a>.</p>
        <?php else: ?>
          <div class="scan-list">
            <?php foreach ($scans as $scan): ?>
            <div class="scan-item" onclick="selectScan(this, <?php echo $scan['id']; ?>)">
              <div class="scan-target"><?php echo htmlspecialchars($scan['target']); ?></div>
              <div class="scan-date"><?php echo date('M d, Y H:i', strtotime($scan['created_at'])); ?> • <?php echo $scan['total_pages']; ?> pages</div>
              <input type="radio" name="scan_id" value="<?php echo $scan['id']; ?>" style="display: none;" required>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Recipient Info -->
      <div class="form-section">
        <div class="section-title">2. Recipient Information</div>
        <div class="form-row">
          <div class="form-group">
            <label for="recipient_email">Recipient Email *</label>
            <input type="email" id="recipient_email" name="recipient_email" required placeholder="client@example.com" />
          </div>
          <div class="form-group">
            <label for="recipient_name">Recipient Name</label>
            <input type="text" id="recipient_name" name="recipient_name" placeholder="Client Name" />
          </div>
        </div>
      </div>

      <!-- Email Settings -->
      <div class="form-section">
        <div class="section-title">3. Email Settings</div>
        <div class="form-group">
          <label for="subject">Email Subject</label>
          <input type="text" id="subject" name="subject" value="Wolf2XFinder Security Scan Report" />
        </div>

        <div class="form-group">
          <label>Report Format</label>
          <div class="radio-group">
            <label><input type="radio" name="format" value="html" checked /> HTML (Formatted)</label>
            <label><input type="radio" name="format" value="text" /> Plain Text</label>
          </div>
        </div>

        <div class="checkbox-group">
          <input type="checkbox" id="include_findings" name="include_findings" checked />
          <label for="include_findings">Include detailed findings in the report</label>
        </div>

        <div class="form-group">
          <label for="message">Custom Message (Optional)</label>
          <textarea id="message" name="message" placeholder="Add a personal message to the recipient..."></textarea>
        </div>
      </div>

      <button type="submit" class="btn-send" <?php echo empty($scans) ? 'disabled' : ''; ?>>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
          <rect width="20" height="16" x="2" y="4" rx="2"/>
          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
        </svg>
        Send Report
      </button>
    </form>
    </main>
    </div>
  </div>

  <script>
    function selectScan(element, scanId) {
      // Remove selected class from all items
      document.querySelectorAll('.scan-item').forEach(item => {
        item.classList.remove('selected');
      });

      // Add selected class to clicked item
      element.classList.add('selected');

      // Check the radio button
      const radio = element.querySelector('input[type="radio"]');
      radio.checked = true;
    }
  </script>
</body>
</html>
