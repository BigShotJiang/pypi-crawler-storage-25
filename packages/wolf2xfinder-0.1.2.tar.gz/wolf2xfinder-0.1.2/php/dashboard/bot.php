<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Handle API requests
$response = '';
$error = '';
$chatHistory = [];
$action = $_POST['action'] ?? 'chat';
$isAjax = isset($_POST['ajax']) && $_POST['ajax'] === 'true';

// Load saved settings
$savedProvider = $_SESSION['bot_provider'] ?? 'openai';
$savedApiKey = $_SESSION['bot_api_key'] ?? '';
$savedModel = $_SESSION['bot_model'] ?? 'gpt-4';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $provider = $_POST['provider'] ?? $savedProvider;
    $apiKey = $_POST['api_key'] ?? $savedApiKey;
    $model = $_POST['model'] ?? $savedModel;
    $message = $_POST['message'] ?? '';
    
    // Save settings action
    if ($action === 'save_settings') {
        $_SESSION['bot_provider'] = $provider;
        $_SESSION['bot_api_key'] = $apiKey;
        $_SESSION['bot_model'] = $model;
        $savedProvider = $provider;
        $savedApiKey = $apiKey;
        $savedModel = $model;
        $success = 'Settings saved successfully!';
        $chatHistory = $_SESSION['chat_history'] ?? [];
        
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => $success]);
            exit;
        }
    }
    // Clear chat action
    elseif ($action === 'clear_chat') {
        $_SESSION['chat_history'] = [];
        $chatHistory = [];
        
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => 'Chat history cleared']);
            exit;
        }
    }
    // Chat action
    else {
        // Use saved values if not provided
        if (empty($apiKey)) {
            $apiKey = $savedApiKey;
        }
        if (empty($model)) {
            $model = $savedModel;
        }
        if (empty($provider)) {
            $provider = $savedProvider;
        }
        
        if (empty($apiKey)) {
            $error = 'Please enter and save an API key for the selected provider.';
        } elseif (empty($model)) {
            $error = 'Please enter and save a model name.';
        } elseif (empty($message)) {
            $error = 'Please enter a message.';
        } else {
            // Call the appropriate API based on provider
            try {
                switch ($provider) {
                    case 'gemini':
                        $response = callGeminiAPI($apiKey, $model, $message);
                        break;
                    case 'openrouter':
                        $response = callOpenRouterAPI($apiKey, $model, $message);
                        break;
                    case 'openai':
                        $response = callOpenAIAPI($apiKey, $model, $message);
                        break;
                    case 'ollama':
                        $response = callOllamaAPI($apiKey, $model, $message);
                        break;
                    default:
                        $error = 'Invalid provider selected.';
                }
            } catch (Exception $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
        
        // Store chat history in session
        if (!empty($message) && !empty($response)) {
            if (!isset($_SESSION['chat_history'])) {
                $_SESSION['chat_history'] = [];
            }
            $_SESSION['chat_history'][] = [
                'user' => $message,
                'assistant' => $response,
                'provider' => $provider,
                'model' => $model,
                'timestamp' => date('Y-m-d H:i:s')
            ];
            // Keep only last 20 messages
            if (count($_SESSION['chat_history']) > 20) {
                $_SESSION['chat_history'] = array_slice($_SESSION['chat_history'], -20);
            }
        }
        
        $chatHistory = $_SESSION['chat_history'] ?? [];
        
        if ($isAjax) {
            if ($error) {
                echo json_encode(['success' => false, 'error' => $error]);
            } else {
                echo json_encode(['success' => true, 'response' => $response, 'provider' => $provider, 'model' => $model, 'timestamp' => date('Y-m-d H:i:s')]);
            }
            exit;
        }
    }
} else {
    $chatHistory = $_SESSION['chat_history'] ?? [];
}

function callGeminiAPI($apiKey, $model, $message) {
    $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";
    
    $data = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $message]
                ]
            ]
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        throw new Exception("API request failed with HTTP code: {$httpCode}");
    }
    
    $response = json_decode($result, true);
    if (isset($response['candidates'][0]['content']['parts'][0]['text'])) {
        return $response['candidates'][0]['content']['parts'][0]['text'];
    }
    throw new Exception('Invalid response format from Gemini API.');
}

function callOpenRouterAPI($apiKey, $model, $message) {
    $url = "https://openrouter.ai/api/v1/chat/completions";
    
    $data = [
        'model' => $model,
        'messages' => [
            ['role' => 'user', 'content' => $message]
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        throw new Exception("API request failed with HTTP code: {$httpCode}");
    }
    
    $response = json_decode($result, true);
    if (isset($response['choices'][0]['message']['content'])) {
        return $response['choices'][0]['message']['content'];
    }
    throw new Exception('Invalid response format from OpenRouter API.');
}

function callOpenAIAPI($apiKey, $model, $message) {
    $url = "https://api.openai.com/v1/chat/completions";
    
    $data = [
        'model' => $model,
        'messages' => [
            ['role' => 'user', 'content' => $message]
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        throw new Exception("API request failed with HTTP code: {$httpCode}");
    }
    
    $response = json_decode($result, true);
    if (isset($response['choices'][0]['message']['content'])) {
        return $response['choices'][0]['message']['content'];
    }
    throw new Exception('Invalid response format from OpenAI API.');
}

function callOllamaAPI($baseUrl, $model, $message) {
    $url = rtrim($baseUrl, '/') . "/api/chat";
    
    $data = [
        'model' => $model,
        'messages' => [
            ['role' => 'user', 'content' => $message]
        ],
        'stream' => false
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        throw new Exception("API request failed with HTTP code: {$httpCode}");
    }
    
    $response = json_decode($result, true);
    if (isset($response['message']['content'])) {
        return $response['message']['content'];
    }
    throw new Exception('Invalid response format from Ollama API.');
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AI Chat Bot - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }
    }

    /* Page specific styles */
    .container { max-width: 1200px; padding: 0; }
    .page-title { font-size: 2rem; color: #00E5FF; margin-bottom: 10px; font-family: 'HeaderFont', 'Orbitron', sans-serif; font-weight: normal; text-shadow: 0 0 20px rgba(0, 229, 255, 0.3); text-transform: uppercase; letter-spacing: 2px; }
    .page-subtitle { color: #8A93A6; margin-bottom: 30px; }
    .form-section { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; padding: 30px; margin-bottom: 20px; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4); }
    .section-title { font-size: 1.3rem; color: #00E5FF; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(0, 229, 255, 0.2); font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; margin-bottom: 10px; color: #E6EAF2; font-weight: 500; letter-spacing: 0.5px; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 16px; border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; background: rgba(18, 24, 42, 0.8); color: #E6EAF2; font-size: 0.95rem; transition: all 0.3s ease; font-family: 'TruenoLight', 'Inter', sans-serif; }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #00E5FF; box-shadow: 0 0 15px rgba(0, 229, 255, 0.2); }
    .form-group textarea { min-height: 120px; resize: vertical; }
    .btn-send { width: auto; padding: 14px 40px; font-size: 16px; background: linear-gradient(135deg, #5FD1C8 0%, #4ECDC4 100%); border: none; border-radius: 0; color: #0B0F1A; font-weight: 600; cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); letter-spacing: 0.3px; box-shadow: 0 4px 20px rgba(95, 209, 200, 0.25); font-family: 'TruenoLight', 'Inter', sans-serif; display: block; margin: 0 auto; }
    .btn-send:hover { background: linear-gradient(135deg, #6FE5DC 0%, #5FD1C8 100%); transform: translateY(-2px); box-shadow: 0 6px 30px rgba(95, 209, 200, 0.35); }
    .btn-clear { background: linear-gradient(135deg, #FF4D6D 0%, #FF6B8A 100%); border: none; border-radius: 0; color: #fff; font-weight: 600; cursor: pointer; transition: all 0.3s ease; padding: 8px 16px; font-size: 14px; }
    .btn-clear:hover { background: linear-gradient(135deg, #FF6B8A 0%, #FF4D6D 100%); }
    .alert { padding: 16px 20px; border-radius: 0; margin-bottom: 24px; font-weight: 500; }
    .alert-success { background: rgba(61, 220, 132, 0.1); border: 1px solid rgba(61, 220, 132, 0.3); color: #3ddc84; }
    .alert-error { background: rgba(255, 77, 109, 0.1); border: 1px solid rgba(255, 77, 109, 0.3); color: #FF4D6D; }
    
    .chat-container {
      display: flex;
      gap: 20px;
      margin-top: 20px;
    }

    .chat-config {
      width: 350px;
      flex-shrink: 0;
    }

    .chat-main {
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .chat-messages {
      flex: 1;
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 20px;
      max-height: 500px;
      overflow-y: auto;
      margin-bottom: 20px;
    }

    .message {
      margin-bottom: 20px;
      padding: 15px;
      border-radius: 0;
      max-width: 80%;
    }

    .message.user {
      background: rgba(95, 209, 200, 0.15);
      border: 1px solid rgba(95, 209, 200, 0.3);
      margin-left: auto;
    }

    .message.assistant {
      background: rgba(0, 229, 255, 0.1);
      border: 1px solid rgba(0, 229, 255, 0.2);
      margin-right: auto;
    }

    .message-header {
      font-size: 0.8rem;
      color: #8A93A6;
      margin-bottom: 8px;
    }

    .message-content {
      color: #E6EAF2;
      white-space: pre-wrap;
      line-height: 1.6;
    }

    .chat-input {
      display: flex;
      gap: 15px;
      align-items: flex-end;
    }

    .chat-input textarea {
      flex: 1;
      min-height: 80px;
      padding: 16px;
      color: #E6EAF2;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      font-size: 0.95rem;
      line-height: 1.5;
      resize: vertical;
      transition: all 0.3s ease;
    }

    .chat-input textarea:focus {
      outline: none;
      border-color: #00E5FF;
      box-shadow: 0 0 15px rgba(0, 229, 255, 0.2);
    }

    .chat-input textarea::placeholder {
      color: #8A93A6;
    }

    .chat-input button {
      align-self: flex-end;
      height: 80px;
      min-width: 120px;
    }

    .loading-indicator {
      display: none;
      text-align: center;
      padding: 20px;
      color: #8A93A6;
    }

    .loading-indicator.active {
      display: block;
    }

    .loading-dots {
      display: inline-flex;
      gap: 8px;
      align-items: center;
    }

    .loading-dot {
      width: 12px;
      height: 12px;
      background: #00E5FF;
      border-radius: 50%;
      animation: loadingBounce 1.4s infinite ease-in-out both;
    }

    .loading-dot:nth-child(1) {
      animation-delay: -0.32s;
    }

    .loading-dot:nth-child(2) {
      animation-delay: -0.16s;
    }

    @keyframes loadingBounce {
      0%, 80%, 100% {
        transform: scale(0);
        opacity: 0.5;
      }
      40% {
        transform: scale(1);
        opacity: 1;
      }
    }

    .loading-text {
      margin-top: 10px;
      font-size: 0.9rem;
      color: #8A93A6;
    }

    .model-suggestions {
      font-size: 0.8rem;
      color: #8A93A6;
      margin-top: 5px;
    }

    @media (max-width: 768px) {
      .chat-container {
        flex-direction: column;
      }
      .chat-config {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
    <h1 class="page-title">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      AI Chat Bot
    </h1>
    <p class="page-subtitle">Chat with AI models using multiple providers (Gemini, OpenRouter, OpenAI, Ollama)</p>

    <?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <input type="hidden" name="action" id="formAction" value="chat">
      <div class="chat-container">
        <!-- Configuration Panel -->
        <div class="form-section chat-config">
          <div class="section-title">Configuration</div>
          
          <div class="form-group">
            <label for="provider">AI Provider</label>
            <select id="provider" name="provider" onchange="updateModelSuggestions()">
              <option value="openai" <?php echo $savedProvider === 'openai' ? 'selected' : ''; ?>>OpenAI</option>
              <option value="gemini" <?php echo $savedProvider === 'gemini' ? 'selected' : ''; ?>>Google Gemini</option>
              <option value="openrouter" <?php echo $savedProvider === 'openrouter' ? 'selected' : ''; ?>>OpenRouter</option>
              <option value="ollama" <?php echo $savedProvider === 'ollama' ? 'selected' : ''; ?>>Ollama</option>
            </select>
          </div>

          <div class="form-group">
            <label for="api_key">API Key / Base URL</label>
            <input type="password" id="api_key" name="api_key" placeholder="Enter API key or Ollama base URL" value="<?php echo htmlspecialchars($savedApiKey); ?>" />
            <div class="model-suggestions" id="apiKeyHint">OpenAI API Key</div>
          </div>

          <div class="form-group">
            <label for="model">Model Name</label>
            <input type="text" id="model" name="model" placeholder="e.g., gpt-4, gemini-pro" value="<?php echo htmlspecialchars($savedModel); ?>" />
            <div class="model-suggestions" id="modelSuggestions">Examples: gpt-4, gpt-3.5-turbo</div>
          </div>

          <button type="button" onclick="saveSettings()" class="btn-send" style="width: 100%; margin: 10px 0; background: linear-gradient(135deg, #6C63FF 0%, #5FD1C8 100%);">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17 21 17 13 7 13 7 21"/>
              <polyline points="7 3 7 8 15 8"/>
            </svg>
            Save Settings
          </button>

          <button type="button" onclick="clearChat()" class="btn-clear" style="width: 100%; margin-top: 10px;">
            Clear Chat History
          </button>
        </div>

        <!-- Chat Panel -->
        <div class="chat-main">
          <div class="chat-messages" id="chatMessages">
            <?php if (!empty($chatHistory)): ?>
              <?php foreach ($chatHistory as $msg): ?>
                <div class="message user">
                  <div class="message-header">You • <?php echo htmlspecialchars($msg['timestamp']); ?></div>
                  <div class="message-content"><?php echo htmlspecialchars($msg['user']); ?></div>
                </div>
                <div class="message assistant">
                  <div class="message-header"><?php echo htmlspecialchars($msg['provider']); ?> (<?php echo htmlspecialchars($msg['model']); ?>) • <?php echo htmlspecialchars($msg['timestamp']); ?></div>
                  <div class="message-content"><?php echo htmlspecialchars($msg['assistant']); ?></div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div style="text-align: center; color: #8A93A6; padding: 40px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-bottom: 15px;">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <p>Start a conversation by typing a message below</p>
              </div>
            <?php endif; ?>
            
            <div class="loading-indicator" id="loadingIndicator">
              <div class="loading-dots">
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
                <div class="loading-dot"></div>
              </div>
              <div class="loading-text">AI is thinking...</div>
            </div>
          </div>

          <div class="chat-input">
            <textarea id="message" name="message" placeholder="Type your message here... (Press Enter to send, Shift+Enter for new line)"></textarea>
            <button type="submit" class="btn-send" id="sendButton">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
              </svg>
              Send
            </button>
          </div>
        </div>
      </div>
    </form>
    </main>
    </div>
  </div>

  <script>
    function updateModelSuggestions() {
      const provider = document.getElementById('provider').value;
      const modelSuggestions = document.getElementById('modelSuggestions');
      const apiKeyHint = document.getElementById('apiKeyHint');
      
      const suggestions = {
        openai: {
          models: 'Examples: gpt-4, gpt-3.5-turbo, gpt-4-turbo-preview',
          hint: 'OpenAI API Key'
        },
        gemini: {
          models: 'Examples: gemini-pro, gemini-pro-vision',
          hint: 'Gemini API Key'
        },
        openrouter: {
          models: 'Examples: openai/gpt-4, anthropic/claude-3-opus',
          hint: 'OpenRouter API Key'
        },
        ollama: {
          models: 'Examples: llama2, mistral, codellama',
          hint: 'Ollama Base URL (e.g., http://localhost:11434)'
        }
      };
      
      modelSuggestions.textContent = suggestions[provider].models;
      apiKeyHint.textContent = suggestions[provider].hint;
    }

    function saveSettings() {
      const formData = new FormData();
      formData.append('action', 'save_settings');
      formData.append('provider', document.getElementById('provider').value);
      formData.append('api_key', document.getElementById('api_key').value);
      formData.append('model', document.getElementById('model').value);
      formData.append('ajax', 'true');
      
      fetch('bot.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert(data.message);
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
    }

    function clearChat() {
      if (confirm('Are you sure you want to clear chat history?')) {
        const formData = new FormData();
        formData.append('action', 'clear_chat');
        formData.append('ajax', 'true');
        
        fetch('bot.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            document.getElementById('chatMessages').innerHTML = `
              <div style="text-align: center; color: #8A93A6; padding: 40px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-bottom: 15px;">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <p>Start a conversation by typing a message below</p>
              </div>
            `;
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
      }
    }

    function sendMessage() {
      const messageInput = document.getElementById('message');
      const message = messageInput.value.trim();
      
      if (message === '') return;
      
      const formData = new FormData();
      formData.append('action', 'chat');
      formData.append('provider', document.getElementById('provider').value);
      formData.append('api_key', document.getElementById('api_key').value);
      formData.append('model', document.getElementById('model').value);
      formData.append('message', message);
      formData.append('ajax', 'true');
      
      showLoading();
      
      // Add user message to chat
      addMessage('user', message);
      messageInput.value = '';
      
      fetch('bot.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        hideLoading();
        if (data.success) {
          addMessage('assistant', data.response, data.provider, data.model, data.timestamp);
        } else {
          addMessage('assistant', 'Error: ' + data.error, 'System', '', '');
        }
      })
      .catch(error => {
        hideLoading();
        addMessage('assistant', 'Error: Failed to connect to server', 'System', '', '');
        console.error('Error:', error);
      });
    }

    function addMessage(type, content, provider = '', model = '', timestamp = '') {
      const chatMessages = document.getElementById('chatMessages');
      const loadingIndicator = document.getElementById('loadingIndicator');
      
      // Remove placeholder if exists
      const placeholder = chatMessages.querySelector('div[style*="text-align: center"]');
      if (placeholder) {
        placeholder.remove();
      }
      
      const messageDiv = document.createElement('div');
      messageDiv.className = 'message ' + type;
      
      if (type === 'user') {
        messageDiv.innerHTML = `
          <div class="message-header">You • ${new Date().toLocaleTimeString()}</div>
          <div class="message-content">${escapeHtml(content)}</div>
        `;
      } else {
        messageDiv.innerHTML = `
          <div class="message-header">${escapeHtml(provider)} (${escapeHtml(model)}) • ${timestamp || new Date().toLocaleTimeString()}</div>
          <div class="message-content">${escapeHtml(content)}</div>
        `;
      }
      
      // Insert before loading indicator
      chatMessages.insertBefore(messageDiv, loadingIndicator);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function showLoading() {
      const loadingIndicator = document.getElementById('loadingIndicator');
      const sendButton = document.getElementById('sendButton');
      const messageInput = document.getElementById('message');
      
      if (loadingIndicator) {
        loadingIndicator.classList.add('active');
      }
      if (sendButton) {
        sendButton.disabled = true;
        sendButton.style.opacity = '0.5';
        sendButton.style.cursor = 'not-allowed';
      }
      if (messageInput) {
        messageInput.disabled = true;
      }
    }

    function hideLoading() {
      const loadingIndicator = document.getElementById('loadingIndicator');
      const sendButton = document.getElementById('sendButton');
      const messageInput = document.getElementById('message');
      
      if (loadingIndicator) {
        loadingIndicator.classList.remove('active');
      }
      if (sendButton) {
        sendButton.disabled = false;
        sendButton.style.opacity = '1';
        sendButton.style.cursor = 'pointer';
      }
      if (messageInput) {
        messageInput.disabled = false;
        messageInput.focus();
      }
    }

    // Handle Enter key to send message
    document.addEventListener('DOMContentLoaded', function() {
      const messageInput = document.getElementById('message');
      const sendButton = document.getElementById('sendButton');
      
      if (messageInput) {
        messageInput.addEventListener('keydown', function(e) {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
          }
        });
      }
      
      if (sendButton) {
        sendButton.addEventListener('click', function(e) {
          e.preventDefault();
          sendMessage();
        });
      }
    });

    // Initialize suggestions
    updateModelSuggestions();

    // Scroll to bottom of chat
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  </script>
</body>
</html>
