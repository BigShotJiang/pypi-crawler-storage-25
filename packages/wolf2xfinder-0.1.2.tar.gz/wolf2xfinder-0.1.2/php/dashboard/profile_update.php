<?php
// Disable HTML error output for JSON API
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/firebase.php';

header('Content-Type: application/json');

// Get input
$action = $_POST['action'] ?? '';
$name = $_POST['name'] ?? '';
$removePhoto = $_POST['remove_photo'] ?? '';

if ($action !== 'update') {
    echo json_encode(['ok' => false, 'error' => 'Invalid action']);
    exit;
}

$userId = $_SESSION['user_id'];

// Validate name
if (empty($name) || trim($name) === '') {
    echo json_encode(['ok' => false, 'error' => 'Name is required']);
    exit;
}

$name = trim($name);
if (strlen($name) > 255) {
    echo json_encode(['ok' => false, 'error' => 'Name is too long (max 255 characters)']);
    exit;
}

// Database connection
$mysqli = wolf2x_db();
if ($mysqli->connect_error) {
    echo json_encode(['ok' => false, 'error' => 'Database connection failed']);
    exit;
}

$photoUrl = null;
$firebasePhotoUrl = null;

// Handle photo upload
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['photo'];
    
    // Validate file size (2MB max)
    if ($file['size'] > 2 * 1024 * 1024) {
        echo json_encode(['ok' => false, 'error' => 'Photo must be less than 2MB']);
        $mysqli->close();
        exit;
    }
    
    // Validate file type
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        echo json_encode(['ok' => false, 'error' => 'Only JPG, PNG, and GIF images are allowed']);
        $mysqli->close();
        exit;
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'profile_' . $userId . '_' . time() . '.' . $extension;
    $uploadDir = __DIR__ . '/../uploads/profile/';
    
    // Create upload directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $uploadPath = $uploadDir . $filename;
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(['ok' => false, 'error' => 'Failed to upload photo']);
        $mysqli->close();
        exit;
    }
    
    // Upload to Firebase Storage if enabled
    if (FirebaseHelper::isEnabled()) {
        $storagePath = 'profile/' . $userId . '/' . $filename;
        $firebasePhotoUrl = FirebaseHelper::uploadFile($uploadPath, $storagePath, $mimeType);
        if ($firebasePhotoUrl) {
            $photoUrl = $firebasePhotoUrl;
        } else {
            // Fallback to local storage if Firebase fails
            $photoUrl = '../uploads/profile/' . $filename;
        }
    } else {
        // Use local storage
        $photoUrl = '../uploads/profile/' . $filename;
    }
    
    // Delete old photo if exists
    $stmt = $mysqli->prepare('SELECT photo_url FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $oldUser = $result->fetch_assoc();
    $stmt->close();
    
    if ($oldUser && $oldUser['photo_url']) {
        $oldPhotoPath = __DIR__ . '/../' . $oldUser['photo_url'];
        if (file_exists($oldPhotoPath) && strpos($oldPhotoPath, 'uploads/profile/') !== false) {
            unlink($oldPhotoPath);
        }
        // Delete from Firebase Storage if it was a Firebase URL
        if (FirebaseHelper::isEnabled() && strpos($oldUser['photo_url'], 'firebasestorage') !== false) {
            // Extract storage path from Firebase URL and delete
            $oldStoragePath = 'profile/' . $userId . '/' . basename($oldPhotoPath);
            FirebaseHelper::deleteFile($oldStoragePath);
        }
    }
}

// Handle photo removal
if ($removePhoto === '1') {
    $photoUrl = '';
    
    // Delete existing photo file
    $stmt = $mysqli->prepare('SELECT photo_url FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $oldUser = $result->fetch_assoc();
    $stmt->close();
    
    if ($oldUser && $oldUser['photo_url']) {
        $oldPhotoPath = __DIR__ . '/../' . $oldUser['photo_url'];
        if (file_exists($oldPhotoPath) && strpos($oldPhotoPath, 'uploads/profile/') !== false) {
            unlink($oldPhotoPath);
        }
    }
}

// Update database
if ($photoUrl !== null) {
    // Update both name and photo
    $stmt = $mysqli->prepare('UPDATE users SET name = ?, photo_url = ? WHERE id = ?');
    $stmt->bind_param('ssi', $name, $photoUrl, $userId);
} else {
    // Update only name
    $stmt = $mysqli->prepare('UPDATE users SET name = ? WHERE id = ?');
    $stmt->bind_param('si', $name, $userId);
}

if (!$stmt) {
    echo json_encode(['ok' => false, 'error' => 'Database error: ' . $mysqli->error]);
    $mysqli->close();
    exit;
}

if ($stmt->execute()) {
    // Update session
    $_SESSION['user_name'] = $name;
    if ($photoUrl !== null) {
        $_SESSION['user_photo'] = $photoUrl;
    }
    
    // Sync user data to Firestore if enabled
    if (FirebaseHelper::isEnabled()) {
        // Fetch current 2FA status from database
        $stmt2fa = $mysqli->prepare('SELECT twofa_enabled, twofa_email, twofa_secret FROM users WHERE id = ?');
        $stmt2fa->bind_param('i', $userId);
        $stmt2fa->execute();
        $result2fa = $stmt2fa->get_result();
        $user2FA = $result2fa->fetch_assoc();
        $stmt2fa->close();

        $userData = [
            'email' => $_SESSION['user_email'] ?? '',
            'name' => $name,
            'photo_url' => $photoUrl ?? ($_SESSION['user_photo'] ?? ''),
            'provider' => 'email',
            'role' => $_SESSION['user_role'] ?? 'user',
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => date('Y-m-d H:i:s'),
            'profile_updated_at' => date('Y-m-d H:i:s')
        ];

        // Include 2FA data if available
        if ($user2FA) {
            $userData['two_fa'] = [
                'enabled' => (bool)($user2FA['twofa_enabled'] ?? false),
                'email' => $user2FA['twofa_email'] ?? '',
                'setup_completed' => !empty($user2FA['twofa_secret']),
                'last_updated' => date('Y-m-d H:i:s')
            ];
            $userData['security'] = [
                'two_fa_status' => ($user2FA['twofa_enabled'] ?? false) ? 'enabled' : 'disabled',
                'email_verification_status' => ($user2FA['twofa_enabled'] ?? false) ? '2fa_verified' : 'primary_only'
            ];
        }

        // Include email verification tracking
        $userData['email_verification'] = [
            'primary_email' => $_SESSION['user_email'] ?? '',
            'primary_verified' => true,
            '2fa_email' => $user2FA['twofa_email'] ?? '',
            '2fa_email_verified' => (bool)($user2FA['twofa_enabled'] ?? false)
        ];

        FirebaseHelper::syncUserToFirestore($userId, $userData);

        // Log profile update to audit collection
        $auditData = [
            'user_id' => $userId,
            'action' => 'profile_update',
            'changes' => [
                'name' => $name,
                'photo_updated' => $photoUrl !== null
            ],
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'timestamp' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s')
        ];
        FirebaseHelper::setDocument('profile_audit_logs', null, $auditData);
    }

    echo json_encode([
        'ok' => true,
        'name' => $name,
        'photo_url' => $photoUrl
    ]);
} else {
    echo json_encode(['ok' => false, 'error' => 'Failed to update profile: ' . $stmt->error]);
}

$stmt->close();
$mysqli->close();
