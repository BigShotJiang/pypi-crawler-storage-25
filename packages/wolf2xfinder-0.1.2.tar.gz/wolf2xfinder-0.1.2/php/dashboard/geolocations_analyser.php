<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Handle API requests
$geoData = null;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['target'])) {
    $target = trim($_POST['target']);
    
    if (empty($target)) {
        $error = 'Please enter a URL, IP address, or domain.';
    } else {
        // Extract domain/hostname from URL if provided
        $hostname = $target;
        if (filter_var($target, FILTER_VALIDATE_URL)) {
            $hostname = parse_url($target, PHP_URL_HOST);
        }
        
        // Use ip-api.com for geolocation (free, no API key required)
        $apiUrl = "http://ip-api.com/json/" . urlencode($hostname) . "?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response) {
            $data = json_decode($response, true);
            
            if ($data && isset($data['status']) && $data['status'] === 'success') {
                $geoData = $data;
                $success = 'Geolocation data retrieved successfully!';
            } else {
                $error = $data['message'] ?? 'Failed to retrieve geolocation data. Please try again.';
            }
        } else {
            $error = 'Unable to connect to geolocation service. Please check your internet connection.';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Geolocation Analyzer - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }

      .page-title {
        font-size: 1.5rem;
      }

      .geo-grid {
        grid-template-columns: 1fr;
      }
    }

    /* Page specific styles */
    .container { max-width: 1200px; padding: 0; }
    .page-title { font-size: 2rem; color: #00E5FF; margin-bottom: 10px; font-family: 'HeaderFont', 'Orbitron', sans-serif; font-weight: normal; text-shadow: 0 0 20px rgba(0, 229, 255, 0.3); text-transform: uppercase; letter-spacing: 2px; }
    .page-subtitle { color: #8A93A6; margin-bottom: 30px; }
    .form-section { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; padding: 30px; margin-bottom: 20px; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4); }
    .section-title { font-size: 1.3rem; color: #00E5FF; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(0, 229, 255, 0.2); font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; margin-bottom: 10px; color: #E6EAF2; font-weight: 500; letter-spacing: 0.5px; }
    .form-group input { width: 100%; padding: 14px 16px; border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; background: rgba(18, 24, 42, 0.8); color: #E6EAF2; font-size: 0.95rem; transition: all 0.3s ease; font-family: 'TruenoLight', 'Inter', sans-serif; }
    .form-group input:focus { outline: none; border-color: #00E5FF; box-shadow: 0 0 15px rgba(0, 229, 255, 0.2); }
    .btn-analyze { width: auto; padding: 14px 40px; font-size: 16px; background: linear-gradient(135deg, #5FD1C8 0%, #4ECDC4 100%); border: none; border-radius: 0; color: #0B0F1A; font-weight: 600; cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); letter-spacing: 0.3px; box-shadow: 0 4px 20px rgba(95, 209, 200, 0.25); font-family: 'TruenoLight', 'Inter', sans-serif; display: block; margin: 0 auto; }
    .btn-analyze:hover { background: linear-gradient(135deg, #6FE5DC 0%, #5FD1C8 100%); transform: translateY(-2px); box-shadow: 0 6px 30px rgba(95, 209, 200, 0.35); }
    .alert { padding: 16px 20px; border-radius: 0; margin-bottom: 24px; font-weight: 500; }
    .alert-success { background: rgba(61, 220, 132, 0.1); border: 1px solid rgba(61, 220, 132, 0.3); color: #3ddc84; }
    .alert-error { background: rgba(255, 77, 109, 0.1); border: 1px solid rgba(255, 77, 109, 0.3); color: #FF4D6D; }
    
    .geo-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
      margin-top: 20px;
    }

    .geo-card {
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 24px;
      transition: all 0.3s ease;
    }

    .geo-card:hover {
      border-color: rgba(0, 229, 255, 0.4);
      box-shadow: 0 4px 15px rgba(0, 229, 255, 0.1);
    }

    .geo-card-title {
      font-size: 1.1rem;
      color: #00E5FF;
      margin-bottom: 16px;
      font-weight: 600;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }

    .geo-info-row {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
    }

    .geo-info-row:last-child {
      border-bottom: none;
    }

    .geo-label {
      color: #8A93A6;
      font-size: 0.9rem;
    }

    .geo-value {
      color: #E6EAF2;
      font-weight: 500;
    }

    .map-placeholder {
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 40px;
      text-align: center;
      color: #8A93A6;
      margin-top: 20px;
    }

    #geoMap {
      height: 400px;
      width: 100%;
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      margin-top: 20px;
    }

    .map-toggle {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-top: 15px;
      padding: 10px 15px;
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .map-toggle:hover {
      background: rgba(0, 229, 255, 0.1);
      border-color: rgba(0, 229, 255, 0.4);
    }

    .map-toggle span {
      color: #E6EAF2;
      font-size: 0.9rem;
      font-weight: 500;
    }

    .toggle-switch {
      width: 50px;
      height: 26px;
      background: #8A93A6;
      border-radius: 13px;
      position: relative;
      transition: background 0.3s ease;
    }

    .toggle-switch.active {
      background: #00E5FF;
    }

    .toggle-switch::after {
      content: '';
      position: absolute;
      width: 22px;
      height: 22px;
      background: #fff;
      border-radius: 50%;
      top: 2px;
      left: 2px;
      transition: transform 0.3s ease;
    }

    .toggle-switch.active::after {
      transform: translateX(24px);
    }

    .leaflet-container {
      background: #0B0F1A;
    }

    .leaflet-popup-content-wrapper {
      background: #12182A;
      color: #E6EAF2;
      border: 1px solid rgba(0, 229, 255, 0.3);
      border-radius: 0;
    }

    .leaflet-popup-tip {
      background: #12182A;
    }

    .leaflet-popup-content {
      margin: 15px;
      font-family: 'TruenoLight', 'Inter', sans-serif;
    }

    .flag-emoji {
      font-size: 2rem;
      margin-right: 10px;
    }

    @media (max-width: 768px) {
      .geo-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
    <h1 class="page-title">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
        <path d="M2 12h20"/>
      </svg>
      Geolocation Analyzer
    </h1>
    <p class="page-subtitle">Analyze geolocation data for URLs, IP addresses, and domains</p>

    <?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="form-section">
        <div class="section-title">Enter Target</div>
        <div class="form-group">
          <label for="target">URL, IP Address, or Domain</label>
          <input type="text" id="target" name="target" required placeholder="e.g., google.com, 8.8.8.8, or https://example.com" />
        </div>
        <button type="submit" class="btn-analyze">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.35-4.35"/>
          </svg>
          Analyze
        </button>
      </div>
    </form>

    <?php if ($geoData): ?>
    <div class="form-section">
      <div class="section-title">
        <span class="flag-emoji"><?php echo getFlagEmoji($geoData['countryCode']); ?></span>
        Geolocation Results
      </div>
      
      <div class="geo-grid">
        <!-- Location Info -->
        <div class="geo-card">
          <div class="geo-card-title">Location Information</div>
          <div class="geo-info-row">
            <span class="geo-label">Country</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['country']); ?> (<?php echo htmlspecialchars($geoData['countryCode']); ?>)</span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">Region</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['regionName']); ?> (<?php echo htmlspecialchars($geoData['region']); ?>)</span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">City</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['city']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">ZIP Code</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['zip']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">Timezone</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['timezone']); ?></span>
          </div>
        </div>

        <!-- Network Info -->
        <div class="geo-card">
          <div class="geo-card-title">Network Information</div>
          <div class="geo-info-row">
            <span class="geo-label">IP Address</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['query']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">ISP</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['isp']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">Organization</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['org']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">AS Number</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['as']); ?></span>
          </div>
        </div>

        <!-- Coordinates -->
        <div class="geo-card" style="grid-column: span 2;">
          <div class="geo-card-title">Coordinates & Map</div>
          <div class="geo-info-row">
            <span class="geo-label">Latitude</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['lat']); ?></span>
          </div>
          <div class="geo-info-row">
            <span class="geo-label">Longitude</span>
            <span class="geo-value"><?php echo htmlspecialchars($geoData['lon']); ?></span>
          </div>
          <div class="map-toggle" onclick="toggleMapMode()">
            <span>Map Mode:</span>
            <div class="toggle-switch" id="mapToggle"></div>
            <span id="mapModeText">Light</span>
          </div>
          <div id="geoMap"></div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    </main>
    </div>
  </div>

  <?php
  function getFlagEmoji($countryCode) {
    $regionalOffset = 0x1F1E6;
    $letters = str_split($countryCode);
    $emoji = '';
    foreach ($letters as $letter) {
      $emoji .= mb_chr(ord(strtoupper($letter)) + $regionalOffset - 65);
    }
    return $emoji;
  }
  ?>

  <?php if ($geoData): ?>
  <script>
    // Initialize map
    const lat = <?php echo floatval($geoData['lat']); ?>;
    const lon = <?php echo floatval($geoData['lon']); ?>;
    const city = "<?php echo htmlspecialchars($geoData['city']); ?>";
    const country = "<?php echo htmlspecialchars($geoData['country']); ?>";
    const ip = "<?php echo htmlspecialchars($geoData['query']); ?>";

    const map = L.map('geoMap').setView([lat, lon], 13);

    // Tile layers
    const lightLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 20
    });

    const darkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 20
    });

    // Default to light mode
    let currentLayer = lightLayer;
    currentLayer.addTo(map);

    // Add marker
    const marker = L.marker([lat, lon]).addTo(map);
    
    // Add popup
    const popupContent = `
      <div style="min-width: 200px;">
        <strong style="color: #00E5FF; font-size: 14px;">${city}, ${country}</strong><br/>
        <span style="color: #8A93A6; font-size: 12px;">IP: ${ip}</span><br/>
        <span style="color: #8A93A6; font-size: 12px;">Lat: ${lat}, Lon: ${lon}</span>
      </div>
    `;
    marker.bindPopup(popupContent).openPopup();

    // Toggle map mode function
    function toggleMapMode() {
      const toggle = document.getElementById('mapToggle');
      const modeText = document.getElementById('mapModeText');
      
      if (currentLayer === lightLayer) {
        // Switch to dark mode
        map.removeLayer(lightLayer);
        darkLayer.addTo(map);
        currentLayer = darkLayer;
        toggle.classList.add('active');
        modeText.textContent = 'Dark';
      } else {
        // Switch to light mode
        map.removeLayer(darkLayer);
        lightLayer.addTo(map);
        currentLayer = lightLayer;
        toggle.classList.remove('active');
        modeText.textContent = 'Light';
      }
    }
  </script>
  <?php endif; ?>
</body>
</html>
