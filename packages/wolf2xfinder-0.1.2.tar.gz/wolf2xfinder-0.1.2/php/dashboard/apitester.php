<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Handle API requests
$response = '';
$error = '';
$statusCode = '';
$responseTime = '';
$responseHeaders = '';
$responseSize = '';
$requestHistory = $_SESSION['api_tester_history'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'send';
    $method = $_POST['method'] ?? 'GET';
    $url = $_POST['url'] ?? '';
    $headers = $_POST['headers'] ?? '';
    $body = $_POST['body'] ?? '';
    
    if ($action === 'send') {
        if (empty($url)) {
            $error = 'Please enter a URL.';
        } else {
            $startTime = microtime(true);
            
            try {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                curl_setopt($ch, CURLOPT_HEADER, true);
                
                // Add headers
                if (!empty($headers)) {
                    $headerArray = [];
                    $headerLines = explode("\n", trim($headers));
                    foreach ($headerLines as $line) {
                        if (strpos($line, ':') !== false) {
                            $headerArray[] = trim($line);
                        }
                    }
                    if (!empty($headerArray)) {
                        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
                    }
                }
                
                // Add body for POST, PUT, PATCH
                if (in_array($method, ['POST', 'PUT', 'PATCH']) && !empty($body)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                }
                
                $fullResponse = curl_exec($ch);
                $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $curlError = curl_error($ch);
                curl_close($ch);
                
                if ($curlError) {
                    $error = 'cURL Error: ' . $curlError;
                } else {
                    // Split headers and body
                    $responseHeaders = substr($fullResponse, 0, $headerSize);
                    $response = substr($fullResponse, $headerSize);
                    $responseSize = strlen($response);
                }
                
                $responseTime = round((microtime(true) - $startTime) * 1000, 2);
                
                // Save to history
                if (!isset($_SESSION['api_tester_history'])) {
                    $_SESSION['api_tester_history'] = [];
                }
                array_unshift($_SESSION['api_tester_history'], [
                    'method' => $method,
                    'url' => $url,
                    'status' => $statusCode,
                    'time' => $responseTime,
                    'timestamp' => date('Y-m-d H:i:s'),
                    'headers' => $headers,
                    'body' => $body,
                    'response' => $response
                ]);
                // Keep only last 20 requests
                if (count($_SESSION['api_tester_history']) > 20) {
                    $_SESSION['api_tester_history'] = array_slice($_SESSION['api_tester_history'], 0, 20);
                }
                $requestHistory = $_SESSION['api_tester_history'];
                
            } catch (Exception $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'clear_history') {
        $_SESSION['api_tester_history'] = [];
        $requestHistory = [];
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>API Tester - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #00E5FF;
    }

    .user-details {
      flex: 1;
    }

    .user-name {
      color: #E6EAF2;
      font-weight: 600;
      font-size: 0.9rem;
    }

    .user-email {
      color: #8A93A6;
      font-size: 0.8rem;
    }

    /* Main Content */
    .main-content {
      flex: 1;
      margin-left: 260px;
      background: linear-gradient(135deg, #0B0F1A 0%, #121826 100%);
      min-height: 100vh;
    }

    .app-header {
      background: rgba(11, 15, 26, 0.95);
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }

    .brand-title {
      font-size: 1.5rem;
      color: #E6EAF2;
      font-weight: 600;
    }

    .brand-sub {
      color: #8A93A6;
      font-size: 0.85rem;
      margin-top: 4px;
    }

    .container {
      padding: 40px;
      max-width: 1400px;
      margin: 0 auto;
      width: 100%;
      box-sizing: border-box;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    @media (max-width: 768px) {
      .brand {
        gap: 10px;
      }
    }

    .page-title {
      font-size: 2rem;
      color: #E6EAF2;
      margin-bottom: 8px;
      font-weight: 600;
    }

    .page-subtitle {
      color: #8A93A6;
      margin-bottom: 30px;
    }

    /* API Tester Styles */
    .api-tester-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      width: 100%;
      max-width: 100%;
    }

    .form-section {
      background: rgba(18, 24, 42, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 25px;
      border-radius: 0;
      overflow: hidden;
      max-width: 100%;
    }

    .section-title {
      font-size: 1.1rem;
      color: #00E5FF;
      margin-bottom: 20px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      color: #E6EAF2;
      margin-bottom: 8px;
      font-weight: 500;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px 16px;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      color: #E6EAF2;
      font-size: 0.95rem;
      border-radius: 0;
      transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #00E5FF;
      box-shadow: 0 0 15px rgba(0, 229, 255, 0.2);
    }

    .form-group textarea {
      min-height: 120px;
      resize: vertical;
      font-family: 'Courier New', monospace;
    }

    .url-input-group {
      display: flex;
      gap: 10px;
    }

    .method-select {
      width: 120px !important;
      flex-shrink: 0;
    }

    .url-input {
      flex: 1;
    }

    .btn-send {
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
      color: #0B0F1A;
      border: none;
      padding: 12px 30px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      border-radius: 0;
      font-size: 0.95rem;
    }

    .btn-send:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 20px rgba(0, 229, 255, 0.4);
    }

    .btn-clear {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border: 1px solid rgba(255, 77, 109, 0.3);
      padding: 10px 20px;
      cursor: pointer;
      transition: all 0.3s ease;
      border-radius: 0;
      font-size: 0.9rem;
    }

    .btn-clear:hover {
      background: rgba(255, 77, 109, 0.2);
      border-color: #FF4D6D;
    }

    /* Response Section */
    .response-section {
      background: rgba(18, 24, 42, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 25px;
      border-radius: 0;
      overflow: hidden;
      max-width: 100%;
    }

    .response-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
    }

    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      border-radius: 0;
      font-weight: 600;
      font-size: 0.9rem;
      border: 1px solid transparent;
      min-width: 50px;
      justify-content: center;
    }

    .status-badge.success {
      background: rgba(0, 255, 136, 0.1);
      color: #00FF88;
      border-color: rgba(0, 255, 136, 0.3);
    }

    .status-badge.error {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border-color: rgba(255, 77, 109, 0.3);
    }

    .response-time {
      color: #8A93A6;
      font-size: 0.85rem;
    }

    .response-body {
      background: rgba(11, 15, 26, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 20px;
      min-height: 300px;
      max-height: 500px;
      overflow-x: auto;
      overflow-y: auto;
      font-family: 'Courier New', monospace;
      font-size: 0.9rem;
      color: #E6EAF2;
      white-space: pre;
      word-break: normal;
      word-wrap: normal;
      max-width: 100%;
    }

    .response-body::-webkit-scrollbar {
      width: 8px;
      height: 8px;
    }

    .response-body::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .response-body::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 4px;
    }

    .response-body::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .response-body:empty {
      color: #8A93A6;
    }

    .response-body:empty::before {
      content: 'Response will appear here...';
    }

    .response-actions {
      display: flex;
      gap: 10px;
      margin-bottom: 15px;
    }

    .btn-action {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border: 1px solid rgba(0, 229, 255, 0.3);
      padding: 8px 16px;
      cursor: pointer;
      transition: all 0.3s ease;
      border-radius: 0;
      font-size: 0.85rem;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .btn-action:hover {
      background: rgba(0, 229, 255, 0.2);
      border-color: #00E5FF;
    }

    .response-info {
      display: flex;
      gap: 20px;
      margin-bottom: 15px;
      font-size: 0.85rem;
      color: #8A93A6;
    }

    .response-info-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .response-headers {
      background: rgba(11, 15, 26, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 15px;
      margin-bottom: 15px;
      max-height: 200px;
      overflow-y: auto;
      font-family: 'Courier New', monospace;
      font-size: 0.85rem;
      color: #8A93A6;
    }

    .response-headers h4 {
      color: #00E5FF;
      margin-bottom: 10px;
      font-size: 0.9rem;
    }

    .response-headers pre {
      margin: 0;
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    /* History Section */
    .history-section {
      grid-column: 1 / -1;
      margin-top: 20px;
    }

    .history-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .history-item {
      display: flex;
      align-items: center;
      gap: 15px;
      padding: 15px;
      background: rgba(11, 15, 26, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      transition: all 0.3s ease;
    }

    .history-item:hover {
      border-color: rgba(0, 229, 255, 0.3);
      background: rgba(0, 229, 255, 0.05);
    }

    .history-method {
      padding: 6px 12px;
      font-weight: 600;
      font-size: 0.85rem;
      border-radius: 0;
      min-width: 70px;
      text-align: center;
    }

    .history-method.GET {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border: 1px solid rgba(0, 229, 255, 0.3);
    }

    .history-method.POST {
      background: rgba(0, 255, 136, 0.1);
      color: #00FF88;
      border: 1px solid rgba(0, 255, 136, 0.3);
    }

    .history-method.PUT {
      background: rgba(255, 193, 7, 0.1);
      color: #FFC107;
      border: 1px solid rgba(255, 193, 7, 0.3);
    }

    .history-method.DELETE {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border: 1px solid rgba(255, 77, 109, 0.3);
    }

    .history-method.PATCH {
      background: rgba(156, 39, 176, 0.1);
      color: #9C27B0;
      border: 1px solid rgba(156, 39, 176, 0.3);
    }

    .history-url {
      flex: 1;
      color: #E6EAF2;
      font-size: 0.9rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .history-status {
      padding: 4px 10px;
      font-size: 0.8rem;
      border-radius: 0;
      font-weight: 600;
      border: 1px solid transparent;
      min-width: 40px;
      text-align: center;
      display: inline-block;
    }

    .history-status.success {
      background: rgba(0, 255, 136, 0.1);
      color: #00FF88;
      border-color: rgba(0, 255, 136, 0.3);
    }

    .history-status.error {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border-color: rgba(255, 77, 109, 0.3);
    }

    .history-time {
      color: #8A93A6;
      font-size: 0.8rem;
      min-width: 80px;
    }

    .history-timestamp {
      color: #8A93A6;
      font-size: 0.8rem;
      min-width: 140px;
    }

    .history-item {
      cursor: pointer;
    }

    /* Modal Styles */
    .modal-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }

    .modal-overlay.active {
      display: flex;
    }

    .modal-content {
      background: #0B0F1A;
      border: 1px solid rgba(0, 229, 255, 0.3);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      overflow-y: auto;
      padding: 30px;
      position: relative;
    }

    .modal-close {
      position: absolute;
      top: 15px;
      right: 15px;
      background: none;
      border: none;
      color: #8A93A6;
      cursor: pointer;
      font-size: 1.5rem;
      transition: color 0.3s ease;
    }

    .modal-close:hover {
      color: #FF4D6D;
    }

    .modal-title {
      font-size: 1.3rem;
      color: #00E5FF;
      margin-bottom: 20px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .modal-section {
      margin-bottom: 25px;
    }

    .modal-section h4 {
      color: #E6EAF2;
      margin-bottom: 10px;
      font-size: 0.9rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .modal-section pre {
      background: rgba(11, 15, 26, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 15px;
      color: #E6EAF2;
      font-family: 'Courier New', monospace;
      font-size: 0.85rem;
      white-space: pre-wrap;
      word-wrap: break-word;
      max-height: 200px;
      overflow-y: auto;
    }

    .modal-info-row {
      display: flex;
      gap: 30px;
      margin-bottom: 15px;
    }

    .modal-info-item {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #8A93A6;
      font-size: 0.9rem;
    }

    .modal-info-item strong {
      color: #E6EAF2;
    }

    .alert {
      padding: 15px 20px;
      margin-bottom: 20px;
      border-radius: 0;
      font-weight: 500;
    }

    .alert-error {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border: 1px solid rgba(255, 77, 109, 0.3);
    }

    @media (max-width: 1200px) {
      .container {
        padding: 30px;
        max-width: 100%;
      }
      .api-tester-container {
        grid-template-columns: 1fr;
        gap: 15px;
      }
      .response-body {
        max-height: 400px;
        overflow-x: auto;
        white-space: pre;
      }
    }

    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
        transition: transform 0.3s ease;
      }
      .sidebar.active {
        transform: translateX(0);
      }
      .main-content {
        margin-left: 0;
      }
      .container {
        padding: 15px;
        max-width: 100%;
      }
      .page-title {
        font-size: 1.5rem;
      }
      .app-header {
        padding: 15px 20px;
      }
      .form-section, .response-section {
        padding: 15px;
      }
      .url-input-group {
        flex-direction: column;
        gap: 8px;
      }
      .method-select {
        width: 100% !important;
      }
      .history-item {
        flex-wrap: wrap;
        gap: 8px;
        padding: 10px;
      }
      .history-url {
        order: 3;
        width: 100%;
        font-size: 0.8rem;
      }
      .history-method {
        min-width: 60px;
        padding: 4px 8px;
        font-size: 0.75rem;
      }
      .history-status {
        padding: 3px 8px;
        font-size: 0.75rem;
      }
      .history-time, .history-timestamp {
        font-size: 0.75rem;
        min-width: auto;
      }
      .modal-content {
        width: 95%;
        padding: 20px;
      }
      .modal-info-row {
        flex-wrap: wrap;
        gap: 10px;
      }
      .response-header {
        flex-wrap: wrap;
        gap: 10px;
      }
      .response-actions {
        flex-wrap: wrap;
      }
      .btn-action {
        padding: 6px 12px;
        font-size: 0.8rem;
      }
    }

    @media (max-width: 480px) {
      .container {
        padding: 10px;
      }
      .page-title {
        font-size: 1.3rem;
      }
      .page-subtitle {
        font-size: 0.85rem;
      }
      .section-title {
        font-size: 0.95rem;
      }
      .form-group input,
      .form-group select,
      .form-group textarea {
        padding: 10px 12px;
        font-size: 0.9rem;
      }
      .btn-send {
        width: 100%;
        padding: 12px 20px;
      }
      .response-body {
        min-height: 200px;
        max-height: 300px;
        padding: 12px;
        font-size: 0.8rem;
        overflow-x: auto;
        white-space: pre;
      }
    }

    /* Mobile Menu Toggle */
    .mobile-menu-toggle {
      display: none;
      background: none;
      border: none;
      color: #00E5FF;
      cursor: pointer;
      padding: 8px;
    }
    .mobile-menu-toggle svg {
      width: 24px;
      height: 24px;
    }

    @media (max-width: 768px) {
      .mobile-menu-toggle {
        display: block;
      }
    }

    /* Overlay for mobile sidebar */
    .sidebar-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99;
    }
    .sidebar-overlay.active {
      display: block;
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
      
        <a href="../auth/logout.php" class="nav-item logout" style="margin-top: 15px; padding: 10px 24px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <button type="button" class="mobile-menu-toggle" onclick="toggleSidebar()" aria-label="Toggle Menu">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="3" y1="12" x2="21" y2="12"/>
              <line x1="3" y1="6" x2="21" y2="6"/>
              <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
        <h1 class="page-title">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          API Tester
        </h1>
        <p class="page-subtitle">Test and debug API endpoints with HTTP requests</p>

        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
          <div class="api-tester-container">
            <!-- Request Section -->
            <div class="form-section">
              <div class="section-title">Request Configuration</div>
              
              <div class="form-group">
                <label>Endpoint URL</label>
                <div class="url-input-group">
                  <select name="method" class="method-select">
                    <option value="GET" <?php echo ($_POST['method'] ?? 'GET') === 'GET' ? 'selected' : ''; ?>>GET</option>
                    <option value="POST" <?php echo ($_POST['method'] ?? '') === 'POST' ? 'selected' : ''; ?>>POST</option>
                    <option value="PUT" <?php echo ($_POST['method'] ?? '') === 'PUT' ? 'selected' : ''; ?>>PUT</option>
                    <option value="DELETE" <?php echo ($_POST['method'] ?? '') === 'DELETE' ? 'selected' : ''; ?>>DELETE</option>
                    <option value="PATCH" <?php echo ($_POST['method'] ?? '') === 'PATCH' ? 'selected' : ''; ?>>PATCH</option>
                    <option value="HEAD" <?php echo ($_POST['method'] ?? '') === 'HEAD' ? 'selected' : ''; ?>>HEAD</option>
                    <option value="OPTIONS" <?php echo ($_POST['method'] ?? '') === 'OPTIONS' ? 'selected' : ''; ?>>OPTIONS</option>
                  </select>
                  <input type="text" name="url" class="url-input" placeholder="https://api.example.com/endpoint" value="<?php echo htmlspecialchars($_POST['url'] ?? ''); ?>" />
                </div>
              </div>

              <div class="form-group">
                <label>Headers (one per line, format: Name: Value)</label>
                <textarea name="headers" placeholder="Content-Type: application/json&#10;Authorization: Bearer token&#10;User-Agent: API Tester"><?php echo htmlspecialchars($_POST['headers'] ?? ''); ?></textarea>
              </div>

              <div class="form-group">
                <label>Request Body (JSON, XML, or plain text)</label>
                <textarea name="body" placeholder='{"key": "value"}'><?php echo htmlspecialchars($_POST['body'] ?? ''); ?></textarea>
              </div>

              <button type="submit" name="action" value="send" class="btn-send">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                  <line x1="22" y1="2" x2="11" y2="13"/>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
                Send Request
              </button>
            </div>

            <!-- Response Section -->
            <div class="response-section">
              <div class="response-header">
                <div class="section-title">Response</div>
                <?php if ($statusCode): ?>
                <div class="status-badge <?php echo $statusCode >= 200 && $statusCode < 300 ? 'success' : 'error'; ?>">
                  <?php echo $statusCode; ?>
                </div>
                <?php endif; ?>
              </div>
              
              <?php if ($responseTime || $responseSize): ?>
              <div class="response-info">
                <?php if ($responseTime): ?>
                <div class="response-info-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                  </svg>
                  <span><?php echo $responseTime; ?>ms</span>
                </div>
                <?php endif; ?>
                <?php if ($responseSize): ?>
                <div class="response-info-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                  </svg>
                  <span><?php echo $responseSize; ?> bytes</span>
                </div>
                <?php endif; ?>
              </div>
              <?php endif; ?>
              
              <?php if ($response): ?>
              <div class="response-actions">
                <button type="button" class="btn-action" onclick="copyResponse()">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                  </svg>
                  Copy
                </button>
                <button type="button" class="btn-action" onclick="formatJSON()">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                    <polyline points="10 9 9 9 8 9"/>
                  </svg>
                  Format JSON
                </button>
                <button type="button" class="btn-action" onclick="toggleHeaders()">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                  </svg>
                  Headers
                </button>
              </div>
              <?php endif; ?>
              
              <?php if ($responseHeaders): ?>
              <div class="response-headers" id="responseHeaders" style="display: none;">
                <h4>Response Headers</h4>
                <pre><?php echo htmlspecialchars($responseHeaders); ?></pre>
              </div>
              <?php endif; ?>
              
              <div class="response-body" id="responseBody"><?php echo htmlspecialchars($response); ?></div>
            </div>

            <!-- History Section -->
            <div class="form-section history-section">
              <div class="response-header">
                <div class="section-title">Request History</div>
                <button type="submit" name="action" value="clear_history" class="btn-clear">Clear History</button>
              </div>
              
              <div class="history-list">
                <?php if (!empty($requestHistory)): ?>
                  <?php foreach ($requestHistory as $index => $item): ?>
                    <div class="history-item" onclick="openModal(<?php echo $index; ?>)" data-index="<?php echo $index; ?>" data-method="<?php echo htmlspecialchars($item['method']); ?>" data-url="<?php echo htmlspecialchars($item['url']); ?>" data-status="<?php echo htmlspecialchars($item['status']); ?>" data-time="<?php echo htmlspecialchars($item['time']); ?>" data-timestamp="<?php echo htmlspecialchars($item['timestamp']); ?>" data-headers="<?php echo htmlspecialchars($item['headers'] ?? ''); ?>" data-body="<?php echo htmlspecialchars($item['body'] ?? ''); ?>" data-response="<?php echo htmlspecialchars($item['response'] ?? ''); ?>">
                      <div class="history-method <?php echo $item['method']; ?>"><?php echo $item['method']; ?></div>
                      <div class="history-url"><?php echo htmlspecialchars($item['url']); ?></div>
                      <div class="history-status <?php echo $item['status'] >= 200 && $item['status'] < 300 ? 'success' : 'error'; ?>"><?php echo $item['status']; ?></div>
                      <div class="history-time"><?php echo $item['time']; ?>ms</div>
                      <div class="history-timestamp"><?php echo $item['timestamp']; ?></div>
                    </div>
                  <?php endforeach; ?>
                <?php else: ?>
                  <div style="text-align: center; color: #8A93A6; padding: 30px;">
                    No request history yet
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </form>

        <!-- History Detail Modal -->
        <div class="modal-overlay" id="historyModal">
          <div class="modal-content">
            <button class="modal-close" onclick="closeModal()">&times;</button>
            <div class="modal-title">Request Details</div>
            
            <div class="modal-info-row">
              <div class="modal-info-item">
                <strong>Method:</strong> <span id="modalMethod"></span>
              </div>
              <div class="modal-info-item">
                <strong>Status:</strong> <span id="modalStatus"></span>
              </div>
              <div class="modal-info-item">
                <strong>Time:</strong> <span id="modalTime"></span>
              </div>
              <div class="modal-info-item">
                <strong>Timestamp:</strong> <span id="modalTimestamp"></span>
              </div>
            </div>
            
            <div class="modal-section">
              <h4>URL</h4>
              <pre id="modalUrl"></pre>
            </div>
            
            <div class="modal-section" id="modalHeadersSection" style="display: none;">
              <h4>Request Headers</h4>
              <pre id="modalHeaders"></pre>
            </div>
            
            <div class="modal-section" id="modalBodySection" style="display: none;">
              <h4>Request Body</h4>
              <pre id="modalBody"></pre>
            </div>
            
            <div class="modal-section" id="modalResponseSection" style="display: none;">
              <h4>Response Body</h4>
              <pre id="modalResponse"></pre>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <script>
    function toggleSidebar() {
      const sidebar = document.querySelector('.sidebar');
      const overlay = document.getElementById('sidebarOverlay');
      sidebar.classList.toggle('active');
      overlay.classList.toggle('active');
    }

    function copyResponse() {
      const responseBody = document.getElementById('responseBody');
      if (responseBody && responseBody.textContent) {
        navigator.clipboard.writeText(responseBody.textContent).then(() => {
          alert('Response copied to clipboard!');
        }).catch(err => {
          console.error('Failed to copy:', err);
        });
      }
    }

    function formatJSON() {
      const responseBody = document.getElementById('responseBody');
      if (responseBody && responseBody.textContent) {
        try {
          const json = JSON.parse(responseBody.textContent);
          responseBody.textContent = JSON.stringify(json, null, 2);
        } catch (e) {
          alert('Response is not valid JSON');
        }
      }
    }

    function toggleHeaders() {
      const headersDiv = document.getElementById('responseHeaders');
      if (headersDiv) {
        headersDiv.style.display = headersDiv.style.display === 'none' ? 'block' : 'none';
      }
    }

    function openModal(index) {
      const historyItem = document.querySelector('.history-item[data-index="' + index + '"]');
      if (!historyItem) return;
      
      const method = historyItem.getAttribute('data-method');
      const url = historyItem.getAttribute('data-url');
      const status = historyItem.getAttribute('data-status');
      const time = historyItem.getAttribute('data-time');
      const timestamp = historyItem.getAttribute('data-timestamp');
      const headers = historyItem.getAttribute('data-headers');
      const body = historyItem.getAttribute('data-body');
      const response = historyItem.getAttribute('data-response');
      
      document.getElementById('modalMethod').textContent = method;
      document.getElementById('modalStatus').textContent = status;
      document.getElementById('modalTime').textContent = time + 'ms';
      document.getElementById('modalTimestamp').textContent = timestamp;
      document.getElementById('modalUrl').textContent = url;
      
      // Show/hide headers section
      const headersSection = document.getElementById('modalHeadersSection');
      const headersContent = document.getElementById('modalHeaders');
      if (headers && headers.trim()) {
        headersSection.style.display = 'block';
        headersContent.textContent = headers;
      } else {
        headersSection.style.display = 'none';
      }
      
      // Show/hide body section
      const bodySection = document.getElementById('modalBodySection');
      const bodyContent = document.getElementById('modalBody');
      if (body && body.trim()) {
        bodySection.style.display = 'block';
        bodyContent.textContent = body;
      } else {
        bodySection.style.display = 'none';
      }
      
      // Show/hide response section
      const responseSection = document.getElementById('modalResponseSection');
      const responseContent = document.getElementById('modalResponse');
      if (response && response.trim()) {
        responseSection.style.display = 'block';
        responseContent.textContent = response;
      } else {
        responseSection.style.display = 'none';
      }
      
      // Show modal
      const modal = document.getElementById('historyModal');
      modal.classList.add('active');
    }

    function closeModal() {
      const modal = document.getElementById('historyModal');
      modal.classList.remove('active');
    }

    // Close modal when clicking outside
    document.getElementById('historyModal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal();
      }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeModal();
      }
    });
  </script>
</body>
</html>
