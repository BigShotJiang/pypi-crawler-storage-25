<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Handle OSINT requests
$osintResults = [];
$error = '';
$targetType = '';
$targetValue = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetType = $_POST['target_type'] ?? '';
    $targetValue = $_POST['target_value'] ?? '';
    
    if (empty($targetValue)) {
        $error = 'Please enter a target value.';
    } else {
        // Simulate OSINT data collection (replace with actual OSINT APIs)
        $osintResults = performOsintLookup($targetType, $targetValue);
    }
}

function performOsintLookup($type, $value) {
    $results = [
        'nodes' => [],
        'edges' => [],
        'details' => []
    ];
    
    // Shape definitions for different node types
    $shapes = [
        'target' => 'star',
        'domain' => 'hexagon',
        'server' => 'box',
        'database' => 'database',
        'network' => 'dot',
        'location' => 'triangle',
        'security' => 'diamond',
        'person' => 'circularImage',
        'email' => 'ellipse',
        'document' => 'square',
        'phone' => 'triangleDown'
    ];
    
    // Main target node
    $results['nodes'][] = [
        'id' => 'main',
        'label' => $value,
        'type' => $type,
        'group' => 'target',
        'shape' => 'star',
        'size' => 35,
        'title' => "Target: $type"
    ];
    
    switch($type) {
        case 'ip':
            // Detailed IP lookup data
            $results['details'] = [
                'ip' => $value,
                'country' => 'United States',
                'city' => 'Mountain View',
                'region' => 'California',
                'isp' => 'Google LLC',
                'asn' => 'AS15169',
                'timezone' => 'America/Los_Angeles',
                'ports' => [80, 443, 8080],
                'services' => ['HTTP', 'HTTPS', 'Proxy']
            ];
            
            // Location node (triangle)
            $results['nodes'][] = [
                'id' => 'geo', 
                'label' => "{$results['details']['city']}\n{$results['details']['country']}", 
                'type' => 'location', 
                'group' => 'location', 
                'shape' => 'triangle',
                'size' => 25,
                'title' => "Location: {$results['details']['city']}, {$results['details']['region']}, {$results['details']['country']}\nTimezone: {$results['details']['timezone']}"
            ];
            
            // ISP node (box)
            $results['nodes'][] = [
                'id' => 'isp', 
                'label' => "{$results['details']['isp']}\n{$results['details']['asn']}", 
                'type' => 'isp', 
                'group' => 'network', 
                'shape' => 'box',
                'size' => 22,
                'title' => "ISP: {$results['details']['isp']}\nASN: {$results['details']['asn']}"
            ];
            
            // Ports node (hexagon)
            $results['nodes'][] = [
                'id' => 'ports', 
                'label' => "Open Ports\n" . implode(', ', $results['details']['ports']), 
                'type' => 'ports', 
                'group' => 'security', 
                'shape' => 'hexagon',
                'size' => 23,
                'title' => "Open Ports: " . implode(', ', $results['details']['ports']) . "\nServices: " . implode(', ', $results['details']['services'])
            ];
            
            // Reverse DNS domains
            $results['nodes'][] = [
                'id' => 'domains', 
                'label' => "Reverse DNS\nHostnames", 
                'type' => 'domains', 
                'group' => 'domain', 
                'shape' => 'hexagon',
                'size' => 20,
                'title' => "Associated Hostnames\n PTR Records"
            ];
            
            // Threat Intelligence
            $results['nodes'][] = [
                'id' => 'threat', 
                'label' => "Threat Intel\nReputation", 
                'type' => 'security', 
                'group' => 'security', 
                'shape' => 'diamond',
                'size' => 22,
                'title' => "IP Reputation Score\nBlacklist Status\nThreat Feeds"
            ];
            
            $results['edges'][] = ['id' => 'edge_main_geo', 'from' => 'main', 'to' => 'geo', 'label' => 'located'];
            $results['edges'][] = ['id' => 'edge_main_isp', 'from' => 'main', 'to' => 'isp', 'label' => 'belongs to'];
            $results['edges'][] = ['id' => 'edge_main_ports', 'from' => 'main', 'to' => 'ports', 'label' => 'exposes'];
            $results['edges'][] = ['id' => 'edge_main_domains', 'from' => 'main', 'to' => 'domains', 'label' => 'resolves'];
            $results['edges'][] = ['id' => 'edge_main_threat', 'from' => 'main', 'to' => 'threat', 'label' => 'scanned'];
            
            // Add expandable sub-nodes for more details (supports up to 60 nodes)
            // Geo sub-nodes
            $results['nodes'][] = ['id' => 'geo_coords', 'label' => "Coordinates\n40.7128, -74.0060", 'type' => 'location', 'group' => 'location', 'size' => 18, 'title' => "Latitude: 40.7128\nLongitude: -74.0060\nAccuracy: 95%"];
            $results['nodes'][] = ['id' => 'geo_timezone', 'label' => "Timezone\nAmerica/New_York", 'type' => 'info', 'group' => 'info', 'size' => 18, 'title' => "Timezone: America/New_York\nUTC Offset: -5:00\nDST: Yes"];
            $results['edges'][] = ['id' => 'edge_geo_coords', 'from' => 'geo', 'to' => 'geo_coords', 'label' => 'precise'];
            $results['edges'][] = ['id' => 'edge_geo_timezone', 'from' => 'geo', 'to' => 'geo_timezone', 'label' => 'zone'];
            
            // ISP sub-nodes
            $results['nodes'][] = ['id' => 'isp_asn', 'label' => "ASN\nAS15169", 'type' => 'network', 'group' => 'network', 'size' => 18, 'title' => "ASN: AS15169\nOrganization: Google LLC\nType: ISP"];
            $results['nodes'][] = ['id' => 'isp_route', 'label' => "Routing\nBGP", 'type' => 'network', 'group' => 'network', 'size' => 18, 'title' => "BGP Routing\nAdvertised: Yes\nPeers: 150+"];
            $results['edges'][] = ['id' => 'edge_isp_asn', 'from' => 'isp', 'to' => 'isp_asn', 'label' => 'announced'];
            $results['edges'][] = ['id' => 'edge_isp_route', 'from' => 'isp', 'to' => 'isp_route', 'label' => 'uses'];
            
            // Ports sub-nodes (expandable list)
            $portList = [80, 443, 8080, 8443, 22, 21, 25, 110, 143, 993, 995, 3306, 5432, 6379, 27017];
            foreach ($portList as $i => $portNum) {
                $portId = "port_$portNum";
                $services = [80 => 'HTTP', 443 => 'HTTPS', 8080 => 'HTTP-Alt', 8443 => 'HTTPS-Alt', 22 => 'SSH', 21 => 'FTP', 25 => 'SMTP', 110 => 'POP3', 143 => 'IMAP', 993 => 'IMAPS', 995 => 'POP3S', 3306 => 'MySQL', 5432 => 'PostgreSQL', 6379 => 'Redis', 27017 => 'MongoDB'];
                $service = $services[$portNum] ?? 'Unknown';
                $results['nodes'][] = ['id' => $portId, 'label' => "Port $portNum\n$service", 'type' => 'port', 'group' => 'network', 'size' => 16, 'title' => "Port: $portNum\nService: $service\nStatus: Open\nProtocol: TCP"];
                $results['edges'][] = ['id' => "edge_ports_$portNum", 'from' => 'ports', 'to' => $portId, 'label' => 'has'];
            }
            
            // Domain sub-nodes
            $results['nodes'][] = ['id' => 'domains_reverse', 'label' => "Reverse DNS\nhost.example.com", 'type' => 'dns', 'group' => 'network', 'size' => 18, 'title' => "Reverse DNS: host.example.com\nPTR Record Verified"];
            $results['nodes'][] = ['id' => 'domains_history', 'label' => "History\n45 records", 'type' => 'history', 'group' => 'info', 'size' => 18, 'title' => "Domain History: 45 records\nFirst seen: 2015\nLast seen: 2024"];
            $results['edges'][] = ['id' => 'edge_domains_reverse', 'from' => 'domains', 'to' => 'domains_reverse', 'label' => 'rDNS'];
            $results['edges'][] = ['id' => 'edge_domains_history', 'from' => 'domains', 'to' => 'domains_history', 'label' => 'tracked'];
            
            // Threat sub-nodes
            $results['nodes'][] = ['id' => 'threat_vt', 'label' => "VirusTotal\n0/90", 'type' => 'security', 'group' => 'security', 'size' => 18, 'title' => "VirusTotal Score: 0/90\nClean: 90 vendors\nDetections: 0"];
            $results['nodes'][] = ['id' => 'threat_abuse', 'label' => "AbuseIPDB\n0 reports", 'type' => 'security', 'group' => 'security', 'size' => 18, 'title' => "AbuseIPDB: 0 reports\nConfidence: 0%\nLast reported: Never"];
            $results['nodes'][] = ['id' => 'threat_shodan', 'label' => "Shodan\n12 services", 'type' => 'security', 'group' => 'security', 'size' => 18, 'title' => "Shodan Results: 12 services\nBanner grabs: 45\nOpen ports detected"];
            $results['edges'][] = ['id' => 'edge_threat_vt', 'from' => 'threat', 'to' => 'threat_vt', 'label' => 'scanned'];
            $results['edges'][] = ['id' => 'edge_threat_abuse', 'from' => 'threat', 'to' => 'threat_abuse', 'label' => 'reports'];
            $results['edges'][] = ['id' => 'edge_threat_shodan', 'from' => 'threat', 'to' => 'threat_shodan', 'label' => 'indexed'];
            break;
            
        case 'url':
            // Parse domain from URL
            $domain = parse_url($value, PHP_URL_HOST) ?: $value;
            
            $results['details'] = [
                'url' => $value,
                'domain' => $domain,
                'ip' => '142.250.80.46',
                'registrar' => 'MarkMonitor Inc.',
                'created' => '1997-09-15',
                'expires' => '2028-09-14',
                'nameservers' => ['ns1.google.com', 'ns2.google.com', 'ns3.google.com', 'ns4.google.com'],
                'subdomains' => ['www', 'mail', 'api', 'admin', 'blog'],
                'tech' => ['Nginx', 'PHP', 'MySQL', 'Cloudflare'],
                'dns_records' => [
                    'A' => ['142.250.80.46'],
                    'MX' => ['10 smtp.google.com'],
                    'TXT' => ['v=spf1 include:_spf.google.com ~all']
                ]
            ];
            
            // Domain node (hexagon)
            $results['nodes'][] = [
                'id' => 'domain', 
                'label' => "Domain\n$domain", 
                'type' => 'domain', 
                'group' => 'domain', 
                'shape' => 'hexagon',
                'size' => 28,
                'title' => "Domain: $domain\nRegistrar: {$results['details']['registrar']}\nCreated: {$results['details']['created']}\nExpires: {$results['details']['expires']}"
            ];
            
            // Server IP (box)
            $results['nodes'][] = [
                'id' => 'ip', 
                'label' => "Server\n{$results['details']['ip']}", 
                'type' => 'ip', 
                'group' => 'server', 
                'shape' => 'box',
                'size' => 24,
                'title' => "Server IP: {$results['details']['ip']}\nHosting Provider Detected"
            ];
            
            // Subdomains (database icon shape)
            $results['nodes'][] = [
                'id' => 'subdomains', 
                'label' => "Subdomains\n" . count($results['details']['subdomains']) . " found", 
                'type' => 'subdomain', 
                'group' => 'domain', 
                'shape' => 'square',
                'size' => 22,
                'title' => "Discovered Subdomains:\n" . implode(', ', $results['details']['subdomains'])
            ];
            
            // Technologies (dot cluster)
            $results['nodes'][] = [
                'id' => 'tech', 
                'label' => "Tech Stack\n" . implode(', ', array_slice($results['details']['tech'], 0, 2)) . "...", 
                'type' => 'tech', 
                'group' => 'tech', 
                'shape' => 'dot',
                'size' => 23,
                'title' => "Technologies Detected:\n" . implode('\n', $results['details']['tech'])
            ];
            
            // DNS Records (database shape)
            $results['nodes'][] = [
                'id' => 'dns', 
                'label' => "DNS Records\nA, MX, TXT", 
                'type' => 'dns', 
                'group' => 'network', 
                'shape' => 'database',
                'size' => 24,
                'title' => "DNS Records:\nA: " . implode(', ', $results['details']['dns_records']['A']) . "\nMX: " . $results['details']['dns_records']['MX'][0] . "\nTXT: SPF Record Present"
            ];
            
            // Whois Data (document)
            $results['nodes'][] = [
                'id' => 'whois', 
                'label' => "WHOIS Data\nRegistrar Info", 
                'type' => 'document', 
                'group' => 'info', 
                'shape' => 'square',
                'size' => 22,
                'title' => "WHOIS Information:\nRegistrar: {$results['details']['registrar']}\nCreated: {$results['details']['created']}\nExpires: {$results['details']['expires']}"
            ];
            
            // SSL Certificate
            $results['nodes'][] = [
                'id' => 'ssl', 
                'label' => "SSL/TLS\nCertificate", 
                'type' => 'security', 
                'group' => 'security', 
                'shape' => 'diamond',
                'size' => 21,
                'title' => "SSL Certificate:\nIssuer: Let's Encrypt\nValid: Yes\nExpiry: 90 days"
            ];
            
            $results['edges'][] = ['id' => 'edge_main_domain', 'from' => 'main', 'to' => 'domain', 'label' => 'hosts'];
            $results['edges'][] = ['id' => 'edge_domain_ip', 'from' => 'domain', 'to' => 'ip', 'label' => 'resolves'];
            $results['edges'][] = ['id' => 'edge_domain_subdomains', 'from' => 'domain', 'to' => 'subdomains', 'label' => 'contains'];
            $results['edges'][] = ['id' => 'edge_main_tech', 'from' => 'main', 'to' => 'tech', 'label' => 'uses'];
            $results['edges'][] = ['id' => 'edge_domain_dns', 'from' => 'domain', 'to' => 'dns', 'label' => 'configured'];
            $results['edges'][] = ['id' => 'edge_domain_whois', 'from' => 'domain', 'to' => 'whois', 'label' => 'registered'];
            $results['edges'][] = ['id' => 'edge_main_ssl', 'from' => 'main', 'to' => 'ssl', 'label' => 'secured'];
            
            // Add expandable sub-nodes for URL case (supports up to 60 nodes)
            // Subdomain list
            $subdomains = ['www', 'api', 'mail', 'ftp', 'admin', 'blog', 'shop', 'cdn', 'img', 'static', 'dev', 'test'];
            foreach ($subdomains as $sub) {
                $subId = "sub_{$sub}";
                $results['nodes'][] = ['id' => $subId, 'label' => "$sub.\n$domain", 'type' => 'subdomain', 'group' => 'domain', 'size' => 15, 'title' => "Subdomain: $sub.$domain\nStatus: Active\nType: A Record"];
                $results['edges'][] = ['id' => "edge_sub_{$sub}", 'from' => 'subdomains', 'to' => $subId, 'label' => 'has'];
            }
            
            // DNS records
            $dnsRecords = [
                ['id' => 'dns_a', 'label' => "A Records\n1 entry", 'type' => 'dns', 'info' => "A: 142.250.80.46"],
                ['id' => 'dns_aaaa', 'label' => "AAAA\n1 entry", 'type' => 'dns', 'info' => "AAAA: 2607:f8b0::"],
                ['id' => 'dns_mx', 'label' => "MX\n5 entries", 'type' => 'mx', 'info' => "MX: 5 mail servers"],
                ['id' => 'dns_txt', 'label' => "TXT\n3 entries", 'type' => 'dns', 'info' => "TXT: SPF, DKIM, DMARC"],
                ['id' => 'dns_ns', 'label' => "NS\n4 entries", 'type' => 'dns', 'info' => "NS: 4 nameservers"],
                ['id' => 'dns_cname', 'label' => "CNAME\n2 entries", 'type' => 'dns', 'info' => "CNAME: 2 aliases"],
                ['id' => 'dns_soa', 'label' => "SOA\n1 entry", 'type' => 'dns', 'info' => "SOA: Primary NS"],
            ];
            foreach ($dnsRecords as $record) {
                $results['nodes'][] = ['id' => $record['id'], 'label' => $record['label'], 'type' => $record['type'], 'group' => 'network', 'size' => 16, 'title' => "{$record['info']}\nClick to expand"];
                $results['edges'][] = ['id' => "edge_dns_{$record['id']}", 'from' => 'dns', 'to' => $record['id'], 'label' => 'record'];
            }
            
            // WHOIS sub-nodes
            $results['nodes'][] = ['id' => 'whois_registrar', 'label' => "Registrar\nMarkMonitor", 'type' => 'whois', 'group' => 'info', 'size' => 17, 'title' => "Registrar: MarkMonitor Inc.\nIANA ID: 292\nAbuse Email: abuse@markmonitor.com"];
            $results['nodes'][] = ['id' => 'whois_dates', 'label' => "Dates\n1997-2028", 'type' => 'whois', 'group' => 'info', 'size' => 17, 'title' => "Created: 1997-09-15\nUpdated: 2024-01-10\nExpires: 2028-09-14"];
            $results['nodes'][] = ['id' => 'whois_status', 'label' => "Status\nActive", 'type' => 'whois', 'group' => 'info', 'size' => 17, 'title' => "Status: clientDeleteProhibited\nclientTransferProhibited\nclientUpdateProhibited"];
            $results['edges'][] = ['id' => 'edge_whois_registrar', 'from' => 'whois', 'to' => 'whois_registrar', 'label' => 'by'];
            $results['edges'][] = ['id' => 'edge_whois_dates', 'from' => 'whois', 'to' => 'whois_dates', 'label' => 'period'];
            $results['edges'][] = ['id' => 'edge_whois_status', 'from' => 'whois', 'to' => 'whois_status', 'label' => 'state'];
            
            // Tech sub-nodes
            $techStack = [
                ['id' => 'tech_server', 'label' => "Server\nnginx/1.20", 'type' => 'server', 'info' => "Web Server: nginx 1.20"],
                ['id' => 'tech_js', 'label' => "JavaScript\nReact", 'type' => 'tech', 'info' => "Framework: React 18"],
                ['id' => 'tech_css', 'label' => "CSS\nTailwind", 'type' => 'tech', 'info' => "Styling: Tailwind CSS"],
                ['id' => 'tech_analytics', 'label' => "Analytics\nGoogle", 'type' => 'tech', 'info' => "Tracking: Google Analytics 4"],
                ['id' => 'tech_cdn', 'label' => "CDN\nCloudflare", 'type' => 'network', 'info' => "CDN: Cloudflare Pro"],
                ['id' => 'tech_waf', 'label' => "WAF\nEnabled", 'type' => 'security', 'info' => "Firewall: Cloudflare WAF"],
            ];
            foreach ($techStack as $tech) {
                $results['nodes'][] = ['id' => $tech['id'], 'label' => $tech['label'], 'type' => $tech['type'], 'group' => ($tech['type'] === 'security' ? 'security' : 'network'), 'size' => 16, 'title' => "{$tech['info']}\nDetected via Wappalyzer"];
                $results['edges'][] = ['id' => "edge_tech_{$tech['id']}", 'from' => 'tech', 'to' => $tech['id'], 'label' => 'uses'];
            }
            
            // SSL sub-nodes
            $results['nodes'][] = ['id' => 'ssl_issuer', 'label' => "Issuer\nLet's Encrypt", 'type' => 'security', 'group' => 'security', 'size' => 17, 'title' => "Issuer: Let's Encrypt Authority X3\nCountry: US\nOrganization: Let's Encrypt"];
            $results['nodes'][] = ['id' => 'ssl_cipher', 'label' => "Cipher\nTLS 1.3", 'type' => 'security', 'group' => 'security', 'size' => 17, 'title' => "Protocol: TLS 1.3\nCipher: AES-256-GCM\nKey Exchange: X25519"];
            $results['nodes'][] = ['id' => 'ssl_cert', 'label' => "Certificate\nValid", 'type' => 'security', 'group' => 'security', 'size' => 17, 'title' => "Valid: Yes\nSelf-signed: No\nChain: Complete"];
            $results['edges'][] = ['id' => 'edge_ssl_issuer', 'from' => 'ssl', 'to' => 'ssl_issuer', 'label' => 'by'];
            $results['edges'][] = ['id' => 'edge_ssl_cipher', 'from' => 'ssl', 'to' => 'ssl_cipher', 'label' => 'protocol'];
            $results['edges'][] = ['id' => 'edge_ssl_cert', 'from' => 'ssl', 'to' => 'ssl_cert', 'label' => 'status'];
            break;
            
        case 'email':
            $domain = substr(strrchr($value, "@"), 1);
            $username = substr($value, 0, strrpos($value, '@'));
            
            $results['details'] = [
                'email' => $value,
                'username' => $username,
                'domain' => $domain,
                'valid_format' => true,
                'mx_records' => ['10 mx1.example.com', '20 mx2.example.com'],
                'breaches' => ['HaveIBeenPwned: 2 breaches', 'DeHashed: Found'],
                'social_profiles' => ['LinkedIn', 'Twitter', 'GitHub', 'Instagram'],
                'spf' => 'v=spf1 include:_spf.google.com ~all',
                'dmarc' => 'v=DMARC1; p=quarantine;',
                'disposable' => false
            ];
            
            // Email Domain
            $results['nodes'][] = [
                'id' => 'domain', 
                'label' => "Domain\n$domain", 
                'type' => 'domain', 
                'group' => 'domain', 
                'shape' => 'hexagon',
                'size' => 26,
                'title' => "Email Domain: $domain\nDisposable: " . ($results['details']['disposable'] ? 'Yes' : 'No') . "\nValid Format: Yes"
            ];
            
            // Username
            $results['nodes'][] = [
                'id' => 'username', 
                'label' => "Username\n$username", 
                'type' => 'person', 
                'group' => 'person', 
                'shape' => 'circularImage',
                'size' => 24,
                'image' => 'https://ui-avatars.com/api/?name=' . urlencode($username) . '&background=E91E63&color=fff',
                'title' => "Username: $username\nEmail Format Valid"
            ];
            
            // Data Breaches (diamond)
            $results['nodes'][] = [
                'id' => 'breaches', 
                'label' => "Breaches\n" . count($results['details']['breaches']) . " found", 
                'type' => 'breach', 
                'group' => 'security', 
                'shape' => 'diamond',
                'size' => 25,
                'title' => "Data Breach History:\n" . implode('\n', $results['details']['breaches'])
            ];
            
            // Social Profiles (circular)
            $results['nodes'][] = [
                'id' => 'social', 
                'label' => "Social\nProfiles", 
                'type' => 'social', 
                'group' => 'social', 
                'shape' => 'circularImage',
                'size' => 24,
                'image' => 'https://ui-avatars.com/api/?name=SO&background=8BC34A&color=fff',
                'title' => "Social Profiles Found:\n" . implode(', ', $results['details']['social_profiles'])
            ];
            
            // MX Records
            $results['nodes'][] = [
                'id' => 'mx', 
                'label' => "MX Records\nMail Servers", 
                'type' => 'mx', 
                'group' => 'network', 
                'shape' => 'box',
                'size' => 22,
                'title' => "Mail Servers:\n" . implode('\n', $results['details']['mx_records'])
            ];
            
            // SPF/DKIM
            $results['nodes'][] = [
                'id' => 'spf', 
                'label' => "SPF/DKIM\nEmail Auth", 
                'type' => 'security', 
                'group' => 'security', 
                'shape' => 'diamond',
                'size' => 22,
                'title' => "SPF: {$results['details']['spf']}\nDMARC: {$results['details']['dmarc']}"
            ];
            
            // Similar Emails
            $results['nodes'][] = [
                'id' => 'similar', 
                'label' => "Pattern\nVariants", 
                'type' => 'email', 
                'group' => 'info', 
                'shape' => 'ellipse',
                'size' => 20,
                'title' => "Email Pattern Analysis\nCommon Variants Detected"
            ];
            
            $results['edges'][] = ['id' => 'edge_main_domain', 'from' => 'main', 'to' => 'domain', 'label' => 'domain'];
            $results['edges'][] = ['id' => 'edge_main_username', 'from' => 'main', 'to' => 'username', 'label' => 'user'];
            $results['edges'][] = ['id' => 'edge_main_breaches', 'from' => 'main', 'to' => 'breaches', 'label' => 'exposed in'];
            $results['edges'][] = ['id' => 'edge_username_social', 'from' => 'username', 'to' => 'social', 'label' => 'linked to'];
            $results['edges'][] = ['id' => 'edge_domain_mx', 'from' => 'domain', 'to' => 'mx', 'label' => 'routes via'];
            $results['edges'][] = ['id' => 'edge_domain_spf', 'from' => 'domain', 'to' => 'spf', 'label' => 'protected by'];
            $results['edges'][] = ['id' => 'edge_main_similar', 'from' => 'main', 'to' => 'similar', 'label' => 'pattern'];
            
            // Add expandable sub-nodes for email case (supports up to 60 nodes)
            // Breach sub-nodes
            $breachList = ['LinkedIn 2012', 'Adobe 2013', 'Canva 2019', 'Dropbox 2016', 'Tumblr 2013'];
            foreach ($breachList as $i => $breach) {
                $breachId = "breach_$i";
                $results['nodes'][] = ['id' => $breachId, 'label' => "Breach\n$breach", 'type' => 'security', 'group' => 'security', 'size' => 15, 'title' => "Breach: $breach\nData: Email, Password\nStatus: Leaked"];
                $results['edges'][] = ['id' => "edge_breach_$i", 'from' => 'breaches', 'to' => $breachId, 'label' => 'in'];
            }
            
            // Social profile sub-nodes
            $socialPlatforms = [
                ['id' => 'social_github', 'name' => 'GitHub', 'status' => 'Active'],
                ['id' => 'social_twitter', 'name' => 'Twitter', 'status' => 'Active'],
                ['id' => 'social_linkedin', 'name' => 'LinkedIn', 'status' => 'Found'],
                ['id' => 'social_facebook', 'name' => 'Facebook', 'status' => 'Private'],
                ['id' => 'social_instagram', 'name' => 'Instagram', 'status' => 'Active'],
                ['id' => 'social_tiktok', 'name' => 'TikTok', 'status' => 'Found'],
            ];
            foreach ($socialPlatforms as $social) {
                $results['nodes'][] = ['id' => $social['id'], 'label' => "{$social['name']}\n{$social['status']}", 'type' => 'social', 'group' => 'social', 'size' => 15, 'title' => "Platform: {$social['name']}\nStatus: {$social['status']}\nUsername: $username"];
                $results['edges'][] = ['id' => "edge_{$social['id']}", 'from' => 'social', 'to' => $social['id'], 'label' => 'account'];
            }
            
            // MX record sub-nodes
            $mxServers = [
                ['id' => 'mx_google', 'prio' => 1, 'server' => 'aspmx.l.google.com'],
                ['id' => 'mx_alt1', 'prio' => 5, 'server' => 'alt1.aspmx.l.google.com'],
                ['id' => 'mx_alt2', 'prio' => 5, 'server' => 'alt2.aspmx.l.google.com'],
                ['id' => 'mx_alt3', 'prio' => 10, 'server' => 'alt3.aspmx.l.google.com'],
                ['id' => 'mx_alt4', 'prio' => 10, 'server' => 'alt4.aspmx.l.google.com'],
            ];
            foreach ($mxServers as $mx) {
                $results['nodes'][] = ['id' => $mx['id'], 'label' => "MX {$mx['prio']}\n{$mx['server']}", 'type' => 'mx', 'group' => 'network', 'size' => 14, 'title' => "Priority: {$mx['prio']}\nServer: {$mx['server']}\nType: MX"];
                $results['edges'][] = ['id' => "edge_{$mx['id']}", 'from' => 'mx', 'to' => $mx['id'], 'label' => 'record'];
            }
            
            // SPF sub-nodes
            $results['nodes'][] = ['id' => 'spf_include', 'label' => "Include\n_spf.google.com", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "Include: _spf.google.com\nMechanism: include\nResult: Pass"];
            $results['nodes'][] = ['id' => 'spf_all', 'label' => "Policy\n~all", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "Policy: ~all (SoftFail)\nDefault: Recommended\nAction: Accept but flag"];
            $results['edges'][] = ['id' => 'edge_spf_include', 'from' => 'spf', 'to' => 'spf_include', 'label' => 'includes'];
            $results['edges'][] = ['id' => 'edge_spf_all', 'from' => 'spf', 'to' => 'spf_all', 'label' => 'policy'];
            
            // Similar email variants
            $variants = ['john.doe', 'jdoe', 'j.doe', 'doe.john', 'johnd'];
            foreach ($variants as $i => $variant) {
                $varId = "similar_$i";
                $results['nodes'][] = ['id' => $varId, 'label' => "$variant@\n$domain", 'type' => 'email', 'group' => 'info', 'size' => 14, 'title' => "Variant: $variant@$domain\nProbability: High\nPattern: Common"];
                $results['edges'][] = ['id' => "edge_similar_$i", 'from' => 'similar', 'to' => $varId, 'label' => 'variant'];
            }
            
            // Domain sub-nodes (MX check, DNSSEC, DMARC)
            $results['nodes'][] = ['id' => 'domain_dnssec', 'label' => "DNSSEC\nEnabled", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "DNSSEC: Enabled\nAlgorithm: ECDSAP256SHA256\nStatus: Valid"];
            $results['nodes'][] = ['id' => 'domain_dmarc', 'label' => "DMARC\np=quarantine", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "DMARC Policy: p=quarantine\nRUA: dmarc@example.com\nPct: 100"];
            $results['nodes'][] = ['id' => 'domain_dkim', 'label' => "DKIM\nValid", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "DKIM: Valid\nSelector: default\nKey: 2048-bit RSA"];
            $results['edges'][] = ['id' => 'edge_domain_dnssec', 'from' => 'domain', 'to' => 'domain_dnssec', 'label' => 'security'];
            $results['edges'][] = ['id' => 'edge_domain_dmarc', 'from' => 'domain', 'to' => 'domain_dmarc', 'label' => 'policy'];
            $results['edges'][] = ['id' => 'edge_domain_dkim', 'from' => 'domain', 'to' => 'domain_dkim', 'label' => 'signed'];
            break;
            
        case 'phone':
            $results['details'] = [
                'number' => $value,
                'country' => 'United States',
                'country_code' => '+1',
                'carrier' => 'T-Mobile US',
                'type' => 'Mobile',
                'line_type' => 'Wireless',
                'location' => 'California, CA',
                'timezone' => 'PST',
                'valid' => true,
                'apps' => ['WhatsApp', 'Telegram', 'Signal'],
                'databases' => ['Truecaller', 'Sync.ME', 'Hiya']
            ];
            
            // Carrier (box)
            $results['nodes'][] = [
                'id' => 'carrier', 
                'label' => "Carrier\n{$results['details']['carrier']}", 
                'type' => 'carrier', 
                'group' => 'network', 
                'shape' => 'box',
                'size' => 26,
                'title' => "Carrier: {$results['details']['carrier']}\nCountry: {$results['details']['country']} ({$results['details']['country_code']})"
            ];
            
            // Location (triangle)
            $results['nodes'][] = [
                'id' => 'location', 
                'label' => "Location\n{$results['details']['location']}", 
                'type' => 'location', 
                'group' => 'location', 
                'shape' => 'triangle',
                'size' => 24,
                'title' => "Location: {$results['details']['location']}\nTimezone: {$results['details']['timezone']}"
            ];
            
            // Number Type
            $results['nodes'][] = [
                'id' => 'type', 
                'label' => "Type\n{$results['details']['type']}", 
                'type' => 'info', 
                'group' => 'info', 
                'shape' => 'triangleDown',
                'size' => 22,
                'title' => "Line Type: {$results['details']['line_type']}\nValid: " . ($results['details']['valid'] ? 'Yes' : 'No')
            ];
            
            // Messaging Apps
            $results['nodes'][] = [
                'id' => 'apps', 
                'label' => "Apps\n" . implode(', ', $results['details']['apps']), 
                'type' => 'apps', 
                'group' => 'social', 
                'shape' => 'dot',
                'size' => 23,
                'title' => "Registered on:\n" . implode('\n', $results['details']['apps'])
            ];
            
            // Caller ID Databases
            $results['nodes'][] = [
                'id' => 'databases', 
                'label' => "Databases\n" . count($results['details']['databases']) . " sources", 
                'type' => 'document', 
                'group' => 'info', 
                'shape' => 'database',
                'size' => 22,
                'title' => "Found in:\n" . implode('\n', $results['details']['databases'])
            ];
            
            // Reputation Score
            $results['nodes'][] = [
                'id' => 'reputation', 
                'label' => "Score\nNeutral", 
                'type' => 'security', 
                'group' => 'security', 
                'shape' => 'diamond',
                'size' => 21,
                'title' => "Reputation Score: Neutral\nSpam Reports: 0\nBlocklists: Not listed"
            ];
            
            $results['edges'][] = ['id' => 'edge_main_carrier', 'from' => 'main', 'to' => 'carrier', 'label' => 'assigned to'];
            $results['edges'][] = ['id' => 'edge_main_location', 'from' => 'main', 'to' => 'location', 'label' => 'registered'];
            $results['edges'][] = ['id' => 'edge_main_type', 'from' => 'main', 'to' => 'type', 'label' => 'is'];
            $results['edges'][] = ['id' => 'edge_main_apps', 'from' => 'main', 'to' => 'apps', 'label' => 'active on'];
            $results['edges'][] = ['id' => 'edge_main_databases', 'from' => 'main', 'to' => 'databases', 'label' => 'indexed'];
            $results['edges'][] = ['id' => 'edge_main_reputation', 'from' => 'main', 'to' => 'reputation', 'label' => 'scored'];
            
            // Add expandable sub-nodes for phone case (supports up to 60 nodes)
            // Location sub-nodes
            $results['nodes'][] = ['id' => 'location_city', 'label' => "City\nNew York", 'type' => 'location', 'group' => 'location', 'size' => 17, 'title' => "City: New York\nPopulation: 8.4M\nArea: 783 km2"];
            $results['nodes'][] = ['id' => 'location_state', 'label' => "State\nNY", 'type' => 'location', 'group' => 'location', 'size' => 17, 'title' => "State: New York\nAbbreviation: NY\nRegion: Northeast"];
            $results['nodes'][] = ['id' => 'location_zip', 'label' => "ZIP\n10001", 'type' => 'location', 'group' => 'location', 'size' => 17, 'title' => "ZIP Code: 10001\nManhattan, NYC\nZone: Midtown"];
            $results['edges'][] = ['id' => 'edge_location_city', 'from' => 'location', 'to' => 'location_city', 'label' => 'in'];
            $results['edges'][] = ['id' => 'edge_location_state', 'from' => 'location', 'to' => 'location_state', 'label' => 'region'];
            $results['edges'][] = ['id' => 'edge_location_zip', 'from' => 'location', 'to' => 'location_zip', 'label' => 'postal'];
            
            // Carrier sub-nodes
            $results['nodes'][] = ['id' => 'carrier_network', 'label' => "Network\n5G/LTE", 'type' => 'network', 'group' => 'network', 'size' => 17, 'title' => "Network: 5G/LTE\nBands: n71, n41, n25\nCoverage: 99%"];
            $results['nodes'][] = ['id' => 'carrier_mnc', 'label' => "MNC-MCC\n310-260", 'type' => 'network', 'group' => 'network', 'size' => 17, 'title' => "MCC: 310 (US)\nMNC: 260 (T-Mobile)\nNetwork Code"];
            $results['edges'][] = ['id' => 'edge_carrier_network', 'from' => 'carrier', 'to' => 'carrier_network', 'label' => 'tech'];
            $results['edges'][] = ['id' => 'edge_carrier_mnc', 'from' => 'carrier', 'to' => 'carrier_mnc', 'label' => 'code'];
            
            // Type sub-nodes
            $results['nodes'][] = ['id' => 'type_prepaid', 'label' => "Billing\nPostpaid", 'type' => 'info', 'group' => 'info', 'size' => 17, 'title' => "Billing: Postpaid\nPlan: Unlimited\nContract: 24 months"];
            $results['nodes'][] = ['id' => 'type_ported', 'label' => "Ported\nNo", 'type' => 'info', 'group' => 'info', 'size' => 17, 'title' => "Ported: No\nOriginal Carrier: T-Mobile\nSince: 2015"];
            $results['edges'][] = ['id' => 'edge_type_prepaid', 'from' => 'type', 'to' => 'type_prepaid', 'label' => 'billing'];
            $results['edges'][] = ['id' => 'edge_type_ported', 'from' => 'type', 'to' => 'type_ported', 'label' => 'status'];
            
            // Apps sub-nodes (messaging/social apps)
            $appList = [
                ['id' => 'app_whatsapp', 'name' => 'WhatsApp', 'status' => 'Active'],
                ['id' => 'app_telegram', 'name' => 'Telegram', 'status' => 'Found'],
                ['id' => 'app_signal', 'name' => 'Signal', 'status' => 'Active'],
                ['id' => 'app_viber', 'name' => 'Viber', 'status' => 'Inactive'],
                ['id' => 'app_line', 'name' => 'LINE', 'status' => 'Found'],
                ['id' => 'app_wechat', 'name' => 'WeChat', 'status' => 'Not Found'],
            ];
            foreach ($appList as $app) {
                $results['nodes'][] = ['id' => $app['id'], 'label' => "{$app['name']}\n{$app['status']}", 'type' => 'apps', 'group' => 'social', 'size' => 15, 'title' => "App: {$app['name']}\nStatus: {$app['status']}\nPrivacy: End-to-end"];
                $results['edges'][] = ['id' => "edge_{$app['id']}", 'from' => 'apps', 'to' => $app['id'], 'label' => 'uses'];
            }
            
            // Database sub-nodes
            $dbList = [
                ['id' => 'db_truecaller', 'name' => 'TrueCaller', 'records' => 'Found'],
                ['id' => 'db_syncme', 'name' => 'Sync.ME', 'records' => '2 entries'],
                ['id' => 'db_numlookup', 'name' => 'NumLookup', 'records' => 'Listed'],
                ['id' => 'db_spydialer', 'name' => 'SpyDialer', 'records' => 'Found'],
                ['id' => 'db_whitepages', 'name' => 'WhitePages', 'records' => '1 entry'],
            ];
            foreach ($dbList as $db) {
                $results['nodes'][] = ['id' => $db['id'], 'label' => "{$db['name']}\n{$db['records']}", 'type' => 'database', 'group' => 'info', 'size' => 15, 'title' => "Database: {$db['name']}\nRecords: {$db['records']}\nVisibility: Public"];
                $results['edges'][] = ['id' => "edge_{$db['id']}", 'from' => 'databases', 'to' => $db['id'], 'label' => 'listed'];
            }
            
            // Reputation sub-nodes
            $results['nodes'][] = ['id' => 'rep_spam', 'label' => "Spam\n0 reports", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "Spam Reports: 0\nLast Report: Never\nTrend: Stable"];
            $results['nodes'][] = ['id' => 'rep_fraud', 'label' => "Fraud\nClean", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "Fraud Score: 0/100\nRisk Level: Low\nVerified: Yes"];
            $results['nodes'][] = ['id' => 'rep_robocall', 'label' => "Robocall\nNo", 'type' => 'security', 'group' => 'security', 'size' => 16, 'title' => "Robocall: No\nRobotest: Passed\nHuman: Likely"];
            $results['nodes'][] = ['id' => 'rep_hlr', 'label' => "HLR\nActive", 'type' => 'network', 'group' => 'network', 'size' => 16, 'title' => "HLR Status: Active\nReachable: Yes\nRoaming: No"];
            $results['edges'][] = ['id' => 'edge_rep_spam', 'from' => 'reputation', 'to' => 'rep_spam', 'label' => 'spam'];
            $results['edges'][] = ['id' => 'edge_rep_fraud', 'from' => 'reputation', 'to' => 'rep_fraud', 'label' => 'fraud'];
            $results['edges'][] = ['id' => 'edge_rep_robocall', 'from' => 'reputation', 'to' => 'rep_robocall', 'label' => 'robocall'];
            $results['edges'][] = ['id' => 'edge_rep_hlr', 'from' => 'reputation', 'to' => 'rep_hlr', 'label' => 'hlr'];
            break;
    }
    
    return $results;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>OSINT Tool - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #00E5FF;
    }

    .user-details {
      flex: 1;
    }

    .user-name {
      color: #E6EAF2;
      font-weight: 600;
      font-size: 0.9rem;
    }

    .user-email {
      color: #8A93A6;
      font-size: 0.8rem;
    }

    /* Main Content */
    .main-content {
      flex: 1;
      margin-left: 260px;
      background: linear-gradient(135deg, #0B0F1A 0%, #121826 100%);
      min-height: 100vh;
    }

    .app-header {
      background: rgba(11, 15, 26, 0.95);
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .brand-title {
      font-size: 1.5rem;
      color: #E6EAF2;
      font-weight: 600;
    }

    .brand-sub {
      color: #8A93A6;
      font-size: 0.85rem;
      margin-top: 4px;
    }

    .container {
      padding: 40px;
      max-width: 1400px;
      margin: 0 auto;
      width: 100%;
      box-sizing: border-box;
    }

    .page-title {
      font-size: 2rem;
      color: #E6EAF2;
      margin-bottom: 8px;
      font-weight: 600;
    }

    .page-subtitle {
      color: #8A93A6;
      margin-bottom: 30px;
    }

    /* OSINT Styles */
    .osint-container {
      display: grid;
      grid-template-columns: 380px 1fr;
      gap: 25px;
      height: calc(100vh - 200px);
      min-height: 600px;
    }

    .input-panel {
      background: rgba(18, 24, 42, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      padding: 25px;
      border-radius: 0;
      overflow-y: auto;
    }

    .graph-panel {
      background: rgba(18, 24, 42, 0.6);
      border: 1px solid rgba(0, 229, 255, 0.1);
      border-radius: 0;
      position: relative;
      overflow: hidden;
      min-height: 700px;
      height: 700px;
    }

    #mynetwork {
      width: 100%;
      height: 100%;
      min-height: 700px;
      background: rgba(11, 15, 26, 0.8);
    }

    .section-title {
      font-size: 1.1rem;
      color: #00E5FF;
      margin-bottom: 20px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      color: #E6EAF2;
      margin-bottom: 8px;
      font-weight: 500;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 12px 16px;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      color: #E6EAF2;
      font-size: 0.95rem;
      border-radius: 0;
      transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group select:focus {
      outline: none;
      border-color: #00E5FF;
      box-shadow: 0 0 15px rgba(0, 229, 255, 0.2);
    }

    .target-type-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 20px;
    }

    .target-type-btn {
      padding: 15px;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      color: #8A93A6;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }

    .target-type-btn:hover {
      border-color: rgba(0, 229, 255, 0.5);
      color: #E6EAF2;
    }

    .target-type-btn.active {
      background: rgba(0, 229, 255, 0.1);
      border-color: #00E5FF;
      color: #00E5FF;
    }

    .target-type-btn svg,
    .target-type-btn img.type-icon {
      width: 28px;
      height: 28px;
      filter: brightness(1.2);
    }

    .btn-investigate {
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
      color: #0B0F1A;
      border: none;
      padding: 14px 30px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      border-radius: 0;
      font-size: 1rem;
      width: 100%;
    }

    .btn-investigate:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 20px rgba(0, 229, 255, 0.4);
    }

    .graph-legend {
      position: absolute;
      bottom: 20px;
      left: 20px;
      background: rgba(11, 15, 26, 0.9);
      border: 1px solid rgba(0, 229, 255, 0.2);
      padding: 15px;
      border-radius: 0;
      z-index: 10;
    }

    .legend-title {
      color: #00E5FF;
      font-size: 0.85rem;
      font-weight: 600;
      margin-bottom: 10px;
      text-transform: uppercase;
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 6px;
      font-size: 0.8rem;
      color: #8A93A6;
    }

    .legend-icon {
      width: 20px;
      height: 20px;
      filter: brightness(1.2);
    }

    .legend-color {
      width: 12px;
      height: 12px;
      border-radius: 2px;
    }

    .graph-controls {
      position: absolute;
      top: 20px;
      right: 20px;
      display: flex;
      gap: 10px;
      z-index: 10;
    }

    .control-btn {
      background: rgba(0, 229, 255, 0.1);
      border: 1px solid rgba(0, 229, 255, 0.3);
      color: #00E5FF;
      padding: 8px 12px;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .control-btn:hover {
      background: rgba(0, 229, 255, 0.2);
    }

    .control-btn svg {
      width: 18px;
      height: 18px;
    }

    .alert {
      padding: 15px 20px;
      margin-bottom: 20px;
      border-radius: 0;
      font-weight: 500;
    }

    .alert-error {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      border: 1px solid rgba(255, 77, 109, 0.3);
    }

    .results-info {
      background: rgba(0, 229, 255, 0.05);
      border: 1px solid rgba(0, 229, 255, 0.2);
      padding: 15px;
      margin-top: 20px;
    }

    .results-info h4 {
      color: #00E5FF;
      margin-bottom: 10px;
      font-size: 0.9rem;
    }

    .results-info p {
      color: #8A93A6;
      font-size: 0.85rem;
      line-height: 1.5;
    }

    .details-panel {
      background: rgba(11, 15, 26, 0.9);
      border: 1px solid rgba(0, 229, 255, 0.2);
      padding: 20px;
      margin-top: 20px;
      max-height: 300px;
      overflow-y: auto;
      display: none;
    }

    .details-panel h4 {
      color: #00E5FF;
      margin-bottom: 15px;
      font-size: 1rem;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
      padding-bottom: 10px;
    }

    .details-content {
      color: #E6EAF2;
      font-size: 0.85rem;
    }

    .detail-item {
      padding: 8px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }

    .detail-item:last-child {
      border-bottom: none;
    }

    .detail-item strong {
      color: #00E5FF;
      display: inline-block;
      min-width: 120px;
    }

    .details-placeholder {
      color: #8A93A6;
      font-style: italic;
    }

    .node-details-popup {
      position: absolute;
      top: 70px;
      right: 20px;
      width: 280px;
      background: rgba(11, 15, 26, 0.95);
      border: 1px solid rgba(0, 229, 255, 0.3);
      padding: 20px;
      border-radius: 0;
      z-index: 100;
      backdrop-filter: blur(10px);
      max-height: 400px;
      overflow-y: auto;
    }

    .node-details-popup h4 {
      color: #00E5FF;
      margin-bottom: 15px;
      font-size: 1rem;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
      padding-bottom: 10px;
    }

    .node-meta {
      color: #E6EAF2;
      font-size: 0.85rem;
      line-height: 1.6;
    }

    .node-meta strong {
      color: #00E5FF;
    }

    .node-description {
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      color: #8A93A6;
    }

    .node-actions {
      margin-top: 15px;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .node-btn {
      background: rgba(0, 229, 255, 0.1);
      border: 1px solid rgba(0, 229, 255, 0.3);
      color: #00E5FF;
      padding: 6px 12px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: all 0.3s ease;
      flex: 1;
      min-width: 80px;
    }

    .node-btn:hover {
      background: rgba(0, 229, 255, 0.2);
      border-color: #00E5FF;
    }

    .node-btn.secondary {
      background: rgba(255, 255, 255, 0.05);
      border-color: rgba(255, 255, 255, 0.2);
      color: #8A93A6;
    }

    .node-btn.secondary:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: #8A93A6;
      color: #E6EAF2;
    }

    /* Mobile Menu Toggle */
    .mobile-menu-toggle {
      display: none;
      background: none;
      border: none;
      color: #00E5FF;
      cursor: pointer;
      padding: 8px;
    }
    .mobile-menu-toggle svg {
      width: 24px;
      height: 24px;
    }

    /* Sidebar Overlay */
    .sidebar-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99;
    }
    .sidebar-overlay.active {
      display: block;
    }

    @media (max-width: 1200px) {
      .osint-container {
        grid-template-columns: 1fr;
        height: auto;
      }
      .graph-panel {
        height: 600px;
        min-height: 500px;
      }
    }

    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
        transition: transform 0.3s ease;
      }
      .sidebar.active {
        transform: translateX(0);
      }
      .main-content {
        margin-left: 0;
      }
      .mobile-menu-toggle {
        display: block;
      }
      .container {
        padding: 20px;
      }
      .app-header {
        padding: 15px 20px;
      }
      .page-title {
        font-size: 1.5rem;
      }
      .target-type-grid {
        grid-template-columns: 1fr;
      }
      .graph-panel {
        height: 450px;
        min-height: 350px;
      }
      .graph-legend {
        bottom: 10px;
        left: 10px;
        padding: 10px;
      }
      .node-details-popup {
        width: 220px;
        top: 60px;
        right: 10px;
        max-height: 300px;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item active">
          <img src="../assets/osint-svgs/target.svg" width="20" height="20" style="filter: brightness(1.2);" alt="OSINT">
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout" style="margin-top: 15px; padding: 10px 24px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <button type="button" class="mobile-menu-toggle" onclick="toggleSidebar()" aria-label="Toggle Menu">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="3" y1="12" x2="21" y2="12"/>
              <line x1="3" y1="6" x2="21" y2="6"/>
              <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
        <h1 class="page-title">
          <img src="../assets/osint-svgs/target.svg" width="28" height="28" style="vertical-align: middle; margin-right: 8px;" alt="OSINT">
          OSINT Investigation Tool
        </h1>
        <p class="page-subtitle">Analyze IP addresses, URLs, emails, and phone numbers with interactive relationship mapping</p>

        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
          <div class="osint-container">
            <!-- Input Panel -->
            <div class="input-panel">
              <div class="section-title">Target Selection</div>
              
              <div class="target-type-grid">
                <div class="target-type-btn <?php echo ($targetType === 'ip' || empty($targetType)) ? 'active' : ''; ?>" onclick="selectType('ip')" data-type="ip">
                  <img src="../assets/osint-svgs/ip.svg" class="type-icon" alt="IP">
                  <span>IP Address</span>
                </div>
                <div class="target-type-btn <?php echo $targetType === 'url' ? 'active' : ''; ?>" onclick="selectType('url')" data-type="url">
                  <img src="../assets/osint-svgs/domain.svg" class="type-icon" alt="Domain">
                  <span>URL/Domain</span>
                </div>
                <div class="target-type-btn <?php echo $targetType === 'email' ? 'active' : ''; ?>" onclick="selectType('email')" data-type="email">
                  <img src="../assets/osint-svgs/email.svg" class="type-icon" alt="Email">
                  <span>Email</span>
                </div>
                <div class="target-type-btn <?php echo $targetType === 'phone' ? 'active' : ''; ?>" onclick="selectType('phone')" data-type="phone">
                  <img src="../assets/osint-svgs/phone.svg" class="type-icon" alt="Phone">
                  <span>Phone</span>
                </div>
              </div>

              <input type="hidden" name="target_type" id="targetType" value="<?php echo htmlspecialchars($targetType ?: 'ip'); ?>">

              <div class="form-group">
                <label for="targetValue">Enter Target</label>
                <input type="text" id="targetValue" name="target_value" placeholder="e.g., 8.8.8.8 or example.com" value="<?php echo htmlspecialchars($targetValue); ?>" required />
              </div>

              <button type="submit" class="btn-investigate">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                  <circle cx="11" cy="11" r="8"/>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                Start Investigation
              </button>

              <div id="detailsPanel" class="details-panel" style="display: none;">
                <h4>Investigation Details</h4>
                <div class="details-content">
                  <p class="details-placeholder">Investigation results will appear here...</p>
                </div>
              </div>

              <div class="results-info">
                <h4>About OSINT</h4>
                <p>Open Source Intelligence (OSINT) gathers publicly available information about targets. This tool visualizes relationships between entities like IP addresses, domains, emails, and phone numbers.</p>
              </div>
            </div>

            <!-- Graph Panel -->
            <div class="graph-panel">
              <div class="graph-controls">
                <button type="button" class="control-btn" onclick="expandAllNodes()" title="Expand All">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>
                  </svg>
                </button>
                <button type="button" class="control-btn" onclick="collapseAllNodes()" title="Collapse All">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>
                  </svg>
                </button>
                <button type="button" class="control-btn" onclick="zoomIn()" title="Zoom In">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    <line x1="11" y1="8" x2="11" y2="14"/>
                    <line x1="8" y1="11" x2="14" y2="11"/>
                  </svg>
                </button>
                <button type="button" class="control-btn" onclick="zoomOut()" title="Zoom Out">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    <line x1="8" y1="11" x2="14" y2="11"/>
                  </svg>
                </button>
                <button type="button" class="control-btn" onclick="fitGraph()" title="Fit to Screen">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>
                  </svg>
                </button>
                <button type="button" class="control-btn" onclick="resetGraph()" title="Reset View">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
                    <path d="M3 3v5h5"/>
                  </svg>
                </button>
              </div>

              <div id="mynetwork"></div>

              <div class="graph-legend">
                <div class="legend-title">Node Types</div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/target.svg" class="legend-icon" alt="Target">
                  <div class="legend-color" style="background: #00E5FF;"></div>
                  <span>Target</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/domain.svg" class="legend-icon" alt="Domain">
                  <div class="legend-color" style="background: #00FF88;"></div>
                  <span>Domain</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/server.svg" class="legend-icon" alt="Server">
                  <div class="legend-color" style="background: #FF6B35;"></div>
                  <span>Network/Server</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/location.svg" class="legend-icon" alt="Location">
                  <div class="legend-color" style="background: #9C27B0;"></div>
                  <span>Location</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/security.svg" class="legend-icon" alt="Security">
                  <div class="legend-color" style="background: #FFC107;"></div>
                  <span>Security</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/person.svg" class="legend-icon" alt="Person">
                  <div class="legend-color" style="background: #E91E63;"></div>
                  <span>Person/Social</span>
                </div>
                <div class="legend-item">
                  <img src="../assets/osint-svgs/database.svg" class="legend-icon" alt="Database">
                  <div class="legend-color" style="background: #607D8B;"></div>
                  <span>Database/Docs</span>
                </div>
              </div>

              <div id="nodeDetails" class="node-details-popup" style="display: none;">
                <h4>Node Information</h4>
                <div class="node-meta">Click on a node to see details</div>
              </div>
            </div>
          </div>
        </form>
      </main>
    </div>
  </div>

  <script>
    let network = null;
    let nodesDataSet = null;
    let edgesDataSet = null;
    let expandedNodes = new Set();
    let allNodeData = {};
    let allEdgeData = [];

    // Node colors by group
    const groupColors = {
      target: { background: '#00E5FF', border: '#00B8D4', highlight: '#00FFFF' },
      domain: { background: '#00FF88', border: '#00C853', highlight: '#69F0AE' },
      network: { background: '#FF6B35', border: '#E55A2B', highlight: '#FF8A65' },
      location: { background: '#9C27B0', border: '#7B1FA2', highlight: '#CE93D8' },
      security: { background: '#FFC107', border: '#FFA000', highlight: '#FFD54F' },
      person: { background: '#E91E63', border: '#C2185B', highlight: '#F48FB1' },
      isp: { background: '#3F51B5', border: '#303F9F', highlight: '#7986CB' },
      tech: { background: '#00BCD4', border: '#0097A7', highlight: '#4DD0E1' },
      info: { background: '#607D8B', border: '#455A64', highlight: '#90A4AE' },
      social: { background: '#8BC34A', border: '#689F38', highlight: '#AED581' },
      apps: { background: '#FF9800', border: '#F57C00', highlight: '#FFB74D' },
      server: { background: '#FF5722', border: '#E64A19', highlight: '#FF8A65' }
    };

    // Shape configuration
    const shapeConfig = {
      star: { borderRadius: 0 },
      hexagon: { borderRadius: 0 },
      box: { borderRadius: 4 },
      database: { borderRadius: 0 },
      dot: { borderRadius: 50 },
      triangle: { borderRadius: 0 },
      triangleDown: { borderRadius: 0 },
      diamond: { borderRadius: 0 },
      square: { borderRadius: 2 },
      ellipse: { borderRadius: 50 }
    };

    function selectType(type) {
      document.querySelectorAll('.target-type-btn').forEach(btn => {
        btn.classList.remove('active');
      });
      document.querySelector(`.target-type-btn[data-type="${type}"]`).classList.add('active');
      document.getElementById('targetType').value = type;
      
      // Update placeholder
      const placeholders = {
        ip: 'e.g., 8.8.8.8',
        url: 'e.g., example.com',
        email: 'e.g., user@example.com',
        phone: 'e.g., +1 234 567 8900'
      };
      document.getElementById('targetValue').placeholder = placeholders[type];
    }

    // SVG mapping for node types
    const svgMapping = {
      target: '../assets/osint-svgs/target.svg',
      domain: '../assets/osint-svgs/domain.svg',
      server: '../assets/osint-svgs/server.svg',
      network: '../assets/osint-svgs/network.svg',
      location: '../assets/osint-svgs/location.svg',
      security: '../assets/osint-svgs/security.svg',
      person: '../assets/osint-svgs/person.svg',
      social: '../assets/osint-svgs/social.svg',
      info: '../assets/osint-svgs/database.svg',
      database: '../assets/osint-svgs/database.svg',
      tech: '../assets/osint-svgs/tech.svg',
      apps: '../assets/osint-svgs/apps.svg',
      ip: '../assets/osint-svgs/ip.svg',
      email: '../assets/osint-svgs/email.svg',
      phone: '../assets/osint-svgs/phone.svg',
      breach: '../assets/osint-svgs/breach.svg',
      dns: '../assets/osint-svgs/dns.svg',
      whois: '../assets/osint-svgs/whois.svg',
      ssl: '../assets/osint-svgs/ssl.svg',
      port: '../assets/osint-svgs/port.svg',
      mx: '../assets/osint-svgs/mx.svg',
      carrier: '../assets/osint-svgs/carrier.svg',
      subdomain: '../assets/osint-svgs/subdomain.svg',
      reputation: '../assets/osint-svgs/reputation.svg',
      threat: '../assets/osint-svgs/threat.svg'
    };

    function initGraph() {
      const container = document.getElementById('mynetwork');
      
      // Initial empty data
      nodesDataSet = new vis.DataSet([]);
      edgesDataSet = new vis.DataSet([]);
      
      const data = {
        nodes: nodesDataSet,
        edges: edgesDataSet
      };
      
      const options = {
        nodes: {
          shape: 'circularImage',
          size: 30,
          font: {
            size: 12,
            color: '#E6EAF2',
            face: 'Arial',
            multi: true,
            strokeWidth: 0,
            background: 'rgba(11, 15, 26, 0.8)'
          },
          borderWidth: 3,
          borderWidthSelected: 4,
          shadow: {
            enabled: true,
            color: 'rgba(0,0,0,0.6)',
            size: 12,
            x: 3,
            y: 3
          },
          shapeProperties: {
            useBorderWithImage: true,
            useImageSize: false
          }
        },
        edges: {
          width: 2,
          color: {
            color: 'rgba(0, 229, 255, 0.5)',
            highlight: '#00E5FF',
            hover: '#00E5FF'
          },
          smooth: {
            type: 'cubicBezier',
            forceDirection: 'horizontal',
            roundness: 0.4
          },
          arrows: {
            to: { enabled: true, scaleFactor: 0.8 }
          },
          font: {
            size: 11,
            color: '#8A93A6',
            face: 'Arial',
            strokeWidth: 3,
            strokeColor: '#0B0F1A',
            background: 'rgba(11, 15, 26, 0.9)',
            align: 'middle'
          },
          labelHighlightBold: true
        },
        physics: {
          forceAtlas2Based: {
            gravitationalConstant: -120,
            centralGravity: 0.008,
            springLength: 180,
            springConstant: 0.04,
            damping: 0.5,
            avoidOverlap: 0.6
          },
          maxVelocity: 50,
          minVelocity: 0.1,
          solver: 'forceAtlas2Based',
          timestep: 0.35,
          stabilization: {
            enabled: true,
            iterations: 3000,
            updateInterval: 25,
            onlyDynamicEdges: false,
            fit: true
          },
          adaptiveTimestep: true
        },
        layout: {
          randomSeed: 2,
          improvedLayout: true,
          clusterThreshold: 200
        },
        groups: groupColors,
        interaction: {
          hover: true,
          tooltipDelay: 150,
          hideEdgesOnDrag: false,
          navigationButtons: true,
          keyboard: true,
          multiselect: true
        }
      };
      
      network = new vis.Network(container, data, options);
      
      // Add click event for nodes - expand/collapse functionality
      network.on("click", function (params) {
        if (params.nodes.length > 0) {
          const nodeId = params.nodes[0];
          const node = nodesDataSet.get(nodeId);
          
          // Toggle expand/collapse
          if (expandedNodes.has(nodeId)) {
            collapseNode(nodeId);
          } else {
            expandNode(nodeId);
          }
          
          showNodeDetails(node);
        }
      });

      // Double click to expand all children recursively
      network.on("doubleClick", function (params) {
        if (params.nodes.length > 0) {
          const nodeId = params.nodes[0];
          expandNodeRecursive(nodeId);
        }
      });

      // Hover events
      network.on("hoverNode", function (params) {
        document.body.style.cursor = 'pointer';
      });

      network.on("blurNode", function (params) {
        document.body.style.cursor = 'default';
      });
    }

    function showNodeDetails(node) {
      const panel = document.getElementById('nodeDetails');
      if (!panel) return;
      
      const isExpanded = expandedNodes.has(node.id);
      const childCount = getChildCount(node.id);
      
      let html = `<h4>${node.label.replace(/\n/g, ' - ')}</h4>`;
      html += `<div class="node-meta">`;
      html += `<div><strong>Type:</strong> ${node.type || 'Unknown'}</div>`;
      html += `<div><strong>Group:</strong> ${node.group || 'Unknown'}</div>`;
      html += `<div><strong>Status:</strong> ${isExpanded ? 'Expanded' : 'Collapsed'}</div>`;
      if (childCount > 0) {
        html += `<div><strong>Children:</strong> ${childCount} nodes</div>`;
      }
      if (node.title) {
        html += `<div class="node-description">${node.title.replace(/\n/g, '<br>')}</div>`;
      }
      html += `</div>`;
      html += `<div class="node-actions">`;
      html += `<button onclick="toggleNodeById('${node.id}')" class="node-btn">${isExpanded ? 'Collapse' : 'Expand'}</button>`;
      if (childCount > 0) {
        html += `<button onclick="expandAllChildren('${node.id}')" class="node-btn secondary">Expand All</button>`;
      }
      html += `</div>`;
      
      panel.innerHTML = html;
      panel.style.display = 'block';
    }

    function getChildCount(nodeId) {
      return allEdgeData.filter(edge => edge.from === nodeId).length;
    }

    function toggleNodeById(nodeId) {
      if (expandedNodes.has(nodeId)) {
        collapseNode(nodeId);
      } else {
        expandNode(nodeId);
      }
    }

    function expandAllChildren(nodeId) {
      expandNodeRecursive(nodeId);
    }

    function expandNode(nodeId) {
      if (expandedNodes.has(nodeId)) return;
      
      const node = nodesDataSet.get(nodeId);
      if (!node) return;
      
      // Find child nodes from original data
      const childEdges = allEdgeData.filter(edge => edge.from === nodeId);
      const childNodeIds = childEdges.map(edge => edge.to);
      
      if (childNodeIds.length === 0) {
        // Generate dynamic children based on node type
        const dynamicChildren = generateDynamicChildren(nodeId, node.type, node.group);
        if (dynamicChildren.nodes.length > 0) {
          // Add new nodes with animation
          dynamicChildren.nodes.forEach((childNode, index) => {
            setTimeout(() => {
              const configuredNode = configureNodeWithImage(childNode);
              nodesDataSet.add(configuredNode);
              
              // Add edge with animation
              const edge = {
                from: nodeId,
                to: childNode.id,
                label: getRelationshipLabel(node.type, childNode.type),
                color: { color: 'rgba(0, 229, 255, 0.6)' }
              };
              edgesDataSet.add(edge);
            }, index * 150);
          });
        }
      } else {
        // Show existing hidden children
        const animDelay = childNodeIds.length > 20 ? 30 : 80;
        childNodeIds.forEach((childId, index) => {
          const childNode = allNodeData[childId];
          if (childNode && !nodesDataSet.get(childId)) {
            setTimeout(() => {
              const configuredNode = configureNodeWithImage(childNode);
              nodesDataSet.add(configuredNode);
            }, index * animDelay);
          }
        });
        
        // Show edges
        childEdges.forEach((edge, index) => {
          const edgeId = edge.id || `edge_${edge.from}_${edge.to}`;
          if (!edgesDataSet.get(edgeId)) {
            setTimeout(() => {
              edgesDataSet.add({
                ...edge,
                id: edgeId
              });
            }, index * animDelay);
          }
        });
      }
      
      expandedNodes.add(nodeId);
      
      // Animate the parent node
      nodesDataSet.update({
        id: nodeId,
        size: 40,
        borderWidth: 5,
        shadow: {
          enabled: true,
          color: 'rgba(0, 229, 255, 0.5)',
          size: 20,
          x: 0,
          y: 0
        }
      });
      
      // Reset after animation
      setTimeout(() => {
        nodesDataSet.update({
          id: nodeId,
          size: 30,
          borderWidth: 3,
          shadow: {
            enabled: true,
            color: 'rgba(0,0,0,0.6)',
            size: 12,
            x: 3,
            y: 3
          }
        });
      }, 500);
    }

    function collapseNode(nodeId) {
      if (!expandedNodes.has(nodeId)) return;
      
      // Find all direct children from original data
      const childEdges = allEdgeData.filter(e => e.from === nodeId);
      const childNodeIds = childEdges.map(e => e.to);
      
      // Recursively collapse all descendants first
      childNodeIds.forEach(childId => {
        if (expandedNodes.has(childId)) {
          collapseNode(childId);
        }
      });
      
      // Faster animation for large graphs
      const collapseDelay = childNodeIds.length > 20 ? 20 : 40;
      
      // Now remove this node's direct children
      childNodeIds.forEach((id, index) => {
        setTimeout(() => {
          if (nodesDataSet.get(id)) {
            nodesDataSet.remove(id);
          }
        }, index * collapseDelay);
      });
      
      // Remove edges
      childEdges.forEach((edge, index) => {
        const edgeId = edge.id || `edge_${edge.from}_${edge.to}`;
        setTimeout(() => {
          if (edgesDataSet.get(edgeId)) {
            edgesDataSet.remove(edgeId);
          }
        }, index * collapseDelay);
      });
      
      expandedNodes.delete(nodeId);
    }

    function getAllDescendants(nodeId) {
      const nodeIds = [];
      const edgeIds = [];
      const visited = new Set();
      
      function traverse(currentId) {
        if (visited.has(currentId)) return;
        visited.add(currentId);
        
        // Find all edges from this node in the original data
        const edges = allEdgeData.filter(e => e.from === currentId);
        edges.forEach(edge => {
          const edgeId = edge.id || `edge_${edge.from}_${edge.to}`;
          if (!edgeIds.includes(edgeId)) {
            edgeIds.push(edgeId);
          }
          if (!nodeIds.includes(edge.to)) {
            nodeIds.push(edge.to);
          }
          // Always recurse to find all descendants from original data
          traverse(edge.to);
        });
      }
      
      traverse(nodeId);
      return { nodeIds, edgeIds };
    }

    function expandNodeRecursive(nodeId) {
      expandNode(nodeId);
      
      // Recursively expand children after a delay
      const childEdges = allEdgeData.filter(edge => edge.from === nodeId);
      childEdges.forEach((edge, index) => {
        setTimeout(() => {
          expandNodeRecursive(edge.to);
        }, 300 + index * 200);
      });
    }

    function generateDynamicChildren(parentId, parentType, parentGroup) {
      const nodes = [];
      const baseId = `${parentId}_child_${Date.now()}`;
      
      // Generate context-aware children based on parent type
      switch(parentType || parentGroup) {
        case 'target':
          nodes.push(
            { id: `${baseId}_1`, label: 'Properties', type: 'info', group: 'info' },
            { id: `${baseId}_2`, label: 'Relations', type: 'network', group: 'network' },
            { id: `${baseId}_3`, label: 'Metadata', type: 'database', group: 'info' }
          );
          break;
        case 'domain':
          nodes.push(
            { id: `${baseId}_1`, label: 'Subdomains', type: 'subdomain', group: 'domain' },
            { id: `${baseId}_2`, label: 'Records', type: 'dns', group: 'network' },
            { id: `${baseId}_3`, label: 'History', type: 'whois', group: 'info' }
          );
          break;
        case 'location':
          nodes.push(
            { id: `${baseId}_1`, label: 'Coordinates', type: 'info', group: 'location' },
            { id: `${baseId}_2`, label: 'ISP', type: 'network', group: 'network' }
          );
          break;
        case 'security':
        case 'breach':
          nodes.push(
            { id: `${baseId}_1`, label: 'Details', type: 'info', group: 'security' },
            { id: `${baseId}_2`, label: 'Severity', type: 'threat', group: 'security' }
          );
          break;
        default:
          nodes.push(
            { id: `${baseId}_1`, label: 'Details', type: 'info', group: 'info' },
            { id: `${baseId}_2`, label: 'Related', type: 'network', group: 'network' }
          );
      }
      
      return { nodes };
    }

    function getRelationshipLabel(parentType, childType) {
      const relationships = {
        'target-domain': 'owns',
        'target-location': 'at',
        'domain-server': 'hosted',
        'domain-network': 'uses',
        'location-network': 'served by',
        'person-social': 'has',
        'email-domain': 'on',
        'phone-carrier': 'with'
      };
      return relationships[`${parentType}-${childType}`] || 'links to';
    }

    function configureNodeWithImage(node) {
      const svgPath = svgMapping[node.type] || svgMapping[node.group] || svgMapping.info;
      return {
        ...node,
        shape: 'circularImage',
        image: svgPath,
        color: groupColors[node.group] || groupColors.info,
        font: {
          size: 12,
          color: '#E6EAF2',
          face: 'Arial',
          multi: true,
          strokeWidth: 0,
          background: 'rgba(11, 15, 26, 0.8)'
        },
        borderWidth: 3,
        shadow: {
          enabled: true,
          color: 'rgba(0,0,0,0.6)',
          size: 12,
          x: 3,
          y: 3
        },
        shapeProperties: {
          useBorderWithImage: true,
          useImageSize: false
        }
      };
    }

    function loadGraphData(nodes, edges, details) {
      if (!network) return;
      
      // Store all data for expansion functionality
      allNodeData = {};
      allEdgeData = [];
      expandedNodes.clear();
      
      // Store nodes lookup
      nodes.forEach(node => {
        allNodeData[node.id] = node;
      });
      
      // Store edges with unique IDs (consistent format)
      const edgesWithIds = edges.map((edge, index) => ({
        ...edge,
        id: edge.id || `edge_${edge.from}_${edge.to}`
      }));
      allEdgeData = edgesWithIds;
      
      // Configure nodes with SVG images
      const configuredNodes = nodes.map(node => {
        return configureNodeWithImage(node);
      });
      
      nodesDataSet.clear();
      edgesDataSet.clear();
      nodesDataSet.add(configuredNodes);
      edgesDataSet.add(edgesWithIds);
      
      // Mark all nodes as initially expanded (show all children)
      nodes.forEach(node => {
        const hasChildren = allEdgeData.some(e => e.from === node.id);
        if (hasChildren) {
          expandedNodes.add(node.id);
        }
      });
      
      // Update details panel if available
      if (details) {
        updateDetailsPanel(details);
      }
      
      // Fit the graph after stabilization
      network.once("stabilizationIterationsDone", function() {
        network.fit({
          animation: {
            duration: 1000,
            easingFunction: 'easeInOutQuad'
          }
        });
      });
    }

    function updateDetailsPanel(details) {
      const panel = document.getElementById('detailsPanel');
      if (!panel) return;
      
      let html = '<h4>Investigation Details</h4>';
      html += '<div class="details-content">';
      
      for (const [key, value] of Object.entries(details)) {
        if (Array.isArray(value)) {
          html += `<div class="detail-item"><strong>${key}:</strong> ${value.join(', ')}</div>`;
        } else if (typeof value === 'object') {
          html += `<div class="detail-item"><strong>${key}:</strong> ${JSON.stringify(value)}</div>`;
        } else {
          html += `<div class="detail-item"><strong>${key}:</strong> ${value}</div>`;
        }
      }
      
      html += '</div>';
      panel.innerHTML = html;
      panel.style.display = 'block';
    }

    function fitGraph() {
      if (network) {
        network.fit({
          animation: {
            duration: 1000,
            easingFunction: 'easeInOutQuad'
          }
        });
      }
    }

    function resetGraph() {
      if (network) {
        network.fit();
        network.redraw();
      }
    }

    function zoomIn() {
      if (network) {
        const scale = network.getScale() + 0.3;
        network.moveTo({
          scale: scale,
          animation: {
            duration: 400,
            easingFunction: 'easeInOutQuad'
          }
        });
      }
    }

    function zoomOut() {
      if (network) {
        const scale = Math.max(0.1, network.getScale() - 0.3);
        network.moveTo({
          scale: scale,
          animation: {
            duration: 400,
            easingFunction: 'easeInOutQuad'
          }
        });
      }
    }

    function expandAllNodes() {
      if (!network) return;
      
      // Get all nodes that have children
      const parentNodes = allEdgeData.map(e => e.from);
      const uniqueParents = [...new Set(parentNodes)];
      
      // Sort to ensure 'main' (root) is expanded first, then by depth
      const getDepth = (nodeId, depth = 0) => {
        const parent = allEdgeData.find(e => e.to === nodeId);
        return parent ? getDepth(parent.from, depth + 1) : depth;
      };
      
      uniqueParents.sort((a, b) => {
        if (a === 'main') return -1;
        if (b === 'main') return 1;
        return getDepth(a) - getDepth(b);
      });
      
      // Faster delays for large graphs
      const batchDelay = uniqueParents.length > 30 ? 50 : 100;
      
      // First pass: expand all collapsed parent nodes
      uniqueParents.forEach((nodeId, index) => {
        setTimeout(() => {
          if (!expandedNodes.has(nodeId)) {
            expandNode(nodeId);
          }
        }, index * batchDelay);
      });
      
      // Second pass: ensure all children are visible (handle nested cases)
      setTimeout(() => {
        uniqueParents.forEach((nodeId, index) => {
          setTimeout(() => {
            // Re-check and expand any children that might still be collapsed
            const childEdges = allEdgeData.filter(e => e.from === nodeId);
            childEdges.forEach(edge => {
              if (!nodesDataSet.get(edge.to) && allNodeData[edge.to]) {
                // Child not in dataset, add it
                const childNode = configureNodeWithImage(allNodeData[edge.to]);
                nodesDataSet.add(childNode);
                
                const edgeId = edge.id || `edge_${edge.from}_${edge.to}`;
                if (!edgesDataSet.get(edgeId)) {
                  edgesDataSet.add({ ...edge, id: edgeId });
                }
                expandedNodes.add(nodeId);
              }
            });
          }, index * 30);
        });
      }, uniqueParents.length * batchDelay + 300);
    }

    function collapseAllNodes() {
      if (!network) return;
      
      // Get all expanded nodes (except the root/main node)
      const nodesToCollapse = Array.from(expandedNodes).filter(id => id !== 'main');
      
      // Sort by depth (deepest first) for proper nested collapse
      const getDepth = (nodeId, depth = 0) => {
        const parent = allEdgeData.find(e => e.to === nodeId);
        return parent ? getDepth(parent.from, depth + 1) : depth;
      };
      
      nodesToCollapse.sort((a, b) => getDepth(b) - getDepth(a));
      
      // Faster collapse for large graphs
      const collapseDelay = nodesToCollapse.length > 30 ? 25 : 50;
      
      nodesToCollapse.forEach((nodeId, index) => {
        setTimeout(() => {
          collapseNode(nodeId);
        }, index * collapseDelay);
      });
    }

    function toggleSidebar() {
      const sidebar = document.querySelector('.sidebar');
      const overlay = document.getElementById('sidebarOverlay');
      sidebar.classList.toggle('active');
      overlay.classList.toggle('active');
    }

    // Initialize graph on page load
    document.addEventListener('DOMContentLoaded', function() {
      initGraph();
      
      // Load data if available from PHP
      <?php if (!empty($osintResults)): ?>
      const graphData = <?php echo json_encode($osintResults); ?>;
      loadGraphData(graphData.nodes, graphData.edges, graphData.details);
      <?php endif; ?>
    });

    // Handle window resize
    window.addEventListener('resize', function() {
      if (network) {
        network.redraw();
        network.fit();
      }
    });
  </script>
</body>
</html>
