<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';

// Get scan ID from URL parameter
$scanId = isset($_GET['id']) ? intval($_GET['id']) : 0;
?><!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Scan Details - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }

      .brand-logo {
        width: 28px;
        height: 28px;
      }

      .scan-header {
        padding: 16px;
      }

      .scan-meta {
        grid-template-columns: 1fr;
      }

      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .stat-number {
        font-size: 28px;
      }

      .finding-card {
        padding: 16px;
      }

      .finding-header {
        flex-direction: column;
      }

      .filter-bar {
        gap: 6px;
      }

      .filter-btn {
        padding: 8px 12px;
        font-size: 12px;
      }

      .user-name {
        display: none;
      }
    }

    .back-link { display: inline-flex; align-items: center; margin-bottom: 24px; color: #00E5FF; text-decoration: none; font-weight: 500; transition: all 0.3s ease; }
    .back-link:hover { color: #6C63FF; text-shadow: 0 0 10px rgba(108, 99, 255, 0.5); }
    .scan-header { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); padding: 24px; border-radius: 0; margin-bottom: 24px; border: 1px solid rgba(0, 229, 255, 0.15); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3); }
    .scan-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-top: 20px; }
    .meta-item { background: rgba(18, 24, 42, 0.8); padding: 16px; border-radius: 0; border: 1px solid rgba(0, 229, 255, 0.1); transition: all 0.3s ease; }
    .meta-item:hover { border-color: rgba(0, 229, 255, 0.3); box-shadow: 0 4px 15px rgba(0, 229, 255, 0.1); }
    .meta-label { color: #8A93A6; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; font-weight: 500; }
    .meta-value { color: #E6EAF2; font-size: 16px; margin-top: 6px; word-break: break-all; font-weight: 500; }
    .severity-badge {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 0;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .sev-critical { background: rgba(255, 77, 109, 0.2); color: #FF4D6D; border: 1px solid rgba(255, 77, 109, 0.3); }
    .sev-high { background: rgba(255, 77, 109, 0.15); color: #FF4D6D; border: 1px solid rgba(255, 77, 109, 0.25); }
    .sev-medium { background: rgba(255, 176, 32, 0.15); color: #ffb020; border: 1px solid rgba(255, 176, 32, 0.25); }
    .sev-low { background: rgba(61, 220, 132, 0.15); color: #3ddc84; border: 1px solid rgba(61, 220, 132, 0.25); }
    .finding-card {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border-radius: 0;
      padding: 20px;
      margin-bottom: 16px;
      border-left: 3px solid #00E5FF;
      border: 1px solid rgba(0, 229, 255, 0.15);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
    }
    .finding-card:hover { border-color: rgba(0, 229, 255, 0.3); box-shadow: 0 8px 30px rgba(0, 229, 255, 0.1); }
    .finding-card.critical { border-left-color: #FF4D6D; border-left-width: 4px; }
    .finding-card.high { border-left-color: #FF4D6D; border-left-width: 4px; }
    .finding-card.medium { border-left-color: #ffb020; border-left-width: 4px; }
    .finding-card.low { border-left-color: #3ddc84; border-left-width: 4px; }
    .finding-header { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }
    .finding-title { color: #E6EAF2; font-size: 16px; font-weight: 600; font-family: 'Orbitron', sans-serif; }
    .finding-type { color: #5FD1C8; font-size: 13px; font-weight: 500; letter-spacing: 0.5px; }
    .finding-url {
      background: rgba(18, 24, 42, 0.8);
      padding: 12px 16px;
      border-radius: 0;
      font-family: 'Fira Code', 'Consolas', monospace;
      font-size: 12px;
      word-break: break-all;
      color: #3ddc84;
      margin: 12px 0;
      border: 1px solid rgba(61, 220, 132, 0.2);
    }
    .finding-section { margin-top: 16px; }
    .finding-section-title { color: #8A93A6; font-size: 11px; text-transform: uppercase; margin-bottom: 8px; letter-spacing: 1px; font-weight: 500; }
    .finding-section-content {
      background: rgba(18, 24, 42, 0.8);
      padding: 14px;
      border-radius: 0;
      font-family: 'Fira Code', 'Consolas', monospace;
      font-size: 12px;
      color: #E6EAF2;
      white-space: pre-wrap;
      word-break: break-word;
      max-height: 200px;
      overflow-y: auto;
      border: 1px solid rgba(0, 229, 255, 0.1);
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-box {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      padding: 20px;
      border-radius: 0;
      text-align: center;
      border: 1px solid rgba(0, 229, 255, 0.15);
      transition: all 0.3s ease;
    }
    .stat-box:hover { border-color: rgba(0, 229, 255, 0.3); box-shadow: 0 4px 20px rgba(0, 229, 255, 0.1); }
    .stat-number { font-size: 36px; font-weight: 700; color: #00E5FF; font-family: 'Orbitron', sans-serif; text-shadow: 0 0 15px rgba(0, 229, 255, 0.3); }
    .stat-label { font-size: 12px; color: #8A93A6; margin-top: 8px; letter-spacing: 0.5px; text-transform: uppercase; }
    .no-findings { text-align: center; padding: 50px; color: #8A93A6; font-size: 15px; }
    .filter-bar { display: flex; gap: 10px; margin-bottom: 24px; flex-wrap: wrap; }
    .filter-btn {
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      color: #E6EAF2;
      padding: 10px 18px;
      border-radius: 0;
      cursor: pointer;
      font-size: 13px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    .filter-btn.active { background: rgba(0, 229, 255, 0.2); border-color: #00E5FF; color: #00E5FF; box-shadow: 0 0 15px rgba(0, 229, 255, 0.2); }
    .filter-btn:hover { background: rgba(0, 229, 255, 0.1); border-color: rgba(0, 229, 255, 0.4); }
    .hidden { display: none; }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
    <div class="brand">
      <img class="brand-logo" src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" />
      <div>
        <div class="brand-title">Wolf2X Finder</div>
        <div class="brand-sub">Scan Details</div>
      </div>
    </div>
    <div class="actions">
      <a href="index.php" class="pill" style="text-decoration: none; color: inherit;">← Back to Dashboard</a>
      <div class="user-dropdown" style="position: relative;">
        <div class="user-profile" onclick="toggleUserMenu()" style="cursor: pointer;">
          <img src="<?php echo $userPhoto ?: '../logo/wolf2xfinder.png'; ?>" alt="" class="user-avatar" />
          <span class="user-name"><?php echo htmlspecialchars($userName); ?></span>
          <span style="color: #00E5FF; margin-left: 5px;">▼</span>
        </div>
        <div class="user-menu" id="userMenu">
          <div style="padding: 12px 18px; border-bottom: 1px solid rgba(0, 229, 255, 0.1); color: #8A93A6; font-size: 12px;">
            <?php echo htmlspecialchars($userEmail); ?>
          </div>
          <a href="../auth/logout.php">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
            </svg>
            Logout
          </a>
        </div>
      </div>
    </div>
  </header>

  <main class="container">
    <div id="loadingOverlay" class="loading-overlay" style="display: flex;">
      <div class="loading-box">
        <div class="spinner"></div>
        <div class="loading-text">Loading scan details...</div>
      </div>
    </div>

    <div id="scanContent" style="display: none;">
      <div class="scan-header">
        <h2 style="margin: 0; color: #fff;">Scan #<span id="scanId"></span></h2>
        <div class="scan-meta">
          <div class="meta-item">
            <div class="meta-label">Target URL</div>
            <div class="meta-value" id="targetUrl"></div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Generated At</div>
            <div class="meta-value" id="generatedAt"></div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Pages Scanned</div>
            <div class="meta-value" id="pagesScanned"></div>
          </div>
          <div class="meta-item">
            <div class="meta-label">Received At</div>
            <div class="meta-value" id="receivedAt"></div>
          </div>
        </div>
      </div>

      <div class="stats-grid" id="statsGrid"></div>

      <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
          <div class="card-title" style="margin: 0;">Vulnerabilities Found (<span id="findingCount">0</span>)</div>
          <div class="filter-bar" id="severityFilters">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="Critical">Critical</button>
            <button class="filter-btn" data-filter="High">High</button>
            <button class="filter-btn" data-filter="Medium">Medium</button>
            <button class="filter-btn" data-filter="Low">Low</button>
          </div>
        </div>
        <div id="findingsList"></div>
      </div>
    </div>
      </main>
    </div>
  </div>

  <script>
    const scanId = <?php echo $scanId; ?>;

    function severityClass(severity) {
      const s = (severity || '').toLowerCase();
      if (s === 'critical') return 'critical';
      if (s === 'high') return 'high';
      if (s === 'medium') return 'medium';
      if (s === 'low') return 'low';
      return '';
    }

    function severityBadge(severity) {
      const s = (severity || '').toLowerCase();
      let cls = 'sev-' + s;
      let text = severity || 'Unknown';
      return `<span class="severity-badge ${cls}">${text}</span>`;
    }

    async function loadScanDetails() {
      try {
        const res = await fetch(`../api/scan_details.php?id=${scanId}`);
        const data = await res.json();

        if (!data.ok) {
          document.getElementById('findingsList').innerHTML = `<div class="no-findings">Error: ${data.error || 'Failed to load scan details'}</div>`;
          document.getElementById('loadingOverlay').style.display = 'none';
          document.getElementById('scanContent').style.display = 'block';
          return;
        }

        // Populate scan header
        document.getElementById('scanId').textContent = data.scan.id;
        document.getElementById('targetUrl').textContent = data.scan.target;
        document.getElementById('generatedAt').textContent = data.scan.generated_at;
        document.getElementById('pagesScanned').textContent = data.scan.total_pages;
        document.getElementById('receivedAt').textContent = data.scan.created_at;
        document.getElementById('findingCount').textContent = data.findings_count;

        // Populate stats
        const statsGrid = document.getElementById('statsGrid');
        const severityOrder = ['Critical', 'High', 'Medium', 'Low'];
        let statsHtml = '';
        severityOrder.forEach(sev => {
          const count = data.severity_summary[sev] || 0;
          if (count > 0 || sev === 'Low') {
            statsHtml += `
              <div class="stat-box">
                <div class="stat-number" style="color: ${getSeverityColor(sev)}">${count}</div>
                <div class="stat-label">${sev}</div>
              </div>
            `;
          }
        });
        // Add total
        statsHtml += `
          <div class="stat-box">
            <div class="stat-number" style="color: #6C63FF">${data.findings_count}</div>
            <div class="stat-label">Total</div>
          </div>
        `;
        statsGrid.innerHTML = statsHtml;

        // Populate findings
        const findingsList = document.getElementById('findingsList');
        if (data.findings.length === 0) {
          findingsList.innerHTML = '<div class="no-findings">No vulnerabilities found in this scan.</div>';
        } else {
          findingsList.innerHTML = data.findings.map(f => `
            <div class="finding-card ${severityClass(f.severity)}" data-severity="${f.severity}">
              <div class="finding-header">
                <div>
                  <div class="finding-type">${f.vuln_type}</div>
                  <div class="finding-title">${f.title}</div>
                </div>
                ${severityBadge(f.severity)}
              </div>
              <div class="finding-url">${f.url}</div>
              ${f.evidence ? `
                <div class="finding-section">
                  <div class="finding-section-title">Evidence</div>
                  <div class="finding-section-content">${escapeHtml(f.evidence)}</div>
                </div>
              ` : ''}
              ${f.recommendation ? `
                <div class="finding-section">
                  <div class="finding-section-title">Recommendation</div>
                  <div class="finding-section-content">${escapeHtml(f.recommendation)}</div>
                </div>
              ` : ''}
              <div style="margin-top: 10px; color: #666; font-size: 11px;">
                Found: ${f.created_at}
              </div>
            </div>
          `).join('');
        }

        // Setup filters
        setupFilters();

        // Show content
        document.getElementById('loadingOverlay').style.display = 'none';
        document.getElementById('scanContent').style.display = 'block';

      } catch (e) {
        console.error('Error loading scan details:', e);
        document.getElementById('findingsList').innerHTML = '<div class="no-findings">Error loading scan details. Please try again.</div>';
        document.getElementById('loadingOverlay').style.display = 'none';
        document.getElementById('scanContent').style.display = 'block';
      }
    }

    function getSeverityColor(severity) {
      const s = (severity || '').toLowerCase();
      if (s === 'critical') return '#ff4d4d';
      if (s === 'high') return '#ff6b6b';
      if (s === 'medium') return '#ffb020';
      if (s === 'low') return '#3ddc84';
      return '#00E5FF';
    }

    function escapeHtml(text) {
      if (!text) return '';
      return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    function setupFilters() {
      const buttons = document.querySelectorAll('#severityFilters .filter-btn');
      buttons.forEach(btn => {
        btn.addEventListener('click', () => {
          buttons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const filter = btn.dataset.filter;
          filterFindings(filter);
        });
      });
    }

    function filterFindings(severity) {
      const cards = document.querySelectorAll('.finding-card');
      cards.forEach(card => {
        if (severity === 'all' || card.dataset.severity === severity) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    }

    // User menu toggle
    function toggleUserMenu() {
      const menu = document.getElementById('userMenu');
      menu.classList.toggle('show');
    }

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
      const dropdown = document.querySelector('.user-dropdown');
      if (!dropdown.contains(e.target)) {
        document.getElementById('userMenu').classList.remove('show');
      }
    });

    // Load on page load
    if (scanId > 0) {
      loadScanDetails();
    } else {
      document.getElementById('findingsList').innerHTML = '<div class="no-findings">No scan ID provided. Please select a scan from the dashboard.</div>';
      document.getElementById('loadingOverlay').style.display = 'none';
      document.getElementById('scanContent').style.display = 'block';
    }
  </script>
</body>
</html>
