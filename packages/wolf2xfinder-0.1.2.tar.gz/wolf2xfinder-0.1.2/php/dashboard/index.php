<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';
?><!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Wolf2XFinder Live Dashboard</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
      font-weight: 500;
      letter-spacing: 0.3px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }

      .sidebar-header {
        padding: 20px 10px;
      }

      .sidebar-logo {
        width: 40px;
        height: 40px;
      }

      .sidebar-title {
        display: none;
      }

      .nav-item span {
        display: none;
      }

      .nav-item {
        padding: 16px;
        justify-content: center;
      }

      .main-content {
        margin-left: 70px;
      }

      .main-content .container {
        padding: 20px;
      }
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }

      .sidebar-header {
        display: none;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }

      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }

      .nav-item svg {
        width: 22px;
        height: 22px;
      }

      .nav-item span {
        display: block;
        font-size: 10px;
      }

      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }

      .sidebar-footer {
        display: none;
      }

      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }

      .main-content .container {
        padding: 15px;
      }

      .app-header {
        padding: 12px 15px;
      }

      .actions {
        gap: 10px;
      }

      .user-name {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div id="loadingOverlay" class="loading-overlay" aria-hidden="true">
    <div class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">Loading...</div>
    </div>
  </div>

  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          Dashboard
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          Send Report
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          Geo Analyzer
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          Profile
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          Logout
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <div class="pill">Live</div>
          <div class="user-dropdown" style="position: relative;">
            <div class="user-profile" onclick="toggleUserMenu()" style="cursor: pointer;">
              <img src="<?php echo $userPhoto ?: '../logo/wolf2xfinder.png'; ?>" alt="" class="user-avatar" />
              <span class="user-name"><?php echo htmlspecialchars($userName); ?></span>
              <span style="color: #00E5FF; margin-left: 5px;">▼</span>
            </div>
            <div class="user-menu" id="userMenu">
              <div style="padding: 12px 18px; border-bottom: 1px solid rgba(0, 229, 255, 0.1); color: #8A93A6; font-size: 12px;">
                <?php echo htmlspecialchars($userEmail); ?>
              </div>
              <a href="profile.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                Edit Profile
              </a>
              <a href="#" onclick="refreshData(); return false;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                  <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                </svg>
                Refresh Data
              </a>
              <a href="../auth/logout.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
                </svg>
                Logout
              </a>
            </div>
          </div>
        </div>
      </header>

      <main class="container">
    <section class="grid">
      <div class="card">
        <div class="card-title">Severity</div>
        <canvas id="severityChart" height="160"></canvas>
      </div>
      <div class="card">
        <div class="card-title">Top Vulnerability Types</div>
        <canvas id="typeChart" height="160"></canvas>
      </div>
    </section>

    <section class="card" style="margin-top: 14px;">
      <div class="card-title">Latest Findings</div>
      <div id="latestMeta" class="muted" style="margin-top: 6px;"></div>
      <div class="table-wrap" style="margin-top: 10px;">
        <table class="table" id="findingsTable">
          <thead>
            <tr>
              <th>Type</th>
              <th>Title</th>
              <th>Severity</th>
              <th>URL</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </section>

    <section class="card" style="margin-top: 14px;">
      <div class="card-title">Last Scans <span style="font-size: 12px; color: #888; font-weight: normal;">(Click any row for full details)</span></div>
      <div class="table-wrap" style="margin-top: 10px;">
        <table class="table" id="scansTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Target</th>
              <th>Generated</th>
              <th>Pages</th>
              <th>Findings</th>
              <th>Received</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </section>
    </main>
    </div>
  </div>

  <script>
    const COLORS = {
      bg: '#0B0F1A',
      header: '#12182A',
      text: '#E6EAF2',
      accent: '#00E5FF',
      accentSecondary: '#6C63FF',
      grid: 'rgba(0, 229, 255, 0.08)'
    };

    let severityChart;
    let typeChart;

    function severityColor(label) {
      const l = (label || '').toLowerCase();
      if (l === 'critical') return '#FF4D6D';
      if (l === 'high') return '#FF4D6D';
      if (l === 'medium') return '#ffb020';
      if (l === 'low') return '#3ddc84';
      return COLORS.accent;
    }

    async function fetchStats() {
      const res = await fetch('../api/stats.php', { cache: 'no-store' });
      return await res.json();
    }

    function renderTables(data) {
      const scansBody = document.querySelector('#scansTable tbody');
      scansBody.innerHTML = '';
      (data.scans || []).forEach(s => {
        const tr = document.createElement('tr');
        tr.style.cursor = 'pointer';
        tr.style.transition = 'background 0.3s ease';
        tr.onmouseenter = () => tr.style.background = 'rgba(0, 229, 255, 0.05)';
        tr.onmouseleave = () => tr.style.background = '';
        tr.onclick = () => window.location.href = `scan_details.php?id=${s.id}`;

        // Show findings count from API
        const count = s.findings_count || 0;
        const scanFindings = count > 0
          ? `<span style="color: #00E5FF; font-weight: 600;">${count}</span>`
          : '0';

        tr.innerHTML = `
          <td>${s.id}</td>
          <td class="wb">${s.target}</td>
          <td>${s.generated_at}</td>
          <td>${s.total_pages}</td>
          <td>${scanFindings}</td>
          <td>${s.created_at}</td>
          <td><a href="scan_details.php?id=${s.id}" class="view-btn" onclick="event.stopPropagation();">View →</a></td>
        `;
        scansBody.appendChild(tr);
      });

      const meta = document.getElementById('latestMeta');
      if (data.latest_scan_id) {
        meta.innerHTML = `Latest scan id: ${data.latest_scan_id} — <a href="scan_details.php?id=${data.latest_scan_id}" style="color: #00E5FF;">View Full Details →</a>`;
      } else {
        meta.textContent = 'No scans yet. Push from Python to /api/ingest.php';
      }

      const findingsBody = document.querySelector('#findingsTable tbody');
      findingsBody.innerHTML = '';
      (data.latest_findings || []).forEach(f => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${f.vuln_type}</td><td>${f.title}</td><td><span class="sev sev-${f.severity}">${f.severity}</span></td><td class="wb">${f.url}</td>`;
        findingsBody.appendChild(tr);
      });
    }

    function renderCharts(data) {
      const sev = data.severity || {};
      const sevLabels = Object.keys(sev);
      const sevValues = sevLabels.map(k => sev[k]);

      const sevCtx = document.getElementById('severityChart');
      if (severityChart) severityChart.destroy();
      severityChart = new Chart(sevCtx, {
        type: 'doughnut',
        data: {
          labels: sevLabels,
          datasets: [{
            data: sevValues,
            backgroundColor: sevLabels.map(severityColor),
            borderColor: COLORS.grid,
            borderWidth: 1,
          }]
        },
        options: {
          plugins: {
            legend: { labels: { color: COLORS.text } }
          }
        }
      });

      const types = data.types || [];
      const typeLabels = types.map(t => t.vuln_type);
      const typeValues = types.map(t => t.count);

      const typeCtx = document.getElementById('typeChart');
      if (typeChart) typeChart.destroy();
      typeChart = new Chart(typeCtx, {
        type: 'bar',
        data: {
          labels: typeLabels,
          datasets: [{
            label: 'Count',
            data: typeValues,
            backgroundColor: COLORS.accent,
            borderColor: COLORS.grid,
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            x: { ticks: { color: COLORS.text }, grid: { color: COLORS.grid } },
            y: { ticks: { color: COLORS.text }, grid: { color: COLORS.grid } },
          },
          plugins: {
            legend: { labels: { color: COLORS.text } }
          }
        }
      });
    }

    async function refresh() {
      const overlay = document.getElementById('loadingOverlay');
      try {
        overlay.classList.add('is-active');
        const data = await fetchStats();
        if (!data.ok) return;
        renderTables(data);
        renderCharts(data);
      } catch (e) {
      } finally {
        overlay.classList.remove('is-active');
      }
    }

    // User menu toggle
    function toggleUserMenu() {
      const menu = document.getElementById('userMenu');
      menu.classList.toggle('show');
    }

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
      const dropdown = document.querySelector('.user-dropdown');
      if (!dropdown.contains(e.target)) {
        document.getElementById('userMenu').classList.remove('show');
      }
    });

    function refreshData() {
      refresh();
      toggleUserMenu();
    }

    refresh();
    setInterval(refresh, 4000);
  </script>
</body>
</html>
