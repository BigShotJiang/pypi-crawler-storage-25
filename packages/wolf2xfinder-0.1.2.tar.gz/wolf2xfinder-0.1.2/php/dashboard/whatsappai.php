<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';

// API configuration
$apiConfig = [
    'openrouter' => [
        'url' => 'https://openrouter.ai/api/v1/chat/completions',
        'models' => ['openai/gpt-3.5-turbo', 'anthropic/claude-3-haiku', 'google/gemini-pro']
    ],
    'openai' => [
        'url' => 'https://api.openai.com/v1/chat/completions',
        'models' => ['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo']
    ],
    'gemini' => [
        'url' => 'https://generativelanguage.googleapis.com/v1beta/models',
        'models' => ['gemini-pro', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-3-flash-preview']
    ]
];

// Get saved settings from localStorage (client-side) since Firebase is used for WhatsApp data
// Database settings can be added later if needed
$settings = [];
$defaultProvider = 'openrouter';
$defaultModel = 'openai/gpt-3.5-turbo';
$aiEnabled = true;

$defaultProvider = $settings['ai_provider'] ?? 'openrouter';
$defaultModel = $settings['ai_model'] ?? 'openai/gpt-3.5-turbo';
$aiEnabled = $settings['ai_enabled'] ?? true;
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>WhatsApp AI - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <!-- Firebase SDK -->
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-auth-compat.js"></script>
  <!-- QR Code library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    /* WhatsApp Container */
    .whatsapp-container {
      display: grid;
      grid-template-columns: 350px 1fr;
      gap: 20px;
      height: calc(100vh - 140px);
    }

    /* Sidebar Chat List */
    .chat-sidebar {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .chat-sidebar-header {
      padding: 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
      background: rgba(0, 229, 255, 0.05);
    }

    .connection-status {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.9rem;
      margin-top: 10px;
    }

    .status-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #FF4757;
      animation: pulse 2s infinite;
    }

    .status-dot.connected {
      background: #00FF88;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .chat-list {
      flex: 1;
      overflow-y: auto;
      padding: 10px;
    }

    .chat-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      cursor: pointer;
      border-radius: 0;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
    }

    .chat-item:hover {
      background: rgba(0, 229, 255, 0.08);
      border-left-color: rgba(0, 229, 255, 0.5);
    }

    .chat-item.active {
      background: rgba(0, 229, 255, 0.1);
      border-left-color: #00E5FF;
    }

    .chat-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      color: #0B0F1A;
      font-size: 1.2rem;
      flex-shrink: 0;
    }

    .chat-info {
      flex: 1;
      min-width: 0;
    }

    .chat-name {
      font-weight: 500;
      color: #E6EAF2;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .chat-preview {
      font-size: 0.85rem;
      color: #8A93A6;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-top: 4px;
    }

    .chat-meta {
      text-align: right;
    }

    .chat-time {
      font-size: 0.75rem;
      color: #8A93A6;
    }

    .unread-badge {
      background: #00E5FF;
      color: #0B0F1A;
      font-size: 0.75rem;
      padding: 2px 6px;
      border-radius: 10px;
      margin-top: 4px;
      display: inline-block;
    }

    /* Chat Area */
    .chat-area {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      position: relative;
    }

    .chat-header {
      padding: 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
      background: rgba(0, 229, 255, 0.05);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .chat-header-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .ai-toggle-container {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .ai-toggle-label {
      font-size: 0.85rem;
      color: #8A93A6;
    }

    .toggle-switch {
      position: relative;
      width: 50px;
      height: 26px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 13px;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .toggle-switch.active {
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
    }

    .toggle-switch::after {
      content: '';
      position: absolute;
      width: 22px;
      height: 22px;
      background: #fff;
      border-radius: 50%;
      top: 2px;
      left: 2px;
      transition: transform 0.3s ease;
    }

    .toggle-switch.active::after {
      transform: translateX(24px);
    }

    .messages-container {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .message {
      max-width: 70%;
      padding: 12px 16px;
      border-radius: 0;
      position: relative;
      word-wrap: break-word;
    }

    .message.incoming {
      background: rgba(0, 229, 255, 0.1);
      border: 1px solid rgba(0, 229, 255, 0.2);
      align-self: flex-start;
      border-left: 3px solid #00E5FF;
    }

    .message.outgoing {
      background: rgba(95, 209, 200, 0.15);
      border: 1px solid rgba(95, 209, 200, 0.3);
      align-self: flex-end;
      border-right: 3px solid #5FD1C8;
    }

    .message.ai {
      background: linear-gradient(145deg, rgba(163, 125, 55, 0.15) 0%, rgba(163, 125, 55, 0.1) 100%);
      border: 1px solid rgba(163, 125, 55, 0.3);
      border-left: 3px solid #A37D37;
      align-self: flex-start;
    }

    .message-header {
      font-size: 0.75rem;
      color: #8A93A6;
      margin-bottom: 6px;
      display: flex;
      justify-content: space-between;
      gap: 10px;
    }

    .message-content {
      color: #E6EAF2;
      line-height: 1.5;
    }

    .message-time {
      font-size: 0.7rem;
      color: #8A93A6;
      margin-top: 6px;
      text-align: right;
    }

    .ai-indicator {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 0.7rem;
      color: #A37D37;
      background: rgba(163, 125, 55, 0.2);
      padding: 2px 8px;
      border-radius: 4px;
    }

    .chat-input-area {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.2);
      background: rgba(0, 229, 255, 0.05);
    }

    .chat-input-container {
      display: flex;
      gap: 12px;
    }

    .chat-input {
      flex: 1;
      padding: 14px 18px;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      color: #E6EAF2;
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .chat-input:focus {
      outline: none;
      border-color: #00E5FF;
      box-shadow: 0 0 15px rgba(0, 229, 255, 0.2);
    }

    .chat-input::placeholder {
      color: #8A93A6;
    }

    .btn-send {
      padding: 14px 28px;
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
      border: none;
      border-radius: 0;
      color: #0B0F1A;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-send:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 20px rgba(0, 229, 255, 0.3);
    }

    .btn-send:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
    }

    /* QR Code Section */
    .qr-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      padding: 40px;
      text-align: center;
    }

    .qr-container {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      margin: 20px 0;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }
    
    .pairing-code {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border: 2px solid #00E5FF;
      border-radius: 8px;
      padding: 20px 30px;
      margin: 15px 0;
      text-align: center;
    }
    
    .pairing-code-label {
      color: #8A93A6;
      font-size: 0.9rem;
      margin-bottom: 10px;
    }
    
    .pairing-code-value {
      color: #00E5FF;
      font-size: 2rem;
      font-weight: 700;
      letter-spacing: 8px;
      font-family: 'Courier New', monospace;
    }

    .qr-instructions {
      color: #8A93A6;
      font-size: 0.9rem;
      max-width: 400px;
      line-height: 1.6;
    }

    .btn-connect {
      padding: 14px 40px;
      font-size: 16px;
      background: linear-gradient(135deg, #5FD1C8 0%, #4ECDC4 100%);
      border: none;
      border-radius: 0;
      color: #0B0F1A;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 20px;
    }

    .btn-connect:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 30px rgba(95, 209, 200, 0.35);
    }

    /* Settings Panel */
    .settings-panel {
      background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      padding: 20px;
      margin-bottom: 20px;
    }

    .settings-title {
      font-size: 1.1rem;
      color: #00E5FF;
      margin-bottom: 16px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.2);
    }

    .form-group {
      margin-bottom: 16px;
    }

    .form-group label {
      display: block;
      margin-bottom: 8px;
      color: #E6EAF2;
      font-size: 0.9rem;
    }

    .form-group select,
    .form-group input {
      width: 100%;
      padding: 12px;
      background: rgba(18, 24, 42, 0.8);
      border: 1px solid rgba(0, 229, 255, 0.2);
      border-radius: 0;
      color: #E6EAF2;
      font-size: 0.9rem;
    }

    .form-group select:focus,
    .form-group input:focus {
      outline: none;
      border-color: #00E5FF;
      box-shadow: 0 0 10px rgba(0, 229, 255, 0.2);
    }

    .btn-save {
      padding: 12px 24px;
      background: linear-gradient(135deg, #00E5FF 0%, #00B8D4 100%);
      border: none;
      border-radius: 0;
      color: #0B0F1A;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-save:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 15px rgba(0, 229, 255, 0.3);
    }

    /* Loading indicator */
    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 40px;
      color: #8A93A6;
    }

    .loading-spinner {
      width: 40px;
      height: 40px;
      border: 3px solid rgba(0, 229, 255, 0.2);
      border-top-color: #00E5FF;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-right: 12px;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Typing indicator - fixed position above input */
    .typing-indicator {
      display: none;
      position: absolute;
      bottom: 80px;
      left: 20px;
      align-items: center;
      gap: 4px;
      padding: 8px 14px;
      background: rgba(163, 125, 55, 0.15);
      border: 1px solid rgba(163, 125, 55, 0.3);
      border-radius: 20px;
      z-index: 10;
      backdrop-filter: blur(4px);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    .typing-indicator.active {
      display: inline-flex;
    }

    .typing-indicator span {
      width: 8px;
      height: 8px;
      background: #A37D37;
      border-radius: 50%;
      animation: typing 1.4s infinite ease-in-out both;
    }

    .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
    .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }

    @keyframes typing {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }

    /* Responsive */
    @media (max-width: 1024px) {
      .whatsapp-container {
        grid-template-columns: 300px 1fr;
      }
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }
      .nav-item span {
        display: none;
      }
      .main-content {
        margin-left: 70px;
      }
      .whatsapp-container {
        grid-template-columns: 1fr;
      }
      .chat-sidebar {
        display: none;
      }
      .chat-sidebar.mobile-open {
        display: flex;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1000;
      }
    }

    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
      }
      .sidebar-header {
        display: none;
      }
      .sidebar-nav {
        flex-direction: row;
        justify-content: space-around;
        padding: 8px 0;
      }
      .nav-item {
        flex-direction: column;
        padding: 8px;
        font-size: 10px;
      }
      .sidebar-footer {
        display: none;
      }
      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
        <h1 class="page-title">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          WhatsApp AI Chat
        </h1>
        <p class="page-subtitle">Connect WhatsApp and chat with AI assistance</p>

        <!-- Settings Panel -->
        <div class="settings-panel">
          <div class="settings-title">AI Configuration</div>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 16px;">
            <div class="form-group">
              <label>AI Provider</label>
              <select id="aiProvider" onchange="updateModelOptions()">
                <option value="openrouter" <?php echo $defaultProvider === 'openrouter' ? 'selected' : ''; ?>>OpenRouter</option>
                <option value="openai" <?php echo $defaultProvider === 'openai' ? 'selected' : ''; ?>>OpenAI</option>
                <option value="gemini" <?php echo $defaultProvider === 'gemini' ? 'selected' : ''; ?>>Google Gemini</option>
              </select>
            </div>
            <div class="form-group">
              <label>AI Model</label>
              <select id="aiModel">
                <option value="openai/gpt-3.5-turbo" <?php echo $defaultModel === 'openai/gpt-3.5-turbo' ? 'selected' : ''; ?>>GPT-3.5 Turbo</option>
                <option value="anthropic/claude-3-haiku" <?php echo $defaultModel === 'anthropic/claude-3-haiku' ? 'selected' : ''; ?>>Claude 3 Haiku</option>
                <option value="google/gemini-pro" <?php echo $defaultModel === 'google/gemini-pro' ? 'selected' : ''; ?>>Gemini Pro</option>
                <option value="gemini-1.5-flash" <?php echo $defaultModel === 'gemini-1.5-flash' ? 'selected' : ''; ?>>Gemini 1.5 Flash</option>
                <option value="gemini-1.5-pro" <?php echo $defaultModel === 'gemini-1.5-pro' ? 'selected' : ''; ?>>Gemini 1.5 Pro</option>
              </select>
            </div>
            <div class="form-group">
              <label>Typing Style</label>
              <select id="typingStyle">
                <option value="natural">Natural (Human-like)</option>
                <option value="fast">Fast Response</option>
                <option value="detailed">Detailed & Slow</option>
                <option value="professional">Professional</option>
                <option value="casual">Casual & Friendly</option>
              </select>
            </div>
            <div class="form-group">
              <label>AI Personality Module</label>
              <select id="aiModule">
                <option value="assistant">General Assistant</option>
                <option value="cybersecurity">Cybersecurity Expert</option>
                <option value="support">Customer Support</option>
                <option value="teacher">Teacher/Educator</option>
                <option value="developer">Developer/Coder</option>
                <option value="creative">Creative Writer</option>
              </select>
            </div>
            <div class="form-group">
              <label>API Key</label>
              <input type="password" id="apiKey" placeholder="Enter your API key" />
            </div>
          </div>
          <button class="btn-save" onclick="saveSettings()" style="margin-top: 10px;">Save Settings</button>
        </div>

        <!-- QR Code Section (shown when not connected) -->
        <div id="qrSection" class="qr-section" style="display: none;">
          <h2 style="color: #00E5FF; margin-bottom: 20px;">Connect WhatsApp</h2>
          <p class="qr-instructions">
            <strong>Method 1 - QR Code:</strong> Scan the QR code below<br>
            <strong>Method 2 - Pairing Code:</strong> Enter the code manually in WhatsApp
          </p>
          <div id="qrcode" class="qr-container"></div>
          <div id="pairingCodeSection" class="pairing-code" style="display: none;">
            <div class="pairing-code-label">Pairing Code</div>
            <div class="pairing-code-value" id="pairingCode">----</div>
          </div>
          <p id="connectionStatus" style="color: #8A93A6; margin-top: 15px;">Waiting for connection...</p>
          <p id="connectionTime" style="color: #00E5FF; margin-top: 5px; font-size: 0.85rem; display: none;"></p>
          <div id="connectionLog" style="margin-top: 10px; max-height: 100px; overflow-y: auto; font-size: 0.75rem; color: #8A93A6; text-align: left; padding: 10px; background: rgba(0, 0, 0, 0.2); border-radius: 4px; display: none;"></div>
          <div style="display: flex; gap: 10px; margin-top: 15px;">
            <button class="btn-connect" onclick="connectWhatsApp()">Connect WhatsApp</button>
            <button class="btn-connect" onclick="refreshConnection()" style="background: linear-gradient(135deg, #FF6B6B 0%, #EE5A6F 100%);">Refresh</button>
          </div>
        </div>

        <!-- WhatsApp Chat Container (shown when connected) -->
        <div id="chatContainer" class="whatsapp-container">
          <!-- Chat List Sidebar -->
          <div class="chat-sidebar">
            <div class="chat-sidebar-header">
              <h3 style="color: #00E5FF; margin: 0;">Chats</h3>
              <div class="connection-status">
                <span class="status-dot connected" id="statusDot"></span>
                <span id="statusText">Connected</span>
                <button onclick="loadChats()" style="background: rgba(0, 229, 255, 0.1); border: 1px solid rgba(0, 229, 255, 0.3); color: #00E5FF; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; margin-left: auto;">Refresh</button>
              </div>
            </div>
            <div class="chat-list" id="chatList">
              <!-- Chat items will be loaded dynamically -->
              <div class="loading">
                <div class="loading-spinner"></div>
                <span>Loading chats...</span>
              </div>
            </div>
          </div>

          <!-- Chat Area -->
          <div class="chat-area">
            <div class="chat-header">
              <div class="chat-header-info">
                <div class="chat-avatar" id="currentChatAvatar">?</div>
                <div>
                  <div class="chat-name" id="currentChatName">Select a chat</div>
                  <div style="font-size: 0.8rem; color: #8A93A6;" id="currentChatNumber"></div>
                </div>
              </div>
              <div style="display: flex; align-items: center; gap: 15px;">
                <div class="ai-toggle-container">
                  <span class="ai-toggle-label">AI Mode</span>
                  <div class="toggle-switch <?php echo $aiEnabled ? 'active' : ''; ?>" id="aiToggle" onclick="toggleAI()"></div>
                </div>
                <button onclick="exitChat()" style="background: rgba(255, 77, 109, 0.1); border: 1px solid rgba(255, 77, 109, 0.3); color: #FF4D6D; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; display: flex; align-items: center; gap: 4px;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                  Exit Chat
                </button>
                <button onclick="logout()" style="background: rgba(138, 147, 166, 0.1); border: 1px solid rgba(138, 147, 166, 0.3); color: #8A93A6; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; display: flex; align-items: center; gap: 4px;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
                  Logout
                </button>
              </div>
            </div>

            <div class="messages-container" id="messagesContainer">
              <div style="text-align: center; color: #8A93A6; padding: 40px;">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin-bottom: 16px; opacity: 0.5;">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
                </svg>
                <p>Select a chat to start messaging</p>
              </div>
            </div>

            <!-- Typing Indicator -->
            <div class="typing-indicator" id="typingIndicator">
              <span></span>
              <span></span>
              <span></span>
              <span style="font-size: 0.8rem; color: #A37D37; margin-left: 8px;">AI is typing...</span>
            </div>

            <div class="chat-input-area">
              <div class="chat-input-container">
                <input type="text" class="chat-input" id="messageInput" placeholder="Type a message..." disabled />
                <button class="btn-send" id="sendBtn" onclick="sendMessage()" disabled>Send</button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <script>
    // Firebase Configuration
    const firebaseConfig = {
      apiKey: "AIzaSyAHk8zTYM13PvyiUBVyT05WHisXbaLOBvk",
      authDomain: "wolf2xfinder.firebaseapp.com",
      projectId: "wolf2xfinder",
      storageBucket: "wolf2xfinder.firebasestorage.app",
      messagingSenderId: "587045641390",
      appId: "1:587045641390:web:dcee105aba019fd358613f",
      measurementId: "G-3HWLN2Q1NE"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    const db = firebase.firestore();

    // Global variables
    let currentChat = null;
    let isAIEnabled = <?php echo $aiEnabled ? 'true' : 'false'; ?>;
    let isConnected = false;
    let wsConnection = null;
    const userId = '<?php echo $userId; ?>';

    // Load settings and chats on page load
    document.addEventListener('DOMContentLoaded', function() {
      loadSettings();
      checkConnection();
      loadChats();
      setupRealtimeListeners();
    });

    // Load saved settings from Firebase or localStorage
    function loadSettings() {
      // First try to load from localStorage
      const localSettings = localStorage.getItem('whatsapp_ai_settings_' + userId);
      let settings = localSettings ? JSON.parse(localSettings) : null;
      
      // Then try Firebase for more recent settings
      db.collection('whatsapp_settings').doc(userId).get()
        .then(doc => {
          if (doc.exists) {
            settings = doc.data();
          }
          applySettings(settings);
        })
        .catch(error => {
          console.error('Error loading from Firebase:', error);
          // Apply localStorage settings if Firebase fails
          if (settings) {
            applySettings(settings);
          }
        });
    }
    
    // Apply settings to form
    function applySettings(settings) {
      if (!settings) return;
      
      // Restore AI provider
      if (settings.ai_provider) {
        document.getElementById('aiProvider').value = settings.ai_provider;
        updateModelOptions();
      }
      
      // Restore AI model
      if (settings.ai_model) {
        document.getElementById('aiModel').value = settings.ai_model;
      }
      
      // Restore API key
      if (settings.api_key) {
        document.getElementById('apiKey').value = settings.api_key;
      }
      
      // Restore typing style
      if (settings.typing_style) {
        document.getElementById('typingStyle').value = settings.typing_style;
      }
      
      // Restore AI module
      if (settings.ai_module) {
        document.getElementById('aiModule').value = settings.ai_module;
      }
      
      // Restore AI enabled state
      if (settings.ai_enabled !== undefined) {
        isAIEnabled = settings.ai_enabled;
      } else {
        // Try localStorage fallback
        const savedAI = localStorage.getItem('whatsapp_ai_enabled_' + userId);
        if (savedAI !== null) {
          isAIEnabled = savedAI === 'true';
        }
      }
      const toggle = document.getElementById('aiToggle');
      toggle.classList.toggle('active', isAIEnabled);
    }

    // Check WhatsApp connection status
    async function checkConnection() {
      try {
        const res = await fetch('http://localhost:3000/status?userId=' + userId, {
          signal: AbortSignal.timeout(3000)
        });
        const data = await res.json();
        isConnected = data.connected;
        if (isConnected) {
          document.getElementById('qrSection').style.display = 'none';
          document.getElementById('chatContainer').style.display = 'grid';
        } else {
          document.getElementById('qrSection').style.display = 'flex';
          document.getElementById('chatContainer').style.display = 'none';
        }
      } catch (err) {
        console.error('Status check failed:', err);
        document.getElementById('qrSection').style.display = 'flex';
        document.getElementById('chatContainer').style.display = 'none';
        document.getElementById('connectionStatus').textContent = 'WhatsApp Server OFFLINE - Run: npm run dev';
        document.getElementById('connectionStatus').style.color = '#FF4D6D';
      }
    }

    // Refresh connection
    function refreshConnection() {
      // Clear QR and pairing code
      document.getElementById('qrcode').innerHTML = '';
      document.getElementById('pairingCodeSection').style.display = 'none';
      document.getElementById('connectionStatus').textContent = 'Refreshing connection...';
      document.getElementById('connectionStatus').style.color = '#8A93A6';
      document.getElementById('connectionLog').style.display = 'block';
      addLogEntry('Refreshing connection...');
      
      // If WebSocket is open, send refresh action
      if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
        wsConnection.send(JSON.stringify({ action: 'refresh', userId: userId }));
      } else {
        // Close and reconnect
        if (wsConnection) {
          wsConnection.close();
        }
        setTimeout(() => {
          connectWhatsApp();
        }, 1000);
      }
    }
    
    // Add entry to connection log
    function addLogEntry(message) {
      const logDiv = document.getElementById('connectionLog');
      const timestamp = new Date().toLocaleTimeString();
      const entry = document.createElement('div');
      entry.textContent = `[${timestamp}] ${message}`;
      logDiv.appendChild(entry);
      logDiv.scrollTop = logDiv.scrollHeight;
    }

    // Connect to WhatsApp
    async function connectWhatsApp() {
      document.getElementById('connectionStatus').textContent = 'Checking server...';
      document.getElementById('connectionLog').style.display = 'block';
      document.getElementById('connectionLog').innerHTML = '';
      addLogEntry('Checking server status...');
      
      // First check if server is running
      try {
        const healthCheck = await fetch('http://localhost:3000/health', { 
          method: 'GET',
          signal: AbortSignal.timeout(3000)
        });
        if (!healthCheck.ok) {
          throw new Error('Server health check failed');
        }
        addLogEntry('✓ Server is running');
      } catch (error) {
        addLogEntry('✗ Server not responding');
        document.getElementById('connectionStatus').textContent = 'WhatsApp Server OFFLINE - Start it first!';
        document.getElementById('connectionStatus').style.color = '#FF4D6D';
        return;
      }
      
      document.getElementById('connectionStatus').textContent = 'Connecting...';
      addLogEntry('Starting WhatsApp connection...');
      
      // Connect to WebSocket server
      wsConnection = new WebSocket('ws://localhost:3000');
      
      wsConnection.onopen = function() {
        console.log('Connected to WhatsApp server');
        addLogEntry('✓ Connected to server');
        wsConnection.send(JSON.stringify({ action: 'connect', userId: userId }));
      };
      
      wsConnection.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        // Handle heartbeat
        if (data.type === 'heartbeat') {
          // Respond to keep connection alive
          wsConnection.send(JSON.stringify({ type: 'pong' }));
          return;
        }
        
        if (data.type === 'qr') {
          // Generate QR code
          document.getElementById('qrcode').innerHTML = '';
          document.getElementById('qrcode').style.display = 'block';
          new QRCode(document.getElementById('qrcode'), {
            text: data.qr,
            width: 280,
            height: 280,
            colorDark: '#0B0F1A',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.H
          });
          document.getElementById('connectionStatus').textContent = 'Scan this QR code with your WhatsApp app (Settings > Linked Devices)';
          document.getElementById('connectionStatus').style.color = '#00E5FF';
          
          // Show QR generation time
          if (data.timeElapsed) {
            const timeDisplay = document.getElementById('connectionTime');
            timeDisplay.style.display = 'block';
            timeDisplay.textContent = `QR generated in ${(data.timeElapsed / 1000).toFixed(2)}s`;
            addLogEntry(`QR code ready (${(data.timeElapsed / 1000).toFixed(2)}s)`);
          } else {
            addLogEntry('QR code ready');
          }
        } else if (data.type === 'pairing_code') {
          // Show pairing code
          document.getElementById('pairingCode').textContent = data.code;
          document.getElementById('pairingCodeSection').style.display = 'block';
          document.getElementById('connectionStatus').textContent = 'Enter this code in WhatsApp > Linked Devices > Link with phone number';
          addLogEntry('Pairing code received');
        } else if (data.type === 'connected') {
          isConnected = true;
          document.getElementById('qrSection').style.display = 'none';
          document.getElementById('chatContainer').style.display = 'grid';
          
          // Show connection duration
          if (data.connectionDuration) {
            console.log(`Connected in ${(data.connectionDuration / 1000).toFixed(2)}s`);
            const timeDisplay = document.getElementById('connectionTime');
            timeDisplay.style.display = 'block';
            timeDisplay.textContent = `Connected in ${(data.connectionDuration / 1000).toFixed(2)}s`;
            addLogEntry(`✓ Connected successfully (${(data.connectionDuration / 1000).toFixed(2)}s)`);
          } else {
            addLogEntry('✓ Connected successfully');
          }
          
          loadChats();
        } else if (data.type === 'connecting') {
          // Show connecting state - hide QR and show loading
          document.getElementById('qrcode').style.display = 'none';
          document.getElementById('pairingCodeSection').style.display = 'none';
          document.getElementById('connectionStatus').textContent = data.message || 'Connecting to WhatsApp...';
          document.getElementById('connectionStatus').style.color = '#00FF88';
          addLogEntry(data.message || 'Connecting to WhatsApp...');
        } else if (data.type === 'refreshing') {
          document.getElementById('connectionStatus').textContent = data.message || 'Refreshing...';
          document.getElementById('connectionStatus').style.color = '#ffb020';
          addLogEntry(data.message || 'Refreshing...');
        } else if (data.type === 'disconnected') {
          document.getElementById('connectionStatus').textContent = 'Disconnected: ' + (data.reason || 'Connection lost') + (data.shouldReconnect ? ' - Reconnecting...' : '');
          document.getElementById('connectionStatus').style.color = '#ffb020';
          addLogEntry('✗ Disconnected: ' + (data.reason || 'Connection lost'));
          isConnected = false;
          
          // Only auto-reconnect client-side if server indicates it won't reconnect
          if (!data.shouldReconnect) {
            setTimeout(() => {
              if (!isConnected) {
                addLogEntry('Auto-reconnecting...');
                connectWhatsApp();
              }
            }, 3000);
          } else {
            addLogEntry('Server is reconnecting, waiting...');
          }
        } else if (data.type === 'error') {
          document.getElementById('connectionStatus').textContent = 'Error: ' + (data.message || 'Unknown error');
          document.getElementById('connectionStatus').style.color = '#FF4D6D';
          addLogEntry('✗ Error: ' + (data.message || 'Unknown error'));
        } else if (data.type === 'message') {
          handleIncomingMessage(data);
        } else if (data.type === 'messages_loaded') {
          handleLoadedMessages(data.messages);
        }
      };
      
      wsConnection.onerror = function(error) {
        console.error('WebSocket error:', error);
        addLogEntry('✗ WebSocket connection failed');
        document.getElementById('connectionStatus').textContent = 'Server not running. Start the server: npm run dev';
        document.getElementById('connectionStatus').style.color = '#FF4D6D';
      };
      
      wsConnection.onclose = function(event) {
        console.log('WebSocket closed:', event.code, event.reason);
        addLogEntry(`Connection closed (code: ${event.code})`);
        isConnected = false;
        
        // Auto-retry if not manually disconnected
        if (event.code !== 1000 && event.code !== 1005) {
          document.getElementById('connectionStatus').textContent = 'Reconnecting in 3 seconds...';
          setTimeout(() => {
            if (!isConnected) {
              connectWhatsApp();
            }
          }, 3000);
        }
      };
    }

    // Load chats from WhatsApp server
    async function loadChats() {
      const chatList = document.getElementById('chatList');
      chatList.innerHTML = '<div style="padding: 20px; text-align: center; color: #8A93A6;">Loading chats...</div>';
      
      try {
        const response = await fetch(`http://localhost:3000/chats/${userId}`);
        const data = await response.json();
        
        if (data.error) {
          chatList.innerHTML = '<div style="padding: 20px; text-align: center; color: #FF4D6D;">Error loading chats: ' + data.error + '</div>';
          return;
        }
        
        chatList.innerHTML = '';
        
        if (!data.chats || data.chats.length === 0) {
          chatList.innerHTML = '<div style="padding: 20px; text-align: center; color: #8A93A6;">No chats found</div>';
          return;
        }
        
        // Get last selected chat
        const lastChat = localStorage.getItem('whatsapp_last_chat_' + userId);
        const lastChatData = lastChat ? JSON.parse(lastChat) : null;
        let autoSelected = false;
        
        data.chats.forEach(chat => {
          const chatItem = createChatItem(chat.id, chat);
          chatList.appendChild(chatItem);
          
          // Auto-select last chat
          if (lastChatData && lastChatData.id === chat.id && !autoSelected) {
            selectChat(chat.id, chat, chatItem);
            autoSelected = true;
          }
        });
        
        console.log(`Loaded ${data.chats.length} chats`);
      } catch (error) {
        console.error('Error loading chats:', error);
        chatList.innerHTML = '<div style="padding: 20px; text-align: center; color: #FF4D6D;">Failed to load chats. Please check connection.</div>';
      }
    }

    // Create chat item element
    function createChatItem(chatId, chat) {
      const div = document.createElement('div');
      div.className = 'chat-item' + (currentChat === chatId ? ' active' : '');
      div.onclick = function() { selectChat(chatId, chat, this); };
      
      const initials = chat.name ? chat.name.split(' ').map(n => n[0]).join('').toUpperCase() : '?';
      const time = chat.lastMessageTime ? formatTimestamp(chat.lastMessageTime) : '';
      
      div.innerHTML = `
        <div class="chat-avatar">${initials}</div>
        <div class="chat-info">
          <div class="chat-name">${chat.name || chat.number}</div>
          <div class="chat-preview">${chat.lastMessage || 'No messages'}</div>
        </div>
        <div class="chat-meta">
          <div class="chat-time">${time}</div>
          ${chat.unread > 0 ? `<span class="unread-badge">${chat.unread}</span>` : ''}
        </div>
      `;
      
      return div;
    }

    // Select chat
    function selectChat(chatId, chat, element) {
      currentChat = chatId;
      
      // Save selected chat to localStorage
      localStorage.setItem('whatsapp_last_chat_' + userId, JSON.stringify({
        id: chatId,
        name: chat.name,
        number: chat.number
      }));
      
      // Update UI
      document.querySelectorAll('.chat-item').forEach(item => item.classList.remove('active'));
      if (element) {
        element.classList.add('active');
      }
      
      document.getElementById('currentChatName').textContent = chat.name || chat.number;
      document.getElementById('currentChatNumber').textContent = chat.number;
      document.getElementById('currentChatAvatar').textContent = chat.name ? chat.name.split(' ').map(n => n[0]).join('').toUpperCase() : '?';
      
      // Enable input
      document.getElementById('messageInput').disabled = false;
      document.getElementById('sendBtn').disabled = false;
      
      // Load messages
      loadMessages(chatId);
    }

    // Load messages for selected chat
    async function loadMessages(chatId) {
      const container = document.getElementById('messagesContainer');
      container.innerHTML = '<div class="loading"><div class="loading-spinner"></div><span>Loading messages...</span></div>';
      
      // Request messages from server via WebSocket
      if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
        wsConnection.send(JSON.stringify({ 
          action: 'load_messages', 
          userId: userId, 
          chatId: chatId 
        }));
      } else {
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: #FF4D6D;">Connection lost. Please reconnect.</div>';
      }
    }
    
    // Handle loaded messages from server
    function handleLoadedMessages(messages) {
      const container = document.getElementById('messagesContainer');
      container.innerHTML = '';
      
      if (!messages || messages.length === 0) {
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: #8A93A6;">No messages yet</div>';
        return;
      }
      
      messages.forEach(msg => {
        appendMessage(msg);
      });
      
      // Scroll to bottom
      container.scrollTop = container.scrollHeight;
    }

    // Append message to container
    function appendMessage(msg) {
      const container = document.getElementById('messagesContainer');
      const div = document.createElement('div');
      
      let msgClass = msg.fromMe ? 'outgoing' : 'incoming';
      if (msg.isAI) msgClass = 'ai';
      
      div.className = `message ${msgClass}`;
      
      const aiBadge = msg.isAI ? '<span class="ai-indicator"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/></svg> AI</span>' : '';
      
      div.innerHTML = `
        <div class="message-header">
          <span>${msg.sender}</span>
          ${aiBadge}
        </div>
        <div class="message-content">${escapeHtml(msg.message || msg.content)}</div>
        <div class="message-time">${formatTimestamp(msg.timestamp || Date.now())}</div>
      `;
      
      container.appendChild(div);
    }

    // Send message
    function sendMessage() {
      const input = document.getElementById('messageInput');
      const content = input.value.trim();
      if (!content || !currentChat) return;
      
      input.value = '';
      
      // Save to Firebase
      const msgData = {
        content: content,
        fromMe: true,
        sender: '<?php echo $userName; ?>',
        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
        isAI: false
      };
      
      db.collection('whatsapp_chats').doc(userId).collection('conversations').doc(currentChat)
        .collection('messages').add(msgData);
      
      // Update last message
      db.collection('whatsapp_chats').doc(userId).collection('conversations').doc(currentChat)
        .update({
          lastMessage: content,
          lastMessageTime: firebase.firestore.FieldValue.serverTimestamp()
        });
      
      // Send via WhatsApp
      if (wsConnection && isConnected) {
        wsConnection.send(JSON.stringify({
          action: 'send',
          to: currentChat,
          message: content
        }));
      }
      
      // If AI is enabled, generate AI response
      if (isAIEnabled) {
        showTypingIndicator();
        generateAIResponse(content);
      }
    }

    // Get system prompt based on AI module
    function getSystemPrompt() {
      const module = document.getElementById('aiModule').value;
      const prompts = {
        assistant: 'You are Wolf2X Finder AI, a helpful AI assistant for the Wolf2X Finder platform. Keep responses concise and friendly.',
        cybersecurity: 'You are Wolf2X Finder AI, a cybersecurity expert for the Wolf2X Finder platform. Provide accurate security advice, tips on vulnerability assessment, penetration testing, and best practices for securing systems. Keep responses professional and actionable.',
        support: 'You are Wolf2X Finder AI, a customer support specialist for the Wolf2X Finder platform. Be polite, patient, and helpful. Focus on understanding the user\'s issue and providing clear solutions.',
        teacher: 'You are Wolf2X Finder AI, an educator/teacher for the Wolf2X Finder platform. Explain concepts clearly, use examples, and encourage learning. Break down complex topics into understandable parts.',
        developer: 'You are Wolf2X Finder AI, a skilled software developer for the Wolf2X Finder platform. Provide code examples, debugging help, and technical solutions. Use best practices and explain your reasoning.',
        creative: 'You are Wolf2X Finder AI, a creative writer for the Wolf2X Finder platform. Help with storytelling, content creation, and imaginative ideas. Be inspiring and engaging.'
      };
      return prompts[module] || prompts.assistant;
    }

    // Calculate typing delay based on typing style
    function getTypingDelay(textLength) {
      const style = document.getElementById('typingStyle').value;
      const baseSpeeds = {
        natural: 50,      // 50ms per character (human-like)
        fast: 10,         // 10ms per character (fast)
        detailed: 80,     // 80ms per character (slow, detailed)
        professional: 30, // 30ms per character (professional)
        casual: 40      // 40ms per character (casual)
      };
      const baseDelay = baseSpeeds[style] || 50;
      const minDelay = 1000;  // Minimum 1 second
      const maxDelay = 5000;  // Maximum 5 seconds
      
      let delay = Math.max(minDelay, Math.min(maxDelay, textLength * baseDelay));
      
      // Add randomness for natural feel
      if (style === 'natural' || style === 'casual') {
        delay += Math.random() * 500;
      }
      
      return delay;
    }

    // Generate AI response
    async function generateAIResponse(userMessage) {
      const provider = document.getElementById('aiProvider').value;
      const model = document.getElementById('aiModel').value;
      const apiKey = document.getElementById('apiKey').value;
      
      if (!apiKey) {
        hideTypingIndicator();
        alert('Please enter your API key in settings');
        return;
      }
      
      const systemPrompt = getSystemPrompt();
      let apiUrl, requestBody;
      
      if (provider === 'openrouter') {
        apiUrl = 'https://openrouter.ai/api/v1/chat/completions';
        requestBody = {
          model: model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userMessage }
          ]
        };
      } else if (provider === 'gemini') {
        // Google Gemini API
        apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
        requestBody = {
          contents: [{
            parts: [{
              text: `${systemPrompt}\n\nUser: ${userMessage}`
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
          }
        };
      } else {
        apiUrl = 'https://api.openai.com/v1/chat/completions';
        requestBody = {
          model: model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userMessage }
          ]
        };
      }
      
      try {
        const headers = {
          'Content-Type': 'application/json'
        };
        
        if (provider !== 'gemini') {
          headers['Authorization'] = `Bearer ${apiKey}`;
          headers['HTTP-Referer'] = window.location.href;
          headers['X-Title'] = 'Wolf2XFinder WhatsApp AI';
        }
        
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify(requestBody)
        });
        
        const data = await response.json();
        
        // Check for API errors
        if (!response.ok) {
          const errorMsg = data.error?.message || data.message || `API Error: ${response.status} ${response.statusText}`;
          console.error('API Error:', errorMsg, data);
          hideTypingIndicator();
          alert(`AI API Error: ${errorMsg}\n\nPlease check your API key and try again.`);
          return;
        }
        
        // Extract AI response based on provider
        let aiResponse;
        if (provider === 'gemini') {
          if (data.candidates && data.candidates.length > 0 && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts.length > 0) {
            aiResponse = data.candidates[0].content.parts[0].text;
          } else {
            console.error('Invalid Gemini response structure:', data);
            hideTypingIndicator();
            alert('AI returned an invalid response. Please try again or check your API key.');
            return;
          }
        } else {
          if (data.choices && data.choices.length > 0 && data.choices[0].message) {
            aiResponse = data.choices[0].message.content;
          } else {
            console.error('Invalid OpenAI/OpenRouter response structure:', data);
            hideTypingIndicator();
            alert('AI returned an invalid response. Please try again or check your API key.');
            return;
          }
        }
        
        if (!aiResponse || aiResponse.trim() === '') {
          console.error('Empty AI response:', data);
          hideTypingIndicator();
          alert('AI returned an empty response. Please try again.');
          return;
        }
        
        // Calculate and apply typing delay
        const typingDelay = getTypingDelay(aiResponse.length);
        
        setTimeout(() => {
          hideTypingIndicator();
          
          // Save AI response
          const aiMsgData = {
            content: aiResponse,
            fromMe: true,
            sender: 'AI Assistant',
            timestamp: firebase.firestore.FieldValue.serverTimestamp(),
            isAI: true
          };
          
          db.collection('whatsapp_chats').doc(userId).collection('conversations').doc(currentChat)
            .collection('messages').add(aiMsgData);
          
          // Send AI response via WhatsApp if connected
          if (wsConnection && isConnected) {
            wsConnection.send(JSON.stringify({
              action: 'send',
              to: currentChat,
              message: aiResponse
            }));
          }
        }, typingDelay);
        
      } catch (error) {
        console.error('AI generation error:', error);
        hideTypingIndicator();
        alert(`AI Error: ${error.message}\n\nPlease check your internet connection and API key.`);
      }
    }

    // Update model options based on provider
    function updateModelOptions() {
      const provider = document.getElementById('aiProvider').value;
      const modelSelect = document.getElementById('aiModel');
      
      const models = {
        openrouter: [
          { value: 'openai/gpt-3.5-turbo', text: 'GPT-3.5 Turbo' },
          { value: 'anthropic/claude-3-haiku', text: 'Claude 3 Haiku' },
          { value: 'google/gemini-pro', text: 'Gemini Pro' }
        ],
        openai: [
          { value: 'gpt-3.5-turbo', text: 'GPT-3.5 Turbo' },
          { value: 'gpt-4', text: 'GPT-4' },
          { value: 'gpt-4-turbo', text: 'GPT-4 Turbo' }
        ],
        gemini: [
          { value: 'gemini-pro', text: 'Gemini Pro' },
          { value: 'gemini-1.5-flash', text: 'Gemini 1.5 Flash' },
          { value: 'gemini-1.5-pro', text: 'Gemini 1.5 Pro' },
          { value: 'gemini-3-flash-preview', text: 'Gemini 3 Flash Preview' }
        ]
      };
      
      modelSelect.innerHTML = '';
      (models[provider] || models.openrouter).forEach(model => {
        const option = document.createElement('option');
        option.value = model.value;
        option.textContent = model.text;
        modelSelect.appendChild(option);
      });
    }

    // Toggle AI mode
    function toggleAI() {
      isAIEnabled = !isAIEnabled;
      const toggle = document.getElementById('aiToggle');
      toggle.classList.toggle('active', isAIEnabled);
      
      // Save to localStorage
      localStorage.setItem('whatsapp_ai_enabled_' + userId, isAIEnabled);
    }

    // Exit chat - clear current chat selection
    function exitChat() {
      currentChat = null;
      
      // Clear from localStorage
      localStorage.removeItem('whatsapp_last_chat_' + userId);
      
      // Reset UI
      document.querySelectorAll('.chat-item').forEach(item => item.classList.remove('active'));
      document.getElementById('currentChatName').textContent = 'Select a chat';
      document.getElementById('currentChatNumber').textContent = '';
      document.getElementById('currentChatAvatar').textContent = '?';
      document.getElementById('messagesContainer').innerHTML = `
        <div style="text-align: center; color: #8A93A6; padding: 40px;">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin-bottom: 16px; opacity: 0.5;">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <p>Select a chat to start messaging</p>
        </div>
      `;
      
      // Disable input
      document.getElementById('messageInput').disabled = true;
      document.getElementById('sendBtn').disabled = true;
      
      addLogEntry('Exited chat');
    }

    // Logout - disconnect and redirect
    function logout() {
      if (confirm('Are you sure you want to logout?')) {
        // Disconnect WebSocket
        if (wsConnection) {
          wsConnection.close();
        }
        
        // Clear localStorage
        localStorage.removeItem('whatsapp_last_chat_' + userId);
        
        // Redirect to logout
        window.location.href = '../auth/logout.php';
      }
    }

    // Save settings
    async function saveSettings() {
      try {
        const provider = document.getElementById('aiProvider').value;
        const model = document.getElementById('aiModel').value;
        const apiKey = document.getElementById('apiKey').value;
        const typingStyle = document.getElementById('typingStyle').value;
        const aiModule = document.getElementById('aiModule').value;
        
        // Check if Firebase is initialized
        if (!firebase.apps.length) {
          alert('Firebase not initialized. Please refresh the page.');
          return;
        }
        
        // Create settings object
        const settingsData = {
          ai_provider: provider,
          ai_model: model,
          api_key: apiKey,
          typing_style: typingStyle,
          ai_module: aiModule,
          user_id: userId,
          updatedAt: new Date().toISOString()
        };
        
        // Save to localStorage as backup
        localStorage.setItem('whatsapp_ai_settings_' + userId, JSON.stringify(settingsData));
        
        // Try to save to Firebase
        await db.collection('whatsapp_settings').doc(userId).set(settingsData, { merge: true });
        
        alert('Settings saved successfully!');
      } catch (error) {
        console.error('Error saving settings:', error);
        // Still show success if localStorage backup worked
        alert('Settings saved to local storage. Firebase sync may require authentication.');
      }
    }

    // Handle incoming message from WebSocket
    function handleIncomingMessage(data) {
      // Display the message
      const msg = {
        fromMe: false,
        sender: data.sender || 'Unknown',
        from: data.from,
        message: data.message,
        timestamp: data.timestamp || Date.now(),
        type: 'incoming'
      };
      
      appendMessage(msg);
      
      // Scroll to bottom
      const container = document.getElementById('messagesContainer');
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
      
      // If AI is enabled and chat is selected, generate AI response
      if (isAIEnabled && currentChat === data.from) {
        generateAIResponse(data.message);
      }
    }

    // Setup realtime listeners
    function setupRealtimeListeners() {
      // Chat list is updated via Refresh button or on connection
      // Messages are loaded when selecting a chat
    }

    // Show typing indicator
    function showTypingIndicator() {
      document.getElementById('typingIndicator').classList.add('active');
      scrollToBottom();
    }

    // Hide typing indicator
    function hideTypingIndicator() {
      document.getElementById('typingIndicator').classList.remove('active');
    }

    // Scroll to bottom of messages
    function scrollToBottom() {
      const container = document.getElementById('messagesContainer');
      container.scrollTop = container.scrollHeight;
    }

    // Format time
    function formatTime(date) {
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    }

    // Escape HTML
    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    // Format timestamp like WhatsApp
    function formatTimestamp(timestamp) {
      const date = new Date(timestamp);
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const msgDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      
      if (msgDate.getTime() === today.getTime()) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } else if (msgDate.getTime() === today.getTime() - 86400000) {
        return 'Yesterday';
      } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
      }
    }
    
    // Format full timestamp for hover tooltip
    function formatFullTimestamp(timestamp) {
      const date = new Date(timestamp);
      return date.toLocaleString([], { 
        weekday: 'short',
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit' 
      });
    }

    // Handle Enter key
    document.getElementById('messageInput').addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        sendMessage();
      }
    });
  </script>
</body>
</html>
