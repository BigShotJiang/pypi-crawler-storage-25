<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';
$userPhoto = $_SESSION['user_photo'] ?? '';
$userRole = $_SESSION['user_role'] ?? 'user';

// Import PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once '../../PHPMailer-7.0.2/src/Exception.php';
require_once '../../PHPMailer-7.0.2/src/PHPMailer.php';
require_once '../../PHPMailer-7.0.2/src/SMTP.php';

$message = '';
$error = '';
$success = false;

// Pre-set email recipients
$recipients = [
    'prathiksha2k6@gmail.com',
    'malathika01p@gmail.com',
    'raghulraja2006@gmail.com',
    'Viniramesh7@gmail.com',
    'rajbala2829@gmail.com',
    'roshanebi005@gmail.com',
    'yogeshgandhi2005@gmail.com',
    'tamilselvan637986@gmail.com',
    'tamil.s343435@gmail.com'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = $_POST['subject'] ?? '';
    $body = $_POST['message'] ?? '';
    
    if (empty($subject) || empty($body)) {
        $error = 'Please enter both subject and message.';
    } else {
        try {
            $mail = new PHPMailer(true);
            
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'wolf2xfinder.in@gmail.com'; // Replace with your Gmail
            $mail->Password = 'pjjb npge tgby aehy'; // Replace with your App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            // Sender
            $mail->setFrom('wolf2xfinder.in@gmail.com', $userName);
            
            // Add all recipients (BCC to hide other recipients)
            foreach ($recipients as $recipient) {
                $mail->addBCC($recipient);
            }
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            
            // Set timezone for accurate date and time
            date_default_timezone_set('Asia/Kolkata');
            
            // Get current date and time
            $currentDate = date('F j, Y');
            $currentTime = date('g:i A');
            
            // Create HTML email template
            $htmlBody = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . htmlspecialchars($subject) . '</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .email-container { max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .email-header { background: linear-gradient(135deg, #0B0F1A 0%, #12182A 100%); padding: 30px; text-align: center; border-bottom: 3px solid #00E5FF; }
        .email-header h1 { color: #00E5FF; margin: 0; font-size: 24px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
        .email-header .subtitle { color: #8A93A6; margin: 8px 0 0 0; font-size: 14px; }
        .email-body { padding: 30px; color: #333333; line-height: 1.6; }
        .email-body h2 { color: #0B0F1A; margin-top: 0; font-size: 20px; border-bottom: 2px solid #00E5FF; padding-bottom: 10px; }
        .email-body .message-content { background-color: #f9f9f9; border-left: 4px solid #00E5FF; padding: 20px; margin: 20px 0; border-radius: 0 4px 4px 0; }
        .email-footer { background-color: #0B0F1A; color: #8A93A6; padding: 20px; text-align: center; font-size: 12px; border-top: 1px solid rgba(0, 229, 255, 0.2); }
        .email-footer a { color: #00E5FF; text-decoration: none; }
        .datetime { background: rgba(0, 229, 255, 0.1); border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 4px; padding: 10px 15px; margin: 15px 0; text-align: center; color: #0B0F1A; font-weight: 500; }
        .datetime .date { color: #00B8D4; font-size: 16px; }
        .datetime .time { color: #8A93A6; font-size: 14px; margin-top: 4px; }
        .sender-info { background: linear-gradient(145deg, #f0f0f0 0%, #e8e8e8 100%); padding: 15px; border-radius: 4px; margin-top: 20px; border-left: 3px solid #5FD1C8; }
        .sender-info strong { color: #0B0F1A; }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <h1>Wolf2X Finder</h1>
            <p class="subtitle">Broadcast Message</p>
        </div>
        
        <div class="email-body">
            <h2>' . htmlspecialchars($subject) . '</h2>
            
            <div class="datetime">
                <div class="date">' . $currentDate . '</div>
                <div class="time">' . $currentTime . '</div>
            </div>
            
            <div class="message-content">
                ' . nl2br(htmlspecialchars($body)) . '
            </div>
            
            <div class="sender-info">
                <strong>Sent by:</strong> ' . htmlspecialchars($userName) . '<br>
                <strong>User Email:</strong> ' . htmlspecialchars($userEmail) . '<br>
                <strong>User Role:</strong> ' . htmlspecialchars(ucfirst($userRole)) . '<br>
                <strong>User ID:</strong> ' . htmlspecialchars($userId) . '<br>
                <strong>From:</strong> Wolf2X Finder System
            </div>
        </div>
        
        <div class="email-footer">
            <p>This is an automated broadcast message from Wolf2X Finder</p>
            <p>Cyber Wolf Team | <a href="https://www.cyberwolf.pro">www.cyberwolf.pro</a></p>
            <p style="margin-top: 10px; font-size: 11px; color: #555;">Sent on ' . $currentDate . ' at ' . $currentTime . '</p>
        </div>
    </div>
</body>
</html>';
            
            $mail->Body = $htmlBody;
            $mail->AltBody = strip_tags($body);
            
            $mail->send();
            $success = true;
            $message = 'Message sent successfully to all recipients!';
        } catch (Exception $e) {
            $error = 'Message could not be sent. Error: ' . $mail->ErrorInfo;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Message Broadcast - Wolf2XFinder</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/auth.css" />
  <style>
    /* Sidebar Styles */
    .app-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 260px;
      background: #0B0F1A;
      border-right: 1px solid rgba(0, 229, 255, 0.1);
      display: flex;
      flex-direction: column;
      position: fixed;
      height: 100vh;
      z-index: 100;
      box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
    }

    .sidebar-header {
      padding: 30px 20px;
      border-bottom: 1px solid rgba(0, 229, 255, 0.1);
      text-align: center;
    }

    .sidebar-logo {
      width: 55px;
      height: 55px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(0, 229, 255, 0.3));
    }

    .sidebar-title {
      font-size: 1.2rem;
      font-weight: normal;
      color: #00E5FF;
      font-family: 'HeaderFont', 'Orbitron', sans-serif;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .sidebar-nav::-webkit-scrollbar {
      width: 4px;
    }

    .sidebar-nav::-webkit-scrollbar-track {
      background: rgba(0, 229, 255, 0.05);
    }

    .sidebar-nav::-webkit-scrollbar-thumb {
      background: rgba(0, 229, 255, 0.3);
      border-radius: 2px;
    }

    .sidebar-nav::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 229, 255, 0.5);
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 14px 24px;
      color: #FFFFFF;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      gap: 14px;
    }

    .nav-item:hover {
      background: rgba(0, 229, 255, 0.08);
      color: #00E5FF;
      text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
    }

    .nav-item.active {
      background: rgba(0, 229, 255, 0.1);
      color: #00E5FF;
      border-left-color: #00E5FF;
      text-shadow: 0 0 15px rgba(0, 229, 255, 0.5);
    }

    .nav-item.logout {
      color: #FFFFFF;
    }

    .nav-item.logout:hover {
      background: rgba(255, 77, 109, 0.1);
      color: #FF4D6D;
      text-shadow: 0 0 10px rgba(255, 77, 109, 0.5);
    }

    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(0, 229, 255, 0.1);
    }

    .main-content {
      flex: 1;
      margin-left: 260px;
      display: flex;
      flex-direction: column;
      background: #0B0F1A;
    }

    .main-content .container {
      padding: 30px;
      max-width: 1400px;
    }

    .page-title { color: #00E5FF; margin-bottom: 30px; }
    .page-subtitle { color: #8A93A6; margin-bottom: 30px; }
    .form-section { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; padding: 30px; margin-bottom: 20px; box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4); }
    .section-title { font-size: 1.3rem; color: #00E5FF; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(0, 229, 255, 0.2); font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; margin-bottom: 10px; color: #E6EAF2; font-weight: 500; letter-spacing: 0.5px; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 16px; border: 1px solid rgba(0, 229, 255, 0.2); border-radius: 0; background: rgba(18, 24, 42, 0.8); color: #E6EAF2; font-size: 0.95rem; transition: all 0.3s ease; font-family: 'TruenoLight', 'Inter', sans-serif; }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #00E5FF; box-shadow: 0 0 15px rgba(0, 229, 255, 0.2); }
    .form-group textarea { min-height: 120px; resize: vertical; }
    .recipients-list { background: linear-gradient(145deg, #12182A 0%, #0B0F1A 100%); border: 1px solid rgba(95, 209, 200, 0.2); border-radius: 0; padding: 20px; margin-bottom: 24px; }
    .recipients-title { font-size: 1.2rem; color: #5FD1C8; margin-bottom: 12px; font-weight: 600; letter-spacing: 0.5px; }
    .recipients-count { color: #8A93A6; font-size: 0.9rem; }
    .btn-send { width: auto; padding: 14px 40px; font-size: 16px; background: linear-gradient(135deg, #5FD1C8 0%, #4ECDC4 100%); border: none; border-radius: 0; color: #0B0F1A; font-weight: 600; cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); letter-spacing: 0.3px; box-shadow: 0 4px 20px rgba(95, 209, 200, 0.25); font-family: 'TruenoLight', 'Inter', sans-serif; display: block; margin: 0 auto; }
    .btn-send:hover { background: linear-gradient(135deg, #6FE5DC 0%, #5FD1C8 100%); transform: translateY(-2px); box-shadow: 0 6px 30px rgba(95, 209, 200, 0.35); }
    .alert { padding: 16px 20px; border-radius: 0; margin-bottom: 24px; font-weight: 500; }
    .alert-success { background: rgba(61, 220, 132, 0.1); border: 1px solid rgba(61, 220, 132, 0.3); color: #3ddc84; }
    .alert-error { background: rgba(255, 77, 109, 0.1); border: 1px solid rgba(255, 77, 109, 0.3); color: #FF4D6D; }
    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }
      .sidebar-header {
        padding: 20px 10px;
      }
      .sidebar-logo {
        width: 40px;
        height: 40px;
      }
      .sidebar-title {
        display: none;
      }
      .nav-item span {
        display: none;
      }
      .nav-item {
        padding: 16px;
        justify-content: center;
      }
      .main-content {
        margin-left: 70px;
      }
      .main-content .container {
        padding: 20px;
      }
    }
    @media (max-width: 480px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: fixed;
        bottom: 0;
        top: auto;
        flex-direction: row;
        border-right: none;
        border-top: 1px solid rgba(0, 229, 255, 0.1);
        padding: 8px 0;
        z-index: 1000;
      }
      .sidebar-header {
        display: none;
      }
      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        padding: 0;
      }
      .nav-item {
        flex-direction: column;
        padding: 8px 12px;
        border-left: none;
        border-top: 3px solid transparent;
        font-size: 10px;
        gap: 4px;
      }
      .nav-item svg {
        width: 22px;
        height: 22px;
      }
      .nav-item span {
        display: block;
        font-size: 10px;
      }
      .nav-item.active {
        border-left: none;
        border-top-color: #00E5FF;
      }
      .sidebar-footer {
        display: none;
      }
      .main-content {
        margin-left: 0;
        margin-bottom: 70px;
      }
      .main-content .container {
        padding: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <img src="../logo/wolf2xfinder.png" alt="Wolf2XFinder" class="sidebar-logo" />
        <div class="sidebar-title">Wolf2XFinder</div>
      </div>
      
      <nav class="sidebar-nav">
        <a href="index.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
          <span>Dashboard</span>
        </a>
        <a href="reportsender.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          <span>Send Report</span>
        </a>
        <a href="geolocations_analyser.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
            <path d="M2 12h20"/>
          </svg>
          <span>Geo Analyzer</span>
        </a>
        <a href="bot.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>AI Chat</span>
        </a>
        <a href="apitester.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
          </svg>
          <span>API Tester</span>
        </a>
        <a href="osint.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34L2.1 2.1"/>
          </svg>
          <span>OSINT Tool</span>
        </a>
        <a href="Message-broadcast.php" class="nav-item active">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
            <line x1="12" y1="13" x2="12" y2="21"/>
          </svg>
          <span>Message Broadcast</span>
        </a>
        <a href="whatsappai.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          <span>WhatsApp AI</span>
        </a>
        <a href="profile.php" class="nav-item">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <span>Profile</span>
        </a>
      </nav>

      <div class="sidebar-footer">
        <a href="../auth/logout.php" class="nav-item logout" style="margin-top: 15px; padding: 10px 24px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          <span>Logout</span>
        </a>
      </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
      <header class="app-header">
        <div class="brand">
          <div>
            <div class="brand-title">Wolf2X Finder</div>
            <div class="brand-sub">Cyber Wolf Team - www.cyberwolf.pro</div>
          </div>
        </div>
        <div class="actions">
          <a href="profile.php" class="btn-secondary">Profile</a>
        </div>
      </header>

      <main class="container">
    <h1 class="page-title">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
        <rect width="20" height="16" x="2" y="4" rx="2"/>
        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
      </svg>
      Message Broadcast
    </h1>
    <p class="page-subtitle">Send messages to all team members simultaneously</p>

    <?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="alert alert-success"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <!-- Recipients Info -->
      <div class="form-section">
        <div class="section-title">Recipients</div>
        <div class="recipients-list">
          <div class="recipients-title"><?php echo count($recipients); ?> team members will receive this message</div>
        </div>
      </div>

      <!-- Message Details -->
      <div class="form-section">
        <div class="section-title">Message Details</div>
        <div class="form-group">
          <label for="subject">Subject</label>
          <input type="text" id="subject" name="subject" required placeholder="Enter message subject" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" />
        </div>

        <div class="form-group">
          <label for="message">Message</label>
          <textarea id="message" name="message" required placeholder="Type your message here..."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
        </div>

        <button type="submit" class="btn-send">Send to All</button>
      </div>
    </form>
      </main>
    </div>
  </div>
</body>
</html>
