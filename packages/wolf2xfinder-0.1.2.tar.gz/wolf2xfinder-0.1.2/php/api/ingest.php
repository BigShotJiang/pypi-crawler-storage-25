<?php
// Disable HTML error output for JSON API
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/firebase.php';

// CORS headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
if (!$raw) {
  http_response_code(400);
  echo json_encode(['error' => 'Missing JSON body']);
  exit;
}

$data = json_decode($raw, true);
if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(['error' => 'Invalid JSON']);
  exit;
}

$target = isset($data['target']) ? (string)$data['target'] : '';
$generated_at = isset($data['generated_at']) ? (string)$data['generated_at'] : '';
$total_pages = isset($data['total_pages']) ? (int)$data['total_pages'] : 0;
$meta = isset($data['meta']) ? $data['meta'] : [];
$findings = isset($data['findings']) ? $data['findings'] : [];

if ($target === '' || $generated_at === '') {
  http_response_code(400);
  echo json_encode(['error' => 'target and generated_at are required']);
  exit;
}

$mysqli = wolf2x_db();

// Check connection
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed', 'detail' => $mysqli->connect_error]);
    exit;
}

$mysqli->begin_transaction();

try {
  $meta_json = json_encode($meta, JSON_UNESCAPED_UNICODE);

  $stmt = $mysqli->prepare('INSERT INTO scans (target, generated_at, total_pages, meta_json) VALUES (?, ?, ?, ?)');
  $stmt->bind_param('ssis', $target, $generated_at, $total_pages, $meta_json);
  $stmt->execute();
  $scan_id = $stmt->insert_id;
  $stmt->close();

  if (is_array($findings)) {
    $stmt2 = $mysqli->prepare('INSERT INTO findings (scan_id, vuln_type, title, severity, url, evidence, recommendation) VALUES (?, ?, ?, ?, ?, ?, ?)');

    foreach ($findings as $f) {
      $vuln_type = isset($f['vuln_type']) ? (string)$f['vuln_type'] : '';
      $title = isset($f['title']) ? (string)$f['title'] : '';
      $severity = isset($f['severity']) ? (string)$f['severity'] : '';
      $url = isset($f['url']) ? (string)$f['url'] : '';
      $evidence = isset($f['evidence']) ? (string)$f['evidence'] : '';
      $recommendation = isset($f['recommendation']) ? (string)$f['recommendation'] : '';

      if ($vuln_type === '' || $title === '' || $severity === '' || $url === '') {
        continue;
      }

      $stmt2->bind_param('issssss', $scan_id, $vuln_type, $title, $severity, $url, $evidence, $recommendation);
      $stmt2->execute();
    }

    $stmt2->close();
  }

  $mysqli->commit();

  // Sync scan data to Firestore if enabled
  $firestoreSynced = false;
  if (FirebaseHelper::isEnabled()) {
    try {
      // Sync scan to Firestore
      $scanData = [
        'target' => $target,
        'generated_at' => $generated_at,
        'total_pages' => $total_pages,
        'meta_json' => $meta_json,
        'created_at' => date('Y-m-d H:i:s')
      ];
      FirebaseHelper::syncScanToFirestore($scan_id, $scanData);

      // Sync findings to Firestore
      if (is_array($findings)) {
        foreach ($findings as $f) {
          $vuln_type = isset($f['vuln_type']) ? (string)$f['vuln_type'] : '';
          $title = isset($f['title']) ? (string)$f['title'] : '';
          $severity = isset($f['severity']) ? (string)$f['severity'] : '';
          $url = isset($f['url']) ? (string)$f['url'] : '';
          $evidence = isset($f['evidence']) ? (string)$f['evidence'] : '';
          $recommendation = isset($f['recommendation']) ? (string)$f['recommendation'] : '';

          if ($vuln_type !== '' && $title !== '' && $severity !== '' && $url !== '') {
            $findingData = [
              'scan_id' => $scan_id,
              'vuln_type' => $vuln_type,
              'title' => $title,
              'severity' => $severity,
              'url' => $url,
              'evidence' => $evidence,
              'recommendation' => $recommendation,
              'created_at' => date('Y-m-d H:i:s')
            ];
            FirebaseHelper::syncFindingToFirestore(0, $findingData); // 0 will auto-generate ID
          }
        }
      }

      $firestoreSynced = true;
    } catch (Exception $firebaseError) {
      error_log('Firestore sync error: ' . $firebaseError->getMessage());
      // Continue even if Firestore sync fails
    }
  }

  echo json_encode(['ok' => true, 'scan_id' => $scan_id, 'firestore_synced' => $firestoreSynced]);
} catch (Throwable $e) {
  $mysqli->rollback();
  http_response_code(500);
  echo json_encode(['error' => 'Ingest failed', 'detail' => $e->getMessage()]);
}
