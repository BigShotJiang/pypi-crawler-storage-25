<?php
// Disable HTML error output for JSON API
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../lib/db.php';

// CORS headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

$mysqli = wolf2x_db();

// Check connection
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Database connection failed']);
    exit;
}

// Get scan ID from query parameter
$scanId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($scanId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid scan ID']);
    exit;
}

// Get scan details
$scanStmt = $mysqli->prepare('SELECT id, target, generated_at, total_pages, created_at FROM scans WHERE id = ?');
$scanStmt->bind_param('i', $scanId);
$scanStmt->execute();
$scanRes = $scanStmt->get_result();
$scan = $scanRes->fetch_assoc();
$scanStmt->close();

if (!$scan) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Scan not found']);
    exit;
}

// Get all findings for this scan with full details
$findingsStmt = $mysqli->prepare('
    SELECT vuln_type, title, severity, url, evidence, recommendation, created_at 
    FROM findings 
    WHERE scan_id = ? 
    ORDER BY 
        CASE severity 
            WHEN "Critical" THEN 1 
            WHEN "High" THEN 2 
            WHEN "Medium" THEN 3 
            WHEN "Low" THEN 4 
            ELSE 5 
        END, 
        id DESC
');
$findingsStmt->bind_param('i', $scanId);
$findingsStmt->execute();
$findingsRes = $findingsStmt->get_result();
$findings = [];
while ($row = $findingsRes->fetch_assoc()) {
    $findings[] = $row;
}
$findingsStmt->close();

// Calculate severity summary
$severitySummary = [];
foreach ($findings as $f) {
    $sev = $f['severity'];
    if (!isset($severitySummary[$sev])) {
        $severitySummary[$sev] = 0;
    }
    $severitySummary[$sev]++;
}

echo json_encode([
    'ok' => true,
    'scan' => $scan,
    'findings' => $findings,
    'findings_count' => count($findings),
    'severity_summary' => $severitySummary,
]);

$mysqli->close();
