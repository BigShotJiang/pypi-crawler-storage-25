<?php
// Disable HTML error output for JSON API
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../lib/db.php';

// CORS headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

$mysqli = wolf2x_db();

// Check connection
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Database connection failed']);
    exit;
}

// Get scans with findings count
$scanRes = $mysqli->query('SELECT id, target, generated_at, total_pages, created_at FROM scans ORDER BY id DESC LIMIT 20');
$scans = [];
$scanIds = [];
while ($row = $scanRes->fetch_assoc()) {
  $scans[] = $row;
  $scanIds[] = $row['id'];
}

// Get findings count for each scan
$findingsCount = [];
if (!empty($scanIds)) {
  $placeholders = implode(',', array_fill(0, count($scanIds), '?'));
  $countStmt = $mysqli->prepare("SELECT scan_id, COUNT(*) as c FROM findings WHERE scan_id IN ($placeholders) GROUP BY scan_id");
  $types = str_repeat('i', count($scanIds));
  $countStmt->bind_param($types, ...$scanIds);
  $countStmt->execute();
  $countRes = $countStmt->get_result();
  while ($row = $countRes->fetch_assoc()) {
    $findingsCount[$row['scan_id']] = (int)$row['c'];
  }
  $countStmt->close();
}

// Add findings count to each scan
foreach ($scans as &$scan) {
  $scan['findings_count'] = $findingsCount[$scan['id']] ?? 0;
}
unset($scan); // Break reference

$severityRes = $mysqli->query("SELECT severity, COUNT(*) as c FROM findings GROUP BY severity");
$severity = [];
while ($row = $severityRes->fetch_assoc()) {
  $severity[$row['severity']] = (int)$row['c'];
}

$typeRes = $mysqli->query("SELECT vuln_type, COUNT(*) as c FROM findings GROUP BY vuln_type ORDER BY c DESC LIMIT 12");
$types = [];
while ($row = $typeRes->fetch_assoc()) {
  $types[] = ['vuln_type' => $row['vuln_type'], 'count' => (int)$row['c']];
}

$latestScanId = null;
if (count($scans) > 0) {
  $latestScanId = (int)$scans[0]['id'];
}

$latestFindings = [];
if ($latestScanId) {
  $stmt = $mysqli->prepare('SELECT vuln_type, title, severity, url, evidence, recommendation, created_at FROM findings WHERE scan_id=? ORDER BY id DESC LIMIT 200');
  $stmt->bind_param('i', $latestScanId);
  $stmt->execute();
  $res = $stmt->get_result();
  while ($row = $res->fetch_assoc()) {
    $latestFindings[] = $row;
  }
  $stmt->close();
}

echo json_encode([
  'ok' => true,
  'scans' => $scans,
  'severity' => $severity,
  'types' => $types,
  'latest_scan_id' => $latestScanId,
  'latest_findings' => $latestFindings,
]);
