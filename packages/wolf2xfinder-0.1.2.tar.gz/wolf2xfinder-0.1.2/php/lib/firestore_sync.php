<?php
// Firestore Sync Utility for Dashboard Data
// This file provides functions to sync MySQL data to Firestore

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/firebase.php';

/**
 * Sync all scans from MySQL to Firestore
 * @param int $limit Maximum number of scans to sync (default: 100)
 * @return array Results with success count and errors
 */
function syncAllScansToFirestore($limit = 100) {
    if (!FirebaseHelper::isEnabled()) {
        return ['success' => false, 'error' => 'Firebase is not enabled'];
    }

    $mysqli = wolf2x_db();
    $result = ['synced' => 0, 'errors' => 0, 'details' => []];

    try {
        $stmt = $mysqli->prepare('SELECT id, target, generated_at, total_pages, meta_json, created_at FROM scans ORDER BY id DESC LIMIT ?');
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $scans = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($scans as $scan) {
            $syncResult = FirebaseHelper::syncScanToFirestore($scan['id'], $scan);
            if ($syncResult) {
                $result['synced']++;
                $result['details'][] = ['scan_id' => $scan['id'], 'status' => 'success'];
            } else {
                $result['errors']++;
                $result['details'][] = ['scan_id' => $scan['id'], 'status' => 'error'];
            }
        }
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    } finally {
        $mysqli->close();
    }

    return $result;
}

/**
 * Sync all findings from MySQL to Firestore
 * @param int $limit Maximum number of findings to sync (default: 500)
 * @return array Results with success count and errors
 */
function syncAllFindingsToFirestore($limit = 500) {
    if (!FirebaseHelper::isEnabled()) {
        return ['success' => false, 'error' => 'Firebase is not enabled'];
    }

    $mysqli = wolf2x_db();
    $result = ['synced' => 0, 'errors' => 0, 'details' => []];

    try {
        $stmt = $mysqli->prepare('SELECT id, scan_id, vuln_type, title, severity, url, evidence, recommendation, created_at FROM findings ORDER BY id DESC LIMIT ?');
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $findings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($findings as $finding) {
            $syncResult = FirebaseHelper::syncFindingToFirestore($finding['id'], $finding);
            if ($syncResult) {
                $result['synced']++;
                $result['details'][] = ['finding_id' => $finding['id'], 'status' => 'success'];
            } else {
                $result['errors']++;
                $result['details'][] = ['finding_id' => $finding['id'], 'status' => 'error'];
            }
        }
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    } finally {
        $mysqli->close();
    }

    return $result;
}

/**
 * Sync all users from MySQL to Firestore
 * @param int $limit Maximum number of users to sync (default: 100)
 * @return array Results with success count and errors
 */
function syncAllUsersToFirestore($limit = 100) {
    if (!FirebaseHelper::isEnabled()) {
        return ['success' => false, 'error' => 'Firebase is not enabled'];
    }

    $mysqli = wolf2x_db();
    $result = ['synced' => 0, 'errors' => 0, 'details' => []];

    try {
        $stmt = $mysqli->prepare('SELECT id, email, name, photo_url, provider, role, created_at, last_login FROM users ORDER BY id DESC LIMIT ?');
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($users as $user) {
            $syncResult = FirebaseHelper::syncUserToFirestore($user['id'], $user);
            if ($syncResult) {
                $result['synced']++;
                $result['details'][] = ['user_id' => $user['id'], 'status' => 'success'];
            } else {
                $result['errors']++;
                $result['details'][] = ['user_id' => $user['id'], 'status' => 'error'];
            }
        }
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    } finally {
        $mysqli->close();
    }

    return $result;
}

/**
 * Sync all dashboard data to Firestore
 * @return array Results with summary of sync operations
 */
function syncAllToFirestore() {
    $results = [
        'users' => syncAllUsersToFirestore(),
        'scans' => syncAllScansToFirestore(),
        'findings' => syncAllFindingsToFirestore(),
        'timestamp' => date('Y-m-d H:i:s')
    ];

    $results['total_synced'] = 
        ($results['users']['synced'] ?? 0) + 
        ($results['scans']['synced'] ?? 0) + 
        ($results['findings']['synced'] ?? 0);

    $results['total_errors'] = 
        ($results['users']['errors'] ?? 0) + 
        ($results['scans']['errors'] ?? 0) + 
        ($results['findings']['errors'] ?? 0);

    return $results;
}

/**
 * Real-time sync for new scan (call this when a new scan is created)
 * @param int $scanId Scan ID to sync
 * @return bool Success status
 */
function syncNewScanToFirestore($scanId) {
    if (!FirebaseHelper::isEnabled()) {
        return false;
    }

    $mysqli = wolf2x_db();

    try {
        $stmt = $mysqli->prepare('SELECT id, target, generated_at, total_pages, meta_json, created_at FROM scans WHERE id = ?');
        $stmt->bind_param('i', $scanId);
        $stmt->execute();
        $scan = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($scan) {
            return FirebaseHelper::syncScanToFirestore($scanId, $scan);
        }

        return false;
    } catch (Exception $e) {
        error_log('Sync new scan error: ' . $e->getMessage());
        return false;
    } finally {
        $mysqli->close();
    }
}

/**
 * Real-time sync for new finding (call this when a new finding is created)
 * @param int $findingId Finding ID to sync
 * @return bool Success status
 */
function syncNewFindingToFirestore($findingId) {
    if (!FirebaseHelper::isEnabled()) {
        return false;
    }

    $mysqli = wolf2x_db();

    try {
        $stmt = $mysqli->prepare('SELECT id, scan_id, vuln_type, title, severity, url, evidence, recommendation, created_at FROM findings WHERE id = ?');
        $stmt->bind_param('i', $findingId);
        $stmt->execute();
        $finding = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($finding) {
            return FirebaseHelper::syncFindingToFirestore($findingId, $finding);
        }

        return false;
    } catch (Exception $e) {
        error_log('Sync new finding error: ' . $e->getMessage());
        return false;
    } finally {
        $mysqli->close();
    }
}

// If this file is called directly, run a sync
if (php_sapi_name() === 'cli' && isset($argv[1])) {
    $command = $argv[1];
    
    switch ($command) {
        case 'sync-all':
            echo "Syncing all data to Firestore...\n";
            $result = syncAllToFirestore();
            echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
            break;
            
        case 'sync-scans':
            echo "Syncing scans to Firestore...\n";
            $limit = isset($argv[2]) ? (int)$argv[2] : 100;
            $result = syncAllScansToFirestore($limit);
            echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
            break;
            
        case 'sync-findings':
            echo "Syncing findings to Firestore...\n";
            $limit = isset($argv[2]) ? (int)$argv[2] : 500;
            $result = syncAllFindingsToFirestore($limit);
            echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
            break;
            
        case 'sync-users':
            echo "Syncing users to Firestore...\n";
            $limit = isset($argv[2]) ? (int)$argv[2] : 100;
            $result = syncAllUsersToFirestore($limit);
            echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
            break;
            
        default:
            echo "Usage: php firestore_sync.php [sync-all|sync-scans|sync-findings|sync-users] [limit]\n";
    }
}
