<?php
// Supabase Helper Library for database operations
// Uses Supabase REST API for database operations

require_once __DIR__ . '/../config.php';

class SupabaseHelper {
    private static $config = null;
    private static $enabled = false;
    private static $url = '';
    private static $key = '';
    private static $serviceRoleKey = '';

    /**
     * Initialize Supabase configuration
     */
    private static function init() {
        if (self::$config !== null) {
            return;
        }

        self::$config = require __DIR__ . '/../config.php';
        self::$enabled = self::$config['supabase']['enabled'] ?? false;
        self::$url = self::$config['supabase']['url'] ?? '';
        self::$key = self::$config['supabase']['key'] ?? '';
        self::$serviceRoleKey = self::$config['supabase']['service_role_key'] ?? '';

        if (!self::$enabled || empty(self::$url) || empty(self::$key)) {
            self::$enabled = false;
        }
    }

    /**
     * Check if Supabase is enabled and configured
     */
    public static function isEnabled() {
        self::init();
        return self::$enabled;
    }

    /**
     * Make a request to Supabase REST API
     */
    private static function request($method, $endpoint, $data = null, $useServiceRole = false) {
        if (!self::isEnabled()) {
            return false;
        }

        $apiKey = $useServiceRole ? self::$serviceRoleKey : self::$key;
        if ($useServiceRole && empty(self::$serviceRoleKey)) {
            $apiKey = self::$key;
        }

        $url = rtrim(self::$url, '/') . '/' . ltrim($endpoint, '/');

        $headers = [
            'apikey: ' . $apiKey,
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json',
            'Prefer: return=representation'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        if ($data !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            error_log('Supabase request error: ' . $error);
            return ['error' => 'CURL error: ' . $error];
        }

        $result = json_decode($response, true);

        // Check for errors
        if ($httpCode >= 400) {
            error_log('Supabase API error: ' . $response);
            return ['error' => 'API error: ' . $response, 'code' => $httpCode];
        }

        return $result;
    }

    // ==================== SCAN OPERATIONS ====================

    /**
     * Insert or update a scan in Supabase
     */
    public static function upsertScan($scanData) {
        if (!self::isEnabled()) {
            return false;
        }

        $data = [
            'id' => $scanData['id'] ?? null,
            'target' => $scanData['target'] ?? '',
            'generated_at' => $scanData['generated_at'] ?? '',
            'total_pages' => $scanData['total_pages'] ?? 0,
            'meta_json' => isset($scanData['meta_json']) ? $scanData['meta_json'] : json_encode($scanData['meta'] ?? []),
            'created_at' => $scanData['created_at'] ?? date('Y-m-d H:i:s'),
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::request('POST', '/rest/v1/scans', $data, true);
    }

    /**
     * Get a scan from Supabase
     */
    public static function getScan($scanId) {
        if (!self::isEnabled()) {
            return false;
        }

        $result = self::request('GET', '/rest/v1/scans?id=eq.' . $scanId);
        if ($result && is_array($result) && count($result) > 0) {
            return $result[0];
        }
        return false;
    }

    /**
     * Delete a scan from Supabase
     */
    public static function deleteScan($scanId) {
        if (!self::isEnabled()) {
            return false;
        }

        return self::request('DELETE', '/rest/v1/scans?id=eq.' . $scanId, null, true);
    }

    // ==================== FINDING OPERATIONS ====================

    /**
     * Insert or update a finding in Supabase
     */
    public static function upsertFinding($findingData) {
        if (!self::isEnabled()) {
            return false;
        }

        $data = [
            'id' => $findingData['id'] ?? null,
            'scan_id' => $findingData['scan_id'] ?? 0,
            'vuln_type' => $findingData['vuln_type'] ?? '',
            'title' => $findingData['title'] ?? '',
            'severity' => $findingData['severity'] ?? '',
            'url' => $findingData['url'] ?? '',
            'evidence' => $findingData['evidence'] ?? '',
            'recommendation' => $findingData['recommendation'] ?? '',
            'created_at' => $findingData['created_at'] ?? date('Y-m-d H:i:s'),
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::request('POST', '/rest/v1/findings', $data, true);
    }

    /**
     * Get findings for a scan from Supabase
     */
    public static function getFindingsByScan($scanId) {
        if (!self::isEnabled()) {
            return false;
        }

        return self::request('GET', '/rest/v1/findings?scan_id=eq.' . $scanId);
    }

    /**
     * Delete findings for a scan from Supabase
     */
    public static function deleteFindingsByScan($scanId) {
        if (!self::isEnabled()) {
            return false;
        }

        return self::request('DELETE', '/rest/v1/findings?scan_id=eq.' . $scanId, null, true);
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Insert or update a user in Supabase
     */
    public static function upsertUser($userData) {
        if (!self::isEnabled()) {
            return false;
        }

        $data = [
            'id' => $userData['id'] ?? null,
            'email' => $userData['email'] ?? '',
            'name' => $userData['name'] ?? '',
            'photo_url' => $userData['photo_url'] ?? '',
            'provider' => $userData['provider'] ?? 'email',
            'role' => $userData['role'] ?? 'user',
            'created_at' => $userData['created_at'] ?? date('Y-m-d H:i:s'),
            'last_login' => $userData['last_login'] ?? null,
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::request('POST', '/rest/v1/users', $data, true);
    }

    /**
     * Get a user from Supabase
     */
    public static function getUser($userId) {
        if (!self::isEnabled()) {
            return false;
        }

        $result = self::request('GET', '/rest/v1/users?id=eq.' . $userId);
        if ($result && is_array($result) && count($result) > 0) {
            return $result[0];
        }
        return false;
    }

    /**
     * Get user by email from Supabase
     */
    public static function getUserByEmail($email) {
        if (!self::isEnabled()) {
            return false;
        }

        $result = self::request('GET', '/rest/v1/users?email=eq.' . urlencode($email));
        if ($result && is_array($result) && count($result) > 0) {
            return $result[0];
        }
        return false;
    }

    // ==================== SYNC OPERATIONS ====================

    /**
     * Sync scan data from MySQL to Supabase
     */
    public static function syncScan($scanId, $scanData) {
        return self::upsertScan($scanData);
    }

    /**
     * Sync finding data from MySQL to Supabase
     */
    public static function syncFinding($findingId, $findingData) {
        return self::upsertFinding($findingData);
    }

    /**
     * Sync user data from MySQL to Supabase
     */
    public static function syncUser($userId, $userData) {
        return self::upsertUser($userData);
    }
}
