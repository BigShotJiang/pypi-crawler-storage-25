<?php
// Firebase Helper Library for Firestore and Storage operations
// Requires: Google Cloud Firestore PHP SDK and Google Cloud Storage PHP SDK

require_once __DIR__ . '/../config.php';

class FirebaseHelper {
    private static $firestoreClient = null;
    private static $storageClient = null;
    private static $config = null;
    private static $enabled = false;

    /**
     * Initialize Firebase clients
     */
    private static function init() {
        if (self::$config !== null) {
            return;
        }

        self::$config = require __DIR__ . '/../config.php';
        self::$enabled = self::$config['firebase']['enabled'] ?? false;

        if (!self::$enabled) {
            return;
        }

        $serviceAccountPath = self::$config['firebase']['service_account_path'] ?? null;

        if (!$serviceAccountPath || !file_exists($serviceAccountPath)) {
            error_log('Firebase service account file not found: ' . $serviceAccountPath);
            self::$enabled = false;
            return;
        }

        // Check if SDKs are installed
        if (!class_exists('Google\Cloud\Firestore\FirestoreClient') && !class_exists('Google\Cloud\Storage\StorageClient')) {
            error_log('Firebase SDKs not installed. Run: composer require google/cloud-firestore google/cloud-storage');
            self::$enabled = false;
            return;
        }

        try {
            // Initialize Firestore client
            if (class_exists('Google\Cloud\Firestore\FirestoreClient')) {
                self::$firestoreClient = new Google\Cloud\Firestore\FirestoreClient([
                    'keyFilePath' => $serviceAccountPath
                ]);
            }

            // Initialize Storage client
            if (class_exists('Google\Cloud\Storage\StorageClient')) {
                self::$storageClient = new Google\Cloud\Storage\StorageClient([
                    'keyFilePath' => $serviceAccountPath
                ]);
            }
        } catch (Exception $e) {
            error_log('Firebase initialization error: ' . $e->getMessage());
            self::$enabled = false;
        }
    }

    /**
     * Check if Firebase is enabled and available
     */
    public static function isEnabled() {
        self::init();
        return self::$enabled;
    }

    /**
     * Get Firestore client
     */
    public static function getFirestore() {
        self::init();
        return self::$firestoreClient;
    }

    /**
     * Get Storage client
     */
    public static function getStorage() {
        self::init();
        return self::$storageClient;
    }

    /**
     * Get Storage bucket
     */
    public static function getStorageBucket() {
        self::init();
        if (!self::$storageClient) {
            return null;
        }

        $bucketName = self::$config['firebase']['storage_bucket'] ?? null;
        if (!$bucketName) {
            return null;
        }

        return self::$storageClient->bucket($bucketName);
    }

    // ==================== FIRESTORE OPERATIONS ====================

    /**
     * Add or update a document in Firestore
     * @param string $collection Collection name
     * @param string $documentId Document ID (null for auto-generated)
     * @param array $data Document data
     * @return string|bool Document ID on success, false on failure
     */
    public static function setDocument($collection, $documentId, $data) {
        if (!self::isEnabled() || !self::$firestoreClient) {
            return false;
        }

        try {
            $db = self::$firestoreClient;
            $collectionRef = $db->collection($collection);

            if ($documentId) {
                $docRef = $collectionRef->document($documentId);
                $docRef->set($data);
                return $documentId;
            } else {
                $docRef = $collectionRef->add($data);
                return $docRef->id();
            }
        } catch (Exception $e) {
            error_log('Firestore setDocument error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get a document from Firestore
     * @param string $collection Collection name
     * @param string $documentId Document ID
     * @return array|false Document data on success, false on failure
     */
    public static function getDocument($collection, $documentId) {
        if (!self::isEnabled() || !self::$firestoreClient) {
            return false;
        }

        try {
            $db = self::$firestoreClient;
            $docRef = $db->collection($collection)->document($documentId);
            $snapshot = $docRef->snapshot();

            if ($snapshot->exists()) {
                return $snapshot->data();
            }

            return false;
        } catch (Exception $e) {
            error_log('Firestore getDocument error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a document from Firestore
     * @param string $collection Collection name
     * @param string $documentId Document ID
     * @return bool True on success, false on failure
     */
    public static function deleteDocument($collection, $documentId) {
        if (!self::isEnabled() || !self::$firestoreClient) {
            return false;
        }

        try {
            $db = self::$firestoreClient;
            $docRef = $db->collection($collection)->document($documentId);
            $docRef->delete();
            return true;
        } catch (Exception $e) {
            error_log('Firestore deleteDocument error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Query documents from Firestore
     * @param string $collection Collection name
     * @param array $filters Array of filters [['field', 'operator', 'value']]
     * @param int $limit Maximum number of results
     * @return array|false Array of documents on success, false on failure
     */
    public static function queryDocuments($collection, $filters = [], $limit = null) {
        if (!self::isEnabled() || !self::$firestoreClient) {
            return false;
        }

        try {
            $db = self::$firestoreClient;
            $query = $db->collection($collection);

            foreach ($filters as $filter) {
                $query = $query->where($filter[0], $filter[1], $filter[2]);
            }

            if ($limit) {
                $query = $query->limit($limit);
            }

            $snapshot = $query->documents();
            $results = [];

            foreach ($snapshot as $doc) {
                if ($doc->exists()) {
                    $data = $doc->data();
                    $data['_id'] = $doc->id();
                    $results[] = $data;
                }
            }

            return $results;
        } catch (Exception $e) {
            error_log('Firestore queryDocuments error: ' . $e->getMessage());
            return false;
        }
    }

    // ==================== STORAGE OPERATIONS ====================

    /**
     * Upload a file to Firebase Storage
     * @param string $localPath Local file path
     * @param string $storagePath Storage path (e.g., 'profile/user123.jpg')
     * @param string $contentType MIME type (e.g., 'image/jpeg')
     * @return string|bool Public URL on success, false on failure
     */
    public static function uploadFile($localPath, $storagePath, $contentType = null) {
        if (!self::isEnabled() || !self::$storageClient) {
            return false;
        }

        try {
            $bucket = self::getStorageBucket();
            if (!$bucket) {
                return false;
            }

            $object = $bucket->upload(
                fopen($localPath, 'r'),
                [
                    'name' => $storagePath,
                    'metadata' => $contentType ? ['contentType' => $contentType] : []
                ]
            );

            // Make object public
            $object->update(['acl' => []]);
            $acl = $object->acl();
            $acl->add('allUsers', 'READER');
            $acl->update();

            return $object->signedUrl(new DateTime('+1 year'));
        } catch (Exception $e) {
            error_log('Firebase Storage uploadFile error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a file from Firebase Storage
     * @param string $storagePath Storage path
     * @return bool True on success, false on failure
     */
    public static function deleteFile($storagePath) {
        if (!self::isEnabled() || !self::$storageClient) {
            return false;
        }

        try {
            $bucket = self::getStorageBucket();
            if (!$bucket) {
                return false;
            }

            $object = $bucket->object($storagePath);
            if ($object->exists()) {
                $object->delete();
            }

            return true;
        } catch (Exception $e) {
            error_log('Firebase Storage deleteFile error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get a signed URL for a file
     * @param string $storagePath Storage path
     * @param int $expiresIn Expiration time in seconds (default: 1 hour)
     * @return string|bool Signed URL on success, false on failure
     */
    public static function getSignedUrl($storagePath, $expiresIn = 3600) {
        if (!self::isEnabled() || !self::$storageClient) {
            return false;
        }

        try {
            $bucket = self::getStorageBucket();
            if (!$bucket) {
                return false;
            }

            $object = $bucket->object($storagePath);
            if (!$object->exists()) {
                return false;
            }

            return $object->signedUrl(new DateTime('+' . $expiresIn . ' seconds'));
        } catch (Exception $e) {
            error_log('Firebase Storage getSignedUrl error: ' . $e->getMessage());
            return false;
        }
    }

    // ==================== DASHBOARD DATA SYNC ====================

    /**
     * Sync scan data to Firestore
     * @param int $scanId Scan ID
     * @param array $scanData Scan data array
     * @return string|bool Document ID on success, false on failure
     */
    public static function syncScanToFirestore($scanId, $scanData) {
        $data = [
            'scan_id' => $scanId,
            'target' => $scanData['target'] ?? '',
            'generated_at' => $scanData['generated_at'] ?? '',
            'total_pages' => $scanData['total_pages'] ?? 0,
            'meta_json' => $scanData['meta_json'] ?? '',
            'created_at' => $scanData['created_at'] ?? '',
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::setDocument('scans', (string)$scanId, $data);
    }

    /**
     * Sync finding data to Firestore
     * @param int $findingId Finding ID
     * @param array $findingData Finding data array
     * @return string|bool Document ID on success, false on failure
     */
    public static function syncFindingToFirestore($findingId, $findingData) {
        $data = [
            'finding_id' => $findingId,
            'scan_id' => $findingData['scan_id'] ?? 0,
            'vuln_type' => $findingData['vuln_type'] ?? '',
            'title' => $findingData['title'] ?? '',
            'severity' => $findingData['severity'] ?? '',
            'url' => $findingData['url'] ?? '',
            'evidence' => $findingData['evidence'] ?? '',
            'recommendation' => $findingData['recommendation'] ?? '',
            'created_at' => $findingData['created_at'] ?? '',
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::setDocument('findings', (string)$findingId, $data);
    }

    /**
     * Sync user profile to Firestore
     * @param int $userId User ID
     * @param array $userData User data array
     * @return string|bool Document ID on success, false on failure
     */
    public static function syncUserToFirestore($userId, $userData) {
        $data = [
            'user_id' => $userId,
            'email' => $userData['email'] ?? '',
            'name' => $userData['name'] ?? '',
            'photo_url' => $userData['photo_url'] ?? '',
            'provider' => $userData['provider'] ?? '',
            'role' => $userData['role'] ?? 'user',
            'created_at' => $userData['created_at'] ?? '',
            'last_login' => $userData['last_login'] ?? '',
            'synced_at' => date('Y-m-d H:i:s')
        ];

        return self::setDocument('users', (string)$userId, $data);
    }
}
