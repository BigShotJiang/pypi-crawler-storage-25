<?php
function wolf2x_db() {
  $configPath = __DIR__ . '/../config.php';
  if (!file_exists($configPath)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Missing config.php. Copy config.sample.php to config.php']);
    exit;
  }

  $cfg = require $configPath;
  $mysqli = new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
  if ($mysqli->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'DB connection failed', 'detail' => $mysqli->connect_error]);
    exit;
  }

  $mysqli->set_charset('utf8mb4');
  return $mysqli;
}
