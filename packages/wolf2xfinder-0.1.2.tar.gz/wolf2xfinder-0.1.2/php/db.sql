CREATE TABLE IF NOT EXISTS scans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target VARCHAR(2048) NOT NULL,
  generated_at VARCHAR(64) NOT NULL,
  total_pages INT NOT NULL DEFAULT 0,
  meta_json LONGTEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS findings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  scan_id BIGINT UNSIGNED NOT NULL,
  vuln_type VARCHAR(64) NOT NULL,
  title VARCHAR(512) NOT NULL,
  severity VARCHAR(16) NOT NULL,
  url VARCHAR(2048) NOT NULL,
  evidence LONGTEXT NULL,
  recommendation LONGTEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_scan_id (scan_id),
  KEY idx_severity (severity),
  KEY idx_vuln_type (vuln_type),
  CONSTRAINT fk_findings_scan
    FOREIGN KEY (scan_id) REFERENCES scans(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Users table for Firebase authentication
CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255) NULL,
  photo_url VARCHAR(512) NULL,
  provider VARCHAR(32) NULL DEFAULT 'email',
  role VARCHAR(32) NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL,
  PRIMARY KEY (id),
  KEY idx_email (email),
  KEY idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
