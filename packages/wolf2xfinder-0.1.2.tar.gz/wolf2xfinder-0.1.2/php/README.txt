# Wolf2XFinder PHP Dashboard

[![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?logo=php)](https://php.net)
[![MySQL](https://img.shields.io/badge/MySQL-5.7+-4479A1?logo=mysql)](https://mysql.com)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](../LICENSE)

> Real-time web dashboard for Wolf2XFinder security scanner results. Part of the Cyber Wolf Team toolkit.

## Quick Start

```bash
# 1. Copy to XAMPP htdocs
copy Wolf2X-Folder C:\xampp\htdocs\

# 2. Import database
# Open http://localhost/phpmyadmin
# Create database + import db.sql

# 3. Configure
copy config.sample.php config.php
# Edit config.php with your DB credentials

# 4. Access dashboard
open http://localhost/Wolf2X-Finder/php/dashboard/
```

## API Endpoints

| Endpoint | URL | Description |
|----------|-----|-------------|
| **Ingest** | `/php/api/ingest.php` | Receive scan results from Python scanner |
| **Stats** | `/php/api/stats.php` | Get aggregated vulnerability statistics |
| **Dashboard** | `/php/dashboard/` | Live monitoring interface |

## Python Scanner Integration

```bash
# Push scan results to dashboard
wolf2xfinder scan https://example.com \
  --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php
```

## Documentation

- **[SETUP_XAMPP.md](SETUP_XAMPP.md)** - Complete installation & troubleshooting
- **[Architecture](../docs/ARCHITECTURE.md)** - System design & data flow

---

**Cyber Wolf Team** • [www.cyberwolf.pro](https://www.cyberwolf.pro)
