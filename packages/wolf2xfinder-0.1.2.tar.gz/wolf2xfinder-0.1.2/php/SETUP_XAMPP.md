# Wolf2XFinder XAMPP Setup Guide

## Prerequisites
- XAMPP installed (PHP 8.x + MySQL/MariaDB)
- Python wolf2xfinder package installed

## Step 1: Database Setup

1. Start XAMPP Control Panel
2. Start **Apache** and **MySQL** services
3. Open http://localhost/phpmyadmin
4. Create a new database (e.g., `wolf2x_db`)
5. Import the database schema:
   - Click on your database
   - Go to "Import" tab
   - Choose file: `Wolf2X-Finder/php/db.sql`
   - Click "Go"

## Step 2: Configure Database Connection

1. Copy config file:
   ```
   Copy: php/config.sample.php
   To:   php/config.php
   ```

2. Edit `php/config.php` with your database credentials:
   ```php
   <?php
   return [
       'db_host' => 'localhost',
       'db_user' => 'root',
       'db_pass' => '',        // XAMPP default is empty
       'db_name' => 'wolf2x_db',
   ];
   ```

## Step 3: Deploy to XAMPP htdocs

1. Copy the entire `Wolf2X-Finder` folder to XAMPP htdocs:
   ```
   Source: C:\Users\HP\Downloads\Wolf2X-Finder
   Dest:   C:\xampp\htdocs\Wolf2X-Finder
   ```

2. Or create a symlink (optional):
   ```cmd
   mklink /D C:\xampp\htdocs\Wolf2X-Finder C:\Users\HP\Downloads\Wolf2X-Finder
   ```

## Step 4: Verify Installation

1. **Test API Ingest:**
   - URL: http://localhost/Wolf2X-Finder/php/api/ingest.php
   - Method: POST
   - Content-Type: application/json
   - Test payload:
     ```json
     {
       "target": "https://example.com",
       "generated_at": "2024-01-15T10:00:00Z",
       "total_pages": 5,
       "meta": {"team": "Cyber Wolf Team"},
       "findings": []
     }
     ```

2. **Test Stats API:**
   - Open: http://localhost/Wolf2X-Finder/php/api/stats.php
   - Should return JSON with `ok: true`

3. **Open Dashboard:**
   - URL: http://localhost/Wolf2X-Finder/php/dashboard/
   - Should show empty dashboard (no scans yet)

## Step 5: Run Python Scanner with Push

1. **Basic scan with push:**
   ```bash
   cd C:\Users\HP\Downloads\Wolf2X-Finder
   python -m wolf2xfinder scan https://example.com --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php
   ```

2. **Full scan with all options:**
   ```bash
   python -m wolf2xfinder scan https://example.com \
     --max-pages 20 \
     --timeout 15 \
     --rate-limit 0.5 \
     --formats json,html,pdf \
     --out reports/scan_001 \
     --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php
   ```

3. **Authenticated scan (if target requires auth):**
   ```bash
   python -m wolf2xfinder scan https://example.com \
     --auth-cookie "sessionid=abc123; token=xyz789" \
     --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php
   ```

## Folder Structure in XAMPP

```
C:\xampp\htdocs\Wolf2X-Finder\
├── php\
│   ├── api\
│   │   ├── ingest.php      # Receives scan results
│   │   └── stats.php       # Dashboard data feed
│   ├── dashboard\
│   │   └── index.php       # Live dashboard UI
│   ├── lib\
│   │   └── db.php          # Database connection
│   ├── assets\
│   │   └── css\
│   │       └── style.css   # Dashboard styles
│   ├── logo\
│   │   └── wolf2xfinder.png
│   ├── config.php          # Your DB config (create from sample)
│   └── db.sql              # Database schema
└── src\                    # Python package (optional here)
```

## Troubleshooting

### 404 Errors
- Check Apache is running in XAMPP Control Panel
- Verify folder path: `C:\xampp\htdocs\Wolf2X-Finder\php\`
- Try URL: http://localhost/Wolf2X-Finder/php/dashboard/

### Database Connection Failed
- Verify MySQL is running
- Check `php/config.php` credentials
- Default XAMPP: user=`root`, pass=`""` (empty)
- Test in phpMyAdmin first

### CORS Errors (if dashboard/API on different ports)
Add to `php/api/ingest.php` and `php/api/stats.php` after `<?php`:
```php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;
```

### Permission Denied
- Windows: Run XAMPP as Administrator
- Check folder permissions for `htdocs\Wolf2X-Finder`

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/php/api/ingest.php` | POST | Submit scan results |
| `/php/api/stats.php` | GET | Get dashboard statistics |

## Dashboard Features

- **Auto-refresh**: Every 4 seconds
- **Charts**: Severity distribution, vulnerability types
- **Tables**: Latest findings, scan history
- **Live indicator**: Shows when data is loading

## Next Steps

1. Access dashboard: http://localhost/Wolf2X-Finder/php/dashboard/
2. Run a scan with `--push-url`
3. Watch dashboard update in real-time
4. Export reports from `/reports/` folder
