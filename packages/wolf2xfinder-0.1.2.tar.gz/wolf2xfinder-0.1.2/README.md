<p align="center">
  <img src="https://github.com/Tamilselvan-S-Cyber-Security/Wolf2xfinder/blob/main/images/logo/wolf2xfinder.png" alt="Wolf2XFinder Logo" width="200">
</p>

<h1 align="center">Wolf2XFinder</h1>

<p align="center">
  <a href="https://pypi.org/project/wolf2xfinder/"><img src="https://img.shields.io/pypi/v/wolf2xfinder" alt="PyPI Version"></a>
  <a href="https://pypi.org/project/wolf2xfinder/"><img src="https://img.shields.io/pypi/pyversions/wolf2xfinder" alt="Python Version"></a>
  <a href="https://pypi.org/project/wolf2xfinder/"><img src="https://img.shields.io/pypi/l/wolf2xfinder" alt="License"></a>
  <a href="https://pypi.org/project/wolf2xfinder/"><img src="https://img.shields.io/pypi/dm/wolf2xfinder" alt="Downloads"></a>
  <a href="https://github.com/psf/black"><img src="https://img.shields.io/badge/code%20style-black-000000.svg" alt="Code Style"></a>
</p>

**Wolf Sec 2X Finder** - A comprehensive Python-based security vulnerability scanner with dashboard integration.

Developed by **Wolf2X Finder Development Team**  
- **Website:** https://tamilselvan-s-cyber-security.github.io/Wolf2xfinder/  
- **PyPI:** https://pypi.org/project/wolf2xfinder/  
- **GitHub:** https://github.com/Tamilselvan-S-Cyber-Security/Wolf2xfinder

---

## Features

- **15+ Vulnerability Checks:** XSS, SQL Injection, NoSQL Injection, SSRF, LFI/RFI, Command Injection, Path Traversal, XXE, XPath, Header Injection, LDAP Injection, Information Disclosure, SSL/TLS, CORS, CSRF
- **Real-time Progress:** ASCII art banner, animated progress bars, live finding reports
- **Dashboard Integration:** Push results to PHP dashboard with MySQL backend
- **Multiple Export Formats:** JSON, HTML, CSV, PDF
- **Authentication Support:** Bearer tokens, cookies, custom headers
- **Rate Limiting:** Respectful scanning with configurable delays
- **Standalone Executable:** Build single-file EXE for Windows

---

## Installation

### Install from PyPI (Recommended)

```bash
pip install wolf2xfinder
```

📦 **PyPI Package:** https://pypi.org/project/wolf2xfinder/

### Install from Source

```bash
# Clone repository
git clone https://github.com/Tamilselvan-S-Cyber-Security/Wolf2xfinder.git
cd Wolf2X-Finder

# Install in development mode
pip install -e .

# Or install from wheel
pip install dist/wolf2xfinder-0.1.0-py3-none-any.whl
```

## Quick Start

### 2. Basic Scan
```bash
wolf2xfinder scan https://example.com
```

### 3. Scan with Dashboard
```bash
# Test API first
wolf2xfinder test-push http://localhost/Wolf2X-Finder/php/api/ingest.php

# Then scan and push
wolf2xfinder scan https://example.com --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php
```

### 4. View Dashboard
Open: `http://localhost/Wolf2X-Finder/php/dashboard/`

---

## Documentation

| Document | Description |
|----------|-------------|
| **[PUBLISHING.md](PUBLISHING.md)** | PyPI publishing guide with commands |
| **[COMMANDS.md](COMMANDS.md)** | Complete command reference with examples |
| **[BUILD_INSTRUCTIONS.md](BUILD_INSTRUCTIONS.md)** | How to build wheel and executable |
| **[php/SETUP_XAMPP.md](php/SETUP_XAMPP.md)** | XAMPP setup for dashboard |
| **[php/README.txt](php/README.txt)** | Quick PHP setup guide |

---

## Key Commands

```bash
# Basic scan
wolf2xfinder scan https://example.com

# Scan with all options
wolf2xfinder scan https://example.com \
    --max-pages 10 \
    --timeout 15 \
    --rate-limit 0.5 \
    --auth-token "Bearer TOKEN" \
    --push-url http://localhost/Wolf2X-Finder/php/api/ingest.php \
    --out report \
    --formats pdf,html,json,csv

# Build package
python build_package.py --all

# XAMPP setup (see SETUP_XAMPP.md for details)
# 1. Start Apache & MySQL
# 2. Import php/db.sql into database
# 3. Copy php/config.sample.php to php/config.php
# 4. Access http://localhost/Wolf2X-Finder/php/dashboard/
```

---

## Architecture

```
┌─────────────────┐     ┌──────────────┐     ┌─────────────────┐
│   CLI Scanner   │────▶│  Dashboard   │────▶│   MySQL DB      │
│  (Python)       │     │   (PHP)      │     │                 │
└─────────────────┘     └──────────────┘     └─────────────────┘
        │                       │
        │ JSON Push              │ Read Stats
        ▼                       ▼
┌─────────────────┐     ┌──────────────┐
│  API Endpoint   │     │  Live Charts │
│  (ingest.php)   │     │  & Tables    │
└─────────────────┘     └──────────────┘
```

---

## Legal / Ethical Notice

⚠️ **Use this tool only on systems you own or where you have explicit written permission to test.**

Unauthorized scanning may violate:
- Computer Fraud and Abuse Act (USA)
- General Data Protection Regulation (EU)
- Local cybercrime laws

---

## Support

- **Website:** https://tamilselvan-s-cyber-security.github.io/Wolf2xfinder/
- **GitHub:** https://github.com/Tamilselvan-S-Cyber-Security/Wolf2xfinder
- **PyPI:** https://pypi.org/project/wolf2xfinder/
- **Team:** Wolf2X Finder Development Team
- **Version:** 0.1.0

---

