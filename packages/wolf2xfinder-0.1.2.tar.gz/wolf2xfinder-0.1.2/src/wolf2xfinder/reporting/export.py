from __future__ import annotations

from wolf2xfinder.core.types import ScanResults
from wolf2xfinder.reporting.formats import csv_export, html_export, json_export, pdf_export


def export_reports(results: ScanResults, out_prefix: str, formats: list[str]) -> list[str]:
    written: list[str] = []

    for fmt in formats:
        if fmt == "json":
            written.append(json_export.write_json(results, out_prefix + ".json"))
        elif fmt == "csv":
            written.append(csv_export.write_csv(results, out_prefix + ".csv"))
        elif fmt == "html":
            written.append(html_export.write_html(results, out_prefix + ".html"))
        elif fmt == "pdf":
            written.append(pdf_export.write_pdf(results, out_prefix + ".pdf"))
        else:
            raise ValueError(f"Unsupported format: {fmt}")

    return written
