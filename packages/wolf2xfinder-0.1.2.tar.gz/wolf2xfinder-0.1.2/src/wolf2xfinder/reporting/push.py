from __future__ import annotations

import json
import sys

import requests

from wolf2xfinder.core.types import ScanResults


class PushError(Exception):
    """Custom exception for push failures with helpful messages."""
    pass


def push_results(results: ScanResults, push_url: str, timeout: float = 10.0) -> None:
    """Push scan results to the PHP API endpoint."""
    payload = {
        "target": results.target,
        "generated_at": results.generated_at,
        "total_pages": results.total_pages,
        "meta": results.meta,
        "findings": [
            {
                "vuln_type": f.vuln_type,
                "title": f.title,
                "severity": f.severity,
                "url": f.url,
                "evidence": f.evidence,
                "recommendation": f.recommendation,
            }
            for f in results.findings
        ],
    }

    try:
        r = requests.post(
            push_url,
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=timeout,
        )
        r.raise_for_status()
    except requests.exceptions.ConnectionError as e:
        raise PushError(
            f"\n❌ Failed to connect to push URL: {push_url}\n"
            f"   Error: {str(e)}\n\n"
            f"   🔧 Troubleshooting:\n"
            f"   1. Make sure XAMPP Apache is running\n"
            f"   2. Check the URL is correct\n"
            f"   3. Verify the Wolf2X-Finder folder is in C:\\xampp\\htdocs\\\n"
            f"   4. Try: http://localhost/Wolf2X-Finder/php/api/ingest.php\n"
            f"   5. Or without subfolder: http://localhost/php/api/ingest.php"
        )
    except requests.exceptions.HTTPError as e:
        if r.status_code == 404:
            raise PushError(
                f"\n❌ API endpoint not found (404): {push_url}\n\n"
                f"   🔧 Troubleshooting:\n"
                f"   1. Check the URL path is correct:\n"
                f"      - With subfolder: http://localhost/Wolf2X-Finder/php/api/ingest.php\n"
                f"      - Direct: http://localhost/php/api/ingest.php\n"
                f"   2. Verify the file exists at: C:\\xampp\\htdocs\\Wolf2X-Finder\\php\\api\\ingest.php\n"
                f"   3. Check Apache is running in XAMPP Control Panel\n"
                f"   4. Look at php/api/ingest.php for any syntax errors"
            )
        elif r.status_code == 500:
            raise PushError(
                f"\n❌ Server error (500): PHP script crashed\n\n"
                f"   🔧 Troubleshooting:\n"
                f"   1. Check php/config.php exists and has correct DB credentials\n"
                f"   2. Verify database 'wolf2x_db' exists in phpMyAdmin\n"
                f"   3. Check Apache error logs: C:\\xampp\\apache\\logs\\error.log"
            )
        else:
            raise PushError(
                f"\n❌ HTTP error {r.status_code}: {r.reason}\n"
                f"   URL: {push_url}\n"
                f"   Response: {r.text[:200]}"
            )
    except requests.exceptions.Timeout:
        raise PushError(
            f"\n❌ Request timed out after {timeout}s\n"
            f"   URL: {push_url}\n"
            f"   The server may be slow or unresponsive"
        )
    except Exception as e:
        raise PushError(f"\n❌ Failed to push results: {str(e)}")


def test_push_url(push_url: str, timeout: float = 5.0) -> bool:
    """Test if the push URL is accessible."""
    try:
        # Try a simple GET first (ingest.php may not support GET, but we'll catch 404/connection errors)
        r = requests.get(push_url, timeout=timeout)
        # If we get any response (even 405 Method Not Allowed), the endpoint exists
        return r.status_code != 404
    except requests.exceptions.ConnectionError:
        return False
    except Exception:
        # Any other response means the server is up
        return True
