from __future__ import annotations

import csv
import sys

from wolf2xfinder.core.types import ScanResults


def write_csv(results: ScanResults, path: str) -> str:
    try:
        with open(path, "w", newline="", encoding="utf-8") as fp:
            w = csv.writer(fp)
            w.writerow(["vuln_type", "title", "severity", "url", "evidence", "recommendation"])
            for f in results.findings:
                w.writerow([f.vuln_type, f.title, f.severity, f.url, f.evidence, f.recommendation])
    except PermissionError:
        print(f"Error: Cannot write to '{path}' - permission denied.", file=sys.stderr)
        print(f"The file may be open in another program. Close it and try again, or use -o to specify a different output path.", file=sys.stderr)
        sys.exit(1)

    return path
