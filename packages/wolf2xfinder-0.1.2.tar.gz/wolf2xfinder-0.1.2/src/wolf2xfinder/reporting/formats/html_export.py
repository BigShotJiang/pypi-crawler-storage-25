from __future__ import annotations

import sys

from jinja2 import Template

from wolf2xfinder.core.types import ScanResults


_TEMPLATE = Template(
    """<!doctype html>
<html>
<head>
  <meta charset=\"utf-8\" />
  <title>Wolf2XFinder Report</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; color: #111; }
    h1 { margin-bottom: 4px; }
    .meta { color: #444; margin-bottom: 16px; }
    table { border-collapse: collapse; width: 100%; margin-top: 16px; }
    th, td { border: 1px solid #ddd; padding: 10px; vertical-align: top; }
    th { background: #f5f5f5; text-align: left; }
    .sev-High { color: #b00020; font-weight: bold; }
    .sev-Medium { color: #c77700; font-weight: bold; }
    .sev-Low { color: #1a7f37; font-weight: bold; }
  </style>
</head>
<body>
  <h1>Wolf Sec 2X Finder Report</h1>
  <div class=\"meta\">Developed by Cyber Wolf Team - www.cyberwolf.pro</div>
  <div class=\"meta\"><b>Target:</b> {{ target }}<br/>
  <b>Generated:</b> {{ generated_at }}<br/>
  <b>Pages checked:</b> {{ total_pages }}<br/>
  <b>Findings:</b> {{ findings|length }}</div>

  <table>
    <thead>
      <tr>
        <th>Type</th>
        <th>Title</th>
        <th>Severity</th>
        <th>URL</th>
        <th>Evidence</th>
        <th>Recommendation</th>
      </tr>
    </thead>
    <tbody>
      {% for f in findings %}
      <tr>
        <td>{{ f.vuln_type }}</td>
        <td>{{ f.title }}</td>
        <td class=\"sev-{{ f.severity }}\">{{ f.severity }}</td>
        <td style=\"word-break: break-all\">{{ f.url }}</td>
        <td style=\"white-space: pre-wrap\">{{ f.evidence }}</td>
        <td style=\"white-space: pre-wrap\">{{ f.recommendation }}</td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
</body>
</html>"""
)


def write_html(results: ScanResults, path: str) -> str:
    html = _TEMPLATE.render(
        target=results.target,
        generated_at=results.generated_at,
        total_pages=results.total_pages,
        findings=results.findings,
    )

    try:
        with open(path, "w", encoding="utf-8") as fp:
            fp.write(html)
    except PermissionError:
        print(f"Error: Cannot write to '{path}' - permission denied.", file=sys.stderr)
        print(f"The file may be open in another program. Close it and try again, or use -o to specify a different output path.", file=sys.stderr)
        sys.exit(1)

    return path
