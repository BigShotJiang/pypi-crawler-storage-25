from __future__ import annotations

import sys

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from wolf2xfinder.core.types import ScanResults


def write_pdf(results: ScanResults, path: str) -> str:
    doc = SimpleDocTemplate(path, pagesize=A4, title="Wolf2XFinder Report")
    styles = getSampleStyleSheet()

    story = []
    story.append(Paragraph("Wolf Sec 2X Finder Report", styles["Title"]))
    story.append(Paragraph("Developed by Cyber Wolf Team - www.cyberwolf.pro", styles["Normal"]))
    story.append(Spacer(1, 12))

    story.append(Paragraph(f"<b>Target:</b> {results.target}", styles["Normal"]))
    story.append(Paragraph(f"<b>Generated:</b> {results.generated_at}", styles["Normal"]))
    story.append(Paragraph(f"<b>Pages checked:</b> {results.total_pages}", styles["Normal"]))
    story.append(Paragraph(f"<b>Findings:</b> {len(results.findings)}", styles["Normal"]))
    story.append(Spacer(1, 12))

    data = [["Type", "Title", "Severity", "URL"]]
    for f in results.findings:
        data.append([f.vuln_type, f.title, f.severity, f.url])

    table = Table(data, colWidths=[70, 200, 80, 220], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f5f5f5")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ALIGN", (0, 0), (0, -1), "LEFT"),
                ("ALIGN", (1, 0), (1, -1), "LEFT"),
                ("ALIGN", (2, 0), (2, -1), "CENTER"),
                ("ALIGN", (3, 0), (3, -1), "LEFT"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#fafafa")]),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("WORDWRAP", (0, 0), (-1, -1), "CJK"),
            ]
        )
    )

    story.append(table)
    try:
        doc.build(story)
    except PermissionError:
        print(f"Error: Cannot write to '{path}' - permission denied.", file=sys.stderr)
        print(f"The file may be open in another program. Close it and try again, or use -o to specify a different output path.", file=sys.stderr)
        sys.exit(1)
    return path
