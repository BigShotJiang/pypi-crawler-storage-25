from __future__ import annotations

import json
import sys

from wolf2xfinder.core.types import ScanResults


def write_json(results: ScanResults, path: str) -> str:
    payload = {
        "target": results.target,
        "generated_at": results.generated_at,
        "total_pages": results.total_pages,
        "meta": results.meta,
        "findings": [
            {
                "vuln_type": f.vuln_type,
                "title": f.title,
                "severity": f.severity,
                "url": f.url,
                "evidence": f.evidence,
                "recommendation": f.recommendation,
            }
            for f in results.findings
        ],
    }

    try:
        with open(path, "w", encoding="utf-8") as fp:
            json.dump(payload, fp, indent=2, ensure_ascii=False)
    except PermissionError:
        print(f"Error: Cannot write to '{path}' - permission denied.", file=sys.stderr)
        print(f"The file may be open in another program. Close it and try again, or use -o to specify a different output path.", file=sys.stderr)
        sys.exit(1)

    return path
