import argparse
import sys

from wolf2xfinder.config import Config
from wolf2xfinder.core.scanner import ScanConfig, Wolf2XFinder
from wolf2xfinder.reporting.export import export_reports
from wolf2xfinder.reporting.push import push_results, PushError
from wolf2xfinder.utils import print_banner, print_scan_start, print_scan_complete, ScanProgress, print_status, print_vulnerability


def _parse_formats(value: str) -> list[str]:
    parts = [p.strip().lower() for p in value.split(",") if p.strip()]
    allowed = {"pdf", "html", "csv", "json"}
    unknown = [p for p in parts if p not in allowed]
    if unknown:
        raise argparse.ArgumentTypeError(f"Unknown format(s): {', '.join(unknown)}. Allowed: pdf,html,csv,json")
    return parts


def build_parser(cfg: Config) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wolf2xfinder",
        description="Wolf Sec 2X Finder (Cyber Wolf Team - www.cyberwolf.pro)\n\n"
                    "Commands:\n"
                    "  setup       Interactive setup wizard\n"
                    "  run         Interactive scan menu with options\n"
                    "  scan        Scan a website URL\n"
                    "  test-push   Test dashboard API connectivity",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup", help="Interactive configuration wizard")
    sub.add_parser("run", help="Interactive scan menu with options")

    test = sub.add_parser("test-push", help="Test dashboard API connectivity")
    test.add_argument("url", help="API endpoint URL to test (e.g., http://localhost/Wolf2X-Finder/php/api/ingest.php)")

    scan = sub.add_parser("scan", help="Scan a website URL")
    scan.add_argument("url", nargs="?", help="Target URL (include scheme, e.g. https://example.com)")
    scan.add_argument("--out", default=cfg.get("out_prefix", "wolf2xfinder_report"), help="Output path prefix (without extension)")
    scan.add_argument("--formats", type=_parse_formats, default=cfg.get("formats", ["json"]), help="Comma-separated list: pdf,html,csv,json")
    scan.add_argument("--timeout", type=float, default=cfg.get("timeout", 8.0), help="Request timeout in seconds (default: 8)")
    scan.add_argument("--max-pages", type=int, default=cfg.get("max_pages", 5), help="Max pages to crawl (default: 5)")
    scan.add_argument("--user-agent", default=cfg.get("user_agent", "wolf2xfinder/0.1"))
    scan.add_argument("--insecure", action="store_true", help="Disable TLS verification")
    scan.add_argument("-p", "--payloads", default="", help="Optional payloads file. One per line; supports 'type:payload' lines.")
    scan.add_argument("--push-url", default=cfg.get("push_url", ""), help="Optional: POST results JSON to this URL")
    scan.add_argument("--rate-limit", type=float, default=cfg.get("rate_limit", 0.0), help="Delay between requests in seconds (e.g., 0.5)")
    scan.add_argument("--auth-token", default="", help="Bearer token for authentication (Authorization header)")
    scan.add_argument("--auth-cookie", default="", help="Cookie string for authentication")
    scan.add_argument("--header", action="append", default=[], help="Custom header(s) in 'Name: Value' format (can be used multiple times)")

    return parser


def do_scan(args) -> int:
    """Execute scan with provided args."""
    print_banner()

    custom_headers: dict[str, str] = {}
    for header in args.header:
        if ":" in header:
            name, value = header.split(":", 1)
            custom_headers[name.strip()] = value.strip()

    print_scan_start(args.url)

    progress = ScanProgress(total_steps=100)

    config = ScanConfig(
        url=args.url,
        timeout=args.timeout,
        max_pages=args.max_pages,
        user_agent=args.user_agent,
        verify_tls=not args.insecure,
        rate_limit=args.rate_limit,
        auth_token=args.auth_token,
        auth_cookie=args.auth_cookie,
        custom_headers=custom_headers if custom_headers else None,
    )
    finder = Wolf2XFinder(config, progress_callback=progress)
    if args.payloads:
        finder.payloads.add_from_file(args.payloads)

    print_status(f"Max pages: {config.max_pages}, Timeout: {config.timeout}s", "info")
    if config.rate_limit > 0:
        print_status(f"Rate limit: {config.rate_limit}s between requests", "info")
    if config.auth_token or config.auth_cookie:
        print_status("Authentication enabled", "lock")
    print()

    results = finder.scan_all()
    progress.finish()

    if results.findings:
        print()
        print_status(f"Found {len(results.findings)} vulnerabilities:", "warning")
        for f in results.findings[:10]:
            print_vulnerability(f.vuln_type, f.severity, f.url)
        if len(results.findings) > 10:
            print_status(f"... and {len(results.findings) - 10} more", "info")

    export_reports(results, out_prefix=args.out, formats=args.formats)

    if args.push_url:
        print_status(f"Pushing results to {args.push_url}...", "web")
        try:
            push_results(results, args.push_url)
            print_status("Results pushed successfully!", "success")
        except PushError as e:
            print(str(e))
            print()
            print_status("Scan completed but push failed - reports saved locally", "warning")
        except Exception as e:
            print(f"\n Unexpected error during push: {e}")
            print_status("Scan completed but push failed - reports saved locally", "warning")

    print_scan_complete(len(results.findings), results.total_pages, args.out)
    return 0


def cmd_setup() -> int:
    """Interactive setup wizard."""
    print_banner()
    print("\n Wolf2XFinder Setup Wizard")
    print("=" * 40)
    cfg = Config()

    print("Configure your default settings. Press Enter to keep current value.\n")

    current = cfg.get("push_url", "")
    new = input(f" 1. API Push URL [{current or 'none'}]: ").strip()
    if new:
        cfg.set("push_url", new)

    current = cfg.get("out_prefix", "wolf2xfinder_report")
    new = input(f" 2. Default output prefix [{current}]: ").strip()
    if new:
        cfg.set("out_prefix", new)

    current = ",".join(cfg.get("formats", ["json"]))
    new = input(f" 3. Default formats [{current}]: ").strip()
    if new:
        cfg.set("formats", [x.strip() for x in new.split(",") if x.strip()])

    current = str(cfg.get("max_pages", 5))
    new = input(f" 4. Default max pages [{current}]: ").strip()
    if new:
        try:
            cfg.set("max_pages", int(new))
        except ValueError:
            print(" Invalid number, keeping current value.")

    current = str(cfg.get("timeout", 8.0))
    new = input(f" 5. Default timeout (seconds) [{current}]: ").strip()
    if new:
        try:
            cfg.set("timeout", float(new))
        except ValueError:
            print(" Invalid number, keeping current value.")

    current = str(cfg.get("rate_limit", 0.0))
    new = input(f" 6. Default rate limit (seconds) [{current}]: ").strip()
    if new:
        try:
            cfg.set("rate_limit", float(new))
        except ValueError:
            print(" Invalid number, keeping current value.")

    cfg.save()
    print("\n" + "=" * 40)
    print(" Setup complete! Configuration saved successfully.")
    print(f" Config file: {cfg.CONFIG_FILE}")
    print("\n You can now run:")
    print("   wolf2xfinder run       - Interactive menu")
    print("   wolf2xfinder scan URL  - Direct scan")
    return 0


def cmd_run() -> int:
    """Interactive menu for choosing scan options."""
    cfg = Config()

    print_banner()
    print("\n Wolf2XFinder - Interactive Scan Menu")
    print("=" * 40)
    print(" 1. Scan target URL only")
    print(" 2. Scan and export report (default format)")
    print(" 3. Scan and export ALL formats (PDF, HTML, CSV, JSON)")
    print(" 4. Scan, export report and push to API")
    print(" 5. Setup configuration")
    print(" 6. Exit")
    print("=" * 40)

    choice = input("\nEnter option [1-6]: ").strip()

    if choice == "6":
        print(" Exiting.")
        return 0

    if choice == "5":
        return cmd_setup()

    if choice not in {"1", "2", "3", "4"}:
        print(" Invalid option.")
        return 1

    url = input("Enter target URL (e.g., https://example.com): ").strip()
    if not url:
        print(" URL is required!")
        return 1

    argv = ["scan", url]

    if choice == "2":
        out = input(f"Output prefix [{cfg.get('out_prefix', 'report')}]: ").strip()
        if not out:
            out = cfg.get("out_prefix", "report")
        argv.extend(["--out", out])

    elif choice == "3":
        out = input(f"Output prefix [{cfg.get('out_prefix', 'report')}]: ").strip()
        if not out:
            out = cfg.get("out_prefix", "report")
        argv.extend(["--out", out, "--formats", "pdf,html,csv,json"])

    elif choice == "4":
        out = input(f"Output prefix [{cfg.get('out_prefix', 'report')}]: ").strip()
        if not out:
            out = cfg.get("out_prefix", "report")
        push_url = cfg.get("push_url", "")
        if push_url:
            push_input = input(f"API Push URL [{push_url}]: ").strip()
            if push_input:
                push_url = push_input
        else:
            push_url = input("API Push URL: ").strip()

        argv.extend(["--out", out, "--formats", "pdf,html,json"])
        if push_url:
            argv.extend(["--push-url", push_url])

    parser = build_parser(cfg)
    args = parser.parse_args(argv)
    return do_scan(args)


def main(argv: list[str] | None = None) -> int:
    cfg = Config()
    parser = build_parser(cfg)
    args = parser.parse_args(argv)

    if args.command == "test-push":
        from wolf2xfinder.reporting.push import test_push_url
        print_banner()
        print(f"Testing API endpoint: {args.url}")
        print()
        
        if test_push_url(args.url):
            print("✅ API endpoint is reachable!")
            print()
            print("The URL is valid. You can now run scans with --push-url")
            return 0
        else:
            print("❌ Cannot connect to API endpoint")
            print()
            print("Troubleshooting:")
            print("  1. Make sure XAMPP Apache is running")
            print("  2. Check the URL path is correct")
            print("  3. Verify Wolf2X-Finder is in C:\\xampp\\htdocs\\")
            return 1

    if args.command == "setup":
        return cmd_setup()

    if args.command == "run":
        return cmd_run()

    if args.command == "scan":
        if not args.url:
            print("Error: URL is required for scan.")
            print("Usage: wolf2xfinder scan <URL>")
            return 1
        return do_scan(args)

    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
