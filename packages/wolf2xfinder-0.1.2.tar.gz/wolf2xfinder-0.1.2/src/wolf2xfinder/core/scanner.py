from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from wolf2xfinder.core.types import Finding, ScanResults
from wolf2xfinder.payloads.registry import PayloadRegistry
from wolf2xfinder.scanners.checks import (
    check_basic_security_headers,
    check_command_injection,
    check_cors_misconfig,
    check_csrf_forms,
    check_information_disclosure,
    check_lfi,
    check_nosql,
    check_open_redirect,
    check_path_traversal,
    check_reflected_xss,
    check_rfi,
    check_ssl_tls_issues,
    check_ssrf,
    check_sqli_error_based,
    check_xss_dom,
)


@dataclass(frozen=True)
class ScanConfig:
    url: str
    timeout: float = 8.0   # Reduced from 12s for faster scanning
    max_pages: int = 5     # Reduced from 10 for quicker scans
    user_agent: str = "wolf2xfinder/0.1"
    verify_tls: bool = True
    rate_limit: float = 0.0  # Seconds between requests
    auth_token: str = ""  # Bearer token for authentication
    auth_cookie: str = ""  # Cookie for authentication
    custom_headers: dict | None = None  # Additional custom headers


class Wolf2XFinder:
    def __init__(self, config: ScanConfig, payloads: PayloadRegistry | None = None, progress_callback=None):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": config.user_agent})

        # Configure authentication
        if config.auth_token:
            self.session.headers.update({"Authorization": f"Bearer {config.auth_token}"})
        if config.auth_cookie:
            self.session.headers.update({"Cookie": config.auth_cookie})
        if config.custom_headers:
            self.session.headers.update(config.custom_headers)

        self.payloads = payloads if payloads is not None else PayloadRegistry.default()
        self._last_request_time: float = 0
        self._progress = progress_callback

    def add_payloads(self, vuln_type: str, payloads: list[str]) -> "Wolf2XFinder":
        self.payloads.add(vuln_type, payloads)
        return self

    def _apply_rate_limit(self) -> None:
        """Apply rate limiting between requests."""
        if self.config.rate_limit > 0:
            import time
            elapsed = time.time() - self._last_request_time
            if elapsed < self.config.rate_limit:
                time.sleep(self.config.rate_limit - elapsed)
            self._last_request_time = time.time()

    def _update_progress(self, phase: str | None = None, increment: int = 0) -> None:
        """Update progress if callback is set."""
        if self._progress:
            if phase:
                self._progress.update_phase(phase)
            if increment:
                self._progress.increment(increment)

    def scan_all(self) -> ScanResults:
        target = self._normalize_url(self.config.url)
        base = self._base_origin(target)

        self._update_progress("Crawling pages", 0)
        
        visited: set[str] = set()
        queue: list[str] = [target]
        pages: list[tuple[str, requests.Response]] = []

        progress_per_page = 20 / self.config.max_pages  # 20% for crawling

        while queue and len(visited) < self.config.max_pages:
            url = queue.pop(0)
            if url in visited:
                continue
            visited.add(url)

            self._apply_rate_limit()
            try:
                resp = self.session.get(url, timeout=self.config.timeout, verify=self.config.verify_tls, allow_redirects=True)
            except requests.RequestException as e:
                pages.append((url, _FakeResponse(error=str(e))))
                if self._progress:
                    self._progress.add_page()
                self._update_progress(increment=int(progress_per_page))
                continue

            pages.append((url, resp))
            if self._progress:
                self._progress.add_page()
            self._update_progress(increment=int(progress_per_page))

            content_type = resp.headers.get("Content-Type", "")
            if "text/html" not in content_type:
                continue

            for link in self._extract_links(resp.text, url):
                if self._base_origin(link) != base:
                    continue
                if link not in visited and len(visited) + len(queue) < self.config.max_pages:
                    queue.append(link)

        # Run security checks with progress updates
        checks = [
            ("Checking security headers", lambda: check_basic_security_headers(pages)),
            ("Checking CSRF forms", lambda: check_csrf_forms(pages)),
            ("Checking information disclosure", lambda: check_information_disclosure(pages)),
            ("Checking SSL/TLS", lambda: check_ssl_tls_issues(self.session, target)),
            ("Checking CORS", lambda: check_cors_misconfig(self.session, target)),
            ("Checking open redirects", lambda: check_open_redirect(self.session, target, self.payloads)),
            ("Checking XSS", lambda: check_reflected_xss(self.session, target, self.payloads)),
            ("Checking DOM XSS", lambda: check_xss_dom(self.session, target, self.payloads)),
            ("Checking SQL injection", lambda: check_sqli_error_based(self.session, target, self.payloads)),
            ("Checking NoSQL injection", lambda: check_nosql(self.session, target, self.payloads)),
            ("Checking SSRF", lambda: check_ssrf(self.session, target, self.payloads)),
            ("Checking LFI", lambda: check_lfi(self.session, target, self.payloads)),
            ("Checking RFI", lambda: check_rfi(self.session, target, self.payloads)),
            ("Checking path traversal", lambda: check_path_traversal(self.session, target, self.payloads)),
            ("Checking command injection", lambda: check_command_injection(self.session, target, self.payloads)),
        ]

        progress_per_check = 80 // len(checks)  # 80% for checks
        findings: list[Finding] = []
        completed_checks = 0

        # Run checks concurrently with thread pool
        with ThreadPoolExecutor(max_workers=5) as executor:
            # Submit all checks
            future_to_check = {
                executor.submit(check_func): (phase_name, check_func)
                for phase_name, check_func in checks
            }

            # Process results as they complete
            for future in as_completed(future_to_check):
                phase_name, _ = future_to_check[future]
                try:
                    new_findings = future.result()
                    if new_findings and self._progress:
                        for _ in new_findings:
                            self._progress.add_finding()
                    findings.extend(new_findings)
                except Exception:
                    # Individual check failures shouldn't stop the scan
                    pass
                completed_checks += 1
                self._update_progress(increment=progress_per_check)

        return ScanResults(
            target=target,
            total_pages=len(pages),
            findings=findings,
            meta={
                "team": "Cyber Wolf Team",
                "website": "www.cyberwolf.pro",
                "user_agent": self.config.user_agent,
            },
        )

    @staticmethod
    def _normalize_url(url: str) -> str:
        p = urlparse(url)
        if not p.scheme:
            url = "http://" + url
            p = urlparse(url)
        if not p.netloc:
            raise ValueError("Invalid URL")
        return p.geturl()

    @staticmethod
    def _base_origin(url: str) -> str:
        p = urlparse(url)
        return f"{p.scheme}://{p.netloc}".lower()

    @staticmethod
    def _extract_links(html: str, current_url: str) -> list[str]:
        soup = BeautifulSoup(html, "lxml")
        out: list[str] = []
        for a in soup.find_all("a"):
            href = a.get("href")
            if not href:
                continue
            if href.startswith("javascript:") or href.startswith("mailto:"):
                continue
            out.append(urljoin(current_url, href))
        return out


class _FakeResponse:
    def __init__(self, error: str):
        self.status_code = 0
        self.headers = {}
        self.text = ""
        self.url = ""
        self.error = error
