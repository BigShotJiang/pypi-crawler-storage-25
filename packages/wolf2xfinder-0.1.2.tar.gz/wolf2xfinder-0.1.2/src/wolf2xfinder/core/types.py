from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class Finding:
    vuln_type: str
    title: str
    severity: str
    url: str
    evidence: str = ""
    recommendation: str = ""


@dataclass(frozen=True)
class ScanResults:
    target: str
    total_pages: int
    findings: list[Finding]
    meta: dict[str, str] = field(default_factory=dict)
    generated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
