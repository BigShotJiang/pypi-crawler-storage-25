"""Entry point for python -m wolf2xfinder"""
from wolf2xfinder.cli import main
import sys

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
