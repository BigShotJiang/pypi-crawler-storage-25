from __future__ import annotations

import html
import secrets
from urllib.parse import urlencode, urlparse, urlunparse, parse_qsl

import requests
from bs4 import BeautifulSoup

from wolf2xfinder.core.types import Finding
from wolf2xfinder.payloads.registry import PayloadRegistry


def check_basic_security_headers(pages: list[tuple[str, object]]) -> list[Finding]:
    findings: list[Finding] = []
    required = {
        "content-security-policy": ("Medium", "Add a strong Content-Security-Policy header."),
        "x-content-type-options": ("Low", "Add X-Content-Type-Options: nosniff."),
        "x-frame-options": ("Low", "Add X-Frame-Options: DENY or SAMEORIGIN."),
        "referrer-policy": ("Low", "Add a Referrer-Policy header."),
        "strict-transport-security": ("Low", "Add Strict-Transport-Security (HSTS) for HTTPS sites."),
    }

    for url, resp in pages:
        headers = getattr(resp, "headers", {}) or {}
        lower = {str(k).lower(): str(v) for k, v in headers.items()}
        for h, (sev, rec) in required.items():
            if h not in lower:
                findings.append(
                    Finding(
                        vuln_type="misconfiguration",
                        title=f"Missing security header: {h}",
                        severity=sev,
                        url=url,
                        evidence="",
                        recommendation=rec,
                    )
                )
        break

    return _dedupe(findings)


def check_csrf_forms(pages: list[tuple[str, object]]) -> list[Finding]:
    findings: list[Finding] = []
    for url, resp in pages:
        text = getattr(resp, "text", "") or ""
        content_type = (getattr(resp, "headers", {}) or {}).get("Content-Type", "")
        if "text/html" not in content_type:
            continue

        soup = BeautifulSoup(text, "lxml")
        for form in soup.find_all("form"):
            method = (form.get("method") or "get").lower()
            if method != "post":
                continue
            has_token = False
            for inp in form.find_all("input"):
                name = (inp.get("name") or "").lower()
                if "csrf" in name or "token" in name:
                    has_token = True
                    break
            if not has_token:
                findings.append(
                    Finding(
                        vuln_type="csrf",
                        title="Potential CSRF: POST form without anti-CSRF token",
                        severity="Medium",
                        url=url,
                        evidence="POST form without obvious CSRF token field",
                        recommendation="Include a per-request CSRF token for all state-changing POST forms.",
                    )
                )
    return _dedupe(findings)


def check_open_redirect(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["next", "url", "redirect", "return"]

    marker = "W2X" + secrets.token_hex(6)
    max_tests = 15  # Limit total number of requests
    test_count = 0

    for p in payloads.rendered("open_redirect", marker):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5, allow_redirects=False)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1
            loc = r.headers.get("Location", "")
            if r.status_code in (301, 302, 303, 307, 308) and loc and marker in loc:
                findings.append(
                    Finding(
                        vuln_type="open_redirect",
                        title="Possible open redirect via query parameter",
                        severity="Medium",
                        url=url,
                        evidence=f"Redirected with Location: {loc}",
                        recommendation="Validate and allowlist redirect destinations; avoid reflecting untrusted URLs.",
                    )
                )

    return _dedupe(findings)


def check_reflected_xss(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["q", "s", "search"]

    marker = "W2X" + secrets.token_hex(6)
    escaped_marker = html.escape(marker)
    max_tests = 12
    test_count = 0

    for p in payloads.rendered("xss", marker):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 3:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1
            ct = r.headers.get("Content-Type", "")
            if "text/html" not in ct:
                continue
            body = r.text or ""
            if marker in body or escaped_marker in body:
                findings.append(
                    Finding(
                        vuln_type="xss",
                        title="Possible reflected XSS",
                        severity="High",
                        url=url,
                        evidence="Unique marker was reflected in HTML response.",
                        recommendation="HTML-encode untrusted input, use templating auto-escaping, and add CSP.",
                    )
                )

    return _dedupe(findings)


def check_sqli_error_based(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["id", "item", "page"]
    db_errors = [
        "you have an error in your sql syntax",
        "unclosed quotation mark",
        "sqlstate",
        "mysql_fetch",
        "syntax error",
        "odbc",
        "sqlite error",
        "psql:",
    ]

    max_tests = 10
    test_count = 0

    for p in payloads.get("sqli"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1
            body = (r.text or "").lower()
            if any(e in body for e in db_errors):
                findings.append(
                    Finding(
                        vuln_type="sqli",
                        title="Possible SQL Injection (error-based indicator)",
                        severity="High",
                        url=url,
                        evidence="Database error string detected in response.",
                        recommendation="Use parameterized queries/ORM and avoid exposing DB errors.",
                    )
                )

    return _dedupe(findings)


def _with_query(url: str, params: dict[str, str]) -> str:
    p = urlparse(url)
    current = dict(parse_qsl(p.query, keep_blank_values=True))
    current.update({k: str(v) for k, v in params.items()})
    query = urlencode(current, doseq=True)
    return urlunparse((p.scheme, p.netloc, p.path or "/", p.params, query, p.fragment))


def check_ssrf(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["url", "uri", "path", "file"]

    max_tests = 8
    test_count = 0

    for p in payloads.get("ssrf"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                start = __import__("time").time()
                r = session.get(url, timeout=6, allow_redirects=True)
                elapsed = __import__("time").time() - start
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            # Check for internal IP response indicators
            body = (r.text or "").lower()
            indicators = [
                "root:", "daemon:", "bin:", "etc/passwd",
                "inet addr", "127.0.0.1", "localhost",
            ]
            if any(ind in body for ind in indicators) and r.status_code == 200:
                findings.append(
                    Finding(
                        vuln_type="ssrf",
                        title="Possible Server-Side Request Forgery (SSRF)",
                        severity="High",
                        url=url,
                        evidence=f"Internal resource indicator found in response. Status: {r.status_code}",
                        recommendation="Validate and sanitize all user-supplied URLs; use allowlists for outbound requests.",
                    )
                )
                break
            # Time-based detection for internal services
            if elapsed > 5 and any(ip in p for ip in ["127.0.0.1", "localhost", "[::1]"]):
                findings.append(
                    Finding(
                        vuln_type="ssrf",
                        title="Possible SSRF (time-based detection)",
                        severity="Medium",
                        url=url,
                        evidence=f"Long response time ({elapsed:.1f}s) may indicate internal service access",
                        recommendation="Validate and sanitize all user-supplied URLs; use allowlists for outbound requests.",
                    )
                )

    return _dedupe(findings)


def check_lfi(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["file", "path", "page"]
    lfi_indicators = [
        "root:", "daemon:", "bin:", "sys:", "nobody:",  # /etc/passwd content
        "[boot loader]", "[operating systems]",       # Windows boot.ini
        "[fonts]", "[extensions]",                    # Windows win.ini
    ]

    max_tests = 8
    test_count = 0

    for p in payloads.get("lfi"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            body = (r.text or "").lower()
            if r.status_code == 200 and any(ind in body for ind in lfi_indicators):
                findings.append(
                    Finding(
                        vuln_type="lfi",
                        title="Possible Local File Inclusion (LFI)",
                        severity="High",
                        url=url,
                        evidence=f"File content indicators found in response.",
                        recommendation="Avoid using user input in file paths; use allowlists and chroot environments.",
                    )
                )

    return _dedupe(findings)


def check_rfi(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["file", "path", "url"]

    max_tests = 6
    test_count = 0

    for p in payloads.rendered("rfi", "w2x-marker-test"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 1:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            # Check for signs of remote content being processed
            body = (r.text or "").lower()
            if any(ind in body for ind in ["evil.com", "w2x-marker-test", "shell", "cmd", "exec"]):
                findings.append(
                    Finding(
                        vuln_type="rfi",
                        title="Possible Remote File Inclusion (RFI)",
                        severity="Critical",
                        url=url,
                        evidence="Remote file content may have been included/processed.",
                        recommendation="Never use user input to construct file paths for inclusion; disable allow_url_include in PHP.",
                    )
                )

    return _dedupe(findings)


def check_command_injection(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["cmd", "command", "exec", "ping", "host"]
    cmd_indicators = [
        "uid=", "gid=", "groups=",           # id command output
        "root:", "daemon:",                 # /etc/passwd content
        "windows ip configuration",          # Windows ipconfig
        "w2x-marker-test",                   # Our echo marker
    ]

    max_tests = 10
    test_count = 0

    for p in payloads.rendered("command_injection", "w2x-marker-test"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                start = __import__("time").time()
                r = session.get(url, timeout=5)
                elapsed = __import__("time").time() - start
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            body = (r.text or "").lower()
            if any(ind in body for ind in cmd_indicators):
                findings.append(
                    Finding(
                        vuln_type="command_injection",
                        title="Possible Command Injection",
                        severity="Critical",
                        url=url,
                        evidence="Command output indicators found in response.",
                        recommendation="Never pass user input to system shell commands; use safe APIs and input validation.",
                    )
                )
            # Time-based detection for blind command injection
            if "sleep" in p.lower() and elapsed > 3:
                findings.append(
                    Finding(
                        vuln_type="command_injection",
                        title="Possible Blind Command Injection (time-based)",
                        severity="Critical",
                        url=url,
                        evidence=f"Long response time ({elapsed:.1f}s) indicates command execution.",
                        recommendation="Never pass user input to system shell commands; use parameterized APIs.",
                    )
                )

    return _dedupe(findings)


def check_nosql(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["id", "user", "query", "filter"]
    nosql_indicators = [
        "objectid", "mongodb", "bson",
        "_id", "document(s)", "collection",
        "unexpected token", "expected", "parse error",
    ]

    max_tests = 8
    test_count = 0

    for p in payloads.get("nosql"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            body = (r.text or "").lower()
            if any(ind in body for ind in nosql_indicators) and r.status_code == 200:
                findings.append(
                    Finding(
                        vuln_type="nosql_injection",
                        title="Possible NoSQL Injection",
                        severity="High",
                        url=url,
                        evidence="NoSQL/database indicators found in response.",
                        recommendation="Use parameterized queries; validate and sanitize user input for NoSQL operations.",
                    )
                )

    return _dedupe(findings)


def check_path_traversal(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    test_params = ["file", "path", "dir"]
    traversal_indicators = [
        "root:", "etc/passwd", "etc/shadow",
        "[boot loader]", "[fonts]", "[extensions]",
        "..\\", "../", "c:\\windows",
    ]

    max_tests = 8
    test_count = 0

    for p in payloads.get("traversal"):
        for key in test_params:
            if test_count >= max_tests or len(findings) >= 2:
                return _dedupe(findings)
            url = _with_query(target_url, {key: p})
            try:
                r = session.get(url, timeout=5)
            except requests.RequestException:
                test_count += 1
                continue
            test_count += 1

            body = (r.text or "").lower()
            if r.status_code == 200 and any(ind in body for ind in traversal_indicators):
                findings.append(
                    Finding(
                        vuln_type="path_traversal",
                        title="Possible Path Traversal",
                        severity="High",
                        url=url,
                        evidence="Directory traversal indicators found in response.",
                        recommendation="Validate file paths; use chroot jails and canonicalization.",
                    )
                )

    return _dedupe(findings)


def check_information_disclosure(pages: list[tuple[str, object]]) -> list[Finding]:
    findings: list[Finding] = []
    patterns = [
        ("email", r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),
        ("phone", r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"),
        ("api_key", r"['\"](api[_-]?key|apikey)['\"]\s*[:=]\s*['\"][a-zA-Z0-9]{16,}['\"]"),
        ("secret", r"['\"](secret|private[_-]?key)['\"]\s*[:=]\s*['\"][a-zA-Z0-9]{16,}['\"]"),
        ("token", r"['\"](token|auth[_-]?token)['\"]\s*[:=]\s*['\"][a-zA-Z0-9]{16,}['\"]"),
        ("password", r"password\s*[:=]\s*['\"][^'\"]{4,}['\"]"),
        ("internal_ip", r"\b(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})\b"),
        ("stack_trace", r"(exception|traceback|stack trace|at\s+[\w\.]+\([\w]+:\d+\))"),
        ("debug_info", r"(debug|verbose|phpinfo\(\)|server software|server api)"),
    ]

    import re

    for url, resp in pages:
        text = getattr(resp, "text", "") or ""
        headers = getattr(resp, "headers", {}) or {}

        # Check response body for sensitive patterns
        for name, pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches[:3]:  # Limit findings per pattern
                findings.append(
                    Finding(
                        vuln_type="information_disclosure",
                        title=f"Possible information disclosure: {name}",
                        severity="Medium",
                        url=url,
                        evidence=str(match)[:100],
                        recommendation="Remove sensitive data from client-facing responses; implement proper error handling.",
                    )
                )

        # Check for verbose server headers
        server_header = headers.get("Server", "")
        x_powered_by = headers.get("X-Powered-By", "")
        if server_header or x_powered_by:
            findings.append(
                Finding(
                    vuln_type="information_disclosure",
                    title="Server technology disclosure in headers",
                    severity="Low",
                    url=url,
                    evidence=f"Server: {server_header}, X-Powered-By: {x_powered_by}",
                    recommendation="Remove or obfuscate Server and X-Powered-By headers.",
                )
            )

    return _dedupe(findings)


def check_ssl_tls_issues(session: requests.Session, target_url: str) -> list[Finding]:
    findings: list[Finding] = []
    parsed = urlparse(target_url)

    # Check for insecure protocol
    if parsed.scheme == "http":
        findings.append(
            Finding(
                vuln_type="ssl_tls",
                title="Insecure HTTP protocol",
                severity="Medium",
                url=target_url,
                evidence="Target uses HTTP instead of HTTPS",
                recommendation="Enforce HTTPS across the entire application; redirect HTTP to HTTPS.",
            )
        )

    if parsed.scheme == "https":
        try:
            import ssl
            import socket
            hostname = parsed.netloc.split(":")[0]
            port = 443 if ":" not in parsed.netloc else int(parsed.netloc.split(":")[1])

            context = ssl.create_default_context()
            with socket.create_connection((hostname, port), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    version = ssock.version()
                    cipher = ssock.cipher()

                    # Check TLS version
                    if version in ["TLSv1", "TLSv1.1", "SSLv3", "SSLv2"]:
                        findings.append(
                            Finding(
                                vuln_type="ssl_tls",
                                title=f"Weak TLS version: {version}",
                                severity="High",
                                url=target_url,
                                evidence=f"Server supports {version}",
                                recommendation="Disable TLS 1.0/1.1 and SSL; enforce TLS 1.2 or higher.",
                            )
                        )

                    # Check for weak ciphers
                    if cipher and any(weak in str(cipher).lower() for weak in ["rc4", "des", "md5", "sha1", "null"]):
                        findings.append(
                            Finding(
                                vuln_type="ssl_tls",
                                title="Weak cipher suite detected",
                                severity="High",
                                url=target_url,
                                evidence=f"Cipher: {cipher}",
                                recommendation="Disable weak cipher suites; use only strong, modern ciphers.",
                            )
                        )

                    # Check certificate expiration
                    cert = ssock.getpeercert()
                    if cert and "notAfter" in cert:
                        from datetime import datetime
                        expiry = cert["notAfter"]
                        try:
                            expiry_date = datetime.strptime(expiry, "%b %d %H:%M:%S %Y %Z")
                            if expiry_date < datetime.utcnow():
                                findings.append(
                                    Finding(
                                        vuln_type="ssl_tls",
                                        title="Expired SSL/TLS certificate",
                                        severity="Critical",
                                        url=target_url,
                                        evidence=f"Certificate expired on {expiry}",
                                        recommendation="Renew the SSL/TLS certificate immediately.",
                                    )
                                )
                        except ValueError:
                            pass

        except Exception as e:
            # SSL check failed, log but don't crash
            pass

    return _dedupe(findings)


def check_cors_misconfig(session: requests.Session, target_url: str) -> list[Finding]:
    findings: list[Finding] = []
    test_origins = [
        "https://evil.com",
        "null",
        "http://localhost",
    ]

    for origin in test_origins:
        if len(findings) >= 2:
            return _dedupe(findings)
        try:
            r = session.get(
                target_url,
                timeout=5,
                headers={"Origin": origin}
            )
            acao = r.headers.get("Access-Control-Allow-Origin", "")
            acac = r.headers.get("Access-Control-Allow-Credentials", "")

            if acao == "*":
                findings.append(
                    Finding(
                        vuln_type="cors",
                        title="Permissive CORS: wildcard origin allowed",
                        severity="Medium",
                        url=target_url,
                        evidence="Access-Control-Allow-Origin: *",
                        recommendation="Specify exact allowed origins instead of wildcards.",
                    )
                )
            elif origin in acao and acac.lower() == "true":
                findings.append(
                    Finding(
                        vuln_type="cors",
                        title="CORS misconfiguration: reflected origin with credentials",
                        severity="High",
                        url=target_url,
                        evidence=f"Origin {origin} reflected with credentials allowed",
                        recommendation="Validate origins against allowlist; avoid reflecting arbitrary origins with credentials.",
                    )
                )
        except requests.RequestException:
            continue

    return _dedupe(findings)


def check_xss_dom(session: requests.Session, target_url: str, payloads: PayloadRegistry) -> list[Finding]:
    findings: list[Finding] = []
    dom_sinks = [
        "document.write",
        "innerHTML",
        "eval",
        "setTimeout",
        "location.href",
    ]
    test_params = ["callback", "jsonp", "cb"]

    marker = "W2XDOM" + secrets.token_hex(4)

    for key in test_params:
        if len(findings) >= 2:
            return _dedupe(findings)
        url = _with_query(target_url, {key: f"alert({marker})"})
        try:
            r = session.get(url, timeout=5)
        except requests.RequestException:
            continue

        body = (r.text or "").lower()
        if marker.lower() in body:
            # Check if it's in a dangerous context
            for sink in dom_sinks:
                if sink.lower() in body:
                    findings.append(
                        Finding(
                            vuln_type="xss_dom",
                            title="Possible DOM-based XSS",
                            severity="High",
                            url=url,
                            evidence=f"User input reflected near dangerous DOM sink: {sink}",
                            recommendation="Sanitize user input before passing to DOM sinks; avoid eval/innerHTML with untrusted data.",
                        )
                    )
                    break

    return _dedupe(findings)


def _dedupe(items: list[Finding]) -> list[Finding]:
    seen: set[tuple[str, str, str]] = set()
    out: list[Finding] = []
    for f in items:
        k = (f.vuln_type, f.title, f.url)
        if k in seen:
            continue
        seen.add(k)
        out.append(f)
    return out
