import json
import os
from pathlib import Path


class Config:
    """Manage Wolf2XFinder user configuration stored in a JSON file."""

    if os.name == "nt":
        CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "Wolf2XFinder"
    else:
        CONFIG_DIR = Path.home() / ".config" / "wolf2xfinder"

    CONFIG_FILE = CONFIG_DIR / "config.json"

    DEFAULTS = {
        "push_url": "",
        "out_prefix": "wolf2xfinder_report",
        "formats": ["json"],
        "max_pages": 5,
        "timeout": 8.0,
        "rate_limit": 0.0,
        "user_agent": "wolf2xfinder/0.1",
    }

    def __init__(self):
        self.data = dict(self.DEFAULTS)
        self.load()

    def load(self):
        if self.CONFIG_FILE.exists():
            try:
                with open(self.CONFIG_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.data.update(loaded)
            except Exception:
                pass

    def save(self):
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(self.CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
