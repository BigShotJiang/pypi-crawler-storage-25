"""ASCII Art Banner and UI elements for Wolf2XFinder"""
from __future__ import annotations

import os
import sys

# Detect environment capabilities
_IS_WINDOWS = sys.platform == "win32"
_SUPPORTS_COLOR = False
_SUPPORTS_UNICODE = False

def _init_terminal():
    """Initialize terminal and detect capabilities."""
    global _SUPPORTS_COLOR, _SUPPORTS_UNICODE
    
    # Try to enable colorama on Windows
    if _IS_WINDOWS:
        try:
            import colorama
            colorama.init(strip=False, convert=True)
            _SUPPORTS_COLOR = True
        except ImportError:
            # Try Windows 10+ native ANSI
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                std_out = kernel32.GetStdHandle(-11)
                mode = ctypes.c_ulong()
                kernel32.GetConsoleMode(std_out, ctypes.byref(mode))
                kernel32.SetConsoleMode(std_out, mode.value | 0x0004)
                _SUPPORTS_COLOR = True
            except Exception:
                _SUPPORTS_COLOR = False
    else:
        # Unix/Linux/Mac - check for TTY
        _SUPPORTS_COLOR = sys.stdout.isatty()
    
    # Check Unicode support
    try:
        # Test if we can print Unicode box chars
        sys.stdout.write("\u2550")
        sys.stdout.write("\r")
        _SUPPORTS_UNICODE = True
    except (UnicodeEncodeError, UnicodeDecodeError):
        _SUPPORTS_UNICODE = False
    
    # Force color if NO_COLOR is not set and COLORTERM exists
    if os.environ.get("COLORTERM") or os.environ.get("TERM") == "xterm-256color":
        _SUPPORTS_COLOR = True

# Initialize on module load
_init_terminal()

# ASCII-only banner for maximum compatibility
BANNER_ASCII = r"""
+==================================================================+
|                    WOLF SEC 2X FINDER v0.1.0                     |
|              Cyber Wolf Team - www.cyberwolf.pro                 |
+==================================================================+
 __      __   _  __   ___  __  __  ___ _         _         
 \ \    / /__| |/ _| |_  ) \ \/ / | __(_)_ _  __| |___ _ _ 
  \ \/\/ / _ \ |  _|  / /   >  <  | _|| | ' \/ _` / -_) '_|
   \_/\_/\___/_|_|   /___| /_/\_\ |_| |_|_||_\__,_\___|_|                                                        
"""

# Unicode box drawing banner (for terminals that support it)
BANNER_UNICODE = """
\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551                    WOLF SEC 2X FINDER v0.1.0                     \u2551
\u2551              Cyber Wolf Team - www.cyberwolf.pro                 \u2551
\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d
 __      __   _  __   ___  __  __  ___ _         _         
 \ \    / /__| |/ _| |_  ) \ \/ / | __(_)_ _  __| |___ _ _ 
  \ \/\/ / _ \ |  _|  / /   >  <  | _|| | ' \/ _` / -_) '_|
   \_/\_/\___/_|_|   /___| /_/\_\ |_| |_|_||_\__,_\___|_|                                                                      
"""

# Wolf compact logo (ASCII only for maximum compatibility)
WOLF_LOGO = r"""
       /\\_/\\
      ( o.o )    WOLF SEC 2X FINDER
       > ^ <     www.cyberwolf.pro
"""

# Loading frames for spinner (ASCII only)
LOADING_FRAMES = [
    "[    ]",
    "[=   ]",
    "[==  ]",
    "[=== ]",
    "[ ===]",
    "[  ==]",
    "[   =]",
    "[    ]",
]

# Color codes (ANSI)
COLORS = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
    "blue": "\033[94m",
    "magenta": "\033[95m",
    "cyan": "\033[96m",
    "white": "\033[97m",
}


def colorize(text: str, color: str) -> str:
    """Apply ANSI color to text, with fallback to plain text."""
    if not _SUPPORTS_COLOR:
        return text
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def print_banner() -> None:
    """Print the Wolf2XFinder ASCII banner with automatic fallback."""
    print()
    
    # Choose banner based on Unicode support
    if _SUPPORTS_UNICODE:
        banner = BANNER_UNICODE
    else:
        banner = BANNER_ASCII
    
    # Print with color if supported
    if _SUPPORTS_COLOR:
        print(colorize(banner, "cyan"))
    else:
        print(banner)
    
    print()


def print_scan_start(target: str) -> None:
    """Print scan initiation message."""
    # Use ASCII-only icons for maximum compatibility
    icon = ">>>" if not _SUPPORTS_UNICODE else "[>]"
    print(colorize(f"{icon} Starting security scan...", "yellow"))
    print(f"   Target: {colorize(target, 'bold')}")
    print()


def print_scan_complete(findings_count: int, pages_scanned: int, report_prefix: str) -> None:
    """Print scan completion summary."""
    print()
    # Use ASCII-only checkmark
    check = "[OK]" if not _SUPPORTS_UNICODE else "[OK]"
    print(colorize(f"{check} Scan Complete!", "green"))
    print(f"   Pages scanned: {pages_scanned}")
    
    if findings_count > 0:
        severity_color = "red" if findings_count > 5 else "yellow"
        print(colorize(f"   Findings: {findings_count}", severity_color))
    else:
        print(colorize("   No vulnerabilities found", "green"))
    
    print(f"   Report saved: {report_prefix}")
    print()


def print_progress(message: str, current: int, total: int) -> None:
    """Print a progress bar."""
    width = 40
    percent = current / total if total > 0 else 0
    filled = int(width * percent)
    bar = "█" * filled + "░" * (width - filled)
    
    # Clear line and print
    print(f"\r{colorize(message, 'blue')} [{bar}] {current}/{total}", end="", flush=True)


def clear_line() -> None:
    """Clear the current terminal line."""
    print("\r" + " " * 80 + "\r", end="")


def print_finding(vuln_type: str, severity: str, title: str, url: str) -> None:
    """Print a finding in a formatted way."""
    severity_colors = {
        "Critical": "red",
        "High": "red", 
        "Medium": "yellow",
        "Low": "green",
    }
    color = severity_colors.get(severity, "white")
    
    print(f"  {colorize('[' + severity + ']', color)} {colorize(vuln_type, 'bold')}: {title}")
    print(f"    URL: {url[:80]}..." if len(url) > 80 else f"    URL: {url}")
    print()


def force_plain_ascii():
    """Force plain ASCII mode (no colors, no Unicode). Call this if display issues occur."""
    global _SUPPORTS_COLOR, _SUPPORTS_UNICODE
    _SUPPORTS_COLOR = False
    _SUPPORTS_UNICODE = False


def force_color_mode():
    """Force color mode on. Useful when piping to 'less -R' or similar."""
    global _SUPPORTS_COLOR
    _SUPPORTS_COLOR = True
