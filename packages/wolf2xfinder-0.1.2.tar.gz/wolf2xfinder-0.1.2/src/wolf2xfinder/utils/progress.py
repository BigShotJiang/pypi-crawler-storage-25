"""Progress indicators and loading animations for Wolf2XFinder"""
from __future__ import annotations

import sys
import threading
import time
from typing import Callable

# Import banner module to check terminal capabilities
try:
    from .banner import _SUPPORTS_UNICODE
except ImportError:
    _SUPPORTS_UNICODE = False


class ProgressSpinner:
    """A threaded loading spinner for long-running operations."""
    
    # ASCII-only spinner frames for maximum compatibility
    SPINNER_FRAMES_ASCII = ["|", "/", "-", "\\"]
    # Unicode braille patterns (only used if supported)
    SPINNER_FRAMES_UNICODE = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    
    def _get_frames(self):
        """Get appropriate spinner frames for the terminal."""
        if _SUPPORTS_UNICODE:
            return self.SPINNER_FRAMES_UNICODE
        return self.SPINNER_FRAMES_ASCII
    
    def __init__(self, message: str = "Loading..."):
        self.message = message
        self.running = False
        self.thread: threading.Thread | None = None
        self._frame_index = 0
        
    def start(self) -> None:
        """Start the spinner animation."""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._animate, daemon=True)
        self.thread.start()
        
    def stop(self, final_message: str | None = None) -> None:
        """Stop the spinner animation."""
        self.running = False
        if self.thread:
            self.thread.join(timeout=0.5)
        
        # Clear line
        sys.stdout.write("\r" + " " * 80 + "\r")
        if final_message:
            print(final_message)
        sys.stdout.flush()
        
    def _animate(self) -> None:
        """Animation loop running in separate thread."""
        frames = self._get_frames()
        while self.running:
            frame = frames[self._frame_index % len(frames)]
            sys.stdout.write(f"\r  {frame} {self.message}")
            sys.stdout.flush()
            self._frame_index += 1
            time.sleep(0.1)


class ScanProgress:
    """Progress tracker for vulnerability scanning."""
    
    def __init__(self, total_steps: int = 100):
        self.total_steps = total_steps
        self.current_step = 0
        self.current_phase = "Initializing"
        self.findings_found = 0
        self.pages_scanned = 0
        self._start_time = time.time()
        
    def update_phase(self, phase: str) -> None:
        """Update the current scanning phase."""
        self.current_phase = phase
        self._print_progress()
        
    def increment(self, steps: int = 1) -> None:
        """Increment progress by number of steps."""
        self.current_step = min(self.current_step + steps, self.total_steps)
        self._print_progress()
        
    def set_step(self, step: int) -> None:
        """Set absolute progress step."""
        self.current_step = min(step, self.total_steps)
        self._print_progress()
        
    def add_finding(self) -> None:
        """Increment finding count."""
        self.findings_found += 1
        self._print_progress()
        
    def add_page(self) -> None:
        """Increment pages scanned count."""
        self.pages_scanned += 1
        self._print_progress()
        
    def _print_progress(self) -> None:
        """Print progress bar with current status."""
        percent = self.current_step / self.total_steps if self.total_steps > 0 else 0
        filled = int(30 * percent)
        
        # Use ASCII-only bar characters for maximum compatibility
        if _SUPPORTS_UNICODE:
            bar = "█" * filled + "░" * (30 - filled)
        else:
            bar = "=" * filled + "-" * (30 - filled)
        
        elapsed = time.time() - self._start_time
        
        # Format elapsed time
        if elapsed < 60:
            time_str = f"{elapsed:.0f}s"
        else:
            time_str = f"{elapsed/60:.1f}m"
        
        # Build status line (ASCII only, no ANSI codes in progress bar for Windows)
        status = f"\r  [{bar}] {self.current_step}% | {self.current_phase}"
        
        if self.pages_scanned > 0:
            status += f" | Pages: {self.pages_scanned}"
        if self.findings_found > 0:
            status += f" | Findings: {self.findings_found}"
        
        status += f" | {time_str}"
        
        # Pad and print (limit to 80 chars to avoid overflow)
        status = status[:80]
        padding = max(0, 80 - len(status))
        try:
            sys.stdout.write(status + " " * padding)
            sys.stdout.flush()
        except (UnicodeEncodeError, UnicodeDecodeError):
            # Fallback for terminals that can't handle certain characters
            safe_status = status.encode('ascii', 'ignore').decode('ascii')
            padding = max(0, 80 - len(safe_status))
            sys.stdout.write(safe_status + " " * padding)
            sys.stdout.flush()
        
    def finish(self) -> None:
        """Mark progress as complete."""
        self.current_step = self.total_steps
        self._print_progress()
        print()  # New line after progress
        
    def get_elapsed(self) -> float:
        """Get elapsed time in seconds."""
        return time.time() - self._start_time


class IndeterminateProgress:
    """Indeterminate progress bar for operations with unknown duration."""
    
    def __init__(self, message: str = "Processing"):
        self.message = message
        self.running = False
        self.thread: threading.Thread | None = None
        self._dots = 0
        
    def start(self) -> None:
        """Start the indeterminate progress animation."""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._animate, daemon=True)
        self.thread.start()
        
    def stop(self) -> None:
        """Stop the animation."""
        self.running = False
        if self.thread:
            self.thread.join(timeout=0.5)
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()
        
    def _animate(self) -> None:
        """Animation loop."""
        while self.running:
            dots = "." * (self._dots % 4)
            spaces = " " * (3 - len(dots))
            sys.stdout.write(f"\r  {self.message}{dots}{spaces}")
            sys.stdout.flush()
            self._dots += 1
            time.sleep(0.3)


def print_status(message: str, status: str = "info") -> None:
    """Print a status message with appropriate icon."""
    # Use ASCII-only icons for maximum compatibility
    if _SUPPORTS_UNICODE:
        icons = {
            "info": "[i]",
            "success": "[OK]",
            "warning": "[!]",
            "error": "[X]",
            "scan": ">>>",
            "lock": "[#]",
            "web": "[@]",
        }
    else:
        icons = {
            "info": "[i]",
            "success": "[OK]",
            "warning": "[!]",
            "error": "[X]",
            "scan": ">>>",
            "lock": "[#]",
            "web": "[@]",
        }
    icon = icons.get(status, "[*]")
    print(f"  {icon} {message}")


def print_vulnerability(vuln_type: str, severity: str, url: str) -> None:
    """Print a found vulnerability in real-time."""
    # Use ASCII-only severity markers for maximum compatibility
    severity_icons = {
        "Critical": "[CRIT]",
        "High": "[HIGH]",
        "Medium": "[MED]", 
        "Low": "[LOW]",
    }
    icon = severity_icons.get(severity, "[?]")
    
    # Shorten URL if needed
    display_url = url[:60] + "..." if len(url) > 60 else url
    
    print(f"\r  {icon} {severity}: {vuln_type} - {display_url}")
    # Return cursor to start of line for next progress update
    sys.stdout.flush()
