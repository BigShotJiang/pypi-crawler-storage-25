"""browser-recon: scan a URL and produce a scraping reconnaissance report."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__: str = _pkg_version("browser-recon")
except PackageNotFoundError:
    # In-tree run before the package is installed (e.g. `python -m browser_recon`).
    __version__ = "0.0.0+local"
