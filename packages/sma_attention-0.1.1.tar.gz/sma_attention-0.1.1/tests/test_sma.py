"""
Tests for SymmetricMambaAttention.

Run with:
    pytest tests/test_sma.py -v

Requires CUDA + mamba-ssm. On non-CUDA systems these tests will be skipped.
"""

import pytest
import torch
import torch.nn as nn


# Attempt import; skip all tests if unavailable
mamba_ssm = pytest.importorskip(
    "mamba_ssm", reason="mamba-ssm requires CUDA toolkit"
)


from sma_attention import SymmetricMambaAttention


# ── helpers ────────────────────────────────────────────────────────


def _make_module(d_model=128, n_heads=4, **kwargs):
    """Create a default SMA module, moved to GPU if available."""
    device = "cuda" if torch.cuda.is_available() else "cpu"
    return SymmetricMambaAttention(
        d_model=d_model, n_heads=n_heads, **kwargs
    ).to(device)


def _make_inputs(batch=2, d_model=128, seq_len=60):
    """Create random input pair, moved to GPU if available."""
    device = "cuda" if torch.cuda.is_available() else "cpu"
    x1 = torch.randn(batch, d_model, seq_len, device=device)
    x2 = torch.randn(batch, d_model, seq_len, device=device)
    return x1, x2


# ── tests ──────────────────────────────────────────────────────────


class TestShape:
    """Output shape invariants."""

    def test_basic_shape(self):
        sma = _make_module()
        x1, x2 = _make_inputs()
        out = sma(x1, x2)
        assert out.shape == (2, 128, 60)

    def test_varied_inputs(self):
        for B, D, N, H in [(1, 64, 32, 2), (4, 256, 128, 8), (2, 128, 1, 4)]:
            sma = _make_module(d_model=D, n_heads=H)
            x1 = torch.randn(B, D, N, device=x1.device if 'x1' in dir() else "cuda")
            x2 = torch.randn(B, D, N, device=x1.device)
            out = sma(x1, x2)
            assert out.shape == (B, D, N), f"Failed at B={B}, D={D}, N={N}, H={H}"


class TestGradient:
    """Gradient flow through the module."""

    def test_backward_no_nan(self):
        sma = _make_module()
        x1, x2 = _make_inputs()
        x1.requires_grad_(True)
        x2.requires_grad_(True)

        out = sma(x1, x2)
        loss = out.mean()
        loss.backward()

        assert x1.grad is not None
        assert x2.grad is not None
        assert not torch.isnan(x1.grad).any()
        assert not torch.isnan(x2.grad).any()

    def test_all_params_get_grad(self):
        sma = _make_module()
        x1, x2 = _make_inputs()
        out = sma(x1, x2)
        out.mean().backward()

        for name, p in sma.named_parameters():
            assert p.grad is not None, f"{name} received no gradient"
            assert not torch.isnan(p.grad).any(), f"{name} grad is NaN"


class TestBehavior:
    """Functional correctness checks."""

    def test_different_inputs_different_outputs(self):
        sma = _make_module()
        x1, x2 = _make_inputs()
        out1 = sma(x1, x2)
        out2 = sma(x2, x1)          # swapped
        out3 = sma(x1, x1)          # same inputs

        # Swapping inputs should produce a (potentially) different result
        assert not torch.allclose(out1, out2), \
            "Swapping x1/x2 should not give identical output"

        # Same inputs should produce a valid tensor
        assert out3.shape == out1.shape

    def test_output_finite(self):
        sma = _make_module()
        x1, x2 = _make_inputs()
        out = sma(x1, x2)
        assert torch.isfinite(out).all()

    def test_deterministic_in_eval(self):
        sma = _make_module().eval()
        x1, x2 = _make_inputs()
        torch.manual_seed(42)
        out1 = sma(x1, x2)
        torch.manual_seed(42)
        out2 = sma(x1, x2)
        # In eval mode, same inputs should produce same output
        # (Mamba may have stochastic elements, so we do loose tolerance)
        assert torch.allclose(out1, out2, atol=1e-5), \
            "Output should be deterministic in eval mode"


class TestEdgeCases:
    """Boundary conditions."""

    def test_seq_len_1(self):
        sma = _make_module(d_model=64, n_heads=2)
        x1 = torch.randn(2, 64, 1, device=next(sma.parameters()).device)
        x2 = torch.randn(2, 64, 1, device=next(sma.parameters()).device)
        out = sma(x1, x2)
        assert out.shape == (2, 64, 1)
        assert torch.isfinite(out).all()

    def test_batch_size_1(self):
        sma = _make_module()
        x1, x2 = _make_inputs(batch=1)
        out = sma(x1, x2)
        assert out.shape == (1, 128, 60)
        assert torch.isfinite(out).all()


class TestMambaConfigs:
    """Different Mamba hyperparameters."""

    def test_varied_mamba_configs(self):
        configs = [
            dict(d_state=8, d_conv=2, expand=1),
            dict(d_state=16, d_conv=4, expand=2),
            dict(d_state=32, d_conv=4, expand=4),
        ]
        for cfg in configs:
            sma = _make_module(d_model=128, n_heads=4, **cfg)
            x1, x2 = _make_inputs()
            out = sma(x1, x2)
            assert out.shape == (2, 128, 60)
            assert torch.isfinite(out).all(), f"Failed with cfg={cfg}"
