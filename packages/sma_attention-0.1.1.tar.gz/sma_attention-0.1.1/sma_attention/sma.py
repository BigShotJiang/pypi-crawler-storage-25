"""
Symmetric Mamba Attention (SMA) module.

Core implementation of a dual-path attention mechanism where both
query and key are generated through a shared Mamba state-space model
(symmetric design), with sigma-modulated attention weighting and
fused value projection.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, einsum
from mamba_ssm.modules.mamba_simple import Mamba


class SymmetricMambaAttention(nn.Module):
    """
    Symmetric Mamba Attention: dual-path input -> single-path output.

    Design highlights:
    1. **Symmetric Q/K generation**: Both query and key are produced
       by the SAME Mamba layer (shared weights), applied to x1 and x2
       respectively. This ensures consistent bidirectional information
       flow -- neither path is privileged.
    2. **Fused value projection**: V1 and V2 from independent linear
       projections are merged via concat( V1+V2, V1*V2 ), capturing
       both additive and multiplicative interactions.
    3. **Sigma-modulated attention**: Attention scores are element-wise
       modulated by sigma(Q) * sigma(K)^T, introducing a learned
       dimension-aware gating that sharpens or dampens specific
       attention patterns.
    4. **Residual paths**: Multiple residual connections (Q/K
       pre-attention, V fusion, final output) preserve gradient flow.

    Args:
        d_model: Feature dimension.
        n_heads: Number of attention heads.
        d_state: Mamba state expansion factor. Default: 16.
        d_conv: Mamba convolution kernel size. Default: 4.
        expand: Mamba inner dimension expansion factor. Default: 2.

    Input shape:
        x1, x2: ``(batch, d_model, seq_len)``

    Output shape:
        ``(batch, d_model, seq_len)``
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_state: int = 16,
        d_conv: int = 4,
        expand: int = 2,
    ):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.scale = self.head_dim ** -0.5

        # Shared Mamba for symmetric Q/K generation
        self.mamba = Mamba(
            d_model=d_model,
            d_state=d_state,
            d_conv=d_conv,
            expand=expand,
        )

        # Independent value projections for the two input paths
        self.linear_v1 = nn.Linear(d_model, d_model)
        self.linear_v2 = nn.Linear(d_model, d_model)

        # Fusion layer: concat(V1+V2, V1*V2) -> d_model
        self.v_fusion = nn.Linear(d_model * 2, d_model)

        # Sigmoid for sigma-modulated attention
        self.sigma = nn.Sigmoid()

    def forward(
        self,
        x1: torch.Tensor,
        x2: torch.Tensor,
    ) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x1: First input component, shape ``(B, D, N)``.
            x2: Second input component, shape ``(B, D, N)``.

        Returns:
            Output tensor, shape ``(B, D, N)``.
        """
        B, D, N = x1.shape

        # Transpose to (B, N, D) for Mamba and attention ops
        x1_t = x1.transpose(1, 2)
        x2_t = x2.transpose(1, 2)

        # --- Stage 1: Symmetric Q/K via Mamba ---
        Q = self.mamba(x1_t) + x1_t   # residual
        K = self.mamba(x2_t) + x2_t   # residual

        # --- Stage 2: Dual value projections ---
        V1 = self.linear_v1(x1_t)
        V2 = self.linear_v2(x2_t)

        # --- Stage 3: Fused value ---
        # concatenate sum and product to capture both interactions
        V_cat = torch.cat([V1 + V2, V1 * V2], dim=-1)        # (B, N, 2D)
        V_fused = self.v_fusion(V_cat) + (V1 + V2) / 2       # residual

        # --- Stage 4: Multi-head reshape ---
        Q = rearrange(Q, 'b n (h d) -> b h n d', h=self.n_heads)
        K = rearrange(K, 'b n (h d) -> b h n d', h=self.n_heads)
        V = rearrange(V_fused, 'b n (h d) -> b h n d', h=self.n_heads)

        # --- Stage 5: Scaled dot-product affinity ---
        affinity = einsum(Q, K, 'b h i d, b h j d -> b h i j') * self.scale

        # --- Stage 6: Sigma modulation ---
        # σ(Q) · σ(K)^T produces a learned gating over attention logits
        Q_sigma = self.sigma(Q)
        K_sigma = self.sigma(K)
        sigma_mod = torch.matmul(Q_sigma, K_sigma.transpose(-2, -1))
        affinity_mod = affinity * sigma_mod

        # --- Stage 7: Softmax + weighted aggregation ---
        attn_weights = F.softmax(affinity_mod, dim=-1)
        out = einsum(attn_weights, V, 'b h i j, b h j d -> b h i d')
        out = rearrange(out, 'b h n d -> b n (h d)')

        # Transpose back to (B, D, N) and add residual from both inputs
        output = out.transpose(1, 2)
        return output + (x1 + x2) / 2
