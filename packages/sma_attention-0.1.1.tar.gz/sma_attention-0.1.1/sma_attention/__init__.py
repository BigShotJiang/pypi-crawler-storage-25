"""
Symmetric Mamba Attention (SMA).

A dual-path attention module that uses Mamba state-space models to
generate query and key representations, with sigma-modulated attention
weighting and fused value projection.
"""

from .sma import SymmetricMambaAttention

__version__ = "0.1.1"
__all__ = ["SymmetricMambaAttention"]
