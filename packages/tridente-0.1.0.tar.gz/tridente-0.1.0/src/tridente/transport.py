"""Background batched transport for the Tridente client.

Runs a single daemon thread per client that periodically drains the
`_usage_queue` and `_cost_queue` and POSTs them to the Tridente API using
a dedicated sync `httpx.Client`. This keeps `report_*` calls on the
foreground code path non-blocking even for users who never call `flush()`.

Guarantees:
    - Non-blocking from the caller's perspective: enqueueing is a lock +
      append, nothing more.
    - Bounded memory: `MAX_QUEUE_SIZE` is enforced by `enforce_backpressure()`
      which drops the oldest events when the queue is full and warns
      (rate-limited).
    - Clean shutdown: `BatchedTransport.stop()` signals the thread to
      exit, waits up to `stop_timeout_seconds` for it to finish its
      final drain, then returns.
    - `atexit` safety: each client registers its own `close_sync` so
      process exit performs a best-effort flush. Manual `close()` /
      `close_sync()` unregisters that hook.

Thread safety: the transport thread and the foreground code both operate
on the client's queues under `client._queue_lock`. The POST itself happens
outside the lock so enqueues are never blocked by network IO.
"""

from __future__ import annotations

import atexit
import contextlib
import threading
import time
import warnings
from typing import TYPE_CHECKING, Any

import httpx

from tridente.errors import ApiError

if TYPE_CHECKING:
    from tridente.client import Tridente, _PendingUsage

MAX_QUEUE_SIZE: int = 10_000
_BACKPRESSURE_WARN_INTERVAL_SECONDS: float = 60.0
_DEFAULT_STOP_TIMEOUT_SECONDS: float = 5.0


class TridenteTransportWarning(UserWarning):
    """Emitted from the background transport thread on non-fatal errors
    (flush failure, backpressure drop).
    """


class BatchedTransport:
    """Daemon-thread batched transport bound to a single `Tridente` client.

    The thread is started in `__init__` and stopped in `stop()`. It uses
    its own `httpx.Client` for sync POSTs — the async client on the parent
    is reserved for the foreground code path.
    """

    __slots__ = (
        "_client",
        "_last_backpressure_warn",
        "_stop_event",
        "_sync_http",
        "_thread",
    )

    def __init__(self, client: Tridente) -> None:
        self._client = client
        self._stop_event = threading.Event()
        self._last_backpressure_warn = 0.0
        # Dedicated sync client: the thread can't share the parent's
        # AsyncClient (different event-loop semantics). Builds the same
        # auth + UA headers the async client uses.
        self._sync_http = httpx.Client(
            base_url=client.config.api_url,
            timeout=client.config.request_timeout_seconds,
            headers=client.default_headers(),
        )
        self._thread = threading.Thread(
            target=self._run,
            name=f"tridente-transport-{id(client):x}",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def stop(self, *, timeout: float | None = None) -> None:
        """Signal the thread to exit and wait for it to join.

        The thread performs one final drain before returning, so any
        events enqueued before `stop()` was called will still be sent
        (unless they fail, in which case they're dropped with a warning).
        """
        self._stop_event.set()
        effective_timeout = timeout if timeout is not None else _DEFAULT_STOP_TIMEOUT_SECONDS
        if self._thread.is_alive():
            self._thread.join(timeout=effective_timeout)
        try:
            self._sync_http.close()
        except Exception as exc:
            warnings.warn(
                f"Tridente: error closing transport http client: {exc}",
                category=TridenteTransportWarning,
                stacklevel=2,
            )

    # ─── Main loop ───────────────────────────────────────────────────

    def _run(self) -> None:
        interval = self._client.config.flush_interval_seconds
        while not self._stop_event.is_set():
            # `wait()` returns True if the event was set during the
            # wait, giving us prompt shutdown.
            if self._stop_event.wait(interval):
                break
            self._flush_once()
        # Final drain after stop was signaled.
        self._flush_once()

    def _flush_once(self) -> None:
        usage, cost = self._client._drain_queues()
        if not usage and not cost:
            return

        try:
            self._send_usage(usage)
        except Exception as exc:
            self._requeue_usage(usage)
            warnings.warn(
                f"Tridente: usage batch flush failed ({len(usage)} events re-queued): {exc}",
                category=TridenteTransportWarning,
                stacklevel=1,
            )
            # Drop cost on this tick too — we'll try again next interval.
            self._requeue_cost(cost)
            return

        try:
            self._send_cost(cost)
        except Exception as exc:
            self._requeue_cost(cost)
            warnings.warn(
                f"Tridente: cost batch flush failed ({len(cost)} events re-queued): {exc}",
                category=TridenteTransportWarning,
                stacklevel=1,
            )

    def _send_usage(self, events: list[_PendingUsage]) -> None:
        for event in events:
            # Match TS SDK wire shape: include metadata only when set.
            payload: dict[str, Any] = {"event_type": event["event_type"]}
            metadata = event.get("metadata")
            if metadata is not None:
                payload["metadata"] = metadata
            response = self._sync_http.post(
                f"/entities/{event['entity_id']}/events",
                json=payload,
            )
            if response.is_error:
                raise _http_error(response)

    def _send_cost(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        response = self._sync_http.post("/cost-events", json={"events": events})
        if response.is_error:
            raise _http_error(response)
        body = response.json() if response.content else {}
        ingested: Any = None
        if isinstance(body, dict):
            data = body.get("data")
            if isinstance(data, dict):
                ingested = data.get("ingested_count")
        if ingested != len(events):
            raise ApiError(
                code="COST_INGEST_MISMATCH",
                message=f"expected {len(events)}, got {ingested}",
                status_code=None,
            )

    def _requeue_usage(self, events: list[_PendingUsage]) -> None:
        if not events:
            return
        with self._client._queue_lock:
            self._client._usage_queue = events + self._client._usage_queue

    def _requeue_cost(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        with self._client._queue_lock:
            self._client._cost_queue = events + self._client._cost_queue

    # ─── Backpressure ────────────────────────────────────────────────

    def enforce_backpressure(self) -> None:
        """Drop oldest events when the combined queue exceeds
        `MAX_QUEUE_SIZE`. Drops are reported via `TridenteTransportWarning`,
        rate-limited to once per minute per client.
        """
        now = time.monotonic()
        dropped_any = False
        with self._client._queue_lock:
            total = len(self._client._usage_queue) + len(self._client._cost_queue)
            if total <= MAX_QUEUE_SIZE:
                return
            excess = total - MAX_QUEUE_SIZE
            # Prefer dropping usage events first — they're cheaper to lose
            # than cost events (cost → invoicing).
            drop_usage = min(len(self._client._usage_queue), excess)
            if drop_usage:
                del self._client._usage_queue[:drop_usage]
                excess -= drop_usage
                dropped_any = True
            if excess:
                del self._client._cost_queue[:excess]
                dropped_any = True

        if dropped_any and now - self._last_backpressure_warn > _BACKPRESSURE_WARN_INTERVAL_SECONDS:
            self._last_backpressure_warn = now
            warnings.warn(
                f"Tridente: event queue exceeded {MAX_QUEUE_SIZE} — dropping oldest events.",
                category=TridenteTransportWarning,
                stacklevel=2,
            )


def _http_error(response: httpx.Response) -> ApiError:
    body: Any = {}
    with contextlib.suppress(ValueError):
        body = response.json()
    err = body.get("error") if isinstance(body, dict) else None
    err = err if isinstance(err, dict) else {}
    return ApiError(
        code=err.get("code", "HTTP_ERROR"),
        message=err.get("message", f"status={response.status_code}"),
        status_code=response.status_code,
    )


def register_atexit_flush(client: Tridente) -> None:
    """Register a best-effort flush on process exit."""
    atexit.register(client.close_sync)


def unregister_atexit_flush(client: Tridente) -> None:
    """Unregister a previously registered flush-on-exit hook."""
    atexit.unregister(client.close_sync)


__all__ = [
    "MAX_QUEUE_SIZE",
    "BatchedTransport",
    "TridenteTransportWarning",
    "register_atexit_flush",
    "unregister_atexit_flush",
]
