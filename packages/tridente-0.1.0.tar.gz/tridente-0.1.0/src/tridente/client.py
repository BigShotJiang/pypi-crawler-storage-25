"""Tridente SDK client.

Design:

- Async-first core. Every IO operation is an `async def` method that uses a
  single, long-lived `httpx.AsyncClient`.
- Synchronous facade. Every async method has a `_sync` twin that wraps the
  coroutine in `asyncio.run(...)`. The sync facade deliberately refuses to
  run inside an already-running event loop — calling `.get_entity_sync()`
  from inside FastAPI or Jupyter is a caller bug, not something to paper
  over.
- Dual init. `tridente.init(...)` configures a module-level global client
  for the "three-line demo" flow. `Tridente(...)` is the OO surface for
  long-lived services that want to own the client's lifecycle.

Cross-cutting concerns that live here but are populated by later tasks:

- Task 16.4 adds `_usage_queue`, `_cost_queue`, and `_enqueue_*` helpers
  plus `flush()` / `flush_sync()`.
- Task 16.6 adds the daemon-thread batched transport that drains the queues
  on an interval.
- Task 16.5 layers Pydantic `Entity` / `SearchResponse` models on top of
  the `_raw` surface defined here.
"""

from __future__ import annotations

import asyncio
import contextlib
import threading
import warnings
from types import TracebackType
from typing import TYPE_CHECKING, Any, TypedDict, cast

import httpx

from tridente.config import ClientConfig
from tridente.entity_ref import parse_entity_ref
from tridente.errors import ApiError, ClosedClientError

if TYPE_CHECKING:
    from tridente.models import Entity, SearchResponse

try:
    from tridente._version import __version__ as _SDK_VERSION
except ImportError:  # pragma: no cover — only hit in source trees without hatch-vcs
    _SDK_VERSION = "0.0.0+local"

_USER_AGENT = f"tridente-python/{_SDK_VERSION}"


class _PendingUsage(TypedDict):
    """Internal record for a queued usage event. `entity_id` is resolved
    before enqueue so the background transport thread never needs to do a
    lookup — it just POSTs to the right URL.
    """

    entity_id: str
    event_type: str
    metadata: dict[str, Any] | None


_global_client: Tridente | None = None
_global_lock = threading.Lock()


def get_global_client() -> Tridente | None:
    """Return the module-level client configured via `init(...)`, or None."""
    return _global_client


def reset_global_client() -> None:
    """Close and clear the module-level client.

    Intended for tests and for programmatic re-configuration. User code
    should normally just call `init(...)` again with the new settings —
    `init` handles replacement automatically.
    """
    global _global_client
    with _global_lock:
        existing = _global_client
        _global_client = None
    if existing is not None:
        existing.close_sync()


class Tridente:
    """Tridente SDK client.

    Safe to construct from sync or async code. Each instance owns its own
    `httpx.AsyncClient`, so creating multiple clients (e.g. per-request or
    per-tenant) is cheap but not free — prefer sharing one instance where
    possible.
    """

    def __init__(
        self,
        *,
        api_url: str | None = None,
        api_key: str | None = None,
        flush_interval_seconds: float = 5.0,
        batch_size: int = 50,
        request_timeout_seconds: float = 10.0,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self.config = ClientConfig.from_env(
            api_url=api_url,
            api_key=api_key,
            flush_interval_seconds=flush_interval_seconds,
            batch_size=batch_size,
            request_timeout_seconds=request_timeout_seconds,
        )
        # Async http client is created lazily per-loop. `httpx.AsyncClient`
        # binds its connection pool to the first event loop it's used on;
        # if that loop is closed (which happens every time the sync facade
        # calls asyncio.run()), subsequent use raises "Event loop is
        # closed". We resolve this by caching one AsyncClient per running
        # loop id — async callers reuse their loop's client across awaits,
        # and each fresh asyncio.run() gets its own.
        #
        # When the caller brings their own `http_client`, we honor it
        # unconditionally (they're taking ownership of loop affinity).
        self._user_http: httpx.AsyncClient | None = http_client
        self._owns_http = http_client is None
        self._http_per_loop: dict[int, httpx.AsyncClient] = {}
        self._http_lock = threading.Lock()
        self._closed = False
        self._close_lock = threading.Lock()

        # Resolved entity_ref → entity_id cache. Used by event-reporting
        # methods (Task 16.4) to avoid a lookup per call.
        self._entity_id_cache: dict[str, str] = {}
        self._cache_lock = threading.Lock()

        # Event queues drained by `flush()` and the background transport.
        # Each usage event carries the resolved entity_id alongside the
        # public wire fields.
        self._usage_queue: list[_PendingUsage] = []
        self._cost_queue: list[dict[str, Any]] = []
        self._queue_lock = threading.Lock()

        # Background batched transport. Started here so users get
        # background flushing by default — no extra setup needed.
        from tridente.transport import BatchedTransport, register_atexit_flush

        self._transport = BatchedTransport(self)
        self._transport.start()
        register_atexit_flush(self)

    # ─── HTTP client plumbing ────────────────────────────────────────

    def default_headers(self) -> dict[str, str]:
        """Headers attached to every request by both the async foreground
        client and the background sync transport client.
        """
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "User-Agent": _USER_AGENT,
        }

    def _get_http_for_current_loop(self) -> httpx.AsyncClient:
        """Return an `httpx.AsyncClient` bound to the currently running
        event loop.

        If the caller injected their own `http_client` via the
        constructor, always return that — they own its loop affinity.

        Otherwise, cache one `AsyncClient` per running loop id so that
        repeated `await`s on the same loop reuse the connection pool,
        but fresh `asyncio.run()` invocations (what the sync facade
        uses) get a new client rather than inheriting a pool bound to
        a now-closed loop.
        """
        if self._user_http is not None:
            return self._user_http

        loop = asyncio.get_running_loop()
        loop_id = id(loop)
        with self._http_lock:
            cached = self._http_per_loop.get(loop_id)
            if cached is not None:
                return cached
            client = httpx.AsyncClient(
                base_url=self.config.api_url,
                timeout=self.config.request_timeout_seconds,
                headers=self.default_headers(),
            )
            self._http_per_loop[loop_id] = client
        return client

    # ─── Low-level request ───────────────────────────────────────────

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        _bypass_closed_check: bool = False,
    ) -> Any:
        """Issue an authenticated request and return parsed JSON.

        Non-2xx responses raise `ApiError` with the server-provided code,
        message, and status. Malformed JSON bodies are tolerated on the
        error path — the caller still gets a meaningful status code.

        `_bypass_closed_check` is an internal hook reserved for the
        final flush during `close()`. Never set it from user code.
        """
        if self._closed and not _bypass_closed_check:
            raise ClosedClientError("Tridente client is closed.")

        http = self._get_http_for_current_loop()
        response = await http.request(method, path, json=json, params=params)
        body = _safe_parse_json(response)

        if response.is_error:
            err = (body or {}).get("error") if isinstance(body, dict) else None
            err = err if isinstance(err, dict) else {}
            raise ApiError(
                code=err.get("code", "HTTP_ERROR"),
                message=err.get("message", f"Request failed with status {response.status_code}"),
                status_code=response.status_code,
            )

        return body

    # ─── Low-level read surface (Pydantic wrappers land in Task 16.5) ──

    async def get_entity_raw(self, entity_ref: str) -> dict[str, Any]:
        """Fetch an entity by `kind:namespace/name` and return the raw
        `data` payload (a plain dict). Task 16.5 adds a Pydantic wrapper.
        """
        parsed = parse_entity_ref(entity_ref)
        body = await self._request_json(
            "GET",
            f"/entities/by-ref/{parsed.kind}/{parsed.namespace}/{parsed.name}",
        )
        data = body["data"] if isinstance(body, dict) else None
        if not isinstance(data, dict):
            raise ApiError(
                "MALFORMED_RESPONSE",
                f"Expected object at .data, got {type(data).__name__}",
                status_code=None,
            )
        return data

    def get_entity_raw_sync(self, entity_ref: str) -> dict[str, Any]:
        return cast("dict[str, Any]", _run_sync(self.get_entity_raw(entity_ref)))

    # ─── Typed read surface ──────────────────────────────────────────

    async def get_entity(self, entity_ref: str) -> Entity:
        from tridente.read import get_entity as _get_entity

        return await _get_entity(self, entity_ref)

    def get_entity_sync(self, entity_ref: str) -> Entity:
        from tridente.read import get_entity as _get_entity

        return cast("Entity", _run_sync(_get_entity(self, entity_ref)))

    async def search(self, query: str, **filters: Any) -> SearchResponse:
        from tridente.read import search as _search

        return await _search(self, query, **filters)

    def search_sync(self, query: str, **filters: Any) -> SearchResponse:
        from tridente.read import search as _search

        return cast("SearchResponse", _run_sync(_search(self, query, **filters)))

    # ─── Entity-id cache helper ──────────────────────────────────────

    async def _resolve_entity_id(self, entity_ref: str) -> str:
        with self._cache_lock:
            cached = self._entity_id_cache.get(entity_ref)
        if cached is not None:
            return cached

        entity = await self.get_entity_raw(entity_ref)
        entity_id = str(entity["id"])
        with self._cache_lock:
            self._entity_id_cache[entity_ref] = entity_id
        return entity_id

    # ─── Event queues ────────────────────────────────────────────────

    def _enqueue_usage(self, event: _PendingUsage) -> None:
        with self._queue_lock:
            if self._closed:
                raise ClosedClientError(
                    "Tridente client is closed. Events queued after close() "
                    "are dropped; create a new client to continue."
                )
            self._usage_queue.append(event)
        self._transport.enforce_backpressure()

    def _enqueue_cost(self, event: dict[str, Any]) -> None:
        with self._queue_lock:
            if self._closed:
                raise ClosedClientError(
                    "Tridente client is closed. Events queued after close() "
                    "are dropped; create a new client to continue."
                )
            self._cost_queue.append(event)
        self._transport.enforce_backpressure()

    def _queue_len(self) -> int:
        with self._queue_lock:
            return len(self._usage_queue) + len(self._cost_queue)

    def _drain_queues(self) -> tuple[list[_PendingUsage], list[dict[str, Any]]]:
        with self._queue_lock:
            usage = self._usage_queue[:]
            cost = self._cost_queue[:]
            self._usage_queue.clear()
            self._cost_queue.clear()
        return usage, cost

    async def flush(self) -> None:
        """Send all queued events now.

        On any POST failure, the failing batch is re-queued at the head of
        its lane so the next flush (or the background transport) can retry.
        Raises `ApiError` if the server rejects a batch.
        """
        usage, cost = self._drain_queues()
        try:
            await self._send_usage_batch(usage)
        except Exception:
            # Restore unsent events so a later flush can retry them.
            with self._queue_lock:
                self._usage_queue = usage + self._usage_queue
                self._cost_queue = cost + self._cost_queue
            raise

        try:
            await self._send_cost_batch(cost)
        except Exception:
            with self._queue_lock:
                self._cost_queue = cost + self._cost_queue
            raise

    def flush_sync(self) -> None:
        _run_sync(self.flush())

    async def _send_usage_batch(self, events: list[_PendingUsage]) -> None:
        for event in events:
            # Match TS SDK wire shape: include metadata only when it was
            # set by the caller. JSON.stringify drops undefined values,
            # so {"event_type": "run"} is the wire payload when metadata
            # is None.
            payload: dict[str, Any] = {"event_type": event["event_type"]}
            if event["metadata"] is not None:
                payload["metadata"] = event["metadata"]
            await self._request_json(
                "POST",
                f"/entities/{event['entity_id']}/events",
                json=payload,
            )

    async def _send_cost_batch(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        result = await self._request_json("POST", "/cost-events", json={"events": events})
        ingested: Any = None
        if isinstance(result, dict):
            data = result.get("data")
            if isinstance(data, dict):
                ingested = data.get("ingested_count")
        if ingested != len(events):
            raise ApiError(
                code="COST_INGEST_MISMATCH",
                message=f"expected {len(events)}, got {ingested}",
                status_code=None,
            )

    # ─── Lifecycle ───────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the client: stop the background transport, flush any
        queued events, release HTTP resources. Idempotent.

        Flush failures during close are surfaced as `UserWarning` rather
        than raised — the caller has already signaled intent to shut down
        and raising here would mask user exceptions arriving via `__exit__`.
        """
        # Flip _closed under the lock so concurrent enqueues see a
        # consistent state. Everything after this point can be lock-free
        # because the only writer is this close path.
        with self._close_lock:
            if self._closed:
                return
            self._closed = True

        # Signal the background thread to exit and do its final drain.
        self._transport.stop()

        # Unregister the atexit hook now that we're closing explicitly.
        from tridente.transport import unregister_atexit_flush

        unregister_atexit_flush(self)

        # Best-effort flush of anything the background thread didn't
        # drain. Uses the bypass hook instead of flipping _closed so
        # concurrent enqueues cleanly raise ClosedClientError rather
        # than racing into a post-flush queue that will never ship.
        try:
            await self._flush_for_close()
        except Exception as exc:
            warnings.warn(
                f"Tridente: flush-on-close failed and {self._queue_len()} "
                f"events may be lost: {exc}",
                stacklevel=2,
            )

        # Close every per-loop AsyncClient we built. Only the client
        # bound to the CURRENT loop can be closed cleanly here — ones
        # whose loop is already closed will raise `RuntimeError: Event
        # loop is closed` and are left to the GC / httpx finalizer.
        # If the user injected their own client, they own its lifecycle.
        if self._owns_http:
            with self._http_lock:
                clients = list(self._http_per_loop.values())
                self._http_per_loop.clear()
            for client in clients:
                with contextlib.suppress(RuntimeError):
                    await client.aclose()

    async def _flush_for_close(self) -> None:
        """Variant of `flush()` that bypasses the `_closed` guard. Only
        called from `close()` / `close_sync()`; external callers should
        use `flush()`.
        """
        usage, cost = self._drain_queues()
        for event in usage:
            payload: dict[str, Any] = {"event_type": event["event_type"]}
            if event["metadata"] is not None:
                payload["metadata"] = event["metadata"]
            await self._request_json(
                "POST",
                f"/entities/{event['entity_id']}/events",
                json=payload,
                _bypass_closed_check=True,
            )
        if cost:
            result = await self._request_json(
                "POST",
                "/cost-events",
                json={"events": cost},
                _bypass_closed_check=True,
            )
            ingested: Any = None
            if isinstance(result, dict):
                data = result.get("data")
                if isinstance(data, dict):
                    ingested = data.get("ingested_count")
            if ingested != len(cost):
                raise ApiError(
                    code="COST_INGEST_MISMATCH",
                    message=f"expected {len(cost)}, got {ingested}",
                    status_code=None,
                )

    def close_sync(self) -> None:
        """Synchronous variant of `close()`. Idempotent; safe to call from
        `atexit` handlers and from multiple threads concurrently.
        """
        # Take the lock and the close decision atomically so two threads
        # racing to close (common: atexit + user `__exit__`) don't both
        # proceed into asyncio.run(), which would raise in one of them.
        with self._close_lock:
            if self._closed:
                return
            loop_running = _is_event_loop_running()
            if loop_running:
                # We can't drive asyncio.run from inside a running loop.
                # Flip the flag synchronously so concurrent enqueues stop
                # succeeding; callers who want a proper flush must use
                # `await client.close()` instead.
                self._closed = True

        if loop_running:
            self._transport.stop()
            from tridente.transport import unregister_atexit_flush

            unregister_atexit_flush(self)
            return

        # No loop running — drive the full async close() synchronously.
        # close() itself re-acquires _close_lock for its idempotency
        # check, which sees _closed is still False and proceeds.
        asyncio.run(self.close())

    def __enter__(self) -> Tridente:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close_sync()

    async def __aenter__(self) -> Tridente:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()


# ─── Global init ─────────────────────────────────────────────────────


def init(
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    flush_interval_seconds: float = 5.0,
    batch_size: int = 50,
    request_timeout_seconds: float = 10.0,
) -> Tridente:
    """Configure (or reconfigure) the process-wide Tridente client.

    Idempotent: calling `init(...)` a second time with the same settings
    returns the same client instance. Calling with different settings
    closes the previous client and creates a new one.
    """
    global _global_client

    candidate = ClientConfig.from_env(
        api_url=api_url,
        api_key=api_key,
        flush_interval_seconds=flush_interval_seconds,
        batch_size=batch_size,
        request_timeout_seconds=request_timeout_seconds,
    )

    with _global_lock:
        existing = _global_client
        if existing is not None and _configs_equal(existing.config, candidate):
            return existing

    # Build the new client BEFORE closing the old one so that a failing
    # construction (e.g. bad URL scheme) doesn't leave us with no client.
    replacement = Tridente(
        api_url=candidate.api_url,
        api_key=candidate.api_key,
        flush_interval_seconds=candidate.flush_interval_seconds,
        batch_size=candidate.batch_size,
        request_timeout_seconds=candidate.request_timeout_seconds,
    )

    with _global_lock:
        previous = _global_client
        _global_client = replacement

    if previous is not None:
        previous.close_sync()

    return replacement


def _configs_equal(a: ClientConfig, b: ClientConfig) -> bool:
    return (
        a.api_url == b.api_url
        and a.api_key == b.api_key
        and a.batch_size == b.batch_size
        and a.flush_interval_seconds == b.flush_interval_seconds
        and a.request_timeout_seconds == b.request_timeout_seconds
    )


# ─── Helpers ─────────────────────────────────────────────────────────


def _safe_parse_json(response: httpx.Response) -> Any:
    if not response.content:
        return None
    try:
        return response.json()
    except ValueError:
        return {
            "error": {
                "code": "INVALID_JSON",
                "message": response.text[:500],
            }
        }


def _is_event_loop_running() -> bool:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True


def _run_sync(coro: Any) -> Any:
    """Run an async coroutine from sync code.

    Refuses to run inside an already-running event loop — attempting to
    `asyncio.run()` there would raise `RuntimeError: asyncio.run() cannot
    be called from a running event loop`, which is a worse error than the
    guidance below. On refusal, closes the passed-in coroutine so the
    interpreter doesn't emit a `coroutine was never awaited` warning.
    """
    if _is_event_loop_running():
        with contextlib.suppress(AttributeError):
            coro.close()
        raise RuntimeError(
            "Cannot call synchronous Tridente method from inside a running "
            "event loop. Use the async variant instead, e.g. "
            "`await client.get_entity('agent:default/x')`."
        )
    return asyncio.run(coro)
