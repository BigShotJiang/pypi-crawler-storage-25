"""Parse Tridente entity references of the form `kind:namespace/name`.

Entity refs are the stable, human-readable identifier for a cataloged
entity. They appear in SDK calls, CLI commands, webhook payloads, and the
UI. The grammar is intentionally tight (lowercase kebab-case) so that
round-tripping through a shell, a URL, or a Slack message is lossless.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Final

ENTITY_KINDS: Final[tuple[str, ...]] = (
    "agent",
    "skill",
    "connector",
    "tool",
    "evaluation-suite",
)

_ENTITY_REF_RE: Final = re.compile(r"^([a-z-]+):([a-z0-9-]+)/([a-z0-9-]+)$")


@dataclass(frozen=True, slots=True)
class EntityRef:
    """A parsed entity reference.

    Frozen so instances are safe to cache across threads and use as dict
    keys.
    """

    kind: str
    namespace: str
    name: str

    def __str__(self) -> str:
        return f"{self.kind}:{self.namespace}/{self.name}"


def parse_entity_ref(entity_ref: str) -> EntityRef:
    """Parse a `kind:namespace/name` string.

    Raises `ValueError` with a descriptive message on malformed input or
    unknown kinds — the SDK surfaces these eagerly rather than letting
    the server reject them after a round-trip.
    """
    match = _ENTITY_REF_RE.match(entity_ref)
    if not match:
        raise ValueError(
            f"Invalid entity_ref format: {entity_ref!r}. "
            'Expected "kind:namespace/name" (example: "agent:default/my-agent").'
        )

    kind, namespace, name = match.group(1), match.group(2), match.group(3)
    if kind not in ENTITY_KINDS:
        raise ValueError(
            f"Unsupported entity kind {kind!r}. Expected one of: {', '.join(ENTITY_KINDS)}."
        )

    return EntityRef(kind=kind, namespace=namespace, name=name)
