"""Hand-written Pydantic models for the ergonomic SDK surface.

These mirror the OpenAPI-generated models in `tridente._generated.models`
but use Pydantic (not attrs) so users get:

    - `.model_validate()` for strict parsing from API responses
    - `.model_dump()` for serialization
    - Full IDE autocomplete and type checking
    - A stable, Pydantic-idiomatic surface independent of codegen quirks

The generated attrs classes remain available under `tridente._generated`
for code paths that round-trip the exact server wire types (e.g. the
Task 16.10 contract test).

**Schema drift protection:** the parity test at
`tests/contract/test_wire_parity.py` (Task 16.10) asserts that every
field on a `_generated.models.Entity` also exists on `tridente.models.Entity`.
If you add or rename a field in the OpenAPI spec, regenerate
(`pnpm sdk:python:regenerate`) and update this file — the parity test will
point at any gaps.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

RuntimeStatus = Literal["unknown", "healthy", "degraded", "offline"]


class PaginationMeta(BaseModel):
    """Cursor-and-offset metadata returned alongside paginated collections."""

    model_config = ConfigDict(frozen=True, extra="ignore")

    total: int
    page: int
    limit: int
    next_cursor: str | None = None


class EntityFacets(BaseModel):
    """Faceted aggregate counts returned by search endpoints.

    Each field is a `{value: count}` map, e.g. `kind == {"agent": 42}`.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: dict[str, int] = Field(default_factory=dict)
    maturity: dict[str, int] = Field(default_factory=dict)
    risk_level: dict[str, int] = Field(default_factory=dict)
    runtime_status: dict[str, int] = Field(default_factory=dict)
    owner_team: dict[str, int] = Field(default_factory=dict)


class Entity(BaseModel):
    """A Tridente catalog entity.

    Fields match the `Entity` OpenAPI component. JSONB fields (`labels`,
    `annotations`, `spec`, `created_at`, `updated_at`, `deleted_at`) are
    `Any` because Drizzle returns them as opaque JSON — the server guarantees
    only the shape of the top-level envelope, not the contents of nested
    JSON columns. Access them via `.raw` for forward compatibility when
    the server adds new top-level fields before the SDK is updated.
    """

    model_config = ConfigDict(frozen=True, extra="allow")

    id: str
    kind: str
    name: str
    namespace: str
    display_name: str | None = None
    description: str = ""
    owner_team: str = ""
    maturity: str = ""
    risk_level: str = ""
    version: str = ""
    tags: list[str] = Field(default_factory=list)
    labels: Any = None
    annotations: Any = None
    spec: Any = None
    manifest_raw: str | None = None
    last_verified: str | None = None
    runtime_status: RuntimeStatus = "unknown"
    last_heartbeat: str | None = None
    created_at: Any = None
    updated_at: Any = None
    created_by: str | None = None
    deleted_at: Any = None

    @property
    def raw(self) -> dict[str, Any]:
        """Round-trip-safe dict of every field, including unknown keys
        preserved via `extra='allow'`.
        """
        return self.model_dump(mode="python")


class SearchResponse(BaseModel):
    """Response from `GET /search` — paginated entities with facets."""

    model_config = ConfigDict(frozen=True, extra="ignore")

    data: list[Entity]
    meta: PaginationMeta
    facets: EntityFacets


__all__ = [
    "Entity",
    "EntityFacets",
    "PaginationMeta",
    "RuntimeStatus",
    "SearchResponse",
]
