"""Exception hierarchy for the Tridente SDK.

All SDK errors inherit from `TridenteError` so users can `except` a single
base class. Specific subclasses convey semantic information about what went
wrong:

- `ConfigError`: the SDK was configured incorrectly (missing API key,
  invalid URL, etc.). Raised at construction time.
- `ApiError`: the Tridente API returned a non-2xx response. Carries the
  server-provided error code, message, and HTTP status.
- `ClosedClientError`: a method was called on a client that has been
  closed. Create a fresh client to continue.
"""

from __future__ import annotations


class TridenteError(Exception):
    """Base class for every exception raised by the Tridente SDK."""


class ConfigError(TridenteError):
    """SDK configuration is invalid or missing (e.g. no API key)."""


class ApiError(TridenteError):
    """The Tridente API returned an error response.

    The `code` attribute matches the `error.code` field of the API
    envelope and is stable across SDK versions; use it (not the message)
    for programmatic error handling.
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int | None = None,
    ) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.status_code = status_code


class ClosedClientError(TridenteError):
    """A method was called on a client that has already been closed."""
