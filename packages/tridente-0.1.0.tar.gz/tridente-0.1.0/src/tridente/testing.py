"""Testing utilities for user code that depends on the Tridente SDK.

`MockTridenteClient` is an in-memory, zero-network stand-in for
`tridente.Tridente`. Typical usage in a pytest suite:

    from tridente.testing import MockTridenteClient, tridente_mock  # noqa: F401

    def test_my_agent_emits_a_run_event(tridente_mock):
        my_agent(tridente=tridente_mock)
        assert len(tridente_mock.usage_events) == 1
        assert tridente_mock.usage_events[0].event_type == "run"

The mock records every `report_usage` / `report_cost` / `report_heartbeat`
call so tests can assert on the exact payloads produced by the code
under test. It deliberately does NOT pretend to be a full `Tridente` —
methods like `get_entity` or `search` raise `NotImplementedError` so
callers know they're outside the mock's supported surface.

Use `patch_global_client` for the three-line demo flow:

    with patch_global_client() as mock:
        code_that_calls_tridente_init_somewhere()
        assert mock.usage_events == [...]
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

import pytest

from tridente import client as _client_module


@dataclass(frozen=True)
class CapturedUsageEvent:
    """Fields captured by a mock `report_usage` call."""

    entity_ref: str
    event_type: str
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class CapturedCostEvent:
    """Fields captured by a mock `report_cost` call. Matches the wire
    event shape so tests can assert on what the server would have
    received.
    """

    provider: str
    model: str
    token_count_input: int
    token_count_output: int
    compute_cost_usd: float
    currency: str = "USD"
    recorded_at: str | None = None
    metadata: dict[str, Any] | None = None
    entity_ref: str | None = None


@dataclass(frozen=True)
class CapturedHeartbeat:
    """Fields captured by a mock `report_heartbeat` call."""

    entity_ref: str
    status: str
    metadata: dict[str, Any] | None = None


@dataclass
class MockTridenteClient:
    """In-memory, zero-network stand-in for `tridente.Tridente`.

    All capture lists are populated in call order. Use `reset()` between
    tests or rely on the `tridente_mock` fixture, which creates a fresh
    instance per test.
    """

    usage_events: list[CapturedUsageEvent] = field(default_factory=list)
    cost_events: list[CapturedCostEvent] = field(default_factory=list)
    heartbeats: list[CapturedHeartbeat] = field(default_factory=list)

    def report_usage(
        self,
        entity_ref: str,
        event_type: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.usage_events.append(
            CapturedUsageEvent(
                entity_ref=entity_ref,
                event_type=event_type,
                metadata=metadata,
            )
        )

    def report_cost(
        self,
        *,
        provider: str,
        model: str,
        token_count_input: int,
        token_count_output: int,
        compute_cost_usd: float,
        currency: str = "USD",
        recorded_at: str | None = None,
        metadata: dict[str, Any] | None = None,
        entity_ref: str | None = None,
    ) -> None:
        self.cost_events.append(
            CapturedCostEvent(
                provider=provider,
                model=model,
                token_count_input=token_count_input,
                token_count_output=token_count_output,
                compute_cost_usd=compute_cost_usd,
                currency=currency,
                recorded_at=recorded_at,
                metadata=metadata,
                entity_ref=entity_ref,
            )
        )

    def report_heartbeat(
        self,
        entity_ref: str,
        status: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.heartbeats.append(
            CapturedHeartbeat(
                entity_ref=entity_ref,
                status=status,
                metadata=metadata,
            )
        )

    def reset(self) -> None:
        self.usage_events.clear()
        self.cost_events.clear()
        self.heartbeats.clear()

    # The real `Tridente` exposes `flush` / `close` / etc. for lifecycle
    # management. The mock defines no-ops so that user code that calls
    # them (e.g. atexit handlers, context managers) continues to work.

    def flush_sync(self) -> None:
        return None

    async def flush(self) -> None:
        return None

    def close_sync(self) -> None:
        return None

    async def close(self) -> None:
        return None


@pytest.fixture
def tridente_mock() -> MockTridenteClient:
    """Pytest fixture providing a fresh `MockTridenteClient` per test."""
    return MockTridenteClient()


@contextmanager
def patch_global_client(
    mock: MockTridenteClient | None = None,
) -> Iterator[MockTridenteClient]:
    """Context manager that replaces the module-level client with a mock
    for the duration of the block.

    Useful when code under test calls `tridente.report_usage(...)` /
    `tridente.report_cost(...)` / `tridente.report_heartbeat(...)`
    against the global client and you want to capture those without
    standing up a real network endpoint.

    Example:

        with patch_global_client() as mock:
            user_code_that_uses_tridente()
        assert mock.cost_events == [...]
    """
    mock = mock if mock is not None else MockTridenteClient()
    previous = _client_module._global_client
    _client_module._global_client = mock  # type: ignore[assignment]
    try:
        yield mock
    finally:
        _client_module._global_client = previous


__all__ = [
    "CapturedCostEvent",
    "CapturedHeartbeat",
    "CapturedUsageEvent",
    "MockTridenteClient",
    "patch_global_client",
    "tridente_mock",
]
