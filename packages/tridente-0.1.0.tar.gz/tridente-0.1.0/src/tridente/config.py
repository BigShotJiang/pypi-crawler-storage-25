"""Client configuration.

Resolution order (first non-empty wins):

    1. Explicit keyword arguments to `Tridente(...)` or `init(...)`.
    2. `TRIDENTE_API_URL` / `TRIDENTE_API_KEY` environment variables.
    3. Error.

Config objects are frozen so they can be safely shared across the
synchronous facade, async core, and background transport thread.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Final
from urllib.parse import urlparse

from tridente.errors import ConfigError

DEFAULT_FLUSH_INTERVAL_SECONDS: Final[float] = 5.0
DEFAULT_BATCH_SIZE: Final[int] = 50
MAX_BATCH_SIZE: Final[int] = 100
DEFAULT_REQUEST_TIMEOUT_SECONDS: Final[float] = 10.0

_API_V1_SUFFIX: Final[str] = "/api/v1"


@dataclass(frozen=True, slots=True)
class ClientConfig:
    """Immutable, validated configuration for a `Tridente` client.

    `api_url` is always normalized to end with `/api/v1`. Inputs like
    `https://api.example.com`, `https://api.example.com/`, and
    `https://api.example.com/api/v1/` all normalize to the same value.
    """

    api_url: str
    api_key: str
    flush_interval_seconds: float
    batch_size: int
    request_timeout_seconds: float

    @classmethod
    def from_options(
        cls,
        *,
        api_url: str | None,
        api_key: str | None,
        flush_interval_seconds: float = DEFAULT_FLUSH_INTERVAL_SECONDS,
        batch_size: int = DEFAULT_BATCH_SIZE,
        request_timeout_seconds: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
    ) -> ClientConfig:
        if not api_url:
            raise ConfigError("Missing required option 'api_url' (or TRIDENTE_API_URL env var).")
        if not api_key:
            raise ConfigError("Missing required option 'api_key' (or TRIDENTE_API_KEY env var).")
        if not isinstance(batch_size, int) or batch_size <= 0 or batch_size > MAX_BATCH_SIZE:
            raise ConfigError(
                f"batch_size must be an integer in [1, {MAX_BATCH_SIZE}], got {batch_size!r}."
            )
        if flush_interval_seconds <= 0:
            raise ConfigError(
                f"flush_interval_seconds must be positive, got {flush_interval_seconds!r}."
            )
        if request_timeout_seconds <= 0:
            raise ConfigError(
                f"request_timeout_seconds must be positive, got {request_timeout_seconds!r}."
            )

        return cls(
            api_url=_normalize_base_url(api_url),
            api_key=api_key,
            flush_interval_seconds=float(flush_interval_seconds),
            batch_size=batch_size,
            request_timeout_seconds=float(request_timeout_seconds),
        )

    @classmethod
    def from_env(
        cls,
        *,
        api_url: str | None = None,
        api_key: str | None = None,
        flush_interval_seconds: float = DEFAULT_FLUSH_INTERVAL_SECONDS,
        batch_size: int = DEFAULT_BATCH_SIZE,
        request_timeout_seconds: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
    ) -> ClientConfig:
        """Build a config, falling back to `TRIDENTE_*` env vars for any
        field not supplied as a keyword argument.
        """
        return cls.from_options(
            api_url=api_url or os.environ.get("TRIDENTE_API_URL"),
            api_key=api_key or os.environ.get("TRIDENTE_API_KEY"),
            flush_interval_seconds=flush_interval_seconds,
            batch_size=batch_size,
            request_timeout_seconds=request_timeout_seconds,
        )


def _normalize_base_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ConfigError(
            f"api_url must use http or https scheme, got {parsed.scheme!r} ({url!r})."
        )
    stripped = url.rstrip("/")
    # If the caller already ended with /api/v1 (optionally with a trailing
    # slash, stripped above), keep it. Otherwise append it.
    if stripped.endswith(_API_V1_SUFFIX):
        return stripped
    return f"{stripped}{_API_V1_SUFFIX}"
