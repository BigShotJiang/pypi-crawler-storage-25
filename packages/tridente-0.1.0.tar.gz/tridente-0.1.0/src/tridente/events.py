"""Event reporting surface: `report_usage`, `report_cost`, `report_heartbeat`,
`run()`, `track()`.

These are the three-line demo the SDK exists to enable:

    import tridente
    tridente.init(api_url="...", api_key="...")
    tridente.report_usage("agent:default/my-agent", "run")

All free functions accept `client=` to target a specific client instance.
When omitted, they fall back to the module-level client configured via
`tridente.init(...)`.

Wire format matches the TypeScript SDK byte-for-byte; Task 16.10's parity
test pins that. Do not change payload shapes here without updating the
golden fixtures and running `pnpm -r test` on the TS side.
"""

from __future__ import annotations

import functools
import inspect
import time
from collections.abc import AsyncIterator, Callable, Iterator
from contextlib import asynccontextmanager, contextmanager
from typing import Any, Final, TypeVar, cast

from tridente.client import Tridente, _run_sync, get_global_client
from tridente.entity_ref import parse_entity_ref

# Mirrors `USAGE_EVENT_TYPES` in packages/shared/src/constants/entity.ts and
# the `UsageEventType` OpenAPI enum. Kept as a tuple (not imported from the
# generated module) so that event reporting works even if codegen is stale —
# which prevents a circular "spec changed -> tests fail -> can't regenerate"
# scenario during local dev.
# Must match `USAGE_EVENT_TYPES` in packages/shared/src/constants/entity.ts
# exactly, otherwise the server will reject emitted events. Keep the two
# in sync (enforced by the sdk-contract/ wire-parity test).
USAGE_EVENT_TYPES: Final[tuple[str, ...]] = ("run", "view", "clone", "reuse")

HEARTBEAT_STATUSES: Final[tuple[str, ...]] = ("healthy", "degraded", "offline")


# ─── Helpers ─────────────────────────────────────────────────────────


def _require_client(explicit: Tridente | None) -> Tridente:
    client = explicit if explicit is not None else get_global_client()
    if client is None:
        raise RuntimeError(
            "No Tridente client configured. Call tridente.init(...) or pass client=... explicitly."
        )
    return client


def _assert_usage_event_type(event_type: str) -> None:
    if event_type not in USAGE_EVENT_TYPES:
        raise ValueError(
            f"Unsupported usage event type {event_type!r}. "
            f"Expected one of: {', '.join(USAGE_EVENT_TYPES)}."
        )


def _assert_heartbeat_status(status: str) -> None:
    if status not in HEARTBEAT_STATUSES:
        raise ValueError(
            f"Unsupported heartbeat status {status!r}. "
            f"Expected one of: {', '.join(HEARTBEAT_STATUSES)}."
        )


# ─── report_usage ────────────────────────────────────────────────────


async def report_usage_async(
    entity_ref: str,
    event_type: str,
    *,
    metadata: dict[str, Any] | None = None,
    client: Tridente | None = None,
) -> None:
    """Queue a usage event. Non-blocking (apart from a possible entity-id
    lookup on the first call for a given ref).
    """
    _assert_usage_event_type(event_type)
    parse_entity_ref(entity_ref)  # validate early; fails fast on typos
    c = _require_client(client)
    entity_id = await c._resolve_entity_id(entity_ref)
    c._enqueue_usage(
        {
            "entity_id": entity_id,
            "event_type": event_type,
            "metadata": metadata,
        }
    )


def report_usage(
    entity_ref: str,
    event_type: str,
    *,
    metadata: dict[str, Any] | None = None,
    client: Tridente | None = None,
) -> None:
    """Synchronous facade for `report_usage_async`."""
    # Validate synchronously so callers see the ValueError immediately,
    # not wrapped in whatever _run_sync raises for loop collisions.
    _assert_usage_event_type(event_type)
    parse_entity_ref(entity_ref)
    _run_sync(report_usage_async(entity_ref, event_type, metadata=metadata, client=client))


# ─── report_cost ─────────────────────────────────────────────────────


async def report_cost_async(
    *,
    provider: str,
    model: str,
    token_count_input: int,
    token_count_output: int,
    compute_cost_usd: float,
    currency: str = "USD",
    recorded_at: str | None = None,
    metadata: dict[str, Any] | None = None,
    entity_ref: str | None = None,
    client: Tridente | None = None,
) -> None:
    """Queue a cost event.

    `entity_ref` is optional — cost events can be reported at the org level
    (e.g. a shared LLM proxy) when there is no single owning entity.
    """
    c = _require_client(client)

    # Keep the wire payload shape byte-identical to the TS SDK so the
    # sdk-contract/ parity tests can diff them. The TS SDK omits
    # entity_id entirely when no entity_ref is passed (JSON.stringify
    # drops undefined values); we mirror that here by only setting the
    # key when we actually resolved an ID.
    event: dict[str, Any] = {}
    if entity_ref is not None:
        parse_entity_ref(entity_ref)
        event["entity_id"] = await c._resolve_entity_id(entity_ref)

    event.update(
        {
            "provider": provider,
            "model": model,
            "token_count_input": token_count_input,
            "token_count_output": token_count_output,
            "compute_cost_usd": compute_cost_usd,
            "currency": currency,
        }
    )
    if recorded_at is not None:
        event["recorded_at"] = recorded_at
    if metadata is not None:
        event["metadata"] = metadata

    c._enqueue_cost(event)


def report_cost(
    *,
    provider: str,
    model: str,
    token_count_input: int,
    token_count_output: int,
    compute_cost_usd: float,
    currency: str = "USD",
    recorded_at: str | None = None,
    metadata: dict[str, Any] | None = None,
    entity_ref: str | None = None,
    client: Tridente | None = None,
) -> None:
    """Synchronous facade for `report_cost_async`."""
    if entity_ref is not None:
        parse_entity_ref(entity_ref)
    _run_sync(
        report_cost_async(
            provider=provider,
            model=model,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            compute_cost_usd=compute_cost_usd,
            currency=currency,
            recorded_at=recorded_at,
            metadata=metadata,
            entity_ref=entity_ref,
            client=client,
        )
    )


# ─── report_heartbeat ────────────────────────────────────────────────


async def report_heartbeat_async(
    entity_ref: str,
    status: str,
    *,
    metadata: dict[str, Any] | None = None,
    client: Tridente | None = None,
) -> None:
    """Send a heartbeat synchronously (no batching).

    Heartbeats are liveness signals — the caller needs to know immediately
    whether the server acknowledged them.
    """
    _assert_heartbeat_status(status)
    parse_entity_ref(entity_ref)
    c = _require_client(client)
    entity_id = await c._resolve_entity_id(entity_ref)
    # Match TS SDK wire shape: metadata key is present only when the
    # caller passed a dict. JSON.stringify drops undefined values, so
    # {"status": "healthy"} is the wire payload when no metadata is set.
    body: dict[str, Any] = {"status": status}
    if metadata is not None:
        body["metadata"] = metadata
    await c._request_json("POST", f"/entities/{entity_id}/heartbeat", json=body)


def report_heartbeat(
    entity_ref: str,
    status: str,
    *,
    metadata: dict[str, Any] | None = None,
    client: Tridente | None = None,
) -> None:
    """Synchronous facade for `report_heartbeat_async`."""
    _assert_heartbeat_status(status)
    parse_entity_ref(entity_ref)
    _run_sync(report_heartbeat_async(entity_ref, status, metadata=metadata, client=client))


# ─── Top-level flush helpers ─────────────────────────────────────────


def flush_sync(*, client: Tridente | None = None) -> None:
    """Drain queued usage + cost events on the given (or global) client.

    Equivalent to `client.flush_sync()` but works with the process-wide
    client configured via `tridente.init(...)` without needing to fetch
    the client handle first.
    """
    _require_client(client).flush_sync()


async def flush(*, client: Tridente | None = None) -> None:
    """Async variant of `flush_sync`."""
    await _require_client(client).flush()


# ─── run() context manager ───────────────────────────────────────────


class RunContext:
    """Handle yielded by `run(...)` for accumulating metadata on the
    wrapped block.

    Users do:

        with run("agent:default/x") as ctx:
            ctx.add_metadata(trace_id="abc", user_id="u1")
            ...do work...

    The metadata is merged with duration and (on failure) exception info
    before the event is enqueued.
    """

    __slots__ = ("_metadata", "entity_ref")

    def __init__(self, entity_ref: str) -> None:
        self.entity_ref = entity_ref
        self._metadata: dict[str, Any] = {}

    def add_metadata(self, **kwargs: Any) -> None:
        self._metadata.update(kwargs)

    def set_metadata(self, key: str, value: Any) -> None:
        self._metadata[key] = value

    def metadata_snapshot(self) -> dict[str, Any]:
        return dict(self._metadata)


def _finalize_run(
    ctx: RunContext,
    started_at: float,
    error: BaseException | None,
) -> dict[str, Any]:
    """Build the metadata payload for the `run` event emitted when a
    `run()` block exits.

    The event_type is ALWAYS `"run"` — the canonical
    `USAGE_EVENT_TYPES` enum on the server has no dedicated "failure"
    type. Callers that want to distinguish successes from failures read
    `metadata.error`: set to the exception class name on failure, absent
    on success.
    """
    duration_ms = int((time.monotonic() - started_at) * 1000)
    metadata = ctx.metadata_snapshot()
    metadata["duration_ms"] = duration_ms
    metadata["instrumentation"] = "run"
    if error is not None:
        metadata["error"] = type(error).__name__
    return metadata


@contextmanager
def run(
    entity_ref: str,
    *,
    client: Tridente | None = None,
) -> Iterator[RunContext]:
    """Synchronous context manager that reports a `run` usage event
    with duration when the block exits.

    If the block raises, the exception propagates unchanged; the usage
    event is still queued with `metadata.error` set to the exception
    class name so server-side analytics can compute failure rate. If the
    reporting itself fails AND the user's block also raised, the
    reporting error is suppressed so the user's exception wins.
    """
    parse_entity_ref(entity_ref)
    c = _require_client(client)
    ctx = RunContext(entity_ref)
    started_at = time.monotonic()
    error: BaseException | None = None
    try:
        yield ctx
    except BaseException as exc:
        error = exc
        raise
    finally:
        metadata = _finalize_run(ctx, started_at, error)
        try:
            report_usage(entity_ref, "run", metadata=metadata, client=c)
        except Exception:
            if error is None:
                raise
            # else: user's exception is in flight — swallow the reporting
            # failure. The event will be dropped; a future flush will still
            # surface any queued ones.


@asynccontextmanager
async def run_async(
    entity_ref: str,
    *,
    client: Tridente | None = None,
) -> AsyncIterator[RunContext]:
    """Async variant of `run()`. Used by `track()` to wrap coroutines."""
    parse_entity_ref(entity_ref)
    c = _require_client(client)
    ctx = RunContext(entity_ref)
    started_at = time.monotonic()
    error: BaseException | None = None
    try:
        yield ctx
    except BaseException as exc:
        error = exc
        raise
    finally:
        metadata = _finalize_run(ctx, started_at, error)
        try:
            await report_usage_async(entity_ref, "run", metadata=metadata, client=c)
        except Exception:
            if error is None:
                raise


# ─── track() decorator ───────────────────────────────────────────────


_F = TypeVar("_F", bound=Callable[..., Any])


def track(
    entity_ref: str,
    *,
    client: Tridente | None = None,
) -> Callable[[_F], _F]:
    """Decorator that wraps a function so each call emits a `run` event.

    Works on both sync and async functions — the wrapper detects the
    wrapped function's kind at decoration time and picks the right run
    context.
    """

    def decorator(fn: _F) -> _F:
        if inspect.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                async with run_async(entity_ref, client=client):
                    return await fn(*args, **kwargs)

            return cast("_F", async_wrapper)

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            with run(entity_ref, client=client):
                return fn(*args, **kwargs)

        return cast("_F", sync_wrapper)

    return decorator


__all__ = [
    "HEARTBEAT_STATUSES",
    "USAGE_EVENT_TYPES",
    "RunContext",
    "flush",
    "flush_sync",
    "report_cost",
    "report_cost_async",
    "report_heartbeat",
    "report_heartbeat_async",
    "report_usage",
    "report_usage_async",
    "run",
    "run_async",
    "track",
]
