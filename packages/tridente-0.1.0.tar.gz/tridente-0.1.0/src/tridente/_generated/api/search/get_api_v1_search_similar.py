# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.api_error import ApiError
from ...models.entity_similar_list import EntitySimilarList
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    *,
    entity_id: UUID,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_entity_id = str(entity_id)
    params["entity_id"] = json_entity_id

    params["kind"] = kind

    params["maturity"] = maturity

    params["risk_level"] = risk_level

    params["owner_team"] = owner_team

    params["page"] = page

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/search/similar",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ApiError | EntitySimilarList | None:
    if response.status_code == 200:
        response_200 = EntitySimilarList.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ApiError | EntitySimilarList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    entity_id: UUID,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[ApiError | EntitySimilarList]:
    """ Find entities similar to a source entity

    Args:
        entity_id (UUID):
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | EntitySimilarList]
     """


    kwargs = _get_kwargs(
        entity_id=entity_id,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    entity_id: UUID,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> ApiError | EntitySimilarList | None:
    """ Find entities similar to a source entity

    Args:
        entity_id (UUID):
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | EntitySimilarList
     """


    return sync_detailed(
        client=client,
entity_id=entity_id,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    entity_id: UUID,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[ApiError | EntitySimilarList]:
    """ Find entities similar to a source entity

    Args:
        entity_id (UUID):
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | EntitySimilarList]
     """


    kwargs = _get_kwargs(
        entity_id=entity_id,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    entity_id: UUID,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> ApiError | EntitySimilarList | None:
    """ Find entities similar to a source entity

    Args:
        entity_id (UUID):
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | EntitySimilarList
     """


    return (await asyncio_detailed(
        client=client,
entity_id=entity_id,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )).parsed
