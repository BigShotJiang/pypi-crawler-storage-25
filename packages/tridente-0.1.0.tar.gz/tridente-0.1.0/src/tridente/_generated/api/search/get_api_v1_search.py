# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.entity_list import EntityList
from ...models.get_api_v1_search_mode import GetApiV1SearchMode
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    q: str,
    mode: GetApiV1SearchMode | Unset = GetApiV1SearchMode.FTS,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["q"] = q

    json_mode: str | Unset = UNSET
    if not isinstance(mode, Unset):
        json_mode = mode.value

    params["mode"] = json_mode

    params["kind"] = kind

    params["maturity"] = maturity

    params["risk_level"] = risk_level

    params["owner_team"] = owner_team

    params["page"] = page

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/search",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> EntityList | None:
    if response.status_code == 200:
        response_200 = EntityList.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[EntityList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    mode: GetApiV1SearchMode | Unset = GetApiV1SearchMode.FTS,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[EntityList]:
    """ Full-text search across all entities

    Args:
        q (str):
        mode (GetApiV1SearchMode | Unset):  Default: GetApiV1SearchMode.FTS.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EntityList]
     """


    kwargs = _get_kwargs(
        q=q,
mode=mode,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    mode: GetApiV1SearchMode | Unset = GetApiV1SearchMode.FTS,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> EntityList | None:
    """ Full-text search across all entities

    Args:
        q (str):
        mode (GetApiV1SearchMode | Unset):  Default: GetApiV1SearchMode.FTS.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EntityList
     """


    return sync_detailed(
        client=client,
q=q,
mode=mode,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    mode: GetApiV1SearchMode | Unset = GetApiV1SearchMode.FTS,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[EntityList]:
    """ Full-text search across all entities

    Args:
        q (str):
        mode (GetApiV1SearchMode | Unset):  Default: GetApiV1SearchMode.FTS.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EntityList]
     """


    kwargs = _get_kwargs(
        q=q,
mode=mode,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    mode: GetApiV1SearchMode | Unset = GetApiV1SearchMode.FTS,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> EntityList | None:
    """ Full-text search across all entities

    Args:
        q (str):
        mode (GetApiV1SearchMode | Unset):  Default: GetApiV1SearchMode.FTS.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        owner_team (str | Unset):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EntityList
     """


    return (await asyncio_detailed(
        client=client,
q=q,
mode=mode,
kind=kind,
maturity=maturity,
risk_level=risk_level,
owner_team=owner_team,
page=page,
limit=limit,

    )).parsed
