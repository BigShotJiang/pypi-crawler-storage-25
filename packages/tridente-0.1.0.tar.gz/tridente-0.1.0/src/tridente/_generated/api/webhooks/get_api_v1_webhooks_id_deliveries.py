# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_webhooks_id_deliveries_response_200 import GetApiV1WebhooksIdDeliveriesResponse200
from ...models.get_api_v1_webhooks_id_deliveries_response_403 import GetApiV1WebhooksIdDeliveriesResponse403
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/webhooks/{id}/deliveries".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403 | None:
    if response.status_code == 200:
        response_200 = GetApiV1WebhooksIdDeliveriesResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = GetApiV1WebhooksIdDeliveriesResponse403.from_dict(response.json())



        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403]:
    """ Get delivery logs for a webhook subscription

    Args:
        id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403]
     """


    kwargs = _get_kwargs(
        id=id,
page=page,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403 | None:
    """ Get delivery logs for a webhook subscription

    Args:
        id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403
     """


    return sync_detailed(
        id=id,
client=client,
page=page,
limit=limit,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> Response[GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403]:
    """ Get delivery logs for a webhook subscription

    Args:
        id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403]
     """


    kwargs = _get_kwargs(
        id=id,
page=page,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,

) -> GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403 | None:
    """ Get delivery logs for a webhook subscription

    Args:
        id (UUID):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1WebhooksIdDeliveriesResponse200 | GetApiV1WebhooksIdDeliveriesResponse403
     """


    return (await asyncio_detailed(
        id=id,
client=client,
page=page,
limit=limit,

    )).parsed
