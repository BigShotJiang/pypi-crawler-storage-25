# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_api_v1_webhooks_id_response_200 import DeleteApiV1WebhooksIdResponse200
from ...models.delete_api_v1_webhooks_id_response_403 import DeleteApiV1WebhooksIdResponse403
from ...models.delete_api_v1_webhooks_id_response_404 import DeleteApiV1WebhooksIdResponse404
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/v1/webhooks/{id}".format(id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404 | None:
    if response.status_code == 200:
        response_200 = DeleteApiV1WebhooksIdResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = DeleteApiV1WebhooksIdResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = DeleteApiV1WebhooksIdResponse404.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404]:
    """ Delete a webhook subscription

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404 | None:
    """ Delete a webhook subscription

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404
     """


    return sync_detailed(
        id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404]:
    """ Delete a webhook subscription

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404 | None:
    """ Delete a webhook subscription

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteApiV1WebhooksIdResponse200 | DeleteApiV1WebhooksIdResponse403 | DeleteApiV1WebhooksIdResponse404
     """


    return (await asyncio_detailed(
        id=id,
client=client,

    )).parsed
