# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_approvals_id_approve_response_200 import PostApiV1ApprovalsIdApproveResponse200
from ...models.post_api_v1_approvals_id_approve_response_404 import PostApiV1ApprovalsIdApproveResponse404
from ...models.post_api_v1_approvals_id_approve_response_409 import PostApiV1ApprovalsIdApproveResponse409
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/approvals/{id}/approve".format(id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409 | None:
    if response.status_code == 200:
        response_200 = PostApiV1ApprovalsIdApproveResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = PostApiV1ApprovalsIdApproveResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 409:
        response_409 = PostApiV1ApprovalsIdApproveResponse409.from_dict(response.json())



        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409]:
    """ Approve a pending entity (admin only)

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409 | None:
    """ Approve a pending entity (admin only)

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409
     """


    return sync_detailed(
        id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409]:
    """ Approve a pending entity (admin only)

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409 | None:
    """ Approve a pending entity (admin only)

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1ApprovalsIdApproveResponse200 | PostApiV1ApprovalsIdApproveResponse404 | PostApiV1ApprovalsIdApproveResponse409
     """


    return (await asyncio_detailed(
        id=id,
client=client,

    )).parsed
