# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_teams_name_entities_kind import GetApiV1TeamsNameEntitiesKind
from ...models.get_api_v1_teams_name_entities_maturity import GetApiV1TeamsNameEntitiesMaturity
from ...models.get_api_v1_teams_name_entities_response_200 import GetApiV1TeamsNameEntitiesResponse200
from ...models.get_api_v1_teams_name_entities_risk_level import GetApiV1TeamsNameEntitiesRiskLevel
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    name: str,
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: GetApiV1TeamsNameEntitiesKind | Unset = UNSET,
    maturity: GetApiV1TeamsNameEntitiesMaturity | Unset = UNSET,
    risk_level: GetApiV1TeamsNameEntitiesRiskLevel | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    json_kind: str | Unset = UNSET
    if not isinstance(kind, Unset):
        json_kind = kind.value

    params["kind"] = json_kind

    json_maturity: str | Unset = UNSET
    if not isinstance(maturity, Unset):
        json_maturity = maturity.value

    params["maturity"] = json_maturity

    json_risk_level: str | Unset = UNSET
    if not isinstance(risk_level, Unset):
        json_risk_level = risk_level.value

    params["risk_level"] = json_risk_level


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/teams/{name}/entities".format(name=quote(str(name), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1TeamsNameEntitiesResponse200 | None:
    if response.status_code == 200:
        response_200 = GetApiV1TeamsNameEntitiesResponse200.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1TeamsNameEntitiesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    name: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: GetApiV1TeamsNameEntitiesKind | Unset = UNSET,
    maturity: GetApiV1TeamsNameEntitiesMaturity | Unset = UNSET,
    risk_level: GetApiV1TeamsNameEntitiesRiskLevel | Unset = UNSET,

) -> Response[GetApiV1TeamsNameEntitiesResponse200]:
    """ List entities owned by a specific team

    Args:
        name (str):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (GetApiV1TeamsNameEntitiesKind | Unset):
        maturity (GetApiV1TeamsNameEntitiesMaturity | Unset):
        risk_level (GetApiV1TeamsNameEntitiesRiskLevel | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1TeamsNameEntitiesResponse200]
     """


    kwargs = _get_kwargs(
        name=name,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    name: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: GetApiV1TeamsNameEntitiesKind | Unset = UNSET,
    maturity: GetApiV1TeamsNameEntitiesMaturity | Unset = UNSET,
    risk_level: GetApiV1TeamsNameEntitiesRiskLevel | Unset = UNSET,

) -> GetApiV1TeamsNameEntitiesResponse200 | None:
    """ List entities owned by a specific team

    Args:
        name (str):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (GetApiV1TeamsNameEntitiesKind | Unset):
        maturity (GetApiV1TeamsNameEntitiesMaturity | Unset):
        risk_level (GetApiV1TeamsNameEntitiesRiskLevel | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1TeamsNameEntitiesResponse200
     """


    return sync_detailed(
        name=name,
client=client,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,

    ).parsed

async def asyncio_detailed(
    name: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: GetApiV1TeamsNameEntitiesKind | Unset = UNSET,
    maturity: GetApiV1TeamsNameEntitiesMaturity | Unset = UNSET,
    risk_level: GetApiV1TeamsNameEntitiesRiskLevel | Unset = UNSET,

) -> Response[GetApiV1TeamsNameEntitiesResponse200]:
    """ List entities owned by a specific team

    Args:
        name (str):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (GetApiV1TeamsNameEntitiesKind | Unset):
        maturity (GetApiV1TeamsNameEntitiesMaturity | Unset):
        risk_level (GetApiV1TeamsNameEntitiesRiskLevel | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1TeamsNameEntitiesResponse200]
     """


    kwargs = _get_kwargs(
        name=name,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    name: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: GetApiV1TeamsNameEntitiesKind | Unset = UNSET,
    maturity: GetApiV1TeamsNameEntitiesMaturity | Unset = UNSET,
    risk_level: GetApiV1TeamsNameEntitiesRiskLevel | Unset = UNSET,

) -> GetApiV1TeamsNameEntitiesResponse200 | None:
    """ List entities owned by a specific team

    Args:
        name (str):
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (GetApiV1TeamsNameEntitiesKind | Unset):
        maturity (GetApiV1TeamsNameEntitiesMaturity | Unset):
        risk_level (GetApiV1TeamsNameEntitiesRiskLevel | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1TeamsNameEntitiesResponse200
     """


    return (await asyncio_detailed(
        name=name,
client=client,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,

    )).parsed
