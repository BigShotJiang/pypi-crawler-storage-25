# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_teams_body import PostApiV1TeamsBody
from ...models.post_api_v1_teams_response_201 import PostApiV1TeamsResponse201
from ...models.post_api_v1_teams_response_403 import PostApiV1TeamsResponse403
from ...models.post_api_v1_teams_response_409 import PostApiV1TeamsResponse409
from ...models.post_api_v1_teams_response_500 import PostApiV1TeamsResponse500
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: PostApiV1TeamsBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/teams",
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500 | None:
    if response.status_code == 201:
        response_201 = PostApiV1TeamsResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 403:
        response_403 = PostApiV1TeamsResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 409:
        response_409 = PostApiV1TeamsResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = PostApiV1TeamsResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsBody | Unset = UNSET,

) -> Response[PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500]:
    """ Create a new team

    Args:
        body (PostApiV1TeamsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsBody | Unset = UNSET,

) -> PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500 | None:
    """ Create a new team

    Args:
        body (PostApiV1TeamsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsBody | Unset = UNSET,

) -> Response[PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500]:
    """ Create a new team

    Args:
        body (PostApiV1TeamsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsBody | Unset = UNSET,

) -> PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500 | None:
    """ Create a new team

    Args:
        body (PostApiV1TeamsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1TeamsResponse201 | PostApiV1TeamsResponse403 | PostApiV1TeamsResponse409 | PostApiV1TeamsResponse500
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
