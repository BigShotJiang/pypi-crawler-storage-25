# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_teams_id_members_body import PostApiV1TeamsIdMembersBody
from ...models.post_api_v1_teams_id_members_response_201 import PostApiV1TeamsIdMembersResponse201
from ...models.post_api_v1_teams_id_members_response_403 import PostApiV1TeamsIdMembersResponse403
from ...models.post_api_v1_teams_id_members_response_409 import PostApiV1TeamsIdMembersResponse409
from ...models.post_api_v1_teams_id_members_response_500 import PostApiV1TeamsIdMembersResponse500
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    body: PostApiV1TeamsIdMembersBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/teams/{id}/members".format(id=quote(str(id), safe=""),),
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500 | None:
    if response.status_code == 201:
        response_201 = PostApiV1TeamsIdMembersResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 403:
        response_403 = PostApiV1TeamsIdMembersResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 409:
        response_409 = PostApiV1TeamsIdMembersResponse409.from_dict(response.json())



        return response_409

    if response.status_code == 500:
        response_500 = PostApiV1TeamsIdMembersResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsIdMembersBody | Unset = UNSET,

) -> Response[PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500]:
    """ Add a member to a team

    Args:
        id (UUID):
        body (PostApiV1TeamsIdMembersBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsIdMembersBody | Unset = UNSET,

) -> PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500 | None:
    """ Add a member to a team

    Args:
        id (UUID):
        body (PostApiV1TeamsIdMembersBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsIdMembersBody | Unset = UNSET,

) -> Response[PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500]:
    """ Add a member to a team

    Args:
        id (UUID):
        body (PostApiV1TeamsIdMembersBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1TeamsIdMembersBody | Unset = UNSET,

) -> PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500 | None:
    """ Add a member to a team

    Args:
        id (UUID):
        body (PostApiV1TeamsIdMembersBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1TeamsIdMembersResponse201 | PostApiV1TeamsIdMembersResponse403 | PostApiV1TeamsIdMembersResponse409 | PostApiV1TeamsIdMembersResponse500
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
