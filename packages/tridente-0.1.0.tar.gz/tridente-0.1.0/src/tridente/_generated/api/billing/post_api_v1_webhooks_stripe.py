# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_webhooks_stripe_response_200 import PostApiV1WebhooksStripeResponse200
from ...models.post_api_v1_webhooks_stripe_response_400 import PostApiV1WebhooksStripeResponse400
from ...models.post_api_v1_webhooks_stripe_response_503 import PostApiV1WebhooksStripeResponse503
from typing import cast



def _get_kwargs(
    
) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/webhooks/stripe",
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503 | None:
    if response.status_code == 200:
        response_200 = PostApiV1WebhooksStripeResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = PostApiV1WebhooksStripeResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 503:
        response_503 = PostApiV1WebhooksStripeResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503]:
    """ Stripe webhook receiver for subscription lifecycle events

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503]
     """


    kwargs = _get_kwargs(
        
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,

) -> PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503 | None:
    """ Stripe webhook receiver for subscription lifecycle events

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503
     """


    return sync_detailed(
        client=client,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503]:
    """ Stripe webhook receiver for subscription lifecycle events

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503]
     """


    kwargs = _get_kwargs(
        
    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,

) -> PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503 | None:
    """ Stripe webhook receiver for subscription lifecycle events

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1WebhooksStripeResponse200 | PostApiV1WebhooksStripeResponse400 | PostApiV1WebhooksStripeResponse503
     """


    return (await asyncio_detailed(
        client=client,

    )).parsed
