# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_notifications_mark_read_body import PostApiV1NotificationsMarkReadBody
from ...models.post_api_v1_notifications_mark_read_response_200 import PostApiV1NotificationsMarkReadResponse200
from ...models.post_api_v1_notifications_mark_read_response_401 import PostApiV1NotificationsMarkReadResponse401
from ...models.post_api_v1_notifications_mark_read_response_503 import PostApiV1NotificationsMarkReadResponse503
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: PostApiV1NotificationsMarkReadBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/notifications/mark-read",
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503 | None:
    if response.status_code == 200:
        response_200 = PostApiV1NotificationsMarkReadResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = PostApiV1NotificationsMarkReadResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 503:
        response_503 = PostApiV1NotificationsMarkReadResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1NotificationsMarkReadBody | Unset = UNSET,

) -> Response[PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503]:
    """ Mark notifications as read (all unread if ids omitted)

    Args:
        body (PostApiV1NotificationsMarkReadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1NotificationsMarkReadBody | Unset = UNSET,

) -> PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503 | None:
    """ Mark notifications as read (all unread if ids omitted)

    Args:
        body (PostApiV1NotificationsMarkReadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1NotificationsMarkReadBody | Unset = UNSET,

) -> Response[PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503]:
    """ Mark notifications as read (all unread if ids omitted)

    Args:
        body (PostApiV1NotificationsMarkReadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1NotificationsMarkReadBody | Unset = UNSET,

) -> PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503 | None:
    """ Mark notifications as read (all unread if ids omitted)

    Args:
        body (PostApiV1NotificationsMarkReadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1NotificationsMarkReadResponse200 | PostApiV1NotificationsMarkReadResponse401 | PostApiV1NotificationsMarkReadResponse503
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
