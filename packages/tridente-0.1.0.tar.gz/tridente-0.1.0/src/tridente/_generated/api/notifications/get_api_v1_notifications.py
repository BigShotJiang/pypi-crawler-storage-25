# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_notifications_response_200 import GetApiV1NotificationsResponse200
from ...models.get_api_v1_notifications_response_401 import GetApiV1NotificationsResponse401
from ...models.get_api_v1_notifications_response_503 import GetApiV1NotificationsResponse503
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    unread_only: bool | None | Unset = False,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    json_unread_only: bool | None | Unset
    if isinstance(unread_only, Unset):
        json_unread_only = UNSET
    else:
        json_unread_only = unread_only
    params["unread_only"] = json_unread_only


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/notifications",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503 | None:
    if response.status_code == 200:
        response_200 = GetApiV1NotificationsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = GetApiV1NotificationsResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 503:
        response_503 = GetApiV1NotificationsResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    unread_only: bool | None | Unset = False,

) -> Response[GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503]:
    """ List in-app notifications for current user

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        unread_only (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
unread_only=unread_only,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    unread_only: bool | None | Unset = False,

) -> GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503 | None:
    """ List in-app notifications for current user

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        unread_only (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503
     """


    return sync_detailed(
        client=client,
page=page,
limit=limit,
unread_only=unread_only,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    unread_only: bool | None | Unset = False,

) -> Response[GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503]:
    """ List in-app notifications for current user

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        unread_only (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
unread_only=unread_only,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    unread_only: bool | None | Unset = False,

) -> GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503 | None:
    """ List in-app notifications for current user

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        unread_only (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1NotificationsResponse200 | GetApiV1NotificationsResponse401 | GetApiV1NotificationsResponse503
     """


    return (await asyncio_detailed(
        client=client,
page=page,
limit=limit,
unread_only=unread_only,

    )).parsed
