# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_requests_id_comments_body import PostApiV1RequestsIdCommentsBody
from ...models.post_api_v1_requests_id_comments_response_201 import PostApiV1RequestsIdCommentsResponse201
from ...models.post_api_v1_requests_id_comments_response_401 import PostApiV1RequestsIdCommentsResponse401
from ...models.post_api_v1_requests_id_comments_response_404 import PostApiV1RequestsIdCommentsResponse404
from ...models.post_api_v1_requests_id_comments_response_503 import PostApiV1RequestsIdCommentsResponse503
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    body: PostApiV1RequestsIdCommentsBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/requests/{id}/comments".format(id=quote(str(id), safe=""),),
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503 | None:
    if response.status_code == 201:
        response_201 = PostApiV1RequestsIdCommentsResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 401:
        response_401 = PostApiV1RequestsIdCommentsResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 404:
        response_404 = PostApiV1RequestsIdCommentsResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 503:
        response_503 = PostApiV1RequestsIdCommentsResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsIdCommentsBody | Unset = UNSET,

) -> Response[PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503]:
    """ Add a comment to a request

    Args:
        id (UUID):
        body (PostApiV1RequestsIdCommentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsIdCommentsBody | Unset = UNSET,

) -> PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503 | None:
    """ Add a comment to a request

    Args:
        id (UUID):
        body (PostApiV1RequestsIdCommentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsIdCommentsBody | Unset = UNSET,

) -> Response[PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503]:
    """ Add a comment to a request

    Args:
        id (UUID):
        body (PostApiV1RequestsIdCommentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsIdCommentsBody | Unset = UNSET,

) -> PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503 | None:
    """ Add a comment to a request

    Args:
        id (UUID):
        body (PostApiV1RequestsIdCommentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1RequestsIdCommentsResponse201 | PostApiV1RequestsIdCommentsResponse401 | PostApiV1RequestsIdCommentsResponse404 | PostApiV1RequestsIdCommentsResponse503
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
