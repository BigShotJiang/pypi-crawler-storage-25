# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_requests_response_200 import GetApiV1RequestsResponse200
from ...models.get_api_v1_requests_response_503 import GetApiV1RequestsResponse503
from ...models.get_api_v1_requests_status import GetApiV1RequestsStatus
from ...models.get_api_v1_requests_target_kind import GetApiV1RequestsTargetKind
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    status: GetApiV1RequestsStatus | Unset = UNSET,
    target_kind: GetApiV1RequestsTargetKind | Unset = UNSET,
    requester_id: UUID | Unset = UNSET,
    assignee_id: UUID | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_target_kind: str | Unset = UNSET
    if not isinstance(target_kind, Unset):
        json_target_kind = target_kind.value

    params["target_kind"] = json_target_kind

    json_requester_id: str | Unset = UNSET
    if not isinstance(requester_id, Unset):
        json_requester_id = str(requester_id)
    params["requester_id"] = json_requester_id

    json_assignee_id: str | Unset = UNSET
    if not isinstance(assignee_id, Unset):
        json_assignee_id = str(assignee_id)
    params["assignee_id"] = json_assignee_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/requests",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503 | None:
    if response.status_code == 200:
        response_200 = GetApiV1RequestsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 503:
        response_503 = GetApiV1RequestsResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    status: GetApiV1RequestsStatus | Unset = UNSET,
    target_kind: GetApiV1RequestsTargetKind | Unset = UNSET,
    requester_id: UUID | Unset = UNSET,
    assignee_id: UUID | Unset = UNSET,

) -> Response[GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503]:
    """ List component requests

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        status (GetApiV1RequestsStatus | Unset):
        target_kind (GetApiV1RequestsTargetKind | Unset):
        requester_id (UUID | Unset):
        assignee_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
status=status,
target_kind=target_kind,
requester_id=requester_id,
assignee_id=assignee_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    status: GetApiV1RequestsStatus | Unset = UNSET,
    target_kind: GetApiV1RequestsTargetKind | Unset = UNSET,
    requester_id: UUID | Unset = UNSET,
    assignee_id: UUID | Unset = UNSET,

) -> GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503 | None:
    """ List component requests

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        status (GetApiV1RequestsStatus | Unset):
        target_kind (GetApiV1RequestsTargetKind | Unset):
        requester_id (UUID | Unset):
        assignee_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503
     """


    return sync_detailed(
        client=client,
page=page,
limit=limit,
status=status,
target_kind=target_kind,
requester_id=requester_id,
assignee_id=assignee_id,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    status: GetApiV1RequestsStatus | Unset = UNSET,
    target_kind: GetApiV1RequestsTargetKind | Unset = UNSET,
    requester_id: UUID | Unset = UNSET,
    assignee_id: UUID | Unset = UNSET,

) -> Response[GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503]:
    """ List component requests

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        status (GetApiV1RequestsStatus | Unset):
        target_kind (GetApiV1RequestsTargetKind | Unset):
        requester_id (UUID | Unset):
        assignee_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
status=status,
target_kind=target_kind,
requester_id=requester_id,
assignee_id=assignee_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    status: GetApiV1RequestsStatus | Unset = UNSET,
    target_kind: GetApiV1RequestsTargetKind | Unset = UNSET,
    requester_id: UUID | Unset = UNSET,
    assignee_id: UUID | Unset = UNSET,

) -> GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503 | None:
    """ List component requests

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        status (GetApiV1RequestsStatus | Unset):
        target_kind (GetApiV1RequestsTargetKind | Unset):
        requester_id (UUID | Unset):
        assignee_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1RequestsResponse200 | GetApiV1RequestsResponse503
     """


    return (await asyncio_detailed(
        client=client,
page=page,
limit=limit,
status=status,
target_kind=target_kind,
requester_id=requester_id,
assignee_id=assignee_id,

    )).parsed
