# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_requests_body import PostApiV1RequestsBody
from ...models.post_api_v1_requests_response_201 import PostApiV1RequestsResponse201
from ...models.post_api_v1_requests_response_401 import PostApiV1RequestsResponse401
from ...models.post_api_v1_requests_response_503 import PostApiV1RequestsResponse503
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: PostApiV1RequestsBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/requests",
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503 | None:
    if response.status_code == 201:
        response_201 = PostApiV1RequestsResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 401:
        response_401 = PostApiV1RequestsResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 503:
        response_503 = PostApiV1RequestsResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsBody | Unset = UNSET,

) -> Response[PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503]:
    """ Create a component request

    Args:
        body (PostApiV1RequestsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsBody | Unset = UNSET,

) -> PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503 | None:
    """ Create a component request

    Args:
        body (PostApiV1RequestsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsBody | Unset = UNSET,

) -> Response[PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503]:
    """ Create a component request

    Args:
        body (PostApiV1RequestsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1RequestsBody | Unset = UNSET,

) -> PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503 | None:
    """ Create a component request

    Args:
        body (PostApiV1RequestsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1RequestsResponse201 | PostApiV1RequestsResponse401 | PostApiV1RequestsResponse503
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
