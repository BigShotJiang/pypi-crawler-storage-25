# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.put_api_v1_requests_id_body import PutApiV1RequestsIdBody
from ...models.put_api_v1_requests_id_response_200 import PutApiV1RequestsIdResponse200
from ...models.put_api_v1_requests_id_response_401 import PutApiV1RequestsIdResponse401
from ...models.put_api_v1_requests_id_response_403 import PutApiV1RequestsIdResponse403
from ...models.put_api_v1_requests_id_response_404 import PutApiV1RequestsIdResponse404
from ...models.put_api_v1_requests_id_response_503 import PutApiV1RequestsIdResponse503
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,
    *,
    body: PutApiV1RequestsIdBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/requests/{id}".format(id=quote(str(id), safe=""),),
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503 | None:
    if response.status_code == 200:
        response_200 = PutApiV1RequestsIdResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = PutApiV1RequestsIdResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = PutApiV1RequestsIdResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = PutApiV1RequestsIdResponse404.from_dict(response.json())



        return response_404

    if response.status_code == 503:
        response_503 = PutApiV1RequestsIdResponse503.from_dict(response.json())



        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutApiV1RequestsIdBody | Unset = UNSET,

) -> Response[PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503]:
    """ Update request fields

    Args:
        id (UUID):
        body (PutApiV1RequestsIdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutApiV1RequestsIdBody | Unset = UNSET,

) -> PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503 | None:
    """ Update request fields

    Args:
        id (UUID):
        body (PutApiV1RequestsIdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutApiV1RequestsIdBody | Unset = UNSET,

) -> Response[PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503]:
    """ Update request fields

    Args:
        id (UUID):
        body (PutApiV1RequestsIdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutApiV1RequestsIdBody | Unset = UNSET,

) -> PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503 | None:
    """ Update request fields

    Args:
        id (UUID):
        body (PutApiV1RequestsIdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PutApiV1RequestsIdResponse200 | PutApiV1RequestsIdResponse401 | PutApiV1RequestsIdResponse403 | PutApiV1RequestsIdResponse404 | PutApiV1RequestsIdResponse503
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
