# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_entities_graph_response_200 import GetApiV1EntitiesGraphResponse200
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    kind: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["kind"] = kind

    params["owner_team"] = owner_team


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/entities/graph",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1EntitiesGraphResponse200 | None:
    if response.status_code == 200:
        response_200 = GetApiV1EntitiesGraphResponse200.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1EntitiesGraphResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    kind: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,

) -> Response[GetApiV1EntitiesGraphResponse200]:
    """ Get entity dependency graph (nodes and edges)

    Args:
        kind (str | Unset):
        owner_team (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1EntitiesGraphResponse200]
     """


    kwargs = _get_kwargs(
        kind=kind,
owner_team=owner_team,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    kind: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,

) -> GetApiV1EntitiesGraphResponse200 | None:
    """ Get entity dependency graph (nodes and edges)

    Args:
        kind (str | Unset):
        owner_team (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1EntitiesGraphResponse200
     """


    return sync_detailed(
        client=client,
kind=kind,
owner_team=owner_team,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    kind: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,

) -> Response[GetApiV1EntitiesGraphResponse200]:
    """ Get entity dependency graph (nodes and edges)

    Args:
        kind (str | Unset):
        owner_team (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1EntitiesGraphResponse200]
     """


    kwargs = _get_kwargs(
        kind=kind,
owner_team=owner_team,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    kind: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,

) -> GetApiV1EntitiesGraphResponse200 | None:
    """ Get entity dependency graph (nodes and edges)

    Args:
        kind (str | Unset):
        owner_team (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1EntitiesGraphResponse200
     """


    return (await asyncio_detailed(
        client=client,
kind=kind,
owner_team=owner_team,

    )).parsed
