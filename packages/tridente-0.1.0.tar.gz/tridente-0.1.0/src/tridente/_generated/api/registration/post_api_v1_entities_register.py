# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_api_v1_entities_register_body import PostApiV1EntitiesRegisterBody
from ...models.post_api_v1_entities_register_response_201 import PostApiV1EntitiesRegisterResponse201
from ...models.post_api_v1_entities_register_response_400 import PostApiV1EntitiesRegisterResponse400
from ...models.post_api_v1_entities_register_response_403 import PostApiV1EntitiesRegisterResponse403
from ...models.post_api_v1_entities_register_response_409 import PostApiV1EntitiesRegisterResponse409
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: PostApiV1EntitiesRegisterBody | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/entities/register",
    }

    
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409 | None:
    if response.status_code == 201:
        response_201 = PostApiV1EntitiesRegisterResponse201.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = PostApiV1EntitiesRegisterResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 403:
        response_403 = PostApiV1EntitiesRegisterResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 409:
        response_409 = PostApiV1EntitiesRegisterResponse409.from_dict(response.json())



        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1EntitiesRegisterBody | Unset = UNSET,

) -> Response[PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409]:
    """ Register a new entity from a YAML manifest

    Args:
        body (PostApiV1EntitiesRegisterBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1EntitiesRegisterBody | Unset = UNSET,

) -> PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409 | None:
    """ Register a new entity from a YAML manifest

    Args:
        body (PostApiV1EntitiesRegisterBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1EntitiesRegisterBody | Unset = UNSET,

) -> Response[PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409]:
    """ Register a new entity from a YAML manifest

    Args:
        body (PostApiV1EntitiesRegisterBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostApiV1EntitiesRegisterBody | Unset = UNSET,

) -> PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409 | None:
    """ Register a new entity from a YAML manifest

    Args:
        body (PostApiV1EntitiesRegisterBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostApiV1EntitiesRegisterResponse201 | PostApiV1EntitiesRegisterResponse400 | PostApiV1EntitiesRegisterResponse403 | PostApiV1EntitiesRegisterResponse409
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
