# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_users_response_200 import GetApiV1UsersResponse200
from ...models.get_api_v1_users_response_403 import GetApiV1UsersResponse403
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    search: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    params["search"] = search


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/users",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1UsersResponse200 | GetApiV1UsersResponse403 | None:
    if response.status_code == 200:
        response_200 = GetApiV1UsersResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = GetApiV1UsersResponse403.from_dict(response.json())



        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1UsersResponse200 | GetApiV1UsersResponse403]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    search: str | Unset = UNSET,

) -> Response[GetApiV1UsersResponse200 | GetApiV1UsersResponse403]:
    """ List users in organization

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1UsersResponse200 | GetApiV1UsersResponse403]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
search=search,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    search: str | Unset = UNSET,

) -> GetApiV1UsersResponse200 | GetApiV1UsersResponse403 | None:
    """ List users in organization

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1UsersResponse200 | GetApiV1UsersResponse403
     """


    return sync_detailed(
        client=client,
page=page,
limit=limit,
search=search,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    search: str | Unset = UNSET,

) -> Response[GetApiV1UsersResponse200 | GetApiV1UsersResponse403]:
    """ List users in organization

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1UsersResponse200 | GetApiV1UsersResponse403]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
search=search,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    search: str | Unset = UNSET,

) -> GetApiV1UsersResponse200 | GetApiV1UsersResponse403 | None:
    """ List users in organization

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        search (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1UsersResponse200 | GetApiV1UsersResponse403
     """


    return (await asyncio_detailed(
        client=client,
page=page,
limit=limit,
search=search,

    )).parsed
