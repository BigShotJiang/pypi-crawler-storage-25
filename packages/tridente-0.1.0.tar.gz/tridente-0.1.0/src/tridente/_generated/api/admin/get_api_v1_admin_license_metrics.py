# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_admin_license_metrics_response_200 import GetApiV1AdminLicenseMetricsResponse200
from ...models.get_api_v1_admin_license_metrics_response_403 import GetApiV1AdminLicenseMetricsResponse403
from ...models.get_api_v1_admin_license_metrics_response_500 import GetApiV1AdminLicenseMetricsResponse500
from typing import cast



def _get_kwargs(
    
) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/admin/license-metrics",
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500 | None:
    if response.status_code == 200:
        response_200 = GetApiV1AdminLicenseMetricsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = GetApiV1AdminLicenseMetricsResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = GetApiV1AdminLicenseMetricsResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500]:
    """ Get license revenue KPI metrics

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500]
     """


    kwargs = _get_kwargs(
        
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,

) -> GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500 | None:
    """ Get license revenue KPI metrics

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500
     """


    return sync_detailed(
        client=client,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500]:
    """ Get license revenue KPI metrics

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500]
     """


    kwargs = _get_kwargs(
        
    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,

) -> GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500 | None:
    """ Get license revenue KPI metrics

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1AdminLicenseMetricsResponse200 | GetApiV1AdminLicenseMetricsResponse403 | GetApiV1AdminLicenseMetricsResponse500
     """


    return (await asyncio_detailed(
        client=client,

    )).parsed
