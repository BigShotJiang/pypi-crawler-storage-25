# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_api_v1_analytics_adoption_trends_range import GetApiV1AnalyticsAdoptionTrendsRange
from ...models.get_api_v1_analytics_adoption_trends_response_200 import GetApiV1AnalyticsAdoptionTrendsResponse200
from ...models.get_api_v1_analytics_adoption_trends_response_403 import GetApiV1AnalyticsAdoptionTrendsResponse403
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    range_: GetApiV1AnalyticsAdoptionTrendsRange | Unset = GetApiV1AnalyticsAdoptionTrendsRange.QTD,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_range_: str | Unset = UNSET
    if not isinstance(range_, Unset):
        json_range_ = range_.value

    params["range"] = json_range_


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/analytics/adoption-trends",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403 | None:
    if response.status_code == 200:
        response_200 = GetApiV1AnalyticsAdoptionTrendsResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = GetApiV1AnalyticsAdoptionTrendsResponse403.from_dict(response.json())



        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    range_: GetApiV1AnalyticsAdoptionTrendsRange | Unset = GetApiV1AnalyticsAdoptionTrendsRange.QTD,

) -> Response[GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403]:
    """ Adoption trends: new users, teams, and reuse events per week

    Args:
        range_ (GetApiV1AnalyticsAdoptionTrendsRange | Unset):  Default:
            GetApiV1AnalyticsAdoptionTrendsRange.QTD.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403]
     """


    kwargs = _get_kwargs(
        range_=range_,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    range_: GetApiV1AnalyticsAdoptionTrendsRange | Unset = GetApiV1AnalyticsAdoptionTrendsRange.QTD,

) -> GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403 | None:
    """ Adoption trends: new users, teams, and reuse events per week

    Args:
        range_ (GetApiV1AnalyticsAdoptionTrendsRange | Unset):  Default:
            GetApiV1AnalyticsAdoptionTrendsRange.QTD.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403
     """


    return sync_detailed(
        client=client,
range_=range_,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    range_: GetApiV1AnalyticsAdoptionTrendsRange | Unset = GetApiV1AnalyticsAdoptionTrendsRange.QTD,

) -> Response[GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403]:
    """ Adoption trends: new users, teams, and reuse events per week

    Args:
        range_ (GetApiV1AnalyticsAdoptionTrendsRange | Unset):  Default:
            GetApiV1AnalyticsAdoptionTrendsRange.QTD.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403]
     """


    kwargs = _get_kwargs(
        range_=range_,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    range_: GetApiV1AnalyticsAdoptionTrendsRange | Unset = GetApiV1AnalyticsAdoptionTrendsRange.QTD,

) -> GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403 | None:
    """ Adoption trends: new users, teams, and reuse events per week

    Args:
        range_ (GetApiV1AnalyticsAdoptionTrendsRange | Unset):  Default:
            GetApiV1AnalyticsAdoptionTrendsRange.QTD.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiV1AnalyticsAdoptionTrendsResponse200 | GetApiV1AnalyticsAdoptionTrendsResponse403
     """


    return (await asyncio_detailed(
        client=client,
range_=range_,

    )).parsed
