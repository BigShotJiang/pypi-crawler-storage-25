# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.api_error import ApiError
from ...models.entity_envelope import EntityEnvelope
from ...models.entity_kind import EntityKind
from typing import cast



def _get_kwargs(
    kind: EntityKind,
    namespace: str,
    name: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/entities/by-ref/{kind}/{namespace}/{name}".format(kind=quote(str(kind), safe=""),namespace=quote(str(namespace), safe=""),name=quote(str(name), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ApiError | EntityEnvelope | None:
    if response.status_code == 200:
        response_200 = EntityEnvelope.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ApiError | EntityEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    kind: EntityKind,
    namespace: str,
    name: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ApiError | EntityEnvelope]:
    """ Get entity by kind:namespace/name reference

    Args:
        kind (EntityKind):
        namespace (str):
        name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | EntityEnvelope]
     """


    kwargs = _get_kwargs(
        kind=kind,
namespace=namespace,
name=name,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    kind: EntityKind,
    namespace: str,
    name: str,
    *,
    client: AuthenticatedClient | Client,

) -> ApiError | EntityEnvelope | None:
    """ Get entity by kind:namespace/name reference

    Args:
        kind (EntityKind):
        namespace (str):
        name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | EntityEnvelope
     """


    return sync_detailed(
        kind=kind,
namespace=namespace,
name=name,
client=client,

    ).parsed

async def asyncio_detailed(
    kind: EntityKind,
    namespace: str,
    name: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ApiError | EntityEnvelope]:
    """ Get entity by kind:namespace/name reference

    Args:
        kind (EntityKind):
        namespace (str):
        name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | EntityEnvelope]
     """


    kwargs = _get_kwargs(
        kind=kind,
namespace=namespace,
name=name,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    kind: EntityKind,
    namespace: str,
    name: str,
    *,
    client: AuthenticatedClient | Client,

) -> ApiError | EntityEnvelope | None:
    """ Get entity by kind:namespace/name reference

    Args:
        kind (EntityKind):
        namespace (str):
        name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | EntityEnvelope
     """


    return (await asyncio_detailed(
        kind=kind,
namespace=namespace,
name=name,
client=client,

    )).parsed
