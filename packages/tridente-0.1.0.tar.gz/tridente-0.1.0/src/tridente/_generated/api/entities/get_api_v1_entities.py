# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.entity_list import EntityList
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    runtime_status: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    cursor: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    params["kind"] = kind

    params["maturity"] = maturity

    params["risk_level"] = risk_level

    params["runtime_status"] = runtime_status

    params["owner_team"] = owner_team

    params["cursor"] = cursor


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/entities",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> EntityList | None:
    if response.status_code == 200:
        response_200 = EntityList.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[EntityList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    runtime_status: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    cursor: str | Unset = UNSET,

) -> Response[EntityList]:
    """ List entities with pagination and filters

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        runtime_status (str | Unset):
        owner_team (str | Unset):
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EntityList]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,
runtime_status=runtime_status,
owner_team=owner_team,
cursor=cursor,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    runtime_status: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    cursor: str | Unset = UNSET,

) -> EntityList | None:
    """ List entities with pagination and filters

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        runtime_status (str | Unset):
        owner_team (str | Unset):
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EntityList
     """


    return sync_detailed(
        client=client,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,
runtime_status=runtime_status,
owner_team=owner_team,
cursor=cursor,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    runtime_status: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    cursor: str | Unset = UNSET,

) -> Response[EntityList]:
    """ List entities with pagination and filters

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        runtime_status (str | Unset):
        owner_team (str | Unset):
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EntityList]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,
runtime_status=runtime_status,
owner_team=owner_team,
cursor=cursor,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = 1,
    limit: int | Unset = 20,
    kind: str | Unset = UNSET,
    maturity: str | Unset = UNSET,
    risk_level: str | Unset = UNSET,
    runtime_status: str | Unset = UNSET,
    owner_team: str | Unset = UNSET,
    cursor: str | Unset = UNSET,

) -> EntityList | None:
    """ List entities with pagination and filters

    Args:
        page (int | Unset):  Default: 1.
        limit (int | Unset):  Default: 20.
        kind (str | Unset):
        maturity (str | Unset):
        risk_level (str | Unset):
        runtime_status (str | Unset):
        owner_team (str | Unset):
        cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EntityList
     """


    return (await asyncio_detailed(
        client=client,
page=page,
limit=limit,
kind=kind,
maturity=maturity,
risk_level=risk_level,
runtime_status=runtime_status,
owner_team=owner_team,
cursor=cursor,

    )).parsed
