# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_api_v1_entities_register_response_201_data_governance import PostApiV1EntitiesRegisterResponse201DataGovernance
  from ..models.post_api_v1_entities_register_response_201_data_relations import PostApiV1EntitiesRegisterResponse201DataRelations





T = TypeVar("T", bound="PostApiV1EntitiesRegisterResponse201Data")



@_attrs_define
class PostApiV1EntitiesRegisterResponse201Data:
    """ 
        Attributes:
            governance (PostApiV1EntitiesRegisterResponse201DataGovernance):
            entity (Any | Unset):
            relations (PostApiV1EntitiesRegisterResponse201DataRelations | Unset):
            pending_approval (bool | Unset):
     """

    governance: PostApiV1EntitiesRegisterResponse201DataGovernance
    entity: Any | Unset = UNSET
    relations: PostApiV1EntitiesRegisterResponse201DataRelations | Unset = UNSET
    pending_approval: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_api_v1_entities_register_response_201_data_governance import PostApiV1EntitiesRegisterResponse201DataGovernance
        from ..models.post_api_v1_entities_register_response_201_data_relations import PostApiV1EntitiesRegisterResponse201DataRelations
        governance = self.governance.to_dict()

        entity = self.entity

        relations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.relations, Unset):
            relations = self.relations.to_dict()

        pending_approval = self.pending_approval


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "governance": governance,
        })
        if entity is not UNSET:
            field_dict["entity"] = entity
        if relations is not UNSET:
            field_dict["relations"] = relations
        if pending_approval is not UNSET:
            field_dict["pending_approval"] = pending_approval

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_api_v1_entities_register_response_201_data_governance import PostApiV1EntitiesRegisterResponse201DataGovernance
        from ..models.post_api_v1_entities_register_response_201_data_relations import PostApiV1EntitiesRegisterResponse201DataRelations
        d = dict(src_dict)
        governance = PostApiV1EntitiesRegisterResponse201DataGovernance.from_dict(d.pop("governance"))




        entity = d.pop("entity", UNSET)

        _relations = d.pop("relations", UNSET)
        relations: PostApiV1EntitiesRegisterResponse201DataRelations | Unset
        if isinstance(_relations,  Unset):
            relations = UNSET
        else:
            relations = PostApiV1EntitiesRegisterResponse201DataRelations.from_dict(_relations)




        pending_approval = d.pop("pending_approval", UNSET)

        post_api_v1_entities_register_response_201_data = cls(
            governance=governance,
            entity=entity,
            relations=relations,
            pending_approval=pending_approval,
        )


        post_api_v1_entities_register_response_201_data.additional_properties = d
        return post_api_v1_entities_register_response_201_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
