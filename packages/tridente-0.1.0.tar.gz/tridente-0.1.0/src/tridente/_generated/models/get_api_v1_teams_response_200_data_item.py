# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime






T = TypeVar("T", bound="GetApiV1TeamsResponse200DataItem")



@_attrs_define
class GetApiV1TeamsResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            name (str):
            slug (str):
            created_at (datetime.datetime | str):
            updated_at (datetime.datetime | str):
            deleted_at (Any | datetime.datetime | str):
            member_count (float):
            entity_count (float):
            description (None | str | Unset):
     """

    id: UUID
    org_id: UUID
    name: str
    slug: str
    created_at: datetime.datetime | str
    updated_at: datetime.datetime | str
    deleted_at: Any | datetime.datetime | str
    member_count: float
    entity_count: float
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        org_id = str(self.org_id)

        name = self.name

        slug = self.slug

        created_at: str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        updated_at: str
        if isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        deleted_at: Any | str
        if isinstance(self.deleted_at, datetime.datetime):
            deleted_at = self.deleted_at.isoformat()
        else:
            deleted_at = self.deleted_at

        member_count = self.member_count

        entity_count = self.entity_count

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "name": name,
            "slug": slug,
            "created_at": created_at,
            "updated_at": updated_at,
            "deleted_at": deleted_at,
            "member_count": member_count,
            "entity_count": entity_count,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        name = d.pop("name")

        slug = d.pop("slug")

        def _parse_created_at(data: object) -> datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)



                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | str, data)

        created_at = _parse_created_at(d.pop("created_at"))


        def _parse_updated_at(data: object) -> datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)



                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | str, data)

        updated_at = _parse_updated_at(d.pop("updated_at"))


        def _parse_deleted_at(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                deleted_at_type_0 = isoparse(data)



                return deleted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at"))


        member_count = d.pop("member_count")

        entity_count = d.pop("entity_count")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        get_api_v1_teams_response_200_data_item = cls(
            id=id,
            org_id=org_id,
            name=name,
            slug=slug,
            created_at=created_at,
            updated_at=updated_at,
            deleted_at=deleted_at,
            member_count=member_count,
            entity_count=entity_count,
            description=description,
        )


        get_api_v1_teams_response_200_data_item.additional_properties = d
        return get_api_v1_teams_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
