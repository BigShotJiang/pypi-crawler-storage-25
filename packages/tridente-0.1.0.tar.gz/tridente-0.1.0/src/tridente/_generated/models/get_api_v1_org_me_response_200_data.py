# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_org_me_response_200_data_organization import GetApiV1OrgMeResponse200DataOrganization





T = TypeVar("T", bound="GetApiV1OrgMeResponse200Data")



@_attrs_define
class GetApiV1OrgMeResponse200Data:
    """ 
        Attributes:
            organization (GetApiV1OrgMeResponse200DataOrganization):
            features (list[str]):
     """

    organization: GetApiV1OrgMeResponse200DataOrganization
    features: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_org_me_response_200_data_organization import GetApiV1OrgMeResponse200DataOrganization
        organization = self.organization.to_dict()

        features = self.features




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "organization": organization,
            "features": features,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_org_me_response_200_data_organization import GetApiV1OrgMeResponse200DataOrganization
        d = dict(src_dict)
        organization = GetApiV1OrgMeResponse200DataOrganization.from_dict(d.pop("organization"))




        features = cast(list[str], d.pop("features"))


        get_api_v1_org_me_response_200_data = cls(
            organization=organization,
            features=features,
        )


        get_api_v1_org_me_response_200_data.additional_properties = d
        return get_api_v1_org_me_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
