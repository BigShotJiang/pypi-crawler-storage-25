# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_entities_graph_response_200_data_edges_item import GetApiV1EntitiesGraphResponse200DataEdgesItem
  from ..models.get_api_v1_entities_graph_response_200_data_nodes_item import GetApiV1EntitiesGraphResponse200DataNodesItem





T = TypeVar("T", bound="GetApiV1EntitiesGraphResponse200Data")



@_attrs_define
class GetApiV1EntitiesGraphResponse200Data:
    """ 
        Attributes:
            nodes (list[GetApiV1EntitiesGraphResponse200DataNodesItem]):
            edges (list[GetApiV1EntitiesGraphResponse200DataEdgesItem]):
     """

    nodes: list[GetApiV1EntitiesGraphResponse200DataNodesItem]
    edges: list[GetApiV1EntitiesGraphResponse200DataEdgesItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_entities_graph_response_200_data_edges_item import GetApiV1EntitiesGraphResponse200DataEdgesItem
        from ..models.get_api_v1_entities_graph_response_200_data_nodes_item import GetApiV1EntitiesGraphResponse200DataNodesItem
        nodes = []
        for nodes_item_data in self.nodes:
            nodes_item = nodes_item_data.to_dict()
            nodes.append(nodes_item)



        edges = []
        for edges_item_data in self.edges:
            edges_item = edges_item_data.to_dict()
            edges.append(edges_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "nodes": nodes,
            "edges": edges,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_entities_graph_response_200_data_edges_item import GetApiV1EntitiesGraphResponse200DataEdgesItem
        from ..models.get_api_v1_entities_graph_response_200_data_nodes_item import GetApiV1EntitiesGraphResponse200DataNodesItem
        d = dict(src_dict)
        nodes = []
        _nodes = d.pop("nodes")
        for nodes_item_data in (_nodes):
            nodes_item = GetApiV1EntitiesGraphResponse200DataNodesItem.from_dict(nodes_item_data)



            nodes.append(nodes_item)


        edges = []
        _edges = d.pop("edges")
        for edges_item_data in (_edges):
            edges_item = GetApiV1EntitiesGraphResponse200DataEdgesItem.from_dict(edges_item_data)



            edges.append(edges_item)


        get_api_v1_entities_graph_response_200_data = cls(
            nodes=nodes,
            edges=edges,
        )


        get_api_v1_entities_graph_response_200_data.additional_properties = d
        return get_api_v1_entities_graph_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
