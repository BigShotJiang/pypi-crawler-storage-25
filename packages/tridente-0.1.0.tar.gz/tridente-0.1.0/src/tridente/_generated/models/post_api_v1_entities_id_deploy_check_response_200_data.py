# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem





T = TypeVar("T", bound="PostApiV1EntitiesIdDeployCheckResponse200Data")



@_attrs_define
class PostApiV1EntitiesIdDeployCheckResponse200Data:
    """ 
        Attributes:
            overall_passed (bool):
            error_count (float):
            warning_count (float):
            results (list[PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem]):
     """

    overall_passed: bool
    error_count: float
    warning_count: float
    results: list[PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem
        overall_passed = self.overall_passed

        error_count = self.error_count

        warning_count = self.warning_count

        results = []
        for results_item_data in self.results:
            results_item = results_item_data.to_dict()
            results.append(results_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "overall_passed": overall_passed,
            "error_count": error_count,
            "warning_count": warning_count,
            "results": results,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem
        d = dict(src_dict)
        overall_passed = d.pop("overall_passed")

        error_count = d.pop("error_count")

        warning_count = d.pop("warning_count")

        results = []
        _results = d.pop("results")
        for results_item_data in (_results):
            results_item = PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem.from_dict(results_item_data)



            results.append(results_item)


        post_api_v1_entities_id_deploy_check_response_200_data = cls(
            overall_passed=overall_passed,
            error_count=error_count,
            warning_count=warning_count,
            results=results,
        )


        post_api_v1_entities_id_deploy_check_response_200_data.additional_properties = d
        return post_api_v1_entities_id_deploy_check_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
