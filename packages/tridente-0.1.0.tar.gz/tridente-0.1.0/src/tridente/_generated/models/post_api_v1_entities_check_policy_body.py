# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostApiV1EntitiesCheckPolicyBody")



@_attrs_define
class PostApiV1EntitiesCheckPolicyBody:
    """ 
        Attributes:
            manifest_raw (str):
     """

    manifest_raw: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        manifest_raw = self.manifest_raw


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "manifest_raw": manifest_raw,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        manifest_raw = d.pop("manifest_raw")

        post_api_v1_entities_check_policy_body = cls(
            manifest_raw=manifest_raw,
        )


        post_api_v1_entities_check_policy_body.additional_properties = d
        return post_api_v1_entities_check_policy_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
