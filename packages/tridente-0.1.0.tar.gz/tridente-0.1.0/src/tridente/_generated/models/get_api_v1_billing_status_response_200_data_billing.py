# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="GetApiV1BillingStatusResponse200DataBilling")



@_attrs_define
class GetApiV1BillingStatusResponse200DataBilling:
    """ 
        Attributes:
            stripe_customer_id (None | str | Unset):
            stripe_subscription_id (None | str | Unset):
            stripe_subscription_status (None | str | Unset):
            stripe_checkout_session_id (None | str | Unset):
            current_period_end (None | str | Unset):
            grace_period_ends_at (None | str | Unset):
            last_payment_failed_at (None | str | Unset):
     """

    stripe_customer_id: None | str | Unset = UNSET
    stripe_subscription_id: None | str | Unset = UNSET
    stripe_subscription_status: None | str | Unset = UNSET
    stripe_checkout_session_id: None | str | Unset = UNSET
    current_period_end: None | str | Unset = UNSET
    grace_period_ends_at: None | str | Unset = UNSET
    last_payment_failed_at: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        stripe_customer_id: None | str | Unset
        if isinstance(self.stripe_customer_id, Unset):
            stripe_customer_id = UNSET
        else:
            stripe_customer_id = self.stripe_customer_id

        stripe_subscription_id: None | str | Unset
        if isinstance(self.stripe_subscription_id, Unset):
            stripe_subscription_id = UNSET
        else:
            stripe_subscription_id = self.stripe_subscription_id

        stripe_subscription_status: None | str | Unset
        if isinstance(self.stripe_subscription_status, Unset):
            stripe_subscription_status = UNSET
        else:
            stripe_subscription_status = self.stripe_subscription_status

        stripe_checkout_session_id: None | str | Unset
        if isinstance(self.stripe_checkout_session_id, Unset):
            stripe_checkout_session_id = UNSET
        else:
            stripe_checkout_session_id = self.stripe_checkout_session_id

        current_period_end: None | str | Unset
        if isinstance(self.current_period_end, Unset):
            current_period_end = UNSET
        else:
            current_period_end = self.current_period_end

        grace_period_ends_at: None | str | Unset
        if isinstance(self.grace_period_ends_at, Unset):
            grace_period_ends_at = UNSET
        else:
            grace_period_ends_at = self.grace_period_ends_at

        last_payment_failed_at: None | str | Unset
        if isinstance(self.last_payment_failed_at, Unset):
            last_payment_failed_at = UNSET
        else:
            last_payment_failed_at = self.last_payment_failed_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if stripe_customer_id is not UNSET:
            field_dict["stripeCustomerId"] = stripe_customer_id
        if stripe_subscription_id is not UNSET:
            field_dict["stripeSubscriptionId"] = stripe_subscription_id
        if stripe_subscription_status is not UNSET:
            field_dict["stripeSubscriptionStatus"] = stripe_subscription_status
        if stripe_checkout_session_id is not UNSET:
            field_dict["stripeCheckoutSessionId"] = stripe_checkout_session_id
        if current_period_end is not UNSET:
            field_dict["currentPeriodEnd"] = current_period_end
        if grace_period_ends_at is not UNSET:
            field_dict["gracePeriodEndsAt"] = grace_period_ends_at
        if last_payment_failed_at is not UNSET:
            field_dict["lastPaymentFailedAt"] = last_payment_failed_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_stripe_customer_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_customer_id = _parse_stripe_customer_id(d.pop("stripeCustomerId", UNSET))


        def _parse_stripe_subscription_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_subscription_id = _parse_stripe_subscription_id(d.pop("stripeSubscriptionId", UNSET))


        def _parse_stripe_subscription_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_subscription_status = _parse_stripe_subscription_status(d.pop("stripeSubscriptionStatus", UNSET))


        def _parse_stripe_checkout_session_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_checkout_session_id = _parse_stripe_checkout_session_id(d.pop("stripeCheckoutSessionId", UNSET))


        def _parse_current_period_end(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_period_end = _parse_current_period_end(d.pop("currentPeriodEnd", UNSET))


        def _parse_grace_period_ends_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        grace_period_ends_at = _parse_grace_period_ends_at(d.pop("gracePeriodEndsAt", UNSET))


        def _parse_last_payment_failed_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_payment_failed_at = _parse_last_payment_failed_at(d.pop("lastPaymentFailedAt", UNSET))


        get_api_v1_billing_status_response_200_data_billing = cls(
            stripe_customer_id=stripe_customer_id,
            stripe_subscription_id=stripe_subscription_id,
            stripe_subscription_status=stripe_subscription_status,
            stripe_checkout_session_id=stripe_checkout_session_id,
            current_period_end=current_period_end,
            grace_period_ends_at=grace_period_ends_at,
            last_payment_failed_at=last_payment_failed_at,
        )


        get_api_v1_billing_status_response_200_data_billing.additional_properties = d
        return get_api_v1_billing_status_response_200_data_billing

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
