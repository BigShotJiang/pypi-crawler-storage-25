# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="GetApiV1EntitiesGraphResponse200DataEdgesItem")



@_attrs_define
class GetApiV1EntitiesGraphResponse200DataEdgesItem:
    """ 
        Attributes:
            id (UUID):
            source_id (UUID):
            target_id (UUID):
            type_ (str):
     """

    id: UUID
    source_id: UUID
    target_id: UUID
    type_: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        source_id = str(self.source_id)

        target_id = str(self.target_id)

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "source_id": source_id,
            "target_id": target_id,
            "type": type_,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        source_id = UUID(d.pop("source_id"))




        target_id = UUID(d.pop("target_id"))




        type_ = d.pop("type")

        get_api_v1_entities_graph_response_200_data_edges_item = cls(
            id=id,
            source_id=source_id,
            target_id=target_id,
            type_=type_,
        )


        get_api_v1_entities_graph_response_200_data_edges_item.additional_properties = d
        return get_api_v1_entities_graph_response_200_data_edges_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
