# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1TeamsNameEntitiesMaturity(str, Enum):
    BETA = "beta"
    DEPRECATED = "deprecated"
    EXPERIMENTAL = "experimental"
    PRODUCTION = "production"

    def __str__(self) -> str:
        return str(self.value)
