# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1GovernanceSummaryResponse200Data")



@_attrs_define
class GetApiV1GovernanceSummaryResponse200Data:
    """ 
        Attributes:
            high_risk_count (float):
            failed_count (float):
            pending_approvals_count (float):
     """

    high_risk_count: float
    failed_count: float
    pending_approvals_count: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        high_risk_count = self.high_risk_count

        failed_count = self.failed_count

        pending_approvals_count = self.pending_approvals_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "high_risk_count": high_risk_count,
            "failed_count": failed_count,
            "pending_approvals_count": pending_approvals_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        high_risk_count = d.pop("high_risk_count")

        failed_count = d.pop("failed_count")

        pending_approvals_count = d.pop("pending_approvals_count")

        get_api_v1_governance_summary_response_200_data = cls(
            high_risk_count=high_risk_count,
            failed_count=failed_count,
            pending_approvals_count=pending_approvals_count,
        )


        get_api_v1_governance_summary_response_200_data.additional_properties = d
        return get_api_v1_governance_summary_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
