# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.heartbeat_recorded_data import HeartbeatRecordedData





T = TypeVar("T", bound="HeartbeatRecorded")



@_attrs_define
class HeartbeatRecorded:
    """ 
        Attributes:
            data (HeartbeatRecordedData):
     """

    data: HeartbeatRecordedData
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.heartbeat_recorded_data import HeartbeatRecordedData
        data = self.data.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "data": data,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.heartbeat_recorded_data import HeartbeatRecordedData
        d = dict(src_dict)
        data = HeartbeatRecordedData.from_dict(d.pop("data"))




        heartbeat_recorded = cls(
            data=data,
        )


        heartbeat_recorded.additional_properties = d
        return heartbeat_recorded

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
