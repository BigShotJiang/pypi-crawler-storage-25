# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_api_v1_auth_device_token_response_410_error import PostApiV1AuthDeviceTokenResponse410Error






T = TypeVar("T", bound="PostApiV1AuthDeviceTokenResponse410")



@_attrs_define
class PostApiV1AuthDeviceTokenResponse410:
    """ 
        Attributes:
            error (PostApiV1AuthDeviceTokenResponse410Error):
     """

    error: PostApiV1AuthDeviceTokenResponse410Error
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        error = self.error.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "error": error,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        error = PostApiV1AuthDeviceTokenResponse410Error(d.pop("error"))




        post_api_v1_auth_device_token_response_410 = cls(
            error=error,
        )


        post_api_v1_auth_device_token_response_410.additional_properties = d
        return post_api_v1_auth_device_token_response_410

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
