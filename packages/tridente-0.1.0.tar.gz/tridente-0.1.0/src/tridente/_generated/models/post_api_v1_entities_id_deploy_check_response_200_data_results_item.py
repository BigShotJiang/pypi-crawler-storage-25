# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem





T = TypeVar("T", bound="PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem")



@_attrs_define
class PostApiV1EntitiesIdDeployCheckResponse200DataResultsItem:
    """ 
        Attributes:
            policy_name (str):
            policy_type (str):
            severity (str):
            passed (bool):
            violations (list[PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem]):
     """

    policy_name: str
    policy_type: str
    severity: str
    passed: bool
    violations: list[PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem
        policy_name = self.policy_name

        policy_type = self.policy_type

        severity = self.severity

        passed = self.passed

        violations = []
        for violations_item_data in self.violations:
            violations_item = violations_item_data.to_dict()
            violations.append(violations_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "policy_name": policy_name,
            "policy_type": policy_type,
            "severity": severity,
            "passed": passed,
            "violations": violations,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item import PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem
        d = dict(src_dict)
        policy_name = d.pop("policy_name")

        policy_type = d.pop("policy_type")

        severity = d.pop("severity")

        passed = d.pop("passed")

        violations = []
        _violations = d.pop("violations")
        for violations_item_data in (_violations):
            violations_item = PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem.from_dict(violations_item_data)



            violations.append(violations_item)


        post_api_v1_entities_id_deploy_check_response_200_data_results_item = cls(
            policy_name=policy_name,
            policy_type=policy_type,
            severity=severity,
            passed=passed,
            violations=violations,
        )


        post_api_v1_entities_id_deploy_check_response_200_data_results_item.additional_properties = d
        return post_api_v1_entities_id_deploy_check_response_200_data_results_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
