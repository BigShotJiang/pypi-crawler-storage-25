# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_health_response_200_data_status import GetApiV1HealthResponse200DataStatus






T = TypeVar("T", bound="GetApiV1HealthResponse200Data")



@_attrs_define
class GetApiV1HealthResponse200Data:
    """ 
        Attributes:
            status (GetApiV1HealthResponse200DataStatus):
            version (str):
            timestamp (str):
     """

    status: GetApiV1HealthResponse200DataStatus
    version: str
    timestamp: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        version = self.version

        timestamp = self.timestamp


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "version": version,
            "timestamp": timestamp,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = GetApiV1HealthResponse200DataStatus(d.pop("status"))




        version = d.pop("version")

        timestamp = d.pop("timestamp")

        get_api_v1_health_response_200_data = cls(
            status=status,
            version=version,
            timestamp=timestamp,
        )


        get_api_v1_health_response_200_data.additional_properties = d
        return get_api_v1_health_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
