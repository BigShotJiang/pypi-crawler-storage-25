# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem")



@_attrs_define
class PostApiV1EntitiesIdDeployCheckResponse200DataResultsItemViolationsItem:
    """ 
        Attributes:
            message (str):
            field (str | Unset):
            remediation (str | Unset):
     """

    message: str
    field: str | Unset = UNSET
    remediation: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        message = self.message

        field = self.field

        remediation = self.remediation


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "message": message,
        })
        if field is not UNSET:
            field_dict["field"] = field
        if remediation is not UNSET:
            field_dict["remediation"] = remediation

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        message = d.pop("message")

        field = d.pop("field", UNSET)

        remediation = d.pop("remediation", UNSET)

        post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item = cls(
            message=message,
            field=field,
            remediation=remediation,
        )


        post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item.additional_properties = d
        return post_api_v1_entities_id_deploy_check_response_200_data_results_item_violations_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
