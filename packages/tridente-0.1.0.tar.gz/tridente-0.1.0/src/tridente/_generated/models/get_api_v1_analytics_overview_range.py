# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1AnalyticsOverviewRange(str, Enum):
    ALL = "all"
    QTD = "qtd"
    YTD = "ytd"

    def __str__(self) -> str:
        return str(self.value)
