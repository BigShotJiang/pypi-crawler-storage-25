# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.runtime_status import RuntimeStatus
from uuid import UUID






T = TypeVar("T", bound="HeartbeatRecordedData")



@_attrs_define
class HeartbeatRecordedData:
    """ 
        Attributes:
            entity_id (UUID):
            runtime_status (RuntimeStatus):
            last_heartbeat (str):
     """

    entity_id: UUID
    runtime_status: RuntimeStatus
    last_heartbeat: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        entity_id = str(self.entity_id)

        runtime_status = self.runtime_status.value

        last_heartbeat = self.last_heartbeat


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entity_id": entity_id,
            "runtime_status": runtime_status,
            "last_heartbeat": last_heartbeat,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        entity_id = UUID(d.pop("entity_id"))




        runtime_status = RuntimeStatus(d.pop("runtime_status"))




        last_heartbeat = d.pop("last_heartbeat")

        heartbeat_recorded_data = cls(
            entity_id=entity_id,
            runtime_status=runtime_status,
            last_heartbeat=last_heartbeat,
        )


        heartbeat_recorded_data.additional_properties = d
        return heartbeat_recorded_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
