# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_admin_license_metrics_response_200_data_active_licenses import GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses
  from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon





T = TypeVar("T", bound="GetApiV1AdminLicenseMetricsResponse200Data")



@_attrs_define
class GetApiV1AdminLicenseMetricsResponse200Data:
    """ 
        Attributes:
            mrr_cents (int):
            active_licenses (GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses):
            expiring_soon (GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon):
            total_revenue_cents (int):
            churn_count (int):
     """

    mrr_cents: int
    active_licenses: GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses
    expiring_soon: GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon
    total_revenue_cents: int
    churn_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_admin_license_metrics_response_200_data_active_licenses import GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon
        mrr_cents = self.mrr_cents

        active_licenses = self.active_licenses.to_dict()

        expiring_soon = self.expiring_soon.to_dict()

        total_revenue_cents = self.total_revenue_cents

        churn_count = self.churn_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "mrr_cents": mrr_cents,
            "active_licenses": active_licenses,
            "expiring_soon": expiring_soon,
            "total_revenue_cents": total_revenue_cents,
            "churn_count": churn_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_admin_license_metrics_response_200_data_active_licenses import GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon
        d = dict(src_dict)
        mrr_cents = d.pop("mrr_cents")

        active_licenses = GetApiV1AdminLicenseMetricsResponse200DataActiveLicenses.from_dict(d.pop("active_licenses"))




        expiring_soon = GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon.from_dict(d.pop("expiring_soon"))




        total_revenue_cents = d.pop("total_revenue_cents")

        churn_count = d.pop("churn_count")

        get_api_v1_admin_license_metrics_response_200_data = cls(
            mrr_cents=mrr_cents,
            active_licenses=active_licenses,
            expiring_soon=expiring_soon,
            total_revenue_cents=total_revenue_cents,
            churn_count=churn_count,
        )


        get_api_v1_admin_license_metrics_response_200_data.additional_properties = d
        return get_api_v1_admin_license_metrics_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
