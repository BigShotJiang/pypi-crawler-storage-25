# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_entities_id_governance_response_200_data_results_item_violations_item import GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem





T = TypeVar("T", bound="GetApiV1EntitiesIdGovernanceResponse200DataResultsItem")



@_attrs_define
class GetApiV1EntitiesIdGovernanceResponse200DataResultsItem:
    """ 
        Attributes:
            policy_name (str):
            policy_type (str):
            severity (str):
            passed (bool):
            violations (list[GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem]):
            policy_version (int | None | Unset):
     """

    policy_name: str
    policy_type: str
    severity: str
    passed: bool
    violations: list[GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem]
    policy_version: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_entities_id_governance_response_200_data_results_item_violations_item import GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem
        policy_name = self.policy_name

        policy_type = self.policy_type

        severity = self.severity

        passed = self.passed

        violations = []
        for violations_item_data in self.violations:
            violations_item = violations_item_data.to_dict()
            violations.append(violations_item)



        policy_version: int | None | Unset
        if isinstance(self.policy_version, Unset):
            policy_version = UNSET
        else:
            policy_version = self.policy_version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "policy_name": policy_name,
            "policy_type": policy_type,
            "severity": severity,
            "passed": passed,
            "violations": violations,
        })
        if policy_version is not UNSET:
            field_dict["policy_version"] = policy_version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_entities_id_governance_response_200_data_results_item_violations_item import GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem
        d = dict(src_dict)
        policy_name = d.pop("policy_name")

        policy_type = d.pop("policy_type")

        severity = d.pop("severity")

        passed = d.pop("passed")

        violations = []
        _violations = d.pop("violations")
        for violations_item_data in (_violations):
            violations_item = GetApiV1EntitiesIdGovernanceResponse200DataResultsItemViolationsItem.from_dict(violations_item_data)



            violations.append(violations_item)


        def _parse_policy_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        policy_version = _parse_policy_version(d.pop("policy_version", UNSET))


        get_api_v1_entities_id_governance_response_200_data_results_item = cls(
            policy_name=policy_name,
            policy_type=policy_type,
            severity=severity,
            passed=passed,
            violations=violations,
            policy_version=policy_version,
        )


        get_api_v1_entities_id_governance_response_200_data_results_item.additional_properties = d
        return get_api_v1_entities_id_governance_response_200_data_results_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
