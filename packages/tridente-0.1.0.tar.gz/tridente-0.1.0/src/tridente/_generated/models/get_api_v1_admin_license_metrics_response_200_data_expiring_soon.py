# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_30_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item
  from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item
  from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_90_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item





T = TypeVar("T", bound="GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon")



@_attrs_define
class GetApiV1AdminLicenseMetricsResponse200DataExpiringSoon:
    """ 
        Attributes:
            days_30 (list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item]):
            days_60 (list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item]):
            days_90 (list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item]):
     """

    days_30: list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item]
    days_60: list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item]
    days_90: list[GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_30_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_90_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item
        days_30 = []
        for days_30_item_data in self.days_30:
            days_30_item = days_30_item_data.to_dict()
            days_30.append(days_30_item)



        days_60 = []
        for days_60_item_data in self.days_60:
            days_60_item = days_60_item_data.to_dict()
            days_60.append(days_60_item)



        days_90 = []
        for days_90_item_data in self.days_90:
            days_90_item = days_90_item_data.to_dict()
            days_90.append(days_90_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "days_30": days_30,
            "days_60": days_60,
            "days_90": days_90,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_30_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item
        from ..models.get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_90_item import GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item
        d = dict(src_dict)
        days_30 = []
        _days_30 = d.pop("days_30")
        for days_30_item_data in (_days_30):
            days_30_item = GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays30Item.from_dict(days_30_item_data)



            days_30.append(days_30_item)


        days_60 = []
        _days_60 = d.pop("days_60")
        for days_60_item_data in (_days_60):
            days_60_item = GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item.from_dict(days_60_item_data)



            days_60.append(days_60_item)


        days_90 = []
        _days_90 = d.pop("days_90")
        for days_90_item_data in (_days_90):
            days_90_item = GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays90Item.from_dict(days_90_item_data)



            days_90.append(days_90_item)


        get_api_v1_admin_license_metrics_response_200_data_expiring_soon = cls(
            days_30=days_30,
            days_60=days_60,
            days_90=days_90,
        )


        get_api_v1_admin_license_metrics_response_200_data_expiring_soon.additional_properties = d
        return get_api_v1_admin_license_metrics_response_200_data_expiring_soon

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
