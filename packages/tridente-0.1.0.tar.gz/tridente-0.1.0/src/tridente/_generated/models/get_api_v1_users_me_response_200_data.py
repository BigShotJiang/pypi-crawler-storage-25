# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_users_me_response_200_data_provider import GetApiV1UsersMeResponse200DataProvider
from ..models.get_api_v1_users_me_response_200_data_role import GetApiV1UsersMeResponse200DataRole
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime






T = TypeVar("T", bound="GetApiV1UsersMeResponse200Data")



@_attrs_define
class GetApiV1UsersMeResponse200Data:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            email (str):
            name (None | str):
            team (None | str):
            role (GetApiV1UsersMeResponse200DataRole):
            provider (GetApiV1UsersMeResponse200DataProvider):
            provider_id (None | str):
            created_at (datetime.datetime | str):
            last_login (Any | datetime.datetime | str):
            deleted_at (Any | datetime.datetime | str):
     """

    id: UUID
    org_id: UUID
    email: str
    name: None | str
    team: None | str
    role: GetApiV1UsersMeResponse200DataRole
    provider: GetApiV1UsersMeResponse200DataProvider
    provider_id: None | str
    created_at: datetime.datetime | str
    last_login: Any | datetime.datetime | str
    deleted_at: Any | datetime.datetime | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        org_id = str(self.org_id)

        email = self.email

        name: None | str
        name = self.name

        team: None | str
        team = self.team

        role = self.role.value

        provider = self.provider.value

        provider_id: None | str
        provider_id = self.provider_id

        created_at: str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        last_login: Any | str
        if isinstance(self.last_login, datetime.datetime):
            last_login = self.last_login.isoformat()
        else:
            last_login = self.last_login

        deleted_at: Any | str
        if isinstance(self.deleted_at, datetime.datetime):
            deleted_at = self.deleted_at.isoformat()
        else:
            deleted_at = self.deleted_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "email": email,
            "name": name,
            "team": team,
            "role": role,
            "provider": provider,
            "provider_id": provider_id,
            "created_at": created_at,
            "last_login": last_login,
            "deleted_at": deleted_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        email = d.pop("email")

        def _parse_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        name = _parse_name(d.pop("name"))


        def _parse_team(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        team = _parse_team(d.pop("team"))


        role = GetApiV1UsersMeResponse200DataRole(d.pop("role"))




        provider = GetApiV1UsersMeResponse200DataProvider(d.pop("provider"))




        def _parse_provider_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        provider_id = _parse_provider_id(d.pop("provider_id"))


        def _parse_created_at(data: object) -> datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)



                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | str, data)

        created_at = _parse_created_at(d.pop("created_at"))


        def _parse_last_login(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_login_type_0 = isoparse(data)



                return last_login_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        last_login = _parse_last_login(d.pop("last_login"))


        def _parse_deleted_at(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                deleted_at_type_0 = isoparse(data)



                return deleted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at"))


        get_api_v1_users_me_response_200_data = cls(
            id=id,
            org_id=org_id,
            email=email,
            name=name,
            team=team,
            role=role,
            provider=provider,
            provider_id=provider_id,
            created_at=created_at,
            last_login=last_login,
            deleted_at=deleted_at,
        )


        get_api_v1_users_me_response_200_data.additional_properties = d
        return get_api_v1_users_me_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
