# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1AnalyticsActivityHeatmapResponse200DataItem")



@_attrs_define
class GetApiV1AnalyticsActivityHeatmapResponse200DataItem:
    """ 
        Attributes:
            day_of_week (int):
            hour (int):
            count (int):
     """

    day_of_week: int
    hour: int
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        day_of_week = self.day_of_week

        hour = self.hour

        count = self.count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "day_of_week": day_of_week,
            "hour": hour,
            "count": count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        day_of_week = d.pop("day_of_week")

        hour = d.pop("hour")

        count = d.pop("count")

        get_api_v1_analytics_activity_heatmap_response_200_data_item = cls(
            day_of_week=day_of_week,
            hour=hour,
            count=count,
        )


        get_api_v1_analytics_activity_heatmap_response_200_data_item.additional_properties = d
        return get_api_v1_analytics_activity_heatmap_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
