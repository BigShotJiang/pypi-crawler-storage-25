# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item")



@_attrs_define
class GetApiV1AdminLicenseMetricsResponse200DataExpiringSoonDays60Item:
    """ 
        Attributes:
            org_id (UUID):
            org_name (str):
            expires_at (Any | Unset):
     """

    org_id: UUID
    org_name: str
    expires_at: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        org_id = str(self.org_id)

        org_name = self.org_name

        expires_at = self.expires_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "org_id": org_id,
            "org_name": org_name,
        })
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        org_id = UUID(d.pop("org_id"))




        org_name = d.pop("org_name")

        expires_at = d.pop("expires_at", UNSET)

        get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item = cls(
            org_id=org_id,
            org_name=org_name,
            expires_at=expires_at,
        )


        get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item.additional_properties = d
        return get_api_v1_admin_license_metrics_response_200_data_expiring_soon_days_60_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
