# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.cost_event_provider import CostEventProvider
from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.cost_event_metadata_type_0 import CostEventMetadataType0





T = TypeVar("T", bound="CostEvent")



@_attrs_define
class CostEvent:
    """ 
        Attributes:
            id (UUID):
            provider (CostEventProvider):
            model (str):
            token_count_input (int):
            token_count_output (int):
            compute_cost_usd (float | str):
            currency (str):
            recorded_at (str):
            created_at (str):
            entity_id (None | Unset | UUID):
            metadata (CostEventMetadataType0 | None | Unset):
     """

    id: UUID
    provider: CostEventProvider
    model: str
    token_count_input: int
    token_count_output: int
    compute_cost_usd: float | str
    currency: str
    recorded_at: str
    created_at: str
    entity_id: None | Unset | UUID = UNSET
    metadata: CostEventMetadataType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.cost_event_metadata_type_0 import CostEventMetadataType0
        id = str(self.id)

        provider = self.provider.value

        model = self.model

        token_count_input = self.token_count_input

        token_count_output = self.token_count_output

        compute_cost_usd: float | str
        compute_cost_usd = self.compute_cost_usd

        currency = self.currency

        recorded_at = self.recorded_at

        created_at = self.created_at

        entity_id: None | str | Unset
        if isinstance(self.entity_id, Unset):
            entity_id = UNSET
        elif isinstance(self.entity_id, UUID):
            entity_id = str(self.entity_id)
        else:
            entity_id = self.entity_id

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, CostEventMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "provider": provider,
            "model": model,
            "token_count_input": token_count_input,
            "token_count_output": token_count_output,
            "compute_cost_usd": compute_cost_usd,
            "currency": currency,
            "recorded_at": recorded_at,
            "created_at": created_at,
        })
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.cost_event_metadata_type_0 import CostEventMetadataType0
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        provider = CostEventProvider(d.pop("provider"))




        model = d.pop("model")

        token_count_input = d.pop("token_count_input")

        token_count_output = d.pop("token_count_output")

        def _parse_compute_cost_usd(data: object) -> float | str:
            return cast(float | str, data)

        compute_cost_usd = _parse_compute_cost_usd(d.pop("compute_cost_usd"))


        currency = d.pop("currency")

        recorded_at = d.pop("recorded_at")

        created_at = d.pop("created_at")

        def _parse_entity_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                entity_id_type_0 = UUID(data)



                return entity_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        entity_id = _parse_entity_id(d.pop("entity_id", UNSET))


        def _parse_metadata(data: object) -> CostEventMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = CostEventMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CostEventMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))


        cost_event = cls(
            id=id,
            provider=provider,
            model=model,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            compute_cost_usd=compute_cost_usd,
            currency=currency,
            recorded_at=recorded_at,
            created_at=created_at,
            entity_id=entity_id,
            metadata=metadata,
        )


        cost_event.additional_properties = d
        return cost_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
