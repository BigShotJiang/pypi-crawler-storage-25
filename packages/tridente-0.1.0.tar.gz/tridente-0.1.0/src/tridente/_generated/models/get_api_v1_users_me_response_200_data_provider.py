# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1UsersMeResponse200DataProvider(str, Enum):
    EMAIL = "email"
    GITHUB = "github"
    OIDC = "oidc"

    def __str__(self) -> str:
        return str(self.value)
