# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_billing_status_response_200_data_plan_tier import GetApiV1BillingStatusResponse200DataPlanTier
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.get_api_v1_billing_status_response_200_data_billing import GetApiV1BillingStatusResponse200DataBilling





T = TypeVar("T", bound="GetApiV1BillingStatusResponse200Data")



@_attrs_define
class GetApiV1BillingStatusResponse200Data:
    """ 
        Attributes:
            organization_id (UUID):
            plan_tier (GetApiV1BillingStatusResponse200DataPlanTier):
            configured (bool):
            billing (GetApiV1BillingStatusResponse200DataBilling):
     """

    organization_id: UUID
    plan_tier: GetApiV1BillingStatusResponse200DataPlanTier
    configured: bool
    billing: GetApiV1BillingStatusResponse200DataBilling
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_billing_status_response_200_data_billing import GetApiV1BillingStatusResponse200DataBilling
        organization_id = str(self.organization_id)

        plan_tier = self.plan_tier.value

        configured = self.configured

        billing = self.billing.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "organization_id": organization_id,
            "plan_tier": plan_tier,
            "configured": configured,
            "billing": billing,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_billing_status_response_200_data_billing import GetApiV1BillingStatusResponse200DataBilling
        d = dict(src_dict)
        organization_id = UUID(d.pop("organization_id"))




        plan_tier = GetApiV1BillingStatusResponse200DataPlanTier(d.pop("plan_tier"))




        configured = d.pop("configured")

        billing = GetApiV1BillingStatusResponse200DataBilling.from_dict(d.pop("billing"))




        get_api_v1_billing_status_response_200_data = cls(
            organization_id=organization_id,
            plan_tier=plan_tier,
            configured=configured,
            billing=billing,
        )


        get_api_v1_billing_status_response_200_data.additional_properties = d
        return get_api_v1_billing_status_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
