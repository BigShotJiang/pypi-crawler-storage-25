# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1WebhooksIdDeliveriesResponse200DataItem")



@_attrs_define
class GetApiV1WebhooksIdDeliveriesResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            subscription_id (UUID):
            event_type (str):
            status_code (float | None):
            response_body (None | str):
            attempt (int):
            succeeded (bool):
            payload (Any | Unset):
            delivered_at (Any | Unset):
            next_retry_at (Any | Unset):
     """

    id: UUID
    subscription_id: UUID
    event_type: str
    status_code: float | None
    response_body: None | str
    attempt: int
    succeeded: bool
    payload: Any | Unset = UNSET
    delivered_at: Any | Unset = UNSET
    next_retry_at: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        subscription_id = str(self.subscription_id)

        event_type = self.event_type

        status_code: float | None
        status_code = self.status_code

        response_body: None | str
        response_body = self.response_body

        attempt = self.attempt

        succeeded = self.succeeded

        payload = self.payload

        delivered_at = self.delivered_at

        next_retry_at = self.next_retry_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "subscription_id": subscription_id,
            "event_type": event_type,
            "status_code": status_code,
            "response_body": response_body,
            "attempt": attempt,
            "succeeded": succeeded,
        })
        if payload is not UNSET:
            field_dict["payload"] = payload
        if delivered_at is not UNSET:
            field_dict["delivered_at"] = delivered_at
        if next_retry_at is not UNSET:
            field_dict["next_retry_at"] = next_retry_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        subscription_id = UUID(d.pop("subscription_id"))




        event_type = d.pop("event_type")

        def _parse_status_code(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        status_code = _parse_status_code(d.pop("status_code"))


        def _parse_response_body(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        response_body = _parse_response_body(d.pop("response_body"))


        attempt = d.pop("attempt")

        succeeded = d.pop("succeeded")

        payload = d.pop("payload", UNSET)

        delivered_at = d.pop("delivered_at", UNSET)

        next_retry_at = d.pop("next_retry_at", UNSET)

        get_api_v1_webhooks_id_deliveries_response_200_data_item = cls(
            id=id,
            subscription_id=subscription_id,
            event_type=event_type,
            status_code=status_code,
            response_body=response_body,
            attempt=attempt,
            succeeded=succeeded,
            payload=payload,
            delivered_at=delivered_at,
            next_retry_at=next_retry_at,
        )


        get_api_v1_webhooks_id_deliveries_response_200_data_item.additional_properties = d
        return get_api_v1_webhooks_id_deliveries_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
