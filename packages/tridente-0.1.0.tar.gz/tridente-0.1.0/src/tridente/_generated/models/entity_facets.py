# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.entity_facets_kind import EntityFacetsKind
  from ..models.entity_facets_maturity import EntityFacetsMaturity
  from ..models.entity_facets_owner_team import EntityFacetsOwnerTeam
  from ..models.entity_facets_risk_level import EntityFacetsRiskLevel
  from ..models.entity_facets_runtime_status import EntityFacetsRuntimeStatus





T = TypeVar("T", bound="EntityFacets")



@_attrs_define
class EntityFacets:
    """ 
        Attributes:
            kind (EntityFacetsKind):
            maturity (EntityFacetsMaturity):
            risk_level (EntityFacetsRiskLevel):
            runtime_status (EntityFacetsRuntimeStatus):
            owner_team (EntityFacetsOwnerTeam):
     """

    kind: EntityFacetsKind
    maturity: EntityFacetsMaturity
    risk_level: EntityFacetsRiskLevel
    runtime_status: EntityFacetsRuntimeStatus
    owner_team: EntityFacetsOwnerTeam
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.entity_facets_kind import EntityFacetsKind
        from ..models.entity_facets_maturity import EntityFacetsMaturity
        from ..models.entity_facets_owner_team import EntityFacetsOwnerTeam
        from ..models.entity_facets_risk_level import EntityFacetsRiskLevel
        from ..models.entity_facets_runtime_status import EntityFacetsRuntimeStatus
        kind = self.kind.to_dict()

        maturity = self.maturity.to_dict()

        risk_level = self.risk_level.to_dict()

        runtime_status = self.runtime_status.to_dict()

        owner_team = self.owner_team.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "kind": kind,
            "maturity": maturity,
            "risk_level": risk_level,
            "runtime_status": runtime_status,
            "owner_team": owner_team,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.entity_facets_kind import EntityFacetsKind
        from ..models.entity_facets_maturity import EntityFacetsMaturity
        from ..models.entity_facets_owner_team import EntityFacetsOwnerTeam
        from ..models.entity_facets_risk_level import EntityFacetsRiskLevel
        from ..models.entity_facets_runtime_status import EntityFacetsRuntimeStatus
        d = dict(src_dict)
        kind = EntityFacetsKind.from_dict(d.pop("kind"))




        maturity = EntityFacetsMaturity.from_dict(d.pop("maturity"))




        risk_level = EntityFacetsRiskLevel.from_dict(d.pop("risk_level"))




        runtime_status = EntityFacetsRuntimeStatus.from_dict(d.pop("runtime_status"))




        owner_team = EntityFacetsOwnerTeam.from_dict(d.pop("owner_team"))




        entity_facets = cls(
            kind=kind,
            maturity=maturity,
            risk_level=risk_level,
            runtime_status=runtime_status,
            owner_team=owner_team,
        )


        entity_facets.additional_properties = d
        return entity_facets

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
