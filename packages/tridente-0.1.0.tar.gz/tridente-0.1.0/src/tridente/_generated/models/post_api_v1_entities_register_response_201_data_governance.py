# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="PostApiV1EntitiesRegisterResponse201DataGovernance")



@_attrs_define
class PostApiV1EntitiesRegisterResponse201DataGovernance:
    """ 
        Attributes:
            overall_passed (bool):
            error_count (float):
            warning_count (float):
            results (list[Any]):
     """

    overall_passed: bool
    error_count: float
    warning_count: float
    results: list[Any]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        overall_passed = self.overall_passed

        error_count = self.error_count

        warning_count = self.warning_count

        results = self.results




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "overall_passed": overall_passed,
            "error_count": error_count,
            "warning_count": warning_count,
            "results": results,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        overall_passed = d.pop("overall_passed")

        error_count = d.pop("error_count")

        warning_count = d.pop("warning_count")

        results = cast(list[Any], d.pop("results"))


        post_api_v1_entities_register_response_201_data_governance = cls(
            overall_passed=overall_passed,
            error_count=error_count,
            warning_count=warning_count,
            results=results,
        )


        post_api_v1_entities_register_response_201_data_governance.additional_properties = d
        return post_api_v1_entities_register_response_201_data_governance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
