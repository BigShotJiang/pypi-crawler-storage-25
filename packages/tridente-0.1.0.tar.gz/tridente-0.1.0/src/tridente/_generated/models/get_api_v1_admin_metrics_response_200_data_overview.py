# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1AdminMetricsResponse200DataOverview")



@_attrs_define
class GetApiV1AdminMetricsResponse200DataOverview:
    """ 
        Attributes:
            total_orgs (int):
            total_users (int):
            total_entities (int):
            total_teams (int):
            total_reuse_events (int):
            total_cost_events (int):
            growth_rate_pct (float):
     """

    total_orgs: int
    total_users: int
    total_entities: int
    total_teams: int
    total_reuse_events: int
    total_cost_events: int
    growth_rate_pct: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        total_orgs = self.total_orgs

        total_users = self.total_users

        total_entities = self.total_entities

        total_teams = self.total_teams

        total_reuse_events = self.total_reuse_events

        total_cost_events = self.total_cost_events

        growth_rate_pct = self.growth_rate_pct


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "total_orgs": total_orgs,
            "total_users": total_users,
            "total_entities": total_entities,
            "total_teams": total_teams,
            "total_reuse_events": total_reuse_events,
            "total_cost_events": total_cost_events,
            "growth_rate_pct": growth_rate_pct,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_orgs = d.pop("total_orgs")

        total_users = d.pop("total_users")

        total_entities = d.pop("total_entities")

        total_teams = d.pop("total_teams")

        total_reuse_events = d.pop("total_reuse_events")

        total_cost_events = d.pop("total_cost_events")

        growth_rate_pct = d.pop("growth_rate_pct")

        get_api_v1_admin_metrics_response_200_data_overview = cls(
            total_orgs=total_orgs,
            total_users=total_users,
            total_entities=total_entities,
            total_teams=total_teams,
            total_reuse_events=total_reuse_events,
            total_cost_events=total_cost_events,
            growth_rate_pct=growth_rate_pct,
        )


        get_api_v1_admin_metrics_response_200_data_overview.additional_properties = d
        return get_api_v1_admin_metrics_response_200_data_overview

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
