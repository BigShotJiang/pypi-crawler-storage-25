# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="GetApiV1AnalyticsDuplicationReportResponse200DataItem")



@_attrs_define
class GetApiV1AnalyticsDuplicationReportResponse200DataItem:
    """ 
        Attributes:
            policy_name (str):
            entity_id (UUID):
            entity_name (str):
            entity_namespace (str):
            entity_kind (str):
            owner_team (str):
            violations (Any | Unset):
     """

    policy_name: str
    entity_id: UUID
    entity_name: str
    entity_namespace: str
    entity_kind: str
    owner_team: str
    violations: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        policy_name = self.policy_name

        entity_id = str(self.entity_id)

        entity_name = self.entity_name

        entity_namespace = self.entity_namespace

        entity_kind = self.entity_kind

        owner_team = self.owner_team

        violations = self.violations


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "policy_name": policy_name,
            "entity_id": entity_id,
            "entity_name": entity_name,
            "entity_namespace": entity_namespace,
            "entity_kind": entity_kind,
            "owner_team": owner_team,
        })
        if violations is not UNSET:
            field_dict["violations"] = violations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        policy_name = d.pop("policy_name")

        entity_id = UUID(d.pop("entity_id"))




        entity_name = d.pop("entity_name")

        entity_namespace = d.pop("entity_namespace")

        entity_kind = d.pop("entity_kind")

        owner_team = d.pop("owner_team")

        violations = d.pop("violations", UNSET)

        get_api_v1_analytics_duplication_report_response_200_data_item = cls(
            policy_name=policy_name,
            entity_id=entity_id,
            entity_name=entity_name,
            entity_namespace=entity_namespace,
            entity_kind=entity_kind,
            owner_team=owner_team,
            violations=violations,
        )


        get_api_v1_analytics_duplication_report_response_200_data_item.additional_properties = d
        return get_api_v1_analytics_duplication_report_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
