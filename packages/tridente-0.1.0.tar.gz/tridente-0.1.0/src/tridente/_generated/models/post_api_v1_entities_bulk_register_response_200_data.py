# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_api_v1_entities_bulk_register_response_200_data_failed_item import PostApiV1EntitiesBulkRegisterResponse200DataFailedItem
  from ..models.post_api_v1_entities_bulk_register_response_200_data_succeeded_item import PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem





T = TypeVar("T", bound="PostApiV1EntitiesBulkRegisterResponse200Data")



@_attrs_define
class PostApiV1EntitiesBulkRegisterResponse200Data:
    """ 
        Attributes:
            succeeded (list[PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem]):
            failed (list[PostApiV1EntitiesBulkRegisterResponse200DataFailedItem]):
     """

    succeeded: list[PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem]
    failed: list[PostApiV1EntitiesBulkRegisterResponse200DataFailedItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_api_v1_entities_bulk_register_response_200_data_failed_item import PostApiV1EntitiesBulkRegisterResponse200DataFailedItem
        from ..models.post_api_v1_entities_bulk_register_response_200_data_succeeded_item import PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem
        succeeded = []
        for succeeded_item_data in self.succeeded:
            succeeded_item = succeeded_item_data.to_dict()
            succeeded.append(succeeded_item)



        failed = []
        for failed_item_data in self.failed:
            failed_item = failed_item_data.to_dict()
            failed.append(failed_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "succeeded": succeeded,
            "failed": failed,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_api_v1_entities_bulk_register_response_200_data_failed_item import PostApiV1EntitiesBulkRegisterResponse200DataFailedItem
        from ..models.post_api_v1_entities_bulk_register_response_200_data_succeeded_item import PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem
        d = dict(src_dict)
        succeeded = []
        _succeeded = d.pop("succeeded")
        for succeeded_item_data in (_succeeded):
            succeeded_item = PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem.from_dict(succeeded_item_data)



            succeeded.append(succeeded_item)


        failed = []
        _failed = d.pop("failed")
        for failed_item_data in (_failed):
            failed_item = PostApiV1EntitiesBulkRegisterResponse200DataFailedItem.from_dict(failed_item_data)



            failed.append(failed_item)


        post_api_v1_entities_bulk_register_response_200_data = cls(
            succeeded=succeeded,
            failed=failed,
        )


        post_api_v1_entities_bulk_register_response_200_data.additional_properties = d
        return post_api_v1_entities_bulk_register_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
