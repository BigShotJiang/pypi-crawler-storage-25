# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_org_quotas_response_200_data_api_keys import GetApiV1OrgQuotasResponse200DataApiKeys
  from ..models.get_api_v1_org_quotas_response_200_data_entities import GetApiV1OrgQuotasResponse200DataEntities
  from ..models.get_api_v1_org_quotas_response_200_data_teams import GetApiV1OrgQuotasResponse200DataTeams
  from ..models.get_api_v1_org_quotas_response_200_data_users import GetApiV1OrgQuotasResponse200DataUsers





T = TypeVar("T", bound="GetApiV1OrgQuotasResponse200Data")



@_attrs_define
class GetApiV1OrgQuotasResponse200Data:
    """ 
        Attributes:
            entities (GetApiV1OrgQuotasResponse200DataEntities):
            users (GetApiV1OrgQuotasResponse200DataUsers):
            teams (GetApiV1OrgQuotasResponse200DataTeams):
            api_keys (GetApiV1OrgQuotasResponse200DataApiKeys):
            tier (str):
     """

    entities: GetApiV1OrgQuotasResponse200DataEntities
    users: GetApiV1OrgQuotasResponse200DataUsers
    teams: GetApiV1OrgQuotasResponse200DataTeams
    api_keys: GetApiV1OrgQuotasResponse200DataApiKeys
    tier: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_org_quotas_response_200_data_api_keys import GetApiV1OrgQuotasResponse200DataApiKeys
        from ..models.get_api_v1_org_quotas_response_200_data_entities import GetApiV1OrgQuotasResponse200DataEntities
        from ..models.get_api_v1_org_quotas_response_200_data_teams import GetApiV1OrgQuotasResponse200DataTeams
        from ..models.get_api_v1_org_quotas_response_200_data_users import GetApiV1OrgQuotasResponse200DataUsers
        entities = self.entities.to_dict()

        users = self.users.to_dict()

        teams = self.teams.to_dict()

        api_keys = self.api_keys.to_dict()

        tier = self.tier


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entities": entities,
            "users": users,
            "teams": teams,
            "api_keys": api_keys,
            "tier": tier,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_org_quotas_response_200_data_api_keys import GetApiV1OrgQuotasResponse200DataApiKeys
        from ..models.get_api_v1_org_quotas_response_200_data_entities import GetApiV1OrgQuotasResponse200DataEntities
        from ..models.get_api_v1_org_quotas_response_200_data_teams import GetApiV1OrgQuotasResponse200DataTeams
        from ..models.get_api_v1_org_quotas_response_200_data_users import GetApiV1OrgQuotasResponse200DataUsers
        d = dict(src_dict)
        entities = GetApiV1OrgQuotasResponse200DataEntities.from_dict(d.pop("entities"))




        users = GetApiV1OrgQuotasResponse200DataUsers.from_dict(d.pop("users"))




        teams = GetApiV1OrgQuotasResponse200DataTeams.from_dict(d.pop("teams"))




        api_keys = GetApiV1OrgQuotasResponse200DataApiKeys.from_dict(d.pop("api_keys"))




        tier = d.pop("tier")

        get_api_v1_org_quotas_response_200_data = cls(
            entities=entities,
            users=users,
            teams=teams,
            api_keys=api_keys,
            tier=tier,
        )


        get_api_v1_org_quotas_response_200_data.additional_properties = d
        return get_api_v1_org_quotas_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
