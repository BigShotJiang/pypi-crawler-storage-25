# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1AdminLicensesResponse200DataItem")



@_attrs_define
class GetApiV1AdminLicensesResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            org_name (str):
            plan_tier (str):
            license_key_hash (str):
            monthly_price_cents (int):
            notes (None | str):
            issued_at (Any | Unset):
            expires_at (Any | Unset):
            revoked_at (Any | Unset):
     """

    id: UUID
    org_id: UUID
    org_name: str
    plan_tier: str
    license_key_hash: str
    monthly_price_cents: int
    notes: None | str
    issued_at: Any | Unset = UNSET
    expires_at: Any | Unset = UNSET
    revoked_at: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        org_id = str(self.org_id)

        org_name = self.org_name

        plan_tier = self.plan_tier

        license_key_hash = self.license_key_hash

        monthly_price_cents = self.monthly_price_cents

        notes: None | str
        notes = self.notes

        issued_at = self.issued_at

        expires_at = self.expires_at

        revoked_at = self.revoked_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "org_name": org_name,
            "plan_tier": plan_tier,
            "license_key_hash": license_key_hash,
            "monthly_price_cents": monthly_price_cents,
            "notes": notes,
        })
        if issued_at is not UNSET:
            field_dict["issued_at"] = issued_at
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if revoked_at is not UNSET:
            field_dict["revoked_at"] = revoked_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        org_name = d.pop("org_name")

        plan_tier = d.pop("plan_tier")

        license_key_hash = d.pop("license_key_hash")

        monthly_price_cents = d.pop("monthly_price_cents")

        def _parse_notes(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        notes = _parse_notes(d.pop("notes"))


        issued_at = d.pop("issued_at", UNSET)

        expires_at = d.pop("expires_at", UNSET)

        revoked_at = d.pop("revoked_at", UNSET)

        get_api_v1_admin_licenses_response_200_data_item = cls(
            id=id,
            org_id=org_id,
            org_name=org_name,
            plan_tier=plan_tier,
            license_key_hash=license_key_hash,
            monthly_price_cents=monthly_price_cents,
            notes=notes,
            issued_at=issued_at,
            expires_at=expires_at,
            revoked_at=revoked_at,
        )


        get_api_v1_admin_licenses_response_200_data_item.additional_properties = d
        return get_api_v1_admin_licenses_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
