# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem")



@_attrs_define
class PostApiV1EntitiesBulkRegisterResponse200DataSucceededItem:
    """ 
        Attributes:
            index (int):
            entity_id (UUID):
            name (str):
     """

    index: int
    entity_id: UUID
    name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        index = self.index

        entity_id = str(self.entity_id)

        name = self.name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "index": index,
            "entity_id": entity_id,
            "name": name,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        index = d.pop("index")

        entity_id = UUID(d.pop("entity_id"))




        name = d.pop("name")

        post_api_v1_entities_bulk_register_response_200_data_succeeded_item = cls(
            index=index,
            entity_id=entity_id,
            name=name,
        )


        post_api_v1_entities_bulk_register_response_200_data_succeeded_item.additional_properties = d
        return post_api_v1_entities_bulk_register_response_200_data_succeeded_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
