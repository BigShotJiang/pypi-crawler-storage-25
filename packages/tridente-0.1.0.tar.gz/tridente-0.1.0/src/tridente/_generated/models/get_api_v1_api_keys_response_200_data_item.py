# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_api_keys_response_200_data_item_scopes_item import GetApiV1ApiKeysResponse200DataItemScopesItem
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime






T = TypeVar("T", bound="GetApiV1ApiKeysResponse200DataItem")



@_attrs_define
class GetApiV1ApiKeysResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            name (str):
            prefix (str):
            scopes (list[GetApiV1ApiKeysResponse200DataItemScopesItem]):
            last_used_at (Any | datetime.datetime | str):
            expires_at (Any | datetime.datetime | str):
            created_at (datetime.datetime | str):
            revoked_at (Any | datetime.datetime | str):
     """

    id: UUID
    name: str
    prefix: str
    scopes: list[GetApiV1ApiKeysResponse200DataItemScopesItem]
    last_used_at: Any | datetime.datetime | str
    expires_at: Any | datetime.datetime | str
    created_at: datetime.datetime | str
    revoked_at: Any | datetime.datetime | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        name = self.name

        prefix = self.prefix

        scopes = []
        for scopes_item_data in self.scopes:
            scopes_item = scopes_item_data.value
            scopes.append(scopes_item)



        last_used_at: Any | str
        if isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        expires_at: Any | str
        if isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        created_at: str
        if isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        revoked_at: Any | str
        if isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "prefix": prefix,
            "scopes": scopes,
            "last_used_at": last_used_at,
            "expires_at": expires_at,
            "created_at": created_at,
            "revoked_at": revoked_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        name = d.pop("name")

        prefix = d.pop("prefix")

        scopes = []
        _scopes = d.pop("scopes")
        for scopes_item_data in (_scopes):
            scopes_item = GetApiV1ApiKeysResponse200DataItemScopesItem(scopes_item_data)



            scopes.append(scopes_item)


        def _parse_last_used_at(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)



                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))


        def _parse_expires_at(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)



                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        expires_at = _parse_expires_at(d.pop("expires_at"))


        def _parse_created_at(data: object) -> datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)



                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | str, data)

        created_at = _parse_created_at(d.pop("created_at"))


        def _parse_revoked_at(data: object) -> Any | datetime.datetime | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)



                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | datetime.datetime | str, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at"))


        get_api_v1_api_keys_response_200_data_item = cls(
            id=id,
            name=name,
            prefix=prefix,
            scopes=scopes,
            last_used_at=last_used_at,
            expires_at=expires_at,
            created_at=created_at,
            revoked_at=revoked_at,
        )


        get_api_v1_api_keys_response_200_data_item.additional_properties = d
        return get_api_v1_api_keys_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
