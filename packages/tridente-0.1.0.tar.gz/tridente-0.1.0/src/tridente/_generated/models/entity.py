# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.runtime_status import RuntimeStatus
from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="Entity")



@_attrs_define
class Entity:
    """ 
        Attributes:
            id (UUID):
            kind (str):
            name (str):
            namespace (str):
            display_name (None | str):
            description (str):
            owner_team (str):
            maturity (str):
            risk_level (str):
            version (str):
            tags (list[str]):
            manifest_raw (None | str):
            last_verified (None | str):
            runtime_status (RuntimeStatus):
            last_heartbeat (None | str):
            created_by (None | str):
            labels (Any | Unset):
            annotations (Any | Unset):
            spec (Any | Unset):
            created_at (Any | Unset):
            updated_at (Any | Unset):
            deleted_at (Any | Unset):
     """

    id: UUID
    kind: str
    name: str
    namespace: str
    display_name: None | str
    description: str
    owner_team: str
    maturity: str
    risk_level: str
    version: str
    tags: list[str]
    manifest_raw: None | str
    last_verified: None | str
    runtime_status: RuntimeStatus
    last_heartbeat: None | str
    created_by: None | str
    labels: Any | Unset = UNSET
    annotations: Any | Unset = UNSET
    spec: Any | Unset = UNSET
    created_at: Any | Unset = UNSET
    updated_at: Any | Unset = UNSET
    deleted_at: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        kind = self.kind

        name = self.name

        namespace = self.namespace

        display_name: None | str
        display_name = self.display_name

        description = self.description

        owner_team = self.owner_team

        maturity = self.maturity

        risk_level = self.risk_level

        version = self.version

        tags = self.tags



        manifest_raw: None | str
        manifest_raw = self.manifest_raw

        last_verified: None | str
        last_verified = self.last_verified

        runtime_status = self.runtime_status.value

        last_heartbeat: None | str
        last_heartbeat = self.last_heartbeat

        created_by: None | str
        created_by = self.created_by

        labels = self.labels

        annotations = self.annotations

        spec = self.spec

        created_at = self.created_at

        updated_at = self.updated_at

        deleted_at = self.deleted_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "kind": kind,
            "name": name,
            "namespace": namespace,
            "display_name": display_name,
            "description": description,
            "owner_team": owner_team,
            "maturity": maturity,
            "risk_level": risk_level,
            "version": version,
            "tags": tags,
            "manifest_raw": manifest_raw,
            "last_verified": last_verified,
            "runtime_status": runtime_status,
            "last_heartbeat": last_heartbeat,
            "created_by": created_by,
        })
        if labels is not UNSET:
            field_dict["labels"] = labels
        if annotations is not UNSET:
            field_dict["annotations"] = annotations
        if spec is not UNSET:
            field_dict["spec"] = spec
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if deleted_at is not UNSET:
            field_dict["deleted_at"] = deleted_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        kind = d.pop("kind")

        name = d.pop("name")

        namespace = d.pop("namespace")

        def _parse_display_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        display_name = _parse_display_name(d.pop("display_name"))


        description = d.pop("description")

        owner_team = d.pop("owner_team")

        maturity = d.pop("maturity")

        risk_level = d.pop("risk_level")

        version = d.pop("version")

        tags = cast(list[str], d.pop("tags"))


        def _parse_manifest_raw(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        manifest_raw = _parse_manifest_raw(d.pop("manifest_raw"))


        def _parse_last_verified(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_verified = _parse_last_verified(d.pop("last_verified"))


        runtime_status = RuntimeStatus(d.pop("runtime_status"))




        def _parse_last_heartbeat(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_heartbeat = _parse_last_heartbeat(d.pop("last_heartbeat"))


        def _parse_created_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        created_by = _parse_created_by(d.pop("created_by"))


        labels = d.pop("labels", UNSET)

        annotations = d.pop("annotations", UNSET)

        spec = d.pop("spec", UNSET)

        created_at = d.pop("created_at", UNSET)

        updated_at = d.pop("updated_at", UNSET)

        deleted_at = d.pop("deleted_at", UNSET)

        entity = cls(
            id=id,
            kind=kind,
            name=name,
            namespace=namespace,
            display_name=display_name,
            description=description,
            owner_team=owner_team,
            maturity=maturity,
            risk_level=risk_level,
            version=version,
            tags=tags,
            manifest_raw=manifest_raw,
            last_verified=last_verified,
            runtime_status=runtime_status,
            last_heartbeat=last_heartbeat,
            created_by=created_by,
            labels=labels,
            annotations=annotations,
            spec=spec,
            created_at=created_at,
            updated_at=updated_at,
            deleted_at=deleted_at,
        )


        entity.additional_properties = d
        return entity

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
