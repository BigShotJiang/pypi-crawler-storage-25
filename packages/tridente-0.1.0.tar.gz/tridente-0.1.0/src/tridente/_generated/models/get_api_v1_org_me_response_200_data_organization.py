# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_org_me_response_200_data_organization_plan_tier import GetApiV1OrgMeResponse200DataOrganizationPlanTier
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.get_api_v1_org_me_response_200_data_organization_settings import GetApiV1OrgMeResponse200DataOrganizationSettings





T = TypeVar("T", bound="GetApiV1OrgMeResponse200DataOrganization")



@_attrs_define
class GetApiV1OrgMeResponse200DataOrganization:
    """ 
        Attributes:
            id (UUID):
            name (str):
            slug (str):
            plan_tier (GetApiV1OrgMeResponse200DataOrganizationPlanTier):
            settings (GetApiV1OrgMeResponse200DataOrganizationSettings):
            created_at (str):
            updated_at (str):
     """

    id: UUID
    name: str
    slug: str
    plan_tier: GetApiV1OrgMeResponse200DataOrganizationPlanTier
    settings: GetApiV1OrgMeResponse200DataOrganizationSettings
    created_at: str
    updated_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_org_me_response_200_data_organization_settings import GetApiV1OrgMeResponse200DataOrganizationSettings
        id = str(self.id)

        name = self.name

        slug = self.slug

        plan_tier = self.plan_tier.value

        settings = self.settings.to_dict()

        created_at = self.created_at

        updated_at = self.updated_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "slug": slug,
            "plan_tier": plan_tier,
            "settings": settings,
            "created_at": created_at,
            "updated_at": updated_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_org_me_response_200_data_organization_settings import GetApiV1OrgMeResponse200DataOrganizationSettings
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        name = d.pop("name")

        slug = d.pop("slug")

        plan_tier = GetApiV1OrgMeResponse200DataOrganizationPlanTier(d.pop("plan_tier"))




        settings = GetApiV1OrgMeResponse200DataOrganizationSettings.from_dict(d.pop("settings"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        get_api_v1_org_me_response_200_data_organization = cls(
            id=id,
            name=name,
            slug=slug,
            plan_tier=plan_tier,
            settings=settings,
            created_at=created_at,
            updated_at=updated_at,
        )


        get_api_v1_org_me_response_200_data_organization.additional_properties = d
        return get_api_v1_org_me_response_200_data_organization

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
