# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="HeartbeatMetadata")



@_attrs_define
class HeartbeatMetadata:
    """ 
        Attributes:
            uptime_seconds (int | Unset):
            last_error (str | Unset):
            version (str | Unset):
     """

    uptime_seconds: int | Unset = UNSET
    last_error: str | Unset = UNSET
    version: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        uptime_seconds = self.uptime_seconds

        last_error = self.last_error

        version = self.version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if uptime_seconds is not UNSET:
            field_dict["uptime_seconds"] = uptime_seconds
        if last_error is not UNSET:
            field_dict["last_error"] = last_error
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uptime_seconds = d.pop("uptime_seconds", UNSET)

        last_error = d.pop("last_error", UNSET)

        version = d.pop("version", UNSET)

        heartbeat_metadata = cls(
            uptime_seconds=uptime_seconds,
            last_error=last_error,
            version=version,
        )


        heartbeat_metadata.additional_properties = d
        return heartbeat_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
