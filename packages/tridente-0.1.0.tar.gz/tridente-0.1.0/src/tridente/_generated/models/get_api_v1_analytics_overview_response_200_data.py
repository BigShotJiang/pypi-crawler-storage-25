# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1AnalyticsOverviewResponse200Data")



@_attrs_define
class GetApiV1AnalyticsOverviewResponse200Data:
    """ 
        Attributes:
            total_entities (float):
            total_cost_usd (float):
            avg_cost_per_agent (float):
            adoption_pct (float):
            estimated_time_saved_hrs (float):
     """

    total_entities: float
    total_cost_usd: float
    avg_cost_per_agent: float
    adoption_pct: float
    estimated_time_saved_hrs: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        total_entities = self.total_entities

        total_cost_usd = self.total_cost_usd

        avg_cost_per_agent = self.avg_cost_per_agent

        adoption_pct = self.adoption_pct

        estimated_time_saved_hrs = self.estimated_time_saved_hrs


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "total_entities": total_entities,
            "total_cost_usd": total_cost_usd,
            "avg_cost_per_agent": avg_cost_per_agent,
            "adoption_pct": adoption_pct,
            "estimated_time_saved_hrs": estimated_time_saved_hrs,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_entities = d.pop("total_entities")

        total_cost_usd = d.pop("total_cost_usd")

        avg_cost_per_agent = d.pop("avg_cost_per_agent")

        adoption_pct = d.pop("adoption_pct")

        estimated_time_saved_hrs = d.pop("estimated_time_saved_hrs")

        get_api_v1_analytics_overview_response_200_data = cls(
            total_entities=total_entities,
            total_cost_usd=total_cost_usd,
            avg_cost_per_agent=avg_cost_per_agent,
            adoption_pct=adoption_pct,
            estimated_time_saved_hrs=estimated_time_saved_hrs,
        )


        get_api_v1_analytics_overview_response_200_data.additional_properties = d
        return get_api_v1_analytics_overview_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
