# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1GovernancePoliciesResponse200DataItem")



@_attrs_define
class GetApiV1GovernancePoliciesResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            name (str):
            description (None | str):
            type_ (str):
            severity (str):
            enabled (bool):
            created_at (str):
            updated_at (str):
     """

    id: UUID
    name: str
    description: None | str
    type_: str
    severity: str
    enabled: bool
    created_at: str
    updated_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        name = self.name

        description: None | str
        description = self.description

        type_ = self.type_

        severity = self.severity

        enabled = self.enabled

        created_at = self.created_at

        updated_at = self.updated_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "description": description,
            "type": type_,
            "severity": severity,
            "enabled": enabled,
            "created_at": created_at,
            "updated_at": updated_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        name = d.pop("name")

        def _parse_description(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        description = _parse_description(d.pop("description"))


        type_ = d.pop("type")

        severity = d.pop("severity")

        enabled = d.pop("enabled")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        get_api_v1_governance_policies_response_200_data_item = cls(
            id=id,
            name=name,
            description=description,
            type_=type_,
            severity=severity,
            enabled=enabled,
            created_at=created_at,
            updated_at=updated_at,
        )


        get_api_v1_governance_policies_response_200_data_item.additional_properties = d
        return get_api_v1_governance_policies_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
