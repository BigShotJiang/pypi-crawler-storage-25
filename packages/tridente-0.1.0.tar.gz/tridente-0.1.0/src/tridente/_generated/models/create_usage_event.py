# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.usage_event_type import UsageEventType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_usage_event_metadata import CreateUsageEventMetadata





T = TypeVar("T", bound="CreateUsageEvent")



@_attrs_define
class CreateUsageEvent:
    """ 
        Attributes:
            event_type (UsageEventType):
            user_id (str | Unset):
            team (str | Unset):
            metadata (CreateUsageEventMetadata | Unset):
     """

    event_type: UsageEventType
    user_id: str | Unset = UNSET
    team: str | Unset = UNSET
    metadata: CreateUsageEventMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_usage_event_metadata import CreateUsageEventMetadata
        event_type = self.event_type.value

        user_id = self.user_id

        team = self.team

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "event_type": event_type,
        })
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if team is not UNSET:
            field_dict["team"] = team
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_usage_event_metadata import CreateUsageEventMetadata
        d = dict(src_dict)
        event_type = UsageEventType(d.pop("event_type"))




        user_id = d.pop("user_id", UNSET)

        team = d.pop("team", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: CreateUsageEventMetadata | Unset
        if isinstance(_metadata,  Unset):
            metadata = UNSET
        else:
            metadata = CreateUsageEventMetadata.from_dict(_metadata)




        create_usage_event = cls(
            event_type=event_type,
            user_id=user_id,
            team=team,
            metadata=metadata,
        )


        create_usage_event.additional_properties = d
        return create_usage_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
