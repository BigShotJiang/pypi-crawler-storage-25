# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_api_v1_entities_id_stats_response_200_data_by_event_type import GetApiV1EntitiesIdStatsResponse200DataByEventType
  from ..models.get_api_v1_entities_id_stats_response_200_data_by_team import GetApiV1EntitiesIdStatsResponse200DataByTeam





T = TypeVar("T", bound="GetApiV1EntitiesIdStatsResponse200Data")



@_attrs_define
class GetApiV1EntitiesIdStatsResponse200Data:
    """ 
        Attributes:
            total_events (int):
            by_event_type (GetApiV1EntitiesIdStatsResponse200DataByEventType):
            by_team (GetApiV1EntitiesIdStatsResponse200DataByTeam):
            unique_users (int):
            last_used_at (None | str):
     """

    total_events: int
    by_event_type: GetApiV1EntitiesIdStatsResponse200DataByEventType
    by_team: GetApiV1EntitiesIdStatsResponse200DataByTeam
    unique_users: int
    last_used_at: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_entities_id_stats_response_200_data_by_event_type import GetApiV1EntitiesIdStatsResponse200DataByEventType
        from ..models.get_api_v1_entities_id_stats_response_200_data_by_team import GetApiV1EntitiesIdStatsResponse200DataByTeam
        total_events = self.total_events

        by_event_type = self.by_event_type.to_dict()

        by_team = self.by_team.to_dict()

        unique_users = self.unique_users

        last_used_at: None | str
        last_used_at = self.last_used_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "total_events": total_events,
            "by_event_type": by_event_type,
            "by_team": by_team,
            "unique_users": unique_users,
            "last_used_at": last_used_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_entities_id_stats_response_200_data_by_event_type import GetApiV1EntitiesIdStatsResponse200DataByEventType
        from ..models.get_api_v1_entities_id_stats_response_200_data_by_team import GetApiV1EntitiesIdStatsResponse200DataByTeam
        d = dict(src_dict)
        total_events = d.pop("total_events")

        by_event_type = GetApiV1EntitiesIdStatsResponse200DataByEventType.from_dict(d.pop("by_event_type"))




        by_team = GetApiV1EntitiesIdStatsResponse200DataByTeam.from_dict(d.pop("by_team"))




        unique_users = d.pop("unique_users")

        def _parse_last_used_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))


        get_api_v1_entities_id_stats_response_200_data = cls(
            total_events=total_events,
            by_event_type=by_event_type,
            by_team=by_team,
            unique_users=unique_users,
            last_used_at=last_used_at,
        )


        get_api_v1_entities_id_stats_response_200_data.additional_properties = d
        return get_api_v1_entities_id_stats_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
