# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1NotificationsResponse200DataItemType(str, Enum):
    APPROVAL_REQUIRED = "approval_required"
    REQUEST_ASSIGNED = "request_assigned"
    REQUEST_STATUS_CHANGED = "request_status_changed"
    SYSTEM = "system"

    def __str__(self) -> str:
        return str(self.value)
