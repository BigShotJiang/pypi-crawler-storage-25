# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1GovernanceTrendsResponse200DataItem")



@_attrs_define
class GetApiV1GovernanceTrendsResponse200DataItem:
    """ 
        Attributes:
            week_start (str):
            compliance_pct (float):
            total_checks (float):
            passed_checks (float):
     """

    week_start: str
    compliance_pct: float
    total_checks: float
    passed_checks: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        week_start = self.week_start

        compliance_pct = self.compliance_pct

        total_checks = self.total_checks

        passed_checks = self.passed_checks


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "week_start": week_start,
            "compliance_pct": compliance_pct,
            "total_checks": total_checks,
            "passed_checks": passed_checks,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        week_start = d.pop("week_start")

        compliance_pct = d.pop("compliance_pct")

        total_checks = d.pop("total_checks")

        passed_checks = d.pop("passed_checks")

        get_api_v1_governance_trends_response_200_data_item = cls(
            week_start=week_start,
            compliance_pct=compliance_pct,
            total_checks=total_checks,
            passed_checks=passed_checks,
        )


        get_api_v1_governance_trends_response_200_data_item.additional_properties = d
        return get_api_v1_governance_trends_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
