# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="GetApiV1GovernanceViolationsResponse200DataItem")



@_attrs_define
class GetApiV1GovernanceViolationsResponse200DataItem:
    """ 
        Attributes:
            entity_id (UUID):
            entity_name (str):
            entity_kind (str):
            entity_namespace (str):
            violation_type (str):
            severity (str):
            checked_at (str):
     """

    entity_id: UUID
    entity_name: str
    entity_kind: str
    entity_namespace: str
    violation_type: str
    severity: str
    checked_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        entity_id = str(self.entity_id)

        entity_name = self.entity_name

        entity_kind = self.entity_kind

        entity_namespace = self.entity_namespace

        violation_type = self.violation_type

        severity = self.severity

        checked_at = self.checked_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entity_id": entity_id,
            "entity_name": entity_name,
            "entity_kind": entity_kind,
            "entity_namespace": entity_namespace,
            "violation_type": violation_type,
            "severity": severity,
            "checked_at": checked_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        entity_id = UUID(d.pop("entity_id"))




        entity_name = d.pop("entity_name")

        entity_kind = d.pop("entity_kind")

        entity_namespace = d.pop("entity_namespace")

        violation_type = d.pop("violation_type")

        severity = d.pop("severity")

        checked_at = d.pop("checked_at")

        get_api_v1_governance_violations_response_200_data_item = cls(
            entity_id=entity_id,
            entity_name=entity_name,
            entity_kind=entity_kind,
            entity_namespace=entity_namespace,
            violation_type=violation_type,
            severity=severity,
            checked_at=checked_at,
        )


        get_api_v1_governance_violations_response_200_data_item.additional_properties = d
        return get_api_v1_governance_violations_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
