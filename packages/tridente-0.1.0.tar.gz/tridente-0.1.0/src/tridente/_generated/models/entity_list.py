# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.entity import Entity
  from ..models.entity_facets import EntityFacets
  from ..models.pagination_meta import PaginationMeta





T = TypeVar("T", bound="EntityList")



@_attrs_define
class EntityList:
    """ 
        Attributes:
            data (list[Entity]):
            meta (PaginationMeta):
            facets (EntityFacets):
     """

    data: list[Entity]
    meta: PaginationMeta
    facets: EntityFacets
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.entity import Entity
        from ..models.entity_facets import EntityFacets
        from ..models.pagination_meta import PaginationMeta
        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)



        meta = self.meta.to_dict()

        facets = self.facets.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "data": data,
            "meta": meta,
            "facets": facets,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.entity import Entity
        from ..models.entity_facets import EntityFacets
        from ..models.pagination_meta import PaginationMeta
        d = dict(src_dict)
        data = []
        _data = d.pop("data")
        for data_item_data in (_data):
            data_item = Entity.from_dict(data_item_data)



            data.append(data_item)


        meta = PaginationMeta.from_dict(d.pop("meta"))




        facets = EntityFacets.from_dict(d.pop("facets"))




        entity_list = cls(
            data=data,
            meta=meta,
            facets=facets,
        )


        entity_list.additional_properties = d
        return entity_list

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
