# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1HealthResponse200DataStatus(str, Enum):
    OK = "ok"

    def __str__(self) -> str:
        return str(self.value)
