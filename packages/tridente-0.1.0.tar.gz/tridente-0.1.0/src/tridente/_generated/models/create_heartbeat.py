# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.heartbeat_status import HeartbeatStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.heartbeat_metadata import HeartbeatMetadata





T = TypeVar("T", bound="CreateHeartbeat")



@_attrs_define
class CreateHeartbeat:
    """ 
        Attributes:
            status (HeartbeatStatus):
            metadata (HeartbeatMetadata | Unset):
     """

    status: HeartbeatStatus
    metadata: HeartbeatMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.heartbeat_metadata import HeartbeatMetadata
        status = self.status.value

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
        })
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.heartbeat_metadata import HeartbeatMetadata
        d = dict(src_dict)
        status = HeartbeatStatus(d.pop("status"))




        _metadata = d.pop("metadata", UNSET)
        metadata: HeartbeatMetadata | Unset
        if isinstance(_metadata,  Unset):
            metadata = UNSET
        else:
            metadata = HeartbeatMetadata.from_dict(_metadata)




        create_heartbeat = cls(
            status=status,
            metadata=metadata,
        )


        create_heartbeat.additional_properties = d
        return create_heartbeat

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
