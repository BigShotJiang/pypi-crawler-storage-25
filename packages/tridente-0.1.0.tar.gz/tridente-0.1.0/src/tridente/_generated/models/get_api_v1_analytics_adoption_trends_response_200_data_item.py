# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1AnalyticsAdoptionTrendsResponse200DataItem")



@_attrs_define
class GetApiV1AnalyticsAdoptionTrendsResponse200DataItem:
    """ 
        Attributes:
            period (str):
            new_users (int):
            new_teams (int):
            reuse_events (int):
     """

    period: str
    new_users: int
    new_teams: int
    reuse_events: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        period = self.period

        new_users = self.new_users

        new_teams = self.new_teams

        reuse_events = self.reuse_events


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "period": period,
            "new_users": new_users,
            "new_teams": new_teams,
            "reuse_events": reuse_events,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period = d.pop("period")

        new_users = d.pop("new_users")

        new_teams = d.pop("new_teams")

        reuse_events = d.pop("reuse_events")

        get_api_v1_analytics_adoption_trends_response_200_data_item = cls(
            period=period,
            new_users=new_users,
            new_teams=new_teams,
            reuse_events=reuse_events,
        )


        get_api_v1_analytics_adoption_trends_response_200_data_item.additional_properties = d
        return get_api_v1_analytics_adoption_trends_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
