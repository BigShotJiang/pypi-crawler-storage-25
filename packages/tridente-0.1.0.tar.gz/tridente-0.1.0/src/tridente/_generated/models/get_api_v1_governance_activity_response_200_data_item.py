# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1GovernanceActivityResponse200DataItem")



@_attrs_define
class GetApiV1GovernanceActivityResponse200DataItem:
    """ 
        Attributes:
            type_ (str):
            title (str):
            description (str):
            timestamp (str):
     """

    type_: str
    title: str
    description: str
    timestamp: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        title = self.title

        description = self.description

        timestamp = self.timestamp


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "title": title,
            "description": description,
            "timestamp": timestamp,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type")

        title = d.pop("title")

        description = d.pop("description")

        timestamp = d.pop("timestamp")

        get_api_v1_governance_activity_response_200_data_item = cls(
            type_=type_,
            title=title,
            description=description,
            timestamp=timestamp,
        )


        get_api_v1_governance_activity_response_200_data_item.additional_properties = d
        return get_api_v1_governance_activity_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
