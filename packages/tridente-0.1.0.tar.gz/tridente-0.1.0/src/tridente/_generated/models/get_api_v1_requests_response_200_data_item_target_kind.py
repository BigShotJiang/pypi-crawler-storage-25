# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1RequestsResponse200DataItemTargetKind(str, Enum):
    AGENT = "agent"
    CONNECTOR = "connector"
    EVALUATION_SUITE = "evaluation-suite"
    SKILL = "skill"
    TOOL = "tool"

    def __str__(self) -> str:
        return str(self.value)
