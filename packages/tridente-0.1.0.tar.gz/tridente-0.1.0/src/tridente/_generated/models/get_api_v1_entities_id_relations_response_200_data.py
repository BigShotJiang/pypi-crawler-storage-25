# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item import GetApiV1EntitiesIdRelationsResponse200DataRelationsItem





T = TypeVar("T", bound="GetApiV1EntitiesIdRelationsResponse200Data")



@_attrs_define
class GetApiV1EntitiesIdRelationsResponse200Data:
    """ 
        Attributes:
            entity_id (UUID):
            relations (list[GetApiV1EntitiesIdRelationsResponse200DataRelationsItem]):
     """

    entity_id: UUID
    relations: list[GetApiV1EntitiesIdRelationsResponse200DataRelationsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item import GetApiV1EntitiesIdRelationsResponse200DataRelationsItem
        entity_id = str(self.entity_id)

        relations = []
        for relations_item_data in self.relations:
            relations_item = relations_item_data.to_dict()
            relations.append(relations_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entity_id": entity_id,
            "relations": relations,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item import GetApiV1EntitiesIdRelationsResponse200DataRelationsItem
        d = dict(src_dict)
        entity_id = UUID(d.pop("entity_id"))




        relations = []
        _relations = d.pop("relations")
        for relations_item_data in (_relations):
            relations_item = GetApiV1EntitiesIdRelationsResponse200DataRelationsItem.from_dict(relations_item_data)



            relations.append(relations_item)


        get_api_v1_entities_id_relations_response_200_data = cls(
            entity_id=entity_id,
            relations=relations,
        )


        get_api_v1_entities_id_relations_response_200_data.additional_properties = d
        return get_api_v1_entities_id_relations_response_200_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
