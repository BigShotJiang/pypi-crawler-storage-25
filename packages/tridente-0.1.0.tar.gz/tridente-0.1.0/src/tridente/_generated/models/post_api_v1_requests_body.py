# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_api_v1_requests_body_target_kind import PostApiV1RequestsBodyTargetKind
from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="PostApiV1RequestsBody")



@_attrs_define
class PostApiV1RequestsBody:
    """ 
        Attributes:
            title (str):
            description (str):
            target_kind (PostApiV1RequestsBodyTargetKind):
            assignee_id (UUID | Unset):
     """

    title: str
    description: str
    target_kind: PostApiV1RequestsBodyTargetKind
    assignee_id: UUID | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        title = self.title

        description = self.description

        target_kind = self.target_kind.value

        assignee_id: str | Unset = UNSET
        if not isinstance(self.assignee_id, Unset):
            assignee_id = str(self.assignee_id)


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "title": title,
            "description": description,
            "target_kind": target_kind,
        })
        if assignee_id is not UNSET:
            field_dict["assignee_id"] = assignee_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title")

        description = d.pop("description")

        target_kind = PostApiV1RequestsBodyTargetKind(d.pop("target_kind"))




        _assignee_id = d.pop("assignee_id", UNSET)
        assignee_id: UUID | Unset
        if isinstance(_assignee_id,  Unset):
            assignee_id = UNSET
        else:
            assignee_id = UUID(_assignee_id)




        post_api_v1_requests_body = cls(
            title=title,
            description=description,
            target_kind=target_kind,
            assignee_id=assignee_id,
        )


        post_api_v1_requests_body.additional_properties = d
        return post_api_v1_requests_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
