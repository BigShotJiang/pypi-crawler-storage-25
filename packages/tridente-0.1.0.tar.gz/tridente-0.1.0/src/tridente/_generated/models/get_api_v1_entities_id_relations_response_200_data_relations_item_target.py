# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget")



@_attrs_define
class GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget:
    """ 
        Attributes:
            id (UUID):
            kind (str):
            namespace (str):
            name (str):
            description (str):
     """

    id: UUID
    kind: str
    namespace: str
    name: str
    description: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        kind = self.kind

        namespace = self.namespace

        name = self.name

        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "kind": kind,
            "namespace": namespace,
            "name": name,
            "description": description,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        kind = d.pop("kind")

        namespace = d.pop("namespace")

        name = d.pop("name")

        description = d.pop("description")

        get_api_v1_entities_id_relations_response_200_data_relations_item_target = cls(
            id=id,
            kind=kind,
            namespace=namespace,
            name=name,
            description=description,
        )


        get_api_v1_entities_id_relations_response_200_data_relations_item_target.additional_properties = d
        return get_api_v1_entities_id_relations_response_200_data_relations_item_target

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
