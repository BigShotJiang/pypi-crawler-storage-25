# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class CreateCostEventProvider(str, Enum):
    ANTHROPIC = "anthropic"
    AZURE = "azure"
    CUSTOM = "custom"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
