# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class GetApiV1BillingStatusResponse200DataPlanTier(str, Enum):
    COMMUNITY = "community"
    ENTERPRISE = "enterprise"
    PRO = "pro"

    def __str__(self) -> str:
        return str(self.value)
