# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1WebhooksResponse200DataItem")



@_attrs_define
class GetApiV1WebhooksResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            url (str):
            events (list[str]):
            active (bool):
            created_at (Any | Unset):
            updated_at (Any | Unset):
     """

    id: UUID
    org_id: UUID
    url: str
    events: list[str]
    active: bool
    created_at: Any | Unset = UNSET
    updated_at: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        org_id = str(self.org_id)

        url = self.url

        events = self.events



        active = self.active

        created_at = self.created_at

        updated_at = self.updated_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "url": url,
            "events": events,
            "active": active,
        })
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        url = d.pop("url")

        events = cast(list[str], d.pop("events"))


        active = d.pop("active")

        created_at = d.pop("created_at", UNSET)

        updated_at = d.pop("updated_at", UNSET)

        get_api_v1_webhooks_response_200_data_item = cls(
            id=id,
            org_id=org_id,
            url=url,
            events=events,
            active=active,
            created_at=created_at,
            updated_at=updated_at,
        )


        get_api_v1_webhooks_response_200_data_item.additional_properties = d
        return get_api_v1_webhooks_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
