# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_notifications_response_200_data_item_type import GetApiV1NotificationsResponse200DataItemType
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.get_api_v1_notifications_response_200_data_item_metadata_type_0 import GetApiV1NotificationsResponse200DataItemMetadataType0





T = TypeVar("T", bound="GetApiV1NotificationsResponse200DataItem")



@_attrs_define
class GetApiV1NotificationsResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            user_id (UUID):
            type_ (GetApiV1NotificationsResponse200DataItemType):
            title (str):
            message (str):
            metadata (GetApiV1NotificationsResponse200DataItemMetadataType0 | None):
            read_at (None | str):
            created_at (str):
     """

    id: UUID
    org_id: UUID
    user_id: UUID
    type_: GetApiV1NotificationsResponse200DataItemType
    title: str
    message: str
    metadata: GetApiV1NotificationsResponse200DataItemMetadataType0 | None
    read_at: None | str
    created_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_notifications_response_200_data_item_metadata_type_0 import GetApiV1NotificationsResponse200DataItemMetadataType0
        id = str(self.id)

        org_id = str(self.org_id)

        user_id = str(self.user_id)

        type_ = self.type_.value

        title = self.title

        message = self.message

        metadata: dict[str, Any] | None
        if isinstance(self.metadata, GetApiV1NotificationsResponse200DataItemMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        read_at: None | str
        read_at = self.read_at

        created_at = self.created_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "user_id": user_id,
            "type": type_,
            "title": title,
            "message": message,
            "metadata": metadata,
            "read_at": read_at,
            "created_at": created_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_notifications_response_200_data_item_metadata_type_0 import GetApiV1NotificationsResponse200DataItemMetadataType0
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        user_id = UUID(d.pop("user_id"))




        type_ = GetApiV1NotificationsResponse200DataItemType(d.pop("type"))




        title = d.pop("title")

        message = d.pop("message")

        def _parse_metadata(data: object) -> GetApiV1NotificationsResponse200DataItemMetadataType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = GetApiV1NotificationsResponse200DataItemMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetApiV1NotificationsResponse200DataItemMetadataType0 | None, data)

        metadata = _parse_metadata(d.pop("metadata"))


        def _parse_read_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        read_at = _parse_read_at(d.pop("read_at"))


        created_at = d.pop("created_at")

        get_api_v1_notifications_response_200_data_item = cls(
            id=id,
            org_id=org_id,
            user_id=user_id,
            type_=type_,
            title=title,
            message=message,
            metadata=metadata,
            read_at=read_at,
            created_at=created_at,
        )


        get_api_v1_notifications_response_200_data_item.additional_properties = d
        return get_api_v1_notifications_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
