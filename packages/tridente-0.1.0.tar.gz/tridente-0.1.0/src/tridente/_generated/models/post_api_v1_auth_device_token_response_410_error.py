# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class PostApiV1AuthDeviceTokenResponse410Error(str, Enum):
    AUTHORIZATION_PENDING = "authorization_pending"
    EXPIRED_TOKEN = "expired_token"
    INVALID_CODE = "invalid_code"

    def __str__(self) -> str:
        return str(self.value)
