# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item_direction import GetApiV1EntitiesIdRelationsResponse200DataRelationsItemDirection
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item_target import GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget





T = TypeVar("T", bound="GetApiV1EntitiesIdRelationsResponse200DataRelationsItem")



@_attrs_define
class GetApiV1EntitiesIdRelationsResponse200DataRelationsItem:
    """ 
        Attributes:
            id (UUID):
            type_ (str):
            direction (GetApiV1EntitiesIdRelationsResponse200DataRelationsItemDirection):
            target (GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget):
     """

    id: UUID
    type_: str
    direction: GetApiV1EntitiesIdRelationsResponse200DataRelationsItemDirection
    target: GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item_target import GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget
        id = str(self.id)

        type_ = self.type_

        direction = self.direction.value

        target = self.target.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "type": type_,
            "direction": direction,
            "target": target,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_entities_id_relations_response_200_data_relations_item_target import GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        type_ = d.pop("type")

        direction = GetApiV1EntitiesIdRelationsResponse200DataRelationsItemDirection(d.pop("direction"))




        target = GetApiV1EntitiesIdRelationsResponse200DataRelationsItemTarget.from_dict(d.pop("target"))




        get_api_v1_entities_id_relations_response_200_data_relations_item = cls(
            id=id,
            type_=type_,
            direction=direction,
            target=target,
        )


        get_api_v1_entities_id_relations_response_200_data_relations_item.additional_properties = d
        return get_api_v1_entities_id_relations_response_200_data_relations_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
