# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_requests_response_200_data_item_status import GetApiV1RequestsResponse200DataItemStatus
from ..models.get_api_v1_requests_response_200_data_item_target_kind import GetApiV1RequestsResponse200DataItemTargetKind
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1RequestsResponse200DataItem")



@_attrs_define
class GetApiV1RequestsResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            org_id (UUID):
            requester_id (UUID):
            title (str):
            description (str):
            target_kind (GetApiV1RequestsResponse200DataItemTargetKind):
            status (GetApiV1RequestsResponse200DataItemStatus):
            assignee_id (None | UUID):
            created_at (str):
            updated_at (str):
            resolved_at (None | str):
     """

    id: UUID
    org_id: UUID
    requester_id: UUID
    title: str
    description: str
    target_kind: GetApiV1RequestsResponse200DataItemTargetKind
    status: GetApiV1RequestsResponse200DataItemStatus
    assignee_id: None | UUID
    created_at: str
    updated_at: str
    resolved_at: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        org_id = str(self.org_id)

        requester_id = str(self.requester_id)

        title = self.title

        description = self.description

        target_kind = self.target_kind.value

        status = self.status.value

        assignee_id: None | str
        if isinstance(self.assignee_id, UUID):
            assignee_id = str(self.assignee_id)
        else:
            assignee_id = self.assignee_id

        created_at = self.created_at

        updated_at = self.updated_at

        resolved_at: None | str
        resolved_at = self.resolved_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org_id": org_id,
            "requester_id": requester_id,
            "title": title,
            "description": description,
            "target_kind": target_kind,
            "status": status,
            "assignee_id": assignee_id,
            "created_at": created_at,
            "updated_at": updated_at,
            "resolved_at": resolved_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        org_id = UUID(d.pop("org_id"))




        requester_id = UUID(d.pop("requester_id"))




        title = d.pop("title")

        description = d.pop("description")

        target_kind = GetApiV1RequestsResponse200DataItemTargetKind(d.pop("target_kind"))




        status = GetApiV1RequestsResponse200DataItemStatus(d.pop("status"))




        def _parse_assignee_id(data: object) -> None | UUID:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                assignee_id_type_0 = UUID(data)



                return assignee_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UUID, data)

        assignee_id = _parse_assignee_id(d.pop("assignee_id"))


        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_resolved_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        resolved_at = _parse_resolved_at(d.pop("resolved_at"))


        get_api_v1_requests_response_200_data_item = cls(
            id=id,
            org_id=org_id,
            requester_id=requester_id,
            title=title,
            description=description,
            target_kind=target_kind,
            status=status,
            assignee_id=assignee_id,
            created_at=created_at,
            updated_at=updated_at,
            resolved_at=resolved_at,
        )


        get_api_v1_requests_response_200_data_item.additional_properties = d
        return get_api_v1_requests_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
