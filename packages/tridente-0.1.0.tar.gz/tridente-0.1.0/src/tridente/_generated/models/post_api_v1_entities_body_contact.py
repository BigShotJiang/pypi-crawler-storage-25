# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PostApiV1EntitiesBodyContact")



@_attrs_define
class PostApiV1EntitiesBodyContact:
    """ 
        Attributes:
            email (str | Unset):
            slack_channel (str | Unset):
            pagerduty_service (str | Unset):
            owner_name (str | Unset):
     """

    email: str | Unset = UNSET
    slack_channel: str | Unset = UNSET
    pagerduty_service: str | Unset = UNSET
    owner_name: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        slack_channel = self.slack_channel

        pagerduty_service = self.pagerduty_service

        owner_name = self.owner_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if email is not UNSET:
            field_dict["email"] = email
        if slack_channel is not UNSET:
            field_dict["slack_channel"] = slack_channel
        if pagerduty_service is not UNSET:
            field_dict["pagerduty_service"] = pagerduty_service
        if owner_name is not UNSET:
            field_dict["owner_name"] = owner_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email", UNSET)

        slack_channel = d.pop("slack_channel", UNSET)

        pagerduty_service = d.pop("pagerduty_service", UNSET)

        owner_name = d.pop("owner_name", UNSET)

        post_api_v1_entities_body_contact = cls(
            email=email,
            slack_channel=slack_channel,
            pagerduty_service=pagerduty_service,
            owner_name=owner_name,
        )


        post_api_v1_entities_body_contact.additional_properties = d
        return post_api_v1_entities_body_contact

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
