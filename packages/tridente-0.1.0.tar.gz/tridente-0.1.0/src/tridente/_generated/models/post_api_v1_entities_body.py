# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_api_v1_entities_body_kind import PostApiV1EntitiesBodyKind
from ..models.post_api_v1_entities_body_maturity import PostApiV1EntitiesBodyMaturity
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_api_v1_entities_body_annotations import PostApiV1EntitiesBodyAnnotations
  from ..models.post_api_v1_entities_body_contact import PostApiV1EntitiesBodyContact
  from ..models.post_api_v1_entities_body_labels import PostApiV1EntitiesBodyLabels
  from ..models.post_api_v1_entities_body_links_item import PostApiV1EntitiesBodyLinksItem
  from ..models.post_api_v1_entities_body_spec import PostApiV1EntitiesBodySpec





T = TypeVar("T", bound="PostApiV1EntitiesBody")



@_attrs_define
class PostApiV1EntitiesBody:
    """ 
        Attributes:
            kind (PostApiV1EntitiesBodyKind):
            name (str):
            description (str):
            owner_team (str):
            spec (PostApiV1EntitiesBodySpec):
            namespace (str | Unset):  Default: 'default'.
            display_name (str | Unset):
            maturity (PostApiV1EntitiesBodyMaturity | Unset):  Default: PostApiV1EntitiesBodyMaturity.EXPERIMENTAL.
            version (str | Unset):  Default: '0.1.0'.
            tags (list[str] | Unset):
            labels (PostApiV1EntitiesBodyLabels | Unset):
            annotations (PostApiV1EntitiesBodyAnnotations | Unset):
            repository_url (str | Unset):
            documentation_url (str | Unset):
            contact (PostApiV1EntitiesBodyContact | Unset):
            links (list[PostApiV1EntitiesBodyLinksItem] | Unset):
            manifest_raw (str | Unset):
     """

    kind: PostApiV1EntitiesBodyKind
    name: str
    description: str
    owner_team: str
    spec: PostApiV1EntitiesBodySpec
    namespace: str | Unset = 'default'
    display_name: str | Unset = UNSET
    maturity: PostApiV1EntitiesBodyMaturity | Unset = PostApiV1EntitiesBodyMaturity.EXPERIMENTAL
    version: str | Unset = '0.1.0'
    tags: list[str] | Unset = UNSET
    labels: PostApiV1EntitiesBodyLabels | Unset = UNSET
    annotations: PostApiV1EntitiesBodyAnnotations | Unset = UNSET
    repository_url: str | Unset = UNSET
    documentation_url: str | Unset = UNSET
    contact: PostApiV1EntitiesBodyContact | Unset = UNSET
    links: list[PostApiV1EntitiesBodyLinksItem] | Unset = UNSET
    manifest_raw: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_api_v1_entities_body_annotations import PostApiV1EntitiesBodyAnnotations
        from ..models.post_api_v1_entities_body_contact import PostApiV1EntitiesBodyContact
        from ..models.post_api_v1_entities_body_labels import PostApiV1EntitiesBodyLabels
        from ..models.post_api_v1_entities_body_links_item import PostApiV1EntitiesBodyLinksItem
        from ..models.post_api_v1_entities_body_spec import PostApiV1EntitiesBodySpec
        kind = self.kind.value

        name = self.name

        description = self.description

        owner_team = self.owner_team

        spec = self.spec.to_dict()

        namespace = self.namespace

        display_name = self.display_name

        maturity: str | Unset = UNSET
        if not isinstance(self.maturity, Unset):
            maturity = self.maturity.value


        version = self.version

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags



        labels: dict[str, Any] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels.to_dict()

        annotations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.annotations, Unset):
            annotations = self.annotations.to_dict()

        repository_url = self.repository_url

        documentation_url = self.documentation_url

        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)



        manifest_raw = self.manifest_raw


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "kind": kind,
            "name": name,
            "description": description,
            "owner_team": owner_team,
            "spec": spec,
        })
        if namespace is not UNSET:
            field_dict["namespace"] = namespace
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if maturity is not UNSET:
            field_dict["maturity"] = maturity
        if version is not UNSET:
            field_dict["version"] = version
        if tags is not UNSET:
            field_dict["tags"] = tags
        if labels is not UNSET:
            field_dict["labels"] = labels
        if annotations is not UNSET:
            field_dict["annotations"] = annotations
        if repository_url is not UNSET:
            field_dict["repository_url"] = repository_url
        if documentation_url is not UNSET:
            field_dict["documentation_url"] = documentation_url
        if contact is not UNSET:
            field_dict["contact"] = contact
        if links is not UNSET:
            field_dict["links"] = links
        if manifest_raw is not UNSET:
            field_dict["manifest_raw"] = manifest_raw

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_api_v1_entities_body_annotations import PostApiV1EntitiesBodyAnnotations
        from ..models.post_api_v1_entities_body_contact import PostApiV1EntitiesBodyContact
        from ..models.post_api_v1_entities_body_labels import PostApiV1EntitiesBodyLabels
        from ..models.post_api_v1_entities_body_links_item import PostApiV1EntitiesBodyLinksItem
        from ..models.post_api_v1_entities_body_spec import PostApiV1EntitiesBodySpec
        d = dict(src_dict)
        kind = PostApiV1EntitiesBodyKind(d.pop("kind"))




        name = d.pop("name")

        description = d.pop("description")

        owner_team = d.pop("owner_team")

        spec = PostApiV1EntitiesBodySpec.from_dict(d.pop("spec"))




        namespace = d.pop("namespace", UNSET)

        display_name = d.pop("display_name", UNSET)

        _maturity = d.pop("maturity", UNSET)
        maturity: PostApiV1EntitiesBodyMaturity | Unset
        if isinstance(_maturity,  Unset):
            maturity = UNSET
        else:
            maturity = PostApiV1EntitiesBodyMaturity(_maturity)




        version = d.pop("version", UNSET)

        tags = cast(list[str], d.pop("tags", UNSET))


        _labels = d.pop("labels", UNSET)
        labels: PostApiV1EntitiesBodyLabels | Unset
        if isinstance(_labels,  Unset):
            labels = UNSET
        else:
            labels = PostApiV1EntitiesBodyLabels.from_dict(_labels)




        _annotations = d.pop("annotations", UNSET)
        annotations: PostApiV1EntitiesBodyAnnotations | Unset
        if isinstance(_annotations,  Unset):
            annotations = UNSET
        else:
            annotations = PostApiV1EntitiesBodyAnnotations.from_dict(_annotations)




        repository_url = d.pop("repository_url", UNSET)

        documentation_url = d.pop("documentation_url", UNSET)

        _contact = d.pop("contact", UNSET)
        contact: PostApiV1EntitiesBodyContact | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = PostApiV1EntitiesBodyContact.from_dict(_contact)




        _links = d.pop("links", UNSET)
        links: list[PostApiV1EntitiesBodyLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = PostApiV1EntitiesBodyLinksItem.from_dict(links_item_data)



                links.append(links_item)


        manifest_raw = d.pop("manifest_raw", UNSET)

        post_api_v1_entities_body = cls(
            kind=kind,
            name=name,
            description=description,
            owner_team=owner_team,
            spec=spec,
            namespace=namespace,
            display_name=display_name,
            maturity=maturity,
            version=version,
            tags=tags,
            labels=labels,
            annotations=annotations,
            repository_url=repository_url,
            documentation_url=documentation_url,
            contact=contact,
            links=links,
            manifest_raw=manifest_raw,
        )


        post_api_v1_entities_body.additional_properties = d
        return post_api_v1_entities_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
