# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_cost_event_provider import CreateCostEventProvider
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
  from ..models.create_cost_event_metadata import CreateCostEventMetadata





T = TypeVar("T", bound="CreateCostEvent")



@_attrs_define
class CreateCostEvent:
    """ 
        Attributes:
            provider (CreateCostEventProvider):
            model (str):
            token_count_input (int):
            token_count_output (int):
            compute_cost_usd (float):
            entity_id (UUID | Unset):
            currency (str | Unset):  Default: 'USD'.
            recorded_at (datetime.datetime | Unset):
            metadata (CreateCostEventMetadata | Unset):
     """

    provider: CreateCostEventProvider
    model: str
    token_count_input: int
    token_count_output: int
    compute_cost_usd: float
    entity_id: UUID | Unset = UNSET
    currency: str | Unset = 'USD'
    recorded_at: datetime.datetime | Unset = UNSET
    metadata: CreateCostEventMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_cost_event_metadata import CreateCostEventMetadata
        provider = self.provider.value

        model = self.model

        token_count_input = self.token_count_input

        token_count_output = self.token_count_output

        compute_cost_usd = self.compute_cost_usd

        entity_id: str | Unset = UNSET
        if not isinstance(self.entity_id, Unset):
            entity_id = str(self.entity_id)

        currency = self.currency

        recorded_at: str | Unset = UNSET
        if not isinstance(self.recorded_at, Unset):
            recorded_at = self.recorded_at.isoformat()

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "provider": provider,
            "model": model,
            "token_count_input": token_count_input,
            "token_count_output": token_count_output,
            "compute_cost_usd": compute_cost_usd,
        })
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id
        if currency is not UNSET:
            field_dict["currency"] = currency
        if recorded_at is not UNSET:
            field_dict["recorded_at"] = recorded_at
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_cost_event_metadata import CreateCostEventMetadata
        d = dict(src_dict)
        provider = CreateCostEventProvider(d.pop("provider"))




        model = d.pop("model")

        token_count_input = d.pop("token_count_input")

        token_count_output = d.pop("token_count_output")

        compute_cost_usd = d.pop("compute_cost_usd")

        _entity_id = d.pop("entity_id", UNSET)
        entity_id: UUID | Unset
        if isinstance(_entity_id,  Unset):
            entity_id = UNSET
        else:
            entity_id = UUID(_entity_id)




        currency = d.pop("currency", UNSET)

        _recorded_at = d.pop("recorded_at", UNSET)
        recorded_at: datetime.datetime | Unset
        if isinstance(_recorded_at,  Unset):
            recorded_at = UNSET
        else:
            recorded_at = isoparse(_recorded_at)




        _metadata = d.pop("metadata", UNSET)
        metadata: CreateCostEventMetadata | Unset
        if isinstance(_metadata,  Unset):
            metadata = UNSET
        else:
            metadata = CreateCostEventMetadata.from_dict(_metadata)




        create_cost_event = cls(
            provider=provider,
            model=model,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            compute_cost_usd=compute_cost_usd,
            entity_id=entity_id,
            currency=currency,
            recorded_at=recorded_at,
            metadata=metadata,
        )


        create_cost_event.additional_properties = d
        return create_cost_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
