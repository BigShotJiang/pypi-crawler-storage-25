# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="GetApiV1AnalyticsCostTrendsResponse200DataItem")



@_attrs_define
class GetApiV1AnalyticsCostTrendsResponse200DataItem:
    """ 
        Attributes:
            team (str):
            period (str):
            total_cost_usd (float):
            token_count_total (float):
     """

    team: str
    period: str
    total_cost_usd: float
    token_count_total: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        team = self.team

        period = self.period

        total_cost_usd = self.total_cost_usd

        token_count_total = self.token_count_total


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "team": team,
            "period": period,
            "total_cost_usd": total_cost_usd,
            "token_count_total": token_count_total,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        team = d.pop("team")

        period = d.pop("period")

        total_cost_usd = d.pop("total_cost_usd")

        token_count_total = d.pop("token_count_total")

        get_api_v1_analytics_cost_trends_response_200_data_item = cls(
            team=team,
            period=period,
            total_cost_usd=total_cost_usd,
            token_count_total=token_count_total,
        )


        get_api_v1_analytics_cost_trends_response_200_data_item.additional_properties = d
        return get_api_v1_analytics_cost_trends_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
