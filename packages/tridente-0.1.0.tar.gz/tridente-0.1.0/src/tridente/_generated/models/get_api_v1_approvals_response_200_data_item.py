# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.get_api_v1_approvals_response_200_data_item_status import GetApiV1ApprovalsResponse200DataItemStatus
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="GetApiV1ApprovalsResponse200DataItem")



@_attrs_define
class GetApiV1ApprovalsResponse200DataItem:
    """ 
        Attributes:
            id (UUID):
            entity_id (UUID):
            entity_name (str):
            entity_kind (str):
            entity_namespace (str):
            risk_level (str):
            requested_by (str):
            status (GetApiV1ApprovalsResponse200DataItemStatus):
            decision_reason (None | str):
            decided_by (None | str):
            decided_at (None | str):
            created_at (str):
     """

    id: UUID
    entity_id: UUID
    entity_name: str
    entity_kind: str
    entity_namespace: str
    risk_level: str
    requested_by: str
    status: GetApiV1ApprovalsResponse200DataItemStatus
    decision_reason: None | str
    decided_by: None | str
    decided_at: None | str
    created_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        entity_id = str(self.entity_id)

        entity_name = self.entity_name

        entity_kind = self.entity_kind

        entity_namespace = self.entity_namespace

        risk_level = self.risk_level

        requested_by = self.requested_by

        status = self.status.value

        decision_reason: None | str
        decision_reason = self.decision_reason

        decided_by: None | str
        decided_by = self.decided_by

        decided_at: None | str
        decided_at = self.decided_at

        created_at = self.created_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "entity_id": entity_id,
            "entity_name": entity_name,
            "entity_kind": entity_kind,
            "entity_namespace": entity_namespace,
            "risk_level": risk_level,
            "requested_by": requested_by,
            "status": status,
            "decision_reason": decision_reason,
            "decided_by": decided_by,
            "decided_at": decided_at,
            "created_at": created_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        entity_id = UUID(d.pop("entity_id"))




        entity_name = d.pop("entity_name")

        entity_kind = d.pop("entity_kind")

        entity_namespace = d.pop("entity_namespace")

        risk_level = d.pop("risk_level")

        requested_by = d.pop("requested_by")

        status = GetApiV1ApprovalsResponse200DataItemStatus(d.pop("status"))




        def _parse_decision_reason(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        decision_reason = _parse_decision_reason(d.pop("decision_reason"))


        def _parse_decided_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        decided_by = _parse_decided_by(d.pop("decided_by"))


        def _parse_decided_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        decided_at = _parse_decided_at(d.pop("decided_at"))


        created_at = d.pop("created_at")

        get_api_v1_approvals_response_200_data_item = cls(
            id=id,
            entity_id=entity_id,
            entity_name=entity_name,
            entity_kind=entity_kind,
            entity_namespace=entity_namespace,
            risk_level=risk_level,
            requested_by=requested_by,
            status=status,
            decision_reason=decision_reason,
            decided_by=decided_by,
            decided_at=decided_at,
            created_at=created_at,
        )


        get_api_v1_approvals_response_200_data_item.additional_properties = d
        return get_api_v1_approvals_response_200_data_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
