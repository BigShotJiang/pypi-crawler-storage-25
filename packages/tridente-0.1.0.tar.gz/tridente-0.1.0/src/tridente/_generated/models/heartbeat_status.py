# THIS FILE IS GENERATED. DO NOT EDIT.
# Regenerate via `pnpm sdk:python:regenerate` from the repo root.
from enum import Enum

class HeartbeatStatus(str, Enum):
    DEGRADED = "degraded"
    HEALTHY = "healthy"
    OFFLINE = "offline"

    def __str__(self) -> str:
        return str(self.value)
