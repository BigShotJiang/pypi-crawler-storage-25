//! Profile where time is spent at n=5000, d=8

use mgcv_rust::basis::{BasisFunction, CubicRegressionSpline};
use mgcv_rust::block_penalty::BlockPenalty;
use mgcv_rust::penalty::compute_penalty;
use mgcv_rust::smooth::{OptimizationMethod, REMLAlgorithm, SmoothingParameter};
use ndarray::{Array1, Array2};
use rand::distributions::{Distribution, Uniform};
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use std::f64::consts::PI;
use std::time::Instant;

fn main() {
    println!("=== Profiling n=5000, d=8 bottlenecks ===\n");

    let mut rng = ChaCha8Rng::seed_from_u64(123);
    let uniform = Uniform::new(0.0, 1.0);

    let n = 5000;
    let d = 8;
    let k = 8;

    // Time: Data generation
    let t0 = Instant::now();
    let mut x_vecs = Vec::new();
    for _ in 0..d {
        let x: Vec<f64> = (0..n).map(|_| uniform.sample(&mut rng)).collect();
        x_vecs.push(Array1::from(x));
    }

    let y: Array1<f64> = {
        let mut y_vec = Vec::new();
        for i in 0..n {
            let signal: f64 = x_vecs.iter().map(|x| (2.0 * PI * x[i]).sin()).sum();
            let u1 = uniform.sample(&mut rng);
            let u2 = uniform.sample(&mut rng);
            let noise = 0.3 * (-2.0 * u1.ln()).sqrt() * (2.0 * PI * u2).cos();
            y_vec.push(signal + noise);
        }
        Array1::from(y_vec)
    };
    println!(
        "Data generation: {:.1}ms",
        t0.elapsed().as_secs_f64() * 1000.0
    );

    // Time: Design matrix construction
    let t1 = Instant::now();
    let mut design_matrices = Vec::new();
    let mut penalties_vec = Vec::new();

    for x in &x_vecs {
        let basis = CubicRegressionSpline::with_quantile_knots(x, k);
        let design = basis.evaluate(x).unwrap();
        let knots = basis.knots().unwrap();
        let mut penalty = compute_penalty("cr", k, Some(knots), 1).unwrap();

        // Apply penalty normalization
        let inf_norm_X = design
            .rows()
            .into_iter()
            .map(|row| row.iter().map(|x| x.abs()).sum::<f64>())
            .fold(0.0f64, f64::max);
        let maXX = inf_norm_X * inf_norm_X;

        let inf_norm_S = (0..k)
            .map(|i| (0..k).map(|j| penalty[[i, j]].abs()).sum::<f64>())
            .fold(0.0f64, f64::max);

        if inf_norm_S > 1e-10 {
            penalty *= maXX / inf_norm_S;
        }

        design_matrices.push(design);
        penalties_vec.push(penalty);
    }
    println!(
        "Basis & penalty construction: {:.1}ms",
        t1.elapsed().as_secs_f64() * 1000.0
    );

    // Time: Matrix assembly
    let t2 = Instant::now();
    let total_basis = k * d;
    let mut full_design = Array2::zeros((n, total_basis));
    for (i, mat) in design_matrices.iter().enumerate() {
        full_design
            .slice_mut(ndarray::s![.., (i * k)..((i + 1) * k)])
            .assign(mat);
    }

    let mut penalties = Vec::new();
    for (i, pen) in penalties_vec.into_iter().enumerate() {
        penalties.push(BlockPenalty::new(pen, i * k, total_basis));
    }
    println!(
        "Matrix assembly: {:.1}ms",
        t2.elapsed().as_secs_f64() * 1000.0
    );

    // Time: Newton optimization
    println!("\nStarting Newton optimization (will show per-iteration timing)...");
    std::env::set_var("MGCV_PROFILE", "1");

    let mut sp =
        SmoothingParameter::new_with_algorithm(d, OptimizationMethod::REML, REMLAlgorithm::Newton);

    let weights = Array1::ones(n);
    let t3 = Instant::now();

    match sp.optimize(&y, &full_design, &weights, &penalties, 30, 1e-6) {
        Ok(_) => {
            let elapsed = t3.elapsed().as_secs_f64() * 1000.0;
            println!("\nTotal Newton time: {:.1}ms", elapsed);
            println!("Average per iteration: {:.1}ms", elapsed / 9.0);
        }
        Err(e) => {
            println!("\nOptimization failed: {}", e);
        }
    }

    println!("\n=== Time Breakdown ===");
    println!(
        "Data generation:       {:.1}ms",
        t0.elapsed().as_secs_f64() * 1000.0
    );
    println!(
        "Basis construction:    {:.1}ms",
        t1.elapsed().as_secs_f64() * 1000.0
    );
    println!(
        "Matrix assembly:       {:.1}ms",
        t2.elapsed().as_secs_f64() * 1000.0
    );
    println!(
        "Newton optimization:   {:.1}ms",
        t3.elapsed().as_secs_f64() * 1000.0
    );
    println!(
        "TOTAL:                 {:.1}ms",
        t0.elapsed().as_secs_f64() * 1000.0
    );
}
