//! Test d=4 and d=8 convergence

use mgcv_rust::basis::{BasisFunction, CubicRegressionSpline};
use mgcv_rust::block_penalty::BlockPenalty;
use mgcv_rust::penalty::compute_penalty;
use mgcv_rust::smooth::{OptimizationMethod, REMLAlgorithm, SmoothingParameter};
use ndarray::{Array1, Array2};
use rand::distributions::{Distribution, Uniform};
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use std::f64::consts::PI;

fn test_config(n: usize, d: usize, k: usize) {
    println!("\n=== Testing n={}, d={}, k={} ===", n, d, k);

    let mut rng = ChaCha8Rng::seed_from_u64(123);
    let uniform = Uniform::new(0.0, 1.0);

    // Generate X matrix and y vector
    let mut x_vecs = Vec::new();
    for _ in 0..d {
        let x: Vec<f64> = (0..n).map(|_| uniform.sample(&mut rng)).collect();
        x_vecs.push(Array1::from(x));
    }

    // y = sum of sin(2πxᵢ) + noise
    let y: Array1<f64> = {
        let mut y_vec = Vec::new();
        for i in 0..n {
            let signal: f64 = x_vecs.iter().map(|x| (2.0 * PI * x[i]).sin()).sum();
            let u1 = uniform.sample(&mut rng);
            let u2 = uniform.sample(&mut rng);
            let noise = 0.3 * (-2.0 * u1.ln()).sqrt() * (2.0 * PI * u2).cos();
            y_vec.push(signal + noise);
        }
        Array1::from(y_vec)
    };

    // Build design matrices and penalties
    let mut design_matrices = Vec::new();
    let mut penalties_vec = Vec::new();

    for x in &x_vecs {
        let basis = CubicRegressionSpline::with_quantile_knots(x, k);
        let design = basis.evaluate(x).unwrap();
        let knots = basis.knots().unwrap();
        let mut penalty = compute_penalty("cr", k, Some(knots), 1).unwrap();

        // Apply penalty normalization
        let inf_norm_X = design
            .rows()
            .into_iter()
            .map(|row| row.iter().map(|x| x.abs()).sum::<f64>())
            .fold(0.0f64, f64::max);
        let maXX = inf_norm_X * inf_norm_X;

        let inf_norm_S = (0..k)
            .map(|i| (0..k).map(|j| penalty[[i, j]].abs()).sum::<f64>())
            .fold(0.0f64, f64::max);

        if inf_norm_S > 1e-10 {
            penalty *= maXX / inf_norm_S;
        }

        design_matrices.push(design);
        penalties_vec.push(penalty);
    }

    // Combine into full design matrix
    let total_basis = k * d;
    let mut full_design = Array2::zeros((n, total_basis));
    for (i, mat) in design_matrices.iter().enumerate() {
        full_design
            .slice_mut(ndarray::s![.., (i * k)..((i + 1) * k)])
            .assign(mat);
    }

    // Create block-diagonal penalties
    let mut penalties = Vec::new();
    for (i, pen) in penalties_vec.into_iter().enumerate() {
        penalties.push(BlockPenalty::new(pen, i * k, total_basis));
    }

    // Test Newton
    std::env::set_var("MGCV_PROFILE", "1");

    let mut sp =
        SmoothingParameter::new_with_algorithm(d, OptimizationMethod::REML, REMLAlgorithm::Newton);

    let weights = Array1::ones(n);
    let start = std::time::Instant::now();

    match sp.optimize(&y, &full_design, &weights, &penalties, 30, 1e-6) {
        Ok(_) => {
            let elapsed = start.elapsed().as_secs_f64() * 1000.0;
            let lambda_mean = sp.lambda.iter().sum::<f64>() / sp.lambda.len() as f64;
            println!("✓ Converged in {:.1}ms", elapsed);
            println!("  Lambda (mean): {:.6}", lambda_mean);
        }
        Err(e) => {
            println!("✗ Failed: {}", e);
        }
    }

    std::env::remove_var("MGCV_PROFILE");
}

fn main() {
    println!("=== Rust Newton Performance: High-D ===");

    test_config(500, 4, 10);
    test_config(500, 8, 8);
    test_config(1000, 4, 10);
    test_config(1000, 8, 8);
}
