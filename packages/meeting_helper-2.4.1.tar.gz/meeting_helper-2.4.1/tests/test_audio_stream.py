"""AudioStream + dual queue routing on CombinedAudioCapture."""

from __future__ import annotations

import sys
from queue import Queue

import numpy as np
import pytest

# This module imports macOS-only audio deps at import-time. Skip gracefully on non-darwin.
pytestmark = pytest.mark.skipif(
    not sys.platform.startswith("darwin"),
    reason="macOS-only audio module",
)


def test_audio_stream_returns_chunk_when_available():
    from meeting_helper.audio.capture import AudioStream
    q: Queue = Queue()
    chunk = np.array([0.1, 0.2, 0.3], dtype=np.float32)
    q.put(chunk)

    stream = AudioStream(queue=q, sample_rate=16000, channels=1)
    out = stream.get_transcriber_audio(timeout=0.01)
    assert out is not None
    np.testing.assert_array_equal(out, chunk)


def test_audio_stream_returns_none_on_empty():
    from meeting_helper.audio.capture import AudioStream
    q: Queue = Queue()
    stream = AudioStream(queue=q, sample_rate=16000, channels=1)
    assert stream.get_transcriber_audio(timeout=0.01) is None


def test_audio_stream_exposes_sample_rate_and_channels():
    from meeting_helper.audio.capture import AudioStream
    q: Queue = Queue()
    stream = AudioStream(queue=q, sample_rate=48000, channels=2)
    assert stream.sample_rate == 48000
    assert stream.channels == 2


def test_capture_exposes_self_and_other_streams():
    from meeting_helper.audio.capture import CombinedAudioCapture
    cap = CombinedAudioCapture(sample_rate=16000)
    assert cap.self_stream is not None
    assert cap.other_stream is not None
    assert cap.self_stream.sample_rate == 16000
    assert cap.other_stream.sample_rate == 16000


def test_mic_chunks_route_only_to_self_stream():
    from meeting_helper.audio.capture import CombinedAudioCapture
    cap = CombinedAudioCapture(sample_rate=16000)
    chunk = np.array([0.5, -0.5, 0.25], dtype=np.float32)
    cap._mic_transcribe_q.put(chunk)

    out_self = cap.self_stream.get_transcriber_audio(timeout=0.01)
    out_other = cap.other_stream.get_transcriber_audio(timeout=0.01)
    np.testing.assert_array_equal(out_self, chunk)
    assert out_other is None


def test_sys_chunks_route_only_to_other_stream():
    from meeting_helper.audio.capture import CombinedAudioCapture
    cap = CombinedAudioCapture(sample_rate=16000)
    chunk = np.array([0.1, 0.2, 0.3], dtype=np.float32)
    cap._sys_transcribe_q.put(chunk)

    out_self = cap.self_stream.get_transcriber_audio(timeout=0.01)
    out_other = cap.other_stream.get_transcriber_audio(timeout=0.01)
    assert out_self is None
    np.testing.assert_array_equal(out_other, chunk)
