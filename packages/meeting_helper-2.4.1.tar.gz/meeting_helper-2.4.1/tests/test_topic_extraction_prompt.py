"""Unit tests for the topic-extraction user message builder."""

from meeting_helper.ai.prompts import (
    TOPIC_EXTRACTION_SYSTEM_PROMPT,
    build_topic_extraction_user_message,
)


def test_self_only_lines_are_labeled_me():
    msg = build_topic_extraction_user_message(
        labeled_sentences=[
            ("self", "I'm working on ENGT-4147."),
            ("self", "Status remapper now accepts numeric values."),
        ]
    )
    assert "[me] I'm working on ENGT-4147." in msg
    assert "[me] Status remapper now accepts numeric values." in msg
    assert "[other]" not in msg


def test_mixed_lines_get_correct_role_labels():
    msg = build_topic_extraction_user_message(
        labeled_sentences=[
            ("self", "I'm checking ENGT-4147."),
            ("other", "What about the migration plan?"),
            ("self", "Let me look that up."),
        ]
    )
    assert "[me] I'm checking ENGT-4147." in msg
    assert "[other] What about the migration plan?" in msg
    assert "[me] Let me look that up." in msg


def test_empty_input_renders_placeholder():
    msg = build_topic_extraction_user_message(labeled_sentences=[])
    assert "(empty)" in msg


def test_blank_text_is_dropped():
    msg = build_topic_extraction_user_message(
        labeled_sentences=[
            ("self", "  "),
            ("self", "Real sentence."),
        ]
    )
    assert "[me] Real sentence." in msg
    assert "[me] \n" not in msg


def test_system_prompt_documents_role_labels():
    """The system prompt must teach the LLM what [me]/[other] mean."""
    assert "[me]" in TOPIC_EXTRACTION_SYSTEM_PROMPT
    assert "[other]" in TOPIC_EXTRACTION_SYSTEM_PROMPT
