"""LocalTodoClient.search() must call the local-todo MCP's search_tasks
and search_docs tools and return a flat list of normalized records."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper.local_todo import LocalTodoClient


@pytest.fixture
def fake_session():
    """A fake mcp ClientSession with controllable call_tool return values."""
    session = MagicMock()
    session.initialize = AsyncMock()
    session.call_tool = AsyncMock()
    return session


@pytest.fixture
def patched_client(fake_session, monkeypatch):
    """Return a LocalTodoClient where _ensure_started installs fake_session."""
    client = LocalTodoClient(mcp_config={"type": "stdio", "command": "echo", "args": ["fake"], "env": {}})

    async def _fake_ensure(self):
        self._session = fake_session

    monkeypatch.setattr(LocalTodoClient, "_ensure_started", _fake_ensure)
    return client, fake_session


def test_close_is_idempotent_when_never_started():
    """Closing a never-started client must not raise."""
    import asyncio
    client = LocalTodoClient(mcp_config={"type": "stdio", "command": "echo", "args": ["fake"], "env": {}})
    asyncio.run(client.close())


def test_constructor_accepts_http_config():
    client = LocalTodoClient(mcp_config={
        "type": "http",
        "url": "http://x/mcp",
        "headers": {"Authorization": "Bearer y"},
    })
    assert client._type == "http"
    assert client._url == "http://x/mcp"
    assert client._headers == {"Authorization": "Bearer y"}


def test_constructor_rejects_empty_http_url():
    import pytest
    with pytest.raises(ValueError):
        LocalTodoClient(mcp_config={"type": "http", "url": ""})


def test_constructor_rejects_empty_stdio_command():
    import pytest
    with pytest.raises(ValueError):
        LocalTodoClient(mcp_config={"type": "stdio", "command": ""})


def test_constructor_rejects_unknown_type():
    import pytest
    with pytest.raises(ValueError):
        LocalTodoClient(mcp_config={"type": "websocket", "url": "ws://x"})


# ---------- New tests for real-schema methods ----------

def _mk_text_result(payload):
    """Build a fake MCP call_tool result whose content[0].text is JSON of payload."""
    text = json.dumps(payload)
    return MagicMock(content=[MagicMock(text=text)])


@pytest.mark.asyncio
async def test_list_boards_filters_to_readable(patched_client):
    client, session = patched_client
    session.call_tool.return_value = _mk_text_result([
        {"board_id": 1, "name": "A", "effective_permission": "read"},
        {"board_id": 2, "name": "B", "effective_permission": "write"},
        {"board_id": 3, "name": "C", "effective_permission": "none"},
    ])
    boards = await client.list_boards()
    assert [b["board_id"] for b in boards] == [1, 2]
    # Cached: second call doesn't hit the session again
    session.call_tool.reset_mock()
    boards2 = await client.list_boards()
    assert boards2 is boards or boards2 == boards
    session.call_tool.assert_not_called()


@pytest.mark.asyncio
async def test_search_uses_board_id_and_q(patched_client):
    """search() must call search_tasks AND search_docs per authorized board with q=query."""
    import json as _json
    client, session = patched_client

    def _route(tool_name, args):
        if tool_name == "list_boards":
            return _mk_text_result([
                {"board_id": 1, "name": "Grepr", "effective_permission": "read"},
                {"board_id": 2, "name": "SoFi", "effective_permission": "write"},
            ])
        if tool_name == "search_tasks":
            return _mk_text_result([
                {"id": f"t-{args['board_id']}-{args.get('q', '')[:3]}", "title": f"hit on {args['board_id']}",
                 "status": "in_progress", "url": f"http://x/b/{args['board_id']}/t/1"},
            ])
        if tool_name == "search_docs":
            return _mk_text_result([])
        return _mk_text_result(None)

    session.call_tool.side_effect = lambda tool, args: _route(tool, args)
    results = await client.search("auth", limit=5)

    # Should have made 1 list_boards + 2 search_tasks + 2 search_docs = 5 calls
    assert session.call_tool.await_count == 5
    # Each task result tagged with board metadata + kind
    tasks = [r for r in results if r["kind"] == "task"]
    assert len(tasks) == 2
    assert {t["board_id"] for t in tasks} == {1, 2}
    assert all("board_name" in t for t in tasks)
    # Verify q was passed (not "query")
    search_task_calls = [c for c in session.call_tool.await_args_list
                         if c.args[0] == "search_tasks"]
    for c in search_task_calls:
        assert "q" in c.args[1] and c.args[1]["q"] == "auth"
        assert "board_id" in c.args[1]


@pytest.mark.asyncio
async def test_my_active_tasks_aggregates_across_boards(patched_client):
    client, session = patched_client

    def _route(tool, args):
        if tool == "list_boards":
            return _mk_text_result([
                {"board_id": 1, "name": "A", "effective_permission": "read"},
                {"board_id": 2, "name": "B", "effective_permission": "write"},
            ])
        if tool == "list_sprints":
            if args["board_id"] == 1:
                return _mk_text_result({
                    "active": {"id": "10", "name": "Sprint A1", "state": "active"},
                    "planned": [], "closed": [],
                })
            else:
                return _mk_text_result({"active": None, "planned": [], "closed": []})
        if tool == "search_tasks":
            assert args["board_id"] == 1, "should only query boards with active sprint"
            return _mk_text_result([
                {"id": "77", "title": "Refresh tokens", "status": "in_progress", "sprint_id": "10"},
            ])
        return _mk_text_result(None)

    session.call_tool.side_effect = lambda t, a: _route(t, a)
    tasks = await client.my_active_tasks()
    assert len(tasks) == 1
    assert tasks[0]["id"] == "77"
    assert tasks[0]["board_id"] == 1
    assert tasks[0]["sprint_name"] == "Sprint A1"


@pytest.mark.asyncio
async def test_my_active_tasks_returns_empty_when_no_boards_have_active_sprint(patched_client):
    client, session = patched_client

    def _route(tool, args):
        if tool == "list_boards":
            return _mk_text_result([
                {"board_id": 1, "name": "A", "effective_permission": "read"},
            ])
        if tool == "list_sprints":
            return _mk_text_result({"active": None, "planned": [], "closed": []})
        return _mk_text_result(None)

    session.call_tool.side_effect = lambda t, a: _route(t, a)
    assert await client.my_active_tasks() == []


@pytest.mark.asyncio
async def test_get_requires_board_id(patched_client):
    client, session = patched_client
    session.call_tool.return_value = _mk_text_result(
        {"id": "77", "title": "Refresh tokens", "body": "..."}
    )
    record = await client.get("task", "77", board_id=2)
    session.call_tool.assert_awaited_once_with("get_task", {"board_id": 2, "id": "77"})
    assert record["id"] == "77"


@pytest.mark.asyncio
async def test_get_doc_uses_get_doc(patched_client):
    client, session = patched_client
    session.call_tool.return_value = _mk_text_result({"id": "9", "title": "Doc"})
    await client.get("doc", "9", board_id=5)
    session.call_tool.assert_awaited_once_with("get_doc", {"board_id": 5, "id": "9"})


@pytest.mark.asyncio
async def test_get_rejects_unknown_kind(patched_client):
    client, _ = patched_client
    with pytest.raises(ValueError):
        await client.get("project", "X", board_id=1)
