"""Round-trip + migration tests for the local_todo_mcp config field."""

from __future__ import annotations

import json

from meeting_helper.config import Config


def test_config_round_trips_stdio(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {
        "type": "stdio",
        "command": "custom",
        "args": ["--flag", "value"],
        "env": {"FOO": "bar"},
        "url": "",
        "headers": {},
    }
    config.save()

    reloaded = Config(cfg_path)
    cfg = reloaded.local_todo_mcp
    assert cfg["type"] == "stdio"
    assert cfg["command"] == "custom"
    assert cfg["args"] == ["--flag", "value"]
    assert cfg["env"] == {"FOO": "bar"}


def test_config_round_trips_http(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {
        "type": "http",
        "command": "",
        "args": [],
        "env": {},
        "url": "http://vcloud.local/local-todo/mcp",
        "headers": {"Authorization": "Bearer ltb_xxxx"},
    }
    config.save()

    reloaded = Config(cfg_path)
    cfg = reloaded.local_todo_mcp
    assert cfg["type"] == "http"
    assert cfg["url"] == "http://vcloud.local/local-todo/mcp"
    assert cfg["headers"] == {"Authorization": "Bearer ltb_xxxx"}


def test_config_default_local_todo(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    cfg = config.local_todo_mcp
    assert cfg["type"] == "stdio"
    assert cfg["command"] == "npx"
    assert cfg["args"] == ["@local-todo/mcp"]


def test_config_migrates_legacy_flat_list(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({"local_todo_mcp_command": ["npx", "@old/pkg"]}))
    config = Config(cfg_path)
    cfg = config.local_todo_mcp
    assert cfg["type"] == "stdio"
    assert cfg["command"] == "npx"
    assert cfg["args"] == ["@old/pkg"]


def test_config_detects_http_when_url_present_but_type_missing(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "local_todo_mcp": {"url": "http://x/mcp", "headers": {"Authorization": "Bearer y"}}
    }))
    config = Config(cfg_path)
    cfg = config.local_todo_mcp
    assert cfg["type"] == "http"
    assert cfg["url"] == "http://x/mcp"


def test_config_back_compat_command_property_for_stdio(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {"type": "stdio", "command": "uvx", "args": ["mypkg"]}
    assert config.local_todo_mcp_command == ["uvx", "mypkg"]


def test_config_command_property_returns_empty_for_http(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {"type": "http", "url": "http://x/mcp"}
    assert config.local_todo_mcp_command == []
