"""Unit tests for Pill — option list + selection callback."""

from meeting_helper.flet_gui.components.pill import Pill, PillOption


def test_pill_stores_options():
    pill = Pill(label="Provider", options=[
        PillOption(key="claude", label="Claude"),
        PillOption(key="gemini", label="Gemini"),
    ], on_select=lambda k: None)
    assert [o.key for o in pill.options] == ["claude", "gemini"]


def test_pill_select_invokes_callback_with_key():
    received: list[str] = []
    pill = Pill(label="Model", options=[
        PillOption(key="sonnet", label="Sonnet"),
        PillOption(key="opus", label="Opus"),
    ], on_select=lambda k: received.append(k))
    pill.select("opus")
    assert received == ["opus"]


def test_pill_select_unknown_key_is_a_no_op():
    received: list[str] = []
    pill = Pill(label="x", options=[PillOption(key="a", label="A")],
                on_select=lambda k: received.append(k))
    pill.select("not-a-known-key")
    assert received == []


def test_pill_set_label_updates_display():
    pill = Pill(label="Provider", options=[
        PillOption(key="claude", label="Claude"),
    ], on_select=lambda k: None)
    pill.set_label("Claude")
    assert pill.label == "Claude"


def test_pill_replace_options():
    pill = Pill(label="Model", options=[
        PillOption(key="sonnet", label="Sonnet"),
    ], on_select=lambda k: None)
    pill.set_options([
        PillOption(key="flash", label="Flash"),
        PillOption(key="pro", label="Pro"),
    ])
    assert [o.key for o in pill.options] == ["flash", "pro"]
