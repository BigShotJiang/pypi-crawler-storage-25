"""Tests for the screen-recording recovery helpers."""

from __future__ import annotations

import sys
from unittest.mock import patch

import pytest

from meeting_helper import permissions as perm


def test_is_macos_matches_platform():
    assert perm.is_macos() == (sys.platform == "darwin")


def test_open_screen_recording_settings_on_non_mac_returns_false(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: False)
    assert perm.open_screen_recording_settings() is False


def test_restart_tcc_returns_false_on_non_mac(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: False)
    ok, msg = perm.restart_tcc()
    assert ok is False
    assert "macOS" in msg


def test_restart_tcc_succeeds_when_sudo_returncode_zero(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: "/usr/bin/sudo")
    monkeypatch.setattr(perm, "_run", lambda cmd, timeout=5.0: (0, "", ""))
    ok, msg = perm.restart_tcc()
    assert ok is True
    assert "tccd" in msg


def test_restart_tcc_reports_sudo_required_on_non_zero(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: "/usr/bin/sudo")
    monkeypatch.setattr(perm, "_run", lambda cmd, timeout=5.0: (1, "", "a password is required"))
    ok, msg = perm.restart_tcc()
    assert ok is False
    assert "sudo required" in msg
    assert "password is required" in msg


def test_restart_tcc_returns_false_when_sudo_missing(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: None)
    ok, msg = perm.restart_tcc()
    assert ok is False
    assert msg == "sudo not available"


def test_restart_coreaudio_succeeds_when_zero(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: "/usr/bin/sudo")
    monkeypatch.setattr(perm, "_run", lambda cmd, timeout=5.0: (0, "", ""))
    ok, msg = perm.restart_coreaudio()
    assert ok is True
    assert "coreaudiod" in msg


def test_restart_tcc_and_coreaudio_interactive_success(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm, "_run", lambda cmd, timeout=30.0: (0, "", ""))
    result = perm.restart_tcc_and_coreaudio_interactive()
    assert result["tccd"] is True
    assert result["coreaudiod"] is True
    assert result["replayd"] is True
    assert "restarted" in result["message"]


def test_restart_tcc_and_coreaudio_interactive_failure(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(
        perm, "_run", lambda cmd, timeout=30.0: (1, "", "auth cancelled"),
    )
    result = perm.restart_tcc_and_coreaudio_interactive()
    assert result["tccd"] is False
    assert result["coreaudiod"] is False
    assert result["replayd"] is False
    assert "auth cancelled" in result["message"]


def test_restart_interactive_command_includes_replayd(monkeypatch):
    """The single sudo invocation must touch replayd, not just tccd/coreaudiod."""
    captured: dict = {}

    def _spy_run(cmd, timeout=30.0):
        captured["cmd"] = cmd
        return (0, "", "")

    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm, "_run", _spy_run)
    perm.restart_tcc_and_coreaudio_interactive()
    cmd_str = " ".join(captured["cmd"])
    assert "killall tccd" in cmd_str
    assert "killall coreaudiod" in cmd_str
    assert "killall replayd" in cmd_str


def test_reset_app_screen_recording_handles_missing_tccutil(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: None)
    ok, msg = perm.reset_app_screen_recording("com.example.foo")
    assert ok is False
    assert "tccutil" in msg


def test_reset_app_screen_recording_success(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: True)
    monkeypatch.setattr(perm.shutil, "which", lambda _: "/usr/bin/tccutil")
    monkeypatch.setattr(perm, "_run", lambda cmd, timeout=5.0: (0, "", ""))
    ok, msg = perm.reset_app_screen_recording("com.example.foo")
    assert ok is True
    assert "com.example.foo" in msg


def test_screen_recording_status_returns_unknown_off_mac(monkeypatch):
    monkeypatch.setattr(perm, "is_macos", lambda: False)
    assert perm.screen_recording_status() == "unknown"
