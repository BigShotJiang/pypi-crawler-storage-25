"""Unit tests for last_n_distinct — topic-history dedup."""

from meeting_helper.flet_gui.components.topic_strip import last_n_distinct


def test_empty_history_returns_empty():
    assert last_n_distinct([]) == []


def test_returns_last_three_when_all_distinct():
    history = ["a", "b", "c", "d"]
    assert last_n_distinct(history) == ["d", "c", "b"]


def test_collapses_consecutive_duplicates():
    history = ["a", "a", "a", "b", "b", "c"]
    assert last_n_distinct(history) == ["c", "b", "a"]


def test_collapses_repeated_topics_anywhere():
    history = ["a", "b", "a", "c", "b", "a"]
    # walking from the end: a, b, c — a then re-seen b/c skipped not from end
    # Actually: start from end: a (new) -> b (new) -> c (new) -> stop (3 reached)
    assert last_n_distinct(history) == ["a", "b", "c"]


def test_returns_fewer_when_history_short():
    assert last_n_distinct(["a"]) == ["a"]
    assert last_n_distinct(["a", "b"]) == ["b", "a"]


def test_n_parameter_overrides_default():
    history = ["a", "b", "c", "d", "e"]
    assert last_n_distinct(history, n=2) == ["e", "d"]
    assert last_n_distinct(history, n=5) == ["e", "d", "c", "b", "a"]


def test_ignores_blank_strings():
    history = ["a", "", "  ", "b", ""]
    assert last_n_distinct(history) == ["b", "a"]
