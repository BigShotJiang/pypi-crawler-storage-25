"""Unit tests for AppState Hot Moment primitives."""

import time

from meeting_helper.state import AppState


def test_default_is_idle():
    s = AppState()
    assert s.is_hot_moment() is False
    assert s.hot_moment_until == 0.0


def test_arm_sets_future_until_and_marks_active():
    s = AppState()
    s.arm_hot_moment(window_sec=60.0)
    assert s.is_hot_moment() is True
    assert s.hot_moment_until > time.monotonic()
    assert s.hot_moment_until <= time.monotonic() + 61.0


def test_arm_with_zero_window_remains_idle():
    s = AppState()
    s.arm_hot_moment(window_sec=0.0)
    assert s.is_hot_moment() is False


def test_re_arming_extends_window():
    s = AppState()
    s.arm_hot_moment(window_sec=10.0)
    first_until = s.hot_moment_until
    time.sleep(0.01)
    s.arm_hot_moment(window_sec=120.0)
    assert s.hot_moment_until > first_until


def test_state_decays_after_window_passes():
    s = AppState()
    s.hot_moment_until = time.monotonic() - 1.0
    assert s.is_hot_moment() is False
