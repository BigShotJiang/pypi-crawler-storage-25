"""TopicWorker — debounce, hash-skip, state updates, broadcast."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import AppState
from meeting_helper.topic_worker import TopicWorker


class FakeConfig:
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    google_api_key = ""
    deepgram_api_key = ""
    claude_model = "claude-test"
    gemini_model = "gemini-test"
    local_model = "x"
    ollama_host = "http://localhost:11434"
    max_tokens = 512


@pytest.mark.asyncio
async def test_topic_worker_extracts_and_writes_state(monkeypatch):
    buf = SentenceBuffer(role="self")
    buf.append_final("I finished ENGT-4147 — status remapper now accepts numeric severity values.")
    buf.append_final("Today I'm working on ENGT-4212 Phase 2.")

    fake_local_todo = MagicMock()
    fake_local_todo.search = AsyncMock(return_value=[
        {"kind": "task", "id": "ENGT-4147", "title": "Status remapper", "board_id": 1}
    ])

    state = AppState()
    state.self_buffer = buf
    state.local_todo = fake_local_todo
    state.asyncio_loop = asyncio.get_event_loop()

    fake_response = (
        '{"topic": "Status remapper", '
        '"ticket_ids": ["ENGT-4147", "ENGT-4212"], '
        '"search_query": "status remapper numeric severity", '
        '"last_user_statement": "I finished ENGT-4147 — status remapper now accepts numeric severity values."}'
    )
    fake_call = AsyncMock(return_value=fake_response)
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)

    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    assert state.current_topic["topic"] == "Status remapper"
    assert state.current_topic["ticket_ids"] == ["ENGT-4147", "ENGT-4212"]
    assert state.current_topic["search_query"] == "status remapper numeric severity"

    fake_local_todo.search.assert_awaited_once_with(
        "status remapper numeric severity", limit=5
    )
    assert len(state.current_topic_cards) == 1
    assert state.current_topic_cards[0]["id"] == "ENGT-4147"

    assert any(p.get("type") == "topic" for p in payloads)
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["topic"] == "Status remapper"
    assert topic_payload["ticket_ids"] == ["ENGT-4147", "ENGT-4212"]


@pytest.mark.asyncio
async def test_topic_worker_hash_skip_avoids_duplicate_calls(monkeypatch):
    buf = SentenceBuffer(role="self")
    buf.append_final("I'm on the auth migration.")

    state = AppState()
    state.self_buffer = buf
    state.local_todo = None
    state.asyncio_loop = asyncio.get_event_loop()

    fake_call = AsyncMock(return_value='{"topic": "auth migration", "ticket_ids": [], "search_query": "auth migration", "last_user_statement": "I am on the auth migration"}')
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    async def fake_broadcast(payload):
        pass
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()
    await worker._run()  # same buffer text → should hash-skip

    assert fake_call.await_count == 1


@pytest.mark.asyncio
async def test_topic_worker_handles_ai_failure(monkeypatch):
    buf = SentenceBuffer(role="self")
    buf.append_final("I'm working on something.")

    state = AppState()
    state.self_buffer = buf
    state.local_todo = None
    state.asyncio_loop = asyncio.get_event_loop()

    fake_call = AsyncMock(side_effect=RuntimeError("network down"))
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)

    async def fake_broadcast(payload):
        pass
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    # current_topic gets the empty-topic dict, no crash
    assert state.current_topic["topic"] == ""
    assert state.current_topic["ticket_ids"] == []


@pytest.mark.asyncio
async def test_topic_worker_skips_empty_buffer(monkeypatch):
    buf = SentenceBuffer(role="self")
    state = AppState()
    state.self_buffer = buf
    state.asyncio_loop = asyncio.get_event_loop()

    fake_call = AsyncMock(return_value='{}')
    monkeypatch.setattr("meeting_helper.ai.client._call_ai_for_tasks", fake_call)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(FakeConfig(), buf)
    await worker._run()

    fake_call.assert_not_awaited()


def test_topic_worker_lifecycle_attaches_listener():
    buf = SentenceBuffer(role="self")
    worker = TopicWorker(FakeConfig(), buf)
    assert len(buf._on_sentence) == 0
    worker.start()
    assert len(buf._on_sentence) == 1
    worker.stop()
    assert len(buf._on_sentence) == 0
