"""Unit tests for `_extract_likely_question` — chronological + cutoff-aware."""

from meeting_helper.ai.client import _extract_likely_question


def test_returns_most_recent_question_after_cutoff():
    sentences = [
        (100.0, "self", "I'm working on ENGT-4147."),
        (101.0, "self", "What does the remapper do?"),
        (102.0, "other", "And what about ENGT-4212?"),
    ]
    # Cutoff at 99 — everything is fresh; latest `?` wins
    assert (
        _extract_likely_question(sentences, cutoff_ts=99.0)
        == "And what about ENGT-4212?"
    )


def test_cutoff_filters_out_stale_questions():
    sentences = [
        (100.0, "self", "What does the remapper do?"),  # stale
        (101.0, "self", "Followed up declarative statement."),
        (102.0, "other", "Some other-party statement, no question mark."),
    ]
    # Cutoff at 100 — the only `?` is stale, so we get nothing
    assert _extract_likely_question(sentences, cutoff_ts=100.0) == ""


def test_chronological_ordering_beats_role_order():
    # Other speaks first, then self — most recent `?` should be self's
    sentences = [
        (100.0, "other", "Earlier other question?"),
        (110.0, "self", "Later self question?"),
    ]
    assert (
        _extract_likely_question(sentences, cutoff_ts=0.0)
        == "Later self question?"
    )


def test_no_question_mark_returns_empty():
    sentences = [
        (100.0, "self", "Just a statement."),
        (101.0, "other", "Another statement, no questions here."),
    ]
    assert _extract_likely_question(sentences, cutoff_ts=0.0) == ""


def test_empty_input_returns_empty():
    assert _extract_likely_question([], cutoff_ts=0.0) == ""


def test_cutoff_zero_includes_all():
    sentences = [(100.0, "self", "Everything is in scope?")]
    assert (
        _extract_likely_question(sentences, cutoff_ts=0.0)
        == "Everything is in scope?"
    )
