"""GET /current_topic returns the current TopicWorker state."""

from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_current_topic_returns_state(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.current_topic = {
        "topic": "Status remapper",
        "ticket_ids": ["ENGT-4147"],
        "search_query": "status remapper",
        "last_user_statement": "I finished the remapper.",
    }
    global_state.current_topic_cards = [
        {"kind": "task", "id": "ENGT-4147", "title": "Status remapper", "board_id": 2}
    ]

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/current_topic")
    assert resp.status == 200
    body = await resp.json()
    assert body["topic"]["topic"] == "Status remapper"
    assert body["topic"]["ticket_ids"] == ["ENGT-4147"]
    assert body["cards_count"] == 1

    # Reset
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []


@pytest.mark.asyncio
async def test_current_topic_returns_idle_when_unset(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/current_topic")
    body = await resp.json()
    assert body["topic"]["topic"] == ""
    assert body["cards_count"] == 0
