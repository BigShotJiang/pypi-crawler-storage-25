"""Tests for ai.client.extract_tasks — AI provider call is mocked."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from meeting_helper.ai import client as client_mod
from meeting_helper.state import AppState


class FakeBuffer:
    def __init__(self, transcript: str):
        self._t = transcript

    def get_full_transcript(self) -> str:
        return self._t


class FakeConfig:
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    claude_model = "claude-test"
    max_tokens = 1000


@pytest.mark.asyncio
async def test_extract_tasks_appends_new_items():
    state = AppState()
    state.sentence_buffer = FakeBuffer("Alice will send the report.")
    state.session_tasks = []

    fake_response = (
        '{"tasks": [{"title": "Send report", '
        '"description": "Alice sends the quarterly report.", '
        '"source_quote": "Alice will send the report"}]}'
    )
    with patch.object(client_mod, "_call_ai_for_tasks",
                      new=AsyncMock(return_value=fake_response)):
        added = await client_mod.extract_tasks(state, FakeConfig())

    assert len(added) == 1
    assert added[0]["title"] == "Send report"
    assert added[0]["description"] == "Alice sends the quarterly report."
    assert "id" in added[0] and "created_at" in added[0]
    assert state.session_tasks == added


@pytest.mark.asyncio
async def test_extract_tasks_empty_transcript_returns_empty():
    state = AppState()
    state.sentence_buffer = FakeBuffer("")
    state.session_tasks = []

    with patch.object(client_mod, "_call_ai_for_tasks", new=AsyncMock()) as mock_ai:
        added = await client_mod.extract_tasks(state, FakeConfig())
        mock_ai.assert_not_called()

    assert added == []
    assert state.session_tasks == []


@pytest.mark.asyncio
async def test_extract_tasks_passes_existing_to_prompt():
    state = AppState()
    state.sentence_buffer = FakeBuffer("New stuff was discussed.")
    state.session_tasks = [
        {
            "id": "1",
            "title": "Existing task",
            "description": "",
            "source_quote": "x",
            "created_at": "2026-01-01T00:00:00Z",
        }
    ]

    captured = {}

    async def fake_ai(config, system_prompt, user_msg):
        captured["user_msg"] = user_msg
        return '{"tasks": []}'

    with patch.object(client_mod, "_call_ai_for_tasks", side_effect=fake_ai):
        added = await client_mod.extract_tasks(state, FakeConfig())

    assert added == []
    assert "Existing task" in captured["user_msg"]


@pytest.mark.asyncio
async def test_extract_tasks_handles_ai_failure_gracefully():
    state = AppState()
    state.sentence_buffer = FakeBuffer("Alice will send the report.")
    state.session_tasks = []

    with patch.object(client_mod, "_call_ai_for_tasks",
                      new=AsyncMock(side_effect=RuntimeError("network"))):
        added = await client_mod.extract_tasks(state, FakeConfig())

    assert added == []
    assert state.session_tasks == []


@pytest.mark.asyncio
async def test_extract_tasks_handles_malformed_response():
    state = AppState()
    state.sentence_buffer = FakeBuffer("Stuff.")
    state.session_tasks = []

    with patch.object(client_mod, "_call_ai_for_tasks",
                      new=AsyncMock(return_value="not json")):
        added = await client_mod.extract_tasks(state, FakeConfig())

    assert added == []
    assert state.session_tasks == []
