"""Tests for the tasks module."""

from __future__ import annotations

from pathlib import Path

from meeting_helper import tasks as tasks_mod


def test_parse_ai_response_plain_json():
    raw = (
        '{"tasks": [{"title": "Send the report", '
        '"description": "Send the quarterly report by tomorrow.", '
        '"source_quote": "I will send the report tomorrow"}]}'
    )
    result = tasks_mod.parse_ai_response(raw)
    assert result == [
        {
            "title": "Send the report",
            "description": "Send the quarterly report by tomorrow.",
            "source_quote": "I will send the report tomorrow",
        }
    ]


def test_parse_ai_response_fenced_json():
    raw = (
        '```json\n{"tasks": [{"title": "Email Bob", "description": "", '
        '"source_quote": "email Bob"}]}\n```'
    )
    result = tasks_mod.parse_ai_response(raw)
    assert result == [
        {"title": "Email Bob", "description": "", "source_quote": "email Bob"}
    ]


def test_parse_ai_response_legacy_text_field():
    """Legacy responses with `text` instead of `title` should still parse."""
    raw = '{"tasks": [{"text": "Old field", "source_quote": "q"}]}'
    result = tasks_mod.parse_ai_response(raw)
    assert result == [{"title": "Old field", "description": "", "source_quote": "q"}]


def test_parse_ai_response_empty_list():
    assert tasks_mod.parse_ai_response('{"tasks": []}') == []


def test_parse_ai_response_invalid_json_returns_empty():
    assert tasks_mod.parse_ai_response("not json at all") == []


def test_parse_ai_response_missing_tasks_key_returns_empty():
    assert tasks_mod.parse_ai_response('{"other": []}') == []


def test_parse_ai_response_non_list_tasks_returns_empty():
    assert tasks_mod.parse_ai_response('{"tasks": "oops"}') == []


def test_parse_ai_response_filters_invalid_items():
    raw = (
        '{"tasks": [{"title": "Good", "description": "d", "source_quote": "q"}, '
        '{"missing_title": true}, "string-not-dict"]}'
    )
    result = tasks_mod.parse_ai_response(raw)
    assert result == [{"title": "Good", "description": "d", "source_quote": "q"}]


def test_finalize_assigns_id_and_created_at():
    parsed = [{"title": "X", "description": "desc", "source_quote": "x"}]
    finalized = tasks_mod.finalize_tasks(parsed)
    assert len(finalized) == 1
    t = finalized[0]
    assert t["title"] == "X"
    assert t["description"] == "desc"
    assert t["source_quote"] == "x"
    assert isinstance(t["id"], str) and len(t["id"]) > 0
    assert "created_at" in t and t["created_at"].endswith("Z")


def test_save_and_load_roundtrip(tmp_path: Path):
    items = [
        {
            "id": "a",
            "title": "One",
            "description": "first",
            "source_quote": "q1",
            "created_at": "2026-01-01T00:00:00Z",
        },
        {
            "id": "b",
            "title": "Two",
            "description": "second",
            "source_quote": "q2",
            "created_at": "2026-01-02T00:00:00Z",
        },
    ]
    p = tmp_path / "meeting.tasks.json"
    tasks_mod.save_tasks(p, items)
    assert p.exists()
    assert tasks_mod.load_tasks(p) == items


def test_load_tasks_missing_file_returns_empty(tmp_path: Path):
    assert tasks_mod.load_tasks(tmp_path / "nope.json") == []


def test_load_tasks_malformed_returns_empty(tmp_path: Path):
    p = tmp_path / "bad.json"
    p.write_text("not json")
    assert tasks_mod.load_tasks(p) == []


def test_save_tasks_skips_when_empty(tmp_path: Path):
    p = tmp_path / "empty.tasks.json"
    tasks_mod.save_tasks(p, [])
    assert not p.exists()
