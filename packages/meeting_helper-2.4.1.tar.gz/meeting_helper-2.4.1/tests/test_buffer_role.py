"""SentenceBuffer.role attribute + broadcast plumbing."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from meeting_helper.buffer import SentenceBuffer


def test_default_role_is_self():
    assert SentenceBuffer().role == "self"


def test_explicit_role_other():
    assert SentenceBuffer(role="other").role == "other"


def test_invalid_role_raises():
    with pytest.raises(ValueError):
        SentenceBuffer(role="bystander")


@pytest.mark.asyncio
async def test_broadcast_transcript_includes_role():
    from meeting_helper.audio.transcriber import DeepgramTranscriber
    payloads: list[dict] = []

    async def fake_broadcast(payload: dict) -> None:
        payloads.append(payload)

    with patch("meeting_helper.server.websocket.broadcast", new=fake_broadcast):
        await DeepgramTranscriber._broadcast_transcript("hello", interim=False, role="other")

    assert payloads == [{"type": "transcript", "text": "hello", "interim": False, "role": "other"}]
