"""state.sentence_buffer property aliases self_buffer (back-compat)."""

from __future__ import annotations

from meeting_helper.state import AppState
from meeting_helper.buffer import SentenceBuffer


def test_sentence_buffer_returns_self_buffer():
    state = AppState()
    state.self_buffer = SentenceBuffer(role="self")
    assert state.sentence_buffer is state.self_buffer


def test_sentence_buffer_setter_updates_self_buffer():
    state = AppState()
    buf = SentenceBuffer(role="self")
    state.sentence_buffer = buf
    assert state.self_buffer is buf


def test_sentence_buffer_unset_returns_none():
    state = AppState()
    assert state.sentence_buffer is None
