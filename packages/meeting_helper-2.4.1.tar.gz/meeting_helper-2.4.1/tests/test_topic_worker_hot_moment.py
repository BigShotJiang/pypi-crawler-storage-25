"""Unit tests for TopicWorker buffer merging + Hot Moment gating."""

import time
from unittest.mock import MagicMock

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import state
from meeting_helper.topic_worker import TopicWorker


def _fresh_state():
    state.hot_moment_until = 0.0
    state.self_buffer = None
    state.other_buffer = None


def test_collect_window_hot_moment_off_uses_self_only():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("I'm checking ENGT-4147.")
    other_buf.append_final("What about ENGT-4212?")

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    roles = [role for role, _ in labeled]
    assert roles == ["self"]
    assert labeled[0][1] == "I'm checking ENGT-4147."


def test_collect_window_hot_moment_on_merges_chronologically():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("First me line.")
    time.sleep(0.005)
    other_buf.append_final("First other line.")
    time.sleep(0.005)
    self_buf.append_final("Second me line.")
    time.sleep(0.005)
    other_buf.append_final("Second other line.")

    state.arm_hot_moment(window_sec=60.0)

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    assert labeled == [
        ("self", "First me line."),
        ("other", "First other line."),
        ("self", "Second me line."),
        ("other", "Second other line."),
    ]


def test_collect_window_respects_n_cap_after_merge():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    for i in range(5):
        self_buf.append_final(f"me {i}")
        time.sleep(0.001)
        other_buf.append_final(f"other {i}")
        time.sleep(0.001)

    state.arm_hot_moment(window_sec=60.0)

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=4)

    assert len(labeled) == 4
    assert labeled[-1] == ("other", "other 4")
    assert labeled[-2] == ("self", "me 4")


def test_collect_window_hot_moment_off_ignores_other_even_if_other_is_more_recent():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("Older me line.")
    time.sleep(0.005)
    other_buf.append_final("Newer other line — should be ignored when OFF.")

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    assert all(role == "self" for role, _ in labeled)
    assert labeled[-1][1] == "Older me line."
