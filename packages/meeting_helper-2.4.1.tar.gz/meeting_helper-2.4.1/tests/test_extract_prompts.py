from meeting_helper.ai.prompts import (
    EXTRACT_TASKS_SYSTEM_PROMPT,
    build_extract_tasks_user_message,
)


def test_system_prompt_mentions_json_and_dedupe():
    assert "JSON" in EXTRACT_TASKS_SYSTEM_PROMPT
    assert "tasks" in EXTRACT_TASKS_SYSTEM_PROMPT
    assert (
        "skip" in EXTRACT_TASKS_SYSTEM_PROMPT.lower()
        or "dedup" in EXTRACT_TASKS_SYSTEM_PROMPT.lower()
    )


def test_user_message_includes_transcript_and_existing():
    msg = build_extract_tasks_user_message(
        transcript="Alice will send the report. Bob will review it.",
        existing_task_titles=["Send report"],
    )
    assert "Alice will send the report" in msg
    assert "Send report" in msg


def test_user_message_handles_no_existing():
    msg = build_extract_tasks_user_message(
        transcript="Only do X.", existing_task_titles=[]
    )
    assert "Only do X." in msg
    assert msg.strip() != ""
