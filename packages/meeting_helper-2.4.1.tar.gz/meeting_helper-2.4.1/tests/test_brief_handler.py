"""POST /brief calls my_active_tasks → Haiku → returns {script, cards}."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
async def test_brief_handler_assembles_script_and_cards(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    fake_local_todo = MagicMock()
    fake_local_todo.my_active_tasks = AsyncMock(return_value=[
        {"id": "PROJ-123", "title": "Refresh tokens", "status": "in_progress", "board_id": 2},
        {"id": "PROJ-119", "title": "OAuth refactor", "status": "done", "board_id": 2},
    ])
    fake_local_todo.get = AsyncMock(side_effect=[
        {"id": "PROJ-119", "title": "OAuth refactor", "status": "done"},
        {"id": "PROJ-123", "title": "Refresh tokens", "status": "in_progress", "sprint": "W17"},
    ])

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": "Yesterday I finished OAuth.\nToday I'm on refresh tokens.",
        "card_ids": ["PROJ-119", "PROJ-123"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *args, **kwargs):
            self.messages = FakeMessages()

    global_state.local_todo = fake_local_todo

    class FakeConfig:
        anthropic_api_key = "test-key"
        max_tokens = 800

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(app)
        resp = await client.post("/brief")
        assert resp.status == 200
        body = await resp.json()
        assert "Yesterday I finished OAuth" in body["script"]
        assert len(body["cards"]) == 2
        ids = [c["id"] for c in body["cards"]]
        assert "PROJ-119" in ids
        assert "PROJ-123" in ids


@pytest.mark.asyncio
async def test_brief_handler_returns_503_when_local_todo_unconfigured(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.local_todo = None
    class FakeConfig: anthropic_api_key = "test-key"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.post("/brief")
    assert resp.status == 503


@pytest.mark.asyncio
async def test_last_cards_handler_returns_state_cards(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.last_cards = [
        {"kind": "task", "id": "PROJ-9", "title": "Test", "status": "open"}
    ]

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/last_cards")
    assert resp.status == 200
    body = await resp.json()
    assert body["items"][0]["id"] == "PROJ-9"

    # Reset for other tests
    global_state.last_cards = []


@pytest.mark.asyncio
async def test_last_cards_handler_returns_empty_when_unset(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.last_cards = []

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/last_cards")
    body = await resp.json()
    assert body["items"] == []


@pytest.mark.asyncio
async def test_brief_seeds_warm_cache(aiohttp_client):
    """After /brief succeeds, state.current_topic + state.current_topic_cards
    + state.self_buffer are populated so subsequent queries are grounded."""
    import json
    from unittest.mock import AsyncMock, MagicMock, patch
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state
    from meeting_helper.buffer import SentenceBuffer

    fake_local_todo = MagicMock()
    fake_local_todo.my_active_tasks = AsyncMock(return_value=[
        {"id": "ENGT-4212", "title": "Frontend contract layer", "status": "in_progress", "board_id": 2},
        {"id": "ENGT-4147", "title": "Status remapper", "status": "done", "board_id": 2},
    ])
    fake_local_todo.get = AsyncMock(side_effect=[
        {"id": "ENGT-4212", "title": "Frontend contract layer", "status": "in_progress"},
        {"id": "ENGT-4147", "title": "Status remapper", "status": "done"},
    ])

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": (
            "**Today**\n"
            "- I'm working on ENGT-4212 Phase 2 — Frontend contract layer + feature flag (PR #3635, draft).\n"
            "**Yesterday**\n"
            "- I finished ENGT-4147 — Status remapper: accept numeric severity values."
        ),
        "card_ids": ["ENGT-4212", "ENGT-4147"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *a, **k):
            self.messages = FakeMessages()

    global_state.local_todo = fake_local_todo
    global_state.self_buffer = SentenceBuffer(role="self")
    global_state.other_buffer = SentenceBuffer(role="other")
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []

    class FakeConfig:
        anthropic_api_key = "test"
        max_tokens = 800

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(app)
        resp = await client.post("/brief")
        assert resp.status == 200

    # current_topic seeded
    assert "ENGT-4212" in global_state.current_topic["ticket_ids"]
    assert "ENGT-4147" in global_state.current_topic["ticket_ids"]
    assert "frontend contract layer" in global_state.current_topic["topic"].lower() or \
           "ENGT-4212" in global_state.current_topic["last_user_statement"]
    assert global_state.current_topic["last_user_statement"].startswith("I'm working on ENGT-4212")

    # current_topic_cards seeded from brief cards
    assert len(global_state.current_topic_cards) == 2
    assert any(c["id"] == "ENGT-4212" for c in global_state.current_topic_cards)

    # self_buffer received both bullet sentences
    self_sentences = global_state.self_buffer.get_last_n()
    assert any("ENGT-4212" in s for s in self_sentences)
    assert any("ENGT-4147" in s for s in self_sentences)

    # Reset
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []
    global_state.self_buffer = None
    global_state.other_buffer = None


@pytest.mark.asyncio
async def test_debug_say_injects_into_self_buffer(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state
    from meeting_helper.buffer import SentenceBuffer

    global_state.self_buffer = SentenceBuffer(role="self")
    global_state.other_buffer = SentenceBuffer(role="other")

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.post("/debug/say", json={"text": "I finished the auth refactor.", "role": "self"})
    assert resp.status == 200
    assert "I finished the auth refactor." in global_state.self_buffer.get_last_n()

    resp = await client.post("/debug/say", json={"text": "what about edge cases?", "role": "other"})
    assert resp.status == 200
    assert "what about edge cases?" in global_state.other_buffer.get_last_n()

    # Bad role
    resp = await client.post("/debug/say", json={"text": "test", "role": "bystander"})
    assert resp.status == 400

    # Empty text
    resp = await client.post("/debug/say", json={"text": "  ", "role": "self"})
    assert resp.status == 400

    # Reset
    global_state.self_buffer = None
    global_state.other_buffer = None
