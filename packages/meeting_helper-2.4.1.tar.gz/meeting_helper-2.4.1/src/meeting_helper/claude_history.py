"""Read past Claude Code conversations from ~/.claude/projects/*.jsonl.

Used to attach a prior Claude Code conversation as primary context for the
in-meeting AI agent. The user picks a conversation in the overlay; the
reconstructed text is injected via build_system_prompt() while a meeting
is active.

On-disk layout (Claude Code stores history per workspace cwd):
    ~/.claude/projects/<encoded-cwd>/<sessionId>.jsonl
where <encoded-cwd> is the absolute repo path with every '/' replaced by '-'.
Each line is a JSON record. We only care about user/assistant text turns and
the optional ai-title record (which provides the human-readable name shown
in `claude --resume`).
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Lines bigger than this trigger tail-read to avoid loading the whole file.
LARGE_FILE_BYTES = 25_000_000  # 25 MB
TAIL_READ_BYTES = 4_000_000    # last 4 MB is plenty for "recent turns"

# Strip ASCII control chars (except \t \n \r) from titles before display.
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# These XML-ish wrappers wrap meta/command output, not real user input.
# We skip them when picking a fallback title so the picker shows something useful.
# Note: <command-name> is handled specially — we extract the slash-command name
# from inside it (so e.g. "/login" sessions title as "/login" like Claude Code does).
_META_PREFIXES = (
    "<local-command-",
    "<command-message>",
    "<command-args>",
    "<command-stdout>",
    "<command-stderr>",
    "<system-reminder>",
    "<bash-stdout>",
    "<bash-stderr>",
    "Caveat:",
)

_CMD_NAME_RE = re.compile(r"<command-name>([^<]+)</command-name>")

# Specific pattern for detecting user/assistant turn lines without JSON parsing.
# Much tighter than '"user"' in raw, which also matches conversation text content.
_TURN_TYPE_RE = re.compile(r'"type"\s*:\s*"(user|assistant)"')

# Files above this threshold use head+tail scanning instead of full read.
_FAST_SCAN_BYTES = 500_000   # 500 KB
_HEAD_LINES = 200            # lines from start for title candidates
_TITLE_TAIL_BYTES = 50_000   # bytes from end for last-prompt lookup


def _is_meta_text(text: str) -> bool:
    stripped = text.lstrip()
    return any(stripped.startswith(p) for p in _META_PREFIXES)


def _extract_command_name(text: str) -> Optional[str]:
    """Pull 'X' out of a '<command-name>X</command-name>' wrapper, if present."""
    m = _CMD_NAME_RE.search(text)
    if m:
        name = m.group(1).strip()
        return name or None
    return None


def _pick_user_title_text(text: str) -> Optional[str]:
    """Given a user message's flattened text, return what should become the title.

    Priority:
      1. If it wraps a slash command (<command-name>X</command-name>), return X.
      2. If it is pure meta (caveats, stdout, system reminders), return None
         so the caller keeps looking.
      3. Otherwise return the text itself.
    """
    if not text:
        return None
    cmd = _extract_command_name(text)
    if cmd:
        return cmd
    if _is_meta_text(text):
        return None
    return text


def encode_cwd(repo_path: str) -> str:
    """/Users/victor/.../meeting-helper -> -Users-victor-...-meeting-helper.

    Mirrors the encoding Claude Code uses for ~/.claude/projects/ folder names.
    """
    resolved = str(Path(repo_path).expanduser().resolve())
    return resolved.replace("/", "-")


def projects_dir() -> Path:
    return Path.home() / ".claude" / "projects"


def repo_history_dir(repo_path: str) -> Path:
    return projects_dir() / encode_cwd(repo_path)


# ---------------------------------------------------------------------------
# Listing
# ---------------------------------------------------------------------------

def list_conversations(repo_path: str, limit: int = 50) -> list[dict]:
    """Return [{session_id, title, mtime, msg_count, path}] for a repo.

    Sorted by file mtime descending (most recent first). Returns [] if there
    is no Claude Code history folder for this repo.
    """
    folder = repo_history_dir(repo_path)
    if not folder.is_dir():
        return []

    out: list[dict] = []
    try:
        # Cache stat() results: sort needs mtime, and we reuse it in the dict.
        file_stats = [(f, f.stat()) for f in folder.glob("*.jsonl")]
        file_stats.sort(key=lambda x: x[1].st_mtime, reverse=True)
    except OSError as exc:
        logger.warning("list_conversations: cannot scan %s: %s", folder, exc)
        return []

    for f, st in file_stats[:limit]:
        try:
            title, msg_count = _extract_title_and_count(f)
        except Exception as exc:
            logger.debug("list_conversations: skipping %s: %s", f.name, exc)
            continue
        out.append({
            "session_id": f.stem,
            "title": _clean_title(title),
            "mtime": st.st_mtime,
            "msg_count": msg_count,
            "path": str(f),
        })
    return out


def _extract_title_and_count(jsonl_path: Path) -> tuple[str, int]:
    """Derive the display title + message count for a conversation file.

    Title resolution order (matches Claude Code's /resume picker):
      1. `custom-title` record's `customTitle` field
      2. Latest `last-prompt` record's `lastPrompt` field
      3. `ai-title` record's `aiTitle` field
      4. First non-meta user message text (with `<command-name>X</command-name>`
         unwrapped to just `X`)

    For large files (>500 KB), only the head and tail are read and msg_count
    is estimated from file size to avoid multi-second full-file scans.
    """
    try:
        file_size = jsonl_path.stat().st_size
    except OSError:
        file_size = 0

    if file_size > _FAST_SCAN_BYTES:
        return _extract_title_and_count_fast(jsonl_path, file_size)

    # Small file: full scan with optimised turn detection.
    custom_title: str | None = None
    last_prompt: str | None = None
    ai_title: str | None = None
    first_user: str | None = None
    msg_count = 0

    with jsonl_path.open("r", encoding="utf-8", errors="replace") as fh:
        for raw in fh:
            if not raw.strip():
                continue
            # Title-metadata lines — rare, always worth a json.loads().
            is_meta_line = (
                '"custom-title"' in raw
                or '"last-prompt"' in raw
                or '"ai-title"' in raw
            )
            if is_meta_line:
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                rtype = rec.get("type")
                if rtype == "custom-title":
                    if custom_title is None:
                        ct = rec.get("customTitle")
                        if ct:
                            custom_title = ct
                elif rtype == "last-prompt":
                    lp = rec.get("lastPrompt")
                    if lp:
                        last_prompt = lp  # always take the most recent
                elif rtype == "ai-title":
                    if ai_title is None:
                        at = rec.get("aiTitle")
                        if at:
                            ai_title = at
                continue

            # Count user/assistant turns via regex — avoids json.loads()
            # on the thousands of lines whose *text* happens to contain
            # the words "user" or "assistant".
            m = _TURN_TYPE_RE.search(raw)
            if not m:
                continue
            msg_count += 1
            # Only JSON-parse the *first* user turn for fallback title.
            if first_user is None and m.group(1) == "user":
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                text = _flatten_text(rec.get("message", {}).get("content"))
                picked = _pick_user_title_text(text)
                if picked:
                    first_user = picked

    title = _resolve_title(custom_title, last_prompt, ai_title, first_user, jsonl_path.stem)
    return title, msg_count


def _extract_title_and_count_fast(
    jsonl_path: Path, file_size: int,
) -> tuple[str, int]:
    """Head+tail scan for large files — avoids reading the entire file.

    Reads the first _HEAD_LINES lines for title candidates (custom-title,
    ai-title, first user message) and the last _TITLE_TAIL_BYTES for the
    most recent last-prompt record.  msg_count is estimated from file size.
    """
    custom_title: str | None = None
    ai_title: str | None = None
    first_user: str | None = None

    # --- Head scan --------------------------------------------------------
    with jsonl_path.open("r", encoding="utf-8", errors="replace") as fh:
        for i, raw in enumerate(fh):
            if i >= _HEAD_LINES:
                break
            if not raw.strip():
                continue
            if '"custom-title"' in raw and custom_title is None:
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if rec.get("type") == "custom-title":
                    ct = rec.get("customTitle")
                    if ct:
                        custom_title = ct
                continue
            if '"ai-title"' in raw and ai_title is None:
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if rec.get("type") == "ai-title":
                    at = rec.get("aiTitle")
                    if at:
                        ai_title = at
                continue
            if first_user is None:
                m = _TURN_TYPE_RE.search(raw)
                if m and m.group(1) == "user":
                    try:
                        rec = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    text = _flatten_text(rec.get("message", {}).get("content"))
                    picked = _pick_user_title_text(text)
                    if picked:
                        first_user = picked

    # --- Tail scan for last-prompt (and custom-title if not in head) ------
    last_prompt: str | None = None
    if custom_title is None:
        for raw in reversed(_tail_lines(jsonl_path, _TITLE_TAIL_BYTES)):
            if last_prompt is None and '"last-prompt"' in raw:
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if rec.get("type") == "last-prompt":
                    lp = rec.get("lastPrompt")
                    if lp:
                        last_prompt = lp
            if custom_title is None and '"custom-title"' in raw:
                try:
                    rec = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if rec.get("type") == "custom-title":
                    ct = rec.get("customTitle")
                    if ct:
                        custom_title = ct
            if custom_title is not None and last_prompt is not None:
                break

    # Rough estimate: typical JSONL turn record is ~3 KB on average.
    msg_count = max(1, file_size // 3000)

    title = _resolve_title(
        custom_title, last_prompt, ai_title, first_user, jsonl_path.stem,
    )
    return title, msg_count


def _flatten_text(content) -> str:
    """Extract plain text from a Claude message content field.

    `content` can be a string (older format) or a list of blocks. We keep only
    blocks where type == 'text' and join them.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") != "text":
            continue
        text = block.get("text") or ""
        if text:
            parts.append(text)
    return "\n".join(parts).strip()


def _clean_title(title: str) -> str:
    return _CTRL_RE.sub("", title).strip() or "Untitled"


def _resolve_title(
    custom_title: str | None,
    last_prompt: str | None,
    ai_title: str | None,
    first_user: str | None,
    fallback_id: str,
) -> str:
    """Pick the best display title following Claude Code's /resume priority."""
    return custom_title or last_prompt or ai_title or first_user or f"Untitled ({fallback_id[:8]})"


# ---------------------------------------------------------------------------
# Reconstruction
# ---------------------------------------------------------------------------

def reconstruct_conversation(
    repo_path: str,
    session_id: str,
    max_chars: int = 120_000,
) -> dict:
    """Read a session JSONL and return a reconstructed conversation block.

    Returns {session_id, title, repo, body, chars, truncated, turn_count}.
    Keeps only user/assistant text turns. If the resulting text exceeds
    max_chars, walks from the end accumulating chars until the cap is hit
    so the most recent turns are preserved.
    """
    folder = repo_history_dir(repo_path)
    path = folder / f"{session_id}.jsonl"
    if not path.is_file():
        raise FileNotFoundError(f"No conversation file for {session_id} in {folder}")

    # For huge files, read only the tail. This is correct because we want
    # the most recent turns anyway.
    try:
        size = path.stat().st_size
    except OSError:
        size = 0
    if size > LARGE_FILE_BYTES:
        raw_lines = _tail_lines(path, TAIL_READ_BYTES)
    else:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            raw_lines = fh.readlines()

    custom_title: str | None = None
    last_prompt: str | None = None
    ai_title: str | None = None
    turns: list[dict] = []
    for raw in raw_lines:
        if not raw.strip():
            continue
        # Cheap title hunt — only do JSON parse for lines that might matter.
        if (
            '"custom-title"' in raw
            or '"last-prompt"' in raw
            or '"ai-title"' in raw
        ):
            try:
                rec = json.loads(raw)
            except json.JSONDecodeError:
                rec = None
            if rec is not None:
                rtype = rec.get("type")
                if rtype == "custom-title" and custom_title is None:
                    ct = rec.get("customTitle")
                    if ct:
                        custom_title = ct
                    continue
                if rtype == "last-prompt":
                    lp = rec.get("lastPrompt")
                    if lp:
                        last_prompt = lp  # keep the most recent
                    continue
                if rtype == "ai-title" and ai_title is None:
                    at = rec.get("aiTitle")
                    if at:
                        ai_title = at
                    continue
        turn = _line_to_turn(raw)
        if turn is not None:
            turns.append(turn)

    first_user: str | None = None
    for t in turns:
        if t["role"] != "user":
            continue
        picked = _pick_user_title_text(t["text"])
        if picked:
            first_user = picked
            break
    title = _clean_title(
        _resolve_title(custom_title, last_prompt, ai_title, first_user, session_id)
    )

    # Build the body keeping the most recent turns within max_chars.
    body, truncated = _render_turns(turns, max_chars)

    return {
        "session_id": session_id,
        "title": title,
        "repo": str(Path(repo_path).expanduser().resolve()),
        "body": body,
        "chars": len(body),
        "truncated": truncated,
        "turn_count": len(turns),
    }


def _line_to_turn(raw_line: str) -> Optional[dict]:
    """Parse a JSONL line into a simplified turn, or None if not a text turn.

    Tolerates a truncated last line (Claude Code may still be writing).
    """
    if '"user"' not in raw_line and '"assistant"' not in raw_line:
        return None
    try:
        rec = json.loads(raw_line)
    except json.JSONDecodeError:
        return None
    rtype = rec.get("type")
    if rtype not in ("user", "assistant"):
        return None
    msg = rec.get("message") or {}
    text = _flatten_text(msg.get("content"))
    if not text:
        return None
    return {"role": rtype, "text": text, "ts": rec.get("timestamp", "")}


def _render_turns(turns: list[dict], max_chars: int) -> tuple[str, bool]:
    """Render turns as markdown, keeping the most recent ones within max_chars."""
    rendered: list[str] = []
    for t in turns:
        header = "## User" if t["role"] == "user" else "## Assistant"
        rendered.append(f"{header}\n{t['text']}\n")

    if not rendered:
        return "", False

    # Walk from the end, accumulate until cap.
    kept_rev: list[str] = []
    total = 0
    truncated = False
    for block in reversed(rendered):
        if total + len(block) + 2 > max_chars and kept_rev:
            truncated = True
            break
        kept_rev.append(block)
        total += len(block) + 2
    kept = list(reversed(kept_rev))

    body = "\n".join(kept)
    if truncated:
        omitted = len(rendered) - len(kept)
        notice = (
            f"[…earlier turns omitted, showing last {len(kept)} of {len(rendered)}…]\n\n"
        )
        body = notice + body
    return body, truncated


# ---------------------------------------------------------------------------
# Tail-read for huge files
# ---------------------------------------------------------------------------

def _tail_lines(path: Path, n_bytes: int) -> list[str]:
    """Read the last n_bytes of a file and return complete lines.

    Discards the first (likely partial) line so we never feed a corrupted
    half-record to the parser.
    """
    with path.open("rb") as fh:
        try:
            fh.seek(max(0, path.stat().st_size - n_bytes))
        except OSError:
            return []
        chunk = fh.read()
    text = chunk.decode("utf-8", errors="replace")
    lines = text.splitlines(keepends=True)
    if len(lines) <= 1:
        return lines
    return lines[1:]  # drop first (potentially partial) line


# ---------------------------------------------------------------------------
# Display helpers (used by overlay picker)
# ---------------------------------------------------------------------------

def relative_time(epoch: float) -> str:
    """Human-readable 'X minutes ago' for a unix timestamp."""
    if not epoch:
        return ""
    now = datetime.now(tz=timezone.utc).timestamp()
    delta = max(0, now - epoch)
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta // 60)}m ago"
    if delta < 86400:
        return f"{int(delta // 3600)}h ago"
    if delta < 86400 * 7:
        return f"{int(delta // 86400)}d ago"
    if delta < 86400 * 30:
        return f"{int(delta // (86400 * 7))}w ago"
    return datetime.fromtimestamp(epoch).strftime("%Y-%m-%d")
