"""Screen Recording / TCC permission recovery helpers (macOS).

Why this exists: on company-managed laptops, Screen Recording permission
sometimes 'silently breaks' — the OS still says it's granted in System
Settings, but ScreenCaptureKit no longer produces samples. The daemon
captures mic audio fine but `_system_capture` returns nothing. The only
known reliable fix today is a full reboot.

This module provides a faster recovery path:

  1. Check whether the permission is even granted (so we don't waste effort).
  2. Restart the daemon process (cheapest fix — works when the SCK session
     itself is wedged inside our process but the OS state is healthy).
  3. (Optional, asks for sudo) restart `tccd` and `coreaudiod` — the OS
     daemons that own permission state and audio routing. Often un-wedges
     a bad cached state without requiring a reboot.
  4. Open the Screen Recording settings pane as a last-resort hint.

All shell-outs are best-effort: failures are logged but don't crash the
caller. The flow is: do what we can without sudo, then offer the sudo
nudge if the user opts in.
"""

from __future__ import annotations

import logging
import os
import shlex
import shutil
import subprocess
import time
from typing import Optional

logger = logging.getLogger(__name__)


SETTINGS_URL = (
    "x-apple.systempreferences:com.apple.preference.security?"
    "Privacy_ScreenCapture"
)


def is_macos() -> bool:
    """True when running on Darwin. Recovery is only meaningful on macOS."""
    import sys
    return sys.platform == "darwin"


def open_screen_recording_settings() -> bool:
    """Open System Settings → Privacy & Security → Screen Recording.

    Returns True if the open command was launched successfully.
    """
    if not is_macos():
        return False
    try:
        subprocess.Popen(
            ["open", SETTINGS_URL],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except Exception as exc:
        logger.warning("open settings failed: %s", exc)
        return False


def screen_recording_status() -> str:
    """Return a coarse status string for the Screen Recording permission.

    Best-effort: macOS does not expose a programmatic 'is granted?' API
    for Screen Recording outside of attempting to capture. We use a simple
    heuristic: try to enumerate windows via `CGWindowListCopyWindowInfo`
    with `kCGWindowListOptionOnScreenOnly`. Without permission, this still
    returns *something* but window names/owners are missing.

    Returns one of: "granted", "denied", "unknown".
    """
    if not is_macos():
        return "unknown"
    try:
        import Quartz  # type: ignore
        opts = (
            Quartz.kCGWindowListOptionOnScreenOnly
            | Quartz.kCGWindowListExcludeDesktopElements
        )
        windows = Quartz.CGWindowListCopyWindowInfo(opts, Quartz.kCGNullWindowID)
        if not windows:
            return "unknown"
        # When permission is denied, owner/name fields tend to be empty for
        # most windows. With permission, at least some windows expose names.
        named = sum(1 for w in windows if w.get("kCGWindowName"))
        if named >= 2:
            return "granted"
        return "denied"
    except Exception as exc:
        logger.warning("screen_recording_status check failed: %s", exc)
        return "unknown"


def _run(cmd: list[str], *, timeout: float = 10.0) -> tuple[int, str, str]:
    """Run a command and return (returncode, stdout, stderr) — never raises."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timed out"
    except Exception as exc:
        return 1, "", str(exc)


def restart_tcc() -> tuple[bool, str]:
    """Restart the TCC daemon (`tccd`).

    Requires sudo on most macOS versions. Best-effort. Returns (ok, message).
    On corporate-managed laptops, sudo may itself be locked down — in that
    case this is a clear "you need IT" signal.
    """
    if not is_macos():
        return False, "not macOS"
    if shutil.which("sudo") is None:
        return False, "sudo not available"
    code, out, err = _run(["sudo", "-n", "killall", "tccd"], timeout=5.0)
    if code == 0:
        return True, "tccd restarted"
    # `sudo -n` failed: needs an interactive password.
    return False, f"sudo required (rc={code}): {err.strip() or out.strip()}"


def restart_coreaudio() -> tuple[bool, str]:
    """Restart the CoreAudio daemon. Same caveats as restart_tcc()."""
    if not is_macos():
        return False, "not macOS"
    if shutil.which("sudo") is None:
        return False, "sudo not available"
    code, out, err = _run(["sudo", "-n", "killall", "coreaudiod"], timeout=5.0)
    if code == 0:
        return True, "coreaudiod restarted"
    return False, f"sudo required (rc={code}): {err.strip() or out.strip()}"


def restart_tcc_and_coreaudio_interactive() -> dict:
    """Run the sudo restarts in interactive mode (asks for password once).

    Restarts three daemons that together own screen-recording / audio capture:
      - tccd        — permission consent / cache
      - coreaudiod  — audio routing
      - replayd     — ScreenCaptureKit's underlying capture service (often
                      the actual culprit when SCK initialization hangs)

    Returns a dict {tccd, coreaudiod, replayd, message}. The user must run
    this from an interactive terminal — sudo will prompt for password.
    """
    out: dict = {
        "tccd": False, "coreaudiod": False, "replayd": False, "message": "",
    }
    if not is_macos():
        out["message"] = "not macOS"
        return out
    # Single sudo call so the password is asked once. `|| true` so a failure
    # to find one daemon (e.g. replayd not running on older macOS) doesn't
    # abort the others.
    code, _stdout, stderr = _run(
        [
            "sudo", "sh", "-c",
            "killall tccd 2>/dev/null || true; "
            "killall coreaudiod 2>/dev/null || true; "
            "killall replayd 2>/dev/null || true; "
            "exit 0",
        ],
        timeout=30.0,
    )
    if code == 0:
        # We can't tell from the combined exit code whether each individual
        # killall succeeded, but the daemons auto-restart via launchd so
        # this is best-effort. Mark all three as "attempted".
        out["tccd"] = True
        out["coreaudiod"] = True
        out["replayd"] = True
        out["message"] = "tccd + coreaudiod + replayd restarted (best-effort)"
    else:
        out["message"] = f"sudo failed (rc={code}): {stderr.strip()}"
    return out


def probe_sck(timeout: float = 3.0) -> str:
    """Probe whether ScreenCaptureKit's getShareableContent works.

    Calls SCShareableContent with a strict timeout. Returns one of:
      "ok"           — completion handler fired with content
      "timeout"      — handler never called within timeout (the daemon-stuck
                       case — SCK service is wedged)
      "error:<msg>"  — handler fired with a non-nil error
      "no_content"   — handler fired but returned empty
      "unavailable"  — SCK module not importable (not macOS or PyObjC missing)

    This is the most reliable signal we have for "is screen capture
    actually going to work?" — far more accurate than the CGWindowList
    heuristic in screen_recording_status().
    """
    if not is_macos():
        return "unavailable"
    try:
        import threading
        import ScreenCaptureKit as SCK  # type: ignore
    except ImportError as exc:
        logger.warning("probe_sck: SCK not importable: %s", exc)
        return "unavailable"

    ready = threading.Event()
    result: list = [None, None]  # [content, error]

    def _on_content(content, error):
        result[0] = content
        result[1] = error
        ready.set()

    try:
        SCK.SCShareableContent.getShareableContentWithCompletionHandler_(_on_content)
    except Exception as exc:
        return f"error:{exc}"

    if not ready.wait(timeout=timeout):
        return "timeout"
    if result[1] is not None:
        return f"error:{result[1]}"
    if result[0] is None:
        return "no_content"
    return "ok"


def userspace_reboot_interactive() -> tuple[bool, str]:
    """Run `sudo launchctl reboot userspace` after warning the user.

    Restarts the user session (all GUI apps close + relaunch) WITHOUT
    rebooting the kernel. Takes ~10 seconds. Often unwedges user-space
    daemons that survived `killall`. Caller is responsible for asking
    confirmation BEFORE calling this — this function just runs the command.

    Returns (ok, message). On success, this process WILL be killed by the
    user-session restart shortly after the function returns.
    """
    if not is_macos():
        return False, "not macOS"
    if shutil.which("sudo") is None:
        return False, "sudo not available"
    code, _out, err = _run(
        ["sudo", "launchctl", "reboot", "userspace"],
        timeout=20.0,
    )
    if code == 0:
        return True, "userspace reboot initiated — session will restart in seconds"
    return False, f"launchctl rc={code}: {err.strip() or 'unknown error'}"


def collect_diagnostics() -> dict:
    """Gather everything we can to diagnose a stuck SCK. Returns a dict
    of named sections — the caller dumps to stdout.

    Sections:
      - python:           sys.executable, version, pid
      - bundle:           PyObjC bundle id + main bundle path
      - permission:       Quartz heuristic + SCK probe outcome
      - sck_log:          last 30s of unified log filtered to SCK / replayd
      - daemon_processes: are tccd / coreaudiod / replayd / WindowServer alive?
    """
    import os as _os
    import sys as _sys
    out: dict = {}

    out["python"] = {
        "executable": _sys.executable,
        "version": _sys.version.split()[0],
        "pid": _os.getpid(),
        "platform": _sys.platform,
    }

    # Bundle identity — what macOS attributes our SCK request to
    bundle_info: dict = {}
    if is_macos():
        try:
            from Foundation import NSBundle  # type: ignore
            bundle = NSBundle.mainBundle()
            bundle_info["bundle_id"] = str(bundle.bundleIdentifier() or "(none)")
            bundle_info["bundle_path"] = str(bundle.bundlePath() or "(none)")
            info = bundle.infoDictionary() or {}
            bundle_info["bundle_name"] = str(info.get("CFBundleName", "(none)"))
        except Exception as exc:
            bundle_info["error"] = str(exc)
    out["bundle"] = bundle_info

    # Permission heuristic + actual probe
    out["permission"] = {
        "quartz_heuristic": screen_recording_status(),
        "sck_probe": probe_sck(timeout=4.0),
    }

    # Daemon liveness — are the OS daemons we depend on actually running?
    daemons = ("tccd", "coreaudiod", "replayd", "WindowServer", "controlcenter")
    proc_state: dict = {}
    if is_macos():
        for d in daemons:
            code, _stdout, _stderr = _run(["pgrep", "-x", d], timeout=3.0)
            proc_state[d] = "running" if code == 0 else "not-running"
    out["daemon_processes"] = proc_state

    # macOS unified-log scrape — last 30s of SCK / replayd / TCC traffic.
    # `log show` is non-privileged.
    sck_log = ""
    if is_macos():
        code, stdout, _stderr = _run(
            [
                "log", "show",
                "--last", "30s",
                "--style", "compact",
                "--predicate",
                "(subsystem == 'com.apple.screencapturekit') "
                "OR (subsystem == 'com.apple.replayd') "
                "OR (subsystem == 'com.apple.TCC') "
                "OR (process == 'replayd') "
                "OR (process == 'tccd')",
            ],
            timeout=15.0,
        )
        if code == 0 and stdout:
            # Trim — last 60 lines, that's enough signal
            lines = stdout.strip().splitlines()
            sck_log = "\n".join(lines[-60:])
        else:
            sck_log = "(log show returned no output or failed)"
    out["sck_log"] = sck_log

    return out


def reset_app_screen_recording(bundle_id: str) -> tuple[bool, str]:
    """Use `tccutil reset ScreenCapture <bundle>` to clear a specific app's
    grant. The user must re-grant after running this. Use only when the
    permission state itself is broken; usually unnecessary."""
    if not is_macos():
        return False, "not macOS"
    if shutil.which("tccutil") is None:
        return False, "tccutil not available"
    code, out, err = _run(
        ["tccutil", "reset", "ScreenCapture", bundle_id],
        timeout=5.0,
    )
    if code == 0:
        return True, f"reset ScreenCapture for {bundle_id}"
    return False, f"tccutil rc={code}: {err.strip() or out.strip()}"
