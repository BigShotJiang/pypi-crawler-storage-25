"""AI client: real-time queries (Claude or Ollama), post-meeting transcription & summarization."""

from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState

logger = logging.getLogger(__name__)


def _format_cards_markdown(cards: list[dict]) -> str:
    """Render local-todo records as a compact Markdown block for the system prompt."""
    if not cards:
        return ""
    lines: list[str] = []
    for c in cards:
        cid = c.get("id", "?")
        title = c.get("title", "(untitled)")
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("sprint"):
            meta_parts.append(f"Sprint {c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        if c.get("updated_at"):
            meta_parts.append(f"Updated {c['updated_at']}")
        meta = " · ".join(meta_parts) if meta_parts else ""
        head = f"- [{cid}] {title}"
        if meta:
            head += f" — {meta}"
        lines.append(head)
        body = c.get("body") or c.get("description")
        if body:
            snippet = body.strip().replace("\n", " ")
            if len(snippet) > 280:
                snippet = snippet[:280] + "…"
            lines.append(f"  Body: {snippet}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Message assembly
# ---------------------------------------------------------------------------

def _extract_likely_question(
    timestamped_sentences: list[tuple[float, str, str]],
    cutoff_ts: float = 0.0,
) -> str:
    """Find the most recent unanswered question in the merged transcript.

    ``timestamped_sentences`` is a list of ``(ts, role, text)`` tuples sorted
    chronologically (oldest first). Only sentences with ``ts > cutoff_ts``
    are considered — this prevents us from re-extracting a question that
    already produced an AI answer (the previous query stamps the cutoff).

    Returns the most recent ``?``-terminated sentence after the cutoff.
    Returns ``""`` if no fresh question exists. The empty case is handled
    gracefully by ``_assemble_messages``, which substitutes a "answer about
    the topic" prompt fragment.
    """
    fresh = [(ts, txt) for ts, _role, txt in timestamped_sentences if ts > cutoff_ts]
    for _ts, txt in reversed(fresh):
        if txt.rstrip().endswith("?"):
            return txt.strip()
    return ""


def _collect_timestamped_sentences(
    state: "AppState",
    n_per_buffer: int,
) -> list[tuple[float, str, str]]:
    """Read the most recent ``n_per_buffer`` entries from each buffer and
    return a chronological merge as ``[(ts, role, text), ...]``.

    Reads the raw buffers (with timestamps) under their existing locks.
    """
    self_entries: list[tuple[float, str, str]] = []
    other_entries: list[tuple[float, str, str]] = []
    if state.self_buffer is not None:
        with state.self_buffer._lock:  # noqa: SLF001 — no public ts accessor today
            self_entries = [
                (e.timestamp, "self", e.text)
                for e in list(state.self_buffer._sentences)[-n_per_buffer:]
            ]
    if state.other_buffer is not None:
        with state.other_buffer._lock:  # noqa: SLF001
            other_entries = [
                (e.timestamp, "other", e.text)
                for e in list(state.other_buffer._sentences)[-n_per_buffer:]
            ]
    return sorted(self_entries + other_entries, key=lambda t: t[0])


def _assemble_messages(state: "AppState", config: "AppConfig") -> list:
    """Build the messages list with explicit, role-tagged context sections.

    Sections (in order):
      ## Topic just discussed         — from state.current_topic (TopicWorker)
      ## What I just said             — from state.self_buffer
      ## What others just said        — from state.other_buffer
      ## What was just asked          — explicit question (last '?' in either buffer)

    The AI prompt's "answer using these sections" rule pins the model to this
    structure, eliminating "I don't have enough context" responses.
    """
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    if not self_sentences and not other_sentences:
        content = "No transcript captured yet. The meeting may have just started."
    else:
        # Find the most recent NEW question across BOTH buffers, merged
        # chronologically. ``last_query_at`` filters out stale questions that
        # already produced an answer.
        timestamped = _collect_timestamped_sentences(state, n_per_buffer=8)
        question = _extract_likely_question(timestamped, cutoff_ts=state.last_query_at)
        # Stamp the cursor — anything earlier than now is "already considered"
        # for question extraction. Updated even when no `?` was found, so the
        # next call doesn't keep searching the same window.
        state.last_query_at = time.time()

        topic = state.current_topic or {}
        topic_lines: list[str] = []
        if topic.get("topic"):
            topic_lines.append(f"- Topic: {topic['topic']}")
        if topic.get("ticket_ids"):
            topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
        if topic.get("last_user_statement"):
            topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
        topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

        self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
        other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

        content = (
            "## Topic just discussed\n"
            f"{topic_block}\n\n"
            "## What I just said (first person, my own voice)\n"
            f"{self_block}\n\n"
            "## What others just said\n"
            f"{other_block}\n\n"
            "## What was just asked\n"
            f"{question or '(no explicit question — answer about the topic above)'}\n\n"
            "Answer the question above. Resolve all pronouns and fragments using the Topic and 'What I just said' sections. NEVER ask for clarification."
        )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    return messages


# ---------------------------------------------------------------------------
# Claude (Anthropic) streaming
# ---------------------------------------------------------------------------

async def _stream_claude(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Stream response from Claude. Returns full_text."""
    from meeting_helper.server.websocket import broadcast
    import anthropic
    import httpx

    if not config.anthropic_api_key:
        await broadcast({"type": "error", "message": "No Anthropic API key configured."})
        return ""

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    full_text = ""

    try:
        async with client.messages.stream(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=system_prompt,
            messages=messages,
        ) as stream:
            async for text_delta in stream.text_stream:
                full_text += text_delta
                await broadcast({"type": "chunk", "text": text_delta})
        return full_text

    except anthropic.AuthenticationError:
        msg = "Invalid Anthropic API key. Check your configuration."
        logger.error(msg)
        await broadcast({"type": "error", "message": msg})
        return ""

    except anthropic.BadRequestError as exc:
        if "token" in str(exc).lower():
            # Context too long — trim history and retry
            trimmed = len(state.conversation_history)
            half = max(2, len(state.conversation_history) // 2)
            state.conversation_history = state.conversation_history[half:]
            logger.warning("Context too long (%d entries) — trimmed to %d, retrying",
                           trimmed, len(state.conversation_history))

            await broadcast({"type": "start"})
            messages_retry = list(state.conversation_history)
            messages_retry.append(messages[-1])  # re-append current user turn
            try:
                full_text = ""
                async with client.messages.stream(
                    model=config.claude_model,
                    max_tokens=config.max_tokens,
                    system=system_prompt,
                    messages=messages_retry,
                ) as stream:
                    async for text_delta in stream.text_stream:
                        full_text += text_delta
                        await broadcast({"type": "chunk", "text": text_delta})
                return full_text
            except Exception as retry_exc:
                logger.error("Retry after trim failed: %s", retry_exc)
                await broadcast({"type": "error", "message": f"Failed after trimming: {retry_exc}"})
                return ""
        else:
            logger.error("Bad request: %s", exc)
            await broadcast({"type": "error", "message": f"Bad request: {exc}"})
            return ""

    except anthropic.APIConnectionError as exc:
        logger.error("Connection error: %s", exc)
        await broadcast({"type": "error", "message": f"Connection error: {exc}"})
        return ""

    except Exception as exc:
        logger.error("Unexpected error: %s", exc)
        await broadcast({"type": "error", "message": f"Unexpected error: {exc}"})
        return ""


# ---------------------------------------------------------------------------
# Gemini (Google) streaming
# ---------------------------------------------------------------------------

def _messages_to_gemini_contents(messages: list) -> list:
    """Convert internal message format to Gemini contents list."""
    from google.genai import types

    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        text = msg.get("content", "")
        if isinstance(text, str) and text:
            contents.append(types.Content(
                role=role,
                parts=[types.Part.from_text(text=text)],
            ))
        elif isinstance(text, list):
            parts = [types.Part.from_text(text=b["text"]) for b in text if b.get("type") == "text"]
            if parts:
                contents.append(types.Content(role=role, parts=parts))
    return contents


async def _stream_gemini(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Stream response from Gemini API. Returns full_text."""
    from meeting_helper.server.websocket import broadcast

    if not config.google_api_key:
        await broadcast({"type": "error", "message": "No Google API key configured."})
        return ""

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=config.google_api_key)
        contents = _messages_to_gemini_contents(messages)
        full_text = ""

        def _stream_sync():
            nonlocal full_text
            chunks = []
            for chunk in client.models.generate_content_stream(
                model=config.gemini_model,
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    max_output_tokens=config.max_tokens,
                ),
            ):
                if chunk.text:
                    full_text += chunk.text
                    chunks.append(chunk.text)
            return chunks

        loop = asyncio.get_event_loop()
        chunks = await loop.run_in_executor(None, _stream_sync)

        for chunk_text in chunks:
            await broadcast({"type": "chunk", "text": chunk_text})

        return full_text

    except Exception as exc:
        logger.error("Gemini error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Gemini error: {exc}"})
        return ""


# ---------------------------------------------------------------------------
# Ollama (local) streaming
# ---------------------------------------------------------------------------

def _ensure_ollama(model: str, host: str = "http://localhost:11434") -> bool:
    """Ensure Ollama is running and the model is available. Returns True if ready."""
    from meeting_helper.ai.ollama_utils import (
        is_ollama_installed, start_ollama, get_installed_models, keep_alive, _is_remote,
    )

    remote = _is_remote(host)

    if not remote and not is_ollama_installed():
        logger.error("Ollama not installed")
        return False

    if not start_ollama(host):
        logger.error("Ollama server failed to start (host=%s)", host)
        return False

    if not remote:
        keep_alive()

    installed = get_installed_models(start_server=True, host=host)
    if model not in installed:
        logger.error("Model %s not available on %s. Download it from Settings.", model, host)
        return False

    return True


def _trim_system_prompt_for_local(system_prompt: str, max_chars: int = 4000) -> str:
    """Trim the system prompt for local models that have smaller context windows.

    Keeps the core instructions and truncates the workspace context block.
    """
    if len(system_prompt) <= max_chars:
        return system_prompt

    # Find the context block separator
    sep = "\n\n---\nThe user's workspace context is below."
    idx = system_prompt.find(sep)
    if idx == -1:
        # No context block — just truncate
        return system_prompt[:max_chars]

    # Keep core prompt + truncated context
    core = system_prompt[:idx]
    context = system_prompt[idx:]
    remaining = max_chars - len(core) - 100  # leave room for truncation notice
    if remaining > 200:
        trimmed_context = context[:remaining] + "\n\n[... context truncated for local model ...]"
        return core + trimmed_context
    else:
        return core


async def _stream_ollama(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Stream response from Ollama. Returns full_text."""
    from meeting_helper.server.websocket import broadcast

    model = config.local_model
    host = config.ollama_host

    ready = await asyncio.get_event_loop().run_in_executor(None, _ensure_ollama, model, host)
    if not ready:
        await broadcast({"type": "error", "message": f"Ollama not reachable at {host}. Check server or install locally: brew install ollama"})
        return ""

    # Trim system prompt for local models
    system_prompt = _trim_system_prompt_for_local(system_prompt)

    try:
        # Convert messages to OpenAI format (text only)
        ollama_messages = [{"role": "system", "content": system_prompt}]
        for msg in messages:
            role = msg["role"]
            content = msg.get("content", "")
            if isinstance(content, str):
                ollama_messages.append({"role": role, "content": content})
            elif isinstance(content, list):
                text_parts = [b["text"] for b in content if b.get("type") == "text"]
                if text_parts:
                    ollama_messages.append({"role": role, "content": "\n\n".join(text_parts)})

        full_text = ""

        def _stream_sync():
            nonlocal full_text
            body = json.dumps({
                "model": model,
                "messages": ollama_messages,
                "stream": True,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        text = chunk.get("message", {}).get("content", "")
                        if text:
                            full_text += text
                    except json.JSONDecodeError:
                        pass

        loop = asyncio.get_event_loop()
        prev_len = 0
        task = loop.run_in_executor(None, _stream_sync)

        while not task.done():
            await asyncio.sleep(0.05)
            if len(full_text) > prev_len:
                await broadcast({"type": "chunk", "text": full_text[prev_len:]})
                prev_len = len(full_text)

        await task  # raise any exception

        # Flush remaining
        if len(full_text) > prev_len:
            await broadcast({"type": "chunk", "text": full_text[prev_len:]})

        return full_text

    except Exception as exc:
        logger.error("Ollama error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Local AI error: {exc}"})
        return ""


# ---------------------------------------------------------------------------
# Provider router
# ---------------------------------------------------------------------------

async def _stream_ai(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Route to the configured AI provider with fallback chain. Returns full_text."""
    from meeting_helper.server.websocket import broadcast

    candidates = {
        "claude": ("Claude", _stream_claude, bool(config.anthropic_api_key)),
        "gemini": ("Gemini", _stream_gemini, bool(config.google_api_key)),
        "local":  ("Local",  _stream_ollama,  True),
    }

    # Determine preferred provider
    provider = config.preferred_provider or "claude"
    if provider == "gemini" and not config.google_api_key:
        provider = "claude"
    if provider == "claude" and not config.anthropic_api_key:
        provider = "gemini" if config.google_api_key else "local"

    # Build fallback chain: preferred first, then others
    primary = candidates.pop(provider, None)
    chain = [primary] if primary else []
    for entry in candidates.values():
        chain.append(entry)

    prev_label = None
    for label, stream_fn, available in chain:
        if not available:
            continue
        if prev_label:
            logger.warning("%s failed, falling back to %s", prev_label, label)
            await broadcast({"type": "chunk", "text": f"\n\n*[Switched to {label} — {prev_label} unavailable]*\n\n"})
        try:
            result = await stream_fn(state, config, messages, system_prompt)
            if result:
                return result
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("%s error: %s", label, exc)
            prev_label = label
            continue

    await broadcast({"type": "error", "message": "All providers failed."})
    return ""


# ---------------------------------------------------------------------------
# Real-time query (during meeting, hotkey-triggered)
# ---------------------------------------------------------------------------

async def handle_query(state: "AppState", config: "AppConfig") -> None:
    """Assemble context from buffers + warm topic, stream AI response.

    NO per-query LLM extraction or cards search — TopicWorker keeps
    state.current_topic and state.current_topic_cards updated every ~5s.
    """
    from meeting_helper.server.websocket import broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Warm reads from TopicWorker — no per-query LLM cost
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": cards})

    messages = _assemble_messages(state, config)
    current_user_turn = messages[-1]
    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block=state.auto_context_index or "",
        cards_markdown=cards_markdown,
    )

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Query cancelled")
        return

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Manual query (user-typed text during meeting)
# ---------------------------------------------------------------------------

async def handle_manual_query(state: "AppState", config: "AppConfig", user_text: str) -> None:
    """Send a user-typed question to AI, with both transcripts + warm topic."""
    from meeting_helper.server.websocket import broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Warm cache from TopicWorker
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": cards})

    # Build full prompt content with explicit user-typed question
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    topic = state.current_topic or {}
    topic_lines: list[str] = []
    if topic.get("topic"):
        topic_lines.append(f"- Topic: {topic['topic']}")
    if topic.get("ticket_ids"):
        topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
    if topic.get("last_user_statement"):
        topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
    topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

    self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
    other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

    # Stamp the question cursor so the next hotkey press won't re-extract any
    # `?` from the buffer that's older than this typed query.
    state.last_query_at = time.time()

    content = (
        "## Topic just discussed\n"
        f"{topic_block}\n\n"
        "## What I just said (first person)\n"
        f"{self_block}\n\n"
        "## What others just said\n"
        f"{other_block}\n\n"
        "## What was just asked (typed by me)\n"
        f"{user_text}\n\n"
        "Answer the typed question. Use the Topic and 'What I just said' sections to resolve any pronouns or vague references."
    )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block=state.auto_context_index or "",
        cards_markdown=cards_markdown,
    )

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Manual query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Manual query cancelled")
        return

    except Exception as exc:
        logger.error("Manual query error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Proactive query (auto-triggered when a question is detected in transcript)
# ---------------------------------------------------------------------------

async def handle_proactive_query(state: "AppState", config: "AppConfig", question: str) -> None:
    """Auto-triggered query when a question is detected. Same as manual but labeled auto."""
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one (proactive)")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start", "proactive": True, "question": question})

    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window * 2)

    if transcript:
        content = f"{question}\n\n---\n## Recent meeting transcript:\n{transcript}"
    else:
        content = question

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Proactive query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Proactive query cancelled")
        return

    except Exception as exc:
        logger.error("Proactive query error: %s", exc)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Post-meeting: transcribe MP3 with faster-whisper
# ---------------------------------------------------------------------------

def transcribe_audio_file(mp3_path: str, config: "AppConfig") -> str:
    """Transcribe an MP3 file using faster-whisper. Returns full transcript text.

    Runs synchronously — caller should wrap in asyncio.to_thread().
    """
    from faster_whisper import WhisperModel

    path = Path(mp3_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {mp3_path}")

    logger.info("Transcribing %s with faster-whisper...", path.name)
    t0 = time.monotonic()

    from meeting_helper.ssl_fix import patch_ssl
    patch_ssl()

    model = WhisperModel("medium", compute_type="int8")
    segments, info = model.transcribe(
        str(path),
        language=config.transcription_language if config.transcription_language != "auto" else None,
        beam_size=5,
        vad_filter=True,
        condition_on_previous_text=True,
    )

    lines: list[str] = []
    for segment in segments:
        start_m, start_s = divmod(int(segment.start), 60)
        end_m, end_s = divmod(int(segment.end), 60)
        timestamp = f"[{start_m:02d}:{start_s:02d} - {end_m:02d}:{end_s:02d}]"
        lines.append(f"{timestamp} {segment.text.strip()}")

    transcript = "\n".join(lines)
    elapsed = time.monotonic() - t0
    logger.info("Transcription complete: %d segments, %.1fs", len(lines), elapsed)

    # Save alongside the MP3
    out_path = path.with_suffix(".transcript.txt")
    out_path.write_text(transcript)
    logger.info("Transcript saved: %s", out_path.name)

    return transcript


# ---------------------------------------------------------------------------
# Auto-context: select relevant repos/knowledge from low-level index
# ---------------------------------------------------------------------------

async def _select_context(
    index: str, transcript: str, history: list, config: "AppConfig"
) -> dict:
    """Ask AI which repos/knowledge are relevant. Returns {repos, knowledge}.

    Uses Claude Haiku when available, falls back to Ollama for local provider.
    """
    import re
    from meeting_helper.ai.prompts import AUTO_CONTEXT_SELECTION_PROMPT

    if not index.strip() or not transcript.strip():
        return {"repos": [], "knowledge": []}

    history_text = "\n".join(
        f"{m['role'].title()}: {str(m.get('content', ''))[:200]}" for m in history[-4:]
    ) or "(none)"

    prompt = AUTO_CONTEXT_SELECTION_PROMPT.format(
        index=index,
        n=len(transcript.split("\n")),
        transcript=transcript[-3000:],
        history=history_text,
    )

    try:
        raw = ""

        if config.preferred_provider == "local":
            # Use Ollama — truncate index to keep prompt small for local models
            truncated_index = index[:2000] if len(index) > 2000 else index
            short_prompt = AUTO_CONTEXT_SELECTION_PROMPT.format(
                index=truncated_index,
                n=len(transcript.split("\n")),
                transcript=transcript[-1500:],
                history=history_text,
            )
            model = config.local_model
            host = config.ollama_host
            ready = await asyncio.get_event_loop().run_in_executor(
                None, _ensure_ollama, model, host,
            )
            if not ready:
                return {"repos": [], "knowledge": []}

            def _query_sync():
                body = json.dumps({
                    "model": model,
                    "messages": [{"role": "user", "content": short_prompt}],
                    "stream": False,
                }).encode()
                req = urllib.request.Request(
                    f"{host.rstrip('/')}/api/chat",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read()).get("message", {}).get("content", "")

            raw = await asyncio.get_event_loop().run_in_executor(None, _query_sync)

        elif config.anthropic_api_key:
            # Use Claude Haiku (fast + cheap)
            import anthropic
            import httpx
            client = anthropic.AsyncAnthropic(
                api_key=config.anthropic_api_key,
                http_client=httpx.AsyncClient(verify=False),
            )
            msg = await client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            raw = msg.content[0].text.strip()

        elif config.google_api_key:
            # Use Gemini Flash (fast + cheap)
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=config.google_api_key)

            def _query_gemini():
                resp = client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=prompt,
                    config=types.GenerateContentConfig(max_output_tokens=256),
                )
                return resp.text.strip() if resp.text else ""

            raw = await asyncio.get_event_loop().run_in_executor(None, _query_gemini)

        else:
            return {"repos": [], "knowledge": []}

        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return {"repos": [], "knowledge": []}
        result = json.loads(match.group())
        return {
            "repos": result.get("repos", []) if isinstance(result.get("repos"), list) else [],
            "knowledge": result.get("knowledge", []) if isinstance(result.get("knowledge"), list) else [],
        }
    except Exception as exc:
        logger.warning("_select_context error: %s", exc)
        return {"repos": [], "knowledge": []}


# ---------------------------------------------------------------------------
# Post-meeting: summarize transcript
# ---------------------------------------------------------------------------

async def summarize_transcript(transcript_path: str, config: "AppConfig") -> str:
    """Send a full transcript to the configured AI provider for structured summary."""
    from meeting_helper.ai.prompts import SUMMARIZE_SYSTEM_PROMPT

    path = Path(transcript_path)
    if not path.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")

    transcript = path.read_text()
    if not transcript.strip():
        raise ValueError("Transcript file is empty")

    logger.info("Summarizing transcript (%d chars)...", len(transcript))
    t0 = time.monotonic()

    user_msg = f"Please summarize this meeting transcript:\n\n{transcript}"

    if config.preferred_provider == "local":
        # Use Ollama
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise ValueError(f"Ollama not reachable at {host}")

        def _summarize_sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": SUMMARIZE_SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_sync)

    elif config.preferred_provider == "gemini" and config.google_api_key:
        # Use Gemini
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _summarize_gemini():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=SUMMARIZE_SYSTEM_PROMPT,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_gemini)

    else:
        # Use Claude
        import anthropic
        import httpx

        if not config.anthropic_api_key:
            raise ValueError("No Anthropic API key configured")

        client = anthropic.AsyncAnthropic(
            api_key=config.anthropic_api_key,
            http_client=httpx.AsyncClient(verify=False),
        )
        message = await client.messages.create(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=SUMMARIZE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        summary = message.content[0].text

    elapsed = time.monotonic() - t0
    logger.info("Summarization complete: %d chars, %.1fs", len(summary), elapsed)

    # Save alongside the transcript
    out_path = path.with_name(path.name.replace(".transcript.txt", ".summary.txt"))
    if out_path == path:
        out_path = path.with_suffix(".summary.txt")
    out_path.write_text(summary)
    logger.info("Summary saved: %s", out_path.name)

    return summary


async def _call_ai_for_tasks(config: "AppConfig", system_prompt: str, user_msg: str) -> str:
    """Send a single non-streaming request to the configured provider, return raw text."""
    if config.preferred_provider == "local":
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise RuntimeError(f"Ollama not reachable at {host}")

        def _sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    if config.preferred_provider == "gemini" and config.google_api_key:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _sync():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    import anthropic
    import httpx

    if not config.anthropic_api_key:
        raise RuntimeError("No Anthropic API key configured")

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    message = await client.messages.create(
        model=config.claude_model,
        max_tokens=config.max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    return message.content[0].text


async def extract_tasks(state: "AppState", config: "AppConfig") -> list[dict]:
    """Extract new action items from the live transcript.

    Reads state.sentence_buffer + state.session_tasks. Appends newly extracted
    tasks to state.session_tasks. Returns the list of newly added tasks
    (empty on any failure or empty transcript).
    """
    from meeting_helper.ai.prompts import (
        EXTRACT_TASKS_SYSTEM_PROMPT,
        build_extract_tasks_user_message,
    )
    from meeting_helper import tasks as tasks_mod

    if state.sentence_buffer is None:
        return []
    transcript = state.sentence_buffer.get_full_transcript().strip()
    if not transcript:
        return []

    existing_titles = [t.get("title") or t.get("text", "") for t in state.session_tasks]
    user_msg = build_extract_tasks_user_message(transcript, existing_titles)

    logger.info("extract_tasks: transcript=%d chars, existing=%d",
                len(transcript), len(existing_titles))

    try:
        raw = await _call_ai_for_tasks(config, EXTRACT_TASKS_SYSTEM_PROMPT, user_msg)
    except Exception as exc:
        logger.warning("extract_tasks: AI call failed: %s", exc)
        return []

    parsed = tasks_mod.parse_ai_response(raw)
    if not parsed:
        return []

    new_tasks = tasks_mod.finalize_tasks(parsed)
    state.session_tasks.extend(new_tasks)
    logger.info("extract_tasks: added %d tasks (total=%d)",
                len(new_tasks), len(state.session_tasks))
    return new_tasks
