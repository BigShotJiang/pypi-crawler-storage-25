"""Task data type, AI response parsing, and JSON persistence."""

from __future__ import annotations

import json
import logging
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_FENCE_RE = re.compile(r"^```(?:json)?\s*\n(.*?)\n```\s*$", re.DOTALL)


def parse_ai_response(raw: str) -> list[dict[str, str]]:
    """Parse an AI response into a list of {title, description, source_quote} dicts.

    Tolerates ```json fences and legacy {text, source_quote} shape. Returns [] on
    any parse failure or unexpected shape.
    """
    if not raw:
        return []
    text = raw.strip()
    m = _FENCE_RE.match(text)
    if m:
        text = m.group(1).strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        logger.warning("extract_tasks: failed to parse AI response as JSON")
        return []
    if not isinstance(data, dict):
        return []
    items = data.get("tasks")
    if not isinstance(items, list):
        return []
    out: list[dict[str, str]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = item.get("title") or item.get("text")
        description = item.get("description", "")
        quote = item.get("source_quote", "")
        if not isinstance(title, str) or not title.strip():
            continue
        out.append({
            "title": title.strip(),
            "description": str(description).strip(),
            "source_quote": str(quote).strip(),
        })
    return out


def finalize_tasks(parsed: list[dict[str, str]]) -> list[dict[str, str]]:
    """Add id + created_at to each parsed task."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return [
        {
            "id": uuid.uuid4().hex,
            "title": p["title"],
            "description": p.get("description", ""),
            "source_quote": p.get("source_quote", ""),
            "created_at": now,
        }
        for p in parsed
    ]


def save_tasks(path: Path, items: list[dict[str, Any]]) -> None:
    """Write tasks JSON; skips writing when the list is empty."""
    if not items:
        return
    path.write_text(json.dumps(items, ensure_ascii=False, indent=2))


def load_tasks(path: Path) -> list[dict[str, Any]]:
    """Load tasks JSON; returns [] if missing or malformed."""
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        logger.warning("load_tasks: could not parse %s", path)
        return []
    if not isinstance(data, list):
        return []
    return [item for item in data if isinstance(item, dict)]
