"""macOS menu bar icon for Meeting Helper.

Lightweight process -- shows an icon in the top bar with a dropdown menu.
No dock icon. Communicates with the daemon via HTTP and spawns the GUI as needed.

Usage (internal): python -m meeting_helper.menubar
       or:        meeting-helper menubar
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

import objc
from AppKit import (
    NSApplication,
    NSApplicationActivationPolicyAccessory,
    NSBezierPath,
    NSColor,
    NSFont,
    NSFontAttributeName,
    NSForegroundColorAttributeName,
    NSGraphicsContext,
    NSImage,
    NSMenu,
    NSMenuItem,
    NSMutableParagraphStyle,
    NSObject,
    NSParagraphStyleAttributeName,
    NSStatusBar,
    NSVariableStatusItemLength,
)
from Foundation import NSDictionary, NSMakeRect, NSMakeSize, NSString
from PyObjCTools import AppHelper

from meeting_helper.config import GUI_PID_FILE, MENUBAR_PID_FILE, get_config

MENUBAR_ICONS = {
    "MH": "MH",
    "◆": "◆",
    "⚡": "⚡",
    "●": "●",
    "▶": "▶",
    "☰": "☰",
}

# Colors (RGB 0-1 floats)
_GRAY = (0.545, 0.545, 0.545)   # #8b8b8b — daemon stopped
_GREEN = (0.306, 0.788, 0.690)  # #4ec9b0 — ready
_RED = (0.973, 0.298, 0.298)    # #f14c4c — recording


def _is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _cli_path() -> str:
    """Find the meeting-helper CLI binary."""
    p = Path(sys.executable).parent / "meeting-helper"
    if p.exists():
        return str(p)
    import shutil
    return shutil.which("meeting-helper") or "meeting-helper"


def _create_icon(text: str, rgb: tuple) -> NSImage:
    """Create a rounded-square NSImage with colored background and white text."""
    size = 22  # macOS menu bar standard canvas
    badge = 16  # actual rounded square size
    img = NSImage.alloc().initWithSize_(NSMakeSize(size, size))
    img.lockFocus()

    # Rounded square background — centered in the canvas
    color = NSColor.colorWithSRGBRed_green_blue_alpha_(rgb[0], rgb[1], rgb[2], 1.0)
    color.setFill()
    offset = (size - badge) / 2
    rect = NSMakeRect(offset, offset, badge, badge)
    path = NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(rect, 4.0, 4.0)
    path.fill()

    # White text centered
    font = NSFont.boldSystemFontOfSize_(8.0 if len(text) <= 2 else 6.5)
    white = NSColor.whiteColor()
    para = NSMutableParagraphStyle.alloc().init()
    para.setAlignment_(1)  # NSTextAlignmentCenter
    attrs = NSDictionary.dictionaryWithObjects_forKeys_(
        [font, white, para],
        [NSFontAttributeName, NSForegroundColorAttributeName, NSParagraphStyleAttributeName],
    )
    ns_text = NSString.stringWithString_(text)
    text_size = ns_text.sizeWithAttributes_(attrs)
    x = (size - text_size.width) / 2
    y = (size - text_size.height) / 2
    ns_text.drawAtPoint_withAttributes_((x, y), attrs)

    img.unlockFocus()
    img.setTemplate_(False)
    return img


class MenuBarDelegate(NSObject):
    def applicationDidFinishLaunching_(self, notification):
        config = get_config()
        self._port = config.port
        self._cli = _cli_path()
        self._icon_text = MENUBAR_ICONS.get(config.menubar_icon, "MH")

        # Pre-render icons for all 3 states
        self._icons = {
            "stopped": _create_icon(self._icon_text, _GRAY),
            "ready": _create_icon(self._icon_text, _GREEN),
            "recording": _create_icon(self._icon_text, _RED),
        }

        # Create status bar item
        self.status_item = NSStatusBar.systemStatusBar().statusItemWithLength_(
            NSVariableStatusItemLength
        )
        self.status_item.button().setImage_(self._icons["stopped"])
        self.status_item.setHighlightMode_(True)

        # Build menu
        self._menu = NSMenu.alloc().init()

        self._item_open_gui = self._add_item("Open Dashboard", "openDashboard:")
        self._menu.addItem_(NSMenuItem.separatorItem())
        self._item_start = self._add_item("Start Recording", "startRecording:")
        self._item_start.setEnabled_(False)
        self._item_stop = self._add_item("Stop Recording", "stopRecording:")
        self._item_stop.setEnabled_(False)
        self._menu.addItem_(NSMenuItem.separatorItem())
        self._add_item("Quit", "quit:")

        self.status_item.setMenu_(self._menu)

        # Start status polling
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()

    def _add_item(self, title: str, action: str) -> NSMenuItem:
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, action, "")
        item.setTarget_(self)
        self._menu.addItem_(item)
        return item

    def _poll_loop(self):
        while True:
            try:
                req = urllib.request.Request(f"http://127.0.0.1:{self._port}/health")
                with urllib.request.urlopen(req, timeout=1) as resp:
                    data = json.loads(resp.read().decode())
                state = {"running": True, "session_active": data.get("session_active", False)}
            except Exception:
                state = {"running": False, "session_active": False}
            try:
                self.performSelectorOnMainThread_withObject_waitUntilDone_(
                    "updateStatus:", state, False
                )
            except Exception:
                pass
            threading.Event().wait(3)

    @objc.python_method
    def _update_status_impl(self, info):
        running = info.get("running", False)
        session_active = info.get("session_active", False)

        if session_active:
            self.status_item.button().setImage_(self._icons["recording"])
            self._item_start.setEnabled_(False)
            self._item_stop.setEnabled_(True)
        elif running:
            self.status_item.button().setImage_(self._icons["ready"])
            self._item_start.setEnabled_(True)
            self._item_stop.setEnabled_(False)
        else:
            self.status_item.button().setImage_(self._icons["stopped"])
            self._item_start.setEnabled_(False)
            self._item_stop.setEnabled_(False)

    def updateStatus_(self, info):
        self._update_status_impl(info)

    def openDashboard_(self, sender):
        if GUI_PID_FILE.exists():
            try:
                pid = int(GUI_PID_FILE.read_text().strip())
                if _is_running(pid):
                    try:
                        from AppKit import NSWorkspace
                        for app in NSWorkspace.sharedWorkspace().runningApplications():
                            name = app.localizedName() or ""
                            bid = app.bundleIdentifier() or ""
                            if "Flet" in name or "Meeting Helper" in name or "flet" in bid:
                                app.activateWithOptions_(1 << 1)
                                break
                    except Exception:
                        pass
                    return
            except Exception:
                pass
        subprocess.Popen(
            [self._cli, "gui"],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )

    def startRecording_(self, sender):
        threading.Thread(target=self._post, args=("/session/start",), daemon=True).start()

    def stopRecording_(self, sender):
        threading.Thread(target=self._post, args=("/session/stop",), daemon=True).start()

    @objc.python_method
    def _post(self, path: str):
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}{path}",
                data=b"{}",
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass

    def quit_(self, sender):
        MENUBAR_PID_FILE.unlink(missing_ok=True)
        NSApplication.sharedApplication().terminate_(sender)


def run_menubar() -> None:
    """Start the menu bar icon. Blocks until quit."""
    if MENUBAR_PID_FILE.exists():
        try:
            old_pid = int(MENUBAR_PID_FILE.read_text().strip())
            if _is_running(old_pid) and old_pid != os.getpid():
                return
        except Exception:
            pass
        MENUBAR_PID_FILE.unlink(missing_ok=True)

    MENUBAR_PID_FILE.write_text(str(os.getpid()))

    try:
        app = NSApplication.sharedApplication()
        app.setActivationPolicy_(NSApplicationActivationPolicyAccessory)
        delegate = MenuBarDelegate.alloc().init()
        app.setDelegate_(delegate)
        AppHelper.runEventLoop()
    finally:
        MENUBAR_PID_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    run_menubar()
