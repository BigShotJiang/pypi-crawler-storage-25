"""Async client for the local-todo MCP server.

The daemon spawns the configured MCP command as a stdio JSON-RPC subprocess,
keeps the session alive for the daemon's lifetime, and exposes a small
typed surface for the meeting-helper's needs.
"""

from __future__ import annotations

import asyncio
import json
import logging
from contextlib import AsyncExitStack
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _parse_tool_result(result: Any) -> Any:
    """MCP call_tool() returns a result with .content (list of TextContent).
    For local-todo we expect a single text block of JSON. Parse it; on
    failure return None so callers can detect parse errors distinctly from
    valid empty results."""
    try:
        if not getattr(result, "content", None):
            return None
        text = result.content[0].text
        return json.loads(text)
    except (AttributeError, IndexError, ValueError, json.JSONDecodeError) as exc:
        logger.warning("local-todo parse error: %s", exc)
        return None


class LocalTodoClient:
    """Async wrapper around the local-todo MCP server.

    Lazy: the subprocess is spawned on the first call and kept alive thereafter.
    Auto-restart is NOT in this version — if the subprocess dies, the next call
    will fail and the user must restart the daemon. (Acceptable for v1; revisit
    if it becomes a real pain.)
    """

    def __init__(self, mcp_config: dict) -> None:
        if not mcp_config:
            raise ValueError("LocalTodoClient: mcp_config must be non-empty")
        self._type = (mcp_config.get("type") or "stdio").strip().lower()
        if self._type not in ("stdio", "http"):
            raise ValueError(f"LocalTodoClient: unknown type {self._type!r} (expected 'stdio' or 'http')")
        if self._type == "stdio":
            command = str(mcp_config.get("command", "")).strip()
            if not command:
                raise ValueError("LocalTodoClient: stdio config requires non-empty command")
            self._command = command
            self._args = list(mcp_config.get("args", []) or [])
            self._env = dict(mcp_config.get("env", {}) or {})
            self._url = ""
            self._headers: dict[str, str] = {}
        else:
            url = str(mcp_config.get("url", "")).strip()
            if not url:
                raise ValueError("LocalTodoClient: http config requires non-empty url")
            self._command = ""
            self._args = []
            self._env = {}
            self._url = url
            self._headers = dict(mcp_config.get("headers", {}) or {})
        self._stack: Optional[AsyncExitStack] = None
        self._session: Any = None  # mcp.client.session.ClientSession when started
        self._lock = asyncio.Lock()
        self._cached_boards: Optional[list[dict]] = None

    async def _ensure_started(self) -> None:
        async with self._lock:
            if self._session is not None:
                return
            from mcp.client.session import ClientSession

            stack = AsyncExitStack()
            try:
                if self._type == "stdio":
                    from mcp.client.stdio import stdio_client, StdioServerParameters
                    params = StdioServerParameters(
                        command=self._command,
                        args=list(self._args),
                        env=dict(self._env) if self._env else None,
                    )
                    read, write = await stack.enter_async_context(stdio_client(params))
                    logger.info("local-todo MCP started (stdio): %s %s",
                                self._command, " ".join(self._args))
                else:
                    from mcp.client.streamable_http import streamablehttp_client
                    headers = dict(self._headers) if self._headers else None
                    read, write, _get_sid = await stack.enter_async_context(
                        streamablehttp_client(self._url, headers=headers)
                    )
                    logger.info("local-todo MCP started (http): %s", self._url)

                session = await stack.enter_async_context(ClientSession(read, write))
                await session.initialize()
                self._stack = stack
                self._session = session
            except Exception:
                await stack.aclose()
                raise

    async def close(self) -> None:
        async with self._lock:
            if self._stack is not None:
                try:
                    await self._stack.aclose()
                finally:
                    self._stack = None
                    self._session = None
                    logger.info("local-todo MCP closed")

    async def list_boards(self) -> list[dict]:
        """Return all authorized boards. Cached for the client's lifetime.

        Each board: {"board_id": int, "name": str, "effective_permission": str, ...}.
        """
        if self._cached_boards is not None:
            return self._cached_boards
        await self._ensure_started()
        result = await self._session.call_tool("list_boards", {})
        parsed = _parse_tool_result(result)
        boards = parsed if isinstance(parsed, list) else []
        # Filter to only boards we can read
        boards = [b for b in boards if b.get("effective_permission") in ("read", "write")]
        self._cached_boards = boards
        return boards

    async def search(self, query: str, limit: int = 5) -> list[dict]:
        """Search tasks + docs across all authorized boards. Returns top-K
        normalized records.

        Each record is the raw task/doc object from local-todo, plus:
          - "kind": "task" | "doc"
          - "board_id": int (which board it came from)
          - "board_name": str
        """
        if not query.strip():
            return []
        await self._ensure_started()

        boards = await self.list_boards()
        if not boards:
            return []

        # Issue per-board task + doc searches in parallel
        per_board_calls: list = []
        for b in boards:
            bid = b["board_id"]
            per_board_calls.append(self._session.call_tool(
                "search_tasks", {"board_id": bid, "q": query, "limit": limit}
            ))
            per_board_calls.append(self._session.call_tool(
                "search_docs", {"board_id": bid, "q": query, "limit": limit}
            ))

        results = await asyncio.gather(*per_board_calls, return_exceptions=True)

        records: list[dict] = []
        # Results come in (tasks, docs) pairs per board
        for i, b in enumerate(boards):
            tasks_res = results[i * 2]
            docs_res = results[i * 2 + 1]
            board_meta = {"board_id": b["board_id"], "board_name": b.get("name", "")}

            if not isinstance(tasks_res, Exception):
                payload = _parse_tool_result(tasks_res)
                if isinstance(payload, list):
                    for t in payload:
                        records.append({"kind": "task", **board_meta, **t})

            if not isinstance(docs_res, Exception):
                payload = _parse_tool_result(docs_res)
                if isinstance(payload, list):
                    for d in payload:
                        records.append({"kind": "doc", **board_meta, **d})

        return records[:limit]

    async def my_active_tasks(self, limit: int = 20) -> list[dict]:
        """Return tasks in the active sprint of every authorized board.

        Each task is the raw object from local-todo plus:
          - "board_id": int
          - "board_name": str
          - "sprint_name": str (resolved from list_sprints.active.name)
        """
        await self._ensure_started()

        boards = await self.list_boards()
        if not boards:
            return []

        # First: list_sprints per board to find the active sprint name
        sprint_calls = [
            self._session.call_tool("list_sprints", {"board_id": b["board_id"]})
            for b in boards
        ]
        sprint_results = await asyncio.gather(*sprint_calls, return_exceptions=True)

        # active_sprints[board_id] = {"id": "...", "name": "..."} or None
        active_sprints: dict[int, Optional[dict]] = {}
        for b, res in zip(boards, sprint_results):
            if isinstance(res, Exception):
                active_sprints[b["board_id"]] = None
                continue
            payload = _parse_tool_result(res)
            if isinstance(payload, dict):
                active_sprints[b["board_id"]] = payload.get("active") or None
            else:
                active_sprints[b["board_id"]] = None

        # Second: search_tasks(scope="active") per board where there IS an active sprint
        task_calls = []
        boards_with_active = []
        for b in boards:
            sprint = active_sprints.get(b["board_id"])
            if sprint:
                boards_with_active.append(b)
                task_calls.append(self._session.call_tool(
                    "search_tasks", {"board_id": b["board_id"]}  # default scope=active
                ))

        if not task_calls:
            return []

        task_results = await asyncio.gather(*task_calls, return_exceptions=True)

        records: list[dict] = []
        for b, res in zip(boards_with_active, task_results):
            if isinstance(res, Exception):
                continue
            payload = _parse_tool_result(res)
            if not isinstance(payload, list):
                continue
            sprint = active_sprints.get(b["board_id"]) or {}
            board_meta = {
                "board_id": b["board_id"],
                "board_name": b.get("name", ""),
                "sprint_name": sprint.get("name", ""),
            }
            for t in payload:
                records.append({**board_meta, **t})

        return records[:limit]

    async def get(self, kind: str, id: str, board_id: int) -> dict:
        """Fetch a full record by kind ('task' or 'doc'), id, and board_id.

        Returns the parsed record dict, or {} on failure.
        """
        if kind not in ("task", "doc"):
            raise ValueError(f"kind must be 'task' or 'doc', got {kind!r}")
        await self._ensure_started()
        tool_name = "get_task" if kind == "task" else "get_doc"
        result = await self._session.call_tool(
            tool_name, {"board_id": board_id, "id": id}
        )
        parsed = _parse_tool_result(result)
        return parsed if isinstance(parsed, dict) else {}
