"""Pill — compact label + chevron button that opens a menu of options."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import flet as ft


@dataclass
class PillOption:
    key: str
    label: str


class Pill(ft.Container):
    """Compact pill: shows current label, opens a PopupMenu of options on click.

    The Flet rendering uses `ft.PopupMenuButton` wrapped in a styled container.
    Most logic (selection routing, option mutation) lives in plain Python so it
    can be unit-tested without a Page.
    """

    def __init__(
        self,
        label: str,
        options: list[PillOption],
        on_select: Callable[[str], None],
    ) -> None:
        super().__init__()
        self._label = label
        self._options = list(options)
        self._on_select = on_select
        self._build()

    @property
    def label(self) -> str:
        return self._label

    @property
    def options(self) -> list[PillOption]:
        return list(self._options)

    def set_label(self, label: str) -> None:
        self._label = label
        if self._label_text is not None:
            self._label_text.value = label
            try:
                self._label_text.update()
            except Exception:
                pass

    def set_options(self, options: list[PillOption]) -> None:
        self._options = list(options)
        if self._menu is not None:
            self._menu.items = [
                ft.PopupMenuItem(content=ft.Text(o.label), on_click=self._make_handler(o.key))
                for o in self._options
            ]
            try:
                self._menu.update()
            except Exception:
                pass

    def select(self, key: str) -> None:
        """Programmatically trigger a selection (used by tests + chip click)."""
        if any(o.key == key for o in self._options):
            self._on_select(key)

    # ------------------------------------------------------------------ Flet UI

    def _make_handler(self, key: str) -> Callable[[ft.ControlEvent], None]:
        def handler(_e: ft.ControlEvent) -> None:
            self._on_select(key)
        return handler

    def _build(self) -> None:
        self._label_text = ft.Text(
            self._label,
            size=12,
            weight=ft.FontWeight.W_500,
        )
        self._menu = ft.PopupMenuButton(
            items=[
                ft.PopupMenuItem(content=ft.Text(o.label), on_click=self._make_handler(o.key))
                for o in self._options
            ],
            content=ft.Row(
                [
                    self._label_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, size=16),
                ],
                spacing=2,
                tight=True,
            ),
        )
        self.padding = ft.Padding(left=10, right=10, top=4, bottom=4)
        self.border = ft.Border(
            left=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
            right=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
            top=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
            bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
        )
        self.border_radius = 14
        self.bgcolor = ft.Colors.SURFACE_CONTAINER_HIGH
        self.content = self._menu
