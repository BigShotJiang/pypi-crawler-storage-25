"""Topic strip — clickable current-topic pill + last-3 distinct topic chips.

Includes ``last_n_distinct`` (pure-Python, testable) and ``TopicStrip`` Flet UI.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft


def last_n_distinct(history: list[str], n: int = 3) -> list[str]:
    """Return the last n distinct topics, most recent first.

    Blank/whitespace-only entries are ignored.
    """
    seen: list[str] = []
    for topic in reversed(history):
        if not topic or not topic.strip():
            continue
        if topic not in seen:
            seen.append(topic)
            if len(seen) == n:
                break
    return seen


TEAL = "#4ec9b0"


class TopicStrip(ft.Column):
    """Topic pill (clickable) + clickable chips for past distinct topics.

    State is push-driven: callers invoke ``set_topic(...)`` whenever a new
    topic arrives. The strip maintains its own internal history list for chip
    dedup.

    The current topic itself is clickable — clicking it fires
    ``on_explain(current_topic)``. Past topics show as chips beneath; clicking
    a chip fires ``on_explain(that_topic)``. The current topic is intentionally
    excluded from the chip row (already in the pill above), and the chip set
    is backfilled so that you reliably see ``CHIP_COUNT`` past topics whenever
    history has enough.
    """

    CHIP_COUNT = 3

    def __init__(
        self,
        on_explain: Callable[[str], None],
    ) -> None:
        """on_explain(topic) is called when the topic pill or any chip is clicked."""
        super().__init__(spacing=4)
        self._on_explain = on_explain
        self._history: list[str] = []
        self._current_topic: str = ""
        self._current_tickets: list[str] = []

        self._topic_text = ft.Text(
            "Topic: (idle)",
            size=12,
            italic=True,
            color=ft.Colors.ON_SURFACE_VARIANT,
            tooltip="No active topic",
            max_lines=1,
            overflow=ft.TextOverflow.ELLIPSIS,
        )
        # The whole pill row is clickable when a topic is active. ``ink``
        # gives a visual ripple so it reads as interactive.
        self._topic_pill = ft.Container(
            content=ft.Row(
                [
                    ft.Text("💬", size=12, color=TEAL),
                    ft.Container(self._topic_text, expand=True),
                ],
                spacing=6,
                tight=True,
            ),
            padding=ft.padding.symmetric(horizontal=4, vertical=2),
            border_radius=4,
            ink=True,
            on_click=self._on_pill_clicked,
            tooltip="Click to ask: Explain more about this topic",
        )

        self._chips_row = ft.Row(spacing=6, wrap=True)
        chips_row_container = ft.Container(self._chips_row, padding=ft.padding.only(top=2))

        self.controls = [self._topic_pill, chips_row_container]

    def set_topic(
        self,
        topic: str,
        ticket_ids: list[str] | None = None,
    ) -> None:
        """Update the displayed topic; appends to internal history for chip dedup."""
        topic = (topic or "").strip()
        self._current_topic = topic
        self._current_tickets = list(ticket_ids or [])

        if topic:
            label_parts = [topic]
            if self._current_tickets:
                label_parts.append(f"({', '.join(self._current_tickets)})")
            label = " ".join(label_parts)
            self._topic_text.value = f"Topic: {label}"
            self._topic_text.tooltip = label
            self._topic_text.italic = False
            self._topic_pill.disabled = False
            self._history.append(topic)
        else:
            self._topic_text.value = "Topic: (idle)"
            self._topic_text.tooltip = "No active topic"
            self._topic_text.italic = True
            self._topic_pill.disabled = True

        self._render_chips()

    def _render_chips(self) -> None:
        # Ask for one extra so we can drop the current topic and still have
        # CHIP_COUNT chips when history has enough distinct topics.
        topics = last_n_distinct(self._history, n=self.CHIP_COUNT + 1)
        topics = [t for t in topics if t != self._current_topic][: self.CHIP_COUNT]
        self._chips_row.controls = [self._make_chip(t) for t in topics]

    def _make_chip(self, topic: str) -> ft.Control:
        display = topic if len(topic) <= 36 else topic[:33] + "…"
        return ft.Container(
            content=ft.Text(display, size=11, color=TEAL),
            padding=ft.padding.symmetric(horizontal=8, vertical=3),
            border=ft.border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=10,
            on_click=lambda _e, t=topic: self._on_explain(t),
            tooltip=topic,
        )

    def _on_pill_clicked(self, _e: ft.ControlEvent) -> None:
        if self._current_topic:
            self._on_explain(self._current_topic)
