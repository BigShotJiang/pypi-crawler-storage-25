"""BriefPanel — renders the {script, cards} response from POST /brief."""

from __future__ import annotations

import flet as ft


class BriefPanel(ft.Column):
    """Renders the {script, cards} response from POST /brief."""

    def __init__(self):
        super().__init__(spacing=8, visible=False)
        self._script = ft.Markdown(
            "",
            selectable=True,
            extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
        )
        self._cards_col = ft.Column(spacing=4)
        self.controls = [
            ft.Container(
                content=self._script,
                padding=12,
                bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
                border_radius=8,
            ),
            self._cards_col,
        ]

    def render(self, payload: dict):
        self._script.value = payload.get("script", "") or ""
        self._cards_col.controls = [
            self._render_card(c) for c in (payload.get("cards", []) or [])
        ]
        self.visible = True
        self.update()

    def show_error(self, message: str):
        self._script.value = f"**(error)** {message}"
        self._cards_col.controls = []
        self.visible = True
        self.update()

    def _render_card(self, c: dict) -> ft.Control:
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("sprint"):
            meta_parts.append(f"Sprint {c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        meta = "  ·  ".join(meta_parts)
        head = f"[{c.get('id', '?')}] {c.get('title', '')}"
        return ft.Container(
            content=ft.Column([
                ft.Text(head, weight=ft.FontWeight.W_600, size=13),
                ft.Text(meta, size=11, color=ft.Colors.ON_SURFACE_VARIANT)
                    if meta else ft.Container(),
            ], spacing=2),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=6,
        )
