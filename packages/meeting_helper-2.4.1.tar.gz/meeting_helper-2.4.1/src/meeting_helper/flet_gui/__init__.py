"""Flet-based GUI for Meeting Helper (Material Design 3)."""
