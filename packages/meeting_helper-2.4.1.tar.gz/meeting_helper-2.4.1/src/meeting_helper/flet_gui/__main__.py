"""Entry point for: python -m meeting_helper.flet_gui"""

from meeting_helper.config import get_config
from meeting_helper.flet_gui.app import run_flet_gui

# Fix SSL certificate verification for Flet client download.
# Homebrew Python on macOS does not ship CA certs and certifi's bundle
# is not picked up by Python 3.14's ssl module. Since the only HTTPS
# call at this stage is downloading the public Flet client from GitHub
# Releases, skip verification entirely.
import ssl
import urllib.request

_ctx = ssl._create_unverified_context()
urllib.request.install_opener(
    urllib.request.build_opener(urllib.request.HTTPSHandler(context=_ctx))
)

run_flet_gui(get_config())
