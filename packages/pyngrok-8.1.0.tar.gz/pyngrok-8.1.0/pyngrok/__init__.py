__copyright__ = "Copyright (c) 2018-2025 Alex Laird"
__license__ = "MIT"
__version__ = "8.1.0"
