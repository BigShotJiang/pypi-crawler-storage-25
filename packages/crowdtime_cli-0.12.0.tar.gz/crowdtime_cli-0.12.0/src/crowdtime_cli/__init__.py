"""CrowdTime CLI - AI-powered time tracking from the command line."""

__version__ = "0.12.0"
