# Termux-AI package initialization
