# AI-quickstart prompt

The canonical prompt for driving Efterlev with an AI assistant (Claude
Code, Cursor, Codex, Kiro, or any tool with shell access). Paste it
verbatim and the assistant will:

- Confirm the repo root (catches the silent 20%-coverage-loss footgun).
- Ask which LLM backend you want — Anthropic API, AWS Bedrock, or
  Claude Code subscription — and surface ambient state (env vars, AWS
  creds, `claude` CLI presence) as informational, not decisional.
- For Bedrock: pick the latest Sonnet inference profile, default to it,
  surface Opus / Haiku as overrides.
- Install or upgrade Efterlev. Detects pipx vs uv and gives the right
  command per installer.
- Run `efterlev report run` — the one-command pipeline (init → scan →
  agent gap → agent document → poam → oscal poam → oscal cd). Per-stage
  wall-clock prints inline; a timing summary lands at the end.
- Surface the readiness scorecard and offer to bundle a 3PAO submission
  package.
- Brief you on the top 3 KSIs to focus on (biased toward SVC + IAM —
  the most-cited 3PAO finding categories) plus the partial-status KSIs
  best suited to `agent remediate`.

Cost (first run): ~$1–5 on Sonnet 4.6 depending on workspace size, or
~$3–10 on Opus. **Free on Claude Pro/Max subscription** (Claude Code
backend; no per-call billing). **Cache hits are free on every backend**
— re-running `report run` on the same workspace replays from disk
(v0.1.151+). Wall time: 2–25 minutes for the first run depending on
workspace size; subsecond per stage on cache hit. The prompt's
constraints section sets a soft cap ($5 Anthropic / $8 Bedrock) that
the assistant tracks by `tail .efterlev/receipts.log` between stages
— Efterlev itself doesn't enforce a cap, the assistant does.

The prompt is self-contained — no other docs needed for the assistant
to drive end-to-end.

---

```text
You are helping me run Efterlev (https://efterlev.com) against my Terraform
for the first time. Efterlev is a FedRAMP 20x compliance scanner that reads
Terraform / CloudFormation / Python CDK, classifies it against 60 Key
Security Indicators, and drafts FRMR-compatible attestations and OSCAL
1.0.4 artifacts (POA&M + Component-Definition) with cited evidence. It
runs locally; the only outbound call is to the LLM endpoint I configure.

## Step 0 — confirm the target path

This is the silent footgun, so handle it first.

Ask me for the **absolute path to my repo root** — NOT a Terraform
subdirectory like `infra/terraform/`. Efterlev needs the repo root to
walk all three evidence sources:

  - `**/*.tf`, `**/*.yaml/.json` (CFN templates), `**/*.py` (CDK Python)
    for the IaC detectors
  - `.github/workflows/*.yml` for the GitHub-workflow detectors
    (5 detectors, ~10% of coverage)
  - `.efterlev/manifests/*.yml` for procedural-KSI attestations
    (covers the AFR / CED / INR themes, ~10% of coverage)

If I name a subdir, you'll silently miss workflows + manifests — about
20% of detector coverage disappears with no error message. So:

1. Ask me for the path.
2. Verify it's a git repo root: check for `.git/` AND at least one of
   `**/*.tf` OR `.github/workflows/`.
   - If only one is present, confirm with me before proceeding ("I see
     Terraform but no workflows — is this a repo root or a subdir?").
   - **If NEITHER is present** (no `.git/`, no `*.tf`, no workflows),
     I probably don't have a real target yet. Offer the demo repo as
     a turnkey test fixture so I can see Efterlev work without
     setting up my own:

         "I don't see a Terraform or workflow target at that path.
          Want to test against the demo repo lhassa8/govnotes-demo?
          It's a FedRAMP-shaped fixture with ~140 resources across
          Terraform + workflows + manifests — designed exactly for
          this walk-through. I can clone it for you:

              git clone https://github.com/lhassa8/govnotes-demo \
                ~/govnotes-demo

          Then I'll re-verify and proceed from there."

     Wait for my answer before cloning. If I say yes, clone and treat
     the cloned path as the verified target. If I say no, ask me
     where to look.
3. `cd` to that path and stay there for the rest of the run.

## Step 1 — pick the LLM backend

**Always ask me this question — do NOT auto-decide based on env vars,
AWS profile state, `claude` CLI presence, or any other ambient signal.**
The presence of an `ANTHROPIC_API_KEY` doesn't mean I want to use it for
this run; many users have credentials for multiple backends and testing
one specifically is the whole point.

You may surface ambient state as informational context, but the choice
is mine:

  > "I see `ANTHROPIC_API_KEY` is set, `aws sts get-caller-identity`
  >  succeeds for region us-east-1, and `claude` is on PATH. Which
  >  backend would you like to use for this run?
  >
  >    (a) Direct Anthropic API — fastest path; uses your existing key.
  >    (b) AWS Bedrock — uses your AWS credentials; works for GovCloud
  >        and FedRAMP-authorized infra.
  >    (c) Claude Code subscription — Pro/Max users; zero per-call
  >        billing, run from your existing subscription."

Only proceed once I've answered. If I'm genuinely undecided and ask
you to choose, default to whichever is cheapest given my ambient state:
(c) > (a) > (b). Say so explicitly.

Trade-off summary, if I want it:

  - **Anthropic API** — ~2 min setup, one env var, no AWS account.
  - **Bedrock** — ~5–10 min setup (model-access opt-in + inference
    profile selection), works at FedRAMP-authorized scale.
  - **Claude Code subscription** — ~30s setup (run `claude` once to
    sign in), zero per-call billing for Pro/Max plans, but the
    underlying API tokens still count against your subscription's
    fair-use ceiling.

## Step 2a — Anthropic API path

The fast path. ~2 minutes from zero to running.

1. Confirm I have an Anthropic API key. Verify:
       echo "${ANTHROPIC_API_KEY:0:10}"
   Must start with `sk-ant-` (Anthropic-format). If it starts with
   `sk-proj-` or any other prefix, that's a different vendor's key and
   won't authenticate against Anthropic — stop and ask me to set
   `ANTHROPIC_API_KEY` to an actual Anthropic key. If empty, point me
   at https://console.anthropic.com/settings/keys.
2. Install or upgrade (see Step 2d for installer-specific commands).
3. Confirm `efterlev --version`. Check the latest published version
   with whichever of these is on PATH: `pip index versions efterlev`,
   `pip3 index versions efterlev`, or `uv pip index versions efterlev`.
   If the binary is older than the latest, clean-reinstall per Step 2d.

Then jump to Step 3.

## Step 2b — Bedrock path

Bedrock connects you to LLMs hosted on AWS. Same Anthropic models, just
billed through your AWS account.

### Step 2b.0 — pick the model family

Ask me which model family I want to use:

  (a) Anthropic Claude — RECOMMENDED. This is what Efterlev's agents
      are tuned for; the only family with full feature support today.
  (b) Other (OpenAI / AI21 / Cohere / Meta / Mistral / Nvidia Nemotron)
      — not yet supported as a full backend (Nemotron pricing is wired
      for benchmark dispatches only).

If I say anything other than Claude, gently flag it's not yet
supported, recommend Claude as the working path, and only proceed if
I explicitly confirm I want to wait. The rest of this step assumes
Claude.

### Step 2b.1 — region and credentials

1. Ask me which AWS region to use. Default suggestion: `us-east-1`
   (us-west-2 is the other reliable option). Verify creds:

       aws sts get-caller-identity --region <region>

   If this fails, stop — I need to run `aws configure` first.

2. Confirm Anthropic model access is enabled in this account. The #1
   cold-start cliff. Visit:

       https://console.aws.amazon.com/bedrock/home?region=<region>#/modelaccess

   At least one Claude 4.x must show "Access granted." If not, request
   access there (~near-instant for most accounts) and wait a minute to
   propagate before continuing.

### Step 2b.2 — pick the tier

3. Discover available Claude inference profiles in that region.
   CRITICAL: use `--no-paginate --max-results 1000`. The default page
   size silently truncates at ~100, and older Claude 3.x profiles fill
   the first page hiding 4.x. Run:

       aws bedrock list-inference-profiles --region <region> \
           --type-equals SYSTEM_DEFINED \
           --no-paginate --max-results 1000 \
         | jq -r '.inferenceProfileSummaries[]
                  | select(.inferenceProfileName | test("claude"; "i"))
                  | "\(.inferenceProfileName)\t\(.inferenceProfileArn)"'

   Group results by tier (Opus / Sonnet / Haiku), pick the LATEST
   version of each. Prefer regional `us.` / `eu.` profiles over
   global. If NO 4.x profiles appear after `--no-paginate`, model
   access from step 2 isn't actually granted — go back.

4. Present this as a recommendation, NOT a multiple-choice question.
   Pick the latest Sonnet ARN as MODEL_ARN unless I explicitly object:

       Recommended: Latest Sonnet (claude-sonnet-4-6)
         — Best cost/quality balance for this workload.
         — ~5× cheaper than Opus; classification quality
           indistinguishable from Opus on the 60-KSI sweep.
         — Run cost: ~$1–5 on a typical mid-size codebase.

       Override only if you have a specific reason:
         — Latest Opus (claude-opus-4-7): higher reasoning ceiling,
           ~5× the spend. Worth it for ambiguous codebases.
         — Latest Haiku (claude-haiku-4-5): cheapest tier; validated at
           99.1% precision + 100% recall across labeled fixtures
           (v0.1.118). Fine for smoke tests and re-runs.

   If a tier is unavailable in this account, omit it from the
   alternatives. Capture the chosen `inferenceProfileArn` as MODEL_ARN.

## Step 2c — Claude Code subscription path

The zero-billing path for Pro/Max subscribers.

1. Verify `claude` is on PATH:
       which claude
   If missing, point me at https://claude.com/code/install and stop.
2. Verify subscription is active by running:
       claude --print --output-format json "ping"
   A successful JSON response with `"is_error": false` means the OAuth
   session is good. A 401 means I need to run `claude` interactively
   once to refresh the session.
3. Install or upgrade Efterlev (Step 2d).

**Configuration**: pass `--llm-backend=claude_code` to `efterlev init`
in Step 3 — no post-init config edit needed (v0.1.158+). Init writes
`fallback_model = "claude-opus-4-7"` automatically on this backend
because Claude Code Pro/Max bills against your subscription quota, NOT
per-token, so there's no cost difference between Sonnet, Opus, and
Haiku — Opus is free upside. (On Anthropic API / Bedrock, init keeps
`fallback_model = "claude-sonnet-4-6"` since Opus is ~5× the spend
there.)

Note on per-agent overrides: the Gap Agent already uses Opus 4.7 by
default (its `default_model` overrides the workspace fallback). The
Documentation Agent uses Sonnet 4.6 by design — extractive writing
doesn't need Opus reasoning. The `fallback_model` only affects agents
that don't have a stronger built-in default, which on subscription
makes Opus the right choice.

Efterlev strips `ANTHROPIC_API_KEY` from the subprocess environment
automatically so my parent-shell key doesn't override the subscription
session.

## Step 2d — install Efterlev

**Pick the path that matches your installer.** pipx and uv tool manage
isolated venvs at different paths; using the wrong installer's commands
silently fails to find the package. `efterlev doctor` detects which
installer was used and gives the right hint when boto3 is missing, but
you can pre-empt the round-trip.

- **pipx users:**
  - First-time (Anthropic / Claude Code backend):
        pipx install efterlev
  - First-time (Bedrock backend — extras need quotes):
        pipx install 'efterlev[bedrock]'
    If pipx itself is missing: `brew install pipx` first. **macOS
    gotcha**: a fresh `brew install` puts pipx at `/opt/homebrew/bin/`,
    which isn't on the default PATH for new shells. Either run
    `pipx ensurepath` and restart the shell, or for the current
    session: `export PATH="/opt/homebrew/bin:$PATH"`. If `efterlev`
    doesn't resolve after `pipx install efterlev`, this is why.
  - Upgrade: `pipx upgrade efterlev` (drop the `[bedrock]` bracket —
    extras are install-time only). If the prior install was non-
    Bedrock and you're switching, also run:
        pipx inject efterlev boto3
    Verify: `pipx runpip efterlev show boto3`.

- **uv tool users** (e.g. `uv tool install efterlev` previously):
  - Install or re-install (with extra if Bedrock):
        uv tool install --reinstall 'efterlev[bedrock]'   # Bedrock
        uv tool install --reinstall efterlev              # Anthropic / Claude Code

- Confirm `efterlev --version` matches the latest published release.
  Check the latest with whichever of these is on PATH:
  `pip index versions efterlev`, `pip3 index versions efterlev`, or
  `uv pip index versions efterlev`. If older, clean-reinstall.

## Step 3 — run the pipeline (one command)

You're at the repo root from Step 0. Run the full pipeline as a single
command. This chains init → scan → agent gap → agent document → poam →
oscal poam → oscal component-definition with per-stage wall-clock and
an end-of-run timing summary.

**Set expectations with me BEFORE kicking it off.** On a real-shape
repo (~100+ resources, 60 KSIs to classify), `report run` typically
takes 10-25 minutes — the gap stage alone is 60 sequential LLM calls.
Tell me the projected duration up front so I don't sit wondering if
it hung. Example phrasing:

  > "Heads up: this is a fresh run on a 60-KSI baseline. Expect
  >  10-25 min total — the gap stage (60 LLM calls) is the longest
  >  stretch, typically 5-15 min. Documentation is ~5-15 min more.
  >  POA&M and OSCAL stages are deterministic and finish in seconds.
  >  Re-runs on the same workspace replay from cache in seconds
  >  total. Kicking off now."

The `efterlev report run` command itself also prints this upfront
("Expected wall-clock: ~10-25 min on first run; cache replays are
near-instant") so the timing context is visible whether or not you
relayed it.

**If stdout is buffered** (common when Claude Code or other CLIs
background the long-running process), the per-stage progress doesn't
appear in real time. Peek at `.efterlev/receipts.log` and
`ls -t efterlev-out/reports/` periodically to surface which stage is in
flight. Don't silently sit through 15 minutes of "nothing happening"
— check artifacts every ~2 min and report progress to me.

  - Anthropic API backend:
        efterlev init --target . --force --llm-backend=anthropic
        efterlev report run --target .

  - Claude Code subscription backend (v0.1.158+, no manual config edit):
        efterlev init --target . --force --llm-backend=claude_code
        efterlev report run --target .

  - Bedrock backend (pass the ARN you captured in Step 2b.2):
        efterlev init --target . --force \
          --llm-backend=bedrock --llm-region=<region> --llm-model=<MODEL_ARN>
        efterlev report run --target .

The `--force` on init preserves customer-authored `.efterlev/manifests/`
(the only sticky state worth keeping) and regenerates the FRMR cache,
provenance store, and `config.toml`. Skip `--force` only if I tell you
I have an in-progress workspace with hand-edited `config.toml` I want
to preserve.

If the pipeline fails partway, the failing stage's error message is
your only signal (the end-of-run timing summary only prints on full
success). Read the stderr text and decide:

  - **`ANTHROPIC_API_KEY is not set` / 401 / credentials error**:
    stop and fix the backend setup before re-running.
  - **Bedrock model-access denied**: go back to Step 2b.1.
  - **Anything else**: stop and ask me — don't paper over.

To resume after a fix, just re-run `efterlev report run` — scan
replays cached evidence (write-time dedupe, v0.1.155+) and any agent
stage that completed before the failure replays from the LLM cache
(v0.1.151+) so re-runs are cheap. Stages downstream of the failure
will run for real on the retry.

**Soft cost cap (you're responsible for this — no CLI enforcement
today):** before each agent stage on a fresh run, the cap is your
implicit budget. After each stage completes you can `tail -20
.efterlev/receipts.log` to see per-call $ — sum the most recent run's
calls and stop if you're approaching the cap.

### Scan-mode note

`efterlev scan` (which `report run` invokes) defaults to HCL mode for
`.tf` source. If I have `terraform` on PATH and want full module
coverage, run plan-JSON mode through the one-command pipeline using
the v0.1.158 `--scan-plan` flag:

    efterlev init --target . --force --llm-backend=anthropic   # or claude_code / bedrock
    terraform init                                              # or -backend=false
    terraform plan -out plan.bin                                # or -refresh=false
    terraform show -json plan.bin > plan.json
    efterlev report run --target . --scan-plan plan.json

Plan-JSON gives full module coverage; HCL keeps file:line citations
(which plan-JSON loses). If `terraform init` fails on a missing backend
(common when scanning a repo you don't operate), try
`terraform init -backend=false && terraform plan -refresh=false -out plan.bin`.
If both fail, drop to HCL mode (just omit `--scan-plan`) — don't burn
5 minutes on the terraform dance.

## Step 4 — brief me on the results

After `report run` completes, read the NEWEST gap-report JSON by
filesystem mtime. Filenames are timestamped
(`gap-YYYYMMDD-HHMMSS.json`), so:

    # v0.1.160+: artifacts land under efterlev-out/. Pre-v0.1.160 stores
    # still have artifacts under .efterlev/reports/ — glob both for safety:
    ls -t efterlev-out/reports/gap-*.json .efterlev/reports/gap-*.json 2>/dev/null | head -1

Open that file and tell me:

  - The classification breakdown — count of `implemented` / `partial`
    / `not_implemented` / `not_applicable` / `evidence_layer_inapplicable`.
  - Workspace boundary state (`workspace_boundary_state` field) — if
    `boundary_undeclared`, recommend running
    `efterlev boundary set --include 'pattern' --exclude 'pattern'`
    so the POA&M filter has scope to enforce. Important: if I declare
    `--include 'infra/terraform/**'`, ALL workflow evidence
    (`.github/workflows/*.yml`) becomes `out_of_boundary` because
    workflows aren't under `infra/terraform/`. To keep workflow
    findings in scope, pass two patterns:
    `--include 'infra/terraform/**' --include '.github/workflows/**'`.
  - **Top 3 KSIs to focus on**: pick the highest-impact `not_implemented`
    classifications. Bias toward the SVC theme (encryption, integrity,
    transport) and IAM (MFA, federation) — typically the most-cited
    finding categories in 3PAO reviews. For each: KSI id + name,
    one-line rationale from the report, canonical fix.
  - Any KSI classified `partial` — these are the texture cases where
    `efterlev agent remediate --ksi <id>` produces the most useful
    diff (mid-journey, not zero-to-one). Surface 2 of them.

Surface the documentation-agent breakdown too:
`agent_drafted` vs `deterministic_template` counts. The
`deterministic_template` rows are inapplicable KSIs that skipped the
LLM (the cost-saving path; ~70% of Sonnet spend would have been wasted
on procedural-only KSIs without it).

## Step 5 — readiness scorecard + 3PAO submission package

Run `efterlev readiness` — single-page heuristic scorecard (0–100%) with
progress bar, top-3 blockers, and suggested next commands. Deterministic;
zero LLM cost.

If I'm preparing to engage a 3PAO, also run `efterlev submission package`
— bundles every artifact (FRMR attestation, POA&M, OSCAL POA&M+CD, HTML
reports, manifests) into one zip with README + machine-readable
index.json + SHA-256 per artifact. Deterministic; zero LLM cost.

## Constraints

- Don't run `efterlev agent remediate` without me asking — it generates
  code-level diffs and I want to be in the loop.
- Don't modify my Terraform. Don't commit anything.
- Soft cost cap: $5 on the Anthropic path, $8 on the Bedrock path
  (Bedrock retries can burn more on first-run config issues), $0 on
  Claude Code subscription. Stop and check back before exceeding.
- If anything fails or surprises you, stop and ask — don't paper over.
- If a re-run goes back to ~50s per gap batch instead of ~0.1s, the
  cache isn't hitting — flag this; don't silently accept the long run.

## When done

Brief me with:
- Counts of `implemented` / `partial` / `not_implemented` /
  `not_applicable` / `evidence_layer_inapplicable` KSIs.
- Readiness score + top 3 blockers from `efterlev readiness`.
- Paths to: HTML gap report, FRMR attestation JSON, POA&M markdown,
  OSCAL POA&M JSON, OSCAL Component-Definition JSON, and the
  submission package zip if I asked for one.
- The per-stage timing summary from `report run` so I can see where
  wall-clock went.
- Anything notable: secrets caught by the redaction layer, KSIs flagged
  for review, modules where evidence was sparse.
```
