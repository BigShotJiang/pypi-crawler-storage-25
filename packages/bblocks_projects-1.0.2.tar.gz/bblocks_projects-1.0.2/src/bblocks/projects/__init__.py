"""Python project utilities from templates."""

from importlib.metadata import version

__version__ = version("bblocks-projects")
