import json
import os
import subprocess
from types import SimpleNamespace

import codex_agent.utils as utils
from codex_agent import Agent, ResponseContentDeltaEvent, ServerToolCallEvent, WebSearchTool
from codex_agent.builtin_plugins.image_generation import ImageGenerationTool
from codex_agent.message import (
    AssistantMessage,
    CompactionMessage,
    DeveloperMessage,
    MessageChunk,
    ServerToolResponseMessage,
    ToolResultMessage,
    UserMessage,
)
from codex_agent.sessions import AgentSession, UNRESOLVED_TOOL_RESULT_CONTENT


class FakeAI:
    def __init__(self, agent):
        self.agent = agent
        self.params = None

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="hi")
        message.add_chunk(chunk)
        self.agent.emit(
            ResponseContentDeltaEvent,
            delta="hi",
            content="hi",
            chunk=chunk,
            message=message,
        )
        return message


class FakeCodexClient:
    def __init__(self, events):
        self.events = events
        self.kwargs = None
        self.responses = self
        self.codex = self

    def create(self, **kwargs):
        self.kwargs = kwargs
        return iter(self.events)

    def usage(self):
        return {
            "rate_limit": {
                "primary_window": {"used_percent": 11},
                "secondary_window": {"used_percent": 22},
            }
        }


def response_event(event_type, **payload):
    return SimpleNamespace(type=event_type, **payload)


def output_item_event(item):
    return response_event("response.output_item.done", item=item)


def completed_event(model="gpt-test", input_tokens=0):
    return response_event(
        "response.completed",
        response={
            "id": "resp_123",
            "model": model,
            "usage": {"input_tokens": input_tokens},
        },
    )


def test_agent_get_response_emits_events_and_persists_assistant_message():
    agent = Agent(session="new")
    agent.ai = FakeAI(agent)
    seen = []
    agent.on(ResponseContentDeltaEvent, lambda event: seen.append(event.delta))

    message = agent.get_response()

    assert message.content == "hi"
    assert seen == ["hi"]
    assert agent.session.messages[-1] is message
    assert json.loads(json.dumps(message))["type"] == "assistant_message"
    assert agent.ai.params["text"] == agent.config.text
    assert agent.ai.params["reasoning"] == agent.config.reasoning
    assert agent.ai.params["parallel_tool_calls"] is True
    assert agent.ai.params["prompt_cache_key"] == agent.current_session_id
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "function" and tool["name"] == "edit" for tool in agent.ai.params["tools"])
    assert not any(tool["type"] == "custom" and tool["name"] == "python" for tool in agent.ai.params["tools"])
    assert not any(tool["type"] == "custom" and tool["name"] == "bash" for tool in agent.ai.params["tools"])
    assert not any(tool["type"] == "function" and tool["name"] == "show" for tool in agent.ai.params["tools"])
    assert {"type": "web_search"} not in agent.ai.params["tools"]
    assert {"type": "image_generation", "output_format": "png"} not in agent.ai.params["tools"]


def test_agent_get_response_does_not_write_api_success_session_backup(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")
    agent.ai = FakeAI(agent)
    agent.add_message(UserMessage(content="hello"))

    agent.get_response()

    assert not os.path.isfile(agent.session.api_success_backup_file)


def test_agent_get_response_repairs_unsane_session_before_api_call(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")
    stable = UserMessage(content="stable")
    agent.sessions_manager.append_message(stable)
    corrupt = AssistantMessage(content="corrupt")
    corrupt.tool_calls = [{
        "index": 0,
        "type": "custom_tool_call",
        "call_id": "call_missing",
        "name": "desktop",
        "input": "{}",
    }]
    agent.session.messages.append(corrupt)
    agent.session.save()

    class RecordingAI(FakeAI):
        def run(self, **params):
            self.params = params
            return AssistantMessage(content="recovered")

    agent.ai = RecordingAI(agent)

    message = agent.get_response()

    assert message.content == "recovered"
    assert corrupt in agent.session.messages
    synthetic = next(
        msg for msg in agent.session.messages
        if isinstance(msg, ToolResultMessage) and msg.call_id == "call_missing"
    )
    assert synthetic.content == UNRESOLVED_TOOL_RESULT_CONTENT
    assert synthetic.tool_call_type == "custom_tool_call"
    assert agent.session.is_sane() is True
    restored = AgentSession.load(agent.current_session_id).messages
    assert corrupt.id in [msg.id for msg in restored]
    assert synthetic.id in [msg.id for msg in restored]
    assert any((tmp_path / "sessions").glob(f"{agent.current_session_id}.json.broken_*"))


def test_agent_should_auto_compact_uses_ninety_percent_threshold(monkeypatch):
    agent = Agent(session="new", input_token_limit=100)
    messages = [DeveloperMessage(content="context")]

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", lambda *_args, **_kwargs: 90)
    assert agent.context_manager.should_auto_compact(messages) is False

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", lambda *_args, **_kwargs: 91)
    assert agent.context_manager.should_auto_compact(messages) is True

    agent.config.auto_compact = False
    assert agent.context_manager.should_auto_compact(messages) is False


def test_agent_should_auto_compact_counts_response_tool_specs(monkeypatch):
    agent = Agent(session="new", input_token_limit=100)
    messages = [DeveloperMessage(content="context")]
    seen = []

    def count(messages_arg, response_tools=None):
        seen.append(response_tools)
        return 91

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", count)
    assert agent.context_manager.should_auto_compact(messages) is True
    assert seen == [agent.tools_manager.get_response_tools()]


def test_agent_get_response_auto_compacts_before_backend_call(monkeypatch):
    agent = Agent(session="new")
    agent.ai = FakeAI(agent)
    calls = []
    agent.session.messages.extend([
        DeveloperMessage(content="compact me"),
        AssistantMessage(content="done"),
    ])

    def compact(session, **params):
        calls.append(params)
        message = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
        session.messages.append(message)
        return message

    agent.context_manager.should_auto_compact = lambda _messages: True
    monkeypatch.setattr(AgentSession, "compact", compact)

    agent.get_response()

    assert calls == [{
        "model": agent.config.compaction_model,
        "max_input_tokens": agent.config.max_input_tokens,
        "instructions": agent.config.compaction_instructions,
    }]
    assert any(isinstance(message, CompactionMessage) for message in agent.ai.params["messages"])


def test_agent_combines_local_and_server_tools_for_response():
    agent = Agent(
        session="new",
        builtin_plugins=["files", "python", "bash", "content"],
    )
    agent.ai = FakeAI(agent)
    agent.tools_manager.add_server_tool(WebSearchTool())
    agent.tools_manager.add_server_tool(ImageGenerationTool())

    agent.get_response()

    tools = agent.ai.params["tools"]
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "python" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "bash" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "show" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "edit" for tool in tools)
    assert {"type": "web_search"} in tools
    assert {"type": "image_generation", "output_format": "png"} in tools


def test_agent_emits_server_tool_call_event_from_output_items():
    agent = Agent(session="new", builtin_plugins=["files", "web_search"])
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([output_item_event(item)])
    seen = []

    agent.on(ServerToolCallEvent, lambda event: seen.append((event.name, event.call_id, event.status)))
    agent.ai.run(
        messages=[],
        tools=agent.tools_manager.get_response_tools(),
        **agent.config.extract("model", "reasoning", "text"),
    )

    assert seen == [("web_search", "ws_123", "completed")]
    assert agent.ai._codex_client.kwargs["prompt_cache_key"] is None


def test_agent_caches_status_from_completed_response():
    agent = Agent(session="new", input_token_limit=20_000)
    agent.ai._codex_client = FakeCodexClient([completed_event(input_tokens=4000)])

    agent.ai.run(messages=[], tools=[], model="gpt-test")

    status = agent.get_status()
    assert status.context_current_tokens == 4000
    assert status.context_limit_tokens == 20_000
    assert status.context_percent == 20
    assert status.quota_5h_percent == 11
    assert status.quota_7d_percent == 22
    assert status.model == "gpt-test"


def test_agent_persists_server_tool_output_items_as_messages():
    agent = Agent(session="new", builtin_plugins=["web_search"])
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([output_item_event(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]

    assert message.output_items[0].type == "web_search_call"
    assert "output_items" not in message
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == item
    assert server_message.to_response_format() == item


def test_open_silently_uses_detached_posix_opener(monkeypatch):
    import codex_agent.builtin_plugins.content.system as system_tools

    calls = []

    def fake_popen(command, **kwargs):
        calls.append((command, kwargs))

    monkeypatch.setattr(system_tools.os, "name", "posix")
    monkeypatch.setattr(system_tools.sys, "platform", "linux")
    monkeypatch.setattr(system_tools.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(system_tools.webbrowser, "open", lambda target: False)

    assert system_tools.open_silently("/tmp/file.txt") is True
    assert calls == [([
        "xdg-open",
        "/tmp/file.txt",
    ], {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
        "start_new_session": True,
    })]


def test_open_silently_falls_back_to_webbrowser_when_posix_opener_missing(monkeypatch):
    import codex_agent.builtin_plugins.content.system as system_tools

    calls = []

    def missing_opener(*args, **kwargs):
        raise FileNotFoundError

    def fake_web_open(target):
        calls.append(target)
        return True

    monkeypatch.setattr(system_tools.os, "name", "posix")
    monkeypatch.setattr(system_tools.subprocess, "Popen", missing_opener)
    monkeypatch.setattr(system_tools.webbrowser, "open", fake_web_open)

    assert system_tools.open_silently("https://example.com") is True
    assert calls == ["https://example.com"]


def test_open_tui_tool_bridges_to_agent_server():
    import codex_agent.builtin_plugins.content.system as system_tools
    from codex_agent.tool import reset_current_agent, set_current_agent
    from modict import modict

    class FakeAgent:
        def open_tui(self):
            return modict(opened=True, terminal_pid=1234)

    token = set_current_agent(FakeAgent())
    try:
        result = system_tools.open_tui()
    finally:
        reset_current_agent(token)

    assert result == "Opened TUI terminal process 1234."


def test_open_and_close_tui_tools_use_server_registered_tui():
    import codex_agent.builtin_plugins.content.system as system_tools
    from codex_agent.tool import reset_current_agent, set_current_agent
    from modict import modict

    class FakeAgent:
        def open_tui(self):
            return modict(already_open=True, tui=modict(pid=1234))

        def close_tui(self):
            return modict(closed=True, pid=1234)

    token = set_current_agent(FakeAgent())
    try:
        opened = system_tools.open_tui()
        closed = system_tools.close_tui()
    finally:
        reset_current_agent(token)

    assert opened == "TUI is already open with pid 1234."
    assert closed == "Closed TUI process 1234."


def test_agent_keeps_tool_outputs_contiguous_and_wrappers_pending():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def echo(value):
        return value

    message = AssistantMessage()
    message.tool_calls = [
        {
            "type": "function_call",
            "call_id": "call_1",
            "name": "echo",
            "arguments": '{"value": "one"}',
        },
        {
            "type": "function_call",
            "call_id": "call_2",
            "name": "echo",
            "arguments": '{"value": "two"}',
        },
    ]

    assert agent.mainloop_manager.call_tools(message) is True

    outputs = agent.session.messages[-2:]
    assert [output.call_id for output in outputs] == ["call_1", "call_2"]
    assert [output.type for output in outputs] == ["tool_result_message", "tool_result_message"]
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_1", "call_2"]
    assert [wrapper.content for wrapper in agent.mainloop_manager.pending[-2:]] == ["one", "two"]
    assert [wrapper.turns_left for wrapper in agent.mainloop_manager.pending[-2:]] == [3, 3]


def test_agent_can_enable_builtin_server_tools_from_plugins():
    agent = Agent(
        session="new",
        builtin_plugins=["web_search", "image_generation"],
    )

    assert {tool.type for tool in agent.tools_manager.get_server_tools()} == {"web_search", "image_generation"}


def test_codex_stream_params_forward_text_prompt_cache_key_and_parallel_tool_calls():
    agent = Agent(session="new", text={"verbosity": "low"})
    tools = [{"type": "function", "name": "noop", "parameters": {"type": "object"}}]

    params = agent.ai._to_codex_response_params({
        "messages": agent.context_manager.get_context(),
        "tools": tools,
        "text": agent.config.text,
        "parallel_tool_calls": True,
        "prompt_cache_key": agent.current_session_id,
    })

    assert params["text"] == {"verbosity": "low"}
    assert params["parallel_tool_calls"] is True
    assert params["prompt_cache_key"] == agent.current_session_id


def test_codex_stream_params_disable_parallel_tool_calls_without_tools():
    agent = Agent(session="new")

    params = agent.ai._to_codex_response_params({
        "messages": agent.context_manager.get_context(),
        "tools": [],
        "parallel_tool_calls": True,
    })

    assert params["tool_choice"] == "none"
    assert params["parallel_tool_calls"] is True


def test_restart_server_calls_server_endpoint(monkeypatch):
    agent = Agent(session="new")
    calls = []
    monkeypatch.setattr(agent.runtime, "call_server_endpoint", lambda method, path, payload=None: calls.append((method, path, payload)) or {"restarting": True})
    result = agent.runtime.restart_server(prompt="resume", title="after update")
    assert result["restarting"] is True
    assert calls == [("POST", "/restart", {"prompt": "resume", "title": "after update"})]


def test_restart_server_and_wakeup_stops_agentic_loop(monkeypatch):
    agent = Agent(session="new")
    monkeypatch.setattr(agent.runtime, "restart_server", lambda prompt=None, title="": {"restarting": True, "wakeup_persisted": True})

    result = agent.plugins.scheduler.restart_server_and_wakeup(prompt="resume", title="after update")

    assert agent.mainloop_manager.stop_agentic_loop is True
    assert "Server restart requested" in result
