from codex_agent.config import ConfigManager, parse_config_value


class DummyAgent:
    pass


def manager_with_builtin_field(field, value):
    agent = DummyAgent()
    manager = ConfigManager(agent)
    setattr(manager.config, field, value)
    return manager


def test_parse_config_value_handles_cli_scalars_and_json():
    cases = {
        "true": True,
        "yes": True,
        "on": True,
        "1": True,
        "false": False,
        "no": False,
        "off": False,
        "0": False,
        "none": None,
        "null": None,
        "128": 128,
        "-7": -7,
        "3.5": 3.5,
        "1e3": 1000.0,
        '{"model":"test"}': {"model": "test"},
        '["memory"]': ["memory"],
    }
    for raw, expected in cases.items():
        assert parse_config_value(raw) == expected


def test_parse_config_value_preserves_unknown_strings_and_values():
    assert parse_config_value("gpt-test") == "gpt-test"
    assert parse_config_value(True) is True
    assert parse_config_value({"already": "parsed"}) == {"already": "parsed"}


def test_apply_config_defaults_accepts_legacy_alias_arguments():
    agent = DummyAgent()
    manager = ConfigManager(agent)

    config = manager.apply_config_defaults(
        "legacy_plugin",
        legacy_agent_aliases={"old": "new"},
        legacy_agent_sections=["old_section"],
    )

    assert config is not None
    assert agent.config is manager.config


def test_builtin_plugin_enabled_none_loads_everything():
    manager = manager_with_builtin_field("builtin_plugins", None)

    assert manager.builtin_plugin_enabled("bash") is True
    assert manager.builtin_plugin_enabled("anything") is True


def test_builtin_plugin_enabled_empty_list_loads_nothing():
    manager = manager_with_builtin_field("builtin_plugins", [])

    assert manager.builtin_plugin_enabled("bash") is False


def test_builtin_plugin_enabled_list_loads_only_named_builtins():
    manager = manager_with_builtin_field("builtin_plugins", ["memory", "planner"])

    assert manager.builtin_plugin_enabled("memory") is True
    assert manager.builtin_plugin_enabled("planner") is True
    assert manager.builtin_plugin_enabled("browser") is False
