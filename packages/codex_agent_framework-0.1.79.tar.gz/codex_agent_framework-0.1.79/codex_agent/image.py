from .message import Message, register_message_type
from .utils import guess_extension_from_bytes, runtime_join, short_id, timestamp
import base64
import binascii
from collections.abc import Mapping
from io import BytesIO
import os
import re
import math

from PIL import Image as PILImage
import requests
from urllib.parse import urlparse


IMAGE_CACHE_ATTR = 'b64_string'
IMAGE_DIR = 'images'


def ext_to_mime(ext):
    """Return the MIME type matching a common image extension."""
    ext = ext.lower().lstrip('.')
    if ext in ('jpg', 'jpeg'):
        return 'image/jpeg'
    if ext == 'png':
        return 'image/png'
    if ext == 'webp':
        return 'image/webp'
    if ext == 'gif':
        return 'image/gif'
    return None


def _data_url(data, mime_type):
    b64 = base64.b64encode(data).decode('utf-8')
    return f"data:{mime_type};base64,{b64}"


def data_url_from_file(path):
    """Read a local image file and encode it as a data URL."""
    ext = os.path.splitext(path)[1]
    mime_type = ext_to_mime(ext) or 'image/jpeg'
    with open(path, 'rb') as f:
        return _data_url(f.read(), mime_type)


def image_request_headers(url):
    """Return browser-like headers for remote image fetches.

    Some image hosts/CDNs reject the default python-requests user agent even
    for public images. A small, stable header set makes observe() much more
    reliable without changing semantics.
    """
    parsed = urlparse(url)
    referer = f"{parsed.scheme}://{parsed.netloc}/" if parsed.scheme and parsed.netloc else None
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 codex-agent/observe"
        ),
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    }
    if referer:
        headers["Referer"] = referer
    return headers


def image_mime_from_source(source, content_type=None):
    """Infer an image MIME type from headers, paths, or bytes-like sources."""
    content_type = (content_type or '').split(';')[0].strip()
    if content_type.startswith('image/'):
        return content_type
    if isinstance(source, str):
        ext = os.path.splitext(source.split('?', 1)[0])[1]
        return ext_to_mime(ext) or 'image/jpeg'
    return 'image/png'


def fetch_image_bytes(url, timeout=15):
    """Download image bytes and validate or infer their MIME type."""
    response = requests.get(url, timeout=timeout, headers=image_request_headers(url))
    response.raise_for_status()

    data = response.content
    if not data:
        raise ValueError(f"URL resolved to an empty image response: {url!r}")

    content_type = response.headers.get('content-type')
    content_mime = (content_type or '').split(';')[0].strip()
    guessed_mime = ext_to_mime(guess_extension_from_bytes(data) or '')

    if content_mime and not content_mime.startswith('image/'):
        if not guessed_mime:
            raise ValueError(f"URL did not resolve to an image: {url!r} ({content_mime})")
        return data, guessed_mime

    return data, guessed_mime or image_mime_from_source(url, content_type)


def data_url_from_url(url):
    """Fetch a remote image URL and encode it as a data URL."""
    data, mime_type = fetch_image_bytes(url)
    return _data_url(data, mime_type)


def persist_image_url(url):
    """Download a remote image and persist it in the runtime image cache."""
    data, mime_type = fetch_image_bytes(url)
    ext = os.path.splitext(url.split('?', 1)[0])[1] or None
    mime_ext = {
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/webp': '.webp',
        'image/gif': '.gif',
    }.get(mime_type)
    if mime_ext and ext_to_mime(ext or '') != mime_type:
        ext = mime_ext
    return persist_image_bytes(data, name=f"remote{ext or ''}")


def get_data_url(source):
    """Return a data URL for a supported local path or remote URL source."""
    if isinstance(source, str) and os.path.isfile(source):
        return data_url_from_file(source)
    if isinstance(source, str) and source.startswith(('http://', 'https://')):
        return data_url_from_url(source)
    raise ValueError(f"Unsupported image source: {source!r}")


def persist_image_bytes(data, name=None):
    """Persist raw image bytes under the runtime image cache directory."""
    _, ext = os.path.splitext(name) if isinstance(name, str) else ('', '')
    ext = ext or guess_extension_from_bytes(data) or '.png'

    folder = runtime_join(IMAGE_DIR)
    os.makedirs(folder, exist_ok=True)

    path = runtime_join(IMAGE_DIR, f"{timestamp()}_{short_id()}{ext}")
    with open(path, 'wb') as f:
        f.write(data)
    return path


def persist_bytesio(source):
    """Persist a BytesIO image source, preserving its filename extension."""
    return persist_image_bytes(source.getvalue(), name=getattr(source, 'name', None))


def image_name_from_source(source):
    """Return a human-friendly image name for paths, URLs, or byte streams."""
    if isinstance(source, BytesIO) and getattr(source, 'name', None):
        return os.path.basename(source.name)
    if isinstance(source, str) and os.path.isfile(source):
        return os.path.basename(source)
    if source:
        return str(source)
    return 'Unnamed image'


def image_uses_patch_tokenization(model):
    model = str(model or "")
    return model.startswith((
        "gpt-5.4",
        "gpt-5.2",
        "gpt-5.3-codex",
        "gpt-5-codex-mini",
        "gpt-5.1-codex-mini",
        "gpt-5-mini",
        "gpt-5-nano",
        "o4-mini",
    )) or model in ("gpt-4.1-mini-2025-04-14", "gpt-4.1-nano-2025-04-14")


def image_patch_multiplier(model):
    model = str(model or "")
    if model.startswith(("gpt-5.4-mini", "gpt-5-mini")) or model == "gpt-4.1-mini-2025-04-14":
        return 1.62
    if model.startswith(("gpt-5.4-nano", "gpt-5-nano")) or model == "gpt-4.1-nano-2025-04-14":
        return 2.46
    if model.startswith("o4-mini"):
        return 1.72
    return 1.0


def image_patch_budget(detail="auto", model=None):
    model = str(model or "")
    detail = detail or "auto"
    if detail == "low":
        return None
    if model.startswith("gpt-5.5"):
        return 10000 if detail in ("auto", "original") else 2500
    if model.startswith("gpt-5.4"):
        return 10000 if detail == "original" else 2500
    return 1536


def image_patch_token_count(width, height, detail="auto", model=None):
    if detail == "low":
        return 64
    width = max(1, int(width))
    height = max(1, int(height))
    budget = image_patch_budget(detail=detail, model=model)
    max_dimension = 6000 if detail == "original" and str(model or "").startswith(("gpt-5.4", "gpt-5.5")) else 2048
    scale = min(max_dimension / width, max_dimension / height, 1)
    width *= scale
    height *= scale

    patches = math.ceil(width / 32) * math.ceil(height / 32)
    if budget and patches > budget:
        shrink = math.sqrt((32 * 32 * budget) / (width * height))
        scaled_width = width * shrink
        scaled_height = height * shrink
        width_patches = max(1, math.floor(scaled_width / 32))
        height_patches = max(1, math.floor(scaled_height / 32))
        adjusted = shrink * min(
            width_patches / (scaled_width / 32),
            height_patches / (scaled_height / 32),
        )
        width *= adjusted
        height *= adjusted
        patches = math.ceil(width / 32) * math.ceil(height / 32)
    return math.ceil(patches * image_patch_multiplier(model))


def image_token_rates(model):
    model = str(model or "")
    if model.startswith("gpt-5"):
        return 70, 140
    if model.startswith("gpt-4o-mini"):
        return 2833, 5667
    if model.startswith(("o1", "o3")):
        return 75, 150
    if model.startswith(("gpt-4o", "gpt-4.1", "gpt-4.5")):
        return 85, 170
    return 85, 170


def image_input_token_count(width, height, detail="auto", model=None):
    if image_uses_patch_tokenization(model):
        return image_patch_token_count(width, height, detail=detail, model=model)

    base_tokens, tile_tokens = image_token_rates(model)
    if detail == "low":
        return base_tokens

    width = max(1, int(width))
    height = max(1, int(height))
    scale = min(2048 / width, 2048 / height, 1)
    width *= scale
    height *= scale

    shortest = min(width, height)
    if shortest > 768:
        scale = 768 / shortest
        width *= scale
        height *= scale

    tiles = math.ceil(width / 512) * math.ceil(height / 512)
    return base_tokens + tiles * tile_tokens


def normalize_image_content(content):
    if isinstance(content, BytesIO):
        return persist_bytesio(content)
    if isinstance(content, bytes):
        return persist_image_bytes(content)
    if content is not None and not isinstance(content, str):
        raise TypeError(f"Image content must be a path, URL, BytesIO, or bytes. Got {type(content).__name__}.")
    return content


@register_message_type
class ImageMessage(Message):
    """Image message with a lightweight serialized payload.

    The session stores only reloadable ``content``. The base64 data URL is
    cached as runtime metadata and generated only when formatting API input.
    """

    detail = "auto"
    description = None
    image_name = None
    embedding = None
    name = 'image'
    role = "user"

    def __init__(self, *args, **kwargs):
        args, kwargs, data_url, content_name = self._prepare_init_payload(args, kwargs)
        super().__init__(*args, **kwargs)

        if not self.get('image_name'):
            self.image_name = content_name or image_name_from_source(self.get('content'))

        if data_url:
            self.set_attr(IMAGE_CACHE_ATTR, data_url)

    @classmethod
    def _prepare_init_payload(cls, args, kwargs):
        kwargs = dict(kwargs)
        data_url = kwargs.pop(IMAGE_CACHE_ATTR, None)
        content = kwargs.get('content')

        if args and isinstance(args[0], Mapping):
            data = dict(args[0])
            data_url = data.pop(IMAGE_CACHE_ATTR, data_url)
            if 'content' in data:
                if 'content' not in kwargs:
                    content = data['content']
                data['content'] = normalize_image_content(data['content'])
            args = (data, *args[1:])

        if 'content' in kwargs:
            content = kwargs['content']
            kwargs['content'] = normalize_image_content(content)

        content_name = image_name_from_source(content) if content is not None else None
        return args, kwargs, data_url, content_name

    def get_base64(self):
        data_url = self.get_attr(IMAGE_CACHE_ATTR, None)
        if data_url:
            return data_url

        try:
            data_url = get_data_url(self.get('content'))
        except Exception:
            return None

        self.set_attr(IMAGE_CACHE_ATTR, data_url)
        return data_url

    def is_valid(self):
        data_url = self.get_base64()
        if not isinstance(data_url, str) or not data_url.startswith('data:image/'):
            return False
        match = re.match(r"^data:image/[^;]+;base64,(.*)$", data_url)
        if not match:
            return False
        try:
            image_bytes = base64.b64decode(match.group(1), validate=True)
        except (binascii.Error, ValueError):
            return False
        try:
            with PILImage.open(BytesIO(image_bytes)) as img:
                img.verify()
        except Exception:
            return False
        return True

    def content_to_response_parts(self, output=False):
        data_url = self.get_base64()
        if not data_url:
            return [{
                'type': 'input_text',
                'text': f"Unable to access the image ({self.image_name!r})",
            }]

        text = (
            "The following image has been made available in context for visual analysis:\n"
            + repr(self.image_name)
        )
        if self.get('description'):
            text += f"\nAlong with the following description:\n{self.description}\n"

        return [
            {
                'type': 'input_image',
                'image_url': data_url,
                'detail': self.detail,
            },
            {
                'type': 'input_text',
                'text': text,
            },
        ]

    def to_response_format(self):
        return {
            "type": "message",
            "role": self.role,
            "content": self.content_to_response_parts(),
        }

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["image_name"] = self.get("image_name")
        attrs["detail"] = self.get("detail")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        parts = []
        if self.get("content"):
            parts.append(f"<source>{self.content}</source>")
        if self.get("description"):
            parts.append(f"<description>{self.description}</description>")
        return "\n".join(parts)

    def as_bytesio(self):
        """Return the in-memory image payload as bytes, when available."""
        data_url = self.get_base64()
        if not data_url:
            return None

        match = re.match(r"^data:image/[^;]+;base64,(.*)$", data_url)
        if not match:
            return None
        return BytesIO(base64.b64decode(match.group(1)))

    def image_size(self):
        """Return image dimensions, or None when the payload is unavailable."""
        img_bytes = self.as_bytesio()
        if not img_bytes:
            return None
        try:
            with PILImage.open(img_bytes) as img:
                return img.size
        except Exception:
            return None

    def api_token_fingerprint(self):
        """Return a stable fingerprint for cached image token estimates."""
        import hashlib
        import json

        payload = {
            "class": type(self).__name__,
            "content": self.get("content"),
            "description": self.get("description"),
            "detail": self.get("detail"),
            "image_name": self.get("image_name"),
            "size": self.image_size(),
        }
        text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def compute_api_token_count(self, model=None):
        """Estimate text-structure and visual-token cost for the image message."""
        size = self.image_size()
        text = (
            "The following image has been made available in context for visual analysis:\n"
            + repr(self.image_name)
        )
        if self.get('description'):
            text += f"\nAlong with the following description:\n{self.description}\n"

        from .utils import token_count_payload

        structure_tokens = token_count_payload({
            "type": "message",
            "role": self.role,
            "content": [
                {"type": "input_image", "image_url": "<image>", "detail": self.detail},
                {"type": "input_text", "text": text},
            ],
        }, model=model)
        if not size:
            return structure_tokens
        return structure_tokens + image_input_token_count(*size, detail=self.detail, model=model)

    def show(self):
        img_bytes = self.as_bytesio()
        if not img_bytes:
            print("[ImageMessage.show] Image non disponible en mémoire.")
            return

        try:
            PILImage.open(img_bytes).show()
        except Exception as e:
            print(f"[ImageMessage.show] Erreur lors de l'affichage : {e}")
