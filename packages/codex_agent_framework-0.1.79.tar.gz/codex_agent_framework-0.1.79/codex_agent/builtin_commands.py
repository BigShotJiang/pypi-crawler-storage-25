"""Built-in slash commands."""

from modict import modict

from .command import command
from .config import parse_config_value
from .sessions import AgentSession
from .tool import get_agent


def _format_lines(value, prefix=""):
    if isinstance(value, dict):
        lines = []
        for key, child in value.items():
            full_key = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(child, dict):
                lines.append(f"{full_key}:")
                lines.extend(_format_lines(child, full_key))
            else:
                lines.append(f"{full_key}: {child!r}")
        return lines
    return [f"{prefix}: {value!r}" if prefix else repr(value)]


def format_config_output(value, prefix=""):
    """Render config values as readable slash-command output."""
    return "\n".join(_format_lines(value, prefix=prefix)) if isinstance(value, dict) else repr(value)


@command
def help():
    """List slash commands currently registered on the active agent."""
    agent = get_agent()
    names = ", ".join(f"/{name}" for name in sorted(agent.commands))
    return f"Available commands: {names}"


@command
def compact(max_compacted_turns=None):
    agent = get_agent()
    max_compacted_turns = None if max_compacted_turns in (None, "", "all") else int(max_compacted_turns)
    message = agent.compact_session(
        max_compacted_turns=max_compacted_turns,
    )
    if message is None:
        return "Nothing to compact."
    if message.get("status") == "failed":
        return f"Compaction failed: {message.error}"
    suffix = "" if max_compacted_turns is None else f" from {max_compacted_turns} compacted turn(s)"
    return f"Compacted {message.compacted_message_count} messages{suffix}."


def _message_count_text(count):
    return f"{count} message" if count == 1 else f"{count} messages"


def _session_infos(agent):
    infos = []
    for index, info in enumerate(AgentSession.list_session_infos(), start=1):
        infos.append(modict(
            index=index,
            session_id=info.session_id,
            title=info.title or info.session_id,
            message_count=info.message_count,
            current=info.session_id == agent.current_session_id,
        ))
    return infos


def _format_session_list(agent):
    infos = _session_infos(agent)
    if not infos:
        return "No saved sessions."
    lines = ["Sessions:"]
    for info in infos:
        marker = "*" if info.current else " "
        lines.append(
            f"{marker} [{info.index}] {info.title} "
            f"({info.session_id}, {_message_count_text(info.message_count)})"
        )
    return "\n".join(lines)


@command
def session(action=None, *parts):
    agent = get_agent()
    if action is None:
        return _format_session_list(agent)

    action_text = str(action).strip()
    action_lower = action_text.lower()
    if action_lower == "new":
        created = agent.start_new_session()
        return f"Created session: {created.session_id}"

    if action_lower == "rename":
        title = " ".join(str(part) for part in parts).strip()
        if not title:
            raise ValueError("/session rename requires a title")
        if agent.session is None:
            raise ValueError("No active session to rename")
        agent.session.title = title
        agent.save_session()
        return f"Renamed session: {title}"

    if parts:
        raise ValueError("Usage: /session, /session <index>, /session new, /session rename <title>")

    try:
        index = int(action_text)
    except ValueError as exc:
        raise ValueError(f"Unknown /session action: {action_text}") from exc

    infos = _session_infos(agent)
    if index < 1 or index > len(infos):
        raise ValueError(f"Session index out of range: {index}")
    loaded = agent.load_session(infos[index - 1].session_id)
    return f"Loaded session: {loaded.session_id}"


@command
def config(path=None, value=None, *extra, **values):
    agent = get_agent()
    manager = agent.config_manager

    if values:
        unknown = sorted(key for key in values if key not in agent.config)
        if unknown:
            raise ValueError(f"Unknown model config keys: {', '.join(unknown)}")
        parsed = {key: parse_config_value(raw) for key, raw in values.items()}
        manager.update_config("agent", config=parsed, save=True)
        changed = ", ".join(f"{key}={agent.config.get(key)!r}" for key in parsed)
        return f"Updated config: {changed}" if changed else format_config_output(manager.export_tree())

    if path is None:
        if value is not None or extra:
            raise ValueError("/config with no path does not accept extra arguments")
        return format_config_output(manager.export_tree())

    if path == "save":
        manager.save_all()
        return "Saved all config namespaces."

    if value is None and not extra:
        displayed = manager.get_path(path)
        return format_config_output(displayed, prefix=path)

    if value == "save" and not extra:
        namespace, remainder = manager.namespace_path(path)
        if remainder:
            raise ValueError("Save targets a config namespace, not a nested key")
        manager.save_config(namespace)
        return f"Saved config namespace: {namespace}"

    raw_value = " ".join(str(part) for part in ((value,) + extra))
    updated = manager.set_path(path, raw_value, save=False)
    return f"Updated config: {path}={updated!r}"


@command
def model(value=None):
    """Show or update the active model configuration value."""
    if value is None:
        return f"model: {get_agent().config.model!r}"
    get_agent().config_manager.set_path("agent.model", value, save=True)
    return f"Updated config: model={get_agent().config.model!r}"


@command
def reasoning(value=None):
    """Show or update the reasoning effort config shortcut."""
    agent = get_agent()
    if value is None:
        return f"reasoning: {agent.config.get('reasoning')!r}"
    current = dict(agent.config.get("reasoning") or {})
    current["effort"] = value
    current.setdefault("summary", "auto")
    agent.config_manager.update_config("agent", reasoning=current, save=True)
    return f"Updated config: reasoning={agent.config.get('reasoning')!r}"


@command
def verbosity(value=None):
    """Show or update the text verbosity config shortcut."""
    agent = get_agent()
    if value is None:
        return f"text: {agent.config.get('text')!r}"
    current = dict(agent.config.get("text") or {})
    current["verbosity"] = value
    agent.config_manager.update_config("agent", text=current, save=True)
    return f"Updated config: text={agent.config.get('text')!r}"


@command
def voice(value=None):
    agent = get_agent()
    if "tts" not in agent.plugins:
        agent.load_builtin_plugin("tts")
    return agent.plugins.tts.voice(value)
