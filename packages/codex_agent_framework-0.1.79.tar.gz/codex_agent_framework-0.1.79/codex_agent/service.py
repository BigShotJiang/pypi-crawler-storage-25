import contextlib
import json
import os
import plistlib
import shlex
import subprocess
import sys
from pathlib import Path

from .utils import project_python_env, runtime_join


SERVER_SERVICE_NAME = "codex-agent.service"
TRAY_SERVICE_NAME = "codex-agent-tray.service"
# Backwards-compatible alias for callers that predate the tray/server split.
SERVICE_NAME = SERVER_SERVICE_NAME
RESTART_WAKEUP_FILE = "restart_wakeup.json"


def restart_wakeup_file():
    """Return the runtime file used to resume work after a service restart."""
    return Path(runtime_join(RESTART_WAKEUP_FILE))


def write_restart_wakeup(prompt, title=""):
    """Persist a prompt for the next server startup to consume as a wakeup."""
    if not prompt or not str(prompt).strip():
        raise ValueError("prompt must not be empty")
    path = restart_wakeup_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "prompt": str(prompt),
        "title": title or "post-restart wakeup",
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def pop_restart_wakeup():
    """Read and remove any pending post-restart wakeup payload."""
    path = restart_wakeup_file()
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    finally:
        with contextlib.suppress(FileNotFoundError):
            path.unlink()
    return payload


def restart_server_service(check=False):
    """Restart only the local server service without blocking the caller."""
    return service_controller().restart(SERVER_SERVICE_NAME, check=check, no_block=True)


def user_systemd_dir():
    return Path.home() / ".config" / "systemd" / "user"


def service_file_path(name=SERVER_SERVICE_NAME):
    return user_systemd_dir() / name


def service_unit(host="127.0.0.1", port=8765, extra_args=None):
    extra_args = extra_args or []
    command = [sys.executable, "-m", "codex_agent", "start", "server", "--host", host, "--port", str(port), "--foreground", *extra_args]
    env_runtime = os.environ.get("AGENT_RUNTIME_DIR") or runtime_join("")
    env_file = runtime_join(".env")
    python_env = project_python_env()
    return f"""[Unit]
Description=Codex Agent local runtime server
After=network.target

[Service]
Type=simple
WorkingDirectory={shlex.quote(os.getcwd())}
Environment=AGENT_RUNTIME_DIR={shlex.quote(env_runtime)}
Environment=PATH={shlex.quote(python_env['PATH'])}
Environment=PYTHON={shlex.quote(python_env['PYTHON'])}
Environment=PYTHON_EXECUTABLE={shlex.quote(python_env['PYTHON_EXECUTABLE'])}
EnvironmentFile=-{shlex.quote(env_file)}
ExecStart={' '.join(shlex.quote(part) for part in command)}
TimeoutStopSec=6
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
"""


def tray_unit(host="127.0.0.1", port=8765, extra_args=None):
    extra_args = extra_args or []
    command = [
        sys.executable,
        "-m",
        "codex_agent",
        "start",
        "tray",
        "--url",
        f"http://{host}:{port}",
        "--foreground",
        *extra_args,
    ]
    env_runtime = os.environ.get("AGENT_RUNTIME_DIR") or runtime_join("")
    env_file = runtime_join(".env")
    python_env = project_python_env()
    return f"""[Unit]
Description=Codex Agent tray controller
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
WorkingDirectory={shlex.quote(os.getcwd())}
Environment=AGENT_RUNTIME_DIR={shlex.quote(env_runtime)}
Environment=PATH={shlex.quote(python_env['PATH'])}
Environment=PYTHON={shlex.quote(python_env['PYTHON'])}
Environment=PYTHON_EXECUTABLE={shlex.quote(python_env['PYTHON_EXECUTABLE'])}
EnvironmentFile=-{shlex.quote(env_file)}
ExecStart={' '.join(shlex.quote(part) for part in command)}
Restart=on-failure
RestartSec=3

[Install]
WantedBy=graphical-session.target
"""


def install_user_service(host="127.0.0.1", port=8765, enable=True, start=False):
    return service_controller().install(host=host, port=port, enable=enable, start=start)


def uninstall_user_service(disable=True, stop=False):
    return service_controller().uninstall(disable=disable, stop=stop)


def run_systemctl(*args, check=True):
    return subprocess.run(["systemctl", "--user", *args], text=True, capture_output=True, check=check)


def launchd_dir():
    return Path.home() / "Library" / "LaunchAgents"


def launchd_label(name):
    if name == SERVER_SERVICE_NAME:
        return "dev.codex-agent.server"
    if name == TRAY_SERVICE_NAME:
        return "dev.codex-agent.tray"
    return f"dev.codex-agent.{Path(name).stem}"


def launchd_file_path(name=SERVER_SERVICE_NAME):
    return launchd_dir() / f"{launchd_label(name)}.plist"


def launchd_plist(name, command, env=None, keep_alive=True):
    env = env or {}
    python_env = project_python_env()
    return {
        "Label": launchd_label(name),
        "ProgramArguments": command,
        "WorkingDirectory": os.getcwd(),
        "EnvironmentVariables": {
            "AGENT_RUNTIME_DIR": os.environ.get("AGENT_RUNTIME_DIR") or runtime_join(""),
            "PATH": python_env["PATH"],
            "PYTHON": python_env["PYTHON"],
            "PYTHON_EXECUTABLE": python_env["PYTHON_EXECUTABLE"],
            **env,
        },
        "RunAtLoad": False,
        "KeepAlive": bool(keep_alive),
        "StandardOutPath": str(Path(runtime_join(f"{Path(name).stem}.out.log"))),
        "StandardErrorPath": str(Path(runtime_join(f"{Path(name).stem}.err.log"))),
    }


class ServiceController:
    platform = "generic"

    def active(self, name=SERVER_SERVICE_NAME):
        raise NotImplementedError

    def run(self, command, name=SERVER_SERVICE_NAME, *extra_args, check=False):
        raise NotImplementedError

    def install(self, host="127.0.0.1", port=8765, enable=True, start=False):
        raise NotImplementedError

    def uninstall(self, disable=True, stop=False):
        raise NotImplementedError

    def restart(self, name=SERVER_SERVICE_NAME, check=True, no_block=False):
        extra_args = ["--no-block"] if no_block and self.platform == "linux" else []
        return self.run("restart", name, *extra_args, check=check)


class SystemdServiceController(ServiceController):
    platform = "linux"

    def active(self, name=SERVER_SERVICE_NAME):
        result = run_systemctl("is-active", name, check=False)
        return result.returncode == 0 and str(result.stdout).strip() == "active"

    def run(self, command, name=SERVER_SERVICE_NAME, *extra_args, check=False):
        return run_systemctl(command, *extra_args, name, check=check)

    def install(self, host="127.0.0.1", port=8765, enable=True, start=False):
        path = service_file_path(SERVER_SERVICE_NAME)
        tray_path = service_file_path(TRAY_SERVICE_NAME)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(service_unit(host=host, port=port), encoding="utf-8")
        tray_path.write_text(tray_unit(host=host, port=port), encoding="utf-8")
        run_systemctl("daemon-reload")
        if enable:
            run_systemctl("enable", SERVER_SERVICE_NAME)
            run_systemctl("reenable", TRAY_SERVICE_NAME)
        if start:
            run_systemctl("restart", SERVER_SERVICE_NAME)
            run_systemctl("restart", TRAY_SERVICE_NAME)
        return path

    def uninstall(self, disable=True, stop=False):
        if stop:
            run_systemctl("stop", TRAY_SERVICE_NAME, check=False)
            run_systemctl("stop", SERVER_SERVICE_NAME, check=False)
        if disable:
            run_systemctl("disable", TRAY_SERVICE_NAME, check=False)
            run_systemctl("disable", SERVER_SERVICE_NAME, check=False)
        for path in [service_file_path(SERVER_SERVICE_NAME), service_file_path(TRAY_SERVICE_NAME)]:
            if path.exists():
                path.unlink()
        run_systemctl("daemon-reload", check=False)
        return service_file_path(SERVER_SERVICE_NAME)


class LaunchdServiceController(ServiceController):
    platform = "darwin"

    def active(self, name=SERVER_SERVICE_NAME):
        result = self.run("print", name, check=False)
        return result.returncode == 0

    def run(self, command, name=SERVER_SERVICE_NAME, *extra_args, check=False):
        label = launchd_label(name)
        if command == "is-active":
            return self.run("print", name, check=check)
        if command == "start":
            args = ["launchctl", "kickstart", "-k", f"gui/{os.getuid()}/{label}"]
        elif command == "stop":
            args = ["launchctl", "bootout", f"gui/{os.getuid()}/{label}"]
        elif command == "restart":
            args = ["launchctl", "kickstart", "-k", f"gui/{os.getuid()}/{label}"]
        elif command == "print":
            args = ["launchctl", "print", f"gui/{os.getuid()}/{label}"]
        elif command == "bootstrap":
            args = ["launchctl", "bootstrap", f"gui/{os.getuid()}", str(launchd_file_path(name))]
        else:
            args = ["launchctl", command, *extra_args, label]
        return subprocess.run(args, text=True, capture_output=True, check=check)

    def install(self, host="127.0.0.1", port=8765, enable=True, start=False):
        server_path = launchd_file_path(SERVER_SERVICE_NAME)
        tray_path = launchd_file_path(TRAY_SERVICE_NAME)
        server_path.parent.mkdir(parents=True, exist_ok=True)
        server_command = [sys.executable, "-m", "codex_agent", "start", "server", "--host", host, "--port", str(port), "--foreground"]
        tray_command = [sys.executable, "-m", "codex_agent", "start", "tray", "--url", f"http://{host}:{port}", "--foreground"]
        server_path.write_bytes(plistlib.dumps(launchd_plist(SERVER_SERVICE_NAME, server_command)))
        tray_path.write_bytes(plistlib.dumps(launchd_plist(TRAY_SERVICE_NAME, tray_command)))
        if enable:
            self.run("bootstrap", SERVER_SERVICE_NAME, check=False)
            self.run("bootstrap", TRAY_SERVICE_NAME, check=False)
        if start:
            self.run("restart", SERVER_SERVICE_NAME, check=False)
            self.run("restart", TRAY_SERVICE_NAME, check=False)
        return server_path

    def uninstall(self, disable=True, stop=False):
        if stop or disable:
            self.run("stop", TRAY_SERVICE_NAME, check=False)
            self.run("stop", SERVER_SERVICE_NAME, check=False)
        for path in [launchd_file_path(SERVER_SERVICE_NAME), launchd_file_path(TRAY_SERVICE_NAME)]:
            if path.exists():
                path.unlink()
        return launchd_file_path(SERVER_SERVICE_NAME)


class UnsupportedServiceController(ServiceController):
    platform = "unsupported"

    def __init__(self, platform=None):
        self.platform = platform or sys.platform

    def active(self, name=SERVER_SERVICE_NAME):
        return False

    def run(self, command, name=SERVER_SERVICE_NAME, *extra_args, check=False):
        result = subprocess.CompletedProcess(
            args=[command, *extra_args, name],
            returncode=1,
            stdout="",
            stderr=f"Service management is not implemented for {self.platform}.",
        )
        if check:
            raise subprocess.CalledProcessError(result.returncode, result.args, result.stdout, result.stderr)
        return result

    def install(self, host="127.0.0.1", port=8765, enable=True, start=False):
        raise RuntimeError(f"Service installation is not implemented for {self.platform}.")

    def uninstall(self, disable=True, stop=False):
        raise RuntimeError(f"Service uninstallation is not implemented for {self.platform}.")


def service_controller(platform=None):
    platform = platform or sys.platform
    if platform.startswith("linux"):
        return SystemdServiceController()
    if platform == "darwin":
        return LaunchdServiceController()
    return UnsupportedServiceController(platform=platform)
