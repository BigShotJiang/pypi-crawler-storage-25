import json
import sys


def dump_json(payload, *, stream=None):
    """Write a payload as pretty JSON to stdout or a custom stream."""
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str), file=stream or sys.stdout)


def dump_ndjson(payload, *, stream=None):
    """Write a payload as one flushed NDJSON line."""
    print(json.dumps(payload, ensure_ascii=False, default=str), file=stream or sys.stdout, flush=True)


def output_payload(payload, *, fmt="text", text_formatter=None):
    """Print a payload using the requested CLI output format."""
    if fmt == "json":
        dump_json(payload)
        return
    if fmt == "ndjson":
        dump_ndjson(payload)
        return
    if text_formatter is not None:
        text = text_formatter(payload)
    else:
        text = str(payload)
    if text:
        print(text)


def key_value_text(payload):
    """Render dictionaries as simple key-value lines for text output."""
    if not isinstance(payload, dict):
        return str(payload)
    return "\n".join(f"{key}: {value}" for key, value in payload.items())
