import os
from collections.abc import Mapping
from urllib.parse import quote_plus

from ...browser import get_browser_controller
from ...desktop import DesktopControlError, get_desktop_controller
from ...image import ImageMessage, persist_image_url
from ...tool import get_agent, tool
from ...utils import runtime_join


@tool
def observe(sources):
    """
    description: |
        Observe and analyze one or more visual sources by adding ImageMessages to the conversation context.
        The images will be available for visual analysis in the next response.

        Prefer the normalized source object format. Legacy string sources are still accepted and inferred as path or url.
    parameters:
        sources:
            description: |
                A single source object or a list of source objects.
                Normalized source objects are dictionaries with a required target:
                - {"target": "path", "path": "/home/user/image.png"}
                - {"target": "url", "url": "https://example.com/page-or-image"}
                - {"target": "screen"}
                - {"target": "window", "window_id": "0x123456"}

                Optional fields:
                - image_name: custom display name
                - full_page: for url screenshot fallback, defaults true
                - wait_until: Playwright wait condition for url screenshot fallback, defaults "networkidle"
                - timeout: Playwright navigation timeout in milliseconds, defaults 30000
                - output_path: explicit screenshot output path for screen/window/url fallback
            anyOf:
                - type: object
                  properties:
                    target:
                        type: string
                        enum: [path, url, screen, window]
                    path:
                        type: string
                    url:
                        type: string
                    window_id:
                        type: string
                    image_name:
                        type: string
                    full_page:
                        type: boolean
                    wait_until:
                        type: string
                    timeout:
                        type: integer
                    output_path:
                        type: string
                  required:
                    - target
                - type: array
                  items:
                    type: object
                    properties:
                        target:
                            type: string
                            enum: [path, url, screen, window]
                        path:
                            type: string
                        url:
                            type: string
                        window_id:
                            type: string
                        image_name:
                            type: string
                        full_page:
                            type: boolean
                        wait_until:
                            type: string
                        timeout:
                            type: integer
                        output_path:
                            type: string
                    required:
                        - target
    required:
        - sources
    """
    if isinstance(sources, (str, Mapping)):
        source_items = [sources]
    elif isinstance(sources, list):
        source_items = sources
    else:
        return "Failed: sources must be a source object or a list of source objects."

    return [observe_source(source) for source in source_items]


def normalize_observe_source(source):
    """Normalize legacy string sources and mapping sources to observe objects."""
    if isinstance(source, str):
        target = "url" if source.startswith(("http://", "https://")) else "path"
        key = "url" if target == "url" else "path"
        return {"target": target, key: source}
    if isinstance(source, Mapping):
        return dict(source)
    return None


def observe_source(source):
    """Dispatch one normalized observe source to the matching capture helper."""
    item = normalize_observe_source(source)
    if not item:
        return "failed: source must be an object."

    target = item.get("target")
    if target == "path":
        return observe_path(item)
    if target == "url":
        return observe_url(item)
    if target == "screen":
        return observe_screen(item)
    if target == "window":
        return observe_window(item)
    return f"failed: unsupported observe target: {target!r}"


def resolve_agent_path(path):
    """Resolve paths relative to the active agent when one is available."""
    try:
        return get_agent().resolve_path(path)
    except RuntimeError:
        return os.path.abspath(os.path.expanduser(str(path)))


def observe_path(item):
    """Validate a local image path observe source."""
    path = item.get("path") or item.get("source")
    if not isinstance(path, str) or not path:
        return "failed: path target requires a non-empty 'path'."
    path = resolve_agent_path(path)
    return validated_image(path, image_name=item.get("image_name"), original_source=path)


def observe_url(item):
    """Observe a URL as an image, falling back to a page screenshot."""
    url = item.get("url") or item.get("source")
    if not isinstance(url, str) or not url:
        return "failed: url target requires a non-empty 'url'."

    try:
        path = persist_image_url(url)
        return validated_image(path, image_name=item.get("image_name", url), original_source=url)
    except Exception:
        pass

    try:
        path = screenshot_page_url(url, item)
        return validated_image(
            path,
            image_name=item.get("image_name", f"Screenshot of {url}"),
            original_source=url,
            url_fallback=True,
        )
    except Exception as exc:
        return f"failed: invalid image URL and page screenshot fallback failed for {url!r}: {exc}"


def observe_screen(item):
    """Capture and validate a screenshot of the local screen."""
    output_path = item.get("output_path")
    if output_path:
        output_path = resolve_agent_path(output_path)
    try:
        path = get_desktop_controller().capture_screen(output_path)
    except DesktopControlError as exc:
        return f"failed: local screen screenshot failed: {exc}"
    return validated_image(path, image_name=item.get("image_name", "Screenshot of screen"), original_source="screen")


def observe_window(item):
    """Capture and validate a screenshot of a local desktop window."""
    window_id = item.get("window_id") or item.get("id")
    output_path = item.get("output_path")
    if output_path:
        output_path = resolve_agent_path(output_path)
    try:
        path = get_desktop_controller().capture_window(window_id, output_path)
    except DesktopControlError as exc:
        return f"failed: local window screenshot failed: {exc}"
    return validated_image(path, image_name=item.get("image_name", f"Screenshot of window {window_id}"), original_source=f"window {window_id}")


def validated_image(path, image_name=None, original_source=None, url_fallback=False):
    """Return an ImageMessage or a readable failure string for invalid input."""
    image = ImageMessage(content=path, image_name=image_name, turns_left=3)
    if not image.is_valid():
        label = "URL fallback screenshot" if url_fallback else "image source"
        return f"failed: invalid or inaccessible {label}: {original_source!r}"
    return image


def screenshot_page_url(url, item=None):
    """Capture a webpage screenshot using caller options or a runtime path."""
    item = item or {}
    path = item.get("output_path")
    if path:
        path = resolve_agent_path(path)
    if not path:
        screenshots_dir = runtime_join("images", "screenshots")
        os.makedirs(screenshots_dir, exist_ok=True)
        path = os.path.join(screenshots_dir, f"page_{quote_plus(url)[:80]}.png")
    return get_browser_controller().capture_page_screenshot(
        url,
        path,
        headless=True,
        profile_name="observe-fallback",
        full_page=item.get("full_page", True),
        wait_until=item.get("wait_until", "networkidle"),
        timeout=item.get("timeout", 30_000),
    )
