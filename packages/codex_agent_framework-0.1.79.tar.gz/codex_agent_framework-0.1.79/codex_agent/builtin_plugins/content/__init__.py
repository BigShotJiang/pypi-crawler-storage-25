"""Built-in content inspection plugin."""

from ...plugin import Plugin
from ...tool import tool
from ..files import tools as file_tools
from . import system as system_tools
from . import vision as vision_tools


class ContentPlugin(Plugin):
    """Expose rich content extraction, visual observation, and open/show tools."""

    name = "content"
    description = "Extract, observe, or open content from varied sources."
    prefix_tools = False
    system_prompt = """
# Content Tools

Use the specialized content tools to inspect or present non-plain-text sources and visual material:
- `view`: quickly access extracted content from folders, URLs, PDFs, DOCX, ODT, HTML, XLSX, archives, and other rich sources. It is convenient and broad, but not a strict source-of-truth reader for local UTF-8 files.
- `observe`: use AI vision capabilities on image files, screenshots, windows, screens, or URLs.
- `show`: open a local file, folder, or URL with the system default application/browser when the user should visually inspect it outside the chat.

Use `view` for broad extraction and discovery, but prefer the file plugin's `read` tool when you need faithful line-numbered local UTF-8 file content before editing.
"""

    @tool(name="view")
    def view(self, source, start_at_line: int = 1, search_query: str = None):
        return file_tools.view(source, start_at_line=start_at_line, search_query=search_query)

    @tool(name="observe")
    def observe(self, sources):
        return vision_tools.observe(sources)

    @tool(name="show")
    def show(self, file_or_url: str):
        return system_tools.show(file_or_url)


ContentPlugin.view.__doc__ = file_tools.view.__doc__
ContentPlugin.observe.__doc__ = vision_tools.observe.__doc__
ContentPlugin.show.__doc__ = system_tools.show.__doc__
