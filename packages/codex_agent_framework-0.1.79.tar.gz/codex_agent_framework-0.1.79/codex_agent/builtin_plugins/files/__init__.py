"""Built-in file editing plugin."""

from ...plugin import Plugin
from ...tool import tool
from . import tools as file_tools


class FilesPlugin(Plugin):
    """Expose strict local text-file read, write, edit, and search tools."""

    name = "files"
    description = "Strict local UTF-8 file/folder read and search plus write/edit operations."
    prefix_tools = False
    system_prompt = """
# File Tools

Use the specialized file tools for local UTF-8 text operations:
- `read`: read line-numbered local UTF-8 files precisely, list local folders as a compact one-level tree, or search folders recursively with a pattern.
- `write`: create or overwrite complete UTF-8 text files; use with caution.
- `edit`: perform targeted exact-string replacements in local UTF-8 text files.

Always use these tools instead of generic `bash` or `python` for reading and editing local text files when they fit the task.
Never edit blindly or guessing: read the relevant file content first, then make precise edits based on the observed source of truth.
Prefer `edit` for small targeted changes and `write` when creating a new file or replacing a complete file is clearly safer.
"""

    @tool(name="read")
    def read(self, reads):
        return file_tools.read(reads)

    @tool(name="write")
    def write(self, writes):
        return file_tools.write(writes)

    @tool(name="edit")
    def edit(self, edits):
        return file_tools.edit(edits)


FilesPlugin.read.__doc__ = file_tools.read.__doc__
FilesPlugin.write.__doc__ = file_tools.write.__doc__
FilesPlugin.edit.__doc__ = file_tools.edit.__doc__
