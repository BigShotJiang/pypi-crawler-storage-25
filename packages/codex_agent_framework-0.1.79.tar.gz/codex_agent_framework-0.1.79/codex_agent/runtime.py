import requests

from modict import modict


class RuntimeManager:
    """Small HTTP bridge for runtime actions handled by the local server."""

    def __init__(self, agent):
        self.agent = agent

    @property
    def server_url(self):
        return str(self.agent.config.get("server_url") or "http://127.0.0.1:8765").rstrip("/")

    def call_server_endpoint(self, method, path, payload=None):
        base_url = self.server_url
        try:
            health = requests.get(f"{base_url}/health", timeout=1.0)
            health.raise_for_status()
            response = requests.request(method, f"{base_url}{path}", json=payload or {}, timeout=5.0)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise RuntimeError(f"Agent server is not active at {base_url}: {exc}") from exc
        if not response.content:
            return modict()
        return modict(response.json())

    def open_tui(self):
        return self.call_server_endpoint("POST", "/tui/open")

    def close_tui(self):
        return self.call_server_endpoint("POST", "/tui/close")

    def restart_server(self, prompt=None, title="post-restart wakeup"):
        return self.call_server_endpoint("POST", "/restart", {"prompt": prompt, "title": title})
