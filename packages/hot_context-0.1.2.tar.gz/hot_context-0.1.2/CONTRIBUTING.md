# Contributing to hot-context

Thank you for your interest in contributing. hot-context is a research library
and contributions of all kinds are welcome — bug fixes, new adapters, benchmark
improvements, documentation, and new ideas.

---

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Ways to Contribute](#ways-to-contribute)
- [Development Setup](#development-setup)
- [Project Structure](#project-structure)
- [Making Changes](#making-changes)
- [Tests](#tests)
- [Submitting a Pull Request](#submitting-a-pull-request)
- [Reporting Bugs](#reporting-bugs)
- [Requesting Features](#requesting-features)
- [Style Guide](#style-guide)

---

## Code of Conduct

Be respectful and constructive. This is a research project maintained by one
person — response times may vary, but all issues and PRs will be reviewed.

---

## Ways to Contribute

### Good first issues

These do not require deep knowledge of the codebase:

- Fix a typo or improve documentation
- Add a usage example to the README
- Improve error messages to be more descriptive
- Add a test case for an edge case you encountered
- Report a bug with a minimal reproduction

### Larger contributions

These are areas where the project actively needs help:

| Area | Description |
|------|-------------|
| **Embedding-based trimming** | Sentence-level similarity trimming for unstructured prose (see Limitation L1 in the paper) |
| **SQL column-aware trimming** | Retain rows where query entities appear in key columns, not just value columns |
| **New adapters** | Anthropic Python SDK, Google Gemini, Mistral, LlamaIndex |
| **Soft eviction** | Move evicted chunks to an external vector store for recovery without tool re-calls |
| **Benchmarks** | LongBench, SCROLLS, or NarrativeQA evaluation |
| **Negation handling** | The entity extractor does not handle negation |

If you plan to work on something large, open an issue first to discuss the
approach before writing code. This avoids duplicated effort.

---

## Development Setup

### Prerequisites

- Python 3.10 or later
- Git
- AWS credentials configured (for benchmarks that call Bedrock — not required for unit tests)

### Install

```bash
# Fork the repo on GitHub, then clone your fork
git clone https://github.com/YOUR_USERNAME/hot-context.git
cd hot-context

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Optional: install embedding support
pip install -e ".[embeddings]"
```

### Verify the setup

```bash
# Run the unit tests — should pass with no LLM or AWS credentials
pytest tests/test_core.py tests/test_eval.py -v
```

---

## Project Structure

```
hot-context/
├── src/
│   └── hot_context/
│       ├── __init__.py          # Public API exports
│       ├── manager.py           # HotContextManager — core orchestrator
│       ├── scorer.py            # Scoring formula and topic shift detection
│       ├── trimmer.py           # Line-level tool result trimming
│       ├── chunker.py           # Message chunking into ContextEntry objects
│       ├── entity_extractor.py  # Regex-based entity extraction
│       ├── feedback.py          # Entity echo feedback loop
│       ├── token_estimator.py   # Adaptive token calibration
│       ├── types.py             # ContextEntry, ScoringWeights dataclasses
│       ├── similarity.py        # Jaccard and embedding similarity backends
│       └── adapters/
│           ├── strands.py       # AWS Strands ConversationManager adapter
│           ├── langchain.py     # LangChain BaseChatMemory adapter
│           └── openai.py        # OpenAI message list adapter
├── tests/
│   ├── mock_mcp_server.py       # Deterministic mock MCP server (7 tools)
│   ├── test_questions.py        # 46 test questions across all tools
│   ├── eval_scenarios.py        # Named eval scenarios with assertions
│   ├── test_core.py             # Unit tests (no LLM required)
│   ├── test_eval.py             # Pytest wrapper for eval scenarios
│   ├── benchmark_llm.py         # LLM benchmark (requires Bedrock)
│   └── benchmark_agent.py       # Agent benchmark (requires Bedrock + Strands)
├── LICENSE
├── README.md
├── CONTRIBUTING.md
├── CHANGELOG.md
└── pyproject.toml
```

### Key design decisions to be aware of

- **No LLM calls in the eviction path.** The entire scoring and eviction pipeline
  must remain free of LLM calls. Any change that adds a model call to decide what
  to keep will not be accepted.
- **Tool-use / tool-result pairs must stay together.** The chunker ensures these
  are never separated. Changes to chunking logic must preserve this invariant.
- **Adapters are thin wrappers.** Business logic belongs in the core, not in
  adapters. An adapter should only translate between the framework's interface
  and `HotContextManager`.

---

## Making Changes

### Branch naming

```
feature/short-description       # new functionality
fix/short-description           # bug fixes
docs/short-description          # documentation only
bench/short-description         # benchmark additions or changes
```

### Workflow

```bash
# Create a branch from main
git checkout main
git pull origin main
git checkout -b feature/your-feature-name

# Make your changes, then run tests
pytest tests/test_core.py tests/test_eval.py -v

# Commit with a descriptive message (see style guide below)
git add .
git commit -m "feat: add column-aware SQL trimming"

# Push and open a PR
git push origin feature/your-feature-name
```

---

## Tests

### Running tests

```bash
# Unit tests and eval scenarios — no credentials required, ~15 seconds
pytest tests/test_core.py tests/test_eval.py -v

# With coverage report
pytest tests/test_core.py tests/test_eval.py --cov=hot_context --cov-report=term-missing

# LLM benchmark — requires AWS Bedrock credentials
python -m tests.benchmark_llm --turns 30

# Agent benchmark — requires AWS Bedrock + Strands
python -m tests.benchmark_agent --turns 25 --context 32000
```

### Writing tests

- All new features must include tests in `tests/test_core.py`
- New eval scenarios (context management assertions) go in `tests/eval_scenarios.py`
- Tests must pass without any LLM or AWS credentials
- Use the existing `_msg()`, `_tool_use()`, `_tool_result()` helpers for building
  test messages — do not construct raw dicts by hand

### Test categories

| Test class | What it covers |
|------------|----------------|
| `TestEntityExtractor` | Entity extraction patterns |
| `TestScorer` | Scoring formula, decay, topic shift |
| `TestChunker` | Message chunking and tool pairing |
| `TestFeedback` | Entity echo feedback loop |
| `TestManager` | End-to-end pipeline: add → score → evict → retrieve |
| `TestTokenEstimator` | Calibration and estimation |
| `TestTrimmer` | Line-level trimming of tool results |
| Eval scenarios | Named scenarios asserting fact retention and eviction |

---

## Submitting a Pull Request

Before opening a PR, make sure:

- [ ] All existing tests pass: `pytest tests/test_core.py tests/test_eval.py`
- [ ] New functionality has test coverage
- [ ] New public functions and classes have docstrings
- [ ] The PR description explains **what** changed and **why**
- [ ] If the change affects the scoring formula or eviction logic, include
      a before/after comparison on at least one eval scenario

### PR description template

```
## What

Brief description of the change.

## Why

Why is this needed? Which limitation or issue does it address?

## Test coverage

Which tests were added or modified?

## Eval impact (if applicable)

Did any eval scenarios change result? Before/after:
  scenario_name: PASS → PASS  (no change)
  scenario_name: FAIL → PASS  (fixed by this PR)
```

---

## Reporting Bugs

Open an issue with:

1. **Python version** and **hot-context version** (`pip show hot-context`)
2. **Minimal reproduction** — the shortest code that triggers the bug
3. **Expected behavior** vs **actual behavior**
4. **Stack trace** if applicable

```python
# Example minimal reproduction
from hot_context import HotContextManager

mgr = HotContextManager(token_budget=1000)
mgr.on_query("test query")
# ... steps that trigger the bug
```

---

## Requesting Features

Open an issue with:

1. **Use case** — what are you trying to accomplish?
2. **Current workaround** — how are you handling it today?
3. **Proposed API** — if you have a specific interface in mind, sketch it out

Feature requests that align with the roadmap (embedding-based trimming, soft
eviction, new adapters) are most likely to be picked up quickly.

---

## Style Guide

### Code

- Follow [PEP 8](https://peps.python.org/pep-0008/)
- Maximum line length: 100 characters
- Type hints on all public functions and methods
- Docstrings on all public classes and methods (Google style)

```python
def score_all(
    self,
    entries: list[ContextEntry],
    query_entities: set[str],
    current_turn: int,
    token_budget: int,
) -> list[ContextEntry]:
    """Score all entries against the current query and return them sorted.

    Args:
        entries: List of context entries to score.
        query_entities: Entities extracted from the current user query.
        current_turn: Current turn index for recency calculation.
        token_budget: Total token budget for size penalty calculation.

    Returns:
        Entries sorted by score descending (highest score first).
    """
```

### Commit messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: add embedding-based sentence trimmer
fix: prevent tool-use/tool-result pairs from being split during eviction
docs: add LangChain adapter example to README
test: add eval scenario for frequency-based protection under topic shift
bench: add 100-turn scaling test to benchmark_llm
refactor: extract similarity backend into pluggable interface
```

### What not to do

- Do not add LLM calls to the eviction or scoring path
- Do not break the `ConversationStrategy` interface in the benchmark library
- Do not commit AWS credentials, API keys, or `.env` files
- Do not change `pyproject.toml` dependencies without discussing in an issue first

---

## Questions

If you are unsure about anything, open a discussion or issue before writing code.
It is much easier to align on direction before a PR than after.
