"""HotContextManager: Framework-agnostic core orchestrator.

Pipeline per turn:
  1. on_query()    → score existing entries, evict if over budget
  2. (framework sends context to LLM, gets response)
  3. on_response() → feedback loop updates access logs
  4. add_messages() → new messages chunked into entries

This class knows nothing about Strands, LangChain, or OpenAI.
Framework adapters translate message formats and call these methods.
"""

from __future__ import annotations

import logging
from typing import Any

from hot_context.chunker import chunk_messages, estimate_tokens, extract_text
from hot_context.entity_extractor import EntityExtractor
from hot_context.feedback import update_access_from_response
from hot_context.scorer import ContextScorer, ScoringWeights, EntitySimilarityFunction
from hot_context.types import ContextEntry

logger = logging.getLogger(__name__)

_EVICTION_STUB = "[evicted: {role} turn {turn} — {summary}]"


class HotContextManager:
    """Intelligent LRU context manager with query-aware scoring and feedback loop.

    Args:
        token_budget: Maximum tokens to retain in context.
        weights: Scoring weights (use presets: ScoringWeights.tool_agent(), etc.)
        pin_last_n: Always keep the last N turns (never evict).
        extra_patterns: Additional regex patterns for entity extraction.
        stub_evicted: Replace evicted entries with a stub (vs full removal).
        similarity_fn: Custom similarity function (default: Jaccard on entities).
    """

    def __init__(
        self,
        token_budget: int = 100_000,
        weights: ScoringWeights | None = None,
        pin_last_n: int = 2,
        extra_patterns: list | None = None,
        stub_evicted: bool = False,
        similarity_fn: EntitySimilarityFunction | None = None,
    ):
        self.token_budget = token_budget
        self.pin_last_n = pin_last_n
        self.stub_evicted = stub_evicted
        self.extractor = EntityExtractor(extra_patterns=extra_patterns)
        self.scorer = ContextScorer(
            weights=weights, similarity_fn=similarity_fn,
        )
        self.entries: list[ContextEntry] = []
        self.current_turn: int = 0
        self._last_query: str = ""

    def on_query(self, query: str) -> None:
        """Call before sending context to LLM. Scores and evicts if needed."""
        self._last_query = query
        self.current_turn += 1

        if not self.entries:
            return

        query_entities = self.extractor.extract(query)
        self.scorer.score_all(
            self.entries, query_entities, self.current_turn, self.token_budget,
        )

        total = sum(e.token_estimate for e in self.entries)
        if total > self.token_budget:
            self._evict(self.token_budget)

    def on_response(self, response_text: str) -> None:
        """Call after LLM responds. Updates access logs via entity echo."""
        update_access_from_response(
            self.entries, response_text, self._last_query,
            self.extractor, self.current_turn,
        )

    def add_messages(self, messages: list[dict[str, Any]]) -> None:
        """Add new messages to the context store. Chunks them into entries."""
        new_entries = chunk_messages(
            messages, self.extractor,
            start_turn=self.current_turn,
        )
        self.entries.extend(new_entries)

    def get_context_messages(self) -> list[dict[str, Any]]:
        """Return the current context as a flat message list (in turn order)."""
        result = []
        for entry in sorted(self.entries, key=lambda e: e.turn_index):
            result.extend(entry.messages)
        return result

    def force_reduce(self, budget_ratio: float = 0.7) -> None:
        """Aggressively evict for overflow recovery."""
        self._evict(int(self.token_budget * budget_ratio))

    def _evict(self, budget: int) -> None:
        """Evict lowest-scored entries until within budget."""
        sorted_entries = sorted(self.entries, key=lambda e: e.score, reverse=True)

        survivors: list[ContextEntry] = []
        used_tokens = 0
        evicted = 0

        for entry in sorted_entries:
            if entry.pinned or used_tokens + entry.token_estimate <= budget:
                survivors.append(entry)
                used_tokens += entry.token_estimate
            else:
                evicted += 1
                if self.stub_evicted:
                    stub = self._make_stub(entry)
                    survivors.append(stub)
                    used_tokens += stub.token_estimate

        # If still over budget, force-evict unpinned then pinned by score
        if used_tokens > budget:
            survivors.sort(key=lambda e: e.score)
            final: list[ContextEntry] = []
            used_tokens = 0
            for entry in reversed(survivors):
                if used_tokens + entry.token_estimate <= budget:
                    final.append(entry)
                    used_tokens += entry.token_estimate
                else:
                    evicted += 1
                    if self.stub_evicted:
                        stub = self._make_stub(entry)
                        final.append(stub)
                        used_tokens += stub.token_estimate
            survivors = final

        survivors.sort(key=lambda e: e.turn_index)
        self.entries = survivors

        if not survivors:
            logger.warning("eviction removed ALL entries")

        logger.info("evicted=%d, tokens=%d, budget=%d", evicted, used_tokens, budget)

    def _make_stub(self, entry: ContextEntry) -> ContextEntry:
        entity_summary = ", ".join(list(entry.entities)[:5]) if entry.entities else "general"
        stub_text = _EVICTION_STUB.format(
            role=entry.role, turn=entry.turn_index, summary=entity_summary,
        )
        return ContextEntry(
            messages=[{"role": "user", "content": [{"text": stub_text}]}],
            turn_index=entry.turn_index,
            role="stub",
            entities=entry.entities,
            token_estimate=estimate_tokens(stub_text),
        )

    @property
    def total_tokens(self) -> int:
        return sum(e.token_estimate for e in self.entries)

    @property
    def entry_count(self) -> int:
        return len(self.entries)
