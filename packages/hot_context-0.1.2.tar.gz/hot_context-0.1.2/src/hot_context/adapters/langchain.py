"""LangChain memory adapter for hot-context.

Translates LangChain message format to hot-context ContextEntry format.
"""

from __future__ import annotations

from typing import Any

from hot_context.manager import HotContextManager
from hot_context.scorer import ScoringWeights


def _langchain_to_converse(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert LangChain messages to Converse API format."""
    converted = []
    for msg in messages:
        role = msg.get("role", msg.get("type", "user"))
        if role in ("ai", "assistant"):
            role = "assistant"
        elif role in ("human", "user"):
            role = "user"
        content = msg.get("content", "")
        converted.append({"role": role, "content": [{"text": content}]})
    return converted


def _converse_to_langchain(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert Converse API format back to LangChain messages."""
    converted = []
    for msg in messages:
        role = msg.get("role", "user")
        lc_role = "ai" if role == "assistant" else "human"
        text_parts = []
        for block in msg.get("content", []):
            if isinstance(block, dict) and "text" in block:
                text_parts.append(block["text"])
        converted.append({"type": lc_role, "content": " ".join(text_parts)})
    return converted


class LangChainHotContextMemory:
    """LangChain-compatible memory using hot-context.

    Usage:
        from hot_context.adapters.langchain import LangChainHotContextMemory

        memory = LangChainHotContextMemory(token_budget=50_000)
        memory.add_message({"role": "human", "content": "hello"})
        memory.add_message({"role": "ai", "content": "hi there"})
        context = memory.get_context(query="what did I say?")
    """

    def __init__(
        self,
        token_budget: int = 100_000,
        weights: ScoringWeights | None = None,
        pin_last_n: int = 2,
    ):
        self._manager = HotContextManager(
            token_budget=token_budget, weights=weights, pin_last_n=pin_last_n,
        )

    def add_message(self, message: dict[str, Any]) -> None:
        converted = _langchain_to_converse([message])
        self._manager.add_messages(converted)

    def get_context(self, query: str) -> list[dict[str, Any]]:
        self._manager.on_query(query)
        return _converse_to_langchain(self._manager.get_context_messages())

    def on_response(self, response_text: str) -> None:
        self._manager.on_response(response_text)
