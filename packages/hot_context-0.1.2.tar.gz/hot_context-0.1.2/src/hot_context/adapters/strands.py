"""Strands agent adapter for hot-context.

Drop-in replacement for SlidingWindowConversationManager.

Strategy:
- During a turn: let the LLM see everything (no eviction).
- End of turn: trim previous turns' tool results to only relevant lines.
- On overflow: aggressively trim + evict previous turns to make room.
- Token estimation: calibrates from actual Bedrock token counts over time.

Install:
    pip install hot-context[strands]
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from hot_context.entity_extractor import EntityExtractor
from hot_context.manager import HotContextManager
from hot_context.scorer import ScoringWeights
from hot_context.similarity import SimilarityFunction, get_best_similarity
from hot_context.token_estimator import TokenEstimator
from hot_context.trimmer import trim_tool_result

try:
    from strands.agent.conversation_manager.conversation_manager import ConversationManager
    from strands.types.exceptions import ContextWindowOverflowException

    _STRANDS_AVAILABLE = True
except ImportError:
    _STRANDS_AVAILABLE = False
    ConversationManager = object  # type: ignore
    ContextWindowOverflowException = RuntimeError  # type: ignore

if TYPE_CHECKING:
    # Only used for type hints — never imported at runtime
    from strands.agent.agent import Agent

logger = logging.getLogger(__name__)


class StrandsHotContextManager(ConversationManager):
    """Strands-compatible wrapper around HotContextManager.

    Requires strands-agents: pip install hot-context[strands]
    """

    def __init__(
        self,
        token_budget: int = 100_000,
        weights: ScoringWeights | None = None,
        pin_last_n: int = 2,
        extra_patterns: list | None = None,
        stub_evicted: bool = False,
        similarity_fn: SimilarityFunction | None = None,
    ):
        if not _STRANDS_AVAILABLE:
            raise ImportError(
                "strands-agents is required. "
                "Install with: pip install strands-agents  "
                "or: pip install hot-context[strands]"
            )
        super().__init__()
        self._estimator = TokenEstimator()
        self._similarity_fn = similarity_fn or get_best_similarity()
        self._manager = HotContextManager(
            token_budget=token_budget,
            weights=weights,
            pin_last_n=pin_last_n,
            extra_patterns=extra_patterns,
            stub_evicted=stub_evicted,
            similarity_fn=similarity_fn,
        )
        self._extractor = EntityExtractor(extra_patterns=extra_patterns)
        self._peak_context_tokens = 0
        self._eviction_count = 0
        self._trim_count = 0

    @property
    def manager(self) -> HotContextManager:
        return self._manager

    @property
    def estimator(self) -> TokenEstimator:
        return self._estimator

    @property
    def peak_context_tokens(self) -> int:
        return self._peak_context_tokens

    @property
    def eviction_count(self) -> int:
        return self._eviction_count

    @property
    def trim_count(self) -> int:
        return self._trim_count

    def reset_stats(self) -> None:
        self._peak_context_tokens = 0
        self._eviction_count = 0
        self._trim_count = 0

    def calibrate(self, messages: list[dict], actual_input_tokens: int) -> None:
        """Feed actual token count from Bedrock to improve estimates.

        Call this after each LLM response with the reported input_tokens.
        """
        self._estimator.calibrate(messages, actual_input_tokens)
        logger.info(
            "calibrated: ratio=%.2f (actual=%d tokens)",
            self._estimator.ratio, actual_input_tokens,
        )

    def apply_management(self, agent: "Agent", **kwargs: Any) -> None:
        """Called after each tool call and at end of turn.

        Mid-turn: track peak only.
        End-of-turn: trim previous turns' tool results using entity relevance.
        """
        messages = agent.messages
        if not messages:
            return

        estimated = self._estimator.estimate(messages)
        self._peak_context_tokens = max(self._peak_context_tokens, estimated)

        # Only act at end-of-turn: last message is assistant text (no toolUse)
        if not self._is_final_answer(messages[-1]):
            return

        answer_text = self._extract_text(messages[-1])
        used_entities = self._extractor.extract(answer_text)

        if not used_entities or estimated <= self._manager.token_budget:
            return

        logger.info(
            "end-of-turn trim: ~%d tokens (ratio=%.2f), %d entities",
            estimated, self._estimator.ratio, len(used_entities),
        )
        self._trim_previous_turns(messages, used_entities, answer_text=answer_text)
        self._trim_count += 1

    def reduce_context(self, agent: "Agent", e: Exception | None = None, **kwargs: Any) -> None:
        """Called on context window overflow. Trim + evict previous turns."""
        if not agent.messages:
            raise ContextWindowOverflowException("No messages to reduce.") from e

        messages = agent.messages
        estimated = self._estimator.estimate(messages)

        used_entities: set[str] = set()
        answer_text = ""
        for msg in reversed(messages):
            if msg.get("role") == "assistant":
                answer_text = self._extract_text(msg)
                used_entities = self._extractor.extract(answer_text)
                break

        # Step 1: trim tool results to relevant lines
        self._trim_previous_turns(messages, used_entities, answer_text=answer_text)
        after_trim = self._estimator.estimate(messages)
        logger.info("reduce_context: %d → %d after trim", estimated, after_trim)

        # Step 2: if still too big, evict entire old entries
        if after_trim > estimated * 0.6:
            target = estimated // 3
            logger.info("reduce_context: still large, evicting to target=%d", target)

            query = self._extract_last_query(messages)
            self._manager.entries = []
            self._manager.add_messages(messages)

            last_user_idx = self._find_last_user_entry_idx()
            for i, entry in enumerate(self._manager.entries):
                is_current = i >= last_user_idx if last_user_idx >= 0 else False
                entry.pinned = is_current or entry.role == "assistant"

            self._manager.on_query(query)
            self._manager._evict(target)
            messages[:] = self._manager.get_context_messages()

        self._eviction_count += 1

    def _find_last_user_entry_idx(self) -> int:
        last = -1
        for i, e in enumerate(self._manager.entries):
            if e.role == "user":
                last = i
        return last

    def _trim_previous_turns(
        self, messages: list[dict], used_entities: set[str], answer_text: str = "",
    ) -> None:
        last_user_idx = 0
        for i, msg in enumerate(messages):
            if msg.get("role") == "user":
                last_user_idx = i

        for i in range(last_user_idx):
            msg = messages[i]
            content = msg.get("content", [])
            has_tool_result = any(
                isinstance(b, dict) and "toolResult" in b for b in content
            )
            if has_tool_result:
                trimmed = trim_tool_result(
                    [msg], used_entities,
                    answer_text=answer_text,
                    similarity_fn=self._similarity_fn,
                )
                if trimmed:
                    messages[i] = trimmed[0]

    def _is_final_answer(self, msg: dict) -> bool:
        if msg.get("role") != "assistant":
            return False
        content = msg.get("content", [])
        has_text = any(isinstance(b, dict) and "text" in b for b in content)
        has_tool = any(isinstance(b, dict) and "toolUse" in b for b in content)
        return has_text and not has_tool

    def _extract_text(self, msg: dict) -> str:
        parts = []
        for block in msg.get("content", []):
            if isinstance(block, dict) and "text" in block:
                parts.append(block["text"])
        return " ".join(parts)

    def _extract_last_query(self, messages: list[dict]) -> str:
        for msg in reversed(messages):
            if msg.get("role") == "user":
                return self._extract_text(msg)
        return ""
