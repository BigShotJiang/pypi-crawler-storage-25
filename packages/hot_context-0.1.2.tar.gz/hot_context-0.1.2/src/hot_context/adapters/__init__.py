"""Framework adapters for hot-context."""
