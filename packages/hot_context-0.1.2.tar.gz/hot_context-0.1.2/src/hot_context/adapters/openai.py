"""OpenAI chat completion adapter for hot-context.

Translates OpenAI message format to hot-context ContextEntry format.
"""

from __future__ import annotations

from typing import Any

from hot_context.manager import HotContextManager
from hot_context.scorer import ScoringWeights


def _openai_to_converse(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert OpenAI messages to Converse API format."""
    converted = []
    for msg in messages:
        role = msg.get("role", "user")
        if role == "system":
            continue  # system prompt handled separately
        content = msg.get("content", "")
        # Handle tool calls
        if msg.get("tool_calls"):
            blocks = []
            for tc in msg["tool_calls"]:
                blocks.append({"toolUse": {
                    "name": tc["function"]["name"],
                    "toolUseId": tc["id"],
                    "input": tc["function"].get("arguments", ""),
                }})
            converted.append({"role": "assistant", "content": blocks})
        elif role == "tool":
            converted.append({"role": "user", "content": [{"toolResult": {
                "toolUseId": msg.get("tool_call_id", ""),
                "content": [{"text": content}],
            }}]})
        else:
            converted.append({"role": role, "content": [{"text": content}]})
    return converted


def _converse_to_openai(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert Converse API format back to OpenAI messages."""
    converted = []
    for msg in messages:
        role = msg.get("role", "user")
        for block in msg.get("content", []):
            if isinstance(block, dict):
                if "text" in block:
                    converted.append({"role": role, "content": block["text"]})
                elif "toolUse" in block:
                    tu = block["toolUse"]
                    converted.append({"role": "assistant", "tool_calls": [{
                        "id": tu.get("toolUseId", ""),
                        "type": "function",
                        "function": {"name": tu["name"], "arguments": str(tu.get("input", ""))},
                    }]})
                elif "toolResult" in block:
                    tr = block["toolResult"]
                    text = " ".join(i.get("text", "") for i in tr.get("content", []))
                    converted.append({"role": "tool", "tool_call_id": tr.get("toolUseId", ""), "content": text})
    return converted


class OpenAIHotContext:
    """OpenAI-compatible context manager using hot-context.

    Usage:
        from hot_context.adapters.openai import OpenAIHotContext

        ctx = OpenAIHotContext(token_budget=50_000)
        ctx.add_messages(conversation_history)
        managed = ctx.get_context(query="latest question")
        # Pass managed messages to openai.chat.completions.create()
    """

    def __init__(
        self,
        token_budget: int = 100_000,
        weights: ScoringWeights | None = None,
        pin_last_n: int = 2,
    ):
        self._manager = HotContextManager(
            token_budget=token_budget, weights=weights, pin_last_n=pin_last_n,
        )

    def add_messages(self, messages: list[dict[str, Any]]) -> None:
        converted = _openai_to_converse(messages)
        self._manager.add_messages(converted)

    def get_context(self, query: str) -> list[dict[str, Any]]:
        self._manager.on_query(query)
        return _converse_to_openai(self._manager.get_context_messages())

    def on_response(self, response_text: str) -> None:
        self._manager.on_response(response_text)
