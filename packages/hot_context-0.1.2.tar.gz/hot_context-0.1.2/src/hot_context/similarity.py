"""Similarity functions for scoring and trimming.

Auto-detects sentence-transformers. Falls back to entity overlap.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np

    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False


@runtime_checkable
class SimilarityFunction(Protocol):
    """Protocol for pluggable similarity."""

    def score(self, query: str, text: str) -> float: ...
    def score_batch(self, query: str, texts: list[str]) -> list[float]: ...


class EmbeddingSimilarity:
    """Semantic similarity using sentence-transformers.

    Install: pip install hot-context[embeddings]
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        if not _HAS_EMBEDDINGS:
            raise ImportError(
                "sentence-transformers required: pip install hot-context[embeddings]"
            )
        self._model = SentenceTransformer(model_name)
        self._cache: dict[str, np.ndarray] = {}

    def _embed(self, text: str) -> np.ndarray:
        if text not in self._cache:
            self._cache[text] = self._model.encode(text, normalize_embeddings=True)
        return self._cache[text]

    def score(self, query: str, text: str) -> float:
        q = self._embed(query)
        t = self._embed(text)
        return float(np.dot(q, t))

    def score_batch(self, query: str, texts: list[str]) -> list[float]:
        if not texts:
            return []
        q = self._embed(query)
        # Batch encode uncached texts
        uncached = [t for t in texts if t not in self._cache]
        if uncached:
            embeddings = self._model.encode(uncached, normalize_embeddings=True)
            for t, emb in zip(uncached, embeddings):
                self._cache[t] = emb
        scores = [float(np.dot(q, self._cache[t])) for t in texts]
        return scores

    def clear_cache(self) -> None:
        self._cache.clear()


class JaccardSimilarity:
    """Default: token-level Jaccard overlap. Zero deps."""

    def score(self, query: str, text: str) -> float:
        q = set(query.lower().split())
        t = set(text.lower().split())
        if not q or not t:
            return 0.0
        return len(q & t) / len(q | t)

    def score_batch(self, query: str, texts: list[str]) -> list[float]:
        return [self.score(query, t) for t in texts]


def get_best_similarity() -> SimilarityFunction:
    """Return the best available similarity function."""
    if _HAS_EMBEDDINGS:
        logger.info("Using EmbeddingSimilarity (sentence-transformers)")
        return EmbeddingSimilarity()
    logger.info("Using JaccardSimilarity (install sentence-transformers for better results)")
    return JaccardSimilarity()
