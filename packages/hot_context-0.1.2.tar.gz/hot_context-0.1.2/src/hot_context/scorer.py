"""Relevance scoring engine. Pure math, no LLM.

Revised formula:
  score(ci, Q) = α · sim(ci, Q)
               + β · exp(-λ · (turn - last_access(ci)))
               + γ · Σ exp(-μ · (turn - t_k))  for each access k
               - δ · (tokens(ci) / budget)
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from hot_context.types import ContextEntry, ScoringWeights


class EntitySimilarityFunction(Protocol):
    """Pluggable similarity for entity-set comparison in scoring."""
    def __call__(self, entry_entities: set[str], query_entities: set[str]) -> float: ...


def jaccard_similarity(entry_entities: set[str], query_entities: set[str]) -> float:
    """Default similarity: Jaccard index on entity sets."""
    if not entry_entities or not query_entities:
        return 0.0
    return len(entry_entities & query_entities) / len(entry_entities | query_entities)


class ContextScorer:
    """Scores context entries against a query.

    Args:
        weights: α, β, γ, δ coefficients.
        recency_lambda: λ — controls recency decay speed.
        access_decay_mu: μ — controls access frequency decay speed.
        topic_shift_boost: How much to boost α on topic shift.
        min_frequency_floor: Minimum frequency score for new chunks (cold start).
        similarity_fn: Pluggable similarity function. Default: Jaccard.
    """

    def __init__(
        self,
        weights: ScoringWeights | None = None,
        recency_lambda: float = 0.2,
        access_decay_mu: float = 0.3,
        topic_shift_boost: float = 0.15,
        min_frequency_floor: float = 0.1,
        similarity_fn: EntitySimilarityFunction | None = None,
    ):
        self.weights = weights or ScoringWeights()
        self.recency_lambda = recency_lambda
        self.access_decay_mu = access_decay_mu
        self.topic_shift_boost = topic_shift_boost
        self.min_frequency_floor = min_frequency_floor
        self.similarity_fn = similarity_fn or jaccard_similarity
        self._prev_query_entities: set[str] | None = None

    def score_all(
        self,
        entries: list[ContextEntry],
        query_entities: set[str],
        current_turn: int,
        token_budget: int,
    ) -> list[ContextEntry]:
        """Score all entries. Returns sorted by score descending."""
        topic_continuity = self._topic_continuity(query_entities)
        self._prev_query_entities = query_entities
        w = self._adapt_weights(topic_continuity)

        for entry in entries:
            if entry.pinned:
                entry.score = float("inf")
                continue

            sim = self.similarity_fn(entry.entities, query_entities)
            rec = math.exp(-self.recency_lambda * (current_turn - entry.last_access_turn))
            freq = self._access_frequency(entry, current_turn)
            size = entry.token_estimate / max(token_budget, 1)

            entry.score = (
                w.similarity * sim
                + w.recency * rec
                + w.access_freq * freq
                - w.size_penalty * min(size, 1.0)
            )

        return sorted(entries, key=lambda e: e.score, reverse=True)

    def _access_frequency(self, entry: ContextEntry, current_turn: int) -> float:
        """Time-decayed access frequency: Σ exp(-μ · (turn - t_k))."""
        if not entry.access_log:
            return self.min_frequency_floor
        score = sum(
            math.exp(-self.access_decay_mu * (current_turn - r.turn))
            for r in entry.access_log
        )
        return min(score, 1.0)

    def _topic_continuity(self, query_entities: set[str]) -> float:
        if self._prev_query_entities is None or not query_entities:
            return 1.0
        if not self._prev_query_entities:
            return 0.5
        union = query_entities | self._prev_query_entities
        return len(query_entities & self._prev_query_entities) / len(union) if union else 1.0

    def _adapt_weights(self, topic_continuity: float) -> ScoringWeights:
        w = self.weights
        shift = (1.0 - topic_continuity) * self.topic_shift_boost
        return ScoringWeights(
            similarity=w.similarity + shift,
            recency=w.recency,
            access_freq=w.access_freq * topic_continuity,
            size_penalty=w.size_penalty,
        )
