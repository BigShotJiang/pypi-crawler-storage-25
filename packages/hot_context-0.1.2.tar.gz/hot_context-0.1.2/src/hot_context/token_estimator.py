"""Adaptive token estimator that calibrates from actual LLM token counts.

Instead of guessing chars-per-token, learns a multiplier from real data.
After each LLM call, feed back the actual token count to improve estimates.
"""

from __future__ import annotations

import logging
from collections import deque

logger = logging.getLogger(__name__)

# Initial conservative guess (will be calibrated)
_DEFAULT_CHARS_PER_TOKEN = 3
_CALIBRATION_WINDOW = 20  # rolling window of observations


class TokenEstimator:
    """Learns the real chars-per-token ratio from LLM feedback.

    Usage:
        estimator = TokenEstimator()
        est = estimator.estimate(messages)       # before LLM call
        estimator.calibrate(messages, actual=87450)  # after LLM reports tokens
        # future estimates are now more accurate
    """

    def __init__(self, initial_ratio: float = _DEFAULT_CHARS_PER_TOKEN):
        self._ratio = initial_ratio
        self._observations: deque[float] = deque(maxlen=_CALIBRATION_WINDOW)

    @property
    def ratio(self) -> float:
        return self._ratio

    def estimate(self, messages: list[dict]) -> int:
        """Estimate token count for a message list."""
        char_count = len(str(messages))
        return max(char_count // max(int(self._ratio), 1), 1)

    def estimate_text(self, text: str) -> int:
        """Estimate token count for raw text."""
        return max(len(text) // max(int(self._ratio), 1), 1)

    def calibrate(self, messages: list[dict], actual_tokens: int) -> None:
        """Update ratio based on actual token count from LLM.

        Args:
            messages: The messages that were sent to the LLM.
            actual_tokens: The actual input token count reported by the LLM.
        """
        if actual_tokens <= 0:
            return

        char_count = len(str(messages))
        if char_count <= 0:
            return

        observed_ratio = char_count / actual_tokens
        self._observations.append(observed_ratio)

        # Use median of observations for robustness
        sorted_obs = sorted(self._observations)
        mid = len(sorted_obs) // 2
        self._ratio = sorted_obs[mid]

        logger.debug(
            "calibrated: chars=%d actual=%d observed_ratio=%.2f new_ratio=%.2f",
            char_count, actual_tokens, observed_ratio, self._ratio,
        )
