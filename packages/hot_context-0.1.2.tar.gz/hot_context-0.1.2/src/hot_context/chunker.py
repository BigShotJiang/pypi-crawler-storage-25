"""Smart chunking that respects tool call/result pairing.

Groups messages into atomic ContextEntry blocks:
- toolUse + toolResult = one block (API requires pairing)
  - Large tool results are split into logical sub-sections
- user message = one block
- assistant text response = one block

Supports Converse API format. Adapters for other formats
should convert to this structure before chunking.
"""

from __future__ import annotations

import logging
from typing import Any

from hot_context.entity_extractor import EntityExtractor
from hot_context.token_estimator import TokenEstimator
from hot_context.types import ContextEntry

logger = logging.getLogger(__name__)

# Shared default estimator; adapters can inject a calibrated one
_default_estimator = TokenEstimator()

# Tool results larger than this get sub-chunked
_SUB_CHUNK_THRESHOLD = 5000  # tokens


def estimate_tokens(text: str) -> int:
    return _default_estimator.estimate_text(text)


def extract_text(message: dict[str, Any]) -> str:
    """Extract all text content from a Converse API message."""
    parts = []
    for block in message.get("content", []):
        if isinstance(block, dict):
            if "text" in block:
                parts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                parts.append(f"{tu.get('name', '')} {str(tu.get('input', ''))}")
            elif "toolResult" in block:
                for item in block["toolResult"].get("content", []):
                    if "text" in item:
                        parts.append(item["text"])
        elif isinstance(block, str):
            parts.append(block)
    return " ".join(parts)


def chunk_messages(
    messages: list[dict[str, Any]],
    extractor: EntityExtractor,
    start_turn: int = 0,
    estimator: TokenEstimator | None = None,
) -> list[ContextEntry]:
    """Convert messages into scored ContextEntry blocks."""
    est = estimator or _default_estimator
    entries: list[ContextEntry] = []
    turn = start_turn
    i = 0

    while i < len(messages):
        msg = messages[i]
        if not isinstance(msg, dict):
            logger.warning("skipping non-dict message at index %d", i)
            i += 1
            continue

        role = msg.get("role", "")
        content = msg.get("content", [])
        if not isinstance(content, list):
            content = []

        has_tool_use = any(
            isinstance(b, dict) and "toolUse" in b for b in content
        )

        if role == "assistant" and has_tool_use:
            block = [msg]
            j = i + 1
            while j < len(messages):
                next_content = messages[j].get("content", [])
                has_result = any(
                    isinstance(b, dict) and "toolResult" in b for b in next_content
                )
                if has_result:
                    block.append(messages[j])
                    j += 1
                    if j < len(messages) and messages[j].get("role") == "assistant":
                        nc = messages[j].get("content", [])
                        if not any(isinstance(b, dict) and "toolUse" in b for b in nc):
                            block.append(messages[j])
                            j += 1
                    break
                else:
                    break

            text = " ".join(extract_text(m) for m in block)
            tok = est.estimate_text(text)

            if tok > 1:  # skip empty tool results
                entries.append(ContextEntry(
                    messages=block,
                    turn_index=turn,
                    role="tool_pair",
                    entities=extractor.extract(text),
                    token_estimate=tok,
                ))
            i = j
        else:
            text = extract_text(msg)
            tok = est.estimate_text(text) if text.strip() else 1
            entries.append(ContextEntry(
                messages=[msg],
                turn_index=turn,
                role=role,
                entities=extractor.extract(text) if text.strip() else set(),
                token_estimate=tok,
            ))
            i += 1

        turn += 1

    return entries
