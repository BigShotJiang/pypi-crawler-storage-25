"""Core types for hot-context."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AccessRecord:
    """Single access event for a context entry."""
    timestamp: float
    turn: int
    query: str


@dataclass
class ScoringWeights:
    """Tunable weights for the scoring formula.

    score = α·similarity + β·recency + γ·access_freq - δ·size_penalty
    """
    similarity: float = 0.4
    recency: float = 0.3
    access_freq: float = 0.2
    size_penalty: float = 0.1

    @classmethod
    def tool_agent(cls) -> ScoringWeights:
        return cls(similarity=0.45, recency=0.25, access_freq=0.2, size_penalty=0.1)

    @classmethod
    def conversational(cls) -> ScoringWeights:
        return cls(similarity=0.25, recency=0.35, access_freq=0.3, size_penalty=0.1)

    @classmethod
    def research(cls) -> ScoringWeights:
        return cls(similarity=0.4, recency=0.15, access_freq=0.35, size_penalty=0.1)


@dataclass
class ContextEntry:
    """A scored chunk of conversation context.

    Framework-agnostic: `messages` holds raw message dicts in whatever
    format the adapter provides (Converse API, OpenAI, LangChain, etc.)
    """
    messages: list[dict[str, Any]]
    turn_index: int
    role: str  # "user", "assistant", "tool_pair", "stub"
    entities: set[str] = field(default_factory=set)
    token_estimate: int = 0
    access_log: list[AccessRecord] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    score: float = 0.0
    pinned: bool = False

    @property
    def access_count(self) -> int:
        return len(self.access_log)

    @property
    def last_access_turn(self) -> int:
        """Last turn this entry was accessed, or creation turn if never accessed."""
        if self.access_log:
            return max(r.turn for r in self.access_log)
        return self.turn_index

    def record_access(self, query: str, turn: int) -> None:
        self.access_log.append(AccessRecord(
            timestamp=time.time(), turn=turn, query=query,
        ))
