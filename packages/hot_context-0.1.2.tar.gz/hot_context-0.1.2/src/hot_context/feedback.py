"""Feedback loop: analyze LLM response to update access logs.

Uses entity echo as proxy for attention weights — if entities from a
context entry appear in the LLM's response, that entry was "used".
"""

from __future__ import annotations

from hot_context.entity_extractor import EntityExtractor
from hot_context.types import ContextEntry


def update_access_from_response(
    entries: list[ContextEntry],
    response_text: str,
    query: str,
    extractor: EntityExtractor,
    current_turn: int,
    min_overlap: int = 1,
) -> list[ContextEntry]:
    """Update access logs for entries whose entities appear in the LLM response."""
    response_entities = extractor.extract(response_text)
    if not response_entities:
        return entries

    for entry in entries:
        overlap = entry.entities & response_entities
        if len(overlap) >= min_overlap:
            entry.record_access(query, current_turn)

    return entries
