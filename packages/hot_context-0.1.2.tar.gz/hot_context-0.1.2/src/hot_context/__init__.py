"""hot-context: LRU-based intelligent context manager for LLM agents.

Core (framework-agnostic):
    from hot_context import HotContextManager, ScoringWeights

Strands adapter:
    from hot_context.adapters.strands import StrandsHotContextManager

LangChain adapter:
    from hot_context.adapters.langchain import LangChainHotContextMemory

OpenAI adapter:
    from hot_context.adapters.openai import OpenAIHotContext
"""

from hot_context.manager import HotContextManager
from hot_context.scorer import ContextScorer, ScoringWeights
from hot_context.similarity import JaccardSimilarity, SimilarityFunction, get_best_similarity
from hot_context.token_estimator import TokenEstimator
from hot_context.types import ContextEntry, AccessRecord

__all__ = [
    "HotContextManager",
    "ContextScorer",
    "ScoringWeights",
    "SimilarityFunction",
    "JaccardSimilarity",
    "get_best_similarity",
    "TokenEstimator",
    "ContextEntry",
    "AccessRecord",
]
