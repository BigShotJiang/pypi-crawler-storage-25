"""Trim tool results to only the lines relevant to the LLM's response.

Uses semantic similarity (if available) or entity matching to determine
which lines of a tool result the LLM actually used.
"""

from __future__ import annotations

import logging
from typing import Any

from hot_context.similarity import SimilarityFunction, get_best_similarity

logger = logging.getLogger(__name__)

_CONTEXT_LINES = 2
_MIN_LINES_TO_TRIM = 10
_KEEP_THRESHOLD = 0.15  # similarity score threshold


def trim_tool_result(
    entry_messages: list[dict[str, Any]],
    used_entities: set[str],
    answer_text: str = "",
    similarity_fn: SimilarityFunction | None = None,
    context_lines: int = _CONTEXT_LINES,
) -> list[dict[str, Any]]:
    """Trim tool result messages to only relevant lines.

    If similarity_fn is available and answer_text provided, uses semantic
    similarity. Otherwise falls back to entity string matching.
    """
    result = []
    for msg in entry_messages:
        content = msg.get("content", [])
        new_content = []
        for block in content:
            if isinstance(block, dict) and "toolResult" in block:
                trimmed = _trim_block(
                    block, used_entities, answer_text, similarity_fn, context_lines,
                )
                new_content.append(trimmed)
            else:
                new_content.append(block)
        result.append({**msg, "content": new_content})
    return result


def _trim_block(
    block: dict[str, Any],
    entities: set[str],
    answer_text: str,
    similarity_fn: SimilarityFunction | None,
    context_lines: int,
) -> dict[str, Any]:
    tr = block["toolResult"]
    items = tr.get("content", [])
    new_items = []

    for item in items:
        if isinstance(item, dict) and "text" in item:
            text = item["text"]
            trimmed = _trim_text(text, entities, answer_text, similarity_fn, context_lines)
            if trimmed:
                new_items.append({**item, "text": trimmed})
        else:
            new_items.append(item)

    return {**block, "toolResult": {**tr, "content": new_items}}


def _trim_text(
    text: str,
    entities: set[str],
    answer_text: str,
    similarity_fn: SimilarityFunction | None,
    context_lines: int,
) -> str:
    lines = text.split("\n")
    if len(lines) <= _MIN_LINES_TO_TRIM:
        return text

    if similarity_fn and answer_text:
        relevant = _score_lines_semantic(lines, answer_text, similarity_fn, context_lines)
    else:
        relevant = _score_lines_entity(lines, entities, context_lines)

    if not relevant:
        # No matches — keep first and last few lines as summary
        relevant = set(range(min(5, len(lines)))) | set(range(max(0, len(lines) - 3), len(lines)))

    # Always keep at least 10% of lines to preserve context
    min_keep = max(len(lines) // 10, 5)
    if len(relevant) < min_keep:
        # Add first N lines (usually headers/schema)
        for i in range(min(min_keep, len(lines))):
            relevant.add(i)

    if len(relevant) >= len(lines) * 0.8:
        return text

    return _build_trimmed(lines, relevant)


def _score_lines_semantic(
    lines: list[str],
    answer_text: str,
    similarity_fn: SimilarityFunction,
    context_lines: int,
) -> set[int]:
    """Score lines using semantic similarity against the LLM's answer."""
    # Filter out empty/tiny lines for scoring
    scorable = [(i, line) for i, line in enumerate(lines) if len(line.strip()) > 5]
    if not scorable:
        return set(range(len(lines)))

    indices, texts = zip(*scorable)
    scores = similarity_fn.score_batch(answer_text, list(texts))

    relevant: set[int] = set()
    # Always keep first line (usually header/schema)
    relevant.add(0)

    for idx, score in zip(indices, scores):
        if score >= _KEEP_THRESHOLD:
            for j in range(max(0, idx - context_lines), min(len(lines), idx + context_lines + 1)):
                relevant.add(j)

    return relevant


def _score_lines_entity(
    lines: list[str],
    entities: set[str],
    context_lines: int,
) -> set[int]:
    """Score lines using entity string matching."""
    entities_lower = {e.lower() for e in entities}
    relevant: set[int] = set()

    for i, line in enumerate(lines):
        line_lower = line.lower()
        if any(e in line_lower for e in entities_lower):
            for j in range(max(0, i - context_lines), min(len(lines), i + context_lines + 1)):
                relevant.add(j)

    return relevant


def _build_trimmed(lines: list[str], relevant: set[int]) -> str:
    sorted_indices = sorted(relevant)
    output = []
    prev = -2

    for idx in sorted_indices:
        if idx > prev + 1:
            gap = idx - prev - 1
            output.append(f"... [{gap} lines trimmed] ...")
        output.append(lines[idx])
        prev = idx

    trimmed_count = len(lines) - len(relevant)
    if trimmed_count > 0:
        output.append(f"\n[trimmed {trimmed_count}/{len(lines)} irrelevant lines]")

    logger.info("trimmed tool result: %d → %d lines", len(lines), len(relevant))
    return "\n".join(output)
