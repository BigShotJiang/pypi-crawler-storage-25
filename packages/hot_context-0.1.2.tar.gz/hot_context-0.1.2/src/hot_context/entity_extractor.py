"""Lightweight regex-based entity extraction. No LLM needed.

Default patterns are intentionally generic — they fire on common structured
tokens that appear across domains: dates, IDs, numbers, codes, and URIs.
Domain-specific patterns (order IDs, ticker symbols, etc.) can be added via
extra_patterns or add_pattern().
"""

from __future__ import annotations

import re

# Default patterns ordered from most to least specific to minimize false positives.
_DEFAULT_PATTERNS: list[tuple[str, re.Pattern]] = [
    # ISO date: 2024-03-15
    ("date",
     re.compile(r"\b\d{4}-\d{2}-\d{2}\b")),

    # UUID: 550e8400-e29b-41d4-a716-446655440000
    ("uuid",
     re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)),

    # Semantic version: 1.2.3 or 1.2.3-beta
    ("semver",
     re.compile(r"\bv?\d+\.\d+\.\d+(?:-[\w.]+)?\b")),

    # Email address
    ("email",
     re.compile(r"\b[\w.+-]+@[\w-]+\.\w{2,}\b")),

    # URL / URI (http, https, ftp, s3, arn)
    ("uri",
     re.compile(r"\b(?:https?|ftp|s3|arn)://\S+\b")),

    # Hex color or short hash: #a1b2c3 or #fff
    ("hex",
     re.compile(r"#[0-9a-fA-F]{3,8}\b")),

    # Alphanumeric ID: mixed case+digits, 4–32 chars (order IDs, commit hashes, ticket numbers)
    # Requires at least one letter and one digit to avoid matching plain words or plain numbers
    ("alphanum_id",
     re.compile(r"\b(?=[A-Za-z0-9_-]{4,32}\b)(?=[^a-zA-Z]*[a-zA-Z])(?=[^0-9]*[0-9])[A-Za-z0-9_-]{4,32}\b")),

    # ALL_CAPS_IDENTIFIER: ENV_VAR, STATUS_CODE, FEATURE_FLAG (min 2 segments)
    ("caps_identifier",
     re.compile(r"\b[A-Z][A-Z0-9]{1,}(?:_[A-Z0-9]+)+\b")),

    # Large number: 4+ digits (prices, token counts, record counts)
    ("large_number",
     re.compile(r"\b\d{4,}\b")),
]


class EntityExtractor:
    """Extract entities from text using regex patterns.

    Ships with domain-agnostic defaults. Register custom patterns
    for your specific domain via constructor or add_pattern().

    Examples:
        # E-commerce
        EntityExtractor(extra_patterns=[
            ("asin",     re.compile(r"\\bB[A-Z0-9]{9}\\b")),
            ("order_id", re.compile(r"\\b\\d{3}-\\d{7}-\\d{7}\\b")),
        ])

        # Finance
        EntityExtractor(extra_patterns=[
            ("ticker", re.compile(r"\\b[A-Z]{1,5}\\b")),
            ("isin",   re.compile(r"\\b[A-Z]{2}[A-Z0-9]{10}\\b")),
        ])

        # DevOps
        EntityExtractor(extra_patterns=[
            ("ip",      re.compile(r"\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")),
            ("git_sha", re.compile(r"\\b[0-9a-f]{7,40}\\b")),
        ])
    """

    def __init__(self, extra_patterns: list[tuple[str, re.Pattern]] | None = None):
        self.patterns = list(_DEFAULT_PATTERNS)
        if extra_patterns:
            self.patterns.extend(extra_patterns)

    def extract(self, text: str) -> set[str]:
        """Extract all matching entities from text."""
        entities: set[str] = set()
        for _, pattern in self.patterns:
            entities.update(pattern.findall(text))
        return entities

    def add_pattern(self, name: str, pattern: re.Pattern) -> None:
        """Register a new pattern at runtime."""
        self.patterns.append((name, pattern))
