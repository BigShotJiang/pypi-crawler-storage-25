"""Strands agent integration example."""

try:
    from strands import Agent
    from strands.models.bedrock import BedrockModel
except ImportError:
    raise ImportError(
        "strands-agents is required to run this example. "
        "Install with: pip install strands-agents "
        "or: pip install hot-context[strands]"
    )

from hot_context.adapters.strands import StrandsHotContextManager
from hot_context.scorer import ScoringWeights

# Drop-in replacement for SlidingWindowConversationManager
agent = Agent(
    model=BedrockModel(model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0"),
    conversation_manager=StrandsHotContextManager(
        token_budget=100_000,
        weights=ScoringWeights.tool_agent(),
        pin_last_n=2,
    ),
)

# Use agent normally — hot-context manages context automatically
result = agent("Hi agent")
print(result)
