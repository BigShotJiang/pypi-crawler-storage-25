"""Unit tests for chunker.py"""

from __future__ import annotations

import pytest
from hot_context.chunker import chunk_messages, estimate_tokens, extract_text
from hot_context.entity_extractor import EntityExtractor


@pytest.fixture
def ext():
    return EntityExtractor()


def user_msg(text):
    return {"role": "user", "content": [{"text": text}]}

def assistant_msg(text):
    return {"role": "assistant", "content": [{"text": text}]}

def tool_use_msg(name="tool1", input_data=None):
    return {"role": "assistant", "content": [{"toolUse": {"name": name, "input": input_data or {}}}]}

def tool_result_msg(text="result"):
    return {"role": "user", "content": [{"toolResult": {"content": [{"text": text}]}}]}


def test_user_message_becomes_entry(ext):
    entries = chunk_messages([user_msg("hello")], ext)
    assert len(entries) == 1
    assert entries[0].role == "user"


def test_assistant_message_becomes_entry(ext):
    entries = chunk_messages([assistant_msg("hello")], ext)
    assert len(entries) == 1
    assert entries[0].role == "assistant"


def test_tool_use_and_result_paired(ext):
    entries = chunk_messages([tool_use_msg(), tool_result_msg()], ext)
    assert len(entries) == 1
    assert entries[0].role == "tool_pair"
    assert len(entries[0].messages) == 2


def test_tool_pair_includes_followup_assistant(ext):
    msgs = [tool_use_msg(), tool_result_msg(), assistant_msg("Done!")]
    entries = chunk_messages(msgs, ext)
    assert entries[0].role == "tool_pair"
    assert len(entries[0].messages) == 3


def test_start_turn_offset(ext):
    entries = chunk_messages([user_msg("hi")], ext, start_turn=10)
    assert entries[0].turn_index == 10


def test_non_dict_message_skipped(ext):
    entries = chunk_messages(["not a dict", user_msg("hello")], ext)
    assert len(entries) == 1


def test_extract_text_from_plain_text():
    msg = {"content": [{"text": "hello world"}]}
    assert "hello world" in extract_text(msg)


def test_extract_text_from_tool_use():
    msg = {"content": [{"toolUse": {"name": "search", "input": {"q": "test"}}}]}
    assert "search" in extract_text(msg)


def test_extract_text_from_tool_result():
    msg = {"content": [{"toolResult": {"content": [{"text": "found it"}]}}]}
    assert "found it" in extract_text(msg)


def test_estimate_tokens_positive():
    assert estimate_tokens("some text here") >= 1
