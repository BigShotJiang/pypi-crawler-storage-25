"""Unit tests for entity_extractor.py"""

from __future__ import annotations

import re

import pytest
from hot_context.entity_extractor import EntityExtractor


@pytest.fixture
def ext():
    return EntityExtractor()


def test_extracts_date(ext):
    assert "2024-03-15" in ext.extract("Event on 2024-03-15 at the venue")


def test_extracts_uuid(ext):
    uid = "550e8400-e29b-41d4-a716-446655440000"
    assert uid in ext.extract(f"ID is {uid}")


def test_extracts_facility_id(ext):
    assert "ABC1" in ext.extract("Located at ABC1 facility")


def test_extracts_number(ext):
    assert "42" in ext.extract("processed 42 items")


def test_no_matches_returns_empty_set(ext):
    assert isinstance(ext.extract("hello world"), set)


def test_multiple_dates(ext):
    entities = ext.extract("From 2023-01-01 to 2023-12-31")
    assert "2023-01-01" in entities
    assert "2023-12-31" in entities


def test_custom_pattern_via_constructor():
    ext = EntityExtractor(extra_patterns=[("ticker", re.compile(r"\$[A-Z]+"))])
    assert "$AAPL" in ext.extract("Buy $AAPL now")


def test_add_pattern(ext):
    ext.add_pattern("email", re.compile(r"[\w.+-]+@[\w-]+\.\w+"))
    assert "foo@bar.com" in ext.extract("reach me at foo@bar.com")
