"""Unit tests for trimmer.py"""

from __future__ import annotations

import pytest
from hot_context.similarity import JaccardSimilarity
from hot_context.trimmer import trim_tool_result


def tool_result_msg(text):
    return {"role": "user", "content": [{"toolResult": {"content": [{"text": text}]}}]}


def test_short_result_not_trimmed():
    text = "\n".join(f"line {i}" for i in range(5))
    msgs = [tool_result_msg(text)]
    result = trim_tool_result(msgs, used_entities={"line"})
    out = result[0]["content"][0]["toolResult"]["content"][0]["text"]
    assert out == text


def test_long_result_trimmed_with_entities():
    lines = [f"irrelevant line {i}" for i in range(30)]
    lines[15] = "important line with entity ABC123"
    msgs = [tool_result_msg("\n".join(lines))]
    result = trim_tool_result(msgs, used_entities={"ABC123"})
    out = result[0]["content"][0]["toolResult"]["content"][0]["text"]
    assert "ABC123" in out


def test_non_tool_result_blocks_unchanged():
    msgs = [{"role": "assistant", "content": [{"text": "plain response"}]}]
    result = trim_tool_result(msgs, used_entities=set())
    assert result[0]["content"][0]["text"] == "plain response"


def test_no_matches_keeps_fallback_lines():
    lines = [f"line {i}" for i in range(25)]
    msgs = [tool_result_msg("\n".join(lines))]
    result = trim_tool_result(msgs, used_entities={"NOMATCH"})
    out = result[0]["content"][0]["toolResult"]["content"][0]["text"]
    assert len(out) > 0


def test_trim_with_answer_text_and_similarity():
    lines = [f"word{i} word{i}" for i in range(25)]
    lines[12] = "target answer relevant text"
    msgs = [tool_result_msg("\n".join(lines))]
    result = trim_tool_result(
        msgs, used_entities=set(),
        answer_text="target answer",
        similarity_fn=JaccardSimilarity(),
    )
    out = result[0]["content"][0]["toolResult"]["content"][0]["text"]
    assert len(out) > 0
