"""Unit tests for feedback.py"""

from __future__ import annotations

import pytest
from hot_context.entity_extractor import EntityExtractor
from hot_context.feedback import update_access_from_response
from hot_context.types import ContextEntry


@pytest.fixture
def ext():
    return EntityExtractor()


def make_entry(entities):
    return ContextEntry(messages=[], turn_index=0, role="user", entities=entities)


def test_matching_entities_recorded(ext):
    e = make_entry({"2024-01-01"})
    update_access_from_response([e], "result on 2024-01-01", "q", ext, current_turn=1)
    assert e.access_count == 1


def test_non_matching_entities_not_recorded(ext):
    e = make_entry({"XYZ99"})
    update_access_from_response([e], "nothing relevant here", "q", ext, current_turn=1)
    assert e.access_count == 0


def test_empty_response_skips_all(ext):
    e = make_entry({"2024-01-01"})
    update_access_from_response([e], "no entities at all here", "q", ext, 1)
    assert e.access_count == 0


def test_returns_entries_list(ext):
    e = make_entry(set())
    result = update_access_from_response([e], "text", "q", ext, 1)
    assert isinstance(result, list)
