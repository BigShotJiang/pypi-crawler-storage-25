"""Unit tests for similarity.py"""

from __future__ import annotations

import pytest
from hot_context.similarity import JaccardSimilarity, SimilarityFunction, get_best_similarity


@pytest.fixture
def sim():
    return JaccardSimilarity()


def test_identical_texts(sim):
    assert sim.score("hello world", "hello world") == 1.0


def test_disjoint_texts(sim):
    assert sim.score("foo bar", "baz qux") == 0.0


def test_partial_overlap(sim):
    score = sim.score("hello world", "hello there")
    assert 0.0 < score < 1.0


def test_empty_query(sim):
    assert sim.score("", "some text") == 0.0


def test_score_batch_length(sim):
    scores = sim.score_batch("hello world", ["hello there", "foo bar"])
    assert len(scores) == 2


def test_score_batch_ordering(sim):
    scores = sim.score_batch("hello world", ["hello there", "foo bar"])
    assert scores[0] > scores[1]


def test_score_batch_empty(sim):
    assert sim.score_batch("q", []) == []


def test_get_best_similarity_returns_protocol():
    sim = get_best_similarity()
    assert isinstance(sim, SimilarityFunction)
