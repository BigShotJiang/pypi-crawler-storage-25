"""Unit tests for token_estimator.py"""

from __future__ import annotations

import pytest
from hot_context.token_estimator import TokenEstimator


@pytest.fixture
def est():
    return TokenEstimator()


def test_estimate_text_positive(est):
    assert est.estimate_text("hello world foo bar") >= 1


def test_estimate_messages(est):
    msgs = [{"role": "user", "content": [{"text": "hello"}]}]
    assert est.estimate(msgs) >= 1


def test_estimate_empty_text_returns_at_least_one(est):
    assert est.estimate_text("") >= 1


def test_calibrate_updates_ratio(est):
    msgs = [{"role": "user", "content": "a" * 300}]
    est.calibrate(msgs, actual_tokens=100)
    assert est.ratio > 0


def test_calibrate_ignores_zero_tokens(est):
    ratio_before = est.ratio
    est.calibrate([{"role": "user", "content": "text"}], actual_tokens=0)
    assert est.ratio == ratio_before


def test_calibration_stabilizes_with_multiple_observations(est):
    msgs = [{"role": "user", "content": "x" * 400}]
    for _ in range(5):
        est.calibrate(msgs, actual_tokens=100)
    assert est.ratio > 0
