"""Unit tests for scorer.py"""

from __future__ import annotations

import pytest
from hot_context.scorer import ContextScorer, jaccard_similarity
from hot_context.types import ContextEntry


@pytest.fixture
def scorer():
    return ContextScorer()


def make_entry(entities=None, turn=0, tokens=100):
    return ContextEntry(
        messages=[], turn_index=turn, role="user",
        entities=entities or set(), token_estimate=tokens,
    )


def test_score_all_returns_sorted(scorer):
    e1 = make_entry(entities={"foo"})
    e2 = make_entry(entities={"bar"})
    result = scorer.score_all([e1, e2], {"foo"}, current_turn=1, token_budget=1000)
    assert result[0].score >= result[1].score


def test_pinned_entry_gets_inf_score(scorer):
    e = make_entry()
    e.pinned = True
    scorer.score_all([e], {"q"}, current_turn=1, token_budget=1000)
    assert e.score == float("inf")


def test_similar_entry_scores_higher(scorer):
    e_match = make_entry(entities={"alpha", "beta"})
    e_no_match = make_entry(entities={"gamma", "delta"})
    scorer.score_all([e_match, e_no_match], {"alpha", "beta"}, 1, 1000)
    assert e_match.score > e_no_match.score


def test_recent_entry_scores_higher(scorer):
    e_recent = make_entry(turn=9)
    e_old = make_entry(turn=1)
    scorer.score_all([e_recent, e_old], set(), current_turn=10, token_budget=1000)
    assert e_recent.score > e_old.score


def test_large_entry_penalized(scorer):
    e_small = make_entry(tokens=100)
    e_large = make_entry(tokens=9000)
    scorer.score_all([e_small, e_large], set(), current_turn=1, token_budget=10000)
    assert e_small.score > e_large.score


def test_access_frequency_floor_when_no_accesses(scorer):
    e = make_entry()
    assert scorer._access_frequency(e, current_turn=5) == scorer.min_frequency_floor


def test_access_frequency_increases_with_accesses(scorer):
    e = make_entry(turn=1)
    e.record_access("q", 1)
    e.record_access("q", 2)
    assert scorer._access_frequency(e, current_turn=3) > scorer.min_frequency_floor


def test_jaccard_similarity_identical():
    assert jaccard_similarity({"a"}, {"a"}) == 1.0


def test_jaccard_similarity_disjoint():
    assert jaccard_similarity({"a", "b"}, {"c", "d"}) == 0.0


def test_jaccard_similarity_empty_sets():
    assert jaccard_similarity(set(), {"a"}) == 0.0
    assert jaccard_similarity({"a"}, set()) == 0.0
