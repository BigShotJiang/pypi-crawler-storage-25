"""Unit tests for types.py"""

from __future__ import annotations

from hot_context.types import AccessRecord, ContextEntry, ScoringWeights


class TestAccessRecord:
    def test_fields(self):
        rec = AccessRecord(timestamp=1.0, turn=3, query="hello")
        assert rec.timestamp == 1.0
        assert rec.turn == 3
        assert rec.query == "hello"


class TestScoringWeights:
    def test_defaults(self):
        w = ScoringWeights()
        assert w.similarity == 0.4
        assert w.recency == 0.3
        assert w.access_freq == 0.2
        assert w.size_penalty == 0.1

    def test_tool_agent_preset(self):
        assert ScoringWeights.tool_agent().similarity == 0.45

    def test_conversational_preset(self):
        assert ScoringWeights.conversational().recency == 0.35

    def test_research_preset(self):
        assert ScoringWeights.research().access_freq == 0.35


class TestContextEntry:
    def _make(self, turn=0, **kwargs):
        return ContextEntry(messages=[], turn_index=turn, role="user", **kwargs)

    def test_access_count_empty(self):
        assert self._make().access_count == 0

    def test_record_access(self):
        e = self._make(turn=1)
        e.record_access("q1", 2)
        e.record_access("q2", 5)
        assert e.access_count == 2
        assert e.last_access_turn == 5

    def test_last_access_turn_fallback(self):
        assert self._make(turn=7).last_access_turn == 7

    def test_pinned_default_false(self):
        assert self._make().pinned is False

    def test_score_default(self):
        assert self._make().score == 0.0
