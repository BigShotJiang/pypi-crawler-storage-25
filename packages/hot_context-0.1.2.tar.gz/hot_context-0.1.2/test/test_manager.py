"""Unit tests for manager.py"""

from __future__ import annotations

import pytest
from hot_context.manager import HotContextManager


@pytest.fixture
def mgr():
    return HotContextManager(token_budget=10_000)


def user_msg(text):
    return {"role": "user", "content": [{"text": text}]}

def assistant_msg(text):
    return {"role": "assistant", "content": [{"text": text}]}


def test_initial_state(mgr):
    assert mgr.entry_count == 0
    assert mgr.total_tokens == 0


def test_add_messages_increases_count(mgr):
    mgr.add_messages([user_msg("hello")])
    assert mgr.entry_count == 1


def test_get_context_messages_ordered(mgr):
    mgr.add_messages([user_msg("first")])
    mgr.add_messages([assistant_msg("second")])
    assert len(mgr.get_context_messages()) == 2


def test_on_query_increments_turn(mgr):
    mgr.on_query("test query")
    assert mgr.current_turn == 1


def test_on_query_no_error_with_empty_entries(mgr):
    mgr.on_query("anything")  # should not raise


def test_on_response_no_error(mgr):
    mgr.add_messages([user_msg("hi 2024-01-01")])
    mgr.on_query("what happened on 2024-01-01")
    mgr.on_response("Something on 2024-01-01")


def test_total_tokens_property(mgr):
    mgr.add_messages([user_msg("hello world")])
    assert mgr.total_tokens > 0


def test_eviction_reduces_tokens():
    mgr = HotContextManager(token_budget=50)
    for i in range(20):
        mgr.add_messages([user_msg(f"message number {i} with some extra text padding")])
    mgr.on_query("query")
    assert mgr.total_tokens <= mgr.token_budget * 1.1


def test_force_reduce(mgr):
    for i in range(10):
        mgr.add_messages([user_msg(f"msg {i}")])
    before = mgr.total_tokens
    mgr.force_reduce(budget_ratio=0.3)
    assert mgr.total_tokens <= before


def test_stub_evicted_mode():
    mgr = HotContextManager(token_budget=50, stub_evicted=True)
    for i in range(15):
        mgr.add_messages([user_msg(f"long message padding text {i} " * 3)])
    mgr.on_query("query")
    roles = {e.role for e in mgr.entries}
    assert "stub" in roles or mgr.entry_count < 15
