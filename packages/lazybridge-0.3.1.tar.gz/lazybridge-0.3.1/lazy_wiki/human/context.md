# LazyContext — Context Injection

`LazyContext` lets you inject dynamic content into an agent's system prompt — without modifying the prompt string itself.

---

## The problem it solves

The old approach: manually build system prompts with f-strings.

```python
# The old way — fragile, hard to compose
system = f"""
You are a writer.
Here is the research: {researcher_output}
Style guide: {style_guide}
Current date: {datetime.now()}
"""
```

Problems:
- You need to run `researcher` before building the string
- Hard to test — the string is baked at construction time
- Hard to compose — can't mix sources cleanly

**LazyContext**: sources are evaluated *at execution time*, not at construction time.

```python
from lazybridge import LazyContext

ctx = (
    LazyContext.from_text("You are a professional writer.")
    + LazyContext.from_agent(researcher)        # evaluates researcher's output when invoked
    + LazyContext.from_function(get_style_guide) # calls get_style_guide() when invoked
)

writer = LazyAgent("openai", context=ctx)
writer.chat("write an article")   # ctx is evaluated here, after researcher has run
```

---

## Four source types

### 1. Static text

```python
ctx = LazyContext.from_text("Always answer in formal English.")
```

Use for: instructions that never change.

### 2. Function (called at execution time)

```python
from datetime import date

def current_date() -> str:
    return f"Today is {date.today().isoformat()}"

ctx = LazyContext.from_function(current_date)
```

Use for: dynamic data (current date, user profile, database lookup).

### 3. From the shared store

```python
from lazybridge import LazyStore

store = LazyStore()

# Only specific keys:
ctx = LazyContext.from_store(store, keys=["research", "style_guide"])

# All keys:
ctx = LazyContext.from_store(store)
```

Output format injected into the system prompt:
```
[shared store]
  research: <value>
  style_guide: <value>
```

Use for: state written by other agents (pattern C pipelines).

### 4. From another agent's last output

```python
researcher = LazyAgent("anthropic", name="researcher")
ctx = LazyContext.from_agent(researcher)
```

When `ctx` is evaluated:
- If `researcher` has run and returned text → injects `[researcher output]\n{output}`
- If `researcher` hasn't run yet → injects nothing, logs at DEBUG
- If `researcher` ran but returned empty output → injects nothing, logs at DEBUG

No exception is raised in any case. Enable `DEBUG` logging to diagnose silent context gaps.

Use for: passing one agent's result to another in a sequential pipeline.

---

## Composing contexts

Use `+` to combine any number of sources:

```python
ctx = (
    LazyContext.from_text("You are a senior analyst.")
    + LazyContext.from_agent(data_collector)
    + LazyContext.from_store(sess.store, keys=["market_data"])
    + LazyContext.from_function(get_current_date)
)
```

Or `LazyContext.merge()` for the same result:

```python
ctx = LazyContext.merge(
    LazyContext.from_text("You are a senior analyst."),
    LazyContext.from_agent(data_collector),
    LazyContext.from_store(sess.store, keys=["market_data"]),
)
```

Sources are evaluated in order and joined with blank lines (`\n\n`).

---

## Testing your context

Because `ctx()` is just a string, you can test it independently:

```python
# Before running any agents:
print(ctx())   # only static parts appear

# After running the researcher:
researcher.loop("find data")
print(ctx())   # now includes researcher's output
```

This is much easier to debug than embedded f-strings.

---

## Agent-level vs call-level context

```python
# Context applied to every call on this agent:
writer = LazyAgent("openai", context=LazyContext.from_text("Write in Italian."))
writer.chat("What is Python?")    # "Python è un linguaggio..."

# Override for a single call:
writer.chat("What is Python?", context=LazyContext.from_text("Write in German."))
# call-level context replaces agent-level context for this call only
```

---

## Full example

> **When to use manual store writes:** This pattern (explicit store writes between agents) is the right choice when agents are intentionally decoupled — running in separate processes, persisting results for inspection, or when any agent may be skipped. For tightly coupled sequential agents where every output feeds the next, `sess.as_tool(mode="chain")` handles the wiring automatically with no store writes at all.

Declare each agent's context upfront — LazyContext is evaluated at call time, so you can reference store keys that don't exist yet. The pipeline body becomes pure data flow.

```python
from lazybridge import LazyAgent, LazyContext, LazyStore

store = LazyStore()

# Contexts declared once — evaluated lazily when each agent actually runs
collector = LazyAgent("anthropic", name="collector")
analyst   = LazyAgent("anthropic", name="analyst",
                      context=LazyContext.from_store(store, keys=["papers"]))
writer    = LazyAgent("openai",
                      context=(
                          LazyContext.from_text("Write for a non-technical audience.")
                          + LazyContext.from_store(store, keys=["findings"])
                      ))

# Pipeline: pure execution + store handoffs
collector.loop("Collect the top 5 AI papers this month")
store.write("papers", collector.result)

analyst.chat("Identify the 3 most impactful findings")
store.write("findings", analyst.result)

writer.chat("Write a blog post from these findings")
```
