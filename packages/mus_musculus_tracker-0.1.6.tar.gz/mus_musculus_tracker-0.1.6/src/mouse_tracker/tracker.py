"""
Key points labelling, video Cropping and Object Tracking Script
Description: Allows user to select some key points, crops the video around it, 
and uses YOLO to track objects while generating a trajectory (trail) and a CSV log.

Manual points: there are now 10 labeled points: p0, p1, p2, p3, p4, p5, p6, p7, p8, p9.
They are ordered counter-clockwise, starting from the center point p0. From p0,
the next point is p1 at the inner circle intersection in the lid direction, then p2
at the inner border of the lid, and after that the remaining points follow
counter-clockwise around the outermost circle intersection of each radial line.

Install dependencies using:
conda env create -f environment.yml
conda activate mouse-tracker

How to run:
$ mouse-track your_video.mp4
$ mouse-track video_list_with_keypoints.csv

The CSV input must include a header with 21 columns:
path_and_file, p0_x, p0_y, ..., p9_x, p9_y

Tip: for OpenCV GUI to work properly install 'sudo apt install -y fonts-dejavu'
"""

from moviepy.video.io.VideoFileClip import VideoFileClip
import cv2
import sys
from pathlib import Path
import ultralytics
from ultralytics import YOLO
import csv
import numpy as np
from tqdm import tqdm

# Initialize Ultralytics checks
ultralytics.checks()

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_MODEL_PATH = PACKAGE_DIR / "weights" / "best.pt"

import warnings

warnings.filterwarnings(
    "ignore",
    message=".*Using the last valid frame instead.*"
)

def points_select(params):
    for point in range(10):
        params['current_point'] = point

        ## GUI for center point selection
        cv2.namedWindow(f'Select Point {point}', cv2.WINDOW_GUI_NORMAL)
        cv2.resizeWindow(f'Select Point {point}', 1280, 1280)
        cv2.imshow(f'Select Point {point}', params['frame'])
        cv2.setMouseCallback(f'Select Point {point}', select_point, params)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        cv2.waitKey(1)

        params['frame'] = params['frame_copy'].copy()
        
        if params[f'point_{point}'] is None:
            print(f"No point {point} selected. Exiting.")
            return False
    
    return True

# The flags parameter captures mouse event flags (like which modifier keys were held), and even though 
# you're not using it, it must be in the signature to match what OpenCV sends to the callback.
def select_point(event, x, y, flags, param):
    """Mouse callback to capture the point coordinates for cropping."""
    if event == cv2.EVENT_LBUTTONDOWN:
        param[f'point_{param["current_point"]}'] = (x, y)
        param['frame_copy'] = param['frame'].copy()
        # Draw a visual marker for the selection
        cv2.circle(param['frame_copy'], (x, y), 4, (255, 0, 0), -1)
        cv2.imshow(f'Select Point {param["current_point"]}', param['frame_copy'])
        print(f"Point selected: ({param[f'point_{param['current_point']}']})")

def crop_video_borders(video_path, params, h, w):
    """Crops the video around a center point and resizes to 640x640."""
    video = VideoFileClip(video_path)
    center_of_coordinates = params['point_0']
    # Calculate crop boundaries based on the height (creating a square)
    cropped_video = video.cropped(
        x1=center_of_coordinates[0] - h // 2,
        x2=center_of_coordinates[0] + h // 2
    ).resized((640, 640))
    
    p = Path(video_path)
    output_filename = str(p.with_name(p.stem + "_cropped" + p.suffix))

    # Save using mpeg4 codec for consistency with OpenCV output
    cropped_video.without_audio().write_videofile(output_filename, codec="mpeg4")
    
    video.close()
    cropped_video.close()
    
    print(f"Video successfully cropped and saved as: {output_filename}")
    return output_filename

def yolo_track(cropped_video_filename, params):
    """Runs YOLO tracking, draws trajectory trails, and logs data to CSV."""

    # 1. Prepare the clean filenames
    p = Path(cropped_video_filename)
    # Remove "_cropped" from the stem (filename without extension)
    base_name = p.stem.replace("_cropped", "")
    
    # Final names: segment_1_tracked.mp4 and segment_1_log.csv
    out_path = str(p.with_name(f"{base_name}_tracked{p.suffix}"))
    log_filename = str(p.with_name(f"{base_name}_log.csv"))

    # Load your custom model
    model = YOLO(str(DEFAULT_MODEL_PATH))

    results_generator = model.track(
        cropped_video_filename,
        conf=0.5,
        iou=0,
        max_det=1, # Optimized for tracking a single subject
        persist=True,
        save=False,
        show_labels=False,
        show_conf=False,
        tracker="botsort.yaml", 
        stream=True,
        verbose=False,
    )

    # Get video metadata
    cap = cv2.VideoCapture(cropped_video_filename)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()

    print(f"Video properties: {fps:.2f} FPS | Total Frames: {total_frames}")

    # Configure VideoWriter for the annotated output
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(out_path, fourcc, fps, (width, height))
    
    # Prepare CSV log file
    with open(log_filename, mode='w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Frame", "Track_ID", "Class", "Time (s)", "Confidence", 
                         "pos_x", "pos_y", 
                         "Region",
                         "p0_x", "p0_y", 
                         "p1_x", "p1_y",
                         "p2_x", "p2_y",
                         "p3_x", "p3_y",
                         "p4_x", "p4_y",
                         "p5_x", "p5_y",
                         "p6_x", "p6_y",
                         "p7_x", "p7_y",
                         "p8_x", "p8_y",
                         "p9_x", "p9_y",
                         "p10_x", "p10_y",
                         "p11_x", "p11_y",
                         "p12_x", "p12_y",
                         "p13_x", "p13_y",
                         "p14_x", "p14_y",
                         "p15_x", "p15_y",
                         "p16_x", "p16_y"
                        ])
        
    ## Adjusting coordinates based on cropping and resizing
    crop_x1 = params['point_0'][0] - params['height'] // 2

    p0_x = int((params['point_0'][0] - crop_x1) * 640 / params['height'])
    p0_y = int(params['point_0'][1] * 640 / params['height'])

    p1_x = int((params['point_1'][0] - crop_x1) * 640 / params['height'])
    p1_y = int(params['point_1'][1] * 640 / params['height'])

    p2_x = int((params['point_2'][0] - crop_x1) * 640 / params['height'])
    p2_y = int(params['point_2'][1] * 640 / params['height'])

    p3_x = int((params['point_3'][0] - crop_x1) * 640 / params['height'])
    p3_y = int(params['point_3'][1] * 640 / params['height'])

    p4_x = int((params['point_4'][0] - crop_x1) * 640 / params['height'])
    p4_y = int(params['point_4'][1] * 640 / params['height'])

    p5_x = int((params['point_5'][0] - crop_x1) * 640 / params['height'])
    p5_y = int(params['point_5'][1] * 640 / params['height'])

    p6_x = int((params['point_6'][0] - crop_x1) * 640 / params['height'])
    p6_y = int(params['point_6'][1] * 640 / params['height'])

    p7_x = int((params['point_7'][0] - crop_x1) * 640 / params['height'])
    p7_y = int(params['point_7'][1] * 640 / params['height'])

    p8_x = int((params['point_8'][0] - crop_x1) * 640 / params['height'])
    p8_y = int(params['point_8'][1] * 640 / params['height'])

    p9_x = int((params['point_9'][0] - crop_x1) * 640 / params['height'])
    p9_y = int(params['point_9'][1] * 640 / params['height'])


    # Ratio p0-p1 / p0-p2
    dist_p0_p2 = ((p2_x - p0_x) ** 2 + (p2_y - p0_y) ** 2) ** 0.5
    dist_p0_p1 = ((p1_x - p0_x) ** 2 + (p1_y - p0_y) ** 2) ** 0.5
    ratio = dist_p0_p1 / dist_p0_p2 if dist_p0_p2 != 0 else 0

    # Infer p10 on the inner circle in the direction of p3 using the p0-p1 / p0-p2 ratio
    p10_x = int(round(p0_x + ratio * (p3_x - p0_x)))
    p10_y = int(round(p0_y + ratio * (p3_y - p0_y)))

    # Infer p11 on the inner circle in the direction of p4 using the p0-p1 / p0-p2 ratio
    p11_x = int(round(p0_x + ratio * (p4_x - p0_x)))
    p11_y = int(round(p0_y + ratio * (p4_y - p0_y)))

    # Infer p12 on the inner circle in the direction of p5 using the p0-p1 / p0-p2 ratio
    p12_x = int(round(p0_x + ratio * (p5_x - p0_x)))
    p12_y = int(round(p0_y + ratio * (p5_y - p0_y)))

    # Infer p13 on the inner circle in the direction of p6 using the p0-p1 / p0-p2 ratio
    p13_x = int(round(p0_x + ratio * (p6_x - p0_x)))
    p13_y = int(round(p0_y + ratio * (p6_y - p0_y)))

    # Infer p14 on the inner circle in the direction of p7 using the p0-p1 / p0-p2 ratio
    p14_x = int(round(p0_x + ratio * (p7_x - p0_x)))
    p14_y = int(round(p0_y + ratio * (p7_y - p0_y)))

    # Infer p15 on the inner circle in the direction of p8 using the p0-p1 / p0-p2 ratio
    p15_x = int(round(p0_x + ratio * (p8_x - p0_x)))
    p15_y = int(round(p0_y + ratio * (p8_y - p0_y)))

    # Infer p16 on the inner circle in the direction of p9 using the p0-p1 / p0-p2 ratio
    p16_x = int(round(p0_x + ratio * (p9_x - p0_x)))
    p16_y = int(round(p0_y + ratio * (p9_y - p0_y)))

    # Calculate inner ellipse fitted to center (p0) and points 2,3,4,5 to have at least 5 points
    inner_points = np.array([[p1_x, p1_y], [p10_x, p10_y], [p11_x, p11_y], [p12_x, p12_y], [p13_x, p13_y], [p14_x, p14_y], [p15_x, p15_y], [p16_x, p16_y]], dtype=np.int32)
    inner_ellipse = cv2.fitEllipse(inner_points)

    # Calculate outer ellipse fitted to center (p0) and points 2,3,4,5 to have at least 5 points
    outer_points = np.array([[p2_x, p2_y], [p3_x, p3_y], [p4_x, p4_y], [p5_x, p5_y], [p6_x, p6_y], [p7_x, p7_y], [p8_x, p8_y], [p9_x, p9_y]], dtype=np.int32)
    outer_ellipse = cv2.fitEllipse(outer_points)

    # Create ellipse contours for point-in-polygon testing
    inner_center = (int(inner_ellipse[0][0]), int(inner_ellipse[0][1]))
    inner_axes = (int(inner_ellipse[1][0]/2), int(inner_ellipse[1][1]/2))
    inner_angle = int(inner_ellipse[2])
    inner_contour = cv2.ellipse2Poly(inner_center, inner_axes, inner_angle, 0, 360, 1)

    outer_center = (int(outer_ellipse[0][0]), int(outer_ellipse[0][1]))
    outer_axes = (int(outer_ellipse[1][0]/2), int(outer_ellipse[1][1]/2))
    outer_angle = int(outer_ellipse[2])
    outer_contour = cv2.ellipse2Poly(outer_center, outer_axes, outer_angle, 0, 360, 1)

    frame_index = 0
    trails = [] # Stores coordinate history for trajectory drawing

    print("\nProcessing tracking and generating logs...")

    for result in tqdm(results_generator, total=total_frames, unit="frames"):
        frame = result.orig_img

        if result.boxes:
            boxes = result.boxes.cpu().numpy()
            track_ids = boxes.id if boxes.id is not None else [-1] * len(boxes)

            for box, track_id in zip(boxes, track_ids):
                x, y, w, h = box.xywh[0]
                confidence = box.conf[0]
                cls_id = int(box.cls[0])
                class_name = result.names[cls_id]
                time_stamp = frame_index / fps

                current_point = (int(x), int(y))

                # Update trajectory if coordinates are within frame
                if 0 <= int(y) < height and 0 <= int(x) < width:
                    trails.append(current_point)

                # Draw trajectory trail
                if len(trails) > 1:
                    points_array = np.array(trails, dtype=np.int32).reshape((-1, 1, 2))
                    cv2.polylines(frame, [points_array], isClosed=False, color=(0, 255, 255), thickness=2)

                # Draw current detection point
                cv2.circle(frame, current_point, radius=3, color=(0, 0, 255), thickness=-1)

                # Drawing the coordinate points for reference
                cv2.circle(frame, (p0_x, p0_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p1_x, p1_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p2_x, p2_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p3_x, p3_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p4_x, p4_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p5_x, p5_y), radius=3, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p6_x, p6_y), radius=4, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p7_x, p7_y), radius=4, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p8_x, p8_y), radius=4, color=(255, 0, 0), thickness=-1)
                cv2.circle(frame, (p9_x, p9_y), radius=4, color=(255, 0, 0), thickness=-1)

                cv2.circle(frame, (p10_x, p10_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p11_x, p11_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p12_x, p12_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p13_x, p13_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p14_x, p14_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p15_x, p15_y), radius=4, color=(0, 165, 255), thickness=-1)
                cv2.circle(frame, (p16_x, p16_y), radius=4, color=(0, 165, 255), thickness=-1)

                # Drawing the inner and outer shapes based on the selected points
                cv2.ellipse(frame, inner_ellipse, (0, 255, 0), 1)
                cv2.ellipse(frame, outer_ellipse, (0, 255, 0), 1)

                # Determine whether the current point is inside the inner ellipse, outer ellipse, or outside
                if cv2.pointPolygonTest(inner_contour, (int(x), int(y)), False) >= 0:
                    region = "inner"
                elif cv2.pointPolygonTest(outer_contour, (int(x), int(y)), False) >= 0:
                    region = "outer"
                else:
                    region = "outside"

                # Write data to CSV
                with open(log_filename, mode='a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        frame_index, int(track_id), class_name, 
                        f"{time_stamp:.3f}", f"{confidence:.4f}", 
                        f"{x:.1f}", f"{y:.1f}",
                        region,
                        p0_x, p0_y, 
                        p1_x, p1_y, 
                        p2_x, p2_y, 
                        p3_x, p3_y, 
                        p4_x, p4_y, 
                        p5_x, p5_y, 
                        p6_x, p6_y,
                        p7_x, p7_y,
                        p8_x, p8_y,
                        p9_x, p9_y,
                        p10_x, p10_y,
                        p11_x, p11_y,
                        p12_x, p12_y,
                        p13_x, p13_y,
                        p14_x, p14_y,
                        p15_x, p15_y,
                        p16_x, p16_y
                        ])
        else:
            # Continue drawing trail even if detection is lost in current frame
            if len(trails) > 1:
                points_array = np.array(trails, dtype=np.int32).reshape((-1, 1, 2))
                cv2.polylines(frame, [points_array], isClosed=False, color=(0, 255, 255), thickness=2)

        out.write(frame)
        frame_index += 1

    out.release()
    print(f"Tracking complete. Log saved to: {log_filename}")

def load_video_keypoints_from_csv(csv_file):
    """Load a CSV list of videos with their 10 keypoints.

    The CSV must include a header with 21 columns:
    path_and_file, p0_x, p0_y, ..., p9_x, p9_y.

    Args:
        csv_file: Path to the CSV file containing video paths and keypoints.

    Returns:
        A list of dictionaries with keys 'path' and 'points', where 'points'
        is a list of 10 (x, y) tuples.
    """
    expected_columns = ["path_and_file"] + [f"p{i}_{coord}" for i in range(10) for coord in ("x", "y")]
    with open(csv_file, newline='') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            print(f"[ERROR] CSV file is empty or malformed: {csv_file}")
            sys.exit(1)

        header = [name.strip() for name in reader.fieldnames]
        if header != expected_columns:
            print(f"[ERROR] CSV header is incorrect for file: {csv_file}")
            print(f"Expected columns: {', '.join(expected_columns)}")
            sys.exit(1)

        items = []
        for row_index, row in enumerate(reader, start=1):
            video_path = row.get("path_and_file", "").strip()
            if not video_path:
                print(f"[WARNING] Missing path in row {row_index}. Skipping.")
                continue

            points = []
            invalid = False
            for i in range(10):
                x_key = f"p{i}_x"
                y_key = f"p{i}_y"
                x_raw = row.get(x_key, "").strip()
                y_raw = row.get(y_key, "").strip()
                if x_raw == "" or y_raw == "":
                    print(f"[WARNING] Missing {x_key}/{y_key} for {video_path}. Skipping.")
                    invalid = True
                    break
                try:
                    px = int(round(float(x_raw)))
                    py = int(round(float(y_raw)))
                except ValueError:
                    print(f"[WARNING] Invalid numeric data for {x_key}/{y_key} in {video_path}. Skipping.")
                    invalid = True
                    break
                points.append((px, py))

            if invalid:
                continue

            items.append({"path": video_path, "points": points})

    return items


def build_params_from_keypoints(frame, keypoints):
    """Create the tracker params dictionary from a frame and keypoints.

    This converts a list of 10 (x, y) points into the same params structure
    used by the manual selection workflow, so the rest of the pipeline can
    reuse cropping and tracking code.

    Args:
        frame: The first video frame as a NumPy array.
        keypoints: A list of 10 (x, y) tuples.

    Returns:
        A params dictionary containing frame metadata and point values.
    """
    h, w = frame.shape[:2]
    params = {
        'height': h,
        'width': w,
        'current_point': None,
        'frame': frame,
        'frame_copy': frame.copy(),
    }
    for i, point in enumerate(keypoints):
        params[f'point_{i}'] = point
    return params


def process_video(video_path, params):
    """Crop and track a single video using pre-defined keypoints.

    Args:
        video_path: Path to the input video file.
        params: Dictionary containing keypoints and frame metadata.
    """
    cropped_video_filename = crop_video_borders(video_path, params, params['height'], params['width'])
    yolo_track(cropped_video_filename, params)
    print(f"\nCleaning up temporary file: {cropped_video_filename}")
    Path(cropped_video_filename).unlink(missing_ok=True)


def parse_args():
    """Parse CLI arguments and return the input path and batch confirmation flag."""
    yes_flag = False
    input_path = None

    for arg in sys.argv[1:]:
        if arg in ("-y", "--yes"):
            yes_flag = True
        elif input_path is None:
            input_path = Path(arg)
        else:
            print(f"[ERROR] Unexpected argument: {arg}")
            print("Usage: mouse-track [-y] <mp4_video_path> or mouse-track [-y] <keypoints_list.csv>")
            sys.exit(1)

    if input_path is None:
        print("Usage: mouse-track [-y] <mp4_video_path> or mouse-track [-y] <keypoints_list.csv>")
        sys.exit(1)

    return input_path, yes_flag


def main():
    input_path, yes_flag = parse_args()
    if not input_path.exists():
        print(f"[ERROR] Input path not found: {input_path}")
        sys.exit(1)

    if input_path.suffix.lower() == ".csv":
        items = load_video_keypoints_from_csv(input_path)
        if not items:
            print("[ERROR] No valid videos found in the CSV.")
            sys.exit(1)

        print(f"Batch mode: {len(items)} videos loaded from CSV.")
        if not yes_flag:
            if input("Proceed with cropping and tracking all videos? (y/n): ").strip().lower() != 'y':
                print("Operation cancelled.")
                sys.exit(0)

        for item in items:
            video_path = item["path"]
            if not Path(video_path).exists():
                print(f"\n[WARNING] Video file does not exist: {video_path}\n")
                continue

            print(f"\nProcessing video: {video_path}")
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                print(f"[WARNING] Could not open video file: {video_path}")
                continue

            ret, frame = cap.read()
            cap.release()
            if not ret:
                print(f"[WARNING] Could not read the first frame of: {video_path}")
                continue

            params = build_params_from_keypoints(frame, item["points"])
            process_video(video_path, params)

        print("\nBatch tracking finished!")
        return
    
    else:
        video_path = str(input_path)
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            print("[ERROR] Could not open video file.")
            sys.exit(1)
        
        ret, frame = cap.read()
        cap.release()
        
        if not ret:
            print("[ERROR] Could not read the first frame.")
            sys.exit(1)
        
        h, w = frame.shape[:2]
        params = {'height': h, 'width': w,
                  'current_point': None,
                  'frame': frame, 
                  'frame_copy': frame.copy()
                 }
        for i in range(10):
            params[f'point_{i}'] = None

        ok = points_select(params)
        if not ok:
            cv2.destroyAllWindows()
            cv2.waitKey(1)
            return
        
        if not yes_flag:
            if input("\nProceed with tracking? (y/n): ").lower() != 'y':
                sys.exit(0)
        
        process_video(video_path, params)
        print("Tracking finished!")

if __name__ == "__main__":
    main()
