"""
Key points labeler tool.
Description: Allows user to select the key points of every first frame of each video in a list of videos and save to a CSV log.

Points to select: p0, p1, p2, p3, p4, p5, p6, p7, p8, p9.
They are ordered counter-clockwise, starting from the center point p0. From p0,
the next point is p1 at the inner circle intersection in the lid direction, then p2
at the inner border of the lid, and after that the remaining points follow
counter-clockwise around the outermost circle intersection of each radial line.

Create environment and install dependencies:
- conda env create -f environment.yml
- conda activate mouse-tracker

Workflow:
- Load video paths from the input CSV list (without header).
- Run manual keypoint labeling for each valid video path.
- Save labeled coordinates to the output CSV file.

How to run:
$ mouse-label your_video_list.csv output_keypoints.csv

Keyboard behavior during labeling:
- Any key (except q/Q) advances to the next point window.
- If you advance without selecting a point, the current video is skipped and the script continues to the next video.
- Pressing q or Q aborts the full batch labeling loop.

Tip: for OpenCV GUI to work properly install 'sudo apt install -y fonts-dejavu'
"""

import cv2
import sys
from pathlib import Path
import csv

def points_selection(params):
    """
    Interactive keypoint selection loop for p0..p9.

    For each keypoint index, opens an OpenCV window and waits for one mouse
    click handled by `select_point`. The selected coordinates are stored in
    `params["point_<index>"]`.

    Args:
        params: Shared state dictionary used by the GUI callback. It must
            include `frame`, `frame_copy`, `current_point`, and `point_0` to
            `point_9`.

    Returns:
        True when all points are selected.
        False when a point was not selected.
        "abort" when user presses q or Q.
    """
    for point in range(10):
        # Track which keypoint is currently requested.
        params['current_point'] = point

        # Open a resizable window and bind the mouse callback.
        cv2.namedWindow(f'Select Point {point}', cv2.WINDOW_GUI_NORMAL)
        cv2.resizeWindow(f'Select Point {point}', 1280, 1280)
        cv2.imshow(f'Select Point {point}', params['frame'])
        cv2.setMouseCallback(f'Select Point {point}', select_point, params)
        key = cv2.waitKey(0) & 0xFF
        cv2.destroyAllWindows()
        cv2.waitKey(1)

        # Abort the full batch when q/Q is pressed.
        if key in (ord('q'), ord('Q')):
            return "abort"
        
        # Preserve markers already drawn in previous selections.
        params['frame'] = params['frame_copy'].copy()
        
        # Abort if the user closed the window without selecting this point.
        if params[f'point_{point}'] is None:
            print(f"No point {point} selected. Exiting.")
            return False
    
    return True

# The flags parameter captures mouse event flags (like which modifier keys were held), and even though you're not using it, it must be in the signature to match what OpenCV sends to the callback.
def select_point(event, x, y, flags, param):
    """Mouse callback to capture the point coordinates for cropping."""
    if event == cv2.EVENT_LBUTTONDOWN:
        param[f'point_{param["current_point"]}'] = (x, y)
        param['frame_copy'] = param['frame'].copy()
        # Draw a visual marker for the selection
        cv2.circle(param['frame_copy'], (x, y), 4, (255, 0, 0), -1)
        # Draw the keypoint label near the selected pixel.
        label = f"p{param['current_point']}"
        cv2.putText(param['frame_copy'], str(param['current_point']), (x + 6, y - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.imshow(f'Select Point {param["current_point"]}', param['frame_copy'])
        print(f"Point selected: ({param[f'point_{param['current_point']}']})")
   

def keypoints_labeler(video_path):
    """
    Label keypoints on the first frame of a video.

    Opens the video, reads only the first frame, and runs the interactive
    keypoint selection workflow (`points_selection`).

    Args:
        video_path: Path to the input video file.

    Returns:
        A flat list in this order:
        [p0_x, p0_y, p1_x, p1_y, ..., p9_x, p9_y].
        Returns None if the video cannot be opened, the first frame cannot be
        read, or labeling is not completed.
    """
    # Open video and try to extract the first frame for manual labeling.
    cap = cv2.VideoCapture(video_path)

    # If OpenCV cannot open the file, skip this video.
    if not cap.isOpened():
        print(f"[WARNING] Could not open video file: {video_path}")
        return None

    # Read only the first frame; no full video processing is needed here.
    ret, frame = cap.read()
    cap.release()

    # Stop this item if the first frame is unavailable/corrupted.
    if not ret:
        print(f"[WARNING] Could not read first frame from: {video_path}")
        return None
    
    # Shared state consumed by the point-selection GUI and callback.
    h, w = frame.shape[:2]
    params = {
        'height': h,
        'width': w,
        'point_0': None, 
        'point_1': None,
        'point_2': None,
        'point_3': None,
        'point_4': None,
        'point_5': None,
        'point_6': None,
        'point_7': None,
        'point_8': None,
        'point_9': None,
        'current_point': None,
        'frame': frame,
        'frame_copy': frame.copy(),
    }

    # Collect p0..p9 interactively with mouse clicks.
    status = points_selection(params)
    if status == "abort":
        cv2.destroyAllWindows()
        cv2.waitKey(1)
        return "abort"
    if status is False:
        cv2.destroyAllWindows()
        cv2.waitKey(1)
        return None

    # Flatten tuple points to a CSV-friendly sequence.
    labeled_points = []
    for i in range(10):
        px, py = params[f"point_{i}"]
        labeled_points.extend([px, py])

    return labeled_points


def read_video_paths(video_list_file):
    """
    Read a CSV list file and return the video paths found in the first column.

    Expected input format:
    - No header.
    - One video path per line (first column).
    - Empty lines are ignored.

    Args:
        video_list_file: Path to the CSV file containing video paths. The CSV file must not have a header and only one column.

    Returns:
        A list of non-empty video path strings.
    """
    video_paths = []
    with open(video_list_file, newline='') as f:
        reader = csv.reader(f)
        for row in reader:
            # Skip fully empty rows.
            if not row:
                continue
            # Use the first column as the video path and trim surrounding spaces.
            raw_path = row[0].strip()
            # Ignore blank entries.
            if not raw_path:
                continue
            video_paths.append(raw_path)
    return video_paths


def build_output_header():
    """
    Build the CSV header for the keypoint labeling log.

    Output columns:
    - path_and_file
    - p0_x, p0_y, p1_x, p1_y, ..., p9_x, p9_y

    Returns:
        A list of column names in the expected output order.
    """
    # First column stores the original video path.
    header = ["path_and_file"]
    # Add x/y columns for each keypoint from p0 to p9.
    for i in range(10):
        header.extend([f"p{i}_x", f"p{i}_y"])
    return header

def main():
    """
    CLI entrypoint for batch keypoint labeling.

    Usage:
        mouse-label <csv_video_list_path.csv> <output_keypoints.csv>

    Workflow:
    - Load video paths from the input CSV list (without header).
    - Run manual keypoint labeling for each valid video path.
    - Save labeled coordinates to the output CSV file.
    """
    # Check that at least the input list path was provided.
    if len(sys.argv) < 3:
        print("Missing arguments. Usage: mouse-label <csv_video_list_path.csv> <output_keypoints.csv>")
        sys.exit(1)

    # Reject extra unexpected CLI arguments.
    if len(sys.argv) > 3:
        print(f"Error: too many arguments provided. Usage: mouse-label <csv_video_list_path.csv> <output_keypoints.csv>")
        sys.exit(1)

    # Read the input CSV list path and ensure it exists.
    video_list_file = sys.argv[1]
    video_list_path = Path(video_list_file)
    if not video_list_path.exists():
        print(f"Error: list file not found: {video_list_file}")
        sys.exit(1)

    # Verify that the output CSV path is valid (can be created or overwritten).
    output_csv_path = Path(sys.argv[2])
    if output_csv_path.exists():
        response = input(f"Output file already exists: {output_csv_path}\nDo you want to overwrite it? (yes/no): ").strip().lower()
        if response not in ('yes', 'y'):
            print("Operation cancelled.")
            sys.exit(1)

    # Parse the input list and decide output CSV location.
    video_paths = read_video_paths(video_list_file)
    output_csv = Path(sys.argv[2])

    # Create/overwrite the output CSV and write the column header.
    with open(output_csv, mode='w', newline='') as fout:
        writer = csv.writer(fout)
        writer.writerow(build_output_header())

        # Process each video independently and skip invalid/failed cases.
        for video_path in video_paths:
            path_obj = Path(video_path)
            if not path_obj.exists():
                print(f"\n [WARNING] Video file does not exist: \n\t {video_path} \n")
                continue

            print(f"\nLabeling keypoints for: {video_path}")
            labeled_points = keypoints_labeler(video_path)

            if labeled_points == "abort":
                print("Batch interrupted by user (quit).")
                break

            if labeled_points is None:
                print(f"\n [WARNING] Skipping video due to incomplete labeling: \n\t {video_path} \n")
                continue

            writer.writerow([video_path, *labeled_points])
            fout.flush()

    # Report completion and output file path.
    print(f"\nScript finished! Keypoints log saved to: {output_csv}")

if __name__ == "__main__":
    main()
