# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .cyclic import CyclicRecipe
from .fedavg import FedAvgRecipe
from .fedeval import FedEvalRecipe
from .fedopt import FedOptRecipe
from .scaffold import ScaffoldRecipe


# Lazy imports for recipes with optional dependencies or to avoid circular imports
def __getattr__(name):
    if name == "FedAvgRecipeWithHE":
        from .fedavg_he import FedAvgRecipeWithHE

        return FedAvgRecipeWithHE
    if name == "SwarmLearningRecipe":
        from .swarm import SwarmLearningRecipe

        return SwarmLearningRecipe
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "FedAvgRecipe",
    "CyclicRecipe",
    "FedOptRecipe",
    "ScaffoldRecipe",
    "FedAvgRecipeWithHE",
    "FedEvalRecipe",
    "SwarmLearningRecipe",
]
