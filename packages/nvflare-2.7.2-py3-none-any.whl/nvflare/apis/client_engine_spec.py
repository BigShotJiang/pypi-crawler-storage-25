# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from abc import ABC, abstractmethod

from .fl_context import FLContext


class ClientEngineSpec(ABC):
    @abstractmethod
    def fire_event(self, event_type: str, fl_ctx: FLContext):
        pass

    @abstractmethod
    def new_context(self) -> FLContext:
        # the engine must use FLContextManager to create a new context!
        pass

    @abstractmethod
    def add_component(self, component_id: str, component):
        """Add a component into the system.

        Args:
            component_id: component ID
            component: component object

        Returns:

        """
        pass

    @abstractmethod
    def get_component(self, component_id: str) -> object:
        """Retrieve the system component from the engine.

        Args:
            component_id: component ID

        Returns:
            component object

        """
        pass
