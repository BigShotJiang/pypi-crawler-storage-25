"""Agentic Earth Python SDK client."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Callable, Generator, Iterator

import httpx

from .config import get_api_key, get_base_url


class AgenticEarthError(Exception):
    pass


class AuthError(AgenticEarthError):
    pass


class InsufficientCreditsError(AgenticEarthError):
    pass


class StreamEvent:
    def __init__(self, data: dict):
        self.type        = data.get("type", "")
        self.tool        = data.get("tool")
        self.args        = data.get("args")
        self.result_key  = data.get("result_key")
        self.count       = data.get("count")
        self.answer      = data.get("answer")
        self.turns       = data.get("turns")
        self.message     = data.get("message")
        self.result_type = data.get("result_type")
        self.text        = data.get("text")   # text_delta chunks
        self._raw        = data


class QueryResult:
    """Returned by client.query() after the stream completes."""

    def __init__(self, answer: str, result_keys: list[str], client: "AgenticEarth"):
        self.answer      = answer
        self.result_keys = result_keys
        self._client     = client

    def __repr__(self) -> str:
        return f"<QueryResult answer={self.answer[:60]!r} result_keys={self.result_keys}>"

    def fetch(self, result_key: str | None = None, format: str = "geojson") -> Any:
        """Download a result as GeoDataFrame (requires geopandas) or raw dict."""
        key = result_key or (self.result_keys[0] if self.result_keys else None)
        if not key:
            raise AgenticEarthError("No result_key available.")
        return self._client.fetch_result(key, format=format)

    def preview(self, result_key: str | None = None, n: int = 5, browser: bool = False) -> None:
        """Preview a result in the terminal (table) or browser (interactive map).

        Args:
            result_key: Key to preview. Defaults to first result key.
            n:          Number of rows to show in table mode. Default 5.
            browser:    If True, opens an interactive Leaflet map in the browser.

        Example:
            result = ae.query("conflict events in Sudan")
            result.preview()              # table of first 5 rows
            result.preview(n=10)          # first 10 rows
            result.preview(browser=True)  # open map in browser
        """
        key = result_key or (self.result_keys[0] if self.result_keys else None)
        if not key:
            raise AgenticEarthError("No result_key available.")

        try:
            from rich.console import Console
            from rich.table import Table
            _rich = True
            _console = Console()
        except ImportError:
            _rich = False
            _console = None

        _GOLD = "#d4a843"
        _DIM  = "#5C4F3A"

        raw      = self._client.fetch_raw(key)
        geojson  = raw.get("geojson") or raw.get("data")
        plotly_j = raw.get("plotly") or (raw.get("data", {}) or {}).get("plotly")
        markets  = raw.get("markets")

        if plotly_j:
            import tempfile, webbrowser, json
            from pathlib import Path as _Path
            spec = json.dumps(plotly_j)
            html = (f'<!DOCTYPE html><html><head><script src="https://cdn.plot.ly/plotly-2.32.0.min.js"></script>'
                    f'<style>body{{margin:0;background:#0d0d1a}}#c{{width:100vw;height:100vh}}</style></head>'
                    f'<body><div id="c"></div><script>Plotly.newPlot("c",{spec}.data,{spec}.layout,{{responsive:true}})</script></body></html>')
            tmp = _Path(tempfile.mktemp(suffix=".html", prefix="ae_chart_"))
            tmp.write_text(html)
            webbrowser.open(tmp.as_uri())
            print(f"✓ Chart opened in browser")
            return

        if geojson and isinstance(geojson, dict) and "features" in geojson:
            features = geojson.get("features", [])
            total    = len(features)

            if browser:
                import tempfile, webbrowser, json
                from pathlib import Path as _Path
                geo_str = json.dumps(geojson)
                html = (f'<!DOCTYPE html><html><head><meta charset="utf-8">'
                        f'<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>'
                        f'<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>'
                        f'<style>body{{margin:0}}#map{{width:100vw;height:100vh}}</style></head><body>'
                        f'<div id="map"></div><script>'
                        f'const g={geo_str};const map=L.map("map");'
                        f'L.tileLayer("https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png").addTo(map);'
                        f'const l=L.geoJSON(g,{{style:()=>({{color:"#d4a843",weight:1.5,fillOpacity:0.25}}),'
                        f'pointToLayer:(f,ll)=>L.circleMarker(ll,{{radius:5,fillColor:"#d4a843",color:"#d4a843",fillOpacity:0.85}}),'
                        f'onEachFeature:(f,l)=>{{if(f.properties)l.bindPopup(Object.entries(f.properties).slice(0,10).map(([k,v])=>`<b>${{k}}</b>: ${{v}}`).join("<br>"))}}'
                        f'}}).addTo(map);try{{map.fitBounds(l.getBounds().pad(0.08))}}catch(e){{map.setView([20,0],2)}}'
                        f'</script></body></html>')
                tmp = _Path(tempfile.mktemp(suffix=".html", prefix="ae_preview_"))
                tmp.write_text(html)
                webbrowser.open(tmp.as_uri())
                print(f"✓ Map opened in browser  ({total:,} features)")
                return

            sample = features[:n]
            if not sample:
                print("No features.")
                return
            props_list = [f.get("properties") or {} for f in sample]
            cols = list(dict.fromkeys(k for p in props_list for k in p))[:12]

            if _rich and _console:
                tbl = Table(title=f"{key}  ({total:,} features, showing {len(sample)})",
                            title_style=f"bold {_GOLD}", border_style=_DIM, header_style=f"bold {_GOLD}")
                for col in cols:
                    tbl.add_column(col, max_width=28, no_wrap=True)
                for props in props_list:
                    tbl.add_row(*[str(props.get(c, ""))[:28] for c in cols])
                _console.print(tbl)
            else:
                print(f"\n{key}  ({total} features, showing {len(sample)})")
                print("  " + "  ".join(f"{c:<20}" for c in cols))
                for props in props_list:
                    print("  " + "  ".join(f"{str(props.get(c,'')):<20}" for c in cols))
            return

        if markets:
            sample = markets[:n]
            if _rich and _console:
                tbl = Table(title=f"{key}  ({len(markets)} markets)", title_style=f"bold {_GOLD}",
                            border_style=_DIM, header_style=f"bold {_GOLD}")
                tbl.add_column("Question", max_width=50, no_wrap=True)
                tbl.add_column("Yes %", max_width=8, justify="right")
                tbl.add_column("Vol 24h", max_width=12, justify="right")
                tbl.add_column("Ends", max_width=12)
                for m in sample:
                    yes_pct = f"{m.get('yes_price',0)*100:.0f}%" if m.get('yes_price') is not None else "—"
                    tbl.add_row(m.get("question","")[:50], yes_pct, f"${m.get('volume_24h_usd',0):,.0f}", m.get("end_date",""))
                _console.print(tbl)
            else:
                for m in sample:
                    print(f"  {m.get('question','')[:60]}  yes={m.get('yes_price')}  ends={m.get('end_date')}")
            return

        print(f"No previewable data found for '{key}'.")

    def save(self, path: str, result_key: str | None = None) -> Path:
        """Save result to file. Format inferred from extension (.geojson, .csv, .parquet)."""
        p = Path(path)
        ext = p.suffix.lstrip(".") or "geojson"
        key = result_key or (self.result_keys[0] if self.result_keys else None)
        if not key:
            raise AgenticEarthError("No result_key available.")
        return self._client.save_result(key, path=p, format=ext)


class AgenticEarth:
    """Agentic Earth SDK client.

    Usage:
        import agenticearth as ae
        result = ae.query("conflict events in Sudan last 30 days")
        result.save("sudan.geojson")
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 120.0,
    ):
        self.api_key  = api_key or get_api_key()
        self.base_url = (base_url or get_base_url()).rstrip("/")
        self.timeout  = timeout

        if not self.api_key:
            raise AuthError(
                "No API key found. Run `ae login` or set AE_API_KEY environment variable."
            )

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _get_user_id(self) -> str:
        """Resolve and cache user_id from the current API key."""
        if not hasattr(self, "_user_id_cache"):
            with httpx.Client(timeout=10) as client:
                resp = client.get(f"{self.base_url}/auth/whoami", headers=self._headers())
                resp.raise_for_status()
            self._user_id_cache: str = resp.json()["user_id"]
        return self._user_id_cache

    def _stream_agent(
        self,
        prompt: str,
        history: list[dict] | None = None,
        on_event: Callable[[StreamEvent], None] | None = None,
        user_id: str = "",
    ) -> Generator[StreamEvent, None, None]:
        """Stream agent events from /agent/stream."""
        payload = {
            "query":      prompt,
            "user_id":    user_id,
            "zeus_model": "ZeusStandard",
            "history":    history or [],
            "max_turns":  10,
            "mode":       "sdk",
        }
        with httpx.Client(timeout=self.timeout) as client:
            with client.stream(
                "POST",
                f"{self.base_url}/agent/stream",
                headers=self._headers(),
                json=payload,
            ) as resp:
                if resp.status_code == 401:
                    raise AuthError("Invalid API key.")
                if resp.status_code != 200:
                    raise AgenticEarthError(f"Stream failed: {resp.status_code} {resp.text}")

                buffer = ""
                for chunk in resp.iter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        block, buffer = buffer.split("\n\n", 1)
                        for line in block.splitlines():
                            if line.startswith("data: "):
                                raw = line[6:]
                                try:
                                    event = StreamEvent(json.loads(raw))
                                    if event.type == "error" and event.message == "insufficient_credits":
                                        raise InsufficientCreditsError("Insufficient credits.")
                                    if event.type == "error" and event.message == "plan_required":
                                        raise InsufficientCreditsError("API access requires a Pro plan or above. Upgrade at agenticearth.app.")
                                    if on_event:
                                        on_event(event)
                                    yield event
                                except (json.JSONDecodeError, InsufficientCreditsError):
                                    raise
                                except Exception:
                                    pass

    def query(
        self,
        prompt: str,
        history: list[dict] | None = None,
        on_event: Callable[[StreamEvent], None] | None = None,
    ) -> QueryResult:
        """Run an agent query. Returns QueryResult with answer + result_keys.

        Example:
            result = ae.query("conflict events in Sudan last 30 days")
            result.save("sudan.geojson")
        """
        answer = ""
        result_keys: list[str] = []

        for event in self._stream_agent(prompt, history=history, on_event=on_event):
            if event.type == "tool_done" and event.result_key:
                result_keys.append(event.result_key)
            elif event.type == "done":
                answer = event.answer or ""

        return QueryResult(answer=answer, result_keys=result_keys, client=self)

    def fetch_raw(self, result_key: str) -> dict:
        """Fetch the raw stored result dict (no post-processing)."""
        url = f"{self.base_url}/agent/results/{result_key}"
        with httpx.Client(timeout=60) as client:
            resp = client.get(url, headers=self._headers(), params={"geometry": "true"})
            resp.raise_for_status()
        return resp.json()

    def fetch_result(self, result_key: str, format: str = "geojson") -> Any:
        """Fetch a stored result by key. Returns GeoDataFrame if geopandas available, else dict."""
        url = f"{self.base_url}/agent/results/{result_key}"
        params: dict = {"geometry": "true"}
        if format == "parquet":
            params["format"] = "parquet"

        with httpx.Client(timeout=60) as client:
            resp = client.get(url, headers=self._headers(), params=params)
            resp.raise_for_status()

        if format == "parquet":
            try:
                import geopandas as gpd
                import io
                return gpd.read_parquet(io.BytesIO(resp.content))
            except ImportError:
                raise AgenticEarthError("Install geopandas to use format='parquet': pip install agenticearth[geo]")

        data = resp.json()
        geojson = data.get("geojson") or data.get("data")

        if geojson and isinstance(geojson, dict) and "features" in geojson:
            try:
                import geopandas as gpd
                return gpd.GeoDataFrame.from_features(geojson["features"], crs="EPSG:4326")
            except ImportError:
                return geojson

        return data

    def save_result(self, result_key: str, path: Path, format: str = "geojson") -> Path:
        """Download result and write to file."""
        if format in ("geojson", "json"):
            url = f"{self.base_url}/agent/results/{result_key}"
            with httpx.Client(timeout=60) as client:
                resp = client.get(url, headers=self._headers(), params={"geometry": "true"})
                resp.raise_for_status()
            data = resp.json()
            geojson = data.get("geojson") or data.get("data")
            path.write_text(json.dumps(geojson, indent=2))
        elif format == "csv":
            url = f"{self.base_url}/agent/results/{result_key}"
            with httpx.Client(timeout=60) as client:
                resp = client.get(url, headers=self._headers(), params={"geometry": "false"})
                resp.raise_for_status()
            data = resp.json()
            geojson = data.get("geojson") or data.get("data")
            if geojson and "features" in geojson:
                import csv, io
                rows = [f.get("properties", {}) for f in geojson["features"]]
                if rows:
                    out = io.StringIO()
                    w = csv.DictWriter(out, fieldnames=list(rows[0].keys()))
                    w.writeheader()
                    w.writerows(rows)
                    path.write_text(out.getvalue())
        elif format == "parquet":
            url = f"{self.base_url}/agent/results/{result_key}"
            with httpx.Client(timeout=60) as client:
                resp = client.get(url, headers=self._headers(), params={"format": "parquet"})
                resp.raise_for_status()
            path.write_bytes(resp.content)
        else:
            raise AgenticEarthError(f"Unknown format: {format}. Use geojson, csv, or parquet.")

        return path

    def balance(self) -> dict:
        """Return current credit balance and tier."""
        user_id = self._get_user_id()
        with httpx.Client(timeout=30) as client:
            resp = client.get(
                f"{self.base_url}/usage/balance",
                headers=self._headers(),
                params={"user_id": user_id},
            )
            resp.raise_for_status()
        return resp.json()

    def datasets(self) -> list:
        """List uploaded ZeusLM datasets for the current user."""
        user_id = self._get_user_id()
        with httpx.Client(timeout=30) as client:
            resp = client.get(
                f"{self.base_url}/zeusLM/datasets",
                headers=self._headers(),
                params={"user_id": user_id},
            )
            resp.raise_for_status()
        return resp.json()

    def upload(self, file_path: str | Path, filename: str | None = None) -> dict:
        """Upload a file to ZeusLM. Returns dataset metadata dict."""
        p = Path(file_path)
        if not p.exists():
            raise AgenticEarthError(f"File not found: {p}")
        name = filename or p.name
        headers = {k: v for k, v in self._headers().items() if k != "Content-Type"}
        with httpx.Client(timeout=120) as client:
            with open(p, "rb") as f:
                resp = client.post(
                    f"{self.base_url}/zeusLM/upload",
                    headers=headers,
                    files={"file": (name, f)},
                    data={"user_id": ""},
                )
            resp.raise_for_status()
        return resp.json()
