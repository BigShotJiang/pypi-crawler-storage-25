"""Agentic Earth CLI — ae ask / ae chat / ae resume / ae upload / ae login."""
from __future__ import annotations

import json
import secrets
import sys
from datetime import datetime, timezone
from pathlib import Path

import click

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich import print as rprint
    _rich = True
except ImportError:
    _rich = False

_MAX_WIDTH = 100
console = Console(width=min((Console().width or _MAX_WIDTH), _MAX_WIDTH)) if _rich else None

_SESSIONS_DIR  = Path.home() / ".agenticearth" / "sessions"
_LAST_SESSION  = _SESSIONS_DIR / ".last"

_GOLD  = "#d4a843"
_MUTED = "#8A7455"
_DIM   = "#5C4F3A"

# ── Helpers ───────────────────────────────────────────────────────────────────

def _print_banner() -> None:
    if not _rich or not console:
        print("\n  Agentic Earth  —  150+ live geospatial datasets\n")
        return
    from rich.text import Text
    gold     = _GOLD
    base_col = _DIM
    peak_pad  = 12
    num_rows  = 10
    globe_row = 6
    console.print()
    for i in range(num_rows - 1):
        inner = i * 2
        t = Text(" " * (peak_pad - i))
        t.append("╱", style=f"bold {gold}")
        if i == globe_row:
            side = (inner - 2) // 2
            t.append(" " * side + "🌍" + " " * side)
        else:
            t.append(" " * inner)
        t.append("╲", style=f"bold {gold}")
        console.print(t)
    # base
    t = Text(" " * (peak_pad - num_rows + 1))
    t.append("╱", style=f"bold {gold}")
    t.append("─" * ((num_rows - 1) * 2), style=base_col)
    t.append("╲", style=f"bold {gold}")
    console.print(t)
    console.print()
    console.print(Text.from_markup(f"  [bold {gold}]A G E N T I C   E A R T H[/bold {gold}]"))
    console.print(Text.from_markup(f"  [{base_col}]150+ live datasets · clustering · hotspots · SQL · natural language[/{base_col}]"))
    console.print()


def _print(msg: str, style: str = "") -> None:
    if _rich and console:
        console.print(msg, style=style)
    else:
        print(msg)


def _print_tool_event(event) -> None:
    """Print thinking / tool_start / tool_done events. Text delta handled separately."""
    if event.type == "thinking":
        _print(f"  [dim]● thinking…[/dim]" if _rich else "  ● thinking…")
    elif event.type == "tool_start":
        args_str = json.dumps(event.args or {})
        if len(args_str) > 80:
            args_str = args_str[:80] + "…"
        _print(f"  [cyan]▶ {event.tool}[/cyan]  [dim]{args_str}[/dim]" if _rich
               else f"  ▶ {event.tool}  {args_str}")
    elif event.type == "tool_done":
        count = f" ({event.count} features)" if event.count else ""
        key   = f"  key={event.result_key}" if event.result_key else ""
        _print(f"  [green]✓ {event.tool}{count}[/green][dim]{key}[/dim]" if _rich
               else f"  ✓ {event.tool}{count}{key}")


def _render_md(text: str) -> str:
    """Convert Markdown to clean ANSI output — no box chars, no heavy rules."""
    import re, shutil

    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    ITALIC = "\033[3m"
    CODE   = "\033[38;5;222m"   # warm gold for inline code

    def strip_ansi(s: str) -> str:
        return re.sub(r'\033\[[0-9;]*m', '', s)

    def inline(s: str) -> str:
        s = re.sub(r'\*\*\*(.+?)\*\*\*', lambda m: BOLD + ITALIC + m.group(1) + RESET, s)
        s = re.sub(r'\*\*(.+?)\*\*',     lambda m: BOLD  + m.group(1) + RESET, s)
        s = re.sub(r'\*([^*\n]+?)\*',    lambda m: ITALIC + m.group(1) + RESET, s)
        s = re.sub(r'`([^`\n]+?)`',      lambda m: CODE  + m.group(1) + RESET, s)
        return s

    out: list[str] = []
    src = text.split("\n")
    i = 0
    while i < len(src):
        raw = src[i]
        stripped = raw.strip()

        # Fenced code block
        if stripped.startswith("```"):
            i += 1
            block: list[str] = []
            while i < len(src) and not src[i].strip().startswith("```"):
                block.append(src[i])
                i += 1
            if block:
                out.append("")
                for bl in block:
                    out.append(DIM + "  " + bl + RESET)
                out.append("")
            i += 1
            continue

        # Horizontal rule — drop silently
        if re.match(r'^[-_*]{3,}\s*$', stripped):
            i += 1
            continue

        # Header
        m = re.match(r'^(#{1,6})\s+(.*)', raw)
        if m:
            out.append("")
            out.append(BOLD + inline(m.group(2).strip()) + RESET)
            i += 1
            continue

        # Markdown table
        if stripped.startswith("|") and stripped.endswith("|"):
            rows: list[list[str]] = []
            while i < len(src) and src[i].strip().startswith("|"):
                tl = src[i].strip()
                if not re.match(r'^\|[-| :]+\|$', tl):
                    rows.append([c.strip() for c in tl.strip("|").split("|")])
                i += 1
            if rows:
                n_cols = max(len(r) for r in rows)
                col_w = [0] * n_cols
                for row in rows:
                    for ci, cell in enumerate(row[:n_cols]):
                        col_w[ci] = max(col_w[ci], len(strip_ansi(inline(cell))))
                out.append("")
                for ri, row in enumerate(rows):
                    parts: list[str] = []
                    for ci in range(n_cols):
                        cell = row[ci] if ci < len(row) else ""
                        fmt  = (BOLD + inline(cell) + RESET) if ri == 0 else inline(cell)
                        pad  = col_w[ci] - len(strip_ansi(inline(cell)))
                        parts.append(fmt + " " * pad)
                    out.append("  " + "  ".join(parts))
                out.append("")
            continue

        # Bullet / numbered list
        m = re.match(r'^(\s*)([-*+]|\d+\.)\s+(.*)', raw)
        if m:
            marker = "•" if m.group(2) in ("-", "*", "+") else m.group(2)
            out.append(f"{m.group(1)}{marker} {inline(m.group(3))}")
            i += 1
            continue

        # Blockquote
        if stripped.startswith(">"):
            out.append(DIM + "│ " + inline(stripped.lstrip("> ").strip()) + RESET)
            i += 1
            continue

        # Blank line
        if not stripped:
            out.append("")
            i += 1
            continue

        # Regular text
        out.append(inline(raw))
        i += 1

    return "\n".join(out)


def _live_query(client, prompt: str, history: list | None = None, on_result_key=None):
    """Stream tool events and text live; erase raw stream and re-render clean."""
    import sys
    from .client import InsufficientCreditsError

    text_buffer: list[str] = []
    stream_started = [False]

    def on_event(event):
        if event.type == "text_delta" and event.text:
            if not stream_started[0]:
                sys.stdout.write("\n")
                sys.stdout.flush()
                stream_started[0] = True
            text_buffer.append(event.text)
            sys.stdout.write(event.text)
            sys.stdout.flush()
        else:
            _print_tool_event(event)
            if on_result_key and event.type == "tool_done" and event.result_key:
                on_result_key(event.result_key)

    result = client.query(prompt, history=history, on_event=on_event)

    full_text = "".join(text_buffer) or result.answer or ""
    if not full_text:
        return result

    def _erase_and_render(text: str) -> None:
        import shutil
        term_w = shutil.get_terminal_size((100, 40)).columns
        lines = 0
        for line in text.split("\n"):
            lines += max(1, (len(line) + term_w - 1) // term_w) if line else 1
        sys.stdout.write(f"\033[{lines}A\033[J")
        sys.stdout.flush()
        rendered = _render_md(text)
        sys.stdout.write("\n" + rendered + "\n\n")
        sys.stdout.flush()

    if stream_started[0]:
        _erase_and_render(full_text)
    else:
        sys.stdout.write("\n" + _render_md(full_text) + "\n\n")
        sys.stdout.flush()

    return result


def _plotly_html(plotly_json: dict) -> str:
    """Wrap a Plotly JSON spec in a minimal self-contained HTML page."""
    import json as _json
    spec = _json.dumps(plotly_json)
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Agentic Earth Chart</title>
<script src="https://cdn.plot.ly/plotly-2.32.0.min.js"></script>
<style>body{{margin:0;background:#0d0d1a}}#chart{{width:100vw;height:100vh}}</style>
</head>
<body>
<div id="chart"></div>
<script>Plotly.newPlot('chart',{spec}.data,{spec}.layout,{{responsive:true,displayModeBar:true}})</script>
</body>
</html>"""


def _leaflet_html(geojson: dict, title: str = "Agentic Earth Preview") -> str:
    """Generate a self-contained Leaflet map HTML page for a GeoJSON result."""
    import json as _json
    geo_str = _json.dumps(geojson)
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{title}</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  body{{margin:0;background:#080810;font-family:sans-serif}}
  #map{{width:100vw;height:100vh}}
  #info{{position:absolute;top:12px;left:50%;transform:translateX(-50%);z-index:1000;
         background:rgba(8,8,16,0.85);border:1px solid #d4a843;border-radius:8px;
         padding:6px 16px;color:#d4a843;font-size:13px;font-weight:600;pointer-events:none}}
</style>
</head>
<body>
<div id="info">{title}</div>
<div id="map"></div>
<script>
  const geojson = {geo_str};
  const map = L.map('map', {{zoomControl:true}});
  L.tileLayer('https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png', {{
    attribution: '© OpenStreetMap © Carto', maxZoom: 19
  }}).addTo(map);
  const gold = '#d4a843';
  const layer = L.geoJSON(geojson, {{
    style: () => ({{ color: gold, weight: 1.5, fillColor: gold, fillOpacity: 0.25 }}),
    pointToLayer: (f, ll) => L.circleMarker(ll, {{
      radius: 5, fillColor: gold, color: gold, weight: 1, fillOpacity: 0.85
    }}),
    onEachFeature: (f, l) => {{
      if (f.properties && Object.keys(f.properties).length) {{
        const rows = Object.entries(f.properties)
          .filter(([k,v]) => v != null)
          .slice(0, 12)
          .map(([k,v]) => `<tr><td style="color:#8a8070;padding-right:8px">${{k}}</td><td style="color:#fff">${{v}}</td></tr>`)
          .join('');
        l.bindPopup(`<table style="font-size:12px;font-family:monospace;background:#0d0d1a;color:#fff">${{rows}}</table>`,
          {{maxWidth:340}});
      }}
    }}
  }}).addTo(map);
  try {{ map.fitBounds(layer.getBounds().pad(0.08)); }} catch(e) {{ map.setView([20,0],2); }}
</script>
</body>
</html>"""


def _preview_result(client, result_key: str, rows: int = 5, browser: bool = False) -> None:
    """Fetch a result and render it as a table (default) or browser map (--map)."""
    try:
        raw = client.fetch_raw(result_key)
    except Exception as exc:
        _print(f"[red]✗ Could not fetch '{result_key}': {exc}[/red]" if _rich else f"✗ {exc}")
        return

    geojson     = raw.get("geojson") or raw.get("data")
    plotly_json = raw.get("plotly") or (raw.get("data", {}) or {}).get("plotly")
    markets     = raw.get("markets")
    text_result = raw.get("text") or raw.get("answer")

    # ── Chart ────────────────────────────────────────────────────────────────
    if plotly_json:
        import tempfile, webbrowser
        html = _plotly_html(plotly_json)
        tmp = Path(tempfile.mktemp(suffix=".html", prefix="ae_chart_"))
        tmp.write_text(html)
        webbrowser.open(tmp.as_uri())
        _print(f"[green]✓ Chart opened in browser[/green]  [dim]{tmp}[/dim]" if _rich
               else f"✓ Chart opened in browser  {tmp}")
        return

    # ── GeoJSON / vector ─────────────────────────────────────────────────────
    if geojson and isinstance(geojson, dict) and "features" in geojson:
        features = geojson.get("features", [])
        total    = len(features)

        if browser:
            import tempfile, webbrowser
            html = _leaflet_html(geojson, title=f"ae preview · {result_key} · {total:,} features")
            tmp  = Path(tempfile.mktemp(suffix=".html", prefix="ae_preview_"))
            tmp.write_text(html)
            webbrowser.open(tmp.as_uri())
            _print(f"[green]✓ Map opened in browser[/green]  [dim]{total:,} features · {tmp}[/dim]"
                   if _rich else f"✓ Map opened in browser  {total} features  {tmp}")
            return

        # Table preview
        sample = features[:rows]
        if not sample:
            _print("[dim]No features.[/dim]" if _rich else "No features.")
            return

        props_list = [f.get("properties") or {} for f in sample]
        cols = list(dict.fromkeys(k for p in props_list for k in p))[:8]

        if _rich and console:
            from rich.table import Table as RTable
            term_w   = console.width or 100
            col_w    = max(12, (term_w - 6) // max(len(cols), 1) - 3)
            table = RTable(
                title=f"{result_key}  ({total:,} features, showing {len(sample)})",
                title_style=f"bold {_GOLD}",
                border_style=_DIM,
                header_style=f"bold {_GOLD}",
                show_lines=False,
            )
            for col in cols:
                table.add_column(col, max_width=col_w, no_wrap=True)
            for props in props_list:
                table.add_row(*[str(props.get(c, ""))[:col_w] for c in cols])
            console.print()
            console.print(table)
            console.print(
                f"  [dim]Tip: /preview {result_key} --map  to open in browser[/dim]\n"
            )
        else:
            print(f"\n{result_key}  ({total} features, showing {len(sample)})")
            print("  " + "  ".join(f"{c:<20}" for c in cols))
            for props in props_list:
                print("  " + "  ".join(f"{str(props.get(c,'')):<20}" for c in cols))
        return

    # ── Polymarket / tabular list ─────────────────────────────────────────────
    if markets:
        sample = markets[:rows]
        if _rich and console:
            from rich.table import Table as RTable
            table = RTable(
                title=f"{result_key}  ({len(markets)} markets, showing {len(sample)})",
                title_style=f"bold {_GOLD}", border_style=_DIM, header_style=f"bold {_GOLD}",
            )
            table.add_column("Question",  max_width=50, no_wrap=True)
            table.add_column("Yes %",     max_width=8,  justify="right")
            table.add_column("Vol 24h",   max_width=12, justify="right")
            table.add_column("Ends",      max_width=12)
            for m in sample:
                yes_pct = f"{m.get('yes_price',0)*100:.0f}%" if m.get('yes_price') is not None else "—"
                vol     = f"${m.get('volume_24h_usd',0):,.0f}"
                table.add_row(m.get("question","")[:50], yes_pct, vol, m.get("end_date",""))
            console.print()
            console.print(table)
        else:
            for m in sample:
                print(f"  {m.get('question','')[:60]}  yes={m.get('yes_price')}  ends={m.get('end_date')}")
        return

    # ── Text / fallback ───────────────────────────────────────────────────────
    if text_result:
        _print(str(text_result)[:500])
        return

    _print(f"[yellow]No previewable data found for '{result_key}'.[/yellow]" if _rich
           else f"No previewable data for '{result_key}'.")


def _save_session(session_id: str, history: list[dict]) -> None:
    _SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    path = _SESSIONS_DIR / f"{session_id}.json"
    path.write_text(json.dumps({
        "id": session_id,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "history": history,
    }, indent=2))
    _LAST_SESSION.write_text(session_id)


def _load_session(session_id: str | None) -> tuple[str, list[dict]]:
    if not session_id:
        if _LAST_SESSION.exists():
            session_id = _LAST_SESSION.read_text().strip()
        else:
            raise click.ClickException("No previous session found. Start one with `ae chat`.")
    path = _SESSIONS_DIR / f"{session_id}.json"
    if not path.exists():
        raise click.ClickException(f"Session '{session_id}' not found.")
    data = json.loads(path.read_text())
    return session_id, data["history"]


_SLASH_COMMANDS = [
    ("/preview",  "<key>         preview result as table"),
    ("/preview",  "<key> --map   open result as map in browser"),
    ("/save",     "<file>        export result (.geojson .csv .parquet)"),
    ("/upload",   "<file>        upload a file mid-session"),
    ("/credits",  "              show credit balance"),
    ("/datasets", "              list uploaded datasets"),
    ("/sessions", "              list saved sessions"),
    ("/history",  "              show conversation history"),
    ("/clear",    "              reset conversation"),
    ("/exit",     "              end session"),
]


def _print_command_panel(session_id: str) -> None:
    if not _rich or not console:
        print(f"\nAgentic Earth  {session_id}\n")
        return
    from rich.text import Text as RText

    cmds = "  ".join(f"[{_GOLD}]{cmd}[/{_GOLD}]" for cmd, _ in dict.fromkeys(
        (cmd, None) for cmd, _ in _SLASH_COMMANDS
    ))

    console.print()
    console.print(RText.from_markup(
        f"  [bold {_GOLD}]Agentic Earth[/bold {_GOLD}]  [dim]{session_id}[/dim]"
    ))
    console.print(RText.from_markup(f"  {cmds}"))
    console.print(RText.from_markup(f"  [dim]Press Tab after / for command hints[/dim]"))
    console.print()


def _make_prompt_session(last_result_keys_ref: list):
    """Build a prompt_toolkit PromptSession with slash-command autocomplete."""
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.styles import Style
        from prompt_toolkit.history import InMemoryHistory

        class SlashCompleter(Completer):
            def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                if not text.startswith("/"):
                    return
                word = text.split()[0] if text.split() else "/"
                seen = set()
                for cmd, desc in _SLASH_COMMANDS:
                    if cmd not in seen and cmd.startswith(word):
                        seen.add(cmd)
                        # for /preview, also suggest last result key
                        if cmd == "/preview" and last_result_keys_ref:
                            display = f"{cmd} {last_result_keys_ref[0]}  —  {desc.strip()}"
                            yield Completion(
                                f"{cmd} {last_result_keys_ref[0]}",
                                start_position=-len(text),
                                display=display,
                            )
                        else:
                            yield Completion(
                                cmd,
                                start_position=-len(word),
                                display=f"{cmd}  —  {desc.strip()}",
                            )

        style = Style.from_dict({
            "prompt":           f"{_GOLD} bold",
            "completion-menu.completion":          "bg:#1a1a2e #888",
            "completion-menu.completion.current":  f"bg:#1a1a2e {_GOLD} bold",
            "completion-menu.meta.completion":     "bg:#1a1a2e #555",
            "scrollbar.background": "bg:#1a1a2e",
            "scrollbar.button":     f"bg:{_GOLD}",
        })

        return PromptSession(
            completer=SlashCompleter(),
            complete_while_typing=True,
            history=InMemoryHistory(),
            style=style,
        )
    except ImportError:
        return None


def _run_chat_loop(client, history: list[dict], session_id: str) -> None:
    """Core interactive loop shared by `ae chat` and `ae resume`."""
    from .client import InsufficientCreditsError

    last_result_keys: list[str] = []
    _print_command_panel(session_id)

    pt_session = _make_prompt_session(last_result_keys)

    def _get_input() -> str:
        if pt_session:
            try:
                return pt_session.prompt("  > ").strip()
            except (EOFError, KeyboardInterrupt):
                raise KeyboardInterrupt
        return input("  > ").strip()

    while True:
        try:
            user_input = _get_input()
        except (EOFError, KeyboardInterrupt):
            _print("\n")
            break

        if not user_input:
            continue

        # ── In-session slash commands ────────────────────────────────────────
        if user_input.startswith("/"):
            parts = user_input.split(None, 1)
            cmd = parts[0].lower()
            arg = parts[1].strip() if len(parts) > 1 else ""

            if cmd in ("/exit", "/quit", "/q"):
                break

            elif cmd == "/clear":
                history.clear()
                last_result_keys.clear()
                _print("[dim]Conversation cleared.[/dim]" if _rich else "Conversation cleared.")

            elif cmd == "/history":
                if not history:
                    _print("[dim]No history yet.[/dim]" if _rich else "No history yet.")
                for msg in history:
                    role = "You" if msg["role"] == "user" else " AE"
                    preview = msg["content"][:100].replace("\n", " ")
                    _print(f"[dim]{role}:[/dim] {preview}…" if _rich else f"{role}: {preview}…")

            elif cmd == "/save":
                if not arg:
                    _print("[yellow]Usage: /save <filename.geojson|.csv|.parquet>[/yellow]" if _rich
                           else "Usage: /save <filename>")
                elif not last_result_keys:
                    _print("[yellow]No result available to save yet.[/yellow]" if _rich
                           else "No result available yet.")
                else:
                    ext = Path(arg).suffix.lstrip(".") or "geojson"
                    try:
                        saved = client.save_result(last_result_keys[0], Path(arg), format=ext)
                        _print(f"[green]✓ Saved → {saved}[/green]" if _rich else f"✓ Saved → {saved}")
                    except Exception as exc:
                        _print(f"[red]✗ Save failed: {exc}[/red]" if _rich else f"✗ Save failed: {exc}")

            elif cmd == "/upload":
                if not arg:
                    _print("[yellow]Usage: /upload <filepath>[/yellow]" if _rich
                           else "Usage: /upload <filepath>")
                else:
                    p = Path(arg)
                    if not p.exists():
                        _print(f"[red]File not found: {p}[/red]" if _rich else f"File not found: {p}")
                    else:
                        _print(f"  [cyan]↑ Uploading {p.name}…[/cyan]" if _rich else f"  ↑ Uploading {p.name}…")
                        try:
                            meta = client.upload(str(p))
                            dk = meta.get("dataset_key", "?")
                            _print(f"  [green]✓ Uploaded[/green]  [dim]dataset_key={dk}[/dim]" if _rich
                                   else f"  ✓ Uploaded  dataset_key={dk}")
                            history.append({"role": "user",      "content": f"I have uploaded a dataset with key '{dk}'."})
                            history.append({"role": "assistant", "content": f"Got it — dataset key `{dk}` is loaded and ready. What would you like to do with it?"})
                            _save_session(session_id, history)
                        except Exception as exc:
                            _print(f"[red]✗ Upload failed: {exc}[/red]" if _rich else f"✗ Upload failed: {exc}")

            elif cmd == "/credits":
                try:
                    b = client.balance()
                    tier      = b.get("tier", "?")
                    remaining = b.get("credits_remaining", "?")
                    monthly   = b.get("credits_monthly", "?")
                    used      = b.get("credits_used", "?")
                    pct       = int(remaining / monthly * 100) if monthly else 0
                    bar_fill  = int(pct / 5)
                    bar       = "█" * bar_fill + "░" * (20 - bar_fill)
                    _print(
                        f"\n  Tier:    [bold]{tier}[/bold]\n"
                        f"  Credits: [green]{remaining:,}[/green] / {monthly:,}  [{pct}%]\n"
                        f"  [{bar}]\n"
                        f"  Used:    {used:,} this cycle\n"
                        if _rich else
                        f"\n  Tier: {tier}  Credits: {remaining}/{monthly} ({pct}%)  Used: {used}\n"
                    )
                except Exception as exc:
                    _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")

            elif cmd == "/datasets":
                try:
                    items = client.datasets()
                    if not items:
                        _print("[dim]No datasets. Use /upload <file> to add one.[/dim]" if _rich
                               else "No datasets. Use /upload <file> to add one.")
                    else:
                        _print(f"\n  [dim]{'DATASET KEY':<18} {'FILE':<30} ROWS[/dim]" if _rich
                               else f"\n  {'DATASET KEY':<18} {'FILE':<30} ROWS")
                        for d in items:
                            key  = d.get("dataset_key", "?")[:18]
                            name = (d.get("filename") or d.get("name") or "?")[:30]
                            rows = d.get("row_count", "?")
                            _print(f"  [cyan]{key:<18}[/cyan]  {name:<30}  {rows}" if _rich
                                   else f"  {key:<18}  {name:<30}  {rows}")
                        _print("")
                except Exception as exc:
                    _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")

            elif cmd == "/preview":
                use_map = "--map" in arg
                key_arg = arg.replace("--map", "").strip()
                if not key_arg:
                    key_arg = last_result_keys[0] if last_result_keys else ""
                if not key_arg:
                    _print("[yellow]Usage: /preview <result_key>  or  /preview <key> --map[/yellow]"
                           if _rich else "Usage: /preview <result_key>  or  /preview <key> --map")
                else:
                    _preview_result(client, key_arg, rows=5, browser=use_map)

            elif cmd == "/view":
                if not arg:
                    keys_hint = last_result_keys[0] if last_result_keys else "<result_key>"
                    _print(f"[yellow]Usage: /view {keys_hint}[/yellow]" if _rich
                           else f"Usage: /view <result_key>")
                else:
                    try:
                        raw = client.fetch_raw(arg)
                        plotly_json = raw.get("plotly") or (raw.get("data", {}) or {}).get("plotly")
                        if plotly_json:
                            import tempfile, webbrowser
                            html = _plotly_html(plotly_json)
                            tmp = Path(tempfile.mktemp(suffix=".html", prefix="ae_chart_"))
                            tmp.write_text(html)
                            webbrowser.open(tmp.as_uri())
                            _print(f"[green]✓ Chart opened in browser[/green]  [dim]{tmp}[/dim]" if _rich
                                   else f"✓ Chart opened in browser  {tmp}")
                        else:
                            _print("[yellow]Not a chart result. Use /save <file.geojson> instead.[/yellow]" if _rich
                                   else "Not a chart result. Use /save <file.geojson> instead.")
                    except Exception as exc:
                        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")

            elif cmd == "/sessions":
                if not _SESSIONS_DIR.exists():
                    _print("[dim]No saved sessions.[/dim]" if _rich else "No saved sessions.")
                else:
                    files = sorted(_SESSIONS_DIR.glob("ae_sess_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
                    if not files:
                        _print("[dim]No saved sessions.[/dim]" if _rich else "No saved sessions.")
                    else:
                        _print(f"\n  [dim]{'SESSION ID':<22} {'UPDATED':<22} TURNS[/dim]" if _rich
                               else f"\n  {'SESSION ID':<22} {'UPDATED':<22} TURNS")
                        for p in files[:10]:
                            try:
                                import json as _json
                                data    = _json.loads(p.read_text())
                                sid     = data.get("id", p.stem)
                                turns   = len(data.get("history", [])) // 2
                                updated = data.get("updated_at", "")[:16].replace("T", " ")
                                marker  = " ← current" if sid == session_id else ""
                                _print(f"  [cyan]{sid}[/cyan]  [dim]{updated}[/dim]  {turns} turns[green]{marker}[/green]"
                                       if _rich else f"  {sid}  {updated}  {turns} turns{marker}")
                            except Exception:
                                pass
                        _print("")

            else:
                _print(f"[yellow]Unknown command '{cmd}'. Try /preview, /view, /save, /upload, /credits, /datasets, /sessions, /clear, /history, /exit.[/yellow]"
                       if _rich else f"Unknown command: {cmd}")
            continue

        # ── Agent turn ────────────────────────────────────────────────────────
        if _rich and console:
            from rich.text import Text as RText
            console.print(RText.from_markup(f"\n  [bold {_GOLD}]you[/bold {_GOLD}]  [dim]{user_input}[/dim]"))
        turn_result_keys: list[str] = []

        try:
            result = _live_query(
                client, user_input, history=history,
                on_result_key=turn_result_keys.append,
            )
        except InsufficientCreditsError:
            _print("[red]✗ Insufficient credits. Visit agenticearth.io to upgrade.[/red]" if _rich
                   else "✗ Insufficient credits.")
            continue
        except Exception as exc:
            _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
            continue

        if result.result_keys:
            last_result_keys[:] = result.result_keys
            _print(f"\n[dim]Result keys: {', '.join(result.result_keys)}  · /save <file> to export[/dim]\n"
                   if _rich else f"\nResult keys: {', '.join(result.result_keys)}\n")

        history.append({"role": "user",      "content": user_input})
        history.append({"role": "assistant", "content": result.answer})
        _save_session(session_id, history)

    _save_session(session_id, history)
    turns = len(history) // 2
    _print(f"\n[dim]Session saved ({turns} turn{'s' if turns != 1 else ''}). "
           f"Resume with: ae resume {session_id}[/dim]"
           if _rich else
           f"\nSession saved ({turns} turns). Resume with: ae resume {session_id}")


# ── Commands ──────────────────────────────────────────────────────────────────

@click.group()
@click.version_option(package_name="agenticearth")
def main():
    """Agentic Earth CLI — 150+ live geospatial datasets via natural language.\n\nGet started: ae login"""
    pass


@main.command()
@click.option("--key", prompt="API key (from agenticearth.io/settings)", help="Your ae_sk_* API key.")
@click.option("--url", default=None, help="Custom API base URL (default: https://api.agenticearth.app).")
def login(key: str, url: str | None):
    """Save your API key to ~/.agenticearth/config.json."""
    from .config import save_credentials
    save_credentials(key.strip(), base_url=url)
    _print(f"[green]✓ Logged in. Key saved to ~/.agenticearth/config.json[/green]" if _rich
           else "✓ Logged in.")


@main.command()
def logout():
    """Clear saved credentials."""
    from .config import clear_credentials
    clear_credentials()
    _print("Credentials cleared.")


@main.command(name="ask")
@click.argument("prompt", nargs=-1, required=True)
@click.option("--output", "-o", default=None, help="Save result to file (e.g. result.geojson, result.csv, result.parquet).")
@click.option("--file", "-f", default=None, type=click.Path(exists=True), help="Upload a file and analyse it (CSV, GeoJSON, Parquet, Shapefile zip, TIFF).")
@click.option("--url", default=None, envvar="AE_BASE_URL", help="API base URL override.")
def ask(prompt: tuple, output: str | None, file: str | None, url: str | None):
    """Ask the agent a one-shot question and stream the response.

    \b
    Examples:
      ae ask "conflict events in Sudan last 30 days"
      ae ask "cluster WiFi APs in Belarus" --output clusters.geojson
      ae ask "NDBC buoys in Gulf of Mexico" -o buoys.csv
      ae ask "what is this file" --file my_data.csv
    """
    from .client import AgenticEarth, InsufficientCreditsError

    full_prompt = " ".join(prompt)
    try:
        client = AgenticEarth(base_url=url)
    except Exception as exc:
        _print(f"[red]Error: {exc}[/red]" if _rich else f"Error: {exc}")
        sys.exit(1)

    if file:
        _print(f"  [cyan]↑ Uploading {file}…[/cyan]" if _rich else f"  ↑ Uploading {file}…")
        try:
            meta = client.upload(file)
            dataset_key = meta.get("dataset_key")
            if not dataset_key:
                raise ValueError(f"Upload succeeded but no dataset_key returned: {meta}")
            _print(f"  [green]✓ Uploaded[/green]  [dim]dataset_key={dataset_key}[/dim]" if _rich
                   else f"  ✓ Uploaded  dataset_key={dataset_key}")
            full_prompt = f"I have uploaded a dataset with key '{dataset_key}'. {full_prompt}"
        except Exception as exc:
            _print(f"[red]✗ Upload failed: {exc}[/red]" if _rich else f"✗ Upload failed: {exc}")
            sys.exit(1)

    _print(f"\n[bold]Agentic Earth[/bold]  [dim]{' '.join(prompt)}[/dim]\n" if _rich
           else f"\nAgentic Earth: {' '.join(prompt)}\n")

    try:
        result = _live_query(client, full_prompt)
    except InsufficientCreditsError:
        _print("[red]✗ Insufficient credits. Visit agenticearth.io to upgrade.[/red]" if _rich
               else "✗ Insufficient credits.")
        sys.exit(1)
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)

    if output and result.result_keys:
        ext = Path(output).suffix.lstrip(".") or "geojson"
        try:
            saved = client.save_result(result.result_keys[0], Path(output), format=ext)
            _print(f"\n[green]✓ Saved → {saved}[/green]" if _rich else f"\n✓ Saved → {saved}")
        except Exception as exc:
            _print(f"[red]✗ Save failed: {exc}[/red]" if _rich else f"✗ Save failed: {exc}")
    elif result.result_keys:
        _print(f"\n[dim]Result keys: {', '.join(result.result_keys)}[/dim]" if _rich
               else f"\nResult keys: {', '.join(result.result_keys)}")
        _print("[dim]Use --output result.geojson to save.[/dim]" if _rich
               else "Use --output result.geojson to save.")


@main.command(name="chat")
@click.option("--url", default=None, envvar="AE_BASE_URL", help="API base URL override.")
def chat(url: str | None):
    """Start an interactive multi-turn session.

    \b
    In-session commands:
      /save <file>     export last result to geojson, csv, or parquet
      /upload <file>   upload a file mid-session
      /clear           reset conversation history
      /history         show conversation so far
      /exit            end session (also ctrl+c)

    Example:
      ae chat
      > NDBC buoys in Gulf of Mexico
      > now cluster them by wave height
      > /save clusters.geojson
    """
    from .client import AgenticEarth

    try:
        client = AgenticEarth(base_url=url)
    except Exception as exc:
        _print(f"[red]Error: {exc}[/red]" if _rich else f"Error: {exc}")
        sys.exit(1)

    _print_banner()
    session_id = "ae_sess_" + secrets.token_hex(4)
    _run_chat_loop(client, [], session_id)


@main.command(name="resume")
@click.argument("session_id", required=False, default=None)
@click.option("--url", default=None, envvar="AE_BASE_URL", help="API base URL override.")
def resume(session_id: str | None, url: str | None):
    """Resume a previous session.

    \b
    Examples:
      ae resume                    # resumes last session
      ae resume ae_sess_a1b2c3d4   # resumes specific session
    """
    from .client import AgenticEarth

    try:
        client = AgenticEarth(base_url=url)
    except Exception as exc:
        _print(f"[red]Error: {exc}[/red]" if _rich else f"Error: {exc}")
        sys.exit(1)

    try:
        sid, history = _load_session(session_id)
    except click.ClickException as exc:
        _print(f"[red]✗ {exc.format_message()}[/red]" if _rich else f"✗ {exc.format_message()}")
        sys.exit(1)

    _print_banner()
    turns = len(history) // 2
    _print(f"[dim]Resuming session {sid} ({turns} previous turn{'s' if turns != 1 else ''}).[/dim]"
           if _rich else f"Resuming session {sid} ({turns} previous turns).")
    _run_chat_loop(client, history, sid)


@main.command(name="view")
@click.argument("result_key")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def view_cmd(result_key: str, url: str | None):
    """Open a chart result in the browser, or print the raw result.

    \b
    Example:
      ae view create_chart_e8d1
    """
    from .client import AgenticEarth
    try:
        client = AgenticEarth(base_url=url)
        raw = client.fetch_raw(result_key)
        plotly_json = raw.get("plotly") or (raw.get("data", {}) or {}).get("plotly")
        if plotly_json:
            import tempfile, webbrowser
            html = _plotly_html(plotly_json)
            tmp = Path(tempfile.mktemp(suffix=".html", prefix="ae_chart_"))
            tmp.write_text(html)
            webbrowser.open(tmp.as_uri())
            _print(f"[green]✓ Chart opened in browser[/green]  [dim]{tmp}[/dim]" if _rich
                   else f"✓ Chart opened in browser  {tmp}")
        else:
            _print("[yellow]Not a chart result. Use `ae export` for geo data.[/yellow]" if _rich
                   else "Not a chart result. Use `ae export` for geo data.")
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command(name="preview")
@click.argument("result_key")
@click.option("--rows", "-n", default=5, show_default=True, help="Number of rows to show in table preview.")
@click.option("--map", "use_map", is_flag=True, default=False, help="Open result as an interactive map in the browser instead of a table.")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def preview_cmd(result_key: str, rows: int, use_map: bool, url: str | None):
    """Preview a result — table in terminal or interactive map in browser.

    \b
    Examples:
      ae preview get_conflict_events_a1b2          # first 5 rows as table
      ae preview get_conflict_events_a1b2 -n 10    # first 10 rows
      ae preview get_conflict_events_a1b2 --map    # open Leaflet map in browser
      ae preview get_ais_vessels_c3d4 --map        # vessel positions on dark map
    """
    from .client import AgenticEarth
    try:
        client = AgenticEarth(base_url=url)
        _preview_result(client, result_key, rows=rows, browser=use_map)
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command(name="export")
@click.argument("result_key")
@click.option("--output", "-o", required=True, help="Output file path (e.g. result.geojson).")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def export(result_key: str, output: str, url: str | None):
    """Download a result by key to a file.

    \b
    Example:
      ae export get_conflict_events_a1b2 --output events.geojson
    """
    from .client import AgenticEarth
    ext = Path(output).suffix.lstrip(".") or "geojson"
    try:
        client = AgenticEarth(base_url=url)
        saved = client.save_result(result_key, Path(output), format=ext)
        _print(f"[green]✓ Saved → {saved}[/green]" if _rich else f"✓ Saved → {saved}")
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command()
def mcp():
    """Start the Agentic Earth MCP server (stdio transport).

    \b
    Connects Claude Desktop, Cursor, Windsurf, and any MCP-compatible host
    to Agentic Earth's 150+ live geospatial datasets.

    \b
    Setup (Claude Desktop):
      Add to ~/Library/Application Support/Claude/claude_desktop_config.json:
      {
        "mcpServers": {
          "agenticearth": {
            "command": "ae",
            "args": ["mcp"],
            "env": { "AE_API_KEY": "ae_sk_..." }
          }
        }
      }

    \b
    Requires: pip install "agenticearth[mcp]"
    """
    try:
        from .mcp_server import run
    except ImportError:
        _print(
            '[red]✗ MCP dependencies not installed.[/red]\n'
            'Run: [bold]pip install "agenticearth[mcp]"[/bold]'
            if _rich else
            '✗ MCP dependencies not installed.\nRun: pip install "agenticearth[mcp]"'
        )
        sys.exit(1)
    run()


@main.command(name="upload")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--url", default=None, envvar="AE_BASE_URL")
def upload_cmd(file_path: str, url: str | None):
    """Upload a file to ZeusLM for analysis.

    \b
    Supported formats: CSV, GeoJSON, GeoPackage, Parquet, Shapefile (zip), TIFF.

    Example:
      ae upload my_data.csv
    """
    from .client import AgenticEarth
    try:
        client = AgenticEarth(base_url=url)
        _print(f"Uploading [cyan]{file_path}[/cyan]…" if _rich else f"Uploading {file_path}…")
        meta = client.upload(file_path)
        _print(f"[green]✓ Uploaded[/green]  dataset_key=[cyan]{meta.get('dataset_key','?')}[/cyan]  "
               f"rows=[dim]{meta.get('row_count','?')}[/dim]" if _rich
               else f"✓ Uploaded  key={meta.get('dataset_key','?')}  rows={meta.get('row_count','?')}")
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command(name="credits")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def credits_cmd(url: str | None):
    """Show current credit balance and tier."""
    from .client import AgenticEarth
    try:
        client = AgenticEarth(base_url=url)
        b = client.balance()
        tier      = b.get("tier", "?")
        remaining = b.get("credits_remaining", "?")
        monthly   = b.get("credits_monthly", "?")
        used      = b.get("credits_used", "?")
        pct       = int(remaining / monthly * 100) if monthly else 0
        bar_fill  = int(pct / 5)
        bar       = "█" * bar_fill + "░" * (20 - bar_fill)
        _print(
            f"\n  Tier:      [bold]{tier}[/bold]\n"
            f"  Credits:   [green]{remaining:,}[/green] / {monthly:,} remaining  [{pct}%]\n"
            f"  [{bar}]\n"
            f"  Used:      {used:,} this cycle\n"
            if _rich else
            f"\n  Tier: {tier}\n  Credits: {remaining}/{monthly} ({pct}%)\n  Used: {used}\n"
        )
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command(name="sessions")
def sessions_cmd():
    """List saved chat sessions."""
    if not _SESSIONS_DIR.exists():
        _print("No sessions found." )
        return
    files = sorted(_SESSIONS_DIR.glob("ae_sess_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        _print("No sessions found.")
        return
    last = _LAST_SESSION.read_text().strip() if _LAST_SESSION.exists() else ""
    _print(f"\n  {'SESSION ID':<22} {'UPDATED':<22} TURNS" if not _rich else
           f"\n  [dim]{'SESSION ID':<22} {'UPDATED':<22} TURNS[/dim]")
    for p in files:
        import json as _json
        try:
            data   = _json.loads(p.read_text())
            sid    = data.get("id", p.stem)
            turns  = len(data.get("history", [])) // 2
            updated = data.get("updated_at", "")[:16].replace("T", " ")
            marker = " ←" if sid == last else ""
            _print(f"  [cyan]{sid}[/cyan]  [dim]{updated}[/dim]  {turns} turns[green]{marker}[/green]"
                   if _rich else f"  {sid}  {updated}  {turns} turns{marker}")
        except Exception:
            pass
    _print("")


@main.command(name="datasets")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def datasets_cmd(url: str | None):
    """List uploaded ZeusLM datasets."""
    from .client import AgenticEarth
    try:
        client = AgenticEarth(base_url=url)
        items = client.datasets()
        if not items:
            _print("No datasets found. Use `ae upload <file>` or `/upload` in ae chat.")
            return
        _print(f"\n  {'DATASET KEY':<18} {'FILE':<30} ROWS" if not _rich else
               f"\n  [dim]{'DATASET KEY':<18} {'FILE':<30} ROWS[/dim]")
        for d in items:
            key  = d.get("dataset_key", "?")[:18]
            name = (d.get("filename") or d.get("name") or "?")[:30]
            rows = d.get("row_count", "?")
            _print(f"  [cyan]{key:<18}[/cyan]  {name:<30}  {rows}" if _rich
                   else f"  {key:<18}  {name:<30}  {rows}")
        _print("")
    except Exception as exc:
        _print(f"[red]✗ {exc}[/red]" if _rich else f"✗ {exc}")
        sys.exit(1)


@main.command(name="whoami")
@click.option("--url", default=None, envvar="AE_BASE_URL")
def whoami(url: str | None):
    """Show current API key and base URL."""
    from .config import get_api_key, get_base_url
    key = get_api_key()
    base = url or get_base_url()
    if key:
        masked = key[:10] + "…" + key[-4:]
        _print(f"API key:  [cyan]{masked}[/cyan]\nBase URL: [dim]{base}[/dim]" if _rich
               else f"API key:  {masked}\nBase URL: {base}")
    else:
        _print("[yellow]Not logged in. Run `ae login`.[/yellow]" if _rich else "Not logged in.")
