"""Agentic Earth Python SDK."""
from .client import AgenticEarth, AgenticEarthError, AuthError, InsufficientCreditsError, QueryResult, StreamEvent
from .config import get_api_key, get_base_url, save_credentials

_default_client: AgenticEarth | None = None


def _get_client() -> AgenticEarth:
    global _default_client
    if _default_client is None:
        _default_client = AgenticEarth()
    return _default_client


def query(prompt: str, **kwargs) -> QueryResult:
    """Run an agent query with the default client.

    Example:
        import agenticearth as ae
        result = ae.query("conflict events in Sudan last 30 days")
        result.save("sudan.geojson")
    """
    return _get_client().query(prompt, **kwargs)


def upload(file_path: str, **kwargs) -> dict:
    """Upload a file to ZeusLM."""
    return _get_client().upload(file_path, **kwargs)


__all__ = [
    "AgenticEarth",
    "AgenticEarthError",
    "AuthError",
    "InsufficientCreditsError",
    "QueryResult",
    "StreamEvent",
    "query",
    "upload",
]
