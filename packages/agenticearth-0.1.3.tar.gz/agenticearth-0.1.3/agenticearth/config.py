"""Config file management — stores API key and base URL in ~/.agenticearth/config.json."""
from __future__ import annotations

import json
import os
from pathlib import Path

_CONFIG_DIR  = Path.home() / ".agenticearth"
_CONFIG_FILE = _CONFIG_DIR / "config.json"

DEFAULT_BASE_URL = "https://api.agenticearth.app"


def _load() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))
    _CONFIG_FILE.chmod(0o600)


def get_api_key() -> str | None:
    return os.environ.get("AE_API_KEY") or _load().get("api_key")


def get_base_url() -> str:
    return os.environ.get("AE_BASE_URL") or _load().get("base_url") or DEFAULT_BASE_URL


def save_credentials(api_key: str, base_url: str | None = None) -> None:
    data = _load()
    data["api_key"] = api_key
    if base_url:
        data["base_url"] = base_url
    _save(data)


def clear_credentials() -> None:
    _save({})
