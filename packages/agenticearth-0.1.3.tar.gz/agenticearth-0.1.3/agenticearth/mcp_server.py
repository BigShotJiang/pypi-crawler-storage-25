"""Agentic Earth MCP server.

Exposes AE as native tools for Claude Desktop, Cursor, Windsurf, and any
MCP-compatible host. Communicates over stdio (default) so no port is needed.

Usage
-----
  # Claude Desktop — add to ~/Library/Application Support/Claude/claude_desktop_config.json:
  {
    "mcpServers": {
      "agenticearth": {
        "command": "ae",
        "args": ["mcp"],
        "env": { "AE_API_KEY": "ae_sk_..." }
      }
    }
  }

  # Or via uvx (no install needed):
  uvx agenticearth mcp
"""
from __future__ import annotations

import json
import os

from mcp.server.fastmcp import FastMCP

from .client import AgenticEarth, AuthError, InsufficientCreditsError

mcp = FastMCP(
    name="Agentic Earth",
    instructions=(
        "Agentic Earth gives you access to 150+ live geospatial datasets via natural language. "
        "Use ae_query to fetch data, run spatial analysis, or generate charts. "
        "Use ae_fetch to retrieve the raw GeoJSON for a result key returned by ae_query. "
        "Use ae_balance to check remaining credits."
    ),
)


def _client() -> AgenticEarth:
    api_key = os.environ.get("AE_API_KEY")
    if not api_key:
        raise AuthError(
            "AE_API_KEY environment variable not set. "
            "Get your key at agenticearth.app/settings."
        )
    return AgenticEarth(api_key=api_key)


@mcp.tool()
def ae_query(prompt: str) -> str:
    """Query Agentic Earth with natural language.

    Fetches live geospatial data, runs spatial analysis (hotspots, clustering,
    Prophet forecasting, trajectory analysis), and generates charts.

    Examples:
      - "Show conflict events in Sudan over the last 30 days"
      - "Fetch Sentinel-2 imagery for the Amazon and compute NDVI"
      - "Forecast US electricity demand for the next 12 months"
      - "Cluster AIS vessel activity near the Strait of Hormuz"
      - "What do Polymarket odds say about the Iranian nuclear deal?"

    Returns the agent's answer and any result keys. Use ae_fetch to retrieve
    the full dataset for a result key.
    """
    try:
        client = _client()
    except AuthError as e:
        return f"Auth error: {e}"

    try:
        result = client.query(prompt)
    except InsufficientCreditsError:
        return "Insufficient credits. Visit agenticearth.app to upgrade your plan."
    except Exception as e:
        return f"Query failed: {e}"

    lines = [result.answer or ""]
    if result.result_keys:
        lines.append(f"\nDatasets fetched: {', '.join(result.result_keys)}")
        lines.append("Use ae_fetch(result_key) to retrieve the full GeoJSON for any of these.")
    lines.append(
        "\n---\n"
        "🌍 For interactive maps, hotspot analysis, clustering, and full session history: "
        "**agenticearth.app** or `pip install agenticearth && ae chat`"
    )
    return "\n".join(lines)


@mcp.tool()
def ae_fetch(result_key: str, max_features: int = 200) -> str:
    """Fetch a stored dataset by result key. Returns GeoJSON.

    result_key is returned by ae_query after a successful data fetch.
    max_features caps the number of features returned (default 200).
    """
    try:
        client = _client()
    except AuthError as e:
        return f"Auth error: {e}"

    try:
        raw = client.fetch_raw(result_key)
    except Exception as e:
        return f"Fetch failed: {e}"

    # GeoDataFrame result
    geojson = raw.get("geojson") or raw.get("data")
    if geojson and isinstance(geojson, dict) and "features" in geojson:
        features = geojson["features"]
        truncated = len(features) > max_features
        geojson["features"] = features[:max_features]
        result = json.dumps(geojson)
        if truncated:
            result += f"\n\n[Truncated to {max_features} of {len(features)} features. Use the export tool or ae CLI to download the full dataset.]"
        return result

    # Markets / tabular result
    if raw.get("markets"):
        return json.dumps(raw["markets"])

    # Text / chart result
    if raw.get("answer"):
        return raw["answer"]

    return json.dumps(raw)


@mcp.tool()
def ae_balance() -> str:
    """Check your Agentic Earth credit balance."""
    try:
        client = _client()
        bal = client.balance()
        return f"Credits remaining: {bal}"
    except AuthError as e:
        return f"Auth error: {e}"
    except Exception as e:
        return f"Could not fetch balance: {e}"


def run() -> None:
    """Start the MCP server (stdio transport)."""
    mcp.run()
