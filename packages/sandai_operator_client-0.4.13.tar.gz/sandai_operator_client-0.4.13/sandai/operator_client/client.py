"""Sandai Operator client implementation."""

import asyncio
import math
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from celery.result import AsyncResult

from .config import (
    VALID_PRIORITIES,
    CeleryConfig,
    ClientConfig,
    DEFAULT_BLOCKING_TIMEOUT_SECONDS,
    get_celery_config,
    get_default_celery_config,
    resolve_client_config,
)
from .exceptions import ClientPoolTimeoutError, InvalidPriorityError, OperatorError
from .exceptions import TaskTimeoutError
from .protocol import (
    build_task_payload,
    inspect_probe_result,
    parse_desc_result,
    parse_task_result,
    raise_unexpected_task_error,
)
from .transport import CeleryTransport
from .debug_output import PrintLogger
from .async_transport import AsyncTransportAdapter
from .types import (
    AsyncSubmittedTask,
    AsyncTaskHandle,
    BatchTaskResult,
    HealthCheckResult,
    OperatorDescription,
    SubmittedTask,
)

_LOGGER = PrintLogger(__name__, enabled=False)

_PROBE_TIMEOUT_SECONDS = 10
_BATCH_IDLE_BACKOFF_START_SECONDS = 0.05
_BATCH_IDLE_BACKOFF_MAX_SECONDS = 0.5


LegacyTaskResult = Tuple[List[Dict[str, Any]], Dict[str, Any]]
LegacyBatchTasks = List[Tuple[List[Dict[str, Any]], Dict[str, Any]]]


class OperatorClient:
    """Client for sending tasks to a Sandai operator over Celery."""

    def __init__(
        self,
        operator_name: str,
        operator_version: str,
        broker_url: Optional[str] = None,
        result_backend: Optional[str] = None,
        timeout: int = DEFAULT_BLOCKING_TIMEOUT_SECONDS,
        debug: bool = False,
        priority: str = "normal",
        cancel_key: Optional[str] = None,
        auto_forget_result: Optional[bool] = None,
        broker_pool_limit: Optional[int] = None,
        result_backend_max_connections: Optional[int] = None,
        backend_pool_limit: Optional[int] = None,
        backend_poll_concurrency: Optional[int] = None,
        pool_acquire_timeout: Optional[float] = None,
        thread_safe_mode: bool = True,
        shared_transport_scope: str = "operator",
    ):
        self.valid_priorities = list(VALID_PRIORITIES)
        self._validate_priority(priority)

        self.config = resolve_client_config(
            operator_name,
            operator_version,
            broker_url=broker_url,
            result_backend=result_backend,
            timeout=timeout,
            debug=debug,
            priority=priority,
            cancel_key=cancel_key,
            auto_forget_result=auto_forget_result,
            broker_pool_limit=broker_pool_limit,
            result_backend_max_connections=result_backend_max_connections,
            backend_pool_limit=backend_pool_limit,
            backend_poll_concurrency=backend_poll_concurrency,
            pool_acquire_timeout=pool_acquire_timeout,
            thread_safe_mode=thread_safe_mode,
            shared_transport_scope=shared_transport_scope,
        )
        self._logger = _LOGGER.child(enabled=self.config.debug)
        self.transport = CeleryTransport(self.config, logger=self._logger)
        self.celery_app = self.transport.app

        self.operator_name = self.config.operator_name
        self.operator_version = self.config.operator_version
        self.timeout = self.config.timeout
        self.debug = self.config.debug
        self.priority = self.config.priority
        self.cancel_key = self.config.cancel_key
        self.auto_forget_result = self.config.auto_forget_result
        self.task_name = self.config.task_name
        self.queue_names = self.config.queue_names
        self.broker_url = self.config.broker_url
        self.result_backend = self.config.result_backend
        self._desc_cache: Optional[Dict[str, Any]] = None
        self._desc_lock = threading.Lock()

        if self.debug:
            self._logger.debug(
                "OperatorClient initialized operator=%s version=%s broker=%s backend=%s queues=%s detailed_debug=%s",
                self.operator_name,
                self.operator_version,
                self.broker_url,
                self.result_backend,
                list(self.queue_names.values()),
                self.config.detailed_debug,
            )

    def _validate_priority(self, priority: str) -> None:
        if priority not in self.valid_priorities:
            raise InvalidPriorityError(priority, self.valid_priorities)

    def _effective_timeout(self, timeout: Optional[int]) -> int:
        return timeout if timeout is not None else self.timeout

    def _deadline_from_timeout(self, timeout: Optional[int]) -> tuple[int, float]:
        effective_timeout = self._effective_timeout(timeout)
        return effective_timeout, time.monotonic() + max(0, effective_timeout)

    def _remaining_timeout(self, deadline: float) -> int:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return 0
        return max(1, math.ceil(remaining))

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> "OperatorClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _forget_result_if_needed(self, async_result: Optional[AsyncResult]) -> None:
        if not self.auto_forget_result or async_result is None:
            return

        try:
            self.transport.forget(async_result)
            if self.debug:
                self._logger.debug("forgot result key task_id=%s", async_result.id)
        except Exception as forget_error:  # pragma: no cover - defensive logging only
            if self.debug:
                self._logger.debug(
                    "failed to forget result key task_id=%s error=%s",
                    getattr(async_result, "id", None),
                    forget_error,
                )

    def _submit_payload(self, payload: Dict[str, Any], *, priority: str) -> AsyncResult:
        queue_name = self.queue_names[priority]
        return self.transport.send_task(self.task_name, kwargs=payload, queue=queue_name)

    def _build_task_payload(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        *,
        timeout: Optional[int],
        cancel_key: Optional[str],
        persistent_output: bool,
    ) -> Dict[str, Any]:
        return build_task_payload(
            input_artifacts,
            options,
            timeout=timeout,
            default_timeout=self.timeout,
            cancel_key=cancel_key,
            default_cancel_key=self.cancel_key,
            persistent_output=persistent_output,
        )

    def _send_task_async(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        *,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> AsyncResult:
        resolved_priority = priority or self.priority
        self._validate_priority(resolved_priority)
        payload = self._build_task_payload(
            input_artifacts,
            options,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        if self.debug:
            self._logger.debug(
                "submit_task operator=%s version=%s priority=%s timeout=%s cancel_key=%s persistent_output=%s artifacts=%s option_keys=%s",
                self.operator_name,
                self.operator_version,
                resolved_priority,
                timeout,
                cancel_key or self.cancel_key,
                persistent_output,
                len(input_artifacts),
                sorted(options.keys()),
            )
        return self._submit_payload(payload, priority=resolved_priority)

    def _wait_for_task_result(
        self, async_result: AsyncResult, *, timeout: int
    ) -> LegacyTaskResult:
        try:
            raw_result = self.transport.get_result(async_result, timeout=timeout)
            if self.debug:
                self._logger.debug("task_result_received task_id=%s timeout=%s", async_result.id, timeout)
            return parse_task_result(async_result.id, raw_result).to_legacy_tuple()
        except OperatorError:
            raise
        except Exception as exc:
            raise_unexpected_task_error(async_result.id, timeout, exc)

    def _wait_for_desc(self, async_result: AsyncResult, *, timeout: int) -> OperatorDescription:
        try:
            raw_result = self.transport.get_result(async_result, timeout=timeout)
            if self.debug:
                self._logger.debug("desc_result_received task_id=%s timeout=%s", async_result.id, timeout)
            return parse_desc_result(async_result.id, raw_result)
        except OperatorError:
            raise
        except Exception as exc:
            raise_unexpected_task_error(async_result.id, timeout, exc)

    @property
    def desc(self) -> Dict[str, Any]:
        if self._desc_cache is not None:
            return self._desc_cache

        with self._desc_lock:
            if self._desc_cache is not None:
                return self._desc_cache
            async_result = self._submit_payload({"task_type": "desc"}, priority="high")
            timeout, _ = self._deadline_from_timeout(None)
            try:
                self._desc_cache = self._wait_for_desc(async_result, timeout=timeout).to_dict()
                return self._desc_cache
            finally:
                self._forget_result_if_needed(async_result)

    def async_call(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> AsyncResult:
        return self._send_task_async(
            input_artifacts,
            options,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )

    def sync(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        *,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> LegacyTaskResult:
        async_result = self._send_task_async(
            input_artifacts,
            options,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        effective_timeout, _ = self._deadline_from_timeout(timeout)

        try:
            return self._wait_for_task_result(async_result, timeout=effective_timeout)
        finally:
            self._forget_result_if_needed(async_result)

    def batch_submit(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[SubmittedTask]:
        submissions: List[SubmittedTask] = []
        if self.debug:
            self._logger.debug(
                "batch_submit_start size=%s priority=%s timeout=%s cancel_key=%s persistent_output=%s",
                len(tasks),
                priority or self.priority,
                timeout,
                cancel_key or self.cancel_key,
                persistent_output,
            )
        for index, (input_artifacts, options) in enumerate(tasks):
            try:
                async_result = self._send_task_async(
                    input_artifacts,
                    options,
                    priority=priority,
                    timeout=timeout,
                    cancel_key=cancel_key,
                    persistent_output=persistent_output,
                )
                submissions.append(SubmittedTask(index=index, async_result=async_result))
                if self.debug:
                    self._logger.debug("batch_submit_item index=%s task_id=%s submitted=true", index, async_result.id)
            except Exception as exc:
                submissions.append(SubmittedTask(index=index, error=exc))
                if self.debug:
                    self._logger.debug("batch_submit_item index=%s submitted=false error=%s", index, exc)
        if self.debug:
            self._logger.debug("batch_submit_done size=%s", len(submissions))
        return submissions

    def batch_async(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[Optional[AsyncResult]]:
        """Legacy best-effort batch submit API kept for compatibility."""

        submissions = self.batch_submit(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return [submission.async_result for submission in submissions]

    def batch_collect(
        self, submissions: List[SubmittedTask], *, timeout: Optional[int] = None
    ) -> List[BatchTaskResult]:
        effective_timeout, deadline = self._deadline_from_timeout(timeout)
        results: List[Optional[BatchTaskResult]] = [None] * len(submissions)
        pending: Dict[str, tuple[int, SubmittedTask]] = {}
        submitted_async_results: List[AsyncResult] = []
        idle_sleep = _BATCH_IDLE_BACKOFF_START_SECONDS
        poll_round = 0

        for position, submission in enumerate(submissions):
            if not submission.submitted or submission.async_result is None:
                results[position] = BatchTaskResult(
                    index=submission.index,
                    task_id=submission.task_id,
                    submitted=False,
                    error=submission.error,
                )
                continue
            submitted_async_results.append(submission.async_result)
            if submission.task_id:
                pending[submission.task_id] = (position, submission)

        try:
            while pending:
                poll_round += 1
                remaining = self._remaining_timeout(deadline)
                if remaining <= 0:
                    break

                try:
                    ready_results = self.transport.collect_ready_results(
                        [
                            submission.async_result
                            for _, submission in pending.values()
                            if submission.async_result is not None
                        ],
                        wait_for_slot=False,
                    )
                except ClientPoolTimeoutError:
                    ready_results = {}

                if ready_results:
                    if self.debug:
                        self._logger.debug(
                            "batch_collect_round round=%s pending=%s ready=%s remaining=%s idle_sleep=%s",
                            poll_round,
                            len(pending),
                            len(ready_results),
                            remaining,
                            idle_sleep,
                        )
                    idle_sleep = _BATCH_IDLE_BACKOFF_START_SECONDS
                else:
                    if self.debug:
                        self._logger.debug(
                            "batch_collect_round_idle round=%s pending=%s remaining=%s sleep=%s",
                            poll_round,
                            len(pending),
                            remaining,
                            idle_sleep,
                        )
                    time.sleep(min(idle_sleep, max(0.0, deadline - time.monotonic())))
                    idle_sleep = min(_BATCH_IDLE_BACKOFF_MAX_SECONDS, idle_sleep * 2)
                    continue

                for task_id, raw_result in ready_results.items():
                    entry = pending.pop(task_id, None)
                    if entry is None:
                        continue
                    position, submission = entry
                    try:
                        artifacts, task_results = parse_task_result(task_id, raw_result).to_legacy_tuple()
                        results[position] = BatchTaskResult(
                            index=submission.index,
                            task_id=submission.task_id,
                            submitted=True,
                            artifacts=artifacts,
                            results=task_results,
                        )
                        if self.debug:
                            self._logger.debug("batch_collect_item_ready index=%s task_id=%s", submission.index, task_id)
                    except Exception as exc:
                        if isinstance(exc, OperatorError):
                            error = exc
                        else:
                            try:
                                raise_unexpected_task_error(task_id, 0, exc)
                            except OperatorError as mapped_exc:
                                error = mapped_exc
                        results[position] = BatchTaskResult(
                            index=submission.index,
                            task_id=submission.task_id,
                            submitted=True,
                            error=error,
                        )
                        if self.debug:
                            self._logger.debug("batch_collect_item_error index=%s task_id=%s error=%s", submission.index, task_id, error)

            for position, submission in pending.values():
                results[position] = BatchTaskResult(
                    index=submission.index,
                    task_id=submission.task_id,
                    submitted=True,
                    error=TaskTimeoutError(submission.task_id or "", effective_timeout),
                )
                if self.debug:
                    self._logger.debug(
                        "batch_collect_item_timeout index=%s task_id=%s timeout=%s",
                        submission.index,
                        submission.task_id,
                        effective_timeout,
                    )
        finally:
            for async_result in submitted_async_results:
                self._forget_result_if_needed(async_result)

        return [result for result in results if result is not None]

    def batch_sync_detailed(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[BatchTaskResult]:
        submissions = self.batch_submit(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return self.batch_collect(submissions, timeout=timeout)

    def batch_sync(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[LegacyTaskResult]:
        """Legacy best-effort batch sync API kept for compatibility."""

        detailed_results = self.batch_sync_detailed(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return [result.to_legacy_tuple() for result in detailed_results]

    def get_queue_info(self) -> Dict[str, str]:
        return self.queue_names.copy()

    def probe(self, timeout: int = _PROBE_TIMEOUT_SECONDS) -> HealthCheckResult:
        try:
            async_result = self._send_task_async(
                input_artifacts=[],
                options={"test": True},
                priority="low",
            )
        except Exception as exc:
            return HealthCheckResult(
                submit_ok=False,
                retrieval_ok=False,
                response_ok=False,
                error=str(exc),
            )

        try:
            raw_result = self.transport.get_result(async_result, timeout=timeout)
            response_ok, probe_error = inspect_probe_result(raw_result)
            return HealthCheckResult(
                submit_ok=True,
                retrieval_ok=True,
                response_ok=response_ok,
                task_id=async_result.id,
                error=probe_error,
            )
        except Exception as exc:
            return HealthCheckResult(
                submit_ok=True,
                retrieval_ok=False,
                response_ok=False,
                task_id=async_result.id,
                error=str(exc),
            )
        finally:
            self._forget_result_if_needed(async_result)

    def ping(self, timeout: int = 10) -> bool:
        """Compatibility helper that confirms the submit path is reachable."""

        return self.probe(timeout=timeout).submit_ok


class AsyncOperatorClient:
    """Async client for sending tasks to a Sandai operator."""

    def __init__(
        self,
        operator_name: str,
        operator_version: str,
        broker_url: Optional[str] = None,
        result_backend: Optional[str] = None,
        timeout: int = DEFAULT_BLOCKING_TIMEOUT_SECONDS,
        debug: bool = False,
        priority: str = "normal",
        cancel_key: Optional[str] = None,
        auto_forget_result: Optional[bool] = None,
        broker_pool_limit: Optional[int] = None,
        result_backend_max_connections: Optional[int] = None,
        backend_pool_limit: Optional[int] = None,
        backend_poll_concurrency: Optional[int] = None,
        pool_acquire_timeout: Optional[float] = None,
        thread_safe_mode: bool = True,
        shared_transport_scope: str = "operator",
    ):
        self.valid_priorities = list(VALID_PRIORITIES)
        self._validate_priority(priority)

        self.config = resolve_client_config(
            operator_name,
            operator_version,
            broker_url=broker_url,
            result_backend=result_backend,
            timeout=timeout,
            debug=debug,
            priority=priority,
            cancel_key=cancel_key,
            auto_forget_result=auto_forget_result,
            broker_pool_limit=broker_pool_limit,
            result_backend_max_connections=result_backend_max_connections,
            backend_pool_limit=backend_pool_limit,
            backend_poll_concurrency=backend_poll_concurrency,
            pool_acquire_timeout=pool_acquire_timeout,
            thread_safe_mode=thread_safe_mode,
            shared_transport_scope=shared_transport_scope,
        )
        self._logger = _LOGGER.child(enabled=self.config.debug)
        self.transport = AsyncTransportAdapter(self.config, logger_=self._logger)
        self.celery_app = self.transport.app

        self.operator_name = self.config.operator_name
        self.operator_version = self.config.operator_version
        self.timeout = self.config.timeout
        self.debug = self.config.debug
        self.priority = self.config.priority
        self.cancel_key = self.config.cancel_key
        self.auto_forget_result = self.config.auto_forget_result
        self.task_name = self.config.task_name
        self.queue_names = self.config.queue_names
        self.broker_url = self.config.broker_url
        self.result_backend = self.config.result_backend
        self._desc_cache: Optional[Dict[str, Any]] = None
        self._desc_lock = threading.Lock()

        if self.debug:
            self._logger.debug(
                "AsyncOperatorClient initialized operator=%s version=%s broker=%s backend=%s queues=%s detailed_debug=%s",
                self.operator_name,
                self.operator_version,
                self.broker_url,
                self.result_backend,
                list(self.queue_names.values()),
                self.config.detailed_debug,
            )

    def _validate_priority(self, priority: str) -> None:
        if priority not in self.valid_priorities:
            raise InvalidPriorityError(priority, self.valid_priorities)

    def _effective_timeout(self, timeout: Optional[int]) -> int:
        return timeout if timeout is not None else self.timeout

    def _deadline_from_timeout(self, timeout: Optional[int]) -> tuple[int, float]:
        effective_timeout = self._effective_timeout(timeout)
        return effective_timeout, time.monotonic() + max(0, effective_timeout)

    def _remaining_timeout(self, deadline: float) -> int:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return 0
        return max(1, math.ceil(remaining))

    async def aclose(self) -> None:
        await self.transport.aclose()

    async def __aenter__(self) -> "AsyncOperatorClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def _forget_result_if_needed(self, handle: Optional[AsyncTaskHandle]) -> None:
        if not self.auto_forget_result or handle is None:
            return

        try:
            await handle.forget()
            if self.debug:
                self._logger.debug("forgot result key task_id=%s", handle.task_id)
        except Exception as forget_error:  # pragma: no cover
            if self.debug:
                self._logger.debug(
                    "failed to forget result key task_id=%s error=%s",
                    getattr(handle, "task_id", None),
                    forget_error,
                )

    def _build_task_payload(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        *,
        timeout: Optional[int],
        cancel_key: Optional[str],
        persistent_output: bool,
    ) -> Dict[str, Any]:
        return build_task_payload(
            input_artifacts,
            options,
            timeout=timeout,
            default_timeout=self.timeout,
            cancel_key=cancel_key,
            default_cancel_key=self.cancel_key,
            persistent_output=persistent_output,
        )

    async def _submit_payload(self, payload: Dict[str, Any], *, priority: str) -> AsyncTaskHandle:
        queue_name = self.queue_names[priority]
        async_result = await self.transport.send_task(self.task_name, kwargs=payload, queue=queue_name)
        return AsyncTaskHandle(async_result=async_result, transport=self.transport)

    async def _send_task_async(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        *,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> AsyncTaskHandle:
        resolved_priority = priority or self.priority
        self._validate_priority(resolved_priority)
        payload = self._build_task_payload(
            input_artifacts,
            options,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        if self.debug:
            self._logger.debug(
                "async_submit_task operator=%s version=%s priority=%s timeout=%s cancel_key=%s persistent_output=%s artifacts=%s option_keys=%s",
                self.operator_name,
                self.operator_version,
                resolved_priority,
                timeout,
                cancel_key or self.cancel_key,
                persistent_output,
                len(input_artifacts),
                sorted(options.keys()),
            )
        return await self._submit_payload(payload, priority=resolved_priority)

    async def _wait_for_task_result(
        self, handle: AsyncTaskHandle, *, timeout: int
    ) -> LegacyTaskResult:
        try:
            raw_result = await self.transport.get_result(handle.async_result, timeout=timeout)
            if self.debug:
                self._logger.debug("async_task_result_received task_id=%s timeout=%s", handle.task_id, timeout)
            return parse_task_result(handle.task_id or "", raw_result).to_legacy_tuple()
        except OperatorError:
            raise
        except Exception as exc:
            raise_unexpected_task_error(handle.task_id or "", timeout, exc)

    async def _wait_for_desc(self, handle: AsyncTaskHandle, *, timeout: int) -> OperatorDescription:
        try:
            raw_result = await self.transport.get_result(handle.async_result, timeout=timeout)
            if self.debug:
                self._logger.debug("async_desc_result_received task_id=%s timeout=%s", handle.task_id, timeout)
            return parse_desc_result(handle.task_id or "", raw_result)
        except OperatorError:
            raise
        except Exception as exc:
            raise_unexpected_task_error(handle.task_id or "", timeout, exc)

    def _load_desc_sync(self) -> Dict[str, Any]:
        if self._desc_cache is not None:
            return self._desc_cache

        with self._desc_lock:
            if self._desc_cache is not None:
                return self._desc_cache
            async_result = self.transport.celery.send_task(
                self.task_name,
                kwargs={"task_type": "desc"},
                queue=self.queue_names["high"],
            )
            timeout, _ = self._deadline_from_timeout(None)
            try:
                raw_result = self.transport.celery.get_result(async_result, timeout=timeout)
                self._desc_cache = parse_desc_result(async_result.id, raw_result).to_dict()
                return self._desc_cache
            except OperatorError:
                raise
            except Exception as exc:
                raise_unexpected_task_error(async_result.id, timeout, exc)
            finally:
                if self.auto_forget_result:
                    try:
                        self.transport.celery.forget(async_result)
                    except Exception:
                        if self.debug:
                            self._logger.debug(
                                "failed to forget result key task_id=%s",
                                getattr(async_result, "id", None),
                                exc_info=True,
                            )

    async def desc(self) -> Dict[str, Any]:
        return await asyncio.to_thread(self._load_desc_sync)

    async def async_call(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> AsyncTaskHandle:
        return await self._send_task_async(
            input_artifacts,
            options,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )

    async def sync(
        self,
        input_artifacts: List[Dict[str, Any]],
        options: Dict[str, Any],
        priority: Optional[str] = None,
        *,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> LegacyTaskResult:
        handle = await self._send_task_async(
            input_artifacts,
            options,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        effective_timeout, _ = self._deadline_from_timeout(timeout)
        try:
            return await self._wait_for_task_result(handle, timeout=effective_timeout)
        finally:
            await self._forget_result_if_needed(handle)

    async def batch_submit(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[AsyncSubmittedTask]:
        submissions: List[AsyncSubmittedTask] = []
        if self.debug:
            self._logger.debug(
                "async_batch_submit_start size=%s priority=%s timeout=%s cancel_key=%s persistent_output=%s",
                len(tasks),
                priority or self.priority,
                timeout,
                cancel_key or self.cancel_key,
                persistent_output,
            )
        for index, (input_artifacts, options) in enumerate(tasks):
            try:
                handle = await self._send_task_async(
                    input_artifacts,
                    options,
                    priority=priority,
                    timeout=timeout,
                    cancel_key=cancel_key,
                    persistent_output=persistent_output,
                )
                submissions.append(AsyncSubmittedTask(index=index, handle=handle))
                if self.debug:
                    self._logger.debug("async_batch_submit_item index=%s task_id=%s submitted=true", index, handle.task_id)
            except Exception as exc:
                submissions.append(AsyncSubmittedTask(index=index, error=exc))
                if self.debug:
                    self._logger.debug("async_batch_submit_item index=%s submitted=false error=%s", index, exc)
        if self.debug:
            self._logger.debug("async_batch_submit_done size=%s", len(submissions))
        return submissions

    async def batch_async(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[Optional[AsyncTaskHandle]]:
        submissions = await self.batch_submit(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return [submission.handle for submission in submissions]

    async def batch_collect(
        self, submissions: List[AsyncSubmittedTask], *, timeout: Optional[int] = None
    ) -> List[BatchTaskResult]:
        effective_timeout, deadline = self._deadline_from_timeout(timeout)
        results: List[Optional[BatchTaskResult]] = [None] * len(submissions)
        pending: Dict[str, tuple[int, AsyncSubmittedTask]] = {}
        submitted_handles: List[AsyncTaskHandle] = []
        idle_sleep = _BATCH_IDLE_BACKOFF_START_SECONDS
        poll_round = 0

        for position, submission in enumerate(submissions):
            if not submission.submitted or submission.handle is None:
                results[position] = BatchTaskResult(
                    index=submission.index,
                    task_id=submission.task_id,
                    submitted=False,
                    error=submission.error,
                )
                continue
            submitted_handles.append(submission.handle)
            if submission.task_id:
                pending[submission.task_id] = (position, submission)

        try:
            while pending:
                poll_round += 1
                remaining = self._remaining_timeout(deadline)
                if remaining <= 0:
                    break

                try:
                    ready_results = await self.transport.collect_ready_results(
                        [
                            submission.handle.async_result
                            for _, submission in pending.values()
                            if submission.handle is not None
                        ],
                        wait_for_slot=False,
                    )
                except ClientPoolTimeoutError:
                    ready_results = {}

                if ready_results:
                    if self.debug:
                        self._logger.debug(
                            "async_batch_collect_round round=%s pending=%s ready=%s remaining=%s idle_sleep=%s",
                            poll_round,
                            len(pending),
                            len(ready_results),
                            remaining,
                            idle_sleep,
                        )
                    idle_sleep = _BATCH_IDLE_BACKOFF_START_SECONDS
                else:
                    if self.debug:
                        self._logger.debug(
                            "async_batch_collect_round_idle round=%s pending=%s remaining=%s sleep=%s",
                            poll_round,
                            len(pending),
                            remaining,
                            idle_sleep,
                        )
                    await asyncio.sleep(min(idle_sleep, max(0.0, deadline - time.monotonic())))
                    idle_sleep = min(_BATCH_IDLE_BACKOFF_MAX_SECONDS, idle_sleep * 2)
                    continue

                for task_id, raw_result in ready_results.items():
                    entry = pending.pop(task_id, None)
                    if entry is None:
                        continue
                    position, submission = entry
                    try:
                        artifacts, task_results = parse_task_result(task_id, raw_result).to_legacy_tuple()
                        results[position] = BatchTaskResult(
                            index=submission.index,
                            task_id=submission.task_id,
                            submitted=True,
                            artifacts=artifacts,
                            results=task_results,
                        )
                        if self.debug:
                            self._logger.debug("async_batch_collect_item_ready index=%s task_id=%s", submission.index, task_id)
                    except Exception as exc:
                        if isinstance(exc, OperatorError):
                            error = exc
                        else:
                            try:
                                raise_unexpected_task_error(task_id, 0, exc)
                            except OperatorError as mapped_exc:
                                error = mapped_exc
                        results[position] = BatchTaskResult(
                            index=submission.index,
                            task_id=submission.task_id,
                            submitted=True,
                            error=error,
                        )
                        if self.debug:
                            self._logger.debug("async_batch_collect_item_error index=%s task_id=%s error=%s", submission.index, task_id, error)

            for position, submission in pending.values():
                results[position] = BatchTaskResult(
                    index=submission.index,
                    task_id=submission.task_id,
                    submitted=True,
                    error=TaskTimeoutError(submission.task_id or "", effective_timeout),
                )
                if self.debug:
                    self._logger.debug(
                        "async_batch_collect_item_timeout index=%s task_id=%s timeout=%s",
                        submission.index,
                        submission.task_id,
                        effective_timeout,
                    )
        finally:
            for handle in submitted_handles:
                await self._forget_result_if_needed(handle)

        return [result for result in results if result is not None]

    async def batch_sync_detailed(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[BatchTaskResult]:
        submissions = await self.batch_submit(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return await self.batch_collect(submissions, timeout=timeout)

    async def batch_sync(
        self,
        tasks: LegacyBatchTasks,
        *,
        priority: Optional[str] = None,
        timeout: Optional[int] = None,
        cancel_key: Optional[str] = None,
        persistent_output: bool = False,
    ) -> List[LegacyTaskResult]:
        detailed_results = await self.batch_sync_detailed(
            tasks,
            priority=priority,
            timeout=timeout,
            cancel_key=cancel_key,
            persistent_output=persistent_output,
        )
        return [result.to_legacy_tuple() for result in detailed_results]

    def get_queue_info(self) -> Dict[str, str]:
        return self.queue_names.copy()

    async def probe(self, timeout: int = _PROBE_TIMEOUT_SECONDS) -> HealthCheckResult:
        try:
            handle = await self._send_task_async(
                input_artifacts=[],
                options={"test": True},
                priority="low",
            )
        except Exception as exc:
            return HealthCheckResult(
                submit_ok=False,
                retrieval_ok=False,
                response_ok=False,
                error=str(exc),
            )

        try:
            raw_result = await self.transport.get_result(handle.async_result, timeout=timeout)
            response_ok, probe_error = inspect_probe_result(raw_result)
            return HealthCheckResult(
                submit_ok=True,
                retrieval_ok=True,
                response_ok=response_ok,
                task_id=handle.task_id,
                error=probe_error,
            )
        except Exception as exc:
            return HealthCheckResult(
                submit_ok=True,
                retrieval_ok=False,
                response_ok=False,
                task_id=handle.task_id,
                error=str(exc),
            )
        finally:
            await self._forget_result_if_needed(handle)

    async def ping(self, timeout: int = 10) -> bool:
        return (await self.probe(timeout=timeout)).submit_ok



def create_client(
    operator_name: str, operator_version: str, **kwargs: Any
) -> OperatorClient:
    """Convenience constructor for ``OperatorClient``."""

    return OperatorClient(operator_name, operator_version, **kwargs)


def create_async_client(
    operator_name: str, operator_version: str, **kwargs: Any
) -> AsyncOperatorClient:
    """Convenience constructor for ``AsyncOperatorClient``."""

    return AsyncOperatorClient(operator_name, operator_version, **kwargs)


__all__ = [
    "CeleryConfig",
    "ClientConfig",
    "LegacyBatchTasks",
    "LegacyTaskResult",
    "OperatorClient",
    "HealthCheckResult",
    "SubmittedTask",
    "BatchTaskResult",
    "AsyncOperatorClient",
    "AsyncTaskHandle",
    "AsyncSubmittedTask",
    "create_client",
    "create_async_client",
    "get_celery_config",
    "get_default_celery_config",
    "resolve_client_config",
]
