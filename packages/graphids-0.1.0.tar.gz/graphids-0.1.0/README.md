# GraphIDS

Graph-based intrusion detection using GCN, Transformer autoencoder, and contrastive learning.

Reference implementation of the framework introduced in:

> Govindarajan, V. & Muzamal, J. H. (2025). Advanced cloud intrusion detection
> framework using graph based features transformers and contrastive learning.
> *Scientific Reports*, 15, 20511. DOI: [10.1038/s41598-025-07956-w](https://doi.org/10.1038/s41598-025-07956-w)

## Install

```bash
pip install graphids
```

## Quick start

```python
from graphids import GraphIDS

model = GraphIDS(n_features=41, n_classes=5)
model.train_pipeline(X_train, y_train)
result = model.evaluate(X_test, y_test)
print(f"Accuracy: {result.accuracy:.4f}")
```

## Architecture

Three-stage pipeline:

1. **GCN** — constructs a communication graph from flow data, extracts structural node embeddings via 3-layer graph convolution
2. **Transformer autoencoder** — refines embeddings through self-attention, identifies discriminative feature dimensions
3. **Contrastive classifier** — improves class separation for minority attack types (U2R, R2L), outputs multi-class predictions

## Results (from the paper)

| Dataset | Accuracy | Precision | Recall | F1 | FPR |
|---|---|---|---|---|---|
| NSL-KDD (5-class) | 99.97% | 99.94% | 99.92% | 99.93% | 0.05% |
| CIC-IDS (binary) | 99.96% | 99.93% | 99.91% | 99.92% | 0.06% |
| CIC-IDS (multi) | 99.95% | 99.92% | 99.90% | 99.91% | 0.07% |

## Citation

```bibtex
@article{govindarajan2025graphids,
    title   = {Advanced cloud intrusion detection framework using graph based
               features transformers and contrastive learning},
    author  = {Govindarajan, Vijay and Muzamal, Junaid Hussain},
    journal = {Scientific Reports},
    volume  = {15},
    pages   = {20511},
    year    = {2025},
    doi     = {10.1038/s41598-025-07956-w},
}
```

## License

MIT
