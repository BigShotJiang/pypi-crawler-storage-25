"""Integration tests for the full GraphIDS pipeline."""

import numpy as np
import pytest
from sklearn.datasets import make_classification

from graphids.pipeline import GraphIDS, EvalResult


def _make_ids_data(n_samples=200, n_features=20, n_classes=3, random_state=42):
    X, y = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_informative=12,
        n_redundant=4,
        n_classes=n_classes,
        random_state=random_state,
        flip_y=0.03,
    )
    return X, y


def test_train_and_predict_shapes():
    X, y = _make_ids_data(n_samples=100, n_classes=3)
    model = GraphIDS(n_features=20, n_classes=3)
    model.train_pipeline(
        X[:70], y[:70],
        gcn_epochs=5, ae_epochs=5, clf_epochs=5,
        verbose=False,
    )
    preds = model.predict(X[70:])
    assert preds.shape == (30,)


def test_evaluate_returns_result():
    X, y = _make_ids_data(n_samples=100, n_classes=2)
    model = GraphIDS(n_features=20, n_classes=2)
    model.train_pipeline(
        X[:70], y[:70],
        gcn_epochs=5, ae_epochs=5, clf_epochs=5,
        verbose=False,
    )
    result = model.evaluate(X[70:], y[70:])
    assert isinstance(result, EvalResult)
    assert 0 <= result.accuracy <= 1
    assert 0 <= result.f1 <= 1
    assert result.predictions.shape == (30,)


def test_accuracy_above_chance():
    # Binary classification with a well-separated dataset gives the
    # 3-stage pipeline enough signal to learn in a short training run.
    X, y = _make_ids_data(n_samples=400, n_features=20, n_classes=2, random_state=0)
    model = GraphIDS(n_features=20, n_classes=2)
    model.train_pipeline(
        X[:300], y[:300],
        gcn_epochs=40, ae_epochs=40, clf_epochs=40,
        verbose=False,
    )
    result = model.evaluate(X[300:], y[300:])
    # Binary chance = 0.50. On synthetic data the graph is nearly fully
    # connected (uniform cosine similarity), limiting GCN's ability to
    # extract structural features. Real IDS data has natural clusters that
    # produce a much sparser and more informative graph. The real validation
    # is on NSL-KDD, not synthetic data — this test just confirms the
    # pipeline doesn't crash and learns *something*.
    assert result.accuracy > 0.50, f"accuracy {result.accuracy:.2f} not above chance"


def test_predict_returns_known_labels():
    X, y = _make_ids_data(n_samples=100, n_classes=2)
    model = GraphIDS(n_features=20, n_classes=2)
    model.train_pipeline(
        X[:70], y[:70],
        gcn_epochs=5, ae_epochs=5, clf_epochs=5,
        verbose=False,
    )
    preds = model.predict(X[70:])
    assert set(preds).issubset(set(y))


def test_pipeline_with_string_labels():
    X, y = _make_ids_data(n_samples=100, n_classes=3)
    label_map = {0: "Normal", 1: "DoS", 2: "Probe"}
    y_str = np.array([label_map[yi] for yi in y])

    model = GraphIDS(n_features=20, n_classes=3)
    model.train_pipeline(
        X[:70], y_str[:70],
        gcn_epochs=5, ae_epochs=5, clf_epochs=5,
        verbose=False,
    )
    preds = model.predict(X[70:])
    assert all(p in ["Normal", "DoS", "Probe"] for p in preds)
