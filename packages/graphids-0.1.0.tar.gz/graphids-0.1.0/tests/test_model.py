"""Tests for the GCN, Transformer autoencoder, and classifier modules."""

import torch
import pytest

from graphids.gcn import GCN, GCNLayer
from graphids.transformer import TransformerAutoencoder
from graphids.contrastive import Classifier, ContrastiveLoss


# --------------------------------------------------------------------------- #
# GCN
# --------------------------------------------------------------------------- #
def test_gcn_output_shape():
    gcn = GCN(in_features=41, hidden_dim=64, n_layers=3)
    A = torch.eye(10)
    X = torch.randn(10, 41)
    out = gcn(A, X)
    assert out.shape == (10, 64)


def test_gcn_single_layer():
    gcn = GCN(in_features=5, hidden_dim=8, n_layers=1)
    A = torch.eye(4)
    X = torch.randn(4, 5)
    out = gcn(A, X)
    assert out.shape == (4, 8)


def test_gcn_out_dim_property():
    gcn = GCN(in_features=10, hidden_dim=32)
    assert gcn.out_dim == 32


def test_gcn_gradient_flows():
    gcn = GCN(in_features=5, hidden_dim=8)
    A = torch.eye(3)
    X = torch.randn(3, 5)
    out = gcn(A, X)
    loss = out.sum()
    loss.backward()
    for p in gcn.parameters():
        assert p.grad is not None


# --------------------------------------------------------------------------- #
# Transformer autoencoder
# --------------------------------------------------------------------------- #
def test_ae_output_shape():
    ae = TransformerAutoencoder(d_model=64, n_heads=4, n_layers=2, d_ff=128)
    x = torch.randn(8, 64)
    encoded, reconstructed = ae(x)
    assert encoded.shape == (8, 64)
    assert reconstructed.shape == (8, 64)


def test_ae_loss_finite():
    ae = TransformerAutoencoder(d_model=16, n_heads=2, n_layers=1, d_ff=32)
    x = torch.randn(5, 16)
    encoded, reconstructed = ae(x)
    loss = ae.loss(x, encoded, reconstructed)
    assert torch.isfinite(loss)
    assert loss.item() > 0


def test_ae_3d_input():
    ae = TransformerAutoencoder(d_model=16, n_heads=2, n_layers=1, d_ff=32)
    x = torch.randn(4, 3, 16)  # batch=4, seq=3, d=16
    encoded, reconstructed = ae(x)
    assert encoded.shape == (4, 3, 16)


# --------------------------------------------------------------------------- #
# Contrastive loss
# --------------------------------------------------------------------------- #
def test_contrastive_loss_finite():
    cl = ContrastiveLoss()
    embeddings = torch.randn(16, 32)
    labels = torch.tensor([0, 0, 1, 1, 2, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0])
    loss = cl(embeddings, labels)
    assert torch.isfinite(loss)


def test_contrastive_loss_lower_for_good_embeddings():
    """Embeddings that already cluster by class should produce lower loss
    than random embeddings."""
    cl = ContrastiveLoss()
    labels = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])

    # Good: each class is a tight cluster far from others
    good = torch.zeros(9, 8)
    good[:3, :3] = 5.0
    good[3:6, 3:6] = 5.0
    good[6:, 6:] = 5.0
    good += torch.randn_like(good) * 0.1

    # Bad: random
    bad = torch.randn(9, 8)

    loss_good = cl(good, labels)
    loss_bad = cl(bad, labels)
    assert loss_good < loss_bad


# --------------------------------------------------------------------------- #
# Classifier
# --------------------------------------------------------------------------- #
def test_classifier_output_shape():
    clf = Classifier(d_in=64, n_classes=5, hidden_dim=128)
    x = torch.randn(10, 64)
    logits = clf(x)
    assert logits.shape == (10, 5)


def test_classifier_loss_finite():
    clf = Classifier(d_in=32, n_classes=3, hidden_dim=64)
    embeddings = torch.randn(8, 32)
    logits = clf(embeddings)
    labels = torch.tensor([0, 1, 2, 0, 1, 2, 0, 1])
    loss = clf.loss(embeddings, logits, labels)
    assert torch.isfinite(loss)
    assert loss.item() > 0


def test_classifier_gradient_flows():
    clf = Classifier(d_in=16, n_classes=3)
    x = torch.randn(6, 16)
    logits = clf(x)
    labels = torch.tensor([0, 1, 2, 0, 1, 2])
    loss = clf.loss(x, logits, labels)
    loss.backward()
    for p in clf.parameters():
        assert p.grad is not None
