"""Tests for graph construction."""

import numpy as np
import torch
import pytest

from graphids.graph import build_adjacency, add_self_loops, symmetric_norm, prepare_graph


def test_adjacency_shape():
    X = np.random.randn(10, 5)
    A = build_adjacency(X)
    assert A.shape == (10, 10)


def test_adjacency_symmetric():
    X = np.random.randn(8, 4)
    A = build_adjacency(X)
    torch.testing.assert_close(A, A.T)


def test_adjacency_non_negative():
    X = np.random.randn(10, 5)
    A = build_adjacency(X)
    assert (A >= 0).all()


def test_adjacency_threshold():
    X = np.random.randn(20, 5)
    A = build_adjacency(X, threshold=0.5)
    assert (A[A > 0] >= 0.5).all()


def test_self_loops_adds_identity():
    A = torch.zeros(3, 3)
    A_hat = add_self_loops(A)
    torch.testing.assert_close(A_hat, torch.eye(3))


def test_symmetric_norm_preserves_shape():
    A = torch.ones(5, 5)
    A_norm = symmetric_norm(A)
    assert A_norm.shape == (5, 5)


def test_symmetric_norm_row_sums():
    """For a uniform adjacency (all ones), the normalized version should
    have rows summing to 1."""
    N = 5
    A = torch.ones(N, N)
    A_norm = symmetric_norm(A)
    row_sums = A_norm.sum(dim=1)
    torch.testing.assert_close(row_sums, torch.ones(N), atol=1e-6, rtol=0)


def test_prepare_graph_returns_correct_types():
    X = np.random.randn(10, 5).astype(np.float32)
    A_norm, X_tensor = prepare_graph(X)
    assert isinstance(A_norm, torch.Tensor)
    assert isinstance(X_tensor, torch.Tensor)
    assert A_norm.shape == (10, 10)
    assert X_tensor.shape == (10, 5)


def test_identical_rows_have_max_similarity():
    X = np.ones((3, 4))  # all identical rows
    A = build_adjacency(X)
    # Cosine similarity of identical vectors is 1.0
    assert A.min().item() >= 0.99
