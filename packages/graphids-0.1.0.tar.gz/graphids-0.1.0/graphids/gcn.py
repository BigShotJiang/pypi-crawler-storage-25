"""Three-layer Graph Convolutional Network for structural feature extraction.

Implemented in pure PyTorch — no dependency on torch-geometric. The GCN
update rule at each layer is:

    H^{l+1} = sigma( A_norm @ H^l @ W^l )

where A_norm is the symmetrically normalized adjacency with self-loops
(precomputed by ``graph.prepare_graph``), H^l is the node feature matrix
at layer l, W^l is a learnable weight matrix, and sigma is ReLU.

Three layers means the receptive field covers 2-hop neighborhoods — enough
to detect patterns like lateral movement (A -> B -> C) without the
oversmoothing that degrades embeddings at higher layer counts.
"""

from __future__ import annotations

import torch
import torch.nn as nn


class GCNLayer(nn.Module):
    """Single GCN convolutional layer."""

    def __init__(self, in_features: int, out_features: int, dropout: float = 0.3):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(in_features, out_features))
        nn.init.xavier_uniform_(self.weight)
        self.norm = nn.LayerNorm(out_features)
        self.dropout = nn.Dropout(dropout)

    def forward(self, A_norm: torch.Tensor, H: torch.Tensor) -> torch.Tensor:
        """Forward pass: A_norm @ H @ W, then LayerNorm, ReLU, dropout."""
        out = A_norm @ H @ self.weight
        out = self.norm(out)
        out = torch.relu(out)
        out = self.dropout(out)
        return out


class GCN(nn.Module):
    """Three-layer GCN for node embedding extraction.

    Parameters
    ----------
    in_features
        Dimensionality of the input node features (e.g. 41 for NSL-KDD).
    hidden_dim
        Number of neurons per GCN layer. Paper uses 64.
    n_layers
        Number of GCN layers. Paper uses 3.
    dropout
        Dropout rate. Paper uses 0.3.
    """

    def __init__(
        self,
        in_features: int,
        hidden_dim: int = 64,
        n_layers: int = 3,
        dropout: float = 0.3,
    ):
        super().__init__()
        layers = []
        for i in range(n_layers):
            d_in = in_features if i == 0 else hidden_dim
            layers.append(GCNLayer(d_in, hidden_dim, dropout=dropout))
        self.layers = nn.ModuleList(layers)

    @property
    def out_dim(self) -> int:
        return self.layers[-1].weight.size(1)

    def forward(self, A_norm: torch.Tensor, X: torch.Tensor) -> torch.Tensor:
        """Extract node embeddings.

        Parameters
        ----------
        A_norm
            Normalized adjacency matrix ``(N, N)``.
        X
            Node feature matrix ``(N, d_in)``.

        Returns
        -------
        torch.Tensor
            Node embeddings ``(N, hidden_dim)``.
        """
        H = X
        for layer in self.layers:
            H = layer(A_norm, H)
        return H
