"""Graph-based Intrusion Detection System (GraphIDS).

A modular cloud intrusion detection framework combining GCN feature extraction,
Transformer-based autoencoding, and contrastive learning. Reference implementation
of the framework introduced in:

    Govindarajan, V. & Muzamal, J. H. (2025). Advanced cloud intrusion detection
    framework using graph based features transformers and contrastive learning.
    Scientific Reports, 15, 20511. DOI: 10.1038/s41598-025-07956-w
"""

__version__ = "0.1.0"
