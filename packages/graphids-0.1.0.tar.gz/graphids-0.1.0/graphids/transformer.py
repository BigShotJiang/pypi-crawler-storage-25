"""Transformer-based autoencoder for embedding refinement.

Takes the GCN node embeddings and refines them through a self-attention
encoder-decoder. The encoder identifies which dimensions of the embedding
are informative for distinguishing attack types; the decoder ensures the
representation retains enough information to reconstruct the original
embeddings (preventing information collapse).

The training loss combines reconstruction error (MSE) and a KL divergence
regularization term that keeps the latent distribution smooth. This pushes
the autoencoder toward a compact representation where similar traffic types
cluster together in the latent space.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class TransformerAutoencoder(nn.Module):
    """Encoder-decoder Transformer autoencoder.

    Parameters
    ----------
    d_model
        Dimensionality of the input embeddings (should match GCN output dim).
    n_heads
        Number of attention heads. Paper uses 4.
    n_layers
        Number of self-attention layers in both encoder and decoder.
        Paper uses 2.
    d_ff
        Feed-forward layer dimensionality. Paper uses 128.
    dropout
        Dropout rate. Paper uses 0.2.
    alpha
        Weight for the KL regularization term. Controls the tradeoff between
        faithful reconstruction and smooth latent space.
    """

    def __init__(
        self,
        d_model: int = 64,
        n_heads: int = 4,
        n_layers: int = 2,
        d_ff: int = 128,
        dropout: float = 0.2,
        alpha: float = 0.001,
    ):
        super().__init__()
        self.alpha = alpha
        self.d_model = d_model

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=n_layers)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Encode and reconstruct.

        Parameters
        ----------
        x
            Input embeddings ``(batch, d_model)`` or ``(batch, seq, d_model)``.

        Returns
        -------
        encoded
            Refined embeddings from the encoder.
        reconstructed
            Decoder's reconstruction of the input.
        """
        # Add a sequence dimension if input is 2D (treating each sample as
        # a length-1 sequence). This is the common case when the GCN
        # produces one embedding per node.
        squeeze = False
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (batch, 1, d_model)
            squeeze = True

        encoded = self.encoder(x)
        reconstructed = self.decoder(encoded, encoded)

        if squeeze:
            encoded = encoded.squeeze(1)
            reconstructed = reconstructed.squeeze(1)

        return encoded, reconstructed

    def loss(self, x: torch.Tensor, encoded: torch.Tensor, reconstructed: torch.Tensor) -> torch.Tensor:
        """Combined reconstruction + KL regularization loss.

        L = L_recon + alpha * L_reg
        L_recon = (1/n) * sum ||x - x_hat||^2
        L_reg = (1/n) * sum KL(softmax(x) || softmax(x_hat))
        """
        # Reconstruction loss (MSE)
        recon_loss = F.mse_loss(reconstructed, x)

        # KL divergence regularization between input and reconstruction
        # distributions (applied over the feature dimension via softmax)
        log_p = F.log_softmax(x, dim=-1)
        q = F.softmax(reconstructed.detach(), dim=-1)
        kl_loss = F.kl_div(log_p, q, reduction="batchmean")

        return recon_loss + self.alpha * kl_loss
