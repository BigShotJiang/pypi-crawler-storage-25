"""End-to-end GraphIDS pipeline: GCN → Transformer AE → Contrastive Classifier.

This module wires the three stages together into a single trainable pipeline.
Each stage can be trained independently (following the paper's training
protocol) or jointly fine-tuned.

Training protocol from the paper:
    1. Build the graph and train the GCN (Adam, lr=0.001, batch=128, 50 epochs)
    2. Feed GCN embeddings to the Transformer AE and train it
       (AdamW, lr=0.0001, batch=64, 100 epochs)
    3. Feed refined embeddings to the classifier with contrastive loss
       (RMSprop, lr=0.0005, batch=256, 50 epochs)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import MinMaxScaler, LabelEncoder

from .graph import prepare_graph
from .gcn import GCN
from .transformer import TransformerAutoencoder
from .contrastive import Classifier


@dataclass
class EvalResult:
    """Evaluation metrics from a prediction run."""
    accuracy: float
    precision: float
    recall: float
    f1: float
    predictions: np.ndarray


class GraphIDS(nn.Module):
    """Full intrusion detection pipeline.

    Parameters
    ----------
    n_features
        Number of input features per flow (e.g. 41 for NSL-KDD after encoding).
    n_classes
        Number of output classes (e.g. 5 for NSL-KDD multi-class).
    gcn_hidden
        GCN hidden layer size. Paper uses 64.
    gcn_layers
        Number of GCN layers. Paper uses 3.
    gcn_dropout
        GCN dropout rate. Paper uses 0.3.
    ae_heads
        Number of Transformer attention heads. Paper uses 4.
    ae_layers
        Number of Transformer encoder/decoder layers. Paper uses 2.
    ae_ff
        Transformer feed-forward dimensionality. Paper uses 128.
    ae_dropout
        Transformer dropout rate. Paper uses 0.2.
    ae_alpha
        KL regularization weight for the autoencoder. Paper uses 0.001.
    clf_hidden
        Classifier hidden layer size. Paper uses 128.
    beta
        Contrastive loss weight. Controls how strongly the contrastive
        term influences classification training.
    """

    def __init__(
        self,
        n_features: int,
        n_classes: int,
        gcn_hidden: int = 64,
        gcn_layers: int = 3,
        gcn_dropout: float = 0.3,
        ae_heads: int = 4,
        ae_layers: int = 2,
        ae_ff: int = 128,
        ae_dropout: float = 0.2,
        ae_alpha: float = 0.001,
        clf_hidden: int = 128,
        beta: float = 0.5,
    ):
        super().__init__()
        self.gcn = GCN(
            in_features=n_features,
            hidden_dim=gcn_hidden,
            n_layers=gcn_layers,
            dropout=gcn_dropout,
        )
        self.autoencoder = TransformerAutoencoder(
            d_model=gcn_hidden,
            n_heads=ae_heads,
            n_layers=ae_layers,
            d_ff=ae_ff,
            dropout=ae_dropout,
            alpha=ae_alpha,
        )
        self.classifier = Classifier(
            d_in=gcn_hidden,
            n_classes=n_classes,
            hidden_dim=clf_hidden,
            beta=beta,
        )
        self.scaler = MinMaxScaler()
        self.label_encoder = LabelEncoder()

    def preprocess(self, X: np.ndarray, y: np.ndarray | None = None, fit: bool = False):
        """Scale features to [0, 1] and encode labels.

        Parameters
        ----------
        X : array (n_samples, n_features)
        y : array (n_samples,), optional
        fit : bool
            If True, fit the scaler and label encoder.

        Returns
        -------
        X_scaled, y_encoded (or None)
        """
        if fit:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = self.scaler.transform(X)

        y_enc = None
        if y is not None:
            if fit:
                y_enc = self.label_encoder.fit_transform(y)
            else:
                y_enc = self.label_encoder.transform(y)

        return X_scaled, y_enc

    def forward(self, A_norm: torch.Tensor, X: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Full forward pass through all three stages.

        Returns
        -------
        gcn_out
            GCN node embeddings.
        refined
            Transformer-refined embeddings.
        logits
            Classification logits.
        """
        gcn_out = self.gcn(A_norm, X)
        refined, reconstructed = self.autoencoder(gcn_out)
        logits = self.classifier(refined)
        return gcn_out, refined, logits

    def train_pipeline(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        gcn_epochs: int = 50,
        ae_epochs: int = 100,
        clf_epochs: int = 50,
        gcn_lr: float = 0.001,
        ae_lr: float = 0.0001,
        clf_lr: float = 0.0005,
        verbose: bool = True,
    ) -> None:
        """Train all three stages sequentially.

        This follows the paper's training protocol: GCN first, then
        autoencoder on frozen GCN embeddings, then classifier on frozen
        refined embeddings.
        """
        X_scaled, y_enc = self.preprocess(X_train, y_train, fit=True)
        A_norm, X_tensor = prepare_graph(X_scaled)
        y_tensor = torch.tensor(y_enc, dtype=torch.long)

        # Stage 1: GCN
        if verbose:
            print("Stage 1: Training GCN...")
        gcn_opt = torch.optim.Adam(self.gcn.parameters(), lr=gcn_lr)
        # Train GCN with a proxy classification objective
        proxy_clf = nn.Linear(self.gcn.out_dim, len(self.label_encoder.classes_))
        proxy_opt = torch.optim.Adam(
            list(self.gcn.parameters()) + list(proxy_clf.parameters()), lr=gcn_lr
        )
        self.gcn.train()
        for epoch in range(gcn_epochs):
            proxy_opt.zero_grad()
            embeddings = self.gcn(A_norm, X_tensor)
            logits = proxy_clf(embeddings)
            loss = nn.functional.cross_entropy(logits, y_tensor)
            loss.backward()
            proxy_opt.step()
            if verbose and (epoch + 1) % 10 == 0:
                print(f"  epoch {epoch+1}/{gcn_epochs}  loss={loss.item():.4f}")
        del proxy_clf, proxy_opt

        # Stage 2: Transformer autoencoder
        if verbose:
            print("Stage 2: Training Transformer autoencoder...")
        ae_opt = torch.optim.AdamW(self.autoencoder.parameters(), lr=ae_lr)
        self.gcn.eval()
        self.autoencoder.train()
        with torch.no_grad():
            gcn_embeddings = self.gcn(A_norm, X_tensor)
        for epoch in range(ae_epochs):
            ae_opt.zero_grad()
            encoded, reconstructed = self.autoencoder(gcn_embeddings)
            loss = self.autoencoder.loss(gcn_embeddings, encoded, reconstructed)
            loss.backward()
            ae_opt.step()
            if verbose and (epoch + 1) % 20 == 0:
                print(f"  epoch {epoch+1}/{ae_epochs}  loss={loss.item():.4f}")

        # Stage 3: Contrastive classifier
        if verbose:
            print("Stage 3: Training contrastive classifier...")
        clf_opt = torch.optim.RMSprop(self.classifier.parameters(), lr=clf_lr)
        self.autoencoder.eval()
        self.classifier.train()
        with torch.no_grad():
            encoded, _ = self.autoencoder(gcn_embeddings)
        for epoch in range(clf_epochs):
            clf_opt.zero_grad()
            logits = self.classifier(encoded)
            loss = self.classifier.loss(encoded, logits, y_tensor)
            loss.backward()
            clf_opt.step()
            if verbose and (epoch + 1) % 10 == 0:
                acc = (logits.argmax(dim=1) == y_tensor).float().mean().item()
                print(f"  epoch {epoch+1}/{clf_epochs}  loss={loss.item():.4f}  acc={acc:.4f}")

        if verbose:
            print("Training complete.")

    @torch.no_grad()
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels for new samples."""
        self.eval()
        X_scaled, _ = self.preprocess(X)
        A_norm, X_tensor = prepare_graph(X_scaled)
        _, refined, logits = self.forward(A_norm, X_tensor)
        preds = logits.argmax(dim=1).cpu().numpy()
        return self.label_encoder.inverse_transform(preds)

    @torch.no_grad()
    def evaluate(self, X: np.ndarray, y: np.ndarray) -> EvalResult:
        """Predict and compute metrics."""
        y_pred = self.predict(X)
        return EvalResult(
            accuracy=accuracy_score(y, y_pred),
            precision=precision_score(y, y_pred, average="weighted", zero_division=0),
            recall=recall_score(y, y_pred, average="weighted", zero_division=0),
            f1=f1_score(y, y_pred, average="weighted", zero_division=0),
            predictions=y_pred,
        )
