"""Graph construction from tabular network traffic data.

Converts flat flow-level feature matrices into graph representations where
nodes are network entities (IPs, ports, services) and edges are weighted by
communication metrics. The adjacency matrix is built from cosine similarity
between node feature vectors, which means structurally similar nodes are
connected more strongly than nodes that merely happen to communicate.
"""

from __future__ import annotations

import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def build_adjacency(X: np.ndarray, threshold: float = 0.0) -> torch.Tensor:
    """Build a cosine-similarity adjacency matrix from a feature matrix.

    Each row of X is treated as a node. The adjacency weight between nodes
    i and j is the cosine similarity of their feature vectors, clipped to
    [0, 1]. A threshold can be applied to sparsify the graph.

    Parameters
    ----------
    X
        Feature matrix with shape ``(n_nodes, n_features)``.
    threshold
        Edges with similarity below this value are set to zero.

    Returns
    -------
    torch.Tensor
        Adjacency matrix of shape ``(n_nodes, n_nodes)``.
    """
    sim = cosine_similarity(X)
    sim = np.clip(sim, 0.0, 1.0)
    if threshold > 0:
        sim[sim < threshold] = 0.0
    return torch.tensor(sim, dtype=torch.float32)


def add_self_loops(A: torch.Tensor) -> torch.Tensor:
    """Add self-loops to the adjacency matrix: Ã = A + I."""
    return A + torch.eye(A.size(0), dtype=A.dtype, device=A.device)


def symmetric_norm(A: torch.Tensor) -> torch.Tensor:
    """Compute the symmetric degree normalization D^{-1/2} A D^{-1/2}.

    This prevents high-degree nodes from dominating neighbor aggregation
    in the GCN. Nodes with zero degree get a zero row/column.
    """
    deg = A.sum(dim=1)
    # D^{-1/2}, guarding against zero-degree nodes
    deg_inv_sqrt = torch.zeros_like(deg)
    nonzero = deg > 0
    deg_inv_sqrt[nonzero] = 1.0 / torch.sqrt(deg[nonzero])
    D_inv_sqrt = torch.diag(deg_inv_sqrt)
    return D_inv_sqrt @ A @ D_inv_sqrt


def prepare_graph(X: np.ndarray, threshold: float = 0.0) -> tuple[torch.Tensor, torch.Tensor]:
    """Full graph preparation: adjacency + normalization.

    Returns the normalized adjacency matrix (ready for GCN forward pass)
    and the node feature tensor.

    Parameters
    ----------
    X
        Feature matrix ``(n_nodes, n_features)``, already scaled.

    Returns
    -------
    A_norm
        Normalized adjacency ``(n_nodes, n_nodes)`` with self-loops.
    X_tensor
        Node features as a float32 tensor ``(n_nodes, n_features)``.
    """
    A = build_adjacency(X, threshold=threshold)
    A_hat = add_self_loops(A)
    A_norm = symmetric_norm(A_hat)
    X_tensor = torch.tensor(X, dtype=torch.float32)
    return A_norm, X_tensor
