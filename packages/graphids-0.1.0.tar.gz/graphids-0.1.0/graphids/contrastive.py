"""Contrastive learning module and classification head.

The contrastive loss improves class separation in the embedding space,
particularly for minority classes (U2R, R2L) that get ignored when training
with cross-entropy alone. It works by pulling same-class embeddings together
and pushing different-class embeddings apart using cosine similarity.

The final classification loss is:
    L_class = L_CE + beta * L_contrastive

The classifier is a two-layer FC network: 128 neurons with ReLU, then
softmax for multi-class prediction.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ContrastiveLoss(nn.Module):
    """Pairwise contrastive loss using cosine similarity.

    For a pair (i, j):
        - If same class (y_ij = 1): L = -log(sim(f_i, f_j))
        - If different class (y_ij = 0): L = -log(1 - sim(f_i, f_j))

    Pairs are sampled within the batch. For efficiency, we compute the
    full pairwise similarity matrix and mask by label equality.

    Parameters
    ----------
    temperature
        Scaling factor for the similarity scores. Lower values sharpen
        the distribution. Default 0.5.
    """

    def __init__(self, temperature: float = 0.5):
        super().__init__()
        self.temperature = temperature

    def forward(self, embeddings: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """Compute the contrastive loss over all pairs in the batch.

        Parameters
        ----------
        embeddings
            Feature embeddings ``(batch, d)``.
        labels
            Integer class labels ``(batch,)``.
        """
        # Normalized embeddings for cosine similarity
        normed = F.normalize(embeddings, p=2, dim=1)
        sim_matrix = (normed @ normed.T) / self.temperature

        # Mask: 1 where labels match, 0 otherwise
        label_eq = labels.unsqueeze(0) == labels.unsqueeze(1)  # (B, B)
        # Exclude self-pairs from the diagonal
        mask_self = ~torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
        positive_mask = label_eq & mask_self
        negative_mask = ~label_eq & mask_self

        # Numerically stable log-sum-exp
        # For positive pairs: -log(exp(sim_pos) / sum(exp(sim_all)))
        # This is equivalent to the supervised contrastive loss formulation
        exp_sim = torch.exp(sim_matrix) * mask_self.float()
        log_sum_exp = torch.log(exp_sim.sum(dim=1) + 1e-8)

        # Mean of positive log-similarities
        pos_sim = (sim_matrix * positive_mask.float()).sum(dim=1)
        n_pos = positive_mask.float().sum(dim=1).clamp(min=1)
        mean_pos_sim = pos_sim / n_pos

        loss = (-mean_pos_sim + log_sum_exp).mean()
        return loss


class Classifier(nn.Module):
    """Two-layer FC classifier with contrastive-augmented training.

    Parameters
    ----------
    d_in
        Input embedding dimensionality (should match encoder output).
    n_classes
        Number of output classes.
    hidden_dim
        Hidden layer size. Paper uses 128.
    beta
        Weight of the contrastive loss relative to cross-entropy.
    """

    def __init__(
        self,
        d_in: int,
        n_classes: int,
        hidden_dim: int = 128,
        beta: float = 0.5,
    ):
        super().__init__()
        self.fc1 = nn.Linear(d_in, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, n_classes)
        self.dropout = nn.Dropout(0.2)
        self.beta = beta
        self.contrastive_loss = ContrastiveLoss()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Predict class logits."""
        h = self.dropout(torch.relu(self.fc1(x)))
        return self.fc2(h)

    def loss(self, embeddings: torch.Tensor, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """Combined cross-entropy + beta * contrastive loss.

        Parameters
        ----------
        embeddings
            The refined feature embeddings (used for contrastive loss).
        logits
            Output of forward() (used for cross-entropy).
        labels
            Ground-truth integer labels.
        """
        ce_loss = F.cross_entropy(logits, labels)
        cl_loss = self.contrastive_loss(embeddings, labels)
        return ce_loss + self.beta * cl_loss
