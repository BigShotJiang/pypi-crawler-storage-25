"""Tests for the grootboekrekeningen resource."""

from __future__ import annotations

from decimal import Decimal

import pytest
import responses

from mboek._exceptions import MboekError
from mboek.models._enums import DagboekType, RekeningCategorie, RekeningType
from tests.conftest import BASE_URL, GROOTBOEKREKENING


def test_list(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    items = client.administratie(1).grootboekrekeningen.list()
    assert len(items) == 1
    assert items[0].code == 1220
    assert items[0].rekening_type == RekeningType.ACTIVA
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if c.request.url.startswith(
            f"{BASE_URL}/api/administraties/1/grootboekrekeningen"
        )
        and "met-saldo" not in c.request.url
        and "mutaties" not in c.request.url
    ]
    assert "limit=1000" in gbr_calls[-1].request.url
    assert "offset=0" in gbr_calls[-1].request.url


def test_get(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    item = client.administratie(1).grootboekrekeningen.get(30)
    assert item.naam == "Bank"


def test_create(mocked_responses, client):
    mocked_responses.add(
        responses.POST,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=GROOTBOEKREKENING,
        status=201,
    )
    item = client.administratie(1).grootboekrekeningen.create(
        code=1220,
        naam="Bank",
        rekening_type=RekeningType.ACTIVA,
        categorie=RekeningCategorie.BALANS,
    )
    assert item.id == 30


def test_seed_rgs(mocked_responses, client):
    mocked_responses.add(
        responses.POST,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/seed-rgs",
        status=204,
    )
    client.administratie(1).grootboekrekeningen.seed_rgs()  # should not raise


def test_met_saldo(mocked_responses, client):
    data = [{"rekening": GROOTBOEKREKENING, "aantal_transacties": 5, "saldo": 100000}]
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=data,
    )
    items = client.administratie(1).grootboekrekeningen.met_saldo(10)
    assert items[0].saldo == Decimal("1000.00")  # 100000 cents → €1000.00
    saldo_calls = [c for c in mocked_responses.calls if "met-saldo" in c.request.url]
    assert "limit=1000" in saldo_calls[-1].request.url
    assert "offset=0" in saldo_calls[-1].request.url


@pytest.mark.parametrize("missing_key", ["saldo", "aantal_transacties"])
def test_met_saldo_requires_top_level_fields(mocked_responses, client, missing_key):
    payload = {"rekening": GROOTBOEKREKENING, "aantal_transacties": 5, "saldo": 100000}
    payload.pop(missing_key)
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[payload],
    )

    with pytest.raises(ValueError, match=missing_key):
        client.administratie(1).grootboekrekeningen.met_saldo(10)


def test_mutaties(mocked_responses, client):
    mutatie = {
        "regel_id": 1,
        "boeking_id": 100,
        "dagboek_id": 20,
        "dagboek_type": "beginbalans",
        "datum": "2024-01-15",
        "dagboek_code": "BANK",
        "dagboek_naam": "Bankboek",
        "boeking_omschrijving": "Test",
        "regel_omschrijving": "Regel",
        "bedrag": -10000,
    }
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30/mutaties",
        json=[mutatie],
    )
    items = client.administratie(1).grootboekrekeningen.mutaties(30, 10)
    from decimal import Decimal

    assert items[0].bedrag == Decimal("-100.00")
    assert items[0].dagboek_type == DagboekType.BEGINBALANS
    mutatie_calls = [c for c in mocked_responses.calls if "mutaties" in c.request.url]
    assert "boekjaar_id=10" in mutatie_calls[-1].request.url
    assert "limit=1000" in mutatie_calls[-1].request.url
    assert "offset=0" in mutatie_calls[-1].request.url


def test_list_filters_auto_paginate(mocked_responses, client):
    first_page = [
        {
            **GROOTBOEKREKENING,
            "id": i + 1,
            "code": 1000 + i,
            "naam": f"Rekening {i + 1}",
        }
        for i in range(1000)
    ]
    target = {**GROOTBOEKREKENING, "id": 2001, "code": 9999, "naam": "Target"}
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=first_page,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[target],
    )

    items = client.administratie(1).grootboekrekeningen.list(code=9999, refresh=True)

    assert len(items) == 1
    assert items[0].id == 2001
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if c.request.url.startswith(
            f"{BASE_URL}/api/administraties/1/grootboekrekeningen"
        )
        and "met-saldo" not in c.request.url
        and "mutaties" not in c.request.url
    ]
    assert len(gbr_calls) == 2
    assert "offset=1000" in gbr_calls[1].request.url


def test_list_filters(mocked_responses, client):
    other = {**GROOTBOEKREKENING, "id": 31, "code": 4000, "naam": "Kosten"}
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING, other],
    )
    by_name = client.administratie(1).grootboekrekeningen.list(name="Bank")
    assert len(by_name) == 1
    assert by_name[0].id == 30

    by_code = client.administratie(1).grootboekrekeningen.list(code=4000)
    assert len(by_code) == 1
    assert by_code[0].naam == "Kosten"

    by_id = client.administratie(1).grootboekrekeningen.list(id=31)
    assert len(by_id) == 1
    assert by_id[0].code == 4000


def test_list_filters_not_found(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    assert client.administratie(1).grootboekrekeningen.list(name="Kas") == []
    assert client.administratie(1).grootboekrekeningen.list(code=9999) == []


# ── Cache tests ───────────────────────────────────────────────────────────────


def test_list_cached(mocked_responses, client):
    """list() is served from cache on the second call; only one HTTP request is made."""
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    gbr = client.administratie(1).grootboekrekeningen
    first = gbr.list()
    second = gbr.list()
    assert first == second
    # Only one HTTP call despite two list() calls
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 1


def test_list_cache_is_isolated_from_caller_mutation(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    gbr = client.administratie(1).grootboekrekeningen
    first = gbr.list()
    first[0].naam = "Mutated"

    second = gbr.list()

    assert first[0].naam == "Mutated"
    assert second[0].naam == "Bank"
    assert first[0] is not second[0]


def test_list_refresh_bypasses_cache(mocked_responses, client):
    """list(refresh=True) bypasses the cache and fetches fresh data."""
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.list(refresh=True)
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 2


def test_clear_cache(mocked_responses, client):
    """clear_cache() causes the next list() to fetch fresh data."""
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.clear_cache()
    gbr.list()
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 2


def test_list_filters_use_cache(mocked_responses, client):
    """Filtered list() calls share the same cached list."""
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    gbr = client.administratie(1).grootboekrekeningen
    r1 = gbr.list(name="Bank")
    r2 = gbr.list(code=1220)
    assert len(r1) == 1
    assert len(r2) == 1
    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 1


def test_create_invalidates_cache(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.POST,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=GROOTBOEKREKENING,
        status=201,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )

    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.create(
        code=1220,
        naam="Bank",
        rekening_type=RekeningType.ACTIVA,
        categorie=RekeningCategorie.BALANS,
    )
    gbr.list()

    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 3


def test_update_invalidates_cache(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.PATCH,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )

    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.update(30, naam="Bank")
    gbr.list()

    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 3


def test_delete_invalidates_cache(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.DELETE,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        status=204,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )

    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.delete(30)
    gbr.list()

    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 3


def test_seed_rgs_invalidates_cache(mocked_responses, client):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )
    mocked_responses.add(
        responses.POST,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/seed-rgs",
        status=204,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING],
    )

    gbr = client.administratie(1).grootboekrekeningen
    gbr.list()
    gbr.seed_rgs()
    gbr.list()

    gbr_calls = [
        c
        for c in mocked_responses.calls
        if "grootboekrekeningen" in c.request.url and "met-saldo" not in c.request.url
    ]
    assert len(gbr_calls) == 3


# ── Unified domain object tests ───────────────────────────────────────────────


def test_grootboekrekening_saldo_scope_error(mocked_responses, client):
    """Accessing saldo without boekjaar scope raises ScopeError."""
    from mboek._exceptions import ScopeError

    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    gbr = client.administratie(1).grootboekrekeningen.get(30)
    try:
        _ = gbr.saldo
        assert False
    except ScopeError:
        pass


def test_grootboekrekening_with_boekjaar(mocked_responses, client):
    """with_boekjaar() sets scope; without_boekjaar() removes it."""
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    gbr = client.administratie(1).grootboekrekeningen.get(30)
    scoped = gbr.with_boekjaar(id=10)
    assert scoped is not gbr
    assert scoped._boekjaar_id == 10
    assert gbr._boekjaar_id is None

    unscoped = scoped.without_boekjaar()
    assert unscoped._boekjaar_id is None


def test_grootboekrekening_lazy_saldo(mocked_responses, client):
    """saldo is lazily fetched via met-saldo when boekjaar scope is set."""
    from decimal import Decimal

    data = [{"rekening": GROOTBOEKREKENING, "aantal_transacties": 2, "saldo": 50000}]
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=data,
    )
    gbr = client.administratie(1).grootboekrekeningen.get(30)
    scoped = gbr.with_boekjaar(id=10)
    assert scoped.saldo == Decimal("500.00")
    # Second access is cached — no additional HTTP call
    assert scoped.saldo == Decimal("500.00")
    saldo_calls = [c for c in mocked_responses.calls if "met-saldo" in c.request.url]
    assert len(saldo_calls) == 1


def test_grootboekrekening_lazy_saldo_is_shared_across_siblings(
    mocked_responses, client
):
    other = {**GROOTBOEKREKENING, "id": 31, "code": 4000, "naam": "Kosten"}
    data = [
        {"rekening": GROOTBOEKREKENING, "aantal_transacties": 2, "saldo": 50000},
        {"rekening": other, "aantal_transacties": 3, "saldo": 12500},
    ]
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen",
        json=[GROOTBOEKREKENING, other],
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=data,
    )

    rekeningen = client.administratie(1).grootboekrekeningen.list()
    bank = rekeningen[0].with_boekjaar(id=10)
    kosten = rekeningen[1].with_boekjaar(id=10)

    assert bank.saldo == Decimal("500.00")
    assert kosten.saldo == Decimal("125.00")
    saldo_calls = [c for c in mocked_responses.calls if "met-saldo" in c.request.url]
    assert len(saldo_calls) == 1


def test_grootboekrekening_lazy_saldo_refreshes_after_resource_cache_clear(
    mocked_responses, client
):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 2, "saldo": 50000}],
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 3, "saldo": 75000}],
    )

    resource = client.administratie(1).grootboekrekeningen
    scoped = resource.get(30).with_boekjaar(id=10)

    assert scoped.saldo == Decimal("500.00")

    resource.clear_cache()

    assert scoped.saldo == Decimal("750.00")
    assert scoped.aantal_transacties == 3


def test_grootboekrekening_with_boekjaar_does_not_reuse_stale_snapshot_after_client_clear(
    mocked_responses, client
):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 2, "saldo": 50000}],
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 4, "saldo": 62500}],
    )

    gbr = client.administratie(1).grootboekrekeningen.get(30)
    scoped = gbr.with_boekjaar(id=10)

    assert scoped.saldo == Decimal("500.00")

    client._clear_client_caches()

    refreshed = gbr.with_boekjaar(id=10)
    assert refreshed.saldo == Decimal("625.00")
    assert scoped.saldo == Decimal("625.00")


def test_grootboekrekening_lazy_saldo_refreshes_after_successful_write(
    mocked_responses, client
):
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 2, "saldo": 50000}],
    )
    mocked_responses.add(
        responses.PATCH,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=[{"rekening": GROOTBOEKREKENING, "aantal_transacties": 5, "saldo": 88000}],
    )

    scoped = client.administratie(1).grootboekrekeningen.get(30).with_boekjaar(id=10)

    assert scoped.saldo == Decimal("500.00")

    client.administratie(1).grootboekrekeningen.update(30, naam="Bank")

    assert scoped.saldo == Decimal("880.00")
    assert scoped.aantal_transacties == 5


def test_grootboekrekening_lazy_saldo_missing_match_raises(mocked_responses, client):
    other = {**GROOTBOEKREKENING, "id": 31, "code": 4000, "naam": "Kosten"}
    data = [{"rekening": other, "aantal_transacties": 2, "saldo": 50000}]
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/met-saldo/10",
        json=data,
    )
    gbr = client.administratie(1).grootboekrekeningen.get(30)
    scoped = gbr.with_boekjaar(id=10)

    with pytest.raises(
        MboekError, match="did not return grootboekrekening 30"
    ) as exc_info:
        _ = scoped.saldo

    assert exc_info.value.detail == {
        "administratie_id": 1,
        "boekjaar_id": 10,
        "grootboekrekening_id": 30,
        "returned_grootboekrekening_ids": [31],
    }


def test_grootboekrekening_with_boekjaar_name_requires_single_match(
    mocked_responses, client
):
    from tests.conftest import BOEKJAAR

    duplicate = {**BOEKJAAR, "id": 11}
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/grootboekrekeningen/30",
        json=GROOTBOEKREKENING,
    )
    mocked_responses.add(
        responses.GET,
        f"{BASE_URL}/api/administraties/1/boekjaren",
        json=[BOEKJAAR, duplicate],
    )
    gbr = client.administratie(1).grootboekrekeningen.get(30)
    try:
        gbr.with_boekjaar(name="2024")
        assert False
    except ValueError as e:
        assert "2024" in str(e)
