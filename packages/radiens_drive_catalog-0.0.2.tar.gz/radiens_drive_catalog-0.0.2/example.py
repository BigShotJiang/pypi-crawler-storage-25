from pprint import pprint

from radiens_drive_catalog import Catalog, Config

config = Config.from_file()
catalog = Catalog(config)

# # Scan Drive and build the catalog
catalog.scan()

# Query datasets
catalog.list()  # everything
catalog.list(date="2026-02-15_batch")  # all datasets in a date folder
catalog.list(date="2026-02-15_batch", experiment="reaching")  # narrowed to an experiment

# # Access the raw DataFrame
pprint(catalog.df)

# # Check what's available locally
pprint(catalog.status())

# # Download a dataset
catalog.download("rat01_session3")

# Get the local path, downloading automatically if needed
path = catalog.get_path("rat01_session3")
