# radiens-drive-catalog

A Python package for programmatically managing large neural datasets stored on Google Drive. It handles Drive scanning, local cataloging, and selective dataset download — analysis itself is done locally.

Neural data is stored as xdat filesets (NeuroNexus format) on a shared Google Drive. Each dataset consists of three files sharing a common `base_name`:

```
{base_name}_data.xdat
{base_name}.xdat.json
{base_name}_timestamp.xdat
```

The package scans the Drive hierarchy, builds a local catalog indexed by `base_name`, and lets you query and download datasets selectively. Non-xdat content found alongside datasets — logs directories, PowerPoints, writeups — is also discovered and tracked as **assets**.

---

## Quick Start

```python
from radiens_drive_catalog import Catalog, Config

config = Config.from_file("config.json")
catalog = Catalog(config)

catalog.scan()                                       # scan Drive — finds datasets and assets
df = catalog.list(date_folder="2026-02-15_batch")    # query datasets by date folder
path = catalog.get_path("rat01_s3")                  # download dataset if not already local

# Assets (non-xdat files and folders)
catalog.list_assets(experiment="reaching")                           # query assets
path = catalog.get_asset_path("2026-02-15_batch/reaching", "logs")  # download if needed
```

---

## What's in this site

- **[Configuration](configuration.md)** — Config file format, path expansion, service account setup
- **[Usage Guide](usage.md)** — Scanning, querying, downloading, and working with the DataFrame
- **API Reference** — Full auto-generated API docs (see nav above)
- **[Contributing](contributing.md)** — Development setup and quality checks
- **[Changelog](changelog.md)** — Version history
