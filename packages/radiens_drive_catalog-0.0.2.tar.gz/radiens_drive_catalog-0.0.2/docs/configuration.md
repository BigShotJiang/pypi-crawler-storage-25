# Configuration

## Config file format

The package is configured via a JSON file with four fields:

```json
{
    "credentials_path": "/path/to/service_account.json",
    "root_folder_id": "1aBcDeFgHiJkLmNoPqRsTuVw",
    "local_data_dir": "/data/neural",
    "catalog_path": "/data/neural/catalog.json"
}
```

| Field | Type | Description |
|---|---|---|
| `credentials_path` | `str` | Path to the Google service account credentials JSON file |
| `root_folder_id` | `str` | Google Drive folder ID of the root data folder |
| `local_data_dir` | `str` | Local directory where datasets will be downloaded |
| `catalog_path` | `str` | Path to the catalog JSON file (created by `scan()`) |

The `root_folder_id` is the alphanumeric string in the Drive URL when you navigate to the root data folder:
`https://drive.google.com/drive/folders/`**`1aBcDeFgHiJkLmNoPqRsTuVw`**

## Loading config

Pass the config file path explicitly:

```python
config = Config.from_file("/path/to/config.json")
```

Or set the `RADIENS_DRIVE_CATALOG_CONFIG` environment variable and call `from_file()` with no arguments:

```bash
export RADIENS_DRIVE_CATALOG_CONFIG=/path/to/config.json
```

```python
config = Config.from_file()
```

The env var is convenient for notebooks and scripts that shouldn't hard-code a path.

## Path expansion

All path fields (`credentials_path`, `local_data_dir`, `catalog_path`) support:

- `~` — expanded to the current user's home directory
- `$ENV_VAR` — expanded from the environment

```json
{
    "credentials_path": "~/secrets/service_account.json",
    "local_data_dir": "$LAB_DATA/neural",
    "catalog_path": "$LAB_DATA/neural/catalog.json",
    "root_folder_id": "1aBcDeFgHiJkLmNoPqRsTuVw"
}
```

Paths are resolved to absolute paths when the `Config` object is created.

## Service account setup

This package uses a Google service account so all collaborators share the same credentials without needing individual Google accounts.

1. Create a project in [Google Cloud Console](https://console.cloud.google.com)
2. Enable the **Google Drive API** for the project
3. Create a **Service Account** under *IAM & Admin → Service Accounts*
4. Generate a JSON key for the service account and download it
5. Share your root Drive data folder with the service account's email address (Viewer access is sufficient)
6. Set `credentials_path` in your config to point at the downloaded JSON file

## Security

!!! warning
    The credentials JSON file grants read access to any Drive folder shared with the service account. Treat it like a password.

- Do **not** commit the credentials file to version control
- Add it to `.gitignore`:
  ```
  service_account.json
  *_credentials.json
  ```
- Distribute it to collaborators via a secure channel (e.g. an encrypted password manager or a private shared folder)
