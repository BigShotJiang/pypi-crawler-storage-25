# Contributing

## Development setup

This project uses [`uv`](https://docs.astral.sh/uv/) for dependency management.

```bash
git clone <repo-url>
cd radiens-drive-catalog
uv sync --dev
```

## Running quality checks

All checks are bundled into a single script:

```bash
./scripts/check.sh
```

This runs (in order):

1. `ruff check` — linting
2. `ruff format --check` — formatting
3. `mypy --strict` — type checking
4. `pytest tests/unit/ -v` — unit tests with coverage

The script exits with status `1` if any step fails and prints a pass/fail summary at the end. All checks must pass before a PR is merged.

To auto-fix ruff issues:

```bash
./scripts/check-fix.sh
```

## Test structure

```
tests/unit/
    conftest.py        # shared fixtures (Config, DatasetEntry, mock Drive service)
    test_config.py     # Config dataclass and Config.from_file()
    test_drive.py      # drive scanning and download functions
    test_catalog.py    # Catalog class (all public methods)
```

All Drive API calls are mocked — no real credentials or network access needed to run the tests.

## Code style

- **Line length**: 120 characters
- **Formatter**: `ruff format`
- **Linter**: `ruff check` (pycodestyle, pyflakes, isort, bugbear, simplify, and more)
- **Docstrings**: Google style (as configured in `mkdocs.yml` for API reference generation)
- **Type annotations**: Required everywhere; `mypy --strict` must pass

## Building docs locally

```bash
uv sync --group docs
uv run --group docs mkdocs serve
```

Then open `http://127.0.0.1:8000`.
