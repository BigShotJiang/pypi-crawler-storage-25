#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

RED='\033[0;31m'
GREEN='\033[0;32m'
BOLD='\033[1m'
RESET='\033[0m'

# Collect arguments to pass through to ruff check
RUFF_ARGS=("$@")

passed=()
failures=()

run_step() {
    local name="$1"
    shift
    printf "${BOLD}── %s ──${RESET} " "$name"
    local output
    if output=$("$@" 2>&1); then
        printf "${GREEN}✓${RESET}\n"
        passed+=("$name")
    else
        printf "${RED}✗${RESET}\n"
        printf "%s\n" "$output"
        failures+=("$name")
    fi
}

run_step "ruff check"   uv run ruff check --fix ${RUFF_ARGS[@]+"${RUFF_ARGS[@]}"}
run_step "ruff format"  uv run ruff format
run_step "mypy"         uv run mypy --strict
run_step "pytest"       uv run pytest tests/unit/ -v

join_arr() { local d=", "; local first=1; for item in "$@"; do [ "$first" -eq 1 ] && first=0 || printf "%s" "$d"; printf "%s" "$item"; done; }

printf "\n${BOLD}── Summary ──${RESET}\n"
if [ ${#passed[@]} -gt 0 ]; then
    printf "${GREEN}Passed: %s${RESET}\n" "$(join_arr "${passed[@]}")"
fi
if [ ${#failures[@]} -gt 0 ]; then
    printf "${RED}Failed: %s${RESET}\n" "$(join_arr "${failures[@]}")"
    exit 1
else
    printf "${GREEN}All checks passed.${RESET}\n"
fi
