# radiens-drive-catalog

A Python package for programmatically managing large neural datasets stored on Google Drive. The package handles Drive scanning, local cataloging, and selective dataset download. Analysis itself is done locally in Python — this package is purely about data management.

## Background

Neural data is stored as xdat filesets (NeuroNexus format) on a shared Google Drive. The Drive hierarchy is irregular: top-level folders are date-prefixed, and within them datasets may be nested 1–3 levels deep inside experiment and sub-experiment folders. There is no structured metadata beyond what can be inferred from folder names and filenames.

Alongside xdat datasets, Drive folders may contain other content — logs directories, PowerPoint slides, writeups, etc. These are tracked as **assets** and managed alongside datasets.

## xdat Dataset Convention

Each dataset consists of exactly 3 files sharing a common `base_name`:

```
{base_name}_data.xdat
{base_name}.xdat.json
{base_name}_timestamp.xdat
```

The `base_name` is the canonical identifier for a dataset throughout this package.

## Drive Folder Structure

The root Drive folder contains date-prefixed folders at depth 1. Within those, nesting is variable:

```
root/
  2026-02-15_experiment_batch/        ← date_folder (always present)
    reaching/                         ← experiment (optional, depth 2)
      probe1/                         ← sub_experiment (optional, depth 3)
        rat01_session3_data.xdat
        rat01_session3.xdat.json
        rat01_session3_timestamp.xdat
      logs/                           ← folder asset (depth 3)
        log_20260215.txt
      notes.pptx                      ← file asset (depth 3)
      rat02_session1_data.xdat        ← data can also live at experiment level
      ...
    rat03_baseline_data.xdat          ← or directly in the date_folder
  2026-03-01_cohort2/
    ...
```

Datasets can appear at any depth. The scanner maps the first two path components to the structured fields `date_folder` and `experiment` (`experiment` is `None` if data sits directly in the date folder). Everything deeper is captured in `drive_path` but is otherwise ignored for querying purposes — the package is intentionally agnostic to nesting beyond the experiment level.

## Architecture

```
src/radiens_drive_catalog/
  config.py    — Config dataclass (credentials path, root folder ID, local data dir, catalog path)
  auth.py      — Builds authenticated Drive API service from a service account credentials file
  drive.py     — Recursive Drive scanner and file downloader; xdat suffix logic and asset detection
  catalog.py   — Catalog class: the main user-facing interface
```

## Catalog Design

The catalog is a JSON file on disk with two top-level keys: `"datasets"` and `"assets"`. Both are loaded into pandas DataFrames at runtime for querying.

**Dataset fields** (`DatasetEntry`):

| Field | Type | Description |
|---|---|---|
| `base_name` | str | Unique dataset identifier |
| `date_folder` | str \| None | Top-level date folder name |
| `experiment` | str \| None | Depth-2 folder name; `None` if data is directly in the date folder |
| `drive_path` | str | Slash-joined path from root to the containing folder |
| `drive_file_ids` | dict[str, str] | Maps `"data"`, `"meta"`, `"timestamp"` to Drive file IDs |
| `local_path` | str \| None | Local directory path if downloaded, else None |

**Asset fields** (`AssetEntry`):

| Field | Type | Description |
|---|---|---|
| `asset_name` | str | File or folder name (e.g. `"logs"`, `"notes.pptx"`) |
| `asset_type` | `"folder"` \| `"file"` | Whether the asset is a directory or a file |
| `date_folder` | str \| None | Top-level date folder name |
| `experiment` | str \| None | Depth-2 folder name; `None` if asset is in the date folder |
| `drive_path` | str | Slash-joined path to the asset's *parent* folder |
| `drive_id` | str | Google Drive ID of this file or folder |
| `mime_type` | str | MIME type as reported by Drive |
| `local_path` | str \| None | Local path if downloaded, else None |

**Catalog JSON format:**

```json
{
  "datasets": [...],
  "assets": [...]
}
```

Legacy catalogs (bare list) are automatically migrated on the next `scan()`.

## Asset Discovery Rules

During `scan_drive()`, non-xdat content is cataloged based on depth from root:

- **Depth 2 files** (directly in a date folder): cataloged as file assets
- **Depth 3 files** (directly in an experiment folder): cataloged as file assets
- **Depth 3 folders** (direct subfolders of an experiment): cataloged as folder assets; also recursed for xdat datasets
- **Depth 4+ content**: recursed for xdat datasets only; not separately cataloged (part of a parent folder asset)

Date folders (depth 1) and experiment folders (depth 2) are never cataloged as assets.

## Local Storage

**Datasets** are stored flat — all 3 files land directly in `local_data_dir`.

**Assets** are stored under `local_data_dir/assets/{drive_path}/{asset_name}`, preserving the experiment hierarchy:

```
local_data_dir/
  rat01_session3_data.xdat          ← dataset (flat)
  rat01_session3.xdat.json          ← dataset (flat)
  assets/
    2026-02-15_batch/
      reaching/
        logs/                       ← folder asset (full subtree downloaded)
          log_20260215.txt
        notes.pptx                  ← file asset
```

## Authentication

Uses a Google service account for collaboration. The credentials JSON file is shared among collaborators and referenced via config. The relevant Drive folder must be shared with the service account's email address.

## Public API

```python
from radiens_drive_catalog import AssetEntry, Catalog, Config

config = Config.from_file("config.json")   # or Config.from_file() to use RADIENS_DRIVE_CATALOG_CONFIG env var
catalog = Catalog(config)

# Datasets
catalog.scan()                             # rebuild catalog from Drive (discovers datasets + assets)
catalog.df                                 # full dataset catalog as a DataFrame
catalog.list(date_folder="2026-02-15_batch")               # datasets in that date folder
catalog.list(date_folder="2026-02-15_batch", experiment="reaching")
catalog.download("rat01_session3")         # download 3 xdat files to local_data_dir
catalog.get_path("rat01_session3")         # local path, downloading if needed
catalog.status()                           # df with extra is_local boolean column

# Assets (non-xdat files and folders)
catalog.assets_df                          # full asset catalog as a DataFrame
catalog.list_assets(date_folder="2026-02-15_batch")        # assets in that date folder
catalog.list_assets(experiment="reaching", asset_type="folder")
catalog.download_asset("2026-02-15_batch/reaching", "logs")   # download to assets subdir
catalog.get_asset_path("2026-02-15_batch/reaching", "logs")   # local path, downloading if needed
```

### Query semantics

`list()` and `list_assets()` accept the same two hierarchical filters: `date_folder` and `experiment`. Both are exact-match filters against the respective catalog columns. Passing only `date_folder` returns everything in that date folder's tree. Passing `experiment` narrows to that experiment. `list_assets()` additionally accepts `asset_type` (`"folder"` or `"file"`).

**Asset identification:** Assets are uniquely identified by `(drive_path, asset_name)`. `drive_path` is the slash-joined path to the *parent* folder (e.g. `"2026-02-15_batch/reaching"`), visible in `assets_df["drive_path"]`. Two `logs/` folders from different experiments have different `drive_path` values.

## Tooling

- Package manager: `uv`
- Type checking: `mypy` (strict mode)
- Linting: `ruff`
- Testing: `pytest`
- Python: `>=3.12`

## Running Checks

Use the bundled check script to run all quality gates in one command:

```bash
./scripts/check.sh
```

What it runs (in order):

- `uv run ruff check`
- `uv run ruff format --check`
- `uv run mypy --strict`
- `uv run pytest tests/unit/ -v`

The script prints a pass/fail summary at the end and exits with status `1` if any step fails.
