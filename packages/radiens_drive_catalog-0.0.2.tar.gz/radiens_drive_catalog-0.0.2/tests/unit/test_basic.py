import radiens_drive_catalog


def test_basic() -> None:
    assert radiens_drive_catalog.__doc__ is not None
