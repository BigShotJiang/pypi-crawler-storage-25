"""Tests for radiens_drive_catalog.config."""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING
from unittest.mock import patch

if TYPE_CHECKING:
    from pathlib import Path

import pytest

from radiens_drive_catalog.config import CONFIG_ENV_VAR, Config


class TestConfigPostInit:
    def test_tilde_expanded_in_credentials_path(self) -> None:
        config = Config(
            credentials_path="~/creds.json",
            root_folder_id="root_id",
            local_data_dir="/tmp/data",
            catalog_path="/tmp/catalog.json",
        )
        assert "~" not in config.credentials_path
        assert os.path.isabs(config.credentials_path)

    def test_tilde_expanded_in_local_data_dir(self) -> None:
        config = Config(
            credentials_path="/tmp/creds.json",
            root_folder_id="root_id",
            local_data_dir="~/data",
            catalog_path="/tmp/catalog.json",
        )
        assert "~" not in config.local_data_dir
        assert os.path.isabs(config.local_data_dir)

    def test_tilde_expanded_in_catalog_path(self) -> None:
        config = Config(
            credentials_path="/tmp/creds.json",
            root_folder_id="root_id",
            local_data_dir="/tmp/data",
            catalog_path="~/catalog.json",
        )
        assert "~" not in config.catalog_path
        assert os.path.isabs(config.catalog_path)

    def test_env_var_expanded_in_credentials_path(self) -> None:
        with patch.dict(os.environ, {"MY_DATA_DIR": "/expanded"}):
            config = Config(
                credentials_path="$MY_DATA_DIR/creds.json",
                root_folder_id="root_id",
                local_data_dir="/tmp/data",
                catalog_path="/tmp/catalog.json",
            )
        assert config.credentials_path == "/expanded/creds.json"

    def test_env_var_expanded_in_local_data_dir(self) -> None:
        with patch.dict(os.environ, {"MY_DATA_DIR": "/expanded"}):
            config = Config(
                credentials_path="/tmp/creds.json",
                root_folder_id="root_id",
                local_data_dir="$MY_DATA_DIR/neural",
                catalog_path="/tmp/catalog.json",
            )
        assert config.local_data_dir == "/expanded/neural"

    def test_all_paths_become_absolute(self) -> None:
        config = Config(
            credentials_path="relative/creds.json",
            root_folder_id="root_id",
            local_data_dir="relative/data",
            catalog_path="relative/catalog.json",
        )
        assert os.path.isabs(config.credentials_path)
        assert os.path.isabs(config.local_data_dir)
        assert os.path.isabs(config.catalog_path)

    def test_root_folder_id_unchanged(self) -> None:
        config = Config(
            credentials_path="/tmp/creds.json",
            root_folder_id="1aBcDeFgHiJkL",
            local_data_dir="/tmp/data",
            catalog_path="/tmp/catalog.json",
        )
        assert config.root_folder_id == "1aBcDeFgHiJkL"


class TestConfigFromFile:
    def _write_config(self, path: Path, **overrides: str) -> dict[str, str]:
        data: dict[str, str] = {
            "credentials_path": "/tmp/creds.json",
            "root_folder_id": "root_folder_id",
            "local_data_dir": "/tmp/data",
            "catalog_path": "/tmp/catalog.json",
        }
        data.update(overrides)
        with open(path, "w") as f:
            json.dump(data, f)
        return data

    def test_explicit_path(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        self._write_config(config_file)
        config = Config.from_file(str(config_file))
        assert config.root_folder_id == "root_folder_id"

    def test_explicit_path_fields_loaded(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        self._write_config(
            config_file,
            credentials_path="/tmp/creds.json",
            root_folder_id="my_root",
            local_data_dir="/tmp/data",
            catalog_path="/tmp/catalog.json",
        )
        config = Config.from_file(str(config_file))
        assert config.root_folder_id == "my_root"

    def test_env_var_fallback(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        self._write_config(config_file)
        with patch.dict(os.environ, {CONFIG_ENV_VAR: str(config_file)}):
            config = Config.from_file()
        assert config.root_folder_id == "root_folder_id"

    def test_no_path_no_env_var_raises(self) -> None:
        env = {k: v for k, v in os.environ.items() if k != CONFIG_ENV_VAR}
        with patch.dict(os.environ, env, clear=True), pytest.raises(ValueError, match=CONFIG_ENV_VAR):
            Config.from_file()

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises((FileNotFoundError, OSError)):
            Config.from_file(str(tmp_path / "nonexistent.json"))

    def test_from_file_applies_path_expansion(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        self._write_config(config_file, credentials_path="~/creds.json")
        config = Config.from_file(str(config_file))
        assert "~" not in config.credentials_path
        assert os.path.isabs(config.credentials_path)
