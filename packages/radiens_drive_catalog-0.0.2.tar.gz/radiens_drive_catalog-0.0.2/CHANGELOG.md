# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- `AssetEntry` TypedDict for non-xdat Drive content (folders like `logs/`,
  PowerPoints, writeups, etc.).
- `scan_drive()` now returns `(datasets, assets)` tuple. Assets are
  auto-discovered during scan: non-xdat files inside date or experiment
  folders become file assets; subfolders of experiment folders become folder
  assets and are still recursed for xdat datasets.
- `download_asset()` in `drive.py` for downloading file or folder assets;
  folder assets are downloaded recursively, mirroring the Drive subtree.
- `Catalog.assets_df` property — full asset catalog as a pandas DataFrame.
- `Catalog.list_assets()` — query assets with optional `date`, `experiment`,
  and `asset_type` filters.
- `Catalog.download_asset(drive_path, asset_name)` — download an asset to
  `local_data_dir/assets/{drive_path}/{asset_name}`.
- `Catalog.get_asset_path(drive_path, asset_name)` — return local path,
  downloading automatically if needed.
- Catalog JSON format changed from a bare list to
  `{"datasets": [...], "assets": [...]}`. Old flat-list catalogs are
  migrated automatically on the next `scan()`.
- `AssetEntry` exported from the top-level package.

## [0.0.1] - 2026-04-02

### Added

- `Config` dataclass with `from_file()` classmethod; supports `~` and `$ENV_VAR`
  expansion in path fields and `RADIENS_DRIVE_CATALOG_CONFIG` env var fallback.
- `build_drive_service()` for authenticating with a Google service account.
- `scan_drive()` for recursive Drive scanning; returns `DatasetEntry` records
  with `date_folder`, `experiment`, `drive_path`, and `drive_file_ids`.
- `download_dataset()` for chunked download of xdat filesets to a local directory.
- `Catalog` class with `scan()`, `df`, `list()`, `download()`, `get_path()`,
  and `status()`.
- MkDocs documentation site with Material theme, auto-generated API reference,
  and versioned deployment via `mike`.
- CI/CD workflows: linting, type checking, tests, docs deployment, and PyPI
  publishing via GitHub Actions.
