"""
auth.py
-------
Service account authentication for the Google Drive API.
"""

from google.oauth2 import service_account
from googleapiclient.discovery import build

from .drive import DriveService

SCOPES: list[str] = ["https://www.googleapis.com/auth/drive.readonly"]


def build_drive_service(credentials_path: str) -> DriveService:
    """Build an authenticated Google Drive API service client.

    Uses a service account credentials file for authentication. The Drive
    folders you want to access must be shared with the service account email
    found in the credentials JSON.

    Args:
        credentials_path: Path to the Google service account credentials JSON
            file.

    Returns:
        An authenticated Drive API service object (read-only scope).
    """
    creds = service_account.Credentials.from_service_account_file(credentials_path, scopes=SCOPES)
    return build("drive", "v3", credentials=creds)
