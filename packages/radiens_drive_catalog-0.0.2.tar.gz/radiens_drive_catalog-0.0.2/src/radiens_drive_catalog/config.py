"""
config.py
---------
Configuration management for radiens-drive-catalog.

Config is loaded from a JSON file. The path to that file can be passed
explicitly or set via the RADIENS_DRIVE_CATALOG_CONFIG environment variable.

Example config JSON:
{
    "credentials_path": "/path/to/service_account.json",
    "root_folder_id": "1aBcDeFgHiJkLmNoPqRsTuVw",
    "local_data_dir": "/data/neural",
    "catalog_path": "/data/neural/catalog.json"
}
"""

import json
import os
from dataclasses import dataclass
from pathlib import Path

CONFIG_ENV_VAR = "RADIENS_DRIVE_CATALOG_CONFIG"


def _resolve_path(path: str) -> str:
    """Expand environment variables and ~ then resolve to an absolute path."""
    return str(Path(os.path.expandvars(path)).expanduser().resolve())


@dataclass
class Config:
    """Configuration for radiens-drive-catalog.

    All path fields (`credentials_path`, `local_data_dir`, `catalog_path`) support
    `~` and `$ENV_VAR` expansion and are resolved to absolute paths on construction.
    Typically created via `Config.from_file()` rather than directly.

    Attributes:
        credentials_path: Path to the Google service account credentials JSON file.
        root_folder_id: Google Drive folder ID of the data root folder.
        local_data_dir: Local directory where datasets will be downloaded.
        catalog_path: Path to the catalog JSON file (created by `Catalog.scan()`).
    """

    credentials_path: str
    root_folder_id: str
    local_data_dir: str
    catalog_path: str

    def __post_init__(self) -> None:
        """Expand ~ and $ENV_VARS in all path fields and resolve to absolute paths."""
        self.credentials_path = _resolve_path(self.credentials_path)
        self.local_data_dir = _resolve_path(self.local_data_dir)
        self.catalog_path = _resolve_path(self.catalog_path)

    @classmethod
    def from_file(cls, path: str | None = None) -> "Config":
        """Load config from a JSON file.

        If `path` is not provided, falls back to the `RADIENS_DRIVE_CATALOG_CONFIG`
        environment variable.

        Args:
            path: Path to the config JSON file. If `None`, the
                `RADIENS_DRIVE_CATALOG_CONFIG` environment variable is used.

        Returns:
            A `Config` instance with all paths expanded and resolved.

        Raises:
            ValueError: If no path is provided and `RADIENS_DRIVE_CATALOG_CONFIG`
                is not set.
            FileNotFoundError: If the config file does not exist.
            json.JSONDecodeError: If the config file is not valid JSON.
            TypeError: If the JSON fields do not match the `Config` field names.
        """
        if path is None:
            path = os.environ.get(CONFIG_ENV_VAR)
            if path is None:
                raise ValueError(
                    f"No config path provided and {CONFIG_ENV_VAR} is not set. "
                    f"Pass a path explicitly or set {CONFIG_ENV_VAR}=/path/to/config.json."
                )
        path = _resolve_path(path)
        with open(path) as f:
            data = json.load(f)
        return cls(**data)
