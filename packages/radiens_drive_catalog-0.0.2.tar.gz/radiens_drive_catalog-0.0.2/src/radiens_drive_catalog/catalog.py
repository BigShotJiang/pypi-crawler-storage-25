"""
catalog.py
----------
The main interface for radiens-drive-catalog. The Catalog class wraps Drive
scanning, local caching, querying, and downloading behind a simple API.

Typical usage:
    from radiens_drive_catalog import Catalog, Config

    config = Config.from_file("config.json")
    catalog = Catalog(config)

    # Build or refresh the catalog from Drive
    catalog.scan()

    # Query datasets
    df = catalog.list(date="2026-02")
    df = catalog.list(date="2026-02", experiment="reaching")

    # Query assets (non-xdat files and folders)
    adf = catalog.list_assets(date="2026-02", experiment="reaching")

    # Get a local path, downloading if needed
    path = catalog.get_path("rat01_2026-02-14_probe1")
    path = catalog.get_asset_path("2026-02-15_batch/reaching", "logs")

    # Download explicitly
    catalog.download("rat01_2026-02-14_probe1")
    catalog.download_asset("2026-02-15_batch/reaching", "logs")

    # Access the raw DataFrames
    catalog.df
    catalog.assets_df
"""

import json
from pathlib import Path
from typing import Literal

import pandas as pd

from .auth import build_drive_service
from .config import Config
from .drive import (
    AssetEntry,
    DatasetEntry,
    DriveService,
    download_dataset,
    scan_drive,
)
from .drive import (
    download_asset as _download_asset_entry,
)


class Catalog:
    """Main interface for radiens-drive-catalog.

    Wraps Google Drive scanning, local JSON catalog management, dataset and
    asset querying, and file download behind a single object.

    Example:
        ```python
        from radiens_drive_catalog import Catalog, Config

        config = Config.from_file("config.json")
        catalog = Catalog(config)

        catalog.scan()                              # build catalog from Drive
        df = catalog.list(date="2026-02")           # query datasets
        adf = catalog.list_assets(experiment="reaching")  # query assets
        path = catalog.get_path("rat01_session3")  # download dataset if needed
        path = catalog.get_asset_path("2026-02-15/reaching", "logs")  # download asset if needed
        ```
    """

    def __init__(self, config: Config) -> None:
        """Initialize a Catalog.

        Args:
            config: Package configuration (Drive credentials, folder ID, local
                paths).
        """
        self.config = config
        self._service: DriveService | None = None  # lazy-initialized Drive client
        self._df: pd.DataFrame | None = None  # in-memory cache for datasets
        self._assets_df: pd.DataFrame | None = None  # in-memory cache for assets

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _drive(self) -> DriveService:
        """Lazy-initialize the Drive API service."""
        if self._service is None:
            self._service = build_drive_service(self.config.credentials_path)
        return self._service

    def _invalidate_cache(self) -> None:
        self._df = None
        self._assets_df = None

    def _load_catalog(self) -> tuple[list[DatasetEntry], list[AssetEntry]]:
        """Read the catalog JSON from disk.

        Supports both the current format (``{"datasets": [...], "assets": [...]}``)
        and the legacy format (a bare list of dataset entries). Legacy catalogs
        are treated as having an empty assets list.
        """
        with open(self.config.catalog_path) as f:
            data = json.load(f)

        # Legacy format: bare list of dataset entries
        if isinstance(data, list):
            datasets_raw = data
            assets_raw: list[object] = []
        elif isinstance(data, dict):
            datasets_raw = data.get("datasets", [])
            assets_raw = data.get("assets", [])
            if not isinstance(datasets_raw, list):
                raise ValueError("Catalog 'datasets' must be a list.")
            if not isinstance(assets_raw, list):
                raise ValueError("Catalog 'assets' must be a list.")
        else:
            raise ValueError("Catalog JSON must be an object or a list.")

        datasets = self._parse_datasets(datasets_raw)
        assets = self._parse_assets(assets_raw)
        return datasets, assets

    def _parse_datasets(self, raw: list[object]) -> list[DatasetEntry]:
        entries: list[DatasetEntry] = []
        for item in raw:
            if not isinstance(item, dict):
                raise ValueError("Catalog dataset entry must be an object.")

            base_name = item.get("base_name")
            date_folder = item.get("date_folder")
            experiment = item.get("experiment")
            drive_path = item.get("drive_path")
            drive_file_ids_raw = item.get("drive_file_ids")
            local_path = item.get("local_path")

            if not isinstance(base_name, str):
                raise ValueError("Catalog entry missing string 'base_name'.")
            if date_folder is not None and not isinstance(date_folder, str):
                raise ValueError("'date_folder' must be a string or null.")
            if experiment is not None and not isinstance(experiment, str):
                raise ValueError("'experiment' must be a string or null.")
            if not isinstance(drive_path, str):
                raise ValueError("Catalog entry missing string 'drive_path'.")
            if local_path is not None and not isinstance(local_path, str):
                raise ValueError("'local_path' must be a string or null.")
            if not isinstance(drive_file_ids_raw, dict):
                raise ValueError("Catalog entry missing object 'drive_file_ids'.")

            drive_file_ids: dict[str, str] = {}
            for key, value in drive_file_ids_raw.items():
                if isinstance(key, str) and isinstance(value, str):
                    drive_file_ids[key] = value
                else:
                    raise ValueError("'drive_file_ids' keys and values must be strings.")

            entries.append(
                {
                    "base_name": base_name,
                    "date_folder": date_folder,
                    "experiment": experiment,
                    "drive_path": drive_path,
                    "drive_file_ids": drive_file_ids,
                    "local_path": local_path,
                }
            )
        return entries

    def _parse_assets(self, raw: list[object]) -> list[AssetEntry]:
        entries: list[AssetEntry] = []
        for item in raw:
            if not isinstance(item, dict):
                raise ValueError("Catalog asset entry must be an object.")

            asset_name = item.get("asset_name")
            asset_type = item.get("asset_type")
            date_folder = item.get("date_folder")
            experiment = item.get("experiment")
            drive_path = item.get("drive_path")
            drive_id = item.get("drive_id")
            mime_type = item.get("mime_type")
            local_path = item.get("local_path")

            if not isinstance(asset_name, str):
                raise ValueError("Asset entry missing string 'asset_name'.")
            if asset_type not in ("folder", "file"):
                raise ValueError("'asset_type' must be 'folder' or 'file'.")
            if date_folder is not None and not isinstance(date_folder, str):
                raise ValueError("Asset 'date_folder' must be a string or null.")
            if experiment is not None and not isinstance(experiment, str):
                raise ValueError("Asset 'experiment' must be a string or null.")
            if not isinstance(drive_path, str):
                raise ValueError("Asset entry missing string 'drive_path'.")
            if not isinstance(drive_id, str):
                raise ValueError("Asset entry missing string 'drive_id'.")
            if not isinstance(mime_type, str):
                raise ValueError("Asset entry missing string 'mime_type'.")
            if local_path is not None and not isinstance(local_path, str):
                raise ValueError("Asset 'local_path' must be a string or null.")

            entries.append(
                {
                    "asset_name": asset_name,
                    "asset_type": asset_type,
                    "date_folder": date_folder,
                    "experiment": experiment,
                    "drive_path": drive_path,
                    "drive_id": drive_id,
                    "mime_type": mime_type,
                    "local_path": local_path,
                }
            )
        return entries

    def _save_catalog(self, datasets: list[DatasetEntry], assets: list[AssetEntry]) -> None:
        """Write the catalog JSON to disk."""
        Path(self.config.catalog_path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.config.catalog_path, "w") as f:
            json.dump({"datasets": datasets, "assets": assets}, f, indent=2)

    def _get_dataset_entry(self, base_name: str) -> DatasetEntry:
        datasets, _ = self._load_catalog()
        for entry in datasets:
            if entry["base_name"] == base_name:
                return entry
        raise ValueError(f"Dataset '{base_name}' not found in catalog.")

    def _get_asset_entry(self, drive_path: str, asset_name: str) -> AssetEntry:
        _, assets = self._load_catalog()
        for entry in assets:
            if entry["drive_path"] == drive_path and entry["asset_name"] == asset_name:
                return entry
        raise ValueError(f"Asset '{asset_name}' at '{drive_path}' not found in catalog.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan(self) -> None:
        """
        Scan Drive recursively and rebuild the catalog JSON.

        Any existing local_path entries are preserved so a rescan doesn't
        forget which datasets or assets have already been downloaded.
        """
        print("Scanning Google Drive...")
        new_datasets, new_assets = scan_drive(self._drive, self.config.root_folder_id)

        # Preserve local_path values from the previous catalog
        existing_dataset_paths: dict[str, str | None] = {}
        existing_asset_paths: dict[tuple[str, str], str | None] = {}
        if Path(self.config.catalog_path).exists():
            old_datasets, old_assets = self._load_catalog()
            for ds in old_datasets:
                existing_dataset_paths[ds["base_name"]] = ds.get("local_path")
            for asset in old_assets:
                old_key = (asset["drive_path"], asset["asset_name"])
                existing_asset_paths[old_key] = asset.get("local_path")

        for ds in new_datasets:
            ds["local_path"] = existing_dataset_paths.get(ds["base_name"])
        for asset in new_assets:
            new_key = (asset["drive_path"], asset["asset_name"])
            asset["local_path"] = existing_asset_paths.get(new_key)

        self._save_catalog(new_datasets, new_assets)
        self._invalidate_cache()
        print(f"Catalog updated: {len(new_datasets)} datasets, {len(new_assets)} assets found.")

    @property
    def df(self) -> pd.DataFrame:
        """
        The full dataset catalog as a pandas DataFrame. Columns:
            base_name, date_folder, experiment,
            drive_path, drive_file_ids, local_path
        """
        if self._df is None:
            datasets, _ = self._load_catalog()
            self._df = pd.DataFrame(datasets)
        return self._df

    @property
    def assets_df(self) -> pd.DataFrame:
        """
        The full assets catalog as a pandas DataFrame. Columns:
            asset_name, asset_type, date_folder, experiment,
            drive_path, drive_id, mime_type, local_path
        """
        if self._assets_df is None:
            _, assets = self._load_catalog()
            self._assets_df = pd.DataFrame(assets)
        return self._assets_df

    def list(
        self,
        date_folder: str | None = None,
        experiment: str | None = None,
    ) -> pd.DataFrame:
        """
        Query the dataset catalog and return a filtered DataFrame.

        Arguments act as hierarchical filters — each narrows the result
        further. Omitting an argument returns all values for that level.

        Args:
            date_folder: Exact name of the top-level date folder to filter on
                (e.g. ``"2026-02-15_batch"``). Must match the full folder name.
            experiment: Exact name of the depth-2 experiment folder to filter on.

        Examples:
            catalog.list()                                              # everything
            catalog.list(date_folder="2026-02-15_batch")               # one date folder
            catalog.list(date_folder="2026-02-15_batch", experiment="reaching")
            catalog.list(experiment="reaching")                         # across all dates
        """
        result = self.df

        if date_folder is not None:
            result = result[result["date_folder"] == date_folder]
        if experiment is not None:
            result = result[result["experiment"] == experiment]

        return result.reset_index(drop=True)

    def list_assets(
        self,
        date_folder: str | None = None,
        experiment: str | None = None,
        asset_type: Literal["folder", "file"] | None = None,
    ) -> pd.DataFrame:
        """
        Query the asset catalog and return a filtered DataFrame.

        Arguments act as hierarchical filters. Omitting an argument returns
        all values for that level.

        Args:
            date_folder: Exact name of the top-level date folder to filter on
                (e.g. ``"2026-02-15_batch"``). Must match the full folder name.
            experiment: Exact name of the depth-2 experiment folder to filter on.
            asset_type: ``"folder"`` or ``"file"``; if omitted, returns both.

        Examples:
            catalog.list_assets()
            catalog.list_assets(date_folder="2026-02-15_batch", experiment="reaching")
            catalog.list_assets(asset_type="folder")
        """
        result = self.assets_df

        if date_folder is not None:
            result = result[result["date_folder"] == date_folder]
        if experiment is not None:
            result = result[result["experiment"] == experiment]
        if asset_type is not None:
            result = result[result["asset_type"] == asset_type]

        return result.reset_index(drop=True)

    def download(self, base_name: str) -> str:
        """Download the xdat files for a dataset to `local_data_dir`.

        After a successful download, persists the `local_path` back to the
        catalog JSON so it survives future sessions.

        Args:
            base_name: The dataset identifier (shared filename stem).

        Returns:
            The local directory path where the files were written.

        Raises:
            ValueError: If `base_name` is not found in the catalog.
        """
        dataset = self._get_dataset_entry(base_name)
        print(f"Downloading '{base_name}'...")
        local_path = download_dataset(self._drive, dataset, self.config.local_data_dir)

        # Persist the local_path back to the catalog
        datasets, assets = self._load_catalog()
        for entry in datasets:
            if entry["base_name"] == base_name:
                entry["local_path"] = local_path
                break
        self._save_catalog(datasets, assets)
        self._invalidate_cache()

        print(f"Done. Files saved to: {local_path}")
        return local_path

    def get_path(self, base_name: str) -> str:
        """Return the local directory path for a dataset, downloading if needed.

        If the dataset has not been downloaded yet, or if the recorded
        `local_path` no longer exists on disk, the download is triggered
        automatically.

        Args:
            base_name: The dataset identifier (shared filename stem).

        Returns:
            The local directory path where the xdat files reside.

        Raises:
            ValueError: If `base_name` is not found in the catalog.
        """
        entry = self._get_dataset_entry(base_name)
        local_path = entry["local_path"]
        if local_path is not None and Path(local_path).exists():
            return local_path

        print(f"'{base_name}' is not available locally.")
        return self.download(base_name)

    def download_asset(self, drive_path: str, asset_name: str) -> str:
        """Download an asset (file or folder) to the local assets directory.

        Assets are stored under ``{local_data_dir}/assets/{drive_path}/{asset_name}``.
        For folder assets the entire subtree is downloaded recursively.

        After a successful download, persists the ``local_path`` back to the
        catalog JSON.

        Args:
            drive_path: The slash-joined path to the asset's *parent* folder
                (e.g. ``"2026-02-15_batch/reaching"``). Shown in
                ``assets_df["drive_path"]``.
            asset_name: The file or folder name (e.g. ``"logs"``).

        Returns:
            The local path to the downloaded file or folder.

        Raises:
            ValueError: If the asset is not found in the catalog.
        """
        asset = self._get_asset_entry(drive_path, asset_name)
        print(f"Downloading asset '{asset_name}'...")
        local_path = _download_asset_entry(self._drive, asset, self.config.local_data_dir)

        datasets, assets = self._load_catalog()
        for entry in assets:
            if entry["drive_path"] == drive_path and entry["asset_name"] == asset_name:
                entry["local_path"] = local_path
                break
        self._save_catalog(datasets, assets)
        self._invalidate_cache()

        print(f"Done. Asset saved to: {local_path}")
        return local_path

    def get_asset_path(self, drive_path: str, asset_name: str) -> str:
        """Return the local path for an asset, downloading if needed.

        If the asset has not been downloaded yet, or if the recorded
        ``local_path`` no longer exists on disk, the download is triggered
        automatically.

        Args:
            drive_path: The slash-joined path to the asset's *parent* folder
                (e.g. ``"2026-02-15_batch/reaching"``).
            asset_name: The file or folder name (e.g. ``"logs"``).

        Returns:
            The local path to the downloaded file or folder.

        Raises:
            ValueError: If the asset is not found in the catalog.
        """
        entry = self._get_asset_entry(drive_path, asset_name)
        local_path = entry["local_path"]
        if local_path is not None and Path(local_path).exists():
            return local_path

        print(f"Asset '{asset_name}' is not available locally.")
        return self.download_asset(drive_path, asset_name)

    def status(self) -> pd.DataFrame:
        """
        Return the dataset catalog DataFrame with an extra boolean column
        'is_local' indicating which datasets are already downloaded.
        Useful for a quick overview of what's available locally.
        """
        df = self.df.copy()
        df["is_local"] = df["local_path"].apply(lambda p: bool(p and Path(p).exists()))
        return df
