"""
drive.py
--------
Google Drive API interactions: recursive scanning and file download.

xdat dataset file naming convention (3 files per base_name):
    {base_name}_data.xdat
    {base_name}.xdat.json
    {base_name}_timestamp.xdat
"""

from pathlib import Path
from typing import Literal, Protocol, TypedDict

from googleapiclient.http import MediaIoBaseDownload
from tqdm import tqdm

# Maps each file suffix to a short type label used in drive_file_ids
XDAT_SUFFIXES: dict[str, str] = {
    "_data.xdat": "data",
    ".xdat.json": "meta",
    "_timestamp.xdat": "timestamp",
}

FOLDER_MIME = "application/vnd.google-apps.folder"


class DriveItem(TypedDict):
    """A single item returned by the Drive API `files.list` endpoint."""

    id: str
    name: str
    mimeType: str


class DatasetEntry(TypedDict):
    """One xdat dataset record stored in the catalog.

    Represents a single neural recording dataset, identified by its `base_name`.
    The three xdat files (`_data.xdat`, `.xdat.json`, `_timestamp.xdat`) share
    this common stem.

    Attributes:
        base_name: Shared filename stem across all three xdat files. This is the
            canonical identifier used throughout the package.
        date_folder: Name of the top-level date-prefixed folder (depth 1), or
            `None` if the dataset is at the Drive root.
        experiment: Name of the depth-2 subfolder (e.g. `"reaching"`), or `None`
            if the dataset lives directly inside the date folder.
        drive_path: Slash-joined path from the root folder to the folder containing
            the dataset files (e.g. `"2026-02-15_batch/reaching/probe1"`).
        drive_file_ids: Maps file type labels (`"data"`, `"meta"`, `"timestamp"`)
            to their Google Drive file IDs. May contain fewer than three keys if
            only some files were found during scanning.
        local_path: Absolute path to the local directory where the dataset has
            been downloaded, or `None` if not yet downloaded.
    """

    base_name: str
    date_folder: str | None
    experiment: str | None
    drive_path: str
    drive_file_ids: dict[str, str]
    local_path: str | None


class AssetEntry(TypedDict):
    """One non-xdat asset record stored in the catalog.

    Represents a single file or folder found on Drive that is not an xdat
    dataset — for example a ``logs/`` directory, a PowerPoint, or a writeup.

    Attributes:
        asset_name: The file or folder name as it appears on Drive
            (e.g. ``"logs"``, ``"notes.pptx"``).
        asset_type: ``"folder"`` or ``"file"``.
        date_folder: Name of the top-level date-prefixed folder (depth 1), or
            ``None`` if the asset is at the Drive root.
        experiment: Name of the depth-2 subfolder, or ``None`` if the asset
            lives directly inside the date folder.
        drive_path: Slash-joined path from the root folder to the *parent*
            folder of this asset (e.g. ``"2026-02-15_batch/reaching"``).
        drive_id: Google Drive ID of this file or folder.
        mime_type: MIME type as reported by the Drive API.
        local_path: Absolute local path to the downloaded file or folder, or
            ``None`` if not yet downloaded.
    """

    asset_name: str
    asset_type: Literal["folder", "file"]
    date_folder: str | None
    experiment: str | None
    drive_path: str
    drive_id: str
    mime_type: str
    local_path: str | None


class _DriveListRequest(Protocol):
    def execute(self) -> dict[str, object]: ...


class _DriveMediaRequest(Protocol):
    pass


class _DriveFilesResource(Protocol):
    def list(self, *, q: str, fields: str, pageToken: str | None = None) -> _DriveListRequest: ...

    def get_media(self, *, fileId: str) -> _DriveMediaRequest: ...


class DriveService(Protocol):
    def files(self) -> _DriveFilesResource: ...


def _extract_base_name(filename: str) -> str | None:
    """
    Return the base_name for a recognized xdat filename, or None
    if the file doesn't match any known suffix.
    """
    for suffix in XDAT_SUFFIXES:
        if filename.endswith(suffix):
            return filename[: -len(suffix)]
    return None


def _list_folder(service: DriveService, folder_id: str) -> list[DriveItem]:
    """Return all non-trashed items (files and subfolders) in a Drive folder.

    Handles pagination automatically by following `nextPageToken` until
    exhausted. Items missing any of `id`, `name`, or `mimeType` are silently
    skipped.

    Args:
        service: Authenticated Drive API service.
        folder_id: Google Drive folder ID to list.

    Returns:
        List of `DriveItem` dicts for all items in the folder.
    """
    items: list[DriveItem] = []
    page_token: str | None = None

    while True:
        response = (
            service.files()
            .list(
                q=f"'{folder_id}' in parents and trashed = false",
                fields="nextPageToken, files(id, name, mimeType)",
                pageToken=page_token,
            )
            .execute()
        )
        files_obj = response.get("files")
        if isinstance(files_obj, list):
            for item in files_obj:
                if not isinstance(item, dict):
                    continue
                item_id = item.get("id")
                name = item.get("name")
                mime_type = item.get("mimeType")
                if isinstance(item_id, str) and isinstance(name, str) and isinstance(mime_type, str):
                    items.append({"id": item_id, "name": name, "mimeType": mime_type})
        next_token = response.get("nextPageToken")
        page_token = next_token if isinstance(next_token, str) else None
        if not page_token:
            break

    return items


def scan_drive(service: DriveService, root_folder_id: str) -> tuple[list[DatasetEntry], list[AssetEntry]]:
    """Recursively scan Drive and return xdat datasets and non-xdat assets.

    Traverses the full subtree rooted at ``root_folder_id``.

    **Dataset collection** (unchanged): xdat files are recognized at any depth
    by their suffix and merged by ``base_name`` into :class:`DatasetEntry` records.

    **Asset collection**: Non-xdat content is cataloged according to depth:

    - Folders encountered *inside* an experiment folder (depth ≥ 3 from root)
      are cataloged as ``"folder"`` assets and also recursed into so that any
      xdat files they contain are still found.
    - Non-xdat files encountered inside a date folder or experiment folder
      (depths 2-3 from root) are cataloged as ``"file"`` assets.
    - Content deeper than the experiment level is not separately cataloged
      (it is part of a parent folder asset and downloaded with it).

    The depth thresholds correspond to ``len(path_components)`` inside
    ``_recurse``:  0 = root, 1 = inside date folder, 2 = inside experiment.

    Args:
        service: Authenticated Drive API service.
        root_folder_id: Google Drive folder ID of the root folder to scan.

    Returns:
        A tuple ``(datasets, assets)`` where ``datasets`` is a list of
        :class:`DatasetEntry` dicts (one per unique ``base_name``) and
        ``assets`` is a list of :class:`AssetEntry` dicts. All entries have
        ``local_path=None``; that field is set later by :class:`Catalog`.
    """
    datasets: dict[str, DatasetEntry] = {}
    # keyed by (drive_path, asset_name) to deduplicate across recursive calls
    _asset_dict: dict[tuple[str, str], AssetEntry] = {}

    def _recurse(folder_id: str, path_components: list[str]) -> None:
        depth = len(path_components)
        items = _list_folder(service, folder_id)

        for item in items:
            is_folder = item["mimeType"] == FOLDER_MIME

            if is_folder:
                if depth == 2:
                    # Direct child of an experiment folder → folder asset
                    drive_path = "/".join(path_components)
                    key = (drive_path, item["name"])
                    if key not in _asset_dict:
                        _asset_dict[key] = {
                            "asset_name": item["name"],
                            "asset_type": "folder",
                            "date_folder": path_components[0] if depth > 0 else None,
                            "experiment": path_components[1] if depth > 1 else None,
                            "drive_path": drive_path,
                            "drive_id": item["id"],
                            "mime_type": item["mimeType"],
                            "local_path": None,
                        }
                # Always recurse into folders at any depth
                _recurse(item["id"], [*path_components, item["name"]])
            else:
                base_name = _extract_base_name(item["name"])
                if base_name is not None:
                    # xdat file — add to datasets
                    suffix = next(s for s in XDAT_SUFFIXES if item["name"].endswith(s))
                    file_type = XDAT_SUFFIXES[suffix]

                    if base_name not in datasets:
                        datasets[base_name] = {
                            "base_name": base_name,
                            "date_folder": path_components[0] if depth > 0 else None,
                            "experiment": path_components[1] if depth > 1 else None,
                            "drive_path": "/".join(path_components),
                            "drive_file_ids": {},
                            "local_path": None,
                        }
                    datasets[base_name]["drive_file_ids"][file_type] = item["id"]
                elif depth in (1, 2):
                    # Non-xdat file directly inside a date or experiment folder → file asset
                    drive_path = "/".join(path_components)
                    key = (drive_path, item["name"])
                    if key not in _asset_dict:
                        _asset_dict[key] = {
                            "asset_name": item["name"],
                            "asset_type": "file",
                            "date_folder": path_components[0] if depth > 0 else None,
                            "experiment": path_components[1] if depth > 1 else None,
                            "drive_path": drive_path,
                            "drive_id": item["id"],
                            "mime_type": item["mimeType"],
                            "local_path": None,
                        }

    _recurse(root_folder_id, [])
    return list(datasets.values()), list(_asset_dict.values())


def _download_file(service: DriveService, file_id: str, dest_path: Path, desc: str | None = None) -> None:
    """Download a single Drive file to ``dest_path``, showing a tqdm progress bar."""
    request = service.files().get_media(fileId=file_id)
    with open(dest_path, "wb") as fh:
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        with tqdm(total=None, unit="B", unit_scale=True, desc=desc or dest_path.name, leave=True) as pbar:
            while not done:
                status, done = downloader.next_chunk()
                if status is not None:
                    if pbar.total is None and status.total_size:
                        pbar.total = status.total_size
                        pbar.refresh()
                    pbar.update(int(status.resumable_progress) - int(pbar.n))


def _download_folder_recursive(service: DriveService, folder_id: str, local_dir: Path) -> None:
    """Recursively download all contents of a Drive folder into ``local_dir``."""
    local_dir.mkdir(parents=True, exist_ok=True)
    for item in _list_folder(service, folder_id):
        if item["mimeType"] == FOLDER_MIME:
            _download_folder_recursive(service, item["id"], local_dir / item["name"])
        else:
            _download_file(service, item["id"], local_dir / item["name"])


def download_dataset(service: DriveService, dataset: DatasetEntry, local_data_dir: str) -> str:
    """Download the xdat files for a dataset into `local_data_dir`.

    Files are written flat (not in a per-dataset subdirectory):

    ```
    {local_data_dir}/{base_name}_data.xdat
    {local_data_dir}/{base_name}.xdat.json
    {local_data_dir}/{base_name}_timestamp.xdat
    ```

    The directory is created if it does not already exist.

    Args:
        service: Authenticated Drive API service.
        dataset: The `DatasetEntry` whose files should be downloaded.
        local_data_dir: Path to the local directory where files will be written.

    Returns:
        The `local_data_dir` path as a string.
    """
    local_dir = Path(local_data_dir)
    local_dir.mkdir(parents=True, exist_ok=True)

    # Reverse the suffix map so we can reconstruct filenames from file_type
    type_to_suffix = {v: k for k, v in XDAT_SUFFIXES.items()}

    for file_type, file_id in dataset["drive_file_ids"].items():
        suffix = type_to_suffix[file_type]
        filename = dataset["base_name"] + suffix
        dest_path = local_dir / filename

        _download_file(service, file_id, dest_path)

    return str(local_dir)


def download_asset(service: DriveService, asset: AssetEntry, local_data_dir: str) -> str:
    """Download an asset (file or folder) into the assets subdirectory.

    Assets are stored under ``{local_data_dir}/assets/{drive_path}/{asset_name}``,
    keeping them separate from the flat xdat dataset files.

    For folder assets the entire subtree is downloaded recursively, mirroring
    the Drive folder structure under the asset's local directory.

    Args:
        service: Authenticated Drive API service.
        asset: The :class:`AssetEntry` to download.
        local_data_dir: Root local data directory (same as used for datasets).

    Returns:
        The absolute path to the downloaded file or folder as a string.
    """
    asset_local_path = Path(local_data_dir) / "assets"
    if asset["drive_path"]:
        asset_local_path = asset_local_path / asset["drive_path"]
    asset_local_path = asset_local_path / asset["asset_name"]

    if asset["asset_type"] == "folder":
        _download_folder_recursive(service, asset["drive_id"], asset_local_path)
    else:
        asset_local_path.parent.mkdir(parents=True, exist_ok=True)
        _download_file(service, asset["drive_id"], asset_local_path)

    return str(asset_local_path)
