"""Core architecture checker for Chine.

This module provides static analysis of architectural roles and their dependencies.
"""

import ast
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Violation:
    """Represents an architectural rule violation.

    Attributes:
        rule_id: Stable identifier for the rule (e.g., "ARCH001")
        message: Clear description of the violation
        file_path: Path to the file containing the violation
        line_number: Line number where the violation occurs
    """

    rule_id: str
    message: str
    file_path: str
    line_number: int


@dataclass(frozen=True)
class CheckSpec:
    """Metadata and callable for an architecture check."""

    code: str
    description: str
    func: Callable[["ModuleInfo", "ProjectGraph"], list[Violation]]


@dataclass(frozen=True)
class DependencyRule:
    """Declarative dependency rule between source and forbidden role tags."""

    code: str
    description: str
    source_tags: frozenset[str]
    forbidden_tags: frozenset[str]


@dataclass(frozen=True)
class ModuleInfo:
    """Information about a module in the project graph."""

    file_path: Path
    declared_tags: frozenset[str]
    effective_tags: frozenset[str]
    imports: list[tuple[str, int, Path | None]]


@dataclass(frozen=True)
class ProjectGraph:
    """Project-wide import graph and module metadata."""

    source_root: Path
    modules: dict[Path, ModuleInfo]


@dataclass(frozen=True)
class CoverageStats:
    """Coverage statistics for architecture role declarations."""

    declared_modules: int
    total_modules: int

    @property
    def percentage(self) -> float:
        """Return declaration coverage percentage."""
        if self.total_modules == 0:
            return 0.0
        return (self.declared_modules / self.total_modules) * 100.0


ARCH001 = DependencyRule(
    code="ARCH001",
    description="A use case must not import adapter modules.",
    source_tags=frozenset({"use_case"}),
    forbidden_tags=frozenset({"adapter"}),
)

ARCH002 = DependencyRule(
    code="ARCH002",
    description="A domain module must not import adapter modules.",
    source_tags=frozenset({"domain", "domain_policy"}),
    forbidden_tags=frozenset({"adapter"}),
)

ARCH003 = DependencyRule(
    code="ARCH003",
    description="A domain module must not import use case modules.",
    source_tags=frozenset({"domain", "domain_policy"}),
    forbidden_tags=frozenset({"use_case"}),
)

ROLE_TAG_DESCRIPTIONS = {
    "use_case": "Application orchestration layer that must not import adapters.",
    "domain_policy": "Domain decision logic that must not import adapters or use cases.",
    "domain": "Alias for domain_policy with the same dependency restrictions.",
    "adapter": "Infrastructure edge role that is typically consumed by outer layers.",
    "orm_model": "Persistence adapter tag (expands to adapter, driven, persistence).",
    "api_schema": "Transport adapter tag (expands to adapter, driving, transport).",
    "endpoint": "API endpoint adapter tag (expands to adapter, driving).",
}

TAG_EXPANSIONS: dict[str, frozenset[str]] = {
    # Domain-specific tags map to broader architecture semantics used by dependency rules.
    # These semantic tags (e.g. driven/driving/persistence/transport) are helper labels
    # for rule matching and are not required to be declared as core architecture roles.
    # Expansion is single-pass and only applies to directly declared tags.
    # Expanded tags are not recursively expanded.
    "orm_model": frozenset({"adapter", "driven", "persistence"}),
    "api_schema": frozenset({"adapter", "driving", "transport"}),
    "endpoint": frozenset({"adapter", "driving"}),
}


def get_module_role(file_path: Path) -> frozenset[str] | None:
    """Extract architectural roles from a Python module.

    Looks for __architecture_role__ declarations at module level.
    Supports either a single string role or a collection of string roles.

    Args:
        file_path: Path to the Python file to analyze

    Returns:
        The declared role names if present, None otherwise (treated as architectural Any)
    """
    tree = _parse_module_ast(file_path)
    if tree is None:
        return None
    return _extract_module_role(tree)


def _parse_module_ast(file_path: Path) -> ast.AST | None:
    """Parse a Python module into AST, returning None on read/parse errors."""
    try:
        with open(file_path, encoding="utf-8") as f:
            content = f.read()
    except (OSError, UnicodeDecodeError):
        return None

    try:
        return ast.parse(content, filename=str(file_path))
    except SyntaxError:
        return None


def _extract_roles_from_value(value: ast.expr) -> set[str]:
    """Extract declared role names from an assignment value node."""
    if isinstance(value, ast.Constant) and isinstance(value.value, str):
        return {value.value}

    if isinstance(value, (ast.List, ast.Tuple)):
        roles = set()
        for element in value.elts:
            if isinstance(element, ast.Constant) and isinstance(element.value, str):
                roles.add(element.value)
        return roles

    return set()


def _extract_module_role(tree: ast.AST) -> frozenset[str] | None:
    """Extract role declaration(s) from parsed AST.

    Only module-level assignments are considered, and the last such assignment wins.
    Assignments with no valid string roles normalize to None.
    """
    if not isinstance(tree, ast.Module):
        return None

    extracted_roles: frozenset[str] | None = None

    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue

        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "__architecture_role__":
                roles = _extract_roles_from_value(node.value)
                extracted_roles = frozenset(roles) if roles else None

    return extracted_roles


def _extract_import_names_from_import_from(node: ast.ImportFrom) -> set[str]:
    """Extract possible module import names from an ImportFrom node."""
    import_candidates: set[str] = set()
    relative_prefix = "." * node.level

    if node.module:
        base_import_name = f"{relative_prefix}{node.module}"
        import_candidates.add(base_import_name)
        for alias in node.names:
            if alias.name != "*":
                import_candidates.add(f"{base_import_name}.{alias.name}")
    else:
        for alias in node.names:
            if alias.name != "*":
                import_candidates.add(f"{relative_prefix}{alias.name}")

    return import_candidates


def _format_tags(tags: frozenset[str]) -> str:
    """Render role tags as comma-separated labels, replacing underscores with spaces."""
    return ", ".join(sorted(tag.replace("_", " ").title() for tag in tags))


def _expand_declared_tags(declared_tags: frozenset[str]) -> frozenset[str]:
    """Apply configured semantic expansions to declared tags in a single pass.

    Only directly declared tags are expanded; tags added by expansion are not
    expanded again. Declared tags with no configured expansion are preserved
    unchanged.
    """
    expanded = set(declared_tags)
    for tag in declared_tags:
        expanded.update(TAG_EXPANSIONS.get(tag, frozenset()))
    return frozenset(expanded)


def resolve_import_to_file(import_name: str, current_file: Path, source_root: Path) -> Path | None:
    """Resolve an import statement to a file path within the source root.

    Args:
        import_name: The module name being imported (e.g., "myapp.adapters.db")
        current_file: Path to the file containing the import
        source_root: Root directory of the source code

    Returns:
        Path to the imported file if it exists within source_root, None otherwise
    """
    # Handle relative imports
    if import_name.startswith("."):
        # Get the package directory of the current file
        current_dir = current_file.parent
        parts = import_name.split(".")

        # Count leading dots
        level = 0
        for part in parts:
            if part == "":
                level += 1
            else:
                break

        # Relative imports are anchored to the current package.
        # A single leading dot stays in the same package; additional dots walk upward.
        target_dir = current_dir
        for _ in range(max(level - 1, 0)):
            target_dir = target_dir.parent
            if not target_dir.is_relative_to(source_root):
                return None

        # Add remaining parts
        remaining_parts = [p for p in parts if p]
        if remaining_parts:
            for part in remaining_parts:
                target_dir = target_dir / part
        target_path = target_dir
    else:
        # Absolute import - start from source root
        parts = import_name.split(".")
        target_path = source_root
        for part in parts:
            target_path = target_path / part

    # Try as package (__init__.py) or module (.py)
    if (target_path / "__init__.py").exists():
        return target_path / "__init__.py"

    py_file = target_path.with_suffix(".py")
    if py_file.exists():
        return py_file

    return None


def build_project_graph(source_root: Path) -> ProjectGraph:
    """Build a project-wide import graph with module roles and resolved imports."""
    modules: dict[Path, ModuleInfo] = {}

    for py_file in source_root.rglob("*.py"):
        tree = _parse_module_ast(py_file)
        if tree is None:
            modules[py_file] = ModuleInfo(
                file_path=py_file,
                declared_tags=frozenset(),
                effective_tags=frozenset(),
                imports=[],
            )
            continue

        declared_role_tags = _extract_module_role(tree)
        declared_tags = declared_role_tags if declared_role_tags is not None else frozenset()
        effective_tags = _expand_declared_tags(declared_tags)
        imports: list[tuple[str, int, Path | None]] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    import_name = alias.name
                    imports.append(
                        (
                            import_name,
                            node.lineno,
                            resolve_import_to_file(import_name, py_file, source_root),
                        )
                    )
            elif isinstance(node, ast.ImportFrom):
                for import_name in _extract_import_names_from_import_from(node):
                    imports.append(
                        (
                            import_name,
                            node.lineno,
                            resolve_import_to_file(import_name, py_file, source_root),
                        )
                    )

        modules[py_file] = ModuleInfo(
            file_path=py_file,
            declared_tags=declared_tags,
            effective_tags=effective_tags,
            imports=imports,
        )

    return ProjectGraph(source_root=source_root, modules=modules)


def check_dependency_rule(
    module: ModuleInfo, graph: ProjectGraph, rule: DependencyRule
) -> list[Violation]:
    """Check a declarative dependency rule against one module.

    Args:
        module: Module to check
        graph: Project-wide import graph and metadata
        rule: Dependency rule describing source and forbidden role tags

    Returns:
        List of violations found (empty if none)
    """
    if module.effective_tags.isdisjoint(rule.source_tags):
        return []

    violations: list[Violation] = []

    for import_name, line_no, imported_file in module.imports:
        if imported_file is None:
            continue

        imported_module = graph.modules.get(imported_file)
        if imported_module is None:
            continue

        if imported_module.effective_tags.isdisjoint(rule.forbidden_tags):
            continue

        source_tags = _format_tags(rule.source_tags)
        forbidden_tags = _format_tags(rule.forbidden_tags)
        message = f"{source_tags} module must not import {forbidden_tags} module '{import_name}'."
        violations.append(
            Violation(
                rule_id=rule.code,
                message=message,
                file_path=str(module.file_path),
                line_number=line_no,
            )
        )

    return violations


def check_arch001(module: ModuleInfo, graph: ProjectGraph) -> list[Violation]:
    """Check ARCH001: A use case must not import adapter modules."""
    return check_dependency_rule(module, graph, ARCH001)


def check_arch002(module: ModuleInfo, graph: ProjectGraph) -> list[Violation]:
    """Check ARCH002: A domain module must not import adapter modules."""
    return check_dependency_rule(module, graph, ARCH002)


def check_arch003(module: ModuleInfo, graph: ProjectGraph) -> list[Violation]:
    """Check ARCH003: A domain module must not import use case modules."""
    return check_dependency_rule(module, graph, ARCH003)


def _create_rule_checker(
    rule: DependencyRule,
) -> Callable[[ModuleInfo, ProjectGraph], list[Violation]]:
    """Create a check function for a declarative dependency rule."""

    def _check(module: ModuleInfo, graph: ProjectGraph) -> list[Violation]:
        return check_dependency_rule(module, graph, rule)

    return _check


DEPENDENCY_RULES = [ARCH001, ARCH002, ARCH003]


def _build_supported_role_tags() -> tuple[tuple[str, str], ...]:
    """Build supported role tag metadata from configured dependency rules and expansions."""
    tags: set[str] = set()
    for rule in DEPENDENCY_RULES:
        tags.update(rule.source_tags)
        tags.update(rule.forbidden_tags)
    tags.update(TAG_EXPANSIONS.keys())

    return tuple(
        (
            tag,
            ROLE_TAG_DESCRIPTIONS.get(tag, "Role tag used in architecture dependency checks."),
        )
        for tag in sorted(tags)
    )


SUPPORTED_ROLE_TAGS = _build_supported_role_tags()


CHECK_SPECS = [
    CheckSpec(code=rule.code, description=rule.description, func=_create_rule_checker(rule))
    for rule in DEPENDENCY_RULES
]


def calculate_coverage_stats(graph: ProjectGraph) -> CoverageStats:
    """Calculate role declaration coverage for modules in the project graph."""
    total_modules = len(graph.modules)
    declared_modules = sum(1 for module in graph.modules.values() if module.declared_tags)
    return CoverageStats(declared_modules=declared_modules, total_modules=total_modules)


def check_project_graph(graph: ProjectGraph) -> list[Violation]:
    """Run all registered checks against a pre-built project graph."""
    violations: list[Violation] = []
    for module in graph.modules.values():
        for check_spec in CHECK_SPECS:
            violations.extend(check_spec.func(module, graph))
    return violations


def check_directory(source_root: Path) -> list[Violation]:
    """Check all Python files in a directory tree for architectural violations.

    Args:
        source_root: Root directory to scan

    Returns:
        List of all violations found
    """
    graph = build_project_graph(source_root)
    return check_project_graph(graph)
