#  Copyright (C) 2026  Kevin Tyrrell
#  GUI-driven WoW profession analyzer for material aggregation, cost calculation, and optimized crafting sequences
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QPlainTextEdit

import wow_recipe_calc.view.constants as C

from wow_recipe_calc.crafting_app import CraftingApp
from wow_recipe_calc.crafts.craft_planner import CraftPlan
from wow_recipe_calc.crafts.recipe.recipe_state import RecipeStateCore
from wow_recipe_calc.view.frame.window_banner import WindowBanner
from wow_recipe_calc.view.frame.tabs.edit.edit_tab import EditTab
from wow_recipe_calc.view.frame.tabs.plan_tab import PlanTab
from wow_recipe_calc.view.frame.tabs.bom_tab import BomTab
from wow_recipe_calc.view.frame.tabs.route_tab import RouteTab
from wow_recipe_calc.view.frame.tabs.cost_tab import CostTab
from wow_recipe_calc.util.log_manager import LogManager

logger: logging.Logger = logging.getLogger(__name__)


class MainWindow(QWidget):
    DEFAULT_TAB_INDEX: int = 0

    def __init__(self, craft_app: CraftingApp, state: RecipeStateCore, logs: LogManager) -> None:
        """
        :param craft_app: Entry-point to crafting, recipe, material, and cost information
        :param state: Observable mapping of selected recipes -> desired number of products
        :param logs: Log history buffer, for retrieving logging prior to GUI being displayed
        """
        super().__init__()
        self.__craft_app: CraftingApp = craft_app
        self.__state: RecipeStateCore = state
        self.__current_tab: int = self.DEFAULT_TAB_INDEX
        self._configure_window()
        self._setup_frames()
        logs.broadcast(self._console_logging_cb)

    def _configure_window(self) -> None:
        """Initializes the main window frame properties"""
        self.setWindowTitle(C.Banner.TITLE)
        self.resize(C.Window.WIDTH, C.Window.HEIGHT)
        self.setWindowFlags(Qt.FramelessWindowHint)

    def _setup_frames(self) -> None:
        """Builds the layout and initializes all child widgets"""
        self.__layout: QVBoxLayout = QVBoxLayout(self)
        self.__layout.setContentsMargins(*C.Window.MARGINS)
        self.__layout.setSpacing(C.Window.SPACING)
        # Header
        self.__banner: WindowBanner = WindowBanner(self)
        self.__layout.addWidget(self.__banner)
        # Content (Tabs)
        self.__tabs: QTabWidget = self._create_tab_widget()
        self.__layout.addWidget(self.__tabs)
        # Footer (Console)
        self.__console: QPlainTextEdit = QPlainTextEdit()
        self.__console.setReadOnly(True)
        self.__console.setMaximumBlockCount(C.Console.MAX_LINES)
        self.__console.setObjectName(C.Console.HANDLE)
        self.__console.setFixedHeight(C.Console.HEIGHT)
        self.__layout.addWidget(self.__console)

    def _create_tab_widget(self) -> QTabWidget:
        """Configures and returns the central tab navigation"""
        tab_container: QTabWidget = QTabWidget()
        tab_container.setTabPosition(QTabWidget.South)
        tab_names: tuple[str, ...] = (
            C.EditTab.NAME, C.BomTab.NAME, C.RouteTab.NAME, C.CostTab.NAME)
        plan_tabs: tuple[PlanTab, ...] = (
            BomTab(), RouteTab(self.__craft_app.item_db), CostTab()
        )
        tab_frames: tuple[QWidget, ...] = (EditTab(self.__craft_app, self.__state),) + plan_tabs
        for i in range(len(tab_frames)):
            tab_container.addTab(tab_frames[i], tab_names[i])
        def tab_change_cb(index: int) -> None:
            if index != 0:  # User went from edit tab -> plan tab, changes may have occurred
                if self.__current_tab == 0:
                    plan: CraftPlan = self.__craft_app.run_planner(self.__state)
                    # Notify each tab that their displayed data is out-of-date
                    for plan_tab in plan_tabs: plan_tab.invalidate(plan)
                plan_tabs[index - 1].refresh()  # inform the tab it was selected
            self.__current_tab = index
        tab_container.currentChanged.connect(tab_change_cb)
        return tab_container

    def _console_logging_cb(self, msg: str) -> None:
            self.__console.appendPlainText(msg)
