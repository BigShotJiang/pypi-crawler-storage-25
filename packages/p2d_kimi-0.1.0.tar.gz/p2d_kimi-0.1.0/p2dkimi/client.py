from __future__ import annotations

import json
from typing import Generator, Iterator

import requests

from .errors import KimiAPIError, KimiAuthError
from .session import BASE, build_headers, create_chat, new_id, stream_completion


class KimiClient:
    def __init__(
        self,
        token: str,
        model: str = "kimi",
        timeout: int = 60,
    ) -> None:
        if not token:
            raise KimiAuthError("token is required")
        self.token = token
        self.model = model
        self.timeout = timeout
        self.device_id = new_id()
        self.session_id = new_id()
        self.http = requests.Session()
        self.http.headers.update(build_headers(token, self.device_id, self.session_id))

    def new_chat(self, name: str = "") -> str:
        return create_chat(self.http, name, self.timeout)

    def chat(
        self,
        message: str,
        chat_id: str = "",
        history: list | None = None,
        use_search: bool = False,
    ) -> str:
        return "".join(self.stream(message, chat_id=chat_id, history=history, use_search=use_search))

    def stream(
        self,
        message: str,
        chat_id: str = "",
        history: list | None = None,
        use_search: bool = False,
    ) -> Generator[str, None, None]:
        if not chat_id:
            chat_id = self.new_chat()

        messages = list(history or []) + [{"role": "user", "content": message}]

        resp = stream_completion(
            self.http, chat_id, messages, self.model, use_search, self.timeout
        )

        if not resp.ok:
            raise KimiAPIError(str(resp.status_code), resp.text[:300])

        for raw in resp.iter_lines():
            if not raw:
                continue
            line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                obj = json.loads(data)
            except (json.JSONDecodeError, ValueError):
                continue
            event = obj.get("event", "")
            if event == "cmpl" and "text" in obj:
                yield obj["text"]
            elif event == "all_done":
                break
            elif "error_type" in obj or "error" in obj:
                code = obj.get("error_type") or str(obj.get("error", "unknown"))
                raise KimiAPIError(code, obj.get("message", ""))
