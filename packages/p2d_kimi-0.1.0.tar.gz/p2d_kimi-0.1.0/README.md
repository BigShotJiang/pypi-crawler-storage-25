# p2d-kimi

Unofficial Python client for **Kimi AI** (kimi.moonshot.cn). No API key needed — just your bearer token.

Reverse-engineered from the web interface. Works with any valid Kimi account token.

## Install

```bash
pip install p2d-kimi
```

## Quick start

```python
from p2dkimi import KimiClient

client = KimiClient(token="your-kimi-bearer-token")

reply = client.chat("What is the capital of France?")
print(reply)
```

## Streaming

```python
from p2dkimi import KimiClient

client = KimiClient(token="your-token")

for chunk in client.stream("Explain quantum computing in simple terms"):
    print(chunk, end="", flush=True)
```

## Multi-turn conversation

```python
client = KimiClient(token="your-token")

chat_id = client.new_chat(name="my-session")

reply1 = client.chat("My name is Alex.", chat_id=chat_id)
reply2 = client.chat("What is my name?", chat_id=chat_id)
print(reply2)
```

## With search enabled

```python
reply = client.chat("Latest news on AI today", use_search=True)
```

## API

### `KimiClient(token, model="kimi", timeout=60)`

| Parameter | Description |
|-----------|-------------|
| `token`   | Bearer JWT from kimi.moonshot.cn (see below) |
| `model`   | Model ID: `"kimi"` (default), `"k1"`, `"ok-computer"`, etc. |
| `timeout` | HTTP timeout in seconds |

Each `KimiClient` instance automatically generates its own unique `device_id` and `session_id` using UUID4, so multiple clients can run concurrently without conflicts.

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `chat(message, chat_id, history, use_search)` | `str` | Send a message, get full reply |
| `stream(message, chat_id, history, use_search)` | `Generator[str]` | Send a message, yield reply chunks |
| `new_chat(name)` | `str` (chat ID) | Create a new conversation, return its ID |

## Getting your token

1. Open [kimi.moonshot.cn](https://kimi.moonshot.cn) in your browser
2. Open DevTools → Network → any request → copy `Authorization: Bearer <token>`

Or from the iOS/Android app using a MITM proxy (e.g. mitmproxy, Charles).

The token is a JWT that lasts ~30 days.

## How it works

```
KimiClient.chat("hello")
    → new_chat()          POST /api/chat            → chat_id
    → stream_completion() POST /api/chat/{id}/completion/stream  → SSE chunks
    → collect chunks      event=cmpl text="Hello!"
    → return full string
```

All sessions and device IDs are generated fresh per client instance using `uuid4()`, so every user gets their own isolated session without any shared state.

## License

MIT — made by addy
