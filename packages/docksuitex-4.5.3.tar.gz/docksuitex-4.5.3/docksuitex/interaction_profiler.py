import subprocess
import shutil
import os
from pathlib import Path
from typing import Union, Optional

# Note: Warnings are suppressed globally in docksuitex/__init__.py
import MDAnalysis as mda
import prolif as plf
import pandas as pd

# Path to Open Babel executable bundled with DockSuiteX
OBABEL_EXE = (Path(__file__).parent / "bin" / "obabel" / "obabel.exe").resolve()


class InteractionProfiler:
    """Protein–ligand interaction fingerprinting using ProLIF.

    This module wraps ProLIF to analyse the non-covalent interactions between
    a protein and docked ligand poses produced by AutoDock Vina or AutoDock4.

    The analysis workflow:
        1. Splitting a multi-model PDBQT output into individual pose files.
        2. Converting each pose from PDBQT → PDB using Open Babel.
        3. Cleaning PDB files (keeping only ATOM/HETATM/CONECT records).
        4. Loading the protein and ligand poses with MDAnalysis / ProLIF.
        5. Computing interaction fingerprints with ProLIF.
        6. Saving the resulting DataFrame as a CSV file.

    Supported Input:
        - Protein: PDB (.pdb)
        - Ligand poses: multi-model PDBQT (.pdbqt) from Vina / AD4

    Note:
        Intermediate files (split PDBQT, raw/clean PDB) are saved in
        ``prolif_intermediates/`` inside the output directory.
    """

    def __init__(
        self,
        protein_pdb: Union[str, Path],
        vina_output_pdbqt: Union[str, Path],
        _cpu: int = (os.cpu_count() or 2) - 1,
    ):
        """Initialize an InteractionProfiler with input paths and settings.

        Args:
            protein_pdb (str | Path): Path to the protein PDB file.
                This should be the original or fixed PDB (not PDBQT).
            vina_output_pdbqt (str | Path): Path to the multi-model
                ``output.pdbqt`` produced by AutoDock Vina or AutoDock4.
            _cpu (int, optional): Number of CPUs for ProLIF
                fingerprint calculation. Defaults to ``os.cpu_count() - 1``.

        Raises:
            FileNotFoundError: If either input file does not exist.
            ValueError: If file extensions are incorrect.
        """
        self.protein_pdb = Path(protein_pdb).resolve()
        self.vina_output_pdbqt = Path(vina_output_pdbqt).resolve()
        self.cpu = _cpu

        if not self.protein_pdb.is_file():
            raise FileNotFoundError(
                f"❌ Protein PDB file not found: {self.protein_pdb}")

        if not self.vina_output_pdbqt.is_file():
            raise FileNotFoundError(
                f"❌ Vina output PDBQT file not found: {self.vina_output_pdbqt}")

        if self.protein_pdb.suffix.lower() != ".pdb":
            raise ValueError(
                f"❌ Protein file must be .pdb, got '{self.protein_pdb.suffix}'")

        if self.vina_output_pdbqt.suffix.lower() != ".pdbqt":
            raise ValueError(
                f"❌ Ligand poses file must be .pdbqt, got '{self.vina_output_pdbqt.suffix}'")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _split_vina_pdbqt(input_file: Path, output_dir: Path) -> list[Path]:
        """Split a multi-model PDBQT into individual pose files.

        Args:
            input_file (Path): Multi-model PDBQT from Vina/AD4.
            output_dir (Path): Directory to write pose_N.pdbqt files.

        Returns:
            list[Path]: Sorted list of individual pose PDBQT files.
        """
        with open(input_file, "r") as f:
            lines = f.readlines()

        pose_idx = 0
        current_pose: list[str] = []

        for line in lines:
            if line.startswith("MODEL"):
                current_pose = []

            current_pose.append(line)

            if line.startswith("ENDMDL"):
                pose_idx += 1
                pose_file = output_dir / f"pose_{pose_idx}.pdbqt"
                with open(pose_file, "w") as out:
                    out.writelines(current_pose)


        return sorted(output_dir.glob("pose_*.pdbqt"))

    @staticmethod
    def _convert_and_clean_pdb(input_pdbqt: Path, output_pdb: Path) -> None:
        """Convert a PDBQT file to a clean PDB using Open Babel.

        Converts the PDBQT to PDB via Open Babel, then strips all
        non-structural records (keeping only ATOM, HETATM, and CONECT
        lines) and writes the cleaned result to ``output_pdb``.

        Args:
            input_pdbqt (Path): Input PDBQT file.
            output_pdb (Path): Output cleaned PDB file.

        Raises:
            RuntimeError: If Open Babel fails or produces an empty file.
        """
        # Convert PDBQT → PDB via Open Babel
        cmd = [
            str(OBABEL_EXE),
            "-ipdbqt", str(input_pdbqt),
            "-opdb", "-O", str(output_pdb),
        ]

        env = os.environ.copy()
        env["BABEL_DATADIR"] = str((Path(OBABEL_EXE).parent / "data").resolve())

        result = subprocess.run(cmd, capture_output=True, text=True, env=env)

        if result.returncode != 0:
            raise RuntimeError(
                f"❌ Open Babel conversion failed for {input_pdbqt}:\n{result.stderr}")

        if not output_pdb.exists() or output_pdb.stat().st_size == 0:
            raise RuntimeError(
                f"❌ Open Babel produced an empty output file: {output_pdb}")

        # Clean in-place: keep only structural records
        with open(output_pdb, "r") as f:
            lines = f.readlines()

        clean_lines = [
            line for line in lines
            if line.startswith(("ATOM", "HETATM", "CONECT"))
        ]
        clean_lines.append("END\n")

        with open(output_pdb, "w") as f:
            f.writelines(clean_lines)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        save_to: Union[str, Path, None] = None,
    ) -> pd.DataFrame:
        """Run the ProLIF interaction fingerprint analysis.

        Performs the full workflow: split poses → convert to PDB → load
        structures → compute fingerprints → save CSV.

        Args:
            save_to (str | Path, optional): Directory where the output
                CSV (``prolif_interactions.csv``) and intermediate files
                will be saved. Defaults to pocket-specific directory.

        Returns:
            pandas.DataFrame: Interaction fingerprint table with one row
            per ligand pose and columns for each residue–interaction pair.

        Raises:
            RuntimeError: If Open Babel conversion or ProLIF analysis fails.
        """
        save_to = Path(save_to).expanduser().resolve()
        save_to.mkdir(parents=True, exist_ok=True)

        intermediates_dir = save_to / "prolif_intermediates"
        split_pdbqt_dir = intermediates_dir / "split_pdbqt"
        split_pdb_dir = intermediates_dir / "split_pdb"
        split_pdbqt_dir.mkdir(parents=True, exist_ok=True)
        split_pdb_dir.mkdir(parents=True, exist_ok=True)

        # Copy input files into intermediates for reference
        shutil.copy2(self.protein_pdb, intermediates_dir / self.protein_pdb.name)
        shutil.copy2(self.vina_output_pdbqt, intermediates_dir / self.vina_output_pdbqt.name)

        # 1. Split multi-model PDBQT
        pose_pdbqt_files = self._split_vina_pdbqt(
            self.vina_output_pdbqt, split_pdbqt_dir)

        # 2. Convert PDBQT → PDB (with in-place cleaning)
        pose_pdb_files: list[Path] = []

        for pose_pdbqt in pose_pdbqt_files:
            pose_pdb = split_pdb_dir / f"{pose_pdbqt.stem}.pdb"
            self._convert_and_clean_pdb(pose_pdbqt, pose_pdb)
            pose_pdb_files.append(pose_pdb)

        # 3. Load protein
        u_prot = mda.Universe(str(self.protein_pdb))
        u_prot.atoms.guess_bonds()

        protein_mol = plf.Molecule.from_mda(
            u_prot,
            inferrer=None,
            sanitize=False,
        )

        # 4. Load ligand poses
        lig_mols: list[plf.Molecule] = []

        for pose_file in pose_pdb_files:
            u_lig = mda.Universe(str(pose_file))
            lig = plf.Molecule.from_mda(
                u_lig,
                inferrer=None,
                sanitize=False,
            )
            lig_mols.append(lig)

        # 5. Run ProLIF
        fp = plf.Fingerprint()
        fp.run_from_iterable(
            lig_mols,
            protein_mol,
            n_jobs=self.cpu,
        )

        df = fp.to_dataframe(index_col="Pose")
        df.index = df.index + 1  # 1-indexed poses

        # 6. Save results
        csv_path = save_to / "prolif_interactions.csv"
        df.to_csv(csv_path)

        print(f"✅ ProLIF analysis complete. Results saved to: {csv_path}")
        return df
