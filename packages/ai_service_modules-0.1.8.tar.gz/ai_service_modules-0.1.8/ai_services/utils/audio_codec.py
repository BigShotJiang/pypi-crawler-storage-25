
def pcm_to_wav(pcm_bytes, channels=1, sample_width=2, frame_rate=24000):
    import wave
    import io
    wav_io = io.BytesIO()

    with wave.open(wav_io, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(frame_rate)
        wf.writeframes(pcm_bytes)

    return wav_io.getvalue()


import subprocess
import io

def mp3_to_wav(mp3_bytes: bytes) -> bytes:
    with open("temp.mp3", "wb") as f:
        f.write(mp3_bytes)

    subprocess.run([
        "ffmpeg",
        "-y",
        "-i", "temp.mp3",
        "temp.wav"
    ], check=True)

    with open("temp.wav", "rb") as f:
        return f.read()