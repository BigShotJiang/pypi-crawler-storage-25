import base64
import requests
from google import genai
from google.genai import types
from ai_services.base import LLMProviderBase, TTSProviderBase, STTProviderBase
from ai_services.utils.error_handler import handle_api_errors
from ai_services.utils.audio_codec import pcm_to_wav
import logging
import os

logger = logging.getLogger(__name__)


class GeminiClientProvider(LLMProviderBase):
    def __init__(
        self,
        key: str | None = None,
        model: str = "gemini-2.0-flash",
        temperature: float = 0,
        max_tokens: int = 2048,
        event_logger=None
    ):
        if key is None:
            key = os.getenv("GEMINI_API_KEY")

        if not key:
            raise ValueError("GEMINI API key is required")

        self.client = genai.Client(api_key=key)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.event_logger = event_logger
        self.logger = logging.getLogger(__name__)

        self.logger.info(f"GeminiProvider initialized with model: {self.model}")

    def generate(self, messages, **kwargs):
        temperature = kwargs.get("temperature", self.temperature)
        max_tokens = kwargs.get("max_tokens", self.max_tokens)

        try:
            if not self.validate_messages(messages):
                self.logger.warning("Message validation failed.")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        status="validation_failed",
                        error="Invalid message format"
                    )
                return None

            prompt = ""
            if isinstance(messages, list):
                user_messages = [
                    msg.get("content", "")
                    for msg in messages
                    if msg.get("role") == "user" and msg.get("content")
                ]
                prompt = "\n".join(user_messages).strip()
            elif isinstance(messages, str):
                prompt = messages.strip()

            if not prompt:
                self.logger.warning("Empty prompt.")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        status="validation_failed",
                        error="Empty prompt"
                    )
                return None

            self.logger.info(f"Sending prompt to Gemini: {prompt[:100]}...")

            response = self.client.models.generate_content(
                model=self.model,
                config=types.GenerateContentConfig(
                    temperature=temperature,
                    max_output_tokens=max_tokens,
                ),
                contents=[prompt]
            )

            if hasattr(response, "text") and response.text.strip():
                result = response.text.strip()

                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        response_data={"result": result}
                    )

                return result

            self.logger.warning("No valid response from Gemini.")
            return "No valid response returned from Gemini."

        except Exception as e:
            self.logger.exception("LLM generation error")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="error",
                    error=str(e)
                )

            return "Error in generating response from Gemini."


class GeminiTTSProvider(TTSProviderBase):
    CHANNELS = 1
    SAMPLE_WIDTH = 2
    FRAME_RATE = 24000

    def __init__(
        self,
        key: str | None = None,
        model: str = "gemini-2.5-flash-preview-tts",
        voice: str = "Kore",
        event_logger=None
    ):
        if key is None:
            key = os.getenv("GEMINI_API_KEY")

        if not key:
            raise ValueError("GEMINI API key is required")
        self.api_key = key
        self.model = model
        self.voice = voice
        self.event_logger = event_logger
        self.logger = logging.getLogger(__name__)

        self.logger.info(f"GeminiTTSProvider initialized with model: {self.model}, voice: {self.voice}")

    def generate_speech(self, text: str) -> bytes | None:
        if not self.validate_text(text):
            self.logger.warning("Invalid text input for TTS")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="validation_failed",
                    error="Invalid text input"
                )
            return None
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }


        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"

        payload = {
            "contents": [
                {"role": "user", "parts": [{"text": text}]}
            ],
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {
                        "prebuiltVoiceConfig": {
                            "voiceName": self.voice
                        }
                    }
                }
            }
        }

        try:
            self.logger.info(f"Generating speech using Gemini TTS: {self.model}")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text, "voice": self.voice}
                )

            res = requests.post(url, json=payload,headers=headers, timeout=30)
            res.raise_for_status()

            data = res.json()

            audio_base64 = (
                data.get("candidates", [{}])[0]
                .get("content", {})
                .get("parts", [{}])[0]
                .get("inlineData", {})
                .get("data")
            )

            if not audio_base64:
                self.logger.warning("No audio returned from Gemini TTS")

                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="TTS",
                        module=__name__,
                        function="generate_speech",
                        request_data={"text": text},
                        status="error",
                        error="No audio returned"
                    )
                return None

            pcm_bytes = base64.b64decode(audio_base64)

            audio_bytes = pcm_to_wav(
                pcm_bytes,
                channels=self.CHANNELS,
                sample_width=self.SAMPLE_WIDTH,
                frame_rate=self.FRAME_RATE
            )

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    response_data={"audio_size_bytes": len(audio_bytes)}
                )

            return audio_bytes

        except Exception as e:
            self.logger.exception("TTS generation error")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="error",
                    error=str(e)
                )

            handle_api_errors(self.__class__.__name__, e)
            return None
        
class GeminiSTTProvider(STTProviderBase):
    def __init__(
        self,
        key: str | None = None,
        model: str = "gemini-1.5-flash",
        event_logger=None
    ):
        key = key or os.getenv("GEMINI_API_KEY")

        if not key:
            raise ValueError("GEMINI API key is required")

        self.api_key = key
        self.model = model
        self.event_logger = event_logger
        self.logger = logging.getLogger(__name__)

    def _encode_audio(self, audio_path: str) -> str:
        with open(audio_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def generate_text(self, audio_path: str):
        try:
            if not audio_path or not os.path.exists(audio_path):
                self.logger.warning(f"Audio file not found: {audio_path}")

                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="STT",
                        module=__name__,
                        function="generate_text",
                        request_data={"audio_path": audio_path},
                        status="validation_failed",
                        error="Invalid audio path"
                    )
                return None

            audio_b64 = self._encode_audio(audio_path)

            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key
            }

            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"

            payload = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [
                            {
                                "inlineData": {
                                    "mimeType": "audio/wav",
                                    "data": audio_b64
                                }
                            },
                            {
                                "text": "Transcribe this audio accurately."
                            }
                        ]
                    }
                ]
            }

            self.logger.info(f"Transcribing with Gemini STT: {self.model}")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="STT",
                    module=__name__,
                    function="generate_text",
                    request_data={"audio_path": audio_path}
                )

            res = requests.post(
                url,
                json=payload,
                headers=headers,
                timeout=30
            )
            res.raise_for_status()

            data = res.json()

            text = (
                data.get("candidates", [{}])[0]
                .get("content", {})
                .get("parts", [{}])[0]
                .get("text", "")
                .strip()
            )

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="STT",
                    module=__name__,
                    function="generate_text",
                    request_data={"audio_path": audio_path},
                    response_data={"transcription": text},
                    status="success" if text else "empty"
                )

            return text if text else None

        except Exception as e:
            self.logger.error(f"Gemini STT error: {str(e)}")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="STT",
                    module=__name__,
                    function="generate_text",
                    request_data={"audio_path": audio_path},
                    status="error",
                    error=str(e)
                )

            return None        