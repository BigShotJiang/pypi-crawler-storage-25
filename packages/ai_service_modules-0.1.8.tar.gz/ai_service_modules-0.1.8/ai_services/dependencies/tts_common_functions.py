import logging

logger = logging.getLogger(__name__) 

class SimpleAudioPlayer:
    def play(self, audio_bytes: bytes):
        import pygame
        import time
        import io

        pygame.mixer.init()

        audio_io = io.BytesIO(audio_bytes)
        audio_io.seek(0)

        pygame.mixer.music.load(audio_io)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            time.sleep(0.05)