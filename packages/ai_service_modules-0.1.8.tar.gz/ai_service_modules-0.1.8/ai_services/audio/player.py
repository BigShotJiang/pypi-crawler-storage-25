import pygame
import time
import io


class AudioPlayer:
    def __init__(self):
        pygame.mixer.init()

    def play(self, audio_bytes: bytes):
        try:
            audio_io = io.BytesIO(audio_bytes)
            audio_io.seek(0)

            pygame.mixer.music.load(audio_io)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy():
                time.sleep(0.05)

        except Exception as e:
            print(f"Playback Error: {e}")