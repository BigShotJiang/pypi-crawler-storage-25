from dataclasses import dataclass

from .svc import svc


# --------------------
## info for the OpenGL package
class PackageOpengl:
    # --------------------
    ## return info about the pkgname
    #
    # @param pkgname  the name of the package; default: opengl
    # @return ref to OpenGl info
    def find(self, pkgname):
        svc.log.line(f'finding package: {pkgname}')

        if svc.gbl.os_name == 'ubuntu':
            #
            @dataclass
            class OpenGl:
                include_dir = '/usr/include'
                link_libs = ['glut', 'GLU', 'GL']
                link_dir = []  # not needed
                link_options = []  # not needed

        elif svc.gbl.os_name == 'macos':
            # TODO use this for include_dir: brew --prefix freeglut
            @dataclass
            class OpenGl:
                include_dir = []
                link_libs = []
                link_dir = []
                link_options = [
                    '-framework GLUT',
                    '-framework OpenGL',
                ]

        else:

            @dataclass
            class OpenGl:
                pass
                # TODO: set up for win/msys2
                # include_dir = []
                # link_libs = []
                # link_dir = []
                # link_options = []

        return OpenGl
