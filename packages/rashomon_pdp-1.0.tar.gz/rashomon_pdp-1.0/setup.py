from setuptools import setup, find_packages


with open("./README.md", 'r') as f:
    description = f.read()

with open("./requirements.txt", 'r') as f:
    requirements = [req[:-1] for req in f.readlines()]

setup(
    name='rashomon_pdp',
    version='1.0',  # INCREMENT!!
    packages=find_packages(),
    install_requires=requirements,
    long_description=description,
    long_description_content_type="text/markdown",
)
