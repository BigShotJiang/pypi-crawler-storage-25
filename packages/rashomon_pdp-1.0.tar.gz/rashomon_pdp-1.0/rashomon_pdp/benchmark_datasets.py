"""
Dataset loading utilities for the Rashomon Toolkit.
Downloads benchmark datasets from OpenML.

Author: Move 78
Date: 2026-04-03
"""

import openml
import pandas as pd
from sklearn.model_selection import train_test_split
from typing import Dict, List, Tuple

# Regression datasets from OpenML-CTR23 with their task IDs.
REGRESSION_DATASETS = {
    "abalone": 361234,
    "airfoil_self_noise": 361235,
    "auction_verification": 361236,
    "brazilian_houses": 361267,
    "california_housing": 361255,
    "cars": 361622,
    "concrete_compressive_strength": 361237,
    "cps88wages": 361261,
    "cpu_activity": 361256,
    "diamonds": 361257,
    "energy_efficiency": 361617,
    "fifa": 361272,
    "forest_fires": 361618,
    "fps_benchmark": 361268,
    "geographical_origin_of_music": 361243,
    "grid_stability": 361251,
    "health_insurance": 361269,
    "kin8nm": 361258,
    "kings_county": 361266,
    "miami_housing": 361260,
    "Moneyball": 361616,
    "naval_propulsion_plant": 361247,
    "physiochemical_protein": 361241,
    "pumadyn32nh": 361259,
    "QSAR_fish_toxicity": 361621,
    "red_wine": 361250,
    "sarcos": 361254,
    "socmob": 361264,
    "solar_flare": 361244,
    "space_ga": 361623,
    "student_performance_por": 361619,
    "superconductivity": 361242,
    "video_transcoding": 361252,
    "wave_energy": 361253,
    "white_wine": 361249,
}

# Binary classification datasets from OpenML-CC18 with their task IDs.
BINARY_CLASSIFICATION_DATASETS = {
    "adult": 7592,
    "bank-marketing": 14965,
    "banknote-authentication": 10093,
    "Bioresponse": 9910,
    "blood-transfusion-service-center": 10101,
    "breast-w": 15,
    "churn": 167141,
    "climate-model-simulation-crashes": 146819,
    "credit-approval": 29,
    "credit-g": 31,
    "cylinder-bands": 14954,
    "diabetes": 37,
    "electricity": 219,
    "ilpd": 9971,
    "jm1": 3904,
    "kc1": 3917,
    "kc2": 3913,
    "madelon": 9976,
    "nomao": 9977,
    "numerai28.6": 167120,
    "ozone-level-8hr": 9978,
    "pc3": 3903,
    "pc4": 3902,
    "phoneme": 9952,
    "qsar-biodeg": 9957,
    "sick": 3021,
    "spambase": 43,
    "wdbc": 9946,
    "wilt": 146820,
}


def get_available_regression_datasets() -> List[str]:
    """
    Returns a list of all available regression dataset names.

    Returns:
        List[str]: List of dataset names that can be used with load_regression_dataset().
    """
    return list(REGRESSION_DATASETS.keys())

def get_available_classification_datasets() -> List[str]:
    """
    Returns a list of all available binary classification dataset names.

    Returns:
        List[str]: List of dataset names that can be used with load_classification_dataset().
    """
    return list(BINARY_CLASSIFICATION_DATASETS.keys())


def load_regression_dataset(name: str) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Load a regression dataset from OpenML by its name.

    Parameters:
        name (str): Name of the regression dataset to load.
                    Must be one of the keys in REGRESSION_DATASETS.

    Returns:
        Tuple[pd.DataFrame, pd.Series]: A tuple containing:
            - X (pd.DataFrame): Feature matrix with shape (n_samples, n_features)
            - y (pd.Series): Target values with shape (n_samples,)
    """
    # Validate dataset name exists
    if name not in REGRESSION_DATASETS:
        raise ValueError(f"Dataset '{name}' not found. Available regression datasets: "
                         f"{list(REGRESSION_DATASETS.keys())}")

    tid = REGRESSION_DATASETS[name] # Get the task ID for the dataset
    task = openml.tasks.get_task(tid) # Load the task from OpenML
    dataset = task.get_dataset() # Extract the dataset from the task

    # Get features (X) and target (y) as DataFrame and Series
    X, y, _, _ = dataset.get_data(
        dataset_format="dataframe",
        target=dataset.default_target_attribute
    )

    return X, y

def load_classification_dataset(name: str) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Load a binary classification dataset from OpenML by its name.

    Parameters:
        name (str): Name of the binary classification dataset to load.
                    Must be one of the keys in BINARY_CLASSIFICATION_DATASETS.

    Returns:
        Tuple[pd.DataFrame, pd.Series]: A tuple containing:
            - X (pd.DataFrame): Feature matrix with shape (n_samples, n_features)
            - y (pd.Series): Binary target labels with shape (n_samples,)
    """
    # Validate dataset name exists
    if name not in BINARY_CLASSIFICATION_DATASETS:
        raise ValueError(f"Dataset '{name}' not found. Available binary classification datasets: "
                         f"{list(BINARY_CLASSIFICATION_DATASETS.keys())}"
        )

    tid = BINARY_CLASSIFICATION_DATASETS[name] # Get the task ID for the dataset
    task = openml.tasks.get_task(tid) # Load the task from OpenML
    dataset = task.get_dataset() # Extract the dataset from the task

    # Get features (X) and target (y) as DataFrame and Series
    X, y, _, _ = dataset.get_data(
        dataset_format="dataframe",
        target=dataset.default_target_attribute
    )

    return X, y


def load_all_regression_datasets() -> Dict[str, Tuple[pd.DataFrame, pd.Series]]:
    """
    Load all available regression datasets from OpenML.

    This function iterates through all regression datasets defined in REGRESSION_DATASETS and loads each one.

    Returns:
        Dict[str, Tuple[pd.DataFrame, pd.Series]]: Dictionary mapping dataset names to their (X, y) tuples.
    """
    datasets = {}
    for name in REGRESSION_DATASETS:
        datasets[name] = load_regression_dataset(name)
    return datasets


def load_all_classification_datasets() -> Dict[str, Tuple[pd.DataFrame, pd.Series]]:
    """
    Load all available binary classification datasets from OpenML.

    This function iterates through all binary classification datasets defined in BINARY_CLASSIFICATION_DATASETS and loads each one.

    Returns:
        Dict[str, Tuple[pd.DataFrame, pd.Series]]: Dictionary mapping dataset names to their (X, y) tuples.
    """
    datasets = {}
    for name in BINARY_CLASSIFICATION_DATASETS:
        datasets[name] = load_classification_dataset(name)
    return datasets


def prepare_dataset_for_testing(
    X: pd.DataFrame,
    y: pd.Series,
    test_size: float = 0.2,
    random_state: int = 123
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Split a dataset into training and testing sets for model evaluation.

    Parameters:
        X (pd.DataFrame): Feature matrix to be split.
        y (pd.Series): Target values to be split.
        test_size (float): Proportion of the dataset to include in the test split.
                           Must be between 0.0 and 1.0. Default is 0.2 (20%).
        random_state (int): Random seed for reproducible splits. Default is 123.

    Returns:
        Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]: A tuple containing:
            - X_train (pd.DataFrame): Training features
            - X_test (pd.DataFrame): Testing features
            - y_train (pd.Series): Training targets
            - y_test (pd.Series): Testing targets
    """
    # Split the data with consistent random state for reproducibility
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    return X_train, X_test, y_train, y_test