import numpy as np


class Metric:
    """
    Base class for metric functionalities that can be used in Abstract PDP family objects.

    Metric class objects will contain:
        - (attr) obj: Abstract_PDP object which is used for model and data handling,
        - (attr) data: Module specific DataFrame type test dataset,
        - (func) init: Initializer function which copies parameters to relevant attributes,
        - (func): Function which accepts targets and returns a metric score. 
    """
    def __init__(self, obj, data):
        self.obj = obj
        self.data = data

    def __call__(self, responses_actual, model = None):
        raise NotImplementedError("Abstract Class Call.")


 
class Accuracy(Metric):
    """
    Compare each prediction with target and returns the numerical mean of hits/misses.
    Accuracy = 1/n * sum(predicted == target)
    """
    def __call__(self, responses_actual, model = None) -> float:
        responses_predict = self.obj.predict(self.data, model)['predictions']
        return np.mean(responses_actual == responses_predict)
    