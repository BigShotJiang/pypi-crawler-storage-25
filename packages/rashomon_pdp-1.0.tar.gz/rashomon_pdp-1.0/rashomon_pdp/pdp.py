### INCOMPLETE ###
import h2o
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from .metrics import Metric


class Rashomon_PDP:
    """
    Base class for Rashomon Partial Dependance Profile objects from different machine learning modules, contains abstract functions 
    for PDP calculation and creation as well as fully developed functions for a Rashomon PDP built on top.

    PDP class objects will contain:
        - (attr) model: Single or suite auto machine learning model,
        - (attr) models: Every model that exists in the PDP object,
        - (attr) rashomon_set: Set of models within epsilon hyperparameter metric score from an optimal model,
        - (attr) predictors: Names of predictor columns,
        - (attr) responses: Names of response columns,
        - (attr) feature: Controlled feature for PDP calculation,
        - (attr) metric: Metric used in generating the rashomon set,
        - (func) init: Initializer function which copies parameters to relevant attributes,
        - (func): Calculate Rashomon PDP value for a given feature value and sample,
        - (func) pdp: Calculates a basic PDP for a given feature value and sample with optionality for model selection,
        - (func) change_feature: Changes the PDP conntrol feature,
        - (func) change_metric: Changes the Rashomon set selection metric,
        - (func) rashomon_ratio: Calculates the ratio between Rashomon set size and total number of models that exist in PDP object,
        - (func) get_rashomon_set: Generates the Rashomon set using the metric and epsilon hyperparameter,
        - (func) bootstrap: Calculates Rashomon PDP confidence intervals by bootstrapping with n_boots and alpha hyperparameters,
        - (abst) read_data: Read dataset from a provided path,
        - (abst) data_split: Split a dataset into subsets,
        - (abst) train: 
        - (abst) get_models:
        - (abst) predict:
        - (abst) _modify_feature:
        - (abst) _revert_feature:
        - (abst) get_scores:
    """
    @staticmethod
    def read_data(data_path: str):
        raise NotImplementedError("Abstract Class Call.")
    
    @staticmethod
    def data_split(self, data, **kwargs) -> list:
        raise NotImplementedError("Abstract Class Call.")
    
    def train(self, predictors, responses, data):
        raise NotImplementedError("Abstract Class Call.")
    
    def get_models(self) -> np.array:
        raise NotImplementedError("Abstract Class Call.")

    def predict(self, sample, model_name: str = None) -> dict:
        raise NotImplementedError("Abstract Class Call.")
    
    def _modify_feature(self, feature_value, sample):
        raise NotImplementedError("Abstract Class Call.")
    
    def _revert_feature(self, original_values, sample) -> None:
        raise NotImplementedError("Abstract Class Call.")
    
    def get_scores(self, sample, **kwargs) -> np.array:
        raise NotImplementedError("Abstract Class Call.")
    
    def __init__(self, model, feature: str = None, metric: Metric = None, **kwargs):
        """
        Basic initializer function.
        """
        self.model = model(**kwargs)
        self.models = None
        self.rashomon_set = None
        self.predictors = []
        self.responses = []
        self.feature = feature
        self.metric = metric
    
    def pdp(self, feature_value, sample, model = None) -> float:
        """
        Calculate PDP with a given feature value on a dataset sample with an optional model.
        pdp(x) = 1/n * sum(f(X))  # X changes but the feature value is static
        
        Returns:
            PDP value as a mean or ratio depending on response type.
        """
        # Basic checks
        if self.feature is None:
            raise ValueError("Select the feature with which the PDP will be calculated.")
        if sample is None:
            raise ValueError("Provide a dataset.")
        if model is None:
            model = self.model
        # Run PDP
        original_values = self._modify_feature(feature_value, sample)
        results = self.predict(sample, model)['predictions']
        self._revert_feature(original_values, sample)
        # Return either the mean of results or agreement ratio
        try:
            return results.mean()
        except TypeError:
            le = LabelEncoder()
            return le.fit_transform(results).mean()

    def change_feature(self, feature: str):
        """
        Change PDP control feature.
        """
        self.feature = feature
    
    def change_metric(self, metric: Metric):
        """"
        Change Rashomon set generation metric.
        """
        self.metric = metric

    def rashomon_ratio(self):
        """
        Calculate ratio of Rashomon set models to all used models.
        r = |R|/|M|

        Returns:
            Rashomon ratio.       
        """
        if self.rashomon_set is None:
            raise ValueError("Generate a rashomon set.")
        return len(self.rashomon_set) / len(self.models)
    
    def get_rashomon_set(self, sample, epsilon: float = 0.2, **kwargs) -> np.array:
        """
        Generate the Rashomon set using the selected metric on provided dataset sample and 
        epsilon hyperparameter value.
        R = {M | metric(M) <= [metric(optimal_M) * (1+epsilon)]}

        Returns:
            Array of models which make up the Rashomon set.
        """
        # Check if the metric and models exist yet
        if self.metric is None:
            raise AttributeError("Metric not defined.")
        if self.models is None:
            self.get_models()
        # Calculate metrics and select rashomon set with best model
        scores = self.get_scores(sample, **kwargs)
        optimal_idx = np.argmin(scores)
        model_in_set = scores <= (scores[optimal_idx] * (1 + epsilon))
        self.rashomon_set = np.array(self.models[model_in_set])
        return self.rashomon_set
    
    def __call__(self, feature_value, sample, models = None, **kwargs):
        """
        Calculate Rashomon PDP value for a given feature value and dataset sample, with optional 
        models set selection for later bootstrapping.
        r_pdp(x) = 1/|R| * sum(pdp(x))  # pdp changes per model

        Returns:
            Rashomon PDP value.
        """
        # Ensure set-up is complete
        if self.rashomon_set is None:
            self.get_rashomon_set(sample, **kwargs)
        if models is None:
            models = self.get_models()
        # Calculate rashomon PDP for given value
        results = np.zeros(len(models))
        for idx, model in enumerate(models):
            results[idx] = self.pdp(feature_value, sample, model)
        return results.mean()
    
    def bootstrap(self, feature_value, sample, n_boots: int = 100, alpha: float = 0.05, **kwargs):
        """
        Bootstrap Rashomon PDP calculation to get a confidence interval alongside the actual value, 
        number of bootstraps and confidence interval are both hyperparameters.

        Returns:
            Rashomon PDP value and confidence interval.
        """
        # Calculate base Rashomon PDP
        rashomon_pdp = self(feature_value, sample, **kwargs)
        boot_means = []
        # Perform each bootstrap to calculate confidence intervals
        for _ in range(n_boots):
            boot_sample = np.random.choice(self.models, len(self.models), replace=True)
            boot_means.append(self(feature_value, sample, boot_sample, **kwargs))
        boot_means = np.array(boot_means)
        confidence_interval = np.percentile(boot_means, [alpha*50, 100-(alpha*50)])
        return rashomon_pdp, confidence_interval
    

class h2o_PDP(Rashomon_PDP):
    """
    H2O-3 implementation of the Rashomon PDP.
    """
    @staticmethod
    def read_data(data_path: str) -> h2o.H2OFrame:
        try:
            return h2o.import_file(data_path)
        except Exception as err0:
            print(f"Unexpected error {err0} encountered while reading data.")
            raise
    
    @staticmethod
    def data_split(data: h2o.H2OFrame, ratios: list[float] = None, seed: int = None) -> list[h2o.H2OFrame]:
        return data.split_frame(ratios=ratios, seed=seed)
    
    def train(self, predictors: list[str], responses: str | list[str], data: h2o.H2OFrame):
        self.predictors = predictors
        self.responses = responses
        return self.model.train(x=predictors, y=responses, training_frame=data)
    
    def get_models(self) -> np.array:
        # Function called before
        if self.models is not None:
            return self.models
        # Get all model IDs
        if hasattr(self.model, "get_leaderboard"):
            model_names = self.model.get_leaderboard()['model_id'].as_data_frame()['model_id']
            self.models = [h2o.get_model(model_name) for model_name in model_names]
        else:
            print("There is no model leaderboard, returning self.model")
            self.models = [self.model]
        self.models = np.array(self.models)
        return self.models
    
    def predict(self, sample: h2o.H2OFrame, model = None) -> dict:
        # Model selection
        if model is None:
            model = self.model
        # Get prediction and labels
        pred = model.predict(sample).as_data_frame()
        labels = pred["predict"].values
        # Get probabilities
        prob_cols = [c for c in pred.columns if c != "predict"]
        probs = pred[prob_cols].values if prob_cols else None
        # Return as dictionary of predictions and probabilities
        return {"predictions": labels, "probabilities": probs}
    
    def _modify_feature(self, feature_value, sample: h2o.H2OFrame) -> h2o.H2OFrame:
        if self.feature not in sample.columns:
            raise KeyError(f"Feature {self.feature} does not exist in sample columns.\n{sample.columns}")
        sample["pdp_copy"] = sample[self.feature]
        sample[self.feature] = feature_value
        return sample["pdp_copy"]
    
    def _revert_feature(self, original_values, sample: h2o.H2OFrame) -> None:
        copied = original_values.columns
        sample[self.feature] = original_values
        sample = sample.drop(copied)

    def get_scores(self, sample: h2o.H2OFrame, **kwargs):
        metric = self.metric(self, sample, **kwargs)
        responses_actual = sample[self.responses].as_data_frame()[self.responses]
        scores = []
        for model in self.models:
            scores.append(metric(responses_actual, model))
        return np.array(scores)

    @staticmethod
    def factorize(data: h2o.H2OFrame, columns: str | list[str]) -> None:
        """
        Transform values into categoricals.
        """
        if isinstance(columns, str):
            columns = [columns]
        for col in columns:
            data[col] = data[col].asfactor()


class sklearn_PDP(Rashomon_PDP):
    """
    Sci-kit Learn implementation of the Rashomon PDP.
    """
    @staticmethod
    def read_data(data_path: str):
        return pd.read_csv(data_path)
    
    def predict(self, sample, model = None):
        if model is None:
            model = self.model
        labels = model.predict(sample)
        probs = None
        if hasattr(self.model, "predict_proba"):
            probs = self.model.predict_proba(sample)
        return {"predictions": np.array(labels), "probabilities": probs}
    

def make_PDP(model, feature: str = None, metric: Metric = None, 
             framework: str = 'h2o', **kwargs) -> Rashomon_PDP:
    """
    Make the correct class selection easier and more streamlined.

    Returns:
        Rashomon PDP object of correct framework.
    """
    match framework:
        case 'h2o':
            return h2o_PDP(model, feature, metric, **kwargs)
        case 'sklearn':
            return sklearn_PDP(model, feature, metric, **kwargs)
        case _:
            raise NotImplementedError("Given framework is not yet adapted.")
