"""
The first version of the Rashomon Toolkit.
Author: Move 78
Date: 02-03-2026
"""
import matplotlib.pyplot as plt

def add(x,y):
    """Just a simple add function"""
    return x + y

def get_name():
    """Function that returns the package name"""
    return "Rashomon Toolkit"

def plot_test_graph():
    """
    Creates a simple line graph to test other libraries.
    And how it behaves with pip
    """
    # Some data to plot
    x = [0, 1, 2, 3, 4, 5]
    y = [0, 1, 4, 9, 16, 25] 

    plt.figure(figsize=(8, 5))
    plt.plot(x, y, marker='o', linestyle='-', color='b', label='Growth')
    
    # Adding titles and labels
    plt.title("Simple Square Growth Graph")
    plt.xlabel("Input Value (x)")
    plt.ylabel("Squared Value (y)")
    plt.legend()
    plt.grid(True)
    
    plt.show()

class Toolkit: 
    def __init__(self,owner="Guest"):
        self.owner = owner
    
    def hello(self):
        """Welcomes the user to the toolkit"""
        return f"Hello {self.owner} and welcome to the {get_name()} !"
    
    def calculate(self,a,b):
        """Uses the add function to do addition"""
        return add(a,b)

    def subtract(self,a,b):
        """Just a simple subract function: first - second"""
        return(a-b)
    
