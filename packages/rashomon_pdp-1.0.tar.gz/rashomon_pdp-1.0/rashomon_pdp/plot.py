"""
A file where we can create functions that will render different types of plots
Author: Move 78
Date: 17-03-2026
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

def ci_plot(data: pd.DataFrame,
                      x_col: str,
                      y_col: str,
                      x_title: str,
                      y_title: str,
                      title: str,
                      description: str) -> None:
    """
    Plots a Seaborn line plot with confidence interval that contains a title and a sub-plot description.
    
    Parameters:
        data (float): The data for the plot.

        x_col (str): Give the name of the x-axis column.
        y_col (str): Give the name of the y-axis column.

        x_title (str): Give the title of the x-axis.
        y_title (str): Give the title of the y-axis.

        title (str): Give the title of the plot.
        description (str): Put a small description of the plot.

    Returns:
        Renders a plot.
    """

    # Choose the plot size and the type of plot.
    plt.figure(figsize=(10, 6))
    ax = sns.lineplot(data=data, x=x_col, y=y_col, errorbar=('ci', 95))

    # Add Title and Labels.
    ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel(x_title.capitalize(), fontsize=12)
    ax.set_ylabel(y_title.capitalize(), fontsize=12)

    # Add Description below the plot.
    plt.figtext(0.5, 0.01, description, wrap=True, horizontalalignment='center',color='gray')

    # Render the plot.
    plt.show()


def example_plot():
    """
    A test function to use the ci_plot function

    Returns:
        Nothing on its own
    """
    # A data set from seaborn.
    df = sns.load_dataset("dots")
    # A call to the ci_plot function with all the parameters.
    ci_plot(df, "time", "firing_rate", "surface_area", "Response", "Rashomon Set- PDP visualisation",
            "Note: The shaded area represents the 95% confidence interval.")


if __name__ == "__main__":
    example_plot()
