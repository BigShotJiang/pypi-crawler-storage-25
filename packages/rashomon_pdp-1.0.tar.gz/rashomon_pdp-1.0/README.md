# Rashomon_Toolkit

Rashomon_Toolkit is a python package that allows for the use of the Rashomon Partial Dependence Profile (PDP) framework to aggregate the explanation performance of multiple near-optimal models.

## Installation

Use the package manager [pip](https://pypi.org/project/rashomon-toolkit/#files) to install the rashomon_toolkit package.

```bash
pip install rashomon-toolkit
```

## Dependencies

- matplotlib>=3.7
- seaborn>=0.13.2
- pandas>=2.2.3
- numpy>=2.2.0

See `requirements.txt` for direct installation of dependencies.

## Usage

## Contributing

Contribution credit to:
- [Laith Agbaria](https://github.com/L-Agbaria) 
- [CJ Reitter](https://github.com/cj-reitter)
- [Varun Brahmadin](https://github.com/varun-brahm)
- [Marit Paul](https://github.com/MaritPaul)
- [Bing Steens](https://github.com/Bing-st)
- [Gideon Mazzola](https://github.com/GideonM123)

## License

[MIT](https://github.com/ludev-nl/2026-30-Rashomon_Toolkit/blob/main/LICENSE)
