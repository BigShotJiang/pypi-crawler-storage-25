import logging
import os


class WorkspaceObject(Object):
    """ Workspace base object. All workspace types should inherit. """

    def __init__(self, id=None, name=None, type=None, description=None):
        self.id = id
        self.name = name
        self.type = type
        self.description = description
        self.parents = []
        self.children = []

    def get_parent(self, obj):
        """ Get parent of object """
        pass

    def get_children(self, obj):
        """ Get children of obj """
        pass

    def get_by_type(self, obj, type=None):
        """ Get all children by type """
        pass


class ActionObject(WorkspaceObject):

    def __init__(self, id=None, name=None, type=None, description=None,
                 action_module=None,
                 ):
        super().__init__(id=id, name=name, type=type, description=description)

        self.action_module = action_module

        # 'action_module': {

        # 'playbook_action_id': '20',
        # 'action_name': 'Block File',
        # 'description': 'Contain and prevent any further execution of the given file.',
        # 'action_module': 'playbook.contain.BlockFile',
        # 'category': 'contain',
        # 'enabled': 'true',


class DecisionObject(WorkspaceObject):
    pass


class MatchObject(WorkspaceObject):
    pass


class PlaybookObject(Object):
    """ Data model for Playbook Objects.

        Args:
            playbook_id (int) Playbook ID
            group_name (str) Group name Playbook is assigned
            description (str) Description of playbook
            date_added (datetime) Python datatime object of when playbook was added
            last_updated (datetime) Python datetime object of when playbook was last updated
            priority (str) Playbook priority options are ['Critical', 'High', 'Medium', 'Low']
            enabled (boolean) Playbook is enabled True, or not enabled False
            workspace (list) List of Dictionaries which are Playbook Components

    """

    def __init__(self,
                 playbook_id=None,
                 group_name=None,
                 description=None,
                 date_added=None,
                 last_updated=None,
                 priority=None,
                 enabled=None,
                 workspace=None
                 ):
        self.playbook_id = playbook_id
        self.group_name = group_name
        self.description = description
        self.date_added = convert_str_time(date_added)
        self.last_updated = convert_str_time(last_updated)
        self.priority = priority
        self.enabled = enabled
        self.workspace = self.parse_workspace(workspace)

    def parse_workspace(self, workspace):
        """ Parse workspace into consistent model. """
        types = ('begin', 'action', 'decision', 'filter', 'end')
