from .base import BaseModel


class IngestObject(BaseModel):
    """ Data model for Investigate Objects.

        Args:
            uid (uuidv4): Unique uuidv4 of this obj instance, Assigned by SOAR API
            groups (dict): Group informations used for permissions
            status (str): local current status, can be one of the following new, pending, processing, done, timeout
            ttl (int): Seconds this object is allowed to live for. If ttl is exceeded object.status should be set to timeout and returned
            plugin_action (list): List of actions that should be performed and by what plugin(s) i.e.
                                {
                                    'plugin_id': plugin_id, #Plugin ID as it's registered in SOAR API
                                    'plugin_name': plugin_name,
                                    'plugin_config': plugin_config,
                                    'plugin_action': plugin_action
                                }
            processed_artifacts (dict): Results of plugin after processing request
    """

    def __init__(
            self,
            uid=None,
            groups=None,
            status=None,
            ttl=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.groups = groups
        self.status = status
        self.ttl = ttl
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class InvestigateObject(BaseModel):
    """ Data model for Investigate Objects.

        Args:
            uid (uuidv4): Unique uuidv4 of this obj instance, Assigned by SOAR API
            groups (dict): Group informations used for permissions
            status (str): local current status, can be one of the following new, pending, processing, done, timeout
            ttl (int): Seconds this object is allowed to live for. If ttl is exceeded object.status should be set to timeout and returned
            plugin_action (list): List of actions that should be performed and by what plugin(s) i.e.
                                {
                                    'plugin_id': plugin_id, #Plugin ID as it's registered in SOAR API
                                    'plugin_name': plugin_name,
                                    'plugin_config': plugin_config,
                                    'plugin_action': plugin_action
                                }
            artifacts (list): List of dictionaries containing the information plugins can use to process the request. TODO:Still in progress i.e.
                                {
                                    event_data : {
                                        resource_address : '127.0.0.1',
                                        key : value
                                    },
                                    plugin_data : {
                                        key : value,
                                        key : value
                                    },
                                    other : {
                                        key:value,
                                        key:value
                                    }
                                }
            processed_artifacts (dict): Results of plugin after processing request
    """

    def __init__(
            self,
            uid=None,
            groups=None,
            status=None,
            ttl=None,
            plugin_action=[],
            artifacts=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.ttl = ttl
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.artifacts = artifacts
        self.processed_artifacts = processed_artifacts


class ContainObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class RecoverObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class NotifyObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class RecordObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class UtilityObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class DecisionObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts


class IncludeObject(BaseModel):
    def __init__(
            self,
            uid=None,
            plugin_id=None,
            soar_id=None,
            groups=None,
            status=None,
            plugin_action=[],
            processed_artifacts={}
    ):
        self.uid = uid
        self.plugin_id = plugin_id
        self.soar_id = soar_id
        self.groups = groups
        self.status = status
        self.plugin_action = plugin_action
        self.processed_artifacts = processed_artifacts
