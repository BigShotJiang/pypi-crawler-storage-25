import json
import unittest
from unittest import mock
from hawkSoar.lib.auth import Authentication


class FakeResponse(object):
    # default response attributes
    status_code = 200
    content = "Some content"

    def __init__(self, status, content):
        self.status_code = status
        self.content = content

    def json(self):
        return json.loads(self.content)


class TestAuth(unittest.TestCase):

    def test_auth1(self):
        a = Authentication("https://localhost:8443",
                           "client_id_1", "client_secret")

        a.setVerify(False)
        a.setPrivateKey("/tmp/hawk-soard-test.key")
        a.setPublicKey("/tmp/hawk-soard-test.key")
        a.setUUIDFile("/tmp/hawk-soard-test-client-id")
        self.assertEqual(a.verify, False)

        with mock.patch.object(a.Session, 'get') as mock_request:
            fake_response = FakeResponse(
                200, '{"clientId": "4334a99c-cb4e-49c6-b5f5-afd9239372f5", "editable": true, "group": "96edb385-650a-46d3-ae19-cd9e369f5a4a", "id": "0beee969-20e8-4305-a22d-95df239c9951", "name": "AzureAD Node", "description": "AD node", "authorize_uri": "https://login.microsoftonline.com/8f9158f0-af26-4fa3-ba90-a8f9ca38cfba/oauth2/v2.0/authorize", "redirect_uri": "https://10.11.0.162:8443/api/auth/callback", "token_uri": "https://login.microsoftonline.com/8f9158f0-af26-4fa3-ba90-a8f9ca38cfba/oauth2/v2.0/token", "userinfo_uri": "https://graph.microsoft.com/oidc/userinfo", "response_type": ["code", "token"], "response_mode": "form_post", "scope": ["openid"], "dateAdded": "2020-07-01 20:32:54", "dateUpdated": "2020-07-06 16:31:21", "tokenvalid_uri": "https://graph.microsoft.com/v1.0/$metadata#users/$entity"}')
            mock_request.return_value = fake_response
            self.assertEqual(a.getEndpoints(), True)
            self.assertEqual(
                a.endpointData['clientId'], "4334a99c-cb4e-49c6-b5f5-afd9239372f5")

        self.assertEqual(a.setScope(["openid"]), True)

        with mock.patch.object(a.Session, 'post') as mock_request:
            fake_response = FakeResponse(200, '{"token_type": "Bearer", "expires_in": 3599, "ext_expires_in": 3599, "access_token": "eyJ0eXAiOiJKV1QiLCJub25jZSI6Imlob0Rrcnh4UVZLLUZTWmlYNm5KbW0tUGYxNjJyYnVySVZ5ekJVZGtCSnciLCJhbGciOiJSUzI1NiIsIng1dCI6Imh1Tjk1SXZQZmVocTM0R3pCRFoxR1hHaXJuTSIsImtpZCI6Imh1Tjk1SXZQZmVocTM0R3pCRFoxR1hHaXJuTSJ9.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC84ZjkxNThmMC1lMjI2LTRmYTMtYmE5MC1hOGY5Y2EzOGNmYmEvIiwiaWF0IjoxNTk0ODM0Mjg2LCJuYmYiOjE1OTQ4MzQyODYsImV4cCI6MTU5NDgzODE4NiwiYWlvIjoiRTJCZ1lGQXY3Tm5ycW5VdXhmNkNTNDFjMmZZWUFBPT0iLCJhcHBfZGlzcGxheW5hbWUiOiJoYXdrLXNvYXIgbm9kZXMiLCJhcHBpZCI6IjQzMzRhOTljLWNiNGUtNDljNi1iNWY1LWFmZDkyMzkzNzJmNSIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzhmOTE1OGYwLWUyMjYtNGZhMy1iYTkwLWE4ZjljYTM4Y2ZiYS8iLCJvaWQiOiIwYjg0ZTgzZS1mNzM2LTRjZTktYWRkMC1iZmE1YmJiZGI0ZjUiLCJzdWIiOiIwYjg0ZTgzZS1mNzM2LTRjZTktYWRkMC1iZmE1YmJiZGI0ZjUiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiTkEiLCJ0aWQiOiI4ZjkxNThmMC1lMjI2LTRmYTMtYmE5MC1hOGY5Y2EzOGNmYmEiLCJ1dGkiOiIxcGh0cFZCTzFrLURHN0N4OE9IeUFBIiwidmVyIjoiMS4wIiwieG1zX3RjZHQiOjEzMjUxNzMzODV9.EgbyOHaVfyVKgEgUfgKYNYdlHKbuV4BmABSmn0aLUrlGnjaKkuis07o-2IGO62VCwLkgnZzLup376sqz0PnGcrF2SfX0fqhV4QJ-EkQNjNf9uT5EVO8xEKD2tIy0I3Rkux8flhSwLDCW_jeW7F7deA7Vbm_n7QKj1X3A-tp3tn8uiS2mM-sPjzzOK4BNPo2Kyyw2qBiw6_UXbNVsynl7FLntginTSh1VjYJ58TnPaK0ERDMwdQvjivRddn1_N-z_Iq2rPLEvFYrbPvEOS1iQWXBVcrhJJg4TWJp24LD-Nxp5AEubbwntxSJP92kJVbg_yLagd4SdgwYI8BgU10jZEQ"}')
            mock_request.return_value = fake_response
            self.assertEqual(a.getToken(), True)

        self.assertNotEqual(a.tokenData, None)

        with mock.patch.object(a.Session, 'post') as mock_request:
            fake_response = FakeResponse(
                200, '{"status": true, "data": {"@class": "Nodes", "group": "96edb385-650a-46d3-ae19-cd9e369f5a4a", "id": "26ec338e-c99f-43ba-a8e4-5baf95e269b1", "hostname": "dev-02.dev.hawkdefense.com", "address": "127.0.0.1", "platform": "posix/Linux 3.10.0-327.18.2.hwk4.x86_64", "publicKey": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCbkp+VemSvS3kz4I4RRnem8YPgUDcsXftyvkm03xGDa4CvQOmfm2DOeksiUrzNuZl1910DRXSzCHe/vRh4v0NIEFsxH0cYeVaG/WVu34tustH+J75KWUD4BRwFTvL8HkdtnnV1OlJjJkJFcKaeB6zeQqrqe8w2nagjAWE4bao0Ewdmq9HYVjiEJ6LYsTgUWG0qT6c3uBgkK7qyK053u3qEop1rWuRbSN2jJONOBCk5VT7Ib/oyVYvtJzFqq5Ac91dfUPiDnZEWL7tKM8pbg259GTOWC005kLeKMawR+zzvqJijop8AwDBEIIjGbkOThS9VcEWzV494KoZ2HiI93q4J", "lastSeen": "2020-07-15 17:36:32", "tags": ["dc1"], "type": "cloud", "dateUpdated": "2020-07-15 15:13:56", "token": "jhia+RFzGjUfM6xlHl5F+4hR6D8hazc7n56XoRKErDVcjkKKx405cfQo0G8dENpxS/h5Gtih/ufnDZNbk5bchC/uKXRzg8j/+5Dl4ox5qnlkYPkd8/+Fv4c1nIGSfIULaJPq8O+2SzCCEAgnNTbIqPv81o9j6kJ2SV7KJLgN4inFyJqodn69wproOV2fy4MCb76NuyyjJeJrdMpPtvT0mNnvRAsNGJKaWLT7Cx/70TrG10VQEoJYlXZp7WGuC2idN/JSoB1dIIPgdt/vVSqTXmjA6bzU9838sm29xvomNUMM1SS9Gsbjr/G9z+3oQs7jOMeWSc5sMpX/iaShMWWYDw==", "approval": false, "@rid": "#133:0", "@version": 30}, "details": "node pending approval."}')
            mock_request.return_value = fake_response
            self.assertEqual(a.registerToken(), False)

        with mock.patch.object(a.Session, 'post') as mock_request:
            fake_response = FakeResponse(
                200, '{"status": true, "data": {"@class": "Nodes", "group": "96edb385-650a-46d3-ae19-cd9e369f5a4a", "id": "26ec338e-c99f-43ba-a8e4-5baf95e269b1", "hostname": "dev-02.dev.hawkdefense.com", "address": "127.0.0.1", "platform": "posix/Linux 3.10.0-327.18.2.hwk4.x86_64", "publicKey": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCbkp+VemSvS3kz4I4RRnem8YPgUDcsXftyvkm03xGDa4CvQOmfm2DOeksiUrzNuZl1910DRXSzCHe/vRh4v0NIEFsxH0cYeVaG/WVu34tustH+J75KWUD4BRwFTvL8HkdtnnV1OlJjJkJFcKaeB6zeQqrqe8w2nagjAWE4bao0Ewdmq9HYVjiEJ6LYsTgUWG0qT6c3uBgkK7qyK053u3qEop1rWuRbSN2jJONOBCk5VT7Ib/oyVYvtJzFqq5Ac91dfUPiDnZEWL7tKM8pbg259GTOWC005kLeKMawR+zzvqJijop8AwDBEIIjGbkOThS9VcEWzV494KoZ2HiI93q4J", "lastSeen": "2020-07-15 17:36:32", "tags": ["dc1"], "type": "cloud", "dateUpdated": "2020-07-15 15:13:56", "token": "jhia+RFzGjUfM6xlHl5F+4hR6D8hazc7n56XoRKErDVcjkKKx405cfQo0G8dENpxS/h5Gtih/ufnDZNbk5bchC/uKXRzg8j/+5Dl4ox5qnlkYPkd8/+Fv4c1nIGSfIULaJPq8O+2SzCCEAgnNTbIqPv81o9j6kJ2SV7KJLgN4inFyJqodn69wproOV2fy4MCb76NuyyjJeJrdMpPtvT0mNnvRAsNGJKaWLT7Cx/70TrG10VQEoJYlXZp7WGuC2idN/JSoB1dIIPgdt/vVSqTXmjA6bzU9838sm29xvomNUMM1SS9Gsbjr/G9z+3oQs7jOMeWSc5sMpX/iaShMWWYDw==", "approval": true, "@rid": "#133:0", "@version": 30}, "details": "node approved."}')
            mock_request.return_value = fake_response
            self.assertEqual(a.registerToken(), True)


if __name__ == '__main__':
    unittest.main()
