"""
Unit tests for soarAPI WebSocket reconnection, re-authentication, node profile
enrichment, and per-node channel subscription.

Regression coverage for the infinite reconnect storm bug:

    BEFORE FIX:
        WebSocketApp was built *once* before the reconnect loop, baking in the
        session cookie from the initial login().  When the server expired that
        session the reconnect loop kept calling run_forever() on the same stale
        WebSocketApp.  The server immediately rejected every new connection
        (expired cookie → HTTP 401/close), producing the observed rapid
        connect/subscribe/disconnect storm logged in production.

    AFTER FIX:
        _build_ws() calls self.login() before constructing each WebSocketApp,
        so every reconnect attempt carries a freshly authenticated session cookie.
"""
import json
import socket
import unittest
from unittest import mock

from hawkSoar.lib.soar import soarAPI


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _config():
    return {
        'server': ['https://localhost:8443'],
        'websocket_server': ['wss://localhost:8443'],
        'clientId': 'test-client',
        'clientSecret': 'test-secret',
        'insecure': True,
        'debug': False,
        'access_token': 'test-access',
        'secret_key': 'test-secret-key',
        'client_id_file': None,
        'private_key': None,
        'public_key': None,
    }


def _make_api():
    """Build a soarAPI with a fully mocked Authentication object."""
    with mock.patch('hawkSoar.lib.soar.Authentication') as MockAuth, \
         mock.patch('hawkSoar.lib.soar.Queue', side_effect=lambda: mock.MagicMock()):
        mock_auth = mock.MagicMock()
        mock_auth.Session = mock.MagicMock()
        mock_auth.Session.cookies.get_dict.return_value = {'session': 'cookie-0'}
        mock_auth.getParentGroup.return_value = 'test-group'
        MockAuth.return_value = mock_auth
        api = soarAPI(_config())
    return api, mock_auth


def _patched_login(api, mock_auth):
    """
    Replace api.login with a mock that bumps the cookie value on every call,
    simulating the server issuing a fresh session token each time.
    Returns the mock so call counts can be inspected.
    """
    call_count = [0]

    def _login():
        call_count[0] += 1
        mock_auth.Session.cookies.get_dict.return_value = {
            'session': 'cookie-%d' % call_count[0]
        }
        return True

    login_mock = mock.MagicMock(side_effect=_login)
    api.login = login_mock
    api.authObj = mock_auth
    return login_mock, call_count


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestSoarWebsocketReauth(unittest.TestCase):

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_login_called_before_initial_connect(self, _sleep):
        """login() is called exactly once before the first WebSocket connect."""
        api, mock_auth = _make_api()
        login_mock, call_count = _patched_login(api, mock_auth)

        def fake_run_forever(**kw):
            api.isRunning = False  # immediate disconnect

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp') as MockWS:
            ws = mock.MagicMock()
            ws.run_forever.side_effect = fake_run_forever
            MockWS.return_value = ws
            api.run_loop(lambda msg: None)

        self.assertEqual(call_count[0], 1,
            "login() must be called once before the first WebSocket connection")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_login_called_again_after_disconnect(self, _sleep):
        """
        REGRESSION: login() must be called again after every disconnect.

        Without re-auth the reconnect loop reuses the original WebSocketApp
        with its expired cookie.  The server rejects the connection immediately
        on every attempt, creating an infinite connect/disconnect storm.
        """
        api, mock_auth = _make_api()
        login_mock, call_count = _patched_login(api, mock_auth)

        disconnect_count = [0]

        def fake_run_forever(**kw):
            disconnect_count[0] += 1
            if disconnect_count[0] >= 2:
                api.isRunning = False  # stop after one reconnect

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp') as MockWS:
            ws = mock.MagicMock()
            ws.run_forever.side_effect = fake_run_forever
            MockWS.return_value = ws
            api.run_loop(lambda msg: None)

        self.assertEqual(call_count[0], 2,
            "login() must be called for the initial connect AND every reconnect; "
            "failing to re-auth caused the observed infinite reconnect storm")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_fresh_cookies_used_on_reconnect(self, _sleep):
        """
        REGRESSION: each WebSocketApp must be built with freshly authenticated
        cookies.

        The old code baked the original cookie into a single WebSocketApp
        instance that was reused forever.  The server would see the same expired
        cookie on every reconnect and close the socket immediately.
        """
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)

        cookies_at_construction = []
        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            cookies_at_construction.append(cookie)
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                if disconnect_count[0] >= 2:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(len(cookies_at_construction), 2,
            "WebSocketApp should be constructed twice: initial connect + one reconnect")

        self.assertNotEqual(
            cookies_at_construction[0],
            cookies_at_construction[1],
            "Reconnect must carry a new session cookie from a fresh login(); "
            "reusing the stale cookie is what caused the infinite reconnect storm"
        )
        self.assertIn('cookie-1', cookies_at_construction[0],
            "First connect should use the cookie from the first login()")
        self.assertIn('cookie-2', cookies_at_construction[1],
            "Reconnect should use the cookie from the second login(), not cookie-1")

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_reauth_failure_retries_and_uses_extended_sleep(self, mock_sleep):
        """
        If re-authentication throws after a disconnect the loop must log the
        error, sleep for the extended backoff period, and retry — not crash.
        """
        api, mock_auth = _make_api()
        login_count = [0]

        def fake_login():
            login_count[0] += 1
            if login_count[0] == 2:
                raise Exception("Auth server unreachable")
            # First login and third login succeed; third also ends the loop
            if login_count[0] >= 3:
                api.isRunning = False
            mock_auth.Session.cookies.get_dict.return_value = {
                'session': 'cookie-%d' % login_count[0]
            }
            return True

        api.login = mock.MagicMock(side_effect=fake_login)
        api.authObj = mock_auth

        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                # Safety cap: stop the loop if login() never drives termination
                # (e.g. when running against buggy code that never calls login).
                if disconnect_count[0] >= 10:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertGreaterEqual(login_count[0], 3,
            "After a failed re-auth the loop must retry login()")
        mock_sleep.assert_any_call(5)

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_no_reconnect_after_shutdown(self, _sleep):
        """Calling shutdown() (isRunning=False) must stop the reconnect loop."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)

        ws_build_count = [0]
        disconnect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws_build_count[0] += 1
            ws = mock.MagicMock()

            def fake_run(**kw):
                disconnect_count[0] += 1
                api.isRunning = False  # simulate shutdown on first disconnect

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(ws_build_count[0], 1,
            "After shutdown (isRunning=False) no second WebSocketApp should be built")


class TestNodeProfile(unittest.TestCase):

    def test_node_profile_includes_platform(self):
        """build_node_profile() must include a 'platform' key for octorepl scoring."""
        api, _ = _make_api()
        profile = api.build_node_profile()
        self.assertIn('platform', profile)
        self.assertIsInstance(profile['platform'], str)
        self.assertGreater(len(profile['platform']), 0)

    def test_node_profile_includes_type_from_config(self):
        api, _ = _make_api()
        api.config['node_type'] = 'domain_controller'
        profile = api.build_node_profile()
        self.assertEqual(profile['type'], 'domain_controller')

    def test_node_profile_type_defaults_to_endpoint(self):
        api, _ = _make_api()
        api.config.pop('node_type', None)
        profile = api.build_node_profile()
        self.assertEqual(profile['type'], 'endpoint')

    def test_node_profile_includes_tags_from_config(self):
        api, _ = _make_api()
        api.config['tags'] = ['prod', 'finance', 'dc1']
        profile = api.build_node_profile()
        for tag in ['prod', 'finance', 'dc1']:
            self.assertIn(tag, profile['tags'])
        self.assertIsInstance(profile['tags'], list)

    def test_node_profile_tags_empty_when_not_configured(self):
        api, _ = _make_api()
        api.config.pop('tags', None)
        profile = api.build_node_profile()
        self.assertIsInstance(profile['tags'], list)
        # Auto-tags may be present; only require the field exists as a list.

    def test_node_profile_hawk_engine_true_when_configured(self):
        api, _ = _make_api()
        api.config['hawk_engine'] = True
        profile = api.build_node_profile()
        self.assertIs(profile['hawk_engine'], True)

    def test_node_profile_hawk_engine_false_by_default(self):
        api, _ = _make_api()
        api.config.pop('hawk_engine', None)
        profile = api.build_node_profile()
        self.assertIs(profile['hawk_engine'], False)

    def test_auto_tags_includes_os_platform(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('linux', auto_tags)

    def test_auto_tags_multi_homed_when_multiple_interfaces(self):
        api, _ = _make_api()
        interfaces = [
            {'name': 'eth0', 'ip': '10.0.0.1', 'netmask': '255.255.255.0'},
            {'name': 'eth1', 'ip': '192.168.1.1', 'netmask': '255.255.255.0'},
        ]
        auto_tags = api._build_auto_tags(interfaces=interfaces)
        self.assertIn('multi-homed', auto_tags)

    def test_auto_tags_vpn_gateway_detected_by_interface_name(self):
        api, _ = _make_api()
        interfaces = [{'name': 'tun0', 'ip': '10.8.0.1', 'netmask': '255.255.255.0'}]
        auto_tags = api._build_auto_tags(interfaces=interfaces)
        self.assertIn('vpn-gateway', auto_tags)

    def test_auto_tags_nmap_detected_when_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda name: '/usr/bin/nmap' if name == 'nmap' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('nmap', auto_tags)

    def test_auto_tags_hawk_engine_tag_when_configured(self):
        api, _ = _make_api()
        api.config['hawk_engine'] = True
        auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('hawk-engine', auto_tags)

    def test_merged_tags_union_with_manual_tags(self):
        api, _ = _make_api()
        api.config['tags'] = ['prod']
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            profile = api.build_node_profile()
        self.assertIn('prod', profile['tags'])
        self.assertIn('linux', profile['tags'])

    def test_manual_tags_preserved_no_duplicate_when_auto_tag_same(self):
        api, _ = _make_api()
        api.config['tags'] = ['linux']
        with mock.patch('hawkSoar.lib.soar._platform.system', return_value='Linux'):
            profile = api.build_node_profile()
        self.assertIn('linux', profile['tags'])
        self.assertEqual(profile['tags'].count('linux'), 1)

    # --- Additional innovative auto-tag tests ---

    def test_auto_tags_container_when_dockerenv_present(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.os.path.exists',
                        side_effect=lambda p: p == '/.dockerenv'):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('container', auto_tags)

    def test_auto_tags_container_windows_sandbox_env_var(self):
        api, _ = _make_api()
        with mock.patch.dict('os.environ',
                             {'CONTAINER_SANDBOX_MOUNT_POINT': 'C:\\ContainerMappedDirectories'}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('container', auto_tags)

    def test_auto_tags_cloud_vm_aws_when_env_var_set(self):
        api, _ = _make_api()
        with mock.patch.dict('os.environ', {'AWS_EXECUTION_ENV': 'AWS_ECS_FARGATE'}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('cloud-vm', auto_tags)
        self.assertIn('aws', auto_tags)

    def test_auto_tags_high_cpu_when_8_or_more_cores(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.psutil.cpu_count', return_value=16):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('high-cpu', auto_tags)

    def test_auto_tags_low_memory_when_under_2gb(self):
        api, _ = _make_api()
        mem_mock = mock.MagicMock()
        mem_mock.total = 1 * 1024 ** 3  # 1 GB
        with mock.patch('hawkSoar.lib.soar.psutil.virtual_memory', return_value=mem_mock):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('low-memory', auto_tags)

    def test_auto_tags_storage_rich_when_over_100gb_free(self):
        api, _ = _make_api()
        disk_mock = mock.MagicMock()
        disk_mock.free = 200 * 1024 ** 3  # 200 GB
        with mock.patch('hawkSoar.lib.soar.psutil.disk_usage', return_value=disk_mock):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('storage-rich', auto_tags)

    def test_auto_tags_gpu_capable_when_nvidia_smi_present(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/nvidia-smi' if n == 'nvidia-smi' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('gpu-capable', auto_tags)

    def test_auto_tags_docker_when_docker_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/docker' if n == 'docker' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('docker', auto_tags)

    def test_auto_tags_python3_when_python3_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/python3' if n == 'python3' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('python3', auto_tags)

    def test_auto_tags_powershell_when_pwsh_in_path(self):
        api, _ = _make_api()
        with mock.patch('hawkSoar.lib.soar.shutil.which',
                        side_effect=lambda n: '/usr/bin/pwsh' if n == 'pwsh' else None):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('powershell', auto_tags)

    def test_auto_tags_ipv6_capable_when_global_ipv6_present(self):
        api, _ = _make_api()
        mock_addr = mock.MagicMock()
        mock_addr.family = socket.AF_INET6
        mock_addr.address = '2001:db8::1'
        with mock.patch('hawkSoar.lib.soar.psutil.net_if_addrs',
                        return_value={'eth0': [mock_addr]}):
            auto_tags = api._build_auto_tags(interfaces=[])
        self.assertIn('ipv6-capable', auto_tags)

    def test_subscribe_node_channel_sends_subscribeNode_message(self):
        """subscribe_node_channel() must send a subscribeNode message with node_id and group_id."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        mock_auth.getParentGroup.return_value = 'group-abc'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        api.send_response = lambda msg: sent.append(json.loads(msg) if isinstance(msg, str) else msg)
        api.subscribe_node_channel()
        self.assertEqual(len(sent), 1)
        msg = sent[0]
        self.assertEqual(msg['cmd'], 'hybrid_catalog')
        self.assertEqual(msg['route'], 'subscribeNode')
        self.assertEqual(msg['node_id'], 'node-uuid-123')
        self.assertEqual(msg['group_id'], 'group-abc')

    def test_runtime_registration_messages_include_node_id(self):
        """registerApps/registerProfile must carry explicit node_id for service-account sessions."""
        api, mock_auth = _make_api()
        mock_auth.getUUID.return_value = 'node-uuid-123'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        api.send_response = lambda msg: sent.append(json.loads(msg) if isinstance(msg, str) else msg)

        api.register_apps([{"id": "hybrid-task-api"}])
        api.register_profile({"hostname": "node-a"})

        self.assertEqual(2, len(sent))
        self.assertEqual('registerApps', sent[0]['route'])
        self.assertEqual('node-uuid-123', sent[0].get('node_id'))
        self.assertEqual('registerProfile', sent[1]['route'])
        self.assertEqual('node-uuid-123', sent[1].get('node_id'))

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_open_replays_registration_callbacks_after_subscriptions(self, _sleep):
        """WebSocket on_open must replay node registration after service/node subscriptions."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)
        mock_auth.getUUID.return_value = 'node-uuid-123'
        mock_auth.getParentGroup.return_value = 'group-abc'
        api.authObj = mock_auth
        api.uuid = 'node-uuid-123'
        sent = []
        callback_calls = []
        api.send_response = lambda msg: sent.append(json.loads(msg) if isinstance(msg, str) else msg)
        api.add_on_connect_callback(lambda: callback_calls.append('ran'))

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                ws.on_open(ws)
                api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(callback_calls, ['ran'])
        self.assertGreaterEqual(len(sent), 2)
        self.assertEqual(sent[0]['cmd'], 'hybrid_catalog')
        self.assertEqual(sent[0]['route'], 'subscribeServices')
        self.assertEqual(sent[1]['cmd'], 'hybrid_catalog')
        self.assertEqual(sent[1]['route'], 'subscribeNode')

    @mock.patch('hawkSoar.lib.soar.time.sleep')
    def test_on_open_replays_registration_callbacks_on_reconnect(self, _sleep):
        """Registration callbacks must replay on every reconnect, not just first connect."""
        api, mock_auth = _make_api()
        _patched_login(api, mock_auth)
        callback_calls = []
        api.add_on_connect_callback(lambda: callback_calls.append('ran'))

        connect_count = [0]

        def make_ws(url, on_message, on_error, on_close, cookie):
            ws = mock.MagicMock()

            def fake_run(**kw):
                connect_count[0] += 1
                ws.on_open(ws)
                if connect_count[0] >= 2:
                    api.isRunning = False

            ws.run_forever.side_effect = fake_run
            return ws

        with mock.patch('hawkSoar.lib.soar.websocket.WebSocketApp', side_effect=make_ws):
            api.run_loop(lambda msg: None)

        self.assertEqual(callback_calls, ['ran', 'ran'])


if __name__ == '__main__':
    unittest.main()
