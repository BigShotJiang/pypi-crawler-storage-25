# for connecting to local cache and for syncing with remote cache


# cotainment actions need to be saved in cache.


from common.database import soarDB


class soarCache(object):

    def __init__(self):
        self._creds = None
        pass

    def get_plugins(self):
        """Get active plugins."""
        pass

    @property
    def creds(self):
        return self._creds

    @creds.setter
    def creds(self, creds):
        self._creds = creds
