
import os
import shutil
import time
import random
import websocket
import ssl
import json
import threading
from multiprocessing import Queue
from uuid import uuid4
import socket
import psutil
import platform as _platform

from .auth import Authentication
from hawkSoar.common.logger import get_logger

# for connecting to soar API


class soarAPI(threading.Thread):
    """Communicating with the SOAR API. """
    config = {}
    authObj = None
    uuid = None
    isRunning = False
    ws = None
    incoming_queue = None
    outgoing_queue = None

    def __init__(self, config):
        threading.Thread.__init__(self)
        self.config = config
        self.logging = get_logger()
        self.incoming_queue = Queue()
        self.outgoing_queue = Queue()
        self._sender_thread = None
        self._on_connect_callbacks = []

        try:
            self.authObj = Authentication(random.choice(
                self.config['server']), self.config['clientId'], self.config['clientSecret'])
            if not self.config['insecure']:
                self.authObj.setVerify(True)
            else:
                self.authObj.setVerify(False)

        except Exception as e:
            self.logging.error(str(e))
            raise e

        try:
            if config['client_id_file']:
                self.authObj.setUUIDFile(config['client_id_file'])
        except Exception as e:
            self.logging.error(str(e))
            raise e

        try:
            if config['private_key']:
                self.authObj.setPrivateKey(config['private_key'])
        except Exception as e:
            self.logging.error(str(e))
            raise e

        try:
            if config['public_key']:
                self.authObj.setPublicKey(config['public_key'])
        except Exception as e:
            self.logging.error(str(e))
            raise e

    def get_task(self):
        try:
            return self.incoming_queue.get(False, 1)
        except:
            return None

    def set_task(self, task):
        return self.incoming_queue.put(task)

    def register_apps(self, appList):
        response = {
            "id": str(uuid4()),
            "cmd": "nodes",
            "route": "registerApps",
            "node_id": self.uuid or (self.authObj.getUUID() if self.authObj else None),
            "data": appList
        }
        self.send_response(json.dumps(response))

    def register_hybrid_tools(self, tool_catalog):
        response = {
            "id": str(uuid4()),
            "cmd": "nodes",
            "route": "registerHybridTools",
            "data": tool_catalog,
        }
        self.send_response(json.dumps(response))

    def register_profile(self, profile):
        response = {
            "id": str(uuid4()),
            "cmd": "nodes",
            "route": "registerProfile",
            "node_id": self.uuid or (self.authObj.getUUID() if self.authObj else None),
            "data": profile,
        }
        self.send_response(json.dumps(response))

    def add_on_connect_callback(self, callback):
        if callable(callback):
            self._on_connect_callbacks.append(callback)

    def _run_on_connect_callbacks(self):
        for callback in list(self._on_connect_callbacks):
            try:
                callback()
            except Exception as e:
                self.logging.warning("[nodes] on-connect registration callback failed: %s", e)

    def subscribe_services(self, group_id=None):
        """Subscribe to service-only channel for hybrid_catalog messages.

        This must be called after WebSocket connection to receive hybrid_catalog
        result/submit messages on the {group}-services Redis channel, which is
        only subscribed to by service sessions (not human SOC users).

        The server will subscribe this session to all groups in the authenticated
        session; group_id parameter is optional for logging purposes.
        """
        if not group_id:
            group_id = self.authObj.getParentGroup() if self.authObj else None
        response = {
            "id": str(uuid4()),
            "cmd": "hybrid_catalog",
            "route": "subscribeServices",
            "group_id": group_id,
            "data": {},
        }
        self.logging.info("[hybrid] Subscribing to service channels for group: %s", group_id)
        self.send_response(json.dumps(response))

    def subscribe_node_channel(self, node_id=None, group_id=None):
        """Subscribe to per-node targeted dispatch channel.

        Must be called after WebSocket connection to receive hybrid tasks that
        were dispatched specifically to this node (target_node_id matching our UUID).
        The server will publish to {group_id}-node-{node_id} for targeted tasks.
        """
        nid = node_id or self.uuid or (self.authObj.getUUID() if self.authObj else None)
        gid = group_id or (self.authObj.getParentGroup() if self.authObj else None)
        if not nid or not gid:
            self.logging.warning("[hybrid] Cannot subscribe to node channel: missing node_id or group_id")
            return
        response = {
            "id": str(uuid4()),
            "cmd": "hybrid_catalog",
            "route": "subscribeNode",
            "node_id": nid,
            "group_id": gid,
            "data": {},
        }
        self.logging.info("[hybrid] Subscribing to per-node channel: node=%s group=%s", nid, gid)
        self.send_response(json.dumps(response))

    def _build_auto_tags(self, interfaces=None):
        """Introspect the local environment and return auto-detected capability/topology tags."""
        tags = []
        if interfaces is None:
            interfaces = []

        # OS platform
        try:
            system = _platform.system().lower()
            if system == "darwin":
                system = "macos"
            if system in ("linux", "windows", "macos"):
                tags.append(system)
        except Exception:
            pass

        # CPU architecture
        try:
            machine = _platform.machine().lower()
            if machine in ("amd64",):
                machine = "x86_64"
            elif machine in ("aarch64",):
                machine = "arm64"
            if machine in ("x86_64", "arm64", "i386"):
                tags.append(machine)
        except Exception:
            pass

        # Network topology: multi-homed
        try:
            if len(interfaces) > 1:
                tags.append("multi-homed")
        except Exception:
            pass

        # Network topology: VPN / tunnel gateway
        try:
            vpn_prefixes = ("tun", "tap", "wg", "vpn")
            for iface in interfaces:
                name = (iface.get("name") or "").lower()
                if any(name.startswith(prefix) for prefix in vpn_prefixes):
                    tags.append("vpn-gateway")
                    break
        except Exception:
            pass

        # Privilege level
        try:
            if _platform.system().lower() == "windows":
                import ctypes
                if ctypes.windll.shell32.IsUserAnAdmin():
                    tags.append("privileged")
            else:
                if os.geteuid() == 0:
                    tags.append("privileged")
        except Exception:
            pass

        # Tool: nmap
        try:
            if shutil.which("nmap") is not None:
                tags.append("nmap")
        except Exception:
            pass

        # Tool: packet capture
        try:
            if shutil.which("tcpdump") is not None or shutil.which("tshark") is not None:
                tags.append("packet-capture")
        except Exception:
            pass

        # Tool: SSH client
        try:
            if shutil.which("ssh") is not None:
                tags.append("ssh-capable")
        except Exception:
            pass

        # Domain-joined (FQDN differs from bare hostname)
        try:
            fqdn = socket.getfqdn().lower()
            hostname = socket.gethostname().lower()
            if fqdn != hostname:
                tags.append("domain-joined")
        except Exception:
            pass

        # Hawk engine — reinforce the config flag as a searchable tag
        try:
            if bool(self.config.get("hawk_engine", False)):
                tags.append("hawk-engine")
        except Exception:
            pass

        # Environment: container (Docker / Kubernetes / Windows Server Containers)
        try:
            _container = (
                os.path.exists("/.dockerenv")           # Linux Docker
                or bool(os.environ.get("KUBERNETES_SERVICE_HOST"))   # K8s (any OS)
                or bool(os.environ.get("CONTAINER_SANDBOX_MOUNT_POINT"))  # Windows Server Containers
            )
            if not _container and os.path.exists("/proc/1/cgroup"):
                with open("/proc/1/cgroup") as _f:
                    _cgroup = _f.read()
                if "docker" in _cgroup or "kubepods" in _cgroup:
                    _container = True
            if _container:
                tags.append("container")
        except Exception:
            pass

        # Environment: virtual machine (VMware / Hyper-V / KVM / QEMU / Xen)
        try:
            _vm = False
            # Linux: hypervisor CPUID flag in /proc/cpuinfo
            if os.path.exists("/proc/cpuinfo"):
                with open("/proc/cpuinfo") as _f:
                    if "hypervisor" in _f.read():
                        _vm = True
            if not _vm:
                # Cross-platform: OS version/processor strings (works for some hypervisors)
                _ver = _platform.uname().version.lower()
                _proc = _platform.uname().processor.lower()
                for _indicator in ("hyperv", "vmware", "virtualbox", "kvm", "xen", "qemu", "hyper-v"):
                    if _indicator in _ver or _indicator in _proc:
                        _vm = True
                        break
            if not _vm and _platform.system().lower() == "windows":
                # Windows: PROCESSOR_IDENTIFIER env var may include "Virtual" on QEMU/Hyper-V
                _proc_id = os.environ.get("PROCESSOR_IDENTIFIER", "").lower()
                if "virtual" in _proc_id:
                    _vm = True
            if _vm:
                tags.append("vm")
        except Exception:
            pass

        # Environment: cloud provider (AWS / GCP / Azure)
        try:
            _cloud = None
            if os.environ.get("AWS_EXECUTION_ENV") or os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):
                _cloud = "aws"
            elif os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("GCLOUD_PROJECT"):
                _cloud = "gcp"
            elif os.environ.get("WEBSITE_SITE_NAME") or os.environ.get("AZURE_CLIENT_ID"):
                _cloud = "azure"
            elif os.path.exists("/sys/class/dmi/id/product_name"):
                with open("/sys/class/dmi/id/product_name") as _f:
                    _product = _f.read().strip().lower()
                if "amazon" in _product or "ec2" in _product:
                    _cloud = "aws"
                elif "google" in _product:
                    _cloud = "gcp"
                elif "microsoft" in _product or "azure" in _product:
                    _cloud = "azure"
            if _cloud:
                tags.append("cloud-vm")
                tags.append(_cloud)
        except Exception:
            pass

        # Hardware: high CPU core count (>=8 logical cores)
        try:
            _cpus = psutil.cpu_count(logical=True)
            if _cpus and _cpus >= 8:
                tags.append("high-cpu")
        except Exception:
            pass

        # Hardware: memory-constrained node (<2 GB RAM)
        try:
            if psutil.virtual_memory().total < 2 * 1024 ** 3:
                tags.append("low-memory")
        except Exception:
            pass

        # Hardware: storage-rich node (>100 GB free on root/system volume)
        try:
            _disk_root = "/" if _platform.system().lower() != "windows" else os.path.abspath(os.sep)
            if psutil.disk_usage(_disk_root).free > 100 * 1024 ** 3:
                tags.append("storage-rich")
        except Exception:
            pass

        # Tool: GPU (NVIDIA or AMD ROCm)
        try:
            if shutil.which("nvidia-smi") is not None or shutil.which("rocm-smi") is not None:
                tags.append("gpu-capable")
        except Exception:
            pass

        # Tool: Docker engine
        try:
            if shutil.which("docker") is not None:
                tags.append("docker")
        except Exception:
            pass

        # Tool: Python 3 interpreter
        try:
            if shutil.which("python3") is not None or shutil.which("python") is not None:
                tags.append("python3")
        except Exception:
            pass

        # Tool: PowerShell (cross-platform pwsh or Windows powershell)
        try:
            if shutil.which("pwsh") is not None or shutil.which("powershell") is not None:
                tags.append("powershell")
        except Exception:
            pass

        # Network: routable IPv6 address present
        try:
            for _if_name, _addrs in psutil.net_if_addrs().items():
                for _addr in _addrs:
                    if getattr(_addr, "family", None) != socket.AF_INET6:
                        continue
                    _a = _addr.address.lower()
                    # Skip loopback (::1) and link-local (fe80::)
                    if _a.startswith("::1") or _a.startswith("fe80"):
                        continue
                    tags.append("ipv6-capable")
                    raise StopIteration
        except StopIteration:
            pass
        except Exception:
            pass

        return tags

    def build_node_profile(self, available_tasks=None):
        available_tasks = available_tasks or []
        hostname = socket.gethostname()
        interfaces = []
        primary_ip = None
        primary_netmask = None

        try:
            for if_name, addrs in psutil.net_if_addrs().items():
                for addr in addrs:
                    if getattr(addr, "family", None) != socket.AF_INET:
                        continue
                    if addr.address.startswith("127."):
                        continue
                    entry = {
                        "name": if_name,
                        "ip": addr.address,
                        "netmask": addr.netmask,
                    }
                    interfaces.append(entry)
                    if primary_ip is None:
                        primary_ip = addr.address
                        primary_netmask = addr.netmask
        except Exception:
            pass

        # Merge operator-configured tags with auto-detected capability/topology tags.
        manual_tags = list(self.config.get("tags") or [])
        auto_tags = self._build_auto_tags(interfaces=interfaces)
        merged_tags = sorted(set(manual_tags) | set(auto_tags))

        return {
            "profile_id": self.uuid or str(uuid4()),
            "hostname": hostname,
            "ip": primary_ip,
            "netmask": primary_netmask,
            "interfaces": interfaces,
            "available_tasks": available_tasks,
            # Needed by octorepl node-scoring algorithm
            "platform": _platform.system() + " " + _platform.release(),
            "type": self.config.get("node_type", "endpoint"),
            "tags": merged_tags,
            "hawk_engine": bool(self.config.get("hawk_engine", False)),
        }

    def get_playbooks(self):

        url = random.choice(
            self.config['server']) + "/api/playbook/" + self.authObj.getParentGroup()
        try:
            response = self.authObj.Session.get(
                url, verify=self.authObj.verify)
        except Exception as e:
            self.logging.error("Failed fetching playbooks at url: %s" % url)
            self.logging.exception(e)
            raise e

        if response.status_code != 200:
            raise Exception("Status response not valid (%d): %s" %
                            (response.status_code, response.content))

        return response.json()

    def login(self):

        try:
            access_token = self.config.get('access_token') or self.config.get('access_key')
            secret_key = self.config.get('secret_key') or self.config.get('secret')

            if not access_token or not secret_key:
                raise Exception(
                    "Service-account authentication requires access_token and secret_key in config.")

            self.authObj.loginApiUser(
                access_token,
                secret_key,
            )
            self.logging.info(
                "Authenticated using service-account token pair; websocket session established.")

            self.uuid = self.authObj.getUUID()

            return True

        except Exception as e:
            self.logging.error(str(e))
            raise e

    def run(self, **args):
        self.run_loop(self.set_task)

    def run_loop(self, callback):
        # websocket
        if not self.authObj.Session:
            raise Exception("No valid authenticated session found, unable to continue.")

        self.isRunning = True

        def on_message(ws, message):
            try:
                data = json.loads(message)
            except Exception as e:
                print("Failed to parse json: %s" % message)
                return

            callback(data)

        def on_error(ws, error):
            self.logging.error("Websocket error detected: %s" % str(error))

        def on_close(ws, close_status_code=None, close_msg=None):
            self.logging.error("Websocket has closed. status=%s msg=%s" %
                               (close_status_code, close_msg))

        def on_open(ws):
            self.logging.info("WebSocket connected")
            # Subscribe to service-only channel for hybrid_catalog messages
            # This must be called after WebSocket connection to receive hybrid results
            try:
                self.subscribe_services()
            except Exception as e:
                self.logging.warning("[hybrid] Service channel subscription on connect failed: %s" % e)
            # Subscribe to per-node targeted dispatch channel
            try:
                self.subscribe_node_channel()
            except Exception as e:
                self.logging.warning("[hybrid] Per-node channel subscription failed: %s" % e)
            self._run_on_connect_callbacks()

            def run(*args):
                while self.isRunning:
                    # send any messages in our queue
                    try:
                        msg = self.outgoing_queue.get(False, 1)
                    except:
                        continue

                    if not msg:
                        continue

                    if type(msg) != str:
                        self.send_response(json.dumps(msg))
                    else:
                        self.send_response(msg)

                if ws:
                    try:
                        ws.close()
                    except Exception:
                        pass
                self.logging.info(
                    "Websocket communication thread terminating.")
            if self._sender_thread and self._sender_thread.is_alive():
                return
            self._sender_thread = threading.Thread(
                target=run,
                name="soarapi-ws-sender",
                daemon=True,
            )
            self._sender_thread.start()

        if self.config['debug']:
            websocket.enableTrace(True)
        ws_targets = self.config.get('websocket_server') or self.config['server']
        ws_target = random.choice(ws_targets).strip()
        if ws_target.endswith("/"):
            ws_target = ws_target[:-1]

        if ws_target.startswith("ws://") or ws_target.startswith("wss://"):
            connStr = ws_target if ws_target.endswith("/websocket") else ("%s/websocket" % ws_target)
        else:
            connStr = ws_target if ws_target.endswith("/websocket") else ("%s/websocket" % ws_target)
            if connStr.startswith("https://"):
                connStr = "wss://" + connStr[len("https://"):]
            elif connStr.startswith("http://"):
                connStr = "ws://" + connStr[len("http://"):]
        def _build_ws():
            """Re-authenticate and build a fresh WebSocketApp with current cookies."""
            try:
                self.login()
            except Exception as e:
                self.logging.error("Re-authentication failed before WebSocket connect: %s" % e)
                raise

            cookies = self.authObj.Session.cookies.get_dict()
            cookies_str = ""
            for k in cookies:
                cookies_str += "%s=%s; " % (k, cookies[k])
            self.logging.debug("Websocket connection string: %s (%s)" %
                               (connStr, cookies_str))

            websocket.enableTrace(False)
            ws_app = websocket.WebSocketApp(connStr,
                                             on_message=on_message,
                                             on_error=on_error,
                                             on_close=on_close,
                                             cookie=cookies_str)
            ws_app.on_open = on_open
            return ws_app

        self.ws = _build_ws()

        while self.isRunning:  # enables reconnects
            try:
                if self.config['insecure']:
                    self.ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
                else:
                    self.ws.run_forever()
            except Exception as e:
                self.logging.error(
                    'soarAPI: websocket error occurred, reconnecting: %s' % e)

            if not self.isRunning:
                break

            self.logging.info("WebSocket disconnected, re-authenticating before reconnect...")
            time.sleep(1)
            try:
                self.ws = _build_ws()
            except Exception as e:
                self.logging.error("Failed to re-authenticate for reconnect, retrying in 5s: %s" % e)
                time.sleep(5)

    def send_response(self, response):
        if self.ws:
            while self.isRunning:
                try:
                    if type(response) == str:
                        self.ws.send(response)
                    else:
                        if not 'id' in response:
                            response['id'] = str(uuid4())
                        self.ws.send(json.dumps(response))
                    # Log successful send for hybrid_task results (diagnostic)
                    if isinstance(response, dict) and response.get('cmd') == 'hybrid_task' and response.get('route') == 'result':
                        self.logging.info(
                            "[hybrid-result-sent] id=%s action=%s status=%s",
                            response.get('id'),
                            (response.get('data') or {}).get('action', 'unknown'),
                            (response.get('data') or {}).get('status', 'unknown')
                        )
                    break
                except Exception as e:
                    self.logging.warning("[hybrid-result-send-error] Exception during send: %s", e)
                    time.sleep(1)
        else:
            self.outgoing_queue.put(response)
        return True

    def set_pause(self):
        """Tells SOAR API that we are at capacity"""

        # not implement nice to have
        pass

    def set_resume(self):
        """Tells SOAR API that we can accept work again"""

        # not implement nice to have
        pass

    def close(self):
        self.authObj.finish()

    def shutdown(self):
        print("soar API shutdown...")
        self.isRunning = False
        if self.ws:
            self.ws.close()
        if self._sender_thread and self._sender_thread.is_alive():
            self._sender_thread.join(timeout=5)
