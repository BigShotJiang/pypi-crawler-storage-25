import traceback
import os
from multiprocessing import Queue, Value
from queue import Empty
from concurrent.futures import ThreadPoolExecutor


from hawkSoar.common.plugin import import_plugins
from hawkSoar.common.logger import get_logger
from hawkSoar.common.process import ExceptionSafeProcess, check_worker_exceptions

from hawkSoar.objects.workflow import InvestigateObject
from hawkSoar.schedulers.scheduler import Scheduler


class MatchScheduler(Scheduler):
    """ This Scheduler processes request for Ingest objects. """
    config = None
    db_interface = None

    def __init__(self, config, db_interface=None):
        self.config = config
        self.db_interface = db_interface
        super(MatchScheduler, self).__init__(
            'match', config, db_interface)

    def load_plugins(self):
        source = import_plugins(
            'hawkSoar.plugins.match', 'marketplace/match')

        try:
            os.mkdir(self.config['plugin_data_path'] + "/match")
        except:
            pass

        for plugin_name in source.list_plugins():
            try:
                plugin = source.load_plugin(plugin_name)
                pluginObj = plugin.MatchPlugin(self, config=self.config)
            except Exception as e:
                self.logger.warn(
                    "Failed to load match plugin %s, ignoring: %s %s" % (plugin_name, e, traceback.format_exc()))

            try:
                os.mkdir(self.config['plugin_data_path'] +
                         "/match/" + pluginObj.ID)
            except FileExistsError as e:
                pass
            except Exception as e:
                self.logger.exception(
                    "Failed to create data directory, plugin %s, ignoring: %s %s" % (plugin_name, e, traceback.format_exc()))

    def start(self):
        # start internal thread
        pass

    def get_scheduled_workload(self):
        return {}

    def check_exceptions(self):
        for _, plugin in self.get_plugins().items():
            if plugin.check_exceptions():
                return True
        return check_worker_exceptions([self.schedule_process, self.result_collector_process], 'Scheduler')
