import traceback
from multiprocessing import Queue, Value
from queue import Empty
from concurrent.futures import ThreadPoolExecutor
import os

from hawkSoar.common.plugin import import_plugins
from hawkSoar.common.logger import get_logger

from hawkSoar.common.process import ExceptionSafeProcess, check_worker_exceptions

from hawkSoar.objects.workflow import InvestigateObject
from hawkSoar.schedulers.scheduler import Scheduler


class IngestScheduler(Scheduler):
    """ This Scheduler processes request for Ingest objects. """

    def __init__(self, config, db_interface=None):
        self.config = config
        self.db_interface = db_interface
        self.schedule_process = None
        super(IngestScheduler, self).__init__('ingest', config, db_interface)
        self.logger.debug(" In ingest __init__(); Parent PID: %s, My Pid: %s" % (
            os.getppid(), os.getpid()))

    def load_plugins(self):
        source = import_plugins(
            'hawkSoar.plugins.ingest', 'marketplace/ingest')

        try:
            os.mkdir(self.config['plugin_data_path'] + "/ingest")
        except:
            pass

        for plugin_name in source.list_plugins():
            try:
                plugin = source.load_plugin(plugin_name)
                pluginObj = plugin.IngestPlugin(self, config=self.config)
            except Exception as e:
                self.logger.warn(
                    "Failed to load ingestion plugin %s, ignoring: %s %s" % (plugin_name, e, traceback.format_exc()))

            try:
                os.mkdir(self.config['plugin_data_path'] +
                         "/ingest/" + pluginObj.ID)
            except FileExistsError as e:
                pass
            except Exception as e:
                self.logger.exception(
                    "Failed to create data directory, plugin %s, ignoring: %s %s" % (plugin_name, e, traceback.format_exc()))

    def get_scheduled_workload(self):
        return {}

    def check_exceptions(self):
        for _, plugin in self.get_plugins().items():
            if plugin.check_exceptions():
                return True
        return check_worker_exceptions([self.schedule_process, self.result_collector_process], 'Scheduler')


if __name__ == '__main__':
    pass
