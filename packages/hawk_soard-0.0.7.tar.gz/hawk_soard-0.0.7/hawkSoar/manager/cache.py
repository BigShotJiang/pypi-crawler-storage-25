"""Cache manager — local SQLite-backed key/value cache with TTL.

cacheManager  — get/set/delete individual cache entries.
syncCache     — background thread that expires stale entries and optionally
                syncs the local cache with the remote HAWK server.
"""

import json
import logging
import threading
import time

from sqlalchemy import (
    Column, Float, Integer, MetaData, String, Table, Text, create_engine,
    text,
)
from sqlalchemy.exc import SQLAlchemyError

from hawkSoar.common.logger import get_logger

logger = get_logger("manager.cache")

_DEFAULT_TTL = 300        # seconds
_DEFAULT_DB  = "hawk_cache.db"


def _engine_for_config(config):
    db_type = (config.get("db_type") or "sqlite").lower()
    if db_type == "sqlite":
        db_file = config.get("db_name") or _DEFAULT_DB
        return create_engine("sqlite:///%s" % db_file, connect_args={"check_same_thread": False})
    if db_type == "mysql":
        return create_engine(
            "mysql://{user}:{password}@{host}/{db}".format(
                user=config["username"],
                password=config["password"],
                host=config["host"],
                db=config["db_name"],
            )
        )
    raise ValueError("Unsupported db_type: %s" % db_type)


class cacheManager(object):
    """Get and set entries in the local cache table.

    Args:
        config (dict): Manager config dict.  Recognised keys:
            ``db_type``   – ``"sqlite"`` (default) or ``"mysql"``
            ``db_name``   – SQLite file path or MySQL database name
            ``username``  – MySQL username
            ``password``  – MySQL password
            ``host``      – MySQL host
            ``default_ttl`` – Default TTL in seconds (default 300)
    """

    def __init__(self, config=None):
        self.config = config or {}
        self._engine = _engine_for_config(self.config)
        self._default_ttl = int(self.config.get("default_ttl", _DEFAULT_TTL))
        self._table = self._ensure_table()

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set(self, key, value, ttl=None):
        """Store *value* under *key*.

        Args:
            key   (str): Cache key.
            value (any): JSON-serialisable value.
            ttl   (int): Time-to-live in seconds.  Uses ``default_ttl`` if omitted.
        """
        if ttl is None:
            ttl = self._default_ttl
        expires_at = time.time() + ttl
        serialised = json.dumps(value)

        with self._engine.connect() as conn:
            try:
                # upsert: delete then insert (portable across SQLite and MySQL)
                conn.execute(self._table.delete().where(self._table.c.key == key))
                conn.execute(self._table.insert().values(
                    key=key,
                    value=serialised,
                    expires_at=expires_at,
                ))
                conn.commit()
            except SQLAlchemyError as e:
                logger.error("cache set failed for key=%s: %s", key, e)

    # ------------------------------------------------------------------
    # Getters
    # ------------------------------------------------------------------

    def get(self, key, default=None):
        """Retrieve the value for *key*, or *default* if missing / expired.

        Args:
            key     (str): Cache key.
            default (any): Value returned on cache miss.

        Returns:
            The cached value, or *default*.
        """
        with self._engine.connect() as conn:
            try:
                row = conn.execute(
                    self._table.select().where(self._table.c.key == key)
                ).fetchone()
            except SQLAlchemyError as e:
                logger.error("cache get failed for key=%s: %s", key, e)
                return default

        if row is None:
            return default
        if row.expires_at < time.time():
            self.delete(key)
            return default
        try:
            return json.loads(row.value)
        except (ValueError, TypeError):
            return row.value

    def get_all(self):
        """Return all non-expired cache entries as a ``{key: value}`` dict."""
        now = time.time()
        with self._engine.connect() as conn:
            try:
                rows = conn.execute(
                    self._table.select().where(self._table.c.expires_at > now)
                ).fetchall()
            except SQLAlchemyError as e:
                logger.error("cache get_all failed: %s", e)
                return {}
        result = {}
        for row in rows:
            try:
                result[row.key] = json.loads(row.value)
            except (ValueError, TypeError):
                result[row.key] = row.value
        return result

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def delete(self, key):
        """Remove a single cache entry."""
        with self._engine.connect() as conn:
            try:
                conn.execute(self._table.delete().where(self._table.c.key == key))
                conn.commit()
            except SQLAlchemyError as e:
                logger.error("cache delete failed for key=%s: %s", key, e)

    def flush(self):
        """Remove all cache entries."""
        with self._engine.connect() as conn:
            try:
                conn.execute(self._table.delete())
                conn.commit()
            except SQLAlchemyError as e:
                logger.error("cache flush failed: %s", e)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_table(self):
        meta = MetaData()
        table = Table(
            "hawk_cache", meta,
            Column("key",        String(512), primary_key=True),
            Column("value",      Text,        nullable=False),
            Column("expires_at", Float,       nullable=False),
        )
        meta.create_all(self._engine)
        return table

    def cleanup_expired(self):
        """Delete all entries whose TTL has passed."""
        with self._engine.connect() as conn:
            try:
                conn.execute(
                    self._table.delete().where(self._table.c.expires_at < time.time())
                )
                conn.commit()
            except SQLAlchemyError as e:
                logger.error("cache cleanup_expired failed: %s", e)


class syncCache(threading.Thread):
    """Background thread that keeps the local cache clean and optionally
    syncs containment / active-task state with the remote HAWK server.

    Args:
        cache_manager (cacheManager): The local cache to maintain.
        soar_api      (soarAPI | None): If provided, remote sync is performed.
        interval      (int): Seconds between maintenance cycles (default 60).
    """

    def __init__(self, cache_manager, soar_api=None, interval=60):
        super().__init__(name="syncCache", daemon=True)
        self._cache = cache_manager
        self._soar_api = soar_api
        self._interval = interval
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Public control
    # ------------------------------------------------------------------

    def stop(self):
        """Signal the sync thread to stop after the current sleep."""
        self._stop_event.set()

    def connect(self):
        """Verify connectivity to the remote server (no-op if no soar_api)."""
        if self._soar_api is None:
            return True
        try:
            return self._soar_api.isRunning
        except Exception as e:
            logger.warning("syncCache.connect: remote check failed: %s", e)
            return False

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self):
        logger.info("syncCache started (interval=%ds)", self._interval)
        while not self._stop_event.is_set():
            try:
                self.cleanup_cache()
                self.sync()
            except Exception as e:
                logger.error("syncCache cycle error: %s", e)
            self._stop_event.wait(self._interval)
        logger.info("syncCache stopped")

    def sync(self):
        """Push local pending items to the remote server and pull updates.

        Only runs if a ``soar_api`` was provided at construction time.
        """
        if self._soar_api is None:
            return

        try:
            pending = {
                k: v for k, v in self._cache.get_all().items()
                if k.startswith("pending:")
            }
            for key, payload in pending.items():
                try:
                    self._soar_api.outgoing_queue.put_nowait(payload)
                    self._cache.delete(key)
                    logger.debug("syncCache: flushed %s to remote", key)
                except Exception as e:
                    logger.warning("syncCache: failed to flush %s: %s", key, e)
        except Exception as e:
            logger.error("syncCache.sync error: %s", e)

    def cleanup_cache(self):
        """Remove expired entries from the local cache."""
        try:
            self._cache.cleanup_expired()
            logger.debug("syncCache: expired entries cleaned")
        except Exception as e:
            logger.error("syncCache.cleanup_cache error: %s", e)
