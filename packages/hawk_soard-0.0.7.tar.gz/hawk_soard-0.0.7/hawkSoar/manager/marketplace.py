# marketplace manager code.

# Check to see if this local inistance needs to install new plugin from marketplace.

from lib.marketplace import marketplaceAPI as mpAPI


class marketplaceManager(object):

    def __init__(self):
        pass

    def _get_new_plugins(self):
        return mpAPI.get_new_plugins()

    def install_plugin(self, plugin):
        """ Downloads plugin, then installs the plugin."""
        # download plugin mpAPI.download_plugin(uuid=plugin.uuid)

        # register plugin self.notify_plugin_manager(plugin)

        # if success return True, else return False
        pass

    def notify_plugin_manager(self):
        """ Notify plugin manager of new plugin. """

        # Notify plugin manager
        pass

    def run(self):

        while self.init:
            # check if new plugins are ready to be installed
            new_plugins = self._get_new_plugins()
            if new_plugins:
                for plugin in new_plugins:
                    self.install_plugin(plugin)
