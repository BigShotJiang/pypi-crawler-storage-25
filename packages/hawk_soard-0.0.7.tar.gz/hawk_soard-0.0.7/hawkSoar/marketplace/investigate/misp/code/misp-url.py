

import os
import sys
import json
import requests
import time
from urllib.parse import urlparse

import xml
import radix
import csv
import zipfile
import pickle

import shutil

from hawkSoar.common.logger import get_logger
from hawkSoar.common.process import ExceptionSafeProcess
from hawkSoar.plugins.base import BasePlugin
from hawkSoar.lib.query_parser import QueryInterpreter


from pymisp import PyMISP


class InvestigatePlugin(BasePlugin):

    ID = 'misp-url'
    NAME = 'MISP URL'
    DESCRIPTION = "The MISP threat sharing platform is a free and open source software helping information sharing of threat intelligence including cyber security indicators.\n A threat intelligence platform for gathering, sharing, storing and correlating Indicators of Compromise of targeted attacks, threat intelligence, financial fraud information, vulnerability information or even counter-terrorism information."
    TYPE = 'investigate'
    DEPENDENCIES = ['PyMISP']
    VERSION = '0.0.1'
    MODULE = "playbook.investigate.URLReputation"
    ENABLED = True
    Exceptions = []
    playbookCache = {}
    activeRequests = []
    activeURL = {}

    def __init__(self, plugin_administrator, config=None):
        super().__init__(plugin_administrator, config=config, plugin_path=__file__)
        self.config = config
        self.logger = get_logger()
        self.playbookCache = {}

    def process_task(self, task):
        self.logger.debug("MISP URL TASK RECEIVED: %s" % task['cmd'])
        self.logger.debug(json.dumps(task))
        if task['cmd'] == 'addPlaybookStep':
            self._add_playbook_step(task['data'])
            # start up new worker when new task arrives.

            if not task['data']['id'] in self.playbookCache:
                self.playbookCache[task['data']['id']] = {}

            self.logger.debug("MATCH NEW STEP TASK")
            playbookId = task['data']['id']
            stepId = task['data']['step']['id']
            self.logger.debug(task['data']['step'])
            self.playbookCache[playbookId][stepId] = {
                'config':  task['data']['config'],
                'step':  task['data']['step']
            }
            stepId = task['data']['step']

            step = self.playbookCache[playbookId][stepId]

            # print(self.get_step_by_id(task['data']['playbookId'], task['data']['step']))

            task['data']['data']['artifacts'].append(
                {"plugin_id": self.ID, "name": "version", "module": self.MODULE, "type": "app.version",  "value": self.VERSION})

            result = None

            stepObj = self.get_step_by_id(
                task['data']['playbookId'], task['data']['step'])

            task['data']['data']['return_value'] = True

            task['route'] = 'publish'

            task['data']['step'] = step['step']['next']

            #self.logger.debug("OUTGOING ENRICHMENT TASK")
            # self.logger.debug(json.dumps(task))

            self.outgoing_queue.put(task)

    def add_exception(self, msg):
        self.Exceptions.append(msg)

    def check_exceptions(self):
        # if exceptiosn found, then log out
        return self.Exceptions

    def shutdown(self):
        # stop all on-going workers here
        self.logger.debug('MISP-URL plugin is now shutting down.')
        # super().shutdown()

        self.logger.debug('MISP-URL shutdown complete.')
