# Hawk Hybrid Task Integration (Cloud + OctoRepl + SOARD)

This project now supports a guarded `hybrid_task` execution path for secure on-prem investigations.
It also supports a `hybrid_catalog` capability advertisement path for trigger-driven orchestration.

## Inbound Message Envelope

Use websocket messages in this format:

```json
{
  "id": "uuid",
  "cmd": "hybrid_task",
  "route": "execute",
  "signature": "hex_signature",
  "data": {
    "task_id": "uuid",
    "group_id": "uuid",
    "case_id": "uuid",
    "category": "AD | ENDPOINT | NETWORK | CONTAINMENT",
    "action": "string",
    "parameters": { "structured": "data" },
    "requires_approval": true,
    "timeout": 60,
    "priority": "LOW | MEDIUM | HIGH | CRITICAL"
  }
}
```

`data` is signed using canonical JSON (`sort_keys=True`, compact separators) and PKCS#1 v1.5 + SHA-256.

## Outbound Message Envelope

The agent returns:

```json
{
  "id": "uuid",
  "cmd": "hybrid_task",
  "route": "result",
  "group_id": "uuid",
  "data": {
    "task_id": "uuid",
    "group_id": "uuid",
    "status": "SUCCESS | FAILED | BLOCKED",
    "host": "hostname",
    "execution_time_ms": 1234,
    "output": { "structured": "data" },
    "raw_output_hash": "sha256",
    "error": null
  }
}
```

Note: `group_id` appears at both the envelope level (for backend routing) and inside `data` (for task context).

## Catalog Advertisement And Discovery

On startup, the node publishes its hybrid tool catalog via:

- `cmd: "nodes"`
- `route: "registerHybridTools"`

You can also request current catalog on demand:

```json
{
  "id": "uuid",
  "cmd": "hybrid_catalog",
  "route": "get"
}
```

Trigger-based plan request:

```json
{
  "id": "uuid",
  "cmd": "hybrid_catalog",
  "route": "trigger",
  "data": {
    "trigger": "dns_exfiltration_suspected",
    "case_id": "uuid",
    "include_trigger_only": false
  }
}
```

Response:

```json
{
  "id": "uuid",
  "cmd": "hybrid_catalog",
  "route": "result",
  "data": {
    "catalog_version": "1.0.0",
    "group_id": "uuid",
    "tools": [],
    "trigger_map": {}
  }
}
```

## Security Guardrails

- Strict schema validation for required fields.
- Signature validation (enabled by default).
- `group_id` ownership check against registered node group (enabled by default).
- Category/action allowlists.
- Containment actions require approval.
- No freeform command fields accepted (`command`, `powershell`, `shell`, etc.).
- Command execution uses `subprocess` with `shell=False`.
- Execution timeout bounded by config.
- Audit log events are emitted as `HYBRID_TASK_AUDIT` with action metadata and output hash.
- Remote Windows collection is disabled by default and must be explicitly allowlisted.
- Remote process snapshot is disabled by default and requires approval + target allowlisting.
- Remote file listing/collection is disabled by default and requires host allowlisting.

## Building the NSIS Installer

Run from the repository root:

```powershell
# Standard build — credentials supplied at install time
.\installer\build.ps1

# Build with a specific version string
.\installer\build.ps1 -Version "1.2.0"

# Bake credentials into the installer for MDM / GPO silent deployment
.\installer\build.ps1 -AccessToken "mytoken" -SecretKey "mysecret"

# Repackage only (skip the PyInstaller compile step)
.\installer\build.ps1 -SkipPyInstaller
```

Output: `dist\hawk-soard-setup-<version>.exe`

Prerequisites: Python 3.6+, PyInstaller (auto-installed if missing), NSIS with
`makensis.exe` in PATH or at the default `C:\Program Files (x86)\NSIS\` location.

### Installing with credentials

The generated installer accepts `/ACCESS_TOKEN` and `/SECRET_KEY` on its
command line so credentials can be supplied at deploy time without baking them
into the binary:

```
hawk-soard-setup-1.2.0.exe /S /ACCESS_TOKEN=<token> /SECRET_KEY=<secret>
```

`/S` suppresses the UI (silent install).  `/D=<path>` overrides the install
directory and **must be the last argument** if used:

```
hawk-soard-setup-1.2.0.exe /S /ACCESS_TOKEN=<token> /SECRET_KEY=<secret> /D=C:\Custom\Path
```

The installer:
1. Writes `hawk-soard.cfg` with the supplied credentials (skipped if a config
   already exists — use the remote-deploy task for credential rotation).
2. Registers and starts the `HawkSoard` Windows service (Automatic start).
3. Copies itself to `<INSTDIR>\hawk-soard-setup.exe` so the running agent can
   push it to other endpoints via the remote-deploy task without downloading
   from the internet.

---

## Auto-Update

The agent runs an `AutoUpgrader` background thread that polls
`https://downloads.hawkdefense.com/agent/version.json` once per hour (default)
and self-updates when a newer version is available.

Control via `[SETTINGS]`:

| Key | Default | Description |
|-----|---------|-------------|
| `auto_upgrade` | `true` | Enable / disable the auto-update thread. |
| `auto_upgrade_interval` | `3600` | Seconds between version checks. |

Update workflow:
1. Fetch version manifest; compare to running version.
2. Download the zip package and verify SHA-256.
3. Extract over the install directory.
4. Restart the `HawkSoard` Windows service (or the Linux `hawk-soard` service).

---

## Remote Deployment

A running hawk-soard agent can deploy itself to another Windows host via the
`deploy_hawk_soard` hybrid task (requires WinRM to be enabled on the target).

Enable in `hawk-soard.cfg`:

```ini
enable_remote_deploy = true
# Optional allowlist — leave blank to allow any target
remote_deploy_allowed_targets = host1,host2,192.168.1.10
```

### Task parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `target_host` | yes | Hostname or IP of the destination host. |
| `username` | yes | WinRM credential user. |
| `password` | yes | WinRM credential password. |
| `domain` | no | Domain for `DOMAIN\user` format. |
| `hawk_server` | no | HAWK platform URL for the remote agent. **Defaults to the deploying agent's own `server` value.** |
| `access_token` | no | Access token for the remote agent. **Defaults to the deploying agent's own `access_token`.** |
| `secret_key` | no | Secret key for the remote agent. **Defaults to the deploying agent's own `secret_key`.** |
| `install_dir` | no | Install path on remote host. Default: `C:\Program Files\HAWK\SOAR`. |
| `service_name` | no | Windows service name. Default: `HawkSoard`. |
| `source_path` | no | Local path to a cached NSIS installer to push. Auto-detected from the agent install directory. |
| `source_url` | no | URL for the remote host to download from. Only used when no local installer is found. |
| `insecure` | no | Write `insecure = true` in the remote config (lab use only). |

### Deployment strategies

**Push (preferred)** — used automatically when `<INSTDIR>\hawk-soard-setup.exe`
exists (placed there by the NSIS installer at install time):

1. Opens a PSSession to the remote host.
2. Creates `<install_dir>` and `<install_dir>\data` on the remote host.
3. Copies the local `hawk-soard-setup.exe` to the remote host via
   `Copy-Item -ToSession`.
4. Runs the installer silently: `/S /ACCESS_TOKEN=<tok> /SECRET_KEY=<sec> /D=<dir>`.
5. Writes the config via a PowerShell base64 blob (unconditional, guarantees
   credentials are current even on re-deployment).
6. Stops and restarts the service so the new config takes effect.

**Download** — used when no local installer is cached:

1. Remote host downloads the package from `source_url`.
2. `.exe`: same NSIS silent-install approach as above.
3. `.zip`: extracts the archive, writes config, registers the service manually.
4. Always writes config and restarts the service unconditionally.

### Minimal task invocation (same-tenant deployment)

Because `hawk_server`, `access_token`, and `secret_key` default to the deploying
agent's own config, a same-tenant deployment only needs WinRM credentials:

```json
{
  "action": "deploy_hawk_soard",
  "parameters": {
    "target_host": "192.168.1.50",
    "username": "administrator",
    "password": "WinRMPassword1!"
  }
}
```

### Verification task

Use `verify_hawk_soard` to check the service status on a remote host after
deployment:

```json
{
  "action": "verify_hawk_soard",
  "parameters": {
    "target_host": "192.168.1.50",
    "username": "administrator",
    "password": "WinRMPassword1!"
  }
}
```

Response includes `status`, `running` (bool), `pid`, and `start_mode`.

---



## Config Keys

Add to `[SETTINGS]`:

- `task_signing_public_key`: path to trusted public key.
- `enforce_signed_hybrid_tasks`: `true|false` (default `true`).
- `enforce_group_id`: `true|false` (default `true`).
- `max_task_timeout`: max allowed task timeout in seconds (default `300`).
- `enable_remote_wmi_collection`: allow remote Windows process/module queries (default `false`).
- `remote_wmi_allowed_targets`: comma-separated remote host allowlist for remote collection.
- `enable_remote_process_snapshot`: enable remote process dump retrieval (default `false`).
- `remote_snapshot_allowed_targets`: comma-separated host allowlist for remote snapshots.
- `max_inline_artifact_bytes`: max artifact size to include as inline base64 in task result.
- `enable_remote_file_collection`: enable remote file/folder listing and file collection (default `false`).
- `remote_file_allowed_targets`: comma-separated host allowlist for remote file operations.
- `enable_command_execution`: allow local argv-based command execution and dynamic tool registration (default `true`).
- `max_disk_read_bytes`: maximum bytes returned by `disk_read` for file content requests (default `104857600`).
- `hybrid_dynamic_tools_file`: path to persisted dynamic tool definitions JSON file (default `<plugin_data_path>/hybrid_dynamic_tools.json`).
- `enable_remote_command_execution`: allow `remote_command_execute` (default `false`).
- `remote_command_allowed_targets`: comma-separated host allowlist for `remote_command_execute`.
- `enable_remote_registry_read`: allow `remote_registry_query` (default `false`).
- `remote_registry_allowed_targets`: comma-separated host allowlist for `remote_registry_query`.
- `enable_remote_config_management`: allow `remote_config_update`, `remote_service_restart`, and `remote_process_restart` (default `false`).
- `remote_config_allowed_targets`: comma-separated host allowlist for remote config/restart actions.
- `enable_remote_deploy`: allow `deploy_hawk_soard` and `verify_hawk_soard` (default `false`).
- `remote_deploy_allowed_targets`: comma-separated host allowlist for remote deployment. Empty means all targets are permitted.
- `auto_upgrade`: enable the background auto-update thread (default `true`).
- `auto_upgrade_interval`: seconds between version-check cycles (default `3600`).

When `parameters.submit_to_octorepl=true` and an action returns an `artifact`, Hawk-SOARD emits:
- `cmd: "hybrid_artifact"`
- `route: "submit"`
with artifact metadata/body for upstream submission workflows (for example VirusTotal).

## Windows Service Deployment Helper

For `.exe` distribution on Windows, use:

- `hawk-soard.exe -install -c "C:\ProgramData\Hawk\hawk-soard.cfg"`
- `hawk-soard.exe -service-status`
- `hawk-soard.exe -service-restart`
- `hawk-soard.exe -uninstall`

Built-in service management is transparent (standard Windows service registration, visible in Services/SCM).
