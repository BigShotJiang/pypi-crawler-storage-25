# For local database
# pysqlite driver
# sqlite+pysqlite:////file_path/to/database.db

from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey
from sqlalchemy.dialects.sqlite import \
    BLOB, BOOLEAN, CHAR, DATE, DATETIME, DECIMAL, FLOAT, \
    INTEGER, NUMERIC, JSON, SMALLINT, TEXT, TIME, TIMESTAMP, \
    VARCHAR

from logger import get_logger

from storage.db_interface import DBInterface


class soarDB(DBInterface):
    """
    Setup local database.

    """

    def __init__(self, config=None):
        super().__init__(config=config)
        self.logger = get_logger()

    def create_db_tables(self):
        metadata = MetaData()
        marketplace = self._create_marketplace_table(metadata)
        plugin_view = self._create_pluginview_table(metadata)
        #cache = self.create_cache_table(metadata)
        # Other tables here

        try:
            metadata.create_all(engine)
            self.logger.info('Tables created successfully')
        except Exception as e:
            self.logger.exception(
                'Error during Table creation, Error: %s' % (e))

    def _create_marketplace_table(self, metadata):
        marketplace = Table('marketplace', metadata,
                            Column('id', Integer, primary_key=True),
                            Column('plugin_id', Integer, nullable=False),
                            Column('plugin_name', String, nullable=False),
                            Column('active', BOOLEAN)
                            )

    def _create_pluginview_table(self, metadata):
        plugin_view = Table('plugin_view', metadata,
                            Column('id', Integer, primary_key=True),
                            Column('plugin_id', Integer, nullable=False),
                            Column('plugin_name', String, nullable=False),
                            Column('last_updated', DATETIME, nullable=False),
                            Column('html', BLOB)
                            )
