import gc
import unittest
import unittest.mock

from test.common_helper import DatabaseMock, fake_exit, load_users_from_main_config


class AnalysisPluginTest(unittest.TestCase):
    '''
    This is the base class for analysis plugin test.unit
    '''

    PLUGIN_NAME = 'plugin_test'

    def setup(self):

        pass

    def tear_down(self):
        self.analysis_plugin.shutdown()  # pylint: disable=no-member

        self.enter_patch.stop()
        self.exit_patch.stop()

        self.mocked_interface.shutdown()
        gc.collect()

    def init_basic_config(self):
        config = {}
        config['threads'] = 1

        return config

    def register_plugin(self, name, plugin_object):
        '''
        This is a mock checking if the plugin registers correctly
        '''
        self.assertEqual(name, self.PLUGIN_NAME,
                         'plugin registers with wrong name')
        self.assertEqual(plugin_object.NAME, self.PLUGIN_NAME,
                         'plugin object has wrong name')
        self.assertIsInstance(plugin_object.DESCRIPTION, str)
        self.assertIsInstance(plugin_object.VERSION, str)
        self.assertNotEqual(plugin_object.VERSION,
                            'not set', 'Plug-in version not set')
