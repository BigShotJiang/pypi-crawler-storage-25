import unittest

from hawkSoar import cli
from hawkSoar.version import __VERSION__


class VersionConsistencyTest(unittest.TestCase):
    def test_package_version_matches_release_target(self):
        self.assertEqual("0.0.7", __VERSION__)

    def test_cli_version_matches_package_version(self):
        self.assertEqual(__VERSION__, cli.VERSION)


if __name__ == "__main__":
    unittest.main()
