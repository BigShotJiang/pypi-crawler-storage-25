import json
import unittest
from pathlib import Path

from hawkSoar.version import __VERSION__


class ReleaseManifestContractTest(unittest.TestCase):
    def test_dist_version_manifest_matches_package_version_shape(self):
        manifest_path = Path(__file__).resolve().parents[3] / "dist" / "version.json"
        with open(manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)

        self.assertEqual(
            {"version", "filename", "sha256"},
            set(manifest.keys()),
        )
        self.assertEqual(__VERSION__, manifest["version"])
        self.assertEqual("0.0.7", manifest["version"])
        self.assertEqual("hawk-soard-setup-%s.exe" % __VERSION__, manifest["filename"])
        self.assertEqual(64, len(manifest["sha256"]))
        self.assertTrue(all(ch in "0123456789abcdef" for ch in manifest["sha256"]))


if __name__ == "__main__":
    unittest.main()
