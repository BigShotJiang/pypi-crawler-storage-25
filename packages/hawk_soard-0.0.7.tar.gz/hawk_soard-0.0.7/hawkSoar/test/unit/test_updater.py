import unittest
from unittest import mock

from hawkSoar.common.updater import AutoUpgrader


class AutoUpgraderManifestTest(unittest.TestCase):
    def test_fetch_manifest_accepts_utf8_bom_json(self):
        response = mock.MagicMock()
        response.raise_for_status.return_value = None
        response.content = b"\xef\xbb\xbf{\"version\":\"1.2.3\",\"filename\":\"hawk-soard.zip\",\"sha256\":\"abc\"}"

        updater = AutoUpgrader(current_version="1.0.0", install_dir=".")

        with mock.patch.object(updater, "_get", return_value=response):
            manifest = updater._fetch_manifest()

        self.assertEqual(
            {
                "version": "1.2.3",
                "filename": "hawk-soard.zip",
                "sha256": "abc",
            },
            manifest,
        )


if __name__ == "__main__":
    unittest.main()
