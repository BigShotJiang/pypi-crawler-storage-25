import unittest
from unittest import mock

from hawkSoar.cli import parseConfig, write_default_config


class CliConfigTest(unittest.TestCase):
    def test_parse_config_defaults_listener_only_when_omitted(self):
        config_text = """
[SETTINGS]
server = https://ir.hawk.io
access_token = token
secret_key = secret
insecure = false
timeout = 30
retry = 5
pid_file = /tmp/hawk-soard.pid

[MANAGER]
poll = 1
block = 1
db_type = sqlite

[PLUGINS]
data_path = /tmp/hawk-data
"""

        with mock.patch("builtins.open", mock.mock_open(read_data=config_text)):
            parsed = parseConfig("hawk-soard.cfg")

        self.assertEqual(
            {
                "server": ["https://ir.hawk.io"],
                "websocket_server": None,
                "listener_only": True,
                "access_token": "token",
                "secret_key": "secret",
            },
            {
                "server": parsed["server"],
                "websocket_server": parsed["websocket_server"],
                "listener_only": parsed["listener_only"],
                "access_token": parsed["access_token"],
                "secret_key": parsed["secret_key"],
            },
        )

    def test_parse_config_preserves_explicit_legacy_pipeline_opt_out(self):
        config_text = """
[SETTINGS]
server = https://ir.hawk.io
access_token = token
secret_key = secret
insecure = false
timeout = 30
retry = 5
pid_file = /tmp/hawk-soard.pid
listener_only = false

[MANAGER]
poll = 1
block = 1
db_type = sqlite

[PLUGINS]
data_path = /tmp/hawk-data
"""

        with mock.patch("builtins.open", mock.mock_open(read_data=config_text)):
            parsed = parseConfig("hawk-soard.cfg")

        self.assertEqual({"listener_only": False}, {"listener_only": parsed["listener_only"]})

    def test_write_default_config_emits_listener_only_true(self):
        fake_file = mock.mock_open()
        with mock.patch("os.path.abspath", side_effect=lambda path: path), \
             mock.patch("os.path.dirname", return_value="/configs"), \
             mock.patch("os.path.isdir", return_value=True), \
             mock.patch("builtins.open", fake_file):
            write_default_config(
                config_path="/configs/hawk-soard.cfg",
                access_key="token",
                secret_key="secret",
                server="https://ir.hawk.io",
            )

        written = "".join(call.args[0] for call in fake_file().write.call_args_list)
        self.assertIn("listener_only = true\n", written)


if __name__ == "__main__":
    unittest.main()
