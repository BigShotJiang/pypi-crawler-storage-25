import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile
import unittest
import venv
import zipfile
from uuid import uuid4


class PackagingContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo_root = Path(__file__).resolve().parents[3]

    def _copy_project(self, destination):
        ignore_names = shutil.ignore_patterns(
            ".git",
            ".pytest_cache",
            "__pycache__",
            ".claude",
            "build",
            "build_pyinstaller",
            "dist",
            "packaging-test-*",
            "*.egg-info",
            "*.pyc",
            "*.pyo",
            "hawk-soard.log",
            "hawk-soard.pid",
            "hawk-soard.key",
            "hawk-soard.crt",
            "hawk-soard-id",
        )
        project_copy = Path(destination) / "project"
        shutil.copytree(self.repo_root, project_copy, ignore=ignore_names)
        return project_copy

    def _make_workspace(self):
        workspace = self.repo_root / ("packaging-test-%s" % uuid4().hex)
        workspace.mkdir()
        self.addCleanup(shutil.rmtree, workspace, True)
        return workspace

    def _run(self, command, cwd):
        result = subprocess.run(
            command,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(
            0,
            result.returncode,
            msg="command failed: %s\nstdout:\n%s\nstderr:\n%s"
            % (" ".join(str(part) for part in command), result.stdout, result.stderr),
        )
        return result

    def _build_distributions(self):
        workspace = self._make_workspace()
        project_copy = self._copy_project(workspace)
        dist_dir = project_copy / "dist-test"
        dist_dir.mkdir()
        self._run(
            [
                sys.executable,
                "setup.py",
                "sdist",
                "--dist-dir",
                str(dist_dir),
            ],
            cwd=project_copy,
        )
        self._run(
            [
                sys.executable,
                "setup.py",
                "bdist_wheel",
                "--dist-dir",
                str(dist_dir),
            ],
            cwd=project_copy,
        )
        wheel_path = next(dist_dir.glob("*.whl"))
        sdist_path = next(dist_dir.glob("*.tar.gz"))
        return wheel_path, sdist_path

    def test_built_distributions_include_all_scheduler_modules(self):
        wheel_path, sdist_path = self._build_distributions()
        expected_scheduler_members = {
            "hawkSoar/schedulers/__init__.py",
            "hawkSoar/schedulers/contain.py",
            "hawkSoar/schedulers/decision.py",
            "hawkSoar/schedulers/ingest.py",
            "hawkSoar/schedulers/investigate.py",
            "hawkSoar/schedulers/match.py",
            "hawkSoar/schedulers/notify.py",
            "hawkSoar/schedulers/record.py",
            "hawkSoar/schedulers/recovery.py",
            "hawkSoar/schedulers/scheduler.py",
            "hawkSoar/schedulers/utility.py",
        }

        with zipfile.ZipFile(wheel_path) as wheel_archive:
            wheel_members = set(wheel_archive.namelist())

        with tarfile.open(sdist_path, "r:gz") as sdist_archive:
            sdist_members = {
                member.name.split("/", 1)[1]
                for member in sdist_archive.getmembers()
                if "/" in member.name
            }

        self.assertEqual(set(), expected_scheduler_members - wheel_members)
        self.assertEqual(set(), expected_scheduler_members - sdist_members)

    def test_built_wheel_exposes_exact_console_script_contract(self):
        wheel_path, _ = self._build_distributions()

        with zipfile.ZipFile(wheel_path) as wheel_archive:
            entry_points_path = next(
                name for name in wheel_archive.namelist() if name.endswith(".dist-info/entry_points.txt")
            )
            entry_points_text = wheel_archive.read(entry_points_path).decode("utf-8").strip()

        self.assertEqual("[console_scripts]\nhawk-soard = hawkSoar.cli:main", entry_points_text)

    def test_installed_distribution_exports_expected_console_script_shape(self):
        wheel_path, _ = self._build_distributions()

        workspace = self._make_workspace()
        venv_dir = workspace / "venv"
        try:
            venv.EnvBuilder(with_pip=True).create(venv_dir)
        except subprocess.CalledProcessError as exc:
            self.skipTest("virtualenv bootstrap unavailable in this environment: %s" % exc)

        if os.name == "nt":
            python_path = venv_dir / "Scripts" / "python.exe"
            script_path = venv_dir / "Scripts" / "hawk-soard.exe"
        else:
            python_path = venv_dir / "bin" / "python"
            script_path = venv_dir / "bin" / "hawk-soard"

        self._run(
            [str(python_path), "-m", "pip", "install", "--no-deps", str(wheel_path)],
            cwd=self.repo_root,
        )

        self.assertTrue(script_path.exists(), msg="expected console script at %s" % script_path)

        metadata = self._run(
            [
                str(python_path),
                "-c",
                (
                    "import importlib.metadata as md, json; "
                    "eps = sorted("
                    "f'{ep.group}:{ep.name}={ep.value}' "
                    "for ep in md.distribution('hawk-soard').entry_points"
                    "); "
                    "print(json.dumps(eps))"
                ),
            ],
            cwd=self.repo_root,
        )
        exported_entry_points = json.loads(metadata.stdout.strip())
        self.assertEqual(
            ["console_scripts:hawk-soard=hawkSoar.cli:main"],
            exported_entry_points,
        )

        if os.name != "nt":
            mode = script_path.stat().st_mode
            self.assertNotEqual(0, mode & stat.S_IXUSR)
            self.assertNotEqual(0, mode & stat.S_IXGRP)
            self.assertNotEqual(0, mode & stat.S_IXOTH)


if __name__ == "__main__":
    unittest.main()
