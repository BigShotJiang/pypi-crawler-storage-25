
try:
    import configparser  # Python3
except ImportError:
    import ConfigParser as configparser  # Python2.7


class hawkParseConfig(object):

    def __init__(self, cfg_file):
        self.cfg_file = cfg_file
        cfg = configparser.RawConfigParser()
        logger.info("Parsing Configuration: %s" % (cfg))
        fp = open(self.cfg_file)

        self.config = self.cfg.readfp(fp)
        self.self.ret = {}


def parseConfig(cfg):

    try:
        config = ConfigParser.ConfigParser()
        fp = open(cfg)
        config.readfp(fp)
        self.ret['server'] = config.get("API", "server")
        if type(self.ret['server']) is str:
            if "," in self.ret['server']:
                self.ret['server'] = self.ret['server'].split(',')
            else:
                self.ret['server'] = [self.ret['server']]

        self.ret['username'] = config.get("API", "username")
        self.ret['password'] = config.get("API", "password")
        self.ret['insecure'] = config.get("SETTINGS", "insecure")
        self.ret['global'] = config.get("SETTINGS", "global")
        self.ret['send_emails'] = config.get("SETTINGS", "send_emails")
        self.ret['timeout'] = config.get("SETTINGS", "timeout")
        self.ret['retry'] = config.get("SETTINGS", "retry")

        self.ret['smtp_from'] = config.get("SETTINGS", "smtp_from")

        try:
            self.ret['proxy_type'] = config.get("SETTINGS", "proxy_type")
            self.ret['proxy_host'] = config.get("SETTINGS", "proxy_host")
            self.ret['proxy'] = True
        except:
            self.ret['proxy'] = False
            pass

        fp.close()

    except Exception, e:
        hawk_print("Failed to parse config %s: [%s]" % (cfg, e))
        sys.exit()
    return self.ret
