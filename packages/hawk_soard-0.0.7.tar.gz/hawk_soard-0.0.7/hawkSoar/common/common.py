
import os
import sys
from ctypes import cdll, byref, create_string_buffer


def hawk_print(val):
    if not sys.stderr.closed:
        sys.stderr.write("%s\n" % val)


def set_proc_name(newname):
    # Linux-only best effort; noop on non-POSIX platforms (e.g. Windows).
    if os.name != "posix":
        return False
    try:
        libc = cdll.LoadLibrary('libc.so.6')
        buff = create_string_buffer(len(newname)+1)
        buff.value = newname
        libc.prctl(15, byref(buff), 0, 0, 0)
        return True
    except Exception:
        return False
