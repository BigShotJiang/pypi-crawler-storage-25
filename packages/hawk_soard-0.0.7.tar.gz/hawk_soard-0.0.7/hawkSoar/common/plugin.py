
import logging
from pathlib import Path


def get_dirs_in_dir(directory_path):
    result = []
    try:
        for item in Path(directory_path).iterdir():
            if item.is_dir():
                result.append(str(item.resolve()))
    except Exception as e:
        logging.error(f'Could not get directories: {e}', exc_info=True)
    return result
from pluginbase import PluginBase

from hawkSoar.common.filesystem import get_src_dir

from hawkSoar.common.logger import get_logger

logger = get_logger()

# github.com/mitsuhiko/pluginbase


def import_plugins(plugin_mount, plugin_base_dir):
    plugin_base = PluginBase(package=plugin_mount)
    plugin_src_dirs = _get_plugin_src_dirs(plugin_base_dir)
    return plugin_base.make_plugin_source(searchpath=plugin_src_dirs)


def _get_plugin_src_dirs(base_dir):
    plugin_in_base_path = Path(get_src_dir(), base_dir)
    plugin_dirs = get_dirs_in_dir(str(plugin_in_base_path))
    plugins = []
    for plugin_path in plugin_dirs:
        plugin_code_dir = Path(plugin_path, 'code')
        if plugin_code_dir.is_dir():
            plugins.append(str(plugin_code_dir))
        """
        # noisy and can be ignored
        else:
            logger.debug(
                'Plugin has no code directory: {}'.format(plugin_path))
        """

    return plugins
