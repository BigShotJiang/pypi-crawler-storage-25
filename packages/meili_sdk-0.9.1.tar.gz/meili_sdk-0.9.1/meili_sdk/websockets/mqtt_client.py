import logging

from meili_sdk.clients.base_meili_client import MeiliBaseClient

logger = logging.getLogger("meili_sdk")

import json
import logging
import socket
import typing as t
import urllib.parse
from datetime import datetime
from enum import Enum

from paho.mqtt.client import Client as _Client
from paho.mqtt.client import MQTTMessage

from meili_sdk.exceptions import MqttException, UnauthorizedMqttException
from meili_sdk.mqtt.models.state import VDA5050StateMessage
from meili_sdk.mqtt.site import get_host

logger = logging.getLogger("meili_sdk")
from meili_sdk.websockets.constants import FleetEvents

__all__ = ("MeiliMqttClient",)


class MqttConnectionStatus(Enum):
    UNKNOWN = 0
    CONNECTING = 1
    FAILED = 2
    CONNECTED = 3


class MeiliMqttClient(MeiliBaseClient):
    """
    Base Meili MQTT Client
    """

    def __init__(
        self,
        client_id: str,
        token: str,
        fleet_uuid: str,
        qos: int = 0,
        port=1883,
        host: t.Optional[str] = None,
        **kwargs,
    ):
        super().__init__(token, **kwargs)
        host = get_host()
        self._url = urllib.parse.urlparse(host).hostname
        if qos < 0 or qos > 3:
            raise ValueError("qos needs to be between 0 and 3")
        self._qos = qos

        self.port = port
        self.client_id = client_id
        self._fleet_uuid = fleet_uuid

        # MQTT Client setup
        self.client = _Client(client_id=client_id)
        self.client.username_pw_set(username=client_id, password=token)
        self.client.on_connect = self.__on_connect
        self.client.on_disconnect = self.__on_disconnect
        self.client.on_message = self.__on_message
        self.client.on_subscribe = self.__on_subscribe
        self.__topics = {}

        self.connection_state = MqttConnectionStatus.UNKNOWN

    @property
    def state_topic(self) -> str:
        return f"meili/sdk/{self._fleet_uuid}/state"

    @property
    def order_topic(self) -> str:
        return f"meili/sdk/{self._fleet_uuid}/order"

    def _set_lwt(self):
        """
        Set Last Will and Testament for MQTT connection
        """
        self.client.will_clear()

        message = {"event": FleetEvents.DISCONNECT, "vehicles": self.vehicles}
        self.client.will_set(
            topic=self.state_topic,
            payload=(json.dumps(message, default=str)).encode("utf-8"),
            qos=1,
            retain=True,
        )

    def run(self):
        self.reconnect()
        self.client.loop_forever(timeout=1.0)

    def disconnect(self):
        self.__check_connection()
        self.client.disconnect()

    def reconnect(self):
        """
        Reconnect to MQTT broker if connection is closed
        """

        try:
            self.__check_connection()
            return
        except ConnectionError:
            pass
        self._set_lwt()
        try:
            #self.client.tls_set()
            self.connection_state = MqttConnectionStatus.CONNECTING
            self.client.connect(
                self._url, port=self.port, keepalive=True, bind_address=""
            )
        except socket.gaierror as e:
            self.connection_state = MqttConnectionStatus.FAILED
            raise MqttException(
                f"Cannot connect to {self._url}:{self.port}. Maybe it's incorrect URI?"
            ) from e
            

    def send_raw(self, message: any):
        

        self.__check_connection("Cannot send. Connection is closed")

        if isinstance(message, VDA5050StateMessage):
            message = json.dumps(dict(message), default=str)
        elif not isinstance(message, str):
            try:
                message = json.dumps(message)
            except (TypeError, ValueError):
                message = str(message)

        self.client.publish(topic=self.state_topic, payload=message, qos=self._qos)

    def wait_for_connection(self, timeout=10):
        """
        Block execution until connection is established

        If connection is still closed after timeout provided, it will raise TimeoutError

        If connection was not opened it will raise a ConnectionError
        """
        if self.connection_state in [
            MqttConnectionStatus.UNKNOWN,
            MqttConnectionStatus.FAILED,
        ]:
            raise ConnectionError("Connection is not currently connecting")
        start_time = datetime.now()

        while (
            self.connection_state == MqttConnectionStatus.CONNECTING
            and (datetime.now() - start_time).seconds < timeout
        ):
            continue

        if self.connection_state != MqttConnectionStatus.CONNECTED:
            raise TimeoutError("Timed out")

    def __check_connection(self, custom_message=None):
        if not self.client.is_connected():
            raise ConnectionError(custom_message or "Connection is closed")

    def __on_connect(self, client: _Client, userdata, flags: dict, rc: int):
        if rc != 0:
            self.connection_state = MqttConnectionStatus.FAILED
            raise UnauthorizedMqttException("Bad credentials provided, cannot authenticate")

        self.connection_state = MqttConnectionStatus.CONNECTED
        
        client.subscribe(self.order_topic, qos=self._qos)

        self._connection_is_open = True

        self.on_open()



    def __on_subscribe(
        self, _: _Client, __: t.Optional[dict], mid: int, granted_qos: t.Tuple[int]
    ):
        if granted_qos[0] > 3:
            raise UnauthorizedMqttException(
                f"Subscription unauthorized to topic {self.__topics[mid]}"
            )

    def __on_disconnect(self, client: _Client, _, rc):
        self.on_close()

    def __on_message(self, client: _Client, _: t.Optional[dict], message: MQTTMessage):

        self.on_message(client, message.payload)
    
    def close_mqtt(self):
        """
        Cierra la conexión MQTT de forma segura.
        Detiene loop, borra callbacks, y marca estado como cerrado.
        """

        try:
            logger.info("[MQTT] Closing MQTT connection...")

            # Evita que otros métodos crean que sigue abierto
            self._connection_is_open = False
            self.connection_state = MqttConnectionStatus.UNKNOWN

            # Elimina el LWT para no enviar mensajes fantasma
            self.client.will_clear()

            # Desconectar y detener loop
            self.client.disconnect()
            self.client.loop_stop(force=True)

            # Opcional: borrar handlers
            self.client.on_connect = None
            self.client.on_disconnect = None
            self.client.on_message = None
            self.client.on_subscribe = None

            logger.info("[MQTT] Connection closed successfully.")

        except Exception as e:
            logger.error(f"[MQTT] Error closing MQTT connection: {e}")
            raise

