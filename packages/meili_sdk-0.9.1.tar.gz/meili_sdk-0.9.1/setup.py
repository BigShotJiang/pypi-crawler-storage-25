from setuptools import find_packages, setup

setup(
    name="meili_sdk",
    version="0.9.1",  # your CI may override this
    packages=find_packages(
        exclude=["tests", "tests.*", "examples", "examples.*"]),
    install_requires=[
        "requests>=2.26.0",
        "PyYAML~=6.0",
        "websocket-client>=1.2.3",
    ],
    extras_require={
        "MQTT": [
            "paho-mqtt==1.6.1",
        ],
    },
)
