from unittest.mock import mock_open, patch

from meili_sdk.config.utils import load_config, safe_load_config

sample_data = """uuid: 3f260ec247704c0ab5ee950d499e7675
fleet: 0be8303a5fec518fe884172d95350fd1404e8299
mqttId: meili-agent-66fc1ff8-c313-4f43-a6f6-8f4bd1c8adde
token: 2133207229e54a8362356739c985fd69cbecb882
version: 1
timestamp: "2022-06-30T09:03:58.052069Z"
site: https://development.meilirobots.com
"""


class TestConfigLoading:
    @patch("builtins.open", new_callable=mock_open, read_data=sample_data)
    def test_loading(self, mock_file):
        config = load_config()
        mock_file.assert_called_once()

        expected = {
            "uuid": "3f260ec247704c0ab5ee950d499e7675",
            "fleet": "0be8303a5fec518fe884172d95350fd1404e8299",
            "mqttId": "meili-agent-66fc1ff8-c313-4f43-a6f6-8f4bd1c8adde",
            "token": "2133207229e54a8362356739c985fd69cbecb882",
            "version": 1,
            "timestamp": "2022-06-30T09:03:58.052069Z",
            "site": "https://development.meilirobots.com",
        }

        assert config == expected

    def test_load_no_file(self):
        caught = False
        try:
            load_config()
        except FileNotFoundError:
            caught = True

        assert caught

        cfg = safe_load_config()

        assert cfg == None
