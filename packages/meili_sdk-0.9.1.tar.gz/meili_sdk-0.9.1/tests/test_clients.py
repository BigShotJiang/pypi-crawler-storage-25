from requests.models import Response

from meili_sdk.clients import (
    APITokenClient,
    PersistentTokenClient,
    SDKClient,
    get_client,
)


class TestClients:
    @staticmethod
    def get_response(status_code=200, typ="SDKToken"):
        response = Response()
        response.status_code = status_code
        content = '{"key_type": "%s"}' % typ
        response._content = content.encode()
        return response

    def test_sdk_client(self, mocker):
        mocker.patch("requests.post", return_value=self.get_response(typ="SDKToken"))

        client = get_client("None", None)

        assert client is not None
        assert isinstance(client, SDKClient)

    def test_api_token_client(self, mocker):
        mocker.patch("requests.post", return_value=self.get_response(typ="APIToken"))

        client = get_client("None", None)

        assert client is not None
        assert isinstance(client, APITokenClient)

    def test_persistent_client(self, mocker):
        mocker.patch(
            "requests.post", return_value=self.get_response(typ="PersistentToken")
        )

        client = get_client("None", None)

        assert client is not None
        assert isinstance(client, PersistentTokenClient)

    def test_no_token(self):
        called = False
        try:
            get_client()
        except Exception as e:
            called = True
            assert isinstance(e, ValueError)
        assert called, "Exception not raised"

    def test_sdk_client_headers(self):
        client = SDKClient("token")
        assert client.get_authorization_headers()["Authorization"] == "SDK-Key token"

    def test_api_token_client_headers(self):
        client = APITokenClient("token")
        assert client.get_authorization_headers()["Authorization"] == "Bearer token"

    def test_persistent_api_token_client_headers(self):
        client = PersistentTokenClient("token")
        assert client.get_authorization_headers()["Authorization"] == "API-Key token"
