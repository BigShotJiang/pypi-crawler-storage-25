from unittest.mock import mock_open, patch

from meili_sdk.exceptions import MissingAttributesException
from meili_sdk.schedules import load_schedules
from meili_sdk.schedules.exceptions import TaskFileDoesNotExist
from meili_sdk.schedules.models import ScheduledTask

sample_data = """- uuid: eb516c37a7584540afe89a8d0293f1bd
  name: "Scheduled task"
  time: "00:00"
  week_days: []
  cron: '*/20 * * * *'
  vehicle:
    uuid: f35bbfc6fa2642c7b974c2eb4bf3c67d
    verbose_name: V1
  task_preset:
    uuid: 7599aa1b240f4808bc738a3a53c22936
    slug: test
    title: Test
    auto_confirmation: false
    subtasks:
        - index: 0
          indoor_point:
            uuid: 0e839119fa9940b196b38e52e7b9501f
            name: Station
            point_type: drop_off
            x_coordinate: 100
            y_coordinate: 200
            rotation: 270
"""


class TestLoadSchedules:
    @patch("builtins.open", new_callable=mock_open, read_data=sample_data)
    def test_loading_schedule_success(self, mock_file):
        schedules = load_schedules()

        mock_file.assert_called_once()
        assert 1 == len(schedules)

        schedule = schedules[0]

        assert schedule.uuid == "eb516c37a7584540afe89a8d0293f1bd"
        assert schedule.name == "Scheduled task"
        assert schedule.time == "00:00"
        assert schedule.vehicle.uuid == "f35bbfc6fa2642c7b974c2eb4bf3c67d"
        assert schedule.vehicle.verbose_name == "V1"
        assert schedule.task_preset.uuid == "7599aa1b240f4808bc738a3a53c22936"
        assert schedule.task_preset.slug == "test"
        assert schedule.task_preset.title == "Test"
        assert not schedule.task_preset.auto_confirmation

        assert 1 == len(schedule.task_preset.subtasks)

        subtask = schedule.task_preset.subtasks[0]

        assert subtask.index == 0
        indoor_point = subtask.indoor_point
        assert indoor_point.uuid == "0e839119fa9940b196b38e52e7b9501f"
        assert indoor_point.name == "Station"
        assert indoor_point.point_type == "drop_off"
        assert indoor_point.x_coordinate == 100
        assert indoor_point.y_coordinate == 200
        assert indoor_point.rotation == 270

    def test_no_file(self):
        try:
            load_schedules()
        except TaskFileDoesNotExist:
            assert True
        else:
            assert False, "Exception not raised"

    def test_scheduled_task_creation(self):
        datasets = [
            {
                "uuid": "eb516c37a7584540afe89a8d0293f1bd",
                "name": "Missing vehicle",
                "time": "00:00",
                "week_days": [],
                "cron": "*/20 * * * *",
                "task_preset": {
                    "uuid": "aa1b240f4808bc738a3a53c22936",
                    "slug": "test",
                    "title": "Test",
                    "auto_confirmation": False,
                    "subtasks": [
                        {
                            "index": 0,
                            "indoor_point": {
                                "uuid": "fa9940b196b38e52e7b9501f",
                                "name": "Station",
                                "point_type": "drop_off",
                                "x_coordinate": 100,
                                "y_coordinate": 200,
                                "rotation": 270,
                            },
                        }
                    ],
                },
            },
            {
                "uuid": "eb516c37a7584540afe89a8d0293f1bd",
                "name": "Missing task preset",
                "time": "00:00",
                "week_days": [],
                "cron": "*/20 * * * *",
                "vehicle": {
                    "uuid": "f35bbfc6fa2642c7b974c2eb4bf3c67d",
                    "verbose_name": "V1",
                },
            },
            {
                "uuid": "eb516c37a7584540afe89a8d0293f1bd",
                "name": "Missing subtasks",
                "time": "00:00",
                "week_days": [],
                "cron": "*/20 * * * *",
                "vehicle": {
                    "uuid": "f35bbfc6fa2642c7b974c2eb4bf3c67d",
                    "verbose_name": "V1",
                },
                "task_preset": {
                    "uuid": "aa1b240f4808bc738a3a53c22936",
                    "slug": "test",
                    "title": "Test",
                    "auto_confirmation": False,
                },
            },
            {
                "uuid": "eb516c37a7584540afe89a8d0293f1bd",
                "name": "Missing indoor_point",
                "time": "00:00",
                "week_days": [],
                "cron": "*/20 * * * *",
                "vehicle": {
                    "uuid": "f35bbfc6fa2642c7b974c2eb4bf3c67d",
                    "verbose_name": "V1",
                },
                "task_preset": {
                    "uuid": "aa1b240f4808bc738a3a53c22936",
                    "slug": "test",
                    "title": "Test",
                    "auto_confirmation": False,
                    "subtasks": [
                        {
                            "index": 0,
                        }
                    ],
                },
            },
        ]

        for dataset in datasets:
            try:
                ScheduledTask(**dataset)
            except MissingAttributesException:
                ...
            else:
                assert (
                    False
                ), f"{dataset['name']} missing attributes error were not risen"
