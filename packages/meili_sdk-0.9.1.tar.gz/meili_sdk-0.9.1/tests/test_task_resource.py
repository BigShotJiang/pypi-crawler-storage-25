from unittest.mock import MagicMock

from meili_sdk.clients.sdk_client import SDKClient
from meili_sdk.models.vehicle import Vehicle
from meili_sdk.resources.tasks import SDKTaskResource
from tests.helpers import build_mocked_response

example_task = {
    "uuid": "b5d683cdd18441a19e5b96e801b25911",
    "number": "20210618_0010",
    "user": "454c54f57b3c462698bcb2e6b42de996",
    "vehicle": "c9f62c12a4904e95baf6839d0a2fabde",
    "task_status": "completed",
    "priority": False,
    "subtasks": [
        {
            "uuid": "a2ed25fda38d45cc81f636aa00808000",
            "location": "1db1abe116304be2955d0dca16d27e3f",
            "robot_executed_at": "2021-06-18T14:51:56.100971Z",
            "executed_at": "2021-06-18T14:51:58.836195Z",
            "index": 0,
            "location_point": {
                "uuid": "1db1abe116304be2955d0dca16d27e3f",
                "x": -128,
                "y": -40,
                "metric": {"x": 72, "y": 224},
            },
        }
    ],
    "team": "4c310b85696e4ffe9283f9bdfe2337f1",
}


class TestTaskResource:
    def test_task_list_retrieval(self, mocker):
        example_response = {
            "count": 2,
            "next": None,
            "previous": None,
            "results": [
                {
                    "uuid": "b5d683cdd18441a19e5b96e801b25911",
                    "number": "20210618_0010",
                    "user": "454c54f57b3c462698bcb2e6b42de996",
                    "vehicle": "c9f62c12a4904e95baf6839d0a2fabde",
                    "task_status": "completed",
                    "priority": False,
                    "subtasks": [
                        {
                            "uuid": "a2ed25fda38d45cc81f636aa00808000",
                            "location": "1db1abe116304be2955d0dca16d27e3f",
                            "robot_executed_at": "2021-06-18T14:51:56.100971Z",
                            "executed_at": "2021-06-18T14:51:58.836195Z",
                            "index": 0,
                            "location_point": {
                                "uuid": "1db1abe116304be2955d0dca16d27e3f",
                                "x": -128,
                                "y": -40,
                                "metric": {"x": 72, "y": 224},
                            },
                        }
                    ],
                    "team": "4c310b85696e4ffe9283f9bdfe2337f1",
                },
                {
                    "uuid": "1b14a989c32249f78dceaaa0c01d962f",
                    "number": "20211118_0001",
                    "task_status": "terminated",
                    "priority": False,
                    "subtasks": [
                        {
                            "uuid": "081561f83f0944daaefc0fdeb08839ac",
                            "location": "d9d9110989cf40a197eb5551c00acd64",
                            "robot_executed_at": None,
                            "executed_at": "2021-11-18T14:44:18.424852Z",
                            "index": 0,
                            "location_point": {
                                "uuid": "d9d9110989cf40a197eb5551c00acd64",
                                "x": 33,
                                "y": 81,
                                "metric": {"x": 1.65, "y": 4.05},
                            },
                        }
                    ],
                    "team": "4c310b85696e4ffe9283f9bdfe2337f1",
                },
            ],
        }

        mocked: MagicMock = mocker.patch(
            "requests.get", return_value=build_mocked_response(example_response)
        )

        resource = SDKTaskResource(SDKClient(""))

        status, tasks, raw_data, next_page = resource.get_tasks()

        assert mocked.call_count == 1
        assert status == 200, f"Invalid status: {status}"
        assert next_page is None
        assert raw_data is not None
        assert isinstance(tasks, list)
        assert len(tasks) == 2

        task = tasks[0]
        assert len(task.subtasks) == 1
        subtask = task.subtasks[0]

        assert isinstance(subtask.location_point, dict)

        task = tasks[1]
        assert len(task.subtasks) == 1
        subtask = task.subtasks[0]

        assert isinstance(subtask.location_point, dict)

    def test_task_status_update(self, mocker):
        mocked: MagicMock = mocker.patch(
            "requests.patch", return_value=build_mocked_response(example_task)
        )

        resource = SDKTaskResource(SDKClient(""))
        status, task, raw_data, next_page = resource.update_vehicle_task(
            Vehicle(uuid="12345"), 2, 4
        )

        assert mocked.call_count == 1
        assert mocked.call_args_list
        assert status == 200
        assert task.uuid == example_task["uuid"]
        assert raw_data is not None
        assert next_page is None
