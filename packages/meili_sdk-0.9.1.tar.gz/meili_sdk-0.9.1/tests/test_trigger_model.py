from meili_sdk.exceptions import ValidationError
from meili_sdk.models.trigger import Trigger


class TestTriggerModel:
    def test_invalid_action(self):
        try:
            Trigger(verbose_name="trigger", action="non existent").validate()
        except ValidationError:
            assert True
        else:
            assert False, "Exception was not raised"
