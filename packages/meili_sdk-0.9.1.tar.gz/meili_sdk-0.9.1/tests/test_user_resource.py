from unittest.mock import MagicMock

from meili_sdk.clients.sdk_client import SDKClient
from meili_sdk.exceptions import BadRequest
from meili_sdk.resources.users import UserResource
from tests.helpers import build_mocked_response

sample_user = {
    "uuid": "6fb2ca6bcbb841a282cb39eb8dac62bd",
    "email": "test@test.com",
    "username": "test",
    "first_name": "First",
    "last_name": "Last",
    "timezone": "CPH",
    "token": "12345",
}


class TestUserResource:
    def test_get_current_user(self, mocker):
        mocked: MagicMock = mocker.patch(
            "requests.get", return_value=build_mocked_response(sample_user)
        )

        resource = UserResource(SDKClient(""))
        status, user, raw_data, next_page = resource.get_token_user()

        assert mocked.called
        assert mocked.call_count == 1
        assert next_page is None
        assert raw_data is not None
        assert status == 200
        assert user.uuid == sample_user["uuid"]
        assert user.email == sample_user["email"]
        assert user.username == sample_user["username"]
        assert user.first_name == sample_user["first_name"]
        assert user.last_name == sample_user["last_name"]
        assert user.timezone == sample_user["timezone"]
        assert user.token == sample_user["token"]

    def test_bad_response(self, mocker):
        mocker.patch(
            "requests.get", return_value=build_mocked_response("", status_code=400)
        )
        resource = UserResource(SDKClient(""))

        try:
            resource.get_token_user()
        except BadRequest:
            assert True
        else:
            assert False, "BadRequest exception was not raised"
