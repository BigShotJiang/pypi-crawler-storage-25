from meili_sdk.exceptions import MissingAttributesException
from meili_sdk.mqtt.models.action import VDA5050ActionMessage


class TestVDA5050ActionMessage:
    def test_initialization(self):
        data = {
            "headerId": "meili-header-13212",
            "version": "1.9.x",
            "actions": [
                {
                    "actionType": "move",
                    "actionParameters": [
                        {"key": "x", "value": 2},
                        {"key": "y", "value": 3},
                        {
                            "key": "rotation",
                            "value": 60,
                        },
                    ],
                }
            ],
        }

        message = VDA5050ActionMessage(**data)

        assert message.headerId == data["headerId"]
        assert message.version == data["version"]
        assert len(message.actions) == 1
        action = message.actions[0]
        assert action.actionType == "move"

        param = action.get_parameter("x")

        assert isinstance(param, dict)
        assert param["value"] == 2

        data["actions"][0]["actionParameters"][1]["key"] = "x"

        message = VDA5050ActionMessage(**data)
        assert len(message.actions) == 1
        action = message.actions[0]
        param = action.get_parameter("x")
        assert type(param) == list
        assert len(param) == 2

    def test_missing_actions(self):
        data = {
            "headerId": "meili-header-13212",
            "version": "1.9.x",
        }

        try:
            VDA5050ActionMessage(**data)
        except MissingAttributesException:
            pass
        else:
            assert False, "Exception not risen"
