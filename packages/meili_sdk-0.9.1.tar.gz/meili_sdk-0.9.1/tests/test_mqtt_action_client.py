import json

from meili_sdk.mqtt.action_client import MeiliMqttActionClient
from meili_sdk.mqtt.models.action import VDA5050ActionMessage
from meili_sdk.mqtt.models.order import VDA5050OrderMessage


class TestMeiliMqttActionClient:
    def test_on_action(self):
        on_action_called = False

        def on_action(message):
            assert type(message) == VDA5050ActionMessage
            nonlocal on_action_called
            on_action_called = True

        client = MeiliMqttActionClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
        )
        client.action_handler = on_action

        data = {
            "headerId": "meili-header-13212",
            "version": "1.9.x",
            "actions": [
                {
                    "actionType": "move",
                    "actionParameters": [
                        {"key": "x", "value": 2},
                        {"key": "y", "value": 3},
                        {
                            "key": "rotation",
                            "value": 60,
                        },
                    ],
                }
            ],
        }

        client.on_message(
            client.client,
            topic="vehicle/213312332/actions",
            raw_data=json.dumps(data).encode("utf-8"),
            data=data,
        )

        assert on_action_called

        on_action_called = False
        client.on_message(
            client.client,
            topic="vehicle/213312332",
            raw_data=json.dumps(data).encode("utf-8"),
            data=data,
        )

        assert not on_action_called

        try:
            client.action_handler = 1
        except TypeError:
            ...
        else:
            assert False, "Error not raised"

    def test_on_order(self):
        on_order_called = False

        def on_order(message):
            assert type(message) == VDA5050OrderMessage
            nonlocal on_order_called
            on_order_called = True

        client = MeiliMqttActionClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
        )
        client.on_order = on_order

        data = {
            "headerId": 12,
            "version": "0.1.2",
            "manufacturer": "meili",
            "serialNumber": "1234",
            "orderId": "1234",
            "nodes": [
                {
                    "nodeId": 1,
                    "sequenceId": 1,
                    "description": "First node",
                    "released": True,
                    "nodePosition": {
                        "x": 1.2,
                        "y": 2.1,
                        "theta": 300,
                    },
                },
            ],
            "edges": [
                {
                    "edgeId": 123,
                    "sequenceId": 1,
                    "endNodeId": 123,
                    "trajectory": {
                        "controlPoints": [
                            {
                                "x": 1,
                                "y": 2,
                            }
                        ]
                    },
                },
            ],
        }

        client.on_message(
            client.client,
            topic="vehicle/213312332/orders",
            raw_data=json.dumps(data).encode("utf-8"),
            data=data,
        )
        assert on_order_called
