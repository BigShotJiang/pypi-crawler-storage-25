import json

from meili_sdk.mqtt.models.state import (
    VDA5050NodeState,
    VDA5050StateMessage,
    VDA5050VehicleBatteryState,
    VDA5050VehiclePosition,
)
from meili_sdk.version import VERSION


class TestVDA5050ActionMessage:
    def test_creation(self):
        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
        )

        assert message.version == VERSION, "Version is not set automatically"
        assert message.headerId is not None, "headerId is not set automatically"
        assert message.timestamp is not None, "timestamp is not set automatically"

        message.validate()

    def test_creation_with_node_states(self):
        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            nodeStates=[
                {
                    "nodeId": "1",
                    "sequenceId": "1",
                    "nodePosition": {"x": 5, "y": 10, "theta": 30},
                    "released": True,
                },
                VDA5050NodeState(
                    nodeId="2",
                    sequenceId="2",
                    nodePosition={"x": 10, "y": 20, "theta": 30},
                ),
            ],
        )

        assert len(message.nodeStates) == 2
        state = message.nodeStates[0]
        assert state.nodeId == "1"
        assert state.sequenceId == "1"
        assert state.nodePosition.x == 5
        assert state.nodePosition.y == 10
        assert state.released

        state = message.nodeStates[1]
        assert state.nodeId == "2"
        assert state.sequenceId == "2"
        assert state.nodePosition.x == 10
        assert state.nodePosition.y == 20
        assert not state.released

        message.validate()

    def test_creation_with_position(self):
        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            agvPosition={"x": 10, "y": 20, "theta": 30, "mapId": "", "positionInitialized": True},
        )

        message.validate()
        assert message.agvPosition.x == 10
        assert message.agvPosition.y == 20
        assert message.agvPosition.theta == 30
        assert message.agvPosition.positionInitialized
        assert message.agvPosition.mapId == ""

        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            agvPosition=VDA5050VehiclePosition(x=10, y=20, theta=30, mapId="", positionInitialized=True),
        )

        message.validate()
        assert message.agvPosition.x == 10
        assert message.agvPosition.y == 20
        assert message.agvPosition.theta == 30
        assert message.agvPosition.positionInitialized
        assert message.agvPosition.mapId == ""

    def test_creation_with_battery(self):
        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            batteryState={
                "batteryCharge": 10,
                "batteryVoltage": 12,
                "batteryHealth": 1,
            },
        )

        message.validate()
        assert message.batteryState.batteryCharge == 10
        assert message.batteryState.batteryVoltage == 12
        assert message.batteryState.batteryHealth == 1
        assert not message.batteryState.charging
        assert not message.batteryState.reach

        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            batteryState=VDA5050VehicleBatteryState(
                batteryCharge=10, batteryVoltage=12, batteryHealth=1, charging=True
            ),
        )

        message.validate()
        assert message.batteryState.batteryCharge == 10
        assert message.batteryState.batteryVoltage == 12
        assert message.batteryState.batteryHealth == 1
        assert message.batteryState.charging
        assert not message.batteryState.reach

    def test_to_dictionary(self):
        message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="f35bbfc6fa2642c7b974c2eb4bf3c67d",
            nodeStates=[
                {
                    "nodeId": "1",
                    "sequenceId": "1",
                    "nodePosition": {"x": 5, "y": 10, "theta": 30},
                    "released": True,
                },
                VDA5050NodeState(
                    nodeId="2",
                    sequenceId="2",
                    nodePosition={"x": 10, "y": 20, "theta": 30},
                ),
            ],
            agvPosition={"x": 10, "y": 20, "theta": 30, "mapId": "", "positionInitialized": True},
            batteryState=VDA5050VehicleBatteryState(
                batteryCharge=10, batteryVoltage=12, batteryHealth=1, charging=True
            ),
        )

        json.dumps(dict(message), default=str)
        assert True
