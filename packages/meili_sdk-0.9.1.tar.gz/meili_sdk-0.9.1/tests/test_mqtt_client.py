import json
import socket
from unittest.mock import MagicMock

from paho.mqtt.client import MQTTMessage
from requests import Response

from meili_sdk.exceptions import MqttException, UnauthorizedMqttException
from meili_sdk.mqtt.client import MeiliMqttClient
from meili_sdk.mqtt.models.state import VDA5050StateMessage, VDA5050VehiclePosition
from meili_sdk.version import VERSION


class TestMqttClient:
    def test_init(self):
        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")
        assert client.url == "app.meilirobots.com"

    def test_connection(self, mocker):
        def connection_error(url, port, keepalive, bind_address):
            assert url == "app.meilirobots.com"
            assert port == 1883
            assert keepalive
            assert not bind_address
            raise socket.gaierror

        mocked: MagicMock = mocker.patch(
            "paho.mqtt.client.Client.connect", side_effect=connection_error
        )
        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")

        try:
            client.run()
        except MqttException:
            assert True
            mocked.assert_called_once()
            return
        assert False, "Exception was not raised"

    def test_successful_connection(self, mocker):
        mocked_forever: MagicMock = mocker.patch(
            "paho.mqtt.client.Client.loop_forever", return_value=0
        )
        mocked_loop_start: MagicMock = mocker.patch(
            "paho.mqtt.client.Client.loop_start", return_value=0
        )
        mocked: MagicMock = mocker.patch("paho.mqtt.client.Client.connect")

        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")
        client.run()

        mocked.assert_called_once()
        mocked_loop_start.assert_called_once()

        client.run(block=True)
        mocked_forever.assert_called_once()

    def test_subscribe(self, mocker):
        def handle_subscribe(topic, qos):
            assert type(topic) == str
            assert 0 <= qos <= 3
            return topic, topic

        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=True)
        mocked: MagicMock = mocker.patch(
            "paho.mqtt.client.Client.subscribe", side_effect=handle_subscribe
        )

        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")

        client.subscribe("t1")
        assert mocked.call_count == 1
        client.subscribe("t2", "t3")
        assert mocked.call_count == 3
        client.subscribe(
            ("t4", 0),
            ("t5", 1),
        )
        assert mocked.call_count == 5

        try:
            client.subscribe(
                ("t6",),
            )
        except TypeError:
            assert True
        else:
            assert False, "Exception not raised"

        try:
            client.subscribe("t1")
        except ValueError:
            assert True
        else:
            assert False, "Exception not raised"

        try:
            client.subscribe(("t10", 4))
        except ValueError:
            assert True
        else:
            assert False, "ValueError not risen"

    def test_on_connect_hook(self):
        connect_handler_called = False

        def connect_handler(_client, flags, rc):
            assert _client is not None
            assert isinstance(flags, dict)
            assert rc == 0
            nonlocal connect_handler_called
            connect_handler_called = True

        client = MeiliMqttClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
            open_handler=connect_handler,
        )
        try:
            client.client.on_connect(client, {}, {}, 1)
        except UnauthorizedMqttException:
            assert True
        else:
            assert False, "Exception not raised"

        client.client.on_connect(client, {}, {}, 0)
        assert connect_handler_called, "Handler not called"

    def test_on_subscribe(self, mocker):
        subscribe_handler_called = False

        def subscribe_handler(_client, mid, granted_qos):
            assert _client is not None
            assert mid == "someid"
            assert granted_qos == [0, 1, 2]
            nonlocal subscribe_handler_called
            subscribe_handler_called = True

        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=True)
        client = MeiliMqttClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
            subscribe_handler=subscribe_handler,
        )

        client.client.on_subscribe(client, {}, "someid", [0, 1, 2])
        assert subscribe_handler_called
        mocker.patch("paho.mqtt.client.Client.subscribe", return_value=(1, "someother"))
        try:
            client.subscribe("someother")
            client.client.on_subscribe(client, {}, "someother", [4])
        except UnauthorizedMqttException:
            assert True
        else:
            assert False, "Exception not raised"

    def test_subscribe_on_closed_connection(self):
        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")

        try:
            client.subscribe("topic/1231/132/12/132")
        except ConnectionError:
            pass
        else:
            assert False, "Connection not risen"

    def test_on_disconnect(self):
        disconnect_handler_called = False

        def disconnect_handler(_client, rc):
            assert _client is not None
            assert rc == 0
            nonlocal disconnect_handler_called
            disconnect_handler_called = True

        client = MeiliMqttClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
            disconnect_handler=disconnect_handler,
        )
        client.client.on_disconnect(client, {}, 0)
        assert disconnect_handler_called

    def test_on_message(self):
        message_handler_called = False

        def message_handler(_client, topic, raw_data, data):
            nonlocal message_handler_called
            message_handler_called = True
            assert topic == "sometopic"
            assert raw_data == b'{"message": "msg"}'
            assert data == {"message": "msg"}

        client = MeiliMqttClient(
            "client",
            "token",
            host="https://app.meilirobots.com",
            message_handler=message_handler,
        )
        message = MQTTMessage(
            topic="sometopic".encode("utf-8"),
            mid="sometopic",
        )
        message.payload = json.dumps({"message": "msg"}).encode("utf-8")
        client.client.on_message(client, {}, message)

        assert message_handler_called

    def test_disconnect(self, mocker):
        mocked = mocker.patch("paho.mqtt.client.Client.is_connected", return_value=True)
        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")
        client.disconnect()

        mocked.assert_called_once()

        mocked = mocker.patch(
            "paho.mqtt.client.Client.is_connected", return_value=False
        )
        try:
            client.disconnect()
        except ConnectionError:
            assert True
        else:
            assert False, "Exception not risen"

        mocked.assert_called_once()

    def test_wait_for_connection(self, mocker):
        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=False)

        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")
        try:
            client.wait_for_connection(timeout=1)
        except ConnectionError:
            assert True
        else:
            assert False, "No connection error risen"

        client.connection_state = 1
        try:
            client.wait_for_connection(timeout=0.1)
        except TimeoutError:
            assert True
        else:
            assert False, "TimeoutError not risen"

    def test_publish(self, mocker):
        publish_called = False

        def publish(topic, payload, qos):
            nonlocal publish_called
            publish_called = True
            assert topic == "/topic/123"
            assert payload == '{"data": "d1"}'
            assert qos == 2

        client = MeiliMqttClient("client", "token", host="https://app.meilirobots.com")
        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=False)
        mocker.patch("paho.mqtt.client.Client.publish", side_effect=publish)

        try:
            client.publish("/topic/123/", {"data": "d1"}, qos=2)
        except ConnectionError:
            assert True
        else:
            assert False, "Connection error not risen"

        assert not publish_called

        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=True)
        client.publish("/topic/123", {"data": "d1"}, qos=2)
        assert publish_called

    def test_publish_state(self, mocker):
        publish_called = False
        assertion_error_raised = False

        def publish(topic, payload, qos):
            nonlocal publish_called
            publish_called = True
            assert topic == "meili/v2/meili/vehicle_uuid/state"
            loaded = json.loads(payload)
            expected = {
                "agvPosition": {
                    "positionInitialized": True,
                    "theta": 20,
                    "x": 10,
                    "y": 10,
                    "mapId": "",
                },
                "driving": False,
                "headerId": 1,
                "manufacturer": "Meili",
                "operatingMode": "AUTOMATIC",
                "paused": False,
                "serialNumber": "vehicle_uuid",
                "version": VERSION,
                "orderId": "", 
                "orderUpdateId": 0,
            }
            del loaded["timestamp"]
            assert loaded == expected
            assert qos == 0

        client = MeiliMqttClient("client", "token")
        mocker.patch("paho.mqtt.client.Client.is_connected", return_value=True)
        mocker.patch("paho.mqtt.client.Client.publish", side_effect=publish)

        state_message = VDA5050StateMessage(
            manufacturer="Meili",
            serialNumber="vehicle_uuid",
            agvPosition=VDA5050VehiclePosition(
                x=10,
                y=10,
                theta=20,
                positionInitialized=True,
                mapId="",
            ),
        )

        client.publish_to_state_topic("vehicle_uuid", state_message)
        assert publish_called

    def test_auto_client_retrieval(self, mocker):
        def request_side_effect(url, headers, *a, **kw):
            assert headers["Authorization"] == "API-Key user_token"
            if (
                url
                == "https://app.meilirobots.com/api/setups/4b141de094a94e4a97d809c5522d7d6c/token/"
            ):
                data = {"token": "setup_token"}
            elif (
                url
                == "https://app.meilirobots.com/api/setups/4b141de094a94e4a97d809c5522d7d6c/"
            ):
                data = {
                    "uuid": "4b141de094a94e4a97d809c5522d7d6c",
                    "verbose_name": "Setup 1",
                    "pin": "HKGEG",
                    "created_at": "2022-07-22T10:40:21.224184+02:00",
                    "used": "2019-08-24T14:15:22Z",
                    "mqtt_id": "meili-agent-fff53e61-005c-4116-9c5c-cde6c501ee83",
                    "ros_logs_frequency": 0,
                    "vehicles": [
                        {
                            "uuid": "08b5fe9879584060b42907ee6f9ebadb",
                            "prefix": "string",
                            "topic_overrides": [
                                {
                                    "label": "pose",
                                    "topic": "string",
                                    "message_type": "string",
                                }
                            ],
                            "vehicle": {
                                "uuid": "49ced169d8f44808b0422cf5317d9e45",
                                "external_identifier": "Warehouse Left Wing Warrior",
                                "verbose_name": "Floating Flamingo",
                            },
                        }
                    ],
                }
            else:
                assert False, f"Unknown url called {url}"

            response = Response()
            response.status_code = 200
            response._content = json.dumps(data).encode()
            return response

        mocked: MagicMock = mocker.patch(
            "requests.get", side_effect=request_side_effect
        )

        client = MeiliMqttClient.with_auto_token(
            "4b141de094a94e4a97d809c5522d7d6c", "user_token"
        )

        assert mocked.call_count == 2

        assert client.client_id == "meili-agent-fff53e61-005c-4116-9c5c-cde6c501ee83"
