from unittest.mock import MagicMock

from meili_sdk.exceptions import WebsocketException
from meili_sdk.websockets.client import MeiliWebsocketClient
from meili_sdk.websockets.models import PathReroutingMessage
from meili_sdk.websockets.models.message import Message


class TestWebsocket:
    @staticmethod
    def __create_socket(**kwargs):
        return MeiliWebsocketClient(token="1234", **kwargs)

    def test_message_processor(self, mocker):
        mocked: MagicMock = mocker.patch(
            "meili_sdk.websockets.client.MeiliWebsocketClient.process_task_v2"
        )

        socket = self.__create_socket()

        socket.on_message(
            None,
            """{
            "type": "taskv2",
            "vehicle": "ABC123",
            "data": {
                "uuid": "1234",
                "number": "4321",
                "metric_waypoints":[[1,2],[3,2],[4,2]],
                "rotation_angles":[90, 80, 20],
                "speed_limits":["-1","-1","-1"],
                "subtask":{
                    "action": {
                        "action_type": "move_to_point",
                        "point": {
                            "uuid":12345,
                            "x": 1,
                            "y": 2,
                            "rotation": [128],
                            "metric": [0.32, 9.2]
                        }
                    }
                }
            }
        }""".encode(),
        )
        assert mocked.call_count == 1
        args = mocked.call_args_list
        assert args[0][0][1] == "ABC123"

    def test_message_processor_bad_data(self):
        socket = self.__create_socket()

        try:
            socket.on_message(None, "this is not a json".encode())
        except WebsocketException:
            assert True
        else:
            assert False, "Not a json message should raise websocket exception"

    def test_message_processor_missing_field(self):
        socket = self.__create_socket()

        try:
            socket.on_message(None, """{"valid":"json"}""".encode())
        except WebsocketException:
            assert True
        else:
            assert False, "Missing attribute type should raise websocket exception"

    def test_vehicle_addition(self):
        socket = self.__create_socket()

        socket.add_vehicle("1234")

        assert 1 == len(
            socket.vehicles
        ), "There should be only 1 vehicle in the websocket"

        try:
            socket.add_vehicle("1234")
        except ValueError:
            assert True
        else:
            assert False, "Exception not raised for duplicate vehicles"

    def test_vehicle_setter(self):
        socket = self.__create_socket()

        socket.vehicles = [
            "1234",
            "3312",
        ]

        assert 2 == len(socket.vehicles), "There should be 2 vehicles in the connection"

        try:
            socket.vehicles = [
                "1234",
                "1234",
            ]
        except ValueError:
            assert True
        else:
            assert False, "Value error not raised for duplicate vehicles"

    def test_remove_vehicles(self):
        socket = self.__create_socket()

        socket.vehicles = [
            "1234",
            "3312",
        ]

        socket.remove_vehicle("1234")

        assert 1 == len(socket.vehicles), "One vehicle should be removed"
        assert ["3312"] == socket.vehicles

    def test_error_handler_called(self):
        self.called = False

        def handler(conn, err):
            self.called = True
            assert conn == 1
            assert err == "error"

        socket = self.__create_socket(error_handler=handler)
        socket.on_error(1, "error")

        assert self.called, "Error handler was not called"

    def test_send(self, mocker):
        mocked: MagicMock = mocker.patch(
            "meili_sdk.websockets.client.MeiliWebsocketClient.send_raw"
        )

        socket = self.__create_socket(fake_opened_connection=True)
        socket._connection_is_open = True

        socket.send({"message": "hi"})

        mocked.assert_called_once()
        mocked.assert_called_once_with('{"message": "hi"}')

    def test_send_message(self, mocker):
        mocked: MagicMock = mocker.patch(
            "meili_sdk.websockets.client.MeiliWebsocketClient.send_raw"
        )
        socket = self.__create_socket(fake_opened_connection=True)
        socket._connection_is_open = True

        message = Message(event="connect", vehicles=["1234"])

        socket.send(message)

        mocked.assert_called_once_with(
            '{"event": "connect", "value": 1, "vehicles": ["1234"]}'
        )

    def test_send_connection_closed(self):
        socket = self.__create_socket()

        try:
            socket.send("message")
        except WebsocketException:
            assert True
        else:
            assert False, "Exception not risen"

    def test_docking_routine_request_processor(self):
        def docking_routine_request_handler(message, vehicle):
            assert vehicle == "vehicle"

        socket = self.__create_socket(
            docking_routine_request_handler=docking_routine_request_handler
        )

        message = {
            "data": {
                "uuid": "1234",
                "x": 1,
                "y": 2,
                "rotation": 3.0,
                "metric": {
                    "x": 1.2,
                    "y": 3.2,
                },
            }
        }

        socket.process_docking_routine_request(message, "vehicle")

    def test_docking_routine_finalize_processor(self):
        def docking_routine_finalize_handler(message, vehicle):
            assert vehicle == "vehicle"

        socket = self.__create_socket(
            docking_routine_finalize_handler=docking_routine_finalize_handler
        )

        message = {
            "data": {
                "uuid": "1234",
                "x": 1,
                "y": 2,
                "rotation": 3.0,
                "metric": {
                    "x": 1.2,
                    "y": 3.2,
                },
            }
        }
        socket.process_docking_routine_finalize(message, "vehicle")

    def test_task_processor(self):
        def task_v2_handler(task, vehicle):
            assert vehicle == "vehicle"
            # assert task_data is not None
            assert task.uuid == "1234"
            assert task.number == "4321"

        # assert task.subtask.action.point.uuid == "12345"
        # assert task.subtask.action.point.x == 1
        # assert task.subtask.action.point.y == 2
        # assert task.subtask.action.point.rotation == 128
        # assert 0.32 == task.data.subtask.action.point.metric[0]
        # assert 9.2 == task.data.subtask.action.point.metric[1]

        socket = self.__create_socket(task_v2_handler=task_v2_handler)

        message = {
            "data": {
                "uuid": "1234",
                "number": "4321",
                "metric_waypoints": [[1, 2], [3, 2], [4, 2]],
                "rotation_angles": [90, 80, 20],
                "speed_limits": ["-1", "-1", "-1"],
                "subtask": {
                    "uuid": "4321",
                    "rotation_angles": [90, 80, 20],
                    "metric_waypoints": [[1, 2], [3, 2], [4, 2]],
                    "speed_limits": ["-1", "-1"],
                    "action": {
                        "action_type": "move_to_point",
                        "values": {},
                        "point": {
                            "uuid": 12345,
                            "x": 1,
                            "y": 2,
                            "rotation": [128],
                            "metric": [0.32, 9.2],
                        },
                    },
                },
            }
        }

        socket.process_task_v2(message, "vehicle")

    def test_task_cancellation_processor(self):
        def task_cancellation_handler(task, vehicle):
            assert vehicle == "vehicle"
            assert task.goal_id is not None
            assert task.goal_id == "goal"

            assert task.task == "1234"
            assert task.subtask == "1234"

        socket = self.__create_socket(
            task_cancellation_handler=task_cancellation_handler
        )

        message = {
            "data": {
                "task": "1234",
                "subtask": "1234",
                "goal_id": "goal",
                "type": "cancelOrder",
            }
        }

        socket.process_task_cancellation(message, "vehicle")

    def test_task_batch_handler(self):
        def task_v2_handler(task, vehicle):
            assert vehicle == "vehicle"
            # assert task_data is not None
            assert task.uuid == "1234"
            assert task.number == "1234"
            # assert task.subtask.action.point.uuid == "12345"
            # assert task.subtask.action.point.x == 1
            # assert task.subtask.action.point.y == 2
            # assert task.subtask.action.point.rotation == 128
            # assert 0.32 == task.subtask.action.point.metric[0]
            # assert 9.2 == task.subtask.action.point.metric[1]

        socket = self.__create_socket(task_v2_handler=task_v2_handler)

        message = {
            "data": {
                "uuid": "1234",
                "number": "1234",
                "metric_waypoints": [[1, 2], [3, 2], [4, 2]],
                "rotation_angles": [90, 80, 20],
                "speed_limits": ["-1", "-1", "-1"],
                "subtask": {
                    "uuid": "4321",
                    "metric_waypoints": [[1, 2], [3, 2], [4, 2]],
                    "rotation_angles": [90, 80, 20],
                    "speed_limits": ["-1", "-1"],
                    "action": {
                        "action_type": "move_to_point",
                        "values": {},
                        "point": {
                            "uuid": 12345,
                            "x": 1,
                            "y": 2,
                            "rotation": [128],
                            "metric": [0.32, 9.2],
                        },
                    },
                },
            }
        }
        socket.process_task_v2(message, "vehicle")

    def test_process_path_rerouting(self):
        def path_rerouting_handler(message, data, vehicle):
            assert vehicle == "vehicle"
            assert message.path == [[1, 2], [2, 3]]
            assert message.rotation_angles == [360, 270]

        socket = self.__create_socket(path_rerouting_handler=path_rerouting_handler)

        message = {
            "path": [[1, 2], [2, 3]],
            "rotation_angles": [360, 270],
        }

        socket.process_path_rerouting(message, "vehicle")

    def test_process_collision_clearance(self):
        def collision_clearance_handler(clearence_message, message, vehicle):
            assert vehicle == "vehicle"
            assert clearence_message.message_type == "slow_down"
            task = clearence_message.task_data
            assert task.uuid == "1234"
            assert task.number == "1234"
            location = task.location
            locations = task.locations
            assert location.uuid == "4321"
            assert location.x == 4
            assert location.y == 2
            assert location.rotation == 0
            assert 1.2 == location.metric["x"]
            assert 3.2 == location.metric["y"]
            assert locations[1].uuid == "4321"
            assert locations[0].uuid == "3214"

        socket = self.__create_socket(
            collision_clearance_handler=collision_clearance_handler
        )

        message = {
            "data": {
                "message_type": "slow_down",
                "task_data": {
                    "uuid": "1234",
                    "number": "1234",
                    "metric_waypoints": [[1, 2], [3, 2], [4, 2]],
                    "location": {
                        "uuid": "4321",
                        "x": 4,
                        "y": 2,
                        "rotation": 0,
                        "metric": {
                            "x": 1.2,
                            "y": 3.2,
                        },
                    },
                    "locations": [
                        {
                            "uuid": "3214",
                            "x": 4,
                            "y": 2,
                            "rotation": 0,
                            "metric": {
                                "x": 1.2,
                                "y": 3.2,
                            },
                        },
                        {
                            "uuid": "4321",
                            "x": 4,
                            "y": 2,
                            "rotation": 0,
                            "metric": {
                                "x": 1.2,
                                "y": 3.2,
                            },
                        },
                    ],
                },
            },
        }

        socket.process_collision_clearance(message, "vehicle")

    def test_process_collision_clearance_single_message(self):
        def collision_clearance_handler(clearence_message, message, vehicle):
            assert vehicle == "vehicle"
            assert clearence_message.message_type == "slow_down"

        socket = self.__create_socket(
            collision_clearance_handler=collision_clearance_handler
        )

        message = {"data": {"message_type": "slow_down"}}

        socket.process_collision_clearance(message, "vehicle")

    def test_process_initial_position_message(self):
        def vehicle_initial_position_handler(initial_position, message, vehicle):
            print(message)
            assert vehicle == "vehicle"
            assert initial_position == [1, 2, 3]

        socket = self.__create_socket(
            vehicle_initial_position_handler=vehicle_initial_position_handler
        )

        message = {"message_type": "Initial_position", "data": [1, 2, 3]}

        socket.process_vehicle_initial_position_handler(message, "vehicle")

    def test_process_update_map_id(self):
        def update_map_id_handler(map_id, vehicle):
            print(message)
            assert vehicle == "vehicle"
            assert map_id == "some_map_id"

        socket = self.__create_socket(update_map_id_handler=update_map_id_handler)

        message = {"message_type": "map_id", "data": "some_map_id"}

        socket.process_update_map_id(message, "vehicle")
