from unittest.mock import MagicMock

from meili_sdk.clients.apitoken_client import APITokenClient
from meili_sdk.resources.triggers import TriggerResource
from tests.helpers import build_mocked_response

example = {
    "uuid": "ffbee424bcd24e98847a257f8bb81ab3",
    "verbose_name": "Production line confirmation trigger",
    "token": "4c68a5d45c3eef408ac5a297c4682ad7429f3f17",
    "url": "app.meilirobots.com/workflows/triggers/ae04bde46a085cf643543859c92cd2f2e9fd7cfbe0b4eda3aaf348a03139e11cf27809624567360f/",
    "use_http": True,
    "use_mqtt": True,
    "point": "36ee0ac1e01045758b52cef09451e908",
    "mqtt_id": "meili-trigger-c6650d45-5972-4bfd-9f22-5cb6cfd5cd4f",
    "use_token_authentication": False,
    "use_ip_authentication": False,
    "ip_whitelist": ["127.0.0.1"],
    "action": "location_confirm",
}


class TestTriggerResource:
    def test_trigger_list(self, mocker):
        example_response = [
            example,
        ]
        mocked: MagicMock = mocker.patch(
            "requests.get", return_value=build_mocked_response(example_response)
        )

        resource = TriggerResource(APITokenClient("a"))

        status, triggers, raw_data, next_page = resource.get_team_triggers("test")

        assert mocked.call_count == 1
        assert status == 200, f"Invalid status: {status}"
        assert next_page is None
        assert raw_data is not None
        assert isinstance(triggers, list)
        assert len(triggers) == 1

        trigger = triggers[0]

        assert trigger.uuid == example["uuid"]
