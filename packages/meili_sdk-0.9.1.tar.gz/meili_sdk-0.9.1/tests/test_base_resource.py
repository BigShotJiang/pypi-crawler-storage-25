from meili_sdk.exceptions import APIError, PermissionDenied
from meili_sdk.resources.base import BaseResource
from tests.helpers import build_mocked_response


class TestBaseResource:
    def test_url_build(self):
        url = BaseResource.build_url(
            "https://app.meilirobots.com",
            "/api/teams/",
            page=4,
            query_params={"organization": 123},
        )

        assert url == "https://app.meilirobots.com/api/teams/?organization=123&page=4"

    def test_url_build_only_page(self):
        url = BaseResource.build_url(
            "https://app.meilirobots.com", "/api/teams/", page=4
        )

        assert url == "https://app.meilirobots.com/api/teams/?page=4"

    def test_url_non_http(self):
        try:
            BaseResource.build_url(
                "meilirobots.com", "/non-api", query_params={"q": "search"}
            )
        except ValueError:
            assert True
        else:
            assert False, "Should raise value error"

    def test_get_next_page(self):
        next_page = BaseResource.get_next_page(
            "https://meilirobots.com/api/teams/?page=243"
        )
        assert next_page == 243

    def test_no_next_page(self):
        assert BaseResource.get_next_page(None) is None

    def test_bad_type(self):
        assert (
            BaseResource.get_next_page(
                "https://meilirobots.com/api/teams/?page=onehundredandtwo"
            )
            is None
        )

    def test_pagination_check(self):
        paginated_response = {
            "count": 123,
            "next": None,
            "previous": None,
            "results": [{}],
        }
        not_paginated_response = {
            "counter": 123,
            "next": None,
            "previous": None,
            "results": [{}],
        }

        assert BaseResource.is_response_paginated(paginated_response)
        assert not BaseResource.is_response_paginated(not_paginated_response)

    def test_no_query_for_next_page(self):
        url = "https://meilirobots.com/api/teams"
        next_page = BaseResource.get_next_page(url)
        assert next_page is None

    def test_response_handler_permission_denied_raised(self):
        response = build_mocked_response("", 401)
        resource = BaseResource(None)

        try:
            resource.handle_response(response, "https://app.meilirobots.com/api/teams/")
        except PermissionDenied:
            assert True
        else:
            assert False, "PermissionDenied not risen"

    def test_non_200_response(self):
        response = build_mocked_response("", 302)
        resource = BaseResource(None)

        try:
            resource.handle_response(response, "https://app.meilirobots.com/api/teams/")
        except APIError:
            assert True
        else:
            assert False, "APIError not risen"

    def test_204_response(self):
        response = build_mocked_response("", 204)
        resource = BaseResource(None)

        code, obj, data, next_page = resource.handle_response(
            response, "https://app.meilirobots.com/api/teams/"
        )

        assert code == 204
        assert obj is None
        assert data is None
        assert next_page is None

    def test_no_expected_object(self):
        data = """{"hello": "world"}"""
        response = build_mocked_response(data, 200)
        resource = BaseResource(None)

        code, obj, content, next_page = resource.handle_response(
            response, "https://app.meilirobots.com/api/teams/"
        )

        assert 200 == code
        assert {"hello": "world"} == obj
        assert data.encode() == content
        assert next_page is None
