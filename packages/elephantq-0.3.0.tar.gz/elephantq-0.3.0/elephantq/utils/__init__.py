# ElephantQ Utilities
