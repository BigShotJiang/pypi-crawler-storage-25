"""
Command-line entry: initialize ROS 2, start the executor thread, run FastMCP.

Typical usage (after sourcing ROS and your workspace):

.. code-block:: bash

    ros2-image-mcp --default-topic /camera/image_raw

HTTP (e.g. LangGraph with ``url`` + ``transport: http``):

.. code-block:: bash

    ros2-image-mcp --default-topic /camera/image_raw --transport http --port 8012
"""

from __future__ import annotations

import argparse
import os
import signal
import threading
import time

import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node

from ros2_image_mcp.server import build_mcp_server
from ros2_image_mcp.subscriber_manager import ImageTopicManager


def _default_topic_from_env() -> str:
    return (
        os.environ.get("ROS2_IMAGE_MCP_DEFAULT_TOPIC", "").strip()
        or os.environ.get("ROS2_IMAGE_MCP_TOPIC", "").strip()
    )


def main() -> None:
    """Parse CLI args, spin ROS, then run the MCP server (stdio transport by default)."""
    parser = argparse.ArgumentParser(
        description="MCP server exposing ROS 2 sensor_msgs/Image topics (FastMCP + rclpy)."
    )
    parser.add_argument(
        "-t",
        "--default-topic",
        "--topic",
        dest="default_topic",
        default=_default_topic_from_env(),
        metavar="TOPIC",
        help=(
            "Default ROS image topic when MCP tools omit topic= (optional). "
            "Alias: --topic (same meaning). "
            "If unset, every tool call must supply topic=. "
            "Env: ROS2_IMAGE_MCP_DEFAULT_TOPIC or ROS2_IMAGE_MCP_TOPIC (legacy)."
        ),
    )
    parser.add_argument(
        "--buffer-size",
        type=int,
        default=int(os.environ.get("ROS2_IMAGE_MCP_BUFFER_SIZE", "15")),
        help="Ring buffer depth per topic (>= num_frames you plan to request). Env: ROS2_IMAGE_MCP_BUFFER_SIZE",
    )
    parser.add_argument(
        "--max-frames",
        type=int,
        default=int(os.environ.get("ROS2_IMAGE_MCP_MAX_FRAMES", "15")),
        help="Maximum num_frames allowed in get_recent_ros_image_frames. Env: ROS2_IMAGE_MCP_MAX_FRAMES",
    )
    parser.add_argument(
        "--node-name",
        default=os.environ.get("ROS2_IMAGE_MCP_NODE_NAME", "ros2_image_mcp"),
        help="ROS node name. Env: ROS2_IMAGE_MCP_NODE_NAME",
    )
    parser.add_argument(
        "--transport",
        choices=("stdio", "http"),
        default=os.environ.get("ROS2_IMAGE_MCP_TRANSPORT", "stdio"),
        help="MCP transport: stdio (default) or http for LangGraph URL-based clients. Env: ROS2_IMAGE_MCP_TRANSPORT",
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("ROS2_IMAGE_MCP_HOST", "127.0.0.1"),
        help="Bind address when using --transport http. Env: ROS2_IMAGE_MCP_HOST",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("ROS2_IMAGE_MCP_PORT", "8012")),
        help="TCP port when using --transport http (use a free port; FastMCP default path is /mcp). Env: ROS2_IMAGE_MCP_PORT",
    )
    parser.add_argument(
        "--path",
        default=os.environ.get("ROS2_IMAGE_MCP_PATH", "/mcp"),
        help="HTTP path for the MCP endpoint. Env: ROS2_IMAGE_MCP_PATH",
    )
    args, ros_argv = parser.parse_known_args()

    default_topic = args.default_topic.strip()
    # Ring buffer must hold at least as many frames as the recent-frames tool may request.
    buffer_size = max(args.buffer_size, args.max_frames, 1)

    # Remaining argv is passed to rclpy (e.g. ROS 2-specific CLI flags).
    rclpy.init(args=ros_argv if ros_argv else None)
    node: Node | None = None
    executor: SingleThreadedExecutor | None = None
    spin_thread: threading.Thread | None = None
    stop_event = threading.Event()

    try:
        node = Node(args.node_name)
        manager = ImageTopicManager(node, buffer_size=buffer_size)
        if default_topic:
            manager.ensure_subscription(default_topic)

        executor = SingleThreadedExecutor()
        executor.add_node(node)

        def _spin() -> None:
            while not stop_event.is_set() and rclpy.ok():
                executor.spin_once(timeout_sec=0.1)

        # Daemon: if main exits uncleanly the process can still terminate; MCP blocks main, not this thread.
        spin_thread = threading.Thread(target=_spin, name="rclpy-spin", daemon=True)
        spin_thread.start()

        # Give the first subscription a moment to receive frames (stdio clients connect right after).
        time.sleep(0.05)

        mcp = build_mcp_server(
            manager,
            default_topic=default_topic,
            max_frames_per_tool_call=max(1, args.max_frames),
        )

        def _shutdown(*_: object) -> None:
            stop_event.set()

        signal.signal(signal.SIGINT, _shutdown)
        signal.signal(signal.SIGTERM, _shutdown)

        if args.transport == "http":
            mcp.run(
                transport="http",
                host=args.host,
                port=args.port,
                path=args.path,
            )
        else:
            mcp.run()
    finally:
        stop_event.set()
        if spin_thread is not None:
            spin_thread.join(timeout=2.0)
        # remove_node before destroy_node — executor must stop using the node first.
        if executor is not None and node is not None:
            executor.remove_node(node)
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
