"""
ROS 2 image topics exposed to MCP clients via FastMCP.

This package is intended to run inside an environment where ROS 2 Python
bindings are available (``rclpy``, ``sensor_msgs``), typically after
``source /opt/ros/<distro>/setup.bash`` and any workspace overlays.

Public entry point for programmatic use: :func:`build_mcp_server`.
"""

from importlib.metadata import PackageNotFoundError, version

# Importing server is lightweight (rclpy is not loaded until subscriber_manager is used).
from ros2_image_mcp.server import build_mcp_server

try:
    __version__ = version("ros2-image-mcp")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = ["build_mcp_server", "__version__"]
