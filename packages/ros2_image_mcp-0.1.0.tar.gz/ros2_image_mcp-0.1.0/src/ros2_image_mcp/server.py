"""
FastMCP server exposing ROS 2 image topics as MCP tools for VLM clients.

Tool decorators use ``output_schema=None`` so the server does not advertise a JSON
output schema for heterogeneous ``list`` returns (text + :class:`~fastmcp.utilities.types.Image`).
That matches common LangGraph / LangChain MCP setups, which often consume **content
blocks** only and can mis-handle auto-generated schemas for multimodal tool results.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastmcp import FastMCP
from fastmcp.utilities.types import Image as McpImage

if TYPE_CHECKING:
    from ros2_image_mcp.subscriber_manager import ImageTopicManager


def build_mcp_server(
    manager: ImageTopicManager,
    *,
    default_topic: str,
    max_frames_per_tool_call: int = 15,
) -> FastMCP:
    """
    Build a :class:`fastmcp.FastMCP` instance with image tools.

    Parameters
    ----------
    manager
        Shared :class:`ImageTopicManager` wired to a running ROS node and executor.
    default_topic
        Used when a tool omits ``topic`` (full graph name, e.g. ``/camera/image_raw``).
        May be empty: then every tool call must pass ``topic``.
    max_frames_per_tool_call
        Upper bound for ``num_frames`` in the recent-frames tool.

    Returns
    -------
    FastMCP
        Server ready for ``run()``; tools close over ``manager`` and ``default_topic``.
    """
    if max_frames_per_tool_call < 1:
        raise ValueError("max_frames_per_tool_call must be >= 1")

    mcp = FastMCP(
        name="ROS 2 Image MCP",
        instructions=(
            "Tools expose live camera (or image) data from ROS 2 sensor_msgs/Image topics. "
            "Pass the full topic name when it differs from the default (robots vary). "
            "Use get_latest_ros_image for a single frame; use get_recent_ros_image_frames "
            "for a short temporal sequence (e.g. motion)."
        ),
    )

    def _resolve_topic(topic: str | None) -> str:
        t = (topic or "").strip()
        if t:
            return t
        return default_topic.strip() if default_topic else ""

    # output_schema=None: multimodal list breaks JSON-schema tooling; LangChain/LangGraph expect raw content blocks.
    @mcp.tool(output_schema=None)
    def get_latest_ros_image(topic: str | None = None) -> list:
        """
        Return the most recent image on a ROS sensor_msgs/Image topic.

        Parameters
        ----------
        topic
            Full topic name (e.g. /zed/zed_node/rgb/image_rect_color). If omitted,
            the server default topic is used.

        Returns
        -------
        Text summary plus one MCP image (JPEG/PNG) for the vision model.
        """
        t = _resolve_topic(topic)
        if not t:
            return [
                "No topic: set the server default with --default-topic (or env ROS2_IMAGE_MCP_DEFAULT_TOPIC) "
                "or pass topic= to this tool."
            ]
        manager.ensure_subscription(t)
        frame = manager.get_latest(t)
        if frame is None:
            return [
                f"No image received yet on topic {t!r}. "
                "Check that the publisher is running and the topic name is correct."
            ]
        header = (
            f"topic={t} stamp={frame.stamp_sec}.{frame.stamp_nsec:09d} "
            f"ros_encoding={frame.encoding_ros!r}"
        )
        return [
            header,
            McpImage(data=frame.data, format=frame.mime_subtype),
        ]

    @mcp.tool(output_schema=None)
    def get_recent_ros_image_frames(
        topic: str | None = None,
        num_frames: int = 10,
    ) -> list:
        """
        Return several recent frames in time order (oldest first), like a short clip.

        Useful for motion, flashing indicators, or brief temporal context.

        Parameters
        ----------
        topic
            Full topic name; falls back to the server default if omitted.
        num_frames
            How many frames to return (1 up to the server maximum, default 10).

        Returns
        -------
        A short text header followed by one MCP image per frame.
        """
        t = _resolve_topic(topic)
        if not t:
            return [
                "No topic: set the server default with --default-topic (or env ROS2_IMAGE_MCP_DEFAULT_TOPIC) "
                "or pass topic= to this tool."
            ]
        # Clamp to [1, max_frames_per_tool_call]: models may send floats or huge integers.
        n = max(1, min(int(num_frames), max_frames_per_tool_call))
        manager.ensure_subscription(t)
        frames = manager.get_recent(t, n)
        if not frames:
            return [
                f"No frames buffered yet on topic {t!r}. Wait for the camera stream."
            ]
        header = (
            f"topic={t} frames={len(frames)} order=oldest_first "
            f"first_stamp={frames[0].stamp_sec}.{frames[0].stamp_nsec:09d} "
            f"last_stamp={frames[-1].stamp_sec}.{frames[-1].stamp_nsec:09d}"
        )
        # List of Text + Image blocks is what FastMCP turns into MCP multimodal content.
        out: list = [header]
        for fr in frames:
            out.append(McpImage(data=fr.data, format=fr.mime_subtype))
        return out

    return mcp
