"""
Convert ``sensor_msgs/msg/Image`` payloads into compressed RGB bitmaps for MCP.

VLMs and browsers consume JPEG or PNG. Many robots already publish ``jpeg`` or
``png`` compressed images; raw encodings are re-encoded to JPEG for a stable
wire format.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
from sensor_msgs.msg import Image as RosImage


class ImageConversionError(ValueError):
    """Raised when a ROS image message cannot be converted."""


@dataclass(frozen=True, slots=True)
class EncodedFrame:
    """JPEG or PNG bytes plus MIME subtype for :class:`fastmcp.utilities.types.Image`."""

    mime_subtype: str  # "jpeg" or "png"
    data: bytes


def ros_image_to_encoded_frame(msg: RosImage) -> EncodedFrame:
    """
    Normalize a ROS Image message to JPEG or PNG bytes.

    Pass-through when ``encoding`` is already ``jpeg``/``jpg`` or ``png``.
    Raw encodings supported: ``rgb8``, ``bgr8``, ``rgba8``, ``bgra8``, ``mono8``.

    Parameters
    ----------
    msg
        Incoming ``sensor_msgs/Image`` from a subscription callback.

    Returns
    -------
    EncodedFrame
        Compressed image suitable for ``Image(data=..., format=mime_subtype)``.

    Raises
    ------
    ImageConversionError
        If the encoding is unknown or the buffer size does not match dimensions.
    """
    enc = msg.encoding.lower()
    raw = np.frombuffer(msg.data, dtype=np.uint8)

    # Already compressed: forward bytes unchanged (avoids decode/re-encode loss).
    if enc in ("jpeg", "jpg"):
        return EncodedFrame(mime_subtype="jpeg", data=bytes(msg.data))
    if enc == "png":
        return EncodedFrame(mime_subtype="png", data=bytes(msg.data))

    h, w = int(msg.height), int(msg.width)
    # sensor_msgs/Image.step = bytes per row; may exceed width * channels if the driver pads rows.
    step = int(msg.step) if msg.step else w * _bytes_per_pixel(enc)

    if enc == "mono8":
        expected = h * step
        if raw.size < expected:
            raise ImageConversionError(
                f"mono8 buffer too small: got {raw.size}, need at least {expected}"
            )
        # If step > w, each image row is padded; take only the first w pixels per row.
        gray = raw[:expected].reshape((h, w)) if step == w else raw[: h * step].reshape((h, step))[:, :w]
        return _bgr_to_jpeg(cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR))

    if enc == "rgb8":
        expected = h * step
        if raw.size < expected:
            raise ImageConversionError(
                f"rgb8 buffer too small: got {raw.size}, need at least {expected}"
            )
        # OpenCV expects BGR for imencode; ROS often uses rgb8.
        rgb = raw[: h * step].reshape((h, step))[:, : w * 3].reshape((h, w, 3))
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        return _bgr_to_jpeg(bgr)

    if enc == "bgr8":
        expected = h * step
        if raw.size < expected:
            raise ImageConversionError(
                f"bgr8 buffer too small: got {raw.size}, need at least {expected}"
            )
        bgr = raw[: h * step].reshape((h, step))[:, : w * 3].reshape((h, w, 3))
        return _bgr_to_jpeg(bgr)

    if enc == "rgba8":
        expected = h * step
        if raw.size < expected:
            raise ImageConversionError(
                f"rgba8 buffer too small: got {raw.size}, need at least {expected}"
            )
        rgba = raw[: h * step].reshape((h, step))[:, : w * 4].reshape((h, w, 4))
        bgr = cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGR)
        return _bgr_to_jpeg(bgr)

    if enc == "bgra8":
        expected = h * step
        if raw.size < expected:
            raise ImageConversionError(
                f"bgra8 buffer too small: got {raw.size}, need at least {expected}"
            )
        bgra = raw[: h * step].reshape((h, step))[:, : w * 4].reshape((h, w, 4))
        bgr = cv2.cvtColor(bgra, cv2.COLOR_BGRA2BGR)
        return _bgr_to_jpeg(bgr)

    raise ImageConversionError(
        f"Unsupported image encoding {msg.encoding!r}. "
        "Supported: jpeg, jpg, png, rgb8, bgr8, rgba8, bgra8, mono8."
    )


def _bytes_per_pixel(enc: str) -> int:
    return {
        "mono8": 1,
        "rgb8": 3,
        "bgr8": 3,
        "rgba8": 4,
        "bgra8": 4,
    }.get(enc, 0)


def _bgr_to_jpeg(bgr: np.ndarray, quality: int = 85) -> EncodedFrame:
    # cv2.imencode returns a 1-row numpy buffer; .tobytes() matches ROS uint8[] layout.
    ok, buf = cv2.imencode(".jpg", bgr, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        raise ImageConversionError("OpenCV failed to encode frame as JPEG")
    return EncodedFrame(mime_subtype="jpeg", data=bytes(buf.tobytes()))
