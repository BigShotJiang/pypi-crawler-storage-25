"""
ROS 2 subscriptions and per-topic ring buffers for image frames.

Runs alongside a dedicated ``rclpy`` executor thread so MCP tool handlers stay
responsive while callbacks fill the buffers.
"""

from __future__ import annotations

import threading
from collections import deque
from dataclasses import dataclass
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image as RosImage

from ros2_image_mcp.image_conversion import ImageConversionError, ros_image_to_encoded_frame


@dataclass(frozen=True, slots=True)
class StoredFrame:
    """
    One time-stamped frame already converted to MCP-friendly JPEG/PNG bytes.

    Attributes
    ----------
    stamp_sec, stamp_nsec
        ROS header stamp (sensor time), for ordering and logging.
    encoding_ros
        Original ``msg.encoding`` string (e.g. ``bgr8``, ``jpeg``).
    mime_subtype
        ``jpeg`` or ``png`` for :class:`fastmcp.utilities.types.Image`.
    data
        Compressed image bytes.
    """

    stamp_sec: int
    stamp_nsec: int
    encoding_ros: str
    mime_subtype: str
    data: bytes


class ImageTopicManager:
    """
    Lazily subscribes to ``sensor_msgs/Image`` topics and keeps a ring buffer per topic.

    Thread-safe: callbacks and MCP tools may run on different threads.

    Parameters
    ----------
    node
        ROS node used to create subscriptions.
    buffer_size
        Maximum frames retained per topic (oldest dropped). Should be at least
        the maximum ``num_frames`` your MCP tools will request.
    """

    def __init__(self, node: Node, *, buffer_size: int = 15) -> None:
        if buffer_size < 1:
            raise ValueError("buffer_size must be >= 1")
        self._node = node
        self._buffer_size = buffer_size
        # Callbacks run on the ROS executor thread; MCP tools run on the FastMCP thread — lock bridges both.
        self._lock = threading.Lock()
        self._buffers: dict[str, deque[StoredFrame]] = {}
        self._subs: dict[str, object] = {}

    def ensure_subscription(self, topic: str) -> None:
        """
        Create a subscription and buffer for ``topic`` if not already present.

        Idempotent; safe to call for every tool invocation.
        """
        with self._lock:
            if topic in self._subs:
                return
            buf: deque[StoredFrame] = deque(maxlen=self._buffer_size)

            # Default-arg capture binds this topic's buffer so one callback factory works per subscription.
            def _cb(msg: RosImage, t: str = topic, b: deque[StoredFrame] = buf) -> None:
                self._image_callback(t, b, msg)

            # sensor_data QoS matches typical camera drivers (best-effort, small history).
            sub = self._node.create_subscription(
                RosImage,
                topic,
                _cb,
                qos_profile_sensor_data,
            )
            self._buffers[topic] = buf
            self._subs[topic] = sub
            self._node.get_logger().info(
                f"Subscribed to image topic {topic!r} (buffer={self._buffer_size})"
            )

    def get_latest(self, topic: str) -> StoredFrame | None:
        """Return the newest frame for ``topic``, or ``None`` if no data yet."""
        self.ensure_subscription(topic)
        with self._lock:
            buf = self._buffers.get(topic)
            if not buf:
                return None
            return buf[-1]  # deque is chronological; newest is at the right

    def get_recent(self, topic: str, num_frames: int) -> list[StoredFrame]:
        """
        Return up to ``num_frames`` frames in chronological order (oldest first).

        Fewer frames are returned if the buffer is not yet full or the topic is slow.
        """
        self.ensure_subscription(topic)
        with self._lock:
            buf = self._buffers.get(topic)
            if not buf:
                return []
            n = min(num_frames, len(buf))
            # Last n entries = most recent window; list order is already oldest → newest.
            return list(buf)[-n:]

    def _image_callback(self, topic: str, buf: deque[StoredFrame], msg: RosImage) -> None:
        try:
            enc = ros_image_to_encoded_frame(msg)
        except ImageConversionError as exc:
            self._node.get_logger().warning(
                f"Dropped frame on {topic!r}: {exc} (encoding={msg.encoding})"
            )
            return

        stamp = msg.header.stamp
        # Conversion runs in the callback (executor thread) so tool handlers only copy bytes.
        frame = StoredFrame(
            stamp_sec=int(stamp.sec),
            stamp_nsec=int(stamp.nanosec),
            encoding_ros=msg.encoding,
            mime_subtype=enc.mime_subtype,
            data=enc.data,
        )
        with self._lock:
            buf.append(frame)  # maxlen deque drops oldest automatically
