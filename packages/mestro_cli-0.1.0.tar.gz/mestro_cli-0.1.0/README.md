# mestro-cli

CLI para gerenciamento da plataforma de automação **BotCity Maestro** diretamente pelo terminal.

## Instalação

```bash
pip install mestro-cli
```

Ou a partir do código-fonte:

```bash
pip install -e .
```

## Autenticação

A CLI suporta dois modos de autenticação:

**Sessão persistente (recomendado):** faça login uma vez e as credenciais ficam salvas por 8 horas.

```bash
mestro-cli login --server https://maestro.botcity.dev --login <uuid> --key <api-key>
```

**Por comando:** passe as credenciais diretamente em cada chamada.

```bash
mestro-cli --server https://maestro.botcity.dev --login <uuid> --key <api-key> <comando>
```

## Comandos

### Sessão

| Comando | Descrição |
|---|---|
| `login` | Salva credenciais para uso em comandos futuros |
| `logout` | Remove a sessão salva |
| `session-status` | Exibe informações da sessão ativa |

```bash
# Salvar sessão com duração personalizada (em minutos)
mestro-cli login --server https://maestro.botcity.dev --login user@empresa.com --key SUA_KEY --ttl-minutes 240

# Verificar sessão
mestro-cli session-status

# Encerrar sessão
mestro-cli logout
```

### Bot

```bash
# Empacotar arquivos do bot em ZIP (exclui .venv, __pycache__, .git, etc.)
mestro-cli package-bot --source ./meu-bot --output bot.zip

# Fazer upload do bot para o Maestro
mestro-cli bot-upload --botId 42 --version 1.0.0 --file bot.zip
```

### Tarefas

```bash
# Criar uma nova tarefa
mestro-cli task-create --activity_label "ProcessarPlanilha" --priority 5

# Deletar uma tarefa
mestro-cli task-delete --task_id 123

# Duplicar uma tarefa
mestro-cli task-duplicate --task_id 123
```

## Fluxo Típico de Deploy

```bash
# 1. Autenticar
mestro-cli login --server https://maestro.botcity.dev --login user@empresa.com --key SUA_KEY

# 2. Empacotar o bot
mestro-cli package-bot --source ./meu-bot --output bot.zip

# 3. Fazer upload
mestro-cli bot-upload --botId 42 --version 1.0.0 --file bot.zip

# 4. Disparar execução
mestro-cli task-create --activity_label "NomeDaAtividade"
```

## Referência de Opções

### `login`
| Opção | Obrigatório | Padrão | Descrição |
|---|---|---|---|
| `--server` | Sim | — | URL do servidor Maestro |
| `--login` | Sim | — | Workspace Login |
| `--key` | Sim | — | Workspace Key |
| `--ttl-minutes` | Não | `480` | Duração da sessão em minutos |

### `bot-upload`
| Opção | Obrigatório | Descrição |
|---|---|---|
| `--botId` | Sim | ID único do bot no Maestro |
| `--version` | Sim | Versão da automação |
| `--file` | Sim | Caminho para o arquivo ZIP |

### `package-bot`
| Opção | Obrigatório | Padrão | Descrição |
|---|---|---|---|
| `--source` | Não | `.` | Diretório de origem |
| `--output` | Sim | — | Nome do arquivo ZIP de saída |

### `task-create`
| Opção | Obrigatório | Padrão | Descrição |
|---|---|---|---|
| `--activity_label` | Sim | — | Label da atividade no Maestro |
| `--priority` | Não | `0` | Prioridade da tarefa |
| `--test` | Não | `False` | Execução em modo teste |
