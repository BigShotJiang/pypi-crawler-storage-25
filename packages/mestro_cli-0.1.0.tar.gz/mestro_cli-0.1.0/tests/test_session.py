import json
from datetime import datetime, timezone, timedelta

import pytest
import click

import maestro_cli.session as session_module
from maestro_cli.session import save_session, load_session, clear_session, get_credentials


@pytest.fixture(autouse=True)
def patch_session_paths(tmp_path, monkeypatch):
    session_dir = tmp_path / ".mestro-cli"
    session_file = session_dir / "session.json"
    monkeypatch.setattr(session_module, "SESSION_DIR", session_dir)
    monkeypatch.setattr(session_module, "SESSION_FILE", session_file)


def test_save_session_creates_file_with_correct_data():
    data = save_session("https://server", "user", "key123", ttl_minutes=60)

    assert session_module.SESSION_FILE.exists()
    assert data["server"] == "https://server"
    assert data["login"] == "user"
    assert data["key"] == "key123"
    assert "expires_at" in data


def test_load_session_returns_valid_session():
    save_session("https://server", "user", "key123", ttl_minutes=60)

    loaded = load_session()

    assert loaded is not None
    assert loaded["server"] == "https://server"
    assert loaded["login"] == "user"


def test_load_session_returns_none_when_expired():
    session_module.SESSION_DIR.mkdir(parents=True, exist_ok=True)
    past = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
    session_module.SESSION_FILE.write_text(
        json.dumps({"server": "s", "login": "l", "key": "k", "expires_at": past}),
        encoding="utf-8",
    )

    assert load_session() is None


def test_load_session_deletes_file_when_expired():
    session_module.SESSION_DIR.mkdir(parents=True, exist_ok=True)
    past = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
    session_module.SESSION_FILE.write_text(
        json.dumps({"server": "s", "login": "l", "key": "k", "expires_at": past}),
        encoding="utf-8",
    )

    load_session()

    assert not session_module.SESSION_FILE.exists()


def test_load_session_returns_none_when_no_file():
    assert load_session() is None


def test_clear_session_removes_file():
    save_session("https://server", "user", "key123")
    clear_session()

    assert not session_module.SESSION_FILE.exists()


def test_clear_session_is_idempotent():
    clear_session()  # no file — should not raise


def test_get_credentials_uses_provided_args():
    server, login, key = get_credentials("https://s", "user", "key")

    assert (server, login, key) == ("https://s", "user", "key")


def test_get_credentials_falls_back_to_session():
    save_session("https://server", "user", "key123", ttl_minutes=60)

    server, login, key = get_credentials(None, None, None)

    assert (server, login, key) == ("https://server", "user", "key123")


def test_get_credentials_raises_when_no_credentials():
    with pytest.raises(click.UsageError):
        get_credentials(None, None, None)
