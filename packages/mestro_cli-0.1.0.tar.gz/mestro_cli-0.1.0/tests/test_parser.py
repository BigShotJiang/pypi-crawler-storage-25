from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

import maestro_cli.session as session_module
from maestro_cli.parser import cli
from maestro_cli.session import save_session


@pytest.fixture(autouse=True)
def patch_session_paths(tmp_path, monkeypatch):
    session_dir = tmp_path / ".mestro-cli"
    session_file = session_dir / "session.json"
    monkeypatch.setattr(session_module, "SESSION_DIR", session_dir)
    monkeypatch.setattr(session_module, "SESSION_FILE", session_file)


def test_login_saves_session():
    result = CliRunner().invoke(cli, [
        "login", "--server", "https://server", "--login", "user", "--key", "key123",
    ])

    assert result.exit_code == 0
    assert "Sessão salva" in result.output
    assert session_module.SESSION_FILE.exists()


def test_logout_clears_session():
    save_session("https://server", "user", "key123")

    result = CliRunner().invoke(cli, ["logout"])

    assert result.exit_code == 0
    assert "Sessão removida" in result.output
    assert not session_module.SESSION_FILE.exists()


def test_session_status_shows_active_session():
    save_session("https://server", "user", "key123", ttl_minutes=60)

    result = CliRunner().invoke(cli, ["session-status"])

    assert result.exit_code == 0
    assert "Sessão ativa" in result.output
    assert "https://server" in result.output


def test_session_status_when_no_session():
    result = CliRunner().invoke(cli, ["session-status"])

    assert result.exit_code == 0
    assert "Nenhuma sessão" in result.output


def test_package_bot_creates_zip(tmp_path):
    source_dir = tmp_path / "bot"
    source_dir.mkdir()
    (source_dir / "main.py").write_text("print('hello')")
    output_zip = str(tmp_path / "bot.zip")

    result = CliRunner().invoke(cli, [
        "package-bot", "--source", str(source_dir), "--output", output_zip,
    ])

    assert result.exit_code == 0
    assert (tmp_path / "bot.zip").exists()


def test_package_bot_excludes_venv(tmp_path):
    import zipfile

    source_dir = tmp_path / "bot"
    source_dir.mkdir()
    (source_dir / "main.py").write_text("print('hello')")
    venv_dir = source_dir / ".venv"
    venv_dir.mkdir()
    (venv_dir / "lib.py").write_text("# library")
    output_zip = str(tmp_path / "bot.zip")

    CliRunner().invoke(cli, [
        "package-bot", "--source", str(source_dir), "--output", output_zip,
    ])

    with zipfile.ZipFile(output_zip) as zf:
        names = zf.namelist()
    assert "main.py" in names
    assert not any(".venv" in n for n in names)


def test_task_create_command():
    with patch("maestro_cli.parser.BotCityMaestroClient") as MockClient:
        instance = MockClient.return_value
        instance.create_task.return_value = {
            "id": 1,
            "activityLabel": "Proc",
            "dateCreation": "2026-01-01",
            "repositoryLabel": "repo",
        }

        result = CliRunner().invoke(cli, [
            "--server", "https://server", "--login", "user", "--key", "key",
            "task-create", "--activity_label", "Proc",
        ])

    assert result.exit_code == 0
    assert "Tarefa criada" in result.output
