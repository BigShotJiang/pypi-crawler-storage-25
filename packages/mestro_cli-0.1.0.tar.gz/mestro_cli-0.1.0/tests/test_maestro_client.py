from unittest.mock import MagicMock

import pytest

from maestro_cli.maestro_client import BotCityMaestroClient


@pytest.fixture
def client():
    return BotCityMaestroClient("https://server", "user", "key123")


def _mock_post(client, return_value):
    mock_response = MagicMock()
    mock_response.json.return_value = return_value
    client.session.post = MagicMock(return_value=mock_response)
    return mock_response


def test_login_workspace_sets_token_and_organization(client):
    _mock_post(client, {"accessToken": "tok123", "organizationLabel": "org1"})

    client.login_workspace()

    assert client.token == "tok123"
    assert client.organization == "org1"
    assert client.session.headers["token"] == "tok123"
    assert client.session.headers["organization"] == "org1"


def test_create_task_sends_correct_payload(client):
    _mock_post(client, {"id": 1, "activityLabel": "Test", "dateCreation": "2026-01-01", "repositoryLabel": "repo"})

    result = client.create_task("Test", priority=5, test=True)

    payload = client.session.post.call_args[1]["json"]
    assert payload["activityLabel"] == "Test"
    assert payload["priority"] == 5
    assert payload["test"] is True
    assert result["id"] == 1


def test_delete_task_calls_correct_endpoint(client):
    mock_response = MagicMock()
    client.session.delete = MagicMock(return_value=mock_response)

    client.delete_task(42)

    client.session.delete.assert_called_once_with("https://server/api/v2/task/42")


def test_duplicate_task_calls_correct_endpoint(client):
    _mock_post(client, {"id": 2})

    result = client.duplicate_task(42)

    client.session.post.assert_called_once_with("https://server/api/v2/task/42/duplicate")
    assert result["id"] == 2


def test_upload_bot_sends_file(client, tmp_path):
    bot_file = tmp_path / "bot.zip"
    bot_file.write_bytes(b"zip content")
    mock_response = MagicMock()
    client.session.post = MagicMock(return_value=mock_response)

    client.upload_bot("bot1", "1.0.0", str(bot_file))

    url = client.session.post.call_args[0][0]
    assert "bot1" in url
    assert "1.0.0" in url


def test_upload_bot_raises_when_file_not_found(client):
    with pytest.raises(FileNotFoundError):
        client.upload_bot("bot1", "1.0.0", "/nonexistent/bot.zip")
