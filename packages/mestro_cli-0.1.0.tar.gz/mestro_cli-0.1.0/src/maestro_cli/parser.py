from pathlib import Path
import logging
import zipfile

import click

from maestro_cli.maestro_client import BotCityMaestroClient
from maestro_cli.session import save_session, load_session, clear_session, get_credentials


@click.group(help="BotCity Maestro CLI")
@click.option("--server", required=False, help="URL do servidor Maestro")
@click.option("--login", "login_name", required=False, help="Workspace Login")
@click.option("--key", required=False, help="Workspace Key")
@click.pass_context
def cli(ctx, server, login_name, key):
    invoked = ctx.invoked_subcommand
    if invoked in ("login", "logout", "session-status", "package-bot"):
        return

    server, login_name, key = get_credentials(server, login_name, key)
    client: BotCityMaestroClient = BotCityMaestroClient(server, login_name, key)
    client.login_workspace()
    ctx.obj = client


@cli.command("login", help="Salva credenciais para uso em comandos futuros")
@click.option("--server", required=True, help="URL do servidor Maestro")
@click.option("--login", "login_name", required=True, help="Workspace Login")
@click.option("--key", required=True, help="Workspace Key")
@click.option(
    "--ttl-minutes",
    default=480,
    type=int,
    show_default=True,
    help="Duração da sessão em minutos antes de expirar.",
)
def login(server, login_name, key, ttl_minutes):
    session_data = save_session(server, login_name, key, ttl_minutes)
    click.echo(f"Sessão salva até {session_data['expires_at']}.")


@cli.command("logout", help="Remove a sessão salva")
def logout():
    clear_session()
    click.echo("Sessão removida.")


@cli.command("session-status", help="Mostra o estado da sessão salva")
def session_status():
    session_data = load_session()
    if not session_data:
        click.echo("Nenhuma sessão ativa ou a sessão expirou.")
        return

    click.echo(f"Sessão ativa até {session_data['expires_at']}")
    click.echo(f"Servidor: {session_data['server']}")
    click.echo(f"Login: {session_data['login']}")


@cli.command("bot-upload", help="Realiza o upload de um bot em uma versão específica")
@click.option("--botId", required=True, help="ID único do bot")
@click.option("--version", required=True, help="Versão da automação")
@click.option("--file", required=True, help="Pasta com arquivos da automação")
@click.pass_obj
def bot_upload(client, botid, version, file):
    file_path = str(Path(file).resolve())
    client.upload_bot(botid, version, file_path)
    click.echo("Upload realizado")


@cli.command("task-create", help="Cria uma nova tarefa")
@click.option("--activity_label", required=True)
@click.option("--priority", default=0, type=int)
@click.option("--test", default=False, type=bool)
@click.pass_obj
def task_create(client, activity_label, test, priority):
    result = client.create_task(activity_label, test=test, priority=priority)
    click.echo(f"Tarefa criada: id {result['id']} activity label {result['activityLabel']} creation date {result['dateCreation']} repository label {result['repositoryLabel']}")


@cli.command("task-delete", help="Deleta uma tarefa")
@click.option("--task_id", required=True)
@click.pass_obj
def task_delete(client, task_id):
    client.delete_task(task_id)
    click.echo("Tarefa deletada com sucesso")


@cli.command("task-duplicate", help="Duplica uma tarefa")
@click.option("--task_id", required=True)
@click.pass_obj
def task_duplicate(client, task_id):
    result = client.duplicate_task(task_id)
    click.echo(f"Tarefa duplicada {result}")


@cli.command("package-bot", help="Compacta arquivos do bot excluindo diretórios de ambiente")
@click.option("--source", type=click.Path(exists=True), default=".", help="Diretório de origem (padrão: .)")
@click.option("--output", required=True, help="Nome do arquivo ZIP de saída (ex: bot.zip)")
def package_bot(source, output):
    """Cria um arquivo ZIP excluindo diretórios e arquivos de ambiente virtual."""
    exclude_patterns = {".venv", "venv", "ENV", ".ENV", "env.bak", "venv.bak", "__pycache__", ".git", ".pytest_cache"}

    source_path = Path(source).resolve()
    output_path = Path(output).resolve()

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for file_path in source_path.rglob("*"):
            # Pula diretórios excluídos
            if any(part in exclude_patterns for part in file_path.relative_to(source_path).parts):
                continue

            if file_path.suffix == ".zip":
                continue

            # Adiciona apenas arquivos ao ZIP
            if file_path.is_file():
                arcname = file_path.relative_to(source_path)
                zipf.write(file_path, arcname=arcname)

    click.echo(f"Arquivo criado: {output_path}")


def main():
    logging.basicConfig(level=logging.WARNING)
    cli()


if __name__ == "__main__":
    main()
