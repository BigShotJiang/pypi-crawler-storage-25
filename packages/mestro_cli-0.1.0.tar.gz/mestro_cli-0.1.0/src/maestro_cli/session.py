import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

import click

SESSION_DIR = Path.home() / ".mestro-cli"
SESSION_FILE = SESSION_DIR / "session.json"


def ensure_session_dir():
    """Cria o diretório de sessão se não existir."""
    SESSION_DIR.mkdir(parents=True, exist_ok=True)


def save_session(server, login, key, ttl_minutes=480):
    """Salva as credenciais em um arquivo de sessão com expiração."""
    ensure_session_dir()

    now = datetime.now(timezone.utc)
    expires_at = (now + timedelta(minutes=ttl_minutes)).isoformat()

    session_data = {
        "server": server,
        "login": login,
        "key": key,
        "expires_at": expires_at,
    }

    SESSION_FILE.write_text(json.dumps(session_data, indent=2), encoding="utf-8")
    return session_data


def load_session():
    """Carrega a sessão se existir e não tiver expirado."""
    if not SESSION_FILE.exists():
        return None

    try:
        session_data = json.loads(SESSION_FILE.read_text(encoding="utf-8"))

        expires_at = datetime.fromisoformat(session_data["expires_at"])

        if datetime.now(timezone.utc) >= expires_at:
            SESSION_FILE.unlink(missing_ok=True)
            return None

        return session_data
    except (ValueError, KeyError, json.JSONDecodeError):
        return None


def clear_session():
    """Remove o arquivo de sessão."""
    if SESSION_FILE.exists():
        SESSION_FILE.unlink()


def get_credentials(server, login, key):
    """
    Obtém as credenciais passadas diretamente ou tenta carregar da sessão.

    Raises:
        click.UsageError: Se nenhuma credencial está disponível.
    """
    if server and login and key:
        return server, login, key

    session_data = load_session()
    if session_data and all(session_data.get(field) for field in ("server", "login", "key")):
        return session_data["server"], session_data["login"], session_data["key"]

    raise click.UsageError(
        "Não há sessão ativa. Use `mestro-cli login --server ... --login ... --key ...` "
        "ou passe os parâmetros --server, --login e --key diretamente."
    )
