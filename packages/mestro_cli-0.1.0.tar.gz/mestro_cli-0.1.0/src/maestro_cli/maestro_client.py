import requests
import os
import logging

logger = logging.getLogger(__name__)


class BotCityMaestroClient:
    """
    Cliente de integração com a API do BotCity Maestro para operações de
    gerenciamento de automações e tarefas.
    """

    def __init__(self, server, login, key):
        self.server = server.rstrip("/")
        self.login = login
        self.key = key
        self.token = None
        self.organization = None
        self.session = requests.Session()

    def login_workspace(self):
        """
        Realiza a autenticação no workspace e armazena os tokens de sessão.
        """
        url = f"{self.server}/api/v2/workspace/login"
        payload = {
            "login": self.login,
            "key": self.key
        }

        response = self.session.post(url, json=payload)
        response.raise_for_status()

        data = response.json()
        self.token = data.get("accessToken")
        self.organization = data.get("organizationLabel")

        self.session.headers.update({
            "token": self.token,
            "organization": self.organization
        })
        logger.info("Autenticação realizada com sucesso.")

    def upload_bot(self, bot_id, version, file_path):
        """
        Realiza o upload de um bot em uma versão específica.
        """
        url = f"{self.server}/api/v2/bot/upload/{bot_id}/version/{version}"

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")

        with open(file_path, 'rb') as bot_file:
            file = {
                'file': (os.path.basename(file_path), bot_file, 'application/zip')
            }

            response = self.session.post(url, files=file)
            response.raise_for_status()

    def create_task(self, activity_label, parameters=None, test=False, priority=0):
        """
        Enfileira uma nova tarefa para execução.
        """
        url = f"{self.server}/api/v2/task"
        payload = {
            "activityLabel": activity_label,
            "parameters": parameters or {},
            "test": test,
            "priority": priority
        }

        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def delete_task(self, task_id: int):
        """
        Deleta uma tarefa.
        """
        url = f"{self.server}/api/v2/task/{task_id}"

        response = self.session.delete(url)
        response.raise_for_status()

    def duplicate_task(self, task_id: int):
        """
        Duplica uma tarefa para execução.
        """
        url = f"{self.server}/api/v2/task/{task_id}/duplicate"

        response = self.session.post(url)
        response.raise_for_status()
        return response.json()
