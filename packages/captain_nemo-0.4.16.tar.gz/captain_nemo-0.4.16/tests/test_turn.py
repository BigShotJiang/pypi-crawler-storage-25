"""Tests for nemo.turn — SDK turn execution and event emission."""

import asyncio
from dataclasses import dataclass
from unittest import mock

import pytest

from nemo.turn import (
  run_turn, ProgressEvent, AnswerEvent,
  TaskStartedEvent, TaskDoneEvent, DoneEvent, ErrorEvent,
  RateLimitNoticeEvent, CompactNoticeEvent, TurnEvent,
)


# ---------------------------------------------------------------------------
# Mock SDK types (so we don't need claude_agent_sdk installed)
# ---------------------------------------------------------------------------

@dataclass
class FakeTextBlock:
  text: str
  type: str = "text"


@dataclass
class FakeThinkingBlock:
  thinking: str
  signature: str = ""
  type: str = "thinking"


@dataclass
class FakeToolUseBlock:
  name: str
  input: dict
  id: str = "tu_1"
  type: str = "tool_use"


@dataclass
class FakeAssistantMessage:
  content: list
  parent_tool_use_id: str | None = None


@dataclass
class FakeResultMessage:
  total_cost_usd: float = 0.01
  usage: dict = None
  is_error: bool = False
  result: str = ""

  def __post_init__(self):
    if self.usage is None:
      self.usage = {"input_tokens": 100, "output_tokens": 50}


@dataclass
class FakeTaskStartedMessage:
  task_id: str


@dataclass
class FakeTaskNotificationMessage:
  task_id: str
  status: str = "completed"


@dataclass
class FakeTaskProgressMessage:
  description: str = ""


# ---------------------------------------------------------------------------
# Helper: mock client
# ---------------------------------------------------------------------------

class FakeClient:
  def __init__(self, messages):
    self._messages = messages
    self._queried = False

  async def query(self, prompt):
    self._queried = True

  async def receive_response(self):
    for msg in self._messages:
      yield msg

  async def stop_task(self, task_id):
    pass


def _sdk_modules():
  """Create a mock for claude_agent_sdk module."""
  return {
    "claude_agent_sdk": mock.MagicMock(
      AssistantMessage=FakeAssistantMessage,
      TextBlock=FakeTextBlock,
      ThinkingBlock=FakeThinkingBlock,
      ToolUseBlock=FakeToolUseBlock,
      ResultMessage=FakeResultMessage,
      TaskStartedMessage=FakeTaskStartedMessage,
      TaskNotificationMessage=FakeTaskNotificationMessage,
      TaskProgressMessage=FakeTaskProgressMessage,
    ),
  }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_text_only_turn():
  """A turn that produces only text output."""
  messages = [
    FakeAssistantMessage(content=[FakeTextBlock(text="Hello world")]),
    FakeResultMessage(total_cost_usd=0.02, usage={"input_tokens": 200}),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      cost, usage = await run_turn(client, "say hello", events.append)
      assert cost == 0.02
      assert usage["input_tokens"] == 200
  asyncio.run(_run())
  assert any(isinstance(e, AnswerEvent) and e.text == "Hello world" for e in events)
  assert any(isinstance(e, DoneEvent) for e in events)


def test_tool_use_turn():
  """A turn with tool use should emit ProgressEvents (first=True then first=False)."""
  messages = [
    FakeAssistantMessage(content=[FakeToolUseBlock(name="Read", input={"file_path": "/a/b.py"})]),
    FakeAssistantMessage(content=[FakeToolUseBlock(name="Edit", input={"file_path": "/a/c.py"})]),
    FakeAssistantMessage(content=[FakeTextBlock(text="Done editing")]),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "fix bug", events.append)
  asyncio.run(_run())
  tool_events = [e for e in events if isinstance(e, ProgressEvent) and e.kind == "tool"]
  assert len(tool_events) == 2
  assert tool_events[0].first is True
  assert tool_events[1].first is False


def test_task_lifecycle():
  """TaskStarted and TaskNotification should emit corresponding events."""
  messages = [
    FakeAssistantMessage(content=[FakeToolUseBlock(name="Agent", input={"description": "search"})]),
    FakeTaskStartedMessage(task_id="task_1"),
    FakeTaskNotificationMessage(task_id="task_1", status="completed"),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "search code", events.append)
  asyncio.run(_run())
  assert any(isinstance(e, TaskStartedEvent) and e.task_id == "task_1" for e in events)
  assert any(isinstance(e, TaskDoneEvent) and e.task_id == "task_1" for e in events)


def test_stale_leak_raises_for_reconnect_resume():
  """SDK #788: a stale TaskNotification leaking into the stream must raise
  StaleLeakError (a TransientAPIError) so SDKThread.run_turn_with_reconnect
  recovers via reconnect-with-resume — NOT an in-band drain.
  """
  from nemo.turn import StaleLeakError, TransientAPIError

  assert issubclass(StaleLeakError, TransientAPIError), \
    "StaleLeakError must subclass TransientAPIError so the existing " \
    "reconnect-with-resume path catches it"

  stale_messages = [
    FakeTaskNotificationMessage(task_id="stale_1", status="completed"),
    FakeAssistantMessage(content=[FakeTextBlock(text="answer to a STALE")]),
    FakeResultMessage(total_cost_usd=0.01),
  ]
  sent_prompts: list[str] = []
  events: list = []
  call_count = 0

  class Client:
    async def query(self, prompt):
      sent_prompts.append(prompt)

    async def receive_response(self):
      nonlocal call_count
      call_count += 1
      for msg in stale_messages:
        yield msg

    async def stop_task(self, task_id):
      pass

  stale = {"stale_1"}

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(Client(), "real prompt", events.append,
                     stale_tasks=stale)

  with pytest.raises(StaleLeakError):
    asyncio.run(_run())

  # Exactly one turn attempted — no in-band drain/retry loop.
  assert call_count == 1
  assert sent_prompts == ["real prompt"]
  # The leaked stale's answer must NOT surface to the user.
  assert not any(isinstance(e, AnswerEvent) for e in events), \
    "stale-contaminated output leaked to on_event"
  # No DoneEvent — turn did not complete; the reconnect layer retries.
  assert not any(isinstance(e, DoneEvent) for e in events)
  # A visible breadcrumb MUST be emitted before the raise so the recovery
  # is not silent.
  from nemo.turn import StaleLeakNoticeEvent
  notices = [e for e in events if isinstance(e, StaleLeakNoticeEvent)]
  assert len(notices) == 1 and notices[0].task_id == "stale_1", \
    f"expected one StaleLeakNoticeEvent for stale_1, got {notices}"
  # All tracked stale ids cleared: they belong to the about-to-be-killed
  # subprocess; the resumed session starts clean.
  assert stale == set(), f"stale_tasks must be cleared on leak, got {stale}"


def test_stale_leak_detected_after_some_clean_output():
  """The leak guard fires wherever the stale appears — even after some
  legitimate output — still raising StaleLeakError and stopping the turn.
  """
  from nemo.turn import StaleLeakError, StaleLeakNoticeEvent

  messages = [
    FakeAssistantMessage(content=[FakeTextBlock(text="partial work")]),
    FakeTaskNotificationMessage(task_id="ghost", status="completed"),
    FakeResultMessage(total_cost_usd=0.0),
  ]
  events: list = []
  stale = {"ghost"}

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append,
                     stale_tasks=stale)

  with pytest.raises(StaleLeakError):
    asyncio.run(_run())
  assert stale == set()
  notices = [e for e in events if isinstance(e, StaleLeakNoticeEvent)]
  assert len(notices) == 1 and notices[0].task_id == "ghost"


def test_stop_task_circuit_breaker_on_control_timeout():
  """First 'Control request timeout' from stop_task disables subsequent calls.

  When the SDK's control channel wedges, stop_task returns this error on
  every pending id. After the first occurrence we should short-circuit all
  further stop_task invocations within the same run_turn orchestration.
  """
  # Turn yields two pending tasks then ResultMessage. No stale is marked,
  # so the turn is "clean" — the pending tasks are both promoted to stale.
  messages = [
    FakeTaskStartedMessage(task_id="t1"),
    FakeTaskStartedMessage(task_id="t2"),
    FakeTaskStartedMessage(task_id="t3"),
    FakeResultMessage(total_cost_usd=0.01),
  ]
  stop_calls: list[str] = []

  class TimingOutClient:
    async def query(self, prompt):
      pass

    async def receive_response(self):
      for msg in messages:
        yield msg

    async def stop_task(self, task_id):
      stop_calls.append(task_id)
      raise RuntimeError("Control request timeout: stop_task")

  events: list = []

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(TimingOutClient(), "real", events.append)

  asyncio.run(_run())
  # First stop_task failure trips the breaker — further ids are skipped.
  # (pending_tasks is a set so iteration order is not guaranteed; we only
  # care that exactly one stop_task was attempted.)
  assert len(stop_calls) == 1, \
    f"expected only first stop_task to be attempted, got {stop_calls}"
  assert stop_calls[0] in {"t1", "t2", "t3"}


def test_transient_api_error_in_assistant_message_raises_and_suppresses():
  """CLI-surfaced 'API Error:' text must not reach the user as an answer.

  It should instead raise TransientAPIError from _single_turn so
  SDKThread.run_turn_with_reconnect can reconnect and retry.
  """
  from nemo.turn import TransientAPIError
  messages = [
    FakeAssistantMessage(content=[FakeTextBlock(
      text="API Error: Unable to connect to API (ECONNRESET)")]),
    FakeResultMessage(total_cost_usd=0.0),
  ]
  events: list = []

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "hello", events.append)

  with pytest.raises(TransientAPIError):
    asyncio.run(_run())
  # The error text must NOT have been emitted to the user.
  assert not any(
    isinstance(e, AnswerEvent) and "API Error" in e.text
    for e in events
  ), "CLI error message leaked to user as AnswerEvent"


def test_transient_api_error_via_result_is_error_flag():
  """ResultMessage.is_error + transient-signal body → TransientAPIError."""
  from nemo.turn import TransientAPIError
  messages = [
    FakeResultMessage(
      total_cost_usd=0.0,
      is_error=True,
      result="Request failed: socket hang up",
    ),
  ]
  events: list = []

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)

  with pytest.raises(TransientAPIError):
    asyncio.run(_run())


def test_transient_api_error_detector_no_false_positive_on_user_topic():
  """User asking 'what is ECONNRESET?' gets a normal answer — no reconnect.

  Real model replies never START with 'API Error:' and is_error is False,
  so strict prefix matching must let this through as a regular AnswerEvent.
  """
  messages = [
    FakeAssistantMessage(content=[FakeTextBlock(
      text=(
        "ECONNRESET is a TCP error code meaning the remote peer forcibly "
        "closed the connection (RST packet). You'll see it when the server "
        "crashed, a firewall killed the connection, or a load balancer "
        "dropped the socket. It's distinct from ETIMEDOUT (no response) "
        "and EAI_AGAIN (DNS retry)."
      ))]),
    FakeResultMessage(total_cost_usd=0.02, is_error=False),
  ]
  events: list = []

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "what is ECONNRESET?",
                     events.append)

  asyncio.run(_run())
  answers = [e.text for e in events if isinstance(e, AnswerEvent)]
  assert len(answers) == 1, f"expected one AnswerEvent, got {answers!r}"
  assert "ECONNRESET" in answers[0]


def test_clean_real_turn_preserves_freshly_promoted_stales():
  """Regression: pending_tasks promoted to stale at ResultMessage must
  survive the "clean real turn" drop path.

  Previous behavior: after a clean real turn, ALL stale_tasks were cleared
  under the assumption that nothing surfaced means nothing will. But the
  ResultMessage handler had just promoted N still-pending tasks into
  stale_tasks seconds earlier — those legitimate future-stale ids got
  wiped, so the next turn saw unexpected TaskNotificationMessages that
  weren't in stale_tasks and leaked as TaskDoneEvents / contaminated the
  model context.
  """
  # Turn 1: two background tasks start but never complete before
  # ResultMessage. Neither id was in stale_tasks at turn start.
  messages = [
    FakeTaskStartedMessage(task_id="fresh_x"),
    FakeTaskStartedMessage(task_id="fresh_y"),
    FakeAssistantMessage(content=[FakeTextBlock(text="kicking off tasks")]),
    FakeResultMessage(total_cost_usd=0.1),
  ]
  events: list = []
  stale: set[str] = set()

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "do stuff",
                     events.append, stale_tasks=stale)

  asyncio.run(_run())

  # Both freshly promoted ids must remain in stale_tasks for the NEXT turn
  # to recognise late TaskNotifications as stale.
  assert stale == {"fresh_x", "fresh_y"}, \
    f"freshly promoted stales were wrongly dropped: {stale}"


def test_progress_timeout_fires_on_systemmessage_storm(monkeypatch):
  """SDK emitting SystemMessages indefinitely must not keep a dead turn alive.

  Observed in production: claude CLI enters a rate-limit retry loop that
  emits a SystemMessage every ~1 min. Each SystemMessage used to reset
  HEARTBEAT_TIMEOUT, so the turn was never declared stuck. Progress-only
  timeout should trigger after PROGRESS_TIMEOUT seconds regardless.
  """
  from nemo import turn as turn_module

  # Shrink both timeouts so the test runs fast.
  monkeypatch.setattr(turn_module, "PROGRESS_TIMEOUT", 0.5)
  monkeypatch.setattr(turn_module, "HEARTBEAT_TIMEOUT", 5)

  # A fake "SystemMessage" class (outside our claude_agent_sdk imports) whose
  # class name matches the non-progress set.
  @dataclass
  class SystemMessage:
    subtype: str = "rate_limit"

  # Yield SystemMessages forever (simulating rate-limit retry loop).
  # The progress timeout should fire first and break out.
  async def forever_system():
    while True:
      await asyncio.sleep(0.2)
      yield SystemMessage()

  class StormClient:
    async def query(self, prompt):
      pass

    def receive_response(self):
      return forever_system()

    async def stop_task(self, task_id):
      pass

  events: list = []

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(StormClient(), "hello", events.append)

  with pytest.raises(TimeoutError):
    asyncio.run(_run())

  # The user should see an ErrorEvent documenting the stuck turn.
  assert any(isinstance(e, ErrorEvent) for e in events), \
    "progress-timeout abort must surface as ErrorEvent"


def test_reset_clears_stale_tasks_on_claude_adapter():
  """ClaudeCodingAgent.reset() must clear self._stale_tasks.

  Task ids from a dead SDK session will never produce notifications on a
  fresh session, so keeping them would risk a spurious StaleLeakError
  after every reconnect.
  """
  from nemo.claude_agent import ClaudeCodingAgent

  # Build a minimal adapter without touching the real SDK.
  adapter = ClaudeCodingAgent.__new__(ClaudeCodingAgent)
  adapter._stale_tasks = {"ghost_1", "ghost_2"}

  # Patch the parts reset() touches so we don't actually spawn a CLI.
  adapter._sdk = mock.AsyncMock()
  adapter._sdk.reconnect = mock.AsyncMock()
  adapter._build_options = mock.Mock(return_value=object())

  async def _run():
    await adapter.reset("/tmp", "claude-opus-4-6")

  asyncio.run(_run())
  assert adapter._stale_tasks == set(), \
    "reset() must clear _stale_tasks since old session ids are dead"


def test_empty_turn():
  """A turn with only ResultMessage."""
  messages = [FakeResultMessage(total_cost_usd=0.0, usage={})]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      cost, _usage = await run_turn(client, "", events.append)
      assert cost == 0.0
  asyncio.run(_run())
  assert len(events) == 1
  assert isinstance(events[0], DoneEvent)


def test_task_progress_event():
  """TaskProgressMessage should emit ProgressEvent when working."""
  messages = [
    FakeAssistantMessage(content=[FakeToolUseBlock(name="Bash", input={"command": "ls"})]),
    FakeTaskProgressMessage(description="Searching files..."),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "test", events.append)
  asyncio.run(_run())
  progress = [e for e in events if isinstance(e, ProgressEvent) and e.kind == "tool"]
  assert any(e.summary == "Searching files..." for e in progress)


def test_mixed_text_and_tool():
  """Message with both text and tool blocks."""
  messages = [
    FakeAssistantMessage(content=[
      FakeTextBlock(text="Let me check"),
      FakeToolUseBlock(name="Read", input={"file_path": "/x.py"}),
    ]),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "test", events.append)
  asyncio.run(_run())
  # Text takes priority when present
  answer_events = [e for e in events if isinstance(e, AnswerEvent)]
  assert len(answer_events) == 1
  assert answer_events[0].text == "Let me check"


def test_trailing_thinking_compensation():
  """When the last event is thinking (no text), an AnswerEvent should be synthesized."""
  messages = [
    FakeAssistantMessage(content=[
      FakeThinkingBlock(thinking="Let me analyze this"),
      FakeToolUseBlock(name="Read", input={"file_path": "/a.py"}),
    ]),
    FakeAssistantMessage(content=[
      FakeThinkingBlock(thinking="I see the issue, the fix is to change line 42"),
    ]),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "fix bug", events.append)
  asyncio.run(_run())
  answer_events = [e for e in events if isinstance(e, AnswerEvent)]
  assert len(answer_events) == 1
  assert answer_events[0].text == "I see the issue, the fix is to change line 42"
  assert any(isinstance(e, DoneEvent) for e in events)


def test_rate_limit_event_emits_notice():
  """SDK's RateLimitEvent (matched by class name in non-progress branch) must
  surface as a RateLimitNoticeEvent carrying the upstream status fields."""

  @dataclass
  class FakeRateLimitInfo:
    status: str
    rate_limit_type: str = ""
    resets_at: int | None = None
    utilization: float | None = None

  @dataclass
  class RateLimitEvent:
    rate_limit_info: FakeRateLimitInfo

  messages = [
    RateLimitEvent(rate_limit_info=FakeRateLimitInfo(
      status="rejected",
      rate_limit_type="five_hour",
      resets_at=1_700_000_000,
      utilization=0.97,
    )),
    FakeAssistantMessage(content=[FakeTextBlock(text="back to work")]),
    FakeResultMessage(),
  ]
  events: list = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)
  asyncio.run(_run())

  notices = [e for e in events if isinstance(e, RateLimitNoticeEvent)]
  assert len(notices) == 1
  n = notices[0]
  assert n.status == "rejected"
  assert n.rate_limit_type == "five_hour"
  assert n.resets_at == 1_700_000_000
  assert abs((n.utilization or 0.0) - 0.97) < 1e-9


def test_compact_boundary_emits_notice():
  """SystemMessage(subtype="compact_boundary") must surface as
  CompactNoticeEvent with the metadata fields extracted from data."""

  @dataclass
  class SystemMessage:
    subtype: str
    data: dict

  messages = [
    SystemMessage(
      subtype="compact_boundary",
      data={
        "type": "system",
        "subtype": "compact_boundary",
        "compact_metadata": {
          "trigger": "auto",
          "pre_tokens": 45_000,
          "post_tokens": 8_200,
          "duration_ms": 12_345,
        },
      },
    ),
    FakeAssistantMessage(content=[FakeTextBlock(text="back to work")]),
    FakeResultMessage(),
  ]
  events: list = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)
  asyncio.run(_run())

  notices = [e for e in events if isinstance(e, CompactNoticeEvent)]
  assert len(notices) == 1
  n = notices[0]
  assert n.trigger == "auto"
  assert n.pre_tokens == 45_000
  assert n.post_tokens == 8_200
  assert n.duration_ms == 12_345
  # Compaction is real work — the downstream AssistantMessage should still
  # produce its AnswerEvent (i.e. compact_boundary doesn't short-circuit
  # the rest of the turn).
  assert any(isinstance(e, AnswerEvent) and e.text == "back to work"
             for e in events)


def test_compact_boundary_with_partial_metadata():
  """A compact_boundary with only the required fields (no post_tokens / no
  duration) must still emit a notice — those fields are documented optional
  in the Claude CLI stream-json schema."""

  @dataclass
  class SystemMessage:
    subtype: str
    data: dict

  messages = [
    SystemMessage(
      subtype="compact_boundary",
      data={
        "type": "system",
        "subtype": "compact_boundary",
        "compact_metadata": {"trigger": "manual", "pre_tokens": 30_000},
      },
    ),
    FakeResultMessage(),
  ]
  events: list = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)
  asyncio.run(_run())

  notices = [e for e in events if isinstance(e, CompactNoticeEvent)]
  assert len(notices) == 1
  assert notices[0].trigger == "manual"
  assert notices[0].pre_tokens == 30_000
  assert notices[0].post_tokens == 0
  assert notices[0].duration_ms == 0


def test_microcompact_boundary_is_suppressed():
  """SystemMessage(subtype="microcompact_boundary") should be silently
  dropped — the Claude CLI's UI also returns null for it. We still want
  to consume the message without crashing or surfacing a notice."""

  @dataclass
  class SystemMessage:
    subtype: str
    data: dict

  messages = [
    SystemMessage(subtype="microcompact_boundary", data={}),
    FakeResultMessage(),
  ]
  events: list = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)
  asyncio.run(_run())
  assert not any(isinstance(e, CompactNoticeEvent) for e in events)


def test_rate_limit_event_with_missing_info_is_skipped():
  """If rate_limit_info is absent, no notice should be emitted (defensive)."""
  @dataclass
  class RateLimitEvent:
    rate_limit_info: object = None

  messages = [
    RateLimitEvent(),
    FakeResultMessage(),
  ]
  events: list = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      await run_turn(FakeClient(messages), "hi", events.append)
  asyncio.run(_run())
  assert not any(isinstance(e, RateLimitNoticeEvent) for e in events)


def test_no_compensation_when_answer_is_last():
  """No trailing thinking compensation when the last event is an AnswerEvent."""
  messages = [
    FakeAssistantMessage(content=[
      FakeThinkingBlock(thinking="thinking..."),
      FakeTextBlock(text="Here is my answer"),
    ]),
    FakeResultMessage(),
  ]
  events = []
  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = FakeClient(messages)
      await run_turn(client, "test", events.append)
  asyncio.run(_run())
  answer_events = [e for e in events if isinstance(e, AnswerEvent)]
  assert len(answer_events) == 1
  assert answer_events[0].text == "Here is my answer"


def test_first_message_timeout():
  """First message doesn't arrive within 30s — TimeoutError + ErrorEvent."""
  events = []

  class HangingClient:
    async def query(self, _prompt):
      pass

    async def receive_response(self):
      # Yield nothing — the async iterator hangs forever
      await asyncio.Future()  # never resolves
      # Make this a generator
      yield  # pragma: no cover

    async def stop_task(self, _task_id):
      pass

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = HangingClient()
      # Patch asyncio.wait to simulate timeout (empty done set)
      original_wait = asyncio.wait

      async def fake_wait(fs, **kwargs):
        # Return empty done set, all pending — simulates timeout
        return set(), set(fs)

      with mock.patch("asyncio.wait", side_effect=fake_wait):
        try:
          await run_turn(client, "hello", events.append)
          assert False, "Expected TimeoutError"
        except TimeoutError:
          pass
    assert any(isinstance(e, ErrorEvent) for e in events)
    error = next(e for e in events if isinstance(e, ErrorEvent))
    assert "timed out" in error.message.lower()

  asyncio.run(_run())


def test_heartbeat_timeout():
  """First message arrives, then second one times out at 300s."""
  events = []
  wait_call_count = 0

  class OneMessageClient:
    async def query(self, _prompt):
      pass

    async def receive_response(self):
      yield FakeAssistantMessage(content=[FakeTextBlock(text="thinking...")])
      # Second message hangs forever
      await asyncio.Future()
      yield  # pragma: no cover

    async def stop_task(self, _task_id):
      pass

  async def _run():
    nonlocal wait_call_count
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = OneMessageClient()
      original_wait = asyncio.wait

      async def fake_wait(fs, **kwargs):
        nonlocal wait_call_count
        wait_call_count += 1
        if wait_call_count == 1:
          # First call: let the message through
          return await original_wait(fs, **kwargs)
        else:
          # Second call: simulate timeout
          return set(), set(fs)

      with mock.patch("asyncio.wait", side_effect=fake_wait):
        try:
          await run_turn(client, "hello", events.append)
          assert False, "Expected TimeoutError"
        except TimeoutError:
          pass
    # Should have the text event from first message
    assert any(isinstance(e, AnswerEvent) and e.text == "thinking..." for e in events)
    # Should have error event from timeout
    assert any(isinstance(e, ErrorEvent) for e in events)

  asyncio.run(_run())


@pytest.mark.slow
def test_query_timeout():
  """Mock client.query() to be slow — anyio.fail_after(15) triggers."""
  events = []

  class SlowQueryClient:
    async def query(self, _prompt):
      await asyncio.sleep(60)  # way longer than 15s limit

    async def receive_response(self):
      yield FakeResultMessage()  # pragma: no cover

    async def stop_task(self, _task_id):
      pass

  async def _run():
    with mock.patch.dict("sys.modules", _sdk_modules()):
      client = SlowQueryClient()
      try:
        await run_turn(client, "hello", events.append)
        assert False, "Expected timeout"
      except (TimeoutError, Exception) as exc:
        # anyio.fail_after raises TimeoutError (via anyio.get_cancelled_exc_class
        # or builtins.TimeoutError depending on backend)
        assert "timed out" in str(type(exc).__name__).lower() or isinstance(exc, TimeoutError) or "cancel" in str(type(exc).__name__).lower(), f"Unexpected: {exc!r}"

  asyncio.run(_run())
