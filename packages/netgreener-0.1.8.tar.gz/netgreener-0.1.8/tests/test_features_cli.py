from __future__ import annotations

import json

from click.testing import CliRunner

from netgreener.api_client import APIError
from netgreener.cli import main


class FakeClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, tuple, dict]] = []

    def _record(self, name: str, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    # metadata
    def get_project_feature_metadata(self, project_id: int):
        self._record("get_project_feature_metadata", project_id)
        return {"project_id": project_id, "parquet_path": "/tmp/features.parquet"}

    # inputs
    def post_feature_collection_input(self, payload: dict):
        self._record("post_feature_collection_input", payload)
        return {"input_id": 123, **payload}

    def get_feature_collection_inputs(self, **kwargs):
        self._record("get_feature_collection_inputs", **kwargs)
        return [{"input_id": 1, "project_id": kwargs.get("project_id", 1)}]

    # definitions
    def post_feature_definition(self, payload: dict):
        self._record("post_feature_definition", payload)
        return payload

    def list_feature_definitions(self, **kwargs):
        self._record("list_feature_definitions", **kwargs)
        return [{"feature_name": "f1", "data_type": "float", "source_type": "code"}]


class SmokeFakeClient(FakeClient):
    """Stateful fake for one end-to-end lifecycle test."""

    def __init__(self) -> None:
        super().__init__()
        self.definitions: dict[str, dict] = {}
        self.inputs: dict[int, dict] = {}
        self.next_input_id = 1000

    # definitions lifecycle
    def post_feature_definition(self, payload: dict):
        self._record("post_feature_definition", payload)
        self.definitions[payload["feature_name"]] = payload.copy()
        return self.definitions[payload["feature_name"]]

    def get_feature_definition(self, feature_name: str):
        self._record("get_feature_definition", feature_name)
        return self.definitions[feature_name]

    def update_feature_definition(self, feature_name: str, payload: dict):
        self._record("update_feature_definition", feature_name, payload)
        self.definitions[feature_name].update(payload)
        return self.definitions[feature_name]

    def delete_feature_definition(self, feature_name: str):
        self._record("delete_feature_definition", feature_name)
        for item in self.inputs.values():
            if item["feature_name"] == feature_name:
                raise RuntimeError("Cannot delete definition while inputs reference it")
        del self.definitions[feature_name]
        return {"message": "deleted"}

    def list_feature_definitions(self, **kwargs):
        self._record("list_feature_definitions", **kwargs)
        rows = list(self.definitions.values())
        if kwargs.get("data_type"):
            rows = [r for r in rows if r.get("data_type") == kwargs["data_type"]]
        if kwargs.get("source_type"):
            rows = [r for r in rows if r.get("source_type") == kwargs["source_type"]]
        return rows

    # inputs lifecycle
    def post_feature_collection_input(self, payload: dict):
        self._record("post_feature_collection_input", payload)
        input_id = self.next_input_id
        self.next_input_id += 1
        row = {"input_id": input_id, **payload}
        self.inputs[input_id] = row
        return row

    def get_feature_collection_inputs(self, **kwargs):
        self._record("get_feature_collection_inputs", **kwargs)
        rows = list(self.inputs.values())
        if kwargs.get("project_id") is not None:
            rows = [r for r in rows if r.get("project_id") == kwargs["project_id"]]
        if kwargs.get("feature_name") is not None:
            rows = [r for r in rows if r.get("feature_name") == kwargs["feature_name"]]
        if kwargs.get("entered_by_user_id") is not None:
            rows = [r for r in rows if r.get("entered_by_user_id") == kwargs["entered_by_user_id"]]
        return rows

    def get_feature_collection_input(self, input_id: int):
        self._record("get_feature_collection_input", input_id)
        return self.inputs[input_id]

    def update_feature_collection_input(self, input_id: int, payload: dict):
        self._record("update_feature_collection_input", input_id, payload)
        self.inputs[input_id].update(payload)
        return self.inputs[input_id]

    def delete_feature_collection_input(self, input_id: int):
        self._record("delete_feature_collection_input", input_id)
        del self.inputs[input_id]
        return {"message": "deleted"}

    def list_project_feature_collection_inputs(self, project_id: int):
        self._record("list_project_feature_collection_inputs", project_id)
        return [r for r in self.inputs.values() if r.get("project_id") == project_id]


def _patch_client(monkeypatch, fake_client: FakeClient) -> None:
    monkeypatch.setattr(
        "netgreener.cli.NetGreenerClient.from_credentials",
        classmethod(lambda cls: fake_client),
    )


def test_features_metadata_get(monkeypatch):
    fake = FakeClient()
    _patch_client(monkeypatch, fake)

    runner = CliRunner()
    result = runner.invoke(main, ["features", "metadata", "get", "7"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["project_id"] == 7
    assert fake.calls[0][0] == "get_project_feature_metadata"


def test_features_inputs_create(monkeypatch):
    fake = FakeClient()
    _patch_client(monkeypatch, fake)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "features",
            "inputs",
            "create",
            "11",
            "--feature-name",
            "avg_complexity",
            "--value",
            "0.42",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["project_id"] == 11
    assert payload["feature_name"] == "avg_complexity"
    assert fake.calls[0][0] == "post_feature_collection_input"


def test_features_inputs_list_filters(monkeypatch):
    fake = FakeClient()
    _patch_client(monkeypatch, fake)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "features",
            "inputs",
            "list",
            "--project-id",
            "5",
            "--feature-name",
            "f1",
            "--entered-by-user-id",
            "9",
        ],
    )

    assert result.exit_code == 0
    assert fake.calls[0][0] == "get_feature_collection_inputs"
    assert fake.calls[0][2] == {
        "project_id": 5,
        "feature_name": "f1",
        "entered_by_user_id": 9,
    }


def test_features_definitions_create_and_list(monkeypatch):
    fake = FakeClient()
    _patch_client(monkeypatch, fake)

    runner = CliRunner()
    create_result = runner.invoke(
        main,
        [
            "features",
            "definitions",
            "create",
            "test_feature_x",
            "--description",
            "temp",
            "--data-type",
            "float",
            "--source-type",
            "code",
            "--min-value",
            "0",
            "--max-value",
            "1",
        ],
    )
    assert create_result.exit_code == 0
    create_payload = json.loads(create_result.output)
    assert create_payload["feature_name"] == "test_feature_x"
    assert fake.calls[0][0] == "post_feature_definition"

    list_result = runner.invoke(
        main,
        ["features", "definitions", "list", "--data-type", "float", "--source-type", "code"],
    )
    assert list_result.exit_code == 0
    assert fake.calls[1][0] == "list_feature_definitions"
    assert fake.calls[1][2] == {"data_type": "float", "source_type": "code"}


def test_features_smoke_lifecycle(monkeypatch):
    fake = SmokeFakeClient()
    _patch_client(monkeypatch, fake)
    runner = CliRunner()

    # 1) definitions create/get/update/list
    create_def = runner.invoke(
        main,
        [
            "features",
            "definitions",
            "create",
            "smoke_feature_x",
            "--description",
            "smoke",
            "--data-type",
            "float",
            "--source-type",
            "code",
            "--min-value",
            "0",
            "--max-value",
            "10",
        ],
    )
    assert create_def.exit_code == 0
    get_def = runner.invoke(main, ["features", "definitions", "get", "smoke_feature_x"])
    assert get_def.exit_code == 0
    update_def = runner.invoke(
        main,
        ["features", "definitions", "update", "smoke_feature_x", "--description", "smoke-updated"],
    )
    assert update_def.exit_code == 0
    list_def = runner.invoke(
        main,
        ["features", "definitions", "list", "--data-type", "float", "--source-type", "code"],
    )
    assert list_def.exit_code == 0
    listed = json.loads(list_def.output)
    assert listed and listed[0]["feature_name"] == "smoke_feature_x"

    # 2) inputs create/list/get/update/delete
    create_input = runner.invoke(
        main,
        ["features", "inputs", "create", "2", "--feature-name", "smoke_feature_x", "--value", "0.42"],
    )
    assert create_input.exit_code == 0
    created_input = json.loads(create_input.output)
    input_id = created_input["input_id"]

    list_inputs = runner.invoke(main, ["features", "inputs", "list", "--project-id", "2"])
    assert list_inputs.exit_code == 0
    assert len(json.loads(list_inputs.output)) == 1

    get_input = runner.invoke(main, ["features", "inputs", "get", str(input_id)])
    assert get_input.exit_code == 0
    update_input = runner.invoke(
        main, ["features", "inputs", "update", str(input_id), "--value", "0.43"]
    )
    assert update_input.exit_code == 0
    delete_input = runner.invoke(main, ["features", "inputs", "delete", str(input_id), "-y"])
    assert delete_input.exit_code == 0

    # 3) cleanup definition
    delete_def = runner.invoke(main, ["features", "definitions", "delete", "smoke_feature_x", "-y"])
    assert delete_def.exit_code == 0


class ErrorFakeClient:
    """Fake that raises API-style failures for negative-path tests."""

    def __init__(self, exc: APIError) -> None:
        self.exc = exc

    def get_project_feature_metadata(self, _project_id: int):
        raise self.exc

    def post_feature_definition(self, _payload: dict):
        raise self.exc

    def delete_feature_definition(self, _feature_name: str):
        raise self.exc


def test_features_metadata_get_handles_404(monkeypatch):
    fake = ErrorFakeClient(APIError(404, "Project not found"))
    _patch_client(monkeypatch, fake)
    runner = CliRunner()
    result = runner.invoke(main, ["features", "metadata", "get", "1"])
    assert result.exit_code == 1
    assert "HTTP 404" in result.output


def test_features_definitions_create_handles_403(monkeypatch):
    fake = ErrorFakeClient(APIError(403, "Developer or admin access required"))
    _patch_client(monkeypatch, fake)
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "features",
            "definitions",
            "create",
            "nope_feature",
            "--data-type",
            "float",
        ],
    )
    assert result.exit_code == 1
    assert "HTTP 403" in result.output


def test_features_definitions_delete_handles_400(monkeypatch):
    fake = ErrorFakeClient(APIError(400, "Cannot delete feature definition: 1 inputs are using it"))
    _patch_client(monkeypatch, fake)
    runner = CliRunner()
    result = runner.invoke(main, ["features", "definitions", "delete", "f1", "-y"])
    assert result.exit_code == 1
    assert "HTTP 400" in result.output
