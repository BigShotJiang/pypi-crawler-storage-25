# netgreener CLI

Command-line client for NetGreener run analysis, upload, and feature registry APIs.

## Install

From this folder:

```bash
pip install -e .
```

## Quick start

```bash
netgreener login --email you@example.com
netgreener status
netgreener config
```

## Features API commands

These commands wrap `api_server/routers/features.py` under `/api/v1/features`.

### 1) Project feature metadata (artifact pointer)

Use this to register the project-level path/URI for extracted features (e.g. Parquet or JSON bundle pointer).

```bash
netgreener features metadata get 1
netgreener features metadata register 1 --parquet-path /data/features.parquet --feature-version 1
netgreener features metadata update 1 --parquet-path /data/features_v2.parquet
netgreener features metadata delete 1 -y
```

### 2) Feature collection inputs (`featurecollectioninput`)

```bash
netgreener features inputs list --project-id 1
netgreener features inputs list-project 1
netgreener features inputs create 1 --feature-name avg_complexity --value 0.42
netgreener features inputs get 123
netgreener features inputs update 123 --value 0.43
netgreener features inputs delete 123 -y
```

### 3) Feature definitions (`featuredefinition`)

```bash
netgreener features definitions list --data-type float --source-type code
netgreener features definitions create test_feature_x --description "temp" --data-type float --source-type code --min-value 0 --max-value 1
netgreener features definitions get test_feature_x
netgreener features definitions update test_feature_x --description "temp2" --max-value 10
netgreener features definitions delete test_feature_x -y
```

## Auth / role notes

- `GET` endpoints generally require an authenticated active user with access.
- write operations (`POST`/`PUT`/`DELETE`) in features routes require **developer** or **admin**.

## Related docs

- `../docs/API_ENDPOINTS_CLI_IDE.md`
- `../docs/CODEANALYZER_TO_API_SURFACE.md`
- `../docs/PLAN_INDEX.md`

## SDK delegation note

The CLI API client (`netgreener/api_client.py`) delegates to `netgreener_sdk` when that package is available in the environment, while keeping HTTP fallback for compatibility with existing setups.

## Smoke test (end-to-end features flow)

Use one existing project id and a temporary feature name.

```bash
# 0) prerequisites
netgreener status
netgreener features metadata get 2

# 1) feature definition lifecycle
netgreener features definitions create smoke_feature_x --description "smoke" --data-type float --source-type code --min-value 0 --max-value 10
netgreener features definitions get smoke_feature_x
netgreener features definitions update smoke_feature_x --description "smoke-updated" --max-value 100
netgreener features definitions list --data-type float --source-type code

# 2) feature input lifecycle (for an existing project, e.g. 2)
netgreener features inputs create 2 --feature-name smoke_feature_x --value 0.42
netgreener features inputs list --project-id 2
# Capture input_id from output, then:
netgreener features inputs get <input_id>
netgreener features inputs update <input_id> --value 0.43
netgreener features inputs delete <input_id> -y

# 3) cleanup definition (must be after deleting all inputs that reference it)
netgreener features definitions delete smoke_feature_x -y
```

Expected outcomes:
- create/get/update/list commands return JSON objects/lists (HTTP 200/201 paths)
- delete commands return success payloads
- deleting a definition before deleting referencing inputs returns HTTP 400 by design

### Automated smoke test (one command)

```bash
python -m pytest tests/test_features_cli.py -k smoke_lifecycle -q
```

### Automated failure-path tests (one command)

```bash
python -m pytest tests/test_features_cli.py -k "handles_" -q
```

## PyPI publish (release maintainer)

PyPI distribution name is **`netgreener`** (see `pyproject.toml` `[project] name`).

Before tagging a release:

```bash
python -m pip install --upgrade pip
python -m pip install build twine
python -m build netgreener_cli
python -m twine check netgreener_cli/dist/*
```

Azure DevOps publishes on tags `cli-v*.*.*` via `azure-pipelines-cli-publish.yml`, using the same `PYPI_API_TOKEN` secret as the SDK publish pipeline (Library variable group `Package_credential`).
