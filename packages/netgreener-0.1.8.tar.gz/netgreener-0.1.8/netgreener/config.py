"""
Reads CLI configuration from ~/.netgreener/config.json or environment variables.
"""

import json
import os
from pathlib import Path

_CONFIG_DIR = Path.home() / ".netgreener"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_CREDENTIALS_FILE = _CONFIG_DIR / "credentials.json"
_API_URL_KEY = "api_url"
_ORG_ID_KEY = "organization_id"
_ENV_KEY = "environment"
_DEFAULT_API_URL = "https://netgreener.eastus2.cloudapp.azure.com"
DASHBOARD_URL = "https://dashboard.netgreener.com"


def _ensure_dir() -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _read_config() -> dict:
    try:
        return json.loads(_CONFIG_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _write_config(data: dict) -> None:
    _ensure_dir()
    tmp = _CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(_CONFIG_FILE)


def get_api_url() -> str:
    if url := os.environ.get("NETGREENER_API_URL"):
        return url.rstrip("/")
    return _read_config().get(_API_URL_KEY, _DEFAULT_API_URL).rstrip("/")


def save_api_url(url: str) -> None:
    data = _read_config()
    data[_API_URL_KEY] = url
    _write_config(data)


def get_organization_id() -> int | None:
    env_value = os.environ.get("NETGREENER_ORG_ID")
    if env_value:
        try:
            return int(env_value)
        except ValueError:
            return None
    value = _read_config().get(_ORG_ID_KEY)
    return int(value) if isinstance(value, int) or (isinstance(value, str) and value.isdigit()) else None


def get_environment() -> str:
    env_value = os.environ.get("NETGREENER_ENV")
    if env_value in {"dev", "staging", "prod"}:
        return env_value
    value = _read_config().get(_ENV_KEY, "dev")
    return value if value in {"dev", "staging", "prod"} else "dev"


def save_org_context(organization_id: int | None, environment: str = "dev") -> None:
    data = _read_config()
    if organization_id is None:
        data.pop(_ORG_ID_KEY, None)
    else:
        data[_ORG_ID_KEY] = organization_id
    data[_ENV_KEY] = environment if environment in {"dev", "staging", "prod"} else "dev"
    _write_config(data)


def load_credentials() -> dict | None:
    if token := os.environ.get("NETGREENER_TOKEN"):
        return {"access_token": token, "user": {}}
    try:
        return json.loads(_CREDENTIALS_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def save_credentials(token: str, user: dict) -> None:
    _ensure_dir()
    _CREDENTIALS_FILE.write_text(json.dumps({"access_token": token, "user": user}, indent=2))
    try:
        _CREDENTIALS_FILE.chmod(0o600)
    except NotImplementedError:
        pass  # Windows does not support POSIX permissions


def clear_credentials() -> None:
    try:
        _CREDENTIALS_FILE.unlink()
    except FileNotFoundError:
        pass


# ---------------------------------------------------------------------------
# User LLM config — stored in config.json; overridable via env vars
# ---------------------------------------------------------------------------

_LLM_PROVIDER_KEY = "llm_provider"
_LLM_KEY_KEY = "llm_key"
_LLM_ENDPOINT_KEY = "llm_endpoint"
_LLM_MODEL_KEY = "llm_model"

SUPPORTED_LLM_PROVIDERS = ("azure_openai", "openai", "anthropic", "ollama", "custom")


def get_user_llm_config() -> dict | None:
    """Return user-provided LLM config from env vars or config.json, or None if not configured.

    Env vars (take priority): NETGREENER_LLM_PROVIDER, NETGREENER_LLM_KEY,
    NETGREENER_LLM_ENDPOINT, NETGREENER_LLM_MODEL.
    """
    provider = os.environ.get("NETGREENER_LLM_PROVIDER") or _read_config().get(_LLM_PROVIDER_KEY)
    if not provider:
        return None
    cfg = _read_config()
    key = os.environ.get("NETGREENER_LLM_KEY") or cfg.get(_LLM_KEY_KEY, "")
    endpoint = os.environ.get("NETGREENER_LLM_ENDPOINT") or cfg.get(_LLM_ENDPOINT_KEY, "")
    model = os.environ.get("NETGREENER_LLM_MODEL") or cfg.get(_LLM_MODEL_KEY, "")
    if not model:
        return None
    return {"provider": provider, "key": key, "endpoint": endpoint, "model": model}


def save_user_llm_config(
    provider: str,
    key: str = "",
    endpoint: str = "",
    model: str = "",
) -> None:
    data = _read_config()
    data[_LLM_PROVIDER_KEY] = provider
    data[_LLM_KEY_KEY] = key
    data[_LLM_ENDPOINT_KEY] = endpoint
    data[_LLM_MODEL_KEY] = model
    _write_config(data)


def clear_user_llm_config() -> None:
    data = _read_config()
    for k in [_LLM_PROVIDER_KEY, _LLM_KEY_KEY, _LLM_ENDPOINT_KEY, _LLM_MODEL_KEY]:
        data.pop(k, None)
    _write_config(data)
