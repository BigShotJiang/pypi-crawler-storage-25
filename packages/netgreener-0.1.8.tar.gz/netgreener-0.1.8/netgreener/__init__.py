"""
netgreener — public API for use inside ML training scripts.

Usage inside a user's train.py:
    import netgreener as ng
    ng.log_metrics(accuracy=0.95, f1=0.88, precision=0.90, recall=0.87, auc=0.96)
"""

import json
import os
import socket


def log_metrics(
    accuracy: float | None = None,
    f1: float | None = None,
    precision: float | None = None,
    recall: float | None = None,
    auc: float | None = None,
    **extra: float,
) -> None:
    """
    Report accuracy metrics back to the NetGreener CLI runner.
    Call this anywhere in your script after evaluation is complete.
    Safe to call even when not running under netgreener (silently no-ops).
    """
    port_str = os.environ.get("NETGREENER_METRICS_PORT")
    if not port_str:
        return

    payload: dict = {}
    if accuracy is not None:
        payload["model_accuracy"] = accuracy
    if f1 is not None:
        payload["f1_score"] = f1
    if precision is not None:
        payload["model_precision"] = precision
    if recall is not None:
        payload["recall"] = recall
    if auc is not None:
        payload["auc_score"] = auc
    payload.update(extra)

    if not payload:
        return

    try:
        with socket.create_connection(("127.0.0.1", int(port_str)), timeout=2) as s:
            s.sendall(json.dumps(payload).encode())
    except OSError:
        pass
