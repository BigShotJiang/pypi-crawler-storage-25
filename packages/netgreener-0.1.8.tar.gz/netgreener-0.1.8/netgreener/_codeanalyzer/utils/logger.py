import json
import logging
import time
import logging.handlers
import socket


class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "level": record.levelname,
            "message": record.getMessage(),
            "name": record.name,
            "module": record.module,
            "funcName": record.funcName,
            "user_id": getattr(record, "user_id", None),
            "session_id": getattr(record, "session_id", None),
            "error_code": getattr(record, "error_code", None),
            "timestamp": time.time(),
        }
        return json.dumps(log_record)


class JsonSocketHandler(logging.handlers.SocketHandler):
    def __init__(self, host, port, timeout=0.1):
        super().__init__(host, port)
        self.timeout = timeout

    def makeSocket(self):
        s = socket.create_connection((self.host, self.port), timeout=self.timeout)
        return s

    def makePickle(self, record):
        return self.formatter.format(record).encode("utf-8") + b"\n"


singleton_logger = None


def setup_logging():
    global singleton_logger

    if singleton_logger is not None:
        return singleton_logger

    logger = logging.getLogger("NetGreener")
    logger.setLevel(logging.INFO)

    try:
        socket_handler = JsonSocketHandler("localhost", logging.handlers.DEFAULT_TCP_LOGGING_PORT)
        socket_handler.setFormatter(JsonFormatter())
        logger.addHandler(socket_handler)
    except Exception:
        pass

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(module)s - %(funcName)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(stream_handler)

    singleton_logger = logger
    return logger
