from enum import Enum


class ErrorCode(Enum):
    Normal = 0
    SyntaxError = 1
    UnknownError = 2
    IOError = 3
