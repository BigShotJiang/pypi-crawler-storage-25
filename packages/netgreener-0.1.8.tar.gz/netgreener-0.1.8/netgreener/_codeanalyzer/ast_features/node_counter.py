import ast
import tokenize

from netgreener._codeanalyzer.utils.logger import setup_logging
from netgreener._codeanalyzer.utils.error_codes import ErrorCode
from netgreener._codeanalyzer.ast_features.ast_base_analysis import AstBaseAnalyzer

logger = setup_logging()


class NodeCounter:
    def __init__(self, base_analyzer: AstBaseAnalyzer):
        self.base_analyzer = base_analyzer
        self.source_code = base_analyzer.source_code
        self.parsed_code = base_analyzer.parsed_code

    def count_specific_node_type(self, node_type):
        return sum(1 for node in ast.walk(self.base_analyzer.parsed_code) if isinstance(node, node_type))

    def depth_of_ast(self):
        def calculate_depth(node):
            if isinstance(node, ast.AST):
                children = list(ast.iter_child_nodes(node))
                if not children:
                    return 1
                return 1 + max(calculate_depth(c) for c in children)
            return 0
        return calculate_depth(self.parsed_code)

    def count_lines_of_code(self):
        return len([
            line for line in self.source_code.strip().split("\n")
            if line.strip() and not line.strip().startswith("#")
        ])

    def count_tokens(self):
        return len(list(self.base_analyzer.get_tokens())) - 1

    def count_node(self):
        return len(list(ast.walk(self.base_analyzer.parsed_code)))

    def count_imports(self):
        return self.count_specific_node_type(ast.Import) + self.count_specific_node_type(ast.ImportFrom)

    def count_expression_nodes(self):
        return self.count_specific_node_type(ast.Expr)

    def count_assignment_nodes(self):
        return self.count_specific_node_type(ast.Assign)

    def count_binary_operation_nodes(self):
        return self.count_specific_node_type(ast.BinOp)

    def count_unary_operation_nodes(self):
        return self.count_specific_node_type(ast.UnaryOp)

    def count_class_nodes(self):
        return self.count_specific_node_type(ast.ClassDef)

    def count_function_nodes(self):
        return (self.count_specific_node_type(ast.FunctionDef)
                + self.count_specific_node_type(ast.AsyncFunctionDef))

    def count_call_function_nodes(self):
        return self.count_specific_node_type(ast.Call)

    def count_control_flow_nodes(self):
        return (self.count_specific_node_type(ast.For)
                + self.count_specific_node_type(ast.While)
                + self.count_specific_node_type(ast.If)
                + self.count_specific_node_type(ast.IfExp)
                + self.count_specific_node_type(ast.AsyncFor))

    def count_exception_handling_nodes(self):
        return self.count_specific_node_type(ast.Try)

    def count_lambda_function_nodes(self):
        return self.count_specific_node_type(ast.Lambda)
