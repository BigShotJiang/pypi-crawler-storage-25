from radon.raw import analyze
from radon.complexity import cc_visit, cc_rank
from radon.metrics import h_visit, mi_visit, mi_rank

from netgreener._codeanalyzer.utils.logger import setup_logging
from netgreener._codeanalyzer.ast_features.ast_base_analysis import AstBaseAnalyzer

logger = setup_logging()


class MetricsCalculator:
    def __init__(self, base_analyzer: AstBaseAnalyzer):
        self.base_analyzer = base_analyzer
        self.source_code = base_analyzer.source_code
        self.parsed_code = base_analyzer.parsed_code

    def calculate_raw_metrics(self):
        return analyze(self.source_code)

    def calculate_cyclomatic_complexity(self):
        return [
            (result.name, result.complexity, cc_rank(result.complexity))
            for result in cc_visit(self.source_code)
        ]

    def calculate_maintainability_index_rank(self):
        mi = mi_visit(self.source_code, multi=False)
        return mi, mi_rank(mi)

    def calculate_halstead_metrics(self):
        return h_visit(self.source_code)
