import ast

from netgreener._codeanalyzer.ast_features.ast_base_analysis import AstBaseAnalyzer


class NodeDetailExtractor:
    def __init__(self, base_analyzer: AstBaseAnalyzer):
        self.base_analyzer = base_analyzer
        self.parsed_code = base_analyzer.parsed_code

    def import_nodes_detail(self):
        import_details = []
        for node in ast.walk(self.base_analyzer.parsed_code):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    import_details.append((alias.name, alias.asname if alias.asname else None))
            elif isinstance(node, ast.ImportFrom):
                module_name = node.module
                for alias in node.names:
                    import_details.append((module_name, alias.asname if alias.asname else alias.name))
        return import_details
