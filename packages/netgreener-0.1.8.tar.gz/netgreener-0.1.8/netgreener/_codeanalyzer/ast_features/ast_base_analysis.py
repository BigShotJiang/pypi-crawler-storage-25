import ast
import tokenize
from io import BytesIO

from netgreener._codeanalyzer.utils.logger import setup_logging

logger = setup_logging()


class AstBaseAnalyzer:
    def __init__(self, source_code):
        self.source_code = source_code
        self.parsed_code = self._parse_source_code()

    def _parse_source_code(self):
        try:
            return ast.parse(self.source_code)
        except Exception:
            raise SyntaxError("parse source code has been failed")

    def get_tokens(self):
        return tokenize.tokenize(BytesIO(self.source_code.encode("utf-8")).readline)

    def extract_comments(self):
        comments = []
        for token in self.get_tokens():
            if token.type == tokenize.COMMENT:
                comments.append(token.string.strip())
        return comments, len(comments)
