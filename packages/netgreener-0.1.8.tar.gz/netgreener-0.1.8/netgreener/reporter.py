"""
Formats and prints run results to the terminal using Rich.
"""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from .constants import CO2_KG_PER_KWH
from .executor import RunResult

console = Console()


def print_run_report(result: RunResult, project_summary: dict, script_name: str) -> None:
    console.print()

    # --- Resource metrics ---
    res_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    res_table.add_column("Metric", style="bold cyan")
    res_table.add_column("Value", style="white")

    res_table.add_row("Duration", f"{result.duration_seconds:.1f}s")
    res_table.add_row("CPU (avg, pkg)", f"{result.cpu_percent_avg:.1f}%")
    res_table.add_row("RAM (peak)", f"{result.ram_gb_peak:.3f} GB")
    res_table.add_row("RAM (avg)", f"{result.ram_gb_avg:.3f} GB")
    if result.gpu_utilization_avg > 0:
        res_table.add_row("GPU (avg)", f"{result.gpu_utilization_avg:.1f}%")
        res_table.add_row("GPU mem (peak)", f"{result.gpu_memory_peak_gb:.3f} GB")
    if result.io_bytes_total > 0:
        io_mb = result.io_bytes_total / (1024 ** 2)
        res_table.add_row("IO (total)", f"{io_mb:.1f} MB")
    res_table.add_row("Energy", f"{result.energy_kwh:.6f} kWh")
    res_table.add_row("Carbon", f"{result.energy_kwh * CO2_KG_PER_KWH * 1000:.4f} g CO2")

    console.print(Panel(res_table, title=f"[bold green]Run: {script_name}[/]", expand=False))

    # --- Accuracy metrics (if reported) ---
    if result.accuracy_metrics:
        acc_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        acc_table.add_column("Metric", style="bold yellow")
        acc_table.add_column("Value", style="white")
        label_map = {
            "model_accuracy": "Accuracy",
            "f1_score": "F1 Score",
            "model_precision": "Precision",
            "recall": "Recall",
            "auc_score": "AUC",
        }
        for key, label in label_map.items():
            if key in result.accuracy_metrics:
                acc_table.add_row(label, f"{result.accuracy_metrics[key]:.4f}")
        console.print(Panel(acc_table, title="[bold yellow]Model Metrics[/]", expand=False))

    # --- Code analysis ---
    if project_summary and not project_summary.get("errors"):
        code_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        code_table.add_column("Metric", style="bold magenta")
        code_table.add_column("Value", style="white")
        code_table.add_row("Files analyzed", str(project_summary.get("file_count", 0)))
        code_table.add_row("Total LOC", str(project_summary.get("total_lines_of_code", 0)))
        code_table.add_row("Avg complexity", str(project_summary.get("avg_cyclomatic_complexity", 0)))
        domains = project_summary.get("library_domains", [])
        if domains:
            code_table.add_row("Domains", ", ".join(domains))
        console.print(Panel(code_table, title="[bold magenta]Code Analysis[/]", expand=False))

    exit_style = "green" if result.exit_code == 0 else "red"
    console.print(f"\n[{exit_style}]Exit code: {result.exit_code}[/]\n")


def print_login_success(user: dict) -> None:
    console.print(f"[green]Logged in as[/] [bold]{user.get('name', user.get('email'))}[/] "
                  f"([dim]{user.get('role', '')}[/dim])")


def print_error(msg: str) -> None:
    console.print(f"[red]Error:[/] {msg}")


def print_info(msg: str) -> None:
    console.print(f"[cyan]{msg}[/]")
