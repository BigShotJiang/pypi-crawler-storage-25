"""
Local TCP server that receives ng.log_metrics() calls from the user's running script.

The CLI starts this server before launching the script and injects the port via
NETGREENER_METRICS_PORT. The user-facing netgreener.log_metrics() connects to it.
"""

import json
import socket
import threading
from typing import Callable


class MetricsServer:
    """Listens on a loopback TCP port for metric payloads from the child process."""

    def __init__(self, on_metrics: Callable[[dict], None]):
        self._on_metrics = on_metrics
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind(("127.0.0.1", 0))
        self._server.listen(5)
        self._server.settimeout(0.5)
        self.port: int = self._server.getsockname()[1]
        self._running = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._running = True
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        try:
            self._server.close()
        except OSError:
            pass

    def _serve(self) -> None:
        while self._running:
            try:
                conn, _ = self._server.accept()
            except (socket.timeout, OSError):
                continue
            try:
                conn.settimeout(5.0)
                data = bytearray()
                try:
                    while chunk := conn.recv(4096):
                        data += chunk
                except socket.timeout:
                    pass
                payload = json.loads(bytes(data).decode())
                self._on_metrics(payload)
            except Exception:
                pass
            finally:
                conn.close()
