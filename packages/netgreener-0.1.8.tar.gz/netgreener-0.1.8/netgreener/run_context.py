"""
Run execution context (v0) for attribution and dashboard filtering.

Embedded in:
- ``runsession.session_metadata["run_context"]`` for ``netgreener run`` uploads
- ``surrogatetrainingdata.features["run_context"]`` for ``netgreener analyze`` uploads

No DB migration required (JSON fields already exist).
"""

from __future__ import annotations

import hashlib
import os
import platform
from datetime import datetime, timezone
from typing import Any


def _detect_ci() -> bool:
    return bool(
        os.environ.get("CI")
        or os.environ.get("GITHUB_ACTIONS")
        or os.environ.get("GITLAB_CI")
        or os.environ.get("BUILD_BUILDID")
        or os.environ.get("TF_BUILD")  # Azure DevOps
    )


def build_run_context_v0(
    *,
    client: str,
    script_path: str = "",
    project_dir: str = "",
    no_llm: bool = False,
    hardware_snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Build a small, stable dict for JSON storage.

    ``client``: e.g. ``\"netgreener_cli_run\"`` or ``\"netgreener_cli_analyze\"``.
    """
    host = platform.node() or "unknown"
    fingerprint = hashlib.sha256(host.encode("utf-8", errors="replace")).hexdigest()[:16]
    ci = _detect_ci()
    ctx: dict[str, Any] = {
        "schema_version": 1,
        "client": client,
        "environment_type": "ci" if ci else "local_cli",
        "resource_scope": "single_process",
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "host_fingerprint": fingerprint,
        "no_llm_flag": no_llm,
    }
    if os.environ.get("SSH_CONNECTION"):
        ctx["ssh_session"] = True
    if script_path:
        ctx["script_basename"] = os.path.basename(str(script_path).replace("\\", "/"))
    if project_dir:
        ctx["project_dir_basename"] = os.path.basename(
            os.path.normpath(str(project_dir).replace("\\", "/"))
        )
    ctx["recorded_at_utc"] = datetime.now(timezone.utc).isoformat()
    if hardware_snapshot:
        ctx["hardware_snapshot"] = hardware_snapshot
    return ctx
