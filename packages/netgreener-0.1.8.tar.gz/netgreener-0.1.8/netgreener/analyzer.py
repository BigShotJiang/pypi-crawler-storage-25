"""
Headless code analysis — wraps CodeAnalyzer without any PyQt5 dependency.
Extracts AST features, Halstead metrics, raw Radon metrics, library domains,
and derives resource-risk Finding records for the supervisor dashboard.
"""

import re
from pathlib import Path
from typing import Any

_LIBRARY_DOMAINS: dict[str, str] = {
    # Computer vision
    "cv2": "computer_vision",
    "PIL": "computer_vision",
    "Pillow": "computer_vision",
    "skimage": "computer_vision",
    "torchvision": "computer_vision",
    "imageio": "computer_vision",
    "albumentations": "computer_vision",
    # Deep learning
    "tensorflow": "deep_learning",
    "tf": "deep_learning",
    "keras": "deep_learning",
    "torch": "deep_learning",
    "jax": "deep_learning",
    "flax": "deep_learning",
    "paddle": "deep_learning",
    "mxnet": "deep_learning",
    "fastai": "deep_learning",
    "lightning": "deep_learning",
    "pytorch_lightning": "deep_learning",
    # Classical ML
    "sklearn": "classical_ml",
    "xgboost": "classical_ml",
    "lightgbm": "classical_ml",
    "catboost": "classical_ml",
    "statsmodels": "classical_ml",
    # NLP
    "transformers": "nlp",
    "spacy": "nlp",
    "nltk": "nlp",
    "gensim": "nlp",
    "sentence_transformers": "nlp",
    # Data
    "pandas": "data",
    "numpy": "data",
    "scipy": "data",
    "polars": "data",
    "pyarrow": "data",
    # Visualization
    "matplotlib": "visualization",
    "seaborn": "visualization",
    "plotly": "visualization",
}

_SUSPECT_SECRET_NAME_RE = re.compile(
    r"(secret|api[_-]?key|access[_-]?key|private[_-]?key|token|password|passwd|credential)",
    re.IGNORECASE,
)
_PLACEHOLDER_SECRET_VALUE_RE = re.compile(
    r"^(example|sample|dummy|test|changeme|your[_-]?key|xxx+|<.*>)$",
    re.IGNORECASE,
)


def _detect_domains(imports_detail: list[tuple]) -> list[str]:
    domains: set[str] = set()
    for module, _ in imports_detail:
        if module:
            root = module.split(".")[0]
            if domain := _LIBRARY_DOMAINS.get(root):
                domains.add(domain)
    return sorted(domains)


def _scan_hardcoded_secret_candidates(source_code: str) -> tuple[int, list[str]]:
    """
    Detect likely hardcoded secret assignments from source text.
    Conservative heuristic: suspicious variable name + non-trivial string literal.
    """
    count = 0
    refs: list[str] = []
    assign_re = re.compile(
        r"""^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(['"])([^'"]+)\2""",
        re.MULTILINE,
    )
    for m in assign_re.finditer(source_code):
        name = m.group(1)
        value = m.group(3).strip()
        if not _SUSPECT_SECRET_NAME_RE.search(name):
            continue
        if len(value) < 8:
            continue
        if _PLACEHOLDER_SECRET_VALUE_RE.match(value):
            continue
        count += 1
        refs.append(name)
    # Keep payload small and deterministic.
    return count, refs[:5]


def _safe_halstead(h) -> dict[str, float]:
    """Extract scalar Halstead fields defensively — radon's return type varies by version."""
    try:
        # h_visit may return a namedtuple or an object with a .total attribute
        src = h.total if hasattr(h, "total") else h
        return {
            "halstead_vocabulary": int(getattr(src, "vocabulary", 0)),
            "halstead_length": int(getattr(src, "length", 0)),
            "halstead_volume": round(float(getattr(src, "volume", 0.0)), 2),
            "halstead_difficulty": round(float(getattr(src, "difficulty", 0.0)), 2),
            "halstead_effort": round(float(getattr(src, "effort", 0.0)), 2),
            "halstead_bugs": round(float(getattr(src, "bugs", 0.0)), 4),
        }
    except Exception:
        return {k: 0 for k in ("halstead_vocabulary", "halstead_length",
                               "halstead_volume", "halstead_difficulty",
                               "halstead_effort", "halstead_bugs")}


def detect_code_patterns(features: dict[str, Any], file_path: str, project_id: int) -> list[dict]:
    """Map per-file AST metrics to Finding records for the supervisor dashboard."""
    return detect_findings(features, file_path, project_id)


def detect_findings(features: dict[str, Any], file_path: str, project_id: int) -> list[dict]:
    """Map per-file AST metrics to resource-risk Finding records."""
    findings: list[dict] = []

    source_code: str = features.get("_source_code", "")
    loc = features.get("lines_of_code", 0)
    max_cc = features.get("max_cyclomatic_complexity", 0)
    depth = features.get("depth_of_ast", 0)
    hardcoded_secret_count = features.get("hardcoded_secret_candidate_count", 0)
    hardcoded_secret_refs = features.get("hardcoded_secret_candidate_refs", [])

    def _finding(
        issue_type: str,
        severity: str,
        optimization_category: str,
        resource_impact: list[str],
        description: str,
        recommendation: str,
        expected_impact: str,
        verification: str,
        fix_risk_level: str = "low",
        line_start: int | None = None,
        line_end: int | None = None,
        code_snippet: str | None = None,
        confidence: float = 0.8,
        requires_benchmark: bool = False,
        requires_accuracy_check: bool = False,
    ) -> dict:
        return {
            "project_id": project_id,
            "file_path": file_path,
            "issue_type": issue_type,
            "severity": severity,
            "optimization_category": optimization_category,
            "resource_impact": resource_impact,
            "description": description,
            "recommendation": recommendation,
            "expected_impact": expected_impact,
            "verification": verification,
            "fix_risk_level": fix_risk_level,
            "line_start": line_start,
            "line_end": line_end,
            "code_snippet": code_snippet,
            "confidence": confidence,
            "requires_benchmark": requires_benchmark,
            "requires_accuracy_check": requires_accuracy_check,
            "detection_source": "rule_based",
        }

    # --- iterrows_loop ---
    if source_code and re.search(r"\.iterrows\(\)", source_code):
        line_no = next(
            (i + 1 for i, ln in enumerate(source_code.splitlines()) if ".iterrows()" in ln),
            None,
        )
        findings.append(_finding(
            issue_type="iterrows_loop",
            severity="high",
            optimization_category="cpu",
            resource_impact=["cpu", "ram"],
            description="DataFrame.iterrows() iterates row-by-row in Python, bypassing vectorised NumPy kernels and causing severe CPU and RAM overhead at scale.",
            recommendation="Replace with vectorised operations (.apply(), numpy ufuncs, or pandas built-ins). For row-wise logic use df.itertuples() as a minimal improvement.",
            expected_impact="10–100× speed-up and proportional CPU reduction on large DataFrames.",
            verification="Profile with cProfile or line_profiler before and after; confirm wall-clock time drops without accuracy change.",
            fix_risk_level="low",
            line_start=line_no,
            confidence=0.9,
        ))

    # --- model_load_in_loop ---
    if source_code:
        _model_load_re = re.compile(
            r"(torch\.load|load_model|from_pretrained|joblib\.load|pickle\.load)\s*\(",
            re.IGNORECASE,
        )
        _loop_kw_re = re.compile(r"^\s*(for |while )", re.MULTILINE)
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if _loop_kw_re.match(ln):
                in_loop = True
            if in_loop and _model_load_re.search(ln):
                findings.append(_finding(
                    issue_type="model_load_in_loop",
                    severity="critical",
                    optimization_category="io",
                    resource_impact=["cpu", "ram", "io"],
                    description="A model or large artifact is loaded inside a loop, causing repeated disk I/O and memory churn on every iteration.",
                    recommendation="Load the model once before the loop and reuse the in-memory object.",
                    expected_impact="Eliminates redundant I/O; reduces per-iteration latency by the cost of a full model load.",
                    verification="Add a load counter or log; confirm model is loaded exactly once per process.",
                    fix_risk_level="low",
                    line_start=i + 1,
                    confidence=0.85,
                ))
                break  # one finding per file

    # --- inference_inside_loop ---
    if source_code:
        _infer_re = re.compile(r"\.(predict|forward|__call__)\s*\(", re.IGNORECASE)
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
            if in_loop and _infer_re.search(ln):
                findings.append(_finding(
                    issue_type="inference_inside_loop",
                    severity="high",
                    optimization_category="gpu",
                    resource_impact=["gpu", "cpu"],
                    description="Model inference is called per-sample inside a loop instead of being batched, under-utilising GPU parallelism.",
                    recommendation="Collect samples into a batch and call the model once per batch.",
                    expected_impact="GPU utilisation improvement of 2–10×; proportional throughput gain.",
                    verification="Measure samples/second before and after batching; GPU utilisation should rise significantly.",
                    fix_risk_level="medium",
                    line_start=i + 1,
                    confidence=0.8,
                    requires_accuracy_check=True,
                ))
                break

    # --- no_early_stopping (training scripts only) ---
    if source_code:
        has_fit = bool(re.search(r"\.(fit|train)\s*\(", source_code))
        has_early_stop = bool(re.search(r"early.?stop", source_code, re.IGNORECASE))
        if has_fit and not has_early_stop:
            findings.append(_finding(
                issue_type="no_early_stopping",
                severity="medium",
                optimization_category="ml_training",
                resource_impact=["cpu", "gpu"],
                description="Training loop has no early-stopping callback, so training continues past convergence wasting compute.",
                recommendation="Add an EarlyStopping callback (Keras, PyTorch Lightning, or manual validation loss check).",
                expected_impact="Reduces total epochs by 10–50% on typical workloads.",
                verification="Compare total epochs run and final validation metric with and without early stopping.",
                fix_risk_level="low",
                confidence=0.75,
                requires_benchmark=True,
                requires_accuracy_check=True,
            ))

    # --- no_lr_scheduler ---
    if source_code:
        has_optimizer = bool(re.search(r"(Adam|SGD|RMSprop|Adagrad|Adamax)\s*\(", source_code))
        has_scheduler = bool(re.search(r"(lr_scheduler|ReduceLROnPlateau|StepLR|CosineAnneal|scheduler)", source_code, re.IGNORECASE))
        if has_optimizer and not has_scheduler:
            findings.append(_finding(
                issue_type="no_lr_scheduler",
                severity="low",
                optimization_category="ml_training",
                resource_impact=["gpu", "cpu"],
                description="Optimizer is used without a learning-rate scheduler; a fixed LR can slow convergence and require more epochs.",
                recommendation="Add a scheduler such as ReduceLROnPlateau or CosineAnnealingLR.",
                expected_impact="Faster convergence; fewer total epochs needed to reach the same validation loss.",
                verification="Track validation loss curve; convergence epoch should decrease.",
                fix_risk_level="low",
                confidence=0.7,
                requires_benchmark=True,
                requires_accuracy_check=True,
            ))

    # --- no_mixed_precision ---
    if source_code:
        has_training = bool(re.search(r"\.(fit|train)\s*\(|torch\.nn\.", source_code))
        has_amp = bool(re.search(r"(autocast|GradScaler|mixed.precision|fp16|amp)", source_code, re.IGNORECASE))
        if has_training and not has_amp:
            findings.append(_finding(
                issue_type="no_mixed_precision",
                severity="medium",
                optimization_category="gpu",
                resource_impact=["gpu", "ram"],
                description="Training uses full FP32 precision; mixed precision (FP16/BF16) would halve GPU memory and increase throughput on modern hardware.",
                recommendation="Wrap the training step with torch.cuda.amp.autocast() or set precision='16-mixed' in PyTorch Lightning.",
                expected_impact="Up to 2× throughput improvement and ~50% GPU memory reduction on Ampere/Turing GPUs.",
                verification="Compare iterations/second and peak GPU memory with and without AMP.",
                fix_risk_level="medium",
                confidence=0.7,
                requires_benchmark=True,
                requires_accuracy_check=True,
            ))

    # --- full_dataset_in_memory ---
    if source_code:
        _mem_load_re = re.compile(r"(pd\.read_csv|pd\.read_parquet|np\.load|torch\.load|json\.load)\s*\(")
        for i, ln in enumerate(source_code.splitlines()):
            if _mem_load_re.search(ln):
                findings.append(_finding(
                    issue_type="full_dataset_in_memory",
                    severity="medium",
                    optimization_category="ram",
                    resource_impact=["ram", "io"],
                    description="Dataset is loaded in full into memory; for large files this exhausts RAM and slows other processes.",
                    recommendation="Use chunked reads (pd.read_csv(chunksize=…)), memory-mapped arrays, or a DataLoader with streaming.",
                    expected_impact="RAM peak cut to batch size; enables training on datasets larger than available memory.",
                    verification="Monitor peak RSS before and after; confirm no OOM errors.",
                    fix_risk_level="medium",
                    line_start=i + 1,
                    confidence=0.7,
                    requires_benchmark=True,
                ))
                break

    # --- repeated_file_reads ---
    if source_code:
        read_calls = re.findall(r"(open\s*\(|pd\.read_csv|np\.load|json\.load)", source_code)
        if len(read_calls) >= 3:
            findings.append(_finding(
                issue_type="repeated_file_reads",
                severity="medium",
                optimization_category="io",
                resource_impact=["io", "cpu"],
                description=f"File is read {len(read_calls)} times; each read incurs disk I/O that can be avoided by caching the result.",
                recommendation="Read the file once, store in a variable, and reuse across callers.",
                expected_impact="Eliminates redundant I/O; improves wall-clock time proportional to file size and disk speed.",
                verification="Count file-read syscalls with strace or add logging; confirm single read per file.",
                fix_risk_level="low",
                confidence=0.75,
            ))

    # --- network_call_in_loop ---
    if source_code:
        _net_re = re.compile(r"(requests\.(get|post|put)|urllib|httpx\.|aiohttp\.)", re.IGNORECASE)
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
            if in_loop and _net_re.search(ln):
                findings.append(_finding(
                    issue_type="network_call_in_loop",
                    severity="high",
                    optimization_category="io",
                    resource_impact=["io", "cpu"],
                    description="An HTTP/network call is made inside a loop; latency multiplies linearly with iteration count.",
                    recommendation="Batch requests using async I/O (asyncio + aiohttp) or pre-fetch all data before the loop.",
                    expected_impact="Reduces total network wait time from O(n × latency) to O(latency) for batch APIs.",
                    verification="Log per-iteration latency; confirm batch approach reduces total time.",
                    fix_risk_level="medium",
                    line_start=i + 1,
                    confidence=0.85,
                ))
                break

    # --- high_complexity_function ---
    if max_cc > 20:
        findings.append(_finding(
            issue_type="high_complexity_function",
            severity="critical",
            optimization_category="cpu",
            resource_impact=["cpu"],
            description=f"Max cyclomatic complexity is {max_cc} (>20). Highly complex functions are harder to optimise and profile.",
            recommendation="Split the function into smaller units, each with a single responsibility.",
            expected_impact="Easier profiling and targeted optimisation; typically unlocks compiler/interpreter optimisations.",
            verification="Re-run complexity check after refactoring; confirm max CC drops below 10.",
            fix_risk_level="medium",
            confidence=0.9,
        ))
    elif max_cc > 10:
        findings.append(_finding(
            issue_type="high_complexity_function",
            severity="high",
            optimization_category="cpu",
            resource_impact=["cpu"],
            description=f"Max cyclomatic complexity is {max_cc} (>10). Functions are harder to test and may hide inefficiencies.",
            recommendation="Break down functions with complexity >10 into smaller helpers.",
            expected_impact="Cleaner hot-path isolation; easier to apply targeted optimisation.",
            verification="Re-run complexity check; confirm max CC drops below 10.",
            fix_risk_level="low",
            confidence=0.85,
        ))

    # --- deep_nesting ---
    if depth > 25:
        findings.append(_finding(
            issue_type="deep_nesting",
            severity="medium",
            optimization_category="cpu",
            resource_impact=["cpu"],
            description=f"AST depth is {depth} (>25). Deeply nested code often contains redundant condition checks that increase CPU branch mis-predictions.",
            recommendation="Flatten nested logic with early returns and guard clauses.",
            expected_impact="Improved branch prediction; minor CPU cycle reduction.",
            verification="Re-measure AST depth after refactoring.",
            fix_risk_level="low",
            confidence=0.8,
        ))

    # --- hardcoded_secret ---
    if hardcoded_secret_count > 0:
        refs = ", ".join(str(r) for r in hardcoded_secret_refs[:3]) if isinstance(hardcoded_secret_refs, list) else ""
        detail = f" Identifiers: {refs}." if refs else ""
        findings.append(_finding(
            issue_type="hardcoded_secret",
            severity="critical",
            optimization_category="cpu",
            resource_impact=["cpu"],
            description=f"Detected {hardcoded_secret_count} likely hardcoded secret literal assignment(s).{detail}",
            recommendation="Move secrets to environment variables or a secrets manager (e.g. python-dotenv, Azure Key Vault).",
            expected_impact="Eliminates credential leak risk; no runtime performance change.",
            verification="Confirm variable reads from os.environ or equivalent; run secret scanning tool (truffleHog, gitleaks).",
            fix_risk_level="low",
            confidence=0.8,
        ))

    # --- string_concat_in_loop ---
    if source_code:
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
            if in_loop and re.search(r'\w+\s*\+=\s*["\']', ln):
                findings.append(_finding(
                    issue_type="string_concat_in_loop",
                    severity="medium",
                    optimization_category="ram",
                    resource_impact=["ram", "cpu"],
                    description="String concatenation with += inside a loop creates a new string object on every iteration (O(n²) memory and CPU cost).",
                    recommendation="Collect parts in a list and join at the end: `result = ''.join(parts)`.",
                    expected_impact="Reduces allocations from O(n²) to O(n); measurable speedup on loops with ≥100 iterations.",
                    verification="Profile with tracemalloc before and after; peak memory and wall-clock time should drop.",
                    fix_risk_level="low",
                    line_start=i + 1,
                    confidence=0.85,
                ))
                break

    # --- regex_compile_in_loop ---
    if source_code:
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
            if in_loop and re.search(r"re\.(compile|search|match|findall|sub)\s*\(", ln):
                findings.append(_finding(
                    issue_type="regex_compile_in_loop",
                    severity="medium",
                    optimization_category="cpu",
                    resource_impact=["cpu"],
                    description="Regex pattern is compiled or matched inside a loop, repeating the compilation cost on every iteration.",
                    recommendation="Compile the pattern once before the loop with `pattern = re.compile(...)` and reuse it.",
                    expected_impact="Eliminates redundant regex compilation; 2–5× speedup on loops processing large text corpora.",
                    verification="Compare loop wall-clock time with a pre-compiled pattern.",
                    fix_risk_level="low",
                    line_start=i + 1,
                    confidence=0.8,
                ))
                break

    # --- subprocess_in_loop ---
    if source_code:
        _sub_re = re.compile(r"(subprocess\.(run|call|Popen|check_output)|os\.system|os\.popen)\s*\(")
        lines = source_code.splitlines()
        in_loop = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
            if in_loop and _sub_re.search(ln):
                findings.append(_finding(
                    issue_type="subprocess_in_loop",
                    severity="high",
                    optimization_category="io",
                    resource_impact=["cpu", "io"],
                    description="A subprocess or shell command is spawned inside a loop; process creation overhead multiplies with iteration count.",
                    recommendation="Batch arguments and call the subprocess once, or use a Python-native library instead of a shell command.",
                    expected_impact="Eliminates per-iteration process creation overhead (typically 20–200ms each).",
                    verification="Log iteration count and total wall-clock time; confirm single-invocation alternative is faster.",
                    fix_risk_level="medium",
                    line_start=i + 1,
                    confidence=0.85,
                ))
                break

    # --- sleep_polling ---
    if source_code:
        lines = source_code.splitlines()
        in_while = False
        for i, ln in enumerate(lines):
            if re.match(r"^\s*while\s+True\s*:", ln) or re.match(r"^\s*while\s+1\s*:", ln):
                in_while = True
            if in_while and re.search(r"time\.sleep\s*\(\s*[0-9.]+\s*\)", ln):
                findings.append(_finding(
                    issue_type="sleep_polling",
                    severity="medium",
                    optimization_category="cpu",
                    resource_impact=["cpu"],
                    description="Busy-wait polling loop with time.sleep wastes CPU cycles and prevents the OS from parking the thread efficiently.",
                    recommendation="Replace with an event-driven mechanism: threading.Event.wait(), asyncio.sleep in an async task, or a message queue.",
                    expected_impact="Reduces idle CPU usage from a polling rate to near-zero; improves system responsiveness.",
                    verification="Monitor CPU % of the process at idle; should drop significantly after replacing the poll.",
                    fix_risk_level="medium",
                    line_start=i + 1,
                    confidence=0.8,
                ))
                break

    # --- print_in_loop ---
    if source_code:
        lines = source_code.splitlines()
        in_loop = False
        loop_line = 0
        print_count = 0
        for i, ln in enumerate(lines):
            if re.match(r"^\s*(for |while )", ln):
                in_loop = True
                loop_line = i + 1
                print_count = 0
            if in_loop and re.search(r"\bprint\s*\(", ln):
                print_count += 1
        if print_count >= 2:
            findings.append(_finding(
                issue_type="print_in_loop",
                severity="low",
                optimization_category="io",
                resource_impact=["io", "cpu"],
                description=f"print() is called {print_count} times inside a loop, causing repeated stdout flushes that add I/O overhead on large iterations.",
                recommendation="Accumulate output in a list or buffer and print once after the loop, or use logging with a buffered handler.",
                expected_impact="Reduces I/O syscall frequency; noticeable on loops with ≥1000 iterations.",
                verification="Compare wall-clock time with print inside vs. a single print after the loop.",
                fix_risk_level="low",
                line_start=loop_line,
                confidence=0.75,
            ))

    # --- unvectorized_nested_loops ---
    if source_code:
        lines = source_code.splitlines()
        for i, ln in enumerate(lines):
            if re.match(r"^\s*for ", ln):
                # look for an inner for loop within the next 10 lines
                inner_range = lines[i + 1 : i + 10]
                if any(re.match(r"^\s{4,}for ", il) for il in inner_range):
                    # only flag if there's arithmetic inside (suggests numerical computation)
                    block = "\n".join(inner_range)
                    if re.search(r"[\+\-\*\/]=|\bsum\b|\bappend\b", block):
                        findings.append(_finding(
                            issue_type="unvectorized_nested_loops",
                            severity="high",
                            optimization_category="cpu",
                            resource_impact=["cpu", "ram"],
                            description="Nested for loops performing arithmetic or accumulation — a common candidate for NumPy/pandas vectorisation.",
                            recommendation="Replace inner loops with NumPy array operations or pandas built-ins (e.g. np.dot, df.sum, np.apply_along_axis).",
                            expected_impact="10–100× speedup for numerical kernels on arrays larger than a few hundred elements.",
                            verification="Profile with cProfile; inner loop should disappear from the hot path after vectorisation.",
                            fix_risk_level="medium",
                            line_start=i + 1,
                            confidence=0.7,
                            requires_benchmark=True,
                        ))
                        break

    return findings


def analyze_file(source_code: str) -> dict[str, Any]:
    """
    Run full CodeAnalyzer pipeline on a source string.
    Returns a flat dict of 30+ features including Halstead, Radon raw, and library domains.
    Returns a dict with an 'error' key on failure.
    """
    try:
        from netgreener._codeanalyzer.ast_features.ast_base_analysis import AstBaseAnalyzer
        from netgreener._codeanalyzer.ast_features.node_counter import NodeCounter
        from netgreener._codeanalyzer.ast_features.node_detail_extractor import NodeDetailExtractor
        from netgreener._codeanalyzer.ast_features.metrics_calculator import MetricsCalculator
    except ImportError as e:
        return {"error": f"CodeAnalyzer not available: {e}"}

    try:
        base = AstBaseAnalyzer(source_code)
        counter = NodeCounter(base)
        detail = NodeDetailExtractor(base)
        metrics = MetricsCalculator(base)

        imports_detail = detail.import_nodes_detail()
        _, comment_count = base.extract_comments()
        node_count = counter.count_node()
        mi_result = metrics.calculate_maintainability_index_rank()

        # Cyclomatic complexity — returns list of (name, cc, rank) per function
        cc_list = metrics.calculate_cyclomatic_complexity()
        cc_values = [c for _, c, _ in cc_list] if cc_list else []
        avg_cc = sum(cc_values) / len(cc_values) if cc_values else 0.0
        max_cc = max(cc_values, default=0)

        # Halstead metrics
        halstead = _safe_halstead(metrics.calculate_halstead_metrics())

        # Raw Radon metrics (LLOC, SLOC, blank, multi-line strings)
        raw = metrics.calculate_raw_metrics()

        secret_count, secret_refs = _scan_hardcoded_secret_candidates(source_code)

        features: dict[str, Any] = {
            # AST node counts
            "lines_of_code": counter.count_lines_of_code(),
            "number_of_tokens": counter.count_tokens(),
            "depth_of_ast": counter.depth_of_ast(),
            "number_of_nodes": node_count,
            "number_of_edges": node_count - 1,
            "number_of_imports": counter.count_imports(),
            "imports_detail": imports_detail,
            "count_class_nodes": counter.count_class_nodes(),
            "count_function_nodes": counter.count_function_nodes(),
            "count_call_function_nodes": counter.count_call_function_nodes(),
            "count_control_flow_nodes": counter.count_control_flow_nodes(),
            "count_exception_handling_nodes": counter.count_exception_handling_nodes(),
            "count_expression_nodes": counter.count_expression_nodes(),
            "count_assignment_nodes": counter.count_assignment_nodes(),
            "count_binary_operations": counter.count_binary_operation_nodes(),
            "count_unary_operations": counter.count_unary_operation_nodes(),
            "count_lambda_function_nodes": counter.count_lambda_function_nodes(),
            "comments_count": comment_count,
            # Complexity / quality
            "avg_cyclomatic_complexity": round(avg_cc, 2),
            "max_cyclomatic_complexity": max_cc,
            "maintainability_index": mi_result[0],
            "maintainability_index_rank": mi_result[1],
            # Radon raw
            "lloc": raw.lloc,
            "sloc": raw.sloc,
            "blank_lines": raw.blank,
            "multi_line_strings": raw.multi,
            # Halstead
            **halstead,
            # Library domains
            "library_domains": _detect_domains(imports_detail),
            # Security heuristics
            "hardcoded_secret_candidate_count": secret_count,
            "hardcoded_secret_candidate_refs": secret_refs,
            # Raw source — required by text-scan rules in detect_findings()
            "_source_code": source_code,
        }
        return features

    except SyntaxError as e:
        return {"error": f"SyntaxError: {e}"}
    except Exception as e:
        return {"error": str(e)}


def analyze_project(project_dir: str) -> dict[str, Any]:
    """
    Analyze all .py files in a project directory.
    Returns aggregated features, per-file feature cache, and errors.
    The caller should call detect_code_patterns() per file once project_id is known.
    """
    root = Path(project_dir)
    _SKIP_DIRS = {
        ".venv", "venv", "env", ".env",
        "site-packages", "__pycache__",
        "node_modules", ".git",
        "dist", "build", ".eggs",
    }

    def _collect_py_files(directory: Path) -> list[Path]:
        files: list[Path] = []
        for entry in directory.iterdir():
            if entry.is_dir():
                if entry.name in _SKIP_DIRS or entry.name.endswith(".egg-info"):
                    continue
                files.extend(_collect_py_files(entry))
            elif entry.suffix == ".py":
                files.append(entry)
        return files

    py_files = _collect_py_files(root)

    all_domains: set[str] = set()
    total_loc = 0
    total_imports = 0
    total_tokens = 0
    total_nodes = 0
    total_class_nodes = 0
    total_function_nodes = 0
    total_call_function_nodes = 0
    total_control_flow_nodes = 0
    total_exception_handling_nodes = 0
    total_expression_nodes = 0
    total_assignment_nodes = 0
    total_binary_operations = 0
    total_unary_operations = 0
    total_lambda_function_nodes = 0
    total_comments = 0
    total_lloc = 0
    total_sloc = 0
    total_blank_lines = 0
    total_multi_line_strings = 0
    total_hardcoded_secret_candidates = 0
    total_avg_cc = 0.0
    total_max_cc = 0.0
    total_mi = 0.0
    total_depth_of_ast = 0.0
    total_halstead_volume = 0.0
    total_halstead_difficulty = 0.0
    total_halstead_bugs = 0.0
    total_halstead_vocabulary = 0.0
    total_halstead_length = 0
    total_halstead_effort = 0.0
    file_count = 0
    errors: list[str] = []
    per_file: list[dict] = []  # {"rel_path": str, "features": dict}

    for path in py_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        result = analyze_file(source)
        if "error" in result:
            errors.append(f"{path.name}: {result['error']}")
            continue
        file_count += 1
        total_loc += result.get("lines_of_code", 0)
        total_imports += result.get("number_of_imports", 0)
        total_tokens += result.get("number_of_tokens", 0)
        total_nodes += result.get("number_of_nodes", 0)
        total_class_nodes += result.get("count_class_nodes", 0)
        total_function_nodes += result.get("count_function_nodes", 0)
        total_call_function_nodes += result.get("count_call_function_nodes", 0)
        total_control_flow_nodes += result.get("count_control_flow_nodes", 0)
        total_exception_handling_nodes += result.get("count_exception_handling_nodes", 0)
        total_expression_nodes += result.get("count_expression_nodes", 0)
        total_assignment_nodes += result.get("count_assignment_nodes", 0)
        total_binary_operations += result.get("count_binary_operations", 0)
        total_unary_operations += result.get("count_unary_operations", 0)
        total_lambda_function_nodes += result.get("count_lambda_function_nodes", 0)
        total_comments += result.get("comments_count", 0)
        total_lloc += result.get("lloc", 0)
        total_sloc += result.get("sloc", 0)
        total_blank_lines += result.get("blank_lines", 0)
        total_multi_line_strings += result.get("multi_line_strings", 0)
        total_hardcoded_secret_candidates += result.get("hardcoded_secret_candidate_count", 0)
        total_avg_cc += result.get("avg_cyclomatic_complexity", 0.0)
        total_max_cc += result.get("max_cyclomatic_complexity", 0.0)
        total_mi += result.get("maintainability_index", 0.0)
        total_depth_of_ast += result.get("depth_of_ast", 0.0)
        total_halstead_volume += result.get("halstead_volume", 0.0)
        total_halstead_difficulty += result.get("halstead_difficulty", 0.0)
        total_halstead_bugs += result.get("halstead_bugs", 0.0)
        total_halstead_vocabulary += result.get("halstead_vocabulary", 0.0)
        total_halstead_length += result.get("halstead_length", 0)
        total_halstead_effort += result.get("halstead_effort", 0.0)
        all_domains.update(result.get("library_domains", []))
        per_file.append({"rel_path": str(path.relative_to(root)), "features": result})

    def _avg(total: float) -> float:
        return round(total / file_count, 2) if file_count else 0.0

    return {
        "file_count": file_count,
        # Line / token counts
        "total_lines_of_code": total_loc,
        "total_tokens": total_tokens,
        "total_lloc": total_lloc,
        "total_sloc": total_sloc,
        "total_blank_lines": total_blank_lines,
        "total_multi_line_strings": total_multi_line_strings,
        # Import / library
        "total_imports": total_imports,
        "library_domains": sorted(all_domains),
        # AST structure
        "total_nodes": total_nodes,
        "avg_depth_of_ast": _avg(total_depth_of_ast),
        # Node-type counts
        "total_class_nodes": total_class_nodes,
        "total_function_nodes": total_function_nodes,
        "total_call_function_nodes": total_call_function_nodes,
        "total_control_flow_nodes": total_control_flow_nodes,
        "total_exception_handling_nodes": total_exception_handling_nodes,
        "total_expression_nodes": total_expression_nodes,
        "total_assignment_nodes": total_assignment_nodes,
        "total_binary_operations": total_binary_operations,
        "total_unary_operations": total_unary_operations,
        "total_lambda_function_nodes": total_lambda_function_nodes,
        # Comments
        "total_comments": total_comments,
        # Complexity / quality
        "avg_cyclomatic_complexity": _avg(total_avg_cc),
        "avg_max_cyclomatic_complexity": _avg(total_max_cc),
        "avg_maintainability_index": _avg(total_mi),
        # Halstead
        "avg_halstead_vocabulary": _avg(total_halstead_vocabulary),
        "total_halstead_length": total_halstead_length,
        "avg_halstead_volume": _avg(total_halstead_volume),
        "avg_halstead_difficulty": _avg(total_halstead_difficulty),
        "avg_halstead_effort": _avg(total_halstead_effort),
        "total_halstead_bugs": round(total_halstead_bugs, 3),
        # Security
        "total_hardcoded_secret_candidates": total_hardcoded_secret_candidates,
        # Internal — not sent to surrogate API
        "per_file": per_file,
        "errors": errors,
    }


def build_findings(per_file: list[dict], project_id: int) -> list[dict]:
    """Convert cached per-file features to Finding records for a known project_id."""
    result: list[dict] = []
    for entry in per_file:
        result.extend(detect_findings(entry["features"], entry["rel_path"], project_id))
    return result


def build_patterns(per_file: list[dict], project_id: int) -> list[dict]:
    """Deprecated alias for build_findings."""
    return build_findings(per_file, project_id)
