"""
Semantic code-danger prompts for LLMs — optional layer beside AST/metric patterns.

NetGreener-specific assumptions:
- ``ast_findings`` should align with metric-derived patterns from
  ``analyzer.detect_code_patterns`` (the same family uploaded as CodePattern rows
  for the supervisor), not the IDE CodeAnalyzer design-pattern heuristics, unless
  you merge those elsewhere and pass them in explicitly.

CLI runs this together with NLP features by default (see ``nlp_analyzer.run_combined_llm_analysis``).
Use ``netgreener run ... --no-llm`` / ``netgreener analyze ... --no-llm`` to skip GPT calls.
"""

from __future__ import annotations

import json
import re
from typing import Any, Final, Literal

SEMANTIC_DANGER_TYPES: Final[tuple[str, ...]] = (
    "misleading_naming",
    "hidden_side_effects",
    "fake_validation",
    "unsafe_fallback_behavior",
    "misleading_logging",
    "comment_claims_not_supported",
    "wrong_abstraction",
    "business_logic_overfit",
    "semantic_api_misuse",
    "error_handling_changes_intent",
    "implicit_state_transition",
    "production_risk_hidden_by_demo_style",
)

SEMANTIC_DANGER_DEFINITIONS: Final[dict[str, str]] = {
    "misleading_naming": (
        "a symbol name implies one behavior, but the implementation does materially "
        "more, less, or something different"
    ),
    "hidden_side_effects": (
        "code appears helper-like or local but performs significant mutation, persistence, "
        "I/O, notifications, or other important side effects"
    ),
    "fake_validation": (
        "code appears to validate but the validation is partial, ignored, misleading, "
        "or not truly enforcement-grade"
    ),
    "unsafe_fallback_behavior": (
        "fallback/default behavior silently changes business meaning, workflow meaning, "
        "or safety expectations"
    ),
    "misleading_logging": (
        "logs imply success, diagnosis, completeness, or safety not justified by implementation"
    ),
    "comment_claims_not_supported": (
        "comments or docstrings claim guarantees not supported by implementation"
    ),
    "wrong_abstraction": (
        "abstraction hides critical business rules, invariants, state changes, or side effects"
    ),
    "business_logic_overfit": (
        "logic appears narrowly tailored to one example path, one sample input, one document shape, "
        "one tenant, or one business case while pretending to be general"
    ),
    "semantic_api_misuse": (
        "API or framework usage is semantically suspicious in context even if syntactically plausible"
    ),
    "error_handling_changes_intent": (
        "error recovery changes the intended meaning of the workflow and may hide real failure"
    ),
    "implicit_state_transition": (
        "business/workflow state changes occur without being made explicit"
    ),
    "production_risk_hidden_by_demo_style": (
        "code may work for demo conditions but lacks production-grade workflow semantics, "
        "boundary handling, idempotency, or integrity"
    ),
}

# Typical NetGreener CLI metric-derived patterns (detect_code_patterns); do not restate as semantic.
_NETGREENER_METRIC_PATTERN_EXAMPLES: Final[tuple[str, ...]] = (
    "High cyclomatic complexity (threshold-based)",
    "Low or high maintainability index (MI-based)",
    "Insufficient or strong inline documentation (comment ratio)",
    "Deep AST nesting depth",
    "Presence of exception-handling blocks (count-based signal only)",
)

_ALLOWED_SUMMARY_CONFIDENCE: Final[frozenset[str]] = frozenset({"low", "medium", "high"})
_ALLOWED_ITEM_CONFIDENCE: Final[frozenset[str]] = frozenset({"low", "medium", "high"})
_ALLOWED_SEVERITY: Final[frozenset[str]] = frozenset({"low", "medium", "high", "critical"})

# Match nlp_analyzer.py so combined pipelines can budget tokens consistently.
MAX_SOURCE_CODE_CHARS: Final[int] = 12_000


def build_semantic_danger_system_prompt() -> str:
    """Instruction prompt for semantic danger analysis (NetGreener-aware)."""
    defs_lines = "\n".join(
        f"- {name}: {SEMANTIC_DANGER_DEFINITIONS[name]}" for name in SEMANTIC_DANGER_TYPES
    )
    ng_examples = "\n".join(f"- {ex}" for ex in _NETGREENER_METRIC_PATTERN_EXAMPLES)
    taxonomy_csv = ", ".join(SEMANTIC_DANGER_TYPES)

    return f"""You are a senior code reviewer for NetGreener-style analysis. Your job is ONLY
higher-level semantic risks that are not already covered by the structured static/metric
findings supplied in the user JSON under "ast_findings" (when present).

## Use of context
- Use ONLY fields present in the user JSON. Do not assume repository-wide access, runtime
  state, or files not described in the payload.
- Be conservative: if the payload does not support a claim, add a short note to
  "uncertainties" instead of guessing.

## Output format
- Respond with a single VALID JSON object only. No markdown code fences, no prose before
  or after the JSON.

## Relationship to NetGreener metric patterns
The pipeline already derives dashboard-style patterns from metrics (cyclomatic complexity,
maintainability index, comment ratios, nesting depth, exception-block counts, etc.).
Examples of issues in that family (do NOT repeat as standalone semantic dangers):
{ng_examples}

Additional static issues (e.g. broad bare except, SQL string concatenation) count as
"already static" ONLY if they appear explicitly in "ast_findings" in the payload.

If an issue is directly covered by an entry in "ast_findings", do NOT emit it as a
standalone danger. You may reference it only as supporting evidence inside a true
semantic danger.

## Closed taxonomy
You MUST use only these danger_type strings (exact spelling):
{taxonomy_csv}

Definitions:
{defs_lines}

## JSON schema
Return exactly:
{{
  "summary": {{
    "has_non_ast_dangers": boolean,
    "confidence": "low" | "medium" | "high"
  }},
  "dangers": [
    {{
      "danger_type": string,
      "present": boolean,
      "severity": "low" | "medium" | "high" | "critical",
      "confidence": "low" | "medium" | "high",
      "why": string,
      "evidence": [ {{ "code_ref": string, "reason": string }} ],
      "not_already_covered_by_ast": true
    }}
  ],
  "uncertainties": [ string ]
}}

Include one object per taxonomy value above. Set "present" to false when unsupported.
Each object must have "not_already_covered_by_ast": true (boolean true); if you cannot
honestly do that for an item, set "present" to false and explain under "uncertainties"."""


def build_semantic_danger_user_payload(
    *,
    source_code: str | None = None,
    language: str | None = None,
    framework: str | None = None,
    ast_findings: list[dict[str, Any]] | None = None,
    ast_findings_source: str | None = None,
    symbol_summary: str | None = None,
    helper_summaries: list[str] | dict[str, Any] | None = None,
    callsite_summaries: list[str] | dict[str, Any] | None = None,
    logging_summary: str | None = None,
    mutation_summary: str | None = None,
    return_behavior_summary: str | None = None,
    comments_or_docstrings: str | None = None,
    imports: list[str] | dict[str, Any] | None = None,
    project_context_summaries: list[str] | None = None,
    file_path: str | None = None,
    extra_context: dict[str, Any] | None = None,
    truncate_source_code: bool = True,
) -> dict[str, Any]:
    """
    Build JSON-serializable context for the user message.

    ``ast_findings_source``: optional provenance label, e.g. ``\"netgreener_cli_metrics\"``
    or ``\"ide_pattern_detector\"``, so the model knows what ``ast_findings`` represents.

    When ``truncate_source_code`` is True, ``source_code`` is truncated to
    ``MAX_SOURCE_CODE_CHARS`` (same order of magnitude as ``nlp_analyzer``).
    """
    payload: dict[str, Any] = {"schema_version": 1, "task": "semantic_code_dangers"}

    def _add(key: str, value: Any) -> None:
        if value is None:
            return
        if isinstance(value, str) and not value.strip():
            return
        if isinstance(value, (list, dict)) and len(value) == 0:
            return
        payload[key] = value

    code = source_code
    if truncate_source_code and isinstance(code, str) and len(code) > MAX_SOURCE_CODE_CHARS:
        code = code[:MAX_SOURCE_CODE_CHARS]
        _add(
            "source_code_truncated_note",
            f"source_code truncated to {MAX_SOURCE_CODE_CHARS} characters",
        )

    _add("file_path", file_path)
    _add("source_code", code)
    _add("language", language)
    _add("framework", framework)
    _add("ast_findings", ast_findings)
    _add("ast_findings_source", ast_findings_source)
    _add("symbol_summary", symbol_summary)
    _add("helper_summaries", helper_summaries)
    _add("callsite_summaries", callsite_summaries)
    _add("logging_summary", logging_summary)
    _add("mutation_summary", mutation_summary)
    _add("return_behavior_summary", return_behavior_summary)
    _add("comments_or_docstrings", comments_or_docstrings)
    _add("imports", imports)
    _add("project_context_summaries", project_context_summaries)

    if extra_context:
        for k, v in extra_context.items():
            if k not in payload:
                _add(k, v)

    return payload


def ast_findings_from_detect_code_patterns(
    features: dict[str, Any],
    file_path: str,
    project_id: int,
) -> list[dict[str, Any]]:
    """
    Reuse ``detect_code_patterns`` rows as ``ast_findings`` (drops ``project_id``).
    """
    from netgreener.analyzer import detect_code_patterns

    rows = detect_code_patterns(features, file_path, project_id)
    return [{k: v for k, v in r.items() if k != "project_id"} for r in rows]


def enrich_payload_from_analyze_file_features(
    base: dict[str, Any],
    features: dict[str, Any],
    *,
    max_import_rows: int = 80,
) -> dict[str, Any]:
    """Fill missing ``imports`` / ``symbol_summary`` from ``analyze_file`` output."""
    out = dict(base)
    if "imports" not in out and features.get("imports_detail"):
        detail = features["imports_detail"]
        lines: list[str] = []
        for row in detail[:max_import_rows]:
            if isinstance(row, (list, tuple)) and row:
                lines.append(str(row[0]))
            else:
                lines.append(str(row))
        if lines:
            out.setdefault("imports", lines)
    if "symbol_summary" not in out and features.get("library_domains"):
        domains = features["library_domains"]
        if isinstance(domains, list) and domains:
            out.setdefault(
                "symbol_summary",
                "Inferred library domains from imports: " + ", ".join(str(d) for d in domains),
            )
    return out


def compose_chat_messages(
    user_payload: dict[str, Any],
    *,
    ensure_ascii: bool = False,
) -> list[dict[str, str]]:
    """
    Provider-agnostic message list (OpenAI/Azure/others): system + user JSON string.
    """
    return [
        {"role": "system", "content": build_semantic_danger_system_prompt()},
        {
            "role": "user",
            "content": json.dumps(user_payload, ensure_ascii=ensure_ascii),
        },
    ]


def _extract_json_object(raw: str) -> dict[str, Any]:
    cleaned = raw.replace("```json", "").replace("```", "").strip()
    m = re.search(r"\{[\s\S]*\}\s*$", cleaned)
    if m:
        cleaned = m.group(0)
    return json.loads(cleaned)


def parse_semantic_danger_response(raw: str) -> dict[str, Any]:
    parsed = _extract_json_object(raw)
    normalized, issues = normalize_semantic_danger_response(parsed)
    if issues:
        normalized["_validation_issues"] = issues
    return normalized


def normalize_semantic_danger_response(
    data: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Validate shape; ensure every taxonomy key exists; return (normalized, issues)."""
    issues: list[str] = []
    out: dict[str, Any] = {
        "summary": {"has_non_ast_dangers": False, "confidence": "low"},
        "dangers": [],
        "uncertainties": [],
    }

    summary = data.get("summary")
    if not isinstance(summary, dict):
        issues.append("summary missing or not an object; defaulted.")
    else:
        h = summary.get("has_non_ast_dangers")
        if not isinstance(h, bool):
            issues.append("summary.has_non_ast_dangers invalid; defaulted to false.")
            h = False
        c = summary.get("confidence", "low")
        if c not in _ALLOWED_SUMMARY_CONFIDENCE:
            issues.append(f"summary.confidence invalid ({c!r}); coerced to low.")
            c = "low"
        out["summary"] = {"has_non_ast_dangers": h, "confidence": c}

    unc = data.get("uncertainties", [])
    if unc is None:
        unc = []
    if not isinstance(unc, list):
        issues.append("uncertainties not a list; reset to empty.")
        unc = []
    else:
        unc = [str(x) for x in unc]
    out["uncertainties"] = unc

    dangers_in = data.get("dangers", [])
    if not isinstance(dangers_in, list):
        issues.append("dangers not a list; reset to empty.")
        dangers_in = []

    seen_types: set[str] = set()
    for i, d in enumerate(dangers_in):
        if not isinstance(d, dict):
            issues.append(f"dangers[{i}] skipped: not an object.")
            continue
        dtype = d.get("danger_type")
        if dtype not in SEMANTIC_DANGER_TYPES:
            issues.append(f"dangers[{i}] invalid danger_type {dtype!r}; skipped.")
            out["uncertainties"].append(f"Dropped danger with invalid danger_type: {dtype!r}")
            continue
        if dtype in seen_types:
            issues.append(f"duplicate danger_type {dtype!r}; kept first.")
            continue
        seen_types.add(dtype)

        present = d.get("present", False)
        if not isinstance(present, bool):
            issues.append(f"dangers[{i}].present invalid; coerced to false.")
            present = False

        sev = d.get("severity", "low")
        if sev not in _ALLOWED_SEVERITY:
            issues.append(f"dangers[{i}].severity invalid ({sev!r}); coerced to low.")
            sev = "low"

        conf = d.get("confidence", "low")
        if conf not in _ALLOWED_ITEM_CONFIDENCE:
            issues.append(f"dangers[{i}].confidence invalid ({conf!r}); coerced to low.")
            conf = "low"

        why = str(d.get("why") or "")

        ev_in = d.get("evidence", [])
        evidence: list[dict[str, str]] = []
        if not isinstance(ev_in, list):
            issues.append(f"dangers[{i}].evidence not a list; cleared.")
        else:
            for ev in ev_in:
                if isinstance(ev, dict):
                    evidence.append(
                        {
                            "code_ref": str(ev.get("code_ref", "")),
                            "reason": str(ev.get("reason", "")),
                        }
                    )

        not_ast = d.get("not_already_covered_by_ast", True)
        if not_ast is not True:
            issues.append(f"dangers[{i}].not_already_covered_by_ast not true; coerced to true.")
            not_ast = True

        out["dangers"].append(
            {
                "danger_type": dtype,
                "present": present,
                "severity": sev,
                "confidence": conf,
                "why": why,
                "evidence": evidence,
                "not_already_covered_by_ast": not_ast,
            }
        )

    for t in SEMANTIC_DANGER_TYPES:
        if t not in seen_types:
            out["dangers"].append(
                {
                    "danger_type": t,
                    "present": False,
                    "severity": "low",
                    "confidence": "low",
                    "why": "",
                    "evidence": [],
                    "not_already_covered_by_ast": True,
                }
            )

    out["dangers"].sort(key=lambda x: SEMANTIC_DANGER_TYPES.index(x["danger_type"]))
    return out, issues


# --- Runnable example (no network) ---
if __name__ == "__main__":
    example_features = {
        "lines_of_code": 120,
        "maintainability_index": 18.0,
        "max_cyclomatic_complexity": 12,
        "comments_count": 0,
        "count_exception_handling_nodes": 2,
        "depth_of_ast": 30,
        "imports_detail": [("pandas", 1), ("requests", 1)],
        "library_domains": ["data"],
    }
    ast_rows = ast_findings_from_detect_code_patterns(
        example_features, "service.py", project_id=0
    )
    payload = build_semantic_danger_user_payload(
        language="python",
        file_path="service.py",
        ast_findings=ast_rows,
        ast_findings_source="netgreener_cli_metrics",
        source_code="# placeholder\n" * 20,
    )
    payload = enrich_payload_from_analyze_file_features(payload, example_features)
    msgs = compose_chat_messages(payload)
    print("messages[0] role:", msgs[0]["role"], "len:", len(msgs[0]["content"]))
    print("messages[1] role:", msgs[1]["role"], "user JSON chars:", len(msgs[1]["content"]))

    sample_model = """
    {
      "summary": {"has_non_ast_dangers": true, "confidence": "medium"},
      "dangers": [
        {
          "danger_type": "fake_validation",
          "present": true,
          "severity": "medium",
          "confidence": "medium",
          "why": "Docstring claims validated input but no checks visible in snippet.",
          "evidence": [{"code_ref": "service.py", "reason": "Payload excerpt lacks validators."}],
          "not_already_covered_by_ast": true
        }
      ],
      "uncertainties": ["Full module not in context."]
    }
    """
    normalized, iss = normalize_semantic_danger_response(_extract_json_object(sample_model))
    print("taxonomy coverage:", len(normalized["dangers"]), "issues:", iss)
