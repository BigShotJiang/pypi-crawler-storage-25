"""CLI API client with optional delegation to netgreener_sdk."""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import quote

import requests

from .config import get_api_url, get_environment, get_organization_id, load_credentials

try:
    from netgreener_sdk.client import APIError as SDKAPIError
    from netgreener_sdk.client import NetGreenerClient as SDKClient

    APIError = SDKAPIError
except Exception:  # pragma: no cover - fallback when SDK package is unavailable
    SDKClient = None

    class APIError(Exception):
        def __init__(self, status_code: int, detail: str):
            self.status_code = status_code
            self.detail = detail
            super().__init__(f"HTTP {status_code}: {detail}")


class _AuthPreservingSession(requests.Session):
    """Keep Authorization header and HTTP method on redirects."""

    def rebuild_auth(self, prepared_request, response):
        return

    def rebuild_method(self, _prepared_request, _response):
        return


class NetGreenerClient:
    def __init__(
        self,
        token: str | None = None,
        base_url: str | None = None,
        user_id: int | None = None,
        org_id: int | None = None,
        environment: str | None = None,
    ):
        self.base_url = (base_url or get_api_url()).rstrip("/") + "/api/v1"
        self._token = token
        self._user_id = user_id
        self._org_id = org_id
        self._environment = environment
        self._session = _AuthPreservingSession()
        self._sdk: Optional[SDKClient] = None
        if SDKClient is not None:
            self._sdk = SDKClient(
                token=token, base_url=self.base_url, org_id=org_id, environment=environment
            )

    @classmethod
    def from_credentials(cls) -> "NetGreenerClient":
        creds = load_credentials()
        if not creds:
            raise APIError(401, "Not logged in. Run: netgreener login")
        user_id = creds.get("user", {}).get("user_id")
        instance = cls(
            token=creds["access_token"],
            user_id=user_id,
            org_id=get_organization_id(),
            environment=get_environment(),
        )
        # When token comes from NETGREENER_TOKEN env var, user dict is empty; fetch user_id from API
        if instance._user_id is None and instance._token:
            try:
                me = instance._get("/auth/me", timeout=10)
                instance._user_id = me.get("user_id")
            except Exception:
                pass
        return instance

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        if self._org_id is not None:
            h["X-Organization-ID"] = str(self._org_id)
        if self._environment:
            h["X-Environment"] = self._environment
        return h

    def set_org_context(self, org_id: int | None, environment: str | None = None) -> None:
        self._org_id = org_id
        self._environment = environment
        if self._sdk is not None:
            self._sdk.set_org_context(org_id, environment)

    def _raise(self, resp: requests.Response) -> None:
        if resp.ok:
            return
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise APIError(resp.status_code, str(detail))

    def _get(self, path: str, *, params: dict[str, Any] | None = None, timeout: int = 30):
        resp = self._session.get(f"{self.base_url}{path}", headers=self._headers(), params=params, timeout=timeout)
        self._raise(resp)
        return resp.json()

    def _post(self, path: str, *, payload: dict[str, Any], timeout: int = 30):
        resp = self._session.post(
            f"{self.base_url}{path}", headers=self._headers(), json=payload, timeout=timeout
        )
        self._raise(resp)
        return resp.json()

    def _put(self, path: str, *, payload: dict[str, Any], timeout: int = 30):
        resp = self._session.put(
            f"{self.base_url}{path}", headers=self._headers(), json=payload, timeout=timeout
        )
        self._raise(resp)
        return resp.json()

    def _delete(self, path: str, *, timeout: int = 30):
        resp = self._session.delete(f"{self.base_url}{path}", headers=self._headers(), timeout=timeout)
        self._raise(resp)
        return resp.json()

    def login(self, email: str, password: str) -> dict[str, Any]:
        if self._sdk is not None:
            data = self._sdk.login(email, password)
            self._token = self._sdk.get_access_token()
            return data
        data = self._post("/auth/login", payload={"email": email, "password": password}, timeout=15)
        self._token = data.get("access_token")
        return data

    def get_or_create_project(self, name: str, directory: str) -> dict[str, Any]:
        projects = self._get("/projects/", timeout=15)
        norm_dir = directory.replace("\\", "/").rstrip("/").lower()
        # Match by directory first — same logic as the VS Code extension so both land on the same project
        for p in projects:
            p_dir = (p.get("directory") or "").replace("\\", "/").rstrip("/").lower()
            if p_dir and p_dir == norm_dir:
                return p
        # Fall back to name match
        for p in projects:
            if p.get("name") == name:
                return p
        return self._post(
            "/projects/",
            payload={"name": name, "directory": directory, "language": "Python", "user_id": self._user_id},
            timeout=15,
        )

    # --- Run/upload flows
    def create_run_session(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.post_run_session(payload)
        return self._post("/runsessions/", payload=payload, timeout=15)

    def update_run_accuracy(self, run_id: int, metrics: dict[str, Any]) -> dict[str, Any]:
        return self._put(f"/runsessions/{run_id}/accuracy", payload=metrics, timeout=15)

    def post_findings_batch(self, findings: list[dict[str, Any]]) -> dict[str, Any]:
        return self._post("/findings/batch", payload={"findings": findings}, timeout=30)

    def post_code_patterns_batch(self, patterns: list[dict[str, Any]]) -> dict[str, Any]:
        """Deprecated alias for post_findings_batch."""
        return self.post_findings_batch(patterns)

    def post_surrogate_training(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.post_surrogate_training(payload)
        return self._post("/surrogate-training/", payload=payload, timeout=15)

    def get_llm_config(self) -> dict[str, Any]:
        return self._get("/config/llm/", timeout=10)

    def post_environmental_impact(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._post("/environmental-impact/", payload=payload, timeout=15)

    # --- Project feature metadata
    def get_project_feature_metadata(self, project_id: int) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.get_project_feature_metadata(project_id)
        return self._get(f"/features/project/{project_id}/feature-metadata")

    def post_project_feature_metadata(self, project_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.post_project_feature_metadata(project_id, payload)
        body = {**payload, "project_id": project_id}
        return self._post(f"/features/project/{project_id}/feature-metadata", payload=body)

    def put_project_feature_metadata(self, project_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.put_project_feature_metadata(project_id, payload)
        return self._put(f"/features/project/{project_id}/feature-metadata", payload=payload)

    def delete_project_feature_metadata(self, project_id: int) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.delete_project_feature_metadata(project_id)
        return self._delete(f"/features/project/{project_id}/feature-metadata")

    # --- Feature collection inputs
    def post_feature_collection_input(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.post_feature_collection_input(payload)
        return self._post("/features/inputs", payload=payload)

    def get_feature_collection_inputs(
        self,
        *,
        project_id: int | None = None,
        feature_name: str | None = None,
        entered_by_user_id: int | None = None,
    ) -> list[dict[str, Any]]:
        if self._sdk is not None:
            return self._sdk.get_feature_collection_inputs(
                project_id=project_id,
                feature_name=feature_name,
                entered_by_user_id=entered_by_user_id,
            )
        params: dict[str, Any] = {}
        if project_id is not None:
            params["project_id"] = project_id
        if feature_name is not None:
            params["feature_name"] = feature_name
        if entered_by_user_id is not None:
            params["entered_by_user_id"] = entered_by_user_id
        return self._get("/features/inputs", params=params or None)

    def get_feature_collection_input(self, input_id: int) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.get_feature_collection_input(input_id)
        return self._get(f"/features/inputs/{input_id}")

    def update_feature_collection_input(self, input_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.update_feature_collection_input(input_id, payload)
        return self._put(f"/features/inputs/{input_id}", payload=payload)

    def delete_feature_collection_input(self, input_id: int) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.delete_feature_collection_input(input_id)
        return self._delete(f"/features/inputs/{input_id}")

    def list_project_feature_collection_inputs(self, project_id: int) -> list[dict[str, Any]]:
        if self._sdk is not None:
            return self._sdk.list_project_feature_collection_inputs(project_id)
        return self._get(f"/features/project/{project_id}/inputs")

    # --- Feature definitions
    def list_feature_definitions(
        self,
        *,
        data_type: str | None = None,
        source_type: str | None = None,
    ) -> list[dict[str, Any]]:
        # SDK currently does not support filters for this endpoint.
        params: dict[str, Any] = {}
        if data_type is not None:
            params["data_type"] = data_type
        if source_type is not None:
            params["source_type"] = source_type
        return self._get("/features/definitions", params=params or None)

    def post_feature_definition(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self._sdk is not None:
            return self._sdk.post_feature_definition(payload)
        return self._post("/features/definitions", payload=payload)

    def get_feature_definition(self, feature_name: str) -> dict[str, Any]:
        safe_name = quote(str(feature_name), safe="")
        if self._sdk is not None:
            return self._sdk.get_feature_definition(feature_name)
        return self._get(f"/features/definitions/{safe_name}")

    def update_feature_definition(self, feature_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        safe_name = quote(str(feature_name), safe="")
        if self._sdk is not None:
            return self._sdk.update_feature_definition(feature_name, payload)
        return self._put(f"/features/definitions/{safe_name}", payload=payload)

    def delete_feature_definition(self, feature_name: str) -> dict[str, Any]:
        safe_name = quote(str(feature_name), safe="")
        if self._sdk is not None:
            return self._sdk.delete_feature_definition(feature_name)
        return self._delete(f"/features/definitions/{safe_name}")

    # --- KPI estimation (Phase 7)
    def estimate_run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /runs/estimate — estimate KPIs from explicit feature_values."""
        if self._sdk is not None:
            return self._sdk.estimate_run(payload)
        return self._post("/runs/estimate", payload=payload, timeout=60)

    def estimate_project(self, project_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /runs/projects/{id}/estimate — server resolves features from project DB."""
        if self._sdk is not None:
            return self._sdk.estimate_project(project_id, payload)
        return self._post(f"/runs/projects/{project_id}/estimate", payload=payload, timeout=60)
