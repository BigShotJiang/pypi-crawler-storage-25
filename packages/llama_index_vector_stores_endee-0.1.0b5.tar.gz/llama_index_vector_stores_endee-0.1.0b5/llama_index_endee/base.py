"""Endee Vector Store integration for LlamaIndex.

Implements ``BasePydanticVectorStore`` to bridge LlamaIndex's node/query
model with the Endee vector database, supporting dense, sparse (BM25 /
SPLADE), metadata-filtered, and RRF-tuned search.
"""

import json
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple

from llama_index.core.bridge.pydantic import PrivateAttr
from llama_index.core.schema import BaseNode, TextNode
from llama_index.core.vector_stores.types import (
    BasePydanticVectorStore,
    VectorStoreQuery,
    VectorStoreQueryResult,
)
from llama_index.core.vector_stores.utils import (
    DEFAULT_TEXT_KEY,
    legacy_metadata_dict_to_node,
    metadata_dict_to_node,
    node_to_metadata_dict,
)

from .constants import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_EF_SEARCH,
    MAX_VECTORS_PER_BATCH,
    REVERSE_OPERATOR_MAP,
    SUPPORTED_FILTER_OPERATORS,
)
from .utils import (
    _SDK_TO_ENCODER,
    get_sparse_encoder,
    is_sparse,
    normalize_sparse_model,
)

try:
    from endee import Endee
    from endee.exceptions import NotFoundException
except ImportError as e:
    raise ImportError("Could not import endee. Please install it with `pip install endee`.") from e

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_FILTERABLE_FIELDS = (
    "file_name",
    "doc_id",
    "category",
    "difficulty",
    "language",
    "field",
    "type",
    "feature",
)


class EndeeVectorStore(BasePydanticVectorStore):
    """LlamaIndex vector store backed by the Endee vector database.

    Supports dense, sparse (BM25 / SPLADE), metadata-filtered, and
    RRF-tuned search. Use :meth:`from_params` to create an instance.

    sparse_model controls the search mode:
        - None          → dense-only search
        - "default"     → SPLADE sparse encoder (via FastEmbed)
        - "endee_bm25"  → BM25 sparse encoder (via endee_model)
        - anything else → ignored, falls back to dense

    Examples:
        >>> # Dense only
        >>> store = EndeeVectorStore.from_params(
        ...     api_token="...", index_name="my_index", dimension=384,
        ... )
        >>> # Sparse with BM25
        >>> store = EndeeVectorStore.from_params(
        ...     api_token="...", index_name="bm25_index", dimension=384,
        ...     sparse_model="endee_bm25",
        ... )
        >>> # Sparse with SPLADE (requires fastembed)
        >>> store = EndeeVectorStore.from_params(
        ...     api_token="...", index_name="splade_index", dimension=384,
        ...     sparse_model="default",
        ... )
    """

    stores_text: bool = True
    flat_metadata: bool = False
    api_token: Optional[str]
    base_url:Optional[str]
    index_name: Optional[str]
    space_type: Optional[str]
    dimension: Optional[int]
    add_sparse_vector: bool
    text_key: str
    batch_size: int
    remove_text_from_metadata: bool
    sparse_model: Optional[str]
    precision: Optional[str]
    hybrid: bool = False
    _endee_index: Any = PrivateAttr()
    _sparse_encoder: Optional[Callable] = PrivateAttr(default=None)
    _client: Any = PrivateAttr()

    def __init__(  # noqa: D107
        self,
        endee_index: Optional[Any] = None,
        api_token: Optional[str] = None,
        base_url: Optional[str] = None,

        index_name: Optional[str] = None,
        space_type: Optional[str] = "cosine",
        dimension: Optional[int] = None,
        add_sparse_vector: bool = False,
        text_key: str = DEFAULT_TEXT_KEY,
        batch_size: int = DEFAULT_BATCH_SIZE,
        remove_text_from_metadata: bool = False,
        sparse_model: Optional[str] = None,
        precision: Optional[str] = "int16",
        M: Optional[int] = None,
        ef_con: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        # Normalize: only "default" and "endee_bm25" are valid, rest → None
        sparse_model = normalize_sparse_model(sparse_model)

        super().__init__(
            index_name=index_name,
            api_token=api_token,
            base_url=base_url,
            space_type=space_type,
            dimension=dimension,
            sparse_model=sparse_model,
            precision=precision,
            add_sparse_vector=add_sparse_vector,
            text_key=text_key,
            batch_size=batch_size,
            remove_text_from_metadata=remove_text_from_metadata,
        )
        if self.api_token:
            self._client = Endee(api_token)
        else:
            self._client = Endee()
        if base_url:
            self._client.set_base_url(base_url)

        self.hybrid = is_sparse(sparse_model)

        if endee_index is not None:
            self._endee_index = endee_index
        else:
            self._endee_index = self._initialize_endee_index(
                index_name,
                dimension,
                space_type,
                precision,
                sparse_model=self.sparse_model,
                M=M,
                ef_con=ef_con,
            )
        
        self._sparse_encoder = self._init_sparse_encoder(self.sparse_model, batch_size)
          

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _init_sparse_encoder(self, sparse_model: Optional[str], batch_size: int) -> Optional[Callable]:
        """Create the sparse encoder callable.

        Maps SDK sparse_model → local encoder key:
            "default"     → "splade_pp" (FastEmbed SPLADE++)
            "endee_bm25"  → "endee/bm25" (endee_model BM25)
        """
        encoder_name = _SDK_TO_ENCODER.get(sparse_model)
        if encoder_name is None:
            return None
        return get_sparse_encoder(model_name=encoder_name, batch_size=batch_size)

  
    def _initialize_endee_index(
        self, 

        index_name: Optional[str]=None,
        dimension: Optional[int] = None,
        space_type: Optional[str] = "cosine",
        precision: Optional[str] = "int16",
        sparse_model: Optional[str] = None,
        M: Optional[int] = None,
        ef_con: Optional[int] = None,
    ) -> Any:
        """Retrieve an existing Endee index or create a new one."""
     

        

        # Try to retrieve existing index
        try:
            index = self._client.get_index(name=index_name)
            return index
        except NotFoundException:
            logger.info(f"Index '{index_name}' not found, creating...")

        # Validate dimension is required for creation
     

        create_kwargs: Dict[str, Any] = {
            "name": index_name,
            "dimension": dimension,
            "space_type": space_type,
            "precision": precision,
        }
        if self.hybrid:
            create_kwargs["sparse_model"] = sparse_model
        if M is not None:
            create_kwargs["M"] = M
        if ef_con is not None:
            create_kwargs["ef_con"] = ef_con

        mode = "sparse" if self.hybrid else "dense"
        logger.info(f"Creating {mode} index '{index_name}' (dim={dimension})")
        self._client.create_index(**create_kwargs)
        return self._client.get_index(name=index_name)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_params(
        cls,
        endee_index: Optional[Any] = None,
        api_token: Optional[str] = None,
        base_url: Optional[str] = None,
        index_name: Optional[str] = None,
        dimension: Optional[int] = None,
        space_type: str = "cosine",
        batch_size: int = DEFAULT_BATCH_SIZE,
        sparse_model: Optional[str] = None,
        precision: Optional[str] = "int16",
        M: Optional[int] = None,
        ef_con: Optional[int] = None,
    ) -> "EndeeVectorStore":
        """Recommended way to create an EndeeVectorStore.

        Creates a new Endee index or reconnects to an existing one,
        reads back the actual config from the backend, and returns a
        fully configured store instance.

        Args:
            api_token: Endee API token. None for local server.
            index_name: Name of the Endee index.
            dimension: Vector dimension. Required for new indexes.
            space_type: Distance metric ("cosine", "l2", or "ip").
            batch_size: Vectors per upsert batch.
            sparse_model: None for dense, "default" for SPLADE, "endee_bm25" for BM25.
                          Any other value is treated as dense.
            precision: Vector precision ("float32", "float16", "int16", "int8", "binary").
            M: HNSW index build parameter.
            ef_con: HNSW construction parameter.
        """
     

        # Read actual config from the backend
     

        return cls(
        endee_index=endee_index,
            api_token=api_token,
            base_url=base_url,
            index_name=index_name,
            dimension=dimension,
            space_type=space_type,
            batch_size=batch_size,
            sparse_model=sparse_model,
            precision=precision,
            M=M,
            ef_con=ef_con,
        )

    @classmethod
    def class_name(cls) -> str:
        """Return the class name for LlamaIndex registration."""
        return "EndeeVectorStore"

    # ------------------------------------------------------------------
    # Sparse encoding
    # ------------------------------------------------------------------

    def _compute_sparse_vectors(self, texts: List[str]) -> Tuple[List[List[int]], List[List[float]]]:
        """Encode texts into sparse (indices, values) via the configured backend."""
        if self._sparse_encoder is None:
            raise ValueError(
                "Sparse encoder not initialized. "
                "Create store with sparse_model='default' or sparse_model='endee_bm25'."
            )
        return self._sparse_encoder(texts)

    # ------------------------------------------------------------------
    # CRUD operations
    # ------------------------------------------------------------------

    def add(self, nodes: List[BaseNode], **add_kwargs: Any) -> List[str]:
        """Add nodes with automatic batching, dedup, and optional sparse encoding."""
        use_sparse = self.hybrid

        # Deduplicate by node ID (last occurrence wins)
        seen: Dict[str, int] = {}
        for idx, node in enumerate(nodes):
            seen[node.node_id] = idx
        nodes = [nodes[i] for i in sorted(seen.values())]

        # Compute sparse vectors in batch if sparse mode
        sparse_indices: List[List[int]] = []
        sparse_values: List[List[float]] = []
        if use_sparse:
            texts = [node.get_content() for node in nodes]
            if self._sparse_encoder is not None and texts:
                sparse_indices, sparse_values = self._compute_sparse_vectors(texts)
            else:
                sparse_indices = [[] for _ in nodes]
                sparse_values = [[] for _ in nodes]

        # Build upsert entries
        ids: List[str] = []
        entries: List[Dict[str, Any]] = []
        for i, node in enumerate(nodes):
            metadata = node_to_metadata_dict(node)
            filter_data = self._extract_filter_fields(node, metadata)

            entry: Dict[str, Any] = {
                "id": node.node_id,
                "vector": node.get_embedding(),
                "meta": metadata,
                "filter": filter_data,
            }
            if use_sparse:
                entry["sparse_indices"] = sparse_indices[i]
                entry["sparse_values"] = sparse_values[i]

            ids.append(node.node_id)
            entries.append(entry)

        # Batch upsert
        batch_size = min(self.batch_size, MAX_VECTORS_PER_BATCH)
        for i in range(0, len(entries), batch_size):
            self._endee_index.upsert(entries[i : i + batch_size])

        return ids

    @staticmethod
    def _extract_filter_fields(node: BaseNode, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Extract filterable metadata fields for the Endee filter dict."""
        filter_data: Dict[str, Any] = {}
        ref_id = getattr(node, "ref_doc_id", None) or metadata.get("ref_doc_id")
        if ref_id is not None:
            filter_data["ref_doc_id"] = ref_id
        for field in _FILTERABLE_FIELDS:
            if field in metadata:
                filter_data[field] = metadata[field]
        return filter_data

    def delete(self, ref_doc_id: str, **delete_kwargs: Any) -> None:
        """Delete all vectors matching a ref_doc_id filter."""
        self._endee_index.delete_with_filter([{"ref_doc_id": {"$eq": ref_doc_id}}])

    def delete_vector(self, vector_id: str, **delete_kwargs: Any) -> str:
        """Delete a single vector by ID. Returns SDK success message."""
        return self._endee_index.delete_vector(vector_id)

    @property
    def client(self) -> Any:
        """The underlying Endee Index object for direct SDK access."""
        return self._endee_index

    def describe(self) -> Dict[str, Any]:
        """Index metadata (name, dimension, space_type, precision, count, etc.)."""
        try:
            return self._endee_index.describe()
        except Exception as e:
            logger.error(f"Failed to describe index: {e}")
            return {}

    def fetch(self, ids: List[str]) -> List[Dict[str, Any]]:
        """Fetch full vector data by IDs. Failed fetches are logged and skipped."""
        results: List[Dict[str, Any]] = []
        for vector_id in ids:
            try:
                results.append(self._endee_index.get_vector(vector_id))
            except Exception as e:
                logger.warning(f"Failed to fetch vector '{vector_id}': {e}")
        return results

    def update_filters(self, updates: List[Dict[str, Any]]) -> str:
        """Replace filter metadata on vectors. Each update: {"id": ..., "filter": {...}}."""
        return self._endee_index.update_filters(updates)

    # ------------------------------------------------------------------
    # Query internals
    # ------------------------------------------------------------------

    def _process_filters(self, query: VectorStoreQuery) -> Optional[List[Dict[str, Any]]]:
        """Convert LlamaIndex MetadataFilters → Endee API filter format."""
        if query.filters is None:
            return None

        filters: Dict[str, Dict[str, Any]] = {}
        for item in query.filters.filters:
            if hasattr(item, "key") and hasattr(item, "operator"):
                if item.operator not in SUPPORTED_FILTER_OPERATORS:
                    raise ValueError(
                        f"Unsupported filter operator: {item.operator}. Supported: {SUPPORTED_FILTER_OPERATORS}"
                    )
                filters.setdefault(item.key, {})[REVERSE_OPERATOR_MAP[item.operator]] = item.value
            elif isinstance(item, dict):
                for key, op_dict in item.items():
                    if isinstance(op_dict, dict):
                        for op, val in op_dict.items():
                            filters.setdefault(key, {})[op] = val
            else:
                raise ValueError(f"Unsupported filter format: {type(item).__name__}")

        return [{k: v} for k, v in filters.items()] if filters else None

    def _process_sparse_query(self, query: VectorStoreQuery) -> Tuple[Optional[List[int]], Optional[List[float]]]:
        """Encode query_str into sparse vector. Returns (None, None) if unavailable."""
        query_text = getattr(query, "query_str", None)
        if not query_text or self._sparse_encoder is None:
            return None, None
        si, sv = self._compute_sparse_vectors([query_text])
        return si[0], [float(v) for v in sv[0]]

    def _build_query_params(
        self,
        query_embedding: List[float],
        top_k: int,
        ef: int,
        filter_for_api: Optional[List[Dict[str, Any]]],
        sparse_indices: Optional[List[int]],
        sparse_values: Optional[List[float]],
        prefilter_cardinality_threshold: Optional[int] = None,
        filter_boost_percentage: Optional[int] = None,
        dense_rrf_weight: Optional[float] = None,
        rrf_rank_constant: Optional[int] = None,
        include_vectors: bool = True,
    ) -> Dict[str, Any]:
        """Build the kwargs dict for ``Index.query()``."""
        params: Dict[str, Any] = {
            "vector": query_embedding,
            "top_k": top_k,
            "ef": ef,
            "include_vectors": include_vectors,
        }
        if filter_for_api is not None:
            params["filter"] = filter_for_api
        if sparse_indices is not None:
            params["sparse_indices"] = sparse_indices
        if sparse_values is not None:
            params["sparse_values"] = sparse_values
        if prefilter_cardinality_threshold is not None:
            params["prefilter_cardinality_threshold"] = prefilter_cardinality_threshold
        if filter_boost_percentage is not None:
            params["filter_boost_percentage"] = filter_boost_percentage
        if dense_rrf_weight is not None:
            params["dense_rrf_weight"] = dense_rrf_weight
        if rrf_rank_constant is not None:
            params["rrf_rank_constant"] = rrf_rank_constant
        return params

    # ------------------------------------------------------------------
    # Result conversion (Endee dict → LlamaIndex node)
    # ------------------------------------------------------------------

    def _create_node_from_legacy_metadata(self, metadata: Dict[str, Any], node_id: str) -> BaseNode:
        """Reconstruct a TextNode from stored _node_content JSON."""
        metadata_dict, node_info, relationships = legacy_metadata_dict_to_node(
            metadata=metadata,
            text_key=self.text_key,
        )
        try:
            node_content = json.loads(metadata.get("_node_content", "{}"))
        except json.JSONDecodeError:
            node_content = {}

        node = TextNode(
            text=node_content.get(self.text_key, ""),
            metadata=metadata_dict,
            relationships=relationships,
            id_=node_id,
        )
        for key, val in node_info.items():
            if hasattr(node, key):
                setattr(node, key, val)
        return node

    def _process_single_result(self, result: Dict[str, Any]) -> Tuple[BaseNode, float, str]:
        """Convert one Endee result dict into (node, score, id)."""
        node_id = result["id"]
        score = result.get("similarity", result.get("score", 0.0))
        metadata = result.get("meta", {})

        node = (
            metadata_dict_to_node(metadata=metadata, text=metadata.pop(self.text_key, None), id_=node_id)
            if self.flat_metadata
            else self._create_node_from_legacy_metadata(metadata, node_id)
        )
        if "vector" in result:
            node.embedding = result["vector"]
        return node, score, node_id

    def _process_query_results(self, results: List[Dict[str, Any]]) -> Tuple[List[BaseNode], List[float], List[str]]:
        """Convert a list of Endee result dicts to LlamaIndex format."""
        nodes: List[BaseNode] = []
        similarities: List[float] = []
        ids: List[str] = []
        for result in results:
            try:
                node, score, node_id = self._process_single_result(result)
                nodes.append(node)
                similarities.append(score)
                ids.append(node_id)
            except Exception as e:
                logger.warning(f"Skipping result {result.get('id', '?')}: {e}")
        return nodes, similarities, ids

    # ------------------------------------------------------------------
    # Public query
    # ------------------------------------------------------------------

    def query(
        self,
        query: VectorStoreQuery,
        ef: int = DEFAULT_EF_SEARCH,
        prefilter_cardinality_threshold: Optional[int] = None,
        filter_boost_percentage: Optional[int] = None,
        dense_rrf_weight: Optional[float] = None,
        rrf_rank_constant: Optional[int] = None,
        include_vectors: bool = True,
        **kwargs: Any,
    ) -> VectorStoreQueryResult:
        """Query the index for the top-k most similar nodes.

        Args:
            query: LlamaIndex VectorStoreQuery (embedding, query_str, filters, top_k).
            ef: HNSW search breadth (1-1024, default 128). Higher = better recall.
            prefilter_cardinality_threshold: Switch to brute-force below this count.
            filter_boost_percentage: Expand candidate pool by this % when filtering.
            dense_rrf_weight: RRF weight for dense vs sparse fusion (0.0-1.0).
            rrf_rank_constant: RRF rank constant (>=1, default 60).
            include_vectors: Include embeddings in results (default True).
            **kwargs: Interface compatibility (unused).
        """
        use_sparse = self.hybrid

        # Allow passing tuning params via vector_store_kwargs (LlamaIndex retriever pathway)
        extra: Dict[str, Any] = getattr(query, "query_kwargs", {}) or {}
        if prefilter_cardinality_threshold is None:
            prefilter_cardinality_threshold = extra.get("prefilter_cardinality_threshold")
        if filter_boost_percentage is None:
            filter_boost_percentage = extra.get("filter_boost_percentage")
        if dense_rrf_weight is None:
            dense_rrf_weight = extra.get("dense_rrf_weight")
        if rrf_rank_constant is None:
            rrf_rank_constant = extra.get("rrf_rank_constant")
        if "include_vectors" in extra:
            include_vectors = extra.get("include_vectors")

        filter_for_api = self._process_filters(query)
        query_embedding = query.query_embedding

        sparse_indices_q, sparse_values_q = (
            self._process_sparse_query(query) if use_sparse else (None, None)
        )

        top_k = query.similarity_top_k

        query_kwargs = self._build_query_params(
            query_embedding,
            top_k,
            ef,
            filter_for_api,
            sparse_indices_q,
            sparse_values_q,
            prefilter_cardinality_threshold,
            filter_boost_percentage,
            dense_rrf_weight,
            rrf_rank_constant,
            include_vectors,
        )

        try:
            results = self._endee_index.query(**query_kwargs)
        except Exception as e:
            logger.error(f"Query failed: {e}")
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        nodes, similarities, ids = self._process_query_results(results)
        return VectorStoreQueryResult(nodes=nodes, similarities=similarities, ids=ids)
