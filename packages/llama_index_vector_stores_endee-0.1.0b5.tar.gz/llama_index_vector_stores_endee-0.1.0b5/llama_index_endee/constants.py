"""Constants for EndeeVectorStore.

Fallback defaults are defined first, then overridden from the endee SDK
when available. This keeps the wrapper functional even if the SDK is an
older version that doesn't expose every constant.
"""

from llama_index.core.vector_stores.types import FilterOperator

# ---------------------------------------------------------------------------
# Fallback defaults (overridden from SDK below when possible)
# ---------------------------------------------------------------------------

# Limits



# HNSW defaults
DEFAULT_EF_SEARCH = 128

# Query-tuning defaults
DEFAULT_PREFILTER_CARDINALITY_THRESHOLD = 10_000
DEFAULT_FILTER_BOOST_PERCENTAGE = 0
DEFAULT_DENSE_RRF_WEIGHT = 0.5
DEFAULT_RRF_RANK_CONSTANT = 60

# Sparse model
SPARSE_MODE_TYPES_SUPPORTED = ["default", "endee_bm25"]

# ---------------------------------------------------------------------------
# Override from endee SDK (single try/except for all)
# ---------------------------------------------------------------------------
try:
    from endee.constants import DEFAULT_EF_SEARCH as DEFAULT_EF_SEARCH
    from endee.constants import MAX_DIMENSION_ALLOWED as MAX_DIMENSION_ALLOWED
    from endee.constants import MAX_EF_SEARCH_ALLOWED as MAX_EF_SEARCH_ALLOWED
    from endee.constants import MAX_INDEX_NAME_LENGTH_ALLOWED as MAX_INDEX_NAME_LENGTH_ALLOWED
    from endee.constants import MAX_KEY_BYTES as MAX_KEY_BYTES
    from endee.constants import MAX_TOP_K_ALLOWED as MAX_TOP_K_ALLOWED
    from endee.constants import MAX_VALUE_BYTES as MAX_VALUE_BYTES
    from endee.constants import MAX_VECTORS_PER_BATCH as MAX_VECTORS_PER_BATCH
    from endee.constants import SPARSE_MODE_TYPES_SUPPORTED as SPARSE_MODE_TYPES_SUPPORTED
except ImportError:
    pass



# ---------------------------------------------------------------------------
# Precision enum (from SDK, with fallback)
# ---------------------------------------------------------------------------
try:
    from endee.constants import Precision
except ImportError:
    from enum import Enum

    class Precision(str, Enum):  # type: ignore[no-redef]
        """Fallback Precision enum when endee SDK is too old."""

        BINARY2 = "binary"
        FLOAT16 = "float16"
        FLOAT32 = "float32"
        INT16 = "int16"
        INT8 = "int8"


# ---------------------------------------------------------------------------
# Integration-level constants (not from SDK)
# ---------------------------------------------------------------------------




DEFAULT_BATCH_SIZE = 100

# LlamaIndex FilterOperator → Endee API symbol
SUPPORTED_FILTER_OPERATORS = (
    FilterOperator.EQ,
    FilterOperator.IN,
)

REVERSE_OPERATOR_MAP = {
    FilterOperator.EQ: "$eq",
    FilterOperator.IN: "$in",
}
