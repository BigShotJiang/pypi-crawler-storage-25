"""Ray backend for VizFlow execute — plan serialization + distribution.

Workers collect plans and write parquet files independently (no commit).
The head node then commits ALL files in a single Delta transaction.
This avoids commit conflicts entirely — no retries needed.

Supports both LazyFrame and MapFunction via tagged serialization.
Ray is imported lazily. This module is only loaded when backend="ray".
"""

from __future__ import annotations

import io
import json
import logging
import uuid

logger = logging.getLogger("vizflow.execute.ray")


def _serialize_item(item) -> bytes:
    """Tagged serialization: LazyFrame or MapFunction → bytes.

    Uses cloudpickle for the envelope so workers can dispatch by type tag.
    LazyFrame plan bytes are nested inside (Polars native serialization preserved).
    """
    import cloudpickle

    from .plan import MapFunction

    if isinstance(item, MapFunction):
        return item.serialize()
    else:
        # LazyFrame — wrap with tag, preserve Polars native serialization
        return cloudpickle.dumps({"type": "plan", "data": item.serialize()})


def _deserialize_and_collect(item_bytes: bytes):
    """Tagged deserialization → collect → DataFrame."""
    import cloudpickle
    import polars as pl

    item = cloudpickle.loads(item_bytes)
    if item["type"] == "map_fn":
        from .plan import MapFunction

        task = MapFunction(fn=item["fn"], args=item["args"])
        return task.collect()
    else:
        lf = pl.LazyFrame.deserialize(io.BytesIO(item["data"]))
        return lf.collect()


def execute_ray(
    items: list,
    path: str,
    mode: str,
    storage: str,
    storage_options: dict[str, str] | None,
    partition_by: str | list[str] | None,
) -> list[dict]:
    """Distribute LogicPlan items to Ray workers for collection and writing.

    Architecture:
        1. If mode="overwrite", first item runs on driver to establish the table.
        2. Workers collect items and write parquet files to the table directory
           (UUID-named, no Delta commit — zero conflict).
        3. Head commits all worker-written files in a single Delta transaction.

    Args:
        items: List of LogicPlan items (LazyFrame, MapFunction, etc.).
        path: Output path (S3, CPFS, local).
        mode: "overwrite" or "append".
        storage: "delta" or "parquet".
        storage_options: Passed to storage layer.
        partition_by: Column(s) for Delta partitioning.

    Returns:
        List of result dicts from workers.
    """
    import ray

    if not ray.is_initialized():
        raise RuntimeError(
            "Ray is not initialized. Call ray.init() before using backend='ray'."
        )

    part_list = _normalize_partition_by(partition_by)
    remaining = items

    # mode="overwrite": first item on driver to establish/clear the table
    if mode == "overwrite" and items:
        logger.info("Collecting first item on driver (mode='overwrite')...")
        df0 = items[0].collect()
        _write_delta_full(df0, path, "overwrite", storage_options, part_list)
        logger.info("First item: %d rows written.", len(df0))
        remaining = items[1:]

    if not remaining:
        return [{"rows": len(df0)}] if mode == "overwrite" else []

    # Serialize and submit to workers
    serialized = [_serialize_item(item) for item in remaining]
    logger.info("Serialized %d items, submitting to Ray...", len(serialized))

    remote_fn = ray.remote(_collect_and_write_parquet)
    futures = [
        remote_fn.remote(item_bytes, path, storage_options, part_list)
        for item_bytes in serialized
    ]

    # Collect results (each result contains file metadata, no Delta commit yet)
    results = []
    if mode == "overwrite":
        results.append({"rows": len(df0), "actions": []})

    pending = list(futures)
    total = len(futures)
    while pending:
        done, pending = ray.wait(pending, num_returns=min(10, len(pending)), timeout=10.0)
        for ref in done:
            try:
                result = ray.get(ref)
                results.append(result)
            except Exception as e:
                results.append({"error": str(e)})
        completed = total - len(pending)
        logger.info("Progress: %d/%d completed", completed, total)

    errors = [r for r in results if "error" in r]
    if errors:
        raise RuntimeError(
            f"{len(errors)}/{len(results)} tasks failed. "
            f"First error: {errors[0]['error']}"
        )

    # Commit all worker-written files in ONE Delta transaction
    all_actions = []
    for r in results:
        all_actions.extend(r.get("actions", []))

    if all_actions:
        _commit_actions(path, all_actions, storage_options, part_list)
        total_rows = sum(r["rows"] for r in results)
        logger.info(
            "Committed %d files (%d rows) in a single transaction.",
            len(all_actions), total_rows,
        )

    return results


def _collect_and_write_parquet(
    item_bytes: bytes,
    table_path: str,
    storage_options: dict[str, str] | None,
    partition_by: list[str] | None,
) -> dict:
    """Ray worker: deserialize item → collect → write parquet (no Delta commit).

    Handles both LazyFrame and MapFunction via tagged deserialization.
    Returns file metadata so the head can commit all files at once.
    """
    df = _deserialize_and_collect(item_bytes)

    if partition_by:
        actions = _write_partitioned(df, table_path, storage_options, partition_by)
    else:
        actions = _write_unpartitioned(df, table_path, storage_options)

    return {"rows": len(df), "actions": actions}


def _write_partitioned(
    df,
    table_path: str,
    storage_options: dict[str, str] | None,
    partition_by: list[str],
) -> list[dict]:
    """Write partitioned parquet files, return AddAction metadata."""
    import polars as pl

    actions = []
    data_cols = [c for c in df.columns if c not in partition_by]

    for group_vals, group_df in df.group_by(partition_by):
        if not isinstance(group_vals, tuple):
            group_vals = (group_vals,)

        # Build partition path: part_col=val/part_col2=val2/...
        part_segments = []
        part_values = {}
        for col, val in zip(partition_by, group_vals):
            str_val = str(val)
            part_segments.append(f"{col}={str_val}")
            part_values[col] = str_val

        fname = f"part-{uuid.uuid4()}.parquet"
        rel_path = "/".join(part_segments) + f"/{fname}"
        full_path = f"{table_path}/{rel_path}"

        # Ensure parent dir exists for local paths
        if not full_path.startswith("s3://"):
            import os
            os.makedirs(f"{table_path}/{'/'.join(part_segments)}", exist_ok=True)

        group_df.select(data_cols).write_parquet(
            full_path, storage_options=storage_options,
        )

        actions.append({
            "path": rel_path,
            "num_rows": len(group_df),
            "partition_values": part_values,
        })

    return actions


def _write_unpartitioned(
    df,
    table_path: str,
    storage_options: dict[str, str] | None,
) -> list[dict]:
    """Write a single parquet file, return AddAction metadata."""
    fname = f"part-{uuid.uuid4()}.parquet"
    full_path = f"{table_path}/{fname}"

    df.write_parquet(full_path, storage_options=storage_options)

    return [{
        "path": fname,
        "num_rows": len(df),
        "partition_values": {},
    }]


def _commit_actions(
    table_path: str,
    actions: list[dict],
    storage_options: dict[str, str] | None,
    partition_by: list[str] | None,
) -> None:
    """Commit all worker-written parquet files in a single Delta transaction."""
    from deltalake import DeltaTable
    from deltalake.transaction import AddAction

    dt = DeltaTable(table_path, storage_options=storage_options or {})
    schema = dt.schema()

    add_actions = []
    for a in actions:
        full_path = f"{table_path}/{a['path']}"
        size = _get_file_size(full_path, storage_options)

        add_actions.append(AddAction(
            path=a["path"],
            size=size,
            partition_values=a["partition_values"],
            modification_time=0,
            data_change=True,
            stats=json.dumps({"numRecords": a["num_rows"]}),
        ))

    dt.create_write_transaction(
        actions=add_actions,
        mode="append",
        schema=schema,
        partition_by=partition_by or [],
    )


def _get_file_size(path: str, storage_options: dict[str, str] | None) -> int:
    """Get file size for local or S3 paths."""
    if path.startswith("s3://"):
        import boto3

        bucket, key = path[5:].split("/", 1)
        region = (storage_options or {}).get("AWS_REGION", "eu-west-1")
        s3 = boto3.client("s3", region_name=region)
        resp = s3.head_object(Bucket=bucket, Key=key)
        return resp["ContentLength"]
    else:
        import os

        return os.path.getsize(path)


def _write_delta_full(
    df,
    path: str,
    mode: str,
    storage_options: dict[str, str] | None,
    partition_by: list[str] | None,
) -> None:
    """Write Delta on driver (full commit — used for first plan in overwrite mode)."""
    kwargs: dict = {}
    if partition_by:
        kwargs["delta_write_options"] = {"partition_by": partition_by}
    df.write_delta(
        path,
        mode=mode,
        storage_options=storage_options or {},
        **kwargs,
    )


def _normalize_partition_by(partition_by: str | list[str] | None) -> list[str] | None:
    """Normalize partition_by to list or None."""
    if partition_by is None:
        return None
    if isinstance(partition_by, str):
        return [partition_by]
    return list(partition_by)
