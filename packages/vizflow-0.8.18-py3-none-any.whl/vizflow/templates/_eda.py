"""EDA (Exploratory Data Analysis) whiteboards."""
from __future__ import annotations

import textwrap

PLANS: dict[str, dict[str, str]] = {
    "univ_touch_size_check": {
        "description": "sanity-check avg_touch_size units: compare univ vs quote bid/ask_size0",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            import seaborn as sns
            import matplotlib.pyplot as plt
            from pathlib import Path

            sns.set_theme(style="whitegrid", palette="muted")

            # --- Config (edit these) ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            # --- Plan ---
            # ═══════════════════════════════════════════════════════════════
            # Load all dates, only needed columns (pushdown)
            # ═══════════════════════════════════════════════════════════════
            COLS = ["ukey", "bid_size0_at_order", "ask_size0_at_order", "avg_touch_size"]
            lf = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS)
                for d in DATES
            ])

            df_check = (
                lf.group_by("ukey")
                .agg(
                    pl.col("bid_size0_at_order").mean().alias("mean_bid_size0"),
                    pl.col("ask_size0_at_order").mean().alias("mean_ask_size0"),
                    pl.col("avg_touch_size").first(),
                    pl.len().alias("n_orders"),
                )
                .with_columns(
                    ratio_bid=(pl.col("mean_bid_size0") / pl.col("avg_touch_size")),
                    ratio_ask=(pl.col("mean_ask_size0") / pl.col("avg_touch_size")),
                )
                .sort("ratio_bid")
                .collect()
            )
            print(f"Total ukeys: {len(df_check)}, dates: {len(DATES)}")
            print(df_check.describe())

            # ═══════════════════════════════════════════════════════════════
            # 2. Ratio distribution — are they in the same unit?
            # ═══════════════════════════════════════════════════════════════
            pdf = df_check.select("ratio_bid", "ratio_ask").to_pandas()
            fig, axes = plt.subplots(1, 2, figsize=(12, 4))
            for ax, col in zip(axes, ["ratio_bid", "ratio_ask"]):
                sns.histplot(pdf[col].dropna(), bins=50, kde=True, ax=ax)
                ax.axvline(1.0, color="red", ls="--", label="ratio=1")
                ax.set_xlabel(col)
                ax.legend()
            fig.suptitle("bid/ask_size0 vs avg_touch_size — ratio distribution")
            fig.tight_layout()
            plt.show()

            # ═══════════════════════════════════════════════════════════════
            # 3. Extreme outliers — which ukeys have ratio < 0.1 or > 10?
            # ═══════════════════════════════════════════════════════════════
            outliers = df_check.filter(
                (pl.col("ratio_bid") < 0.1) | (pl.col("ratio_bid") > 10)
            )
            print(f"\\nOutliers (ratio < 0.1 or > 10): {len(outliers)} / {len(df_check)}")
            print(outliers.select("ukey", "mean_bid_size0", "mean_ask_size0", "avg_touch_size", "ratio_bid", "n_orders"))
        """),
    },
    "bucket_distribution": {
        "description": "inspect raw distribution of any bucket expression before running stats",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            import seaborn as sns
            import matplotlib.pyplot as plt
            from pathlib import Path

            sns.set_theme(style="whitegrid", palette="muted")

            # --- Config (edit these) ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            # --- Plan ---
            # ═══════════════════════════════════════════════════════════════
            # Load all dates, only needed columns (pushdown)
            # ═══════════════════════════════════════════════════════════════
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))

            COLS = ["ukey", "order_side", "fill_notional",
                    "bid_size0_at_order", "ask_size0_at_order", "avg_touch_size"]
            lf = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS)
                for d in DATES
            ])

            df = (
                lf.with_columns(near_at_order.alias("near_at_order"))
                .with_columns(
                    near_touch_size_improvement=(
                        (pl.col("near_at_order") - pl.col("avg_touch_size"))
                        / (pl.col("near_at_order") + pl.col("avg_touch_size"))
                    ),
                )
                .collect()
            )

            # ═══════════════════════════════════════════════════════════════
            # Distribution by side
            # ═══════════════════════════════════════════════════════════════
            pdf = df.select("order_side", "near_touch_size_improvement").to_pandas()
            g = sns.FacetGrid(pdf, col="order_side", sharey=True, height=4, aspect=1.3)
            g.map(sns.histplot, "near_touch_size_improvement", bins=100, binrange=(-1, 1), kde=True)
            g.map(plt.axvline, x=0, color="red", ls="--")
            g.set_xlabels("near_touch_size_improvement")
            g.figure.suptitle("Raw near_touch_size_improvement distribution", y=1.02)
            plt.show()

            # ═══════════════════════════════════════════════════════════════
            # Summary stats
            # ═══════════════════════════════════════════════════════════════
            print(
                df.group_by("order_side").agg(
                    pl.col("near_touch_size_improvement").mean().alias("mean"),
                    pl.col("near_touch_size_improvement").median().alias("median"),
                    pl.col("near_touch_size_improvement").quantile(0.1).alias("p10"),
                    pl.col("near_touch_size_improvement").quantile(0.9).alias("p90"),
                    pl.col("near_touch_size_improvement").is_null().sum().alias("n_null"),
                    pl.len().alias("n"),
                )
            )
        """),
    },
    "order_placement_vs_touch": {
        "description": "JOIN order placement: distance from order_price to near-touch, by side (positive=deeper/passive)",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            import seaborn as sns
            import matplotlib.pyplot as plt
            from pathlib import Path

            sns.set_theme(style="whitegrid", palette="muted")

            # --- Config (edit these) ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            # --- Plan ---
            # ═══════════════════════════════════════════════════════════════
            # Load all dates, filter + select pushdown
            # ═══════════════════════════════════════════════════════════════
            # bid_px0_trade / ask_px0_trade are the trade-log's own quote
            # snapshot — but it's per-EVENT, not per-order.
            # MUST filter to ORDNEW to get the true book at order creation.
            is_buy = pl.col("order_side") == "Buy"
            near_touch_px = pl.when(is_buy).then(pl.col("bid_px0_trade")).otherwise(pl.col("ask_px0_trade"))

            COLS = ["ukey", "order_side", "order_price", "fill_notional",
                    "bid_px0_trade", "ask_px0_trade",
                    "order_price_type", "event_type"]
            lf = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS)
                for d in DATES
            ])

            df = (
                lf.filter(pl.col("order_price_type") == "JOIN")
                .filter(pl.col("event_type") == "ORDNEW")
                .with_columns(near_touch_px.alias("near_touch_px"))
                .filter(pl.col("near_touch_px") > 0)
                .with_columns(
                    distance_px=pl.when(is_buy)
                        .then(pl.col("near_touch_px") - pl.col("order_price"))
                        .otherwise(pl.col("order_price") - pl.col("near_touch_px")),
                )
                .with_columns(
                    distance_ticks=(pl.col("distance_px") / 0.01).round(0),
                )
                .collect()
            )

            # ═══════════════════════════════════════════════════════════════
            # 1. Distance in ticks — histogram by side
            # ═══════════════════════════════════════════════════════════════
            pdf = df.select("order_side", "distance_ticks").to_pandas()
            g = sns.FacetGrid(pdf, col="order_side", sharey=True, height=4, aspect=1.3)
            g.map(sns.histplot, "distance_ticks", bins=range(-20, 22), discrete=True)
            g.map(plt.axvline, x=0, color="red", ls="--")
            g.set_xlabels("distance from near touch (ticks)\\n\\u2190 aggressive | passive \\u2192")
            g.figure.suptitle("Order Placement vs Near Touch (ORDNEW only)", y=1.02)
            plt.show()

            # ═══════════════════════════════════════════════════════════════
            # 2. Summary per side
            # ═══════════════════════════════════════════════════════════════
            for side in ["Buy", "Sell"]:
                sub = df.filter(pl.col("order_side") == side)
                n = len(sub)
                n_at = sub.filter(pl.col("distance_ticks") == 0).height
                n_deep = sub.filter(pl.col("distance_ticks") > 0).height
                n_cross = sub.filter(pl.col("distance_ticks") < 0).height
                print(f"\\n{side} (n={n}):")
                print(f"  At touch (0):       {n_at:>5} ({n_at/n*100:5.1f}%)")
                print(f"  Deeper/passive (>0):{n_deep:>5} ({n_deep/n*100:5.1f}%)")
                print(f"  Crossing       (<0):{n_cross:>5} ({n_cross/n*100:5.1f}%)")
        """),
    },
    "spread_at_order": {
        "description": "JOIN order spread analysis: spread in price and ticks at order creation time",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            import seaborn as sns
            import matplotlib.pyplot as plt
            from pathlib import Path

            sns.set_theme(style="whitegrid", palette="muted")

            # --- Config (edit these) ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            # --- Plan ---
            # ═══════════════════════════════════════════════════════════════
            # Load all dates, filter + select pushdown (ORDNEW only)
            # ═══════════════════════════════════════════════════════════════
            COLS = ["ukey", "order_side", "fill_notional",
                    "bid_px0_trade", "ask_px0_trade",
                    "order_price_type", "event_type"]
            lf = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS)
                for d in DATES
            ])

            df = (
                lf.filter(pl.col("order_price_type") == "JOIN")
                .filter(pl.col("event_type") == "ORDNEW")
                .filter(
                    (pl.col("bid_px0_trade") > 0) & (pl.col("ask_px0_trade") > 0)
                )
                .with_columns(
                    spread_px=pl.col("ask_px0_trade") - pl.col("bid_px0_trade"),
                )
                .with_columns(
                    spread_ticks=(pl.col("spread_px") / 0.01).round(0),
                    spread_bps=(
                        pl.col("spread_px")
                        / ((pl.col("bid_px0_trade") + pl.col("ask_px0_trade")) / 2)
                        * 1e4
                    ),
                )
                .collect()
            )

            # ═══════════════════════════════════════════════════════════════
            # 1. Spread in ticks — value counts
            # ═══════════════════════════════════════════════════════════════
            vc = (
                df.group_by("spread_ticks").agg(
                    pl.len().alias("count"),
                    pl.col("fill_notional").sum().alias("sum_notional"),
                )
                .sort("spread_ticks")
                .with_columns(
                    pct=(pl.col("count") / pl.col("count").sum() * 100).round(1),
                    notional_pct=(pl.col("sum_notional") / pl.col("sum_notional").sum() * 100).round(1),
                )
            )
            print("Spread distribution (in ticks):")
            print(vc)

            # ═══════════════════════════════════════════════════════════════
            # 2. Plot
            # ═══════════════════════════════════════════════════════════════
            pdf = df.select("spread_ticks").to_pandas()
            fig, ax = plt.subplots(figsize=(8, 4))
            sns.countplot(data=pdf, x="spread_ticks", ax=ax)
            ax.set_xlabel("spread (ticks)")
            ax.set_ylabel("count")
            ax.set_title("Spread at JOIN Order Time (ORDNEW only)")
            fig.tight_layout()
            plt.show()

            # ═══════════════════════════════════════════════════════════════
            # 3. Summary
            # ═══════════════════════════════════════════════════════════════
            n = len(df)
            n_1tick = df.filter(pl.col("spread_ticks") == 1).height
            print(f"\\n1-tick spread: {n_1tick}/{n} ({n_1tick/n*100:.1f}%)")
            print(f"Mean spread: {df['spread_ticks'].mean():.2f} ticks, {df['spread_bps'].mean():.2f} bps")
            print(f"Median spread: {df['spread_ticks'].median():.1f} ticks")
        """),
    },
    "book_snapshot_is_per_event": {
        "description": "verify trade-log bid/ask is per-event (real-time), not frozen at order creation",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            from pathlib import Path

            # --- Config (edit these) ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            # --- Plan ---
            # ═══════════════════════════════════════════════════════════════
            # Load all dates, only needed columns (pushdown)
            # ═══════════════════════════════════════════════════════════════
            # If bid_px0_trade is frozen at order creation, it should be
            # identical across ORDNEW → ORDACK → ORDFILL for the same order.
            # If it changes, it's a real-time snapshot per event.
            COLS = ["order_id", "event_type", "ukey", "order_side",
                    "bid_px0_trade", "ask_px0_trade",
                    "bid_size0_trade", "ask_size0_trade"]
            df = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS).collect()
                for d in DATES
            ])

            # ═══════════════════════════════════════════════════════════════
            # Pick orders that have multiple events with different book states
            # ═══════════════════════════════════════════════════════════════
            df_diff = (
                df.group_by("order_id")
                .agg(
                    pl.col("event_type").alias("events"),
                    pl.col("bid_px0_trade").n_unique().alias("n_bid_px"),
                    pl.col("ask_px0_trade").n_unique().alias("n_ask_px"),
                    pl.col("bid_size0_trade").n_unique().alias("n_bid_sz"),
                    pl.col("ask_size0_trade").n_unique().alias("n_ask_sz"),
                    pl.len().alias("n_events"),
                )
                .filter(pl.col("n_events") > 1)
            )

            n_orders = len(df_diff)
            n_changed_px = df_diff.filter(
                (pl.col("n_bid_px") > 1) | (pl.col("n_ask_px") > 1)
            ).height
            n_changed_sz = df_diff.filter(
                (pl.col("n_bid_sz") > 1) | (pl.col("n_ask_sz") > 1)
            ).height

            print(f"Orders with >1 event: {n_orders}")
            print(f"  bid/ask PRICE changed across events: {n_changed_px} ({n_changed_px/n_orders*100:.1f}%)")
            print(f"  bid/ask SIZE  changed across events: {n_changed_sz} ({n_changed_sz/n_orders*100:.1f}%)")
            print()

            if n_changed_px > 0 or n_changed_sz > 0:
                print("CONFIRMED: book snapshot is per-event (real-time), NOT frozen at order creation.")
            else:
                print("WARNING: no changes detected — book may be frozen, or sample too small.")

            # ═══════════════════════════════════════════════════════════════
            # Show a few concrete examples
            # ═══════════════════════════════════════════════════════════════
            example_ids = df_diff.filter(
                (pl.col("n_bid_px") > 1) | (pl.col("n_ask_px") > 1)
            ).head(3)["order_id"].to_list()

            if example_ids:
                print("\\n--- Example orders where book changed across events ---")
                print(
                    df.filter(pl.col("order_id").is_in(example_ids))
                    .sort("order_id", "event_type")
                    .select("order_id", "event_type", "order_side",
                            "bid_px0_trade", "ask_px0_trade",
                            "bid_size0_trade", "ask_size0_trade")
                )
        """),
    },
}
