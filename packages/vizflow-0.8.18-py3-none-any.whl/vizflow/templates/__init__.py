"""VizFlow Templates — plan whiteboards for notebook and batch workflows.

Usage:
    import vizflow as vf

    vf.templates.list()                          # see available plans
    vf.templates.show("daily_forward_stats")     # print notebook-ready code
"""
from __future__ import annotations

from vizflow.templates._eda import PLANS as _EDA
from vizflow.templates._enrichment import PLANS as _ENRICHMENT
from vizflow.templates._plots import PLANS as _PLOTS
from vizflow.templates._stats import PLANS as _STATS

_PLANS: dict[str, dict[str, str]] = {**_ENRICHMENT, **_STATS, **_PLOTS, **_EDA}


def list() -> None:
    """Print available plan whiteboards with descriptions."""
    max_name = max(len(name) for name in _PLANS)
    print(f"{'name':<{max_name}}  description")
    print(f"{'─' * max_name}  {'─' * 50}")
    for name, info in _PLANS.items():
        print(f"{name:<{max_name}}  {info['description']}")


def show(name: str) -> None:
    """Print notebook-ready plan code to stdout. Copy-paste into a notebook cell.

    Args:
        name: Plan name (see ``list()`` for available plans).
    """
    if name not in _PLANS:
        available = ", ".join(_PLANS)
        raise KeyError(f"Plan '{name}' not found. Available: {available}")

    code = _PLANS[name]["code"]

    try:
        from rich.console import Console
        from rich.syntax import Syntax
        console = Console()
        syntax = Syntax(code, "python", theme="monokai", line_numbers=False, word_wrap=True)
        console.print(syntax)
    except ImportError:
        print(code)
