"""Plotting whiteboards."""
from __future__ import annotations

import textwrap

PLANS: dict[str, dict[str, str]] = {
    "plot_bucketed_stats_1d": {
        "description": "1D bucketed stats → overview (2×2) + interday/TOD per value_col (notebook, seaborn)",
        "code": textwrap.dedent("""\
            import datetime
            import polars as pl
            import matplotlib.pyplot as plt
            import matplotlib.dates as mdates
            import seaborn as sns
            from pathlib import Path
            from matplotlib.patches import Patch

            # --- Config ---
            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/")
            bucket_names = [
                "tod_spread_improvement",
                "near_touch_size_improvement",
                "far_touch_size_improvement",
                "sta_bps",
                "lta_bps",
            ]

            weight_col = "fill_notional"
            sum_w_col  = f"sum_{weight_col}"

            # Value columns + their horizon (ms) for interday/TOD figures
            VALUE_COLS = {
                "sided_markout": 60000,                # 60s
                "sided_fill_to_near_touch": 10000,     # 10s
            }
            CURVE_XLIM = (-10, 60)          # horizon (s) xlim for overview curves
            MIN_NOTIONAL_FRAC = 0.02        # drop buckets with < 2% of total fill notional

            ORDER_SIDES = ["Buy", "Sell"]   # always plot both sides
            ORDER_TYPES = ["JOIN"]          # add "LMT", "SQZ", "MKT" as needed

            # --- Read all bucket stats (only needed horizons) ---
            needed_horizons = (
                set(h * 1000 for h in range(CURVE_XLIM[0], CURVE_XLIM[1] + 1))
                | set(VALUE_COLS.values())
            )
            data = {}
            for bname in bucket_names:
                table_path = str(OUTPUT_DIR / f"{bname}_bucketing_stats")
                data[bname] = (
                    pl.scan_parquet(table_path + "/*.parquet")
                    .filter(pl.col("horizon").is_in(list(needed_horizons)))
                    .collect()
                )
                print(f"{bname}: {len(data[bname])} rows")


            # --- Helper: sort buckets by numeric left edge ---
            def _bucket_sort_key(label: str) -> float:
                \"\"\"Extract left edge from interval label like '(-0.8, -0.5]'.\"\"\"
                try:
                    left = label.split(",")[0].strip("([ ")
                    return float(left)
                except (ValueError, IndexError):
                    return float("inf")


            # --- Plot ---
            for bname in bucket_names:
                df = data[bname]
                bucket_col = f"bucket_{bname}"

                # Identify significant buckets (>= MIN_NOTIONAL_FRAC of total)
                df_h0_all = df.filter(pl.col("horizon") == 0).drop_nulls(bucket_col)
                total_notional = df_h0_all[sum_w_col].sum()
                keep_buckets = (
                    df_h0_all.group_by(bucket_col)
                    .agg(pl.col(sum_w_col).sum())
                    .filter(pl.col(sum_w_col) >= total_notional * MIN_NOTIONAL_FRAC)
                    [bucket_col].to_list()
                )

                # all_buckets = everything (for bar charts), curve_buckets = significant only
                all_buckets = sorted(
                    [b for b in df[bucket_col].unique().drop_nulls().to_list()],
                    key=_bucket_sort_key,
                )
                curve_buckets = sorted(
                    [b for b in keep_buckets if b is not None],
                    key=_bucket_sort_key,
                )
                n = len(all_buckets)
                if n == 0:
                    continue
                palette = dict(zip(all_buckets, sns.color_palette("coolwarm", n)))

                for opt in ORDER_TYPES:
                    for side in ORDER_SIDES:
                        df_sub = df.filter(
                            (pl.col("order_price_type") == opt)
                            & (pl.col("order_side") == side)
                        ).drop_nulls(bucket_col)
                        if len(df_sub) == 0:
                            continue

                        df_sub = df_sub.with_columns(
                            (pl.col("horizon") / 1000).alias("horizon_s")
                        )

                        # ═══════════════════════════════════════════════════
                        # Figure 1: Overview (2×2)
                        #   markout curve | fill-to-near-touch curve
                        #   fill notional | fill rate
                        # ═══════════════════════════════════════════════════
                        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
                        fig.suptitle(f"{bname} | {opt} | {side} — Overview",
                                     fontsize=14, fontweight="bold", y=0.98)

                        # (0,0) Sided Markout Curve — only significant buckets
                        ax = axes[0, 0]
                        sum_wv_col = f"sum_{weight_col}_x_sided_markout"
                        df_sig = df_sub.filter(pl.col(bucket_col).is_in(curve_buckets))
                        curve = (
                            df_sig.group_by(["horizon", "horizon_s", bucket_col])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4))
                            .to_pandas()
                        )
                        sns.lineplot(data=curve, x="horizon_s", y="bps", hue=bucket_col, palette=palette,
                                     hue_order=curve_buckets, ax=ax, marker="o", markersize=3, linewidth=1.2)
                        ax.set_title("Sided Markout (bps)")
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_xlim(*CURVE_XLIM)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)

                        # (0,1) Sided Fill-to-Near-Touch Curve — only significant buckets
                        ax = axes[0, 1]
                        sum_wv_touch = f"sum_{weight_col}_x_sided_fill_to_near_touch"
                        curve_t = (
                            df_sig.group_by(["horizon", "horizon_s", bucket_col])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_touch).sum()])
                            .with_columns(bps=(pl.col(sum_wv_touch) / pl.col(sum_w_col) * 1e4))
                            .to_pandas()
                        )
                        sns.lineplot(data=curve_t, x="horizon_s", y="bps", hue=bucket_col, palette=palette,
                                     hue_order=curve_buckets, ax=ax, marker="o", markersize=3, linewidth=1.2)
                        ax.set_title("Sided Fill-to-Near-Touch (bps)")
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_xlim(*CURVE_XLIM)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)

                        # (1,0) Fill Notional Distribution — aggregate across dates & tod_bin
                        ax = axes[1, 0]
                        dist = (
                            df_sub.filter(pl.col("horizon") == 0)
                            .group_by(bucket_col)
                            .agg([pl.col(sum_w_col).sum(), pl.col("sum_order_notional").sum()])
                        )
                        pdf_h0 = dist.to_pandas()
                        pdf_h0["_sort"] = pdf_h0[bucket_col].map(_bucket_sort_key)
                        pdf_h0 = pdf_h0.sort_values("_sort").drop(columns="_sort")
                        bar_colors = [palette.get(b, "grey") for b in pdf_h0[bucket_col]]
                        notional_vals = pdf_h0[sum_w_col].values
                        total = notional_vals.sum()
                        bars = ax.bar(range(len(pdf_h0)), notional_vals, color=bar_colors)
                        ax.set_xticks(range(len(pdf_h0)))
                        ax.set_xticklabels(pdf_h0[bucket_col].tolist(), rotation=45, ha="right", fontsize=7)
                        for bar, val in zip(bars, notional_vals):
                            pct = val / total * 100
                            ax.annotate(f"{pct:.1f}%", xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                                        ha="center", va="bottom", fontsize=8, color="#333")
                        ax.set_title("Fill Notional Distribution")
                        ax.set_ylabel("sum fill_notional")

                        # (1,1) Fill Rate Distribution — ylim 0-1, with percentage
                        ax = axes[1, 1]
                        fill_n = pdf_h0[sum_w_col].values
                        order_n = pdf_h0["sum_order_notional"].values
                        rates = [f / o if o > 0 else 0 for f, o in zip(fill_n, order_n)]
                        bars = ax.bar(range(len(pdf_h0)), rates, color=bar_colors)
                        ax.set_xticks(range(len(pdf_h0)))
                        ax.set_xticklabels(pdf_h0[bucket_col].tolist(), rotation=45, ha="right", fontsize=7)
                        ax.set_ylim(0, 1)
                        for bar, r in zip(bars, rates):
                            ax.annotate(f"{r:.1%}", xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                                        ha="center", va="bottom", fontsize=8, color="#333")
                        ax.set_title("Fill Rate")
                        ax.set_ylabel("fill_notional / order_notional")

                        plt.tight_layout()
                        plt.show()

                        # ═══════════════════════════════════════════════════
                        # Figure 2+: Interday + TOD per value_col
                        # ═══════════════════════════════════════════════════
                        for value_col, vcol_horizon in VALUE_COLS.items():
                            cumsum_h_s = vcol_horizon / 1000
                            sum_wv_col = f"sum_{weight_col}_x_{value_col}"

                            fig, (ax_inter, ax_tod) = plt.subplots(2, 1, figsize=(14, 8),
                                                                    height_ratios=[1, 1])
                            fig.suptitle(f"{bname} | {opt} | {side} — {value_col}",
                                         fontsize=14, fontweight="bold", y=0.98)

                            # Row 0: Interday Cumsum — significant buckets only
                            df_sig2 = df_sub.filter(pl.col(bucket_col).is_in(curve_buckets))
                            daily = (
                                df_sig2.filter(pl.col("horizon") == vcol_horizon)
                                .group_by(["data_date", bucket_col])
                                .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                                .sort("data_date")
                                .with_columns(
                                    daily_bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                )
                                .with_columns(
                                    cum_bps=pl.col("daily_bps").cum_sum().over(bucket_col),
                                )
                            )
                            pdf_daily = daily.to_pandas()
                            sns.lineplot(data=pdf_daily, x="data_date", y="cum_bps",
                                         hue=bucket_col, palette=palette, hue_order=curve_buckets,
                                         ax=ax_inter, linewidth=1.2)
                            ax_inter.axhline(0, color="red", ls="--", lw=0.8)
                            ax_inter.set(xlabel="date", ylabel=f"Cumulative {value_col} (bps)",
                                         title=f"Interday Cumsum — {value_col} @ horizon={cumsum_h_s:.0f}s")
                            ax_inter.legend(fontsize=6, ncol=4, title=bname, title_fontsize=7)

                            # Row 1: TOD — overlapping bars, significant buckets only
                            tod = (
                                df_sig2.filter(pl.col("horizon") == vcol_horizon)
                                .group_by(["tod_bin", bucket_col])
                                .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                                .with_columns(bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4))
                                .sort("tod_bin")
                            )
                            pdf_tod = tod.to_pandas()
                            bar_width = datetime.timedelta(minutes=5)

                            # Draw bars: tallest (abs) first → shortest last (foreground)
                            for bucket in sorted(curve_buckets, key=lambda b: abs(pdf_tod.loc[pdf_tod[bucket_col] == b, "bps"].mean() or 0), reverse=True):
                                bdf = pdf_tod[pdf_tod[bucket_col] == bucket].sort_values("tod_bin")
                                if len(bdf) == 0:
                                    continue
                                ax_tod.bar(bdf["tod_bin"], bdf["bps"],
                                           width=bar_width, align="edge", color=palette[bucket], alpha=0.7)

                            ax_tod.axhline(0, color="grey", ls="--", lw=0.5)
                            ax_tod.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
                            ax_tod.legend(handles=[Patch(facecolor=palette[b], alpha=0.7, label=b) for b in curve_buckets],
                                          fontsize=6, ncol=4, title=bname, title_fontsize=7)
                            ax_tod.set(xlabel="time of day", ylabel=f"{value_col} (bps)",
                                       title=f"TOD — {value_col} @ horizon={cumsum_h_s:.0f}s (multi-day avg)")

                            plt.tight_layout()
                            plt.show()"""),
    },
    "plot_bucketed_stats_2d": {
        "description": "2D bucketed stats → heatmap (notional/markout/fill_rate) + marginalized 1D curves (notebook)",
        "code": textwrap.dedent("""\
            import polars as pl
            import matplotlib.pyplot as plt
            import matplotlib.colors as mcolors
            import numpy as np
            from pathlib import Path

            # --- Config ---
            STATS_DIR = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_2d")
            # Which pair to plot (edit these)
            PAIR = "sta_bps_x_near_touch_size_improvement"
            BUCKET_A = "bucket_sta_bps"
            BUCKET_B = "bucket_near_touch_size_improvement"

            weight_col = "fill_notional"
            sum_w_col  = f"sum_{weight_col}"

            VALUE_COLS = {
                "sided_markout": 60000,
                "sided_fill_to_near_touch": 10000,
            }
            MIN_NOTIONAL = 1e6   # mask cells with less than this

            ORDER_SIDES = ["Buy", "Sell"]
            ORDER_TYPES = ["JOIN"]

            # --- Helper: sort buckets by numeric left edge ---
            def _bucket_sort_key(label: str) -> float:
                try:
                    return float(label.split(",")[0].strip("([ "))
                except (ValueError, IndexError):
                    return float("inf")

            # --- Read ---
            table_path = str(STATS_DIR / f"{PAIR}_2d_stats")
            df = pl.scan_parquet(table_path + "/*.parquet").collect()
            print(f"Read {len(df)} rows")

            # --- Sort bucket labels ---
            bins_a = sorted([b for b in df[BUCKET_A].unique().drop_nulls().to_list()], key=_bucket_sort_key)
            bins_b = sorted([b for b in df[BUCKET_B].unique().drop_nulls().to_list()], key=_bucket_sort_key)

            # --- Plot ---
            for opt in ORDER_TYPES:
                for side in ORDER_SIDES:
                    df_sub = df.filter(
                        (pl.col("order_price_type") == opt)
                        & (pl.col("order_side") == side)
                    ).drop_nulls([BUCKET_A, BUCKET_B])
                    if len(df_sub) == 0:
                        continue

                    for value_col, vcol_horizon in VALUE_COLS.items():
                        sum_wv_col = f"sum_{weight_col}_x_{value_col}"
                        h_s = vcol_horizon / 1000

                        # Aggregate across dates for fixed horizon
                        agg = (
                            df_sub.filter(pl.col("horizon") == vcol_horizon)
                            .group_by([BUCKET_A, BUCKET_B])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum(),
                                  pl.col("sum_order_notional").sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                fill_rate=pl.col(sum_w_col) / pl.col("sum_order_notional"),
                            )
                        ).to_pandas()

                        # Pivot to 2D arrays
                        na = len(bins_a)
                        nb = len(bins_b)
                        notional_2d = np.full((nb, na), np.nan)
                        markout_2d  = np.full((nb, na), np.nan)
                        fillrate_2d = np.full((nb, na), np.nan)

                        for _, row in agg.iterrows():
                            ia = bins_a.index(row[BUCKET_A]) if row[BUCKET_A] in bins_a else -1
                            ib = bins_b.index(row[BUCKET_B]) if row[BUCKET_B] in bins_b else -1
                            if ia >= 0 and ib >= 0:
                                notional_2d[ib, ia] = row[sum_w_col]
                                markout_2d[ib, ia]  = row["bps"]
                                fillrate_2d[ib, ia] = row["fill_rate"]

                        # Mask low notional
                        mask = notional_2d < MIN_NOTIONAL
                        markout_masked  = np.ma.array(markout_2d, mask=mask)
                        fillrate_masked = np.ma.array(fillrate_2d, mask=mask)

                        # === Figure: 3 heatmaps + 2 marginalized curves ===
                        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
                        fig.suptitle(f"{PAIR} | {opt} | {side} — {value_col} @ h={h_s:.0f}s",
                                     fontsize=14, fontweight="bold")

                        # Row 0: Heatmaps
                        # Notional (log scale)
                        ax = axes[0, 0]
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1),
                                           np.log10(np.where(notional_2d > 0, notional_2d, np.nan)),
                                           cmap="Blues")
                        fig.colorbar(im, ax=ax, label="log10(fill_notional)")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_xlabel(BUCKET_A.replace("bucket_", "")); ax.set_ylabel(BUCKET_B.replace("bucket_", ""))
                        ax.set_title("Fill Notional (log)")

                        # Markout (diverging, center=0)
                        ax = axes[0, 1]
                        vmax = np.nanmax(np.abs(markout_masked))
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1), markout_masked,
                                           cmap="RdBu_r", vmin=-vmax, vmax=vmax)
                        fig.colorbar(im, ax=ax, label="bps")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_title(f"{value_col} (bps)")

                        # Fill rate
                        ax = axes[0, 2]
                        im = ax.pcolormesh(np.arange(na+1), np.arange(nb+1), fillrate_masked,
                                           cmap="YlOrRd", vmin=0, vmax=1)
                        fig.colorbar(im, ax=ax, label="fill rate")
                        ax.set_xticks(np.arange(na) + 0.5); ax.set_xticklabels(bins_a, rotation=45, ha="right", fontsize=6)
                        ax.set_yticks(np.arange(nb) + 0.5); ax.set_yticklabels(bins_b, fontsize=6)
                        ax.set_title("Fill Rate")

                        # Row 1: Marginalized 1D curves
                        # Marginalize over bucket_b → curve per bucket_a
                        ax = axes[1, 0]
                        margin_a = (
                            df_sub.group_by(["horizon", BUCKET_A])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                horizon_s=(pl.col("horizon") / 1000),
                            ).to_pandas()
                        )
                        for b in bins_a:
                            bdf = margin_a[margin_a[BUCKET_A] == b].sort_values("horizon_s")
                            ax.plot(bdf["horizon_s"], bdf["bps"], label=b, linewidth=1)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.set_xlim(-10, 60)
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_title(f"Marginalized over {BUCKET_B.replace('bucket_', '')}")
                        ax.legend(fontsize=5, ncol=2)

                        # Marginalize over bucket_a → curve per bucket_b
                        ax = axes[1, 1]
                        margin_b = (
                            df_sub.group_by(["horizon", BUCKET_B])
                            .agg([pl.col(sum_w_col).sum(), pl.col(sum_wv_col).sum()])
                            .with_columns(
                                bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                                horizon_s=(pl.col("horizon") / 1000),
                            ).to_pandas()
                        )
                        for b in bins_b:
                            bdf = margin_b[margin_b[BUCKET_B] == b].sort_values("horizon_s")
                            ax.plot(bdf["horizon_s"], bdf["bps"], label=b, linewidth=1)
                        ax.axhline(0, color="grey", ls="--", lw=0.5)
                        ax.set_xlim(-10, 60)
                        ax.set_xlabel("horizon (s)"); ax.set_ylabel("bps")
                        ax.set_title(f"Marginalized over {BUCKET_A.replace('bucket_', '')}")
                        ax.legend(fontsize=5, ncol=2)

                        # Hide unused subplot
                        axes[1, 2].axis("off")

                        plt.tight_layout()
                        plt.show()"""),
    },
    "plot_interday_cumsum": {
        "description": "daily stats → interday cumulative weighted-mean curve per horizon (notebook, seaborn)",
        "code": textwrap.dedent("""\
            import polars as pl
            import matplotlib.pyplot as plt
            import seaborn as sns

            # --- Config ---
            # Path to daily_forward_stats (unbucketed) or {bname}_bucketing_stats (bucketed)
            stats_path = "/cpfs/user2/ylu/data/oic_live/merge_forward/daily_forward_stats"

            # Which value column to plot — pick ONE:
            #   "sided_markout", "sided_return", "sided_fill_to_near_touch"
            value_col = "sided_markout"

            # Weight column (matches WEIGHTS in compute script)
            weight_col = "fill_notional"

            # The aggregated column names follow the convention:
            #   sum_{weight}              → e.g. "sum_fill_notional"
            #   sum_{weight}_x_{value}    → e.g. "sum_fill_notional_x_sided_markout"
            sum_w_col  = f"sum_{weight_col}"
            sum_wv_col = f"sum_{weight_col}_x_{value_col}"

            # Filter (set to None to plot all)
            SIDE = "Buy"           # "Buy" | "Sell" | None
            TYPE = "JOIN"          # "LMT" | "JOIN" | None

            # Optional: for bucketed stats, set bucket_col and bucket_value
            # bucket_col   = "bucket_sta_bps"
            # bucket_value = "(-2, -1]"


            # --- Read ---
            daily = pl.scan_parquet(stats_path + "/*.parquet").collect()
            print(f"Read {len(daily)} rows, columns: {daily.columns}")

            # --- Filter ---
            mask = pl.lit(True)
            if SIDE is not None:
                mask = mask & (pl.col("order_side") == SIDE)
            if TYPE is not None:
                mask = mask & (pl.col("order_price_type") == TYPE)
            # Uncomment for bucketed:
            # mask = mask & (pl.col(bucket_col) == bucket_value)
            daily = daily.filter(mask)


            # --- Compute daily weighted mean (bps) + interday cumsum ---
            daily = (
                daily
                .with_columns(
                    daily_weighted_mean_bps=(pl.col(sum_wv_col) / pl.col(sum_w_col) * 1e4),
                    horizon_s=(pl.col("horizon") / 1000),
                )
                .sort("data_date")
                .with_columns(
                    cum_weighted_mean_bps=pl.col("daily_weighted_mean_bps")
                        .cum_sum()
                        .over("horizon"),
                )
            )


            # --- Plot ---
            pdf = daily.to_pandas()
            horizons_sorted = sorted(pdf["horizon_s"].unique())
            n = len(horizons_sorted)
            palette = dict(zip(horizons_sorted, sns.color_palette("coolwarm", n)))

            fig, ax = plt.subplots(figsize=(14, 6))
            sns.lineplot(
                data=pdf, x="data_date", y="cum_weighted_mean_bps",
                hue="horizon_s", palette=palette, hue_order=horizons_sorted,
                ax=ax, linewidth=1.0,
            )
            ax.axhline(0, color="red", ls="--", lw=0.8)
            ax.set(
                xlabel="date",
                ylabel=f"Cumulative {value_col} (bps)",
                title=f"Interday Cumsum: {SIDE} {TYPE} — {value_col}",
            )
            ax.legend(fontsize=6, ncol=4, title="horizon (s)", title_fontsize=7)
            plt.tight_layout()
            plt.show()"""),
    },
    "plot_fill_analysis": {
        "description": "fill survival analysis: KM curve, cumulative fill rate, duration distribution, notional bar (notebook)",
        "code": textwrap.dedent("""\
            import polars as pl
            import matplotlib.pyplot as plt
            import matplotlib.ticker as mticker
            import numpy as np
            import seaborn as sns
            from pathlib import Path
            from lifelines import KaplanMeierFitter
            from matplotlib.patches import Patch

            # --- Config ---
            BASE_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            DATES    = [f.stem for f in sorted(BASE_DIR.glob("*.parquet"))]

            ORDER_SIDES = ["Buy", "Sell"]
            ORDER_TYPES = ["JOIN"]
            MIN_NOTIONAL_FRAC = 0.02   # drop buckets with < 2% of total notional from curves

            # --- Bucket dimensions (same as execution_stats_1d) ---
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))

            BUCKETS = {
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
            }


            # --- Helper: sort buckets by numeric left edge ---
            def _bucket_sort_key(label: str) -> float:
                try:
                    return float(label.split(",")[0].strip("([ "))
                except (ValueError, IndexError):
                    return float("inf")


            # --- Load all dates ---
            COLS = [
                "seq", "data_date", "ukey", "order_id",
                "event_type", "order_side", "order_price_type",
                "order_qty", "order_price", "fill_qty", "fill_price",
                "duration",   # elapsed_update - elapsed_create (ms), from base enrichment
                "bid_size0_at_order", "ask_size0_at_order", "avg_touch_size",
                "alp_st", "alp_lt",
            ]
            lf = pl.concat([
                pl.scan_parquet(str(BASE_DIR / f"{d}.parquet")).select(COLS)
                for d in DATES
            ])

            # Compute bucket exprs + derived columns
            lf = (
                lf
                .filter(pl.col("order_price_type") != "UKWN")
                .with_columns([spec["expr"].alias(bname) for bname, spec in BUCKETS.items()])
                .with_columns(fill_notional=pl.col("fill_price") * pl.col("fill_qty"))
            )

            # --- Keys for order-level joins ---
            keys = ["data_date", "ukey", "order_id"]

            # order_info: one row per order (from ORDACK)
            order_info = lf.filter(pl.col("event_type") == "ORDACK")

            # order_notional: from ORDNEW (one per order, no double count)
            order_notional_df = (
                lf.filter(pl.col("event_type") == "ORDNEW")
                .with_columns(order_notional=(pl.col("order_qty") * pl.col("order_price")))
                .select(keys + ["order_notional"])
            )

            # cum_fill: total filled qty per order
            cum_fill = (
                lf.filter(pl.col("event_type") == "ORDFILL")
                .group_by(*keys)
                .agg(pl.col("fill_qty").sum().alias("total_filled_qty"))
            )

            # fills: each ORDFILL event is an observed event (event=1)
            fills = (
                lf.filter(pl.col("event_type") == "ORDFILL")
                .select(
                    *keys, pl.col("duration"),
                    pl.col("fill_notional").alias("weight"),
                    pl.lit(1).alias("event"),
                )
            )

            # cancels: ORDCXLACK event is censored (event=0), weight = unfilled notional
            cancels = (
                lf.filter(pl.col("event_type") == "ORDCXLACK")
                .select(*keys, pl.col("duration"))
                .join(order_info.select(*keys, "order_qty", "order_price"), on=keys, how="left")
                .join(cum_fill, on=keys, how="left")
                .with_columns(pl.col("total_filled_qty").fill_null(0))
                .with_columns(
                    ((pl.col("order_qty") - pl.col("total_filled_qty")) * pl.col("order_price")).alias("weight"),
                    pl.lit(0).alias("event"),
                )
                .select(*keys, "duration", "weight", "event")
            )

            # km_df: concat fills + cancels, join order_info for grouping cols
            km_df = (
                pl.concat([fills, cancels])
                .join(order_info.select(
                    *keys, "order_side", "order_price_type",
                    *[bname for bname in BUCKETS],
                ), on=keys, how="left")
                .join(order_notional_df, on=keys, how="left")
                .filter((pl.col("weight") > 0) & (pl.col("duration") > 0))
                .collect()
            )
            print(f"km_df: {len(km_df)} rows, columns: {km_df.columns}")


            # --- Plot ---
            for bname, spec in BUCKETS.items():
                bucket_col = f"bucket_{bname}"
                km_plot = km_df.with_columns(
                    pl.col(bname).cut(spec["edges"]).cast(pl.Utf8).alias(bucket_col)
                ).drop_nulls(bucket_col)

                all_buckets = sorted(
                    km_plot[bucket_col].unique().drop_nulls().to_list(),
                    key=_bucket_sort_key,
                )
                n = len(all_buckets)
                if n == 0:
                    continue
                palette = dict(zip(all_buckets, sns.color_palette("coolwarm", n)))

                # Identify significant buckets (>= MIN_NOTIONAL_FRAC)
                total_w = km_plot["weight"].sum()
                keep_buckets = (
                    km_plot.group_by(bucket_col)
                    .agg(pl.col("weight").sum())
                    .filter(pl.col("weight") >= total_w * MIN_NOTIONAL_FRAC)
                    [bucket_col].to_list()
                )
                curve_buckets = sorted(
                    [b for b in keep_buckets if b is not None],
                    key=_bucket_sort_key,
                )

                for opt in ORDER_TYPES:
                    for side in ORDER_SIDES:
                        df_sub = km_plot.filter(
                            (pl.col("order_price_type") == opt)
                            & (pl.col("order_side") == side)
                        ).drop_nulls(bucket_col)
                        if len(df_sub) == 0:
                            continue

                        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
                        fig.suptitle(f"Fill Analysis: {bname} | {opt} | {side}",
                                     fontsize=14, fontweight="bold", y=0.98)

                        # ═══════════════════════════════════════════════════
                        # (0,0) Kaplan-Meier Survival Curve
                        # ═══════════════════════════════════════════════════
                        ax = axes[0, 0]
                        for bucket in curve_buckets:
                            sub = df_sub.filter(pl.col(bucket_col) == bucket)
                            sub_pd = sub.select("duration", "event", "weight").to_pandas()
                            kmf = KaplanMeierFitter()
                            kmf.fit(
                                durations=sub_pd["duration"],
                                event_observed=sub_pd["event"],
                                weights=sub_pd["weight"],
                            )
                            sf = kmf.survival_function_
                            ax.plot(sf.index, sf.values.flatten(),
                                    label=bucket, color=palette[bucket], linewidth=1.2)
                        ax.set_xscale("log")
                        ax.set_xlim(1, 1e7)
                        ax.set_xlabel("duration (ms)")
                        ax.set_ylabel("P(survive)")
                        ax.set_title("Kaplan-Meier Survival Curve")
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)
                        ax.axhline(0.5, color="grey", ls="--", lw=0.5)

                        # ═══════════════════════════════════════════════════
                        # (0,1) Cumulative Fill Rate
                        # ═══════════════════════════════════════════════════
                        ax = axes[0, 1]
                        for bucket in curve_buckets:
                            sub = df_sub.filter(pl.col(bucket_col) == bucket)
                            # Denominator: ORDNEW order_notional for this bucket
                            denom = sub["order_notional"].sum()
                            if denom is None or denom <= 0:
                                continue
                            # Only fills (event=1), sorted by duration
                            fills_sub = sub.filter(pl.col("event") == 1).sort("duration")
                            if len(fills_sub) == 0:
                                continue
                            cum_fill_n = fills_sub["weight"].cum_sum().to_numpy()
                            durations = fills_sub["duration"].to_numpy()
                            ax.plot(durations, cum_fill_n / denom,
                                    label=bucket, color=palette[bucket], linewidth=1.2)
                        ax.set_xscale("log")
                        ax.set_xlim(1, 1e7)
                        ax.set_ylim(0, 1)
                        ax.set_xlabel("duration (ms)")
                        ax.set_ylabel("cumulative fill rate")
                        ax.set_title("Realized Cumulative Fill Rate")
                        ax.legend(fontsize=6, ncol=2, title=bname, title_fontsize=7)

                        # ═══════════════════════════════════════════════════
                        # (1,0) Duration Distribution (fills only, by bucket)
                        # ═══════════════════════════════════════════════════
                        ax = axes[1, 0]
                        fills_only = df_sub.filter(pl.col("event") == 1)
                        log_dur = np.log10(fills_only["duration"].to_numpy().astype(float))
                        bins = np.linspace(0, 7, 60)  # 1ms to 10^7 ms

                        for bucket in curve_buckets:
                            sub_fills = fills_only.filter(pl.col(bucket_col) == bucket)
                            if len(sub_fills) == 0:
                                continue
                            vals = np.log10(sub_fills["duration"].to_numpy().astype(float))
                            ax.hist(vals, bins=bins, alpha=0.5, color=palette[bucket], label=bucket)

                        # Annotate mean + median
                        all_dur = fills_only["duration"].to_numpy().astype(float)
                        if len(all_dur) > 0:
                            med = np.median(all_dur)
                            mean = np.mean(all_dur)
                            ax.axvline(np.log10(med), color="red", ls="--", lw=1.5, label=f"median={med:.0f}ms")
                            ax.axvline(np.log10(mean), color="blue", ls="--", lw=1.5, label=f"mean={mean:.0f}ms")

                        ax.set_xlabel("log10(duration ms)")
                        ax.set_ylabel("count")
                        ax.set_title("Fill Duration Distribution")
                        ax.legend(fontsize=6, ncol=2)

                        # ═══════════════════════════════════════════════════
                        # (1,1) Fill Notional Distribution (bar chart)
                        # ═══════════════════════════════════════════════════
                        ax = axes[1, 1]
                        fills_only_b = df_sub.filter(pl.col("event") == 1)
                        dist = (
                            fills_only_b.group_by(bucket_col)
                            .agg(pl.col("weight").sum().alias("sum_fill_notional"))
                        ).to_pandas()
                        dist["_sort"] = dist[bucket_col].map(_bucket_sort_key)
                        dist = dist.sort_values("_sort").drop(columns="_sort")
                        bar_colors = [palette.get(b, "grey") for b in dist[bucket_col]]
                        notional_vals = dist["sum_fill_notional"].values
                        total = notional_vals.sum()
                        bars = ax.bar(range(len(dist)), notional_vals, color=bar_colors)
                        ax.set_xticks(range(len(dist)))
                        ax.set_xticklabels(dist[bucket_col].tolist(), rotation=45, ha="right", fontsize=7)
                        for bar, val in zip(bars, notional_vals):
                            pct = val / total * 100
                            ax.annotate(f"{pct:.1f}%",
                                        xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                                        ha="center", va="bottom", fontsize=8, color="#333")
                        ax.set_title("Fill Notional Distribution")
                        ax.set_ylabel("sum fill_notional")

                        plt.tight_layout()
                        plt.show()"""),
    },
}
