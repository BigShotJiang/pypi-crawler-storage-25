"""Workspace — global data catalog + computation graph.

A workspace is a TOML file (workspace.toml) that tracks:
- Data sources (trade, alpha, quote, univ) with their locations and schemas
- Compute nodes with upstream dependencies and output paths
- DAG structure for lineage visualization (graph.dot)

Usage:
    ws = vf.init_workspace("quant_research")
    ws.register_source("ylin_sim_v1", type="trade",
                        dir="/gpfs/.../sc_0", pattern="{date}.meords",
                        schema="sim_standard")
    ws = vf.connect()
    lf = ws.scan("ylin_sim_v1", "20240827")
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl

from .config import Config
from . import io as _io

# tomllib is stdlib in 3.11+, fallback to tomli for 3.8-3.10
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]

try:
    import tomli_w
except ImportError:
    tomli_w = None  # type: ignore[assignment]

try:
    import networkx as nx
except ImportError:
    nx = None  # type: ignore[assignment]


# Source type → (dir field, pattern field, schema field) on Config
_SOURCE_TYPE_MAP = {
    "trade": ("trade_dir", "trade_pattern", "trade_schema"),
    "alpha": ("alpha_dir", "alpha_pattern", "alpha_schema"),
    "quote": ("quote_dir", "quote_pattern", "quote_schema"),
    "univ": ("univ_dir", "univ_pattern", "univ_schema"),
}

# Source type → scan function name on io module
_SCAN_DISPATCH = {
    "trade": "scan_trade",
    "alpha": "scan_alpha",
    "quote": "scan_quote",
    "univ": "scan_univ",
}

# Default patterns per type
_DEFAULT_PATTERNS = {
    "trade": "trade_{date}.feather",
    "alpha": "alpha_{date}.feather",
    "quote": "{date}.fst",
    "univ": "{date}.csv",
}


@dataclass
class SourceNode:
    """A registered data source.

    Attributes:
        name: Unique identifier, e.g. "ylin_sim_v1"
        type: One of "trade", "alpha", "quote", "univ"
        dir: Directory path (absolute)
        pattern: Filename pattern with {date} placeholder
        schema: Schema name (string key into SCHEMAS registry)
        description: Human-readable description
    """

    name: str
    type: str
    dir: Path
    pattern: str
    schema: str | None = None
    description: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.dir, str):
            self.dir = Path(self.dir)
        if self.type not in _SOURCE_TYPE_MAP:
            raise ValueError(
                f"Unknown source type: {self.type!r}. "
                f"Must be one of: {list(_SOURCE_TYPE_MAP.keys())}"
            )


@dataclass
class ComputeNode:
    """A computed dataset node in the DAG.

    Attributes:
        name: Unique identifier, e.g. "enriched_v1"
        upstream: List of upstream node names (sources or other compute nodes)
        path: Output directory path
        partition_by: Column name for partitioning (e.g. "data_date")
        tag: Optional metadata tag
        script: Path to the script that produces this node
    """

    name: str
    upstream: list[str] = field(default_factory=list)
    path: Path | None = None
    partition_by: str | None = None
    tag: str | None = None
    script: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.path, str):
            self.path = Path(self.path)


@dataclass
class Workspace:
    """Global data catalog + computation graph.

    Attributes:
        name: Workspace name
        market: Default market identifier
        sources: Registered data sources
        nodes: Registered compute nodes
        root: Directory containing workspace.toml
    """

    name: str
    market: str = "CN"
    sources: dict[str, SourceNode] = field(default_factory=dict)
    nodes: dict[str, ComputeNode] = field(default_factory=dict)
    root: Path = field(default_factory=lambda: Path.cwd())

    def scan(self, name: str, date: str, **kwargs: Any) -> pl.LazyFrame:
        """Scan a registered source for a given date.

        Builds a temporary Config from the source definition and dispatches
        to the appropriate scan_* function (scan_trade, scan_alpha, etc.).

        Args:
            name: Source name, e.g. "ylin_sim_v1"
            date: Date string, e.g. "20240827"
            **kwargs: Extra keyword arguments passed to the scan function
                (e.g., columns for scan_quote).

        Returns:
            LazyFrame from the source file.

        Raises:
            KeyError: If source name is not registered.
        """
        if name not in self.sources:
            raise KeyError(
                f"Source {name!r} not found. "
                f"Available: {list(self.sources.keys())}"
            )

        source = self.sources[name]
        dir_field, pattern_field, schema_field = _SOURCE_TYPE_MAP[source.type]

        config = Config(
            **{
                dir_field: source.dir,
                pattern_field: source.pattern,
                schema_field: source.schema,
            },
            market=self.market,
        )

        scan_fn = getattr(_io, _SCAN_DISPATCH[source.type])
        return scan_fn(date, config=config, **kwargs)

    def read(self, name: str, date: str | None = None) -> pl.LazyFrame:
        """Read a materialized compute node.

        Args:
            name: Compute node name, e.g. "enriched_v1"
            date: Optional date filter for partitioned data.

        Returns:
            LazyFrame from the materialized output.

        Raises:
            KeyError: If node name is not registered.
            ValueError: If node has no output path.
            FileNotFoundError: If output path does not exist.
        """
        if name not in self.nodes:
            raise KeyError(
                f"Node {name!r} not found. "
                f"Available: {list(self.nodes.keys())}"
            )

        node = self.nodes[name]
        if node.path is None:
            raise ValueError(f"Node {name!r} has no output path.")

        path = node.path
        if not path.is_absolute():
            path = self.root / path

        if not path.exists():
            raise FileNotFoundError(f"Output path does not exist: {path}")

        # Try Delta Lake first, fall back to parquet
        try:
            lf = pl.scan_delta(str(path))
        except Exception:
            lf = pl.scan_parquet(path / "**/*.parquet")

        if date and node.partition_by:
            lf = lf.filter(
                pl.col(node.partition_by)
                == pl.lit(date).str.to_date("%Y%m%d").cast(pl.Date)
            )

        return lf

    def register_source(
        self,
        name: str,
        *,
        type: str,
        dir: str | Path,
        pattern: str | None = None,
        schema: str | None = None,
        description: str | None = None,
    ) -> SourceNode:
        """Register a new data source.

        Args:
            name: Unique source name
            type: Source type ("trade", "alpha", "quote", "univ")
            dir: Directory containing the data files
            pattern: Filename pattern with {date} placeholder
            schema: Schema name (key into SCHEMAS registry)
            description: Human-readable description

        Returns:
            The created SourceNode.
        """
        if pattern is None:
            pattern = _DEFAULT_PATTERNS.get(type, "{date}.parquet")

        source = SourceNode(
            name=name,
            type=type,
            dir=Path(dir),
            pattern=pattern,
            schema=schema,
            description=description,
        )
        self.sources[name] = source
        self.save()
        self.render_dot()
        return source

    def register_node(
        self,
        name: str,
        *,
        upstream: list[str] | None = None,
        path: str | Path | None = None,
        partition_by: str | None = None,
        tag: str | None = None,
        script: str | None = None,
    ) -> ComputeNode:
        """Register a compute node in the DAG.

        Args:
            name: Unique node name
            upstream: List of upstream source/node names
            path: Output directory path
            partition_by: Partition column name
            tag: Optional metadata tag
            script: Path to the script that produces this node

        Returns:
            The created ComputeNode.
        """
        node = ComputeNode(
            name=name,
            upstream=upstream or [],
            path=Path(path) if path else None,
            partition_by=partition_by,
            tag=tag,
            script=script,
        )
        self.nodes[name] = node
        self.save()
        self.render_dot()
        return node

    def _resolve_source(self, name: str, expected_type: str) -> SourceNode:
        """Look up a source by name and validate its type.

        Args:
            name: Source name to look up.
            expected_type: Expected source type (e.g. "trade", "alpha").

        Returns:
            The matching SourceNode.

        Raises:
            KeyError: If source name is not registered.
            ValueError: If source type doesn't match expected_type.
        """
        if name not in self.sources:
            raise KeyError(
                f"Source {name!r} not found. "
                f"Available: {list(self.sources.keys())}"
            )
        source = self.sources[name]
        if source.type != expected_type:
            raise ValueError(
                f"Source {name!r} has type {source.type!r}, "
                f"expected {expected_type!r}"
            )
        return source

    def config(
        self,
        *,
        trade: str | list[str] | None = None,
        alpha: str | None = None,
        quote: str | None = None,
        univ: str | None = None,
        trade_tag: str | None = None,
        # Pass-through analysis params
        calendar_path: str | Path | None = None,
        replay_dir: str | Path | None = None,
        aggregate_dir: str | Path | None = None,
        market: str | None = None,
        horizons: list | None = None,
        binwidths: dict[str, float] | None = None,
        group_by: list[str] | None = None,
        time_cutoff: int | None = None,
    ) -> Config:
        """Build a Config by selecting registered sources from this workspace.

        Instead of manually specifying paths, patterns, and schemas in Config,
        reference workspace sources by name. The workspace resolves everything.

        Args:
            trade: Trade source name, or list of names for multi-source mode.
            alpha: Alpha source name.
            quote: Quote source name.
            univ: Universe source name.
            trade_tag: Column name for multi-source trade tag (default "source").
            calendar_path: Path to calendar file (pass-through).
            replay_dir: Replay output directory (pass-through).
            aggregate_dir: Aggregate output directory (pass-through).
            market: Market identifier (default: workspace market).
            horizons: Forward return horizons (pass-through).
            binwidths: Bin widths for aggregation (pass-through).
            group_by: Group-by columns (pass-through).
            time_cutoff: Time cutoff (pass-through).

        Returns:
            Config instance with source fields populated from workspace.

        Raises:
            KeyError: If a source name is not registered.
            ValueError: If a source type doesn't match (e.g. alpha source
                passed as trade), or if multi-source trade sources have
                inconsistent patterns or schemas.

        Example:
            >>> ws = vf.connect()
            >>> cfg = ws.config(
            ...     trade="ylin_sim_v1",
            ...     alpha="jyao_alpha_v2",
            ...     horizons=[60000, 180000],
            ... )
            >>> vf.set_config(cfg)
        """
        kwargs: dict[str, Any] = {}

        # --- Resolve trade source(s) ---
        if trade is not None:
            if isinstance(trade, list):
                sources = [self._resolve_source(n, "trade") for n in trade]
                # Validate consistency: pattern and schema must match
                patterns = {s.pattern for s in sources}
                if len(patterns) > 1:
                    detail = {s.name: s.pattern for s in sources}
                    raise ValueError(
                        f"Multi-source trade requires identical patterns, "
                        f"got: {detail}"
                    )
                schemas = {s.schema for s in sources}
                if len(schemas) > 1:
                    detail = {s.name: s.schema for s in sources}
                    raise ValueError(
                        f"Multi-source trade requires identical schemas, "
                        f"got: {detail}"
                    )
                kwargs["trade_dir"] = {s.name: s.dir for s in sources}
                kwargs["trade_pattern"] = sources[0].pattern
                kwargs["trade_schema"] = sources[0].schema
                kwargs["trade_tag"] = trade_tag  # Config.__post_init__ defaults to "source"
            else:
                src = self._resolve_source(trade, "trade")
                kwargs["trade_dir"] = src.dir
                kwargs["trade_pattern"] = src.pattern
                kwargs["trade_schema"] = src.schema

        # --- Resolve single-source types ---
        for source_name, source_type in [
            (alpha, "alpha"),
            (quote, "quote"),
            (univ, "univ"),
        ]:
            if source_name is None:
                continue
            src = self._resolve_source(source_name, source_type)
            dir_field, pattern_field, schema_field = _SOURCE_TYPE_MAP[source_type]
            kwargs[dir_field] = src.dir
            kwargs[pattern_field] = src.pattern
            kwargs[schema_field] = src.schema

        # --- Market: workspace default unless overridden ---
        kwargs["market"] = market if market is not None else self.market

        # --- Pass-through params (only set if not None) ---
        if calendar_path is not None:
            kwargs["calendar_path"] = calendar_path
        if replay_dir is not None:
            kwargs["replay_dir"] = replay_dir
        if aggregate_dir is not None:
            kwargs["aggregate_dir"] = aggregate_dir
        if horizons is not None:
            kwargs["horizons"] = horizons
        if binwidths is not None:
            kwargs["binwidths"] = binwidths
        if group_by is not None:
            kwargs["group_by"] = group_by
        if time_cutoff is not None:
            kwargs["time_cutoff"] = time_cutoff

        return Config(**kwargs)

    def graph(self) -> Any:
        """Build a NetworkX DiGraph from sources and compute nodes.

        Returns:
            networkx.DiGraph with source and compute nodes.

        Raises:
            ImportError: If networkx is not installed.
        """
        if nx is None:
            raise ImportError(
                "networkx required for graph operations. "
                "Install: pip install vizflow[workspace]"
            )

        g = nx.DiGraph()

        # Add source nodes
        for name, source in self.sources.items():
            g.add_node(name, node_type="source", source_type=source.type)

        # Add compute nodes with edges
        for name, node in self.nodes.items():
            g.add_node(name, node_type="compute")
            for up in node.upstream:
                g.add_edge(up, name)

        return g

    def render_dot(self) -> Path:
        """Render the DAG as a DOT file (graph.dot) next to workspace.toml.

        Returns:
            Path to the generated DOT file.
        """
        g = self.graph()
        dot_path = self.root / "graph.dot"

        lines = ["digraph workspace {", "    rankdir=TB;", "    node [fontsize=10];"]

        # Style source nodes
        for name in self.sources:
            source = self.sources[name]
            parts = [f"<b>{name}</b>", source.type]
            if source.schema:
                parts.append(f"schema: {source.schema}")
            parts.append(f"pattern: {source.pattern}")
            label = "<br/>".join(parts)
            lines.append(
                f'    "{name}" [label=<{label}>, shape=box, style=filled, fillcolor=lightblue];'
            )

        # Style compute nodes — HTML table so only the title cell is clickable
        for name in self.nodes:
            node = self.nodes[name]
            if node.script:
                script_path = self.root / node.script
                href = f' HREF="vscode://file/{script_path}"'
            else:
                href = ""
            rows = [f'<TR><TD{href}><B>{name}</B></TD></TR>']
            if node.partition_by:
                rows.append(f'<TR><TD>by {node.partition_by}</TD></TR>')
            label = (
                f'<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0">'
                f'{"".join(rows)}'
                f'</TABLE>'
            )
            lines.append(
                f'    "{name}" [label=<{label}>, shape=ellipse, style=filled, fillcolor=lightyellow];'
            )

        # Edges
        for u, v in g.edges():
            lines.append(f'    "{u}" -> "{v}";')

        lines.append("}")

        dot_path.write_text("\n".join(lines) + "\n")
        return dot_path

    def save(self) -> Path:
        """Save workspace to workspace.toml.

        Returns:
            Path to the saved TOML file.

        Raises:
            ImportError: If tomli-w is not installed.
        """
        if tomli_w is None:
            raise ImportError(
                "tomli-w required for saving workspace. "
                "Install: pip install vizflow[workspace]"
            )

        data: dict[str, Any] = {
            "workspace": {
                "name": self.name,
                "market": self.market,
            },
        }

        # Sources
        if self.sources:
            data["sources"] = {}
            for name, source in self.sources.items():
                entry: dict[str, Any] = {
                    "type": source.type,
                    "dir": str(source.dir),
                    "pattern": source.pattern,
                }
                if source.schema:
                    entry["schema"] = source.schema
                if source.description:
                    entry["description"] = source.description
                data["sources"][name] = entry

        # Compute nodes
        if self.nodes:
            data["nodes"] = {}
            for name, node in self.nodes.items():
                entry = {}
                if node.upstream:
                    entry["upstream"] = node.upstream
                if node.path:
                    entry["path"] = str(node.path)
                if node.partition_by:
                    entry["partition_by"] = node.partition_by
                if node.tag:
                    entry["tag"] = node.tag
                if node.script:
                    entry["script"] = node.script
                data["nodes"][name] = entry

        toml_path = self.root / "workspace.toml"
        toml_path.write_bytes(tomli_w.dumps(data).encode())
        return toml_path


def _load_workspace(path: Path) -> Workspace:
    """Load a Workspace from a TOML file.

    Args:
        path: Path to workspace.toml

    Returns:
        Workspace instance.
    """
    with open(path, "rb") as f:
        data = tomllib.load(f)

    ws_data = data.get("workspace", {})
    root = path.parent

    ws = Workspace(
        name=ws_data.get("name", "default"),
        market=ws_data.get("market", "CN"),
        root=root,
    )

    # Load sources
    for name, src_data in data.get("sources", {}).items():
        ws.sources[name] = SourceNode(
            name=name,
            type=src_data["type"],
            dir=Path(src_data["dir"]),
            pattern=src_data.get("pattern", _DEFAULT_PATTERNS.get(src_data["type"], "{date}.parquet")),
            schema=src_data.get("schema"),
            description=src_data.get("description"),
        )

    # Load compute nodes
    for name, node_data in data.get("nodes", {}).items():
        ws.nodes[name] = ComputeNode(
            name=name,
            upstream=node_data.get("upstream", []),
            path=Path(node_data["path"]) if "path" in node_data else None,
            partition_by=node_data.get("partition_by"),
            tag=node_data.get("tag"),
            script=node_data.get("script"),
        )

    return ws


def _save_workspace(ws: Workspace) -> Path:
    """Save a Workspace to TOML. Alias for ws.save()."""
    return ws.save()


def connect(path: str | Path | None = None) -> Workspace:
    """Connect to an existing workspace.

    Search order:
    1. Explicit path argument
    2. CWD/workspace.toml
    3. ~/.vizflow/workspace.toml

    Args:
        path: Explicit path to workspace.toml

    Returns:
        Workspace instance.

    Raises:
        FileNotFoundError: If no workspace.toml found.
    """
    if path is not None:
        p = Path(path)
        if p.is_dir():
            p = p / "workspace.toml"
        if not p.exists():
            raise FileNotFoundError(f"Workspace file not found: {p}")
        return _load_workspace(p)

    # Search CWD
    cwd_path = Path.cwd() / "workspace.toml"
    if cwd_path.exists():
        return _load_workspace(cwd_path)

    # Search ~/.vizflow/
    home_path = Path.home() / ".vizflow" / "workspace.toml"
    if home_path.exists():
        return _load_workspace(home_path)

    raise FileNotFoundError(
        "No workspace.toml found. Searched:\n"
        f"  1. {cwd_path}\n"
        f"  2. {home_path}\n"
        "Create one with vf.init_workspace(name)."
    )


def init_workspace(
    name: str,
    *,
    path: str | Path | None = None,
    market: str = "CN",
) -> Workspace:
    """Create a new empty workspace.

    Args:
        name: Workspace name
        path: Directory for workspace.toml (default: CWD)
        market: Default market identifier

    Returns:
        Empty Workspace instance (saved to disk).
    """
    root = Path(path) if path else Path.cwd()
    root.mkdir(parents=True, exist_ok=True)

    ws = Workspace(name=name, market=market, root=root)
    ws.save()
    ws.render_dot()
    return ws


def refresh_dot(path: str | Path | None = None) -> Path:
    """Regenerate graph.dot from workspace.toml (no computation).

    Usage:
        vf.refresh_dot()           # from CWD
        vf.refresh_dot("/my/dir")  # explicit path
    """
    ws = connect(path=path)
    return ws.render_dot()



# execute() has been moved to vizflow/execute.py
