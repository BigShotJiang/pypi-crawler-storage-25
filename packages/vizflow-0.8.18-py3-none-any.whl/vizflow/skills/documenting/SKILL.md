---
name: documenting
description: Use when the user asks to remember, document, record, or write down anything — decisions, learnings, architecture, research notes, philosophy discussions. Routes content to CLAUDE.md or docs/ based on nature, uses rich markdown with renderable diagrams.
---

# Documenting to Visible Markdown

## Core Principle

**用户不信任黑盒记忆。所有知识落地到可读、可版本控制的 markdown 文档。**

## Routing

```mermaid
flowchart TD
    A["User asks to remember / document something"] --> B{"Content nature?"}
    B -->|"Operational rules, architecture,\nconventions, infra facts —\nagent MUST know this to work"| C{"Scope?"}
    B -->|"Research, philosophy, deep analysis,\ndesign rationale, methodology,\nexperiment logs"| D["~/docs/descriptive-name.md"]

    C -->|"Whole workspace"| E["~/CLAUDE.md"]
    C -->|"One project"| F["projects/xxx/CLAUDE.md"]
    C -->|"One lib"| G["libs/xxx/CLAUDE.md"]

    D --> H["Link from CLAUDE.md if frequently referenced"]
```

**CLAUDE.md** = progressive disclosure hierarchy. Root holds global context; project-level holds specifics. Agents entering a directory see both layers automatically. Keep entries concise; link to `docs/` for lengthy content.

**docs/** = knowledge valuable but not required in every agent context. Research journals, design rationale, methodology guides, investigation notes, anything > ~50 lines of prose.

## Writing Standards

### Dual-Audience: Human + Agent LLM

| Audience | Needs | Technique |
|----------|-------|-----------|
| **Human** | Visual scanning, diagrams, hierarchy | Renderable diagrams, tables, `<details>`, clear H2/H3 |
| **Agent** | Flat text, keywords, no ambiguity | Plain-text summary after every diagram, explicit headings |

### Rich Markdown

**DO:**
- **Tables** for structured comparisons
- **Renderable diagrams** (Mermaid, PlantUML, Graphviz, Kroki, or any protocol supported by Markdown Preview Enhanced) — pick whichever best fits the content
- **Callouts** (`> **⚠️ Warning:**`) for critical info
- **Collapsible sections** (`<details>`) for lengthy reference
- Bold/italic for emphasis, `code` for identifiers

**DON'T:**
- ASCII art box diagrams — always use a renderable protocol
- Walls of unstructured prose
- Diagram without a plain-text summary below it (LLMs can't reliably parse diagram syntax)

### Diagram-then-Text Pattern

````markdown
```mermaid
flowchart LR
    A[Input] --> B[Process] --> C[Output]
```

**In plain text:** Input feeds into Process, producing Output.
Key constraint: X. Invariant: Y.
````

## Procedure

When the user says "记一下", "document this", "记住", "write this down", or similar:

1. **Classify** content using the routing flowchart
2. **Read** target file first — find the right insertion point, avoid duplication
3. **Write** with rich markdown + diagrams where any flow/relationship/architecture is involved
4. **Confirm** to user: what was written, where, and why that location was chosen

### CLAUDE.md Edits
- Find the most specific CLAUDE.md matching the scope
- Insert at the correct section, maintaining progressive disclosure order
- Keep concise — link to `docs/` for detail

### docs/ New Files
- Clear H1 title, date in header or front-matter
- Include `## Context` / `## Background` section
- At least one renderable diagram if content involves flow or architecture
- Brief link from relevant CLAUDE.md if the doc is frequently referenced

## What NOT to Do

| Anti-pattern | Why |
|-------------|-----|
| Write to MEMORY.md | Black box, not version controlled with project |
| Skip reading existing content before writing | May duplicate or conflict |
| 200 lines of research notes in CLAUDE.md | Pollutes agent context → belongs in docs/ |
| Critical operational rules only in docs/ | Agent won't see them unless explicitly loaded |
| ASCII box diagrams | User has Markdown Preview Enhanced — use renderable protocols |
| Diagram without text summary | LLMs can't parse diagram syntax reliably |