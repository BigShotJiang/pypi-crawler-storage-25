"""VizFlow Skills — install AI coding skills for Claude Code / Cline.

Usage:
    import vizflow as vf

    vf.install_skills("vizflow", path=".claude/skills")   # Claude Code
    vf.install_skills("vizflow", path=".cline/skills")    # Cline
    vf.install_skills(path=".claude/skills")               # install all skills
"""
from __future__ import annotations

import shutil
from pathlib import Path

_SKILLS_ROOT = Path(__file__).parent


def _discover_skills() -> list[str]:
    """Discover available skills (flat and nested).

    Flat:   vizflow/SKILL.md        → "vizflow"
    Nested: superpowers/brainstorming/SKILL.md → "superpowers/brainstorming"
    """
    skills = []
    for d in sorted(_SKILLS_ROOT.iterdir()):
        if not d.is_dir() or d.name.startswith(("_", ".")):
            continue
        if (d / "SKILL.md").exists():
            skills.append(d.name)
        else:
            # Nested: check one level deeper
            for sub in sorted(d.iterdir()):
                if sub.is_dir() and (sub / "SKILL.md").exists():
                    skills.append(f"{d.name}/{sub.name}")
    return skills


AVAILABLE = _discover_skills()


def install(
    name: str | None = None,
    *,
    path: str | Path = ".claude/skills",
) -> None:
    """Copy skill files to the target directory.

    Args:
        name: Skill name (e.g. ``"vizflow"``, ``"superpowers/brainstorming"``).
            If ``None``, install all skills.
        path: Target parent directory. Each skill creates a subdirectory.
              Defaults to ``.claude/skills`` (Claude Code convention).

    Examples::

        import vizflow as vf
        vf.install_skills("vizflow")                        # single skill
        vf.install_skills("superpowers/brainstorming")      # nested skill
        vf.install_skills()                                  # all skills
        vf.install_skills(path=".cline/skills")             # Cline target
    """
    target = Path(path)
    names = [name] if name else AVAILABLE

    for skill_name in names:
        src = _SKILLS_ROOT / skill_name
        if not src.exists() or not (src / "SKILL.md").exists():
            raise KeyError(
                f"Skill '{skill_name}' not found. Available: {', '.join(AVAILABLE)}"
            )
        dst = target / skill_name
        if dst.exists():
            shutil.rmtree(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        print(f"  ✓ {skill_name} → {dst}")

    print(f"\nInstalled {len(names)} skill(s) to {target}/")
