---
name: vizflow
description: >
  Complete API guide for VizFlow, a Polars extension for TB-scale financial market data.
  Trigger whenever: code imports vizflow, user mentions trade/alpha/quote data processing,
  forward returns, merge_forward, schema evolution, horizon analysis, market sessions
  (CN/CRYPTO), workspace DAG, FIFO matching, asof joins at multiple horizons, or any
  post-trade / execution quality analysis. Also trigger for vf.* function calls, Polars
  operations on financial time-series, or questions about date-partitioned batch processing.
  Even if the user doesn't mention "vizflow" explicitly, trigger if the task involves
  financial market data pipelines with Polars.
user-invocable: true
---

> **VizFlow v0.8.18** — For skill maintenance rules (sync, versioning), read `references/maintainer.md`.

# VizFlow AI Coding Guide

VizFlow is a **Polars extension** for TB-scale financial market data analysis.
`import vizflow as vf`. Built on Polars for native Rust-level vectorized performance.

## Smart Routing: VizFlow vs Raw Polars

```mermaid
flowchart LR
    Q["User task"] --> C{"Hard problem?"}
    C -->|"Schema evolution, horizons,\nasof joins, market sessions,\nDAG lineage"| VF["Use VizFlow"]
    C -->|"Simple filter, join,\ngroup_by, select"| PL["Use raw Polars"]
```

**In plain text:** Use VizFlow for problems that require domain knowledge (market sessions, multi-horizon asof joins, schema evolution across vendors, date-partitioned batch processing, workspace DAG). Use raw Polars for anything a user can do easily in 3 lines.

---

## Critical Rules

### 1. No `map_elements` / `lambda` / Python UDFs

Polars runs on a Rust engine — `map_elements` drops into row-by-row Python, bypassing it entirely. A single `map_elements` can make a pipeline **100× slower**. This is the single most common performance mistake.

```python
# BAD — row-by-row Python
df.with_columns(pl.col("x").map_elements(lambda v: my_func(v)))

# GOOD — finite-cardinality mapping (O(unique) Python + O(n) Rust)
uniques = df.select("x").unique().collect()
mapping = {v: transform(v) for v in uniques["x"].to_list()}
df.with_columns(pl.col("x").replace_strict(mapping))

# GOOD — native expressions
df.with_columns(pl.when(condition).then(a).otherwise(b))
```

If no native expression exists, **stop and discuss** with the user before writing code.

### 2. Time Types

| Semantic | Polars Type | Column example |
|----------|------------|----------------|
| Time-of-day | `pl.Datetime` | `tod_ticktime` (epoch date 1970-01-01) |
| Date | `pl.Date` | `data_date` |
| Duration/Elapsed | `pl.Duration` | `elapsed_ticktime`, `horizon` |

Timestamps in raw data are integer HHMMSSMMM format (e.g., `93012145` = 09:30:12.145).

### 3. Horizons are `int` milliseconds

The entire VizFlow API uses **`int` milliseconds** for horizons. This is intentional — it avoids Python `timedelta` overhead and keeps everything in the Rust engine.

```python
horizons = [0, 60000, 180000, 1800000]   # 0s, 1m, 3m, 30m
vf.horizon_suffix(60000)                   # "1m"
vf.horizon_cols("mid", [60000, 180000])    # ["mid_1m", "mid_3m"]
```

### 4. Lazy-Reduce-Concat

Calling `collect()` inside a loop defeats Polars' lazy query optimizer and forces one materialization per date. Build a list of LazyFrames, then concat and collect once.

```python
# BAD — collects per date, O(n_dates) materializations
for date in dates:
    df = vf.scan_trade(date).collect()
    results.append(df)

# GOOD — single collect at end
partials = []
for date in dates:
    lf = vf.scan_trade(date).group_by("ukey").agg(pl.col("order_filled_qty").sum())
    partials.append(lf)
df = pl.concat(partials).collect()  # ONE collect
```

### 5. Data Scale Awareness

| Data type | Scale | Store to disk? |
|-----------|-------|---------------|
| Market data (alpha ticks) | Millions/day | No — too large |
| Trade log (fills) | Thousands/day | Yes — by date |

Always reduce per-date before concat. Market-data-level concat will OOM.

### 6. Plotting Duration/Time Axes

No plotting library (matplotlib, seaborn, Plotly) handles `timedelta` / `pl.Duration` natively. Convert to float first.

```python
# Time-of-day: add_tod outputs pl.Datetime → matplotlib handles directly
lf = lf.pipe(vf.add_tod, "ticktime")
pdf = lf.collect().to_pandas()
ax.scatter(pdf["tod_ticktime"], pdf["y"])  # X-axis shows HH:MM

# Duration/elapsed: float ms + DurationFormatter
ax.scatter(pdf["elapsed_ticktime"], pdf["y"])
ax.xaxis.set_major_formatter(vf.DurationFormatter())  # "30s", "5m", "1h20m"
```

---

## API Overview

### Config

```python
vf.Config(trade_dir=Path|dict, trade_pattern=str, trade_schema=str|SchemaEvolution,
          alpha_dir=Path, quote_dir=Path, univ_dir=Path, calendar_path=Path,
          market="CN", horizons=list[int], ...)
vf.set_config(config)          # set global config
config = vf.get_config()       # get global config
```

### I/O — `references/io.md` for full signatures

| Function | Returns | Purpose |
|----------|---------|---------|
| `vf.scan_trade(date)` | LazyFrame | Single-date trade with schema evolution, auto-adds `seq` + `data_date` |
| `vf.scan_trades()` | LazyFrame | All trade files concatenated |
| `vf.scan_alpha(date)` | LazyFrame | Single-date alpha signals |
| `vf.scan_alphas()` | LazyFrame | All alpha files concatenated |
| `vf.scan_quote(date, columns=)` | LazyFrame | Single-date quotes, supports column projection |
| `vf.scan_quotes(columns=)` | LazyFrame | All quote files concatenated |
| `vf.scan_univ(date)` | LazyFrame | Single-date universe data |
| `vf.scan_univs()` | LazyFrame | All universe files concatenated |
| `vf.load_calendar()` | DataFrame | Trading calendar (eager) |

### Market

```python
vf.CN       # Market("CN", sessions=[Session("09:30","11:30"), Session("13:00","15:00")])
vf.CRYPTO   # Market("crypto", sessions=[Session("00:00","24:00")])
```

### Ops — `references/ops.md` for full signatures

| Function | Purpose | Returns |
|----------|---------|---------|
| `vf.parse_time(lf, col)` | HHMMSSMMM → elapsed ms (Int64) | LazyFrame |
| `vf.bin(lf, widths)` | Add `{col}_bin` columns | LazyFrame |
| `vf.aggregate(lf, group_by, metrics)` | Group-by with custom metrics | LazyFrame |
| `vf.forward_return(trade, alpha, horizons)` | Future price lookup + return calc | LazyFrame (eager internally) |
| `vf.merge_forward(trade, ref, ref_cols, horizons)` | Asof join at N horizons → wide | **DataFrame** (eager) |
| `vf.mark_to_close(trade, univ)` | Add `y_close` column | LazyFrame |
| `vf.sign_by_side(lf, cols)` | Side-aware sign flip | LazyFrame |
| `vf.horizon_suffix(h_ms)` | `60000 → "1m"` | str |
| `vf.horizon_cols(prefix, horizons)` | `["mid_1m", "mid_3m"]` | list[str] |
| `vf.pivot_horizons(df, ref_cols, horizons)` | Long → wide by horizon | **DataFrame** (eager) |

### Utils

```python
vf.add_tod(lf, "ticktime")       # adds tod_ticktime (pl.Datetime) for plotting
vf.DurationFormatter()            # matplotlib formatter for ms values
vf.format_duration(90000)         # "1m30s"
```

### Schema Evolution — `references/schema.md` for full details

```python
vf.SchemaEvolution(columns={"raw_col": vf.ColumnSpec(rename_to="std_col", ...)}, ...)
vf.get_schema("ylin_v20251204")   # lookup registered schema by name
# Registered: ylin_v20251204, jyao_v20251114, jyao_univ_v20251230, sim_standard,
#             eric_v20260205, oic_live, stock_sorted_t5ob
```

### Workspace + Execute — `references/workspace.md` for full details

```python
ws = vf.init_workspace("name")                    # create workspace.toml + graph.dot
ws = vf.connect()                                  # load existing workspace

# Build Config from workspace sources (recommended)
cfg = ws.config(trade="ylin_sim_v1", alpha="jyao_alpha", horizons=[60000, 180000])
vf.set_config(cfg)

ws.register_source("name", type="trade", dir=..., pattern=..., schema=...)
lf = ws.scan("source_name", "20240827")            # scan registered source
result = vf.execute(lf, name="node", path="./out", partition_by="data_date")
lf = ws.read("node_name")                         # read materialized output
```

### Plan (LogicPlan Protocol)

```python
vf.LogicPlan    # Protocol: .collect() -> DataFrame, .serialize() -> bytes
vf.MapFunction(fn=callable, args=tuple)  # wraps callable as LogicPlan node
```

`pl.LazyFrame` satisfies `LogicPlan` natively. Use `MapFunction` for custom computations.

### Templates

```python
vf.templates.list()                    # print available whiteboards
vf.templates.show("daily_forward_stats")  # print copy-paste-ready code
```

Categories: enrichment (5), stats (5), plots (4), EDA (5) — 19 total whiteboards.

### Install Skills

```python
vf.install_skills("vizflow")           # copy skill files to .claude/skills/
vf.install_skills("vizflow", path=".cline/skills")  # Cline
```

---

## Gotchas

> **Warning:** These are the most common sources of bugs when working with VizFlow.

- `merge_forward` and `forward_return` **collect internally** — they are eager, not lazy
- `scan_trade` auto-adds `seq` (row index) and `data_date` columns
- `parse_time` output is `elapsed_{col}` (Int64 ms), not the original column
- Schema evolution is automatic when `trade_schema` etc. is set in Config
- `scan_quote` supports `columns=` for **read-time projection** (critical for large FST files)
- Multi-source `trade_dir=dict[str, Path]` auto-adds tag column (default name `"source"`)
- `execute()` is the **only** materialization boundary — don't write files manually with workspace
- `melt_forward` is **deprecated** — use manual horizon loop with select+rename instead
- `pivot_horizons` collects internally (pivot is inherently eager)

---

## Reference Files

When you need full function signatures or detailed examples, read these:

| Topic | File |
|-------|------|
| Quick start / setup | `references/quickstart.md` |
| I/O (scan_*) | `references/io.md` |
| Operations | `references/ops.md` |
| Workspace / Execute / DAG | `references/workspace.md` |
| Schema Evolution | `references/schema.md` |
| Workflow Patterns | `references/patterns.md` |
| Version migration | `references/upgrade.md` |
| Skill maintenance | `references/maintainer.md` |
| Template whiteboards | `vizflow/templates/_enrichment.py`, `_stats.py`, `_plots.py`, `_eda.py` |
| Design rationale | `docs/DESIGN.md` |

---

## Feedback Protocol

VizFlow feedback is collected in `VIZFLOW_FEEDBACK.md` next to `workspace.toml` — a global file shared across all projects.

**When to capture:** user opinions about VizFlow, AI-discovered gaps, API friction, repeated patterns that should be a function.

**How:**
1. Check if raw Polars solves it (often yes — not everything belongs in VizFlow)
2. If it's worth recording, **ask the user**: "Should I record this as VizFlow feedback?"
3. On approval, append to `VIZFLOW_FEEDBACK.md` next to `workspace.toml`

<details>
<summary>Feedback entry template</summary>

```markdown
## [date] Category: Title

**Source:** [project name / context]
**Category:** Missing Feature | API Friction | Better Abstraction | Design Critique | Bug
**Severity:** High | Medium | Low

**Description:**
[What happened, what was expected, why it matters]

**Example code (if applicable):**
```python
# What the user tried or wished they could do
```

**Suggested API (if applicable):**
```python
# How VizFlow could handle this
```
```

</details>
