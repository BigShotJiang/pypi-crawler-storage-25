---
name: clangd-lsp
description: >
  C/C++ development assistance via clangd language server. Trigger whenever the user
  works with C, C++, or header files (.c, .h, .cpp, .cc, .cxx, .hpp, .hxx). Provides
  code intelligence, diagnostics, formatting, and navigation. Also trigger when the user
  asks about compilation errors, include paths, CMake, Makefile, or C/C++ toolchain setup.
---

# C/C++ Development with clangd

clangd is a language server for C/C++ that provides code intelligence, diagnostics, and formatting.

## Supported File Extensions

`.c`, `.h`, `.cpp`, `.cc`, `.cxx`, `.hpp`, `.hxx`, `.C`, `.H`

## Installation

| Platform | Command |
|----------|---------|
| macOS (Homebrew) | `brew install llvm` then `export PATH="/opt/homebrew/opt/llvm/bin:$PATH"` |
| Ubuntu/Debian | `sudo apt install clangd` |
| Fedora | `sudo dnf install clang-tools-extra` |
| Arch Linux | `sudo pacman -S clang` |
| Windows | `winget install LLVM.LLVM` |

## What clangd Provides

- **Code completion** — context-aware suggestions for functions, types, members
- **Diagnostics** — real-time error/warning detection without full compilation
- **Go to definition / references** — navigate across translation units
- **Formatting** — applies `.clang-format` rules automatically
- **Include management** — suggests missing headers, removes unused ones

## Project Setup

clangd needs a `compile_commands.json` to understand your project's build configuration.

**CMake (most common):**
```bash
cmake -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -B build
# Creates build/compile_commands.json
ln -s build/compile_commands.json .  # symlink to project root
```

**Makefile / manual:**
```bash
# Use Bear to generate compile_commands.json from any build system
brew install bear  # or apt install bear
bear -- make       # wraps make and captures compiler invocations
```

**Single files (no build system):**
Create a `.clangd` config file at the project root:
```yaml
CompileFlags:
  Add:
    - -std=c++17
    - -I/usr/local/include
```

## Common Diagnostics

| Diagnostic | Likely cause | Fix |
|-----------|-------------|-----|
| `unknown type name` | Missing include or wrong standard | Add `#include` or set `-std=c++17` |
| `use of undeclared identifier` | Typo, missing header, or namespace | Check spelling, add `using namespace` or qualify |
| `no matching function` | Wrong argument types | Check parameter types, add casts |
| `compile_commands.json not found` | clangd can't find build config | Generate via CMake or Bear (see above) |

## Best Practices for C/C++ with AI

- Keep `compile_commands.json` up to date — re-run CMake after adding files
- Use `.clang-format` for consistent style (clangd formats on save)
- Prefer `#pragma once` over include guards for simplicity
- Use `static_assert` and `constexpr` to catch errors at compile time
- When debugging link errors, check `compile_commands.json` for missing `-l` flags

## References

- [clangd website](https://clangd.llvm.org/)
- [Getting started guide](https://clangd.llvm.org/installation)
- [Configuration reference](https://clangd.llvm.org/config)
