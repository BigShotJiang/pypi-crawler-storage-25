"""Schema Evolution for VizFlow.

This module defines how raw data evolves into standard format through:
- Column renaming (raw names → standard names)
- Parse-time type specification (for CSV parsing)
- Post-load type casting (e.g., Float64 → Int64)
- Null value handling
- Column exclusion

Example:
    >>> schema = SchemaEvolution(
    ...     columns={
    ...         "fillQty": ColumnSpec(
    ...             rename_to="order_filled_qty",
    ...             parse_dtype=pl.Float64,  # Parse as float (catch decimals)
    ...             cast_dtype=pl.Int64,     # Then cast to int
    ...         ),
    ...     },
    ...     null_values=["", "NA"],
    ...     drop=["#HFTORD"],
    ... )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import polars as pl


@dataclass
class ColumnSpec:
    """Specification for a single column's parsing and transformation.

    Attributes:
        rename_to: Standard column name after rename. None keeps original name.
        parse_dtype: Type to use when parsing CSV. None uses Polars inference.
        cast_dtype: Final type after post-load casting. None keeps parse type.
        transform: Value transformation function. Receives pl.col(self),
            returns transformed expression. Applied after rename, before cast.

    Examples:
        # Rename only (most common)
        ColumnSpec(rename_to="ukey")

        # Parse as Float64, cast to Int64 (handle decimal errors in qty)
        ColumnSpec(rename_to="order_filled_qty",
                   parse_dtype=pl.Float64,
                   cast_dtype=pl.Int64)

        # Scale prices: stored as px * 10000 → divide to restore yuan
        ColumnSpec(rename_to="bid_px0", transform=lambda e: e / 10000)
    """

    rename_to: str | None = None
    parse_dtype: Any = None  # pl.DataType
    cast_dtype: Any = None   # pl.DataType
    transform: Callable[[pl.Expr], pl.Expr] | None = None


@dataclass
class SchemaEvolution:
    """Defines how raw data evolves into standard format.

    Combines column renaming, parse-time types, post-load casting,
    null value handling, and column exclusion into a single structure.

    Attributes:
        columns: Mapping from original column name to ColumnSpec.
        null_values: Strings to treat as null at parse time.
        drop: Column names to exclude from output.
        parent: Optional parent schema for version inheritance.

    Example:
        >>> YLIN_V20251204 = SchemaEvolution(
        ...     columns={
        ...         "symbol": ColumnSpec(rename_to="ukey", parse_dtype=pl.Int64),
        ...         "fillQty": ColumnSpec(
        ...             rename_to="order_filled_qty",
        ...             parse_dtype=pl.Float64,
        ...             cast_dtype=pl.Int64,
        ...         ),
        ...     },
        ...     null_values=["", "NA", "null"],
        ...     drop=["#HFTORD"],
        ... )
    """

    columns: dict[str, ColumnSpec] = field(default_factory=dict)
    null_values: list[str] = field(default_factory=lambda: ["", "NA", "null"])
    drop: list[str] = field(default_factory=list)
    zero_size_nulls_price: list[tuple[str, str]] = field(default_factory=list)
    parent: SchemaEvolution | None = None

    def get_schema_overrides(self) -> dict[str, Any]:
        """Get schema_overrides dict for pl.scan_csv().

        Returns:
            Mapping from original column name to Polars dtype.
        """
        result = {}
        if self.parent:
            result.update(self.parent.get_schema_overrides())
        for col_name, spec in self.columns.items():
            if spec.parse_dtype is not None:
                result[col_name] = spec.parse_dtype
        return result

    def get_rename_map(self) -> dict[str, str]:
        """Get rename mapping dict for df.rename().

        Returns:
            Mapping from original column name to new name.
        """
        result = {}
        if self.parent:
            result.update(self.parent.get_rename_map())
        for col_name, spec in self.columns.items():
            if spec.rename_to is not None:
                result[col_name] = spec.rename_to
        return result

    def get_cast_map(self) -> dict[str, Any]:
        """Get post-load cast mapping dict.

        Returns:
            Mapping from FINAL column name (after rename) to cast dtype.
        """
        result = {}
        if self.parent:
            result.update(self.parent.get_cast_map())
        for col_name, spec in self.columns.items():
            if spec.cast_dtype is not None:
                final_name = spec.rename_to or col_name
                result[final_name] = spec.cast_dtype
        return result

    def get_transform_map(self) -> dict[str, Callable[[pl.Expr], pl.Expr]]:
        """Get transform mapping dict.

        Returns:
            Mapping from FINAL column name (after rename) to transform function.
        """
        result = {}
        if self.parent:
            result.update(self.parent.get_transform_map())
        for col_name, spec in self.columns.items():
            if spec.transform is not None:
                final_name = spec.rename_to or col_name
                result[final_name] = spec.transform
        return result

    def get_drop_columns(self) -> set[str]:
        """Get set of columns to drop.

        Returns:
            Set of original column names to exclude.
        """
        result = set()
        if self.parent:
            result.update(self.parent.get_drop_columns())
        result.update(self.drop)
        return result

    def get_reverse_rename_map(self) -> dict[str, str]:
        """Get reverse rename mapping: VizFlow name → original name.

        Returns:
            Mapping from renamed column name back to original name.

        Example:
            >>> schema = SchemaEvolution(columns={
            ...     "bid_px1": ColumnSpec(rename_to="bid_px0"),
            ... })
            >>> schema.get_reverse_rename_map()
            {'bid_px0': 'bid_px1'}
        """
        return {v: k for k, v in self.get_rename_map().items()}

    def get_null_values(self) -> list[str]:
        """Get list of null value strings.

        Returns:
            List of strings to treat as null at parse time.
        """
        return self.null_values

    def get_zero_size_nulls_price(self) -> list[tuple[str, str]]:
        """Get (size_col, price_col) pairs for zero-size → null-price rule.

        When size_col == 0, price_col is set to null. Uses post-rename names.

        Returns:
            List of (size_col, price_col) tuples.
        """
        result: list[tuple[str, str]] = []
        if self.parent:
            result.extend(self.parent.get_zero_size_nulls_price())
        result.extend(self.zero_size_nulls_price)
        return result

    def validate(self) -> list[str]:
        """Validate schema configuration.

        Returns:
            List of warnings about potential issues.
        """
        warnings = []
        for col_name, spec in self.columns.items():
            if spec.cast_dtype is not None and spec.parse_dtype is None:
                warnings.append(
                    f"{col_name}: cast_dtype without parse_dtype may fail "
                    "if Polars infers wrong type"
                )
        return warnings


# =============================================================================
# YLIN Trade Format (v2025-12-04)
# =============================================================================

YLIN_V20251204 = SchemaEvolution(
    columns={
        # === Order columns (18) ===
        "symbol": ColumnSpec(rename_to="ukey", parse_dtype=pl.Int64),
        "orderId": ColumnSpec(rename_to="order_id", parse_dtype=pl.Int64),
        "orderSide": ColumnSpec(rename_to="order_side", parse_dtype=pl.String),
        "orderQty": ColumnSpec(
            rename_to="order_qty",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "orderPrice": ColumnSpec(rename_to="order_price", parse_dtype=pl.Float64),
        "priceType": ColumnSpec(rename_to="order_price_type", parse_dtype=pl.String),
        "fillQty": ColumnSpec(
            rename_to="order_filled_qty",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "fillPrice": ColumnSpec(rename_to="fill_price", parse_dtype=pl.Float64),
        "lastExchangeTs": ColumnSpec(rename_to="update_exchange_ts", parse_dtype=pl.Int64),
        "createdTs": ColumnSpec(rename_to="create_exchange_ts", parse_dtype=pl.Int64),
        "localTs": ColumnSpec(rename_to="create_local_ts", parse_dtype=pl.Int64),
        "qtyAhead": ColumnSpec(
            rename_to="qty_ahead",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "qtyBehind": ColumnSpec(
            rename_to="qty_behind",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "orderStatus": ColumnSpec(rename_to="order_curr_state", parse_dtype=pl.String),
        "orderTposType": ColumnSpec(rename_to="order_tpos_type", parse_dtype=pl.String),
        "alphaTs": ColumnSpec(rename_to="alpha_ts", parse_dtype=pl.Int64),
        "event": ColumnSpec(rename_to="event_type", parse_dtype=pl.String),
        "cumFilledNotional": ColumnSpec(
            rename_to="order_filled_notional",
            parse_dtype=pl.Float64,
        ),
        # === Quote columns (20) ===
        "bid": ColumnSpec(rename_to="bid_px0", parse_dtype=pl.Float64),
        "bid2": ColumnSpec(rename_to="bid_px1", parse_dtype=pl.Float64),
        "bid3": ColumnSpec(rename_to="bid_px2", parse_dtype=pl.Float64),
        "bid4": ColumnSpec(rename_to="bid_px3", parse_dtype=pl.Float64),
        "bid5": ColumnSpec(rename_to="bid_px4", parse_dtype=pl.Float64),
        "ask": ColumnSpec(rename_to="ask_px0", parse_dtype=pl.Float64),
        "ask2": ColumnSpec(rename_to="ask_px1", parse_dtype=pl.Float64),
        "ask3": ColumnSpec(rename_to="ask_px2", parse_dtype=pl.Float64),
        "ask4": ColumnSpec(rename_to="ask_px3", parse_dtype=pl.Float64),
        "ask5": ColumnSpec(rename_to="ask_px4", parse_dtype=pl.Float64),
        "bsize": ColumnSpec(
            rename_to="bid_size0",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "bsize2": ColumnSpec(
            rename_to="bid_size1",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "bsize3": ColumnSpec(
            rename_to="bid_size2",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "bsize4": ColumnSpec(
            rename_to="bid_size3",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "bsize5": ColumnSpec(
            rename_to="bid_size4",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "asize": ColumnSpec(
            rename_to="ask_size0",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "asize2": ColumnSpec(
            rename_to="ask_size1",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "asize3": ColumnSpec(
            rename_to="ask_size2",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "asize4": ColumnSpec(
            rename_to="ask_size3",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "asize5": ColumnSpec(
            rename_to="ask_size4",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "isRebasedQuote": ColumnSpec(rename_to="is_rebased", parse_dtype=pl.String),
        "quoteSeqNum": ColumnSpec(rename_to="seq_num", parse_dtype=pl.Int64),
        "quoteTs": ColumnSpec(rename_to="timestamp", parse_dtype=pl.Int64),
        # === Position columns (11) ===
        "startPos": ColumnSpec(
            rename_to="init_net_pos",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "pos": ColumnSpec(
            rename_to="current_net_pos",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "realizedPos": ColumnSpec(
            rename_to="current_realized_net_pos",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "openBuyPos": ColumnSpec(
            rename_to="open_buy",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "openSellPos": ColumnSpec(
            rename_to="open_sell",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "cumBuy": ColumnSpec(
            rename_to="cum_buy",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "cumSell": ColumnSpec(
            rename_to="cum_sell",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "cashFlow": ColumnSpec(rename_to="cash_flow", parse_dtype=pl.Float64),
        "frozenCash": ColumnSpec(rename_to="frozen_cash", parse_dtype=pl.Float64),
        "globalCumBuyNotional": ColumnSpec(
            rename_to="cum_buy_filled_notional",
            parse_dtype=pl.Float64,
        ),
        "globalCumSellNotional": ColumnSpec(
            rename_to="cum_sell_filled_notional",
            parse_dtype=pl.Float64,
        ),
    },
    null_values=["", "NA", "null", "NULL"],
    drop=["#HFTORD", "#ORD"],  # #HFTORD for .meords, #ORD for .ords (grep output)
)


# =============================================================================
# JYAO Alpha Format (v2025-11-14)
# =============================================================================

JYAO_V20251114 = SchemaEvolution(
    columns={
        # Symbol column - parse_dtype for CSV, cast_dtype for feather/IPC
        # (feather files have embedded types, so cast is needed post-load)
        "ukey": ColumnSpec(parse_dtype=pl.Int64, cast_dtype=pl.Int64),
        # Time columns
        "ticktime": ColumnSpec(parse_dtype=pl.Int64, cast_dtype=pl.Int64),
        # Quote columns
        "BidPrice1": ColumnSpec(rename_to="bid_px0", parse_dtype=pl.Float64),
        "AskPrice1": ColumnSpec(rename_to="ask_px0", parse_dtype=pl.Float64),
        "BidVolume1": ColumnSpec(
            rename_to="bid_size0",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        "AskVolume1": ColumnSpec(
            rename_to="ask_size0",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        # Time columns
        "TimeStamp": ColumnSpec(rename_to="timestamp", parse_dtype=pl.Int64),
        "GlobalExTime": ColumnSpec(rename_to="global_exchange_ts", parse_dtype=pl.Int64),
        "DataDate": ColumnSpec(rename_to="data_date", parse_dtype=pl.Int64),  # Keep Int64, convert in io.py
        # Volume
        "Volume": ColumnSpec(
            rename_to="volume",
            parse_dtype=pl.Float64,
            cast_dtype=pl.Int64,
        ),
        # Predictor columns (x_* = alpha predictions)
        # Rule: ≤60s → s, >60s → m
        "x10s": ColumnSpec(rename_to="x_10s", parse_dtype=pl.Float64),
        "x60s": ColumnSpec(rename_to="x_60s", parse_dtype=pl.Float64),
        "alpha1": ColumnSpec(rename_to="x_3m", parse_dtype=pl.Float64),
        "alpha2": ColumnSpec(rename_to="x_30m", parse_dtype=pl.Float64),
    },
    null_values=["", "NA"],
)


# =============================================================================
# JYAO Univ Format (v2025-12-30)
# =============================================================================

JYAO_UNIV_V20251230 = SchemaEvolution(
    columns={
        # ID
        "ukey": ColumnSpec(parse_dtype=pl.Int64),
        # Price columns (Float64)
        "ydclose": ColumnSpec(parse_dtype=pl.Float64),
        "preclose": ColumnSpec(parse_dtype=pl.Float64),
        "open": ColumnSpec(parse_dtype=pl.Float64),
        "close": ColumnSpec(parse_dtype=pl.Float64),
        "upper_limit_price": ColumnSpec(parse_dtype=pl.Float64),
        "lower_limit_price": ColumnSpec(parse_dtype=pl.Float64),
        "tick_size": ColumnSpec(parse_dtype=pl.Float64),
        # Lot size columns (parse Float64 → cast Int64)
        "trade_min_size": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "trade_unit_size": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "qty_unit": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        # Average/aggregated columns (Float64)
        "trade_max_size": ColumnSpec(parse_dtype=pl.Float64),
        "adv": ColumnSpec(parse_dtype=pl.Float64),
        "roll_spread": ColumnSpec(parse_dtype=pl.Float64),
        "buy_avg_volume": ColumnSpec(parse_dtype=pl.Float64),
        "sell_avg_volume": ColumnSpec(parse_dtype=pl.Float64),
        "avg_touch_size_mean": ColumnSpec(parse_dtype=pl.Float64, rename_to="avg_touch_size"),
        "avg_touch_order_size": ColumnSpec(parse_dtype=pl.Float64),
        # Risk columns (Float64)
        "TotalRisk": ColumnSpec(parse_dtype=pl.Float64),
        "SpecRisk": ColumnSpec(parse_dtype=pl.Float64),
        # Boolean columns (TRUE/FALSE strings)
        "is_price_limited": ColumnSpec(parse_dtype=pl.Boolean),
        "is_t0": ColumnSpec(parse_dtype=pl.Boolean),
        # Integer columns
        "category": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "is_ST": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),  # 0/1 numeric
        # String columns
        "UNIVERSE": ColumnSpec(parse_dtype=pl.String),
        "INDUSTRY": ColumnSpec(parse_dtype=pl.String),
        "INDEX": ColumnSpec(parse_dtype=pl.String),
    },
    null_values=["", "NA"],
)


# =============================================================================
# SIM Standard Format (standard column names, type conversion only)
# For sim output that already uses standard column names (same as YLIN rename_to)
# =============================================================================

SIM_STANDARD = SchemaEvolution(
    columns={
        # === Order columns ===
        "ukey": ColumnSpec(parse_dtype=pl.Int64),
        "order_id": ColumnSpec(parse_dtype=pl.Int64),
        "order_side": ColumnSpec(parse_dtype=pl.String),  # "B" / "S"
        "order_qty": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "order_price": ColumnSpec(parse_dtype=pl.Float64),
        "order_price_type": ColumnSpec(parse_dtype=pl.String),
        "order_filled_qty": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "fill_price": ColumnSpec(parse_dtype=pl.Float64),
        "order_filled_notional": ColumnSpec(parse_dtype=pl.Float64),
        "qty_ahead": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "qty_behind": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "order_curr_state": ColumnSpec(parse_dtype=pl.String),
        "order_tpos_type": ColumnSpec(parse_dtype=pl.String),
        # === Timestamps ===
        "create_exchange_ts": ColumnSpec(parse_dtype=pl.Int64),
        "create_local_ts": ColumnSpec(parse_dtype=pl.Int64),
        "update_exchange_ts": ColumnSpec(parse_dtype=pl.Int64),
        "alpha_ts": ColumnSpec(parse_dtype=pl.Int64),
        "timestamp": ColumnSpec(parse_dtype=pl.Int64),
        # Note: Quote columns (bid_px0, ask_px0, etc.) come from alpha merge
        # === Position columns ===
        "init_net_pos": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "current_net_pos": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "current_realized_net_pos": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "open_buy": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "open_sell": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "cum_buy": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "cum_sell": ColumnSpec(parse_dtype=pl.Float64, cast_dtype=pl.Int64),
        "cash_flow": ColumnSpec(parse_dtype=pl.Float64),
        "frozen_cash": ColumnSpec(parse_dtype=pl.Float64),
        "cum_buy_filled_notional": ColumnSpec(parse_dtype=pl.Float64),
        "cum_sell_filled_notional": ColumnSpec(parse_dtype=pl.Float64),
    },
    null_values=["", "NA", "null"],
)


# =============================================================================
# ERIC Trade Format (v2026-02-05)
# Feather format, snake_case columns
# fill_qty is per-fill incremental (NOT cumulative order_filled_qty)
# =============================================================================

ERIC_V20260205 = SchemaEvolution(
    columns={
        # === Timestamps (int32 in feather → cast Int64) ===
        "last_exchange_ts": ColumnSpec(rename_to="update_exchange_ts", cast_dtype=pl.Int64),
        "local_ts": ColumnSpec(rename_to="update_local_ts", cast_dtype=pl.Int64),
        "created_ts": ColumnSpec(rename_to="create_exchange_ts", cast_dtype=pl.Int64),
        # === Identity ===
        "ukey": ColumnSpec(cast_dtype=pl.Int64),  # int32 → Int64 for consistency
        "order_id": ColumnSpec(),  # Already Int64
        "ecn": ColumnSpec(),
        # === Event ===
        "event": ColumnSpec(rename_to="event_type"),
        "reason": ColumnSpec(),
        # === Order ===
        "order_side": ColumnSpec(),
        "order_qty": ColumnSpec(cast_dtype=pl.Int64),
        "order_price": ColumnSpec(),
        "price_type": ColumnSpec(rename_to="order_price_type"),
        # === Fill (per-fill incremental, NOT cumulative) ===
        "fill_qty": ColumnSpec(cast_dtype=pl.Int64),
        "fill_price": ColumnSpec(),
        # === Quote snapshot at trade time (suffixed to avoid collision with ref data) ===
        "bid": ColumnSpec(rename_to="bid_px0_trade"),
        "ask": ColumnSpec(rename_to="ask_px0_trade"),
        "bsize": ColumnSpec(rename_to="bid_size0_trade", cast_dtype=pl.Int64),
        "asize": ColumnSpec(rename_to="ask_size0_trade", cast_dtype=pl.Int64),
        # === Position ===
        "pos": ColumnSpec(rename_to="current_realized_net_pos", cast_dtype=pl.Int64),
        "live_pos": ColumnSpec(rename_to="current_net_pos", cast_dtype=pl.Int64),
        "tpos": ColumnSpec(rename_to="target_pos", cast_dtype=pl.Int64),
        # === Spread (keep Float64) ===
        "hs": ColumnSpec(rename_to="half_spread_bps"),
        "hhs": ColumnSpec(rename_to="hist_half_spread_bps"),
        "tod_spread": ColumnSpec(rename_to="tod_spread_bps"),
    },
    null_values=["", "NA", "null", "None", "NaN"],
)


# =============================================================================
# OIC Live Trade Format
# Fork of ERIC_V20260205 with bps columns scaled: raw values × 10000 → bps
# =============================================================================

_BPS_SCALE: Callable[[pl.Expr], pl.Expr] = lambda e: e * 10000

OIC_LIVE = SchemaEvolution(
    columns={
        # === Timestamps (int32 in feather → cast Int64) ===
        "last_exchange_ts": ColumnSpec(rename_to="update_exchange_ts", cast_dtype=pl.Int64),
        "local_ts": ColumnSpec(rename_to="update_local_ts", cast_dtype=pl.Int64),
        "created_ts": ColumnSpec(rename_to="create_exchange_ts", cast_dtype=pl.Int64),
        # === Identity ===
        "ukey": ColumnSpec(cast_dtype=pl.Int64),
        "order_id": ColumnSpec(),
        "ecn": ColumnSpec(),
        # === Event ===
        "event": ColumnSpec(rename_to="event_type"),
        "reason": ColumnSpec(),
        # === Order ===
        "order_side": ColumnSpec(),
        "order_qty": ColumnSpec(cast_dtype=pl.Int64),
        "order_price": ColumnSpec(),
        "price_type": ColumnSpec(rename_to="order_price_type"),
        # === Fill (per-fill incremental, NOT cumulative) ===
        "fill_qty": ColumnSpec(cast_dtype=pl.Int64),
        "fill_price": ColumnSpec(),
        # === Quote snapshot at trade time (suffixed to avoid collision with ref data) ===
        "bid": ColumnSpec(rename_to="bid_px0_trade"),
        "ask": ColumnSpec(rename_to="ask_px0_trade"),
        "bsize": ColumnSpec(rename_to="bid_size0_trade", cast_dtype=pl.Int64),
        "asize": ColumnSpec(rename_to="ask_size0_trade", cast_dtype=pl.Int64),
        # === Position ===
        "pos": ColumnSpec(rename_to="current_realized_net_pos", cast_dtype=pl.Int64),
        "live_pos": ColumnSpec(rename_to="current_net_pos", cast_dtype=pl.Int64),
        "tpos": ColumnSpec(rename_to="target_pos", cast_dtype=pl.Int64),
        # === Spread (raw × 10000 → bps) ===
        "hs": ColumnSpec(rename_to="half_spread_bps", transform=_BPS_SCALE),
        "hhs": ColumnSpec(rename_to="hist_half_spread_bps", transform=_BPS_SCALE),
        "tod_spread": ColumnSpec(rename_to="tod_spread_bps", transform=_BPS_SCALE),
    },
    null_values=["", "NA", "null", "None", "NaN"],
)


# =============================================================================
# Stock Sorted T5OB Quote Format (5-level tick-by-tick order book, FST)
# Full market quote data. 1-indexed levels → 0-indexed VizFlow convention.
# vol → size naming convention. FST NaN → float, so int cols need cast_dtype.
# =============================================================================

_PRICE_SCALE: Callable[[pl.Expr], pl.Expr] = lambda e: e / 10000

STOCK_SORTED_T5OB = SchemaEvolution(
    columns={
        # === Identity ===
        "seq_num": ColumnSpec(cast_dtype=pl.Int64),
        "origin_seq_num": ColumnSpec(cast_dtype=pl.Int64),
        "date": ColumnSpec(cast_dtype=pl.Int64),
        "ticktime": ColumnSpec(cast_dtype=pl.Int64),
        "ukey": ColumnSpec(cast_dtype=pl.Int64),
        # === Bid prices (1-indexed → 0-indexed, ×10000 → yuan) ===
        "bid_px1": ColumnSpec(rename_to="bid_px0", transform=_PRICE_SCALE),
        "bid_px2": ColumnSpec(rename_to="bid_px1", transform=_PRICE_SCALE),
        "bid_px3": ColumnSpec(rename_to="bid_px2", transform=_PRICE_SCALE),
        "bid_px4": ColumnSpec(rename_to="bid_px3", transform=_PRICE_SCALE),
        "bid_px5": ColumnSpec(rename_to="bid_px4", transform=_PRICE_SCALE),
        # === Ask prices (1-indexed → 0-indexed, ×10000 → yuan) ===
        "ask_px1": ColumnSpec(rename_to="ask_px0", transform=_PRICE_SCALE),
        "ask_px2": ColumnSpec(rename_to="ask_px1", transform=_PRICE_SCALE),
        "ask_px3": ColumnSpec(rename_to="ask_px2", transform=_PRICE_SCALE),
        "ask_px4": ColumnSpec(rename_to="ask_px3", transform=_PRICE_SCALE),
        "ask_px5": ColumnSpec(rename_to="ask_px4", transform=_PRICE_SCALE),
        # === Bid sizes (vol → size + 1→0 reindex, round + cast for NaN) ===
        "bid_vol1": ColumnSpec(rename_to="bid_size0", cast_dtype=pl.Int64),
        "bid_vol2": ColumnSpec(rename_to="bid_size1", cast_dtype=pl.Int64),
        "bid_vol3": ColumnSpec(rename_to="bid_size2", cast_dtype=pl.Int64),
        "bid_vol4": ColumnSpec(rename_to="bid_size3", cast_dtype=pl.Int64),
        "bid_vol5": ColumnSpec(rename_to="bid_size4", cast_dtype=pl.Int64),
        # === Ask sizes (vol → size + 1→0 reindex, round + cast for NaN) ===
        "ask_vol1": ColumnSpec(rename_to="ask_size0", cast_dtype=pl.Int64),
        "ask_vol2": ColumnSpec(rename_to="ask_size1", cast_dtype=pl.Int64),
        "ask_vol3": ColumnSpec(rename_to="ask_size2", cast_dtype=pl.Int64),
        "ask_vol4": ColumnSpec(rename_to="ask_size3", cast_dtype=pl.Int64),
        "ask_vol5": ColumnSpec(rename_to="ask_size4", cast_dtype=pl.Int64),
        # === Metadata ===
        "price_type": ColumnSpec(),
        "volume_type": ColumnSpec(),
        "origin_extime": ColumnSpec(),
        "localtime_ms": ColumnSpec(cast_dtype=pl.Int64),
        "localtime_ns": ColumnSpec(cast_dtype=pl.Int64),
        # === Bid/Ask indices (1-indexed → 0-indexed) ===
        "bid_index_1": ColumnSpec(rename_to="bid_index_0"),
        "bid_index_2": ColumnSpec(rename_to="bid_index_1"),
        "bid_index_3": ColumnSpec(rename_to="bid_index_2"),
        "bid_index_4": ColumnSpec(rename_to="bid_index_3"),
        "bid_index_5": ColumnSpec(rename_to="bid_index_4"),
        "ask_index_1": ColumnSpec(rename_to="ask_index_0"),
        "ask_index_2": ColumnSpec(rename_to="ask_index_1"),
        "ask_index_3": ColumnSpec(rename_to="ask_index_2"),
        "ask_index_4": ColumnSpec(rename_to="ask_index_3"),
        "ask_index_5": ColumnSpec(rename_to="ask_index_4"),
        # === Cumulative volumes (round + cast for NaN) ===
        "cum_buy_vol": ColumnSpec(cast_dtype=pl.Int64),
        "cum_buy_amt": ColumnSpec(),
        "cum_sell_vol": ColumnSpec(cast_dtype=pl.Int64),
        "cum_sell_amt": ColumnSpec(),
    },
    zero_size_nulls_price=[
        ("bid_size0", "bid_px0"),
        ("ask_size0", "ask_px0"),
        ("bid_size1", "bid_px1"),
        ("ask_size1", "ask_px1"),
        ("bid_size2", "bid_px2"),
        ("ask_size2", "ask_px2"),
        ("bid_size3", "bid_px3"),
        ("ask_size3", "ask_px3"),
        ("bid_size4", "bid_px4"),
        ("ask_size4", "ask_px4"),
    ],
)


# =============================================================================
# Schema Registry
# =============================================================================

SCHEMAS: dict[str, SchemaEvolution] = {
    "ylin_v20251204": YLIN_V20251204,
    "jyao_v20251114": JYAO_V20251114,
    "jyao_univ_v20251230": JYAO_UNIV_V20251230,
    "sim_standard": SIM_STANDARD,
    "eric_v20260205": ERIC_V20260205,
    "oic_live": OIC_LIVE,
    "stock_sorted_t5ob": STOCK_SORTED_T5OB,
}


def get_schema(name: str | None) -> SchemaEvolution | None:
    """Get SchemaEvolution by name.

    Args:
        name: Schema name (e.g., "ylin_v20251204") or None.

    Returns:
        SchemaEvolution or None if name is None or not found.
    """
    if not name:
        return None
    return SCHEMAS.get(name.lower())
