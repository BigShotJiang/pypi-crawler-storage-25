"""Interactive visualization module for VizFlow.

This module provides interactive EDA tools using HoloViews + Datashader + Panel.

Exports:
    - heatmap: Interactive 2D heatmap with custom aggregation
    - horizon_curve: Time-series analysis (markout curves)
    - dashboard: Interactive Panel dashboard
    - raster: Namespace for aggregation functions (raster.wmean, raster.mean, etc.)

Usage:
    >>> import vizflow as vf
    >>> import holoviews as hv
    >>> hv.extension('bokeh')
    >>>
    >>> # Weighted mean heatmap
    >>> viz = vf.viz.heatmap(df, "x", "y", agg=vf.viz.raster.wmean("value", "weight"))
    >>>
    >>> # Simple mean heatmap
    >>> viz = vf.viz.heatmap(df, "x", "y", agg=vf.viz.raster.mean("value"))
"""

# raster is lazy-imported via __getattr__ below (requires numpy)

__all__ = [
    # High-dimensional view
    "heatmap",
    # Time-series analysis
    "horizon_curve",
    # Dashboard
    "dashboard",
    # Aggregators namespace
    "raster",
]


def __getattr__(name):
    """Lazy import for optional dependencies."""
    if name == "heatmap":
        from . import _compat

        _compat.require_explore()
        from .high_dimensional_view import heatmap

        globals()["heatmap"] = heatmap
        return heatmap

    if name == "horizon_curve":
        from . import _compat

        _compat.require_explore()
        from .time_series_analysis import horizon_curve

        globals()["horizon_curve"] = horizon_curve
        return horizon_curve

    if name == "dashboard":
        from . import _compat

        _compat.require_explore()
        from .dashboard import dashboard

        globals()["dashboard"] = dashboard
        return dashboard

    if name == "raster":
        from . import raster

        globals()["raster"] = raster
        return raster

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
