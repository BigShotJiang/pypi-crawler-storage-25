"""LogicPlan protocol and MapFunction implementation.

Aligns with Polars Rust IR design:
- LogicPlan: Protocol (trait) for any deferred computation
- MapFunction: wraps a callable as a plan node (IR::MapFunction equivalent)

pl.LazyFrame satisfies LogicPlan natively — no modification needed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import polars as pl


@runtime_checkable
class LogicPlan(Protocol):
    """Any deferred computation that execute() can dispatch.

    Structural subtyping (Rust trait equivalent):
    - pl.LazyFrame satisfies this natively (.collect(), .serialize())
    - MapFunction implements it explicitly
    - Future Rust nodes will satisfy it via Polars native IR
    """

    def collect(self) -> pl.DataFrame: ...
    def serialize(self) -> bytes: ...


@dataclass
class MapFunction:
    """Wraps a callable as a LogicPlan node.

    Aligns with Polars IR::MapFunction. fn(*args) must return pl.DataFrame.

    Serialization uses cloudpickle (Python workaround).
    Future Rust-native nodes will use Polars native serialization instead.
    """

    fn: callable
    args: tuple = ()

    def collect(self) -> pl.DataFrame:
        import polars as pl

        result = self.fn(*self.args)
        if isinstance(result, pl.DataFrame):
            return result
        return pl.DataFrame(result)

    def serialize(self) -> bytes:
        import cloudpickle

        return cloudpickle.dumps({
            "type": "map_fn",
            "fn": self.fn,
            "args": self.args,
        })

    @staticmethod
    def deserialize(data: bytes) -> MapFunction:
        import cloudpickle

        d = cloudpickle.loads(data)
        return MapFunction(fn=d["fn"], args=d["args"])
