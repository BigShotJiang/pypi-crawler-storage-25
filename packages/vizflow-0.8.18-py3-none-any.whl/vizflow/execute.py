"""VizFlow execute — the sole materialization boundary.

collect + write + register. That's it.

Supports:
- Any LogicPlan: LazyFrame, MapFunction, or custom implementations
- Delta Lake (default) or Parquet storage
- Local or Ray backend
- Workspace DAG registration
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Literal

import polars as pl

from .plan import LogicPlan, MapFunction

if TYPE_CHECKING:
    from .workspace import Workspace

logger = logging.getLogger("vizflow.execute")


def execute(
    target: LogicPlan | list[LogicPlan],
    *,
    name: str | None = None,
    upstream: list[str] | None = None,
    path: str | Path | None = None,
    partition_by: str | list[str] | None = None,
    mode: Literal["append", "overwrite"] = "overwrite",
    script: str | None = None,
    workspace: Workspace | None = None,
    backend: Literal["local", "ray"] = "local",
    storage: Literal["delta", "parquet"] = "delta",
    storage_options: dict[str, str] | None = None,
) -> pl.LazyFrame:
    """Execute LogicPlan(s): collect, write, register.

    The sole materialization boundary in VizFlow. It:
    1. Collects the plan(s) — locally or distributed via Ray
    2. Writes results to storage (Delta Lake or Parquet)
    3. Registers the compute node in the workspace DAG
    4. Returns a new LazyFrame scanning the written output

    Args:
        target: A LogicPlan or list of LogicPlans to materialize.
            pl.LazyFrame and MapFunction both satisfy LogicPlan.
        name: Compute node name for workspace registration.
        upstream: Upstream source/node names for lineage.
        path: Output path (local, S3, CPFS). If None, collect only (no write).
        partition_by: Column(s) to partition output by.
        mode: "overwrite" replaces existing data, "append" adds to it.
        script: Path to the producing script (for workspace metadata).
        workspace: Workspace instance. If None, tries connect().
        backend: "local" or "ray". Ray requires ray.init() beforehand.
        storage: "delta" (default) or "parquet".
        storage_options: Passed through to storage layer (e.g. S3 region).

    Returns:
        LazyFrame scanning the materialized output.
    """
    # Normalize to list
    items = target if isinstance(target, list) else [target]
    if not items:
        raise ValueError("No plans to execute — got empty list.")

    # No path: collect and return lazy view (no write, no register)
    if path is None:
        dfs = [item.collect() for item in items]
        return pl.concat(dfs).lazy() if len(dfs) > 1 else dfs[0].lazy()

    path_str = str(path)

    # Dispatch to backend
    if backend == "ray":
        from .ray_backend import execute_ray

        execute_ray(
            items=items,
            path=path_str,
            mode=mode,
            storage=storage,
            storage_options=storage_options,
            partition_by=partition_by,
        )
    else:
        _execute_local(items, path_str, mode, storage, storage_options, partition_by)

    # Register in workspace
    if name:
        _register_node(name, upstream, path_str, partition_by, script, workspace)

    return _scan_output(path_str, storage, storage_options)


def _execute_local(
    items: list,
    path: str,
    mode: str,
    storage: str,
    storage_options: dict[str, str] | None,
    partition_by: str | list[str] | None,
) -> None:
    """Collect and write each plan sequentially."""
    for i, item in enumerate(items):
        df = item.collect()
        # First write uses user's mode; rest always append
        write_mode = mode if i == 0 else "append"
        if storage == "delta":
            _write_delta(df, path, write_mode, storage_options, partition_by)
        else:
            _write_parquet(df, path, partition_by)
        logger.info("Collected item %d/%d (%d rows)", i + 1, len(items), len(df))


def _write_delta(
    df: pl.DataFrame,
    path: str,
    mode: str,
    storage_options: dict[str, str] | None,
    partition_by: str | list[str] | None,
) -> None:
    """Write a DataFrame to a Delta Lake table."""
    kwargs: dict = {}
    if partition_by:
        part_list = [partition_by] if isinstance(partition_by, str) else partition_by
        kwargs["delta_write_options"] = {"partition_by": part_list}
    df.write_delta(
        path,
        mode=mode,
        storage_options=storage_options or {},
        **kwargs,
    )


def _write_parquet(
    df: pl.DataFrame,
    path: str,
    partition_by: str | list[str] | None,
) -> None:
    """Write Hive-style partitioned parquet (backward compat)."""
    out_path = Path(path)
    out_path.mkdir(parents=True, exist_ok=True)

    part_col = partition_by if isinstance(partition_by, str) else (
        partition_by[0] if partition_by else None
    )
    if part_col and part_col in df.columns:
        for partition_val, group in df.group_by(part_col):
            part_dir = out_path / f"{part_col}={partition_val[0]}"
            part_dir.mkdir(parents=True, exist_ok=True)
            group.write_parquet(part_dir / "data.parquet")
    else:
        df.write_parquet(out_path / "data.parquet")


def _scan_output(
    path: str,
    storage: str,
    storage_options: dict[str, str] | None,
) -> pl.LazyFrame:
    """Return a LazyFrame scanning the materialized output."""
    if storage == "delta":
        return pl.scan_delta(path, storage_options=storage_options or {})
    return pl.scan_parquet(str(Path(path) / "**/*.parquet"))


def _register_node(
    name: str,
    upstream: list[str] | None,
    path: str,
    partition_by: str | list[str] | None,
    script: str | None,
    workspace: Workspace | None,
) -> None:
    """Register compute node in workspace DAG."""
    from .workspace import connect

    ws = workspace
    if ws is None:
        try:
            ws = connect()
        except FileNotFoundError:
            return

    # workspace.register_node expects str | None for partition_by
    part_str = (
        partition_by if isinstance(partition_by, str)
        else ",".join(partition_by) if partition_by
        else None
    )
    ws.register_node(
        name,
        upstream=upstream or [],
        path=path,
        partition_by=part_str,
        script=script,
    )
