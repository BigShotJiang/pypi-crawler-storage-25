# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WorkerCreateParams"]


class WorkerCreateParams(TypedDict, total=False):
    instructions: str
    """Persistent system prompt the worker uses for every task it runs."""

    output_schema: Annotated[Dict[str, object], PropertyInfo(alias="outputSchema")]
    """
    Optional JSON Schema (Draft-07) describing the structured object the worker must
    produce. When set, every task response is validated against the schema and
    exposed as `structuredOutput`.
    """

    prompt: str
    """
    Natural-language description of the worker to use for AI-generated instructions
    when `instructions` is omitted.
    """

    summary: str
    """Short one-line description of the worker's purpose.

    Auto-generated when omitted and a `prompt` is provided.
    """

    title: str
    """Optional display name.

    When omitted, Handinger assigns a random dog-themed name.
    """

    visibility: Literal["public", "private"]
    """`public` (default) is visible to all org members.

    `private` is only visible to invited members.
    """
