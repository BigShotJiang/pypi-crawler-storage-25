# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal

import httpx

from ...types import worker_create_params, worker_retrieve_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from .schedules import (
    SchedulesResource,
    AsyncSchedulesResource,
    SchedulesResourceWithRawResponse,
    AsyncSchedulesResourceWithRawResponse,
    SchedulesResourceWithStreamingResponse,
    AsyncSchedulesResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.worker import Worker
from ...types.worker_create_response import WorkerCreateResponse
from ...types.worker_retrieve_email_response import WorkerRetrieveEmailResponse

__all__ = ["WorkersResource", "AsyncWorkersResource"]


class WorkersResource(SyncAPIResource):
    """Create, retrieve, and manage agent worker templates."""

    @cached_property
    def schedules(self) -> SchedulesResource:
        """Manage future and recurring worker tasks."""
        return SchedulesResource(self._client)

    @cached_property
    def with_raw_response(self) -> WorkersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Ramensoft/handinger-python#accessing-raw-response-data-eg-headers
        """
        return WorkersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WorkersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Ramensoft/handinger-python#with_streaming_response
        """
        return WorkersResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        instructions: str | Omit = omit,
        output_schema: Dict[str, object] | Omit = omit,
        prompt: str | Omit = omit,
        summary: str | Omit = omit,
        title: str | Omit = omit,
        visibility: Literal["public", "private"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkerCreateResponse:
        """Create a new worker.

        The worker is a reusable agent template; tasks are runs
        against this template. Use `POST /tasks` to actually run the agent.

        Args:
          instructions: Persistent system prompt the worker uses for every task it runs.

          output_schema: Optional JSON Schema (Draft-07) describing the structured object the worker must
              produce. When set, every task response is validated against the schema and
              exposed as `structuredOutput`.

          prompt: Natural-language description of the worker to use for AI-generated instructions
              when `instructions` is omitted.

          summary: Short one-line description of the worker's purpose. Auto-generated when omitted
              and a `prompt` is provided.

          title: Optional display name. When omitted, Handinger assigns a random dog-themed name.

          visibility: `public` (default) is visible to all org members. `private` is only visible to
              invited members.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/workers",
            body=maybe_transform(
                {
                    "instructions": instructions,
                    "output_schema": output_schema,
                    "prompt": prompt,
                    "summary": summary,
                    "title": title,
                    "visibility": visibility,
                },
                worker_create_params.WorkerCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkerCreateResponse,
        )

    def retrieve(
        self,
        worker_id: str,
        *,
        stream: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Worker:
        """
        Retrieve the current worker state and messages from its most recent task.
        Returns a JSON worker object by default, or a server-sent event stream when
        `stream=true`.

        Args:
          stream: Set to "true" to receive a server-sent event stream that replays all stored
              messages and then continues with live chunks from the active task (if any)
              before closing.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not worker_id:
            raise ValueError(f"Expected a non-empty value for `worker_id` but received {worker_id!r}")
        return self._get(
            path_template("/api/workers/{worker_id}", worker_id=worker_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"stream": stream}, worker_retrieve_params.WorkerRetrieveParams),
            ),
            cast_to=Worker,
        )

    def retrieve_email(
        self,
        worker_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkerRetrieveEmailResponse:
        """
        Retrieve the inbound email address for a worker.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not worker_id:
            raise ValueError(f"Expected a non-empty value for `worker_id` but received {worker_id!r}")
        return self._get(
            path_template("/api/workers/{worker_id}/email", worker_id=worker_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkerRetrieveEmailResponse,
        )


class AsyncWorkersResource(AsyncAPIResource):
    """Create, retrieve, and manage agent worker templates."""

    @cached_property
    def schedules(self) -> AsyncSchedulesResource:
        """Manage future and recurring worker tasks."""
        return AsyncSchedulesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncWorkersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Ramensoft/handinger-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWorkersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWorkersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Ramensoft/handinger-python#with_streaming_response
        """
        return AsyncWorkersResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        instructions: str | Omit = omit,
        output_schema: Dict[str, object] | Omit = omit,
        prompt: str | Omit = omit,
        summary: str | Omit = omit,
        title: str | Omit = omit,
        visibility: Literal["public", "private"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkerCreateResponse:
        """Create a new worker.

        The worker is a reusable agent template; tasks are runs
        against this template. Use `POST /tasks` to actually run the agent.

        Args:
          instructions: Persistent system prompt the worker uses for every task it runs.

          output_schema: Optional JSON Schema (Draft-07) describing the structured object the worker must
              produce. When set, every task response is validated against the schema and
              exposed as `structuredOutput`.

          prompt: Natural-language description of the worker to use for AI-generated instructions
              when `instructions` is omitted.

          summary: Short one-line description of the worker's purpose. Auto-generated when omitted
              and a `prompt` is provided.

          title: Optional display name. When omitted, Handinger assigns a random dog-themed name.

          visibility: `public` (default) is visible to all org members. `private` is only visible to
              invited members.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/workers",
            body=await async_maybe_transform(
                {
                    "instructions": instructions,
                    "output_schema": output_schema,
                    "prompt": prompt,
                    "summary": summary,
                    "title": title,
                    "visibility": visibility,
                },
                worker_create_params.WorkerCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkerCreateResponse,
        )

    async def retrieve(
        self,
        worker_id: str,
        *,
        stream: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Worker:
        """
        Retrieve the current worker state and messages from its most recent task.
        Returns a JSON worker object by default, or a server-sent event stream when
        `stream=true`.

        Args:
          stream: Set to "true" to receive a server-sent event stream that replays all stored
              messages and then continues with live chunks from the active task (if any)
              before closing.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not worker_id:
            raise ValueError(f"Expected a non-empty value for `worker_id` but received {worker_id!r}")
        return await self._get(
            path_template("/api/workers/{worker_id}", worker_id=worker_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"stream": stream}, worker_retrieve_params.WorkerRetrieveParams),
            ),
            cast_to=Worker,
        )

    async def retrieve_email(
        self,
        worker_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkerRetrieveEmailResponse:
        """
        Retrieve the inbound email address for a worker.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not worker_id:
            raise ValueError(f"Expected a non-empty value for `worker_id` but received {worker_id!r}")
        return await self._get(
            path_template("/api/workers/{worker_id}/email", worker_id=worker_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkerRetrieveEmailResponse,
        )


class WorkersResourceWithRawResponse:
    def __init__(self, workers: WorkersResource) -> None:
        self._workers = workers

        self.create = to_raw_response_wrapper(
            workers.create,
        )
        self.retrieve = to_raw_response_wrapper(
            workers.retrieve,
        )
        self.retrieve_email = to_raw_response_wrapper(
            workers.retrieve_email,
        )

    @cached_property
    def schedules(self) -> SchedulesResourceWithRawResponse:
        """Manage future and recurring worker tasks."""
        return SchedulesResourceWithRawResponse(self._workers.schedules)


class AsyncWorkersResourceWithRawResponse:
    def __init__(self, workers: AsyncWorkersResource) -> None:
        self._workers = workers

        self.create = async_to_raw_response_wrapper(
            workers.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            workers.retrieve,
        )
        self.retrieve_email = async_to_raw_response_wrapper(
            workers.retrieve_email,
        )

    @cached_property
    def schedules(self) -> AsyncSchedulesResourceWithRawResponse:
        """Manage future and recurring worker tasks."""
        return AsyncSchedulesResourceWithRawResponse(self._workers.schedules)


class WorkersResourceWithStreamingResponse:
    def __init__(self, workers: WorkersResource) -> None:
        self._workers = workers

        self.create = to_streamed_response_wrapper(
            workers.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            workers.retrieve,
        )
        self.retrieve_email = to_streamed_response_wrapper(
            workers.retrieve_email,
        )

    @cached_property
    def schedules(self) -> SchedulesResourceWithStreamingResponse:
        """Manage future and recurring worker tasks."""
        return SchedulesResourceWithStreamingResponse(self._workers.schedules)


class AsyncWorkersResourceWithStreamingResponse:
    def __init__(self, workers: AsyncWorkersResource) -> None:
        self._workers = workers

        self.create = async_to_streamed_response_wrapper(
            workers.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            workers.retrieve,
        )
        self.retrieve_email = async_to_streamed_response_wrapper(
            workers.retrieve_email,
        )

    @cached_property
    def schedules(self) -> AsyncSchedulesResourceWithStreamingResponse:
        """Manage future and recurring worker tasks."""
        return AsyncSchedulesResourceWithStreamingResponse(self._workers.schedules)
