"""CoGames packaged game modules."""
