# oeis-tools

[![CI](https://github.com/oeistools/oeis-tools/actions/workflows/tests.yml/badge.svg?branch=main)](https://github.com/oeistools/oeis-tools/actions/workflows/tests.yml?query=branch%3Amain)
[![codecov](https://codecov.io/gh/oeistools/oeis-tools/graph/badge.svg?token=VS85S5ZKYO)](https://codecov.io/gh/oeistools/oeis-tools)
[![PyPI version](https://img.shields.io/pypi/v/oeis-tools.svg?cacheSeconds=60)](https://pypi.org/project/oeis-tools/)
[![Python versions](https://img.shields.io/pypi/pyversions/oeis-tools.svg)](https://pypi.org/project/oeis-tools/)
[![Wheel](https://img.shields.io/pypi/wheel/oeis-tools.svg)](https://pypi.org/project/oeis-tools/)
[![Package format](https://img.shields.io/pypi/format/oeis-tools.svg)](https://pypi.org/project/oeis-tools/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

A focused Python toolkit for working with OEIS integer sequences: fetch metadata, parse b-files, and plot sequence values quickly.

## Features

- Validate OEIS IDs like `A000045`
- Build canonical OEIS URLs and b-file names
- Fetch sequence JSON metadata via `Sequence`
- Fetch and parse b-file numeric data via `BFile`
- Plot b-file values with line or scatter styles

## Requirements

- Python 3.9+
- Optional: `matplotlib` for plotting

## Installation

```bash
pip install oeis-tools
```

For local development:

```bash
git clone https://github.com/oeistools/oeis-tools.git
cd oeis-tools
pip install -e ".[dev]"
```

## Quick Start

### Utility Functions

```python
import oeis_tools as ot

print(ot.check_id("A000045"))                # True
print(ot.oeis_bfile("A000045"))              # b000045.txt
print(ot.oeis_url("A000045"))                # https://oeis.org/A000045
print(ot.oeis_url("A000045", fmt="json"))    # https://oeis.org/search?q=id:A000045&fmt=json
```

### Sequence API

```python
from oeis_tools import Sequence

seq = Sequence("A000045")

print(seq.id)         # A000045
print(seq.name)       # Fibonacci numbers
print(seq.data)       # [0, 1, 1, 2, 3, 5, ...]
print(seq.author)     # list[str]
print(seq.keyword)    # list[str]
print(seq.offset)     # list[int]
print(seq.link)       # parsed links as markdown-style text

info = seq.get_bfile_info()
print(info["available"], info["length"])
```

### B-file API

```python
from oeis_tools import BFile

bfile = BFile("A000045")

print(bfile.get_filename())   # b000045.txt
print(bfile.get_url())        # https://oeis.org/A000045/b000045.txt
print(bfile.get_bfile_data()) # list[int] or None
bfile.plot_data(50, show=False)                                # first 50 points
bfile.plot_data(50, show=False, plot_style="scatter")          # scatter plot
bfile.plot_data(50, show=False, plot_style="joined")           # joined/line plot
ax = bfile.plot_data(show=False, return_ax=True)               # matplotlib Axes
```

## Plotting Examples

Overlay two sequences on one plot:

```python
import matplotlib.pyplot as plt
import oeis_tools

N_POINTS = 200

bfile = oeis_tools.BFile("A114906")
bfile2 = oeis_tools.BFile("A114904")
fig, ax = plt.subplots()
bfile.plot_data(n=N_POINTS, ax=ax, show=False, color="red")
bfile2.plot_data(n=N_POINTS, ax=ax, show=True, color="blue")
plt.show()
```

Scatter versus joined:

```python
import matplotlib.pyplot as plt
from oeis_tools import BFile

bfile = BFile("A000045")
fig, ax = plt.subplots()
bfile.plot_data(80, ax=ax, show=False, plot_style="scatter", color="black")
bfile.plot_data(80, ax=ax, show=False, plot_style="joined", color="orange")
plt.show()
```

## API Summary

- `check_id(oeis_id: str) -> bool`
- `oeis_bfile(oeis_id: str) -> str`
- `oeis_url(oeis_id: str, fmt: str | None = None) -> str`
- `Sequence(oeis_id: str)`
- `Sequence.get_bfile_info() -> dict`
- `BFile(oeis_id: str)`
- `BFile.get_filename() -> str`
- `BFile.get_url() -> str`
- `BFile.get_bfile_data() -> list[int] | None`
- `BFile.plot_data(n: int | None = None, show: bool = True, ax=None, return_ax: bool = False, plot_style: str = "line", **plot_kwargs)`

## Error Behavior

- `Sequence(...)` raises `ValueError` for invalid IDs.
- `Sequence(...)` propagates HTTP errors from the OEIS JSON endpoint.
- `BFile.get_bfile_data()` returns `None` when a b-file cannot be fetched or parsed.

## Development

Run tests:

```bash
pytest -q
```

Run lint checks:

```bash
ruff format .
ruff check . --fix
```

Build distributions:

```bash
python -m build
python -m twine check dist/*
```

Contribution guide: see `CONTRIBUTING.md`.

## Publishing

This repository includes a GitHub Actions publish workflow at `.github/workflows/publish.yml`.

- Automatic publish trigger: GitHub Release `published`
- Manual publish trigger: `workflow_dispatch`
- Upload target: PyPI via trusted publishing (`id-token`)

## License

MIT. See `LICENSE`.
