"""Top-level sampling dispatchers — auto-route by device.

Public entry points that callers (kestrel-src and external library
users) import without knowing which backend will run. Each function
routes to the fastest implementation available for the input
device:

  ``top_p_sampling_from_probs(probs, top_p, *, generator)``
    CUDA: cubin sampler (rejection sampling, fast).
    MPS / CPU / other: torch reference path.

  ``sample_step_from_logits(logits, temps, top_p, *, out, generator)``
    CUDA: clamp + softmax + cubin top_p sampler (the canonical chain
    that used to live in ``kestrel/scheduler/sampling.py``; this is
    the existing CUDA fast path, not a slow fallback).
    MPS:  fused Metal kernel (one dispatch — temp scale + online
    softmax + top-K + top-p truncate + exp-race sample).
    CPU / other: torch reference path.

The MPS fused kernel has caller-side preconditions (``top_p ≤ 0.95``,
``1e-6 < temp ≤ 1.0``, peaked distribution); see
``kestrel_kernels.mps.sampling`` docstring. Production callers in
kestrel-src validate at request admission so the preconditions
always hold; external callers passing settings outside that envelope
on MPS get biased outputs and should fall back to
``top_p_sampling_from_probs`` after manual softmax.
"""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import (
    is_cute_jit_enabled,
    warn_and_run_fallback,
    warn_fallback_once,
)
from kestrel_kernels.sampling.fallback import top_p_sampling_torch

_family = CubinFamily("sampling")
_logprobs_family = CubinFamily("sampling_logprobs")
_softmax_greedy_family = CubinFamily("softmax_greedy")

_KERNEL_KEY = "top_p_sampling_cute"
_SOFTMAX_GREEDY_KEY = "softmax_with_greedy_override_cute"
_MAX_REJECTION_ROUNDS = 16
_SUPPORTED_VOCAB_SIZES = {1024, 51200}
_SOFTMAX_GREEDY_LOGITS_DTYPES = {torch.float32, torch.bfloat16}
_SAMPLING_THREADS = {1024: 128, 51200: 768}
_SOFTMAX_GREEDY_THREADS = {1024: 128, 51200: 256}
_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles

_SAMPLING_EPS = 1e-6


def _softmax_greedy_variant_key(vocab_size: int, dtype: torch.dtype) -> str:
    if dtype == torch.bfloat16:
        return f"vocab_{vocab_size}_bf16"
    return f"vocab_{vocab_size}"


def _ensure_sampling_variant(
    family: CubinFamily,
    variant_key: str,
    x: torch.Tensor,
    *,
    vocab_size: int,
    logprobs: bool,
) -> bool:
    if family.is_available(variant_key):
        return True
    device_index = int(x.device.index or 0)
    if (variant_key, device_index) in family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    compile_factory = (
        _cubin_bundles._compile_sampling_logprobs
        if logprobs
        else _cubin_bundles._compile_sampling
    )
    _cubin_bundles.jit_compile_and_install(
        family=family,
        variant_key=variant_key,
        compile_fn=compile_factory(
            vocab_size=vocab_size,
            num_threads=_SAMPLING_THREADS[vocab_size],
            max_rounds=_MAX_REJECTION_ROUNDS,
        ),
        block_x=_SAMPLING_THREADS[vocab_size],
        device_index=device_index,
    )
    return True


def _ensure_softmax_greedy_variant(
    variant_key: str,
    logits: torch.Tensor,
    *,
    vocab_size: int,
) -> bool:
    if _softmax_greedy_family.is_available(variant_key):
        return True
    device_index = int(logits.device.index or 0)
    if (variant_key, device_index) in _softmax_greedy_family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    logits_dtype = "bfloat16" if logits.dtype == torch.bfloat16 else "float32"
    _cubin_bundles.jit_compile_and_install(
        family=_softmax_greedy_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_softmax_greedy(
            vocab_size=vocab_size,
            num_threads=_SOFTMAX_GREEDY_THREADS[vocab_size],
            logits_dtype=logits_dtype,
        ),
        block_x=_SOFTMAX_GREEDY_THREADS[vocab_size],
        device_index=device_index,
    )
    return True


def top_p_sampling_from_probs(
    probs: torch.Tensor,
    top_p: torch.Tensor,
    *,
    generator: torch.Generator | None = None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Sample token IDs from probabilities and per-row top-p thresholds."""
    if probs.ndim != 2:
        raise ValueError(f"probs must be 2D [batch, vocab], got shape {tuple(probs.shape)}")
    if probs.shape[0] == 0:
        return probs.new_empty((0,), dtype=torch.long)
    if probs.dtype not in (torch.float16, torch.bfloat16, torch.float32):
        raise ValueError(f"unsupported probs dtype {probs.dtype}; expected fp16/bf16/fp32")
    if top_p.ndim == 2 and top_p.shape[1] == 1:
        top_p = top_p.view(-1)
    if top_p.ndim != 1:
        raise ValueError(f"top_p must be 1D [batch], got shape {tuple(top_p.shape)}")
    if top_p.shape[0] != probs.shape[0]:
        raise ValueError(
            f"top_p batch dimension ({top_p.shape[0]}) must match probs ({probs.shape[0]})"
        )
    if logprobs_out is not None:
        _validate_logprobs_out(logprobs_out, batch=probs.shape[0], device=probs.device)

    vocab_size = int(probs.shape[1])
    family = _logprobs_family if logprobs_out is not None else _family
    variant_key = f"vocab_{vocab_size}"

    if (
        probs.device.type == "cuda"
        and vocab_size in _SUPPORTED_VOCAB_SIZES
        and _ensure_sampling_variant(
            family,
            variant_key,
            probs,
            vocab_size=vocab_size,
            logprobs=logprobs_out is not None,
        )
    ):
        try:
            return _run_cubin_kernel(
                probs=probs,
                top_p=top_p,
                generator=generator,
                logprobs_out=logprobs_out,
            )
        except Exception as e:
            warn_fallback_once(
                f"{_KERNEL_KEY}_runtime_error",
                "kestrel-kernels: CuTe top-p kernel failed at runtime; "
                f"falling back to PyTorch. error={type(e).__name__}: {e}",
            )

    return warn_and_run_fallback(
        kernel_key=_KERNEL_KEY,
        message="kestrel-kernels: using PyTorch fallback for top_p_sampling_from_probs.",
        fallback=top_p_sampling_torch,
        kwargs={
            "probs": probs,
            "top_p": top_p,
            "generator": generator,
            "logprobs_out": logprobs_out,
        },
    )


def sample_step_from_logits(
    logits: torch.Tensor,
    temperatures: torch.Tensor,
    top_p: torch.Tensor,
    *,
    out: torch.Tensor | None = None,
    generator: torch.Generator | None = None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Sample token IDs from raw logits — auto-dispatch by device.

    Behaviour:
      - clamp ``temperatures ≥ 0`` and ``top_p ∈ [eps, 1.0]``
      - rows with ``temp ≤ eps`` OR non-finite probs are forced to
        argmax (greedy override)
      - otherwise sample from the temperature-scaled softmax
        truncated at ``top_p``

    On MPS this is one fused Metal dispatch (~5× the torch chain).
    On CUDA this is the existing chain that wraps the cubin sampler.
    """
    if logits.ndim != 2:
        raise ValueError(f"logits must be 2D [batch, vocab], got shape {tuple(logits.shape)}")
    batch = logits.shape[0]
    if temperatures.shape[0] != batch or top_p.shape[0] != batch:
        raise ValueError("Sampling parameters must match logits batch dimension")
    if logprobs_out is not None:
        _validate_logprobs_out(logprobs_out, batch=batch, device=logits.device)

    if logits.device.type == "mps":
        # Lazy import — non-Mac wheels don't ship this module.
        from kestrel_kernels.mps.sampling import sample_step_from_logits_mps

        return sample_step_from_logits_mps(
            logits,
            temperatures,
            top_p,
            out=out,
            generator=generator,
            logprobs_out=logprobs_out,
        )

    # CUDA fast path: fused softmax + greedy override → existing
    # rejection top-p cubin. Replaces the 12-op torch chain with two
    # cubin launches; preserves arbitrary top_p / temperature support
    # and honours ``generator`` (passed through to the cubin sampler).
    # BF16 logits are upcast inside the cubin and accumulated as FP32.
    vocab_size = int(logits.shape[1])
    softmax_greedy_variant_key = _softmax_greedy_variant_key(vocab_size, logits.dtype)
    if (
        logits.device.type == "cuda"
        and logits.dtype in _SOFTMAX_GREEDY_LOGITS_DTYPES
        and temperatures.dtype == torch.float32
        and top_p.dtype == torch.float32
        and vocab_size in _SUPPORTED_VOCAB_SIZES
        and _ensure_softmax_greedy_variant(
            softmax_greedy_variant_key,
            logits,
            vocab_size=vocab_size,
        )
    ):
        # Layout precondition checked here (not inside the cubin
        # helper) so the resulting ValueError propagates instead of
        # being swallowed by the catch-and-warn fallback below.
        # The cubin accepts dynamic row stride, but its innermost
        # dimension is compiled with stride 1. Silently copying would
        # mask a perf surprise (the copy is comparable to the kernel
        # itself).
        if logits.stride(-1) != 1:
            raise ValueError(
                "sample_step_from_logits CUDA path requires logits with "
                "innermost stride 1. Got a strided view; materialise with "
                "``logits.contiguous()`` at the call site if intentional."
            )
        if not temperatures.is_contiguous():
            raise ValueError(
                "sample_step_from_logits CUDA path requires contiguous "
                "temperatures."
            )
        try:
            probs = _run_softmax_greedy_cubin(logits, temperatures)
            topp_clamped = torch.clamp(top_p, min=_SAMPLING_EPS, max=1.0)
            sampled = top_p_sampling_from_probs(
                probs,
                topp_clamped,
                generator=generator,
                logprobs_out=logprobs_out,
            )
            if out is not None:
                out.copy_(sampled)
                return out
            return sampled
        except Exception as e:  # pragma: no cover - defensive
            warn_fallback_once(
                f"{_SOFTMAX_GREEDY_KEY}_runtime_error",
                "kestrel-kernels: softmax_greedy cubin failed at runtime; "
                f"falling back to torch chain. error={type(e).__name__}: {e}",
            )

    return _torch_sample_step(
        logits,
        temperatures,
        top_p,
        out=out,
        generator=generator,
        logprobs_out=logprobs_out,
    )


def _run_softmax_greedy_cubin(
    logits: torch.Tensor, temperatures: torch.Tensor,
) -> torch.Tensor:
    """Invoke the softmax_greedy cubin. Returns a fresh probs tensor.

    Caller (``sample_step_from_logits``) is responsible for the layout
    precondition — the cubin is compiled with innermost stride 1.
    """
    rows, vocab_size = int(logits.shape[0]), int(logits.shape[1])
    probs = torch.empty(
        (rows, vocab_size), dtype=torch.float32, device=logits.device,
    )
    dispatch = _softmax_greedy_family.resolve_dispatch(
        logits,
        variant_key=_softmax_greedy_variant_key(vocab_size, logits.dtype),
        grid_x=rows,
    )
    dispatch(probs, logits, temperatures)
    return probs


def _torch_sample_step(
    logits: torch.Tensor,
    temperatures: torch.Tensor,
    top_p: torch.Tensor,
    *,
    out: torch.Tensor | None = None,
    generator: torch.Generator | None = None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Reference logits → token id chain.

    On CUDA this is the canonical fast path (clamp + softmax +
    cubin top_p sampler under ``top_p_sampling_from_probs``). On
    CPU / other devices it's the torch reference.
    """
    temps = torch.clamp(temperatures, min=0.0)
    topp = torch.clamp(top_p, min=_SAMPLING_EPS, max=1.0)

    greedy_ids = logits.argmax(dim=-1)
    eff_temp = torch.where(
        temps > _SAMPLING_EPS, temps, torch.ones_like(temps)
    ).unsqueeze(-1)
    scaled = logits / eff_temp
    probs = torch.softmax(scaled, dim=-1, dtype=torch.float32)

    row_invalid = ~torch.isfinite(probs).all(dim=-1)
    force_greedy = (temps <= _SAMPLING_EPS) | row_invalid
    probs.nan_to_num_(0.0, posinf=0.0, neginf=0.0)
    probs.masked_fill_(force_greedy.unsqueeze(1), 0.0)
    probs.scatter_add_(
        1, greedy_ids.unsqueeze(1),
        force_greedy.to(probs.dtype).unsqueeze(1),
    )

    sampled = top_p_sampling_from_probs(
        probs,
        topp,
        generator=generator,
        logprobs_out=logprobs_out,
    )
    if out is not None:
        out.copy_(sampled)
        return out
    return sampled


def _run_cubin_kernel(
    *,
    probs: torch.Tensor,
    top_p: torch.Tensor,
    generator: torch.Generator | None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    probs_f = probs.to(dtype=torch.float32).contiguous()
    top_p_f = torch.clamp(
        top_p.to(device=probs.device, dtype=torch.float32),
        min=1e-6,
        max=1.0,
    ).contiguous()
    rows = int(probs_f.shape[0])
    uniforms = torch.rand(
        (rows, _MAX_REJECTION_ROUNDS),
        device=probs.device,
        dtype=torch.float32,
        generator=generator,
    )
    sampled = torch.empty((rows,), device=probs.device, dtype=torch.long)
    vocab_size = int(probs_f.shape[1])
    family = _logprobs_family if logprobs_out is not None else _family
    dispatch = family.resolve_dispatch(
        probs_f, variant_key=f"vocab_{vocab_size}", grid_x=rows,
    )
    if logprobs_out is not None:
        dispatch(sampled, probs_f, top_p_f, uniforms, logprobs_out)
    else:
        dispatch(sampled, probs_f, top_p_f, uniforms)
    return sampled


def _validate_logprobs_out(
    logprobs_out: torch.Tensor,
    *,
    batch: int,
    device: torch.device,
) -> None:
    if logprobs_out.ndim != 1 or logprobs_out.shape[0] != batch:
        raise ValueError(
            f"logprobs_out must be 1D [batch={batch}], got shape "
            f"{tuple(logprobs_out.shape)}"
        )
    if logprobs_out.dtype != torch.float32:
        raise ValueError(f"logprobs_out must be float32; got {logprobs_out.dtype}")
    if logprobs_out.device != device:
        raise ValueError("logprobs_out must live on the same device as inputs")
    if not logprobs_out.is_contiguous():
        raise ValueError("logprobs_out must be contiguous")


__all__ = [
    "sample_step_from_logits",
    "top_p_sampling_from_probs",
]
