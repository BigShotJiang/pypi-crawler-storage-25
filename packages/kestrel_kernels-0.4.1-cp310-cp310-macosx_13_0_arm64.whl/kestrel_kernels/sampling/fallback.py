"""PyTorch fallback for top-p sampling.

The implementation follows a GPU-friendly native sampler shape:
1) sort probabilities descending,
2) truncate rows to nucleus mass `top_p`,
3) sample with the exponential-race trick (`argmax(probs / Exp(1))`).
"""


import torch


_EPS = 1e-6


def top_p_sampling_torch(
    *,
    probs: torch.Tensor,
    top_p: torch.Tensor,
    generator: torch.Generator | None = None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Sample token IDs from per-row probability distributions and top-p thresholds."""
    if probs.ndim != 2:
        raise ValueError(f"probs must be 2D [batch, vocab], got shape {tuple(probs.shape)}")

    if top_p.ndim == 2 and top_p.shape[1] == 1:
        top_p = top_p.view(-1)
    if top_p.ndim != 1:
        raise ValueError(f"top_p must be 1D [batch], got shape {tuple(top_p.shape)}")
    if top_p.shape[0] != probs.shape[0]:
        raise ValueError(
            f"top_p batch dimension ({top_p.shape[0]}) must match probs ({probs.shape[0]})"
        )

    # Fast path for inference: caller already provides sanitized probabilities.
    probs_f = probs.to(dtype=torch.float32)

    top_p_f = torch.clamp(
        top_p.to(device=probs.device, dtype=torch.float32),
        min=_EPS,
        max=1.0,
    )

    sorted_probs, sorted_idx = torch.sort(probs_f, dim=-1, descending=True)
    cdf = torch.cumsum(sorted_probs, dim=-1)
    # Remove tokens strictly after the first point where cumulative mass exceeds top_p.
    truncate_mask = cdf > top_p_f.unsqueeze(1)
    truncate_mask[..., 1:] = truncate_mask[..., :-1].clone()
    truncate_mask[..., 0] = False
    sorted_probs.masked_fill_(truncate_mask, 0.0)

    # Categorical sampling via exponential-race (equivalent to multinomial):
    # draw q ~ Exp(1), then pick argmax_i p_i / q_i.
    q = torch.empty_like(sorted_probs)
    q.exponential_(generator=generator)
    sampled_sorted = sorted_probs.div_(q).argmax(dim=-1)
    # Avoid ``torch.gather`` — the MPS backend aborts with
    # "total bytes of NDArray > 2**32" on some index shapes. Fancy
    # indexing along the batch dim is equivalent here (batch rows,
    # one pick each) and works on every backend.
    batch_idx = torch.arange(sorted_idx.shape[0], device=sorted_idx.device)
    sampled = sorted_idx[batch_idx, sampled_sorted]
    sampled = sampled.to(dtype=torch.long)
    if logprobs_out is not None:
        logprobs_out.copy_(torch.log(probs_f[batch_idx, sampled]))
    return sampled


__all__ = ["top_p_sampling_torch"]
