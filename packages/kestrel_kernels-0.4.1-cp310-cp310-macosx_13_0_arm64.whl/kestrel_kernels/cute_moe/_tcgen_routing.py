"""Host-side dispatch prep for the SM100 tcgen MoE path.

Lives in its own module so the runtime (AOT) dispatch path can import
it without dragging cutlass / cute-dsl into the import graph. The JIT
side (`cute_moe_fp8_sm100_tcgen.py`) re-imports the same symbol so it
stays in lock-step with the kernel's `__call__` argument order.
"""

import torch


def prepare_tcgen_dispatch_tensors(
    kind: str,
    A_fp8_bits,                  # (num_tokens, K) for up; (num_tokens*top_k, K) for down — uint8
    A_scale,                     # fp32, per-token (up) or per-assignment (down)
    B_fp8_bits,                  # (E, N, K) uint8
    B_scale,                     # (E, N) fp32
    C2d,                         # (num_assignments, N) bf16 — flat output view
    *,
    sorted_token_ids,            # (num_assignments,) int32 — compact route output
    topk_weights,                # (num_assignments,) bf16 OR None
    mul_routed_weight: bool,
    top_k: int,
    num_experts: int,
    cu_seqlens_m,                # (E+1,) int32 — compact-route exact offsets
    A_routed_bits,               # compact-route workspace, uint8 [num_assignments, K]
    row_scale,                   # compact-route workspace, fp32 [num_assignments]
) -> list:
    """Build the flat tensor list `_FusedMoeMatmulCuTeTcgenFp8.__call__` wants.

    All host-side prep that doesn't fit in a `@cute.jit` kernel:
    - A_routed / mRowScale from the compact materialize kernel
    - B permuted (E, N, K) → (N, K, E) for the GEMM's expected layout

    Returned order matches the @cute.jit `__call__` signature exactly.
    """
    if cu_seqlens_m is None or A_routed_bits is None or row_scale is None:
        raise ValueError("tcgen MoE requires compact route and materialize workspaces")

    from kestrel_kernels.moe.routing import moe_route_materialize_fp8

    moe_route_materialize_fp8(
        kind=kind,
        A_fp8_bits=A_fp8_bits,
        A_scale=A_scale,
        topk_weights=topk_weights if mul_routed_weight else row_scale,
        sorted_token_ids=sorted_token_ids,
        cu_seqlens_m=cu_seqlens_m,
        A_routed_bits=A_routed_bits,
        row_scale=row_scale,
        top_k=top_k,
        num_experts=num_experts,
    )
    A_routed = A_routed_bits[: sorted_token_ids.shape[0]].view(torch.float8_e4m3fn)
    mAidPerRow = sorted_token_ids
    mRowScale = row_scale[: sorted_token_ids.shape[0]]

    # B permute (E, N, K) → (N, K, E) — view-only, no data movement.
    B_view = B_fp8_bits.view(torch.float8_e4m3fn)
    B_perm = B_view.permute(1, 2, 0)

    # Order matches `_FusedMoeMatmulCuTeTcgenFp8.__call__`:
    #   (A_routed, B_perm, mC, mAidPerRow, mRowScale, mBScale, cu_seqlens_m,
    #    stream, use_pdl) — `_invoke_aot` injects stream + scalar args itself.
    return [A_routed, B_perm, C2d, mAidPerRow, mRowScale, B_scale, cu_seqlens_m]
