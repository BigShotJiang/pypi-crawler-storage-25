"""CuTe MoE kernel dispatch via AOT-emitted host wrappers.

Public routed-GEMM entries are up/down × bf16/fp8. `invoke_cute_moe`
is the full-layer entry for non-routed MoE kernels. Each variant ships
as a self-contained `.so` that bundles the cute-compiled launch logic —
grid derivation, smem optin, cluster dims, warpgroup register
reallocation, PDL stream serialization. Dispatch resolves the `.so`,
builds memref structs from torch tensors in the wrapper's argument
order, and invokes the exported `ciface` entry.

When `KESTREL_CUTE_JIT=1` is set, missing variants are compiled on
demand (source install only).
"""

# PEP 563: keep annotations as strings so type-only references (e.g.
# `torch.Tensor` in the signatures below) don't get evaluated at import
# time. Lets tests that fake `sys.modules['torch']` with a stub module
# (see tests/test_cubin_bundles_launch_config.py) transitively import
# this file without tripping AttributeError on torch.Tensor.
from __future__ import annotations

import ctypes

import torch

from kestrel_kernels.arch import get_cuda_arch, sm_arch_at_least
from kestrel_kernels.cute_aot_runtime import AotFamily
from kestrel_kernels.cute_moe.config import (
    CuteMoeConfig,
    MoeVariant,
    WarpGemvVariant,
    get_cute_moe_routed_config,
)
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled


_CUTE_TOP_K_UP_DECODE = 8


def _jit_compile_fn_factory(variant: MoeVariant):
    """Produce a cute `compile_fn(arch)` for a single MoE variant."""
    from scripts.precompile import cubin_bundles as _cubin_bundles
    return _cubin_bundles._compile_cute_moe(variant)


def _warpgemv_jit_compile_fn_factory(variant):
    def compile_fn(arch: str):
        from kestrel_kernels.cute_moe.warp_gemv_kernel import (
            make_compile_args,
        )

        return make_compile_args(variant, arch)

    return compile_fn


_family = AotFamily(
    "cute_moe",
    jit_compile_fn=_jit_compile_fn_factory if is_cute_jit_enabled() else None,
)
_warpgemv_family = AotFamily(
    "cute_moe_warpgemv",
    jit_compile_fn=(
        _warpgemv_jit_compile_fn_factory if is_cute_jit_enabled() else None
    ),
)


def _variant_for_config(
    kind: str, config: CuteMoeConfig, N: int, K: int, use_pdl: bool,
) -> MoeVariant:
    return MoeVariant(
        kind=kind,
        block_m=config.block_m, block_n=config.block_n, block_k=config.block_k,
        num_warps=config.num_warps, num_stages=config.num_stages,
        N=N, K=K, dtype=config.dtype,
        kernel_type=config.kernel_type, use_pdl=use_pdl,
        cluster_M=config.cluster_M,
    )


def _shrink_routing_for_em_launch(
    config: CuteMoeConfig, top_k: int, num_valid_tokens: int,
    sorted_token_ids: torch.Tensor, expert_ids: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Avoid launching M-blocks that would exit due to routing padding.

    Matches the Triton MoE reference: cap the M-block grid at
    num_valid_tokens * block_m, which is an upper bound on post-padded M.
    """
    em_full = int(sorted_token_ids.numel())
    em_launch = min(em_full, num_valid_tokens * int(config.block_m))
    if em_launch < em_full:
        sorted_token_ids = sorted_token_ids[:em_launch]
        m_blocks = ceil_div(em_launch, int(config.block_m))
        expert_ids = expert_ids[:m_blocks]
    return sorted_token_ids, expert_ids


def _require_routed_config(config: CuteMoeConfig) -> None:
    if config.kernel_type == "warpgemv":
        raise ValueError("warpgemv is a full-layer MoE kernel; use invoke_cute_moe")
    if config.kernel_type == "tcgen":
        raise ValueError("tcgen MoE uses invoke_cute_moe_*_fp8_tcgen")


def _require_tcgen_config(config: CuteMoeConfig) -> None:
    if config.kernel_type != "tcgen":
        raise ValueError("tcgen invoke requires kernel_type='tcgen'")


def _invoke_aot(
    family: AotFamily,
    variant,
    tensors: list[torch.Tensor],
    first_tensor: torch.Tensor | None = None,
) -> None:
    arch = get_cuda_arch()
    bundle = family.resolve(variant, arch)
    if bundle is None:
        raise RuntimeError(
            f"No {family.family_name} AOT variant for {variant.variant_key} on arch={arch}. "
            f"Ship a tuned config for this GPU or set KESTREL_CUTE_JIT=1 to "
            f"compile on demand."
        )

    if first_tensor is None:
        first_tensor = tensors[0]
    device_index = int(first_tensor.device.index or 0)
    bundle.aot._ensure_device(device_index)

    if len(bundle.memref_specs) != len(tensors):
        raise RuntimeError(
            f"{family.family_name}/{variant.variant_key}: memref count mismatch "
            f"(wrapper expects {len(bundle.memref_specs)}, got {len(tensors)})"
        )

    structs = [spec.build(t) for t, spec in zip(tensors, bundle.memref_specs)]
    struct_ptrs = [ctypes.pointer(s) for s in structs]
    stream = ctypes.c_void_p(
        torch.cuda.current_stream(first_tensor.device).cuda_stream
    )
    bundle.aot.call(bundle.arg_kinds, struct_ptrs, [], ctypes.pointer(stream))


def _invoke_cute_moe_warpgemv_fp8(
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    topk_weights: torch.Tensor,
    up_weight: torch.Tensor,
    up_scale: torch.Tensor,
    down_weight: torch.Tensor,
    down_scale: torch.Tensor,
    *,
    out: torch.Tensor | None,
    activation_scratch: torch.Tensor | None,
    warps_per_block: int,
) -> torch.Tensor:
    if x.device.type != "cuda":
        raise ValueError("warp-gemv MoE requires CUDA tensors")
    if x.dtype != torch.bfloat16 or x.ndim != 2:
        raise ValueError("x must be a BF16 CUDA tensor with shape [tokens, hidden]")
    if topk_ids.dtype != torch.int32 or topk_ids.ndim != 2:
        raise ValueError("topk_ids must be int32 with shape [tokens, top_k]")
    if topk_weights.shape != topk_ids.shape:
        raise ValueError("topk_weights must have the same shape as topk_ids")
    if topk_weights.dtype not in (torch.bfloat16, torch.float32):
        raise ValueError("warp-gemv MoE expects BF16 or FP32 topk_weights")
    if up_weight.dtype != torch.uint8 or down_weight.dtype != torch.uint8:
        raise ValueError("warp-gemv MoE expects FP8 expert weights as uint8")
    if up_scale.dtype != torch.float32 or down_scale.dtype != torch.float32:
        raise ValueError("warp-gemv MoE expects fp32 expert scales")
    if not (
        x.is_contiguous()
        and topk_ids.is_contiguous()
        and topk_weights.is_contiguous()
        and up_weight.is_contiguous()
        and up_scale.is_contiguous()
        and down_weight.is_contiguous()
        and down_scale.is_contiguous()
    ):
        raise ValueError("warp-gemv MoE inputs must be contiguous")

    tokens, hidden = map(int, x.shape)
    if int(topk_ids.shape[0]) != tokens:
        raise ValueError("topk_ids token dimension must match x")
    top_k = int(topk_ids.shape[1])
    if top_k != 8:
        raise ValueError("warp-gemv MoE currently supports top_k=8")
    num_experts, up_n, up_k = map(int, up_weight.shape)
    if up_k != hidden or up_n % 2 != 0:
        raise ValueError("up_weight must have shape [experts, 2 * intermediate, hidden]")
    intermediate = up_n // 2
    if hidden % 16 != 0 or intermediate % 16 != 0:
        raise ValueError("warp-gemv MoE requires hidden/intermediate multiples of 16")
    if tuple(up_scale.shape) != (num_experts, up_n):
        raise ValueError("up_scale must have shape [experts, 2 * intermediate]")
    if tuple(down_weight.shape) != (num_experts, hidden, intermediate):
        raise ValueError("down_weight must have shape [experts, hidden, intermediate]")
    if tuple(down_scale.shape) != (num_experts, hidden):
        raise ValueError("down_scale must have shape [experts, hidden]")

    if out is None:
        out = torch.empty((tokens, hidden), device=x.device, dtype=x.dtype)
    elif (
        tuple(out.shape) != (tokens, hidden)
        or out.device != x.device
        or out.dtype != x.dtype
        or not out.is_contiguous()
    ):
        raise ValueError("out must be contiguous BF16 with shape [tokens, hidden]")

    if activation_scratch is None:
        activation = torch.empty(
            (tokens * top_k, intermediate), device=x.device, dtype=x.dtype
        )
    else:
        activation = activation_scratch
        if (
            tuple(activation.shape) != (tokens * top_k, intermediate)
            or activation.device != x.device
            or activation.dtype != x.dtype
            or not activation.is_contiguous()
        ):
            raise ValueError(
                "activation_scratch must be contiguous BF16 with shape "
                "[tokens * top_k, intermediate]"
            )

    warps_per_block = int(warps_per_block)
    if warps_per_block <= 0:
        raise ValueError("warps_per_block must be positive")

    gate_variant = WarpGemvVariant(
        kind="gate",
        hidden_size=hidden,
        intermediate_size=intermediate,
        top_k=top_k,
        warps_per_block=warps_per_block,
    )
    down_variant = WarpGemvVariant(
        kind="down",
        hidden_size=hidden,
        intermediate_size=intermediate,
        top_k=top_k,
        warps_per_block=warps_per_block,
        topk_weight_dtype=(
            "fp32" if topk_weights.dtype == torch.float32 else "bf16"
        ),
    )
    _invoke_aot(
        _warpgemv_family,
        gate_variant,
        [
            x,
            topk_ids,
            up_weight,
            up_scale,
            activation,
        ],
    )
    _invoke_aot(
        _warpgemv_family,
        down_variant,
        [
            activation,
            topk_ids,
            topk_weights,
            down_weight,
            down_scale,
            out,
        ],
    )
    return out


def _invoke_cute_moe_warpgemv_up_fp8(
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    up_weight: torch.Tensor,
    up_scale: torch.Tensor,
    out: torch.Tensor,
    *,
    warps_per_block: int,
) -> None:
    hidden = int(x.shape[1])
    top_k = int(topk_ids.shape[1])
    intermediate = int(up_weight.shape[1]) // 2

    _invoke_aot(
        _warpgemv_family,
        WarpGemvVariant(
            kind="up",
            hidden_size=hidden,
            intermediate_size=intermediate,
            top_k=top_k,
            warps_per_block=int(warps_per_block),
        ),
        [x, topk_ids, up_weight, up_scale, out],
    )


def _invoke_cute_moe_warpgemv_down_slots_fp8(
    activation: torch.Tensor,
    topk_ids: torch.Tensor,
    topk_weights: torch.Tensor,
    down_weight: torch.Tensor,
    down_scale: torch.Tensor,
    out: torch.Tensor,
    *,
    warps_per_block: int,
) -> None:
    top_k = int(topk_ids.shape[1])
    hidden = int(down_weight.shape[1])
    intermediate = int(activation.shape[1])

    _invoke_aot(
        _warpgemv_family,
        WarpGemvVariant(
            kind="down_slots",
            hidden_size=hidden,
            intermediate_size=intermediate,
            top_k=top_k,
            warps_per_block=int(warps_per_block),
            topk_weight_dtype=(
                "fp32" if topk_weights.dtype == torch.float32 else "bf16"
            ),
        ),
        [activation, topk_ids, topk_weights, down_weight, down_scale, out],
    )


def invoke_cute_moe(
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    topk_weights: torch.Tensor,
    up_weight: torch.Tensor,
    up_scale: torch.Tensor,
    down_weight: torch.Tensor,
    down_scale: torch.Tensor,
    *,
    config: CuteMoeConfig,
    out: torch.Tensor | None = None,
    activation_scratch: torch.Tensor | None = None,
) -> torch.Tensor:
    """Run a full CuTe MoE layer for non-routed kernel variants."""
    if config.kernel_type == "warpgemv":
        return _invoke_cute_moe_warpgemv_fp8(
            x,
            topk_ids,
            topk_weights,
            up_weight,
            up_scale,
            down_weight,
            down_scale,
            out=out,
            activation_scratch=activation_scratch,
            warps_per_block=config.num_warps,
        )
    raise ValueError(
        f"invoke_cute_moe does not support kernel_type={config.kernel_type!r}"
    )


def _invoke_cute_moe_impl(
    kind: str,
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor | None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    config: CuteMoeConfig,
) -> None:
    _require_routed_config(config)
    if A.dtype != torch.bfloat16:
        raise ValueError(f"CuTe fused MoE supports bfloat16 only (got {A.dtype})")
    if not (A.is_cuda and B.is_cuda and C.is_cuda):
        raise ValueError("A/B/C must be CUDA tensors")
    if A.ndim != 2:
        raise ValueError("A must be 2D")
    if B.ndim != 3:
        raise ValueError("B must be 3D [E, N, K]")
    if C.ndim != 3:
        raise ValueError("C must be 3D [M, top_k, N]")
    if B.stride(-1) != 1 or C.stride(-1) != 1:
        raise ValueError("B and C must be contiguous in their last dimension")
    if B.shape[2] != A.shape[1]:
        raise ValueError("A and B must have the same K dimension")
    if sorted_token_ids.dtype != torch.int32 or expert_ids.dtype != torch.int32:
        raise ValueError("sorted_token_ids and expert_ids must be int32")
    if num_tokens_post_padded.dtype != torch.int32:
        raise ValueError("num_tokens_post_padded must be int32")
    if mul_routed_weight:
        if topk_weights is None:
            raise ValueError("topk_weights is required when mul_routed_weight=True")
    else:
        topk_weights = torch.empty((0,), device=A.device, dtype=A.dtype)

    C2d = C.view(-1, C.shape[-1])
    num_valid_tokens = int(A.shape[0]) * int(top_k)
    sorted_token_ids, expert_ids = _shrink_routing_for_em_launch(
        config, top_k, num_valid_tokens, sorted_token_ids, expert_ids,
    )

    variant = _variant_for_config(
        kind, config, int(B.shape[1]), int(A.shape[1]), use_pdl=False,
    )

    # Memref order matches the kernel class's `__call__` signature:
    # (mA, mB, mC, mTopkWeights, mSortedTokenIds, mExpertIds, mNumTokensPostPadded).
    _invoke_aot(
        _family,
        variant,
        [A, B, C2d, topk_weights,
         sorted_token_ids, expert_ids, num_tokens_post_padded],
        A,
    )


def _validate_fp8_tensors(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    config: CuteMoeConfig,
) -> tuple[torch.Tensor, torch.Tensor]:
    if A_fp8_bits.dtype != torch.uint8:
        raise ValueError(f"Expected FP8 activation bits as uint8 (got {A_fp8_bits.dtype})")
    if B_fp8_bits.dtype != torch.uint8:
        raise ValueError(f"Expected FP8 weight bits as uint8 (got {B_fp8_bits.dtype})")
    if A_scale.dtype not in (torch.float16, torch.float32):
        raise ValueError(f"Expected A_scale float16/float32 (got {A_scale.dtype})")
    if B_scale.dtype not in (torch.float16, torch.float32):
        raise ValueError(f"Expected B_scale float16/float32 (got {B_scale.dtype})")
    if C.dtype != torch.bfloat16:
        raise ValueError(f"CuTe MoE FP8 expects bfloat16 C (got {C.dtype})")
    if not (
        A_fp8_bits.is_cuda and A_scale.is_cuda
        and B_fp8_bits.is_cuda and B_scale.is_cuda and C.is_cuda
    ):
        raise ValueError("FP8 inputs must be CUDA tensors")
    if A_fp8_bits.ndim != 2 or A_scale.ndim != 1:
        raise ValueError("A_fp8_bits must be 2D and A_scale must be 1D")
    if B_fp8_bits.ndim != 3 or B_scale.ndim != 2:
        raise ValueError("B_fp8_bits must be 3D [E, N, K] and B_scale 2D [E, N]")
    if C.ndim != 3:
        raise ValueError("C must be 3D [M, top_k, N]")
    if A_fp8_bits.stride(-1) != 1 or B_fp8_bits.stride(-1) != 1 or C.stride(-1) != 1:
        raise ValueError("A_fp8_bits, B_fp8_bits and C must be contiguous in the last dim")
    if A_scale.shape[0] != A_fp8_bits.shape[0]:
        raise ValueError("A_scale must have length matching A_fp8_bits.shape[0]")
    if B_fp8_bits.shape[2] != A_fp8_bits.shape[1]:
        raise ValueError("A_fp8_bits and B_fp8_bits must have the same K dimension")
    if int(A_fp8_bits.shape[1]) % int(config.block_k) != 0:
        raise ValueError("CuTe FP8 kernel requires K divisible by block_k")
    if B_scale.shape[0] != B_fp8_bits.shape[0] or B_scale.shape[1] != B_fp8_bits.shape[1]:
        raise ValueError("B_scale must have shape [E, N] matching B_fp8_bits")
    if B_scale.stride(-1) != 1:
        raise ValueError("B_scale must be contiguous in its last dimension")
    if A_scale.dtype != torch.float32:
        A_scale = A_scale.to(dtype=torch.float32)
    if B_scale.dtype != torch.float32:
        B_scale = B_scale.to(dtype=torch.float32)
    return A_scale, B_scale


def _invoke_cute_moe_fp8_impl(
    kind: str,
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor | None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    config: CuteMoeConfig,
    use_pdl: bool = False,
) -> None:
    _require_routed_config(config)
    A_scale, B_scale = _validate_fp8_tensors(
        A_fp8_bits, A_scale, B_fp8_bits, B_scale, C, config,
    )
    if sorted_token_ids.dtype != torch.int32 or expert_ids.dtype != torch.int32:
        raise ValueError("sorted_token_ids and expert_ids must be int32")
    if num_tokens_post_padded.dtype != torch.int32:
        raise ValueError("num_tokens_post_padded must be int32")
    if mul_routed_weight:
        if topk_weights is None:
            raise ValueError("topk_weights is required when mul_routed_weight=True")
    else:
        topk_weights = torch.empty((0,), device=C.device, dtype=C.dtype)

    arch = get_cuda_arch()

    if config.kernel_type == "wgmma" and not sm_arch_at_least(arch, 90):
        raise ValueError(f"FP8 WGMMA kernels require SM90+ (got arch={arch})")
    if use_pdl and not sm_arch_at_least(arch, 90):
        raise ValueError(f"FP8 PDL kernels require SM90+ (got arch={arch})")

    C2d = C.view(-1, C.shape[-1])
    num_valid_tokens = int(A_fp8_bits.shape[0]) * int(top_k)
    sorted_token_ids, expert_ids = _shrink_routing_for_em_launch(
        config, top_k, num_valid_tokens, sorted_token_ids, expert_ids,
    )

    variant = _variant_for_config(
        kind, config, int(C2d.shape[1]), int(A_fp8_bits.shape[1]), use_pdl=use_pdl,
    )

    # Memref order matches the fp8 kernel's `__call__` signature:
    # (mAbits, mAScale, mBbits, mBScale, mC, mTopkWeights, mSortedTokenIds,
    # mExpertIds, mNumTokensPostPadded).
    _invoke_aot(
        _family,
        variant,
        [A_fp8_bits, A_scale, B_fp8_bits, B_scale, C2d, topk_weights,
         sorted_token_ids, expert_ids, num_tokens_post_padded],
        A_fp8_bits,
    )


def _invoke_cute_moe_fp8_tcgen_impl(
    kind: str,
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor | None,
    sorted_token_ids: torch.Tensor,
    cu_seqlens_m: torch.Tensor,
    A_routed_bits: torch.Tensor,
    row_scale: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    config: CuteMoeConfig,
) -> None:
    _require_tcgen_config(config)
    A_scale, B_scale = _validate_fp8_tensors(
        A_fp8_bits, A_scale, B_fp8_bits, B_scale, C, config,
    )
    if sorted_token_ids.dtype != torch.int32:
        raise ValueError("sorted_token_ids must be int32")
    if (
        cu_seqlens_m.dtype != torch.int32
        or cu_seqlens_m.ndim != 1
        or not cu_seqlens_m.is_contiguous()
    ):
        raise ValueError("cu_seqlens_m must be a contiguous int32 1D tensor")
    if A_routed_bits.dtype != torch.uint8 or row_scale.dtype != torch.float32:
        raise ValueError("A_routed_bits must be uint8 and row_scale must be fp32")
    if mul_routed_weight:
        if topk_weights is None:
            raise ValueError("topk_weights is required when mul_routed_weight=True")
    else:
        topk_weights = torch.empty((0,), device=C.device, dtype=C.dtype)

    arch = get_cuda_arch()
    if not sm_arch_at_least(arch, 100):
        raise ValueError(f"FP8 tcgen kernels require SM100+ (got arch={arch})")

    C2d = C.view(-1, C.shape[-1])
    variant = _variant_for_config(
        kind, config, int(C2d.shape[1]), int(A_fp8_bits.shape[1]), use_pdl=False,
    )
    from kestrel_kernels.cute_moe._tcgen_routing import (
        prepare_tcgen_dispatch_tensors,
    )

    tcgen_tensors = prepare_tcgen_dispatch_tensors(
        kind,
        A_fp8_bits,
        A_scale,
        B_fp8_bits,
        B_scale,
        C2d,
        sorted_token_ids=sorted_token_ids,
        cu_seqlens_m=cu_seqlens_m,
        A_routed_bits=A_routed_bits,
        row_scale=row_scale,
        topk_weights=topk_weights if mul_routed_weight else None,
        mul_routed_weight=mul_routed_weight,
        top_k=top_k,
        num_experts=int(B_fp8_bits.shape[0]),
    )
    _invoke_aot(_family, variant, tcgen_tensors, A_fp8_bits)


def invoke_cute_moe_up(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
) -> None:
    """CuTe fused MoE up-projection (no routed-weight scaling)."""
    if config is None:
        config = get_cute_moe_routed_config(
            A.shape[0],
            num_experts=B.shape[0],
            hidden_size=A.shape[1],
            intermediate_size=B.shape[1] // 2,
        )["up"]
    _invoke_cute_moe_impl(
        "up", A, B, C,
        topk_weights=None,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=False,
        top_k=_CUTE_TOP_K_UP_DECODE,
        config=config,
    )


def invoke_cute_moe_down(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
) -> None:
    """CuTe fused MoE down-projection (includes routed-weight scaling)."""
    if config is None:
        config = get_cute_moe_routed_config(
            C.shape[0],
            num_experts=B.shape[0],
            hidden_size=B.shape[1],
            intermediate_size=B.shape[2],
        )["down"]
    _invoke_cute_moe_impl(
        "down", A, B, C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=True,
        top_k=1,
        config=config,
    )


def invoke_cute_moe_up_fp8(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
    use_pdl: bool = False,
) -> None:
    """CuTe fused MoE up-projection with FP8 activations + weights (W8A8).

    `use_pdl=True` enables Programmatic Dependent Launch — the kernel
    waits via `griddepcontrol_wait()` before loading A tiles, allowing
    overlap with a preceding producer (e.g., FP8 quantization). SM90+ only.
    """
    if config is None:
        config = get_cute_moe_routed_config(
            A_fp8_bits.shape[0],
            num_experts=B_fp8_bits.shape[0],
            hidden_size=A_fp8_bits.shape[1],
            intermediate_size=B_fp8_bits.shape[1] // 2,
            dtype="fp8",
        )["up"]
    _invoke_cute_moe_fp8_impl(
        "up", A_fp8_bits, A_scale, B_fp8_bits, B_scale, C,
        topk_weights=None,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=False,
        top_k=_CUTE_TOP_K_UP_DECODE,
        config=config,
        use_pdl=use_pdl,
    )


def invoke_cute_moe_down_fp8(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
    use_pdl: bool = False,
) -> None:
    """CuTe fused MoE down-projection with FP8 activations + weights."""
    if config is None:
        config = get_cute_moe_routed_config(
            C.shape[0],
            num_experts=B_fp8_bits.shape[0],
            hidden_size=B_fp8_bits.shape[1],
            intermediate_size=B_fp8_bits.shape[2],
            dtype="fp8",
        )["down"]
    _invoke_cute_moe_fp8_impl(
        "down", A_fp8_bits, A_scale, B_fp8_bits, B_scale, C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=True,
        top_k=1,
        config=config,
        use_pdl=use_pdl,
    )


def invoke_cute_moe_up_fp8_tcgen(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    sorted_token_ids: torch.Tensor,
    cu_seqlens_m: torch.Tensor,
    A_routed_bits: torch.Tensor,
    row_scale: torch.Tensor,
    config: CuteMoeConfig,
) -> None:
    """CuTe tcgen MoE up-projection with compact routing."""
    _invoke_cute_moe_fp8_tcgen_impl(
        "up",
        A_fp8_bits,
        A_scale,
        B_fp8_bits,
        B_scale,
        C,
        topk_weights=None,
        sorted_token_ids=sorted_token_ids,
        cu_seqlens_m=cu_seqlens_m,
        A_routed_bits=A_routed_bits,
        row_scale=row_scale,
        mul_routed_weight=False,
        top_k=_CUTE_TOP_K_UP_DECODE,
        config=config,
    )


def invoke_cute_moe_down_fp8_tcgen(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    cu_seqlens_m: torch.Tensor,
    A_routed_bits: torch.Tensor,
    row_scale: torch.Tensor,
    config: CuteMoeConfig,
) -> None:
    """CuTe tcgen MoE down-projection with compact routing."""
    _invoke_cute_moe_fp8_tcgen_impl(
        "down",
        A_fp8_bits,
        A_scale,
        B_fp8_bits,
        B_scale,
        C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        cu_seqlens_m=cu_seqlens_m,
        A_routed_bits=A_routed_bits,
        row_scale=row_scale,
        mul_routed_weight=True,
        top_k=1,
        config=config,
    )
