"""Warp-GEMV style FP8 MoE layer kernels.

This is intentionally a layer-level path, not another routed GEMM tile:

* gate/up kernel: one warp computes one intermediate activation for one
  (token, routed expert) pair.
* down kernel: one warp computes one final output scalar for one token,
  folding all top-k routed experts into the accumulator.

Expert weights are FP8 E4M3 with per-output-channel scales. Activations remain
BF16 between the two kernels, so this is a W8A16 path.
"""

from typing import Tuple

import cuda.bindings.driver as cuda
import cutlass
import cutlass.cute as cute
from cutlass import BFloat16, Float32, Int32, Int64, Uint8, const_expr
from cutlass.cutlass_dsl import T, dsl_user_op
from cutlass._mlir.dialects import llvm
from cutlass._mlir.dialects import math as mlir_math

from kestrel_kernels.arch import sm_arch_number
from kestrel_kernels.cute_moe.config import WarpGemvVariant


def _elem_pointer_i64(x: cute.Tensor, coord: cute.Coord, *, loc=None, ip=None):
    flat_coord_i64 = tuple(Int64(c) for c in cute.flatten(coord))
    flat_stride = cute.flatten_to_tuple(x.stride)
    assert len(flat_coord_i64) == len(flat_stride), (
        "Coordinate and stride must have the same length"
    )
    offset = sum(c * s for c, s in zip(flat_coord_i64, flat_stride))
    byte_offset = offset * x.element_type.width // 8
    return cute.make_ptr(
        x.element_type,
        x.iterator.toint() + byte_offset,
        x.memspace,
        assumed_align=x.iterator.alignment,
    )


@dsl_user_op
def _ld_global_u32(addr: Int64, *, loc=None, ip=None) -> Int32:
    return Int32(
        llvm.inline_asm(
            T.i32(),
            [Int64(addr).ir_value(loc=loc, ip=ip)],
            "ld.global.u32 $0, [$1];",
            "=r,l",
            has_side_effects=True,
            loc=loc,
            ip=ip,
        )
    )


@dsl_user_op
def _extract_f16x2_to_f32x2(
    packed_f16x2: Int32, *, loc=None, ip=None
) -> Tuple[Float32, Float32]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import arith

    f16_type = ir.F16Type.get()
    vec_type = ir.VectorType.get([2], f16_type)
    vec_f16x2 = llvm.bitcast(
        vec_type, Int32(packed_f16x2).ir_value(loc=loc, ip=ip), loc=loc, ip=ip
    )
    idx_0 = arith.constant(T.i32(), 0, loc=loc, ip=ip)
    idx_1 = arith.constant(T.i32(), 1, loc=loc, ip=ip)
    lo = llvm.extractelement(vec_f16x2, idx_0, loc=loc, ip=ip)
    hi = llvm.extractelement(vec_f16x2, idx_1, loc=loc, ip=ip)
    return Float32(lo), Float32(hi)


# Keep the tiny GELU helper local to this CuTe template. Importing
# gelu_residual.kernel loads that package's runtime dispatch first, which
# imports the precompile registry and creates a warpgemv variant import cycle.
@dsl_user_op
def _erf_f32(x: Float32, *, loc=None, ip=None) -> Float32:
    return Float32(
        mlir_math.erf(
            Float32(x).ir_value(loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )
    )


@dsl_user_op
def _fma_f32(a: Float32, b: Float32, c: Float32, *, loc=None, ip=None) -> Float32:
    return Float32(
        mlir_math.fma(
            Float32(a).ir_value(loc=loc, ip=ip),
            Float32(b).ir_value(loc=loc, ip=ip),
            Float32(c).ir_value(loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )
    )


@cute.jit
def _gelu_f32(x: Float32) -> Float32:
    sqrt_half = Float32(0.7071067811865476)
    half = Float32(0.5)
    erf_val = _erf_f32(x * sqrt_half)
    return _fma_f32(half * erf_val, x, half * x)


@dsl_user_op
def _cvt_e4m3x4_to_f32x4_hardware(
    packed_fp8x4: Int32, *, loc=None, ip=None
) -> Tuple[Float32, Float32, Float32, Float32]:
    packed_f16x2 = llvm.inline_asm(
        llvm.StructType.get_literal([T.i32(), T.i32()]),
        [Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        "{\n"
        ".reg .b16 lo_fp8x2, hi_fp8x2;\n"
        "mov.b32 {lo_fp8x2, hi_fp8x2}, $2;\n"
        "cvt.rn.f16x2.e4m3x2 $0, lo_fp8x2;\n"
        "cvt.rn.f16x2.e4m3x2 $1, hi_fp8x2;\n"
        "}\n",
        "=r,=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    lo_i32 = Int32(llvm.extractvalue(T.i32(), packed_f16x2, [0], loc=loc, ip=ip))
    hi_i32 = Int32(llvm.extractvalue(T.i32(), packed_f16x2, [1], loc=loc, ip=ip))
    w0, w1 = _extract_f16x2_to_f32x2(lo_i32)
    w2, w3 = _extract_f16x2_to_f32x2(hi_i32)
    return w0, w1, w2, w3


@dsl_user_op
def _cvt_e4m3x4_to_f32x4_software(
    packed_fp8x4: Int32, *, loc=None, ip=None
) -> Tuple[Float32, Float32, Float32, Float32]:
    out = llvm.inline_asm(
        llvm.StructType.get_literal([T.f32(), T.f32(), T.f32(), T.f32()]),
        [Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        "{\n\t"
        ".reg .b32 q, sh, out1, out2, u0, u1, u2, u3;\n\t"
        ".reg .f32 f0, f1, f2, f3;\n\t"
        "mov.b32 q, $4;\n\t"
        "prmt.b32 q, q, q, 0x1302;\n\t"
        "and.b32 out1, q, 0x80008000;\n\t"
        "and.b32 sh, q, 0x7F007F00;\n\t"
        "shr.b32 sh, sh, 4;\n\t"
        "or.b32 out1, out1, sh;\n\t"
        "shl.b32 sh, q, 8;\n\t"
        "and.b32 out2, sh, 0x80008000;\n\t"
        "and.b32 sh, sh, 0x7F007F00;\n\t"
        "shr.b32 sh, sh, 4;\n\t"
        "or.b32 out2, out2, sh;\n\t"
        "and.b32 u0, out1, 0xFFFF;\n\t"
        "shr.b32 u1, out1, 16;\n\t"
        "and.b32 u2, out2, 0xFFFF;\n\t"
        "shr.b32 u3, out2, 16;\n\t"
        "shl.b32 u0, u0, 16;\n\t"
        "shl.b32 u1, u1, 16;\n\t"
        "shl.b32 u2, u2, 16;\n\t"
        "shl.b32 u3, u3, 16;\n\t"
        "mov.b32 f0, u0;\n\t"
        "mov.b32 f1, u1;\n\t"
        "mov.b32 f2, u2;\n\t"
        "mov.b32 f3, u3;\n\t"
        "mul.rn.f32 $0, f0, 0f7B800000;\n\t"
        "mul.rn.f32 $1, f1, 0f7B800000;\n\t"
        "mul.rn.f32 $2, f2, 0f7B800000;\n\t"
        "mul.rn.f32 $3, f3, 0f7B800000;\n\t"
        "}\n",
        "=f,=f,=f,=f,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )
    w0 = Float32(llvm.extractvalue(T.f32(), out, [0], loc=loc, ip=ip))
    w1 = Float32(llvm.extractvalue(T.f32(), out, [1], loc=loc, ip=ip))
    w2 = Float32(llvm.extractvalue(T.f32(), out, [2], loc=loc, ip=ip))
    w3 = Float32(llvm.extractvalue(T.f32(), out, [3], loc=loc, ip=ip))
    return w0, w1, w2, w3


@cute.jit
def _cvt_e4m3x4_to_f32x4(
    packed_fp8x4: Int32,
    arch: cutlass.Constexpr[int],
) -> Tuple[Float32, Float32, Float32, Float32]:
    if const_expr(arch >= 89):
        return _cvt_e4m3x4_to_f32x4_hardware(packed_fp8x4)
    return _cvt_e4m3x4_to_f32x4_software(packed_fp8x4)


@cute.jit
def _load_fp8x4_as_f32(
    weight: cute.Tensor,
    expert: Int32,
    row: Int32,
    col: Int32,
    arch: cutlass.Constexpr[int],
) -> Tuple[Float32, Float32, Float32, Float32]:
    ptr = _elem_pointer_i64(weight, (expert, row, col))
    # Tried sm100 native Float8E4M3FN vector load: 56/73/124/194us at
    # M=1/2/4/8 vs packed 56/71/124/193us in do_bench; keeping packed.
    packed = _ld_global_u32(ptr.toint())
    return _cvt_e4m3x4_to_f32x4(packed, arch)


@cute.jit
def _warp_reduce_sum_f32(val: Float32) -> Float32:
    return cute.arch.warp_reduction_sum(val, threads_in_group=32)


class _MoeWarpGemvBaseFp8:
    WARP_SIZE = 32

    def __init__(
        self,
        *,
        hidden_size: int,
        intermediate_size: int,
        top_k: int = 8,
        warps_per_block: int = 8,
        arch: int = 89,
        raw_up: bool = False,
        slot_outputs: bool = False,
    ) -> None:
        self.hidden_size = int(hidden_size)
        self.intermediate_size = int(intermediate_size)
        self.top_k = int(top_k)
        self.warps_per_block = int(warps_per_block)
        self.arch = int(arch)
        self.raw_up = bool(raw_up)
        self.slot_outputs = bool(slot_outputs)

    @cute.kernel
    def gate_up_kernel(
        self,
        mX: cute.Tensor,
        mTopkIds: cute.Tensor,
        mUpWeight: cute.Tensor,
        mUpScale: cute.Tensor,
        mActivation: cute.Tensor,
    ):
        tidx, _, _ = cute.arch.thread_idx()
        bidx, _, _ = cute.arch.block_idx()

        warp_size = const_expr(self.WARP_SIZE)
        warps_per_block = const_expr(self.warps_per_block)
        hidden = const_expr(self.hidden_size)
        intermediate = const_expr(self.intermediate_size)
        top_k = const_expr(self.top_k)
        out_cols = const_expr(
            2 * self.intermediate_size if self.raw_up else self.intermediate_size
        )
        k_vec = const_expr(4)

        warp_id = tidx // warp_size
        lane = tidx % warp_size
        linear = bidx * warps_per_block + warp_id
        total = Int32(mX.shape[0]) * Int32(top_k * out_cols)

        acc_x = Float32(0.0)
        acc_y = Float32(0.0)

        if linear < total:
            neuron = linear % Int32(out_cols)
            assignment = linear // Int32(out_cols)
            slot = assignment % Int32(top_k)
            token = assignment // Int32(top_k)
            expert = Int32(mTopkIds[token, slot])

            for k in range(
                lane * Int32(k_vec),
                Int32(hidden),
                Int32(warp_size * k_vec),
            ):
                # Tried BF16x4 ld.global.v2.b32 / LDG.E.64: do_bench on B200
                # was 56/73/124/194/335us at M=1/2/4/8/16 vs scalar
                # 56/71/124/193/331us; keeping scalar loads.
                x0 = Float32(mX[token, k])
                x1 = Float32(mX[token, k + Int32(1)])
                x2 = Float32(mX[token, k + Int32(2)])
                x3 = Float32(mX[token, k + Int32(3)])
                wx0, wx1, wx2, wx3 = _load_fp8x4_as_f32(
                    mUpWeight,
                    expert,
                    neuron,
                    k,
                    self.arch,
                )
                acc_x += x0 * wx0 + x1 * wx1 + x2 * wx2 + x3 * wx3
                if const_expr(not self.raw_up):
                    wy0, wy1, wy2, wy3 = _load_fp8x4_as_f32(
                        mUpWeight,
                        expert,
                        Int32(intermediate) + neuron,
                        k,
                        self.arch,
                    )
                    acc_y += x0 * wy0 + x1 * wy1 + x2 * wy2 + x3 * wy3

            acc_x = _warp_reduce_sum_f32(acc_x)
            if const_expr(not self.raw_up):
                acc_y = _warp_reduce_sum_f32(acc_y)

            if lane == 0:
                scale_x = Float32(mUpScale[expert, neuron])
                vx = acc_x * scale_x
                if const_expr(self.raw_up):
                    mActivation[assignment, neuron] = BFloat16(vx)
                else:
                    scale_y = Float32(mUpScale[expert, Int32(intermediate) + neuron])
                    vy = acc_y * scale_y
                    act = _gelu_f32(vx) * (vy + Float32(1.0))
                    mActivation[assignment, neuron] = BFloat16(act)

    @cute.kernel
    def down_kernel(
        self,
        mActivation: cute.Tensor,
        mTopkIds: cute.Tensor,
        mTopkWeights: cute.Tensor,
        mDownWeight: cute.Tensor,
        mDownScale: cute.Tensor,
        mOut: cute.Tensor,
    ):
        tidx, _, _ = cute.arch.thread_idx()
        bidx, _, _ = cute.arch.block_idx()

        warp_size = const_expr(self.WARP_SIZE)
        warps_per_block = const_expr(self.warps_per_block)
        hidden = const_expr(self.hidden_size)
        intermediate = const_expr(self.intermediate_size)
        top_k = const_expr(self.top_k)
        k_vec = const_expr(4)

        warp_id = tidx // warp_size
        lane = tidx % warp_size
        linear = bidx * warps_per_block + warp_id
        total = Int32(mOut.shape[0]) * Int32(hidden)

        if linear < total:
            out_col = linear % Int32(hidden)
            if const_expr(self.slot_outputs):
                assignment = linear // Int32(hidden)
                slot = assignment % Int32(top_k)
                token = assignment // Int32(top_k)
                expert = Int32(mTopkIds[token, slot])
                acc = Float32(0.0)

                for k in range(
                    lane * Int32(k_vec),
                    Int32(intermediate),
                    Int32(warp_size * k_vec),
                ):
                    # See gate/up loop: LDG.E.64 BF16 input loads did not
                    # improve layer do_bench, so keep scalar BF16 loads here.
                    a0 = Float32(mActivation[assignment, k])
                    a1 = Float32(mActivation[assignment, k + Int32(1)])
                    a2 = Float32(mActivation[assignment, k + Int32(2)])
                    a3 = Float32(mActivation[assignment, k + Int32(3)])
                    w0, w1, w2, w3 = _load_fp8x4_as_f32(
                        mDownWeight,
                        expert,
                        out_col,
                        k,
                        self.arch,
                    )
                    acc += a0 * w0 + a1 * w1 + a2 * w2 + a3 * w3

                acc = _warp_reduce_sum_f32(acc)
                route_w = Float32(mTopkWeights[token, slot])
                scale = Float32(mDownScale[expert, out_col])
                if lane == 0:
                    mOut[assignment, out_col] = BFloat16(acc * scale * route_w)
            else:
                token = linear // Int32(hidden)
                out_acc = Float32(0.0)

                for slot in cutlass.range_constexpr(top_k):
                    expert = Int32(mTopkIds[token, slot])
                    assignment = token * Int32(top_k) + Int32(slot)
                    acc = Float32(0.0)

                    for k in range(
                        lane * Int32(k_vec),
                        Int32(intermediate),
                        Int32(warp_size * k_vec),
                    ):
                        # See gate/up loop: LDG.E.64 BF16 input loads did not
                        # improve layer do_bench, so keep scalar BF16 loads here.
                        a0 = Float32(mActivation[assignment, k])
                        a1 = Float32(mActivation[assignment, k + Int32(1)])
                        a2 = Float32(mActivation[assignment, k + Int32(2)])
                        a3 = Float32(mActivation[assignment, k + Int32(3)])
                        w0, w1, w2, w3 = _load_fp8x4_as_f32(
                            mDownWeight,
                            expert,
                            out_col,
                            k,
                            self.arch,
                        )
                        acc += a0 * w0 + a1 * w1 + a2 * w2 + a3 * w3

                    acc = _warp_reduce_sum_f32(acc)
                    route_w = Float32(mTopkWeights[token, slot])
                    scale = Float32(mDownScale[expert, out_col])
                    out_acc += acc * scale * route_w

                if lane == 0:
                    mOut[token, out_col] = BFloat16(out_acc)


class _MoeWarpGemvGateUpFp8(_MoeWarpGemvBaseFp8):
    @cute.jit
    def __call__(
        self,
        mX: cute.Tensor,
        mTopkIds: cute.Tensor,
        mUpWeight: cute.Tensor,
        mUpScale: cute.Tensor,
        mActivation: cute.Tensor,
        stream: cuda.CUstream,
    ):
        out_cols = const_expr(
            2 * self.intermediate_size if self.raw_up else self.intermediate_size
        )
        outputs = Int32(mX.shape[0]) * Int32(self.top_k * out_cols)
        blocks = cute.ceil_div(outputs, const_expr(self.warps_per_block))
        self.gate_up_kernel(
            mX,
            mTopkIds,
            mUpWeight,
            mUpScale,
            mActivation,
        ).launch(
            grid=(blocks, 1, 1),
            block=(self.warps_per_block * self.WARP_SIZE, 1, 1),
            stream=stream,
        )


class _MoeWarpGemvDownFp8(_MoeWarpGemvBaseFp8):
    @cute.jit
    def __call__(
        self,
        mActivation: cute.Tensor,
        mTopkIds: cute.Tensor,
        mTopkWeights: cute.Tensor,
        mDownWeight: cute.Tensor,
        mDownScale: cute.Tensor,
        mOut: cute.Tensor,
        stream: cuda.CUstream,
    ):
        outputs = Int32(mOut.shape[0]) * Int32(self.hidden_size)
        blocks = cute.ceil_div(outputs, const_expr(self.warps_per_block))
        self.down_kernel(
            mActivation,
            mTopkIds,
            mTopkWeights,
            mDownWeight,
            mDownScale,
            mOut,
        ).launch(
            grid=(blocks, 1, 1),
            block=(self.warps_per_block * self.WARP_SIZE, 1, 1),
            stream=stream,
        )


def make_compile_args(variant: WarpGemvVariant, arch: str):
    M_sym = cute.sym_int()
    E_sym = cute.sym_int()
    MT_sym = cute.sym_int()
    H = int(variant.hidden_size)
    I = int(variant.intermediate_size)
    top_k = int(variant.top_k)
    arch_num = sm_arch_number(arch)
    if variant.topk_weight_dtype not in ("bf16", "fp32"):
        raise ValueError(
            f"unsupported topk weight dtype: {variant.topk_weight_dtype!r}"
        )

    x = cute.runtime.make_fake_tensor(
        BFloat16,
        (M_sym, H),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    topk_ids = cute.runtime.make_fake_tensor(
        Int32,
        (M_sym, top_k),
        stride=(top_k, 1),
        assumed_align=4,
    )
    topk_weight_type = Float32 if variant.topk_weight_dtype == "fp32" else BFloat16
    topk_weight_align = 4 if variant.topk_weight_dtype == "fp32" else 16
    topk_weights = cute.runtime.make_fake_tensor(
        topk_weight_type,
        (M_sym, top_k),
        stride=(top_k, 1),
        assumed_align=topk_weight_align,
    )
    up_weight = cute.runtime.make_fake_tensor(
        Uint8,
        (E_sym, 2 * I, H),
        stride=(
            cute.sym_int64(divisibility=16),
            cute.sym_int64(divisibility=16),
            1,
        ),
        assumed_align=16,
    )
    up_scale = cute.runtime.make_fake_tensor(
        Float32,
        (E_sym, 2 * I),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=4,
    )
    down_weight = cute.runtime.make_fake_tensor(
        Uint8,
        (E_sym, H, I),
        stride=(
            cute.sym_int64(divisibility=16),
            cute.sym_int64(divisibility=16),
            1,
        ),
        assumed_align=16,
    )
    down_scale = cute.runtime.make_fake_tensor(
        Float32,
        (E_sym, H),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=4,
    )
    activation = cute.runtime.make_fake_tensor(
        BFloat16,
        (MT_sym, I),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    up_out = cute.runtime.make_fake_tensor(
        BFloat16,
        (MT_sym, 2 * I),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    down_out = cute.runtime.make_fake_tensor(
        BFloat16,
        (MT_sym, H),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    out = cute.runtime.make_fake_tensor(
        BFloat16,
        (M_sym, H),
        stride=(cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    stream = cute.runtime.make_fake_stream(use_tvm_ffi_env_stream=True)
    if variant.kind == "gate":
        op = _MoeWarpGemvGateUpFp8(
            hidden_size=H,
            intermediate_size=I,
            top_k=top_k,
            warps_per_block=int(variant.warps_per_block),
            arch=arch_num,
            raw_up=False,
        )
        return (op, x, topk_ids, up_weight, up_scale, activation, stream)
    if variant.kind == "up":
        op = _MoeWarpGemvGateUpFp8(
            hidden_size=H,
            intermediate_size=I,
            top_k=top_k,
            warps_per_block=int(variant.warps_per_block),
            arch=arch_num,
            raw_up=True,
        )
        return (op, x, topk_ids, up_weight, up_scale, up_out, stream)
    if variant.kind == "down":
        op = _MoeWarpGemvDownFp8(
            hidden_size=H,
            intermediate_size=I,
            top_k=top_k,
            warps_per_block=int(variant.warps_per_block),
            arch=arch_num,
            slot_outputs=False,
        )
        return (
            op,
            activation,
            topk_ids,
            topk_weights,
            down_weight,
            down_scale,
            out,
            stream,
        )
    if variant.kind == "down_slots":
        op = _MoeWarpGemvDownFp8(
            hidden_size=H,
            intermediate_size=I,
            top_k=top_k,
            warps_per_block=int(variant.warps_per_block),
            arch=arch_num,
            slot_outputs=True,
        )
        return (
            op,
            activation,
            topk_ids,
            topk_weights,
            down_weight,
            down_scale,
            down_out,
            stream,
        )
    raise ValueError(f"unsupported warp-gemv kind: {variant.kind!r}")

__all__ = ["WarpGemvVariant", "make_compile_args"]
