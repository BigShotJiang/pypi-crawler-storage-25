"""MoE align block size dispatch via the cubin bundle runtime.

Three cubin variants per (dtype, topk, num_experts, block_size) tuple:
  small                  - single-CTA shared-memory path (one launch)
  large_align + scatter  - two-kernel multi-CTA path

Small vs large is picked by the same heuristic the CUDA extension uses:
small_batch_expert_mode = (num_experts <= 64) and (T*K < 1024).

When KESTREL_CUTE_JIT=1 is set (dev autotuning only), missing variants
are compiled on demand via `cute.compile()` and registered with the cubin
family so subsequent calls dispatch normally. This lets
`scripts/grid_search_cute_moe.py` benchmark arbitrary block sizes without
shipping every candidate in the bundle.
"""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled, warn_and_run_fallback
from kestrel_kernels.moe_align.fallback import (
    moe_align_block_size_torch_into,
)

_family = CubinFamily("moe_align")

_SMALL_BATCH_EXPERT_LIMIT = 64
_SMALL_BATCH_NUMEL_LIMIT = 1024
_LARGE_SCATTER_THREADS = 256

_CUMSUM_BUFFER_CACHE: dict = {}

_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    # Eagerly import cubin_bundles so its module-level CuTe DSL env-var
    # setup (KEEP_CUBIN/PTX/DUMP_DIR) runs before any other module pulls
    # in cutlass. The compile helpers we call later need those env vars
    # to have been set at cutlass import time.
    from scripts.precompile import cubin_bundles as _cubin_bundles


def _tag(topk_ids: torch.Tensor, topk: int, num_experts: int, block_size: int) -> str:
    """Variant-key suffix shared by all phases at one (dtype, topk, e, bs) tuple."""
    dtype_name = "i32" if topk_ids.dtype == torch.int32 else "i64"
    return f"{dtype_name}_k{topk}_e{num_experts}_b{block_size}"


def _cumsum_buffer(device: torch.device, num_experts: int) -> torch.Tensor:
    """Per-stream scratch buffer reused across calls on the hot path."""
    dev_idx = int(device.index or 0)
    stream_id = int(torch.cuda.current_stream(device).cuda_stream)
    key = (dev_idx, stream_id, int(num_experts))
    buf = _CUMSUM_BUFFER_CACHE.get(key)
    required = int(num_experts)
    if buf is None:
        buf = torch.empty((required,), device=device, dtype=torch.int32)
        _CUMSUM_BUFFER_CACHE[key] = buf
    elif buf.numel() < required:
        raise RuntimeError(
            f"moe_align cumsum buffer overflow: need {required} elements, "
            f"have {buf.numel()}. Pre-allocate for the expected num_experts "
            f"before CUDA graph capture."
        )
    return buf


def _run_torch_fallback(
    fallback_fn,
    kernel_key: str,
    *,
    missing_variants: tuple[str, ...] = (),
    **kwargs,
) -> None:
    from kestrel_kernels.arch import get_cuda_arch

    arch = get_cuda_arch()
    reason = (
        f"missing cubin variant(s) for arch={arch}: {', '.join(missing_variants)}"
        if missing_variants
        else f"no cubin bundle for arch={arch}"
    )
    warn_and_run_fallback(
        kernel_key=kernel_key,
        message=(
            f"kestrel-kernels: falling back to PyTorch for {kernel_key} "
            f"({reason})."
        ),
        fallback=fallback_fn,
        kwargs=kwargs,
    )


def _jit_ensure_variant(
    variant_key: str, phase: str, topk_ids: torch.Tensor,
    num_experts: int, block_size: int,
) -> None:
    """JIT-compile a moe_align variant on demand and install it on _family.

    Only invoked under KESTREL_CUTE_JIT=1 (dev autotuning). Requires a
    source install where `scripts/precompile.cubin_bundles` is importable.
    """
    device_index = int(topk_ids.device.index or 0)
    if (variant_key, device_index) in _family._handles:
        return

    from cutlass import Int32, Int64
    topk_dtype = Int32 if topk_ids.dtype == torch.int32 else Int64
    topk = int(topk_ids.shape[1])
    spec = _cubin_bundles._MOE_ALIGN_PHASES[phase]
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_moe_align(
            phase, topk_dtype, topk, num_experts, block_size,
        ),
        block_x=spec["block"][0],
        device_index=device_index,
    )


def _ensure_variants_or_fallback(
    variant_keys: tuple[tuple[str, str], ...],
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
) -> tuple[bool, tuple[str, ...]]:
    """Check that every (phase, variant_key) is available; JIT-install if needed.

    Returns ``(ready, missing_keys)``. ``ready`` is true if all variants are
    available to dispatch. Otherwise ``missing_keys`` names the unavailable
    variant keys so fallback warnings point at the exact shape/config gap.
    """
    missing: list[str] = []
    device_index = int(topk_ids.device.index or 0)
    for phase, key in variant_keys:
        if _family.is_available(key):
            continue
        if _ENABLE_JIT:
            _jit_ensure_variant(key, phase, topk_ids, num_experts, block_size)
            if _family.is_available(key) or (key, device_index) in _family._handles:
                continue
        missing.append(key)
    if missing:
        return False, tuple(missing)
    return True, ()


def moe_align_block_size(
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None:
    """CuTe DSL moe_align_block_size (CUDA-only)."""
    if topk_ids.device.type != "cuda":
        raise ValueError("topk_ids must be a CUDA tensor")
    if not topk_ids.is_contiguous() or topk_ids.ndim != 2:
        raise ValueError("topk_ids must be a contiguous 2D tensor [num_tokens, top_k]")
    if topk_ids.dtype not in (torch.int32, torch.int64):
        raise ValueError("topk_ids must be int32 or int64")
    if (
        sorted_token_ids.dtype != torch.int32
        or sorted_token_ids.ndim != 1
        or not sorted_token_ids.is_contiguous()
    ):
        raise ValueError("sorted_token_ids must be a contiguous int32 1D tensor")
    if (
        expert_ids.dtype != torch.int32
        or expert_ids.ndim != 1
        or not expert_ids.is_contiguous()
    ):
        raise ValueError("expert_ids must be a contiguous int32 1D tensor")
    if (
        num_tokens_post_pad.dtype != torch.int32
        or num_tokens_post_pad.ndim != 1
        or num_tokens_post_pad.numel() != 1
        or not num_tokens_post_pad.is_contiguous()
    ):
        raise ValueError("num_tokens_post_pad must be contiguous int32 with shape (1,)")

    topk = int(topk_ids.shape[1])
    numel = int(topk_ids.numel())
    tag = _tag(topk_ids, topk, int(num_experts), int(block_size))
    small = (int(num_experts) <= _SMALL_BATCH_EXPERT_LIMIT) and (numel < _SMALL_BATCH_NUMEL_LIMIT)

    needed_keys = (
        (("small", f"small_{tag}"),) if small
        else (("large_align", f"large_align_{tag}"), ("large_scatter", f"large_scatter_{tag}"))
    )
    variants_ready, missing_variants = _ensure_variants_or_fallback(
        needed_keys,
        topk_ids,
        int(num_experts),
        int(block_size),
    )
    if not variants_ready:
        _run_torch_fallback(
            moe_align_block_size_torch_into,
            "moe_align_block_size",
            missing_variants=missing_variants,
            topk_ids=topk_ids,
            num_experts=num_experts,
            block_size=block_size,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_post_pad=num_tokens_post_pad,
        )
        return

    if small:
        _family.resolve_dispatch(topk_ids, variant_key=f"small_{tag}", grid_x=1)(
            topk_ids, sorted_token_ids, expert_ids, num_tokens_post_pad,
        )
        return

    cumsum = _cumsum_buffer(topk_ids.device, int(num_experts))
    _family.resolve_dispatch(topk_ids, variant_key=f"large_align_{tag}", grid_x=2)(
        topk_ids, sorted_token_ids, expert_ids, num_tokens_post_pad, cumsum,
    )
    if numel > 0:
        grid_x = ceil_div(numel, _LARGE_SCATTER_THREADS)
        _family.resolve_dispatch(topk_ids, variant_key=f"large_scatter_{tag}", grid_x=grid_x)(
            topk_ids, sorted_token_ids, cumsum,
        )


__all__ = ["moe_align_block_size"]
