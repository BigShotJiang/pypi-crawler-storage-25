"""Torch fallback implementations for MoE align kernels."""


import torch


def _round_up_tensor(x: torch.Tensor, multiple: int) -> torch.Tensor:
    return ((x + multiple - 1) // multiple) * multiple


def moe_align_block_size_torch_into(
    *,
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None:
    num_experts_i = int(num_experts)
    block_size_i = int(block_size)
    device = topk_ids.device
    total_assignments = int(topk_ids.numel())
    sentinel_token = total_assignments

    assignments = topk_ids.reshape(-1).to(torch.int64)
    valid_range = (assignments >= 0) & (assignments < num_experts_i)
    assignments = torch.where(
        valid_range, assignments, torch.full_like(assignments, num_experts_i)
    )

    flat_indices = torch.arange(total_assignments, device=device, dtype=torch.int32)
    sorted_experts, order = torch.sort(assignments, stable=True)
    sorted_indices = flat_indices.index_select(0, order)

    counts = torch.zeros((num_experts_i + 1,), dtype=torch.int64, device=device)
    ones = torch.ones_like(assignments, dtype=torch.int64)
    counts.scatter_add_(0, assignments, ones)

    padded_counts = counts.clone()
    padded_counts[:num_experts_i] = _round_up_tensor(
        padded_counts[:num_experts_i], block_size_i
    )

    expert_offsets = torch.cumsum(padded_counts, dim=0) - padded_counts
    expert_actual_offsets = torch.cumsum(counts, dim=0) - counts
    positional = torch.arange(total_assignments, device=device, dtype=torch.int64)
    destination = expert_offsets.index_select(0, sorted_experts) + (
        positional - expert_actual_offsets.index_select(0, sorted_experts)
    )

    sorted_token_ids.fill_(sentinel_token)
    if total_assignments > 0:
        sorted_token_ids.index_copy_(0, destination, sorted_indices)

    block_counts = (padded_counts[:num_experts_i] // block_size_i).to(torch.int32)
    max_num_m_blocks = int(expert_ids.shape[0])
    expert_ids.zero_()
    if max_num_m_blocks > 0:
        block_boundaries = torch.cumsum(block_counts, dim=0)
        block_indices = torch.arange(max_num_m_blocks, device=device, dtype=torch.int64)
        assigned = torch.bucketize(block_indices, block_boundaries, right=True).to(
            torch.int32
        )
        total_blocks = (
            block_boundaries[-1]
            if block_boundaries.numel() > 0
            else torch.zeros((), device=device, dtype=torch.int64)
        )
        mask = block_indices < total_blocks
        expert_ids.copy_(torch.where(mask, assigned, expert_ids))

    total_padded = padded_counts[:num_experts_i].sum().to(torch.int32)
    num_tokens_post_pad.copy_(total_padded.view(1))


__all__ = ["moe_align_block_size_torch_into"]
