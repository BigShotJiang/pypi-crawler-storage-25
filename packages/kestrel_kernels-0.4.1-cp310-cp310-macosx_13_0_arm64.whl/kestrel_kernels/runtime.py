"""Stable runtime API surface for Kestrel kernels.

This module provides a single place for kernel entrypoints used by Kestrel.
Callers should depend on this API rather than deep internal module paths.
"""


import sys
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Callable

import torch


from kestrel_kernels.flash_attn.cute.mask_ids import PREFIX_LM_730_MASK_ID as _PREFIX_LM_730_HASH


def _missing_runtime_fn(domain: str, name: str, exc: Exception) -> Callable[..., Any]:
    def _missing(*_args, **_kwargs):
        raise RuntimeError(
            f"kestrel-kernels: '{domain}.{name}' is unavailable on this platform/runtime. "
            f"Original import error: {type(exc).__name__}: {exc}"
        ) from exc

    return _missing


def _missing_prefix_mask() -> Callable[..., Any]:
    def _mask(*_args, **_kwargs):
        raise RuntimeError(
            "kestrel-kernels: prefix-LM mask support requires the CuTe flash-attention runtime."
        )

    _mask.__cute_hash__ = _PREFIX_LM_730_HASH
    return _mask


def _topk_torch_fwd(
    x: torch.Tensor,
    k: int,
    softmax: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    values, indices = torch.topk(x, k=k, dim=-1)
    if softmax:
        values = torch.softmax(values.float(), dim=-1).to(x.dtype)
    return values, indices.to(torch.int32)


def _moe_topk_fwd(
    cuda_topk_fwd: Callable[..., Any],
) -> Callable[..., tuple[torch.Tensor, torch.Tensor]]:
    def _topk_fwd(
        x: torch.Tensor,
        k: int,
        softmax: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if (
            x.is_cuda
            and x.dtype == torch.bfloat16
            and x.ndim == 2
            and x.is_contiguous()
            and x.size(1) == 64
            and k == 8
            and softmax
        ):
            return cuda_topk_fwd(x, k, softmax=softmax)
        return _topk_torch_fwd(x, k, softmax=softmax)

    return _topk_fwd


def _cuda_moe_supports_lora(device: torch.device | str | None = None) -> bool:
    if device is None:
        if not torch.cuda.is_available():
            return False
        device = torch.device("cuda", torch.cuda.current_device())
    else:
        device = torch.device(device)
    if device.type != "cuda":
        return False
    if not torch.cuda.is_available():
        return False

    try:
        from kestrel_kernels.moe.lora.cute import supports_moe_lora
    except Exception:
        return False
    return supports_moe_lora(device)


def _cuda_moe_reserve_lora_scratch(
    *,
    max_tokens: int,
    top_k: int,
    max_lora_rank: int,
    device: torch.device | str,
    dtype: torch.dtype,
) -> None:
    if max_tokens <= 0:
        raise ValueError("max_tokens must be positive")
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if max_lora_rank <= 0:
        return

    device = torch.device(device)
    if device.type != "cuda":
        raise RuntimeError("MoE LoRA scratch reservation is only supported on CUDA")


@dataclass(frozen=True)
class AttentionRuntime:
    flash_attn_fwd: Callable[..., Any]
    prefix_lm_mask_730: Callable[..., Any]


@dataclass(frozen=True)
class MoeRuntime:
    prepare: Callable[..., Any]
    forward: Callable[..., Any]
    topk_fwd: Callable[..., Any]
    prepare_lora_metadata: Callable[..., Any]
    supports_lora: Callable[..., bool]
    reserve_lora_scratch: Callable[..., None]


@dataclass(frozen=True)
class CacheRuntime:
    reshape_and_cache_flash: Callable[..., Any]


@dataclass(frozen=True)
class RotaryRuntime:
    rotary_embedding: Callable[..., Any]


@dataclass(frozen=True)
class TauRuntime:
    tau_tail_apply_into: Callable[..., Any]


@dataclass(frozen=True)
class VisionRuntime:
    fused_linear_bias_residual_into: Callable[..., Any]


@dataclass(frozen=True)
class LinearRuntime:
    linear: Callable[..., Any]


@dataclass(frozen=True)
class GeluRuntime:
    gelu_cute: Callable[..., Any]


@dataclass(frozen=True)
class DenseRuntime:
    # High-level cross-arch API — handles shape validation, 3D→2D
    # reshape, variant selection, and fallback-to-torch. Each backend
    # (CUDA, MPS, …) supplies its own implementation under the same
    # name. Compare ``RotaryRuntime.rotary_embedding`` /
    # ``TauRuntime.tau_tail_apply_into`` — arch-neutral fields that work
    # cross-arch without ``is_cuda`` gates at the call site.
    fused_mlp_gelu_bias_residual: Callable[..., Any]
    # ``layernorm_bias_into(out, x, weight, bias, eps, *, variant="auto",
    #                       fallback_to_torch=False) -> None``
    layernorm_bias_into: Callable[..., Any]
    # ``layernorm_bias(x, weight, bias, *, eps=1e-5,
    #                  fallback_to_torch=False) -> Tensor``
    layernorm_bias: Callable[..., Any]


@dataclass(frozen=True)
class SamplingRuntime:
    """Sampling entry point published by every backend.

    ``(logits, temperatures, top_p, *, out=None, generator=None)
      -> token_ids[B]``

    CUDA: clamp + softmax + cubin top_p sampler (existing chain).
    MPS:  one fused Metal dispatch — temperature scale + online
          softmax + top-K + top-p truncate + exp-race sample.
    CPU / other: torch reference.
    """

    sample_step_from_logits: Callable[..., Any]


class KernelRuntime:
    """Unified kernel runtime view used by Kestrel."""

    @property
    def attention(self) -> AttentionRuntime:
        # `interface._flash_attn_fwd` is cutlass-free (dispatch goes through
        # shipped cubins). `mask_definitions.cute_prefix_lm_mask_730` is the
        # real cute.jit mask, but importing it requires cutlass — wheel
        # installs without the `jit` dependency-group fall back to a stub
        # callable that carries the same `__cute_hash__`, so dispatch-by-hash
        # still picks the matching cubin variant without ever invoking
        # the mask.
        try:
            from kestrel_kernels.flash_attn.cute.interface import _flash_attn_fwd
        except Exception as exc:
            return AttentionRuntime(
                flash_attn_fwd=_missing_runtime_fn("attention", "flash_attn_fwd", exc),
                prefix_lm_mask_730=_missing_prefix_mask(),
            )

        try:
            from kestrel_kernels.flash_attn.cute.mask_definitions import (
                cute_prefix_lm_mask_730,
            )
        except Exception:
            prefix_lm_mask_730 = _missing_prefix_mask()
        else:
            cute_prefix_lm_mask_730.__cute_hash__ = _PREFIX_LM_730_HASH
            prefix_lm_mask_730 = cute_prefix_lm_mask_730

        return AttentionRuntime(
            flash_attn_fwd=_flash_attn_fwd,
            prefix_lm_mask_730=prefix_lm_mask_730,
        )

    @property
    def moe(self) -> MoeRuntime:
        try:
            from kestrel_kernels.topk import topk_fwd as cuda_topk_fwd
            from kestrel_kernels.moe.dispatch import (
                forward as moe_forward,
                prepare as moe_prepare,
            )
            from kestrel_kernels.moe import prepare_lora_metadata
        except Exception as exc:
            return MoeRuntime(
                prepare=_missing_runtime_fn("moe", "prepare", exc),
                forward=_missing_runtime_fn("moe", "forward", exc),
                topk_fwd=_missing_runtime_fn("moe", "topk_fwd", exc),
                prepare_lora_metadata=_missing_runtime_fn(
                    "moe", "prepare_lora_metadata", exc
                ),
                supports_lora=lambda *_args, **_kwargs: False,
                reserve_lora_scratch=_missing_runtime_fn(
                    "moe", "reserve_lora_scratch", exc
                ),
            )

        return MoeRuntime(
            prepare=moe_prepare,
            forward=moe_forward,
            topk_fwd=_moe_topk_fwd(cuda_topk_fwd),
            prepare_lora_metadata=prepare_lora_metadata,
            supports_lora=_cuda_moe_supports_lora,
            reserve_lora_scratch=_cuda_moe_reserve_lora_scratch,
        )

    @property
    def cache(self) -> CacheRuntime:
        from kestrel_kernels.kv_cache_write_ops import reshape_and_cache_flash

        return CacheRuntime(reshape_and_cache_flash=reshape_and_cache_flash)

    @property
    def rotary(self) -> RotaryRuntime:
        from kestrel_kernels.rotary_embedding_ops import rotary_embedding

        return RotaryRuntime(rotary_embedding=rotary_embedding)

    @property
    def tau(self) -> TauRuntime:
        from kestrel_kernels.tau_tail_ops import tau_tail_apply_into

        return TauRuntime(tau_tail_apply_into=tau_tail_apply_into)

    @property
    def vision(self) -> VisionRuntime:
        from kestrel_kernels.fused_linear_residual_ops import (
            fused_linear_bias_residual_into,
        )

        return VisionRuntime(
            fused_linear_bias_residual_into=fused_linear_bias_residual_into
        )

    @property
    def linear(self) -> LinearRuntime:
        from kestrel_kernels.linear_ops import linear

        return LinearRuntime(linear=linear)

    @property
    def gelu(self) -> GeluRuntime:
        from kestrel_kernels.gelu_residual import gelu_cute

        return GeluRuntime(gelu_cute=gelu_cute)

    @property
    def dense(self) -> DenseRuntime:
        from kestrel_kernels.fused_mlp_ops import fused_mlp_gelu_bias_residual_cuda
        from kestrel_kernels.layernorm_cuda_ops import (
            layernorm_bias,
            layernorm_bias_into,
        )

        return DenseRuntime(
            fused_mlp_gelu_bias_residual=fused_mlp_gelu_bias_residual_cuda,
            layernorm_bias_into=layernorm_bias_into,
            layernorm_bias=layernorm_bias,
        )

    @property
    def sampling(self) -> SamplingRuntime:
        from kestrel_kernels.sampling import sample_step_from_logits

        return SamplingRuntime(sample_step_from_logits=sample_step_from_logits)

    @property
    def compute_capability(self) -> tuple[int, int]:
        if not torch.cuda.is_available():
            return (0, 0)
        return torch.cuda.get_device_capability()

    @property
    def is_sm90(self) -> bool:
        major, _minor = self.compute_capability
        return major == 9


@lru_cache(maxsize=1)
def get_runtime() -> KernelRuntime:
    if sys.platform == "darwin":
        # Deferred because MPSKernelRuntime's module imports this module —
        # breaking the circular import at function call time.
        from kestrel_kernels.mps.runtime import MPSKernelRuntime

        return MPSKernelRuntime()
    return KernelRuntime()


__all__ = [
    "AttentionRuntime",
    "CacheRuntime",
    "DenseRuntime",
    "GeluRuntime",
    "KernelRuntime",
    "LinearRuntime",
    "MoeRuntime",
    "RotaryRuntime",
    "SamplingRuntime",
    "TauRuntime",
    "VisionRuntime",
    "get_runtime",
]
