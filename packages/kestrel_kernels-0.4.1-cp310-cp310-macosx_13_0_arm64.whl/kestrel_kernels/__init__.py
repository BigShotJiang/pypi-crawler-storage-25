"""Public package surface for kestrel-kernels."""


# Import torch eagerly so its Windows DLL search-path setup runs before any
# kestrel kernel DLL gets loaded. Torch's __init__ calls os.add_dll_directory
# for torch/lib (which holds the bundled cublasLt64_12.dll) and the CUDA
# toolkit path; without that, our C kernels that link against cuBLASLt fail
# to load with Win32 error 126. The directories stay registered for the
# rest of the process, so subsequent LoadLibrary calls in _pybridge inherit
# the search path.
import torch

# Side-effect import: installs ``__dlpack_c_exchange_api__`` on
# ``torch.Tensor`` so any ``_pybridge`` kernel call (Mode-1 or Mode-2)
# can pack tensors via DLPack.
import torch_c_dlpack_ext  # noqa: F401

import os as _os
import sys as _sys
from pathlib import Path as _Path

# On Windows, also register this package's own directory so that kernel
# DLLs in this folder can resolve sibling-DLL dependencies (e.g.
# kestrel_cublas_lt_workspace.dll, which fused_mlp/fused_linear link
# against). _pybridge's LoadLibraryExW call uses LOAD_LIBRARY_SEARCH_USER_DIRS,
# which only consults paths registered via AddDllDirectory.
if _sys.platform == "win32":
    _os.add_dll_directory(_os.path.dirname(__file__))


# ---------------------------------------------------------------------------
# Multi-CUDA wheel layout (aarch64): the wheel ships parallel kernel-library
# trees under ``cu<major>/`` for each supported CUDA major. Mode-1 kernel libs
# (``lib<name>.so`` linked against ``libcudart.so.<major>`` /
# ``libcublasLt.so.<major>``) and Mode-2 cubin/AOT bundles live under
# ``cu<major>/`` and ``cu<major>/bundles/`` respectively. We pick the right
# subdir at import time based on ``torch.version.cuda`` and surface its path
# via ``KERNEL_DIR`` (and to the C extension via ``_pybridge._set_kernel_dir``).
# Single-CUDA wheels keep the legacy flat layout — ``KERNEL_DIR`` then points
# at the package root and Mode-2 runtimes inherit ``<package>/bundles``.
# ---------------------------------------------------------------------------

_PKG_ROOT: _Path = _Path(__file__).resolve().parent


def _detect_cuda_major() -> int | None:
    cv = getattr(torch.version, "cuda", None)
    if not cv:
        return None
    try:
        return int(cv.split(".")[0])
    except (ValueError, IndexError):
        return None


def _select_kernel_dir() -> _Path:
    major = _detect_cuda_major()
    if major is not None:
        candidate = _PKG_ROOT / f"cu{major}"
        if candidate.is_dir():
            return candidate
    # Either CPU/MPS torch (no CUDA) or a single-CUDA wheel (flat layout).
    # If the wheel only ships ``cu<other>`` subdirs and torch's CUDA major
    # doesn't match, raise rather than silently falling back to a layout
    # that has no kernel libs at all.
    available = sorted(p.name for p in _PKG_ROOT.iterdir()
                       if p.is_dir() and p.name.startswith("cu")
                       and p.name[2:].isdigit())
    if available and major is not None:
        raise ImportError(
            f"kestrel_kernels: no kernel build for CUDA {major}; this wheel "
            f"ships builds for: {available}. Install a wheel matching your "
            "torch CUDA major, or rebuild kestrel-kernels with "
            f"-DKESTREL_KERNELS_CUDA_MAJOR={major}."
        )
    return _PKG_ROOT


KERNEL_DIR: _Path = _select_kernel_dir()


def _register_kernel_dir() -> None:
    """Tell the C extension which directory holds Mode-1 kernel libs.

    Only needed for the multi-CUDA subdir layout. On flat-layout wheels
    (single-CUDA x86_64 and non-CUDA macOS/CPU), the C side's default
    lookup — relative to ``kestrel_kernels.__file__`` — is already
    correct, so we skip the call entirely. This also avoids invoking
    the ``_pybridge.py`` shim on non-CUDA wheels: the shim's
    ``__getattr__`` returns a stub callable for *any* attribute, so the
    import succeeds even when the C extension is absent, and calling
    the stub raises ``RuntimeError``.
    """
    if KERNEL_DIR == _PKG_ROOT:
        return
    try:
        from kestrel_kernels._pybridge import _set_kernel_dir
    except ImportError:
        return
    _set_kernel_dir(str(KERNEL_DIR))


_register_kernel_dir()
del _os, _sys, _Path


from typing import Any

__all__ = [
    "KERNEL_DIR",
    "KernelRuntime",
    "get_runtime",
]


def __getattr__(name: str) -> Any:
    if name in {"KernelRuntime", "get_runtime"}:
        from kestrel_kernels.runtime import KernelRuntime, get_runtime

        exports = {
            "KernelRuntime": KernelRuntime,
            "get_runtime": get_runtime,
        }
        return exports[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
