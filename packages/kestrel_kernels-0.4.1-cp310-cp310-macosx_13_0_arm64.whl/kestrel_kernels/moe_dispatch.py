"""Unified MoE kernel dispatch.

Selects the best backend (CuTe or Triton) and config for the current GPU,
then invokes the appropriate kernel.
"""


import torch

from kestrel_kernels.moe_triton import (
    dtype_to_triton,
    invoke_fused_moe_kernel as _triton_bf16,
    invoke_fused_moe_kernel_fp8_w8a8 as _triton_fp8,
)
from kestrel_kernels.moe_triton_configs import get_triton_moe_config


def _device_sm(device: torch.device) -> int:
    major, minor = torch.cuda.get_device_capability(device)
    return int(major) * 10 + int(minor)


def _device_supports_cute_moe_dtype(device: torch.device, dtype: str) -> bool:
    sm = _device_sm(device)
    # sm_80 (A100) and sm_86 (A10) — Ampere has no hardware FP8 MMA and
    # no hardware FP8→F16 cvt PTX op, but cute_moe_fp8_warp can still
    # run on these arches via the software dequant path
    # (`cvt_fp8x2_to_f16_both_software` selected at compile time when
    # the kernel's arch < 89). The MMA itself uses the F16 m16n8k16
    # atom, which is sm_80+. Only `kernel_type='warp'` is shipped for
    # these arches; qmma needs hw FP8 MMA.
    if sm == 80 or sm == 86:
        return dtype == "fp8"
    # sm_89 (Ada / L4 / L40S) and sm_120 (consumer Blackwell /
    # RTX-PRO-6000) ship the warp + qmma FP8 kernels — tuned per-GPU
    # in cute_moe_E64_H2048_I1024_fp8_*.json and packaged via
    # _cute_moe_arch_filter in scripts/precompile/cubin_bundles.py.
    if sm == 89 or sm == 120:
        return dtype == "fp8"
    if sm == 100 or sm == 110:
        # B200 / datacenter Blackwell: routed via cute_moe_fp8_sm100_tcgen
        # (kernel_type='tcgen' — TCGen05 GEMM + custom MoE epilogue with
        # per-thread scatter; AOT-shipped via the standard cute_moe bundle).
        return dtype == "fp8"
    # Hopper (sm_90) ships the full set: warp + qmma + wgmma, FP8 + BF16.
    return sm == 90


def _device_supports_cute_moe_pdl(device: torch.device) -> bool:
    # PDL (programmatic dependent launch) was introduced on Hopper
    # (sm_90) via the gdc_launch_dependents / gdc_wait PTX ops; the
    # ops also work on Blackwell consumer (sm_120). We ship PDL
    # cubins for both. sm_89 (Ada) and earlier don't have the ops.
    # Datacenter Blackwell (sm_100/sm_110) is gated OFF here for now:
    # the tcgen kernel ignores `use_pdl`, and we haven't shipped PDL
    # cubins for warp/qmma on sm_100 (`_cute_moe_arch_filter` excludes
    # PDL for sm100/sm110). Re-enable here once those land.
    sm = _device_sm(device)
    return sm == 90 or sm == 91 or sm == 120


def _resolve_backend(
    *,
    device: torch.device,
    num_tokens: int,
    is_fp8: bool,
    num_experts: int,
    input_size: int,
    hidden_size: int,
    backend_pref: str = "auto",
    auto_threshold: int = 256,
) -> str:
    if is_fp8:
        preferred, dtype = "cute", "fp8"
    elif backend_pref == "auto":
        preferred = "triton" if num_tokens >= auto_threshold else "cute"
        dtype = "bf16"
    else:
        preferred, dtype = backend_pref, "bf16"

    if preferred != "cute":
        return preferred
    if not _device_supports_cute_moe_dtype(device, dtype):
        return "triton"
    from kestrel_kernels.cute_moe import has_cute_moe_config
    if has_cute_moe_config(
        num_experts=num_experts, hidden_size=input_size,
        intermediate_size=hidden_size, dtype=dtype,
    ):
        return "cute"
    return "triton"


def get_moe_block_m(
    num_tokens: int,
    *,
    num_experts: int,
    input_size: int,
    hidden_size: int,
    is_fp8: bool,
    backend_pref: str = "auto",
    auto_threshold: int = 256,
    device: torch.device,
) -> int:
    """Return the BLOCK_SIZE_M to use for MoE routing alignment."""
    backend = _resolve_backend(
        device=device, num_tokens=num_tokens, is_fp8=is_fp8,
        num_experts=num_experts, input_size=input_size, hidden_size=hidden_size,
        backend_pref=backend_pref, auto_threshold=auto_threshold,
    )
    if backend == "cute":
        from kestrel_kernels.cute_moe import get_cute_moe_block_m
        return get_cute_moe_block_m(
            num_tokens, num_experts=num_experts, hidden_size=input_size,
            intermediate_size=hidden_size, dtype="fp8" if is_fp8 else "bf16",
        )
    config = get_triton_moe_config(num_experts, hidden_size, num_tokens, fp8=is_fp8)
    if config is not None:
        return config["BLOCK_SIZE_M"]
    return 16


def _get_triton_config(
    num_experts: int, hidden_size: int, num_tokens: int, *, fp8: bool,
) -> dict[str, int]:
    config = get_triton_moe_config(num_experts, hidden_size, num_tokens, fp8=fp8)
    if config is None:
        raise ValueError(
            f"No Triton MoE config for (num_experts={num_experts}, "
            f"hidden_size={hidden_size}, fp8={fp8}). "
            "Run benchmarks/tune_triton_moe.py to generate configs."
        )
    return config


def invoke_moe_gemm(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    B_scale: torch.Tensor | None = None,
    topk_weights: torch.Tensor | None = None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    num_experts: int,
    input_size: int,
    hidden_size: int,
    allow_tf32: bool = True,
    backend_pref: str = "auto",
    auto_threshold: int = 256,
    a_fp8_bits: torch.Tensor | None = None,
    a_fp8_scale: torch.Tensor | None = None,
    config_num_tokens: int | None = None,
) -> None:
    """Dispatch a single MoE GEMM to the best available backend."""
    b_is_fp8 = B.dtype == torch.uint8
    num_tokens = int(C.shape[0])
    # Routing metadata is built with the prepared handle's block_m. Prefill
    # handles may have capacity > active tokens, so config selection can be
    # pinned to that capacity while launch grids still use the active shape.
    config_tokens = (
        int(config_num_tokens) if config_num_tokens is not None else num_tokens
    )
    compute_type = dtype_to_triton(A.dtype)

    backend = _resolve_backend(
        device=A.device, num_tokens=config_tokens, is_fp8=b_is_fp8,
        num_experts=num_experts, input_size=input_size, hidden_size=hidden_size,
        backend_pref=backend_pref, auto_threshold=auto_threshold,
    )

    # --- Triton FP8 W8A8 path ---
    if b_is_fp8 and backend == "triton":
        from kestrel_kernels.fp8_quant_cute import fp8_quant_cute
        fp8_quant_cute(a_fp8_bits, a_fp8_scale, A)

        config = _get_triton_config(
            num_experts, hidden_size, config_tokens, fp8=True
        )
        _triton_fp8(
            a_fp8_bits.view(torch.float8_e4m3fn),
            a_fp8_scale, B.view(torch.float8_e4m3fn), B_scale, C,
            topk_weights=topk_weights,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_post_padded=num_tokens_post_padded,
            mul_routed_weight=mul_routed_weight,
            top_k=top_k,
            config=config,
            compute_type=compute_type,
        )
        return

    # --- CuTe path ---
    if backend == "cute":
        from kestrel_kernels.cute_moe import (
            get_cute_moe_routed_config,
            invoke_cute_moe_down,
            invoke_cute_moe_down_fp8,
            invoke_cute_moe_up,
            invoke_cute_moe_up_fp8,
        )

        kind = "down" if mul_routed_weight else "up"
        cute_config = get_cute_moe_routed_config(
            config_tokens,
            num_experts=num_experts,
            hidden_size=input_size,
            intermediate_size=hidden_size,
            dtype="fp8" if b_is_fp8 else "bf16",
        )[kind]
        if cute_config.kernel_type == "tcgen":
            raise ValueError("tcgen MoE uses the compact full-layer runtime path")
        if b_is_fp8:
            from kestrel_kernels.fp8_quant_cute import fp8_quant_cute
            use_pdl = _device_supports_cute_moe_pdl(A.device)
            fp8_quant_cute(a_fp8_bits, a_fp8_scale, A, use_pdl=use_pdl)
            if mul_routed_weight:
                invoke_cute_moe_down_fp8(
                    a_fp8_bits, a_fp8_scale, B, B_scale, C,
                    topk_weights=topk_weights,
                    sorted_token_ids=sorted_token_ids,
                    expert_ids=expert_ids,
                    num_tokens_post_padded=num_tokens_post_padded,
                    config=cute_config,
                    use_pdl=use_pdl,
                )
            else:
                invoke_cute_moe_up_fp8(
                    a_fp8_bits, a_fp8_scale, B, B_scale, C,
                    sorted_token_ids=sorted_token_ids,
                    expert_ids=expert_ids,
                    num_tokens_post_padded=num_tokens_post_padded,
                    config=cute_config,
                    use_pdl=use_pdl,
                )
            return

        if mul_routed_weight:
            invoke_cute_moe_down(
                A, B, C,
                topk_weights=topk_weights,
                sorted_token_ids=sorted_token_ids,
                expert_ids=expert_ids,
                num_tokens_post_padded=num_tokens_post_padded,
                config=cute_config,
            )
        else:
            invoke_cute_moe_up(
                A, B, C,
                sorted_token_ids=sorted_token_ids,
                expert_ids=expert_ids,
                num_tokens_post_padded=num_tokens_post_padded,
                config=cute_config,
            )
        return

    # --- Triton BF16 path ---
    if b_is_fp8:
        B = (
            B.view(torch.float8_e4m3fn).to(A.dtype)
            * B_scale.to(A.dtype).unsqueeze(-1)
        )

    config = _get_triton_config(
        num_experts, hidden_size, config_tokens, fp8=False
    )
    _triton_bf16(
        A, B, C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=mul_routed_weight,
        top_k=top_k,
        config=config,
        compute_type=compute_type,
        bias=None,
        allow_tf32=allow_tf32,
    )
