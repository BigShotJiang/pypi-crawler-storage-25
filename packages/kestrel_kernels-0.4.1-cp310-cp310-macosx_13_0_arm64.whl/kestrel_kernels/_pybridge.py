"""Python shim for the _pybridge C extension.

On CUDA wheels, CMake compiles a native ``_pybridge.<abi>.so`` (or ``.pyd``
on Windows), and this shim is not installed. Everywhere the C extension is
built, dispatch modules call into the real C code with zero indirection.

On non-CUDA wheels (macOS, CPU-only) CMake skips the extension build and
this shim is what actually gets imported. ``__getattr__`` returns a
callable for any attribute so module-load-time statements like
``from kestrel_kernels._pybridge import rotary_embedding as _raw``
succeed without the CUDA symbol existing. Dispatch modules always guard
the CUDA branch with ``should_use_cuda_impl(...)`` before calling, so
the stub is never actually invoked on non-CUDA devices — if it ever is,
the raise makes the mistake easy to diagnose.
"""


def __getattr__(name: str):
    def _unavailable(*_args, **_kwargs):
        raise RuntimeError(
            f"kestrel_kernels._pybridge.{name} is unavailable on this "
            "platform (CUDA native extension not built). Dispatch code "
            "must guard with should_use_cuda_impl() before invoking."
        )

    return _unavailable
