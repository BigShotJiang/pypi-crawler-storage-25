"""MPS paged-KV cache write.

Routes through the native Metal kernel
``_native.ops.reshape_and_cache_flash_into`` (one dispatch
per call) when shapes/dtypes are supported. Falls back to a Python
loop scatter for shapes the kernel doesn't cover.

Why we used to live in the Python loop: the shared
``reshape_and_cache_flash_torch`` fallback uses advanced-index
assignment patterns (``cache[blocks, offsets, :, :]``) that go
through MPS dispatch paths that don't interact well with PyTorch's
bf16 casts in the write code. The Metal kernel sidesteps the
indexing-pattern problem entirely (one explicit scatter per token)
and folds N dispatches into one.

Callers that read back from the cache shortly after this returns may
need to force materialization (e.g. via ``.to("cpu")`` or
``torch.mps.synchronize()``) — MPS keeps writes queued, and a
``cache[int, int]`` read doesn't always see pending writes until the
command queue drains. The ``tests/mps/test_cache.py`` fixtures
demonstrate the pattern.

FP8 KV is deferred to v2; only ``kv_cache_dtype="auto"`` is supported.
"""

import torch

# Side-effect import: loads the sidecar bridge, the pre-built Metal
# library, and exposes the direct native op surface.
from kestrel_kernels.mps import _native


# Dtypes the Metal kernel ships specializations for.
_NATIVE_DTYPES = (torch.float16, torch.float32)


def reshape_and_cache_flash_mps(
    key: torch.Tensor,
    value: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str,
    k_scale: torch.Tensor,
    v_scale: torch.Tensor,
) -> None:
    """Scatter ``key``/``value`` into paged KV caches indexed by ``slot_mapping``."""
    del k_scale, v_scale  # FP8 only; not supported on MPS v1.
    if kv_cache_dtype != "auto":
        raise NotImplementedError(
            f"kestrel-kernels MPS backend: kv_cache_dtype={kv_cache_dtype!r} "
            "is not supported in v1; only 'auto' (BF16/FP16) is available."
        )
    n_slots = int(slot_mapping.numel())
    # Match the shared fallback's fail-fast behavior — silently
    # dropping trailing tokens on a length mismatch corrupts the cache
    # unobservably.
    if n_slots != int(key.shape[0]) or n_slots != int(value.shape[0]):
        raise ValueError(
            f"slot_mapping and key/value token dimensions must match "
            f"(slots={n_slots}, key={int(key.shape[0])}, "
            f"value={int(value.shape[0])})"
        )
    if n_slots == 0:
        return

    # Native Metal scatter. The kernel-side ``TORCH_CHECK``s in
    # ``mps_ops.mm`` validate the contract; the predicate here is a
    # cheap pre-filter that lets unsupported shapes skip to the
    # fallback rather than raise. ``key/value`` get cast to the cache
    # dtype (no-op when already-matching, which is the production
    # callsite) + made contiguous so the kernel can index linearly.
    if (
        key_cache.dtype in _NATIVE_DTYPES
        and key_cache.dtype == value_cache.dtype
        and key.dim() == 3
        and value.dim() == 3
        and key_cache.dim() == 4
        and value_cache.dim() == 4
        and key_cache.is_contiguous()
        and value_cache.is_contiguous()
    ):
        key_src = key.to(dtype=key_cache.dtype).contiguous()
        value_src = value.to(dtype=value_cache.dtype).contiguous()
        # Normalize ``slot_mapping`` to MPS-int64-1D-contiguous. The
        # prior ``.tolist()`` loop tolerated a CPU ``slot_mapping``
        # (host transfer happened implicitly); the native op enforces
        # same-device on every tensor, so we move it to ``key.device``
        # if needed. Skipping this would make the kernel-side
        # ``TORCH_CHECK`` fail on a CPU slot_mapping that the old path
        # accepted.
        slots_native = slot_mapping
        if (
            slots_native.device != key.device
            or slots_native.dtype != torch.int64
            or not slots_native.is_contiguous()
            or slots_native.dim() != 1
        ):
            slots_native = (
                slots_native.to(device=key.device, dtype=torch.int64)
                .reshape(-1)
                .contiguous()
            )
        _native.ops.reshape_and_cache_flash_into(
            key_src, value_src, key_cache, value_cache, slots_native,
        )
        return

    # Fallback: per-token slice assignment in a Python loop. Slow
    # (one dispatch per token), but reproduces the previous behavior
    # for any shape/dtype the kernel doesn't cover.
    block_size = int(key_cache.shape[1])
    key_src = key.to(dtype=key_cache.dtype)
    value_src = value.to(dtype=value_cache.dtype)
    slots_list = slot_mapping.contiguous().view(-1).to(torch.int64).tolist()
    for i, slot in enumerate(slots_list):
        # Negative slots (commonly ``-1``) mark padded tokens — skip
        # them, matching the CUDA reference semantics. Python's
        # negative indexing would otherwise corrupt the last page.
        if slot < 0:
            continue
        p = slot // block_size
        o = slot - p * block_size
        key_cache[p, o] = key_src[i]
        value_cache[p, o] = value_src[i]
