"""MPS MoE kernels.

``invoke_moe_gemm_mps`` is the unified entrypoint; it mirrors the signature
of ``kestrel_kernels.moe_dispatch.invoke_moe_gemm`` so consumers can use
the runtime's MoE API unchanged. Two backend paths:

- **bf16 weights**: per-expert torch loop — slow but correct, matches
  the Triton kernel's
  ``(sorted_token_ids, expert_ids, num_tokens_post_padded)`` routing
  contract so ``moe_align_block_size`` output passes through unchanged.
- **FP8 weights** (``B.dtype == torch.uint8``, with per-row fp32
  ``B_scale``): native Metal kernel ``moe_fp8_gemm_into`` — three-stage
  dispatch (route → gather GEMM with FP8 dequant + scale epilogue →
  unsort). Brings up Moondream 3 on Apple Silicon.

Helpers ``moe_sum_mps``, ``gelu_residual_cute_mps``, and
``moe_align_block_size_mps`` delegate to the package's existing pure-torch
fallbacks.

Out of v1 scope:
- CuTe MoE variants (``invoke_cute_moe_up/down[_fp8]``) — CUDA-only.
- Activation FP8 quantization (``a_fp8_bits`` / ``a_fp8_scale``) —
  Moondream 3's scheme is weight-only FP8 with bf16 activations.
- Triton MoE (``invoke_fused_moe_kernel_triton[_fp8]``).
- MoE-LoRA (disabled in v1 per docs/MAC_SUPPORT.md).
"""

import os
from typing import Optional

import torch
import torch.nn.functional as F

# Trigger native extension load.
# The bf16 fallback path doesn't need it, but the FP8 path below
# dispatches through native Metal kernels.
from kestrel_kernels.mps import _native

from kestrel_kernels.gelu_residual.fallback import gelu_residual_torch_into
from kestrel_kernels.moe_align.fallback import moe_align_block_size_torch_into
from kestrel_kernels.moe_sum_ops.fallback import moe_sum_torch

# MPS-side block_m picker: ``8`` for decode (M ≤ 32), ``64`` for mid /
# prefill. The kernel ships three tile-config variants picked by
# (block_m, M) at dispatch time — see ``pick_fp8_variant`` in
# ``mps_ops.mm``. ``get_moe_block_m_mps`` and ``invoke_moe_gemm_mps``
# both call this so the routing pad and kernel dispatch stay in sync.
def _pick_block_m(num_tokens: int) -> int:
    return 8 if num_tokens <= 32 else 64


def get_moe_block_m_mps(
    num_tokens: int,
    *,
    num_experts: int,
    input_size: int,
    hidden_size: int,
    is_fp8: bool,
    backend_pref: str = "auto",
    auto_threshold: int = 256,
    device: torch.device,
) -> int:
    del num_experts, input_size, hidden_size
    del is_fp8, backend_pref, auto_threshold, device
    return _pick_block_m(num_tokens)


def moe_sum_mps(inp: torch.Tensor, out: torch.Tensor) -> None:
    moe_sum_torch(inp, out)


def gelu_residual_cute_mps(out: torch.Tensor, inp: torch.Tensor) -> None:
    gelu_residual_torch_into(out=out, inp=inp)


def topk_fwd_mps(
    x: torch.Tensor,
    k: int,
    softmax: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Fused topk + softmax + int32 cast on MPS via Metal kernel.

    Mirrors the CUDA ``topk_bfloat16_n64_k8_softmax`` cubin's contract:
    ``[M, 64]`` bf16 / fp16 in, ``([M, 8] same-dtype, [M, 8] int32)`` out.
    Saves 3-4 torch dispatches per MoE layer (torch.topk + F.softmax +
    .to(int32)) — measurable on decode where each MoE forward fires
    once per layer.

    Falls back to the torch reference when shape / dtype / k / softmax
    don't match the Metal kernel's lock.
    """
    fast_path = (
        x.device.type == "mps"
        and x.is_contiguous()
        and x.ndim == 2
        and x.size(1) == 64
        and k == 8
        and softmax
        and x.dtype == torch.float16
    )
    if not fast_path:
        return _topk_torch_fallback(x, k, softmax=softmax)

    M = x.size(0)
    values = torch.empty((M, k), dtype=x.dtype, device=x.device)
    indices = torch.empty((M, k), dtype=torch.int32, device=x.device)
    _native.ops.moe_topk_softmax_into(x, values, indices)
    return values, indices


def _topk_torch_fallback(
    x: torch.Tensor, k: int, softmax: bool,
) -> tuple[torch.Tensor, torch.Tensor]:
    values, indices = torch.topk(x, k=k, dim=-1)
    if softmax:
        values = torch.softmax(values.float(), dim=-1).to(x.dtype)
    return values, indices.to(torch.int32)


def moe_align_block_size_mps(
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None:
    """Single-dispatch Metal kernel for MoE routing alignment.

    Replaces the per-decode-step ~10-12 MPS dispatch overhead from the
    torch fallback (sort / cumsum / scatter_add / index_copy_ /
    bucketize) with one fused launch. Falls back to the torch
    implementation when the kernel's preconditions don't hold (CPU
    callers, num_experts > 256, non-int32 dtype).
    """
    # Fast path: all preconditions for the Metal kernel must hold.
    # If ANY check fails we drop through to the torch fallback (which
    # tolerates broader inputs — e.g. CPU tensors, non-contiguous,
    # num_experts > 256). Codex P2: the prior gate didn't check
    # output device / contiguity, so a torch-allocated CPU output
    # would slip past and trigger a TORCH_CHECK failure inside the
    # C++ op instead of using the fallback as documented.
    metal_eligible = (
        topk_ids.device.type == "mps"
        and topk_ids.dtype == torch.int32
        and topk_ids.is_contiguous()
        and 0 < num_experts <= 256
        and sorted_token_ids.device.type == "mps"
        and sorted_token_ids.dtype == torch.int32
        and sorted_token_ids.is_contiguous()
        and expert_ids.device.type == "mps"
        and expert_ids.dtype == torch.int32
        and expert_ids.is_contiguous()
        and num_tokens_post_pad.device.type == "mps"
        and num_tokens_post_pad.dtype == torch.int32
        and num_tokens_post_pad.is_contiguous()
    )
    if metal_eligible:
        _native.ops.moe_align_into(
            topk_ids,
            sorted_token_ids,
            expert_ids,
            num_tokens_post_pad,
            int(num_experts),
            int(block_size),
        )
        return
    moe_align_block_size_torch_into(
        topk_ids=topk_ids,
        num_experts=num_experts,
        block_size=block_size,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_pad=num_tokens_post_pad,
    )


def invoke_moe_gemm_mps(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    B_scale: Optional[torch.Tensor] = None,
    topk_weights: Optional[torch.Tensor] = None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    num_experts: int,
    input_size: int,
    hidden_size: int,
    allow_tf32: bool = True,
    backend_pref: str = "auto",
    auto_threshold: int = 256,
    a_fp8_bits: Optional[torch.Tensor] = None,
    a_fp8_scale: Optional[torch.Tensor] = None,
    config_num_tokens: Optional[int] = None,
) -> None:
    """Torch MoE GEMM matching the Triton kernel's routing contract.

    Output ``C`` has shape ``[M, top_k, N]``; each (token, k_slot) position
    receives the output of ``A[token] @ B[expert(token, k_slot)].T``
    (optionally multiplied by ``topk_weights[token, k_slot]`` when
    ``mul_routed_weight``). Slots whose expert is ``-1`` are zeroed.
    """
    # Capture before the del-shadowing below so the fallback path can
    # forward them to the recursive call.
    _num_experts = num_experts
    _input_size = input_size
    _hidden_size = hidden_size
    del allow_tf32, backend_pref, auto_threshold, num_experts
    del input_size, hidden_size, config_num_tokens

    # Activation-FP8 metadata is unsupported on MPS regardless of the
    # weight dtype — both the FP8-weight path and the bf16 fallback
    # ignore these tensors, so passing them silently means caller-side
    # quant intent is dropped. Reject before either branch.
    if a_fp8_bits is not None or a_fp8_scale is not None:
        raise NotImplementedError(
            "kestrel-kernels MPS MoE: activation quantization "
            "(a_fp8_bits / a_fp8_scale) is not supported on MPS. "
            "Only weight-side FP8 (B.dtype == uint8 + B_scale) is "
            "supported; activations must be bf16 / fp16."
        )

    if B.dtype == torch.uint8:
        if B_scale is None:
            raise ValueError(
                "kestrel-kernels MPS FP8 MoE: B_scale is required when "
                "B is uint8 (FP8-packed)."
            )
        if mul_routed_weight and topk_weights is None:
            raise ValueError(
                "invoke_moe_gemm: mul_routed_weight=True requires topk_weights"
            )
        # Optional torch-fallback bypass: dequantize B to A.dtype, then
        # route through the bf16 per-expert F.linear loop below. Used
        # to isolate Metal-kernel bugs from upstream MoE-pipeline bugs.
        # MPS doesn't support Float8_e4m3fn natively, so we detour via
        # CPU for the cast (slow — debug-only).
        if os.environ.get("KESTREL_MPS_FP8_MOE_FALLBACK") == "1":
            B_dq_cpu = (
                B.cpu().view(torch.float8_e4m3fn).to(torch.float32)
                * B_scale.cpu().unsqueeze(-1)
            ).to(A.dtype)
            B_dq = B_dq_cpu.to(A.device)
            return invoke_moe_gemm_mps(
                A, B_dq, C,
                B_scale=None,
                topk_weights=topk_weights,
                sorted_token_ids=sorted_token_ids,
                expert_ids=expert_ids,
                num_tokens_post_padded=num_tokens_post_padded,
                mul_routed_weight=mul_routed_weight,
                top_k=top_k,
                num_experts=_num_experts,
                input_size=_input_size,
                hidden_size=_hidden_size,
            )
        # Padding slots (and slots routed to expert -1) are skipped by
        # the unsort kernel; pre-zeroing C makes those positions zero.
        C.zero_()
        # Recover ``block_m`` from the routing tensors. ``A.shape[0]``
        # differs between the up call (num_tokens) and the down call
        # (num_tokens * top_k), so deriving from M would be wrong.
        #
        # Requires consistency on TWO axes:
        #   1. ``num_blocks == ceil(EM / block_m)`` — the standard
        #      allocation: caller computes
        #      ``max_num_m_blocks = (EM + block_m - 1) // block_m``.
        #   2. ``num_tokens_post_padded % block_m == 0`` — the active
        #      span is aligned to block_m (which is true by
        #      ``moe_align_block_size``'s padded-counts construction).
        #
        # Iterates ``(64, 8)`` candidates in preference order. Pre-fix
        # using strict ``EM == num_blocks * block_m`` rejected valid
        # ceil-div allocations (e.g. EM=36, num_blocks=5, block_m=8 →
        # 5*8=40 ≠ 36).
        em_int = int(sorted_token_ids.shape[0])
        num_blocks_alloc = int(expert_ids.shape[0])
        npp_int = int(num_tokens_post_padded.item())
        block_m = None
        for candidate in (64, 8):
            ceil_blocks = (em_int + candidate - 1) // candidate
            if (
                num_blocks_alloc > 0
                and num_blocks_alloc == ceil_blocks
                and npp_int % candidate == 0
            ):
                block_m = candidate
                break
        if block_m is None:
            raise RuntimeError(
                "kestrel-kernels MPS FP8 MoE: cannot infer block_m. "
                f"sorted_token_ids.shape[0]={em_int}, "
                f"expert_ids.shape[0]={num_blocks_alloc}, "
                f"num_tokens_post_padded={npp_int}. Routing must satisfy "
                "num_blocks == ceil(EM / block_m) AND "
                "num_tokens_post_padded % block_m == 0 with block_m ∈ {8, 64}."
            )
        # Coerce ``topk_weights`` to match A.dtype — the unsort kernel
        # reads it through a ``device T*`` typed loader (T = bf16 / fp16
        # matching A), so a mismatched dtype would misinterpret the
        # bytes. Other MoE backends (CUDA cute / triton) accept fp32
        # topk_weights and cast during the multiply; mirror that here
        # by casting at the boundary instead of rejecting the call.
        # Cost is negligible — topk_weights is shape ``[M, top_k]``,
        # tiny vs the FP8 weight reads.
        if topk_weights is not None and topk_weights.dtype != A.dtype:
            topk_weights = topk_weights.to(A.dtype)
        _native.ops.moe_fp8_gemm_into(
            C, A, B, B_scale,
            topk_weights,
            sorted_token_ids, expert_ids,
            npp_int,
            int(top_k), block_m,
            bool(mul_routed_weight),
        )
        return
    if B_scale is not None:
        raise NotImplementedError(
            "kestrel-kernels MPS MoE: weight scales are only supported "
            "alongside FP8 (uint8) weights in v1."
        )

    # Match CUDA behavior: ``mul_routed_weight`` without ``topk_weights`` is
    # a caller bug — Triton asserts at invoke_fused_moe_kernel line 306 and
    # CuTe raises at _invoke_cute_moe_impl lines 130-132. Silently skipping
    # the weight multiply would return unweighted MoE output.
    if mul_routed_weight and topk_weights is None:
        raise ValueError(
            "invoke_moe_gemm: mul_routed_weight=True requires topk_weights"
        )

    M = int(A.shape[0])
    top_k_i = int(top_k)
    num_valid_tokens = M * top_k_i
    EM = int(sorted_token_ids.shape[0])
    num_blocks = int(expert_ids.shape[0])
    if num_blocks == 0 or M == 0:
        return
    # Recover block_m via the same ceil-div check as the FP8 dispatcher.
    # See comment there for full rationale.
    npp_int = int(num_tokens_post_padded.item())
    block_m = None
    for candidate in (64, 8):
        ceil_blocks = (EM + candidate - 1) // candidate
        if (
            num_blocks > 0
            and num_blocks == ceil_blocks
            and npp_int % candidate == 0
        ):
            block_m = candidate
            break
    if block_m is None:
        block_m = _pick_block_m(M)

    # Respect ``num_tokens_post_padded`` — positions past it may hold stale
    # or uninitialized data (Triton's kernel explicitly bails at
    # ``pid_m * BLOCK_SIZE_M >= num_tokens_post_padded``). Reading beyond
    # would risk routing stale-but-valid-looking entries through real
    # experts.
    num_valid_padded = int(num_tokens_post_padded.item())
    if num_valid_padded <= 0:
        C.zero_()
        return

    # Sync routing metadata to host — typically small compared to M*top_k
    # and lets us index efficiently in Python.
    sti_list = sorted_token_ids.tolist()
    eid_list = expert_ids.tolist()

    # Zero the output first so slots routed to expert -1 (or left unwritten
    # by padding) end up as zero, matching the Triton kernel's behavior.
    C.zero_()

    tw_flat = topk_weights.reshape(-1) if topk_weights is not None else None

    # Bucket valid slots by expert for one GEMM per expert (vectorized).
    slots_by_expert: dict[int, list[int]] = {}
    for block_idx in range(num_blocks):
        block_start = block_idx * block_m
        if block_start >= num_valid_padded:
            break
        expert_id = eid_list[block_idx]
        if expert_id == -1:
            continue
        hi = min(block_start + block_m, num_valid_padded, EM)
        for pos in range(block_start, hi):
            slot = sti_list[pos]
            if slot < num_valid_tokens:
                slots_by_expert.setdefault(int(expert_id), []).append(slot)

    for expert_id, slots in slots_by_expert.items():
        slots_t = torch.tensor(slots, device=A.device, dtype=torch.int64)
        token_ids = slots_t // top_k_i
        k_slots = slots_t - token_ids * top_k_i

        A_rows = A.index_select(0, token_ids)
        W = B[expert_id]
        out = F.linear(A_rows, W)

        if mul_routed_weight and tw_flat is not None:
            w = tw_flat.index_select(0, slots_t).to(out.dtype).unsqueeze(-1)
            out = out * w

        out = out.to(C.dtype)

        # Write via basic int indexing per slot — MPS-safe (matches the
        # pattern used in mps/cache.py for the same kind of scatter).
        token_list = token_ids.tolist()
        k_list = k_slots.tolist()
        for i, (t, k) in enumerate(zip(token_list, k_list)):
            C[t, k] = out[i]


__all__ = [
    "gelu_residual_cute_mps",
    "get_moe_block_m_mps",
    "invoke_moe_gemm_mps",
    "moe_align_block_size_mps",
    "moe_sum_mps",
    "topk_fwd_mps",
]
