"""MPS KernelRuntime.

Subclasses ``KernelRuntime`` and overrides every property so no CUDA-only
import is ever triggered on macOS. Real implementations land module-by-module.
"""

from kestrel_kernels.mps.attention import (
    flash_attn_fwd_mps,
    prefix_lm_mask_730_mps,
)
from kestrel_kernels.mps.cache import reshape_and_cache_flash_mps
from kestrel_kernels.mps.dense import (
    fused_mlp_gelu_bias_residual_cuda_mps,
    layernorm_bias as layernorm_bias_mps,
    layernorm_bias_into as layernorm_bias_into_mps,
)
from kestrel_kernels.mps import moe as mps_moe
from kestrel_kernels.mps.projection import (
    fused_linear_bias_residual_into_mps,
    gelu_cute_mps,
    linear_mps,
)
from kestrel_kernels.mps.rotary import rotary_embedding_mps
from kestrel_kernels.mps.sampling import sample_step_from_logits_mps
from kestrel_kernels.mps.tau import tau_tail_apply_into_mps
from kestrel_kernels.runtime import (
    AttentionRuntime,
    CacheRuntime,
    DenseRuntime,
    GeluRuntime,
    KernelRuntime,
    LinearRuntime,
    MoeRuntime,
    RotaryRuntime,
    SamplingRuntime,
    TauRuntime,
    VisionRuntime,
)


class MPSKernelRuntime(KernelRuntime):
    """PyTorch MPS backend.

    Properties return sub-runtimes populated with real torch-based implementations
    where available. See ``docs/MAC_SUPPORT.md`` for roadmap.
    """

    @property
    def attention(self) -> AttentionRuntime:
        return AttentionRuntime(
            flash_attn_fwd=flash_attn_fwd_mps,
            prefix_lm_mask_730=prefix_lm_mask_730_mps,
        )

    @property
    def moe(self) -> MoeRuntime:
        from kestrel_kernels.moe.dispatch import (
            forward as moe_forward,
            prepare as moe_prepare,
        )
        from kestrel_kernels.moe import prepare_lora_metadata

        return MoeRuntime(
            prepare=moe_prepare,
            forward=moe_forward,
            topk_fwd=mps_moe.topk_fwd_mps,
            prepare_lora_metadata=prepare_lora_metadata,
            supports_lora=lambda *_args, **_kwargs: False,
            reserve_lora_scratch=lambda *_args, **_kwargs: None,
        )

    @property
    def cache(self) -> CacheRuntime:
        return CacheRuntime(
            reshape_and_cache_flash=reshape_and_cache_flash_mps,
        )

    @property
    def rotary(self) -> RotaryRuntime:
        return RotaryRuntime(
            rotary_embedding=rotary_embedding_mps,
        )

    @property
    def tau(self) -> TauRuntime:
        return TauRuntime(
            tau_tail_apply_into=tau_tail_apply_into_mps,
        )

    @property
    def vision(self) -> VisionRuntime:
        return VisionRuntime(
            fused_linear_bias_residual_into=fused_linear_bias_residual_into_mps,
        )

    @property
    def linear(self) -> LinearRuntime:
        return LinearRuntime(linear=linear_mps)

    @property
    def gelu(self) -> GeluRuntime:
        return GeluRuntime(gelu_cute=gelu_cute_mps)

    @property
    def dense(self) -> DenseRuntime:
        return DenseRuntime(
            fused_mlp_gelu_bias_residual=fused_mlp_gelu_bias_residual_cuda_mps,
            layernorm_bias_into=layernorm_bias_into_mps,
            layernorm_bias=layernorm_bias_mps,
        )

    @property
    def sampling(self) -> SamplingRuntime:
        return SamplingRuntime(sample_step_from_logits=sample_step_from_logits_mps)

    @property
    def compute_capability(self) -> tuple[int, int]:
        return (0, 0)

    @property
    def is_sm90(self) -> bool:
        return False


__all__ = ["MPSKernelRuntime"]
