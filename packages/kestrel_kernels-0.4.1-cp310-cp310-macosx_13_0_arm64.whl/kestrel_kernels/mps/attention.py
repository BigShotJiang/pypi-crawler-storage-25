"""MPS flash attention.

Delegates to the shared torch-SDPA fallback
``kestrel_kernels.flash_attn.cute.fallback.flash_attn_fwd_torch_fallback``,
which already handles every variant Kestrel uses (dense/paged ×
causal/prefix-LM-730 × prefill/decode). On MPS the fallback takes the
prefill per-sequence loop even for decode, since the paged-decode path
uses ``torch.compile(flex_attention)`` which doesn't run on the MPS
backend.

The CUDA runtime's ``attention.prefix_lm_mask_730`` is a ``cute.jit``
callable whose ``__cute_hash__`` attribute is the dispatch marker. The
fallback identifies it by hash, not by invoking the callable — so on
MPS we expose a plain Python stub with the same hash attached; if the
stub ever does get called, the raise points cleanly at the logic bug.
"""

from typing import Any, Callable, Optional, Tuple

import torch

# Side-effect import: loads the sidecar bridge + Metal library at first
# use. Required because the
# fallback predicate dispatches to ``flash_attn_dense_into`` /
# ``paged_decode_attn_into`` / ``paged_prefill_attn_into`` for some
# shape combinations on MPS.
from kestrel_kernels.mps import _native as _mps_native_loader
del _mps_native_loader

from kestrel_kernels.flash_attn.cute.fallback import flash_attn_fwd_torch_fallback
from kestrel_kernels.flash_attn.cute.mask_ids import PREFIX_LM_730_MASK_ID


def _prefix_lm_mask_730(*_args: Any, **_kwargs: Any) -> None:
    # Never called on the MPS path — fallback dispatches on __cute_hash__
    # and inlines the mask construction.
    raise RuntimeError(
        "kestrel_kernels.mps.attention.prefix_lm_mask_730 is a dispatch "
        "marker, not a callable; it is identified via __cute_hash__ "
        "in the torch fallback."
    )


_prefix_lm_mask_730.__cute_hash__ = PREFIX_LM_730_MASK_ID  # type: ignore[attr-defined]

prefix_lm_mask_730_mps: Callable[..., Any] = _prefix_lm_mask_730


def flash_attn_fwd_mps(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: Optional[float] = None,
    window_size_left: Optional[int] = None,
    window_size_right: Optional[int] = None,
    learnable_sink: Optional[torch.Tensor] = None,
    m_block_size: int = 128,
    n_block_size: int = 128,
    num_threads: int = 384,
    num_splits: int = 1,
    pack_gqa: Optional[bool] = None,
    compute_capability: Optional[tuple[int, int]] = None,
    score_mod: Optional[Callable] = None,
    mask_mod: Optional[Callable] = None,
    return_lse: bool = False,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    aux_tensors: Optional[list[torch.Tensor]] = None,
    paged_kv_non_tma: Optional[bool] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    """Drop-in replacement for the CUDA ``_flash_attn_fwd`` entrypoint.

    Signature mirrors ``kestrel_kernels.flash_attn.cute.interface._flash_attn_fwd``
    so consumers can use the runtime's attention API unchanged. CUDA-specific
    tuning args (block sizes, thread count, splits, TMA flags, compute-cap
    override) are accepted and ignored — they're meaningless on MPS.
    """
    # CUDA-only tuning knobs: accepted for signature parity, not used.
    del m_block_size, n_block_size, num_threads, num_splits
    del pack_gqa, compute_capability, paged_kv_non_tma

    # Mirror the canonicalization in ``flash_attn/cute/interface._flash_attn_fwd``
    # so drop-in CUDA-style call patterns don't surface as spurious
    # NotImplementedError from the fallback.
    if softcap == 0.0:
        softcap = None
    if window_size_left is not None and window_size_left < 0:
        window_size_left = None
    if window_size_right is not None and window_size_right < 0:
        window_size_right = None
    if mask_mod is None:
        if causal:
            window_size_right = 0
        if window_size_left is not None or window_size_right is not None:
            if window_size_left is None and window_size_right == 0:
                causal = True
                window_size_right = None
            else:
                causal = False
    else:
        causal = False

    if return_lse:
        # The shared torch fallback doesn't emit LSE (see the matching raise
        # for ``lse is not None`` inside ``flash_attn_fwd_torch_fallback``).
        # Silently returning (out, None) would surface as a None deref far
        # from the miscall; fail loud instead.
        raise NotImplementedError(
            "kestrel-kernels MPS backend: return_lse is not supported — the "
            "shared torch fallback doesn't emit log-sum-exp values."
        )

    if out is None:
        # CUDA's entrypoint sizes ``out`` by ``v.shape[-1]`` (head_dim_v),
        # not ``q.shape[-1]`` (head_dim). They're equal for Moondream but
        # the API allows head_dim_v != head_dim. (MPS's SDPA in torch 2.11
        # doesn't itself handle asymmetric head dims, so a caller that
        # actually exercises the asymmetric case will fail inside SDPA
        # before reaching the copy — but sizing ``out`` correctly keeps
        # this wrapper a faithful API match for when MPS catches up.)
        out = torch.empty(
            (*q.shape[:-1], v.shape[-1]),
            dtype=q.dtype,
            device=q.device,
        )

    k_scale_val = 1.0 if k_scale is None else float(k_scale)
    v_scale_val = 1.0 if v_scale is None else float(v_scale)

    return flash_attn_fwd_torch_fallback(
        q=q,
        k=k,
        v=v,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_k=cu_seqlens_k,
        seqused_q=seqused_q,
        seqused_k=seqused_k,
        page_table=page_table,
        softmax_scale=softmax_scale,
        causal=causal,
        softcap=softcap,
        window_size_left=window_size_left,
        window_size_right=window_size_right,
        score_mod=score_mod,
        mask_mod=mask_mod,
        aux_tensors=aux_tensors,
        learnable_sink=learnable_sink,
        out=out,
        lse=lse,
        k_scale=k_scale_val,
        v_scale=v_scale_val,
    )


__all__ = ["flash_attn_fwd_mps", "prefix_lm_mask_730_mps"]
