"""MPS tau-tail per-head Q/V scaling.

Routes through the native Metal kernel registered as
``_native.ops.tau_tail_apply_into``.
"""

import torch

# Side-effect import: loads the sidecar bridge, the pre-built Metal
# library, and exposes the direct native op surface.
from kestrel_kernels.mps import _native


def tau_tail_apply_into_mps(
    *,
    qkv_out: torch.Tensor,
    tok_qv_lin: torch.Tensor,
    tau_pos_table: torch.Tensor,
    position_ids: torch.Tensor,
) -> None:
    """In-place per-head tau scaling on Q and V slices of a fused QKV tensor."""
    _native.ops.tau_tail_apply_into(
        qkv_out, tok_qv_lin, tau_pos_table, position_ids
    )


__all__ = ["tau_tail_apply_into_mps"]
