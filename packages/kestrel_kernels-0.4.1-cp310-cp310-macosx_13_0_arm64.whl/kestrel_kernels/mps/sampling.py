"""MPS sampling — fused Metal kernel behind the canonical
``kestrel_kernels.sampling.sample_step_from_logits`` API.

  ``sample_step_from_logits_mps(logits, temps, top_p, *, out, generator)``
    Logits → token id in one Metal dispatch — temperature scale,
    online softmax (Milakov–Gimelshein), top-K, top-p truncate, and
    exp-race sampling all fused. ~5× the torch chain on M3 (0.13 ms
    vs 0.69 ms / call at V=51200).

Caller-side preconditions (per-row, validated upstream — no on-device
gate). When violated the kernel silently produces biased outputs:

  - ``top_p ≤ 0.95`` (kernel only inspects top-K=64 candidates)
  - ``1e-6 < temperatures ≤ 1.0`` (low-temp keeps the post-temp
    distribution peaked enough that top-K=64 spans the nucleus;
    in-kernel ``1/temp`` is finite)
  - the probability distribution is peaked enough that the top-64
    cumulative mass crosses ``top_p`` (typical for low-temperature
    softmax outputs over a Moondream-class vocabulary)
  - ``V ≥ 64`` (smaller V breaks the top-K assumption)
  - tensors on the same MPS device, contiguous (the wrapper casts
    logits to fp32 if needed; temps / top_p must already be fp32)

In production the kestrel-src scheduler short-circuits all-greedy
batches at admission (``temp == 0`` → ``argmax`` directly) and only
takes the MPS sampling path when temps are positive. Default
settings (``temp=0.2``, ``top_p=0.9``) sit comfortably inside the
kernel's envelope.
"""

import itertools
import torch

# Side-effect import: loads the direct native op surface at first use.
from kestrel_kernels.mps import _native


# Monotonic counter feeding the kernel's in-kernel RNG. Each call gets
# a fresh seed so successive sampling steps draw uncorrelated streams.
# Process-global is fine — the kernel hashes the seed with the batch
# index inside, and concurrent decoders never share batch slots.
_seed_counter = itertools.count(1)


def sample_step_from_logits_mps(
    logits: torch.Tensor,
    temperatures: torch.Tensor,
    top_p: torch.Tensor,
    *,
    out: torch.Tensor | None = None,
    generator: torch.Generator | None = None,
    logprobs_out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Sample token IDs from raw logits via the fused Metal kernel."""
    del generator  # in-kernel Murmur64 RNG — torch.Generator not honoured
    if logprobs_out is not None:
        raise NotImplementedError("MPS sample_step logprobs are not supported yet")
    B = logits.shape[0]
    # Kernel expects fp32 logits (online softmax accumulator is fp32 to
    # avoid catastrophic cancellation at vocab=51200). LM heads often
    # emit fp16; one MPS cast (~50 µs) is still a win vs the torch chain.
    if logits.dtype != torch.float32:
        logits = logits.to(torch.float32)
    if not logits.is_contiguous():
        logits = logits.contiguous()
    if out is None:
        out = torch.empty(B, dtype=torch.long, device=logits.device)
    seed = next(_seed_counter)
    _native.ops.sample_step_into(
        out, logits, temperatures, top_p, seed,
    )
    return out


__all__ = ["sample_step_from_logits_mps"]
