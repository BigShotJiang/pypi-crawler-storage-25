"""TopK dispatch — resolves on first call, then direct function pointer."""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled, warn_fallback_once

_family = CubinFamily("topk_bfloat16_n64_k8_softmax")
_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles


def _topk_torch_fallback(
    x: torch.Tensor, k: int, values: torch.Tensor, indices: torch.Tensor
) -> None:
    """Reference path used when no cubin is shipped for the current arch."""
    raw_values, raw_indices = torch.topk(x, k=k, dim=-1)
    values.copy_(torch.softmax(raw_values.float(), dim=-1).to(x.dtype))
    indices.copy_(raw_indices.to(torch.int32))


def _ensure_variant(x: torch.Tensor) -> bool:
    variant_key = "_default"
    if _family.is_available(variant_key):
        return True
    device_index = int(x.device.index or 0)
    if (variant_key, device_index) in _family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_topk_bfloat16_n64_k8_softmax,
        block_x=128,
        device_index=device_index,
    )
    return True


def topk_fwd(x: torch.Tensor, k: int, softmax: bool = False):
    if not (
        x.is_cuda
        and x.dtype == torch.bfloat16
        and x.ndim == 2
        and x.is_contiguous()
        and x.size(1) == 64
        and k == 8
        and softmax
    ):
        raise ValueError(
            f"topk_fwd only supports bfloat16 contiguous CUDA tensors with "
            f"shape (M, 64), k=8, softmax=True; got dtype={x.dtype}, "
            f"shape={tuple(x.shape)}, k={k}, softmax={softmax}"
        )

    M = x.size(0)
    values = torch.empty((M, k), dtype=x.dtype, device=x.device)
    indices = torch.empty((M, k), dtype=torch.int32, device=x.device)

    if not _ensure_variant(x):
        warn_fallback_once(
            "topk_fwd_no_cubin",
            "kestrel-kernels: no topk cubin bundle for the current CUDA "
            "architecture; using PyTorch fallback.",
        )
        _topk_torch_fallback(x, k, values, indices)
        return values, indices

    _family.resolve_dispatch(x, grid_x=ceil_div(M, 128))(x, values, indices)
    return values, indices


__all__ = ["topk_fwd"]
