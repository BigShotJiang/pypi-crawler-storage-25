"""Shared MoE data structures and weight normalization."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

import torch


MoeWeightFormat = Literal["bf16", "fp16", "fp32", "fp8_e4m3", "nvfp4"]
MoeMode = Literal["decode", "prefill", "eager", "benchmark"]
MoeActivation = Literal["gelu"]


@dataclass(frozen=True)
class MoeSpec:
    num_experts: int
    top_k: int
    hidden_size: int
    intermediate_size: int
    activation: MoeActivation = "gelu"
    weight_format: MoeWeightFormat = "bf16"
    dtype: torch.dtype = torch.bfloat16
    allow_tf32: bool = True
    backend: str = "auto"
    auto_backend_token_threshold: int = 256

    def __post_init__(self) -> None:
        if self.num_experts <= 0:
            raise ValueError("num_experts must be positive")
        if self.top_k <= 0:
            raise ValueError("top_k must be positive")
        if self.hidden_size <= 0:
            raise ValueError("hidden_size must be positive")
        if self.intermediate_size <= 0:
            raise ValueError("intermediate_size must be positive")
        if self.activation != "gelu":
            raise ValueError(f"unsupported MoE activation: {self.activation!r}")
        if self.weight_format not in ("bf16", "fp16", "fp32", "fp8_e4m3", "nvfp4"):
            raise ValueError(f"unsupported MoE weight format: {self.weight_format!r}")
        if self.weight_format == "nvfp4":
            raise NotImplementedError("NVFP4 MoE weights are planned but not implemented")


@dataclass(frozen=True)
class MoeCapacity:
    max_tokens: int
    max_loras: int = 0
    max_lora_rank: int = 0
    mode: MoeMode = "decode"

    def __post_init__(self) -> None:
        if self.max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        if self.max_loras < 0:
            raise ValueError("max_loras must be non-negative")
        if self.max_lora_rank < 0:
            raise ValueError("max_lora_rank must be non-negative")
        if self.mode not in ("decode", "prefill", "eager", "benchmark"):
            raise ValueError(f"unsupported MoE capacity mode: {self.mode!r}")


@dataclass(frozen=True)
class MoeExpertWeights:
    up: torch.Tensor
    down: torch.Tensor
    up_scale: torch.Tensor | None = None
    down_scale: torch.Tensor | None = None
    format: MoeWeightFormat | None = None


@dataclass(frozen=True)
class MoeLoraMetadata:
    active_token_ids: torch.Tensor
    active_lora_ids: torch.Tensor
    active_lora_meta: torch.Tensor
    active_lora_max_rank: int | None = None


@dataclass(frozen=True)
class MoeLoraState:
    up_a: torch.Tensor
    up_b: torch.Tensor
    down_a: torch.Tensor
    down_b: torch.Tensor
    metadata: MoeLoraMetadata
    lora_ranks: torch.Tensor | None = None


@dataclass(frozen=True)
class MoeHandle:
    spec: MoeSpec
    capacity: MoeCapacity
    device: torch.device
    impl: Any


def _infer_weight_format(up: torch.Tensor, down: torch.Tensor) -> MoeWeightFormat:
    if up.dtype != down.dtype:
        raise ValueError("up and down expert weights must use the same dtype")
    if up.dtype == torch.uint8 or up.dtype == torch.float8_e4m3fn:
        return "fp8_e4m3"
    if up.dtype == torch.bfloat16:
        return "bf16"
    if up.dtype == torch.float16:
        return "fp16"
    if up.dtype == torch.float32:
        return "fp32"
    raise ValueError(f"unsupported MoE expert weight dtype: {up.dtype}")


def _validate_weight_format(
    spec: MoeSpec,
    up: torch.Tensor,
    down: torch.Tensor,
) -> MoeWeightFormat:
    inferred = _infer_weight_format(up, down)
    if spec.weight_format != inferred:
        if not (spec.weight_format == "fp8_e4m3" and inferred == "fp8_e4m3"):
            raise ValueError(
                f"MoeSpec weight_format={spec.weight_format!r} does not match "
                f"expert tensors ({inferred!r})"
            )
    return inferred


def pack_weights(
    spec: MoeSpec,
    raw_weights: MoeExpertWeights | tuple[torch.Tensor, torch.Tensor] | None = None,
    *,
    up: torch.Tensor | None = None,
    down: torch.Tensor | None = None,
    up_scale: torch.Tensor | None = None,
    down_scale: torch.Tensor | None = None,
) -> MoeExpertWeights:
    """Normalize expert weights for ``forward``.

    Phase 1 keeps the tensors in their existing layout.  Later NVFP4 /
    grouped-GEMM prepacking should be added here rather than changing the
    ``forward`` signature.
    """
    if isinstance(raw_weights, MoeExpertWeights):
        inferred = _validate_weight_format(spec, raw_weights.up, raw_weights.down)
        if raw_weights.format is not None and raw_weights.format != inferred:
            raise ValueError(
                f"MoeExpertWeights format={raw_weights.format!r} does not match "
                f"expert tensors ({inferred!r})"
            )
        if raw_weights.format == inferred:
            return raw_weights
        return MoeExpertWeights(
            up=raw_weights.up,
            down=raw_weights.down,
            up_scale=raw_weights.up_scale,
            down_scale=raw_weights.down_scale,
            format=inferred,
        )
    if raw_weights is not None:
        if up is not None or down is not None:
            raise ValueError("pass either raw_weights or up/down, not both")
        up, down = raw_weights
    if up is None or down is None:
        raise ValueError("up and down expert weights are required")

    inferred = _validate_weight_format(spec, up, down)
    return MoeExpertWeights(
        up=up,
        down=down,
        up_scale=up_scale,
        down_scale=down_scale,
        format=inferred,
    )


def prepare_lora_metadata(
    *,
    lora_slot_ids_cpu: torch.Tensor,
    active_token_ids_cpu: torch.Tensor,
    active_token_ids_gpu: torch.Tensor,
    active_lora_ids_cpu: torch.Tensor,
    active_lora_ids_gpu: torch.Tensor,
    active_lora_meta_cpu: torch.Tensor,
    active_lora_meta_gpu: torch.Tensor,
    batch_size: int,
    max_loras: int,
    lora_ranks_host: Sequence[int] | None = None,
    active_lora_max_rank: int | None = None,
    fixed_capacity: bool = False,
) -> MoeLoraMetadata:
    batch_size = int(batch_size)
    max_loras = int(max_loras)
    if batch_size < 0 or max_loras < 0:
        raise ValueError("batch_size and max_loras must be non-negative")

    active_lora_meta_cpu[: max_loras + 4].zero_()

    lora_to_route = [-1] * max_loras
    tokens_by_route: list[list[int]] = []
    active_count = 0
    active_max_rank = 0
    for token_idx, slot_id in enumerate(lora_slot_ids_cpu[:batch_size].tolist()):
        slot_int = int(slot_id)
        if slot_int <= 0:
            continue
        lora_id = slot_int - 1
        if lora_id >= max_loras:
            raise ValueError("lora_slot_ids_cpu contains LoRA id outside max_loras")
        route_id = lora_to_route[lora_id]
        if route_id < 0:
            route_id = active_count
            lora_to_route[lora_id] = route_id
            active_lora_ids_cpu[active_count] = lora_id
            tokens_by_route.append([])
            active_count += 1
            if lora_ranks_host is not None:
                if lora_id >= len(lora_ranks_host):
                    raise ValueError("lora_ranks_host must cover every active LoRA id")
                active_max_rank = max(active_max_rank, int(lora_ranks_host[lora_id]))
        tokens_by_route[route_id].append(token_idx)

    if active_count and lora_ranks_host is None:
        if active_lora_max_rank is None:
            raise ValueError(
                "active LoRA metadata requires lora_ranks_host or active_lora_max_rank"
            )
        active_max_rank = int(active_lora_max_rank)

    active_lora_meta_cpu[0] = active_count
    active_lora_meta_cpu[1] = active_max_rank
    active_token_count = 0
    for route_id, token_ids in enumerate(tokens_by_route):
        active_lora_meta_cpu[3 + route_id] = active_token_count
        for token_idx in token_ids:
            active_token_ids_cpu[active_token_count] = token_idx
            active_token_count += 1
    active_lora_meta_cpu[2] = active_token_count
    active_lora_meta_cpu[3 + active_count] = active_token_count
    meta_len = 4 + (max_loras if fixed_capacity else active_count)
    active_lora_meta_gpu[:meta_len].copy_(
        active_lora_meta_cpu[:meta_len], non_blocking=True
    )
    if active_count:
        active_lora_ids_gpu[:active_count].copy_(
            active_lora_ids_cpu[:active_count], non_blocking=True
        )
    if active_token_count:
        active_token_ids_gpu[:active_token_count].copy_(
            active_token_ids_cpu[:active_token_count], non_blocking=True
        )

    metadata_rank = active_lora_max_rank
    if metadata_rank is None and not fixed_capacity:
        metadata_rank = active_max_rank

    return MoeLoraMetadata(
        active_token_ids=active_token_ids_gpu[:batch_size if fixed_capacity else active_token_count],
        active_lora_ids=active_lora_ids_gpu[:max_loras if fixed_capacity else active_count],
        active_lora_meta=active_lora_meta_gpu[:meta_len],
        active_lora_max_rank=metadata_rank,
    )


__all__ = [
    "MoeActivation",
    "MoeCapacity",
    "MoeExpertWeights",
    "MoeHandle",
    "MoeLoraMetadata",
    "MoeLoraState",
    "MoeMode",
    "MoeSpec",
    "MoeWeightFormat",
    "pack_weights",
    "prepare_lora_metadata",
]
