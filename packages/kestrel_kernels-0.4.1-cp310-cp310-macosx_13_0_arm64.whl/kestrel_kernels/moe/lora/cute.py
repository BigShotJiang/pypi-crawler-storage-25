"""CuTe MoE LoRA apply kernels."""

from dataclasses import dataclass

import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled


_family = CubinFamily("moe_lora")
_WARPS_PER_BLOCK = 4
_THREADS = _WARPS_PER_BLOCK * 32
_REQUIRED_VARIANTS = (
    "shrink_bf16_w4_Kdyn",
    "up_gelu_bf16_w4_Ndyn",
    "down_sum_bf16_twbf16_w4_Ndyn",
    "down_sum_bf16_twfp32_w4_Ndyn",
)
# Tried shrink cap=64 with the old add kernel: same 256-token
# per-expert-rank-8 apply time as shrink cap=32 on RTX 3090; keeping 32.
_SHRINK_BLOCKS_PER_SM = 32
# Finish cap is not revalidated for the fused finalizers; decode shapes do not
# hit the cap in the B200/3090 graph benchmarks in this PR.
_FINISH_BLOCKS_PER_SM = 8
_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles

_EMPTY_I32_CACHE: dict[int, torch.Tensor] = {}
_SM_COUNT_CACHE: dict[int, int] = {}


@dataclass(frozen=True)
class _MoeLoraVariant:
    kind: str
    topk_weight_dtype: str = "bf16"
    warps_per_block: int = 4
    in_dim: int | None = None
    out_dim: int | None = None

    @property
    def variant_key(self) -> str:
        if self.kind == "shrink":
            in_suffix = f"_K{self.in_dim}" if self.in_dim is not None else "_Kdyn"
            return f"shrink_bf16_w{self.warps_per_block}{in_suffix}"
        if self.kind == "up_gelu":
            out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
            return f"up_gelu_bf16_w{self.warps_per_block}{out_suffix}"
        if self.kind == "down_sum":
            suffix = "twfp32" if self.topk_weight_dtype == "fp32" else "twbf16"
            out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
            return f"down_sum_bf16_{suffix}_w{self.warps_per_block}{out_suffix}"
        suffix = "twfp32" if self.topk_weight_dtype == "fp32" else "twbf16"
        out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
        return f"{self.kind}_bf16_{suffix}_w{self.warps_per_block}{out_suffix}"


def _device_key(device: torch.device) -> int:
    return int(device.index or 0)


def _empty_i32(device: torch.device) -> torch.Tensor:
    key = _device_key(device)
    out = _EMPTY_I32_CACHE.get(key)
    if out is None:
        out = torch.empty((0,), dtype=torch.int32, device=device)
        _EMPTY_I32_CACHE[key] = out
    return out


def _sm_count(device: torch.device) -> int:
    key = _device_key(device)
    count = _SM_COUNT_CACHE.get(key)
    if count is None:
        count = int(torch.cuda.get_device_properties(device).multi_processor_count)
        _SM_COUNT_CACHE[key] = count
    return count


def _worker_grid(device: torch.device, blocks: int, blocks_per_sm: int) -> int:
    if blocks <= 0:
        return 1
    cap = max(1, _sm_count(device) * int(blocks_per_sm))
    return max(1, min(int(blocks), cap))


def supports_moe_lora(device: torch.device | str | None = None) -> bool:
    if device is None:
        if not torch.cuda.is_available():
            return False
        device = torch.device("cuda", torch.cuda.current_device())
    else:
        device = torch.device(device)
    if device.type != "cuda" or not torch.cuda.is_available():
        return False
    if _ENABLE_JIT:
        return True
    device_index = int(torch.cuda.current_device() if device.index is None else device.index)
    major, minor = torch.cuda.get_device_capability(device_index)
    arch = f"sm{major}{minor}"
    return all(
        _family._resolve_variant_entry(key, arch) is not None
        for key in _REQUIRED_VARIANTS
    )


def _rank_limit(lora_a: torch.Tensor, active_lora_max_rank: int | None) -> int:
    storage_rank = int(lora_a.shape[1])
    if active_lora_max_rank is None:
        return storage_rank
    return min(storage_rank, max(0, int(active_lora_max_rank)))


def _variant(
    kind: str,
    topk_weights: torch.Tensor | None = None,
    *,
    in_dim: int | None = None,
    out_dim: int | None = None,
) -> _MoeLoraVariant:
    dtype = (
        "fp32"
        if kind == "down_sum"
        and topk_weights is not None
        and topk_weights.dtype == torch.float32
        else "bf16"
    )
    return _MoeLoraVariant(
        kind=kind,
        topk_weight_dtype=dtype,
        warps_per_block=_WARPS_PER_BLOCK,
        in_dim=in_dim,
        out_dim=out_dim,
    )


def _variant_available(variant: _MoeLoraVariant, x: torch.Tensor) -> bool:
    key = variant.variant_key
    device_index = int(x.device.index or 0)
    return _family.is_available(key) or (key, device_index) in _family._handles


def _ensure_variant(variant: _MoeLoraVariant, x: torch.Tensor) -> str:
    key = variant.variant_key
    device_index = int(x.device.index or 0)
    if _family.is_available(key) or (key, device_index) in _family._handles:
        return key
    if not _ENABLE_JIT:
        raise RuntimeError(
            f"No moe_lora cubin variant for {key}; rebuild bundles or set KESTREL_CUTE_JIT=1"
        )
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=key,
        compile_fn=_cubin_bundles._compile_moe_lora(variant),
        block_x=_THREADS,
        device_index=device_index,
    )
    return key


def _ensure_shrink_variant(x: torch.Tensor) -> str:
    specialized = _variant("shrink", in_dim=int(x.shape[1]))
    if _ENABLE_JIT or _variant_available(specialized, x):
        return _ensure_variant(specialized, x)
    return _ensure_variant(_variant("shrink"), x)


def _ensure_finish_variant(
    kind: str,
    out_dim: int,
    x: torch.Tensor,
    topk_weights: torch.Tensor | None = None,
) -> str:
    specialized = _variant(kind, topk_weights, out_dim=out_dim)
    if _ENABLE_JIT or _variant_available(specialized, x):
        return _ensure_variant(specialized, x)
    return _ensure_variant(_variant(kind, topk_weights), x)


def _validate_i32_1d(name: str, tensor: torch.Tensor, device: torch.device) -> None:
    if (
        tensor.device != device
        or tensor.dtype != torch.int32
        or tensor.ndim != 1
        or not tensor.is_contiguous()
    ):
        raise ValueError(f"{name} must be a contiguous int32 tensor on the LoRA device")


def _validate_metadata(
    *,
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    lora_a: torch.Tensor,
    lora_b: torch.Tensor,
    active_token_ids: torch.Tensor,
    active_lora_ids: torch.Tensor,
    active_lora_meta: torch.Tensor,
) -> None:
    tensors = (
        x,
        topk_ids,
        lora_a,
        lora_b,
        active_token_ids,
        active_lora_ids,
        active_lora_meta,
    )
    if any(t.device != x.device for t in tensors):
        raise ValueError("all MoE LoRA tensors must be on the same device")
    if x.device.type != "cuda":
        raise ValueError("CuTe MoE LoRA requires CUDA tensors")
    if x.dtype != torch.bfloat16:
        raise ValueError("CuTe MoE LoRA currently supports BF16 activations")
    if lora_a.dtype != torch.bfloat16 or lora_b.dtype != torch.bfloat16:
        raise ValueError("CuTe MoE LoRA currently supports BF16 LoRA weights")
    if topk_ids.dtype != torch.int32:
        raise ValueError("topk_ids must be int32")
    if active_lora_meta.ndim != 1 or active_lora_meta.numel() < 4:
        raise ValueError(
            "active_lora_meta must contain counts and active-token offsets"
        )
    if not all(t.is_contiguous() for t in tensors):
        raise ValueError("CuTe MoE LoRA tensors must be contiguous")
    _validate_i32_1d("active_token_ids", active_token_ids, x.device)
    _validate_i32_1d("active_lora_ids", active_lora_ids, x.device)
    _validate_i32_1d("active_lora_meta", active_lora_meta, x.device)


def _validate_topk(
    *,
    topk_ids: torch.Tensor,
    top_k: int,
) -> tuple[int, int, int, int]:
    input_top_k = int(top_k)
    output_top_k = int(topk_ids.shape[1])
    if (
        input_top_k <= 0
        or output_top_k <= 0
        or (input_top_k & (input_top_k - 1)) != 0
        or (output_top_k & (output_top_k - 1)) != 0
    ):
        raise ValueError("CuTe MoE LoRA requires power-of-two top_k")
    input_top_k_log2 = input_top_k.bit_length() - 1
    output_top_k_log2 = output_top_k.bit_length() - 1
    output_top_k_mask = output_top_k - 1
    return input_top_k_log2, output_top_k_log2, output_top_k_mask, output_top_k


def _validate_scratch(
    *,
    scratch: torch.Tensor,
    x: torch.Tensor,
    rows: int,
    storage_rank: int,
) -> None:
    if scratch.device != x.device or scratch.dtype != torch.bfloat16 or not scratch.is_contiguous():
        raise ValueError("scratch must be contiguous BF16 on the LoRA device")
    if (
        scratch.ndim != 2
        or int(scratch.shape[0]) != rows
        or int(scratch.shape[1]) < storage_rank
    ):
        raise ValueError("scratch must have shape [tokens * top_k, storage_lora_rank]")


def _ranks_tensor(
    x: torch.Tensor,
    lora_ranks: torch.Tensor | None,
) -> torch.Tensor:
    ranks = lora_ranks if lora_ranks is not None else _empty_i32(x.device)
    if ranks.device != x.device or ranks.dtype != torch.int32 or not ranks.is_contiguous():
        raise ValueError("lora_ranks must be a contiguous int32 tensor on the LoRA device")
    return ranks


def _run_shrink(
    *,
    x: torch.Tensor,
    lora_a: torch.Tensor,
    topk_ids: torch.Tensor,
    active_token_ids: torch.Tensor,
    active_lora_ids: torch.Tensor,
    active_lora_meta: torch.Tensor,
    scratch: torch.Tensor,
    input_top_k_log2: int,
    output_top_k_log2: int,
    output_top_k_mask: int,
    output_top_k: int,
    num_experts: int,
    ranks: torch.Tensor,
    rank: int,
) -> None:
    active_token_capacity = int(active_token_ids.numel())
    if active_token_capacity == 0 or int(active_lora_ids.numel()) == 0 or rank <= 0:
        return
    assignment_capacity = active_token_capacity * output_top_k
    shrink_key = _ensure_shrink_variant(x)
    shrink_grid = _worker_grid(
        x.device,
        ceil_div(assignment_capacity * rank, _WARPS_PER_BLOCK),
        _SHRINK_BLOCKS_PER_SM,
    )
    _family.resolve_dispatch(x, variant_key=shrink_key, grid_x=shrink_grid)(
        x,
        lora_a,
        topk_ids,
        active_token_ids,
        active_lora_ids,
        ranks,
        active_lora_meta,
        scratch,
        int(input_top_k_log2),
        int(output_top_k_log2),
        int(output_top_k_mask),
        int(num_experts),
        int(assignment_capacity),
        int(rank),
    )


@torch.inference_mode()
def apply_moe_lora_up_gelu(
    *,
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    base_up: torch.Tensor,
    activation: torch.Tensor,
    lora_a: torch.Tensor,
    lora_b: torch.Tensor,
    active_token_ids: torch.Tensor,
    active_lora_ids: torch.Tensor,
    active_lora_meta: torch.Tensor,
    top_k: int,
    num_experts: int,
    scratch: torch.Tensor,
    lora_ranks: torch.Tensor | None = None,
    active_lora_max_rank: int | None = None,
) -> None:
    _validate_metadata(
        x=x,
        topk_ids=topk_ids,
        lora_a=lora_a,
        lora_b=lora_b,
        active_token_ids=active_token_ids,
        active_lora_ids=active_lora_ids,
        active_lora_meta=active_lora_meta,
    )
    if base_up.device != x.device or activation.device != x.device:
        raise ValueError("base_up and activation must be on the LoRA device")
    if base_up.dtype != torch.bfloat16 or activation.dtype != torch.bfloat16:
        raise ValueError("base_up and activation must be BF16")
    if base_up.ndim != 3:
        raise ValueError("base_up must have shape [tokens, top_k, 2 * intermediate]")
    if not base_up.is_contiguous() or not activation.is_contiguous():
        raise ValueError("base_up and activation must be contiguous")
    if topk_ids.ndim != 2 or tuple(topk_ids.shape) != tuple(base_up.shape[:2]):
        raise ValueError("topk_ids must have shape [tokens, top_k] matching base_up")
    output_dim = int(base_up.shape[2])
    if output_dim % 2 != 0:
        raise ValueError("base_up output dimension must be even")
    intermediate = output_dim // 2
    if tuple(activation.shape) != (int(base_up.shape[0]) * int(base_up.shape[1]), intermediate):
        raise ValueError("activation must have shape [tokens * top_k, intermediate]")
    if int(lora_b.shape[1]) != output_dim:
        raise ValueError("lora_b must have shape [super_experts, 2 * intermediate, rank]")

    input_top_k_log2, output_top_k_log2, output_top_k_mask, output_top_k = _validate_topk(
        topk_ids=topk_ids,
        top_k=top_k,
    )
    storage_rank = int(lora_a.shape[1])
    if int(lora_b.shape[2]) < storage_rank:
        raise ValueError("lora_b rank dimension must cover lora_a rank")
    _validate_scratch(
        scratch=scratch,
        x=x,
        rows=int(base_up.shape[0]) * int(base_up.shape[1]),
        storage_rank=storage_rank,
    )
    ranks = _ranks_tensor(x, lora_ranks)
    rank = _rank_limit(lora_a, active_lora_max_rank)
    _run_shrink(
        x=x,
        lora_a=lora_a,
        topk_ids=topk_ids,
        active_token_ids=active_token_ids,
        active_lora_ids=active_lora_ids,
        active_lora_meta=active_lora_meta,
        scratch=scratch,
        input_top_k_log2=input_top_k_log2,
        output_top_k_log2=output_top_k_log2,
        output_top_k_mask=output_top_k_mask,
        output_top_k=output_top_k,
        num_experts=num_experts,
        ranks=ranks,
        rank=rank,
    )

    key = _ensure_finish_variant("up_gelu", output_dim, x)
    col_blocks = ceil_div(intermediate, 32)
    grid = _worker_grid(
        x.device,
        ceil_div(int(base_up.shape[0]) * output_top_k * col_blocks, _WARPS_PER_BLOCK),
        _FINISH_BLOCKS_PER_SM,
    )
    _family.resolve_dispatch(x, variant_key=key, grid_x=grid)(
        base_up,
        scratch,
        lora_b,
        topk_ids,
        active_token_ids,
        active_lora_ids,
        ranks,
        active_lora_meta,
        activation,
        int(num_experts),
        int(output_top_k_log2),
        int(output_top_k_mask),
        int(int(base_up.shape[0]) * output_top_k),
        int(rank),
    )


@torch.inference_mode()
def apply_moe_lora_down_sum(
    *,
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    topk_weights: torch.Tensor,
    base_down: torch.Tensor,
    output: torch.Tensor,
    lora_a: torch.Tensor,
    lora_b: torch.Tensor,
    active_token_ids: torch.Tensor,
    active_lora_ids: torch.Tensor,
    active_lora_meta: torch.Tensor,
    top_k: int,
    num_experts: int,
    scratch: torch.Tensor,
    lora_ranks: torch.Tensor | None = None,
    active_lora_max_rank: int | None = None,
) -> None:
    _validate_metadata(
        x=x,
        topk_ids=topk_ids,
        lora_a=lora_a,
        lora_b=lora_b,
        active_token_ids=active_token_ids,
        active_lora_ids=active_lora_ids,
        active_lora_meta=active_lora_meta,
    )
    tensors = (topk_weights, base_down, output)
    if any(t.device != x.device for t in tensors):
        raise ValueError("topk_weights, base_down, and output must be on the LoRA device")
    if topk_weights.dtype not in (torch.bfloat16, torch.float32):
        raise ValueError("topk_weights must be BF16 or FP32")
    if base_down.dtype != torch.bfloat16 or output.dtype != torch.bfloat16:
        raise ValueError("base_down and output must be BF16")
    if base_down.ndim != 3:
        raise ValueError("base_down must have shape [tokens, top_k, hidden]")
    if output.ndim != 2 or tuple(output.shape) != (int(base_down.shape[0]), int(base_down.shape[2])):
        raise ValueError("output must have shape [tokens, hidden]")
    expected_topk_shape = tuple(base_down.shape[:2])
    if topk_ids.ndim != 2 or tuple(topk_ids.shape) != expected_topk_shape:
        raise ValueError("topk_ids must have shape [tokens, top_k] matching base_down")
    if topk_weights.ndim != 2 or tuple(topk_weights.shape) != expected_topk_shape:
        raise ValueError("topk_weights must have shape [tokens, top_k] matching base_down")
    if not all(t.is_contiguous() for t in tensors):
        raise ValueError("topk_weights, base_down, and output must be contiguous")

    input_top_k_log2, output_top_k_log2, output_top_k_mask, output_top_k = _validate_topk(
        topk_ids=topk_ids,
        top_k=top_k,
    )
    output_dim = int(base_down.shape[2])
    storage_rank = int(lora_a.shape[1])
    if int(lora_b.shape[1]) != output_dim or int(lora_b.shape[2]) < storage_rank:
        raise ValueError("lora_b must have shape [super_experts, hidden, rank]")
    _validate_scratch(
        scratch=scratch,
        x=x,
        rows=int(base_down.shape[0]) * int(base_down.shape[1]),
        storage_rank=storage_rank,
    )
    ranks = _ranks_tensor(x, lora_ranks)
    rank = _rank_limit(lora_a, active_lora_max_rank)
    _run_shrink(
        x=x,
        lora_a=lora_a,
        topk_ids=topk_ids,
        active_token_ids=active_token_ids,
        active_lora_ids=active_lora_ids,
        active_lora_meta=active_lora_meta,
        scratch=scratch,
        input_top_k_log2=input_top_k_log2,
        output_top_k_log2=output_top_k_log2,
        output_top_k_mask=output_top_k_mask,
        output_top_k=output_top_k,
        num_experts=num_experts,
        ranks=ranks,
        rank=rank,
    )

    key = _ensure_finish_variant("down_sum", output_dim, x, topk_weights)
    col_blocks = ceil_div(output_dim, 32)
    grid = _worker_grid(
        x.device,
        ceil_div(int(base_down.shape[0]) * col_blocks, _WARPS_PER_BLOCK),
        _FINISH_BLOCKS_PER_SM,
    )
    _family.resolve_dispatch(x, variant_key=key, grid_x=grid)(
        base_down,
        scratch,
        lora_b,
        topk_ids,
        active_token_ids,
        active_lora_ids,
        ranks,
        active_lora_meta,
        topk_weights,
        output,
        int(num_experts),
        int(output_top_k_log2),
        int(output_top_k_mask),
        int(base_down.shape[0]),
        int(rank),
    )


__all__ = [
    "apply_moe_lora_down_sum",
    "apply_moe_lora_up_gelu",
    "supports_moe_lora",
]
