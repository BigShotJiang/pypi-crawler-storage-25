"""CuTe DSL kernels for routed MoE LoRA deltas."""

from dataclasses import dataclass

import cuda.bindings.driver as cuda
import cutlass.cute as cute
from cutlass import BFloat16, Float32, Int32, const_expr
from cutlass.cutlass_dsl import dsl_user_op
from cutlass._mlir.dialects import math as mlir_math


@cute.jit
def _warp_reduce_sum_f32(val: Float32) -> Float32:
    return cute.arch.warp_reduction_sum(val, threads_in_group=32)


@dsl_user_op
def _erf_f32(x: Float32, *, loc=None, ip=None) -> Float32:
    return Float32(
        mlir_math.erf(
            Float32(x).ir_value(loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )
    )


@dsl_user_op
def _fma_f32(a: Float32, b: Float32, c: Float32, *, loc=None, ip=None) -> Float32:
    return Float32(
        mlir_math.fma(
            Float32(a).ir_value(loc=loc, ip=ip),
            Float32(b).ir_value(loc=loc, ip=ip),
            Float32(c).ir_value(loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )
    )


@cute.jit
def _gelu_f32(x: Float32) -> Float32:
    sqrt_half = Float32(0.7071067811865476)
    half = Float32(0.5)
    erf_val = _erf_f32(x * sqrt_half)
    return _fma_f32(half * erf_val, x, half * x)


@cute.jit
def _active_weight_lora_id_for_token(
    token: Int32,
    mActiveTokenIds: cute.Tensor,
    mWeightLoraIds: cute.Tensor,
    mActiveLoraMeta: cute.Tensor,
) -> Int32:
    active_lora_count = Int32(mActiveLoraMeta[0])
    active_token_count = Int32(mActiveLoraMeta[2])
    if active_lora_count > Int32(mWeightLoraIds.shape[0]):
        active_lora_count = Int32(mWeightLoraIds.shape[0])
    meta_loras = Int32(mActiveLoraMeta.shape[0]) - Int32(4)
    if active_lora_count > meta_loras:
        active_lora_count = meta_loras
    if active_token_count > Int32(mActiveTokenIds.shape[0]):
        active_token_count = Int32(mActiveTokenIds.shape[0])

    found = Int32(-1)
    if active_lora_count == Int32(1):
        token_start = Int32(mActiveLoraMeta[3])
        token_end = Int32(mActiveLoraMeta[4])
        if (
            token_start == Int32(0)
            and token >= Int32(0)
            and token < token_end
            and token < active_token_count
            and Int32(mActiveTokenIds[token]) == token
        ):
            found = Int32(mWeightLoraIds[0])
    if found < Int32(0):
        for active_idx in range(active_lora_count):
            token_start = Int32(mActiveLoraMeta[3 + active_idx])
            token_end = Int32(mActiveLoraMeta[4 + active_idx])
            if token_start < Int32(0):
                token_start = Int32(0)
            if token_end > active_token_count:
                token_end = active_token_count
            for pos in range(token_start, token_end):
                if Int32(mActiveTokenIds[pos]) == token:
                    found = Int32(mWeightLoraIds[active_idx])
    return found


@cute.jit
def _rank_for_weight_lora_id(
    weight_lora_id: Int32,
    rank_limit: Int32,
    mScratch: cute.Tensor,
    mLoraRanks: cute.Tensor,
) -> Int32:
    rank = rank_limit
    if rank > Int32(mScratch.shape[1]):
        rank = Int32(mScratch.shape[1])
    if (
        weight_lora_id >= Int32(0)
        and Int32(mLoraRanks.shape[0]) > Int32(0)
        and weight_lora_id < Int32(mLoraRanks.shape[0])
    ):
        rank = Int32(mLoraRanks[weight_lora_id])
        if rank > rank_limit:
            rank = rank_limit
        if rank > Int32(mScratch.shape[1]):
            rank = Int32(mScratch.shape[1])
    if rank < Int32(0):
        rank = Int32(0)
    return rank


@dataclass(frozen=True)
class MoeLoraVariant:
    kind: str
    topk_weight_dtype: str = "bf16"
    warps_per_block: int = 4
    in_dim: int | None = None
    out_dim: int | None = None

    @property
    def variant_key(self) -> str:
        if self.kind == "shrink":
            in_suffix = f"_K{self.in_dim}" if self.in_dim is not None else "_Kdyn"
            return f"shrink_bf16_w{self.warps_per_block}{in_suffix}"
        if self.kind == "up_gelu":
            out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
            return f"up_gelu_bf16_w{self.warps_per_block}{out_suffix}"
        if self.kind == "down_sum":
            suffix = "twfp32" if self.topk_weight_dtype == "fp32" else "twbf16"
            out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
            return f"down_sum_bf16_{suffix}_w{self.warps_per_block}{out_suffix}"
        suffix = "twfp32" if self.topk_weight_dtype == "fp32" else "twbf16"
        out_suffix = f"_N{self.out_dim}" if self.out_dim is not None else "_Ndyn"
        return f"{self.kind}_bf16_{suffix}_w{self.warps_per_block}{out_suffix}"


class _MoeLoraBase:
    WARP_SIZE = 32

    def __init__(self, *, warps_per_block: int = 4) -> None:
        self.warps_per_block = int(warps_per_block)


# Tried two rank outputs per warp with 16-lane reductions on RTX 3090:
# active align+apply slowed by 1.5-2.4x for per-expert rank 8; keeping one warp per dot.
class _MoeLoraShrink(_MoeLoraBase):
    def __init__(self, *, warps_per_block: int = 4, in_dim: int | None = None) -> None:
        super().__init__(warps_per_block=warps_per_block)
        self.in_dim = in_dim

    @cute.kernel
    def shrink_kernel(
        self,
        mX: cute.Tensor,
        mLoraA: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mScratch: cute.Tensor,
        input_top_k_log2: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        num_experts: Int32,
        rank_limit: Int32,
    ) -> None:
        tidx, _, _ = cute.arch.thread_idx()
        bidx, _, _ = cute.arch.block_idx()

        warp_size = const_expr(self.WARP_SIZE)
        warps_per_block = const_expr(self.warps_per_block)
        warp_id = tidx // warp_size
        lane = tidx % warp_size
        output_top_k = output_top_k_mask + Int32(1)

        active_lora_count = Int32(mActiveLoraMeta[0])
        active_token_count = Int32(mActiveLoraMeta[2])
        if active_lora_count > Int32(mWeightLoraIds.shape[0]):
            active_lora_count = Int32(mWeightLoraIds.shape[0])
        meta_loras = Int32(mActiveLoraMeta.shape[0]) - Int32(4)
        if active_lora_count > meta_loras:
            active_lora_count = meta_loras
        if active_token_count > Int32(mActiveTokenIds.shape[0]):
            active_token_count = Int32(mActiveTokenIds.shape[0])

        worker = Int32(bidx) * Int32(warps_per_block) + warp_id
        stride = Int32(cute.arch.grid_dim()[0]) * Int32(warps_per_block)
        for active_idx in range(active_lora_count):
            weight_lora_id = Int32(mWeightLoraIds[active_idx])
            super_base = weight_lora_id * num_experts
            if weight_lora_id >= Int32(0) and super_base < Int32(mLoraA.shape[0]):
                rank = rank_limit
                if rank > Int32(mScratch.shape[1]):
                    rank = Int32(mScratch.shape[1])
                if (
                    Int32(mLoraRanks.shape[0]) > Int32(0)
                    and weight_lora_id < Int32(mLoraRanks.shape[0])
                ):
                    rank = Int32(mLoraRanks[weight_lora_id])
                    if rank > rank_limit:
                        rank = rank_limit
                    if rank > Int32(mScratch.shape[1]):
                        rank = Int32(mScratch.shape[1])

                token_start = Int32(mActiveLoraMeta[3 + active_idx])
                token_end = Int32(mActiveLoraMeta[4 + active_idx])
                if token_start < Int32(0):
                    token_start = Int32(0)
                if token_end > active_token_count:
                    token_end = active_token_count
                token_count = token_end - token_start
                if token_count < Int32(0):
                    token_count = Int32(0)

                if rank > Int32(0) and token_count > Int32(0):
                    total = token_count * output_top_k * rank
                    for linear in range(worker, total, stride):
                        r = linear % rank
                        assignment_idx = linear // rank
                        token_row = assignment_idx >> output_top_k_log2
                        slot = assignment_idx & output_top_k_mask
                        token = Int32(mActiveTokenIds[token_start + token_row])
                        if (
                            token >= Int32(0)
                            and token < Int32(mTopkIds.shape[0])
                        ):
                            expert = Int32(mTopkIds[token, slot])
                            if expert >= Int32(0) and expert < num_experts:
                                super_expert = super_base + expert
                                assignment = token * output_top_k + slot
                                if assignment < Int32(mScratch.shape[0]):
                                    source_row = assignment >> input_top_k_log2
                                    if const_expr(self.in_dim is None):
                                        in_dim = Int32(mX.shape[1])
                                    else:
                                        in_dim = Int32(const_expr(self.in_dim))
                                    acc = Float32(0.0)

                                    for k in range(lane, in_dim, warp_size):
                                        x = Float32(mX[source_row, k])
                                        w = Float32(mLoraA[super_expert, r, k])
                                        acc += x * w

                                    acc = _warp_reduce_sum_f32(acc)
                                    if lane == Int32(0):
                                        mScratch[assignment, r] = BFloat16(acc)

    @cute.jit
    def __call__(
        self,
        mX: cute.Tensor,
        mLoraA: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mScratch: cute.Tensor,
        input_top_k_log2: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        num_experts: Int32,
        assignment_limit: Int32,
        rank_limit: Int32,
        stream: cuda.CUstream,
    ) -> None:
        rank_cap = rank_limit
        if rank_cap > Int32(mScratch.shape[1]):
            rank_cap = Int32(mScratch.shape[1])
        outputs = assignment_limit * rank_cap
        blocks = cute.ceil_div(outputs, const_expr(self.warps_per_block))
        self.shrink_kernel(
            mX,
            mLoraA,
            mTopkIds,
            mActiveTokenIds,
            mWeightLoraIds,
            mLoraRanks,
            mActiveLoraMeta,
            mScratch,
            input_top_k_log2,
            output_top_k_log2,
            output_top_k_mask,
            num_experts,
            rank_limit,
        ).launch(
            grid=[blocks, 1, 1],
            block=[self.warps_per_block * self.WARP_SIZE, 1, 1],
            stream=stream,
        )


class _MoeLoraUpGelu(_MoeLoraBase):
    COLS_PER_WARP = 32

    def __init__(
        self,
        *,
        warps_per_block: int = 4,
        out_dim: int | None = None,
    ) -> None:
        super().__init__(warps_per_block=warps_per_block)
        self.out_dim = out_dim

    @cute.kernel
    def up_gelu_kernel(
        self,
        mBaseUp: cute.Tensor,
        mScratch: cute.Tensor,
        mLoraB: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mActivation: cute.Tensor,
        num_experts: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        rank_limit: Int32,
    ) -> None:
        tidx, _, _ = cute.arch.thread_idx()
        bidx, _, _ = cute.arch.block_idx()

        warp_size = const_expr(self.WARP_SIZE)
        warps_per_block = const_expr(self.warps_per_block)
        warp_id = tidx // warp_size
        lane = tidx % warp_size

        if const_expr(self.out_dim is None):
            out_dim = Int32(mBaseUp.shape[2])
            col_blocks = cute.ceil_div(
                out_dim // Int32(2), const_expr(self.COLS_PER_WARP)
            )
        else:
            out_dim = Int32(const_expr(self.out_dim))
            col_blocks = Int32(
                const_expr(
                    (self.out_dim + self.COLS_PER_WARP - 1) // self.COLS_PER_WARP
                )
            )
        lane_col = lane
        worker = Int32(bidx) * Int32(warps_per_block) + warp_id
        stride = Int32(cute.arch.grid_dim()[0]) * Int32(warps_per_block)
        output_top_k = output_top_k_mask + Int32(1)
        intermediate = out_dim // Int32(2)
        token_count = Int32(mBaseUp.shape[0])
        total = Int32(mActivation.shape[0]) * cute.ceil_div(
            intermediate, const_expr(self.COLS_PER_WARP)
        )

        active_lora_count = Int32(mActiveLoraMeta[0])
        if active_lora_count > Int32(mWeightLoraIds.shape[0]):
            active_lora_count = Int32(mWeightLoraIds.shape[0])
        meta_loras = Int32(mActiveLoraMeta.shape[0]) - Int32(4)
        if active_lora_count > meta_loras:
            active_lora_count = meta_loras
        active_token_count = Int32(mActiveLoraMeta[2])
        if active_token_count > Int32(mActiveTokenIds.shape[0]):
            active_token_count = Int32(mActiveTokenIds.shape[0])

        single_full_batch = False
        single_weight_lora_id = Int32(-1)
        single_rank = Int32(0)
        single_super_base = Int32(-1)
        if active_lora_count == Int32(1):
            token_start = Int32(mActiveLoraMeta[3])
            token_end = Int32(mActiveLoraMeta[4])
            if token_end > active_token_count:
                token_end = active_token_count
            if (
                token_start == Int32(0)
                and token_count > Int32(0)
                and token_end >= token_count
            ):
                single_full_batch = True
                single_weight_lora_id = Int32(mWeightLoraIds[0])
                single_super_base = single_weight_lora_id * num_experts
                single_rank = _rank_for_weight_lora_id(
                    single_weight_lora_id, rank_limit, mScratch, mLoraRanks
                )

        for linear in range(worker, total, stride):
            if const_expr(self.out_dim is not None):
                col_blocks_const = const_expr(
                    ((self.out_dim // 2) + self.COLS_PER_WARP - 1)
                    // self.COLS_PER_WARP
                )
                if const_expr(
                    col_blocks_const > 0
                    and (col_blocks_const & (col_blocks_const - 1)) == 0
                ):
                    col_block = linear & const_expr(col_blocks_const - 1)
                    assignment = linear >> const_expr(
                        col_blocks_const.bit_length() - 1
                    )
                else:
                    col_block = linear % const_expr(col_blocks_const)
                    assignment = linear // const_expr(col_blocks_const)
            else:
                col_block = linear % col_blocks
                assignment = linear // col_blocks
            neuron = col_block * const_expr(self.COLS_PER_WARP) + lane_col

            if const_expr(
                self.out_dim is not None
                and (self.out_dim // 2) % self.COLS_PER_WARP == 0
            ):
                valid_col = True
            else:
                valid_col = neuron < intermediate
            if valid_col:
                token = assignment >> output_top_k_log2
                slot = assignment & output_top_k_mask
                vx = Float32(mBaseUp[token, slot, neuron])
                vy = Float32(mBaseUp[token, slot, intermediate + neuron])

                weight_lora_id = single_weight_lora_id
                super_base = single_super_base
                rank = single_rank
                if not single_full_batch:
                    weight_lora_id = _active_weight_lora_id_for_token(
                        token,
                        mActiveTokenIds,
                        mWeightLoraIds,
                        mActiveLoraMeta,
                    )
                    super_base = weight_lora_id * num_experts
                    rank = _rank_for_weight_lora_id(
                        weight_lora_id, rank_limit, mScratch, mLoraRanks
                    )
                if (
                    weight_lora_id >= Int32(0)
                    and super_base < Int32(mLoraB.shape[0])
                    and assignment < Int32(mScratch.shape[0])
                    and rank > Int32(0)
                ):
                    expert = Int32(mTopkIds[token, slot])
                    if expert >= Int32(0) and expert < num_experts:
                        super_expert = super_base + expert
                        dx = Float32(0.0)
                        dy = Float32(0.0)
                        for r in range(rank):
                            x = Float32(mScratch[assignment, r])
                            dx += x * Float32(mLoraB[super_expert, neuron, r])
                            dy += x * Float32(
                                mLoraB[super_expert, intermediate + neuron, r]
                            )
                        vx += dx
                        vy += dy

                mActivation[assignment, neuron] = BFloat16(
                    _gelu_f32(vx) * (vy + Float32(1.0))
                )

    @cute.jit
    def __call__(
        self,
        mBaseUp: cute.Tensor,
        mScratch: cute.Tensor,
        mLoraB: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mActivation: cute.Tensor,
        num_experts: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        assignment_limit: Int32,
        rank_limit: Int32,
        stream: cuda.CUstream,
    ) -> None:
        if const_expr(self.out_dim is None):
            col_blocks = cute.ceil_div(
                Int32(mBaseUp.shape[2]) // Int32(2),
                const_expr(self.COLS_PER_WARP),
            )
        else:
            col_blocks = Int32(
                const_expr(
                    ((self.out_dim // 2) + self.COLS_PER_WARP - 1)
                    // self.COLS_PER_WARP
                )
            )
        outputs = assignment_limit * col_blocks
        blocks = cute.ceil_div(outputs, const_expr(self.warps_per_block))
        self.up_gelu_kernel(
            mBaseUp,
            mScratch,
            mLoraB,
            mTopkIds,
            mActiveTokenIds,
            mWeightLoraIds,
            mLoraRanks,
            mActiveLoraMeta,
            mActivation,
            num_experts,
            output_top_k_log2,
            output_top_k_mask,
            rank_limit,
        ).launch(
            grid=[blocks, 1, 1],
            block=[self.warps_per_block * self.WARP_SIZE, 1, 1],
            stream=stream,
        )


# Tried rank-major LoRA-B layout [super, rank, out] before finalizer fusion:
# 0.93-0.97x the throughput of [super, out, rank] on B200 mixed-rank apply.
class _MoeLoraDownSum(_MoeLoraBase):
    COLS_PER_WARP = 32

    def __init__(
        self,
        *,
        warps_per_block: int = 4,
        out_dim: int | None = None,
    ) -> None:
        super().__init__(warps_per_block=warps_per_block)
        self.out_dim = out_dim

    @cute.kernel
    def down_sum_kernel(
        self,
        mBaseDown: cute.Tensor,
        mScratch: cute.Tensor,
        mLoraB: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mTopkWeights: cute.Tensor,
        mOut: cute.Tensor,
        num_experts: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        rank_limit: Int32,
    ) -> None:
        tidx, _, _ = cute.arch.thread_idx()
        bidx, _, _ = cute.arch.block_idx()

        warp_size = const_expr(self.WARP_SIZE)
        warps_per_block = const_expr(self.warps_per_block)
        warp_id = tidx // warp_size
        lane = tidx % warp_size

        if const_expr(self.out_dim is None):
            out_dim = Int32(mOut.shape[1])
            col_blocks = cute.ceil_div(out_dim, const_expr(self.COLS_PER_WARP))
        else:
            out_dim = Int32(const_expr(self.out_dim))
            col_blocks = Int32(
                const_expr(
                    (self.out_dim + self.COLS_PER_WARP - 1) // self.COLS_PER_WARP
                )
            )
        lane_col = lane
        worker = Int32(bidx) * Int32(warps_per_block) + warp_id
        stride = Int32(cute.arch.grid_dim()[0]) * Int32(warps_per_block)
        output_top_k = output_top_k_mask + Int32(1)
        total = Int32(mOut.shape[0]) * col_blocks

        active_lora_count = Int32(mActiveLoraMeta[0])
        if active_lora_count > Int32(mWeightLoraIds.shape[0]):
            active_lora_count = Int32(mWeightLoraIds.shape[0])
        meta_loras = Int32(mActiveLoraMeta.shape[0]) - Int32(4)
        if active_lora_count > meta_loras:
            active_lora_count = meta_loras
        active_token_count = Int32(mActiveLoraMeta[2])
        if active_token_count > Int32(mActiveTokenIds.shape[0]):
            active_token_count = Int32(mActiveTokenIds.shape[0])

        single_full_batch = False
        single_weight_lora_id = Int32(-1)
        single_rank = Int32(0)
        single_super_base = Int32(-1)
        if active_lora_count == Int32(1):
            token_start = Int32(mActiveLoraMeta[3])
            token_end = Int32(mActiveLoraMeta[4])
            if token_end > active_token_count:
                token_end = active_token_count
            if (
                token_start == Int32(0)
                and Int32(mOut.shape[0]) > Int32(0)
                and token_end >= Int32(mOut.shape[0])
            ):
                single_full_batch = True
                single_weight_lora_id = Int32(mWeightLoraIds[0])
                single_super_base = single_weight_lora_id * num_experts
                single_rank = _rank_for_weight_lora_id(
                    single_weight_lora_id, rank_limit, mScratch, mLoraRanks
                )

        for linear in range(worker, total, stride):
            if const_expr(self.out_dim is not None):
                col_blocks_const = const_expr(
                    (self.out_dim + self.COLS_PER_WARP - 1) // self.COLS_PER_WARP
                )
                if const_expr(
                    col_blocks_const > 0
                    and (col_blocks_const & (col_blocks_const - 1)) == 0
                ):
                    col_block = linear & const_expr(col_blocks_const - 1)
                    token = linear >> const_expr(col_blocks_const.bit_length() - 1)
                else:
                    col_block = linear % const_expr(col_blocks_const)
                    token = linear // const_expr(col_blocks_const)
            else:
                col_block = linear % col_blocks
                token = linear // col_blocks
            out_col = col_block * const_expr(self.COLS_PER_WARP) + lane_col

            if const_expr(
                self.out_dim is not None
                and self.out_dim % self.COLS_PER_WARP == 0
            ):
                valid_col = True
            else:
                valid_col = out_col < out_dim
            if valid_col:
                weight_lora_id = single_weight_lora_id
                super_base = single_super_base
                rank = single_rank
                if not single_full_batch:
                    weight_lora_id = _active_weight_lora_id_for_token(
                        token,
                        mActiveTokenIds,
                        mWeightLoraIds,
                        mActiveLoraMeta,
                    )
                    super_base = weight_lora_id * num_experts
                    rank = _rank_for_weight_lora_id(
                        weight_lora_id, rank_limit, mScratch, mLoraRanks
                    )
                out_acc = Float32(0.0)
                for slot in range(output_top_k):
                    assignment = token * output_top_k + slot
                    out_acc += Float32(mBaseDown[token, slot, out_col])

                    if (
                        weight_lora_id >= Int32(0)
                        and super_base < Int32(mLoraB.shape[0])
                        and assignment < Int32(mScratch.shape[0])
                        and rank > Int32(0)
                    ):
                        expert = Int32(mTopkIds[token, slot])
                        if expert >= Int32(0) and expert < num_experts:
                            super_expert = super_base + expert
                            delta = Float32(0.0)
                            for r in range(rank):
                                x = Float32(mScratch[assignment, r])
                                w = Float32(mLoraB[super_expert, out_col, r])
                                delta += x * w
                            out_acc += delta * Float32(mTopkWeights[token, slot])
                mOut[token, out_col] = BFloat16(out_acc)

    @cute.jit
    def __call__(
        self,
        mBaseDown: cute.Tensor,
        mScratch: cute.Tensor,
        mLoraB: cute.Tensor,
        mTopkIds: cute.Tensor,
        mActiveTokenIds: cute.Tensor,
        mWeightLoraIds: cute.Tensor,
        mLoraRanks: cute.Tensor,
        mActiveLoraMeta: cute.Tensor,
        mTopkWeights: cute.Tensor,
        mOut: cute.Tensor,
        num_experts: Int32,
        output_top_k_log2: Int32,
        output_top_k_mask: Int32,
        assignment_limit: Int32,
        rank_limit: Int32,
        stream: cuda.CUstream,
    ) -> None:
        if const_expr(self.out_dim is None):
            col_blocks = cute.ceil_div(Int32(mOut.shape[1]), const_expr(self.COLS_PER_WARP))
        else:
            col_blocks = Int32(
                const_expr(
                    (self.out_dim + self.COLS_PER_WARP - 1) // self.COLS_PER_WARP
                )
            )
        outputs = assignment_limit * col_blocks
        blocks = cute.ceil_div(outputs, const_expr(self.warps_per_block))
        self.down_sum_kernel(
            mBaseDown,
            mScratch,
            mLoraB,
            mTopkIds,
            mActiveTokenIds,
            mWeightLoraIds,
            mLoraRanks,
            mActiveLoraMeta,
            mTopkWeights,
            mOut,
            num_experts,
            output_top_k_log2,
            output_top_k_mask,
            rank_limit,
        ).launch(
            grid=[blocks, 1, 1],
            block=[self.warps_per_block * self.WARP_SIZE, 1, 1],
            stream=stream,
        )


def make_compile_args(variant: MoeLoraVariant):
    t_sym = cute.sym_int()
    a_sym = cute.sym_int()
    e_sym = cute.sym_int()
    r_sym = cute.sym_int()
    in_sym = cute.sym_int()
    out_sym = cute.sym_int()
    active_token_sym = cute.sym_int()
    active_lora_sym = cute.sym_int()
    top_k_sym = cute.sym_int()

    def bf16_2d(shape):
        return cute.runtime.make_fake_tensor(
            BFloat16,
            shape,
            stride=(cute.sym_int64(divisibility=8), 1),
            assumed_align=16,
        )

    def i32_1d(shape):
        return cute.runtime.make_fake_tensor(
            Int32, shape, stride=(1,), assumed_align=4,
        )

    x = bf16_2d((a_sym, variant.in_dim or in_sym))
    lora_a = cute.runtime.make_fake_tensor(
        BFloat16,
        (e_sym, r_sym, variant.in_dim or in_sym),
        stride=(
            cute.sym_int64(divisibility=8),
            cute.sym_int64(divisibility=8),
            1,
        ),
        assumed_align=16,
    )
    lora_b = cute.runtime.make_fake_tensor(
        BFloat16,
        (e_sym, variant.out_dim or out_sym, r_sym),
        stride=(
            cute.sym_int64(divisibility=8),
            cute.sym_int64(divisibility=8),
            1,
        ),
        assumed_align=16,
    )
    topk_ids = cute.runtime.make_fake_tensor(
        Int32,
        (t_sym, top_k_sym),
        stride=(top_k_sym, 1),
        assumed_align=4,
    )
    active_token_ids = i32_1d((active_token_sym,))
    weight_lora_ids = i32_1d((active_lora_sym,))
    lora_ranks = i32_1d((cute.sym_int(),))
    active_lora_meta = i32_1d((cute.sym_int(),))
    scratch = bf16_2d((a_sym, r_sym))
    topk_weight_type = Float32 if variant.topk_weight_dtype == "fp32" else BFloat16
    topk_weight_align = 4 if variant.topk_weight_dtype == "fp32" else 16
    topk_weights = cute.runtime.make_fake_tensor(
        topk_weight_type,
        (t_sym, top_k_sym),
        stride=(top_k_sym, 1),
        assumed_align=topk_weight_align,
    )
    out = cute.runtime.make_fake_tensor(
        BFloat16,
        (t_sym, top_k_sym, variant.out_dim or out_sym),
        stride=(cute.sym_int64(divisibility=8), cute.sym_int64(divisibility=8), 1),
        assumed_align=16,
    )
    activation = bf16_2d((a_sym, (variant.out_dim // 2) if variant.out_dim else out_sym))
    final_out = bf16_2d((t_sym, variant.out_dim or out_sym))
    stream = cute.runtime.make_fake_stream(use_tvm_ffi_env_stream=True)
    scalar = Int32(0)

    if variant.kind == "shrink":
        op = _MoeLoraShrink(
            warps_per_block=variant.warps_per_block,
            in_dim=variant.in_dim,
        )
        return (
            op,
            x,
            lora_a,
            topk_ids,
            active_token_ids,
            weight_lora_ids,
            lora_ranks,
            active_lora_meta,
            scratch,
            scalar,
            scalar,
            scalar,
            scalar,
            scalar,
            scalar,
            stream,
        )
    if variant.kind == "up_gelu":
        op = _MoeLoraUpGelu(
            warps_per_block=variant.warps_per_block,
            out_dim=variant.out_dim,
        )
        return (
            op,
            out,
            scratch,
            lora_b,
            topk_ids,
            active_token_ids,
            weight_lora_ids,
            lora_ranks,
            active_lora_meta,
            activation,
            scalar,
            scalar,
            scalar,
            scalar,
            scalar,
            stream,
        )
    if variant.kind == "down_sum":
        op = _MoeLoraDownSum(
            warps_per_block=variant.warps_per_block,
            out_dim=variant.out_dim,
        )
        return (
            op,
            out,
            scratch,
            lora_b,
            topk_ids,
            active_token_ids,
            weight_lora_ids,
            lora_ranks,
            active_lora_meta,
            topk_weights,
            final_out,
            scalar,
            scalar,
            scalar,
            scalar,
            scalar,
            stream,
        )
    raise ValueError(f"unsupported MoE LoRA variant kind: {variant.kind!r}")


__all__ = ["MoeLoraVariant", "make_compile_args"]
