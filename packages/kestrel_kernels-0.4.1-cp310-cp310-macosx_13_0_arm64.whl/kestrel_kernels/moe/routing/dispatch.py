"""Compact MoE routing dispatch via cubin bundles."""

from __future__ import annotations

import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled


_family = CubinFamily("moe_route")
_SMALL_BATCH_EXPERT_LIMIT = 64
_SMALL_BATCH_NUMEL_LIMIT = 1024
_LARGE_SCATTER_THREADS = 256
_MATERIALIZE_WARPS_PER_BLOCK = 8

_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles


def _tag(topk_ids: torch.Tensor, topk: int, num_experts: int) -> str:
    dtype_name = "i32" if topk_ids.dtype == torch.int32 else "i64"
    return f"{dtype_name}_k{topk}_e{num_experts}"


def _materialize_key(
    *,
    kind: str,
    K: int,
    topk: int,
    num_experts: int,
    topk_weight_dtype: torch.dtype,
) -> str:
    dtype_name = "twfp32" if topk_weight_dtype == torch.float32 else "twbf16"
    return f"materialize_{kind}_K{K}_k{topk}_e{num_experts}_{dtype_name}"


def _jit_ensure_variant(
    variant_key: str,
    phase: str,
    topk_ids: torch.Tensor,
    num_experts: int,
) -> None:
    device_index = int(topk_ids.device.index or 0)
    if (variant_key, device_index) in _family._handles:
        return

    from cutlass import Int32, Int64

    topk_dtype = Int32 if topk_ids.dtype == torch.int32 else Int64
    topk = int(topk_ids.shape[1])
    spec = _cubin_bundles._MOE_ROUTE_PHASES[phase]
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_moe_route(
            phase, topk_dtype, topk, num_experts
        ),
        block_x=spec["block"][0],
        device_index=device_index,
    )


def _ensure_variants(
    variant_keys: tuple[tuple[str, str], ...],
    topk_ids: torch.Tensor,
    num_experts: int,
) -> None:
    device_index = int(topk_ids.device.index or 0)
    missing: list[str] = []
    for phase, key in variant_keys:
        if _family.is_available(key):
            continue
        if _ENABLE_JIT:
            _jit_ensure_variant(key, phase, topk_ids, num_experts)
            if _family.is_available(key) or (key, device_index) in _family._handles:
                continue
        missing.append(key)
    if missing:
        raise RuntimeError(
            "No moe_route cubin variant(s) for "
            + ", ".join(missing)
            + "; rebuild bundles or set KESTREL_CUTE_JIT=1"
        )


def _ensure_materialize_variant(
    variant_key: str,
    *,
    kind: str,
    A_fp8_bits: torch.Tensor,
    topk: int,
    num_experts: int,
    topk_weight_dtype: torch.dtype,
) -> None:
    device_index = int(A_fp8_bits.device.index or 0)
    if _family.is_available(variant_key) or (variant_key, device_index) in _family._handles:
        return
    if not _ENABLE_JIT:
        raise RuntimeError(
            f"No moe_route cubin variant for {variant_key}; rebuild bundles "
            "or set KESTREL_CUTE_JIT=1"
        )

    from cutlass import BFloat16, Float32

    topk_dtype = Float32 if topk_weight_dtype == torch.float32 else BFloat16
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_moe_route_materialize(
            kind=kind,
            K=int(A_fp8_bits.shape[1]),
            topk=topk,
            num_experts=num_experts,
            topk_dtype=topk_dtype,
        ),
        block_x=_MATERIALIZE_WARPS_PER_BLOCK * 32,
        device_index=device_index,
    )


def moe_route_topk(
    topk_ids: torch.Tensor,
    num_experts: int,
    sorted_token_ids: torch.Tensor,
    cu_seqlens_m: torch.Tensor,
    cumsum_buffer: torch.Tensor,
) -> None:
    """Build exact expert-major top-k assignment routing.

    Outputs:
      sorted_token_ids: length T*K, values are flat assignment ids
      cu_seqlens_m: length E+1, exact per-expert prefix sums
    """
    if topk_ids.device.type != "cuda":
        raise ValueError("topk_ids must be a CUDA tensor")
    if not topk_ids.is_contiguous() or topk_ids.ndim != 2:
        raise ValueError("topk_ids must be a contiguous 2D tensor [num_tokens, top_k]")
    if topk_ids.dtype not in (torch.int32, torch.int64):
        raise ValueError("topk_ids must be int32 or int64")
    if (
        sorted_token_ids.device != topk_ids.device
        or sorted_token_ids.dtype != torch.int32
        or sorted_token_ids.ndim != 1
        or not sorted_token_ids.is_contiguous()
    ):
        raise ValueError("sorted_token_ids must be a contiguous int32 CUDA 1D tensor")
    if (
        cu_seqlens_m.device != topk_ids.device
        or cu_seqlens_m.dtype != torch.int32
        or cu_seqlens_m.ndim != 1
        or cu_seqlens_m.numel() != int(num_experts) + 1
        or not cu_seqlens_m.is_contiguous()
    ):
        raise ValueError("cu_seqlens_m must be contiguous int32 with shape [num_experts + 1]")
    if sorted_token_ids.numel() < topk_ids.numel():
        raise ValueError("sorted_token_ids capacity is smaller than topk_ids.numel()")
    if (
        cumsum_buffer.device != topk_ids.device
        or cumsum_buffer.dtype != torch.int32
        or cumsum_buffer.ndim != 1
        or cumsum_buffer.numel() < int(num_experts)
        or not cumsum_buffer.is_contiguous()
    ):
        raise ValueError("cumsum_buffer must be contiguous int32 with length >= num_experts")

    topk = int(topk_ids.shape[1])
    numel = int(topk_ids.numel())
    tag = _tag(topk_ids, topk, int(num_experts))
    small = (
        int(num_experts) <= _SMALL_BATCH_EXPERT_LIMIT
        and numel < _SMALL_BATCH_NUMEL_LIMIT
    )

    needed_keys = (
        (("small", f"small_{tag}"),)
        if small
        else (("large_align", f"large_align_{tag}"), ("large_scatter", f"large_scatter_{tag}"))
    )
    _ensure_variants(needed_keys, topk_ids, int(num_experts))

    sorted_view = sorted_token_ids[:numel]
    if small:
        _family.resolve_dispatch(topk_ids, variant_key=f"small_{tag}", grid_x=1)(
            topk_ids,
            sorted_view,
            cu_seqlens_m,
        )
        return

    _family.resolve_dispatch(topk_ids, variant_key=f"large_align_{tag}", grid_x=1)(
        topk_ids,
        cu_seqlens_m,
        cumsum_buffer[: int(num_experts)],
    )
    scatter_blocks = ceil_div(numel, _LARGE_SCATTER_THREADS)
    _family.resolve_dispatch(
        topk_ids, variant_key=f"large_scatter_{tag}", grid_x=scatter_blocks
    )(
        topk_ids,
        sorted_view,
        cumsum_buffer[: int(num_experts)],
    )


def moe_route_materialize_fp8(
    *,
    kind: str,
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    cu_seqlens_m: torch.Tensor,
    A_routed_bits: torch.Tensor,
    row_scale: torch.Tensor,
    top_k: int,
    num_experts: int,
) -> None:
    if kind not in ("up", "down"):
        raise ValueError(f"unknown MoE materialize kind {kind!r}")
    if A_fp8_bits.device.type != "cuda" or A_fp8_bits.dtype != torch.uint8:
        raise ValueError("A_fp8_bits must be a CUDA uint8 tensor")
    if A_scale.device != A_fp8_bits.device or A_scale.dtype != torch.float32:
        raise ValueError("A_scale must be a CUDA fp32 tensor on the same device")
    if topk_weights.device != A_fp8_bits.device:
        raise ValueError("topk_weights must be on the same CUDA device")
    if topk_weights.dtype not in (torch.bfloat16, torch.float32):
        raise ValueError("topk_weights must be bf16 or fp32")
    if (
        sorted_token_ids.device != A_fp8_bits.device
        or sorted_token_ids.dtype != torch.int32
        or sorted_token_ids.ndim != 1
        or not sorted_token_ids.is_contiguous()
    ):
        raise ValueError("sorted_token_ids must be contiguous CUDA int32")
    if (
        cu_seqlens_m.device != A_fp8_bits.device
        or cu_seqlens_m.dtype != torch.int32
        or cu_seqlens_m.ndim != 1
        or cu_seqlens_m.numel() != int(num_experts) + 1
        or not cu_seqlens_m.is_contiguous()
    ):
        raise ValueError("cu_seqlens_m must be contiguous int32 with shape [num_experts + 1]")
    if (
        A_routed_bits.device != A_fp8_bits.device
        or A_routed_bits.dtype != torch.uint8
        or A_routed_bits.ndim != 2
        or A_routed_bits.shape[0] < sorted_token_ids.numel()
        or A_routed_bits.shape[1] != A_fp8_bits.shape[1]
        or not A_routed_bits.is_contiguous()
    ):
        raise ValueError("A_routed_bits must be contiguous uint8 [sorted_token_ids, K]")
    if (
        row_scale.device != A_fp8_bits.device
        or row_scale.dtype != torch.float32
        or row_scale.ndim != 1
        or row_scale.numel() < sorted_token_ids.numel()
        or not row_scale.is_contiguous()
    ):
        raise ValueError("row_scale must be contiguous fp32 with length >= sorted_token_ids")
    if A_fp8_bits.ndim != 2 or int(A_fp8_bits.shape[1]) % 16 != 0:
        raise ValueError("A_fp8_bits must be 2D with K multiple of 16")

    rows = int(sorted_token_ids.numel())
    if rows == 0:
        return

    variant_key = _materialize_key(
        kind=kind,
        K=int(A_fp8_bits.shape[1]),
        topk=int(top_k),
        num_experts=int(num_experts),
        topk_weight_dtype=topk_weights.dtype,
    )
    _ensure_materialize_variant(
        variant_key,
        kind=kind,
        A_fp8_bits=A_fp8_bits,
        topk=int(top_k),
        num_experts=int(num_experts),
        topk_weight_dtype=topk_weights.dtype,
    )
    grid_x = ceil_div(rows, _MATERIALIZE_WARPS_PER_BLOCK)
    _family.resolve_dispatch(A_fp8_bits, variant_key=variant_key, grid_x=grid_x)(
        A_fp8_bits,
        A_scale,
        topk_weights,
        sorted_token_ids,
        cu_seqlens_m,
        A_routed_bits[:rows],
        row_scale[:rows],
    )


__all__ = ["moe_route_materialize_fp8", "moe_route_topk"]
