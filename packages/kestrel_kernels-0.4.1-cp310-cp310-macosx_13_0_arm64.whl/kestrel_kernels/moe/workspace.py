"""Workspace helpers for the public MoE API."""

from __future__ import annotations

from dataclasses import dataclass
from math import prod

import torch


def _strides(shape: tuple[int, ...]) -> tuple[int, ...]:
    strides: list[int] = [1]
    for dim in reversed(shape[1:]):
        strides.insert(0, strides[0] * dim)
    return tuple(strides)


class FixedWorkspaceBuffer:
    """Fixed-capacity tensor backing store.

    ``get`` returns a view into the preallocated backing tensor and raises if
    a caller asks for more elements than ``reserve`` established.
    """

    def __init__(self, name: str) -> None:
        self._name = name
        self._tensor: torch.Tensor | None = None

    def reserve(
        self,
        shape: tuple[int, ...],
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> None:
        self.get(shape, device=device, dtype=dtype)

    def get(
        self,
        shape: tuple[int, ...],
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        numel = prod(shape)
        if numel == 0:
            return torch.empty(shape, device=device, dtype=dtype)
        if self._tensor is None:
            self._tensor = torch.empty((numel,), device=device, dtype=dtype)
        elif self._tensor.numel() < numel:
            raise RuntimeError(
                f"{self._name} overflow: requested {numel} elements but "
                f"only {self._tensor.numel()} were prepared"
            )
        elif self._tensor.device != device or self._tensor.dtype != dtype:
            raise RuntimeError(
                f"{self._name} device/dtype mismatch: prepared on "
                f"{self._tensor.device}/{self._tensor.dtype}, requested "
                f"{device}/{dtype}"
            )
        return torch.as_strided(self._tensor, shape, _strides(shape))


@dataclass(frozen=True)
class LegacyRouteWorkspace:
    sorted_token_ids: torch.Tensor
    expert_ids: torch.Tensor
    num_tokens_post_padded: torch.Tensor


@dataclass
class LegacyWorkspace:
    up: FixedWorkspaceBuffer
    activation: FixedWorkspaceBuffer
    down: FixedWorkspaceBuffer
    output: FixedWorkspaceBuffer
    lora_up: FixedWorkspaceBuffer
    lora_down: FixedWorkspaceBuffer
    fp8_up_bits: FixedWorkspaceBuffer
    fp8_up_scale: FixedWorkspaceBuffer
    fp8_down_bits: FixedWorkspaceBuffer
    fp8_down_scale: FixedWorkspaceBuffer


def make_legacy_workspace() -> LegacyWorkspace:
    return LegacyWorkspace(
        up=FixedWorkspaceBuffer("MoE up workspace"),
        activation=FixedWorkspaceBuffer("MoE activation workspace"),
        down=FixedWorkspaceBuffer("MoE down workspace"),
        output=FixedWorkspaceBuffer("MoE output workspace"),
        lora_up=FixedWorkspaceBuffer("MoE LoRA up workspace"),
        lora_down=FixedWorkspaceBuffer("MoE LoRA down workspace"),
        fp8_up_bits=FixedWorkspaceBuffer("MoE FP8 up bits workspace"),
        fp8_up_scale=FixedWorkspaceBuffer("MoE FP8 up scale workspace"),
        fp8_down_bits=FixedWorkspaceBuffer("MoE FP8 down bits workspace"),
        fp8_down_scale=FixedWorkspaceBuffer("MoE FP8 down scale workspace"),
    )


__all__ = [
    "FixedWorkspaceBuffer",
    "LegacyRouteWorkspace",
    "LegacyWorkspace",
    "make_legacy_workspace",
]
