"""Warp-GEMV MoE implementation behind the public MoE runtime API."""

from __future__ import annotations

from dataclasses import dataclass

import torch

from kestrel_kernels.cute_moe.config import CuteMoeConfig
from kestrel_kernels.moe.api import (
    MoeCapacity,
    MoeExpertWeights,
    MoeLoraState,
    MoeSpec,
)
from kestrel_kernels.moe.workspace import FixedWorkspaceBuffer


def _fp8_weight_as_uint8(weight: torch.Tensor, name: str) -> torch.Tensor:
    if weight.dtype == torch.uint8:
        return weight
    if weight.dtype == torch.float8_e4m3fn:
        return weight.view(torch.uint8)
    raise ValueError(f"warpgemv MoE requires FP8 {name} expert weights")


@dataclass
class WarpGemvWorkspace:
    up: FixedWorkspaceBuffer
    activation: FixedWorkspaceBuffer
    down: FixedWorkspaceBuffer
    output: FixedWorkspaceBuffer
    lora_up: FixedWorkspaceBuffer
    lora_down: FixedWorkspaceBuffer


def _make_workspace() -> WarpGemvWorkspace:
    return WarpGemvWorkspace(
        up=FixedWorkspaceBuffer("MoE warpgemv up workspace"),
        activation=FixedWorkspaceBuffer("MoE warpgemv activation workspace"),
        down=FixedWorkspaceBuffer("MoE warpgemv down workspace"),
        output=FixedWorkspaceBuffer("MoE warpgemv output workspace"),
        lora_up=FixedWorkspaceBuffer("MoE warpgemv LoRA up workspace"),
        lora_down=FixedWorkspaceBuffer("MoE warpgemv LoRA down workspace"),
    )


def _lora_a_rank(lora: MoeLoraState, down: bool) -> int:
    return int((lora.down_a if down else lora.up_a).shape[1])


@dataclass
class WarpGemvImpl:
    spec: MoeSpec
    capacity: MoeCapacity
    device: torch.device
    config: CuteMoeConfig
    workspace: WarpGemvWorkspace

    def _validate_inputs(
        self,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        if x.device != self.device:
            raise ValueError(f"x must be on prepared device {self.device}, got {x.device}")
        if x.device.type != "cuda":
            raise ValueError("warpgemv MoE requires CUDA tensors")
        if x.dtype != torch.bfloat16:
            raise ValueError("warpgemv MoE requires BF16 activations")
        if x.ndim != 2 or x.shape[1] != self.spec.hidden_size:
            raise ValueError(
                f"x must have shape [tokens, {self.spec.hidden_size}], got {tuple(x.shape)}"
            )
        if self.capacity.mode == "decode" and x.shape[0] != self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle token shape mismatch: got {x.shape[0]} tokens, "
                f"prepared for {self.capacity.max_tokens}. Prepare one handle "
                "per CUDA graph/bucket shape."
            )
        if x.shape[0] > self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle capacity overflow: got {x.shape[0]} tokens, "
                f"capacity is {self.capacity.max_tokens}"
            )
        if not x.is_contiguous():
            raise ValueError("x must be contiguous")
        if topk_ids.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_ids must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_weights.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_weights must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_ids.dtype != torch.int32:
            raise ValueError("topk_ids must be int32 for allocation-free MoE forward")
        if topk_weights.dtype not in (torch.bfloat16, torch.float32):
            raise ValueError("topk_weights must be float32 or match x dtype")
        if not topk_ids.is_contiguous() or not topk_weights.is_contiguous():
            raise ValueError("topk_ids and topk_weights must be contiguous")
        if weights.up.device != x.device or weights.down.device != x.device:
            raise ValueError("expert weights must be on the same device as x")

        up_weight = _fp8_weight_as_uint8(weights.up, "up")
        down_weight = _fp8_weight_as_uint8(weights.down, "down")
        if weights.up_scale is None or weights.down_scale is None:
            raise ValueError("FP8 MoE weights require up_scale and down_scale")
        if weights.up_scale.device != x.device or weights.down_scale.device != x.device:
            raise ValueError("expert scales must be on the same device as x")
        if tuple(up_weight.shape) != (
            self.spec.num_experts,
            self.spec.intermediate_size * 2,
            self.spec.hidden_size,
        ):
            raise ValueError(
                "up expert weights must have shape "
                "[num_experts, 2 * intermediate_size, hidden_size]"
            )
        if tuple(down_weight.shape) != (
            self.spec.num_experts,
            self.spec.hidden_size,
            self.spec.intermediate_size,
        ):
            raise ValueError(
                "down expert weights must have shape "
                "[num_experts, hidden_size, intermediate_size]"
            )
        if tuple(weights.up_scale.shape) != (
            self.spec.num_experts,
            self.spec.intermediate_size * 2,
        ):
            raise ValueError("up_scale must have shape [num_experts, 2 * intermediate_size]")
        if tuple(weights.down_scale.shape) != (self.spec.num_experts, self.spec.hidden_size):
            raise ValueError("down_scale must have shape [num_experts, hidden_size]")
        return topk_weights, up_weight, weights.up_scale, down_weight, weights.down_scale

    def _validate_lora_capacity(self, lora: MoeLoraState) -> None:
        weight_loras = int(lora.up_a.shape[0]) // self.spec.num_experts
        if weight_loras > self.capacity.max_loras:
            raise RuntimeError(
                f"MoE LoRA capacity overflow: got {weight_loras} LoRAs, "
                f"capacity is {self.capacity.max_loras}"
            )
        max_rank = max(int(lora.up_a.shape[1]), int(lora.down_a.shape[1]))
        if max_rank > self.capacity.max_lora_rank:
            raise RuntimeError(
                f"MoE LoRA rank overflow: got rank {max_rank}, "
                f"capacity is {self.capacity.max_lora_rank}"
            )

    def _lora_scratch(
        self,
        *,
        x: torch.Tensor,
        lora: MoeLoraState,
        down: bool,
    ) -> torch.Tensor:
        return (self.workspace.lora_down if down else self.workspace.lora_up).get(
            (x.shape[0] * self.spec.top_k, _lora_a_rank(lora, down)),
            device=x.device,
            dtype=x.dtype,
        )

    def forward(
        self,
        *,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
        out: torch.Tensor | None,
        lora: MoeLoraState | None,
    ) -> torch.Tensor:
        route_weights, up_weight, up_scale, down_weight, down_scale = (
            self._validate_inputs(x, topk_ids, topk_weights, weights)
        )
        num_tokens = int(x.shape[0])
        fused = out
        if fused is None:
            fused = self.workspace.output.get(
                (num_tokens, self.spec.hidden_size),
                device=x.device,
                dtype=x.dtype,
            )
        elif (
            tuple(fused.shape) != (num_tokens, self.spec.hidden_size)
            or fused.device != x.device
            or fused.dtype != x.dtype
            or not fused.is_contiguous()
        ):
            raise ValueError(
                f"out must be contiguous BF16 with shape "
                f"[{num_tokens}, {self.spec.hidden_size}]"
            )
        if lora is None:
            activation = self.workspace.activation.get(
                (num_tokens * self.spec.top_k, self.spec.intermediate_size),
                device=x.device,
                dtype=x.dtype,
            )
            from kestrel_kernels.cute_moe.dispatch import invoke_cute_moe

            return invoke_cute_moe(
                x,
                topk_ids,
                route_weights,
                up_weight,
                up_scale,
                down_weight,
                down_scale,
                config=self.config,
                out=fused,
                activation_scratch=activation,
            )

        self._validate_lora_capacity(lora)
        up_out = self.workspace.up.get(
            (num_tokens, self.spec.top_k, self.spec.intermediate_size * 2),
            device=x.device,
            dtype=x.dtype,
        )
        activation = self.workspace.activation.get(
            (num_tokens * self.spec.top_k, self.spec.intermediate_size),
            device=x.device,
            dtype=x.dtype,
        )
        down_out = self.workspace.down.get(
            (num_tokens, self.spec.top_k, self.spec.hidden_size),
            device=x.device,
            dtype=x.dtype,
        )

        from kestrel_kernels.cute_moe.dispatch import (
            _invoke_cute_moe_warpgemv_down_slots_fp8,
            _invoke_cute_moe_warpgemv_up_fp8,
        )
        from kestrel_kernels.moe.lora.cute import (
            apply_moe_lora_down_sum,
            apply_moe_lora_up_gelu,
        )

        _invoke_cute_moe_warpgemv_up_fp8(
            x,
            topk_ids,
            up_weight,
            up_scale,
            up_out.view(num_tokens * self.spec.top_k, self.spec.intermediate_size * 2),
            warps_per_block=self.config.num_warps,
        )
        apply_moe_lora_up_gelu(
            x=x,
            topk_ids=topk_ids,
            base_up=up_out,
            activation=activation,
            lora_a=lora.up_a,
            lora_b=lora.up_b,
            active_token_ids=lora.metadata.active_token_ids,
            active_lora_ids=lora.metadata.active_lora_ids,
            active_lora_meta=lora.metadata.active_lora_meta,
            top_k=self.spec.top_k,
            num_experts=self.spec.num_experts,
            scratch=self._lora_scratch(x=x, lora=lora, down=False),
            lora_ranks=lora.lora_ranks,
            active_lora_max_rank=lora.metadata.active_lora_max_rank,
        )

        _invoke_cute_moe_warpgemv_down_slots_fp8(
            activation,
            topk_ids,
            route_weights,
            down_weight,
            down_scale,
            down_out.view(num_tokens * self.spec.top_k, self.spec.hidden_size),
            warps_per_block=self.config.num_warps,
        )
        apply_moe_lora_down_sum(
            x=activation,
            topk_weights=route_weights,
            topk_ids=topk_ids,
            base_down=down_out,
            output=fused,
            lora_a=lora.down_a,
            lora_b=lora.down_b,
            active_token_ids=lora.metadata.active_token_ids,
            active_lora_ids=lora.metadata.active_lora_ids,
            active_lora_meta=lora.metadata.active_lora_meta,
            top_k=1,
            num_experts=self.spec.num_experts,
            scratch=self._lora_scratch(x=x, lora=lora, down=True),
            lora_ranks=lora.lora_ranks,
            active_lora_max_rank=lora.metadata.active_lora_max_rank,
        )
        return fused


def prepare_warpgemv(
    spec: MoeSpec,
    capacity: MoeCapacity,
    device: torch.device,
    config: CuteMoeConfig,
) -> WarpGemvImpl:
    if capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        # Dev JIT needs lora.cute to set CuTe dump env before any other CuTe import.
        import kestrel_kernels.moe.lora.cute  # noqa: F401

    workspace = _make_workspace()
    workspace.up.reserve(
        (capacity.max_tokens, spec.top_k, spec.intermediate_size * 2),
        device=device,
        dtype=spec.dtype,
    )
    workspace.activation.reserve(
        (capacity.max_tokens * spec.top_k, spec.intermediate_size),
        device=device,
        dtype=spec.dtype,
    )
    workspace.down.reserve(
        (capacity.max_tokens, spec.top_k, spec.hidden_size),
        device=device,
        dtype=spec.dtype,
    )
    workspace.output.reserve(
        (capacity.max_tokens, spec.hidden_size),
        device=device,
        dtype=spec.dtype,
    )
    if capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        workspace.lora_up.reserve(
            (capacity.max_tokens * spec.top_k, capacity.max_lora_rank),
            device=device,
            dtype=spec.dtype,
        )
        workspace.lora_down.reserve(
            (capacity.max_tokens * spec.top_k, capacity.max_lora_rank),
            device=device,
            dtype=spec.dtype,
        )
    return WarpGemvImpl(
        spec=spec,
        capacity=capacity,
        device=device,
        config=config,
        workspace=workspace,
    )


__all__ = ["WarpGemvImpl", "prepare_warpgemv"]
