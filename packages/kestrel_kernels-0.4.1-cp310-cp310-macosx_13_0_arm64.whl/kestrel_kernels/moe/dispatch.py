"""Private MoE implementation selection."""

from __future__ import annotations

import torch

from kestrel_kernels.cute_moe.config import (
    get_cute_moe_config,
    has_cute_moe_config,
)
from kestrel_kernels.moe.api import (
    MoeCapacity,
    MoeExpertWeights,
    MoeHandle,
    MoeLoraState,
    MoeSpec,
)
from kestrel_kernels.moe.legacy.ops import LegacyPaddedOps
from kestrel_kernels.moe.legacy.padded import prepare_legacy_padded
from kestrel_kernels.moe.compact import prepare_compact_moe
from kestrel_kernels.moe.warpgemv import prepare_warpgemv


def prepare(
    spec: MoeSpec,
    capacity: MoeCapacity,
    *,
    device: torch.device | str,
) -> MoeHandle:
    device = torch.device(device)
    if device.type == "cuda" and device.index is None and torch.cuda.is_available():
        device = torch.device("cuda", torch.cuda.current_device())

    if device.type == "mps":
        from kestrel_kernels.mps import moe as mps_moe

        ops = LegacyPaddedOps(
            mps_moe.gelu_residual_cute_mps,
            mps_moe.get_moe_block_m_mps,
            mps_moe.invoke_moe_gemm_mps,
            mps_moe.moe_align_block_size_mps,
            mps_moe.moe_sum_mps,
        )
        impl = prepare_legacy_padded(
            spec, capacity, device,
            ops=ops,
        )
        return MoeHandle(spec=spec, capacity=capacity, device=device, impl=impl)

    if device.type != "cuda":
        raise ValueError("MoE handles can only be prepared for CUDA or MPS devices")

    config_dtype = "fp8" if spec.weight_format == "fp8_e4m3" else spec.weight_format
    moe_config = None
    if has_cute_moe_config(
        num_experts=spec.num_experts,
        hidden_size=spec.hidden_size,
        intermediate_size=spec.intermediate_size,
        dtype=config_dtype,
    ):
        moe_config = get_cute_moe_config(
            capacity.max_tokens,
            num_experts=spec.num_experts,
            hidden_size=spec.hidden_size,
            intermediate_size=spec.intermediate_size,
            dtype=config_dtype,
        )
        config = moe_config["up"]
        if config.kernel_type == "warpgemv":
            impl = prepare_warpgemv(spec, capacity, device, config)
            return MoeHandle(spec=spec, capacity=capacity, device=device, impl=impl)
        up_kernel = moe_config["up"].kernel_type
        down_kernel = moe_config["down"].kernel_type
        if up_kernel == down_kernel == "tcgen":
            impl = prepare_compact_moe(spec, capacity, device, moe_config)
            return MoeHandle(spec=spec, capacity=capacity, device=device, impl=impl)
        if "tcgen" in (up_kernel, down_kernel):
            raise ValueError("compact MoE currently requires tcgen for both up and down")

    from kestrel_kernels.gelu_residual import gelu_residual_cute
    from kestrel_kernels.moe_align import moe_align_block_size
    from kestrel_kernels.moe_dispatch import get_moe_block_m, invoke_moe_gemm
    from kestrel_kernels.moe_sum_ops import moe_sum

    ops = LegacyPaddedOps(
        gelu_residual_cute,
        get_moe_block_m,
        invoke_moe_gemm,
        moe_align_block_size,
        moe_sum,
    )

    impl = prepare_legacy_padded(
        spec, capacity, device,
        ops=ops,
    )
    return MoeHandle(spec=spec, capacity=capacity, device=device, impl=impl)


def forward(
    handle: MoeHandle,
    *,
    x: torch.Tensor,
    topk_ids: torch.Tensor,
    topk_weights: torch.Tensor,
    weights: MoeExpertWeights,
    out: torch.Tensor | None = None,
    lora: MoeLoraState | None = None,
) -> torch.Tensor:
    return handle.impl.forward(
        x=x,
        topk_ids=topk_ids,
        topk_weights=topk_weights,
        weights=weights,
        out=out,
        lora=lora,
    )


__all__ = ["forward", "prepare"]
