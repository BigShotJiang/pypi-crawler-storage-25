"""Legacy padded MoE implementation behind the public MoE API."""

from __future__ import annotations

from dataclasses import dataclass

import torch

from kestrel_kernels.moe.api import (
    MoeCapacity,
    MoeExpertWeights,
    MoeLoraState,
    MoeSpec,
)
from kestrel_kernels.moe.legacy.ops import LegacyPaddedOps
from kestrel_kernels.moe.workspace import (
    LegacyRouteWorkspace,
    LegacyWorkspace,
    make_legacy_workspace,
)


def _round_up(x: int, multiple: int) -> int:
    return ((x + multiple - 1) // multiple) * multiple


def _max_tokens_padded(num_assignments: int, num_experts: int, block_size: int) -> int:
    max_num_tokens_padded = num_assignments + num_experts * (block_size - 1)
    if num_assignments < num_experts:
        max_num_tokens_padded = min(
            num_assignments * block_size, max_num_tokens_padded
        )
    return max_num_tokens_padded


def _normalize_expert_weight(weight: torch.Tensor) -> tuple[torch.Tensor, bool]:
    if weight.dtype == torch.uint8:
        return weight, True
    if weight.dtype == torch.float8_e4m3fn:
        return weight.view(torch.uint8), True
    return weight, False


@dataclass(frozen=True)
class _RouteViews:
    sorted_token_ids: torch.Tensor
    expert_ids: torch.Tensor
    num_tokens_post_padded: torch.Tensor


def _use_lora(lora: MoeLoraState | None) -> bool:
    # Non-None state means the caller wants the CUDA LoRA path; pass None for no LoRA.
    return lora is not None


def _lora_a_rank(lora: MoeLoraState, down: bool) -> int:
    return int((lora.down_a if down else lora.up_a).shape[1])


@dataclass
class LegacyPaddedImpl:
    spec: MoeSpec
    capacity: MoeCapacity
    device: torch.device
    block_size_m: int
    route: LegacyRouteWorkspace
    workspace: LegacyWorkspace
    ops: LegacyPaddedOps

    def _route_views(self, num_tokens: int, block_size_m: int) -> _RouteViews:
        em = _max_tokens_padded(
            num_tokens * self.spec.top_k,
            self.spec.num_experts,
            block_size_m,
        )
        num_blocks = _round_up(em, block_size_m) // block_size_m
        return _RouteViews(
            sorted_token_ids=self.route.sorted_token_ids[:em],
            expert_ids=self.route.expert_ids[:num_blocks],
            num_tokens_post_padded=self.route.num_tokens_post_padded,
        )

    def _validate_inputs(
        self,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if x.device != self.device:
            raise ValueError(f"x must be on prepared device {self.device}, got {x.device}")
        if x.device.type not in ("cuda", "mps"):
            raise ValueError("MoE forward supports CUDA or MPS tensors")
        if x.ndim != 2 or x.shape[1] != self.spec.hidden_size:
            raise ValueError(
                f"x must have shape [tokens, {self.spec.hidden_size}], got {tuple(x.shape)}"
            )
        if self.capacity.mode == "decode" and x.shape[0] != self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle token shape mismatch: got {x.shape[0]} tokens, "
                f"prepared for {self.capacity.max_tokens}. Prepare one handle "
                "per CUDA graph/bucket shape."
            )
        if x.shape[0] > self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle capacity overflow: got {x.shape[0]} tokens, "
                f"capacity is {self.capacity.max_tokens}"
            )
        if not x.is_contiguous():
            raise ValueError("x must be contiguous")
        if topk_ids.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_ids must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_weights.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_weights must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_ids.dtype != torch.int32:
            raise ValueError("topk_ids must be int32 for allocation-free MoE forward")
        if topk_weights.dtype not in (x.dtype, torch.float32):
            raise ValueError("topk_weights must be float32 or match x dtype")
        if not topk_ids.is_contiguous() or not topk_weights.is_contiguous():
            raise ValueError("topk_ids and topk_weights must be contiguous")
        if weights.up.device != x.device or weights.down.device != x.device:
            raise ValueError("expert weights must be on the same device as x")

        up_weight, up_is_fp8w = _normalize_expert_weight(weights.up)
        down_weight, down_is_fp8w = _normalize_expert_weight(weights.down)
        if up_is_fp8w != down_is_fp8w:
            raise ValueError("up and down expert weights must use the same dtype scheme")
        if up_is_fp8w:
            if weights.up_scale is None or weights.down_scale is None:
                raise ValueError("FP8 MoE weights require up_scale and down_scale")
            if weights.up_scale.device != x.device or weights.down_scale.device != x.device:
                raise ValueError("expert scales must be on the same device as x")
        else:
            if up_weight.dtype != x.dtype or down_weight.dtype != x.dtype:
                raise ValueError("BF16/FP16 expert weights must match x dtype")
        return up_weight, down_weight

    def _align_base_route(self, topk_ids: torch.Tensor, route: _RouteViews) -> None:
        self.ops.moe_align_block_size(
            topk_ids,
            self.spec.num_experts,
            self.block_size_m,
            route.sorted_token_ids,
            route.expert_ids,
            route.num_tokens_post_padded,
        )

    def _invoke_moe_gemm(
        self,
        A: torch.Tensor,
        B: torch.Tensor,
        B_scale: torch.Tensor | None,
        C: torch.Tensor,
        *,
        topk_weights: torch.Tensor | None,
        route: _RouteViews,
        mul_routed_weight: bool,
        top_k: int,
        a_fp8_bits: torch.Tensor | None = None,
        a_fp8_scale: torch.Tensor | None = None,
    ) -> None:
        if A.device.type == "mps":
            a_fp8_bits = None
            a_fp8_scale = None
        self.ops.invoke_moe_gemm(
            A,
            B,
            C,
            B_scale=B_scale,
            topk_weights=topk_weights,
            sorted_token_ids=route.sorted_token_ids,
            expert_ids=route.expert_ids,
            num_tokens_post_padded=route.num_tokens_post_padded,
            mul_routed_weight=mul_routed_weight,
            top_k=top_k,
            num_experts=self.spec.num_experts,
            input_size=self.spec.hidden_size,
            hidden_size=self.spec.intermediate_size,
            allow_tf32=self.spec.allow_tf32,
            backend_pref=self.spec.backend,
            auto_threshold=self.spec.auto_backend_token_threshold,
            a_fp8_bits=a_fp8_bits,
            a_fp8_scale=a_fp8_scale,
            config_num_tokens=self.capacity.max_tokens,
        )

    def _run_activation(self, up_out: torch.Tensor, num_tokens: int) -> torch.Tensor:
        activation_in = up_out.view(num_tokens * self.spec.top_k, -1)
        activation_out = self.workspace.activation.get(
            (num_tokens * self.spec.top_k, self.spec.intermediate_size),
            device=up_out.device,
            dtype=up_out.dtype,
        )
        self.ops.gelu_residual(activation_out, activation_in)
        return activation_out

    def _lora_scratch(
        self,
        *,
        x: torch.Tensor,
        lora: MoeLoraState,
        down: bool,
    ) -> torch.Tensor:
        return (self.workspace.lora_down if down else self.workspace.lora_up).get(
            (x.shape[0] * self.spec.top_k, _lora_a_rank(lora, down)),
            device=x.device,
            dtype=x.dtype,
        )

    def forward(
        self,
        *,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
        out: torch.Tensor | None,
        lora: MoeLoraState | None,
    ) -> torch.Tensor:
        up_weight, down_weight = self._validate_inputs(x, topk_ids, topk_weights, weights)
        up_is_fp8w = up_weight.dtype == torch.uint8

        num_tokens = int(x.shape[0])
        route = self._route_views(num_tokens, self.block_size_m)
        self._align_base_route(topk_ids, route)

        up_out = self.workspace.up.get(
            (num_tokens, self.spec.top_k, self.spec.intermediate_size * 2),
            device=x.device,
            dtype=x.dtype,
        )
        fp8_up_bits = fp8_up_scale = fp8_down_bits = fp8_down_scale = None
        if up_is_fp8w:
            fp8_up_bits = self.workspace.fp8_up_bits.get(
                (num_tokens, self.spec.hidden_size),
                device=x.device,
                dtype=torch.uint8,
            )
            fp8_up_scale = self.workspace.fp8_up_scale.get(
                (num_tokens,),
                device=x.device,
                dtype=torch.float32,
            )
            fp8_down_bits = self.workspace.fp8_down_bits.get(
                (num_tokens * self.spec.top_k, self.spec.intermediate_size),
                device=x.device,
                dtype=torch.uint8,
            )
            fp8_down_scale = self.workspace.fp8_down_scale.get(
                (num_tokens * self.spec.top_k,),
                device=x.device,
                dtype=torch.float32,
            )

        use_lora = _use_lora(lora)
        if use_lora and x.device.type != "cuda":
            raise ValueError("MoE LoRA is only supported on CUDA")

        if use_lora and lora is not None:
            weight_loras = int(lora.up_a.shape[0]) // self.spec.num_experts
            if weight_loras > self.capacity.max_loras:
                raise RuntimeError(
                    f"MoE LoRA capacity overflow: got {weight_loras} LoRAs, "
                    f"capacity is {self.capacity.max_loras}"
                )

        self._invoke_moe_gemm(
            x,
            up_weight,
            weights.up_scale,
            up_out,
            topk_weights=None,
            route=route,
            mul_routed_weight=False,
            top_k=self.spec.top_k,
            a_fp8_bits=fp8_up_bits,
            a_fp8_scale=fp8_up_scale,
        )

        if use_lora and lora is not None:
            from kestrel_kernels.moe.lora.cute import apply_moe_lora_up_gelu

            down_in = self.workspace.activation.get(
                (num_tokens * self.spec.top_k, self.spec.intermediate_size),
                device=up_out.device,
                dtype=up_out.dtype,
            )
            apply_moe_lora_up_gelu(
                x=x,
                topk_ids=topk_ids,
                base_up=up_out,
                activation=down_in,
                lora_a=lora.up_a,
                lora_b=lora.up_b,
                active_token_ids=lora.metadata.active_token_ids,
                active_lora_ids=lora.metadata.active_lora_ids,
                active_lora_meta=lora.metadata.active_lora_meta,
                top_k=self.spec.top_k,
                num_experts=self.spec.num_experts,
                scratch=self._lora_scratch(x=x, lora=lora, down=False),
                lora_ranks=lora.lora_ranks,
                active_lora_max_rank=lora.metadata.active_lora_max_rank,
            )
        else:
            down_in = self._run_activation(up_out, num_tokens)

        down_out = self.workspace.down.get(
            (num_tokens, self.spec.top_k, self.spec.hidden_size),
            device=x.device,
            dtype=x.dtype,
        )
        self._invoke_moe_gemm(
            down_in,
            down_weight,
            weights.down_scale,
            down_out,
            topk_weights=topk_weights.view(-1),
            route=route,
            mul_routed_weight=True,
            top_k=1,
            a_fp8_bits=fp8_down_bits,
            a_fp8_scale=fp8_down_scale,
        )

        fused = out
        if fused is None:
            fused = self.workspace.output.get(
                (num_tokens, self.spec.hidden_size),
                device=x.device,
                dtype=x.dtype,
            )
        if use_lora and lora is not None:
            from kestrel_kernels.moe.lora.cute import apply_moe_lora_down_sum

            apply_moe_lora_down_sum(
                x=down_in,
                topk_ids=topk_ids,
                topk_weights=topk_weights,
                base_down=down_out,
                output=fused,
                lora_a=lora.down_a,
                lora_b=lora.down_b,
                active_token_ids=lora.metadata.active_token_ids,
                active_lora_ids=lora.metadata.active_lora_ids,
                active_lora_meta=lora.metadata.active_lora_meta,
                top_k=1,
                num_experts=self.spec.num_experts,
                scratch=self._lora_scratch(x=x, lora=lora, down=True),
                lora_ranks=lora.lora_ranks,
                active_lora_max_rank=lora.metadata.active_lora_max_rank,
            )
        else:
            self.ops.moe_sum(down_out, fused)
        return fused


def _make_route_workspace(
    *,
    max_tokens: int,
    top_k: int,
    num_experts: int,
    block_size_m: int,
    device: torch.device,
) -> LegacyRouteWorkspace:
    em = _max_tokens_padded(max_tokens * top_k, num_experts, block_size_m)
    num_blocks = _round_up(em, block_size_m) // block_size_m
    return LegacyRouteWorkspace(
        sorted_token_ids=torch.empty((em,), dtype=torch.int32, device=device),
        expert_ids=torch.empty((num_blocks,), dtype=torch.int32, device=device),
        num_tokens_post_padded=torch.empty((1,), dtype=torch.int32, device=device),
    )


def prepare_legacy_padded(
    spec: MoeSpec,
    capacity: MoeCapacity,
    device: torch.device,
    *,
    ops: LegacyPaddedOps,
) -> LegacyPaddedImpl:
    if device.type not in ("cuda", "mps"):
        raise ValueError("MoE handles can only be prepared for CUDA or MPS devices")

    if device.type == "cuda" and capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        # Dev JIT needs lora.cute to set CuTe dump env before any other CuTe import.
        import kestrel_kernels.moe.lora.cute  # noqa: F401

    block_size_m = ops.get_moe_block_m(
        capacity.max_tokens,
        num_experts=spec.num_experts,
        input_size=spec.hidden_size,
        hidden_size=spec.intermediate_size,
        is_fp8=spec.weight_format == "fp8_e4m3",
        backend_pref=spec.backend,
        auto_threshold=spec.auto_backend_token_threshold,
        device=device,
    )
    workspace = make_legacy_workspace()
    workspace.up.reserve(
        (capacity.max_tokens, spec.top_k, spec.intermediate_size * 2),
        device=device,
        dtype=spec.dtype,
    )
    workspace.activation.reserve(
        (capacity.max_tokens * spec.top_k, spec.intermediate_size),
        device=device,
        dtype=spec.dtype,
    )
    workspace.down.reserve(
        (capacity.max_tokens, spec.top_k, spec.hidden_size),
        device=device,
        dtype=spec.dtype,
    )
    workspace.output.reserve(
        (capacity.max_tokens, spec.hidden_size),
        device=device,
        dtype=spec.dtype,
    )
    if capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        workspace.lora_up.reserve(
            (capacity.max_tokens * spec.top_k, capacity.max_lora_rank),
            device=device,
            dtype=spec.dtype,
        )
        workspace.lora_down.reserve(
            (capacity.max_tokens * spec.top_k, capacity.max_lora_rank),
            device=device,
            dtype=spec.dtype,
        )
    if spec.weight_format == "fp8_e4m3":
        workspace.fp8_up_bits.reserve(
            (capacity.max_tokens, spec.hidden_size),
            device=device,
            dtype=torch.uint8,
        )
        workspace.fp8_up_scale.reserve(
            (capacity.max_tokens,),
            device=device,
            dtype=torch.float32,
        )
        workspace.fp8_down_bits.reserve(
            (capacity.max_tokens * spec.top_k, spec.intermediate_size),
            device=device,
            dtype=torch.uint8,
        )
        workspace.fp8_down_scale.reserve(
            (capacity.max_tokens * spec.top_k,),
            device=device,
            dtype=torch.float32,
        )

    route = _make_route_workspace(
        max_tokens=capacity.max_tokens,
        top_k=spec.top_k,
        num_experts=spec.num_experts,
        block_size_m=block_size_m,
        device=device,
    )
    return LegacyPaddedImpl(
        spec=spec,
        capacity=capacity,
        device=device,
        block_size_m=int(block_size_m),
        route=route,
        workspace=workspace,
        ops=ops,
    )


__all__ = ["LegacyPaddedImpl", "prepare_legacy_padded"]
