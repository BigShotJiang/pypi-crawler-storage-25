"""Backend ops used by the legacy padded MoE implementation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class LegacyPaddedOps:
    gelu_residual: Callable[..., Any]
    get_moe_block_m: Callable[..., Any]
    invoke_moe_gemm: Callable[..., Any]
    moe_align_block_size: Callable[..., Any]
    moe_sum: Callable[..., Any]


__all__ = ["LegacyPaddedOps"]
