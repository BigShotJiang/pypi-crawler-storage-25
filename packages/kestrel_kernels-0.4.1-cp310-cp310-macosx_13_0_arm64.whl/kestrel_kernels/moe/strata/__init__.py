"""Compact grouped-GEMM MoE variants.

This package is intentionally empty in phase 1.  The public MoE API already
dispatches through an opaque handle, so grouped variants can be added here
without changing inference-engine call sites.
"""

__all__: list[str] = []
