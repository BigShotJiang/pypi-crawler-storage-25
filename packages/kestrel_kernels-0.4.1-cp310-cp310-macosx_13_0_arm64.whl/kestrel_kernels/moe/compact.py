"""Padding-free MoE implementation behind the public MoE runtime API."""

from __future__ import annotations

from dataclasses import dataclass

import torch

from kestrel_kernels.cute_moe.config import CuteMoeConfig
from kestrel_kernels.moe.api import (
    MoeCapacity,
    MoeExpertWeights,
    MoeLoraState,
    MoeSpec,
)
from kestrel_kernels.moe.workspace import FixedWorkspaceBuffer


def _fp8_weight_as_uint8(weight: torch.Tensor, name: str) -> torch.Tensor:
    if weight.dtype == torch.uint8:
        return weight
    if weight.dtype == torch.float8_e4m3fn:
        return weight.view(torch.uint8)
    raise ValueError(f"compact MoE requires FP8 {name} expert weights")


def _lora_a_rank(lora: MoeLoraState, down: bool) -> int:
    return int((lora.down_a if down else lora.up_a).shape[1])


@dataclass(frozen=True)
class CompactRoute:
    sorted_token_ids: torch.Tensor
    cu_seqlens_m: torch.Tensor
    cumsum_buffer: torch.Tensor

    def view(self, assignments: int) -> "CompactRoute":
        return CompactRoute(
            sorted_token_ids=self.sorted_token_ids[:assignments],
            cu_seqlens_m=self.cu_seqlens_m,
            cumsum_buffer=self.cumsum_buffer,
        )


@dataclass
class CompactMoeWorkspace:
    up: FixedWorkspaceBuffer
    activation: FixedWorkspaceBuffer
    down: FixedWorkspaceBuffer
    output: FixedWorkspaceBuffer
    lora_up: FixedWorkspaceBuffer
    lora_down: FixedWorkspaceBuffer
    fp8_up_bits: FixedWorkspaceBuffer
    fp8_up_scale: FixedWorkspaceBuffer
    fp8_down_bits: FixedWorkspaceBuffer
    fp8_down_scale: FixedWorkspaceBuffer
    up_routed_bits: FixedWorkspaceBuffer
    up_row_scale: FixedWorkspaceBuffer
    down_routed_bits: FixedWorkspaceBuffer
    down_row_scale: FixedWorkspaceBuffer


def _make_workspace() -> CompactMoeWorkspace:
    return CompactMoeWorkspace(
        up=FixedWorkspaceBuffer("MoE compact up workspace"),
        activation=FixedWorkspaceBuffer("MoE compact activation workspace"),
        down=FixedWorkspaceBuffer("MoE compact down workspace"),
        output=FixedWorkspaceBuffer("MoE compact output workspace"),
        lora_up=FixedWorkspaceBuffer("MoE compact LoRA up workspace"),
        lora_down=FixedWorkspaceBuffer("MoE compact LoRA down workspace"),
        fp8_up_bits=FixedWorkspaceBuffer("MoE compact FP8 up bits workspace"),
        fp8_up_scale=FixedWorkspaceBuffer("MoE compact FP8 up scale workspace"),
        fp8_down_bits=FixedWorkspaceBuffer("MoE compact FP8 down bits workspace"),
        fp8_down_scale=FixedWorkspaceBuffer("MoE compact FP8 down scale workspace"),
        up_routed_bits=FixedWorkspaceBuffer("MoE compact up routed bits workspace"),
        up_row_scale=FixedWorkspaceBuffer("MoE compact up row scale workspace"),
        down_routed_bits=FixedWorkspaceBuffer("MoE compact down routed bits workspace"),
        down_row_scale=FixedWorkspaceBuffer("MoE compact down row scale workspace"),
    )


def _reserve_workspace(
    workspace: CompactMoeWorkspace,
    spec: MoeSpec,
    capacity: MoeCapacity,
    device: torch.device,
) -> None:
    max_tokens = capacity.max_tokens
    assignments = max_tokens * spec.top_k
    reservations = [
        (workspace.up, (max_tokens, spec.top_k, spec.intermediate_size * 2), spec.dtype),
        (workspace.activation, (assignments, spec.intermediate_size), spec.dtype),
        (workspace.down, (max_tokens, spec.top_k, spec.hidden_size), spec.dtype),
        (workspace.output, (max_tokens, spec.hidden_size), spec.dtype),
        (workspace.fp8_up_bits, (max_tokens, spec.hidden_size), torch.uint8),
        (workspace.fp8_up_scale, (max_tokens,), torch.float32),
        (workspace.fp8_down_bits, (assignments, spec.intermediate_size), torch.uint8),
        (workspace.fp8_down_scale, (assignments,), torch.float32),
        (workspace.up_routed_bits, (assignments, spec.hidden_size), torch.uint8),
        (workspace.up_row_scale, (assignments,), torch.float32),
        (workspace.down_routed_bits, (assignments, spec.intermediate_size), torch.uint8),
        (workspace.down_row_scale, (assignments,), torch.float32),
    ]
    if capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        reservations.extend(
            [
                (workspace.lora_up, (assignments, capacity.max_lora_rank), spec.dtype),
                (workspace.lora_down, (assignments, capacity.max_lora_rank), spec.dtype),
            ]
        )
    for buffer, shape, dtype in reservations:
        buffer.reserve(shape, device=device, dtype=dtype)


def _make_route_workspace(
    *,
    max_tokens: int,
    top_k: int,
    num_experts: int,
    device: torch.device,
) -> CompactRoute:
    assignments = max_tokens * top_k
    return CompactRoute(
        sorted_token_ids=torch.empty((assignments,), dtype=torch.int32, device=device),
        cu_seqlens_m=torch.empty((num_experts + 1,), dtype=torch.int32, device=device),
        cumsum_buffer=torch.empty((num_experts,), dtype=torch.int32, device=device),
    )


@dataclass
class CompactMoeImpl:
    spec: MoeSpec
    capacity: MoeCapacity
    device: torch.device
    up_config: CuteMoeConfig
    down_config: CuteMoeConfig
    route: CompactRoute
    workspace: CompactMoeWorkspace

    def _route_view(self, num_tokens: int) -> CompactRoute:
        return self.route.view(num_tokens * self.spec.top_k)

    def _validate_inputs(
        self,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        if x.device != self.device:
            raise ValueError(f"x must be on prepared device {self.device}, got {x.device}")
        if x.device.type != "cuda":
            raise ValueError("compact MoE requires CUDA tensors")
        if x.dtype != torch.bfloat16:
            raise ValueError("compact MoE requires BF16 activations")
        if x.ndim != 2 or x.shape[1] != self.spec.hidden_size:
            raise ValueError(
                f"x must have shape [tokens, {self.spec.hidden_size}], got {tuple(x.shape)}"
            )
        if self.capacity.mode == "decode" and x.shape[0] != self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle token shape mismatch: got {x.shape[0]} tokens, "
                f"prepared for {self.capacity.max_tokens}. Prepare one handle "
                "per CUDA graph/bucket shape."
            )
        if x.shape[0] > self.capacity.max_tokens:
            raise RuntimeError(
                f"MoE handle capacity overflow: got {x.shape[0]} tokens, "
                f"capacity is {self.capacity.max_tokens}"
            )
        if not x.is_contiguous():
            raise ValueError("x must be contiguous")
        if topk_ids.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_ids must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_weights.shape != (x.shape[0], self.spec.top_k):
            raise ValueError(
                f"topk_weights must have shape [{x.shape[0]}, {self.spec.top_k}]"
            )
        if topk_ids.dtype != torch.int32:
            raise ValueError("topk_ids must be int32 for allocation-free MoE forward")
        if topk_weights.dtype not in (torch.bfloat16, torch.float32):
            raise ValueError("topk_weights must be bf16 or float32")
        if not topk_ids.is_contiguous() or not topk_weights.is_contiguous():
            raise ValueError("topk_ids and topk_weights must be contiguous")
        if weights.up.device != x.device or weights.down.device != x.device:
            raise ValueError("expert weights must be on the same device as x")

        up_weight = _fp8_weight_as_uint8(weights.up, "up")
        down_weight = _fp8_weight_as_uint8(weights.down, "down")
        if weights.up_scale is None or weights.down_scale is None:
            raise ValueError("FP8 MoE weights require up_scale and down_scale")
        if weights.up_scale.device != x.device or weights.down_scale.device != x.device:
            raise ValueError("expert scales must be on the same device as x")
        if tuple(up_weight.shape) != (
            self.spec.num_experts,
            self.spec.intermediate_size * 2,
            self.spec.hidden_size,
        ):
            raise ValueError(
                "up expert weights must have shape "
                "[num_experts, 2 * intermediate_size, hidden_size]"
            )
        if tuple(down_weight.shape) != (
            self.spec.num_experts,
            self.spec.hidden_size,
            self.spec.intermediate_size,
        ):
            raise ValueError(
                "down expert weights must have shape "
                "[num_experts, hidden_size, intermediate_size]"
            )
        if tuple(weights.up_scale.shape) != (
            self.spec.num_experts,
            self.spec.intermediate_size * 2,
        ):
            raise ValueError("up_scale must have shape [num_experts, 2 * intermediate_size]")
        if tuple(weights.down_scale.shape) != (self.spec.num_experts, self.spec.hidden_size):
            raise ValueError("down_scale must have shape [num_experts, hidden_size]")
        return topk_weights, up_weight, weights.up_scale, down_weight, weights.down_scale

    def _validate_lora_capacity(self, lora: MoeLoraState) -> None:
        weight_loras = int(lora.up_a.shape[0]) // self.spec.num_experts
        if weight_loras > self.capacity.max_loras:
            raise RuntimeError(
                f"MoE LoRA capacity overflow: got {weight_loras} LoRAs, "
                f"capacity is {self.capacity.max_loras}"
            )
        max_rank = max(int(lora.up_a.shape[1]), int(lora.down_a.shape[1]))
        if max_rank > self.capacity.max_lora_rank:
            raise RuntimeError(
                f"MoE LoRA rank overflow: got rank {max_rank}, "
                f"capacity is {self.capacity.max_lora_rank}"
            )

    def _output(self, x: torch.Tensor, out: torch.Tensor | None) -> torch.Tensor:
        num_tokens = int(x.shape[0])
        if out is None:
            return self.workspace.output.get(
                (num_tokens, self.spec.hidden_size),
                device=x.device,
                dtype=x.dtype,
            )
        if (
            tuple(out.shape) != (num_tokens, self.spec.hidden_size)
            or out.device != x.device
            or out.dtype != x.dtype
            or not out.is_contiguous()
        ):
            raise ValueError(
                f"out must be contiguous BF16 with shape "
                f"[{num_tokens}, {self.spec.hidden_size}]"
            )
        return out

    def _lora_scratch(
        self,
        *,
        x: torch.Tensor,
        lora: MoeLoraState,
        down: bool,
    ) -> torch.Tensor:
        return (self.workspace.lora_down if down else self.workspace.lora_up).get(
            (x.shape[0] * self.spec.top_k, _lora_a_rank(lora, down)),
            device=x.device,
            dtype=x.dtype,
        )

    def _route(self, topk_ids: torch.Tensor, route: CompactRoute) -> None:
        from kestrel_kernels.moe.routing import moe_route_topk

        moe_route_topk(
            topk_ids,
            self.spec.num_experts,
            route.sorted_token_ids,
            route.cu_seqlens_m,
            route.cumsum_buffer,
        )

    def _run_activation(self, up_out: torch.Tensor, num_tokens: int) -> torch.Tensor:
        activation_in = up_out.view(num_tokens * self.spec.top_k, -1)
        activation_out = self.workspace.activation.get(
            (num_tokens * self.spec.top_k, self.spec.intermediate_size),
            device=up_out.device,
            dtype=up_out.dtype,
        )
        from kestrel_kernels.gelu_residual import gelu_residual_cute

        gelu_residual_cute(activation_out, activation_in)
        return activation_out

    def _invoke_up(
        self,
        x: torch.Tensor,
        up_weight: torch.Tensor,
        up_scale: torch.Tensor,
        up_out: torch.Tensor,
        route: CompactRoute,
    ) -> None:
        from kestrel_kernels.cute_moe.dispatch import invoke_cute_moe_up_fp8_tcgen
        from kestrel_kernels.fp8_quant_cute import fp8_quant_cute

        num_tokens = int(x.shape[0])
        a_bits = self.workspace.fp8_up_bits.get(
            (num_tokens, self.spec.hidden_size),
            device=x.device,
            dtype=torch.uint8,
        )
        a_scale = self.workspace.fp8_up_scale.get(
            (num_tokens,),
            device=x.device,
            dtype=torch.float32,
        )
        routed_bits = self.workspace.up_routed_bits.get(
            (num_tokens * self.spec.top_k, self.spec.hidden_size),
            device=x.device,
            dtype=torch.uint8,
        )
        row_scale = self.workspace.up_row_scale.get(
            (num_tokens * self.spec.top_k,),
            device=x.device,
            dtype=torch.float32,
        )
        fp8_quant_cute(a_bits, a_scale, x)
        invoke_cute_moe_up_fp8_tcgen(
            a_bits,
            a_scale,
            up_weight,
            up_scale,
            up_out,
            sorted_token_ids=route.sorted_token_ids,
            cu_seqlens_m=route.cu_seqlens_m,
            A_routed_bits=routed_bits,
            row_scale=row_scale,
            config=self.up_config,
        )

    def _invoke_down(
        self,
        down_in: torch.Tensor,
        topk_weights: torch.Tensor,
        down_weight: torch.Tensor,
        down_scale: torch.Tensor,
        down_out: torch.Tensor,
        route: CompactRoute,
    ) -> None:
        from kestrel_kernels.cute_moe.dispatch import invoke_cute_moe_down_fp8_tcgen
        from kestrel_kernels.fp8_quant_cute import fp8_quant_cute

        num_tokens = int(down_out.shape[0])
        assignments = num_tokens * self.spec.top_k
        a_bits = self.workspace.fp8_down_bits.get(
            (assignments, self.spec.intermediate_size),
            device=down_in.device,
            dtype=torch.uint8,
        )
        a_scale = self.workspace.fp8_down_scale.get(
            (assignments,),
            device=down_in.device,
            dtype=torch.float32,
        )
        routed_bits = self.workspace.down_routed_bits.get(
            (assignments, self.spec.intermediate_size),
            device=down_in.device,
            dtype=torch.uint8,
        )
        row_scale = self.workspace.down_row_scale.get(
            (assignments,),
            device=down_in.device,
            dtype=torch.float32,
        )
        fp8_quant_cute(a_bits, a_scale, down_in)
        invoke_cute_moe_down_fp8_tcgen(
            a_bits,
            a_scale,
            down_weight,
            down_scale,
            down_out,
            topk_weights=topk_weights.view(-1),
            sorted_token_ids=route.sorted_token_ids,
            cu_seqlens_m=route.cu_seqlens_m,
            A_routed_bits=routed_bits,
            row_scale=row_scale,
            config=self.down_config,
        )

    def forward(
        self,
        *,
        x: torch.Tensor,
        topk_ids: torch.Tensor,
        topk_weights: torch.Tensor,
        weights: MoeExpertWeights,
        out: torch.Tensor | None,
        lora: MoeLoraState | None,
    ) -> torch.Tensor:
        route_weights, up_weight, up_scale, down_weight, down_scale = (
            self._validate_inputs(x, topk_ids, topk_weights, weights)
        )
        if lora is not None:
            self._validate_lora_capacity(lora)

        num_tokens = int(x.shape[0])
        fused = self._output(x, out)
        route = self._route_view(num_tokens)
        self._route(topk_ids, route)

        up_out = self.workspace.up.get(
            (num_tokens, self.spec.top_k, self.spec.intermediate_size * 2),
            device=x.device,
            dtype=x.dtype,
        )
        self._invoke_up(x, up_weight, up_scale, up_out, route)

        if lora is not None:
            from kestrel_kernels.moe.lora.cute import apply_moe_lora_up_gelu

            down_in = self.workspace.activation.get(
                (num_tokens * self.spec.top_k, self.spec.intermediate_size),
                device=up_out.device,
                dtype=up_out.dtype,
            )
            apply_moe_lora_up_gelu(
                x=x,
                topk_ids=topk_ids,
                base_up=up_out,
                activation=down_in,
                lora_a=lora.up_a,
                lora_b=lora.up_b,
                active_token_ids=lora.metadata.active_token_ids,
                active_lora_ids=lora.metadata.active_lora_ids,
                active_lora_meta=lora.metadata.active_lora_meta,
                top_k=self.spec.top_k,
                num_experts=self.spec.num_experts,
                scratch=self._lora_scratch(x=x, lora=lora, down=False),
                lora_ranks=lora.lora_ranks,
                active_lora_max_rank=lora.metadata.active_lora_max_rank,
            )
        else:
            down_in = self._run_activation(up_out, num_tokens)

        down_out = self.workspace.down.get(
            (num_tokens, self.spec.top_k, self.spec.hidden_size),
            device=x.device,
            dtype=x.dtype,
        )
        self._invoke_down(down_in, route_weights, down_weight, down_scale, down_out, route)

        if lora is not None:
            from kestrel_kernels.moe.lora.cute import apply_moe_lora_down_sum

            apply_moe_lora_down_sum(
                x=down_in,
                topk_ids=topk_ids,
                topk_weights=route_weights,
                base_down=down_out,
                output=fused,
                lora_a=lora.down_a,
                lora_b=lora.down_b,
                active_token_ids=lora.metadata.active_token_ids,
                active_lora_ids=lora.metadata.active_lora_ids,
                active_lora_meta=lora.metadata.active_lora_meta,
                top_k=1,
                num_experts=self.spec.num_experts,
                scratch=self._lora_scratch(x=x, lora=lora, down=True),
                lora_ranks=lora.lora_ranks,
                active_lora_max_rank=lora.metadata.active_lora_max_rank,
            )
        else:
            from kestrel_kernels.moe_sum_ops import moe_sum

            moe_sum(down_out, fused)
        return fused


def prepare_compact_moe(
    spec: MoeSpec,
    capacity: MoeCapacity,
    device: torch.device,
    configs: dict[str, CuteMoeConfig],
) -> CompactMoeImpl:
    up_config = configs["up"]
    down_config = configs["down"]
    if up_config.kernel_type != "tcgen" or down_config.kernel_type != "tcgen":
        raise ValueError("compact MoE currently requires tcgen for both up and down")
    if spec.weight_format != "fp8_e4m3":
        raise ValueError("compact MoE requires FP8 expert weights")
    if device.type != "cuda":
        raise ValueError("compact MoE requires CUDA")

    if capacity.max_loras > 0 and capacity.max_lora_rank > 0:
        # Dev JIT needs lora.cute to set CuTe dump env before any other CuTe import.
        import kestrel_kernels.moe.lora.cute  # noqa: F401

    workspace = _make_workspace()
    _reserve_workspace(workspace, spec, capacity, device)

    route = _make_route_workspace(
        max_tokens=capacity.max_tokens,
        top_k=spec.top_k,
        num_experts=spec.num_experts,
        device=device,
    )
    return CompactMoeImpl(
        spec=spec,
        capacity=capacity,
        device=device,
        up_config=up_config,
        down_config=down_config,
        route=route,
        workspace=workspace,
    )


__all__ = ["CompactMoeImpl", "prepare_compact_moe"]
