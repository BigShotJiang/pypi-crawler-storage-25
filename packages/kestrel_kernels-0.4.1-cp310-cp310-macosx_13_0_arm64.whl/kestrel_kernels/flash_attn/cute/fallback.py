"""Torch SDPA fallback for flash attention on non-SM90 devices."""


import math
from functools import lru_cache
from typing import Callable, Optional, Tuple

import torch
import torch.nn.functional as F

from kestrel_kernels.fallback import warn_fallback_once
from kestrel_kernels.flash_attn.cute.mask_ids import PREFIX_LM_730_MASK_ID


def _mps_ops():
    from kestrel_kernels.mps import _native as _mps_native

    return _mps_native.ops


def _is_prefix_lm_730(mask_mod: Optional[Callable]) -> bool:
    if mask_mod is None:
        return False
    return getattr(mask_mod, "__cute_hash__", None) == PREFIX_LM_730_MASK_ID


def _prepare_kv_for_sdpa(
    *,
    k: torch.Tensor,
    v: torch.Tensor,
    target_dtype: torch.dtype,
    k_scale: float,
    v_scale: float,
) -> tuple[torch.Tensor, torch.Tensor, float, float]:
    q_scale = 1.0
    out_scale = 1.0

    if k.dtype == torch.float8_e4m3fn:
        k = k.to(target_dtype)
        q_scale = float(k_scale)
    elif k.dtype != target_dtype:
        k = k.to(target_dtype)

    if v.dtype == torch.float8_e4m3fn:
        v = v.to(target_dtype)
        out_scale = float(v_scale)
    elif v.dtype != target_dtype:
        v = v.to(target_dtype)

    return k, v, q_scale, out_scale


def _index_select_first_dim(t: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    # Torch 2.4 on Jetson lacks float8 index_select CUDA kernels.
    if t.dtype == torch.float8_e4m3fn:
        return t.view(torch.uint8).index_select(0, idx).view(torch.float8_e4m3fn)
    return t.index_select(0, idx)


from collections import OrderedDict

# LRU-bounded cache. Long-lived inference workers can see many distinct
# (q_len, kv_len) combos; entries are MPS device tensors and would
# otherwise grow without bound. 32 keeps the steady-state set (Moondream
# 2 typically uses qL=730 with a handful of kv_len values) hot while
# capping device memory at ~16 MB for the largest masks.
_PREFIX_LM_730_CACHE_MAX = 32
_prefix_lm_730_mask_cache: "OrderedDict[tuple, torch.Tensor]" = OrderedDict()


def _get_prefix_lm_730_mask(
    q_len: int, kv_len: int, device: torch.device, dtype: torch.dtype,
) -> torch.Tensor:
    """LRU-cached additive mask for the MPS paged-prefill kernel:
    ``[1, 1, qL, kL]`` fp16, ``0`` on positions allowed by prefix_lm_730,
    ``-inf`` elsewhere.

    Identical semantics to ``_build_additive_attn_mask`` for the
    prefix_lm_730 case; cached separately so the per-call rebuild
    doesn't show up in the prefill hot path. Key includes dtype and
    device so the same shape across fp16 / bf16 stays separate (MPS
    is fp16 in production today).
    """
    key = (q_len, kv_len, str(device), dtype)
    cached = _prefix_lm_730_mask_cache.get(key)
    if cached is not None:
        _prefix_lm_730_mask_cache.move_to_end(key)
        return cached

    kv_idx = torch.arange(kv_len, device=device, dtype=torch.int64)
    q_abs_idx = torch.arange(q_len, device=device, dtype=torch.int64) + max(kv_len - q_len, 0)
    causal_allowed = kv_idx.unsqueeze(0) <= q_abs_idx.unsqueeze(1)
    both_prefix = (q_abs_idx.unsqueeze(1) < 730) & (kv_idx.unsqueeze(0) < 730)
    allowed = both_prefix | causal_allowed

    mask_2d = torch.zeros((q_len, kv_len), dtype=dtype, device=device)
    mask_2d.masked_fill_(~allowed, float("-inf"))
    mask = mask_2d.view(1, 1, q_len, kv_len)
    _prefix_lm_730_mask_cache[key] = mask
    if len(_prefix_lm_730_mask_cache) > _PREFIX_LM_730_CACHE_MAX:
        _prefix_lm_730_mask_cache.popitem(last=False)
    return mask


def _build_additive_attn_mask(
    *,
    q_len: int,
    kv_len: int,
    causal: bool,
    prefix_lm_730: bool,
    device: torch.device,
) -> Optional[torch.Tensor]:
    if not causal and not prefix_lm_730:
        return None
    if q_len == 1:
        # For the decode-style single-query case, q_abs_idx = kv_len - 1, so causal
        # (and prefix_lm_730 OR causal) admits all keys; no explicit mask is needed.
        return None

    kv_idx = torch.arange(kv_len, device=device, dtype=torch.int64)
    q_abs_idx = torch.arange(q_len, device=device, dtype=torch.int64) + max(kv_len - q_len, 0)

    causal_allowed = kv_idx.unsqueeze(0) <= q_abs_idx.unsqueeze(1)
    allowed = causal_allowed
    if prefix_lm_730:
        both_prefix = (q_abs_idx.unsqueeze(1) < 730) & (kv_idx.unsqueeze(0) < 730)
        allowed = both_prefix | causal_allowed

    attn_mask = torch.zeros((q_len, kv_len), dtype=torch.float32, device=device)
    attn_mask.masked_fill_(~allowed, float("-inf"))
    return attn_mask


def _sdpa(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    attn_mask: Optional[torch.Tensor],
    softmax_scale: Optional[float],
) -> torch.Tensor:
    if attn_mask is not None and attn_mask.dtype != q.dtype:
        attn_mask = attn_mask.to(q.dtype)
    kwargs = {
        "attn_mask": attn_mask,
        "dropout_p": 0.0,
        "is_causal": False,
    }
    if softmax_scale is None:
        return F.scaled_dot_product_attention(q, k, v, **kwargs)
    try:
        return F.scaled_dot_product_attention(q, k, v, scale=float(softmax_scale), **kwargs)
    except TypeError:
        default_scale = 1.0 / math.sqrt(q.shape[-1])
        q_scaled = q if math.isclose(float(softmax_scale), default_scale) else q * (float(softmax_scale) / default_scale)
        return F.scaled_dot_product_attention(q_scaled, k, v, **kwargs)


def _attention_forward(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    q_len: int,
    kv_len: int,
    causal: bool,
    prefix_lm_730: bool,
    softmax_scale: Optional[float],
) -> torch.Tensor:
    attn_mask = _build_additive_attn_mask(
        q_len=q_len,
        kv_len=kv_len,
        causal=causal,
        prefix_lm_730=prefix_lm_730,
        device=q.device,
    )
    return (
        _sdpa(
            q=q,
            k=k,
            v=v,
            attn_mask=attn_mask,
            softmax_scale=softmax_scale,
        )
    )


@lru_cache(maxsize=1)
def _get_flex_attention_symbols():
    try:
        from torch.nn.attention.flex_attention import BlockMask
        from torch.nn.attention.flex_attention import flex_attention
    except Exception as exc:
        raise RuntimeError(
            "paged decode flex fallback requires torch.nn.attention.flex_attention "
            "in the active torch build"
        ) from exc
    return BlockMask, flex_attention


@lru_cache(maxsize=1)
def _get_graph_safe_flex_attention():
    _, flex_attention = _get_flex_attention_symbols()
    try:
        return torch.compile(flex_attention, fullgraph=True)  # type: ignore[arg-type]
    except Exception as exc:
        raise RuntimeError(
            "paged decode flex fallback requires torch.compile(flex_attention, fullgraph=True)"
        ) from exc


def _build_paged_decode_block_mask(
    *,
    page_table: torch.Tensor,
    seqused_k: Optional[torch.Tensor],
    total_pages: int,
    block_size: int,
) -> object:
    BlockMask, _ = _get_flex_attention_symbols()
    if page_table.ndim != 2:
        raise ValueError("paged decode expects page_table with shape [batch, max_pages_per_seq]")
    if page_table.dtype != torch.int32:
        raise ValueError("paged decode expects page_table dtype int32")

    if block_size <= 0:
        raise ValueError("block_size must be positive")

    batch_size, max_pages_per_seq = page_table.shape
    valid_pages = (page_table >= 0) & (page_table < total_pages)
    if seqused_k is not None:
        if seqused_k.ndim != 1 or seqused_k.shape[0] != batch_size:
            raise ValueError("seqused_k must be shape [batch] for paged decode")
        seqused_i32 = seqused_k.to(dtype=torch.int32)
        logical_idx = torch.arange(max_pages_per_seq, device=page_table.device, dtype=torch.int32)
        token_valid = valid_pages & (logical_idx.unsqueeze(0) < seqused_i32.unsqueeze(1))
    else:
        token_valid = valid_pages

    physical_idx = torch.where(token_valid, page_table, torch.zeros_like(page_table))

    # Build physical->logical lookup used to filter inactive tokens within selected blocks.
    logical_idx = torch.arange(max_pages_per_seq, device=page_table.device, dtype=torch.int32)
    logical_idx = logical_idx.unsqueeze(0).expand(batch_size, -1)
    src_logical = torch.where(token_valid, logical_idx, torch.full_like(logical_idx, -1))
    physical_to_logical = torch.full(
        (batch_size, total_pages),
        -1,
        dtype=torch.int32,
        device=page_table.device,
    )
    physical_to_logical.scatter_reduce_(
        1,
        physical_idx,
        src_logical,
        reduce="amax",
        include_self=True,
    )

    block_count = (total_pages + block_size - 1) // block_size
    physical_block_ids = torch.div(physical_idx, block_size, rounding_mode="floor")
    block_present = torch.zeros(
        (batch_size, block_count),
        dtype=torch.int32,
        device=page_table.device,
    )
    block_present.scatter_reduce_(
        1,
        physical_block_ids,
        token_valid.to(torch.int32),
        reduce="amax",
        include_self=True,
    )

    all_blocks = torch.arange(block_count, device=page_table.device, dtype=torch.int32)
    all_blocks = all_blocks.view(1, block_count).expand(batch_size, -1)
    sort_keys = torch.where(block_present > 0, all_blocks, all_blocks + block_count)
    packed_blocks = torch.sort(sort_keys, dim=1).values
    packed_blocks = torch.where(
        packed_blocks < block_count, packed_blocks, torch.zeros_like(packed_blocks)
    )
    kv_num_blocks = block_present.sum(dim=1, dtype=torch.int32).view(batch_size, 1, 1).contiguous()
    kv_indices = packed_blocks.view(batch_size, 1, 1, block_count).contiguous()

    def decode_mask_mod(
        b: torch.Tensor,
        _h: torch.Tensor,
        _q_idx: torch.Tensor,
        kv_idx: torch.Tensor,
    ) -> torch.Tensor:
        return physical_to_logical[b, kv_idx] >= 0

    seq_lengths = (1, total_pages)
    return BlockMask.from_kv_blocks(
        kv_num_blocks=kv_num_blocks,
        kv_indices=kv_indices,
        BLOCK_SIZE=block_size,
        seq_lengths=seq_lengths,
        mask_mod=decode_mask_mod,
    )


def _paged_decode_flex_attention(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    page_table: torch.Tensor,
    seqused_k: Optional[torch.Tensor],
    softmax_scale: Optional[float],
) -> torch.Tensor:
    graph_safe_flex = _get_graph_safe_flex_attention()
    if k.shape[1] != 1 or v.shape[1] != 1:
        raise NotImplementedError("paged decode flex fallback currently requires page_size == 1")

    total_pages = int(k.shape[0])
    block_size = 128
    k_phys = k[:, 0, :, :].permute(1, 0, 2).unsqueeze(0)
    v_phys = v[:, 0, :, :].permute(1, 0, 2).unsqueeze(0)
    k_phys = k_phys.expand(q.shape[0], -1, -1, -1)
    v_phys = v_phys.expand(q.shape[0], -1, -1, -1)

    block_mask = _build_paged_decode_block_mask(
        page_table=page_table,
        seqused_k=seqused_k,
        total_pages=total_pages,
        block_size=block_size,
    )
    return graph_safe_flex(
        q,
        k_phys,
        v_phys,
        block_mask=block_mask,
        scale=softmax_scale,
    )


def flash_attn_fwd_torch_fallback(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    page_table: Optional[torch.Tensor],
    softmax_scale: Optional[float],
    causal: bool,
    softcap: Optional[float] = None,
    window_size_left: Optional[int],
    window_size_right: Optional[int],
    score_mod: Optional[Callable],
    mask_mod: Optional[Callable],
    aux_tensors: Optional[list[torch.Tensor]],
    learnable_sink: Optional[torch.Tensor],
    out: torch.Tensor,
    lse: Optional[torch.Tensor],
    k_scale: float,
    v_scale: float,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    if q.device.type not in ("cuda", "mps"):
        raise RuntimeError(
            "flash_attn SDPA fallback expects CUDA or MPS tensors; "
            f"got device={q.device}"
        )

    if softcap is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support softcap")
    if score_mod is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support score_mod")
    if aux_tensors is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support aux_tensors")
    if learnable_sink is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support learnable_sink")
    if lse is not None:
        raise NotImplementedError(
            "flash_attn SDPA fallback does not support lse outputs. "
            "Shipped cubin variants don't emit LSE either; install the "
            "`jit` dependency group (`uv sync --group jit` / "
            "`pip install --group jit`) and set `KESTREL_CUTE_JIT=1` "
            "to take the JIT cute kernel path, which does populate lse."
        )
    if window_size_left is not None or window_size_right is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support sliding-window attention")

    prefix_lm_730 = _is_prefix_lm_730(mask_mod)
    if mask_mod is not None and not prefix_lm_730:
        raise NotImplementedError("flash_attn SDPA fallback only supports cute_prefix_lm_mask_730")

    if q.device.type == "cuda":
        major, minor = torch.cuda.get_device_capability(q.device)
        arch_label = f"sm{major}{minor}"
    else:
        arch_label = q.device.type
    variant = "paged" if page_table is not None else "dense"
    mask_kind = "prefix_lm_730" if prefix_lm_730 else ("causal" if causal else "none")
    # MPS shapes that land native Metal kernels below — emitting a
    # "falling back to torch attention" warning for paths we actually
    # accelerate would mislead anyone reading the log.
    _mps_dense_metal_path = (
        q.device.type == "mps"
        and page_table is None
        and not causal
        and not prefix_lm_730
        and q.dtype == torch.float16
        and q.dim() == 4
        and q.shape[-1] == 72
    )
    _mps_paged_decode_metal_path = (
        q.device.type == "mps"
        and page_table is not None
        and causal
        and not prefix_lm_730
        and q.dtype == torch.float16
        and q.dim() == 4
        and q.shape[1] == 1              # decode (q_len=1)
        and q.shape[-1] == 64
    )
    # Mirror the dispatch gate below — anything looser would suppress
    # warnings for true torch fallbacks (shapes the native op rejects),
    # hiding routing regressions. Skips the contiguity / stride /
    # device-equality / page-validity checks here because they need
    # the unpacked k/v/seqused_k/page_size and would have to be
    # recomputed; the broad shape gate is the cheap useful filter.
    _mps_paged_prefill_metal_path = (
        q.device.type == "mps"
        and page_table is not None
        and seqused_k is not None
        and (causal or prefix_lm_730)
        and q.dtype == torch.float16
        and q.dim() == 4
        and q.shape[0] == 1              # B=1
        and q.shape[1] > 1               # prefill (q_len > 1)
        and q.shape[-1] == 64            # text decoder; D=72 has no paged path
        and page_table.device == q.device
        and seqused_k.device == q.device
    )
    if not (
        _mps_dense_metal_path
        or _mps_paged_decode_metal_path
        or _mps_paged_prefill_metal_path
    ):
        warn_fallback_once(
            f"flash_attn_fwd_torch_attention_{variant}_{mask_kind}",
            "kestrel-kernels: falling back to torch attention for flash_attn_fwd "
            f"(arch={arch_label}, variant={variant}, mask={mask_kind}).",
        )

    if cu_seqlens_q is not None or cu_seqlens_k is not None:
        raise NotImplementedError(
            "kestrel-kernels fallback only supports fixed-length dense or paged attention paths used by Kestrel"
        )

    if q.dim() != 4:
        raise ValueError("fixed-length mode expects q with shape [batch, seqlen_q, heads, head_dim]")

    batch_size, q_len, num_q_heads, _head_dim = q.shape
    if seqused_q is not None:
        if seqused_q.ndim != 1 or seqused_q.shape[0] != batch_size:
            raise ValueError("seqused_q must be shape [batch] in fallback")
        q_lens = seqused_q.to(dtype=torch.int64)
        if bool((q_lens < 0).any()) or bool((q_lens > q_len).any()):
            raise ValueError("seqused_q entries must be in [0, q_len]")
    else:
        q_lens = None
    out_result = out

    if page_table is None:
        if k.dim() != 4 or v.dim() != 4:
            raise ValueError("dense mode expects k/v with shape [batch, seqlen_k, heads_kv, head_dim]")
        kv_len = int(k.shape[1])

        k_sdpa, v_sdpa, q_scale, out_scale = _prepare_kv_for_sdpa(
            k=k,
            v=v,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        k_sdpa = k_sdpa.permute(0, 2, 1, 3)
        v_sdpa = v_sdpa.permute(0, 2, 1, 3)
        if q_lens is None:
            q_sdpa = q.permute(0, 2, 1, 3)
            q_sdpa_scaled = q_sdpa if q_scale == 1.0 else q_sdpa.mul(q_scale)

            # MPS dense self-attn shortcut: vision encoder shape (head_dim=72,
            # bf16, no mask, no causal, q_len == kv_len) lands the native
            # ``_mps_ops().flash_attn_dense_into`` Metal kernel
            # (MLX steel attention lift). ~5× per-call vs torch SDPA at
            # SigLIP shapes; the fallback path below is what every other
            # case (head_dim != 72, masked, causal, GQA, non-stride-1 last
            # axis) still uses.
            #
            # The kernel requires ``stride(-1) == 1`` on Q/K/V/out (the
            # head_dim axis is loaded vectorized). ``q_sdpa`` /
            # ``k_sdpa`` / ``v_sdpa`` are produced by ``permute(0,2,1,3)``
            # of the inputs, and ``out_view`` is the same permute of
            # ``out_result``; for sliced or otherwise non-stride-1
            # last-axis views the predicate falls back to torch SDPA so
            # we never trip the C++ ``TORCH_CHECK``. The kernel also
            # writes ``out`` while still reading Q/K/V — if a caller
            # aliases ``out`` with any of them (e.g. reuses ``q`` as
            # ``out``), the writes would corrupt later reads, so we
            # defensively reject any storage overlap and fall through
            # to the SDPA path that materializes its output into a
            # disjoint temporary.
            _out_storage_ptr = out_result.untyped_storage().data_ptr()
            _aliased_with_input = (
                q_sdpa.untyped_storage().data_ptr() == _out_storage_ptr
                or k_sdpa.untyped_storage().data_ptr() == _out_storage_ptr
                or v_sdpa.untyped_storage().data_ptr() == _out_storage_ptr
            )
            if (
                q.device.type == "mps"
                and not causal
                and not prefix_lm_730
                and q.dtype == torch.float16
                and q.shape[-1] == 72
                and q_len == kv_len
                and num_q_heads == int(k_sdpa.shape[1])
                and q_sdpa.stride(-1) == 1
                and k_sdpa.stride(-1) == 1
                and v_sdpa.stride(-1) == 1
                and out_result.stride(-1) == 1
                and not _aliased_with_input
            ):
                effective_scale = (
                    softmax_scale if softmax_scale is not None
                    else 1.0 / (q.shape[-1] ** 0.5)
                )
                # ``q_scale`` is a per-tensor pre-softmax score scaling
                # (see ``_prepare_kv_for_sdpa``). Folding it into the
                # softmax temperature instead of materializing
                # ``q_sdpa.mul(q_scale)`` saves an alloc + a full Q
                # multiply per call. Same applies to writing into
                # ``out_result.permute(0,2,1,3)`` directly: the Metal op
                # supports arbitrary strides on the first three axes
                # (only D needs stride-1), so we skip the temporary
                # ``[B, H, L, D]`` output + post-permute copy.
                effective_scale *= q_scale
                out_view = out_result.permute(0, 2, 1, 3)
                _mps_ops().flash_attn_dense_into(
                    out_view, q_sdpa, k_sdpa, v_sdpa, effective_scale,
                    None, False,
                )
                if out_scale != 1.0:
                    out_result.mul_(out_scale)
                return out_result, None

            out_sdpa = _attention_forward(
                q=q_sdpa_scaled,
                k=k_sdpa,
                v=v_sdpa,
                q_len=q_len,
                kv_len=kv_len,
                causal=causal,
                prefix_lm_730=prefix_lm_730,
                softmax_scale=softmax_scale,
            )
            if out_scale != 1.0:
                out_sdpa = out_sdpa.mul(out_scale)
            out_result.copy_(out_sdpa.permute(0, 2, 1, 3))
        else:
            out_result.zero_()
            q_sdpa_all = q.permute(0, 2, 1, 3)
            for b in range(batch_size):
                q_len_b = int(q_lens[b].item())
                if q_len_b <= 0:
                    continue
                q_b = q_sdpa_all[b : b + 1, :, :q_len_b, :]
                q_b_scaled = q_b if q_scale == 1.0 else q_b.mul(q_scale)
                out_b = _attention_forward(
                    q=q_b_scaled,
                    k=k_sdpa[b : b + 1],
                    v=v_sdpa[b : b + 1],
                    q_len=q_len_b,
                    kv_len=kv_len,
                    causal=causal,
                    prefix_lm_730=prefix_lm_730,
                    softmax_scale=softmax_scale,
                )
                if out_scale != 1.0:
                    out_b = out_b.mul(out_scale)
                out_result[b : b + 1, :q_len_b].copy_(out_b.permute(0, 2, 1, 3))
    else:
        if k.dim() != 4 or v.dim() != 4:
            raise ValueError("paged mode expects k/v with shape [num_pages, page_size, heads_kv, head_dim]")
        page_size = int(k.shape[1])
        num_kv_heads = int(k.shape[2])
        head_dim = int(k.shape[3])
        total_pages = int(k.shape[0])

        # MPS paged decode shortcut: single-query causal attention with
        # paged KV at Moondream 2 text-decoder shape (head_dim=64, no GQA,
        # fp16) lands the native ``_mps_ops().paged_decode_attn_into``
        # Metal kernel — 8–22× faster than the per-batch index_select +
        # SDPA loop below, scaling sub-linearly with kv_len. Falls through
        # to the loop for prefill (q_len > 1), GQA, fp8 KV, or any case
        # the kernel doesn't yet handle.
        #
        # Contiguity gate: kestrel passes ``k_cache.permute(0, 2, 1, 3)``
        # (production ``(N, H, P, D)`` storage → ``(N, P, H, D)`` view).
        # The native kernel needs the production layout back, so we
        # re-permute. For ``page_size = 1`` (production prefix-cache
        # requirement) the round-trip restores a contiguous view; for
        # ``page_size > 1`` from a tensor that wasn't originally
        # ``(N, H, P, D)``-contiguous, the re-permute yields a strided
        # view and we fall through to the torch path rather than
        # raising the kernel's contiguity TORCH_CHECK.
        _k_native = k.permute(0, 2, 1, 3) if (q.device.type == "mps") else None
        _v_native = v.permute(0, 2, 1, 3) if (q.device.type == "mps") else None
        # Native dispatch predicate. The kernel takes per-axis strides
        # for q/out (see ``sdpa_vector_paged`` in
        # ``mlx/backend/metal/kernels/sdpa_vector.h``), so q/out only
        # need ``stride(-1) == 1`` (head_dim contiguous). Anything else
        # the kernel would actually reject — fp16, head_dim=64,
        # no GQA, page-table/seqused_k contiguous, etc. — we fail
        # loudly below if a shape lands here that the native kernel
        # can't handle. No silent torch-SDPA fallback for MPS decode.
        if (
            q.device.type == "mps"
            and q.dtype == torch.float16
            and k.dtype == torch.float16
            and v.dtype == torch.float16
            and out_result.dtype == torch.float16
            and q_len == 1
            and q_lens is None
            and causal
            and not prefix_lm_730
            and q.shape[-1] == 64
            and num_q_heads == num_kv_heads
            and seqused_k is not None
            and float(k_scale) == 1.0
            and float(v_scale) == 1.0
            and q.stride(-1) == 1
            and out_result.stride(-1) == 1
            and page_table.is_contiguous()
            and seqused_k.is_contiguous()
            and _k_native.is_contiguous()
            and _v_native.is_contiguous()
        ):
            effective_scale = (
                softmax_scale if softmax_scale is not None
                else 1.0 / (q.shape[-1] ** 0.5)
            )
            _mps_ops().paged_decode_attn_into(
                out_result,
                q,
                _k_native,
                _v_native,
                page_table.to(dtype=torch.int32),
                seqused_k.to(dtype=torch.int32),
                float(effective_scale),
            )
            return out, None
        elif q.device.type == "mps" and q_len == 1 and causal and not prefix_lm_730:
            # MPS decode that can't take the native kernel — fail
            # rather than silently routing into the per-batch torch
            # SDPA loop, which is 3–12× slower per step at B>1 and
            # has historically masked correctness bugs (e.g.,
            # non-contiguous q from QKV split silently regressing
            # into the loop and tanking decode throughput).
            raise NotImplementedError(
                f"MPS paged decode requires the native kernel: got "
                f"q.shape={tuple(q.shape)} q.stride={q.stride()} "
                f"q.dtype={q.dtype} num_q_heads={num_q_heads} "
                f"num_kv_heads={num_kv_heads} k_scale={k_scale} "
                f"v_scale={v_scale}. Verify the conditions above "
                f"(fp16, head_dim=64, no GQA, page_table contiguous, "
                f"q/out stride(-1)==1) — the torch fallback path is "
                f"intentionally disabled on MPS decode."
            )

        # MPS paged prefill shortcut: multi-query attention with paged
        # KV at Moondream 2 text-decoder shape (head_dim=64, no GQA,
        # fp16, page_size=1, causal or prefix_lm_730 mask). Lands the
        # native ``_mps_ops().paged_prefill_attn_into`` Metal
        # kernel — same MLX steel-attention math as ``flash_attn_dense_into``
        # but with K/V loaded via page-table indirection instead of a
        # host-side ``index_select`` + ``contiguous()`` round-trip.
        # Per-batch ``seqused_k`` and out-of-range page IDs are handled
        # inside the kernel (zeroed rows). Falls through to the torch
        # path for D=72 (no paged-vision use today) or shapes the kernel
        # doesn't yet specialize.
        _k_native = k.permute(0, 2, 1, 3) if (q.device.type == "mps") else None
        _v_native = v.permute(0, 2, 1, 3) if (q.device.type == "mps") else None
        # The kernel writes ``out`` while still reading Q/K/V — if a
        # caller aliases ``out`` with any of them (e.g. reuses ``q``
        # as ``out``), the writes would corrupt later reads. Defensively
        # reject storage overlap and fall through to the torch path
        # that materializes into a disjoint temporary. Mirrors the
        # dense Metal shortcut's guard above.
        _paged_out_storage_ptr = (
            out_result.untyped_storage().data_ptr()
            if q.device.type == "mps"
            else 0
        )
        _paged_aliased_with_input = q.device.type == "mps" and (
            q.untyped_storage().data_ptr() == _paged_out_storage_ptr
            or k.untyped_storage().data_ptr() == _paged_out_storage_ptr
            or v.untyped_storage().data_ptr() == _paged_out_storage_ptr
        )
        if (
            q.device.type == "mps"
            and q.dtype == torch.float16
            and k.dtype == torch.float16
            and v.dtype == torch.float16
            and out_result.dtype == torch.float16
            and q_len > 1
            and q_lens is None
            and (causal or prefix_lm_730)
            and batch_size == 1
            and page_size == 1
            and head_dim == 64
            and num_q_heads == num_kv_heads
            and seqused_k is not None
            and float(k_scale) == 1.0
            and float(v_scale) == 1.0
            and page_table.is_contiguous()
            and seqused_k.is_contiguous()
            and _k_native.is_contiguous()
            and _v_native.is_contiguous()
            # The native op's TORCH_CHECK requires stride-1 on the
            # head_dim axis of both q and out. Sliced last-dim inputs
            # would hard-fail; gate them out so they fall through to
            # the torch path instead.
            and q.stride(-1) == 1
            and out_result.stride(-1) == 1
            # All metadata tensors must be on the same device as q —
            # the C++ op's same-device TORCH_CHECK would otherwise
            # hard-fail on a CPU page_table or seqused_k paired with
            # MPS q/k/v.
            and k.device == q.device
            and v.device == q.device
            and page_table.device == q.device
            and seqused_k.device == q.device
            and not _paged_aliased_with_input
        ):
            # Pass strided views directly — the kernel reads strides for
            # the first three axes from ``params->{Q,O}_strides`` and only
            # requires stride-1 on the last (D) axis. Avoiding the
            # ``permute().contiguous()`` copy + ``empty_like`` allocation +
            # final ``copy_`` saves ~6 MB × 2 round-trip per call (Exp 3).
            q_bhld = q.permute(0, 2, 1, 3)
            out_bhld = out_result.permute(0, 2, 1, 3)

            effective_scale = (
                softmax_scale if softmax_scale is not None
                else 1.0 / (q.shape[-1] ** 0.5)
            )

            # Clamp ``seqused_k[0]`` to the count of *valid* page-table
            # entries. The kernel iterates over
            # ``page_table[0, 0..ceil(kL_real / page_size))`` and the
            # paged loader zero-fills rows for invalid page IDs — those
            # zero rows still participate in softmax normalization and
            # would silently skew the output if seqused_k is stale or
            # oversized. Mirrors the prior (gather+dense) path's
            # ``available_pages``-based clamp.
            page_row = page_table[0]
            valid_pages = (page_row >= 0) & (page_row < total_pages)
            available_pages = int(valid_pages.sum().item())
            kv_len_b = min(
                int(seqused_k[0].item()), available_pages * page_size,
            )
            if kv_len_b <= 0:
                # Empty/all-invalid KV: the kernel can't normalize over
                # zero kv positions (NaN softmax) and a zero-width
                # prefix-LM mask trips the dispatcher's qL check. Zero
                # the output and return — caller sees a row of zeros,
                # matching the prior path's implicit no-op behavior.
                out_result.zero_()
                return out, None

            # The kernel reads ``page_table[0, 0..ceil(kv_len_b/page_size))``
            # in order — invalid IDs in the active prefix get
            # zero-filled, but later valid pages then get skipped (the
            # kernel only iterates ``kv_len_b`` rows). Production
            # always fills page_table densely, so this only diverges
            # from the prior compacted-gather path under stale/sparse
            # state. Fall through to the torch path in that case.
            n_logical_pages = (kv_len_b + page_size - 1) // page_size
            prefix_dense = bool(
                valid_pages[:n_logical_pages].all().item()
            )
            if kv_len_b >= q_len and prefix_dense:
                # Production normal prefill always has kv_len >= qL.
                # When kv_len < qL (only in stale/undersized cache
                # states) ``qL_off_local = kL_real - qL`` goes negative
                # for early Q rows, the causal branch masks every
                # column for those rows, and softmax produces NaN —
                # fall through to the torch path in that case.
                kernel_seqused_k = torch.tensor(
                    [kv_len_b], dtype=torch.int32, device=seqused_k.device,
                )

                if prefix_lm_730:
                    mask = _get_prefix_lm_730_mask(
                        q_len, kv_len_b, q.device, q.dtype,
                    )
                    causal_flag = False
                else:
                    mask = None
                    causal_flag = True

                _mps_ops().paged_prefill_attn_into(
                    out_bhld,
                    q_bhld,
                    _k_native,
                    _v_native,
                    page_table.to(dtype=torch.int32),
                    kernel_seqused_k,
                    float(effective_scale),
                    mask,
                    causal_flag,
                )
                return out, None
            # kv_len_b < q_len OR sparse page_table prefix → fall
            # through to the torch path below (which compacts via
            # ``index_select(valid_pages)``).

        # Prefill path: compact each request to its active KV length before attention.
        # This is not used during decode graph capture (q_len == 1 there), so it can
        # use request-local lengths without violating graph-capture constraints.
        #
        # MPS always takes this branch — the decode path below uses
        # ``torch.compile(flex_attention, fullgraph=True)``, which the MPS
        # backend doesn't support in torch 2.11.
        if q_len > 1 or q_lens is not None or q.device.type == "mps":
            if q_lens is not None:
                out_result.zero_()
            page_ids_raw = page_table.to(dtype=torch.long)

            for b in range(batch_size):
                q_len_b = int(q_lens[b].item()) if q_lens is not None else q_len
                if q_len_b <= 0:
                    continue
                q_b = q[b : b + 1, :q_len_b].permute(0, 2, 1, 3)
                page_row = page_ids_raw[b]
                valid_pages = (page_row >= 0) & (page_row < total_pages)
                available_pages = int(valid_pages.sum().item())
                available_kv_len = available_pages * page_size
                if available_kv_len <= 0:
                    out_result[b : b + 1].zero_()
                    continue

                if seqused_k is not None:
                    kv_len = int(min(int(seqused_k[b].item()), available_kv_len))
                else:
                    kv_len = available_kv_len

                if kv_len <= 0:
                    out_result[b : b + 1].zero_()
                    continue

                pages_needed = min((kv_len + page_size - 1) // page_size, available_pages)
                page_ids = page_row[valid_pages][:pages_needed]

                k_pages = _index_select_first_dim(k, page_ids)
                v_pages = _index_select_first_dim(v, page_ids)
                k_seq = k_pages.reshape(pages_needed * page_size, num_kv_heads, head_dim)[:kv_len]
                v_seq = v_pages.reshape(pages_needed * page_size, num_kv_heads, head_dim)[:kv_len]

                k_seq, v_seq, q_scale, out_scale = _prepare_kv_for_sdpa(
                    k=k_seq,
                    v=v_seq,
                    target_dtype=q.dtype,
                    k_scale=k_scale,
                    v_scale=v_scale,
                )
                k_b = k_seq.permute(1, 0, 2).unsqueeze(0)
                v_b = v_seq.permute(1, 0, 2).unsqueeze(0)
                q_b_scaled = q_b if q_scale == 1.0 else q_b.mul(q_scale)

                out_b = _attention_forward(
                    q=q_b_scaled,
                    k=k_b,
                    v=v_b,
                    q_len=q_len_b,
                    kv_len=kv_len,
                    causal=causal,
                    prefix_lm_730=prefix_lm_730,
                    softmax_scale=softmax_scale,
                )
                if out_scale != 1.0:
                    out_b = out_b.mul(out_scale)
                out_result[b : b + 1, :q_len_b].copy_(out_b.permute(0, 2, 1, 3))

            return out, None

        # Decode path: use flex_attention with paged block mask to avoid
        # materializing dense gathered KV tensors.
        q_sdpa_all = q.permute(0, 2, 1, 3)
        k_seq, v_seq, q_scale, out_scale = _prepare_kv_for_sdpa(
            k=k,
            v=v,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        q_sdpa_scaled = q_sdpa_all if q_scale == 1.0 else q_sdpa_all.mul(q_scale)
        out_sdpa = _paged_decode_flex_attention(
            q=q_sdpa_scaled,
            k=k_seq,
            v=v_seq,
            page_table=page_table,
            seqused_k=seqused_k,
            softmax_scale=softmax_scale,
        )

        if out_scale != 1.0:
            out_sdpa = out_sdpa.mul(out_scale)
        out_result.copy_(out_sdpa.permute(0, 2, 1, 3))

    return out, None
