"""GELU and GELU-residual dispatch via the cubin bundle runtime.

Two families:
- `gelu_residual_bfloat16_h1024`: fused GELU(x) * (y + 1) at hidden=1024,
  single-variant bundle.
- `gelu`: plain GELU activation, one shipped variant per last-dim
  (currently `d6144` — the Moondream tau-attention QKV path). Other
  last-dims fall back to `F.gelu` with a one-time warning.
"""


import torch
import torch.nn.functional as F

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled, warn_fallback_once
from kestrel_kernels.gelu_residual.fallback import gelu_residual_torch_into

_residual_family = CubinFamily("gelu_residual_bfloat16_h1024")
_gelu_family = CubinFamily("gelu")
_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles


def _normalize_gelu_out(inp: torch.Tensor, out: torch.Tensor) -> torch.Tensor:
    """Reshape the caller's out buffer to match inp's logical shape if needed."""
    if out.shape == inp.shape:
        return out
    if out.numel() != inp.numel():
        raise ValueError(
            "gelu_cute out tensor must match the input shape or have the same number "
            f"of elements, got inp={tuple(inp.shape)} out={tuple(out.shape)}"
        )
    return out.view_as(inp)


# Hidden size baked into the shipped gelu_residual cubin bundle.
_GELU_RESIDUAL_HIDDEN = 1024

# GeluKernel tiles the D axis into blocks of (num_threads × out_per_vec) =
# 128 × 8 = 1024 elements. Runtime grid_y must match what the cubin was
# compiled with: ceil_div(dim, _GELU_D_ELEMS_PER_BLOCK).
_GELU_D_ELEMS_PER_BLOCK = 1024


def _ensure_residual_variant(x: torch.Tensor) -> bool:
    variant_key = "_default"
    if _residual_family.is_available(variant_key):
        return True
    device_index = int(x.device.index or 0)
    if (variant_key, device_index) in _residual_family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    _cubin_bundles.jit_compile_and_install(
        family=_residual_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_gelu_residual_bfloat16_h1024,
        block_x=128,
        device_index=device_index,
    )
    return True


def _ensure_gelu_variant(variant_key: str, x: torch.Tensor, dim: int) -> bool:
    if _gelu_family.is_available(variant_key):
        return True
    device_index = int(x.device.index or 0)
    if (variant_key, device_index) in _gelu_family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    _cubin_bundles.jit_compile_and_install(
        family=_gelu_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_gelu(dim=dim),
        block_x=128,
        device_index=device_index,
    )
    return True


def gelu_residual_cute(out: torch.Tensor, inp: torch.Tensor) -> None:
    """GELU residual: out = gelu(inp[..., :H]) * inp[..., H:] + gelu(inp[..., :H]).

    Dispatches the bf16 / H=1024 cubin built by `cubin_bundles.py`. Only that
    one shape is supported; callers using other shapes need to fall back to
    the torch reference (kestrel_kernels.gelu_residual.fallback).
    """
    if inp.dtype != torch.bfloat16 or out.dtype != torch.bfloat16:
        raise ValueError(
            f"gelu_residual_cute requires bfloat16, got out={out.dtype} inp={inp.dtype}"
        )
    if out.shape[-1] != _GELU_RESIDUAL_HIDDEN or inp.shape[-1] != 2 * _GELU_RESIDUAL_HIDDEN:
        raise ValueError(
            f"gelu_residual_cute only supports hidden={_GELU_RESIDUAL_HIDDEN}; "
            f"got out.shape={tuple(out.shape)} inp.shape={tuple(inp.shape)}"
        )
    if inp.ndim == 2:
        out2, inp2 = out, inp
    else:
        num_tokens = inp.numel() // inp.shape[-1]
        out2 = out.view(num_tokens, out.shape[-1])
        inp2 = inp.view(num_tokens, inp.shape[-1])

    if not _ensure_residual_variant(out2):
        warn_fallback_once(
            "gelu_residual_cute_no_cubin",
            "kestrel-kernels: no gelu_residual cubin bundle for the current "
            "CUDA architecture; using PyTorch fallback.",
        )
        gelu_residual_torch_into(out=out2, inp=inp2)
        return
    _residual_family.resolve_dispatch(out2, grid_x=out2.size(0))(out2, inp2)


def gelu_cute(inp: torch.Tensor, out: torch.Tensor | None = None) -> torch.Tensor:
    """Plain GELU activation: returns GELU(inp).

    Dispatches the shipped `gelu` cubin bundle for supported last-dims
    (currently d=6144). Falls back to F.gelu otherwise.
    """
    if inp.dtype != torch.bfloat16:
        raise ValueError(f"gelu_cute requires bfloat16, got {inp.dtype}")

    if out is None:
        out = torch.empty_like(inp)
    else:
        out = _normalize_gelu_out(inp, out)

    dim = inp.shape[-1]
    variant_key = f"d{dim}"
    if not _ensure_gelu_variant(variant_key, inp, dim):
        warn_fallback_once(
            f"gelu_cute_no_variant_d{dim}",
            f"kestrel-kernels: no gelu cubin variant for dim={dim} on the "
            f"current CUDA architecture; using PyTorch fallback.",
        )
        out.copy_(F.gelu(inp))
        return out

    if inp.ndim == 2:
        inp2, out2 = inp, out
    else:
        num_tokens = inp.numel() // dim
        inp2 = inp.view(num_tokens, dim)
        out2 = out.view(num_tokens, dim)
    grid_y = ceil_div(dim, _GELU_D_ELEMS_PER_BLOCK)
    _gelu_family.resolve_dispatch(
        inp2, variant_key=variant_key, grid_x=inp2.size(0), grid_y=grid_y,
    )(out2, inp2)
    return out


__all__ = ["gelu_residual_cute", "gelu_cute"]
