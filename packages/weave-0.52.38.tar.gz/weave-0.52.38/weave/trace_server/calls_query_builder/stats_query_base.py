"""Shared utilities for call statistics query builders.

This module contains common utilities used by both usage_query_builder.py
(token/cost metrics grouped by model) and call_metrics_query_builder.py
(latency/count metrics not grouped by model).
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass
from typing import TYPE_CHECKING

from weave.trace_server.calls_query_builder.utils import param_slot
from weave.trace_server.ch_sentinel_values import (
    null_check_literal_sql,
    null_check_sql,
)
from weave.trace_server.orm import ParamBuilder, combine_conditions
from weave.trace_server.project_version.types import ReadTable, TableConfig
from weave.trace_server.trace_server_interface import (
    AggregationType,
    CallsFilter,
)

if TYPE_CHECKING:
    from weave.trace_server.trace_server_interface import CallStatsReq

# Maximum number of buckets to prevent excessive query results
MAX_BUCKETS = 10_000

# Time bucket granularity thresholds (in seconds)
BUCKET_THRESHOLD_2H = 2 * 3600
BUCKET_THRESHOLD_12H = 12 * 3600
BUCKET_THRESHOLD_3D = 3 * 86400
BUCKET_THRESHOLD_14D = 14 * 86400

# Granularity options (in seconds)
GRANULARITY_5MIN = 300
GRANULARITY_1H = 3600
GRANULARITY_6H = 6 * 3600
GRANULARITY_12H = 12 * 3600
GRANULARITY_1D = 86400


@dataclass(slots=True, frozen=True)
class StatsQueryTimeBounds:
    granularity_seconds: int
    start: datetime.datetime
    end: datetime.datetime
    bucket_expr: str


@dataclass(slots=True, frozen=True)
class SqlQueryResult:
    """Base result for parameterized SQL queries."""

    sql: str
    columns: list[str]
    parameters: dict[str, str | float | int | bool | None]


@dataclass(slots=True, frozen=True)
class StatsQueryBuildResult(SqlQueryResult):
    """Query result with time-bucketed granularity metadata."""

    granularity_seconds: int = 0
    start: datetime.datetime = datetime.datetime.min
    end: datetime.datetime = datetime.datetime.min


def auto_select_granularity_seconds(delta: datetime.timedelta) -> int:
    """Automatically select appropriate granularity (in seconds) based on time range span."""
    total_seconds = delta.total_seconds()

    if total_seconds <= BUCKET_THRESHOLD_2H:
        return GRANULARITY_5MIN
    elif total_seconds <= BUCKET_THRESHOLD_12H:
        return GRANULARITY_1H
    elif total_seconds <= BUCKET_THRESHOLD_3D:
        return GRANULARITY_6H
    elif total_seconds <= BUCKET_THRESHOLD_14D:
        return GRANULARITY_12H
    else:
        return GRANULARITY_1D


def ensure_max_buckets(granularity_seconds: int, time_range_seconds: float) -> int:
    """Adjust granularity to ensure we don't exceed MAX_BUCKETS."""
    num_buckets = time_range_seconds / granularity_seconds
    if num_buckets <= MAX_BUCKETS:
        return granularity_seconds

    # Calculate minimum granularity needed to stay under MAX_BUCKETS
    min_granularity = int(time_range_seconds / MAX_BUCKETS) + 1
    return max(granularity_seconds, min_granularity)


def determine_bounds_and_bucket(
    req: CallStatsReq,
    read_table: ReadTable = ReadTable.CALLS_MERGED,
) -> StatsQueryTimeBounds:
    """Resolve request parameters to concrete time bounds and bucket configuration.

    Args:
        req: The CallStatsReq containing time range and granularity settings.
        read_table: Which table to query (calls_merged or calls_complete).

    Returns:
        StatsQueryTimeBounds containing bucket size, UTC range bounds, and bucket SQL.
    """
    now_utc = datetime.datetime.now(datetime.timezone.utc)

    start = req.start
    end = req.end if req.end is not None else now_utc

    time_range_seconds = (end - start).total_seconds()

    # Determine granularity
    if req.granularity is not None:
        granularity_seconds = req.granularity
    else:
        granularity_seconds = auto_select_granularity_seconds(end - start)

    # Ensure we don't exceed MAX_BUCKETS
    granularity_seconds = ensure_max_buckets(granularity_seconds, time_range_seconds)

    # Build bucket expression using the appropriate datetime field
    # calls_merged uses sortable_datetime, calls_complete uses started_at
    table_config = TableConfig.from_read_table(read_table)
    datetime_field = table_config.datetime_filter_field
    bucket_expr = f"toStartOfInterval({datetime_field}, INTERVAL {granularity_seconds} SECOND, {{tz}})"

    return StatsQueryTimeBounds(
        granularity_seconds=granularity_seconds,
        start=start,
        end=end,
        bucket_expr=bucket_expr,
    )


def aggregation_selects_for_metric(
    metric: str,
    aggregations: list[AggregationType],
    percentiles: list[float],
) -> list[tuple[str, str]]:
    """Generate SQL select expressions for the given metric and aggregations.

    Returns a list of (select_expression, column_alias) tuples.
    """
    results: list[tuple[str, str]] = []

    for agg in aggregations:
        col = f"m_{metric}"

        if agg == AggregationType.SUM:
            results.append((f"sumOrNull({col})", f"sum_{metric}"))
        elif agg == AggregationType.AVG:
            results.append((f"avgOrNull({col})", f"avg_{metric}"))
        elif agg == AggregationType.MIN:
            results.append((f"minOrNull({col})", f"min_{metric}"))
        elif agg == AggregationType.MAX:
            results.append((f"maxOrNull({col})", f"max_{metric}"))
        elif agg == AggregationType.COUNT:
            results.append((f"countOrNull({col})", f"count_{metric}"))
        elif agg == AggregationType.COUNT_TRUE:
            # 1 == True, 0 == False in clickhouse boolean arithmetic
            results.append((f"countIf({col} = 1)", f"count_true_{metric}"))
        elif agg == AggregationType.COUNT_FALSE:
            results.append((f"countIf({col} = 0)", f"count_false_{metric}"))
        else:
            raise ValueError(f"Unsupported aggregation type: {agg}")

    for p in percentiles:
        if not 0 <= p <= 100:
            raise ValueError(f"Percentile must be between 0 and 100, got {p}")
        col = f"m_{metric}"
        q = round(p / 100.0, 6)
        p_str = str(int(p)) if p == int(p) else str(p)
        alias = f"p{p_str}_{metric}"
        results.append((f"quantileOrNull({q})({col})", alias))

    return results


def build_calls_filter_sql(
    calls_filter: CallsFilter | None,
    pb: ParamBuilder,
    read_table: ReadTable = ReadTable.CALLS_MERGED,
) -> str:
    """Build WHERE clause SQL for CallsFilter.

    Generates filter conditions without table alias since this is used
    in an inner subquery that directly queries calls_merged or calls_complete.

    Args:
        calls_filter: The filter to convert to SQL.
        pb: Parameter builder for parameterized queries.
        read_table: Which table is being queried; affects NULL vs sentinel checks.

    Returns:
        SQL fragment with leading `` AND `` if any filters apply, or empty string.
    """
    if calls_filter is None:
        return ""

    where_clauses: list[str] = []

    # Handle op_names
    if calls_filter.op_names:
        op_names_param = pb.add_param(calls_filter.op_names)
        where_clauses.append(
            f"op_name IN {param_slot(op_names_param, 'Array(String)')}"
        )

    # Handle trace_roots_only
    if calls_filter.trace_roots_only:
        where_clauses.append(null_check_sql("parent_id", "parent_id", read_table, pb))

    # Handle trace_ids
    if calls_filter.trace_ids:
        trace_ids_param = pb.add_param(calls_filter.trace_ids)
        where_clauses.append(
            f"trace_id IN {param_slot(trace_ids_param, 'Array(String)')}"
        )

    # Handle call_ids
    if calls_filter.call_ids:
        call_ids_param = pb.add_param(calls_filter.call_ids)
        where_clauses.append(f"id IN {param_slot(call_ids_param, 'Array(String)')}")

    # Handle parent_ids
    if calls_filter.parent_ids:
        parent_ids_param = pb.add_param(calls_filter.parent_ids)
        where_clauses.append(
            f"parent_id IN {param_slot(parent_ids_param, 'Array(String)')}"
        )

    # Handle wb_user_ids
    if calls_filter.wb_user_ids:
        wb_user_ids_param = pb.add_param(calls_filter.wb_user_ids)
        where_clauses.append(
            f"wb_user_id IN {param_slot(wb_user_ids_param, 'Array(String)')}"
        )

    # Handle wb_run_ids
    if calls_filter.wb_run_ids:
        wb_run_ids_param = pb.add_param(calls_filter.wb_run_ids)
        where_clauses.append(
            f"wb_run_id IN {param_slot(wb_run_ids_param, 'Array(String)')}"
        )

    if not where_clauses:
        return ""

    return " AND " + combine_conditions(where_clauses, "AND")


def build_grouped_calls_subquery(
    project_param: str,
    start_param: str,
    end_param: str,
    tz_param: str,
    where_filter_sql: str,
    select_columns: list[str],
    read_table: ReadTable = ReadTable.CALLS_MERGED,
) -> str:
    """Build SQL for a grouped calls subquery that collapses unmerged call parts.

    Args:
        project_param: Parameter name for the project ID.
        start_param: Parameter name for the start timestamp (epoch seconds).
        end_param: Parameter name for the end timestamp (epoch seconds).
        tz_param: Parameter name for the timezone string.
        where_filter_sql: Additional WHERE filters (should include leading AND).
        select_columns: Column names to aggregate using anyIf for non-null selection.
        read_table: Which table to query (calls_merged or calls_complete).

    Returns:
        SQL string for the grouped calls subquery.

    Examples:
        >>> sql = build_grouped_calls_subquery(
        ...     "pb_0",
        ...     "pb_1",
        ...     "pb_2",
        ...     "pb_3",
        ...     "",
        ...     ["summary_dump"],
        ... )
        >>> "GROUP BY project_id, id" in sql
        True
    """
    if not select_columns:
        raise ValueError("select_columns must include at least one column")

    table_config = TableConfig.from_read_table(read_table)
    table_name = table_config.table_name
    datetime_field = table_config.datetime_filter_field
    use_aggregation = table_config.use_aggregation
    table_alias = "cm"

    if use_aggregation:
        # calls_merged: use anyIf to aggregate multiple rows per call
        select_sql = ",\n              ".join(
            f"anyIf({table_alias}.{column}, {table_alias}.{column} IS NOT NULL) AS {column}"
            for column in select_columns
        )
        group_by_clause = "\n        GROUP BY project_id, id"
        deleted_at_filter = f"{table_alias}.deleted_at IS NULL"
    else:
        # calls_complete: single row per call, no aggregation needed
        select_sql = ",\n              ".join(
            f"{table_alias}.{column} AS {column}" for column in select_columns
        )
        group_by_clause = ""
        deleted_at_filter = null_check_literal_sql(
            "deleted_at", f"{table_alias}.deleted_at", read_table
        )

    return f"""
        SELECT
              {select_sql}
        FROM {table_name} AS {table_alias}
        WHERE
              {table_alias}.project_id = {param_slot(project_param, "String")}
              AND {table_alias}.{datetime_field} >= toDateTime({param_slot(start_param, "Float64")}, {param_slot(tz_param, "String")})
              AND {table_alias}.{datetime_field} < toDateTime({param_slot(end_param, "Float64")}, {param_slot(tz_param, "String")})
              AND {deleted_at_filter}{where_filter_sql}{group_by_clause}
        """
