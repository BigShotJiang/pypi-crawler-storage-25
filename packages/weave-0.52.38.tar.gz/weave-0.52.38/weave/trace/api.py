"""The top-level functions for Weave Trace API."""

from __future__ import annotations

import contextlib
import logging
import warnings
from collections.abc import Iterator, Sequence
from typing import Any, cast

# TODO: type_handlers is imported here to trigger registration of the image serializer.
# There is probably a better place for this, but including here for now to get the fix in.
from weave import type_handlers  # noqa: F401
from weave.trace import urls, weave_client, weave_init
from weave.trace.autopatch import AutopatchSettings
from weave.trace.constants import TRACE_OBJECT_EMOJI
from weave.trace.context import call_context, weave_client_context
from weave.trace.context.call_context import get_current_call, require_current_call
from weave.trace.display.term import configure_logger, update_logger_level
from weave.trace.op import PostprocessInputsFunc, PostprocessOutputFunc, as_op, op
from weave.trace.refs import ObjectRef, Ref
from weave.trace.registry_links import LinkablePrompt
from weave.trace.settings import (
    UserSettings,
    parse_and_apply_settings,
    should_disable_weave,
)
from weave.trace.table import Table
from weave.trace.view_utils import set_call_view
from weave.trace_server.ids import generate_id
from weave.trace_server.interface.builtin_object_classes import leaderboard
from weave.trace_server_bindings.link_asset_to_registry import LinkAssetToRegistryRes
from weave.type_wrappers.Content.content import Content

logger = logging.getLogger(__name__)

# Sentinel object to distinguish between "not provided" (auto-generate) and explicit None (disable)
_AUTO_GENERATE = object()


def init(
    project_name: str,
    *,
    settings: UserSettings | dict[str, Any] | None = None,
    autopatch_settings: AutopatchSettings | None = None,
    postprocess_inputs: PostprocessInputsFunc | None = None,
    postprocess_output: PostprocessOutputFunc | None = None,
    attributes: dict[str, Any] | None = None,
    # Deprecated aliases — remove in a future release.
    global_postprocess_inputs: PostprocessInputsFunc | None = None,
    global_postprocess_output: PostprocessOutputFunc | None = None,
    global_attributes: dict[str, Any] | None = None,
) -> weave_client.WeaveClient:
    """Initialize weave tracking, logging to a wandb project.

    Logging is initialized globally, so you do not need to keep a reference
    to the return value of init.

    Following init, calls of weave.op decorated functions will be logged
    to the specified project.

    Args:
        project_name: The name of the Weights & Biases team and project to log to. If you don't
            specify a team, your default entity is used.
            To find or update your default entity, refer to [User Settings](https://docs.wandb.ai/platform/app/settings-page/user-settings#default-team) in the W&B Models documentation.
        settings: Configuration for the Weave client generally. Can be a UserSettings instance or a dict
            with any of the following keys (all optional). All settings can also be configured
            via environment variables using the prefix WEAVE_ (e.g., WEAVE_DISABLED=true).
            Available settings:
                - `disabled` (bool): Disables traces on all functions. Default: `False`
                - `print_call_link` (bool): Prints links in terminal to Weave UI for ops. Default: `True`
                - `log_level` (str): Sets what type of information to log (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`). Default: `INFO`
                - `display_viewer` (str): Controls how Weave displays objects in the console (`auto`, `rich`, `print`). Default: `auto`
                - `capture_code` (bool): Captures code of traced ops to your Weave project. Default: `True`
                - `implicitly_patch_integrations` (bool): Auto-patches supported libraries. Default: `True`
                - `redact_pii` (bool): Scans all trace data for sensitive information,
                    like emails, phone numbers, and credit cards, and replaces them with placeholder values
                    before sending to the server. Requires presidio-analyzer and presidio-anonymizer packages.
                    Default: `False`
                - `redact_pii_fields` (list[str]): Specifies which PII entity types to redact when `redact_pii`
                    is `True`. If empty, uses Presidio's default set. Examples: ['EMAIL','PHONE_NUMBER','CREDIT_CARD','US_SSN'].
                    See full list at: https://microsoft.github.io/presidio/supported_entities/
                    Default: `[]`
                - `redact_pii_exclude_fields` (list[str]): PII entity types to exclude. Default: `[]`
                - `capture_client_info` (bool): Captures Python/SDK version info. Default: `True`
                - `capture_system_info` (bool): Captures OS information. Default: `True`
                - `client_parallelism` (int): Number of workers for background ops. Default: `auto`
                - `use_server_cache` (bool): Enables local disk caching of server responses.
                - `server_cache_size_limit` (int): Cache size limit in bytes. Default: `1_000_000_000`
                - `server_cache_dir` (str): Directory for server cache. Default: `temporary`
                - `scorers_dir` (str): Directory for scorer model checkpoints. Default: `~/.cache/wandb/weave-scorers`
                - `max_calls_queue_size` (int): Maximum queue size (0 = unbounded). Default: `100_000`
                - `retry_max_interval` (float): Maximum retry interval in seconds. Default: `300`
                - `retry_max_attempts` (int): Maximum number of retries. Default: `3`
                - `enable_disk_fallback` (bool): Writes dropped items to disk. Default: `True`
                - `use_parallel_table_upload` (bool): Enables parallel chunked upload for large tables. If False,
                    tables are uploaded sequentially in smaller chunks.
                    Default: `True`
                - `http_timeout` (float): Maximum time in seconds to wait for HTTP requests to complete.
                    This includes connection time, data transfer, and server processing. Increase for
                    slow networks or when working with large payloads.
                    Default: `30.0`
                - `use_stainless_server` (bool): Uses the Stainless-generated HTTP client which
                    provides better type safety, automatic retries, and improved error handling. This is
                    experimental and may become the default in future versions.
                    Default: `False`
                - `use_calls_complete` (bool): Uses an optimized write path that batches complete
                    call data (start and end) into a single request instead of separate start/end requests.
                    This reduces server load and improves performance, especially for short-lived ops.
                    Default: `False`
        autopatch_settings: (Deprecated) Configuration for autopatch integrations. Use explicit patching instead.
        postprocess_inputs: A function applied to the inputs of every op traced by this client.
        postprocess_output: A function applied to the output of every op traced by this client.
        attributes: A dictionary of attributes applied to every trace produced by this client.

    NOTE: Client-level postprocessing runs after each op's own postprocessing.
    The order is always:
    1. Op-specific postprocessing
    2. Client-level postprocessing

    Returns:
        A Weave client.
    """
    if not project_name or not project_name.strip():
        raise ValueError("project_name must be non-empty")

    configure_logger()

    # Check if deprecated autopatch_settings is used
    if autopatch_settings is not None:
        logger.warning(
            "The 'autopatch_settings' parameter is deprecated and will be removed in a future version. "
            "Please use explicit patching instead. For example:\n"
            "----------------------------------------\n"
            "    import weave\n"
            "    weave.init('%s')\n"
            "    weave.integrations.patch_openai()\n"
            "----------------------------------------\n"
            "See https://docs.wandb.ai/models/integrations for more information.",
            project_name,
        )

    parse_and_apply_settings(settings)

    if global_postprocess_inputs is not None:
        warnings.warn(
            "`global_postprocess_inputs` is deprecated; use `postprocess_inputs` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        postprocess_inputs = postprocess_inputs or global_postprocess_inputs
    if global_postprocess_output is not None:
        warnings.warn(
            "`global_postprocess_output` is deprecated; use `postprocess_output` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        postprocess_output = postprocess_output or global_postprocess_output
    if global_attributes is not None:
        warnings.warn(
            "`global_attributes` is deprecated; use `attributes` instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        attributes = attributes or global_attributes

    if should_disable_weave():
        return weave_init.init_weave_disabled(
            postprocess_inputs=postprocess_inputs,
            postprocess_output=postprocess_output,
            attributes=attributes,
        )

    return weave_init.init_weave(
        project_name,
        postprocess_inputs=postprocess_inputs,
        postprocess_output=postprocess_output,
        attributes=attributes,
    )


def get_client() -> weave_client.WeaveClient | None:
    return weave_client_context.get_weave_client()


def publish(
    obj: Any,
    name: str | None = None,
    tags: list[str] | None = None,
    aliases: list[str] | None = None,
) -> ObjectRef:
    """Save and version a Python object.

    Weave creates a new version of the object if the object's name already exists and its content hash does
    not match the latest version of that object.

    Args:
        obj: The object to save and version.
        name: The name to save the object under.
        tags: Optional list of tags to add to the published object version.
        aliases: Optional list of aliases to set on the published object version.

    Returns:
        A Weave Ref to the saved object.
    """
    save_name: str
    if name:
        save_name = name
    elif n := getattr(obj, "name", None):
        save_name = n
    else:
        save_name = obj.__class__.__name__

    # If weave is disabled, return a dummy ref without making network calls
    if should_disable_weave():
        return weave_client.ObjectRef(
            entity="DISABLED",
            project="DISABLED",
            name=save_name,
            _digest="DISABLED",
        )

    client = weave_client_context.require_weave_client()

    ref = client._save_object(obj, save_name, "latest")

    if isinstance(ref, ObjectRef):
        if tags:
            client.add_tags(ref, tags)
        if aliases:
            client.set_aliases(ref, aliases)
        if isinstance(ref, weave_client.OpRef):
            url = urls.op_version_path(
                ref.entity,
                ref.project,
                ref.name,
                ref.digest,
            )
        elif isinstance(obj, leaderboard.Leaderboard):
            url = urls.leaderboard_path(
                ref.entity,
                ref.project,
                ref.name,
            )
        # TODO(gst): once frontend has direct dataset/model links
        # elif isinstance(obj, weave_client.Dataset):
        else:
            url = urls.object_version_path(
                ref.entity,
                ref.project,
                ref.name,
                ref.digest,
            )
        # Ensure logger level is up to date before logging
        update_logger_level()
        msg = f"{TRACE_OBJECT_EMOJI} Published to {url}"
        if tags or aliases:
            extras = []
            if tags:
                extras.append(f"tags: {', '.join(tags)}")
            if aliases:
                extras.append(f"aliases: {', '.join(aliases)}")
            msg += f" ({'; '.join(extras)})"
        logger.info(msg)
    return ref


def add_tags(obj_ref: ObjectRef | str, tags: list[str]) -> None:
    """Add tags to an object version.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            (returned by `weave.publish()`) or a weave:/// URI string.
        tags: List of tag strings to add.
    """
    client = weave_client_context.require_weave_client()
    client.add_tags(obj_ref, tags)


def remove_tags(obj_ref: ObjectRef | str, tags: list[str]) -> None:
    """Remove tags from an object version.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            or a weave:/// URI string.
        tags: List of tag strings to remove.
    """
    client = weave_client_context.require_weave_client()
    client.remove_tags(obj_ref, tags)


def get_tags(obj_ref: ObjectRef | str) -> list[str]:
    """Get tags for an object version.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            or a weave:/// URI string.

    Returns:
        List of tag strings.
    """
    client = weave_client_context.require_weave_client()
    return client.get_tags(obj_ref)


def set_aliases(obj_ref: ObjectRef | str, alias: str | list[str]) -> None:
    """Set one or more aliases for an object version.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            or a weave:/// URI string.
        alias: An alias name or list of alias names to set (e.g., "production").
    """
    client = weave_client_context.require_weave_client()
    client.set_aliases(obj_ref, alias)


def remove_aliases(obj_ref: ObjectRef | str, alias: str | list[str]) -> None:
    """Remove one or more aliases from an object.

    Args:
        obj_ref: Reference to the object, either an ObjectRef
            or a weave:/// URI string.
        alias: An alias name or list of alias names to remove.
    """
    client = weave_client_context.require_weave_client()
    client.remove_aliases(obj_ref, alias)


def get_aliases(obj_ref: ObjectRef | str) -> list[str]:
    """Get aliases for an object version.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            or a weave:/// URI string.

    Returns:
        List of alias strings.
    """
    client = weave_client_context.require_weave_client()
    return client.get_aliases(obj_ref)


def get_tags_and_aliases(obj_ref: ObjectRef | str) -> tuple[list[str], list[str]]:
    """Get both tags and aliases for an object version in a single call.

    Args:
        obj_ref: Reference to the object version, either an ObjectRef
            or a weave:/// URI string.

    Returns:
        A tuple of (tags, aliases). Each is a list of strings.
    """
    client = weave_client_context.require_weave_client()
    return client.get_tags_and_aliases(obj_ref)


def list_tags() -> list[str]:
    """List all distinct tags in the project.

    Returns:
        Sorted list of all tag strings in the project.
    """
    client = weave_client_context.require_weave_client()
    return client.list_tags()


def list_aliases() -> list[str]:
    """List all distinct aliases in the project.

    Returns:
        Sorted list of all alias strings in the project.
    """
    client = weave_client_context.require_weave_client()
    return client.list_aliases()


def ref(location: str) -> ObjectRef:
    """Creates a Ref to an existing Weave object. This does not directly retrieve
    the object but allows you to pass it to other Weave API functions.

    Args:
        location: A Weave Ref URI, or if `weave.init()` has been called, `name:version` or `name`. If no version is provided, `latest` is used.

    Returns:
        A Weave Ref to the object.
    """
    if "://" not in location:
        client = weave_client_context.get_weave_client()
        if not client:
            raise ValueError("Call weave.init() first, or pass a fully qualified uri")
        if "/" in location:
            raise ValueError("'/' not currently supported in short-form URI")
        if ":" not in location:
            name = location
            version = "latest"
        else:
            name, version = location.split(":")
        location = str(client._ref_uri(name, version, "obj"))

    ref = Ref.parse_uri(location)
    if not isinstance(ref, ObjectRef):
        raise TypeError("Expected an object ref")
    return ref


def link_prompt_to_registry(
    prompt: LinkablePrompt,
    *,
    target_path: str,
    aliases: Sequence[str] | None = None,
) -> LinkAssetToRegistryRes:
    """Link a published prompt version into the registry.

    Args:
        prompt: A published prompt, an `ObjectRef`, or a fully qualified
            `weave:///...` URI string.
        target_path: Registry destination path in the format
            `<registry_project>/<portfolio_name>`, for example
            `wandb-registry-prompts/my-prompt-collection`.
        aliases: Optional aliases to attach to the created registry version.

    Returns:
        LinkAssetToRegistryRes: Parsed response from the registry-link endpoint.
    """
    client = weave_client_context.require_weave_client()
    return client.link_prompt_to_registry(
        prompt,
        target_path=target_path,
        aliases=aliases,
    )


def get(uri: str | ObjectRef) -> Any:
    """A convenience function for getting an object from a URI.

    Many objects logged by Weave are automatically registered with the Weave
    server. This function allows you to retrieve those objects by their URI.

    Args:
        uri: A fully-qualified weave ref URI.

    Returns:
        The object.

    Example:
    ```python
    weave.init("weave_get_example")
    dataset = weave.Dataset(rows=[{"a": 1, "b": 2}])
    ref = weave.publish(dataset)

    dataset2 = weave.get(ref)  # same as dataset!
    ```
    """
    if isinstance(uri, ObjectRef):
        return uri.get()
    return ref(uri).get()


@contextlib.contextmanager
def attributes(attributes: dict[str, Any]) -> Iterator:
    """Context manager for setting attributes on a call.

    Example:
    ```python
    with weave.attributes({'env': 'production'}):
        print(my_function.call("World"))
    ```
    """
    cur_attributes = {**call_context.call_attributes.get()}
    cur_attributes.update(attributes)

    token = call_context.call_attributes.set(cur_attributes)
    try:
        yield
    finally:
        call_context.call_attributes.reset(token)


def set_view(
    name: str,
    content: Content | str,
    *,
    extension: str | None = None,
    mimetype: str | None = None,
    metadata: dict[str, Any] | None = None,
    encoding: str = "utf-8",
) -> None:
    """Attach a custom view to the current call summary at `_weave.views.<name>`.

    Args:
        name: The view name (key under `summary._weave.views`).
        content: A `weave.Content` instance or raw string. Strings are wrapped via
            `Content.from_text` using the supplied extension or mimetype.
        extension: Optional file extension to use when `content` is a string.
        mimetype: Optional MIME type to use when `content` is a string.
        metadata: Optional metadata to attach when creating `Content` from text.
        encoding: Text encoding to apply when creating `Content` from text.

    Returns:
        None

    Examples:
        >>> import weave
        >>> weave.init("proj")
        >>> @weave.op
        ... def foo():
        ...     weave.set_view("readme", "# Hello", extension="md")
        ...     return 1
        >>> foo()
    """
    if isinstance(content, str) and len(content) == 0:
        raise ValueError("Content cannot be an empty string")

    if not isinstance(name, str) or len(name) == 0:
        raise ValueError("`name` must be a non-empty string")

    call = require_current_call()
    client = weave_client_context.require_weave_client()

    set_call_view(
        call=call,
        client=client,
        name=name,
        content=content,
        extension=extension,
        mimetype=mimetype,
        metadata=metadata,
        encoding=encoding,
    )


class ThreadContext:
    """Context object providing access to current thread and turn information."""

    def __init__(self, thread_id: str | None):
        """Initialize ThreadContext with the specified thread_id.

        Args:
            thread_id: The thread identifier for this context, or None if disabled.
        """
        self._thread_id = thread_id

    @property
    def thread_id(self) -> str | None:
        """Get the thread_id for this context.

        Returns:
            The thread identifier, or None if thread tracking is disabled.
        """
        return self._thread_id

    @property
    def turn_id(self) -> str | None:
        """Get the current turn_id from the active context.

        Returns:
            The current turn_id if set, None otherwise.
        """
        return call_context.get_turn_id()


@contextlib.contextmanager
def thread(thread_id: str | object | None = _AUTO_GENERATE) -> Iterator[ThreadContext]:
    """Context manager for setting thread_id on calls within the context.

    Examples:
    ```python
    # Auto-generate thread_id
    with weave.thread() as t:
        print(f"Thread ID: {t.thread_id}")
        result = my_function("input")  # This call will have the auto-generated thread_id
        print(f"Current turn: {t.turn_id}")

    # Explicit thread_id
    with weave.thread("custom_thread") as t:
        result = my_function("input")  # This call will have thread_id="custom_thread"

    # Disable threading
    with weave.thread(None) as t:
        result = my_function("input")  # This call will have thread_id=None
    ```

    Args:
        thread_id: The thread identifier to associate with calls in this context.
                  If not provided, a UUID v7 will be auto-generated.
                  If None, thread tracking will be disabled.

    Yields:
        ThreadContext: An object providing access to thread_id and current turn_id.
    """
    # Determine actual thread_id to use
    actual_thread_id: str | None
    if thread_id is _AUTO_GENERATE:
        # No argument provided - auto-generate
        actual_thread_id = generate_id()
    else:
        # Explicit thread_id (string or None)
        actual_thread_id = cast(str | None, thread_id)

    # Create context object
    context = ThreadContext(actual_thread_id)

    with call_context.set_thread_id(actual_thread_id):
        # Reset turn lineage when entering new thread context
        call_context.set_turn_id(None)
        yield context


def finish() -> None:
    """Stops logging to weave.

    Following finish, calls of weave.op decorated functions will no longer be logged. You will need to run weave.init() again to resume logging.

    """
    # Capture client before teardown so we can still flush outstanding work.
    wc = weave_client_context.get_weave_client()
    weave_init.finish()

    # Flush any remaining calls
    if wc is not None:
        wc.finish()


__all__ = [
    "ObjectRef",
    "Table",
    "ThreadContext",
    "add_tags",
    "as_op",
    "attributes",
    "finish",
    "get",
    "get_aliases",
    "get_client",
    "get_current_call",
    "get_tags",
    "get_tags_and_aliases",
    "init",
    "link_prompt_to_registry",
    "list_aliases",
    "list_tags",
    "op",
    "publish",
    "ref",
    "remove_aliases",
    "remove_tags",
    "require_current_call",
    "set_aliases",
    "set_view",
    "thread",
    "weave_client_context",
]
