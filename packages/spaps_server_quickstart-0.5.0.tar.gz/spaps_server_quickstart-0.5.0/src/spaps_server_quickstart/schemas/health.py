"""
Health response schema shared across Sweet Potato services.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = Field(default="ok", description="Service status indicator.")
    service: str = Field(default="service", description="Service identifier.")
    version: str = Field(default="unknown", description="Git commit SHA or application version.")
    database_ready: bool = Field(
        default=False,
        description="Whether the database responded to the readiness probes.",
    )
    started_at: str | None = Field(
        default=None,
        description="UTC ISO timestamp of when the service started.",
    )
    started_at_est: str | None = Field(
        default=None,
        description="EST human-readable timestamp of when the service started.",
    )
    details: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional service-specific health details.",
    )
