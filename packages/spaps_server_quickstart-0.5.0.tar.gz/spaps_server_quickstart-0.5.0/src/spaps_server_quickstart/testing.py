"""
Opinionated test infrastructure for Sweet Potato service backends.

Provides pgvector-enabled testcontainer fixtures, database provisioning,
migration application, and per-test state reset. Consumers activate by
adding to their conftest.py:

    pytest_plugins = ["spaps_server_quickstart.testing"]

    from spaps_server_quickstart.testing import TestConfig, register_test_config
    register_test_config(TestConfig(
        template_db_name="htma_template",
        worker_db_prefix="htma_test",
        alembic_ini_path=PROJECT_ROOT / "alembic.ini",
        seed_sql=[SEED_SQL_1, SEED_SQL_2],
        create_app=create_app,
        get_db_session=get_db_session,
        settings_cache_clear=get_settings.cache_clear,
        dispose_engine=dispose_engine,
    ))

Install with: pip install spaps-server-quickstart[testing]
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import os
import tempfile
import time
import warnings
from collections.abc import AsyncIterator, Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest
import pytest_asyncio
from sqlalchemy import create_engine
from sqlalchemy import text as sa_text
from sqlalchemy.engine import URL, make_url
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

try:
    from filelock import FileLock, Timeout as FileLockTimeout
except ImportError:  # pragma: no cover
    FileLock = None  # type: ignore[assignment,misc]
    FileLockTimeout = Exception  # type: ignore[assignment,misc]

try:
    from testcontainers.core.container import DockerContainer
    from testcontainers.core.wait_strategies import (
        CompositeWaitStrategy,
        LogMessageWaitStrategy,
        PortWaitStrategy,
    )
except ImportError:  # pragma: no cover
    DockerContainer = None  # type: ignore[assignment]
    CompositeWaitStrategy = None  # type: ignore[assignment]
    LogMessageWaitStrategy = None  # type: ignore[assignment]
    PortWaitStrategy = None  # type: ignore[assignment]

try:
    import docker as docker_lib
    from docker.errors import DockerException
except ImportError:  # pragma: no cover
    docker_lib = None  # type: ignore[assignment]

    class DockerException(Exception):  # type: ignore[no-redef]
        pass


try:
    from alembic import command as alembic_command
    from alembic.config import Config as AlembicConfig
except ImportError:  # pragma: no cover
    alembic_command = None  # type: ignore[assignment, misc]
    AlembicConfig = None  # type: ignore[assignment, misc]

try:
    from httpx import ASGITransport, AsyncClient
except ImportError:  # pragma: no cover
    ASGITransport = None  # type: ignore[assignment, misc]
    AsyncClient = None  # type: ignore[assignment, misc]


logger = logging.getLogger("spaps.testing")

SHARED_POSTGRES_URL_ENV = "PYTEST_SHARED_POSTGRES_URL"

_TRUNCATE_TABLES_SQL = """
DO $$
DECLARE
    rec record;
BEGIN
    FOR rec IN (
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = 'public'
          AND tablename <> 'alembic_version'
    ) LOOP
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', rec.tablename);
    END LOOP;
END $$;
"""

warnings.filterwarnings(
    "ignore",
    message=r".*@wait_container_is_ready decorator is deprecated.*",
    category=DeprecationWarning,
)


# ---------------------------------------------------------------------------
# TestConfig
# ---------------------------------------------------------------------------

@dataclass
class TestConfig:
    """Service-specific configuration for the testing module."""

    # Container
    postgres_image: str = "ankane/pgvector:latest"
    template_db_name: str = "service_template"
    worker_db_prefix: str = "service_test"
    app_db_user: str = "app"
    app_db_password: str = "app"

    # Migrations
    alembic_ini_path: Path | None = None
    graceful_skip_without_db: bool = True

    # Per-test reset
    seed_sql: list[str] = field(default_factory=list)

    # App integration
    settings_overrides: dict[str, str] = field(default_factory=dict)
    create_app: Callable[..., Any] | None = None
    get_db_session: Callable | None = None
    settings_cache_clear: Callable | None = None
    dispose_engine: Callable | None = None
    celery_app_import: str | None = None


_config: TestConfig | None = None


def register_test_config(config: TestConfig) -> None:
    """Register the service-specific test configuration."""
    global _config
    _config = config


def _get_config() -> TestConfig:
    if _config is None:
        return TestConfig()
    return _config


# ---------------------------------------------------------------------------
# Docker / container helpers
# ---------------------------------------------------------------------------

def _docker_available() -> bool:
    if docker_lib is None:
        return False
    try:
        client = docker_lib.from_env()
        client.ping()
    except DockerException:
        return False
    else:
        client.close()
        return True


DOCKER_AVAILABLE = _docker_available()
TESTCONTAINERS_AVAILABLE = DockerContainer is not None

if DockerContainer is not None:
    class ManagedPostgresContainer(DockerContainer):
        def __init__(self, image: str = "ankane/pgvector:latest") -> None:
            super().__init__(image)
            self.username = "postgres"
            self.password = "postgres"
            self.database = "postgres"
            self.port = 5432

            self.with_env("POSTGRES_USER", self.username)
            self.with_env("POSTGRES_PASSWORD", self.password)
            self.with_env("POSTGRES_DB", self.database)
            self.with_env("POSTGRES_HOST_AUTH_METHOD", "trust")
            self.with_exposed_ports(str(self.port))

            wait_strategy = CompositeWaitStrategy(
                PortWaitStrategy(self.port),
                LogMessageWaitStrategy("database system is ready to accept connections"),
            ).with_startup_timeout(60)
            self.waiting_for(wait_strategy)

        def get_connection_url(self) -> str:
            host = self.get_container_host_ip()
            port = self.get_exposed_port(self.port)
            return f"postgresql://{self.username}:{self.password}@{host}:{port}/{self.database}"
else:  # pragma: no cover
    class ManagedPostgresContainer:  # type: ignore[no-redef]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise RuntimeError("testcontainers is not installed")

        def start(self) -> None:
            raise RuntimeError("testcontainers is not installed")

        def stop(self) -> None:
            raise RuntimeError("testcontainers is not installed")

        def get_connection_url(self) -> str:
            raise RuntimeError("testcontainers is not installed")


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

def _base_driver_name(url: URL) -> str:
    return url.drivername.split("+", 1)[0]


def _async_database_url(sync_url: str) -> str:
    parsed = make_url(sync_url)
    base_driver = _base_driver_name(parsed)
    async_driver = None
    if base_driver.startswith("postgresql"):
        async_driver = "asyncpg"
    elif base_driver.startswith("sqlite"):
        async_driver = "aiosqlite"
    if async_driver is None:
        return sync_url
    drivername = f"{base_driver}+{async_driver}"
    return parsed.set(drivername=drivername).render_as_string(hide_password=False)


def _sync_database_url(url: str) -> str:
    parsed = make_url(url)
    base_driver = _base_driver_name(parsed)
    sync_driver = base_driver
    if base_driver.startswith("postgresql"):
        sync_driver = f"{base_driver}+psycopg"
    elif base_driver.startswith("sqlite"):
        sync_driver = f"{base_driver}+pysqlite"
    return parsed.set(drivername=sync_driver).render_as_string(hide_password=False)


def _build_database_url(
    shared_url: str,
    database: str,
    driver_suffix: str,
    *,
    username: str | None = None,
    password: str | None = None,
) -> str:
    parsed = make_url(shared_url)
    base_driver = _base_driver_name(parsed)
    updated = parsed.set(drivername=f"{base_driver}+{driver_suffix}", database=database)
    if username is not None:
        updated = updated.set(username=username)
    if password is not None:
        updated = updated.set(password=password)
    return updated.render_as_string(hide_password=False)


# ---------------------------------------------------------------------------
# Database provisioning helpers
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class DatabaseURLs:
    app_async_url: str
    app_sync_url: str
    admin_sync_url: str


def _has_distinct_admin_connection(database_urls: DatabaseURLs) -> bool:
    return database_urls.admin_sync_url != database_urls.app_sync_url


def _terminate_database_connections(connection: Any, database: str) -> None:
    connection.execute(
        sa_text(
            "SELECT pg_terminate_backend(pid) "
            "FROM pg_stat_activity "
            "WHERE datname = :db_name AND pid <> pg_backend_pid()"
        ),
        {"db_name": database},
    )


def _drop_database(admin_sync_url: str, database: str) -> None:
    engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as connection:
            _terminate_database_connections(connection, database)
            connection.execute(sa_text(f'DROP DATABASE IF EXISTS "{database}"'))
    finally:
        engine.dispose()


def _create_database(admin_sync_url: str, database: str, template: str | None = None) -> None:
    engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as connection:
            if template:
                connection.execute(
                    sa_text(f'CREATE DATABASE "{database}" WITH TEMPLATE "{template}"'),
                )
            else:
                connection.execute(sa_text(f'CREATE DATABASE "{database}"'))
    finally:
        engine.dispose()


def _ensure_app_role_and_grants(
    admin_sync_url: str, database: str, app_user: str, app_password: str
) -> None:
    sanitized_password = app_password.replace("'", "''")
    admin_engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with admin_engine.connect() as connection:
            connection.execute(
                sa_text(
                    f"""
                    DO $$
                    BEGIN
                        IF NOT EXISTS (
                            SELECT FROM pg_roles WHERE rolname = '{app_user}'
                        ) THEN
                            CREATE ROLE {app_user}
                                LOGIN
                                PASSWORD '{sanitized_password}'
                                NOSUPERUSER;
                        END IF;
                    END
                    $$;
                    """
                )
            )
            connection.execute(
                sa_text(f'GRANT CONNECT ON DATABASE "{database}" TO {app_user}')
            )
    finally:
        admin_engine.dispose()

    target_admin_url = (
        make_url(admin_sync_url)
        .set(database=database)
        .render_as_string(hide_password=False)
    )
    target_engine = create_engine(target_admin_url, isolation_level="AUTOCOMMIT")
    try:
        with target_engine.connect() as connection:
            connection.execute(sa_text(f"GRANT USAGE ON SCHEMA public TO {app_user}"))
            connection.execute(
                sa_text(f"GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO {app_user}")
            )
            connection.execute(
                sa_text(f"GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO {app_user}")
            )
            connection.execute(
                sa_text(
                    f"ALTER DEFAULT PRIVILEGES FOR ROLE CURRENT_USER IN SCHEMA public "
                    f"GRANT ALL PRIVILEGES ON TABLES TO {app_user}"
                )
            )
            connection.execute(
                sa_text(
                    f"ALTER DEFAULT PRIVILEGES FOR ROLE CURRENT_USER IN SCHEMA public "
                    f"GRANT ALL PRIVILEGES ON SEQUENCES TO {app_user}"
                )
            )
    finally:
        target_engine.dispose()


def _template_ready(template_sync_url: str) -> bool:
    engine = create_engine(template_sync_url)
    try:
        with engine.connect() as connection:
            exists = connection.execute(
                sa_text("SELECT to_regclass('public.alembic_version')"),
            ).scalar()
        return bool(exists)
    except Exception:
        return False
    finally:
        engine.dispose()


@contextmanager
def _temporary_env(overrides: dict[str, str], cache_clear: Callable | None = None) -> Iterator[None]:
    if not overrides:
        yield
        return

    previous_values = {key: os.environ.get(key) for key in overrides}
    for key, value in overrides.items():
        os.environ[key] = value
    if cache_clear:
        cache_clear()
    try:
        yield
    finally:
        if cache_clear:
            cache_clear()
        for key, prior in previous_values.items():
            if prior is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = prior


_CONNECTION_ERRORS: tuple[type[BaseException], ...] = (
    ConnectionError,
    ConnectionRefusedError,
    ConnectionResetError,
    OSError,
)

try:
    from sqlalchemy.exc import OperationalError

    _CONNECTION_ERRORS = (*_CONNECTION_ERRORS, OperationalError)
except ImportError:
    pass


def _attempt_migrations(sync_url: str, config: TestConfig) -> bool:
    if alembic_command is None or AlembicConfig is None:
        return False
    if config.alembic_ini_path is None:
        return False

    overrides = {"DATABASE_URL": _async_database_url(sync_url)}
    if "ENV" not in os.environ:
        overrides["ENV"] = "test"

    with _temporary_env(overrides, config.settings_cache_clear):
        cfg = AlembicConfig(str(config.alembic_ini_path))
        cfg.set_main_option("sqlalchemy.url", sync_url)

        for attempt in range(5):
            try:
                alembic_command.upgrade(cfg, "head")
                return True
            except _CONNECTION_ERRORS as exc:
                logger.warning("alembic.upgrade.connection_failure (attempt %d): %s", attempt + 1, exc)
                time.sleep(1)
            except ValueError as exc:
                message = str(exc).lower()
                if "greenlet" in message and "required" in message:
                    logger.warning("alembic.upgrade.missing_dependency: %s", exc)
                    return False
                raise

    return False


def _prepare_template_database(shared_url: str, config: TestConfig) -> None:
    lock_dir = Path(tempfile.gettempdir()) / f"{config.worker_db_prefix}-pytest"
    lock_dir.mkdir(parents=True, exist_ok=True)
    lock_file = lock_dir / "template-db.lock"

    template_sync_url = _build_database_url(shared_url, config.template_db_name, "psycopg")

    if FileLock is None:
        if _template_ready(template_sync_url):
            return
        admin_sync_url = _build_database_url(shared_url, "postgres", "psycopg")
        _drop_database(admin_sync_url, config.template_db_name)
        _create_database(admin_sync_url, config.template_db_name)
        applied = _attempt_migrations(template_sync_url, config)
        if not applied:
            raise RuntimeError("Failed to apply migrations to template database.")
        _ensure_app_role_and_grants(
            admin_sync_url, config.template_db_name, config.app_db_user, config.app_db_password
        )
        return

    lock = FileLock(str(lock_file), timeout=120)
    try:
        with lock:
            if _template_ready(template_sync_url):
                return
            admin_sync_url = _build_database_url(shared_url, "postgres", "psycopg")
            _drop_database(admin_sync_url, config.template_db_name)
            _create_database(admin_sync_url, config.template_db_name)
            applied = _attempt_migrations(template_sync_url, config)
            if not applied:
                raise RuntimeError("Failed to apply migrations to template database.")
            _ensure_app_role_and_grants(
                admin_sync_url, config.template_db_name, config.app_db_user, config.app_db_password
            )
    except FileLockTimeout as exc:  # pragma: no cover
        raise RuntimeError("Timed out waiting for template database lock") from exc


def _provision_worker_database(shared_url: str, worker_db: str, config: TestConfig) -> None:
    admin_sync_url = _build_database_url(shared_url, "postgres", "psycopg")
    _drop_database(admin_sync_url, worker_db)
    _create_database(admin_sync_url, worker_db, template=config.template_db_name)
    _ensure_app_role_and_grants(admin_sync_url, worker_db, config.app_db_user, config.app_db_password)


# ---------------------------------------------------------------------------
# Container lifecycle (shared across xdist workers)
# ---------------------------------------------------------------------------

_SHARED_POSTGRES_CONTAINER: ManagedPostgresContainer | None = None


def _ensure_shared_container_started() -> None:
    global _SHARED_POSTGRES_CONTAINER
    if os.getenv("PYTEST_DATABASE_URL"):
        return
    if _SHARED_POSTGRES_CONTAINER is not None:
        return
    if os.environ.get(SHARED_POSTGRES_URL_ENV):
        return
    if not DOCKER_AVAILABLE or not TESTCONTAINERS_AVAILABLE:
        return
    config = _get_config()
    container = ManagedPostgresContainer(config.postgres_image)
    container.start()
    _SHARED_POSTGRES_CONTAINER = container
    os.environ[SHARED_POSTGRES_URL_ENV] = container.get_connection_url()


# ---------------------------------------------------------------------------
# Worker / database naming
# ---------------------------------------------------------------------------

def _worker_identifier() -> str:
    return os.getenv("PYTEST_XDIST_WORKER", "local")


def _worker_database_name(config: TestConfig) -> str:
    suffix = "".join(ch if ch.isalnum() else "_" for ch in _worker_identifier().lower())
    if not suffix:
        suffix = "local"
    return f"{config.worker_db_prefix}_{suffix[:40]}"


# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

MIGRATIONS_APPLIED = False
WORKER_DATABASE_CLONED = False


# ---------------------------------------------------------------------------
# Pytest hooks (loaded when this module is used as a plugin)
# ---------------------------------------------------------------------------

def pytest_configure(config: pytest.Config) -> None:  # type: ignore[override]
    if hasattr(config, "workerinput"):
        worker_id = config.workerinput.get("workerid")  # type: ignore[assignment]
        if worker_id:
            os.environ.setdefault("PYTEST_XDIST_WORKER", worker_id)
        shared_url = config.workerinput.get("shared_postgres_url")
        if shared_url:
            os.environ[SHARED_POSTGRES_URL_ENV] = shared_url
        return
    _ensure_shared_container_started()


@pytest.hookimpl(optionalhook=True)
def pytest_configure_node(node: pytest.nodes.Node) -> None:  # type: ignore[override, name-defined]
    _ensure_shared_container_started()
    shared_url = os.environ.get(SHARED_POSTGRES_URL_ENV)
    if shared_url:
        node.workerinput["shared_postgres_url"] = shared_url  # type: ignore[attr-defined]
    worker_id = getattr(node, "workerid", None)  # type: ignore[attr-defined]
    if worker_id is not None:
        node.workerinput["workerid"] = worker_id


def pytest_unconfigure(config: pytest.Config) -> None:  # type: ignore[override]
    if hasattr(config, "workerinput"):
        return
    global _SHARED_POSTGRES_CONTAINER
    container = _SHARED_POSTGRES_CONTAINER
    if container is not None:
        container.stop()
        _SHARED_POSTGRES_CONTAINER = None
        os.environ.pop(SHARED_POSTGRES_URL_ENV, None)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def database_urls() -> DatabaseURLs:
    config = _get_config()
    app_override = os.getenv("PYTEST_DATABASE_URL")
    admin_override = os.getenv("PYTEST_DATABASE_ADMIN_URL")
    if app_override:
        app_async_url = app_override
        app_sync_url = _sync_database_url(app_override)
        admin_source = admin_override or app_override
        admin_sync_url = _sync_database_url(admin_source)
        return DatabaseURLs(
            app_async_url=app_async_url,
            app_sync_url=app_sync_url,
            admin_sync_url=admin_sync_url,
        )

    shared_url = os.getenv(SHARED_POSTGRES_URL_ENV)
    if shared_url:
        worker_db = _worker_database_name(config)
        _prepare_template_database(shared_url, config)
        _provision_worker_database(shared_url, worker_db, config)
        global WORKER_DATABASE_CLONED
        WORKER_DATABASE_CLONED = True
        app_async_url = _build_database_url(
            shared_url, worker_db, "asyncpg",
            username=config.app_db_user, password=config.app_db_password,
        )
        app_sync_url = _build_database_url(
            shared_url, worker_db, "psycopg",
            username=config.app_db_user, password=config.app_db_password,
        )
        admin_sync_url = _build_database_url(shared_url, worker_db, "psycopg")
        return DatabaseURLs(
            app_async_url=app_async_url,
            app_sync_url=app_sync_url,
            admin_sync_url=admin_sync_url,
        )

    # Fallback to local dev defaults
    default_async = f"postgresql+asyncpg://{config.app_db_user}:{config.app_db_password}@localhost:5433/service"
    default_sync = f"postgresql+psycopg://{config.app_db_user}:{config.app_db_password}@localhost:5433/service"
    default_admin = "postgresql+psycopg://postgres:postgres@localhost:5433/service"
    return DatabaseURLs(
        app_async_url=default_async,
        app_sync_url=default_sync,
        admin_sync_url=default_admin,
    )


@pytest.fixture(scope="session")
def database_url(database_urls: DatabaseURLs) -> str:
    return database_urls.app_async_url


@pytest.fixture(scope="session")
def configure_test_settings(database_urls: DatabaseURLs) -> Iterator[None]:
    config = _get_config()
    if config.settings_cache_clear:
        config.settings_cache_clear()

    env_overrides = {"DATABASE_URL": database_urls.app_async_url, "ENV": "test"}
    env_overrides.update(config.settings_overrides)

    previous_values: dict[str, str | None] = {}
    for key, value in env_overrides.items():
        previous_values[key] = os.environ.get(key)
        os.environ[key] = value

    if config.dispose_engine:
        asyncio.run(config.dispose_engine())

    yield

    if config.settings_cache_clear:
        config.settings_cache_clear()
    for key, prior in previous_values.items():
        if prior is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = prior
    if config.dispose_engine:
        asyncio.run(config.dispose_engine())


@pytest.fixture(scope="session")
def apply_migrations(configure_test_settings: None, database_urls: DatabaseURLs) -> Iterator[None]:
    global MIGRATIONS_APPLIED
    config = _get_config()

    if WORKER_DATABASE_CLONED:
        MIGRATIONS_APPLIED = True
        yield
        if config.dispose_engine:
            asyncio.run(config.dispose_engine())
        return

    MIGRATIONS_APPLIED = _attempt_migrations(database_urls.admin_sync_url, config)
    if not MIGRATIONS_APPLIED:
        if config.graceful_skip_without_db:
            yield
            return
        pytest.skip("Database not available for migrations.")

    target_db = make_url(database_urls.admin_sync_url).database
    if target_db and _has_distinct_admin_connection(database_urls):
        _ensure_app_role_and_grants(
            database_urls.admin_sync_url, target_db, config.app_db_user, config.app_db_password
        )
    yield
    if config.dispose_engine:
        asyncio.run(config.dispose_engine())


@pytest_asyncio.fixture
async def dispose_async_engine() -> AsyncIterator[None]:
    """Dispose the async engine after each test to prevent event loop mismatch."""
    yield
    config = _get_config()
    if config.dispose_engine:
        await config.dispose_engine()


@pytest_asyncio.fixture
async def reset_database_state() -> AsyncIterator[None]:
    if not MIGRATIONS_APPLIED:
        yield
        return

    config = _get_config()
    db_url = os.environ.get("DATABASE_URL", "")
    sync_url = _sync_database_url(db_url)
    engine = create_engine(sync_url)
    try:
        with engine.begin() as connection:
            connection.execute(sa_text(_TRUNCATE_TABLES_SQL))
            for sql in config.seed_sql:
                connection.execute(sa_text(sql))
    finally:
        engine.dispose()
    yield


@pytest_asyncio.fixture
async def db_session(
    configure_test_settings: None,
    apply_migrations: None,
    reset_database_state: None,
    dispose_async_engine: None,
    database_urls: DatabaseURLs,
) -> AsyncIterator[AsyncSession]:
    """Application session (RLS enforced if app role configured)."""
    engine = create_async_engine(database_urls.app_async_url, echo=False)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()
    await engine.dispose()


@pytest_asyncio.fixture
async def admin_session(
    configure_test_settings: None,
    apply_migrations: None,
    reset_database_state: None,
    dispose_async_engine: None,
    database_urls: DatabaseURLs,
) -> AsyncIterator[AsyncSession]:
    """Admin session using postgres superuser (bypasses RLS)."""
    admin_async_url = _async_database_url(database_urls.admin_sync_url)
    engine = create_async_engine(admin_async_url, echo=False)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()
    await engine.dispose()


@pytest_asyncio.fixture
async def async_client(
    configure_test_settings: None,
    apply_migrations: None,
    reset_database_state: None,
    dispose_async_engine: None,
) -> AsyncIterator[Any]:
    """ASGI test client using TestConfig.create_app."""
    config = _get_config()
    if config.create_app is None:
        pytest.skip("TestConfig.create_app not configured")
        return  # pragma: no cover

    if ASGITransport is None or AsyncClient is None:
        pytest.skip("httpx not installed (install with: pip install spaps-server-quickstart[testing])")
        return  # pragma: no cover

    app = config.create_app()

    if config.get_db_session and not MIGRATIONS_APPLIED:
        # StubSession fallback: allow tests to run without a real database
        from types import SimpleNamespace

        class _StubSession:
            async def execute(self, statement: Any) -> Any:
                text_str = str(statement).strip().lower()
                if "count" in text_str:
                    return SimpleNamespace(scalar_one=lambda: 0, scalar_one_or_none=lambda: 0)
                if "alembic_version" in text_str:
                    return SimpleNamespace(scalar_one=lambda: None, scalar_one_or_none=lambda: None)
                return SimpleNamespace(scalar_one=lambda: 1, scalar_one_or_none=lambda: 1)

        async def _stub_dep() -> AsyncIterator[Any]:
            yield _StubSession()

        app.dependency_overrides[config.get_db_session] = _stub_dep

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as client:
        client.app = app  # type: ignore[attr-defined]
        yield client


@pytest.fixture(scope="session", autouse=True)
def configure_celery_eager_mode() -> Iterator[None]:
    """Configure Celery to run tasks synchronously in tests."""
    config = _get_config()
    if config.celery_app_import:
        try:
            parts = config.celery_app_import.rsplit(".", 1)
            module = importlib.import_module(parts[0])
            celery_app = getattr(module, parts[1])
            celery_app.conf.update(
                task_always_eager=True,
                task_eager_propagates=True,
            )
        except (ImportError, AttributeError):
            pass
    yield


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "TestConfig",
    "register_test_config",
    "DatabaseURLs",
    "ManagedPostgresContainer",
    "MIGRATIONS_APPLIED",
    "WORKER_DATABASE_CLONED",
    "DOCKER_AVAILABLE",
    "TESTCONTAINERS_AVAILABLE",
]
