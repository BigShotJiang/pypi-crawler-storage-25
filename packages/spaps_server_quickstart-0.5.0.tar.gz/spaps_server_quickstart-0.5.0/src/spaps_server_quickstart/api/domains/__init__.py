"""SPAPS API domain routers."""
