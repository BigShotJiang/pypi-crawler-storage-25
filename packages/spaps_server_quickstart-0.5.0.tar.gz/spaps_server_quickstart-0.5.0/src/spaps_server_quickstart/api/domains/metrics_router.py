"""
SPAPS metrics endpoints.

Provides Prometheus-compatible metrics and a JSON variant:
- GET /api/metrics — Prometheus text format
- GET /api/metrics/json — JSON format
"""

from __future__ import annotations

import os
import time
from datetime import UTC, datetime

from fastapi import APIRouter
from starlette.responses import PlainTextResponse

router = APIRouter(tags=["metrics"])

_START_TIME = time.monotonic()
_REQUEST_COUNT: int = 0
_ERROR_COUNT: int = 0


def increment_request_count() -> None:
    global _REQUEST_COUNT
    _REQUEST_COUNT += 1


def increment_error_count() -> None:
    global _ERROR_COUNT
    _ERROR_COUNT += 1


@router.get("/api/metrics", response_class=PlainTextResponse)
async def metrics_prometheus() -> PlainTextResponse:
    """Prometheus-compatible metrics in text exposition format."""
    uptime = time.monotonic() - _START_TIME
    lines = [
        "# HELP spaps_uptime_seconds Time since service start",
        "# TYPE spaps_uptime_seconds gauge",
        f"spaps_uptime_seconds {uptime:.1f}",
        "",
        "# HELP spaps_requests_total Total requests served",
        "# TYPE spaps_requests_total counter",
        f"spaps_requests_total {_REQUEST_COUNT}",
        "",
        "# HELP spaps_errors_total Total error responses",
        "# TYPE spaps_errors_total counter",
        f"spaps_errors_total {_ERROR_COUNT}",
        "",
        "# HELP spaps_info Service information",
        "# TYPE spaps_info gauge",
        f'spaps_info{{version="{os.environ.get("GIT_COMMIT_SHA", "1.0.0")}"}} 1',
        "",
    ]
    return PlainTextResponse(
        content="\n".join(lines),
        media_type="text/plain; version=0.0.4",
    )


@router.get("/api/metrics/json")
async def metrics_json() -> dict:
    """JSON-formatted metrics."""
    uptime = time.monotonic() - _START_TIME
    return {
        "success": True,
        "data": {
            "uptime_seconds": round(uptime, 1),
            "requests_total": _REQUEST_COUNT,
            "errors_total": _ERROR_COUNT,
            "version": os.environ.get("GIT_COMMIT_SHA", "1.0.0"),
        },
        "metadata": {
            "timestamp": datetime.now(UTC).isoformat(),
        },
    }
