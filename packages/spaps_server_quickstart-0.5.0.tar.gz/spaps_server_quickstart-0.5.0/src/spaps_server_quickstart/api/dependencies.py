"""
Common API dependencies for role-based access control.
"""

from __future__ import annotations

from fastapi import HTTPException, status
from starlette.requests import Request

from ..auth import AuthenticatedUser


def require_authenticated_user(request: Request) -> AuthenticatedUser:
    """
    Retrieve the authenticated user from request state.

    The SpapsAuthMiddleware attaches an `AuthenticatedUser` instance on successful
    authentication. Tests can override this dependency to provide stubbed users.
    """
    user = getattr(request.state, "authenticated_user", None)
    if not isinstance(user, AuthenticatedUser):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_role(role: str):
    """
    Factory for role-checking dependencies.

    Usage:
        @router.get("/admin-only")
        def admin_endpoint(user: AuthenticatedUser = Depends(require_role("admin"))):
            ...
    """

    def _dependency(request: Request) -> AuthenticatedUser:
        user = require_authenticated_user(request)
        roles = {r.lower() for r in user.roles}
        if role.lower() not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"{role.capitalize()} role required",
            )
        return user

    return _dependency


def require_any_role(*roles: str):
    """
    Factory for checking if user has any of the specified roles.

    Usage:
        @router.get("/staff-only")
        def staff_endpoint(user: AuthenticatedUser = Depends(require_any_role("admin", "staff"))):
            ...
    """

    def _dependency(request: Request) -> AuthenticatedUser:
        user = require_authenticated_user(request)
        user_roles = {r.lower() for r in user.roles}
        required_roles = {r.lower() for r in roles}
        if not user_roles.intersection(required_roles):
            role_list = ", ".join(roles)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"One of these roles required: {role_list}",
            )
        return user

    return _dependency
