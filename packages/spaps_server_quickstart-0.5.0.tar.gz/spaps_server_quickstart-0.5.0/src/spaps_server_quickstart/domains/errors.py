"""
Domain-level exceptions.

Domain code raises these typed exceptions. API routers catch them and
translate into the standard response envelope with the correct HTTP status.
"""

from __future__ import annotations


class DomainError(Exception):
    """Base for all domain errors. Carries a machine-readable code and optional details."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        status_code: int = 400,
        details: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}


# --- Auth / Identity ---


class InvalidCredentialsError(DomainError):
    def __init__(self, message: str = "Invalid credentials") -> None:
        super().__init__("INVALID_CREDENTIALS", message, status_code=401)


class UnauthorizedError(DomainError):
    def __init__(self, message: str = "Authentication required") -> None:
        super().__init__("UNAUTHORIZED", message, status_code=401)


class ForbiddenError(DomainError):
    def __init__(self, message: str = "Insufficient permissions") -> None:
        super().__init__("FORBIDDEN", message, status_code=403)


class InvalidApplicationError(DomainError):
    def __init__(self, message: str = "Missing or invalid API key") -> None:
        super().__init__("INVALID_APPLICATION", message, status_code=401)


class InvalidTokenError(DomainError):
    def __init__(self, message: str = "Expired or invalid token") -> None:
        super().__init__("INVALID_TOKEN", message, status_code=401)


class InvalidRefreshTokenError(DomainError):
    def __init__(self, message: str = "Expired or blacklisted refresh token", code: str = "INVALID_REFRESH_TOKEN") -> None:
        super().__init__(code, message, status_code=401)


class InvalidSignatureError(DomainError):
    def __init__(self, message: str = "Signature verification failed") -> None:
        super().__init__("INVALID_SIGNATURE", message, status_code=401)


class InvalidNonceError(DomainError):
    def __init__(self, message: str = "Expired or already-used nonce") -> None:
        super().__init__("INVALID_NONCE", message, status_code=401)


class InvalidStateError(DomainError):
    def __init__(
        self,
        message: str = "Invalid state",
        *,
        status_code: int = 400,
    ) -> None:
        super().__init__("INVALID_STATE", message, status_code=status_code)


class InvalidCodeError(DomainError):
    def __init__(self, message: str = "Invalid, expired, or already used code") -> None:
        super().__init__("INVALID_CODE", message, status_code=401)


# --- Validation ---


class ValidationError(DomainError):
    def __init__(self, message: str = "Request validation failed", **kwargs) -> None:
        super().__init__("VALIDATION_ERROR", message, status_code=400, **kwargs)


class EmailAlreadyExistsError(DomainError):
    def __init__(self, message: str = "Email already exists") -> None:
        super().__init__("EMAIL_ALREADY_EXISTS", message, status_code=400)


class WeakPasswordError(DomainError):
    def __init__(self, message: str = "Password does not meet security requirements") -> None:
        super().__init__("WEAK_PASSWORD", message, status_code=400)


class InvalidEmailError(DomainError):
    def __init__(self, message: str = "Invalid email format") -> None:
        super().__init__("INVALID_EMAIL", message, status_code=400)


class MissingEmailError(DomainError):
    def __init__(self, message: str = "Email required but missing") -> None:
        super().__init__("MISSING_EMAIL", message, status_code=400)


class MissingTokenError(DomainError):
    def __init__(self, message: str = "Token required but missing") -> None:
        super().__init__("MISSING_TOKEN", message, status_code=400)


class MissingCodeError(DomainError):
    def __init__(self, message: str = "Missing authorization code") -> None:
        super().__init__("MISSING_CODE", message, status_code=400)


class MissingWalletAddressError(DomainError):
    def __init__(self, message: str = "Wallet address required but missing") -> None:
        super().__init__("MISSING_WALLET_ADDRESS", message, status_code=400)


class InvalidMessageFormatError(DomainError):
    def __init__(self, message: str = "No nonce found in signed message") -> None:
        super().__init__("INVALID_MESSAGE_FORMAT", message, status_code=400)


class UnsupportedWalletError(DomainError):
    def __init__(self, message: str = "Unknown chain type") -> None:
        super().__init__("UNSUPPORTED_WALLET", message, status_code=400)


class UnknownClientError(DomainError):
    def __init__(self, message: str = "Device flow client_id does not match any application") -> None:
        super().__init__("UNKNOWN_CLIENT", message, status_code=400)


# --- Resources ---


class NotFoundError(DomainError):
    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class NotImplementedError_(DomainError):
    """Named with trailing underscore to avoid shadowing builtin."""

    def __init__(self, message: str = "Feature not yet available") -> None:
        super().__init__("NOT_IMPLEMENTED", message, status_code=501)


# --- Rate Limiting ---


class RateLimitExceededError(DomainError):
    def __init__(self, message: str = "Too many requests") -> None:
        super().__init__("RATE_LIMIT_EXCEEDED", message, status_code=429)


# --- Email ---


class EmailConfigurationError(DomainError):
    def __init__(self, message: str = "Email service misconfigured") -> None:
        super().__init__("EMAIL_CONFIGURATION_ERROR", message, status_code=400)


# --- Server ---


class ServerError(DomainError):
    def __init__(self, message: str = "Internal server error") -> None:
        super().__init__("SERVER_ERROR", message, status_code=500)


class ServiceUnavailableError(DomainError):
    def __init__(self, message: str = "Service temporarily unavailable") -> None:
        super().__init__("SERVICE_UNAVAILABLE", message, status_code=503)


class DatabaseError(DomainError):
    def __init__(self, message: str = "Database operation failed") -> None:
        super().__init__("DATABASE_ERROR", message, status_code=500)
