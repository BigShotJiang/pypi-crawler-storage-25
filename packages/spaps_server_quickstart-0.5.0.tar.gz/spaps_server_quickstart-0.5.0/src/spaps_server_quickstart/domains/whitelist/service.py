"""Business logic for the whitelist domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import NotFoundError
from . import repository as repo
from .models import EmailWhitelist

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _entry_to_dict(entry: EmailWhitelist) -> dict[str, Any]:
    """Convert a whitelist model instance to a serialisable dict."""
    return {
        "id": str(entry.id),
        "application_id": str(entry.application_id),
        "email": entry.email,
        "tier": entry.tier,
        "bypass_payment": entry.bypass_payment,
        "metadata": entry.metadata_,
        "created_by": str(entry.created_by) if entry.created_by else None,
        "created_at": entry.created_at.isoformat() if entry.created_at else None,
        "updated_at": entry.updated_at.isoformat() if entry.updated_at else None,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def check_whitelist(
    db: AsyncSession,
    *,
    application_id: UUID,
    email: str,
) -> dict[str, Any]:
    """Check whether an email is whitelisted for an application.

    Returns a dict with an optional ``entry`` key and a ``message``.
    """
    entry = await repo.get_by_email(db, application_id, email.lower())
    if entry is not None:
        return {
            "entry": _entry_to_dict(entry),
            "message": f"Email {email.lower()} is whitelisted",
        }
    return {
        "message": f"Email {email.lower()} is not whitelisted",
    }


async def add_to_whitelist(
    db: AsyncSession,
    *,
    application_id: UUID,
    email: str,
    tier: str = "premium",
    bypass_payment: bool = True,
    metadata: dict[str, Any] | None = None,
    created_by: UUID | None = None,
) -> dict[str, Any]:
    """Add an email to the application whitelist.

    Raises ``DuplicateEntryError`` (409) if the email is already whitelisted.
    """
    from ..errors import DomainError

    existing = await repo.get_by_email(db, application_id, email.lower())
    if existing is not None:
        raise DomainError(
            code="DUPLICATE_ENTRY",
            message=f"Email {email.lower()} is already whitelisted",
            status_code=409,
        )

    entry = await repo.create(
        db,
        application_id=application_id,
        email=email,
        tier=tier,
        bypass_payment=bypass_payment,
        metadata=metadata,
        created_by=created_by,
    )
    return {
        "entry": _entry_to_dict(entry),
        "message": f"Email {email.lower()} successfully added to whitelist",
    }


async def bulk_add(
    db: AsyncSession,
    *,
    application_id: UUID,
    entries: list[dict[str, Any]],
    created_by: UUID | None = None,
) -> dict[str, Any]:
    """Bulk-add emails to the application whitelist.

    Returns a summary with successful, failed, and total counts.
    """
    successful, failed = await repo.bulk_create(
        db,
        application_id=application_id,
        entries=entries,
        created_by=created_by,
    )
    total = len(entries)
    added = len(successful)
    return {
        "message": f"Added {added} of {total} emails",
        "successful": [_entry_to_dict(e) for e in successful],
        "failed": failed,
        "total": total,
    }


async def list_whitelist(
    db: AsyncSession,
    *,
    application_id: UUID,
    limit: int = 10,
    offset: int = 0,
    tier: str | None = None,
) -> dict[str, Any]:
    """List whitelist entries for an application with pagination."""
    entries = await repo.list_entries(
        db,
        application_id,
        limit=limit,
        offset=offset,
        tier=tier,
    )
    total = await repo.count(db, application_id, tier=tier)
    return {
        "entries": [_entry_to_dict(e) for e in entries],
        "total": total,
    }


async def update_entry(
    db: AsyncSession,
    *,
    application_id: UUID,
    email: str,
    tier: str | None = None,
    bypass_payment: bool | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Update an existing whitelist entry.

    Raises ``NotFoundError`` if the entry does not exist.
    """
    kwargs: dict[str, Any] = {}
    if tier is not None:
        kwargs["tier"] = tier
    if bypass_payment is not None:
        kwargs["bypass_payment"] = bypass_payment
    if metadata is not None:
        kwargs["metadata"] = metadata

    entry = await repo.update_entry(
        db,
        application_id,
        email,
        **kwargs,
    )
    if entry is None:
        raise NotFoundError(f"Whitelist entry for {email.lower()} not found")

    return {
        "entry": _entry_to_dict(entry),
        "message": f"Whitelist entry for {email.lower()} updated successfully",
    }


async def get_stats(
    db: AsyncSession,
    *,
    application_id: UUID,
    whitelist_enabled: bool = False,
) -> dict[str, Any]:
    """Get whitelist statistics for an application."""
    stats = await repo.get_stats(
        db,
        application_id,
        whitelist_enabled=whitelist_enabled,
    )
    return {
        "stats": {
            "enabled": stats["enabled"],
            "total": stats["total"],
            "tierBreakdown": [
                {"tier": t["tier"], "count": t["count"]}
                for t in stats["tier_breakdown"]
            ],
        },
    }


async def clear_whitelist(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Remove all whitelist entries for an application."""
    deleted = await repo.clear_all(db, application_id)
    return {
        "message": f"Cleared {deleted} entries from whitelist",
    }


async def remove_from_whitelist(
    db: AsyncSession,
    *,
    application_id: UUID,
    email: str,
) -> dict[str, Any]:
    """Remove a single email from the whitelist.

    Raises ``NotFoundError`` if the entry does not exist.
    """
    deleted = await repo.delete_by_email(db, application_id, email.lower())
    if not deleted:
        raise NotFoundError(f"Whitelist entry for {email.lower()} not found")
    return {
        "message": f"Email {email.lower()} removed from whitelist",
    }
