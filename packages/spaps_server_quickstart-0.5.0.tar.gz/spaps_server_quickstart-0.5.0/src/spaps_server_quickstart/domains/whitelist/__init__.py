"""Whitelist domain — email whitelist management for SPAPS applications."""
