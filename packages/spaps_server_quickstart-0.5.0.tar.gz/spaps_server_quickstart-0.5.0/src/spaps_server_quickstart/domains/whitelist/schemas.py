"""Pydantic request/response schemas for whitelist endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, EmailStr, Field


# ---------------------------------------------------------------------------
# Shared
# ---------------------------------------------------------------------------

TierType = Literal["basic", "premium", "enterprise"]


class WhitelistEntry(BaseModel):
    """Canonical representation of a whitelist entry."""

    id: str
    application_id: str
    email: str
    tier: str
    bypass_payment: bool
    metadata: dict[str, Any] | None = None
    created_by: str | None = None
    created_at: str
    updated_at: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CheckWhitelistParams(BaseModel):
    """GET /whitelist/check query parameters."""

    email: EmailStr


class AddWhitelistRequest(BaseModel):
    """POST /whitelist"""

    email: EmailStr
    tier: TierType = "premium"
    bypass_payment: bool = True
    metadata: dict[str, Any] | None = None


class BulkEmailEntry(BaseModel):
    """Single entry in a bulk add request."""

    email: EmailStr
    tier: TierType = "premium"
    metadata: dict[str, Any] | None = None


class BulkAddWhitelistRequest(BaseModel):
    """POST /whitelist/bulk"""

    emails: list[BulkEmailEntry] = Field(..., min_length=1, max_length=100)


class UpdateWhitelistRequest(BaseModel):
    """PUT /whitelist/{email}"""

    tier: TierType | None = None
    bypass_payment: bool | None = None
    metadata: dict[str, Any] | None = None


class ListWhitelistParams(BaseModel):
    """GET /whitelist query parameters."""

    limit: int = Field(default=10, ge=1, le=100)
    offset: int = Field(default=0, ge=0)
    tier: TierType | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class CheckWhitelistResponse(BaseModel):
    """GET /whitelist/check -- success payload."""

    entry: WhitelistEntry | None = None
    message: str


class AddWhitelistResponse(BaseModel):
    """POST /whitelist -- success payload."""

    entry: WhitelistEntry
    message: str


class BulkFailedEntry(BaseModel):
    """A single failed entry in a bulk add response."""

    email: str
    error: str


class BulkAddWhitelistResponse(BaseModel):
    """POST /whitelist/bulk -- success payload."""

    message: str
    successful: list[WhitelistEntry]
    failed: list[BulkFailedEntry]
    total: int


class ListWhitelistResponse(BaseModel):
    """GET /whitelist -- success payload."""

    entries: list[WhitelistEntry]
    total: int


class UpdateWhitelistResponse(BaseModel):
    """PUT /whitelist/{email} -- success payload."""

    entry: WhitelistEntry
    message: str


class TierBreakdownItem(BaseModel):
    """A single tier count in the stats response."""

    tier: str
    count: int


class WhitelistStats(BaseModel):
    """Statistics shape nested under the stats response."""

    enabled: bool
    total: int
    tierBreakdown: list[TierBreakdownItem]


class StatsResponse(BaseModel):
    """GET /whitelist/stats -- success payload."""

    stats: WhitelistStats


class ClearWhitelistResponse(BaseModel):
    """DELETE /whitelist/all -- success payload."""

    message: str


class RemoveWhitelistResponse(BaseModel):
    """DELETE /whitelist/{email} -- success payload."""

    message: str
